 /*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2010  Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2010  Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef __CLOCK_HAL_PVT_H__
#define __CLOCK_HAL_PVT_H__

#include <sven_devh.h>
#include <gen3_clock.h>
#include <ismd_global_defs.h>
#include <clock_hal_if.h>

/*
 * Frequency of the gen3 clocks.  Note that 90KHz,
 * 180KHz and 27MHz are supported in the hardware.  They
 * are also supported in this HAL code by just defining
 * the desired frequency.
 */

#define HW_CLOCK_FREQUENCY_KHZ ((uint64_t)90)    /*  90kHz */
//#define HW_CLOCK_FREQUENCY_KHZ ((uint64_t)180)   /* 180kHz */
//#define HW_CLOCK_FREQUENCY_KHZ ((uint64_t)27000) /*  27MHz */

/*Timescaling macros*/
#define scale_ismd_time_to_hw_time(time) ((uint64_t)time)
#define scale_hw_time_to_ismd_time(time) ((ismd_time_t)time)
/*
 * Functions available from clock_hal_common.c. 
 * The addresses of these functions may be used by the SOC specific HALs
 * to populate the function pointers in clk_hal_ops_t during 
 * initialization of the HAL.
 */

/* Read a value from a clock's 64-bit counter */
ismd_time_t cmn_clk_hal_read_clock(smd_clock_hal *clk_hal,
                                 clock_hal_dev_t clock );

/* Write a value to the clock's 64-bit counter */
void cmn_clk_hal_write_clock( smd_clock_hal *clk_hal,
                            clock_hal_dev_t clock,
                            ismd_time_t     time );

/* Adjust the value of the clock's 64-bit counter */
void cmn_clk_hal_adjust_clock( smd_clock_hal *clk_hal,
                             clock_hal_dev_t clock,
                             int64_t     adjustment );


/*
 * Read the last timestamp value captured by the clock device.  The
 * value was captured the last time the trigger source was active.
 * Return false if the clock does not support timestamping.  Return
 * ((uint64_t)-1) if the trigger source has never activated.
 */
ismd_time_t cmn_clk_hal_get_last_trigger_time( smd_clock_hal *clk_hal, clock_hal_dev_t clk);


/* 
 * After reading the last trigger time using clock_hal_get_last_trigger_time or 
 * clock_hal_trigger_event API client has to acknowledge the read using this API.  
 * Until an acknowledgement is recieved, no TS source would be able to take a 
 * snapshot of the clock value at PCR arrivals.  
 */
void cmn_clk_hal_ack_last_trigger_time( smd_clock_hal *clk_hal, clock_hal_dev_t clk);



/*
 * Schedule an "alarm" callback when the clock's counter value is
 * greater than or equal to the specified time.  Return false if
 * alarm scheduling is not supported on this clock device or if
 * there is already an alarm scheduled for this clock device.
 */
void cmn_clk_hal_schedule_alarm( smd_clock_hal *clk_hal,
                               clock_hal_dev_t   clock,
                               ismd_time_t        time,
                               clock_callback_t callback,
                               void *clock_alarm);


/*
 * Cancel the currently schedule alarm callback.  Any scheduled
 * callback must not be called after this function returns.
 * Return false if alarm scheduling is not supported on this
 * clock device.
 */
void cmn_clk_hal_cancel_alarm(  smd_clock_hal *clk_hal, clock_hal_dev_t clock );

/*
 * Assign a specific clock source to drive a clock device's counter.
 * The value of clock_src is implementation-dependent and the valid
 * values must be specified in an implementation-dependent include
 * file.  Return false if the specified source is not supported on
 * this clock.
 */
ismd_result_t cmn_clk_hal_set_timestamp_trigger_source(  smd_clock_hal *clk_hal, clock_hal_dev_t clock,
                                              ismd_clock_trigger_source_t trigger_src );

/*
 * Assign a trigger source for timstamping.  When the specified
 * source signal is active, the clock device will capture the
 * value of it's counter and store it as a timestamp.  the value
 * of trigger_src is implementation-dependent and the valid values
 * must be specified in an implementation-dependent include file.
 * Return false if the specified source is not supported on the
 * clock device.
 */
ismd_clock_trigger_source_t cmn_clk_hal_get_timestamp_trigger_source( smd_clock_hal *clk_hal, clock_hal_dev_t clock );


/*clock_hal_route : Selects which DDS output drives the TS ouput and TS input channels.  
When this API is called it will immediately switch to the new destination */
void cmn_clk_hal_route( smd_clock_hal *clk_hal, clock_hal_dev_t clock, ismd_clock_dest_t destination);


/*
 * Adjust the frequency of a clock device's source clock signal.
 * The  adjustment is in parts per million (ppm).  The adjustment can be positive or negative.
 * Positive adjustment implies the frequency would be increased by "adjustment"
 * ppm and negative frequency implies the frequency would be decreased by
 * "adjustment" ppm.

 * If the master clock source is VCXO and the user tries to go beyond range, the
 * frequency will be saturated at the vcxo upper frequency limit and similarly in
 * the lower direction.  In saturation case, return code of ISMD_ERROR_OUT_OF_RANGE
 * will be returned to the driver.

 * This API will also adjust the local dds associated to the master dds, by the same amount
 * as "adjustment" so that the master dds/vcxo and local dds are in sync all the time.
 * Hence giving the opportunity to switch between master clock and local clock
 * smoothly.

 * The maximum frequency that can be programmed in DDS is 2^26 Hz.
 */
ismd_result_t cmn_clk_hal_adjust_frequency( smd_clock_hal *clk_hal,
                                          clock_hal_dev_t clock,
                                          int       adjustment );


/* It reads the last time in the VSYNC timestamp register.  VSYNC timestamp register
contains the last video flip time.  This timestamp register is driven by Display pipe.
There are two display pipes A and B.  The API will return the respective VSYNC timestamp
according to the request.  */

ismd_time_t cmn_clk_hal_get_last_vsync_time( smd_clock_hal *clk_hal, clock_hal_dev_t clock);


/*clock_hal_set_vsync_timestamp_pipe :  Selects Vsync PIPE A or B.  By default the pipe is set to DISPLAY PIPE A on initialization. */

ismd_result_t cmn_clk_hal_set_vsync_timestamp_pipe( smd_clock_hal *clk_hal,
                                                  clock_hal_dev_t clock,
                                                  ismd_clock_vsync_source_t pipe);

/* clock_hal_make_primary:  Makes the requested clock primary.  Any changes made to the primary clock also apply to the local DDS
                  associated to the clock to avoid jumps during primary to local and local to primary transitions.  */
void cmn_clk_hal_make_primary( smd_clock_hal *clk_hal, clock_hal_dev_t clock );

/*clock_hal_reset_primary : Using this API the client can drive the requested clock using local DDS rather then master DDS.  If the
                  clock is not driven by primary currently it will not have any effect */

void cmn_clk_hal_reset_primary( smd_clock_hal *clk_hal, clock_hal_dev_t clock );

/*clock_hal_trigger_event :  This API can be used to trigger a software event.  Only one trigger source can drive the timestamping logic.
                  Either one of the four TS IN sources, External Trigger or Software Event.  */

void cmn_clk_hal_trigger_event( smd_clock_hal *clk_hal, clock_hal_dev_t clock);

/* Sets the clock source of the Master DDS, either to VCXO or Master VCXO */
//source : VCXO = 0, MASTER_DDS = 1
ismd_result_t cmn_clk_hal_set_clock_source(smd_clock_hal      *clk_hal, 
                                         ismd_clock_source_t source);

int cmn_clk_hal_get_type( smd_clock_hal *clk_hal, clock_hal_dev_t clock );

void cmn_clk_hal_set_freq_calib_offset(smd_clock_hal *clk_hal,
                                     int           offset);

ismd_result_t cmn_clk_hal_set_signal(smd_clock_hal *clk_hal, 
                                   clock_hal_dev_t clock,
                                   int            signal);
ismd_result_t cmn_clk_hal_set_frequency(smd_clock_hal *clk_hal, 
                                      clock_hal_dev_t clock, 
                                      int            offset);

void cmn_clk_hal_set_dds_freq( smd_clock_hal *clk_hal,
                           clock_hal_dev_t clock,
                           uint32_t       freq);
						   
void cmn_clk_hal_set_master_dds_freq( smd_clock_hal *clk_hal,
                                  clock_hal_dev_t clock,
                                  uint32_t       freq);		
								  
ismd_result_t cmn_clk_hal_handle_freq_change( smd_clock_hal *clk_hal,
                                          clock_hal_dev_t  clock,
                                          int         adjustment,
                                          uint32_t          freq);
										  
ismd_result_t cmn_clk_hal_set_vcxo_freq( smd_clock_hal *clk_hal,
                                     clock_hal_dev_t  clock,
                                     int offset );										  
									 
ismd_result_t cmn_clk_hal_set_power_state( smd_clock_hal *clk_hal, 
									 icepm_state_t requested_state );

									  
#endif // __CLOCK_HAL__PVT_H__
