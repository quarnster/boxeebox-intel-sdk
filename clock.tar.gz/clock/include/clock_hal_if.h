 /*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2010  Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2010  Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef __CLOCK_HAL_IF_H__
#define __CLOCK_HAL_IF_H__


/* Function typedefs for clk_hal_ops_t */


typedef void (*ftype_deinit) ( smd_clock_hal *clk_hal );

typedef ismd_time_t (*ftype_read_clock) ( smd_clock_hal *clk_hal,
                                          clock_hal_dev_t clock );

typedef void (*ftype_write_clock) ( smd_clock_hal *clk_hal,
                                    clock_hal_dev_t clock,
                                    ismd_time_t     time );

typedef void (*ftype_adjust_clock) ( smd_clock_hal *clk_hal,
                                     clock_hal_dev_t clock,
                                     int64_t     adjustment );

typedef ismd_time_t (*ftype_get_last_trigger_time) ( smd_clock_hal *clk_hal, 
                                                     clock_hal_dev_t clk);

typedef void (*ftype_ack_last_trigger_time) ( smd_clock_hal *clk_hal, 
                                              clock_hal_dev_t clk);

typedef void (*ftype_schedule_alarm) ( smd_clock_hal *clk_hal,
                                        clock_hal_dev_t   clock,
                                        ismd_time_t        time,
                                        clock_callback_t callback,
                                        void *clock_alarm);

typedef void (*ftype_cancel_alarm) (  smd_clock_hal *clk_hal, 
                                      clock_hal_dev_t clock );

typedef ismd_result_t (*ftype_set_timestamp_trigger_source) (  smd_clock_hal *clk_hal, 
                                                      clock_hal_dev_t clock,
                                                      ismd_clock_trigger_source_t trigger_src );

typedef ismd_clock_trigger_source_t (*ftype_get_timestamp_trigger_source) ( smd_clock_hal *clk_hal, 
                                                                            clock_hal_dev_t clock );

typedef void (*ftype_route) ( smd_clock_hal *clk_hal, 
                              clock_hal_dev_t clock, 
							  ismd_clock_dest_t destination);

typedef ismd_result_t (*ftype_adjust_frequency) ( smd_clock_hal *clk_hal,
                                                  clock_hal_dev_t clock,
                                                  int adjustment );

typedef ismd_time_t (*ftype_get_last_vsync_time) ( smd_clock_hal *clk_hal, 
                                                   clock_hal_dev_t clock);

typedef ismd_result_t (*ftype_set_vsync_timestamp_pipe) ( smd_clock_hal *clk_hal,
                                                          clock_hal_dev_t clock,
                                                          ismd_clock_vsync_source_t pipe);

typedef void (*ftype_make_primary) ( smd_clock_hal *clk_hal, 
                                     clock_hal_dev_t clock );

typedef void (*ftype_reset_primary) ( smd_clock_hal *clk_hal, 
                                      clock_hal_dev_t clock );

typedef void (*ftype_trigger_event) ( smd_clock_hal *clk_hal, 
                                      clock_hal_dev_t clock);

typedef ismd_result_t (*ftype_set_clock_source) ( smd_clock_hal  *clk_hal, 
                                                  ismd_clock_source_t source);

typedef int (*ftype_get_type) ( smd_clock_hal *clk_hal, 
                                clock_hal_dev_t clock );

typedef void (*ftype_set_freq_calib_offset) ( smd_clock_hal *clk_hal,
                                              int  offset);

typedef ismd_result_t (*ftype_set_signal) ( smd_clock_hal *clk_hal, 
                                            clock_hal_dev_t clock,
                                            int  signal);

typedef ismd_result_t (*ftype_set_frequency) ( smd_clock_hal *clk_hal, 
                                               clock_hal_dev_t clock, 
                                               int offset);	
									  
typedef ismd_result_t (*ftype_handle_freq_change) ( smd_clock_hal *clk_hal,
                                                    clock_hal_dev_t  clock,
                                                    int  adjustment,
                                                    uint32_t    freq);									  
									  
typedef ismd_result_t (*ftype_set_vcxo_freq) (smd_clock_hal *clk_hal,
                                              clock_hal_dev_t  clock,
                                              int offset );
											   
typedef void (*ftype_set_dds_freq) (smd_clock_hal *clk_hal,
                                    clock_hal_dev_t clock,
                                    uint32_t       freq);											   

typedef void (*ftype_set_master_dds_freq) (smd_clock_hal *clk_hal,
                                           clock_hal_dev_t clock,
                                           uint32_t       freq);	
										   
typedef ismd_result_t (*ftype_set_power_state) (smd_clock_hal *clk_hal,
                                           icepm_state_t requested_state );

							
typedef struct clk_hal_ops_t { 

	ftype_read_clock                            f_read_clock;
	ftype_write_clock                           f_write_clock;
	ftype_adjust_clock                          f_adjust_clock;
	ftype_get_last_trigger_time                 f_get_last_trigger_time;
	ftype_ack_last_trigger_time                 f_ack_last_trigger_time;
	ftype_schedule_alarm                        f_schedule_alarm;
	ftype_cancel_alarm                          f_cancel_alarm;
	ftype_set_timestamp_trigger_source          f_set_timestamp_trigger_source;
	ftype_get_timestamp_trigger_source          f_get_timestamp_trigger_source;
	ftype_route                                 f_route;
	ftype_adjust_frequency                      f_adjust_frequency;
	ftype_get_last_vsync_time                   f_get_last_vsync_time;
	ftype_set_vsync_timestamp_pipe              f_set_vsync_timestamp_pipe;
	ftype_make_primary                          f_make_primary;
	ftype_reset_primary                         f_reset_primary;
	ftype_trigger_event                         f_trigger_event;
	ftype_get_type                              f_get_type;
	ftype_set_freq_calib_offset                 f_set_freq_calib_offset;
	ftype_set_signal                            f_set_signal;
	ftype_set_frequency                         f_set_frequency;
	ftype_handle_freq_change                    f_handle_freq_change;
	ftype_set_vcxo_freq							f_set_vcxo_freq;
	ftype_set_dds_freq							f_set_dds_freq;
	ftype_set_master_dds_freq					f_set_master_dds_freq;	
	ftype_set_power_state                       f_set_power_state;   
}clk_hal_ops_t;
	
#endif // __CLOCK_HAL_IF_H__
