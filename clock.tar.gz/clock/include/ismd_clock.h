/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2010  Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef __ISMD_CLOCK_H__
#define __ISMD_CLOCK_H__

#include "ismd_msg.h"
#include "ismd_global_defs.h"
#include "ismd_core.h"
#include "ismd_core_protected.h"
#include "intel_ce_pm.h"

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_CALIBRATION_DIFF          5 // In 90Khz ticks
#define CLOCK_READ_LATENCY            1 // In 90Khz ticks
#define MIN_CONSECUTIVE_PASSES        3

typedef struct  {
	bool                           free;
	bool                           alarm_set;
	ismd_clock_dev_callback_func_t alarm_callback;
	void                          *alarm_context;
   int                            source;
} clock_context_t;


void SMDEXPORT clock_device_init(void);
void SMDEXPORT clock_device_deinit(void);

ismd_result_t clock_alloc( int               type,
                           ismd_clock_dev_t *clock );

ismd_result_t clock_free( ismd_clock_dev_t clock );

ismd_result_t clock_get_time( ismd_clock_dev_t clock,
                              ismd_time_t     *time);

ismd_result_t clock_set_time( ismd_clock_dev_t clock,
                              ismd_time_t      time );

ismd_result_t clock_adjust_time( ismd_clock_dev_t clock,
                                 int64_t      adjustment );

ismd_result_t clock_get_last_trigger_time( ismd_clock_dev_t clock,
                                          ismd_time_t     *time);

ismd_result_t clock_ack_last_trigger_time( ismd_clock_dev_t clock);


ismd_result_t clock_schedule_alarm( ismd_clock_dev_t clock,
                                    void             *clock_alarm,
                                    ismd_time_t      time);

ismd_result_t clock_cancel_alarm( ismd_clock_dev_t clock );

ismd_result_t clock_set_alarm_handler( ismd_clock_dev_t               clock,
                                       ismd_clock_dev_callback_func_t callback);

ismd_result_t clock_set_timestamp_trigger_source( ismd_clock_dev_t clock,
                                                  int             source );

ismd_result_t clock_get_timestamp_trigger_source( ismd_clock_dev_t clock, 
                                int              *source );

ismd_result_t clock_set_frequency( ismd_clock_dev_t clock,
                                   int        adjustment );

ismd_result_t clock_adjust_frequency( ismd_clock_dev_t clock,
                                      int        adjustment );

ismd_result_t clock_adjust_primary( ismd_clock_dev_t clock,
                                    int      adjustment );

ismd_result_t clock_make_primary( ismd_clock_dev_t clock );

ismd_result_t clock_reset_primary( ismd_clock_dev_t clock );

ismd_result_t clock_route(ismd_clock_dev_t clock, int destination );

ismd_result_t clock_set_signal(ismd_clock_dev_t clock, int signal);

ismd_result_t clock_get_last_vsync_time(ismd_clock_dev_t clock, ismd_time_t *time);

ismd_result_t clock_set_vsync_pipe( ismd_clock_dev_t clock, int pipe);

ismd_result_t clock_trigger_software_event(ismd_clock_dev_t clock);

ismd_result_t clock_set_power_state( icepm_state_t requested_state );

#ifdef __cplusplus
}
#endif

#endif  /* __ISMD_CLOCK_H__ */
