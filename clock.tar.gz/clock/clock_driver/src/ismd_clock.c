/* 
  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011  Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2011  Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


/* 
 ismd_clock.c implements the SMD Clock driver.  The clock driver has the 
 following functions.

   1.  Provide a thin wrapper for the clock HAL.  The SMD core does not 
       touch hardware, but it does control timing.  The clock driver 
       provides a wrapper so that the HAL can exist independently from 
       the SMD Core just like other SMD drivers.
   2.  Initialize the HAL.  The clock driver and HAL have no public APIs
       so the clock driver is responsible for automatically initializing
       the clock HAL.  This is currently done by specifying the init
       function in the AutoAPI header file so that it works in kernel 
       and user mode.
*/

#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core_protected.h"
#include "clock_hal.h"
#include "ismd_clock.h"
#include "clock_hal_if.h"

int clk_drv_debug_level = 0;
#define CLOCK_PRINT(d, p...)  if(clk_drv_debug_level >= d) OS_PRINT(p)

// Examine a specific slot in a clk_hal_ops_t struct. Return NULL or fp
#define INIT_IF_HAL_SUPPORTED( halfunc, fp )  (( clk_hal->pf->halfunc == NULL ) ? NULL:fp)

#define CALIBRATE_DDS

static clock_context_t *clocks;

static smd_clock_hal       g_clk_hal;
static smd_clock_hal       *clk_hal = &g_clk_hal;
static os_thread_t         dds_calibration;
static ismd_event_t calibration_exit_request;

/* Indicate whether calibration thread is completed */
static bool calibration_done;

/*
 * The clock driver expects that the higher-level software (i.e. the SMD 
 * Core Clock Manager) will provide synchronization for all clock devices.  
 * However, during clock device allocation, the higher-level software does 
 * not know which clock device to synchronize.  Therefore, the clock driver 
 * will protect all allocate and free calls. Since the current higher level
 * software provides top-half safe synchronization, the clock driver is forced
 * to do the same, and thus by design, doesn't makes use of a blocking
 * synchronization mechanism such as a semaphore.
 */

// A global lock used when it is necessary to disable interrupts
os_irqlock_t               alloc_free_irq_lock;

// The IRQ locks are never nested, so it is safe to use a global
// variable.
os_irqlock_local_t         irqglobal;

static void clock_callback( ismd_clock_dev_t clock, void *alarm);
static void init_clock_dev( ismd_clock_dev_t clock );
static void calibrate_dds(void);
static ismd_result_t start_clk_calibration_thread(void);
void *clk_calibrate(void *arg);
static signed long long signed_divide64(signed long long num,
                                        signed long long den );
static bool valid_clock_dev(ismd_clock_dev_t clock);
																				
										
static inline bool valid_clock_dev(ismd_clock_dev_t clock)
{
	return (clock >= 0 && clock < clk_hal->num_subunits);	
}

/* Initialize HW and virtual clock types */
void clock_device_init()
{
   ismd_clock_dev_t clock;
   ismd_clock_dev_ops_t clock_ops;
   ismd_result_t result;
   
   os_irqlock_init(&alloc_free_irq_lock);
   
   // Initialze the HAL based on SOC type
   clock_hal_init( clk_hal );
   
   /* Provide a context for each clock */
   clocks = OS_ALLOC( clk_hal->num_subunits * sizeof(clock_context_t) );
   
   /* init each clock's context data */
   for ( clock = 0; clock < clk_hal->num_subunits; clock++ ) {
      init_clock_dev( clock );
   }
   
   // Initialize the operations that the clock driver
   // will make available to the clock manager
   
   // The allocate, free and set alarm handler ops are handled 
   // completely in the driver so we do not check for HAL support
   clock_ops.allocate                        = clock_alloc;   
   clock_ops.free                            = clock_free;
   clock_ops.set_alarm_handler               = clock_set_alarm_handler;   
   

   // If the HAL has not supported a given operation, do not populate it. Insert NULL.
   clock_ops.get_time                        = INIT_IF_HAL_SUPPORTED( f_read_clock, clock_get_time);
   clock_ops.get_last_vsync_time             = INIT_IF_HAL_SUPPORTED( f_get_last_vsync_time, clock_get_last_vsync_time);     
   clock_ops.set_time                        = INIT_IF_HAL_SUPPORTED( f_write_clock, clock_set_time);     
   clock_ops.adjust_time                     = INIT_IF_HAL_SUPPORTED( f_adjust_clock, clock_adjust_time);     
   clock_ops.set_vsync_pipe                  = INIT_IF_HAL_SUPPORTED( f_set_vsync_timestamp_pipe, clock_set_vsync_pipe);     
   clock_ops.get_last_trigger_time           = INIT_IF_HAL_SUPPORTED( f_get_last_trigger_time, clock_get_last_trigger_time);     
   clock_ops.schedule_alarm                  = INIT_IF_HAL_SUPPORTED( f_schedule_alarm, clock_schedule_alarm);     
   clock_ops.cancel_alarm                    = INIT_IF_HAL_SUPPORTED( f_cancel_alarm, clock_cancel_alarm);         
   clock_ops.set_timestamp_trigger_source    = INIT_IF_HAL_SUPPORTED( f_set_timestamp_trigger_source, clock_set_timestamp_trigger_source);     
   clock_ops.adjust_frequency                = INIT_IF_HAL_SUPPORTED( f_adjust_frequency, clock_adjust_frequency);   
   clock_ops.make_primary                    = INIT_IF_HAL_SUPPORTED( f_make_primary, clock_make_primary);   
   clock_ops.reset_primary                   = INIT_IF_HAL_SUPPORTED( f_reset_primary, clock_reset_primary);     
   clock_ops.trigger_software_event          = INIT_IF_HAL_SUPPORTED( f_trigger_event, clock_trigger_software_event);     
   clock_ops.clock_route                     = INIT_IF_HAL_SUPPORTED( f_route, clock_route);     
   clock_ops.set_frequency                   = INIT_IF_HAL_SUPPORTED( f_set_frequency, clock_set_frequency);     
   clock_ops.set_power_state                 = INIT_IF_HAL_SUPPORTED( f_set_power_state, clock_set_power_state);

   
   // Register the newly initialized clock driver operations with the SMD Core.
   ismd_clock_register_clock( &clock_ops );
      
   result = ismd_event_alloc(&calibration_exit_request);
   if(result != ISMD_SUCCESS) {
      OS_PRINT("Error : Couldnt allocate thread exit event\n");
   }

   calibration_done = false;
   calibrate_dds();

   if( ISMD_SUCCESS != result ) {
	   OS_INFO("ISMD Clock may not be functional\n");
   }
   
   return;
}

static signed long long signed_divide64(
   signed long long num,
   signed long long den )
{
   int         flip_result_sign = 0;

   if ( num < 0 )
   {
      flip_result_sign ^= 1;
      num = -num;
   }

   if ( den < 0 )
   {
      flip_result_sign ^= 1;
      den = -den;
   }

   num = OSAL_DIV64( num, den );

   if ( flip_result_sign )
   {
      num = -num;
   }

   return(num);
}

static void calibrate_dds(void) {
   
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   result = start_clk_calibration_thread();
}

static ismd_result_t start_clk_calibration_thread(void) {
   
   osal_result osal_ret;
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   void *arg = NULL;
   osal_ret = os_thread_create(&dds_calibration,
                               clk_calibrate,
                               (void *)arg,
                               0,
                               0,
                               "clk_calibrate");

   if (osal_ret != OSAL_SUCCESS) {
      OS_PRINT("CLOCK: Clk calibration thread creation failed, res:%d \n", osal_ret);
   } else {
      result = ISMD_SUCCESS;
   }
   return result;
}


void *clk_calibrate(void *arg) {

   int64_t ppm_diff = 0, time_diff;
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_clock_dev_t calibration_ref = -1, calibration_tgt = -1;
   int cumulative_ppm_diff = 0, pass_count = 0;   
   ismd_time_t ref_start_time , tgt_start_time, ref_time, ref_time_2, tgt_time, ref_time_diff, tgt_time_diff;
   arg = NULL;

   /* Init calibration environment */
   result = clock_alloc(ISMD_CLOCK_TYPE_SW_CONTROLLED, &calibration_ref);
   result = clock_alloc(ISMD_CLOCK_TYPE_SW_CONTROLLED, &calibration_tgt);   
   
   clock_set_signal(calibration_ref, ISMD_CLOCK_SIGNAL_VCXO);
   clock_set_signal(calibration_tgt, ISMD_CLOCK_SIGNAL_LOCAL_DDS);

   do {
      result = clock_get_time( calibration_ref, &ref_start_time);
      result = clock_get_time( calibration_tgt, &tgt_start_time);
      result     = clock_get_time( calibration_ref, &ref_time_2);
   } while (ref_time_2 - ref_start_time > CLOCK_READ_LATENCY);
	
   CLOCK_PRINT(2,"Ref start time : %lld, tgt start time : %lld\n", ref_start_time, tgt_start_time);
   
   /* Calibrate */
   while( pass_count < MIN_CONSECUTIVE_PASSES) {
      result = ismd_event_wait(calibration_exit_request,1000);
      if(result == ISMD_SUCCESS) {
         ismd_event_acknowledge(calibration_exit_request);
         CLOCK_PRINT(2, "Received calibration_exit_request.\n");
         break;
      }

      CLOCK_PRINT(2, "____________________________________________________\n");
      do {
         result      = clock_get_time( calibration_ref, &ref_time);
         result      = clock_get_time( calibration_tgt, &tgt_time);
         result      = clock_get_time( calibration_ref, &ref_time_2);
      } while (ref_time_2 - ref_time > CLOCK_READ_LATENCY);
      CLOCK_PRINT(2, "Ref time : %lld, tgt time : %lld\n", ref_time, tgt_time);

      ref_time_diff  = ref_time - ref_start_time;
      tgt_time_diff  = tgt_time - tgt_start_time;
      CLOCK_PRINT(2, "Ref time diff : %lld, tgt time diff: %lld\n", ref_time_diff, tgt_time_diff);

      time_diff      = ref_time_diff - tgt_time_diff;
      ref_start_time = ref_time;
      tgt_start_time = tgt_time;
      CLOCK_PRINT(2, "1s inter clock diff : %lld\n", time_diff);       
      if( (time_diff > MAX_CALIBRATION_DIFF) || (time_diff < -MAX_CALIBRATION_DIFF)) {
          time_diff            = time_diff * 1000000;
          CLOCK_PRINT(2, "time diff in million : %lld\n", time_diff);
          ppm_diff             = signed_divide64(time_diff, (int64_t) HW_CLOCK_FREQUENCY_HZ);
          pass_count           = 0;
          cumulative_ppm_diff += ppm_diff;
          CLOCK_PRINT(2, "freq : %lld ppm, tppm : %d\n", ppm_diff, cumulative_ppm_diff);
          clock_set_frequency(calibration_tgt, cumulative_ppm_diff);
      } else {
          pass_count++;
      }
      CLOCK_PRINT(2, "ppm_diff = %lld, ref_diff : %lld, tgt_diff : %lld\n", ppm_diff, ref_time_diff, tgt_time_diff);
   }

   /* Set calibration offset */
   clock_hal_set_freq_calib_offset(clk_hal, ppm_diff);

   /* De-init calibration environment */  
   clock_set_signal(calibration_ref, ISMD_CLOCK_SIGNAL_LOCAL_DDS);
   clock_set_signal(calibration_tgt, ISMD_CLOCK_SIGNAL_LOCAL_DDS);
   clock_free(calibration_ref);
   clock_free(calibration_tgt);
   if (pass_count >= MIN_CONSECUTIVE_PASSES) {
      calibration_done = true;  
   }
   CLOCK_PRINT(2, "Exiting Clk calibration thread\n");
   return NULL;
}


void clock_device_deinit( void )
{
   ismd_clock_dev_t clock;
   ismd_clock_dev_ops_t clock_ops;

   /* Kill the calibrate thread */
   ismd_event_strobe(calibration_exit_request);
   os_thread_wait(&dds_calibration, 1);
   os_thread_destroy(&dds_calibration);

   /* Free global ismd events */
   ismd_event_free(calibration_exit_request);
 

   clock_ops.allocate                  = NULL;
   clock_ops.free                      = NULL;
   clock_ops.get_time                  = NULL;
   clock_ops.set_time                  = NULL;
   clock_ops.adjust_time               = NULL;
   clock_ops.get_last_trigger_time     = NULL;
   clock_ops.get_last_vsync_time       = NULL;
   clock_ops.set_vsync_pipe            = NULL;
   clock_ops.schedule_alarm            = NULL;
   clock_ops.cancel_alarm              = NULL;
   clock_ops.set_alarm_handler         = NULL;
   clock_ops.set_timestamp_trigger_source= NULL;
   clock_ops.adjust_frequency           = NULL;
   clock_ops.make_primary               = NULL;
   clock_ops.reset_primary              = NULL;
   clock_ops.trigger_software_event     = NULL;
   clock_ops.clock_route                = NULL;
   clock_ops.set_frequency              = NULL;
   /* Un-register the clock driver from the SMD Core. */
   ismd_clock_register_clock( &clock_ops );

   /* Init clock struct */
   for ( clock = 0; clock < clk_hal->num_subunits; clock++ ) {
      init_clock_dev( clock );
   }

   /* Destry alloc free sema */
   os_irqlock_destroy(&alloc_free_irq_lock);

   clock_hal_deinit(clk_hal);
   
   /* Free the context area */
   OS_FREE(clocks);
   return;

}


ismd_result_t clock_alloc( int               type, 
                           ismd_clock_dev_t *clock )
{
   ismd_clock_dev_t temp_clock;
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;

   if ( !valid_clock_type(type) ) {
      result = ISMD_ERROR_INVALID_PARAMETER;
   }
   else {
      os_irqlock_acquire( &alloc_free_irq_lock, &irqglobal );
      for ( temp_clock = 0; temp_clock < clk_hal->num_subunits; temp_clock++ ) {
         if ( clocks[temp_clock].free ) {
               clocks[temp_clock].free = false;
               *clock = temp_clock;
               result = ISMD_SUCCESS;
               break;
         }
      }
      os_irqlock_release( &alloc_free_irq_lock, &irqglobal );
   }    
   
   return ( result );
}


ismd_result_t clock_free( ismd_clock_dev_t clock )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   os_irqlock_acquire( &alloc_free_irq_lock, &irqglobal );
   
   clock_hal_cancel_alarm( clk_hal, (clock_hal_dev_t)clock );
   init_clock_dev( clock );
   result = ISMD_SUCCESS;
   
   os_irqlock_release( &alloc_free_irq_lock, &irqglobal );

   return ( result );
}


ismd_result_t clock_get_time( ismd_clock_dev_t clock, 
                              ismd_time_t     *time)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   *time = clock_hal_read_clock(clk_hal, (clock_hal_dev_t)clock );
   result = ISMD_SUCCESS;

   return ( result );
}


ismd_result_t clock_set_vsync_pipe( ismd_clock_dev_t clock, 
                                    int               pipe) 
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
   
   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   result = clock_hal_set_vsync_timestamp_pipe(clk_hal,(clock_hal_dev_t)clock, pipe);

   return ( result );
}


ismd_result_t clock_get_last_vsync_time( ismd_clock_dev_t clock, 
                                         ismd_time_t     *time)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   *time = clock_hal_get_last_vsync_time(clk_hal, (clock_hal_dev_t)clock );
   result = ISMD_SUCCESS;

   return ( result );
}

ismd_result_t clock_trigger_software_event( ismd_clock_dev_t clock)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   clock_hal_trigger_event(clk_hal, (clock_hal_dev_t)clock );
   result = ISMD_SUCCESS;

   return ( result );
}


ismd_result_t clock_get_last_trigger_time( ismd_clock_dev_t clock, 
                                           ismd_time_t     *time)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   *time = clock_hal_get_last_trigger_time(clk_hal, (clock_hal_dev_t)clock );
   result = ISMD_SUCCESS;

   return ( result );
}



ismd_result_t clock_set_time( ismd_clock_dev_t clock, 
                              ismd_time_t      time ) 
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   clock_hal_write_clock(clk_hal,(clock_hal_dev_t)clock, time );
   result = ISMD_SUCCESS;

   return ( result );
}

ismd_result_t clock_adjust_time( ismd_clock_dev_t clock, 
                                 int64_t          adjustment ) 
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   clock_hal_adjust_clock(clk_hal, (clock_hal_dev_t)clock, adjustment );
   result = ISMD_SUCCESS;

   return ( result );
}

ismd_result_t clock_schedule_alarm( ismd_clock_dev_t clock,
                                    void      *clock_alarm,
                                    ismd_time_t      time ) 
{
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   if ( !clocks[clock].alarm_set ) {
      clocks[clock].alarm_set = true;
      clock_hal_schedule_alarm( clk_hal, (clock_hal_dev_t)clock, time,  clock_callback, clock_alarm);
      result = ISMD_SUCCESS;
   }

   return ( result );
}


ismd_result_t clock_cancel_alarm( ismd_clock_dev_t clock )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   clock_hal_cancel_alarm(clk_hal, (clock_hal_dev_t)clock );
   clocks[clock].alarm_set = false;
   result = ISMD_SUCCESS;

   return ( result );
}


ismd_result_t clock_set_alarm_handler( ismd_clock_dev_t                 clock,
                                       ismd_clock_dev_callback_func_t callback)
{
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );
   OS_ASSERT( callback != NULL );

   if ( !clocks[clock].alarm_set ) {
      clocks[clock].alarm_callback = callback;
      result = ISMD_SUCCESS;
   }

   return ( result );
}


ismd_result_t clock_set_timestamp_trigger_source( ismd_clock_dev_t clock, 
                                                  int             source )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   result = clock_hal_set_timestamp_trigger_source(clk_hal, (clock_hal_dev_t)clock, source);
   if( ISMD_SUCCESS == result ) {
      clocks[clock].source = source;
   }

   return ( result );
}


ismd_result_t clock_get_timestamp_trigger_source( ismd_clock_dev_t clock, 
                                int              *source )
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_clock_trigger_source_t clk_source;
 
   OS_ASSERT( source != NULL );
   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   clk_source = clock_hal_get_timestamp_trigger_source(clk_hal, (clock_hal_dev_t)clock);
   *source = clk_source;
   
   return ( result );
}


ismd_result_t clock_adjust_frequency( ismd_clock_dev_t clock,
                                      int adjustment)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   result = clock_hal_adjust_frequency(clk_hal, (clock_hal_dev_t)clock, adjustment);
      
   return ( result );
}


ismd_result_t clock_set_frequency( ismd_clock_dev_t clock,
                                   int              adjustment)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   result = clock_hal_set_frequency(clk_hal, (clock_hal_dev_t)clock, adjustment);   
   return ( result );
}

ismd_result_t clock_route( ismd_clock_dev_t clock , int destination)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   clock_hal_route(clk_hal, (clock_hal_dev_t)clock, destination);
   result = ISMD_SUCCESS;

   return ( result );
}


ismd_result_t clock_set_signal( ismd_clock_dev_t clock , int signal)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   result = clock_hal_set_signal(clk_hal, (clock_hal_dev_t)clock, signal);

   return ( result );
}

ismd_result_t clock_make_primary( ismd_clock_dev_t clock )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   clock_hal_make_primary(clk_hal, (clock_hal_dev_t)clock);
   result = ISMD_SUCCESS;

   return ( result );
}



ismd_result_t clock_reset_primary( ismd_clock_dev_t clock )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   clock_hal_reset_primary(clk_hal, (clock_hal_dev_t) clock);
   result = ISMD_SUCCESS;

   return ( result );
}


ismd_result_t clock_trigger_event( ismd_clock_dev_t clock )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   OS_ASSERT( valid_clock_dev(clock) );
   OS_ASSERT( clocks[clock].free == false );

   clock_hal_trigger_event(clk_hal, (clock_hal_dev_t)clock);
   result = ISMD_SUCCESS;
      
   return ( result );
}


static void clock_callback( ismd_clock_dev_t clock, void *alarm)
{
   if ( (clocks[clock].alarm_callback != NULL) &&
        clocks[clock].alarm_set &&
        !clocks[clock].free ) {
      clocks[clock].alarm_set = false;
      clocks[clock].alarm_callback( alarm );
   }

   return;
}


static void init_clock_dev( ismd_clock_dev_t clock )
{
   clocks[clock].free            = true;
   clocks[clock].alarm_set       = false;
   clocks[clock].alarm_callback  = NULL;
   clocks[clock].alarm_context   = NULL;
   clocks[clock].source          = ISMD_CLOCK_SOURCE_INVALID;

   return;
}

/* Destroy or Create the calibrate thread and then call into clock hal */
ismd_result_t clock_set_power_state( icepm_state_t requested_state ) 
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
   switch (requested_state){
      case ICEPM_D3:
         if (!calibration_done) {
           /* Kill the calibrate thread */
           ismd_event_strobe(calibration_exit_request);
           os_thread_wait(&dds_calibration, 1);
           os_thread_destroy(&dds_calibration);
         }
         result = clock_hal_set_power_state(clk_hal, ICEPM_D3);
         break;
      case ICEPM_D0:
         result = clock_hal_set_power_state(clk_hal, ICEPM_D0);
         if (!calibration_done) {
            calibrate_dds();  
         }
         break;
      default:
         break;
   }
   return result;
}


