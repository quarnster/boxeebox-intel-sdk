 /*  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright (c) 2007-2010. Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright (c) 2007-2010. Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  */
#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core_protected.h"
#include "clock_hal.h"
#include "gen3_cru.h"
#include "sven_devh.h"
#include "pal.h"
#include "pal_interrupt.h"
#include "gen3_clock.h"
#include "clock_control.h"
#include "clock_hal_pvt.h"
#include "intel_ce_device_ids.h"

#define NUM_HW_CLOCKS 6
#define COMPARE_INT_STATUS BMSK_CRU_INT_STATUS_COMPARE_1
#define COMPARE_INT_ENABLE BMSK_CRU_INT_ENABLE_COMPARE_1

#define VALID_CE31XX_TRIGGER_SRC(tsrc) ( ( (tsrc == ISMD_CLOCK_TRIGGER_SOURCE_SOFTWARE)   ||\
                                           (tsrc < ISMD_CLOCK_TRIGGER_SOURCE_TS_IN_5)     ||\
                                           ((tsrc >= ISMD_CLOCK_TRIGGER_SOURCE_GPIO_0)    &&\
                                           (tsrc <= ISMD_CLOCK_TRIGGER_SOURCE_GPIO_3))    ||\
                                           (tsrc == ISMD_CLOCK_TRIGGER_SOURCE_VDC_FLIP_0) ||\
                                           (tsrc == ISMD_CLOCK_TRIGGER_SOURCE_VDC_FLIP_1) ) ? true:false )


static smd_clock_hal_subunit subunit_array[NUM_HW_CLOCKS];


/*
 * Hardware Abstraction Layer implementation for ce31xx clocks. 
 */

/*Set the debug level here */
static int my_debug_level=0;

#define TEST_PRINT(d, p...)  if(my_debug_level >= d) OS_PRINT(p)

/* PAL interrupt declarations */
static pal_result_t pal_result;
static pal_info_t pal_info;
static pal_info_t *pal_info_pointer = &pal_info;
static os_interrupt_t intr_handle = NULL;
/* Used by all clocks when interrupts must be disabled */
static os_irqlock_t  g_dev_irq_lock;

/*Function declarations*/
static ismd_result_t init_subunits( smd_clock_hal *clock_hal, smd_clock_hal_subunit *subunits );
static void clock_hal_interrupt_callback_ce31xx(void *data);
void clock_hal_set_dds_frequency(smd_clock_hal *clk_hal, clock_hal_dev_t clock, uint32_t freq);
void clock_hal_deinit_ce31xx( smd_clock_hal *clk_hal);										   
static ismd_result_t set_timestamp_trigger_source_ce31xx(  smd_clock_hal *clk_hal,
                                    ismd_clock_dev_t clock,
                                    ismd_clock_trigger_source_t trigger_src);
                                    
                                    
/* From auto_eas. Used only during HAL initialization for identifying
the base address of each HW clock unit */
static uint32_t subunit_base[NUM_HW_CLOCKS]={ ROFF_CRU_SUBUNIT_0_BASE, 
                                              ROFF_CRU_SUBUNIT_1_BASE, 
											  ROFF_CRU_SUBUNIT_2_BASE, 
											  ROFF_CRU_SUBUNIT_3_BASE, 
											  ROFF_CRU_SUBUNIT_4_BASE, 
											  ROFF_CRU_SUBUNIT_5_BASE};

/* Routes all HAL functions called by the driver.
   Functions named cmn_clk_hal_* are from clock_hal_common.c.
   The local init routine can choose to use these common routines
   or supply a custom routine (please make them static).
*/
static clk_hal_ops_t ce31xx_funcs={

	cmn_clk_hal_read_clock,
	cmn_clk_hal_write_clock,
	cmn_clk_hal_adjust_clock,
	cmn_clk_hal_get_last_trigger_time,
	cmn_clk_hal_ack_last_trigger_time,
	cmn_clk_hal_schedule_alarm,
	cmn_clk_hal_cancel_alarm,
	set_timestamp_trigger_source_ce31xx,
	cmn_clk_hal_get_timestamp_trigger_source,
	cmn_clk_hal_route,
	cmn_clk_hal_adjust_frequency,
	cmn_clk_hal_get_last_vsync_time,
	cmn_clk_hal_set_vsync_timestamp_pipe,
	cmn_clk_hal_make_primary,
	cmn_clk_hal_reset_primary,
	cmn_clk_hal_trigger_event,
	cmn_clk_hal_get_type,
	cmn_clk_hal_set_freq_calib_offset,
	cmn_clk_hal_set_signal,
	cmn_clk_hal_set_frequency,
	cmn_clk_hal_handle_freq_change,
	cmn_clk_hal_set_vcxo_freq,
	cmn_clk_hal_set_dds_freq,
	cmn_clk_hal_set_master_dds_freq,
	cmn_clk_hal_set_power_state,
};	


/*clock_hal_init : Initializes the clock HAL.  
 Called by clock_hal_init (from clock_hal_common.c) which is called by
 clock_device_init which is called by AUTO API*/

ismd_result_t clock_hal_init_ce31xx( smd_clock_hal  *clk_hal) {

   ismd_result_t result=ISMD_SUCCESS;

   TEST_PRINT(2," Initializing CE31XX Clock HAL\n");

   /* Initialize the global irq lock */
   os_irqlock_init(&g_dev_irq_lock);   
   
   /* Number of HW clocks based on SOC type */
   clk_hal->num_subunits = NUM_HW_CLOCKS;
   
   /* Init the call interface */
   clk_hal->pf = &ce31xx_funcs;

   /* enable device */
   if (os_pci_enable_device(CE_SOC_VENDOR_ID_INTEL, CE_SOC_DEVICE_ID_CRU) != OSAL_SUCCESS) {
      OS_ERROR("%s : Couldnt enable pci device",__FUNCTION__);
      result = ISMD_ERROR_OPERATION_FAILED;
   }

   if( ISMD_SUCCESS == result ) {
 
      clk_hal->devh = devhandle_factory( NULL );

      if ( clk_hal->devh == NULL ) {
         OS_ERROR("\n%s : Couldnt get devhandle",__FUNCTION__);
         result = ISMD_ERROR_OPERATION_FAILED;
      }
      /* Note: PAL defines exactly one RBD for CRU. That is GEN3_CRU. We therefore use that one */
      else if ( !devhandle_connect_name(clk_hal->devh, "GEN3_CRU") ) {
         OS_ERROR("\n%s : Couldnt connect to the CRU",__FUNCTION__);
         devh_Delete( clk_hal->devh);
         result = ISMD_ERROR_OPERATION_FAILED;         
      }
      else {
         init_subunits(clk_hal, subunit_array);
      }
   
      clk_hal->nominal_freq_offset_ppm = 0;
      
   }
   
   return (result);
}

/*clock_hal_deinit:  Free all resources and disable the interrupts*/
void clock_hal_deinit_ce31xx( smd_clock_hal *clk_hal)
{

   uint32_t clock=0, reg_offset, reg_read32;
   smd_clock_hal_subunit *unit;

   TEST_PRINT(5, "\nclock_hal_deinit");
   for ( clock = 0; clock < NUM_HW_CLOCKS; clock++ ) {
      unit = &clk_hal->unit[clock];
      unit->alarm_set                 = false;

      /*Disable the compare enable bit in TM_CMD*/
      TEST_PRINT(4,"\nHal  :clock_hal_deinit : Writing TM_CMD : clock : %d, base_roff : 0x%x", clock, unit->base_roff);
      reg_offset = unit->base_roff;
      hw_write_reg32(clk_hal,reg_offset, TM_CMD_REG_INIT);
   }

   /* Mask all interrupts. */
   TEST_PRINT(2,"\nHal  :clock_hal_deinit : Masking interrupts ");
   reg_offset = ROFF_CRU_INT_ENABLE;
   hw_write_reg32(clk_hal,reg_offset, 0 );

   reg_read32 = hw_read_reg32(clk_hal, reg_offset);
   TEST_PRINT(2,"\nHal  :INT_ENABLE: 0x%x ", reg_read32);

   /* Clear all interrupts. */
   TEST_PRINT(2,"\nHal  :clock_hal_deinit : Clearing Int status ");

   reg_offset=ROFF_CRU_INT_STATUS;
   hw_write_reg32(clk_hal,reg_offset, 0xFFFFFFFF );

   reg_read32 = hw_read_reg32(clk_hal, reg_offset);
   TEST_PRINT(2,"\nHal  :INT_STATUS: 0x%x ", reg_read32);

   /* Release the interrupt */
   os_release_interrupt(intr_handle);
   os_irqlock_destroy(&g_dev_irq_lock);
   os_irqlock_destroy( &(clk_hal->int_hdlr_lock));

   /*Delete the Dev Handle*/
   devh_Delete(clk_hal->devh);

   return;
}


/* Callback function provided to os_acquire_interrupt */
static void clock_hal_interrupt_callback_ce31xx(void *data)
{
   smd_clock_hal         *clk_hal = (smd_clock_hal *)data;
   smd_clock_hal_subunit *unit;
   os_irqlock_local_t     irqlocal;
   uint32_t               interrupt_status;
   int                    clock_index;
   bool                   do_callback[NUM_HW_CLOCKS];

   interrupt_status = hw_read_reg32(clk_hal, ROFF_CRU_INT_STATUS);

   /* Lock out the clock interrupt to avoid race conditions accessing registers. */
   os_irqlock_acquire(&clk_hal->int_hdlr_lock, &irqlocal);

   for ( clock_index = 0; clock_index < NUM_HW_CLOCKS; clock_index++ ) {

      do_callback[clock_index] = false;

      if ( interrupt_status & (COMPARE_INT_STATUS << clock_index) ) {
         unit = &(clk_hal->unit[clock_index]);

         /* Disable the compare for the corresponding clock in TM_CMD. */
         devh_AndBitsReg32(clk_hal->devh, unit->base_roff, ~(BMSK_CRU_TM_CMD_COMP_ENABLE)); 

         /* Disable the corresponding bit in INT_STATUS register. */
         devh_OrBitsReg32(clk_hal->devh, ROFF_CRU_INT_STATUS, (interrupt_status & (COMPARE_INT_STATUS << clock_index)));

         /* Disable the corresponding bit in INT_ENABLE register. */
         devh_AndBitsReg32(clk_hal->devh, ROFF_CRU_INT_ENABLE, ~(COMPARE_INT_ENABLE << clock_index) );

         if (unit->alarm_set ) {
            if ( unit->alarm_time <= clock_hal_read_clock(clk_hal, clock_index) ) {
               unit->alarm_set = false;
               do_callback[clock_index] = true;
            }
            else {
               /* Seems like this should be an assert() */
               OS_INFO("\nClock HAL : clock_hal_interrupt_callback : interrupt before time.\n");
            }
         }
         else {
            /* This can happen if an alarm is cancelled about the same time as the alarm triggers. */
            OS_INFO("\nClock HAL : clock_hal_interrupt_callback : interrupt with no alarm set.\n");
         }
      }
   }

   /* Release the irq lock. */
   os_irqlock_release( &clk_hal->int_hdlr_lock, &irqlocal );

   /* Call the callback, note that this can't be called until the lock is released. */
   for ( clock_index = 0; clock_index < NUM_HW_CLOCKS; clock_index++ ) {
      if ( do_callback[clock_index] ) {
         unit = &(clk_hal->unit[clock_index]);
         unit->alarm_callback( clock_index, unit->clock_alarm );
      }
   }

   return;
}

static ismd_result_t init_subunits( smd_clock_hal *clk_hal, smd_clock_hal_subunit *subunits)
{
   ismd_result_t result = ISMD_SUCCESS;
   smd_clock_hal_subunit *unit;
   uint32_t clock, reg_offset, reg_read32, select_sigma_delta, vcxo_freq;
   uint64_t temp;
   
   clk_hal->unit = subunits;

   for ( clock = 0; clock < NUM_HW_CLOCKS; clock++ ) {	  
      unit = &clk_hal->unit[clock];
      /* Filling up the clock unit structure*/
      unit->base_roff                 = subunit_base[clock];		 
      unit->current_time              = 0;
      unit->alarm_set                 = false;
      unit->alarm_time                = (ismd_time_t)0;
      unit->alarm_callback            = NULL;
      unit->current_time              = (uint64_t)0;
      unit->current_vsync_time        = (uint64_t)0;
      unit->clock_dest                = ISMD_CLOCK_NO_DEST_SET;
      unit->trigger_source            = ISMD_CLOCK_NO_TRIGGER_SOURCE_SET;
      unit->vsync_source              = ISMD_CLOCK_VSYNC_SOURCE_PIPE_A;
      unit->clock_signal              = ISMD_CLOCK_SIGNAL_LOCAL_DDS;
      unit->timestamp_available       = false;
      unit->dev_irq_lock              = &g_dev_irq_lock;


      /* Look in .h file for TM_CMD_REG_INIT explaination*/
      TEST_PRINT(5,"\nHal  :clock_hal_init : Writing TM_CMD : clock : %d, base_roff : 0x%x", clock, unit->base_roff);
      reg_offset = unit->base_roff;
      hw_write_reg32(clk_hal,reg_offset, TM_CMD_REG_INIT);
      TEST_PRINT(3,"\nHAL  : clock_hal_init : value : %d offset : 0x%x", TM_CMD_REG_INIT, reg_offset);

      /* Setting the Local DDS frequency */
      clock_hal_set_dds_frequency(clk_hal, clock, DDS_FREQ);
      unit->frequency = DDS_FREQ;
      TEST_PRINT(5,"\nHal  :clock_hal_init : Local DDS Freq: %d clock: %d, base_roff: 0x%x", hw_read_reg32(clk_hal, unit->base_roff +ROFF_CRU_DDS_FREQ), clock, unit->base_roff);
      /* Default compare value is 0. */
      reg_offset = unit->base_roff + ROFF_CRU_COMP_LO;
      hw_write_reg32(clk_hal,reg_offset, 0);
      reg_offset = unit->base_roff + ROFF_CRU_COMP_HI;
      hw_write_symbol(clk_hal,
                reg_offset,
                BLSB_CRU_COMP_HI_MSB_STC,
                BMSK_CRU_COMP_HI_MSB_STC, 0);
      /* Default time value is 0. */
      TEST_PRINT(5,"\nHal  :clock_hal_init : Writing SET_STC_LO : clock : %d", clock);
      clock_hal_write_clock(clk_hal, clock, 0);
      TEST_PRINT(5,"\n************ Clock HAL Init : Done with clock : %d ********", clock);
   }


   /* Mask all interrupts. */
   TEST_PRINT(5,"\nHal  :clock_hal_init : Masking interrupts ");
   reg_offset = ROFF_CRU_INT_ENABLE;
   hw_write_reg32(clk_hal,reg_offset, 0 );

   reg_read32 = hw_read_reg32(clk_hal, reg_offset);
   TEST_PRINT(2,"\nHal  :INT_ENABLE: 0x%x ", reg_read32);

   /* Clear all interrupts. */
   TEST_PRINT(5,"\nHal  :clock_hal_init : Clearing Int status ");
   reg_offset=ROFF_CRU_INT_STATUS;
   hw_write_reg32(clk_hal,reg_offset, 0xFFFFFFFF );

   reg_read32 = hw_read_reg32(clk_hal, reg_offset);
   TEST_PRINT(2,"\nHal  :INT_STATUS: 0x%x ", reg_read32);

   /* Check the platform config parameter : master_clock_source
   If source != VCXO (=> set the clock source to master dds */

   if(MASTER_CLOCK_SOURCE == ISMD_CLOCK_SIGNAL_MASTER_DDS) {

      /*If clock source required to be set is DDS, no need to write in TS_CTRL register as DDS0 is the default*/
      /* Setting the master dds frequency to 27Mhz*/
      TEST_PRINT(2,"\n Setting the master dds freq on CE3100 \n");

      temp = (uint64_t)DDS_FREQ * 10000;
      temp = OSAL_DIV64(temp, MASTER_FREQ_ADJUSTMENT_UNIT);
      reg_offset = ROFF_CRU_MASTER_DDS_FREQ;
      hw_write_reg32(clk_hal, reg_offset, (uint32_t)temp);
      clk_hal->master_dds_frequency = DDS_FREQ;
 
		 

      clk_hal->master_clock_source = ISMD_CLOCK_SIGNAL_MASTER_DDS;
   }
   else {
      /* Setting the VCXO as the clock source for master */
      TEST_PRINT(5,"\nHal  :clock_hal_init : Setting clk src for master ");
      
      reg_offset =ROFF_CRU_TS_CTRL;
      hw_write_reg32(clk_hal, reg_offset, BMSK_CRU_TS_CTRL_VPLL_REFIN);
      

      /* VCXO frequency, setting to center frequency */
      reg_offset = ROFF_CRU_VCXO_DAC;
      select_sigma_delta = 0x0010000;		 
      vcxo_freq = ((VCXO_CENTER_FREQUENCY-VCXO_LOWER_LIMIT)<<12)/VCXO_RANGE;
      hw_write_reg32(clk_hal, reg_offset, (select_sigma_delta | vcxo_freq));
      clk_hal->master_vcxo_frequency = VCXO_CENTER_FREQUENCY;
      clk_hal->master_clock_source = ISMD_CLOCK_SIGNAL_VCXO;
   }  

   /*Setting each clock to drive channel 0 */
   hw_write_reg32(clk_hal, ROFF_CRU_TS_DDS_MAP, 0);
   TEST_PRINT(2,"\nHal  :TS_DDS_MAP: 0x%x ", hw_read_reg32(clk_hal, ROFF_CRU_TS_DDS_MAP));

   /* grab a PAL interrupt and initialize the interrupt handler lock */
   pal_result = pal_get_base_and_irq(CRU, &pal_info_pointer);
   if (pal_result != PAL_SUCCESS) {
      TEST_PRINT(1,"clock_hal_init: could not get irq number from PAL");
      result = ISMD_ERROR_OPERATION_FAILED;
   }
   else {
      intr_handle = os_acquire_interrupt(pal_info.irq_num, CRU, "Clock_ISR", clock_hal_interrupt_callback_ce31xx, (void *)clk_hal);
      TEST_PRINT(5,"\n Clock HAL Init : Acquired interrupt for clock ");
      os_irqlock_init( &(clk_hal->int_hdlr_lock));

      if (intr_handle == NULL) {
         TEST_PRINT(0,"clock_hal_init: could not get irq number from PAL");
         result = ISMD_ERROR_NO_RESOURCES;
      }
   }
   TEST_PRINT(1,"\nHal  :clock_hal_init : Done with clk_init \n");

	return (result);
}


/*clock_hal_set_timestamp_trigger_source:  Selects the given timestamp
source to cause the timestamp to be captured in the clock unit.
The CE3100 TM_CMD register is significantly different from others so
we use a custom version of this function. */
ismd_result_t set_timestamp_trigger_source_ce31xx(  smd_clock_hal *clk_hal,
                                              ismd_clock_dev_t clock,
                                              ismd_clock_trigger_source_t trigger_src)
{
   uint32_t reg_offset;
   smd_clock_hal_subunit *unit;
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;

   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   unit= &clk_hal->unit[clock];
   reg_offset = unit->base_roff;

   if( VALID_CE31XX_TRIGGER_SRC( trigger_src )  ) {
      
      result = cmn_clk_hal_set_timestamp_trigger_source( clk_hal,
                                                      clock,
                                                      trigger_src );
   
   }
   else {
      result = ISMD_ERROR_INVALID_PARAMETER;
   }   

   return( result );
}
