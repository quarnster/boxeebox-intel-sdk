 /*  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright (c) 2007-2010. Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright (c) 2007-2010. Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  */
#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core_protected.h"
#include "clock_hal.h"
#include "clock_hal_pvt.h"

/* The functions defined here form the interface of the HAL and are 
   called from the clock driver (ismd_clock.o).
   Each of these functions calls through a pointer housed in a clk_hal_ops_t
   structure. A clock HAL has one and only one clk_hal_ops_t struct which 
   initialized in the HAL init routine.
*/   

ismd_time_t clock_hal_read_clock( smd_clock_hal       *clk_hal,
                                  clock_hal_dev_t        clock )
{
	return clk_hal->pf->f_read_clock( clk_hal, clock );
}

/* clock_hal_write_clock :  Writes the 64 bit time value to SET_STC_LO/HI registers */

void clock_hal_write_clock(smd_clock_hal    *clk_hal,
                       clock_hal_dev_t  clock,
                       ismd_time_t      time )
{
	return clk_hal->pf->f_write_clock( clk_hal, clock, time );
}

/* clock_hal_adjust_clock :  ATOMICALLY Modifies the 64 bit time value in SET_STC_LO/HI registers */

void clock_hal_adjust_clock(smd_clock_hal    *clk_hal,
                            clock_hal_dev_t   clock,
                            int64_t           adjustment )
{
	return clk_hal->pf->f_adjust_clock( clk_hal, clock, adjustment );
}


/* clock_hal_schedule_alarm : shcedules an alarm  */

void clock_hal_schedule_alarm( smd_clock_hal     *clk_hal,
                               ismd_clock_dev_t  clock,
                               ismd_time_t       time,
                               clock_callback_t  callback,
                               void              *clock_alarm)
{
	return clk_hal->pf->f_schedule_alarm( clk_hal, 
	                                      clock, 
									      time,
									      callback,
									      clock_alarm );
}


void clock_hal_cancel_alarm( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{
	return clk_hal->pf->f_cancel_alarm( clk_hal, clock );
}


ismd_clock_trigger_source_t clock_hal_get_timestamp_trigger_source ( smd_clock_hal *clk_hal,
                                                                     clock_hal_dev_t clock )
{
	return clk_hal->pf->f_get_timestamp_trigger_source( clk_hal, clock );
}


ismd_result_t clock_hal_set_frequency(smd_clock_hal *clk_hal,
                                      clock_hal_dev_t clock,
                                      int            offset)
{
	return clk_hal->pf->f_set_frequency( clk_hal, clock, offset);
}


ismd_result_t clock_hal_adjust_frequency( smd_clock_hal *clk_hal,
                                          clock_hal_dev_t clock,
                                          int       adjustment )
{
	return clk_hal->pf->f_adjust_frequency( clk_hal, clock, adjustment );
}


/* clock_hal_handle_freq_change */

ismd_result_t clock_hal_handle_freq_change(smd_clock_hal *clk_hal,
                                           clock_hal_dev_t  clock,
                                           int         adjustment,
                                           uint32_t          freq) 
{                                           
	return clk_hal->pf->f_handle_freq_change( clk_hal, clock, adjustment, freq );
}


/* This function sets the VCXO frequency, by given "offset" (in ppm) from the nominal frequency */

ismd_result_t clock_hal_set_vcxo_freq(smd_clock_hal *clk_hal,
                                      clock_hal_dev_t  clock,
                                      int offset ) 
{
	return clk_hal->pf->f_set_vcxo_freq( clk_hal, clock, offset ); 
}


/* clock_hal_set_dds_freq : */

void clock_hal_set_dds_frequency(smd_clock_hal *clk_hal,
                                 clock_hal_dev_t clock,
                                 uint32_t       freq)
{
	return clk_hal->pf->f_set_dds_freq( clk_hal, clock, freq );
}


/* Sets the frquency on the master dds frquency register */

void clock_hal_set_master_dds_frequency(smd_clock_hal *clk_hal,
                                        clock_hal_dev_t clock,
                                        uint32_t       freq) 
{
	return clk_hal->pf->f_set_master_dds_freq( clk_hal, clock, freq );
}


/* clock_hal_set_timestamp_trigger_source:  Connects appropriate TS source to drive the timestamping for the clock */

ismd_result_t clock_hal_set_timestamp_trigger_source(  smd_clock_hal *clk_hal,
                                              ismd_clock_dev_t clock,
                                              ismd_clock_trigger_source_t trigger_src)
{
	return clk_hal->pf->f_set_timestamp_trigger_source( clk_hal, clock, trigger_src );
}


/*  clock_hal_route : selects the output driven by a particular clock. */

void clock_hal_route( smd_clock_hal *clk_hal,
                      clock_hal_dev_t clock,
                      ismd_clock_dest_t destination)
{
	return clk_hal->pf->f_route( clk_hal, clock, destination );
}


/* clock_hal_set_vsync_timestamp_pipe */

ismd_result_t clock_hal_set_vsync_timestamp_pipe( smd_clock_hal *clk_hal,
                                                  clock_hal_dev_t clock,
                                                  ismd_clock_vsync_source_t pipe)
{
	return clk_hal->pf->f_set_vsync_timestamp_pipe( clk_hal, clock, pipe );
}


/* clock_hal_get_last_vsync_time : This API would return the last latched value in the VSYNC timestamp register HI/LO.*/

ismd_time_t clock_hal_get_last_vsync_time( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{
	return clk_hal->pf->f_get_last_vsync_time( clk_hal, clock );
}


/* clock_hal_get_last_trigger_time */

ismd_time_t clock_hal_get_last_trigger_time( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{
	return clk_hal->pf->f_get_last_trigger_time( clk_hal, clock );
}


/* clock_hal_ack_last_trigger_time */

void clock_hal_ack_last_trigger_time( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{
	return clk_hal->pf->f_ack_last_trigger_time( clk_hal, clock );
}


/* clock_hal_make_primary : Requested clock is hooked to master dds */

void clock_hal_make_primary( smd_clock_hal *clk_hal, clock_hal_dev_t clock )
{
	return clk_hal->pf->f_make_primary( clk_hal, clock );
}

/*clock_hal_reset_primary */

void clock_hal_reset_primary( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{
	return clk_hal->pf->f_reset_primary( clk_hal, clock );
}


/* clock_hal_trigger_event : This API has nothing to do with Event Manager in ISMD core.  */

void clock_hal_trigger_event( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{
	return clk_hal->pf->f_trigger_event( clk_hal, clock );
}


/* Sets the master DDS source */

ismd_result_t clock_hal_set_signal( smd_clock_hal *clk_hal, 
                                    clock_hal_dev_t clock,
                                    int            signal)
{
	return clk_hal->pf->f_set_signal( clk_hal, clock, signal );
}


/* clock_hal_set_freq_calib_offset */

void clock_hal_set_freq_calib_offset( smd_clock_hal *clk_hal,
                                      int           offset)
{
	return clk_hal->pf->f_set_freq_calib_offset( clk_hal, offset );
}

/* clock_hal_set_power_state : set power state of clock hal device */

ismd_result_t clock_hal_set_power_state( smd_clock_hal *clk_hal, 
                                       icepm_state_t requested_state )
{
	return clk_hal->pf->f_set_power_state( clk_hal, requested_state );
}



