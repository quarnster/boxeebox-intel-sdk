  /*  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright (c) 2007-2011. Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright (c) 2007-2011. Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

  */
#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core_protected.h"
#include "clock_hal.h"
#include "gen41_cru.h"
#include "sven_devh.h"
#include "pal.h"
#include "pal_interrupt.h"
#include "gen3_clock.h"
#include "clock_control.h"
#include "clock_hal_pvt.h"

//#include "sven.h"
#include "intel_ce_device_ids.h"


/*
 * Common Hardware Abstraction Layer functions that may be used by the SOC
   specific implementations if an SOC specific operation is not needed
*/



#define TEST_PRINT(d, p...)  if(debug_level >= d) OS_PRINT(p)

#define VALID_TRIGGER_SRC(tsrc) ( (tsrc < ISMD_CLOCK_NO_TRIGGER_SOURCE_SET) ? true:false )

/*Timescaling macros*/
#define scale_ismd_time_to_hw_time(time) ((uint64_t)time)
#define scale_hw_time_to_ismd_time(time) ((ismd_time_t)time)

/*Clock Dev Handle*/
os_devhandle_t *clock_devh;

/*Set the debug level here */
int debug_level=0;

/* SOC specific init and deinit from clock_hal_ce??xx.c */
extern ismd_result_t clock_hal_init_ce31xx(smd_clock_hal  *clk_hal);
extern ismd_result_t clock_hal_init_ce41xx(smd_clock_hal  *clk_hal);
extern ismd_result_t clock_hal_init_ce42xx(smd_clock_hal  *clk_hal);
//extern ismd_result_t clock_hal_init_ce5xxx(smd_clock_hal  *clk_hal);

extern ismd_result_t clock_hal_deinit_ce31xx(smd_clock_hal  *clk_hal);
extern ismd_result_t clock_hal_deinit_ce41xx(smd_clock_hal  *clk_hal);
extern ismd_result_t clock_hal_deinit_ce42xx(smd_clock_hal  *clk_hal);
//extern ismd_result_t clock_hal_deinit_ce5xxx(smd_clock_hal  *clk_hal);


/*Function declarations*/
void clock_hal_interrupt_callback(void *data);
void clock_hal_set_dds_frequency(smd_clock_hal *clk_hal, clock_hal_dev_t clock, uint32_t freq);
ismd_result_t clock_hal_set_vcxo_freq(smd_clock_hal *clk_hal, clock_hal_dev_t clock, int ppm);
void clock_hal_set_master_dds_frequency(smd_clock_hal *clk_hal, clock_hal_dev_t clock, uint32_t freq);
ismd_result_t clock_hal_handle_freq_change(smd_clock_hal *clk_hal, clock_hal_dev_t  clock, int adjustment, uint32_t freq);



/*clock_hal_init : Initializes the clock HAL. Called by clock_device_init which 
is called by AUTO API. This function must be called prior to any others in the HAL.
*/

ismd_result_t clock_hal_init( smd_clock_hal  *clk_hal) {

   ismd_result_t result=ISMD_SUCCESS;
   pal_result_t pal_result;

   pal_result = pal_get_soc_info(&clk_hal->soc_info);
   if(pal_result == PAL_FAILURE) {
      OS_INFO("%s, couldn't extract soc_info\n",__FILE__);
      result = ISMD_ERROR_OPERATION_FAILED;
   }
     
   else if( clk_hal->soc_info.name == SOC_NAME_CE3100 ) result = clock_hal_init_ce31xx( clk_hal );
   else if( clk_hal->soc_info.name == SOC_NAME_CE4100 ) result = clock_hal_init_ce41xx( clk_hal );
   else if( clk_hal->soc_info.name == SOC_NAME_CE4200 ) result = clock_hal_init_ce42xx( clk_hal );   
   //else if( clk_hal->soc_info.name == SOC_NAME_CE4200 ) result = clock_hal_init_ce5xxx( clk_hal );  
   else result = ISMD_ERROR_OPERATION_FAILED;
   
   return result;
   
}

/*clock_hal_deinit:  Free all resources and disable the interrupts*/
void clock_hal_deinit( smd_clock_hal *clk_hal)
{
   ismd_result_t result=ISMD_SUCCESS;
  
   if( clk_hal->soc_info.name == SOC_NAME_CE3100 ) result = clock_hal_deinit_ce31xx( clk_hal );
   else if( clk_hal->soc_info.name == SOC_NAME_CE4100 ) result = clock_hal_deinit_ce41xx( clk_hal );
   else if( clk_hal->soc_info.name == SOC_NAME_CE4200 ) result = clock_hal_deinit_ce42xx( clk_hal );   
   //else if( clk_hal->soc_info.name == SOC_NAME_CE4200 ) result = clock_hal_deinit_ce5xxx( clk_hal );  
   else result = ISMD_ERROR_OPERATION_FAILED;
   
}	


/* clock_hal_read_clock : Reads the current value of the reqeusted clock */
ismd_time_t cmn_clk_hal_read_clock( smd_clock_hal       *clk_hal,
                                  clock_hal_dev_t        clock )
{
      smd_clock_hal_subunit *unit;
      bool read_success = false;
      os_irqlock_local_t irqlocal;

      DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
      unit = &clk_hal->unit[clock];

      os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);

      read_success = read_counter_value_gen3_b0(clk_hal, clock);

      os_irqlock_release(unit->dev_irq_lock, &irqlocal);

      return (unit->current_time);
}


/* clock_hal_write_clock :  Writes the 64 bit time value to SET_STC_LO/HI registers */
void cmn_clk_hal_write_clock(smd_clock_hal    *clk_hal,
                       clock_hal_dev_t  clock,
                       ismd_time_t      time )
{
   uint64_t hw_time;
   smd_clock_hal_subunit   *unit;
   unit = &clk_hal->unit[clock];

   TEST_PRINT(3, "\n write : current time : 0x%llx",unit->current_time);
   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   hw_time = scale_ismd_time_to_hw_time( time );
   write_counter_value( clk_hal, clock, hw_time );
   TEST_PRINT(3, "\n write : current time : 0x%llx",unit->current_time);

   return;
}

/* clock_hal_adjust_clock :  ATOMICALLY Modifies the 64 bit time value in SET_STC_LO/HI registers */
void cmn_clk_hal_adjust_clock(smd_clock_hal    *clk_hal,
                            clock_hal_dev_t   clock,
                            int64_t           adjustment )
{
   uint64_t original_smd_time;
   uint64_t adjusted_smd_time;
   uint64_t adjusted_hw_time;
   bool read_success = false;

   os_irqlock_local_t irqlocal;

   smd_clock_hal_subunit  *unit;
   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   unit = &clk_hal->unit[clock];

   TEST_PRINT(3, "\n adjust start : current time : 0x%llx",unit->current_time);

   /****************************************************************************/
   /* START of ATOMIC section */

   os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);

   /* Read the current time */
      read_success = read_counter_value_gen3_b0(clk_hal, clock);
      original_smd_time = unit->current_time;

   /* NOW apply the adjustment to the clock */
   if (read_success) {
      adjusted_smd_time = original_smd_time + adjustment;
      adjusted_hw_time = scale_ismd_time_to_hw_time( adjusted_smd_time );
      write_counter_value( clk_hal, clock, adjusted_hw_time );
   }

   os_irqlock_release(unit->dev_irq_lock, &irqlocal);

   /* END of ATOMIC section */
   /****************************************************************************/

   if (read_success) {
      TEST_PRINT(3, "\n adjust done : current time : 0x%llx",unit->current_time);
   }

   return;
}


/* clock_hal_schedule_alarm : shcedules an alarm  */
void cmn_clk_hal_schedule_alarm( smd_clock_hal     *clk_hal,
                               ismd_clock_dev_t  clock,
                               ismd_time_t       time,
                               clock_callback_t  callback,
                               void              *clock_alarm)
{

   uint64_t hw_time;
   uint32_t reg_offset, reg_read32;
   os_irqlock_local_t irqlocal;
   smd_clock_hal_subunit   *unit;

   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   unit = &clk_hal->unit[clock];

   /* Get the irq lock*/
   os_irqlock_acquire(&clk_hal->int_hdlr_lock, &irqlocal);

   if ( !unit->alarm_set ) {
      unit->alarm_time     = time;
      unit->alarm_set      = true;
      unit->alarm_callback = callback;

      unit->clock_alarm = clock_alarm;

      hw_time = scale_ismd_time_to_hw_time( time ) & HW_CNTR_BIT_MASK;

      /* Update the compare register value with the new time */
      reg_offset = unit->base_roff + ROFF_CRU_COMP_LO;
      hw_write_reg32(clk_hal, reg_offset, (uint32_t)hw_time );

      TEST_PRINT(2,"\nHal  :clock_hal_schedule_alarm: COMP_LO: %u ", hw_read_reg32(clk_hal, reg_offset));
      reg_offset = unit->base_roff + ROFF_CRU_COMP_HI;
      hw_write_symbol(clk_hal,
                     reg_offset,
                     BLSB_CRU_COMP_HI_MSB_STC,
                     BMSK_CRU_COMP_HI_MSB_STC,
                 (uint32_t)(hw_time>>32) );
      TEST_PRINT(2,"\nHal  :clock_hal_schedule_alarm: COMP_HI: %u ", hw_read_reg32(clk_hal, reg_offset));


      /* Enable global comparing for this clock. */
      reg_offset = unit->base_roff;
      hw_write_symbol(clk_hal,reg_offset,
                      BLSB_CRU_TM_CMD_COMP_ENABLE,
                      BMSK_CRU_TM_CMD_COMP_ENABLE, 1);
 
      /* Enable comparing in INT_ENABLE */
      reg_offset = ROFF_CRU_INT_ENABLE;
      devh_OrBitsReg32(clk_hal->devh, reg_offset, (BMSK_CRU_INT_ENABLE_COMPARE_1 << (clock)) );
 
      reg_read32 = hw_read_reg32(clk_hal, ROFF_CRU_INT_ENABLE);
      TEST_PRINT(2,"\nHal  :clock_hal_schedule_alarm: INT_ENABLE: 0x%x Clock: %u", reg_read32, clock);
      TEST_PRINT(5,"\nHal  :clock_hal_schedule_alarm: Exit ");
   }

   /* Release the irq lock*/
   os_irqlock_release(&clk_hal->int_hdlr_lock, &irqlocal);

   return;
}


void cmn_clk_hal_cancel_alarm( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{
   uint32_t reg_offset, int_status, int_enable;
   smd_clock_hal_subunit    *unit;
   os_irqlock_local_t irqlocal;

   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   unit = &clk_hal->unit[clock];

   /* Get the irq lock*/
   os_irqlock_acquire(&clk_hal->int_hdlr_lock, &irqlocal);

   if (unit->alarm_set) {
      /* Reset the "alarm_set" flag for the clock.  This is the flag that is
      checked in the interrupt handler to service the interrupt */
      unit->alarm_set      = false;
   
      /* Disable comparing in TM_CMD*/
      reg_offset = unit->base_roff;
      devh_AndBitsReg32(clk_hal->devh, reg_offset, ~(BMSK_CRU_TM_CMD_COMP_ENABLE));
   
      /* Disable comparing in INT_ENABLE */
      reg_offset = ROFF_CRU_INT_ENABLE;
      int_enable = devh_ReadReg32(clk_hal->devh, reg_offset);
      TEST_PRINT(3, "\n Before correction int_enable : %d, clock : %d, correction : %d final :%d", int_enable, clock, ~(BMSK_CRU_INT_ENABLE_COMPARE_1<< (clock)), int_enable & (BMSK_CRU_INT_ENABLE_COMPARE_1<< (clock)));
      devh_AndBitsReg32(clk_hal->devh, reg_offset, ~(BMSK_CRU_INT_ENABLE_COMPARE_1 << (clock)) );
      TEST_PRINT(3, "\n After correction int_enable : %d", devh_ReadReg32(clk_hal->devh, reg_offset));
   
      /*Update clock structure memebers*/
      unit->alarm_time     = (uint64_t)0;
      unit->alarm_callback = NULL;
   
      /* Clear the INT_STATUS bit for the clock */
      reg_offset = ROFF_CRU_INT_STATUS;
      int_status = devh_ReadReg32(clk_hal->devh, reg_offset);
      TEST_PRINT(3, "\n Before correction int_status : %d, clock : %d, correction : %d final :%d", int_status, clock, (BMSK_CRU_INT_STATUS_COMPARE_1<< (clock)), int_status & (BMSK_CRU_INT_STATUS_COMPARE_1<< (clock)));
      devh_WriteReg32(clk_hal->devh, reg_offset,(BMSK_CRU_INT_STATUS_COMPARE_1<< (clock)));
      TEST_PRINT(2, "\n After correction int_status : %d", devh_ReadReg32(clk_hal->devh, reg_offset));
   }

   /* Release the irq lock*/
   os_irqlock_release(&clk_hal->int_hdlr_lock, &irqlocal);

   return;
}


ismd_clock_trigger_source_t cmn_clk_hal_get_timestamp_trigger_source ( smd_clock_hal *clk_hal,
                                                                     clock_hal_dev_t clock )
{
    smd_clock_hal_subunit *unit;
    unit = &clk_hal->unit[clock];

    DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
    return(unit->trigger_source);

}

ismd_result_t cmn_clk_hal_set_frequency(smd_clock_hal *clk_hal,
                                      clock_hal_dev_t clock,
                                      int            offset)
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   smd_clock_hal_subunit *unit;
   uint32_t freq;

   TEST_PRINT(2, "\nHal  :clock_hal_set_frequency: Clock: %u  Adjustment : %d", clock, offset);
   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   unit = &clk_hal->unit[clock];

   freq = NOMINAL_FREQ_HZ + ((offset + clk_hal->nominal_freq_offset_ppm) * NOMINAL_FREQ_MHZ);
   TEST_PRINT(2, "\nHal  :clock_hal_set_frequency: Clock: %u  Adjustment : %d, calib : %d", clock, offset, clk_hal->nominal_freq_offset_ppm);

   result = clock_hal_handle_freq_change(clk_hal, clock, offset, freq);
   
   return result;
}


/* Note: this function calls clock_hal_handle_freq_change which 
   calls back through the pointer in order to ensure that we pick
   up the correct function in case it has an SOC specific function
   in it.
*/  

ismd_result_t cmn_clk_hal_adjust_frequency( smd_clock_hal *clk_hal,
                                          clock_hal_dev_t clock,
                                          int       adjustment )
{
   uint32_t freq;
   smd_clock_hal_subunit *unit;
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;

   TEST_PRINT(4, "\nHal  :clock_hal_adjust_frequency: Clock: %u  Adjustment : %u", clock, adjustment);
   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   unit = &clk_hal->unit[clock];

   freq   = unit->frequency + ((adjustment + clk_hal->nominal_freq_offset_ppm) * NOMINAL_FREQ_MHZ) ;
   result = clock_hal_handle_freq_change(clk_hal, clock, adjustment, freq);
   return result;
}

/* Note: this function calls clock_hal_set_dds_frequency which 
   calls back through the pointer in order to ensure that we pick
   up the correct function in case it has an SOC specific function
   in it.
*/   

ismd_result_t cmn_clk_hal_handle_freq_change(smd_clock_hal *clk_hal,
                                           clock_hal_dev_t  clock,
                                           int         adjustment,
                                           uint32_t          freq) 
{
                                           
   ismd_result_t result = ISMD_SUCCESS;
   smd_clock_hal_subunit *unit;

   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   unit = &clk_hal->unit[clock];

   if (unit->clock_signal == ISMD_CLOCK_SIGNAL_MASTER_DDS){
      TEST_PRINT(1, "Hal  :clock_hal_handle_freq_change: Clock: %u  Frequency : %u\n", clock, freq);  
      clock_hal_set_master_dds_frequency(clk_hal, clock, freq);
      TEST_PRINT(1, "Hal  :clock_hal_handle_freq_change: Clock: %u  Frequency : %u\n", clock, freq);
      result = ISMD_SUCCESS;
   } else if(unit->clock_signal == ISMD_CLOCK_SIGNAL_VCXO){
      result = clock_hal_set_vcxo_freq(clk_hal, clock, adjustment);
   }
   TEST_PRINT(1, "Hal  :clock_hal_handle_freq_change: Clock: %u  Requested Freq : %u\n", clock, freq);  
   clock_hal_set_dds_frequency(clk_hal, clock, freq);        
   
   return result;
}


/* This function sets the VCXO frequency, by given "offset" (in ppm) from the nominal frequency */
ismd_result_t cmn_clk_hal_set_vcxo_freq(smd_clock_hal *clk_hal,
                                      clock_hal_dev_t  clock,
                                      int offset ) {

   uint32_t reg_offset, levels, select_sigma_delta, vcxo_freq; 
   ismd_result_t result;
   uint64_t temp;
   int freq;
   
   clock=clock;  // Temporarily avoid warning
   
   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   /* Converting adjustment to absolute frequency */
   freq = VCXO_CENTER_FREQUENCY + (offset * NOMINAL_FREQ_MHZ);
   TEST_PRINT(1, "\nHal  :clock_hal_adjust_primary: Frequency : %u", freq);

   reg_offset =  ROFF_CRU_VCXO_DAC;

   /* If freq out of tuning range => saturate it */
   if (freq < VCXO_LOWER_LIMIT) {
      select_sigma_delta = 0x0010000;       
      vcxo_freq = 0;
      hw_write_reg32(clk_hal, reg_offset, (select_sigma_delta | vcxo_freq));
      clk_hal->master_vcxo_frequency = VCXO_LOWER_LIMIT;
      freq = VCXO_LOWER_LIMIT;
      TEST_PRINT(1, "\nHal  Frequency : %u, VCXO adjustment ; 0x%x", freq, (select_sigma_delta | vcxo_freq));
      result = ISMD_ERROR_OUT_OF_RANGE;
   }
   else if(freq > VCXO_UPPER_LIMIT) {
      select_sigma_delta = 0x0010000;
      vcxo_freq = 0x00000FFF;
      hw_write_reg32(clk_hal, reg_offset, (select_sigma_delta | vcxo_freq));
      clk_hal->master_vcxo_frequency = VCXO_UPPER_LIMIT;
      freq = VCXO_UPPER_LIMIT;
      TEST_PRINT(1, "\nHal  Frequency : %u", freq);
      result = ISMD_ERROR_OUT_OF_RANGE;
   }
   /* Else convert to no. of levels and write to VCXO reg */
   else {
      /* 12 bits used for VCXO frequency adjustment = 2^12 = 4096 levels */
      temp =  (freq-VCXO_LOWER_LIMIT)<<12;
      levels = OSAL_DIV64(temp, (VCXO_RANGE));
      hw_write_symbol(clk_hal,
                 reg_offset,
                 BLSB_CRU_VCXO_DAC_VCXO_DAC,
                 BMSK_CRU_VCXO_DAC_VCXO_DAC,
                 levels);
      clk_hal->master_vcxo_frequency = freq;
      TEST_PRINT(1, "\nHal : VCXO Frequency : %u", freq);
      TEST_PRINT(2, "\nHal  :clock_hal_adjust_primary: IN_RANGE : Frequency : %u", freq);
      result = ISMD_SUCCESS;
   }
   return result;
}


/* clock_hal_set_dds_freq : It adjusts the freq of the DDS acting as a source
                            to corresponding wall clock.  The output clock
                            from DDS can be 27/54 Mhz.  0 < freq < 54 000 000.
                            This would be then converted to the units of 0.745.
                            It would also adjust the clock which is connected
                            to master currently as there can be only one primary

                            27 000 000 = 19BFCC0
                            54 000 000 = 337F980 */

void cmn_clk_hal_set_dds_freq( smd_clock_hal *clk_hal,
                           clock_hal_dev_t clock,
                           uint32_t       freq)
{

   uint32_t reg_offset;
   smd_clock_hal_subunit *unit;
   uint64_t temp;

   unit = &clk_hal->unit[clock];
   unit->frequency = freq;

   /* Writing to the local DDS => introduce the necessary frequency adjustment
   multiplier.  The DDS frequency register value is in units of ~0.745 i.e 
   To set 100 Hz freq, a value of (100/0.745) must be written to the frequency
   register.  Unit ~0.745 is an approximation.  Exact value could be found from the 
   formula : (freq in decimal * 2^28) / 200,000,000.  The 28 is the number of bits 
   in the DDS_FREQ register to store the freq value */
  
   temp = (uint64_t)(1<<28) * (uint64_t) freq;
   freq = OSAL_DIV64( temp, DDS_CLOCK_SRC_FREQ_HZ );  /* 200 MHz clock source into DDS */
  
   reg_offset = unit->base_roff + ROFF_CRU_DDS_FREQ;
   hw_write_symbol(clk_hal,
                   reg_offset,
                   BLSB_CRU_DDS_FREQ_DDS_FREQ,
                   BMSK_CRU_DDS_FREQ_DDS_FREQ,
                   freq);

   freq = hw_read_reg32(clk_hal, reg_offset);
   TEST_PRINT(2, "\nHal  :clock_hal_set_dds_frequency: Clock: %u  Frequency : %u", clock, freq);

   return;
}


/* Sets the frquency on the master dds frquency register */
void cmn_clk_hal_set_master_dds_freq(smd_clock_hal *clk_hal,
                                 clock_hal_dev_t clock,
                                 uint32_t       freq) {

   uint32_t reg_offset;
   smd_clock_hal_subunit *unit;
   uint64_t temp;
   
   unit = &clk_hal->unit[clock];
   clk_hal->master_dds_frequency = freq;
   reg_offset =  ROFF_CRU_0_DDS_FREQ;

   /* Writing to the MASTER DDS => introduce the necessary frequency adjustment
   multiplier.  The MASTER DDS frequency register value is in units of ~0.745 i.e 
   To set 100 Hz freq, a value of (100/0.5532) must be written to the frequency
   register.  Unit ~0.5532 is an approximation.  Exact value could be found from the 
   formula : (freq in decimal * 2^32) / 400,000,000.  32 is the number of bits 
   in the MASTER_DDS_FREQ register to store the freq value */
   
   /* Multiply freq by 2^32 */
   temp = freq * (uint64_t)(1<<31);
   temp = temp * 2;
   
   /* Divide result by 400 Mhz */ 
   temp = OSAL_DIV64(temp, MASTER_DDS_CLOCK_SRC_FREQ_HZ);  /* 400 MHz clock source into DDS */
   TEST_PRINT(2, "\nHal  :clock_hal_set_master_dds_frequency: Master DDS Frequency Register : %llu", temp);
   
   freq= temp;
   hw_write_symbol(clk_hal,
                   reg_offset,
                   BLSB_CRU_0_DDS_FREQ_DDS_FREQ,
                   BMSK_CRU_0_DDS_FREQ_DDS_FREQ,
                   (uint32_t)freq);


}


/*clock_hal_set_timestamp_trigger_source:  Selects the given timestamp
source to cause a timestamp to be captured in the clock unit */
ismd_result_t cmn_clk_hal_set_timestamp_trigger_source(  smd_clock_hal *clk_hal,
                                              ismd_clock_dev_t clock,
                                              ismd_clock_trigger_source_t trigger_src)
{
   uint32_t reg_offset;
   smd_clock_hal_subunit *unit;
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;

   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   unit= &clk_hal->unit[clock];
   reg_offset = unit->base_roff;

   if( VALID_TRIGGER_SRC( trigger_src ) ) {
      /*If the trigger source is software dont set anything in the hardware */
      if(trigger_src!=ISMD_CLOCK_TRIGGER_SOURCE_SOFTWARE) {
         hw_write_symbol(clk_hal,
                        reg_offset,
                        BLSB_CRU_TM_CMD_TS_SOURCE,
                        BMSK_CRU_TM_CMD_TS_SOURCE,
                        (uint32_t)trigger_src);
      }
      unit->trigger_source = trigger_src;
      result = ISMD_SUCCESS;
   
   }
   else {
      result = ISMD_ERROR_INVALID_PARAMETER;
   }

   /*  There can be only 1 timestamping source.*/
   /* Driver has to handle something else also.  What if somebody wants to change the clock src.  Any consequences ?*/

   return( result );
}


/*  clock_hal_route : Selects the output driven by a particular clock.  It 
sets values in TS_DDS_MAP register to set the the desired output.  Currently 
TS_OUT2 is not supported */
void cmn_clk_hal_route( smd_clock_hal *clk_hal,
                      clock_hal_dev_t clock,
                      ismd_clock_dest_t destination)
{
   uint32_t reg_offset;
   smd_clock_hal_subunit *unit;
   os_irqlock_local_t irqlocal;

   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   
   unit= &clk_hal->unit[clock];
   reg_offset = ROFF_CRU_TS_DDS_MAP;

  if ((ISMD_CLOCK_ROUTE_TS_IN_5 == destination) ||
       (ISMD_CLOCK_ROUTE_TS_IN_6 == destination) ||
       (ISMD_CLOCK_ROUTE_TS_IN_7 == destination) ||
       (ISMD_CLOCK_ROUTE_TS_IN_8 == destination)
      ) {
		  
         OS_INFO("\n ERROR : TSI %d not supported on CE4100 \n", destination);
         return; 		  
   }

   switch(destination) {
      case ISMD_CLOCK_ROUTE_TS_OUT_1   :

         os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);
         hw_write_symbol(clk_hal,
            reg_offset,
            BLSB_CRU_TS_DDS_MAP_TS_OUT1_MAP,
            BMSK_CRU_TS_DDS_MAP_TS_OUT1_MAP,
            (clock));
         os_irqlock_release(unit->dev_irq_lock, &irqlocal);
         TEST_PRINT(2, "\nHal  clock_hal_route: ISMD_CLOCK_ROUTE_TS_OUT_1: value :%u", clock);
         break;

      case ISMD_CLOCK_ROUTE_TS_IN_1 :

         os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);
         hw_write_symbol(clk_hal,
            reg_offset,
            BLSB_CRU_TS_DDS_MAP_TS_IN1_MAP,
            BMSK_CRU_TS_DDS_MAP_TS_IN1_MAP,
            (clock));
         os_irqlock_release(unit->dev_irq_lock, &irqlocal);
         TEST_PRINT(2, "\nHal  clock_hal_route: ISMD_CLOCK_ROUTE_TS_IN_1: value :%u", clock);
         break;

      case ISMD_CLOCK_ROUTE_TS_IN_2 :
         os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);
         hw_write_symbol(clk_hal,
            reg_offset,
            BLSB_CRU_TS_DDS_MAP_TS_IN2_MAP,
            BMSK_CRU_TS_DDS_MAP_TS_IN2_MAP,
            (clock));
         os_irqlock_release(unit->dev_irq_lock, &irqlocal);
         break;

      case ISMD_CLOCK_ROUTE_TS_IN_3 :
         os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);
         hw_write_symbol(clk_hal,
            reg_offset,
            BLSB_CRU_TS_DDS_MAP_TS_IN3_MAP,
            BMSK_CRU_TS_DDS_MAP_TS_IN3_MAP,
            (clock));
         os_irqlock_release(unit->dev_irq_lock, &irqlocal);
         break;

      case ISMD_CLOCK_ROUTE_TS_IN_4 :
         os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);
         hw_write_symbol(clk_hal,
            reg_offset,
            BLSB_CRU_TS_DDS_MAP_TS_IN4_MAP,
            BMSK_CRU_TS_DDS_MAP_TS_IN4_MAP,
            (clock));
         os_irqlock_release(unit->dev_irq_lock, &irqlocal);
         break;

      case ISMD_CLOCK_ROUTE_TS_IN_5 :
         os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);
         hw_write_symbol(clk_hal,
            reg_offset,
            BLSB_CRU_TS_DDS_MAP2_TS_IN5_MAP,
            BMSK_CRU_TS_DDS_MAP2_TS_IN5_MAP,
            (clock));
         os_irqlock_release(unit->dev_irq_lock, &irqlocal);
         break;

      case ISMD_CLOCK_ROUTE_TS_IN_6 :
         os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);
         hw_write_symbol(clk_hal,
            reg_offset,
            BLSB_CRU_TS_DDS_MAP2_TS_IN6_MAP,
            BMSK_CRU_TS_DDS_MAP2_TS_IN6_MAP,
            (clock));
         os_irqlock_release(unit->dev_irq_lock, &irqlocal);
         break;

      case ISMD_CLOCK_ROUTE_TS_IN_7 :
         os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);
         hw_write_symbol(clk_hal,
            reg_offset,
            BLSB_CRU_TS_DDS_MAP2_TS_IN7_MAP,
            BMSK_CRU_TS_DDS_MAP2_TS_IN7_MAP,
            (clock));
         os_irqlock_release(unit->dev_irq_lock, &irqlocal);
         break;

      case ISMD_CLOCK_ROUTE_TS_IN_8 :
         os_irqlock_acquire(unit->dev_irq_lock, &irqlocal);
         hw_write_symbol(clk_hal,
            reg_offset,
            BLSB_CRU_TS_DDS_MAP2_TS_IN8_MAP,
            BMSK_CRU_TS_DDS_MAP2_TS_IN8_MAP,
            (clock));
         os_irqlock_release(unit->dev_irq_lock, &irqlocal);
         break;

      default :

         break;
      }

   return;
}



ismd_result_t cmn_clk_hal_set_vsync_timestamp_pipe( smd_clock_hal *clk_hal,
                                                  clock_hal_dev_t clock,
                                                  ismd_clock_vsync_source_t pipe)
{

   uint32_t reg_offset;
   smd_clock_hal_subunit *unit;

   TEST_PRINT(4,"\nHAL  :clock_hal_set_vsync_timestamp_pipe : clock : %u pipe : %u", clock, pipe);
   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   unit = &clk_hal->unit[clock];
   TEST_PRINT(4,"\nHAL  :before : clock_hal_set_vsync_timestamp_pipe :0x%x", hw_read_reg32(clk_hal, unit->base_roff + ROFF_CRU_TM_CMD));

   /* Set the VSYNC_SEL bit in the TM_CMD register */
   reg_offset = unit->base_roff  + ROFF_CRU_TM_CMD;

   if(pipe == ISMD_CLOCK_VSYNC_SOURCE_PIPE_A) {
      hw_write_symbol(clk_hal,
                      reg_offset,
                      BLSB_CRU_TM_CMD_VSYNC_SEL,
                      BMSK_CRU_TM_CMD_VSYNC_SEL, 0);

   }
   else if (pipe == ISMD_CLOCK_VSYNC_SOURCE_PIPE_B) {
      hw_write_symbol(clk_hal,
                      reg_offset,
                      BLSB_CRU_TM_CMD_VSYNC_SEL,
                      BMSK_CRU_TM_CMD_VSYNC_SEL , 1);
   }
   else  {
      TEST_PRINT(0,"\nClock HAL  : clock_hal_set_vsync_timestamp_pipe : Incorrect Arguments");
      return(ISMD_ERROR_INVALID_PARAMETER);
   }
   TEST_PRINT(4,"\nHAL  :after : clock_hal_set_vsync_timestamp_pipe :0x%x", hw_read_reg32(clk_hal,  unit->base_roff + ROFF_CRU_TM_CMD));

   return(ISMD_SUCCESS);
}


/* clock_hal_get_last_vsync_time : This API would return the last latched value in the VSYNC timestamp register HI/LO.*/
ismd_time_t cmn_clk_hal_get_last_vsync_time( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{
    ismd_time_t last_vsync_timestamp;
    uint32_t reg_offset, hw_bits_lo, hw_bits_hi;
    uint64_t hw_time, hw_bits, sw_bits;
    smd_clock_hal_subunit *unit;

    DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
    unit = &clk_hal->unit[clock];

    /*Get the hardware portion of the 42 bit counter */

    reg_offset = unit->base_roff + ROFF_CRU_VSYNC_LO;
    hw_bits_lo = hw_read_reg32(clk_hal,reg_offset);

    reg_offset = unit->base_roff + ROFF_CRU_VSYNC_HI;
    hw_bits_hi = hw_read_reg32(clk_hal,reg_offset);

    hw_bits = (((uint64_t)hw_bits_hi)<<32)|((uint64_t)hw_bits_lo);
    hw_bits = hw_bits & HW_CNTR_BIT_MASK;

    /* Check for software roll over.  Get the software portion of the clock */
    sw_bits = unit->current_vsync_time & ~HW_CNTR_BIT_MASK;

    TEST_PRINT(3,"\nHAL  : clock_hal_get_last_vsync_time : hw_bits : %llu, current_vsync_time : %llu",hw_bits, unit->current_vsync_time);

    /* If there was a hardware rollover, increment the software portion of the clock. */
    if ( hw_bits < (unit->current_vsync_time & HW_CNTR_BIT_MASK) ) {
       sw_bits += HW_CNTR_BIT_MASK + (uint64_t)1;
       TEST_PRINT(0,"\nHAL  : clock_hal_get_last_vsync_time : There was a hardware roll over");
    }

    hw_time = (sw_bits | hw_bits);

    /* Put the timestamp register value in a 64 bit variable which will be read by the read_last_timestamp */
    last_vsync_timestamp = scale_hw_time_to_ismd_time( hw_time );
    unit->current_vsync_time = last_vsync_timestamp;
    TEST_PRINT(3,"\nHAL  : clock_hal_get_last_vsync_time : last_vsync_time : %llu",last_vsync_timestamp);

    return(last_vsync_timestamp);
}



/*clock_hal_get_last_trigger_time : This API will return the last time value at which a TS / HW / SW (whichever source is connected
                                    to the clock) event occured.  On the first read it will also clear the lock so that next hardware event
                                    can occur.   ????? Need to add support for two back to back last_trigger_time reads ????? */

ismd_time_t cmn_clk_hal_get_last_trigger_time( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{

     uint64_t hw_time, hw_bits;
     uint32_t hw_bits_hi, reg_offset, hw_bits_lo;
     ismd_time_t last_timestamp;          // Contains the last trigger time value.
     smd_clock_hal_subunit *unit;

     DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
     unit = &clk_hal->unit[clock];

     /*  Before reading the registers for the timestamp check if a timestamp is available and stored in software */
     reg_offset = unit->base_roff + ROFF_CRU_GET_STC_LO;
     hw_bits_lo = (hw_read_reg32(clk_hal,reg_offset));

     reg_offset = unit->base_roff + ROFF_CRU_GET_STC_HI;
     hw_bits_hi = hw_read_reg32(clk_hal,reg_offset);

     hw_bits = (((uint64_t)hw_bits_hi)<<32)|((uint64_t)hw_bits_lo);

     /*Throw the upper 22 bits of the read value */
     hw_bits = hw_bits & HW_CNTR_BIT_MASK;

     /*  Set the read time as current time */
     //hw_time = sw_bits | hw_bits;
     hw_time = hw_bits;
     hw_time = scale_hw_time_to_ismd_time( hw_time );
     last_timestamp = scale_hw_time_to_ismd_time( hw_time );

     return (last_timestamp);
}


/* clock_hal_ack_last_trigger_time : This API would be used once the RTL bug is fixed.  The client has to acknowledge the read of last
                                     timestamp.  Only then would the lock would be released to take a timestamp from another hw
                                     event.*/

void cmn_clk_hal_ack_last_trigger_time( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{

   uint32_t reg_offset;
   smd_clock_hal_subunit *unit;
   unit = &clk_hal->unit[clock];

   unit->timestamp_available = false;

   /* Current timestamp is read so unlock the hardware timestamp register */

   reg_offset = unit->base_roff + ROFF_CRU_GET_STC_LO;
   hw_write_symbol(clk_hal,reg_offset,
      BLSB_CRU_GET_STC_LO_Unlock_TS,
      BMSK_CRU_GET_STC_LO_Unlock_TS, 1);

   return;
}


// TODO Find out if these set/reset primary funcs should be handled from common
/*clock_hal_make_primary : Requested clock is hooked to master dds */
void cmn_clk_hal_make_primary( smd_clock_hal *clk_hal, clock_hal_dev_t clock )
{
   /* Set the MASTER_CLOCK bit in TM_CMD register */
    uint32_t reg_offset;
    smd_clock_hal_subunit *unit;
    int offset;

    DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );

    unit = &clk_hal->unit[clock];

    /*Make the requested clock primary */
    reg_offset = unit->base_roff + ROFF_CRU_TM_CMD;
    hw_write_symbol(clk_hal,reg_offset,
                BLSB_CRU_TM_CMD_MASTER_CLOCK,
                BMSK_CRU_TM_CMD_MASTER_CLOCK, 1);

    unit->clock_signal = clk_hal->master_clock_source;

    /* Copy the frequency of the master clock (VCXO / Master DDS) in the clocks local DDS to keep them in sync.  Each time the master clock's frequency is changed
    the frequency of local DDS should also be changed although it doesnt affect it till its driven by master clock.  But when the switch from
    primary to non-primary happens it should be smooth without any jumps and glitches. */

   /* Set the VCXO freq to the Local DDS freq which the VCXO is going drive
   after this make_primary call */
   if (clk_hal->master_clock_source == ISMD_CLOCK_SIGNAL_VCXO) {
      if(unit->frequency > NOMINAL_FREQ_HZ) {
         offset = (unit->frequency - NOMINAL_FREQ_HZ)/NOMINAL_FREQ_MHZ;
      } else {
         offset = (NOMINAL_FREQ_HZ - unit->frequency)/NOMINAL_FREQ_MHZ;
      }
      clock_hal_set_vcxo_freq(clk_hal, clock, offset);
   }   
   return;
}



/*clock_hal_reset_primary :  A clock which is currently driven by the master clock will now be driven by its local DDS.  The clock driver / Manager
                   would expose the reset_primary API without the argument, because otherwise the client will have to know which clock
                   to reset in order to make its clock primary.  The Manager / Driver should manage a global variable and depending on
                   that, provide a clock handle to the HAL.  HAL wouldnt do the management.*/

				   

void cmn_clk_hal_reset_primary ( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{

    uint32_t reg_offset;
    smd_clock_hal_subunit *unit;

    DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );

    unit = &clk_hal->unit[clock];
    reg_offset = unit->base_roff + ROFF_CRU_TM_CMD;
    hw_write_symbol(clk_hal,reg_offset,
       BLSB_CRU_TM_CMD_MASTER_CLOCK,
       BMSK_CRU_TM_CMD_MASTER_CLOCK, 0);

    unit->clock_signal = ISMD_CLOCK_SIGNAL_LOCAL_DDS;
    return;
}



/* clock_hal_trigger_event : This API has nothing to do with Event Manager in ISMD core.  It triggers an event if the trigger source for the given clock is
                  set to Software source.  It will set the Make_SW_TS in GET_STC_LO register.  This will trigger the capture of
                  correlated timestamp in GET_STC_LO/HI.   A flag NEW_TS bit in  GET_STC_HI_X register to indicate that a new
                  timestamp is available.  Once the software reads it through read_last_trigger_time that bit will be automatically reset. */

void cmn_clk_hal_trigger_event( smd_clock_hal *clk_hal, clock_hal_dev_t clock)
{

   uint32_t reg_offset, value = 1;
   smd_clock_hal_subunit *unit;

   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );

   TEST_PRINT(2,"\nHal  :clock_hal_trigger_event");
   unit = &clk_hal->unit[clock];
   reg_offset = unit->base_roff + ROFF_CRU_GET_STC_LO;

   devh_WriteReg32(clk_hal->devh,
               unit->base_roff + ROFF_CRU_GET_STC_LO,
               (unsigned int)value);
   /*hw_write_symbol(clk_hal,reg_offset,
               BLSB_CRU_GET_STC_LO_Make_SW_TS,
               BMSK_CRU_GET_STC_LO_Make_SW_TS, 1); */
   return;
}



/* Sets the master DDS source */

ismd_result_t cmn_clk_hal_set_signal(smd_clock_hal *clk_hal, 
                                   clock_hal_dev_t clock,
                                   int            signal)
{
   ismd_result_t result;

   smd_clock_hal_subunit *unit;
   
   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );  
   unit = &clk_hal->unit[clock];

   switch(signal) {
      case (ISMD_CLOCK_SIGNAL_VCXO) :

         clock_hal_make_primary(clk_hal, clock);
         clk_hal->master_clock_source = ISMD_CLOCK_SIGNAL_VCXO;
         unit->clock_signal           = ISMD_CLOCK_SIGNAL_VCXO;
         result = ISMD_SUCCESS;
         break;

      case (ISMD_CLOCK_SIGNAL_MASTER_DDS) :

         /*clock_hal_make_primary(clk_hal, clock);
         clk_hal->master_clock_source = ISMD_CLOCK_SIGNAL_MASTER_DDS;
         unit->clock_signal           = ISMD_CLOCK_SIGNAL_MASTER_DDS;*/
         result = ISMD_ERROR_INVALID_PARAMETER;
         break;

      case (ISMD_CLOCK_SIGNAL_LOCAL_DDS) :

         clock_hal_reset_primary(clk_hal, clock);
         unit->clock_signal          = ISMD_CLOCK_SIGNAL_LOCAL_DDS;
         result = ISMD_SUCCESS;
         break;

      default :
         result = ISMD_ERROR_INVALID_PARAMETER;
         TEST_PRINT(5,"\nHal  :clock_hal_set_clock_source : invalid parameter");
         break;
   }
   return (result);
}


void cmn_clk_hal_set_freq_calib_offset(smd_clock_hal *clk_hal,
                                     int           offset)
{
   clk_hal->nominal_freq_offset_ppm = offset;
}

/* cmn_clk_hal_set_power_state : return not supported by default */
ismd_result_t cmn_clk_hal_set_power_state( smd_clock_hal *clk_hal, 
                                          icepm_state_t requested_state )
{
   (void)clk_hal;
   (void)requested_state;
   return ISMD_ERROR_FEATURE_NOT_SUPPORTED;
}

/* Helper functions to read/write HW registers */

/* reads the counter for the HW model introduced in Gen3 B0 
   NOTE: This function assumes that the caller is locking/unlocking
   interrupts 
*/
bool read_counter_value_gen3_b0(smd_clock_hal *clk_hal,
                                       clock_hal_dev_t clock) {
   uint32_t reg_offset, hw_bits_hi, hw_bits_lo;
   uint64_t hw_bits, hw_time, sw_bits;


   smd_clock_hal_subunit  *unit;
   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );
   unit = &clk_hal->unit[clock];

   reg_offset = unit->base_roff + ROFF_CRU_STC_LO;
   hw_bits_lo = (hw_read_reg32(clk_hal,reg_offset));

   reg_offset = unit->base_roff + ROFF_CRU_STC_HI;
   hw_bits_hi = hw_read_reg32(clk_hal,reg_offset);

   hw_bits = (((uint64_t)hw_bits_hi)<<32)|((uint64_t)hw_bits_lo);

   /*Throw the upper 22 bits of the read value */
   hw_bits = hw_bits & HW_CNTR_BIT_MASK;

   /*  Check for software roll over.  Get the software portion of the clock.  Bits higher then 41st bit of 64 bits.
   They store the rollover part.*/
   sw_bits = unit->current_time & (~HW_CNTR_BIT_MASK);
   TEST_PRINT(3, "\nHal  :Clock : %u  current_time : 0x%llx  hw_bits : 0x%llx : Sw_bits : 0x%llx", clock, unit->current_time, hw_bits, sw_bits);

   /* If there was a hardware rollover, increment the software portion of the clock. */
   if ( hw_bits < (unit->current_time & HW_CNTR_BIT_MASK) ) {
      TEST_PRINT(1, "\nHal  :There is a hardware rollover for clock :%u, sw_bits: 0x%llx hw_bits : 0x%llx current_time : 0x%llx", clock, sw_bits, hw_bits, unit->current_time);
      sw_bits += HW_CNTR_BIT_MASK + (uint64_t)1;
      TEST_PRINT(1, "\nHal  :There was a hardware rollover for clock :%u, sw_bits: 0x%llx hw_bits : 0x%llx current_time : 0x%llx", clock, sw_bits, hw_bits, unit->current_time);
   }

   /*  Set the read time as current time */
   hw_time = sw_bits | hw_bits;
   unit->current_time = scale_hw_time_to_ismd_time( hw_time );

   return true;
}


/* write_counter_value :  Writes the given value to SET_STC_LO/HI registers.  The counter is updated by value in these registers is
                          only after the software writes a "1" in bit 31 of the GEt_STC_LO register for the given clock. */
void write_counter_value( smd_clock_hal  *clk_hal,
                           clock_hal_dev_t  clock,
                           uint64_t     value)
{
    smd_clock_hal_subunit  *unit;
    uint64_t temp;

   DEVH_ASSERT( clk_hal->devh, clock < clk_hal->num_subunits );

   unit = &clk_hal->unit[clock];
   temp = value;
   value = value & HW_CNTR_BIT_MASK;

   TEST_PRINT(3,"\nHal  :write_counter_value : 0x%llx ", value);

   TEST_PRINT(3,"\nHal  :write_counter_value : Lo:0x%x ", (unsigned int)value);
   TEST_PRINT(3,"\nHal  :write_counter_value : Hi:0x%llx ", value>>32);
   devh_WriteReg32(clk_hal->devh,
               unit->base_roff + ROFF_CRU_SET_STC_LO,
               (unsigned int)value);

   TEST_PRINT(3,"\nHal  :write_counter_value : Value:0x%llx ", value);
   TEST_PRINT(3,"\nHal  :ls : clock : %u ROFF: 0x%x ", clock, unit->base_roff + ROFF_CRU_SET_STC_LO);

   hw_write_symbol(clk_hal,
               unit->base_roff + ROFF_CRU_SET_STC_HI,
               BLSB_CRU_SET_STC_HI_MSB_STC,
               BMSK_CRU_SET_STC_HI_MSB_STC,
               (uint32_t)(value>>32));


   TEST_PRINT(3,"\nHal  :write_counter_value : clock : %u ROFF: 0x%x ", clock, unit->base_roff + ROFF_CRU_SET_STC_HI);
   /* The values in SET_STC_LO/HI register would be written to wall clock only on when a '1' is written to Media_TB_UPD bit of
   GET_STC_LO register */


   TEST_PRINT(3,"\nHal  :write_counter_value : clock: %u base_roff: %u ", clock, unit->base_roff);
   devh_OrBitsReg32( clk_hal->devh,
               unit->base_roff + ROFF_CRU_GET_STC_LO,
               BMSK_CRU_GET_STC_LO_Media_TB_UPD );

   unit->current_time = scale_hw_time_to_ismd_time(temp);
   unit->current_vsync_time = scale_hw_time_to_ismd_time(temp);
   TEST_PRINT(3,"\nHal  :write_counter_value : current_time: 0x%llx", unit->current_time);
}


int cmn_clk_hal_get_type( smd_clock_hal *clk_hal, clock_hal_dev_t clock )
{
   int result = -1;
   (void)clk_hal; // silence warning

   if ( (clock >= 0) && (clock < clk_hal->num_subunits) ) {
      result = ISMD_CLOCK_TYPE_FIXED;
   }
  
   return ( result );
}


uint32_t hw_read_reg32(smd_clock_hal *clk_hal, uint32_t offset )
{
   uint32_t value;

   value  =  devh_ReadReg32( clk_hal->devh, offset );
   return ( value );
}


/*Write to a 32-bit counter register */
void hw_write_reg32( smd_clock_hal *clk_hal, uint32_t offset, uint32_t value )
{

   devh_WriteReg32( clk_hal->devh, offset, value);
   return;
}

/* Write a value to a 64-bit counter register. */
void hw_write_reg64(smd_clock_hal *clk_hal,
                              uint64_t reg_offset,
                                       uint64_t value )
{
   devh_WriteReg64( clk_hal->devh, reg_offset, value );
   return;
}

/* Read a value from a 64-bit counter register */
uint64_t hw_read_reg64( smd_clock_hal *clk_hal, uint64_t offset )
{
   uint32_t value;

   value  =  devh_ReadReg64( clk_hal->devh, offset );
   return ( value );
}



/* Write selected bits to a 32 bit register */
void hw_write_symbol(smd_clock_hal *clk_hal, uint32_t offset, uint32_t lsb, uint32_t mask, uint32_t val)
{

   devh_SetMaskedReg32(clk_hal->devh, offset, ~mask, (val << lsb));

   return;
}



