/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2006-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include <linux/version.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/mutex.h>
#include <asm/uaccess.h>
#include <linux/string.h>
#include <asm/ioctl.h>
#include "ismd_msg.h"
#include "ismd_msg_pvt.h"

#define xstringify(s) stringify(s)
#define stringify(s) #s
#ifdef COMP_VER
char *ioctl_module_version_string="#@# ioctl_module.ko " xstringify(COMP_VER) " " __DATE__ " " __TIME__;
MODULE_VERSION(xstringify(COMP_VER));
#else
char *ioctl_module_version_string="#@# ioctl_module.ko 0.0.0.0000 <- COMP_VER undefined> " __DATE__ " " __TIME__;
MODULE_VERSION("<Engineering Build> " __DATE__ " " __TIME__);
#endif

struct callback_node
{
	struct callback_node *next;
	void (*callback)(void *);
	unsigned long connection;
	void *data;
};

static struct callback_node *list_head;

/* This is the major number dynamically assigned by Linux */
/* This number is required by the mknod command. */
static int ioctl_major_number = 238;
ismd_api_group smd_api_array[50];
DEFINE_MUTEX(connect_lock);

#define MAX_PARAM_SIZE 512
#define DEVICE_NAME "smdmsg"


int ismd_connection_register(unsigned long connection, void (*callback)(void *), void *data)
{
	struct callback_node *node;

	if(!connection || !callback)
		return 4; //ISMD_ERROR_INVALID_PARAMETER
	node = kmalloc(sizeof(*node), GFP_KERNEL);
	if(!node)
		return 6; //ISMD_ERROR_NO_RESOURCES

	node->data = data;
	node->callback = callback;
	node->connection = connection;

	mutex_lock(&connect_lock);

	node->next = list_head;
	list_head = node;
	mutex_unlock(&connect_lock);	

	return 0;
}

int ismd_connection_unregister(void (*callback)(void *), void *data)
{
	struct callback_node *node, *prev_node;
	int ret = 13; //ISMD_ERROR_OBJECT_DELETED
	mutex_lock(&connect_lock);
	node = list_head;
	prev_node = NULL;
	// find the node, remove it from the list and free it.
	while(node){
		if(node->data == data && node->callback == callback){
			if(node == list_head)
				list_head = node->next;
			else
				prev_node->next = node->next;
			ret = 0;
			kfree(node);     
			break;
		}
		
		prev_node = node;
		node = node->next;
	}

	mutex_unlock(&connect_lock);
	return ret;
}


int ioctl_driver_open(struct inode *inode, struct file *file_ptr)
{
	return 0;
}

int ioctl_driver_close(struct inode *i, struct file *file_ptr)
{
	struct callback_node *node, *prev_node, *dead_node;

	prev_node = NULL;
	node = list_head;
	mutex_lock(&connect_lock);
	// walk the list and find any nodes with a connection that matches
	// this file_ptr
	while(node){
		if(node->connection == (unsigned long)file_ptr){
			// we found a match.  Call the callback and remove the node
			dead_node = node;
			node->callback(node->data);
			if(node == list_head){
				list_head = node->next;
			} else {
				prev_node->next = node->next;
			}
			node = node->next;
			// we're done with this node, free it and see if there are more
			kfree(dead_node);
			continue;
		}
		// No match, keep searching the list
		prev_node = node;
		node = node->next;

	}
	mutex_unlock(&connect_lock);   

	return 0;
}

/******************************************************************************/
int ioctl_driver_ioctl (struct inode *inode, struct file *file_ptr, 
	unsigned int cmd, unsigned long args)
{
	unsigned char params[MAX_PARAM_SIZE];
	unsigned api_group_id, msg_type;
	int ret, size;;

	api_group_id = _IOC_TYPE(cmd);
	msg_type = _IOC_NR(cmd);
	size = _IOC_SIZE(cmd);
	//if(size != MAX_PARAM_SIZE)
	//	return -EINVAL;
	// Copy across the parameters
	ret = copy_from_user(params, (char *)args, size);
	if(ret)
		return ret;

	// if we have a registered function, call it and copy back the results
        // verify we don't overflow any tables first though
        if (api_group_id < 0 || api_group_id >= ARRAY_SIZE(smd_api_array)) {
                printk(KERN_ERR "api_group_id %u out of range <0..%u>\n",
                        api_group_id, ARRAY_SIZE(smd_api_array));
        } else if (msg_type < 0 ||
                msg_type > smd_api_array[api_group_id].max_func_id) {

                printk(KERN_ERR "msg_type %u out of range <0..%u>\n",
                        msg_type, smd_api_array[api_group_id].max_func_id);
        } else if (NULL == smd_api_array[api_group_id].unmarshal) {
                printk(KERN_ERR
                        "NULL unmarshal function for api_group_id %u\n",
                        api_group_id);
        } else {
                smd_api_array[api_group_id].unmarshal[msg_type]((unsigned long)file_ptr, params);
		ret = copy_to_user((char *)args, params, size);
		return ret;
	}

	printk(KERN_ERR "Unknown ioctl: %d %d, %d\n", api_group_id, msg_type, size);

	return -ENXIO;
}


int unlocked_ioctl_driver (struct file *file_ptr, 
	unsigned int cmd, unsigned long args)
{
    return ioctl_driver_ioctl(file_ptr->f_dentry->d_inode, file_ptr, cmd, args);   
}


/* structure that maps our functions to the OS */
/******************************************************************************/
static struct file_operations ioctl_fops = {
    .owner   = THIS_MODULE,
    .open    = ioctl_driver_open,
    .release = ioctl_driver_close,
    .unlocked_ioctl = unlocked_ioctl_driver
};
static int __init ioctl_driver_init(void)
{
	int ret;
	/* register with fs */
	ret = register_chrdev(ioctl_major_number, DEVICE_NAME, &ioctl_fops);
	if (ret < 0) {
		return ret;
	}

	return 0;

}


/******************************************************************************/
static void __exit ioctl_driver_exit(void)
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,23)
	unregister_chrdev(ioctl_major_number, DEVICE_NAME);
#else
	int status;

	status = unregister_chrdev(ioctl_major_number, DEVICE_NAME);
	if (status < 0) {
		printk("Error unregistering device: %d\n", status);
	}
#endif
}

/******************************************************************************/
module_init(ioctl_driver_init);
module_exit(ioctl_driver_exit);
EXPORT_SYMBOL(smd_api_array);
EXPORT_SYMBOL(ismd_connection_register);
EXPORT_SYMBOL(ismd_connection_unregister);

MODULE_AUTHOR("Intel Corporation, (C) 2007-2008 - All Rights Reserved");
MODULE_DESCRIPTION("Intel Ioctl proxy");
MODULE_SUPPORTED_DEVICE("Intel Media Processors");
MODULE_LICENSE("Dual BSD/GPL");
