#!/usr/bin/python
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#   Intel Corporation
#
#   2200 Mission College Blvd.
#   Santa Clara, CA  97052
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import os, sys, re, string

api_name_to_id = { 'test'           : 0,
                   'demux_v2'       : 1,
                   'demux_v3'       : 1,
                   'audio'          : 2,
                   'audio_no_codecs': 2,
                   'mfd'            : 3,
                   'viddec'         : 3,
                   'viddec_v2'      : 3,
                   'viddec_v3'      : 3,
                   'dpe'            : 4,
                   'vidpproc'       : 4,
                   'vidrend'        : 5,
                   'core'           : 6,
                   'clock'          : 7,
                   'dfx'            : 8,
                   'clock_recovery' : 9,
                   'mrt'            : 10,
                   'tsout'          : 11,
                   'bufmon'         : 12,
                 'viddec_fw_parser' : 13,
                'viddec_fw_decoder' : 14,
                 'videnc_fw'        : 15,
                 'avcap_shim'       : 16,
                 'remux'            : 17,
                 'vidsink'          : 18,
                 'gen_timer'        : 19,
                 'ces_router'             : 20,
                 'ces_vidparse_videnc'    : 21,
                 'ces_videnc_mux'         : 22, 
                 'ces_vidparse_viddec'    : 23,
                 'ces_viddec_mux'         : 24,
                 'videnc'           : 25,
                 'mux'              : 26,
 }

api_name_to_desc = { 'test'              : 'SMD Test',
                     'demux_v2'          : 'SMD Demux, 2nd version',
                     'demux_v3'          : 'SMD Demux, 3rd version',
                     'audio'             : 'SMD Audio',
                     'audio_no_codecs'   : 'SMD Audio',
                     'mfd'               : 'SMD Multi-Format Video Decoder',
                     'viddec'            : 'SMD Multi-Format Video Decoder',
                     'viddec_v2'         : 'SMD Multi-Format Video Decoder v2',
                     'viddec_v3'         : 'SMD Multi-Format Video Decoder v3',
                     'dpe'               : 'SMD Display Processing Engine',
                     'vidpproc'          : 'SMD Display Processing Engine',
                     'vidrend'           : 'SMD Video Renderer',
                     'core'              : 'SMD Core',
                     'clock'             : 'SMD Clock',
                     'dfx'               : 'SMD DFX',
                     'clock_recovery'    : 'SMD Clock Recovery',
                     'mrt'               : 'SMD MRT',
                     'tsout'             : 'SMD TSOUT',
                     'bufmon'            : 'SMD BUFFERING MONTIOR',
                     'viddec_fw_parser'  : 'SMD FWPARSER',
                     'viddec_fw_decoder' : 'SMD FWDECODER',
                     'videnc_fw'         : 'SMD FW ENCODER',
                     'avcap_shim'        : 'SMD AVCAP SHIM',
                     'remux'             : 'SMD Multi-view Video Coding (MVC) Remux',
                     'vidsink'           : 'SMD VIDEO SINK',
                     'gen_timer'         : 'Generic Timer',
                     'ces_router'          : 'SMD Common Embedded Services',
                     'ces_vidparse_videnc' : 'CES Parser & Encoder driver',
                     'ces_videnc_mux'      : 'CES Video Encoder and Mux driver', 
                     'ces_vidparse_viddec' : 'CES Parser and Video Encoder', 
                     'ces_viddec_mux'      : 'CES Decoder and Mux',
                     'videnc'            : 'SMD Multi-Format Video Encoder',
                     'mux'	             : 'SMD mux',
}

msgs_file_name = '_msgs.h'
precalc_file_name = '_precalc.c'
server_file_name = '_server_stub.c'
client_file_name = '_client_stub.c'
symbol_file_name = '_symbols.txt'
enable_sven_auto_api = 1
precalc_needed = 0

api_macro = 'SMD_API_FUNC'
api_define = 'SMDEXPORT'
connect_define = 'SMDCONNECTION'
private_define = 'SMDPRIVATE'
##############################################################################
def find_smd_funcs(s):
	func_finder = re.compile('(\w+)\s+' + api_macro + '\((\w+)\)\(([^\)]*)\);')
	api_finder = re.compile('(\w+)\s+' + api_define + '\s+(\w+)\(([^\)]*)\);')
	connect_finder = re.compile('(\w+)\s+' + connect_define + '\s+(\w+)\(([^\)]*)\);')
	private_finder = re.compile('(\w+)\s+' + private_define + '\s+(\w+)\(([^\)]*)\);')
	param_parser = re.compile('\s*((\w+\s+)*\w+)\s*(\s+|\*)\s*(\w+)(\[(\w+)\])?\s*')
	void_check = re.compile('^\s*void\s*$')

	funcs = []
	privfuncs = []
	searches = [func_finder, api_finder, connect_finder]

	matches = private_finder.finditer(s)
	for match in matches:
		privfuncs.append(match.group(2))

	for search in searches:
		matches = search.finditer(s)
		for match in matches:
			# parse the parameters
			params = []
			#no params if only "void"
			if not void_check.findall(match.group(3)):
				param_matches = param_parser.findall(match.group(3))
				for param_match in param_matches:
					cur_param = { \
						'type': param_match[0],
						'is_ptr': param_match[2] == '*',
						'array_len' : param_match[5],
						'name': param_match[3] }

					params.append(cur_param)

			cur_func = { \
				'type': match.group(1), \
				'name': match.group(2), \
				'params': params,
				'has_params': match.group(1) != 'void' or len(params) > 0,
				'connect': search == connect_finder }
			funcs.append(cur_func)

	return [funcs, privfuncs]

##############################################################################
def gen_msgs_precalc(api_group, funcs, api_files ):
    out = '/*\n  This file is provided under a dual BSD/GPLv2 license.  When using or\n  redistributing this file, you may do so under either license.\n\n  GPL LICENSE SUMMARY\n\n  Copyright(c) 2009 Intel Corporation. All rights reserved.\n\n  This program is free software; you can redistribute it and/or modify\n  it under the terms of version 2 of the GNU General Public License as\n  published by the Free Software Foundation.\n\n  This program is distributed in the hope that it will be useful, but\n  WITHOUT ANY WARRANTY; without even the implied warranty of\n  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU\n  General Public License for more details.\n\n  You should have received a copy of the GNU General Public License\n  along with this program; if not, write to the Free Software\n  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.\n  The full GNU General Public License is included in this distribution\n  in the file called LICENSE.GPL.\n\n  Contact Information:\n   Intel Corporation\n\n   2200 Mission College Blvd.\n   Santa Clara, CA  97052\n\n  BSD LICENSE\n\n  Copyright(c) 2009 Intel Corporation. All rights reserved.\n  All rights reserved.\n\n  Redistribution and use in source and binary forms, with or without\n  modification, are permitted provided that the following conditions\n  are met:\n\n    * Redistributions of source code must retain the above copyright\n      notice, this list of conditions and the following disclaimer.\n    * Redistributions in binary form must reproduce the above copyright\n      notice, this list of conditions and the following disclaimer in\n      the documentation and/or other materials provided with the\n      distribution.\n    * Neither the name of Intel Corporation nor the names of its\n      contributors may be used to endorse or promote products derived\n      from this software without specific prior written permission.\n\n  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS\n  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT\n  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR\n  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT\n  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,\n  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT\n  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,\n  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY\n  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT\n  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE\n  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n\n */\n'

    out += '#include <stdio.h>\n'
    out += '#include <stdint.h>\n'
    out += '#include "ismd_msg.h"\n'
    out += '#include "ismd_global_defs.h"\n'
    for f in api_files:
        out += '#include "' + f + '"\n'

    out += '#include "' + api_group + msgs_file_name + '"\n'

    out += '\n\nint g_api_message_sizes_' + api_group + '[] = {\n'
    for f in funcs:
      if f['has_params']:
        out += '   sizeof( '+ f['name'] + '_params_t),\n'
      else:
        out += '   0,\n'
    out += '};\n'

    out += '\n\n#ifdef SELF_TEST\n'
    out += 'int main ( int argc, char *argv[] ) {\n'
    out += '   int siz, max_siz = 0;\n'
    for f in funcs:
      if f['has_params']:
        out += '   siz = sizeof( '+ f['name'] + '_params_t);\n'
        out += '   if ( max_siz < siz ) max_siz = siz;\n'
      else:
        out += '   siz = 0;\n'
      out += '   printf(" %64s: size = %5d 0x%04x\\n", "' + f['name'] + '", siz, siz );\n'
    out += '   printf(" =================================================================\\n" );\n'
    out += '   printf(" %64s: size = %5d 0x%04x\\n", "max_size", max_siz, max_siz );\n'
    out += '   return(0);\n'
    out += '}\n'
    out += '#endif /* SELF_TEST */\n'

    return out

##############################################################################
def gen_msgs(api_group, funcs):
    out = '/*\n  This file is provided under a dual BSD/GPLv2 license.  When using or\n  redistributing this file, you may do so under either license.\n\n  GPL LICENSE SUMMARY\n\n  Copyright(c) 2009 Intel Corporation. All rights reserved.\n\n  This program is free software; you can redistribute it and/or modify\n  it under the terms of version 2 of the GNU General Public License as\n  published by the Free Software Foundation.\n\n  This program is distributed in the hope that it will be useful, but\n  WITHOUT ANY WARRANTY; without even the implied warranty of\n  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU\n  General Public License for more details.\n\n  You should have received a copy of the GNU General Public License\n  along with this program; if not, write to the Free Software\n  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.\n  The full GNU General Public License is included in this distribution\n  in the file called LICENSE.GPL.\n\n  Contact Information:\n   Intel Corporation\n\n   2200 Mission College Blvd.\n   Santa Clara, CA  97052\n\n  BSD LICENSE\n\n  Copyright(c) 2009 Intel Corporation. All rights reserved.\n  All rights reserved.\n\n  Redistribution and use in source and binary forms, with or without\n  modification, are permitted provided that the following conditions\n  are met:\n\n    * Redistributions of source code must retain the above copyright\n      notice, this list of conditions and the following disclaimer.\n    * Redistributions in binary form must reproduce the above copyright\n      notice, this list of conditions and the following disclaimer in\n      the documentation and/or other materials provided with the\n      distribution.\n    * Neither the name of Intel Corporation nor the names of its\n      contributors may be used to endorse or promote products derived\n      from this software without specific prior written permission.\n\n  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS\n  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT\n  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR\n  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT\n  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,\n  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT\n  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,\n  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY\n  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT\n  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE\n  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n\n */\n'

    out += '#ifndef __AUTO_MSGS_H__\n'
    out += '#define __AUTO_MSGS_H__\n'

    api_group_id = api_name_to_id[api_group]
    out += '\n#define API_GROUP_TYPE_'+ api_group + ' ' + str(api_group_id) + '\n'
    cur_id = 0
    for f in funcs:
        out += '\n#define MSG_TYPE_' + f['name'] + ' ' + str(cur_id) + '\n\n'
        if f['has_params']:
            # declare a structure to hold the return value and/or params
            out += 'typedef struct {\n'
            for p in f['params']:
                out += '   ' + p['type'] + ' ' + p['name']
		if p['array_len']:
			out += '[' + p['array_len'] + ']'
                if p['array_len'] or p['is_ptr']:
                        out += ';\n   int ' + p['name'] + '_is_null'
		out += ';\n'
            if f['type'] != 'void':
                out += '   ' + f['type'] + ' return_value;\n'
            out += '} ' + f['name'] + '_params_t;\n'
        cur_id += 1

    out += '#endif\n'
    return out

##############################################################################
def gen_client_stubs(comm_method, api_group, funcs, api_files):
    api_group_id = api_name_to_id[api_group]
    out = ''

    # basic code blocks,  Substitute NAME, TYPE, and ARRAY_LEN for the real values
    pointer_clt_code = '   if(NAME) {\n' + \
                       '      p.NAME = *NAME;\n' + \
                       '      p.NAME_is_null = 0;\n' + \
                       '   } else {\n' + \
                       '      p.NAME_is_null = 1;\n' + \
                       '   }\n'

    normal_clt_code =  '   p.NAME = NAME;\n'

    array_clt_code =   '   if(NAME) {\n' + \
                       '      memcpy(p.NAME, NAME, sizeof(TYPE) * ARRAY_LEN);\n' + \
                       '      p.NAME_is_null = 0;\n' + \
                       '   } else {\n' + \
                       '      p.NAME_is_null = 1;\n' + \
                       '   }\n'

    pointer_fini_code ='   if(NAME) {\n' + \
                       '      *NAME = p.NAME;\n' + \
                       '   }\n'
    array_fini_code =  '   if(NAME) {\n' + \
                       '      memcpy(NAME, p.NAME, sizeof(TYPE) * ARRAY_LEN);\n' + \
                       '   }\n'
    normal_fini_code = '   NAME = p.NAME;\n'

    for f in funcs:
        #out += '\n#pragma GCC diagnostic ignored "-Wall"'
        out += '\n' + f['type'] + ' ' + f['name'] + '('
        first = True
        for p in f['params']:
            if not first:
                out += ', '
            out += p['type'] + ' '
            if p['is_ptr']:
                out += '*'
            out += p['name']
            if p['array_len']:
                out += '[' + p['array_len'] + ']'
            first = False
        out += ') {\n'
        if f['has_params']:
            out += '   ' + f['name'] + '_params_t p;\n'

        # init param struc values
        out += '\n'
        for p in f['params']:
             if p['array_len']:
                 tmp = re.sub('NAME', p['name'], array_clt_code)
                 tmp = re.sub('TYPE', p['type'], tmp)
                 out += re.sub('ARRAY_LEN', p['array_len'], tmp)
             elif p['is_ptr']:
                 out += re.sub('NAME', p['name'], pointer_clt_code)
             else:
                 out += re.sub('NAME', p['name'], normal_clt_code)

        # send SVEN TX message, function entered
        if enable_sven_auto_api == 1 :
            out += '\n   smd_autoapi_called(API_GROUP_TYPE_' + api_group + ', MSG_TYPE_' + f['name'] + ', '
            i = 0
            for p in f['params']:
                if i < 4 :
                    out += '((const int *)&p.' + p['name'] + ')[0], '
                elif i == 4:
                    out += '((const int *)&p.' + p['name'] + ')[0]'
                i += 1

            more_params = 5 - i
            i = 0
            while i < more_params:
                if i == more_params - 1:
                    out += '0'
                else:
                    out += '0, '
                i += 1
            out += ' );\n\n'

        # send message
        out += '\n   ismd_msg_send_' + comm_method +'(API_GROUP_TYPE_' + api_group + ', MSG_TYPE_' + f['name'] + ', '
        if f['has_params']:
            out += '&p, sizeof(p));\n\n'
        else:
            out += '(void*)0, 0);\n\n'

         # copy back final values for 'by reference' parameters
        for p in f['params']:
            if p['is_ptr']:
                out += re.sub('NAME', p['name'], pointer_fini_code)
            elif p['array_len']:
                tmp = re.sub('NAME', p['name'], array_fini_code)
                tmp = re.sub('TYPE', p['type'], tmp)
                out += re.sub('ARRAY_LEN', p['array_len'], tmp)
            else:
                out += re.sub('NAME', p['name'], normal_fini_code)

        # send SVEN TX message, function returned
        if enable_sven_auto_api == 1 :
            out += '\n   smd_autoapi_returned(API_GROUP_TYPE_' + api_group + ', MSG_TYPE_' + f['name'] + ', '
            # publish API_Returned message with return value
            if f['type'] != 'void':
                out += '(int)p.return_value );\n\n'
            else:
                out += '0);\n\n'

        if f['type'] != 'void':
            out += '\n   return p.return_value;\n'

        out += '}\n'

    return out


##############################################################################
def gen_server_stubs(comm_method, api_group, funcs, privfuncs, api_files):
    out = ''
    pointer_srv_code = 'p->NAME_is_null ? (void *)0 : &p->NAME'
    array_srv_code =   'p->NAME_is_null ? (void *)0 : p->NAME'
    normal_srv_code =  'p->NAME'

    for f in funcs:
        param_type = f['name'] + '_params_t'
        out += 'static void ' + f['name'] + '_unmarshal(unsigned long connection, void *params) {\n'
        if f['has_params']:
            out += '   ' + param_type + ' *p = (' + param_type + '*)params;\n'
        out += '   '
        if f['type'] != 'void':
            out += 'p->return_value = '
        out += f['name']
	if f['connect']:
            out += '_track(connection'
	    first = False
	else:
	    out += '('
            first = True
        for p in f['params']:
            if not first:
                out += ', '
            first = False
            if p['array_len']:
                out += re.sub('NAME', p['name'], array_srv_code)
            elif p['is_ptr']:
                out += re.sub('NAME', p['name'], pointer_srv_code)
            else:
                out += re.sub('NAME', p['name'], normal_srv_code)
        out += ');\n'
	out += '    connection = connection;\n'
	out += '    params = params;\n'
        out += '}\n\n'
        if comm_method == 'ioctl':
            out +='EXPORT_SYMBOL(' + f['name'] + ');\n\n'

    out += 'static void (*ismd_msg_unmarshal[])(unsigned long connection, void *params) = {\n'
    first = True
    for f in funcs:
        if not first:
            out += ',\n'
        out += '   ' + f['name'] + '_unmarshal'
        first = False
    out += '\n};\n'
    if comm_method == 'ioctl':
        for f in privfuncs:
            out +='EXPORT_SYMBOL(' + f + ');\n'

    return out

##############################################################################
def gen_svenreverse_stubs(comm_method, api_group, funcs, api_files):
    api_group_id = api_name_to_id[api_group]
    out = ''

    out += '\nstatic const struct SVEN_Module_EventSpecific g_smd_API_' + api_group + '_specific_events[]='
    out += '\n{'

    api_id = 0
    for f in funcs:
        i = 1
        out += '\n' + '   { "' + f['name'] + '", ' + str(api_id) + ', "'
        for p in f['params']:
           if i < 6 :
             out += p['name'] + ': 0x%x, '
             i += 1
        out += '", NULL },'
        api_id += 1

    out += '\n   { NULL, 0, NULL, NULL }'
    out += '\n};'

    return out


##############################################################################
def read_input(files):
    input_str = ''
    for file_name in files:
        f = file(file_name)
        for str in f:
            input_str += str
        f.close()
    return input_str

##############################################################################
def write_file(name, data):
    f = file(name, 'w')
    f.write(data)
    f.close()

##############################################################################
def get_svn_revision(component):
    rev_str = 'SDK'

    # Get last changed revision number for the component from subversion
    # and write to a temporary file
    comp_path = os.path.join(smd_path, component)
    # if there is no .svn directory in the module directory, this is probably not an internal build, so skip
    # trying to find the subversion version.
    if os.path.isdir(os.path.join (comp_path, '.svn')):
        os.system('svn info ' + comp_path + ' | grep \'Last Changed Rev:\' | awk \'{ print $4 }\' > rev');

        # Read the file and get the revision number
        rev_str = read_input(['rev'])

        # Delete temporary file
        os.system('rm rev')

    return string.strip(rev_str)

##############################################################################
def stub_substitution(source_file, body_stub, api_name, api_desc, header_files, comm_method):
    out = read_input([source_file])
    headers = ''
    for f in header_files:
        headers += '#include "' + f + '"\n'
    if comm_method != 'ioctl':
        headers += '#include <string.h>\n'
    out = re.sub('--INPUT_HEADERS--', headers, out)
    out = re.sub('--API_NAME--', api_name, out)
    out = re.sub('--API_DESC--', api_desc, out)
    out = re.sub('--BODY--', body_stub, out)
    if enable_sven_auto_api == 1 :
        out = re.sub('--REV_NO--', get_svn_revision(api_name), out)

    return out

##############################################################################
def api_gen(argv):
    global enable_sven_auto_api
    global precalc_needed
    if len(argv) < 3:
        print "Usage: smd_api_gen <comm_type> <component_name> <file>[, <file>...]"
        return

    comm_method = argv[0]
    api_group = argv[1]
    api_desc = api_name_to_desc[api_group]
    api_group_id = api_name_to_id[api_group]
    if comm_method == 'gv' :
        enable_sven_auto_api = 0
        precalc_needed = 1
    if comm_method == 'mfd' :
        enable_sven_auto_api = 0
        precalc_needed = 1
    if comm_method == 'svenreverse':
       output_filename = argv[2]
       argv = argv[3:]
    else:
       argv = argv[2:]
    input_str = read_input(argv)
    [funcs, privfuncs] = find_smd_funcs(input_str)
    msgs = gen_msgs(api_group, funcs)

    if precalc_needed == 1 :
        precalc = gen_msgs_precalc(api_group, funcs, argv )

    if comm_method == 'svenreverse':
       svenrev_stubs = gen_svenreverse_stubs(comm_method, api_group, funcs, argv)
       svenrev_stubs = stub_substitution(dir_base_name +  'autoapi_reverse.c', svenrev_stubs, api_group, api_desc, argv, comm_method)
       output_dirname = os.path.dirname(output_filename)
       if not os.path.isdir(output_dirname):
              os.mkdir(output_dirname)
       write_file( output_filename, svenrev_stubs )
    else:
       client_stubs = gen_client_stubs(comm_method, api_group, funcs, argv)
       client_stubs = stub_substitution(dir_base_name + comm_method + client_file_name, client_stubs, api_group, api_desc, argv, comm_method)
       server_stubs = gen_server_stubs(comm_method, api_group, funcs, privfuncs, argv)
       server_stubs = stub_substitution(dir_base_name + comm_method + server_file_name, server_stubs, api_group, api_desc, argv, comm_method)
       funclist = ''
       for f in funcs:
           funclist += f['name'] + '\n'
       write_file(api_group + msgs_file_name, msgs)
       if precalc_needed == 1 :
            write_file(api_group + precalc_file_name, precalc )
       write_file(api_group + '_' + comm_method + server_file_name, server_stubs)
       write_file(api_group + '_' + comm_method + client_file_name, client_stubs)
       write_file(api_group + symbol_file_name, funclist)


#    print '-----------' + msgs_file_name + '---------------\n', msgs
#    print '-----------' + client_file_name + '---------------\n', client_stubs
#    print '-----------' + server_file_name + '---------------\n', server_stubs



#############################################################################
if __name__ == "__main__":
    argv = sys.argv[1:]
    path = os.path.dirname(sys.argv[0])

    dir_base_name = path + '/'
    # If this is an internal Intel build, the smd directory will be two levels up from where this script is.
    # This script is typically copied into and run from $BUILD_DEST/internal directory.
    smd_path = os.path.normpath (os.path.join(dir_base_name, '../../smd'))
    api_gen(argv)
