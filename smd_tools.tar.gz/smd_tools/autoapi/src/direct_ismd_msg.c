/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007, 2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
   Intel Corporation

   2200 Mission College Blvd.
   Santa Clara, CA  97052


  BSD LICENSE

  Copyright(c) 2007, 2008 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

/* msg_direct.c

   This file implements a "dummy" message transport to support "direct"
   calling via SMD marshalling infrastructure when client and server are
   in the same address space.
*/


#include <string.h>
#include <assert.h>
#include <errno.h>
#include <pthread.h>
#include <stdlib.h>

#include "ismd_msg.h"
#include "ismd_msg_pvt.h"

#define CONNECTION_MAGIC (0x8675309)
//lame list structure.  Don't care about removal performance.
struct connect_list
{
	struct connect_list *next;
	void (*callback)(void *);
	void *data;
};

pthread_mutex_t callback_lock = PTHREAD_MUTEX_INITIALIZER;

ismd_api_group smd_api_array[50];

static struct connect_list *list_head = NULL;

int ismd_connection_register(unsigned long connection, void (*callback)(void *), void *data)
{
	struct connect_list *node;

	/* Paranoia sanity check */
	if(connection != CONNECTION_MAGIC || !callback){
		return 4; //ISMD_ERROR_INVALID_PARAMETER
	}

	node = malloc(sizeof(*node));
	if(!node){
		return 6; //ISMD_ERROR_NO_RESOURCES
	}

	/* place the callback request in the callback list for later use */

	node->data = data;
	node->callback = callback;
	pthread_mutex_lock(&callback_lock);
	node->next = list_head;
	list_head = node;
	pthread_mutex_unlock(&callback_lock);

	return 0;
}

int ismd_connection_unregister( void (*callback)(void *), void *data)
{
	struct connect_list *node, *old_node;
	int ret = 13; //ISMD_ERROR_OBJECT_DELETED

	/* lock the list, then call every callback */
	pthread_mutex_lock(&callback_lock);
	old_node = NULL;
	for(node = list_head; node; ){
		if(node->data == data && node->callback == callback){
			if(!old_node)
				list_head = node->next;
			else
				old_node->next = node->next;
			free(node);
			ret = 0;
			break;
		}		

		old_node = node;
		node = node->next;
	}
	pthread_mutex_unlock(&callback_lock);

	return ret;
}


/*  called when the app tries to exit gracefully.  Call all callbacks. */
static void connection_exit_callback(void)
{
	struct connect_list *node, *old_node;

	/* lock the list, then call every callback */
	pthread_mutex_lock(&callback_lock);
	for(node = list_head; node; ){
		node->callback(node->data);
		old_node = node;
		node = node->next;
		free(old_node);
		
	}
	pthread_mutex_unlock(&callback_lock);
}

/* Called at program start time.  Registers the callback to be called when
   The app exits */
__attribute__((constructor)) static void setup_exit_callback(void)
{
	atexit(&connection_exit_callback);
}


int ismd_msg_send_direct(unsigned api_group_id, unsigned msg_type, void *params, unsigned int param_size)
{
	/* For testing, copy params into a local block to simulate sending 
	   the data over IPC or address space boundary.
	*/
	char remote_params[512];
	//printf("in ismd_msg_send_direct\n");
	assert(param_size <= sizeof(remote_params));
	memcpy(&remote_params, params, param_size);
	if(smd_api_array[api_group_id].unmarshal){
		smd_api_array[api_group_id].unmarshal[msg_type](CONNECTION_MAGIC, remote_params);
		memcpy(params, &remote_params, param_size);

		/* no I/O errors possible for direct mode */
		return 0;
	}
	return -EINVAL;
		     
}
