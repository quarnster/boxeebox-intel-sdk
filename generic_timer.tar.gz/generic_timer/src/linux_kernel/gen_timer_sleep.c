/*----------------------------------------------------------------------
 * File Name:      generic_timer.c 
 *---------------------------------------------------------------------*/

 /*
  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
   Intel Corporation

   2200 Mission College Blvd.
   Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */
#include "ismd_core.h"
#include "ismd_msg.h"
#include "osal.h"
#include "gen_timer.h"

// Factor applied to input to yield 100usec resolution
#define TICKS_100USEC 9

// Offset used for calculating the value for event wait timeout in milliseconds.
// TODO: (1000 / HZ) (OS clock tick period) to be used once the spurious wakeup issue is resolved in event manager
#define GT_SLEEP_TIMEOUT_OFFSET_MSEC 8

// Microseconds in a millisecond. Used for calculating whether delay argument from the user is factored into the timeout.
#define GT_SLEEP_USEC_PER_MSEC 1000

/****************************************************************************
* Allocate, schedule and wait for an event based on the sleep interval
* requested by the caller in units of 100 microseconds
****************************************************************************/
ismd_result_t
gt_sleep_100us( unsigned long delay  )
{

    ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
    ismd_clock_t clock = ISMD_CLOCK_HANDLE_INVALID;
    ismd_event_t event = ISMD_EVENT_HANDLE_INVALID;
    ismd_clock_alarm_t alarm;
    // Since ismd_time_t is large no need to check/limit arg value
    ismd_time_t sched_alarm_time = (ismd_time_t) delay * TICKS_100USEC;
    unsigned int timeout = GT_SLEEP_TIMEOUT_OFFSET_MSEC + (delay * 100 / GT_SLEEP_USEC_PER_MSEC);

    if ((result = ismd_event_alloc(&event)) == ISMD_SUCCESS) {
        if ((result = ismd_clock_alloc(ISMD_CLOCK_TYPE_FIXED, &clock)) == ISMD_SUCCESS) {
            if ((result = ismd_clock_set_time(clock, (ismd_time_t)0ull)) == ISMD_SUCCESS) {
                if((result = ismd_clock_alarm_schedule(clock, sched_alarm_time, 0ull, event, &alarm)) == ISMD_SUCCESS) {
                    result = ismd_event_wait(event, timeout);

                    // The purpose of this component is to provide a mechanism to accurately sleep for sub-millisecond values.
                    // This assert makes sure that this purpose is always served, failing which a system bug would be reported.
                    OS_ASSERT( result != ISMD_ERROR_TIMEOUT );

                    if(result == ISMD_SUCCESS) {
                        ismd_event_acknowledge( event );
                    }
                    else {
                        ismd_clock_alarm_cancel( clock, alarm );
                    }
                }
            }
            else {
                OS_PRINT ("%s : %s : %d : ERROR %d :  Failed to set time.\n", __FILE__, __FUNCTION__, __LINE__, result);
            }
        }
        else {
            OS_PRINT ("%s : %s : %d : ERROR %d :  Failed to allocate clock.\n", __FILE__, __FUNCTION__, __LINE__, result);
        }
    }
    else {
        OS_PRINT ("%s : %s : %d : ERROR %d :  Failed to allocate event.\n", __FILE__, __FUNCTION__, __LINE__, result);
    }

    if ( clock != ISMD_CLOCK_HANDLE_INVALID ) {
        ismd_clock_free( clock );
    }

    if ( event != ISMD_EVENT_HANDLE_INVALID ) {
        ismd_event_free( event );
    }

    return result;
}
