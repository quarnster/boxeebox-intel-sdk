/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "audio_hal_render.h"
#include "audio_hal_render_pvt.h"
#include "auto_eas/gen3_aud_io.h"

audio_hal_render_context_t *hal_render_contexts[RENDER_HAL_MAX_DEVICES];

ismd_result_t
audio_hal_render_init_context
(
   audio_hal_render_context_t *render_context,
   void *caller_context,
   os_devhandle_t *devh,
   int hw_dev_id,
   audio_hal_render_buffer_mode_t mode,
   uint32_t mem_addr_phys,
   void *mem_addr_virt,
   size_t mem_size,
   buffer_callback_t callback_function
)
{
   ismd_result_t  result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   unsigned int node_count = 0;
   size_t usable_mem_size = 0;
      
   /*Make sure our context it in a default state*/
   audio_pvt_hal_init_render_context_variables(render_context);
   
   /*Fill in the SVEN handle*/
   if(devh != NULL){
      render_context->hal_devh.devh = devh;
      render_context->hal_devh.devName = "AUD_IO";
      render_context->hal_devh.svenModule = SVEN_module_GEN3_AUD_IO;
      render_context->hal_devh.svenUnit = 0;      
   }
   else {
      result = ISMD_ERROR_NULL_POINTER;
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);     
   }
   
   /*Store user context, used for callbacks.*/
   render_context->user_context = caller_context;

   /*Here is the tx/dma context association per HW output.*/
   switch(hw_dev_id){
      case GEN3_HW_OUTPUT_I2S0:
         render_context->tx_context = AUDIO_TX_CONTEXT_TX0;
         render_context->dma_context = AUDIO_DMA_CONTEXT0;
         render_context->interrupt_mask = DMA0_SOURCE_INTERRUPT_PENDING;
         render_context->output = AUDIO_HAL_OUT_SEL_I2S0;
         break;
      case GEN3_HW_OUTPUT_I2S1:
         render_context->tx_context = AUDIO_TX_CONTEXT_TX1;
         render_context->dma_context = AUDIO_DMA_CONTEXT1;
         render_context->interrupt_mask = DMA1_SOURCE_INTERRUPT_PENDING;
         render_context->output = AUDIO_HAL_OUT_SEL_I2S1;
         break;
      case GEN3_HW_OUTPUT_SPDIF:
         render_context->tx_context = AUDIO_TX_CONTEXT_TX2;
         render_context->dma_context = AUDIO_DMA_CONTEXT2;
         render_context->interrupt_mask = DMA2_SOURCE_INTERRUPT_PENDING;
         render_context->output = AUDIO_HAL_OUT_SEL_SPDIF;
         break;
      case GEN3_HW_OUTPUT_HDMI:
         //HDMI has a GDL HAL
      default:
         result =  ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);
         break;
   }
      
   result = audio_hal_dma_flush(&(render_context->hal_devh), render_context->dma_context);
   VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);
   
   /* Reset the context */
   result = audio_hal_dma_reset(&(render_context->hal_devh), render_context->dma_context);
   VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);
   
   result = audio_pvt_hal_tx_reset(&(render_context->hal_devh), render_context->tx_context );
   VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);
   
   /*Set the transmit FIFO threshold level*/
   result = audio_pvt_hal_tx_fifo_set_thrsh_level( &(render_context->hal_devh), render_context->tx_context, AUDIO_TX_FIFO_THRESHOLD_LEVEL);
   VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);
   
   /*Set output Interface based off of the input parameter*/
   audio_pvt_hal_set_output_interface(&(render_context->hal_devh), render_context->tx_context, render_context->output);
   
   /*Set up circular buffer mode*/
   if(mode == AUDIO_RENDER_BUFFER_MODE_CIRCULAR){

      render_context->buffer_mode = mode;

      /* Setup render buffer */
      render_context->circ_buf.base = mem_addr_phys;
      render_context->circ_buf.size = mem_size;
      render_context->circ_buf.saved_read_ptr_val = mem_addr_phys;
      render_context->circ_buf.saved_write_ptr_val = mem_addr_phys;


      result = audio_pvt_hal_dma_get_pointers(&(render_context->hal_devh), render_context->dma_context, &(render_context->circ_buf.read_reg_addr), &(render_context->circ_buf.write_reg_addr));
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);

      result = audio_pvt_hal_render_circ_buf_init(&(render_context->circ_buf_wl), &(render_context->circ_buf));
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);

      result = audio_pvt_hal_dma_set_circ_buf( &(render_context->hal_devh), render_context->tx_context, render_context->dma_context, mem_addr_phys, mem_size);
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);

      if ( os_thread_create(&(render_context->low_wtrmrk_thread), 
                                audio_pvt_hal_render_low_watermark_thread,
                                (void*)render_context, 
                                80, /* TODO: remove hardcoded value if we ever use this function. */
                                OS_THREAD_REALTIME, 
                                "Audio_lowwtrmrk") != OSAL_SUCCESS ) {

         OS_INFO("os_thread_create failed !");
         result = ISMD_ERROR_OPERATION_FAILED;
      }

   } 

   /*Set up linked list mode mode*/
   else if(mode == AUDIO_RENDER_BUFFER_MODE_LINKED_LIST) {

     /* Find out how many nodes we can get out of the memory given. */
     node_count = (mem_size / SIZE_OF_DMA_LINKED_LIST_NODE);

     /* Only send the size of memory we are actually using. */
     usable_mem_size = (node_count * SIZE_OF_DMA_LINKED_LIST_NODE);

    //debug OS_INFO("actual_mem_size: %d, usable_mem_size: %d\n", mem_size, usable_mem_size);
   
      result = audio_pvt_hal_render_linked_list_dma_setup(
         render_context, 
         node_count,  
         mem_addr_phys, 
         (int32_t)mem_addr_virt,
         usable_mem_size);
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);

   
   } 

   else {
      result =  ISMD_ERROR_INVALID_PARAMETER;
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);
   }


   render_context->in_use = true;
   render_context->buffer_callback_func = callback_function;
   render_context->dma_buffer_size = mem_size;

   //Register the instance with the global HAL pointer, the dma context serves as the index into this array
   hal_render_contexts[render_context->dma_context] = render_context;
   
   goto end;
   
error:
   render_context->hal_devh.devh = NULL;
   render_context->in_use = false;            

end:
      //Clean up and exit code
      
   AUDIO_EXIT(render_context->hal_devh.devh);
   

   return result;
}

void
audio_hal_render_deinit_context(audio_hal_render_context_t *render_context)
{

   render_context->start_to_close = true;

   /* Make sure we dont have any nodes we havent already freed. */
   if(render_context->curr_node_count > 0){

      audio_pvt_hal_render_linked_list_shutdown_cleanup(render_context);
   }

   if(render_context->buffer_mode == AUDIO_RENDER_BUFFER_MODE_CIRCULAR){
      audio_pvt_hal_render_circ_buf_deinit(&(render_context->circ_buf_wl), &(render_context->circ_buf));
   }

  //audio_pvt_hal_init_render_context_variables(render_context);

   return;
}

ismd_result_t
audio_hal_render_buffer_set_config
(
   audio_hal_render_context_t *render_context,
   size_t max_buffer_size,
   size_t high_watermark,
   size_t low_watermark
)
{
   ismd_result_t  result = ISMD_SUCCESS;

   render_context->high_watermark = high_watermark;
   render_context->low_watermark = low_watermark;
   render_context->max_dma_buffer_size = max_buffer_size;

   return result;
}

ismd_result_t
audio_hal_render_buffer_get_level
(
   audio_hal_render_context_t *render_context,
   size_t *level
)
{
   ismd_result_t  result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   int space_avail = 0;

   if(render_context->in_use && (render_context->buffer_mode == AUDIO_RENDER_BUFFER_MODE_CIRCULAR)){
      
      result = audio_pvt_hal_render_circ_buf_get_write_cnt(&(render_context->circ_buf_wl), &(render_context->circ_buf), &space_avail);
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);

      *level = space_avail;
   }

   else if(render_context->in_use && (render_context->buffer_mode == AUDIO_RENDER_BUFFER_MODE_LINKED_LIST)){

     *level = render_context->dma_buffer_level;
      
   }

   else{
      result = ISMD_ERROR_INVALID_PARAMETER;
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);
   }

   error:

   return result;
}

ismd_result_t
audio_hal_render_buffer_add
(
   audio_hal_render_context_t *render_context,
   uint32_t buf_addr_phys,
   void *buf_addr_virt,
   size_t buf_size,
   int buf_id 
)
{
   ismd_result_t  result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   unsigned int prev_index = 0;
   unsigned int dma_next_node = 0;
   unsigned int dma_curr_node = 0;
   unsigned int dma_flags_active = 0;
   unsigned int new_node_phys= 0;

   if(render_context->in_use && (render_context->buffer_mode == AUDIO_RENDER_BUFFER_MODE_CIRCULAR) && (!render_context->start_to_close)){

      if((result = audio_pvt_hal_render_circ_buf_write(&(render_context->circ_buf_wl), buf_addr_virt, &(render_context->circ_buf), buf_size)) == ISMD_SUCCESS){

         /* In circular mode we just need to call the callback function to deref the buffer. */
         (*(render_context->buffer_callback_func)) (render_context->user_context,  buf_id, AUDIO_RENDER_INPUT_BUFFER_DONE);   
      }
      else{
         result = ISMD_ERROR_NO_SPACE_AVAILABLE;
      }

   }

   else if(render_context->in_use && (render_context->buffer_mode == AUDIO_RENDER_BUFFER_MODE_LINKED_LIST) && (!render_context->start_to_close))
   {

      /* Check to see where the DMA is at */
      dma_next_node = READ_IO(render_context->hal_devh.devh, DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_NEXT_DESCR); 
      dma_curr_node = READ_IO(render_context->hal_devh.devh, DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_CURR_DESCR); 
      dma_flags_active = READ_IO(render_context->hal_devh.devh, DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_ACTIVE_DMA);
      /* First node addition to the list */
      if(!render_context->first_node_added){

         render_context->underrun = false;
         render_context->first_node_added = true;
         render_context->curr_node_index = 0;
         render_context->curr_dma_node_index = 0;

         /*Update the node.*/
         render_context->dma_nodes[0].dma_descriptor.SRCDMA_START = buf_addr_phys;
         render_context->dma_nodes[0].dma_descriptor.SRCDMA_SIZE = buf_size;
         render_context->dma_nodes[0].dma_descriptor.FLAGS_MODE = render_context->flags_mode_stop;
         render_context->dma_nodes[0].buffer_id = buf_id;
         render_context->dma_nodes[0].buffer_size = buf_size;

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW,render_context->hal_devh.devh, 
            SVEN_MODULE_EVENT_AUD_IO_HAL_RENDER_BUFFER_ADD, 
            (unsigned int) render_context->dma_context, 
            (unsigned int) dma_curr_node , 
            (unsigned int) dma_next_node, 
            (unsigned int) dma_flags_active, 
            (unsigned int) render_context->dma_nodes[0].phys_addr, 
            (unsigned int) render_context->curr_node_count);
    
         result = ISMD_SUCCESS;
      }

      else{
         
         /*Record the previous node index */
         prev_index = render_context->curr_node_index;

         /* Increment our Index count to move on to the next node in the list */
         INCREMENT_INDEX(render_context->curr_node_index, render_context->max_nodes);

         new_node_phys = (unsigned int)render_context->dma_nodes[render_context->curr_node_index].phys_addr;

        /* If the current node we are trying to add is next in line, we are too late. Dont try to add it, notify underrun.*/
        if(((dma_next_node == new_node_phys) && dma_flags_active) || render_context->underrun){

            AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL,render_context->hal_devh.devh, 
               SVEN_MODULE_EVENT_AUD_IO_HAL_RENDER_BUFFER_ADD_FAILED, 
               (unsigned int) render_context->dma_context, 
               (unsigned int) dma_curr_node , 
               (unsigned int) dma_next_node, 
               (unsigned int) dma_flags_active, 
               (unsigned int) new_node_phys,  
               (unsigned int) render_context->curr_node_count);

            render_context->underrun = true;
            result = ISMD_ERROR_NO_SPACE_AVAILABLE;
            DECREMENT_INDEX(render_context->curr_node_index, render_context->max_nodes); // We didnt add the node, so pull back on the index
        }
        else{

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW,render_context->hal_devh.devh, 
            SVEN_MODULE_EVENT_AUD_IO_HAL_RENDER_BUFFER_ADD, 
            (unsigned int) render_context->dma_context, 
            (unsigned int) dma_curr_node , 
            (unsigned int) dma_next_node, 
            (unsigned int) dma_flags_active, 
            (unsigned int) new_node_phys, 
            (unsigned int) render_context->curr_node_count);

            /* First update the current node we want to add with the buffer info, and make sure its terminated */
            render_context->dma_nodes[render_context->curr_node_index].dma_descriptor.SRCDMA_START = buf_addr_phys;
            render_context->dma_nodes[render_context->curr_node_index].dma_descriptor.SRCDMA_SIZE = buf_size;
            render_context->dma_nodes[render_context->curr_node_index].dma_descriptor.FLAGS_MODE = render_context->flags_mode_stop;
            render_context->dma_nodes[render_context->curr_node_index].buffer_id = buf_id;
            render_context->dma_nodes[render_context->curr_node_index].buffer_size = buf_size;

            /* Un-terminate the previous node to link it up */
            render_context->dma_nodes[prev_index].dma_descriptor.FLAGS_MODE = render_context->flags_mode;           

            result = ISMD_SUCCESS;
        } 
      }

      /*If the node add succeeded then update count and current buffer level*/
      if(result == ISMD_SUCCESS) {
         render_context->curr_node_count++;
         render_context->dma_buffer_level += buf_size;
      }

   }
   else {
      result = ISMD_ERROR_NO_SPACE_AVAILABLE;
   }
      
   return result;
}


ismd_result_t
audio_hal_render_flush( audio_hal_render_context_t *render_context, bool drain )
{
   ismd_result_t  result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   if((result = audio_hal_dma_flush(&(render_context->hal_devh), render_context->dma_context)) != ISMD_SUCCESS){
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);
   }
      //NOT IMPLEMENTED
   //else if((result = audio_pvt_hal_tx_fifo_flush(&(render_context->hal_devh), render_context->tx_context)) != ISMD_SUCCESS){
      //VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, result);
   //}
   (void)audio_pvt_hal_tx_fifo_flush;

   error:      
      //Error handler      

   return result;
}

ismd_result_t 
audio_hal_render_start(audio_hal_render_context_t *render_context)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   unsigned int imrx_val = 0;
   unsigned int new_imrx_val = 0;
      
   AUDIO_ENTER(render_context->hal_devh.devh);


   // write first ll descriptor to DMA in LL mode!
   if(render_context->buffer_mode == AUDIO_RENDER_BUFFER_MODE_LINKED_LIST){
      WRITE_IO(render_context->hal_devh.devh, DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_DSTDMA_START,  render_context->txSATRAddr);
      WRITE_IO(render_context->hal_devh.devh, DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_NEXT_DESCR,   render_context->nodeBaseAddrPhys);       
      WRITE_IO(render_context->hal_devh.devh, DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE,   render_context->flags_mode); 
   }
   else{
      render_context->underrun = false;
   }

   switch(render_context->tx_context)
   {
         case AUDIO_TX_CONTEXT_TX0:
         case AUDIO_TX_CONTEXT_TX1: 
         case AUDIO_TX_CONTEXT_TX2:

               /* Start the TX context */
               WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR0_TX0_ENABLE, AUDIO_HAL_BIT_SET);

               /* Read IMRX then write it back */
               imrx_val = READ_IO(render_context->hal_devh.devh, BITFIELD_AUD_IO_IMRX);
               new_imrx_val = (render_context->interrupt_mask | imrx_val);

               /* Un-mask the interrupt in IMRX */
               WRITE_IO(render_context->hal_devh.devh, BITFIELD_AUD_IO_IMRX, new_imrx_val);

               render_context->start_to_close = false;
               render_context->level_node_count = render_context->curr_node_count; //Set the level we want try to maintain.

               break;
         default:
               retStatus = ISMD_ERROR_INVALID_PARAMETER;
               VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus)
   }
   
   goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
   AUDIO_EXIT(render_context->hal_devh.devh);
   return retStatus;
}

/**
This function is responsible for disabling a render device.  It 
will be used in both the stop and pause cases.

@param[in] tx_num : I2S instance to disable.

@retval ISMD_SUCCESS : Interface disabled.
*/
ismd_result_t 
audio_hal_render_stop(audio_hal_render_context_t *render_context)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      AUDIO_ENTER(render_context->hal_devh.devh);

      switch(render_context->tx_context)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1: 
            case AUDIO_TX_CONTEXT_TX2:
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR0_TX0_ENABLE, AUDIO_HAL_BIT_CLEAR);
                  render_context->underrun = true;
                  break;
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }

      /* Need to be notified to clean up remaining nodes. */
      render_context->start_to_close = true;

      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;
}

/**
This function is responsible for putting the I2S hardware back into its reset configuration.

@param[in] tx_num : I2S instance to reset.

@retval ISMD_SUCCESS : Interface reset.
*/
ismd_result_t 
audio_hal_render_reset(audio_hal_render_context_t *render_context)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      audio_dma_context_t dma;
      AUDIO_ENTER(render_context->hal_devh.devh);

      switch(render_context->tx_context)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1: 
            case AUDIO_TX_CONTEXT_TX2:
                  dma = READ_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_DMA_CONTEXT);      
                  retStatus = audio_hal_clear_dma_flags(&(render_context->hal_devh), dma);
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR0_TX0_ENABLE, AUDIO_HAL_BIT_CLEAR);
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
                  retStatus = audio_hal_clear_dma_status_register(&(render_context->hal_devh), dma);
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR0_TX0_FIFO_RESET, AUDIO_HAL_BIT_SET);
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR0_TX0_FIFO_RESET, AUDIO_HAL_BIT_CLEAR);
                  break;
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
       goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;
}


ismd_result_t 
audio_hal_render_i2s_set_clk_invert(audio_hal_render_context_t *render_context, bool invert_bit_clk)
{
      ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
      AUDIO_ENTER(render_context->hal_devh.devh);

      result = audio_hal_render_i2s_set_clk_invert_direct(render_context->hal_devh.devh, render_context->output, invert_bit_clk);

      AUDIO_EXIT(render_context->hal_devh.devh);
      return result;
}


ismd_result_t 
audio_hal_render_i2s_set_clk_invert_direct(os_devhandle_t *devh, audio_hal_output_sel_t i2s_context, bool invert_bit_clk)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      AUDIO_ENTER(devh);

      switch(i2s_context)
      {
            case AUDIO_HAL_OUT_SEL_I2S0:
               WRITE_IO(devh, BITFIELD_AUD_IO_CGR_I2S0_CLK_INV, invert_bit_clk);
               break;     
            case AUDIO_HAL_OUT_SEL_I2S1:
               WRITE_IO(devh, BITFIELD_AUD_IO_CGR_I2S1_CLK_INV, invert_bit_clk);
               break;                  
            default:
               retStatus = ISMD_ERROR_INVALID_PARAMETER; 
               VERIFY_HAL_RETSTATUS(devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(devh);
      return retStatus;
}

ismd_result_t 
audio_hal_render_i2s_set_ws_select(audio_hal_render_context_t *render_context, audio_hal_i2s_ws_select_t state)
{
      ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
      AUDIO_ENTER(render_context->hal_devh.devh);

      result = audio_hal_render_i2s_set_ws_select_direct(render_context->hal_devh.devh, render_context->output, state);

      AUDIO_EXIT(render_context->hal_devh.devh);
      return result;
}

ismd_result_t 
audio_hal_render_i2s_set_ws_select_direct(os_devhandle_t *devh, audio_hal_output_sel_t i2s_context, audio_hal_i2s_ws_select_t state)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      AUDIO_ENTER(devh);

      switch(state)
      {
            case AUDIO_HAL_I2S_WS_SELECT_FALLING:
            case AUDIO_HAL_I2S_WS_SELECT_RISING:
               break;                  
            default:
               retStatus=ISMD_ERROR_INVALID_PARAMETER;
               VERIFY_HAL_RETSTATUS(devh, retStatus);
      }

      switch(i2s_context)
      {
            case AUDIO_HAL_OUT_SEL_I2S0:
            case AUDIO_HAL_OUT_SEL_I2S1:
               WRITE_IO(devh, BITFIELD_AUD_IO_CGR_I2SC1_WS_SELECT, state);
               break;                  
            default:
               retStatus=ISMD_ERROR_INVALID_PARAMETER;
               VERIFY_HAL_RETSTATUS(devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(devh);
      return retStatus;
}

/**
This function is responsible for enabling the an I2S pin. 

@param[in] tx_num : TX instance.
@param[in] pin_num: Pin number 0-1 for I2S0 and 0-3 for I2S1
@param[in] enable : enable/disable.

@retval ISMD_SUCCESS : I2S pin set.
*/
ismd_result_t 
audio_hal_render_i2s_set_pin(audio_hal_render_context_t *render_context, audio_i2s_pin_t pin_num, bool enable)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      audio_hal_i2s_pin_en_t pin; 

      AUDIO_ENTER(render_context->hal_devh.devh);

      pin = enable ? AUDIO_HAL_I2S_PIN_ENABLE : AUDIO_HAL_I2S_PIN_DISABLE;

      switch(render_context->tx_context)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1:
            case AUDIO_TX_CONTEXT_TX2:
                  switch(pin_num)                        
                  {
                        case AUDIO_I2S_PIN0:
                              WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_I2S_PIN0, pin);
                              break;
                        case AUDIO_I2S_PIN1:
                              WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_I2S_PIN1, pin);
                              break;
                        case AUDIO_I2S_PIN2:
                              WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_I2S_PIN2, pin);
                              break;
                        case AUDIO_I2S_PIN3:
                              WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_I2S_PIN3, pin);
                              break;
                        default:
                              retStatus=ISMD_ERROR_INVALID_PARAMETER;
                              VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
                  }
                  break;
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;
}

ismd_result_t 
audio_hal_render_set_atl_mode(audio_hal_render_context_t *render_context, audio_hal_alt_mode_t state)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      AUDIO_ENTER(render_context->hal_devh.devh);

      switch(state)
      {
            case AUDIO_HAL_ALT_MODE_I2S:
            case AUDIO_HAL_ALT_MODE_MSB_JUSTIFIED:
               break;                  
            default:
               retStatus=ISMD_ERROR_INVALID_PARAMETER;
               VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }

      switch(render_context->tx_context)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1: 
            case AUDIO_TX_CONTEXT_TX2:
               WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_ALT_MODE, state);
               break;
            default:
               retStatus = ISMD_ERROR_INVALID_PARAMETER;
               VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;
}


ismd_result_t 
audio_hal_render_set_sample_size(audio_hal_render_context_t *render_context, audio_hal_sample_size_t sample_size)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      AUDIO_ENTER(render_context->hal_devh.devh);

      switch(sample_size)
      {
            case AUDIO_HAL_SAMPLE_SIZE_16BIT:
            case AUDIO_HAL_SAMPLE_SIZE_24BIT:
                  break;
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
            
      switch(render_context->tx_context)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1:
            case AUDIO_TX_CONTEXT_TX2:
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_SAMPLE_SIZE, sample_size);
                  break;
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;
}


ismd_result_t 
audio_hal_render_set_data_storage_mode(audio_hal_render_context_t *render_context, audio_hal_data_storage_mode_t dsm)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      AUDIO_ENTER(render_context->hal_devh.devh);
      
      switch(dsm)
      {
            case AUDIO_HAL_DATA_STORAGE_MODE_7_1:
            case AUDIO_HAL_DATA_STORAGE_MODE_STEREO:
            case AUDIO_HAL_DATA_STORAGE_MODE_LEFT:
            case AUDIO_HAL_DATA_STORAGE_MODE_RIGHT:
                  break;
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }

      switch(render_context->tx_context)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1:
            case AUDIO_TX_CONTEXT_TX2:
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_MODE, dsm);
                  break;

            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;
}


ismd_result_t 
audio_hal_render_set_channel_configuration(audio_hal_render_context_t *render_context, audio_hal_data_storage_mode_t channel_config)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      audio_hal_i2s_pin_en_t pin[4]={AUDIO_HAL_I2S_PIN_DISABLE,AUDIO_HAL_I2S_PIN_DISABLE,AUDIO_HAL_I2S_PIN_DISABLE,AUDIO_HAL_I2S_PIN_DISABLE};
      audio_hal_data_storage_mode_t dsm=channel_config;
      audio_hal_output_sel_t out;
      AUDIO_ENTER(render_context->hal_devh.devh);

      //SPDIF is only 2ch storage mode, even if you have 6ch encoded.
      if(render_context->output == AUDIO_HAL_OUT_SEL_SPDIF){
         dsm = AUDIO_HAL_DATA_STORAGE_MODE_STEREO;
      }

      switch(dsm)
      {
    
         case AUDIO_HAL_DATA_STORAGE_MODE_7_1:            
            pin[3] = AUDIO_HAL_I2S_PIN_ENABLE;
            pin[2] = AUDIO_HAL_I2S_PIN_ENABLE;
            pin[1] = AUDIO_HAL_I2S_PIN_ENABLE;       
            pin[0] = AUDIO_HAL_I2S_PIN_ENABLE;
            break;

         case AUDIO_HAL_DATA_STORAGE_MODE_STEREO:
            pin[0] = AUDIO_HAL_I2S_PIN_ENABLE;
            break;

         case AUDIO_HAL_DATA_STORAGE_MODE_RIGHT:
            pin[0]  = AUDIO_HAL_I2S_PIN_RIGHT_ENABLE;
            break;

         case AUDIO_HAL_DATA_STORAGE_MODE_LEFT: 
            pin[0] = AUDIO_HAL_I2S_PIN_LEFT_ENABLE;
            break;

         default:
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }

      switch(render_context->tx_context)
      {
         case AUDIO_TX_CONTEXT_TX0:
         case AUDIO_TX_CONTEXT_TX1:
         case AUDIO_TX_CONTEXT_TX2:
            if(AUDIO_HAL_DATA_STORAGE_MODE_7_1 == dsm)
            {
                  out = READ_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR0_TX0_OUTPUT_SEL);
                  if(AUDIO_HAL_OUT_SEL_I2S1 != out)
                  {
                     retStatus = ISMD_ERROR_INVALID_REQUEST;
                     VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
                  }
            }
            retStatus = WRITE_IO_VA
            (
                  render_context->hal_devh,
                  TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_I2S_PIN3,    pin[3],
                  TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_I2S_PIN2,    pin[2],
                  TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_I2S_PIN1,    pin[1],
                  TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_I2S_PIN0,    pin[0],
                  TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_MODE,        dsm,
                  TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_ALT_MODE,    AUDIO_HAL_ALT_MODE_I2S,
                  BITFIELD_NULL_TERM()      
            );
            VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
            break;
         default:
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;
}


extern ismd_result_t audio_hal_render_set_bit_clock_divider(audio_hal_render_context_t *render_context, int32_t desired_bit_clock_divider)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      AUDIO_ENTER(render_context->hal_devh.devh);

      switch(render_context->tx_context)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1:
            case AUDIO_TX_CONTEXT_TX2:
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SADIV_TX0_AUD_CLK_DIV, desired_bit_clock_divider);
                  break;
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;
}


ismd_result_t 
audio_hal_render_spdif_set_validity_bit(audio_hal_render_context_t *render_context, bool is_valid)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   audio_hal_bit_set_t bs;
   bool tx_enabled = false;

   /*Ensure the Tx is not enabled. */
   tx_enabled = (bool)READ_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR0_TX0_ENABLE);
   if(!tx_enabled) {
   
      AUDIO_ENTER(render_context->hal_devh.devh);
      bs = is_valid ? AUDIO_HAL_BIT_SET : AUDIO_HAL_BIT_CLEAR;

      switch(render_context->tx_context)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1: 
            case AUDIO_TX_CONTEXT_TX2:

               //Normally you need to disable the Tx context before writing the validity bit register or the change wont happen. However 
               //we are no longer going to change the validity bit when the TX context is running as this was causing some 
               //issues for some recievers. 
               WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_SPDIF_VALIDITY, bs);

                  break;
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
   }
   else {
      retStatus = ISMD_ERROR_INVALID_REQUEST;
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
   }

   goto end;
   error:      
   //Error handler      

   end:
   //Clean up and exit code

   AUDIO_EXIT(render_context->hal_devh.devh);
   return retStatus;
}


ismd_result_t 
audio_hal_render_spdif_set_user_data(audio_hal_render_context_t *render_context, uint8_t *data, unsigned int size)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      int32_t val;
      unsigned int  regOffset, byteOffset;
      AUDIO_ENTER(render_context->hal_devh.devh);
      
      if(NULL == data || USER_DATA_MAX_SIZE < size)
      {
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }

      switch(render_context->tx_context)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1: 
            case AUDIO_TX_CONTEXT_TX2:
                  for(regOffset=0; regOffset < USER_DATA_MAX_SIZE; regOffset+=4)
                  {
                        for(val=byteOffset=0; byteOffset < 4; ++byteOffset)
                        {
                              val += (regOffset+byteOffset<size) ? (data[regOffset+byteOffset]<<BYTE_SHIFT(byteOffset)) : AUDIO_HAL_BIT_CLEAR;
                        }
                        WRITE_IO(render_context->hal_devh.devh, regOffset + TX_OFFSET(render_context->tx_context) + BITFIELD_AUD_IO_TX0SASUD0, val);                        
                  }                  
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SASUDC_TX0_LOAD_SASUD_TO_SPDIF, AUDIO_HAL_BIT_SET);
                  break;                  
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;
}

ismd_result_t 
audio_hal_render_spdif_set_channel_status(audio_hal_render_context_t *render_context, uint32_t lsw, uint8_t msb)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      AUDIO_ENTER(render_context->hal_devh.devh);

      switch(render_context->tx_context)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1:
            case AUDIO_TX_CONTEXT_TX2:
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SASCS0, lsw);
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SASCS1, msb);
                  WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SASCSC_TX0_LOAD_CNTL_STAT_REG, AUDIO_HAL_BIT_SET);
                  break;
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;

}


void
audio_hal_render_handle_interrupt(unsigned int isrx_value)
{
   unsigned int isrx = 0;
   audio_hal_render_context_t *render_context;

   /*DMA0 Source Interrupt*/
   if(isrx_value & DMA0_SOURCE_INTERRUPT_PENDING) {

      render_context = hal_render_contexts[AUDIO_DMA_CONTEXT0]; 

      /*Clear the interrupt, read back to ensure transaction.*/
      WRITE_IO(render_context->hal_devh.devh, BITFIELD_AUD_IO_ISRX, DMA0_SOURCE_INTERRUPT_PENDING);
      isrx = READ_IO(render_context->hal_devh.devh, BITFIELD_AUD_IO_ISRX);

      if(render_context->buffer_mode == AUDIO_RENDER_BUFFER_MODE_LINKED_LIST ){

         if(render_context->in_use){
            audio_pvt_hal_render_linked_list_handle_interrupt( render_context );
         }
         
      }
      else{

         (*(render_context->buffer_callback_func)) (render_context->user_context,  0, AUDIO_RENDER_BUFFER_EMPTY); 
         render_context->underrun = true;
         
      }

   }

   /*DMA1 Source Interrupt*/
   if(isrx_value & DMA1_SOURCE_INTERRUPT_PENDING) {

      render_context = hal_render_contexts[AUDIO_DMA_CONTEXT1]; 

      /*Clear the interrupt, read back to ensure transaction.*/
      WRITE_IO(render_context->hal_devh.devh, BITFIELD_AUD_IO_ISRX, DMA1_SOURCE_INTERRUPT_PENDING);
      isrx = READ_IO(render_context->hal_devh.devh, BITFIELD_AUD_IO_ISRX);

      if(render_context->buffer_mode == AUDIO_RENDER_BUFFER_MODE_LINKED_LIST){

         if(render_context->in_use){
            audio_pvt_hal_render_linked_list_handle_interrupt( render_context );
         }
         
      }
      else{

         (*(render_context->buffer_callback_func)) (render_context->user_context,  0, AUDIO_RENDER_BUFFER_EMPTY); 
         render_context->underrun = true;
         
      }
      
   }

   /*DMA2 Source Interrupt*/
   if(isrx_value & DMA2_SOURCE_INTERRUPT_PENDING) {
      
      render_context = hal_render_contexts[AUDIO_DMA_CONTEXT2]; 

      /*Clear the interrupt, read back to ensure transaction.*/
      WRITE_IO(render_context->hal_devh.devh, BITFIELD_AUD_IO_ISRX, DMA2_SOURCE_INTERRUPT_PENDING);
      isrx = READ_IO(render_context->hal_devh.devh, BITFIELD_AUD_IO_ISRX);  

      if(render_context->buffer_mode == AUDIO_RENDER_BUFFER_MODE_LINKED_LIST){

         if(render_context->in_use){
            audio_pvt_hal_render_linked_list_handle_interrupt( render_context );
         }
         
      }
      else{

         (*(render_context->buffer_callback_func)) (render_context->user_context,  0, AUDIO_RENDER_BUFFER_EMPTY); 
         render_context->underrun = true;
         
      }
      
   }

   return;
}

ismd_result_t 
audio_hal_render_reset_tx_channels(audio_hal_dev_t *hal_devh)
{
   ismd_result_t retStatus;

   if((retStatus = audio_pvt_hal_tx_reset(hal_devh, AUDIO_TX_CONTEXT_TX0)) != ISMD_SUCCESS){
      DEVH_FATAL_ERROR(hal_devh->devh, "hal_tx_reset failed!\n");
   }
   else if((retStatus = audio_pvt_hal_tx_reset(hal_devh, AUDIO_TX_CONTEXT_TX1)) != ISMD_SUCCESS){
      DEVH_FATAL_ERROR(hal_devh->devh, "hal_tx_reset failed!\n");;
   }
   else if((retStatus = audio_pvt_hal_tx_reset(hal_devh, AUDIO_TX_CONTEXT_TX2)) != ISMD_SUCCESS){
      DEVH_FATAL_ERROR(hal_devh->devh, "hal_tx_reset failed!\n");
   }

   return retStatus;
}

ismd_result_t
audio_hal_render_set_power_mode (os_devhandle_t *devh, audio_hal_power_management_mode_t power_mode)
{
   ismd_result_t result = ISMD_SUCCESS;
   AUDIO_ENTER(devh);
   switch(power_mode) 
   {
      case AUDIO_HAL_PM_GATE:
         WRITE_IO(devh, BITFIELD_AUD_IO_CGR_TX2_CLK_EN, AUDIO_HAL_BIT_SET);
         WRITE_IO(devh, BITFIELD_AUD_IO_CGR_TX1_CLK_EN, AUDIO_HAL_BIT_SET);
         WRITE_IO(devh, BITFIELD_AUD_IO_CGR_TX0_CLK_EN, AUDIO_HAL_BIT_SET);
         break;
      case AUDIO_HAL_PM_POWER_ON:
         WRITE_IO(devh, BITFIELD_AUD_IO_CGR_TX2_CLK_EN, AUDIO_HAL_BIT_CLEAR);
         WRITE_IO(devh, BITFIELD_AUD_IO_CGR_TX1_CLK_EN, AUDIO_HAL_BIT_CLEAR);
         WRITE_IO(devh, BITFIELD_AUD_IO_CGR_TX0_CLK_EN, AUDIO_HAL_BIT_CLEAR);
         break;
      case AUDIO_HAL_PM_POWER_DOWN:
      default:
         break;  
   }
      
   AUDIO_EXIT(devh);
   return result;
}

/*********************************************************************************************/

/* Audio Render HAL Private Functions */

static void
audio_pvt_hal_render_linked_list_handle_interrupt(audio_hal_render_context_t *render_context)
{
   int32_t dma_flags_active = 0;
   int32_t dma_curr_node = 0;
   int32_t buffer_id = ISMD_BUFFER_HANDLE_INVALID;
   int32_t free_loop = 0;
   int32_t free_node_count = 0;
   ismd_result_t result = ISMD_SUCCESS;

   dma_curr_node = READ_IO(render_context->hal_devh.devh, DMA_OFFSET(render_context->dma_context) + BITFIELD_AUD_IO_DMA0_CURR_DESCR); 
   dma_flags_active = READ_IO(render_context->hal_devh.devh, DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_ACTIVE_DMA);
   
   AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, render_context->hal_devh.devh, 
      SVEN_MODULE_EVENT_AUD_IO_HAL_RENDER_LL_INTERUPT, 
      (unsigned int) render_context->dma_context, 
      (unsigned int) dma_curr_node , 
      (unsigned int) dma_flags_active, 
      (unsigned int) render_context->curr_node_count, 
      (unsigned int) render_context->level_node_count, 0);

   /* Check to see how far the DMA had advanced since the last interrupt and free those nodes. */
   free_node_count = audio_pvt_hal_render_linked_list_get_free_node_count(render_context, dma_curr_node );

   for(free_loop = free_node_count; free_loop > 0; free_loop--){
      audio_pvt_hal_render_linked_list_free_node(render_context);
   }

   /* Special case where the DMA is not active, free all remaining nodes (probably always 1), then signal the underrun.*/
   if(!dma_flags_active && (render_context->curr_node_count > 0)) {

      for(free_loop = render_context->curr_node_count; free_loop > 0; free_loop--) {  
         audio_pvt_hal_render_linked_list_free_node(render_context);
      }
   }

   /* If we have no nodes we are empty and need to perform an empty callback, else request more data! */
   if(render_context->curr_node_count == 0){
      
      render_context->first_node_added = false;
      render_context->curr_node_index = 0;

      /* If we are NOT closing just signal an underrun, if we are closing signal for the safe to close. */
      if(!render_context->start_to_close){
         (*(render_context->buffer_callback_func)) (render_context->user_context,  buffer_id, AUDIO_RENDER_BUFFER_EMPTY); 
      }
      else {
         (*(render_context->buffer_callback_func)) (render_context->user_context,  render_context->curr_node_count, AUDIO_RENDER_SAFE_TO_CLOSE);
      }
   }
   else{

      //This gets set in start DMA, make sure its never zero or we will stall.
      if(render_context->level_node_count > 0) {

         //This should keep us level if we missed an interrupt or so. 
         while((!render_context->start_to_close) && (result == ISMD_SUCCESS) && (render_context->level_node_count != render_context->curr_node_count)){
            result = ((*(render_context->buffer_callback_func)) (render_context->user_context,  buffer_id, AUDIO_RENDER_BUFFER_REQUEST_DATA)); 
         }
      }
   }

   return;
}

static void
audio_pvt_hal_render_linked_list_free_node(audio_hal_render_context_t *render_context)
{

   /* Call the callback function to de-ref the buffer */
   (*(render_context->buffer_callback_func)) 
     (render_context->user_context,  
      render_context->dma_nodes[render_context->curr_dma_node_index].buffer_id,
      AUDIO_RENDER_INPUT_BUFFER_DONE); 

   /*Decrement the DMA buffer level*/
   render_context->dma_buffer_level -= render_context->dma_nodes[render_context->curr_dma_node_index].buffer_size;

   /* Decrement the count, and advance the current dma index */
   render_context->curr_node_count--;
   INCREMENT_INDEX(render_context->curr_dma_node_index, render_context->max_nodes);

   return;

}

static void
audio_pvt_hal_render_linked_list_shutdown_cleanup(audio_hal_render_context_t *render_context)
{

   while(render_context->curr_node_count) {

      AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW,render_context->hal_devh.devh, 
         SVEN_MODULE_EVENT_AUD_IO_HAL_RENDER_NODE_CLEAN_UP, 
         (unsigned int) render_context->dma_context, 
         (unsigned int) render_context->dma_nodes[render_context->curr_dma_node_index].buffer_id , 
         (unsigned int) render_context->curr_node_count, 0, 0, 0);

      audio_pvt_hal_render_linked_list_free_node(render_context);
   }

   /* Tell the driver we are done cleaning up the nodes. */
   (*(render_context->buffer_callback_func)) (render_context->user_context,  render_context->curr_node_count, AUDIO_RENDER_SAFE_TO_CLOSE);

   return;
}

static int
audio_pvt_hal_render_linked_list_get_free_node_count(audio_hal_render_context_t *render_context, int dma_curr_node)
{
   int32_t first_count = 0;
   int32_t second_count = 0;
   int32_t my_curr_node = render_context->dma_nodes[render_context->curr_dma_node_index].phys_addr;
   int32_t free_node_count = 0;
   
   //Handle index wrap case.
   if(dma_curr_node < my_curr_node){

     first_count = (dma_curr_node - render_context->nodeBaseAddrPhys) /SIZE_OF_DMA_LINKED_LIST_NODE;

     second_count = ((render_context->last_node_phys_addr - my_curr_node) / SIZE_OF_DMA_LINKED_LIST_NODE) + 1;

     free_node_count = (first_count + second_count);
   }

   //Normal case
   else{
      free_node_count = (dma_curr_node - my_curr_node) / SIZE_OF_DMA_LINKED_LIST_NODE;
   }

   return free_node_count;
}


static ismd_result_t
audio_pvt_hal_render_linked_list_dma_setup
(
      audio_hal_render_context_t *render_context,
      unsigned int nodeCount,
      int32_t nodeBaseAddrPhys,
      int32_t nodeBaseAddrVirt,
      size_t nodeMemSize
)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      int32_t txSATRAddr;
      int32_t aud_io_phys_base_addr;
      int32_t flags_mode, flags_mode_stop;
      unsigned int i;
      
      AUDIO_ENTER(render_context->hal_devh.devh);
      
      retStatus = (nodeBaseAddrPhys==0?ISMD_ERROR_INVALID_HANDLE:ISMD_SUCCESS);
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      retStatus = (nodeBaseAddrVirt==0?ISMD_ERROR_INVALID_HANDLE:ISMD_SUCCESS);
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);

      switch(render_context->dma_context)
      {
         case AUDIO_DMA_CONTEXT0:
         case AUDIO_DMA_CONTEXT1:
         case AUDIO_DMA_CONTEXT2:
         case AUDIO_DMA_CONTEXT3:
            break;                              
         default:
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }

      aud_io_phys_base_addr = render_context->hal_devh.devh->devh_regs_phys_addr;
      switch(render_context->tx_context)
      {
         case AUDIO_TX_CONTEXT_TX0:
         case AUDIO_TX_CONTEXT_TX1: 
         case AUDIO_TX_CONTEXT_TX2:
            txSATRAddr = aud_io_phys_base_addr + TX_OFFSET(render_context->tx_context) + ROFF_AUD_IO_TX0SATR;
            WRITE_IO(render_context->hal_devh.devh, TX_OFFSET(render_context->tx_context)+BITFIELD_AUD_IO_TX0SACR1_TX0_DMA_CONTEXT, render_context->dma_context);
            break;
         default:
            txSATRAddr = 0;
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);
      }

      //set up start & stop flags 
      flags_mode=AUDIO_HAL_REG_CLEAR;

      retStatus = audio_hal_create_reg_vsymbol
      (
         &(render_context->hal_devh),
         &flags_mode,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_TERM,          AUDIO_HAL_BIT_CLEAR,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_INT,       AUDIO_HAL_BIT_SET,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_INT,       AUDIO_HAL_BIT_CLEAR,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_ADDR_MODE, AUDIO_HAL_DMA_ADDR_MODE_LINEAR,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_ADDR_MODE, AUDIO_HAL_DMA_ADDR_MODE_FIXED_CONTINOUS,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_LINK_LIST, AUDIO_HAL_BIT_SET,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_READ_EN,       AUDIO_HAL_BIT_SET,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_BURST_SZ,      AUDIO_HAL_DMA_BURST_SIZE_256,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_XBURST_SZ,     AUDIO_HAL_DMA_XBURST_SIZE_256,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_XDMA_GAP,      AUDIO_HAL_XDMA_GAP_SIZE_0000,
         BITFIELD_NULL_TERM()   
      );    
      
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);

      flags_mode_stop=AUDIO_HAL_REG_CLEAR;
      retStatus = audio_hal_create_reg_vsymbol
      (
         &(render_context->hal_devh),
         &flags_mode_stop,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_TERM,          AUDIO_HAL_BIT_SET,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_INT,       AUDIO_HAL_BIT_SET,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_INT,       AUDIO_HAL_BIT_CLEAR,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_ADDR_MODE, AUDIO_HAL_DMA_ADDR_MODE_LINEAR,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_ADDR_MODE, AUDIO_HAL_DMA_ADDR_MODE_FIXED_CONTINOUS,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_LINK_LIST, AUDIO_HAL_BIT_SET,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_READ_EN,       AUDIO_HAL_BIT_SET,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_BURST_SZ,      AUDIO_HAL_DMA_BURST_SIZE_256,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_XBURST_SZ,     AUDIO_HAL_DMA_XBURST_SIZE_256,
         DMA_OFFSET(render_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_XDMA_GAP,      AUDIO_HAL_XDMA_GAP_SIZE_0000,
         BITFIELD_NULL_TERM()   
      );
      VERIFY_HAL_RETSTATUS(render_context->hal_devh.devh, retStatus);

      /* We need all these variables later */
      render_context->max_nodes = nodeCount;
      render_context->flags_mode_stop = flags_mode_stop;
      render_context->flags_mode = flags_mode;
      render_context->txSATRAddr = txSATRAddr;
      render_context->nodeBaseAddrPhys = nodeBaseAddrPhys;

      /* Assign pointer to nodes location */
      render_context->dma_nodes = ((audio_hal_linked_list_node_t *)nodeBaseAddrVirt);

      for(i=0; i < nodeCount; i++)
      {
         //Last node case
         if(i == (nodeCount-1)){
            render_context->dma_nodes[i].dma_descriptor.NEXT_DESC    = nodeBaseAddrPhys;
            render_context->dma_nodes[i].dma_descriptor.FLAGS_MODE   = flags_mode_stop;
            render_context->dma_nodes[i].dma_descriptor.DSTDMA_START = txSATRAddr;
            render_context->dma_nodes[i].dma_descriptor.SRCDMA_START = 0;
            render_context->dma_nodes[i].dma_descriptor.SRCDMA_SIZE  = 0;
            render_context->last_node_phys_addr = nodeBaseAddrPhys + (SIZE_OF_DMA_LINKED_LIST_NODE * (i));
         }
         else {
            render_context->dma_nodes[i].dma_descriptor.NEXT_DESC = nodeBaseAddrPhys + (SIZE_OF_DMA_LINKED_LIST_NODE * (i+1));
            render_context->dma_nodes[i].dma_descriptor.FLAGS_MODE   = flags_mode_stop;
            render_context->dma_nodes[i].dma_descriptor.DSTDMA_START = txSATRAddr;
            render_context->dma_nodes[i].dma_descriptor.SRCDMA_START = 0;
            render_context->dma_nodes[i].dma_descriptor.SRCDMA_SIZE  = 0;
         }

         
         /* Keep track of physical addresses also */
         render_context->dma_nodes[i].phys_addr = nodeBaseAddrPhys + (SIZE_OF_DMA_LINKED_LIST_NODE * (i));

         //OS_PRINT("cnt:%d, phys: 0x%x \n", i, render_context->dma_nodes[i].phys_addr);
      }

      //Please leave this commented code out here for possible debug later.
    /*  for(i=0; i < nodeCount; i++)
      {
         OS_INFO("node %d: Next_Desc: 0x%x -  Own Add: 0x%x\n", i, render_context->dma_nodes[i].dma_descriptor.NEXT_DESC, render_context->dma_nodes[i].phys_addr);
      }*/
      

      goto end;
error:      
      //Error handler
end:
      //Clean up and exit code
      
      AUDIO_EXIT(render_context->hal_devh.devh);
      return retStatus;
}

static void
audio_pvt_hal_init_render_context_variables(audio_hal_render_context_t *render_context)
{
   render_context->user_context = NULL;
   render_context->in_use = false;
   render_context->start_to_close = false;
   render_context->hal_devh.devh = NULL;
   render_context->buffer_mode = AUDIO_RENDER_BUFFER_MODE_LINKED_LIST;
   render_context->dma_context = AUDIO_DMA_CONTEXT_COUNT;
   render_context->tx_context = AUDIO_TX_CONTEXT_COUNT;
   render_context->output = AUDIO_HAL_OUT_SEL_NOT_USED;
   render_context->curr_node_index = 0;
   render_context->curr_dma_node_index = 0;
   render_context->curr_node_count = 0;
   render_context->level_node_count = 0;
   render_context->max_nodes = 0;
   render_context->first_node_added = false;
   render_context->underrun = false;
   render_context->dma_nodes = NULL;
   render_context->flags_mode = 0; 
   render_context->flags_mode_stop = 0;
   render_context->txSATRAddr = 0;
   render_context->nodeBaseAddrPhys = 0;
   render_context->interrupt_mask = 0;
   render_context->dma_buffer_size = 0;
   render_context->max_dma_buffer_size = 0;
   render_context->dma_buffer_level = 0;
   render_context->high_watermark= 0;
   render_context->low_watermark = 0;

   return;
}


static ismd_result_t 
audio_pvt_hal_set_output_interface(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num, audio_hal_output_sel_t out_mode)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      AUDIO_ENTER(hal_devh->devh);

      switch(out_mode)
      {
            case AUDIO_HAL_OUT_SEL_I2S0:
            case AUDIO_HAL_OUT_SEL_I2S1:
            case AUDIO_HAL_OUT_SEL_SPDIF:
               break;                  
            default:
               retStatus = ISMD_ERROR_INVALID_PARAMETER;
               VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
      }

      switch(tx_num)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1: 
            case AUDIO_TX_CONTEXT_TX2:
               WRITE_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SACR0_TX0_OUTPUT_SEL, out_mode);
               break;
            default:
               retStatus = ISMD_ERROR_INVALID_PARAMETER;
               VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
      }
      
      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(hal_devh->devh);
      return retStatus;
}

static ismd_result_t audio_pvt_hal_tx_reset(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num)
{
    ismd_result_t retStatus=ISMD_SUCCESS;
    AUDIO_ENTER(hal_devh->devh);

   switch(tx_num)
   {
      case AUDIO_TX_CONTEXT_TX0:
      case AUDIO_TX_CONTEXT_TX1: 
      case AUDIO_TX_CONTEXT_TX2:
         WRITE_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SACR1,                             AUDIO_HAL_REG_CLEAR);
         WRITE_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SACR0_TX0_FIFO_RESET,              AUDIO_HAL_BIT_SET);
         WRITE_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SACR0_TX0_FIFO_RESET,              AUDIO_HAL_BIT_CLEAR);
         WRITE_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SAISR_TX0_SPDIF_BLK_COMPLETE_INT,  AUDIO_HAL_BIT_CLEAR);
         WRITE_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SAISR_TX0_CLEAR_FIFO_UNDERRUN_INT, AUDIO_HAL_BIT_CLEAR);
         break;
            
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }

   goto end;
error:
    //Error handler

end:
    //Clean up and exit code

    AUDIO_EXIT(hal_devh->devh);
    return retStatus;
}


/*static ismd_result_t audio_pvt_hal_tx_dma_poll_complete(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num, uint32_t timeout)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   audio_dma_context_t dma;
   int32_t fifo;
   AUDIO_ENTER(hal_devh->devh);
 
   switch(tx_num)
   {
      case AUDIO_TX_CONTEXT_TX0:
      case AUDIO_TX_CONTEXT_TX1: 
      case AUDIO_TX_CONTEXT_TX2:
         dma = READ_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SACR1_TX0_DMA_CONTEXT);
         retStatus = audio_hal_poll_dma_complete(hal_devh, dma, timeout);
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
         break;
            
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }

   retStatus = ISMD_SUCCESS;
   fifo = READ_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SAFL_TX0_FIFO_LEVEL);
   while(fifo)
   {
      os_sleep(1);     
      ++retStatus;
      if(retStatus>timeout) 
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus)
      fifo = READ_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SAFL_TX0_FIFO_LEVEL);
   }
   retStatus = ISMD_SUCCESS;

   goto end;
error:
   //Error handler

end:
   AUDIO_EXIT(hal_devh->devh);
   return retStatus;
}*/


static ismd_result_t 
audio_pvt_hal_dma_set_circ_buf
(
      audio_hal_dev_t *hal_devh, 
      audio_tx_context_t tx_num, 
      audio_dma_context_t dma,
      int32_t dmaBaseAddr,
      int32_t dmaSize
)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      int32_t dmaTopAddr;
      int32_t txSATRAddr;
      int32_t aud_io_phys_base_addr;
      AUDIO_ENTER(hal_devh->devh);
                              

      aud_io_phys_base_addr = hal_devh->devh->devh_regs_phys_addr;
      switch(tx_num)
      {
            case AUDIO_TX_CONTEXT_TX0:
            case AUDIO_TX_CONTEXT_TX1: 
            case AUDIO_TX_CONTEXT_TX2:
                  txSATRAddr = aud_io_phys_base_addr + TX_OFFSET(tx_num) + ROFF_AUD_IO_TX0SATR;
                  WRITE_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SACR1_TX0_DMA_CONTEXT, dma);
                  break;
            default:
                  txSATRAddr = 0;
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
      }
  
      dmaTopAddr = dmaBaseAddr + dmaSize;     

      switch(dma)
      {// Set empty circular buf
            case AUDIO_DMA_CONTEXT0:
            case AUDIO_DMA_CONTEXT1:
            case AUDIO_DMA_CONTEXT2:
            case AUDIO_DMA_CONTEXT3:
                  //DMA Empty buffer start=stop
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE,     AUDIO_HAL_REG_CLEAR);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_SRCDMA_START,   dmaBaseAddr);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_SRCDMA_BOT,     dmaBaseAddr);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_SRCDMA_TOP,     dmaTopAddr);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_SRCDMA_STOP,    dmaBaseAddr);
                  //Tx fixed continous transfer mode 
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_DSTDMA_START,   txSATRAddr);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_DSTDMA_STOP,    txSATRAddr);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_DSTDMA_BOT,     txSATRAddr);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_DSTDMA_TOP,     txSATRAddr);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_DSTDMA_SIZE,    dmaSize);
                  retStatus = WRITE_IO_VA
                  (
                     *hal_devh,
                     DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_INT,         AUDIO_HAL_BIT_SET,
                     DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_INT,         AUDIO_HAL_BIT_SET,
                     DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_READ_EN,         AUDIO_HAL_BIT_SET,
                     DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_LINK_LIST,   AUDIO_HAL_BIT_CLEAR,
                     DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_ADDR_MODE,   AUDIO_HAL_DMA_ADDR_MODE_CIRCULAR,
                     DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_ADDR_MODE,   AUDIO_HAL_DMA_ADDR_MODE_FIXED_CONTINOUS,
                     DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_BURST_SZ,        AUDIO_HAL_DMA_BURST_SIZE_004,
                     DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_XBURST_SZ,       AUDIO_HAL_DMA_XBURST_SIZE_004,
                     DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_XDMA_GAP,        AUDIO_HAL_XDMA_GAP_SIZE_0000,
                     BITFIELD_NULL_TERM()
                  );
                  VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);

                  break;                              
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
      }

      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(hal_devh->devh);
      return retStatus;
}


static ismd_result_t
audio_pvt_hal_dma_get_pointers(audio_hal_dev_t *hal_devh, audio_dma_context_t dma, uint32_t *srcdma_start, uint32_t *srcdma_stop)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      int32_t aud_io_phys_base_addr = hal_devh->devh->devh_regs_phys_addr;
      AUDIO_ENTER(hal_devh->devh);

      if
      (
         NULL == srcdma_start || 
         NULL == srcdma_stop
      )
      {  //NULL pointer
         retStatus = ISMD_ERROR_NULL_POINTER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
      }

      switch(dma)
      {// Set empty circular buf
            case AUDIO_DMA_CONTEXT0:
            case AUDIO_DMA_CONTEXT1:
            case AUDIO_DMA_CONTEXT2:
            case AUDIO_DMA_CONTEXT3:
                  *srcdma_start = (uint32_t)(aud_io_phys_base_addr + DMA_OFFSET(dma) + ROFF_AUD_IO_DMA0_SRCDMA_START);
                  *srcdma_stop  = (uint32_t)(aud_io_phys_base_addr + DMA_OFFSET(dma) + ROFF_AUD_IO_DMA0_SRCDMA_STOP);
                   break;                              
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
      }

      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(hal_devh->devh);
      return retStatus;
}


/*static ismd_result_t  audio_pvt_hal_tx_fifo_wait_for_thrsh_level(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num, int timeout_ms)   
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   int32_t txsafl;
   int32_t txsafth;
   bool timeout_enabled = timeout_ms?true:false;

   AUDIO_ENTER(hal_devh->devh);

   switch(tx_num)
   {
      case AUDIO_TX_CONTEXT_TX0:      
      case AUDIO_TX_CONTEXT_TX1:      
      case AUDIO_TX_CONTEXT_TX2:      
         txsafth = READ_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SAFTH);
         txsafl  = READ_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SAFL);
         while(txsafl < txsafth)
         {
            if(!timeout_ms-- && timeout_enabled){
               retStatus = ISMD_ERROR_TIMEOUT;
               VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
            }
            OS_SLEEP_1_mS();
            txsafl = READ_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SAFL); 
         }
         break;         
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }
   
   goto end;
error:   
   //Error handler   

end:
   //Clean up and exit code
   
   AUDIO_EXIT(hal_devh->devh);
   return retStatus;
}*/

static ismd_result_t  audio_pvt_hal_tx_fifo_set_thrsh_level(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num, int level)   
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   AUDIO_ENTER(hal_devh->devh);
 
   switch(tx_num)
   {
      case AUDIO_TX_CONTEXT_TX0:      
      case AUDIO_TX_CONTEXT_TX1:      
      case AUDIO_TX_CONTEXT_TX2:      
         WRITE_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SAFTH_TX0_LOWER_FIFO_THRSH, level); 
         break;         
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }
   
   goto end;
error:   
   //Error handler   

end:
   //Clean up and exit code
   
   AUDIO_EXIT(hal_devh->devh);
   return retStatus;
}

/*static int  audio_pvt_hal_tx_fifo_get_level(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num)   
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   int level=-1;
   AUDIO_ENTER(hal_devh->devh);
 
   switch(tx_num)
   {
      case AUDIO_TX_CONTEXT_TX0:      
      case AUDIO_TX_CONTEXT_TX1:      
      case AUDIO_TX_CONTEXT_TX2:      
         level=READ_IO(hal_devh->devh, TX_OFFSET(tx_num)+BITFIELD_AUD_IO_TX0SAFL_TX0_FIFO_LEVEL); 
         break;         
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         DEVH_INVALID_PARAM(hal_devh->devh);
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }
   
   goto end;
error:   
   //Error handler   

end:
   //Clean up and exit code
   
   AUDIO_EXIT(hal_devh->devh);
   return level;
}*/

static ismd_result_t 
audio_pvt_hal_tx_fifo_flush(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num)
{
      ismd_result_t retStatus=ISMD_ERROR_FEATURE_NOT_SUPPORTED;

      return retStatus;
}

/*********************************************************************************************/

/********** Render circular buffer management functions *********/

static ismd_result_t audio_pvt_hal_render_circ_buf_init(audio_render_buffer_producer_t *wl,
audio_render_circbuf_t *buf)
{
   if (wl == NULL) {
      OS_INFO("audio_pvt_render_prod_buffer_init: invalid handle\n");
      return ISMD_ERROR_INVALID_HANDLE;
   }

   if (buf == NULL) {
      OS_INFO("audio_pvt_render_prod_buffer_init: null buf pointer\n");
      return ISMD_ERROR_NULL_POINTER;
   }

   if (wl->connected) {
      OS_INFO("audio_pvt_render_prod_buffer_init: already connected\n");
   }

   wl->connected = true;

   wl->sw_read_ptr = OS_MAP_IO_TO_MEM_NOCACHE(buf->read_reg_addr, 4);
   wl->shadow_write_ptr = OS_MAP_IO_TO_MEM_NOCACHE(buf->write_reg_addr, 4);
   wl->buf_ptr = OS_MAP_IO_TO_MEM_NOCACHE(buf->base, buf->size);

   //TODO: is the read reg initialized in the consumer?
   *(wl->sw_read_ptr) = buf->saved_read_ptr_val;
   wl->local_write_ptr = buf->saved_write_ptr_val;
   *(wl->shadow_write_ptr) = buf->saved_write_ptr_val;

   return ISMD_SUCCESS;
}

static ismd_result_t audio_pvt_hal_render_circ_buf_deinit(audio_render_buffer_producer_t *wl,
  audio_render_circbuf_t *buf)
{
   if (wl == NULL) {
      OS_INFO("audio_pvt_render_prod_buffer_disconnect: invalid handle\n");
      return ISMD_ERROR_INVALID_HANDLE;
   }

   if (buf == NULL) {
      OS_INFO("audio_pvt_render_prod_buffer_disconnect: null buf pointer\n");
      return ISMD_ERROR_NULL_POINTER;
   }

   if (! wl->connected) {
      OS_INFO("audio_pvt_render_prod_buffer_disconnect: not connected\n");
      return ISMD_ERROR_INVALID_REQUEST;
   }

   //save write pointer value for reconnections
   buf->saved_write_ptr_val = wl->local_write_ptr;

   wl->connected = false;

   OS_UNMAP_IO_FROM_MEM(wl->sw_read_ptr, 4);
   OS_UNMAP_IO_FROM_MEM(wl->shadow_write_ptr, 4);
   OS_UNMAP_IO_FROM_MEM(wl->buf_ptr, buf->size);

   return ISMD_SUCCESS;
}

static ismd_result_t audio_pvt_hal_render_circ_buf_write(audio_render_buffer_producer_t *wl, char *data,
   audio_render_circbuf_t  *buf, unsigned int count)
{
   ismd_result_t ret_val;
   unsigned int space_avail = 0;
   unsigned int amt_written = 0;
   unsigned int temp_offset = 0;
   unsigned int temp_size_avail = 0;

   if (wl == NULL) {
      OS_INFO("audio_pvt_render_buffer_write: invalid handle\n");
      return ISMD_ERROR_INVALID_HANDLE;
   }

   if (buf == NULL || data == NULL) {
      OS_INFO("audio_pvt_render_buffer_write: null pointer\n");
      return ISMD_ERROR_NULL_POINTER;
   }

   if (count == 0) {
      OS_INFO("audio_pvt_render_buffer_write: write of size 0 not allowed\n");
   }

   ret_val = audio_pvt_hal_render_circ_buf_get_write_cnt(wl, buf, &space_avail);
   if (ret_val != ISMD_SUCCESS) {
      OS_INFO("audio_pvt_render_buffer_write: get_write_cnt failed\n");
      return ret_val;
   }

   if (count > space_avail+1) {
      OS_INFO("audio_pvt_render_buffer_write: not enough space to complete write\n");
      return ISMD_ERROR_INVALID_PARAMETER;
   }

   OS_ASSERT(wl->sw_read_ptr);
   OS_ASSERT(wl->shadow_write_ptr);
   OS_ASSERT(wl->buf_ptr);
   OS_ASSERT(data);


   //finally ready to do the write

   if (wl->local_write_ptr >= *(wl->sw_read_ptr)) {
      //safe to write rest of buffer
      temp_offset = wl->local_write_ptr - buf->base;
      temp_size_avail = buf->size - temp_offset;
      if (count <= temp_size_avail) { //can handle entire write here
         OS_MEMCPY(wl->buf_ptr + temp_offset, data, count); //dest, src, size
         // update the write pointer
         // we need to handle the corner case
         // where the new write pointer == end of buffer
         wl->local_write_ptr += count;
         if (wl->local_write_ptr == buf->base + buf->size)
         {
            wl->local_write_ptr = buf->base;
         }
      } else { //fill to end of buffer then continue from start of buffer
         OS_MEMCPY(wl->buf_ptr + temp_offset, data, temp_size_avail);
         amt_written = temp_size_avail;
         OS_MEMCPY(wl->buf_ptr, data + amt_written, count - amt_written);
         //update the write pointer
         wl->local_write_ptr = buf->base + (count - amt_written);
      }
   } else { //only space available is from write pointer to read pointer
      temp_offset = wl->local_write_ptr - buf->base;
      OS_MEMCPY(wl->buf_ptr + temp_offset, data, count);
      //update the write pointer
      wl->local_write_ptr += count;
   }

   *(wl->shadow_write_ptr) = wl->local_write_ptr;

   return ISMD_SUCCESS;
}

static ismd_result_t audio_pvt_hal_render_circ_buf_get_write_cnt(audio_render_buffer_producer_t *wl,
   audio_render_circbuf_t * buf, unsigned int *amt_avail)
{
   uint32_t read_ptr, write_ptr;

   if (wl == NULL) {
      OS_INFO("audio_pvt_render_buffer_get_write_cnt: invalid handle\n");
      return ISMD_ERROR_INVALID_HANDLE;
   }

   if (buf == NULL) {
      OS_INFO("audio_pvt_render_buffer_get_write_cnt: null buffer\n");
      return ISMD_ERROR_NULL_POINTER;
   }

   if (amt_avail == NULL) {
      OS_INFO("audio_pvt_render_buffer_get_write_cnt: null amt_avail\n");
      return ISMD_ERROR_NULL_POINTER;
   }

   if (! wl->connected) {
      OS_INFO("audio_pvt_render_buffer_get_write_cnt: must be connected before calling\n");
      return ISMD_ERROR_INVALID_REQUEST;
   }

   OS_ASSERT(wl->sw_read_ptr);

   read_ptr = *(wl->sw_read_ptr);
   write_ptr = wl->local_write_ptr;

   if (write_ptr >= read_ptr) { //no wrap case
      *amt_avail = buf->size - (write_ptr - read_ptr);
   } else { //wrap case
      *amt_avail = read_ptr - write_ptr;
   }

   //do not let the pointers ever be equal after something has been written
   OS_ASSERT(*amt_avail > 0);
   *amt_avail = *amt_avail - 1;

   return ISMD_SUCCESS;
}

/* This thread is for circular mode only, and is a work-around for low water marks. */
static void 
*audio_pvt_hal_render_low_watermark_thread(void *context)
{
   unsigned int space_avail = 0;
   audio_hal_render_context_t *render_context = (audio_hal_render_context_t *)context;

   while(!render_context->start_to_close){

      if(!render_context->underrun){
         
         if(audio_pvt_hal_render_circ_buf_get_write_cnt(&(render_context->circ_buf_wl), &(render_context->circ_buf), &space_avail) != ISMD_SUCCESS){
            OS_INFO("audio_pvt_hal_render_circ_buf_get_write_cnt failed!\n");
         }


//OS_INFO("level: %d, water: %d\n", (render_context->dma_buffer_size - space_avail), render_context->low_watermark);

         if((render_context->dma_buffer_size - space_avail) < render_context->low_watermark){
            (*(render_context->buffer_callback_func)) (render_context->user_context,  0, AUDIO_RENDER_BUFFER_REQUEST_DATA); 
         }
         else{
            os_sleep(10);
         }
      }
      else{
         os_sleep(10);
      }
   }

   /* Callback to say this thread has exited. */
   (*(render_context->buffer_callback_func)) (render_context->user_context,  render_context->curr_node_count, AUDIO_RENDER_SAFE_TO_CLOSE);

   return NULL;
}


