/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "audio_hal_capture.h"
#include "audio_hal_capture_pvt.h"
#include "auto_eas/gen3_aud_io.h"

#define DEFAULT_CAPTURE_DMA_BURST_SIZE AUDIO_HAL_DMA_BURST_SIZE_032

static audio_hal_capture_context_t *hal_capture_context = NULL;

extern pal_soc_info_t audio_soc_info;

ismd_result_t
audio_hal_capture_init_context
(
   audio_hal_capture_context_t *capture_context,
   void *caller_context,
   os_devhandle_t *devh,
   int hw_dev_id,
   uint32_t mem_addr_phys,
   void *mem_addr_virt,
   size_t mem_size,
   capture_callback_t callback_function,
   int dma_burst_size,
   int dma_xburst_size,
   unsigned int  chunk_size_ticks,
   ismd_clock_t clock,
   bool bitclk_direction, 
   bool msb_justified,
   bool spdif_clock_update_rate
)
{
   ismd_result_t  result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   unsigned int node_count = 0;
   size_t usable_mem_size = 0;
   audio_hal_capture_params capture_params;

   /*Make sure our context it in a default state*/
   audio_pvt_hal_init_capture_context_variables(capture_context);

   /*Fill in the SVEN handle*/
   if(devh != NULL){
      capture_context->hal_devh.devh = devh;
      capture_context->hal_devh.devName = "AUD_IO";
      capture_context->hal_devh.svenModule = SVEN_module_GEN3_AUD_IO;
      capture_context->hal_devh.svenUnit = 0;      
   }
   else {
      result = ISMD_ERROR_NULL_POINTER;
      VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, result);     
   }

   /*Store user context, used for callbacks.*/
   capture_context->user_context = caller_context;

   capture_context->dma_burst_size = dma_burst_size;
   capture_context->dma_xburst_size = dma_xburst_size;
   capture_context->chunk_size_ticks = chunk_size_ticks;
   capture_context->clock = clock;
   capture_context->hw_dev_id = hw_dev_id;
   
   os_irqlock_init(&(capture_context->acap_irq_lock));
   
   capture_context->rx_context = AUDIO_RX_CONTEXT_RX0;
   capture_context->dma_context = AUDIO_DMA_CONTEXT3;
   capture_context->interrupt_mask = DMA3_DESTINATION_INTERRUPT_PENDING;

   /* Reset the context */
   result = audio_hal_dma_reset(&(capture_context->hal_devh), capture_context->dma_context);
   VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, result);

   if(audio_soc_info.name == SOC_NAME_CE3100){
      result = audio_pvt_hal_rx_reset(&(capture_context->hal_devh), capture_context->rx_context );
   } 
   else {
      result = audio_pvt_ce41xx_hal_rx_reset(&(capture_context->hal_devh), capture_context->rx_context );
   }
   VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, result);

   if((hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S0) || (hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S1)){
      capture_params.i2s.bitclk_direction = bitclk_direction;
      capture_params.i2s.msb_justified = msb_justified;        
   }
   else if(hw_dev_id == ISMD_AUDIO_HW_INPUT_SPDIF) {
      capture_params.spdif.clock_update_rate = spdif_clock_update_rate;
   }
   
   result = audio_hal_program_rx_interface(capture_context, capture_params, hw_dev_id);
   VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, result);

   /*Set up linked list mode mode*/

   /* Find out how many nodes we can get out of the memory given. */
   node_count = (mem_size / SIZE_OF_DMA_LINKED_LIST_NODE);

   /* Only send the size of memory we are actually using. */
   usable_mem_size = (node_count * SIZE_OF_DMA_LINKED_LIST_NODE);

   //debug OS_INFO("actual_mem_size: %d, usable_mem_size: %d\n", mem_size, usable_mem_size);

   result = audio_pvt_hal_capture_linked_list_dma_setup(
      capture_context, 
      node_count,  
      mem_addr_phys, 
      (int32_t)mem_addr_virt,
      usable_mem_size);
   VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, result);
   
   capture_context->in_use = true;
   capture_context->buffer_callback_func = callback_function;
   capture_context->dma_buffer_size = mem_size;

   //Register the instance with the global HAL pointer, the dma context serves as the index into this array
   hal_capture_context = capture_context;

   goto end;
   
error:
   capture_context->hal_devh.devh = NULL;
   capture_context->in_use = false;            

end:
      //Clean up and exit code
      
   AUDIO_EXIT(capture_context->hal_devh.devh);

   return result;
}

void
audio_hal_capture_deinit_context(audio_hal_capture_context_t *capture_context)
{

   capture_context->start_to_close = true;

   /* Make sure we dont have any nodes we havent already freed. */
   if(capture_context->curr_node_count > 0){

      audio_pvt_hal_capture_linked_list_shutdown_cleanup(capture_context, false);
   }

   os_irqlock_destroy(&(capture_context->acap_irq_lock));
   
   return;
}

/**
This function is responsible for starting the I2S interface for capture unit.

@param[in] capture_context : I2S instance to start capture on.

@retval ISMD_SUCCESS : Interface started capturing.
*/
ismd_result_t 
audio_hal_capture_start(audio_hal_capture_context_t *capture_context)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   unsigned int imrx_val = 0;
   unsigned int new_imrx_val = 0;
   os_irqlock_local_t   irqlocal;
   bool fifo_overrun = false;
      
   AUDIO_ENTER(capture_context->hal_devh.devh);

   switch(capture_context->rx_context)
   {
      case AUDIO_RX_CONTEXT_RX0:
         capture_context->level_node_count = capture_context->curr_node_count;
         if (capture_context->level_node_count == 0) {
            retStatus = ISMD_ERROR_INVALID_REQUEST;
         }
         else {
            os_irqlock_acquire(&capture_context->acap_irq_lock, &irqlocal); 

            capture_context->state = AUDIO_HAL_STATE_STARTED;
            /* Start the RX context */
            WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SACR0_RX_ENABLE, AUDIO_HAL_BIT_SET);

            // write first ll descriptor to DMA in LL mode!
            WRITE_IO(capture_context->hal_devh.devh, DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_SRCDMA_START,  capture_context->rxSARRAddr);
            WRITE_IO(capture_context->hal_devh.devh, DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_NEXT_DESCR,   capture_context->nodeBaseAddrPhys);
            WRITE_IO(capture_context->hal_devh.devh, DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE,   capture_context->flags_mode);

            /* Read IMRX then write it back */
            imrx_val = READ_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_IMRX);
            new_imrx_val = (capture_context->interrupt_mask | imrx_val);

            /* Un-mask the interrupt in IMRX */
            WRITE_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_IMRX, new_imrx_val);

            fifo_overrun = READ_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SASR0_RX_FIFO_OVERRUN);
            
            capture_context->start_to_close = false;
            
            os_irqlock_release(&capture_context->acap_irq_lock, &irqlocal);

            if(fifo_overrun){
               OS_INFO("WARNING: %s - %s\n", __FUNCTION__, "i2s Rx fifo overrun");
            }
            
         }         
         break;
            
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, retStatus)
   }
   
   goto end;
error:      
   //Error handler      

end:
   //Clean up and exit code
      
   DEVH_FUNC_EXIT(capture_context->hal_devh.devh);
   return retStatus;
}


/**
This function is responsible for stopping capture on a I2S interface.

@param[in] capture_context : I2S instance to stop.

@retval ISMD_SUCCESS : Interface has stopped capturing incoming stream.
*/
ismd_result_t 
audio_hal_capture_stop(audio_hal_capture_context_t* capture_context, bool shutdown)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   unsigned int imrx_val = 0;
   unsigned int new_imrx_val = 0;
   os_irqlock_local_t   irqlocal;
   
   AUDIO_ENTER(capture_context->hal_devh.devh);

   switch(capture_context->rx_context)
   {
      case AUDIO_RX_CONTEXT_RX0:
         os_irqlock_acquire(&capture_context->acap_irq_lock, &irqlocal); 
         
         WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SACR0_RX_ENABLE, AUDIO_HAL_BIT_CLEAR);
         capture_context->overflow = true;
         
         /* Read IMRX then write it back */
         imrx_val = READ_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_IMRX);
         new_imrx_val = (~(capture_context->interrupt_mask) & imrx_val);
         /* Mask the interrupt in IMRX */
         WRITE_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_IMRX, new_imrx_val);
         
         capture_context->state = AUDIO_HAL_STATE_STOPPED;

         os_irqlock_release(&capture_context->acap_irq_lock, &irqlocal);
         break;
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, retStatus);
   }

   /* Need to be notified to clean up remaining nodes. */
   if(shutdown){ 
      capture_context->start_to_close = true;
   }

   goto end;
error:      
   //Error handler      

end:
   //Clean up and exit code

   DEVH_FUNC_EXIT(capture_context->hal_devh.devh);
   return retStatus;
}

/**
This function is responsible for putting the I2S hardware back into its reset setting.

@param[in] capture_context : I2S instance to reset.

@retval ISMD_SUCCESS : Interface reset.
*/
ismd_result_t 
audio_hal_capture_reset(audio_hal_capture_context_t* capture_context)
{
   if(audio_soc_info.name == SOC_NAME_CE3100){
      return audio_pvt_hal_rx_reset(&capture_context->hal_devh, capture_context->rx_context);
   } 
   else {
      return audio_pvt_ce41xx_hal_rx_reset(&(capture_context->hal_devh), capture_context->rx_context);
   }
}

/**
This function is responsible for configuring channels that I2S instance will capture.

@param[in] capture_context : I2S instance to set capture channel characteristics.
@param[in] channel_config : Channel configuration of the data being captured.

@retval ISMD_SUCCESS : Interface is now configured for capturing channels specified by "channel_config".
*/
ismd_result_t 
audio_hal_capture_set_channel_configuration(audio_hal_capture_context_t* capture_context, int ch_count)
{
   ismd_result_t result = ISMD_SUCCESS;
   
   if(audio_soc_info.name == SOC_NAME_CE3100){
      result = audio_ce31xx_hal_capture_set_channel_configuration(capture_context, ch_count);
   }
   else { // need to program number of channels only for i2s interface
      if((capture_context->hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S0) || (capture_context->hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S1)){
         result = audio_ce41xx_hal_capture_set_channel_configuration(capture_context, ch_count);
      }
   }
         
   return result;
}

/**
This function is responsible for configuring the I2S hardware for the sample rate desired based on input and 
output clock frequency divider

@param[in] capture_context : I2S instance.
@param[in] divider : Bitclock divider.

@retval ISMD_SUCCESS : Desired bit clock divider has been set.
*/
ismd_result_t
audio_hal_capture_set_bit_clock_divider(audio_hal_capture_context_t* capture_context,  unsigned int divider, int sample_rate)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(audio_soc_info.name == SOC_NAME_CE3100){
      switch (sample_rate) {
         case 48000:
            /* Need to set RX0_SADIV before capture_startup */
            WRITE_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_RX0SADIV_AUD_CLK_DIV, divider);
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }
   }
   else {
      switch (sample_rate) {
         case 32000:
         case 44100:  
         case 48000:
         case 96000:
         case 192000:
            /* Need to set RX0_SADIV before capture_startup */
            WRITE_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_RX0SADIV_AUD_CLK_DIV, divider);
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }
   }
   
   return result;
}


/**
This function is responsible for configuring sample size of incoming data that I2S instance should capture.

@param[in] capture_context : I2S instance to set capture sample size.
@param[in] sample_size : Sample size enumeration value of incoming data.

@retval ISMD_SUCCESS : Interface is now configured for capturing sample size "sample_size".
*/
ismd_result_t 
audio_hal_capture_set_sample_size(audio_hal_capture_context_t* capture_context, int sample_size, unsigned int *sample_packing_size)
{
   ismd_result_t result = ISMD_SUCCESS;

   if((audio_soc_info.name == SOC_NAME_CE4100) || (audio_soc_info.name == SOC_NAME_CE4200) || (audio_soc_info.name == SOC_NAME_CE5300)){
      result = audio_ce41xx_hal_capture_set_sample_size(capture_context, sample_size, sample_packing_size);
   }
   else if(audio_soc_info.name == SOC_NAME_CE3100){
      result = audio_ce31xx_hal_capture_set_sample_size(capture_context, sample_size, sample_packing_size);
   }
   
   return result;
}


/**
This function is responsible for configuring capture bitclock pin direction. 

@param[in] capture_context : I2S instance to set capture sample size.
@param[in] bitclk_direction : Bit clock direction, input or output.

@retval ISMD_SUCCESS : The desired clock has been set.
*/
ismd_result_t 
audio_hal_capture_set_clk_direction(audio_hal_capture_context_t *capture_context, bool bitclk_direction)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   AUDIO_ENTER(capture_context->hal_devh.devh);

   /* should to set register before capture enabled. */
   result = audio_hal_capture_i2sc_set_clk_direction(capture_context->hal_devh.devh, bitclk_direction);
   
   AUDIO_EXIT(capture_context->hal_devh.devh);
   return result;
}


/**
This function is responsible for configuring sample format I2s stardard or MSB justified mode.

@param[in] capture_context : I2S instance to set capture sample size.
@param[in] msb_justified : sample format, I2s stardard or MSB justified.

@retval ISMD_SUCCESS : The desired sample format has been set.
*/
ismd_result_t 
audio_hal_capture_set_alt_mode(audio_hal_capture_context_t *capture_context, bool msb_justified)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   AUDIO_ENTER(capture_context->hal_devh.devh);

   WRITE_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_RX0SACR1_ALT_MODE, msb_justified);
   
   AUDIO_EXIT(capture_context->hal_devh.devh);
   return retStatus;
}

/**
This function is responsible for configuring SPDIF clock update rate.

@param[in] capture_context : Capture instance to set SPDIF clock update rate.
@param[in] spdif_clock_update_rate : SPDIF measured clock is updated every 192 streo samples or every stereo sample.

@retval ISMD_SUCCESS : The desired clock update rate has been set.
*/
ismd_result_t 
audio_hal_capture_set_spdif_clock_update_rate(audio_hal_capture_context_t *capture_context, bool spdif_clock_update_rate)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   AUDIO_ENTER(capture_context->hal_devh.devh);

   OS_ASSERT(audio_soc_info.name != SOC_NAME_CE3100);

      retStatus = audio_ce41xx_hal_capture_set_spdif_clock_update_rate( capture_context, spdif_clock_update_rate );
   
   AUDIO_EXIT(capture_context->hal_devh.devh);
   return retStatus;
}

ismd_result_t
audio_hal_capture_i2sc_set_clk_direction(os_devhandle_t *devh, bool bitclk_direction)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   AUDIO_ENTER(devh);
   
   WRITE_IO(devh, BITFIELD_AUD_IO_RX0SACR0_BIT_CLK_SRC, bitclk_direction);

   AUDIO_EXIT(devh);
   return retStatus;
}

ismd_result_t
audio_hal_capture_buffer_add
(
   audio_hal_capture_context_t *capture_context,
   uint32_t buf_addr_phys,
   void *buf_addr_virt,
   size_t buf_size,
   int buf_id 
)
{
   ismd_result_t  result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   unsigned int prev_index = 0;
   unsigned int dma_next_node = 0;
   unsigned int dma_curr_node = 0;
   unsigned int dma_flags_active = 0;
   unsigned int new_node_phys= 0;

   if(capture_context->in_use && (!capture_context->start_to_close))
   {
      /* Check to see where the DMA is at */
      dma_next_node = READ_IO(capture_context->hal_devh.devh, DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_NEXT_DESCR); 
      dma_curr_node = READ_IO(capture_context->hal_devh.devh, DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_CURR_DESCR); 
      dma_flags_active = READ_IO(capture_context->hal_devh.devh, DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_ACTIVE_DMA);

      /* First node addition to the list */
      if(!capture_context->first_node_added){

         capture_context->first_node_added = true;
         capture_context->curr_node_index = 0;
         capture_context->curr_dma_node_index = 0;

         /*Update the node.*/
         capture_context->dma_nodes[0].dma_descriptor.DSTDMA_START = buf_addr_phys;
         capture_context->dma_nodes[0].dma_descriptor.SRCDMA_SIZE = buf_size;
         capture_context->dma_nodes[0].dma_descriptor.FLAGS_MODE = capture_context->flags_mode_stop;
         capture_context->dma_nodes[0].buffer_id = buf_id;
         capture_context->dma_nodes[0].buffer_size = buf_size;

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW,capture_context->hal_devh.devh, 
            SVEN_MODULE_EVENT_AUD_IO_HAL_CAPTURE_BUFFER_ADD, 
            (unsigned int) capture_context->dma_context, 
            (unsigned int) dma_curr_node , 
            (unsigned int) dma_next_node, 
            (unsigned int) dma_flags_active, 
            (unsigned int) capture_context->dma_nodes[0].phys_addr, 
            (unsigned int) capture_context->curr_node_count);
    
         result = ISMD_SUCCESS;
      }

      else{
         
         /*Record the previous node index */
         prev_index = capture_context->curr_node_index;

         /* Increment our Index count to move on to the next node in the list */
         INCREMENT_INDEX(capture_context->curr_node_index, capture_context->max_nodes);

         new_node_phys = (unsigned int)capture_context->dma_nodes[capture_context->curr_node_index].phys_addr;

        /* If the current node we are trying to add is next in line, we are too late. Dont try to add it
         * It is under risk of out of empty. It is not capture buffer overflow, it is interrupts missing. We need to handle it.
         */
        if(((dma_next_node == new_node_phys) && dma_flags_active)){

            AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL,capture_context->hal_devh.devh, 
               SVEN_MODULE_EVENT_AUD_IO_HAL_CAPTURE_BUFFER_ADD_FAILED, 
               (unsigned int) capture_context->dma_context, 
               (unsigned int) dma_curr_node , 
               (unsigned int) dma_next_node, 
               (unsigned int) dma_flags_active, 
               (unsigned int) new_node_phys,  
               (unsigned int) capture_context->curr_node_count);

            result = ISMD_ERROR_NO_SPACE_AVAILABLE;
            DECREMENT_INDEX(capture_context->curr_node_index, capture_context->max_nodes); // We didnt add the node, so pull back on the index
        }
        else{

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW,capture_context->hal_devh.devh, 
            SVEN_MODULE_EVENT_AUD_IO_HAL_CAPTURE_BUFFER_ADD, 
            (unsigned int) capture_context->dma_context, 
            (unsigned int) dma_curr_node , 
            (unsigned int) dma_next_node, 
            (unsigned int) dma_flags_active, 
            (unsigned int) new_node_phys, 
            (unsigned int) capture_context->curr_node_count);

            /* First update the current node we want to add with the buffer info, and make sure its terminated */
            capture_context->dma_nodes[capture_context->curr_node_index].dma_descriptor.DSTDMA_START = buf_addr_phys;
            capture_context->dma_nodes[capture_context->curr_node_index].dma_descriptor.SRCDMA_SIZE = buf_size;
            capture_context->dma_nodes[capture_context->curr_node_index].dma_descriptor.FLAGS_MODE = capture_context->flags_mode_stop;
            capture_context->dma_nodes[capture_context->curr_node_index].buffer_id = buf_id;
            capture_context->dma_nodes[capture_context->curr_node_index].buffer_size = buf_size;

            /* Un-terminate the previous node to link it up */
            capture_context->dma_nodes[prev_index].dma_descriptor.FLAGS_MODE = capture_context->flags_mode;           

            result = ISMD_SUCCESS;
        } 
      }

      /*If the node add succeeded then update count and current buffer level*/
      if(result == ISMD_SUCCESS) {
         capture_context->curr_node_count++;
         capture_context->dma_buffer_level += buf_size;
      }

   }
   else {
      result = ISMD_ERROR_NO_SPACE_AVAILABLE;
   }
      
   return result;
}

void
audio_hal_capture_handle_interrupt(unsigned int isrx_value)
{
   unsigned int isrx = 0;
   unsigned int imrx_val;
   unsigned int masked_imrx_val;
   audio_hal_capture_context_t *capture_context;

   /*DMA3 Destination Interrupt*/
   if(isrx_value & DMA3_DESTINATION_INTERRUPT_PENDING) {

      capture_context = hal_capture_context;

      /*Clear the interrupt, read back to ensure transaction.*/
      WRITE_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_ISRX, DMA3_DESTINATION_INTERRUPT_PENDING);
      isrx = READ_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_ISRX);

      imrx_val = READ_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_IMRX);
      masked_imrx_val = (DMA3_DESTINATION_INTERRUPT_PENDING & imrx_val);

      if((capture_context->in_use) && (masked_imrx_val != 0)){
         audio_pvt_hal_capture_linked_list_handle_interrupt( capture_context );
      }
   }

   return;
}

void
audio_hal_capture_shutdown_cleanup(audio_hal_capture_context_t* capture_context)
{
   unsigned int imrx_val = 0;
   unsigned int new_imrx_val = 0;

   /* Read IMRX then write it back */
   imrx_val = READ_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_IMRX);
   new_imrx_val = (~(capture_context->interrupt_mask) & imrx_val);
   
   /* Mask the interrupt in IMRX */
   WRITE_IO(capture_context->hal_devh.devh, BITFIELD_AUD_IO_IMRX, new_imrx_val);
   

   audio_pvt_hal_capture_linked_list_shutdown_cleanup(capture_context, false);
}

void
audio_hal_capture_set_dma_burst_size(audio_hal_capture_context_t* capture_context, int dma_burst_size, int dma_xburst_size)
{
   unsigned int burst_mask, xburst_mask;

   capture_context->dma_burst_size = dma_burst_size;
   capture_context->dma_xburst_size = dma_xburst_size;
   
   burst_mask = BMSK_AUD_IO_DMA0_FLAGS_MODE_BURST_SZ;
   xburst_mask = BMSK_AUD_IO_DMA0_FLAGS_MODE_XBURST_SZ;
   
   capture_context->flags_mode = capture_context->flags_mode & (~(burst_mask));
   capture_context->flags_mode = capture_context->flags_mode | ((capture_context->dma_burst_size << BLSB_AUD_IO_DMA0_FLAGS_MODE_BURST_SZ) & burst_mask);
   capture_context->flags_mode = capture_context->flags_mode & (~(xburst_mask));
   capture_context->flags_mode = capture_context->flags_mode | ((capture_context->dma_xburst_size << BLSB_AUD_IO_DMA0_FLAGS_MODE_XBURST_SZ) & xburst_mask);

   capture_context->flags_mode_stop = capture_context->flags_mode_stop & (~(burst_mask));
   capture_context->flags_mode_stop = capture_context->flags_mode_stop | ((capture_context->dma_burst_size << BLSB_AUD_IO_DMA0_FLAGS_MODE_BURST_SZ) & burst_mask);
   capture_context->flags_mode_stop = capture_context->flags_mode_stop & (~(xburst_mask));
   capture_context->flags_mode_stop = capture_context->flags_mode_stop | ((capture_context->dma_xburst_size << BLSB_AUD_IO_DMA0_FLAGS_MODE_XBURST_SZ) & xburst_mask);
   
}
  
void
audio_hal_capture_wr_swap_endianism(audio_hal_capture_context_t* capture_context, bool do_swap)
{
   unsigned int swap_mask;
   unsigned int swap;

   swap_mask = BMSK_AUD_IO_DMA0_FLAGS_MODE_WR_SWAP_ENDIAN;
   
   if(do_swap){
      swap = 1;      
   }
   else {
      swap = 0;
   }
   
   capture_context->flags_mode = capture_context->flags_mode & (~(swap_mask));
   capture_context->flags_mode = capture_context->flags_mode | ((swap << BLSB_AUD_IO_DMA0_FLAGS_MODE_WR_SWAP_ENDIAN) & swap_mask);

   capture_context->flags_mode_stop = capture_context->flags_mode_stop & (~(swap_mask));
   capture_context->flags_mode_stop = capture_context->flags_mode_stop | ((swap << BLSB_AUD_IO_DMA0_FLAGS_MODE_WR_SWAP_ENDIAN) & swap_mask);
}
  
ismd_result_t 
audio_hal_capture_set_rxframe_size(audio_hal_capture_context_t* capture_context, unsigned int rxframe_size)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(audio_soc_info.name != SOC_NAME_CE3100){ //register not defined for CE31xx
      if(capture_context->hw_dev_id == ISMD_AUDIO_HW_INPUT_SPDIF){
         rxframe_size = rxframe_size * 2; // For I2S this refers to the number of Stereo Samples while for SPDIF this refers to just the number of Samples
      }
      result = audio_ce41xx_hal_capture_set_rxframe_size(capture_context, (rxframe_size+1));
   }
   return result;
}

void 
audio_hal_capture_set_chunk_ticks(audio_hal_capture_context_t* capture_context, unsigned int chunk_ticks)
{
   capture_context->chunk_size_ticks = chunk_ticks;
   capture_context->startup = 1;
}

ismd_result_t
audio_hal_capture_set_power_mode (os_devhandle_t *devh, audio_hal_power_management_mode_t power_mode)
{
   ismd_result_t result = ISMD_SUCCESS;
   AUDIO_ENTER(devh);
   switch(power_mode)
   {
      case AUDIO_HAL_PM_GATE:
         WRITE_IO(devh, BITFIELD_AUD_IO_CGR_RX0_CLK_EN, AUDIO_HAL_BIT_SET);
         break;
      case AUDIO_HAL_PM_POWER_ON:
         WRITE_IO(devh, BITFIELD_AUD_IO_CGR_RX0_CLK_EN, AUDIO_HAL_BIT_CLEAR);
         break;
      case AUDIO_HAL_PM_POWER_DOWN:
      default:
         break;
   }

   AUDIO_EXIT(devh);
   return result;
}

ismd_result_t
audio_hal_capture_get_block_timestamp( audio_hal_capture_context_t* capture_context, ismd_time_t *capture_time, bool clock_locked, bool is_primary)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_time_t render_time;

   if(audio_soc_info.name == SOC_NAME_CE3100) {
      if(capture_context->clock != ISMD_CLOCK_DEV_HANDLE_INVALID){
         if((ismd_clock_get_time_th_safe(capture_context->clock, &render_time)) != ISMD_SUCCESS) {
            OS_INFO("audio_capture: ismd_clock_get_time_th_safe failed!");
         }
         else {
            *capture_time = render_time - capture_context->chunk_size_ticks;
         }
      }
   }
   else {
      if((clock_locked) && (is_primary)){
         result = audio_ce41xx_hal_capture_get_block_timestamp(capture_context, capture_time);
      }
      else {
         result = audio_ce41xx_hal_capture_get_block_sw_timestamp(capture_context, capture_time);
      }
   }

   return result;
}

ismd_result_t
audio_hal_capture_valid_hw_id(int hw_input_id)
{
   ismd_result_t result = ISMD_SUCCESS;

   switch(hw_input_id)
   {
      case ISMD_AUDIO_HW_INPUT_I2S0:
         break;
      case ISMD_AUDIO_HW_INPUT_I2S1:
      case ISMD_AUDIO_HW_INPUT_SPDIF:
         if(audio_soc_info.name == SOC_NAME_CE3100){
            result = ISMD_ERROR_INVALID_PARAMETER;            
         }
         break;
      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         break;
   }

   return result;
}

ismd_result_t
   audio_hal_capture_select_input_interface(
   audio_hal_capture_context_t* capture_context,
   audio_hal_input_sel_t input_select)
{
   ismd_result_t result = ISMD_SUCCESS;

   switch(audio_soc_info.name){
      case SOC_NAME_CE3100:
         break;
      case SOC_NAME_CE4100:
         result = audio_ce41xx_hal_capture_select_input_interface(capture_context, input_select);
         break;
      case SOC_NAME_CE4200:
      case SOC_NAME_CE5300:
         result = audio_ce42xx_hal_capture_select_input_interface(capture_context, input_select);
         break;
      default:
         result = ISMD_ERROR_OPERATION_FAILED;
         break;
   }

   return result;
}


ismd_result_t 
audio_hal_program_rx_interface(
                              audio_hal_capture_context_t* capture_context,
                              audio_hal_capture_params capture_params,
                              int hw_dev_id)
{
   ismd_result_t result = ISMD_SUCCESS;

   switch(hw_dev_id){
      case ISMD_AUDIO_HW_INPUT_I2S0:
         result = audio_hal_capture_select_input_interface(capture_context, AUDIO_HAL_INPUT_SEL_I2S0);
         break;
      case ISMD_AUDIO_HW_INPUT_I2S1:
         result = audio_hal_capture_select_input_interface(capture_context, AUDIO_HAL_INPUT_SEL_I2S1);
         break;
      case ISMD_AUDIO_HW_INPUT_SPDIF:
         result = audio_hal_capture_select_input_interface(capture_context, AUDIO_HAL_INPUT_SEL_SPDIF);
         break;
      default:
         result =  ISMD_ERROR_INVALID_PARAMETER;
         break;
   }

   if(result == ISMD_SUCCESS){

      switch(capture_context->rx_context)
      {
         case AUDIO_RX_CONTEXT_RX0:
            WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SACR1_DMA_CONTEXT, capture_context->dma_context);
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
      }
      if(result == ISMD_SUCCESS){
         if((result = audio_pvt_hal_rx_fifo_set_thrsh_level( &(capture_context->hal_devh), capture_context->rx_context, AUDIO_RX_FIFO_THRESHOLD_LEVEL))!= ISMD_SUCCESS) {
            VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, result);
         }   

         if((hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S0)||(hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S1)){
            if ((result = audio_hal_capture_set_clk_direction(capture_context, capture_params.i2s.bitclk_direction)) != ISMD_SUCCESS) {
               VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, result);
            }
            else if ((result = audio_hal_capture_set_alt_mode(capture_context, capture_params.i2s.msb_justified)) != ISMD_SUCCESS) {
               VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, result);
            }
         }
         else if(hw_dev_id == ISMD_AUDIO_HW_INPUT_SPDIF){
            if ((result = audio_hal_capture_set_spdif_clock_update_rate(capture_context, capture_params.spdif.clock_update_rate)) != ISMD_SUCCESS) {
               VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, result);
            }
         }
      }
   }   
   
   error:   
      //Error handler   
   
   return result;   

}

ismd_result_t 
audio_hal_fifo_reset_restore_rx_registers(
                              audio_hal_capture_context_t* capture_context,
                              bool bitclk_direction,
                              bool msb_justified,
                              bool spdif_clock_update_rate,                              
                              int hw_dev_id)
{
   ismd_result_t result = ISMD_SUCCESS;
   unsigned int shutdown_status = 0;
   audio_hal_capture_params capture_params;

   if((hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S0) || (hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S1)){
      shutdown_status = READ_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SASR0_I2S_CNTL_CLEAN_SHUTDOWN);
      if(shutdown_status){   
         OS_INFO("WARNING: %s - %s\n", __FUNCTION__, "i2s interface shutdown not clean");
      }
   }
   
   audio_hal_dma_reset(&(capture_context->hal_devh), capture_context->dma_context);
   audio_pvt_hal_reset_fifo(capture_context, AUDIO_RX_CONTEXT_RX0);
   
   if((hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S0) || (hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S1)){
      capture_params.i2s.bitclk_direction = bitclk_direction;
      capture_params.i2s.msb_justified = msb_justified;        
   }
   else if(hw_dev_id == ISMD_AUDIO_HW_INPUT_SPDIF) {
      capture_params.spdif.clock_update_rate = spdif_clock_update_rate;
   }

   result = audio_hal_program_rx_interface(capture_context, capture_params, hw_dev_id);
   return result;   
}

void
audio_hal_capture_init()
{
   if(audio_soc_info.name != SOC_NAME_CE3100){
      audio_ce41xx_hal_init_hdvcap_devh();
   }
}

void
audio_hal_capture_deinit()
{
   if(audio_soc_info.name != SOC_NAME_CE3100){
      audio_ce41xx_hal_deinit_hdvcap_devh();
   }
}

//---------------------------------------------------
// audio HAL capture private function
//---------------------------------------------------
static void 
audio_pvt_hal_init_capture_context_variables(audio_hal_capture_context_t* capture_context)
{
   capture_context->start_to_close = false;
   capture_context->in_use = false;
   capture_context->curr_dma_node_index = 0;
   capture_context->curr_node_count = 0;
   capture_context->curr_node_index = 0;
   capture_context->dma_buffer_level = 0;
   capture_context->dma_buffer_size = 0;
   capture_context->dma_context = AUDIO_DMA_CONTEXT3;
   capture_context->dma_nodes = NULL;
   capture_context->first_node_added = false;
   capture_context->flags_mode = 0;
   capture_context->flags_mode_stop = 0;
   capture_context->last_node_phys_addr = 0;
   capture_context->level_node_count = 0;
   capture_context->max_dma_buffer_size = 0;
   capture_context->max_nodes = 0;
   capture_context->nodeBaseAddrPhys = 0;
   capture_context->overflow = false;
   capture_context->rx_context = AUDIO_RX_CONTEXT_RX0;
   capture_context->user_context = NULL;
   capture_context->startup = 1;
   capture_context->current_ts_27mhz = 0;
   capture_context->previous_ts_27mhz = 0;
   capture_context->constant_offset_27mhz = 0;
   capture_context->state = AUDIO_HAL_STATE_STOPPED;
   return;
}

static ismd_result_t 
audio_pvt_hal_rx_fifo_set_thrsh_level(audio_hal_dev_t *hal_devh, audio_rx_context_t rx_num, int level)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   AUDIO_ENTER(hal_devh->devh);
 
   switch(rx_num)
   {
      case AUDIO_RX_CONTEXT_RX0:      
         WRITE_IO(hal_devh->devh, RX_OFFSET(rx_num)+BITFIELD_AUD_IO_RX0SAFTH_RX_UPPER_FIFO_THRSH, level); 
         break;         
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }
   
   goto end;
error:   
   //Error handler   

end:
   //Clean up and exit code
   
   DEVH_FUNC_EXIT(hal_devh->devh);
   return retStatus;
}

ismd_result_t 
audio_pvt_hal_reset_fifo(audio_hal_capture_context_t* capture_context, audio_rx_context_t rx_num)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
 
   switch(rx_num)
   {
      case AUDIO_RX_CONTEXT_RX0:      
         WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(rx_num)+BITFIELD_AUD_IO_RX0SACR0_RST_FIFO, 1); // reset
         WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(rx_num)+BITFIELD_AUD_IO_RX0SACR0_RST_FIFO, 0); 
         break;         
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
   }
   
   return retStatus;
}

static ismd_result_t
audio_pvt_hal_rx_reset(audio_hal_dev_t *hal_devh, audio_rx_context_t rx_num)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   DEVH_FUNC_ENTER(hal_devh->devh);

   switch(rx_num)
   {
      case AUDIO_RX_CONTEXT_RX0:
         WRITE_IO(hal_devh->devh, RX_OFFSET(rx_num)+BITFIELD_AUD_IO_RX0SACR0_RX_ENABLE,                   AUDIO_HAL_BIT_CLEAR);
         WRITE_IO(hal_devh->devh, RX_OFFSET(rx_num)+BITFIELD_AUD_IO_RX0SACR1_DMA_CONTEXT,                 AUDIO_DMA_CONTEXT3);
         WRITE_IO(hal_devh->devh, RX_OFFSET(rx_num)+BITFIELD_AUD_IO_RX0SACR1_ALT_MODE,                    AUDIO_HAL_ALT_MODE_I2S);
         WRITE_IO(hal_devh->devh, RX_OFFSET(rx_num)+BITFIELD_AUD_IO_RX0SACR1_STORAGE_MODE,                AUDIO_HAL_DATA_STORAGE_MODE_STEREO);
         break;
            
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }

   goto end;
error:
   //Error handler

end:
   //Clean up and exit code

   DEVH_FUNC_EXIT(hal_devh->devh);
   return retStatus;
}

static ismd_result_t
audio_pvt_hal_capture_linked_list_dma_setup
(
   audio_hal_capture_context_t *capture_context,
   unsigned int nodeCount,
   int32_t nodeBaseAddrPhys,
   int32_t nodeBaseAddrVirt,
   size_t nodeMemSize
)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   int32_t rxSARRAddr;
   int32_t aud_io_phys_base_addr;
   int32_t flags_mode, flags_mode_stop;
   unsigned int i;
      
   AUDIO_ENTER(capture_context->hal_devh.devh);
      
   retStatus = (nodeBaseAddrPhys==0?ISMD_ERROR_INVALID_HANDLE:ISMD_SUCCESS);
   VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, retStatus);
   retStatus = (nodeBaseAddrVirt==0?ISMD_ERROR_INVALID_HANDLE:ISMD_SUCCESS);
   VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, retStatus);

   switch(capture_context->dma_context)
   {
      case AUDIO_DMA_CONTEXT0:
      case AUDIO_DMA_CONTEXT1:
      case AUDIO_DMA_CONTEXT2:
      case AUDIO_DMA_CONTEXT3:
         break;                              
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, retStatus);
   }

   aud_io_phys_base_addr = capture_context->hal_devh.devh->devh_regs_phys_addr;
   switch(capture_context->rx_context)
   {
      case AUDIO_RX_CONTEXT_RX0:
         rxSARRAddr = aud_io_phys_base_addr + RX_OFFSET(capture_context->rx_context) + ROFF_AUD_IO_RX0SARR;
         break;
      default:
         rxSARRAddr = 0;
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, retStatus);
   }
   
   //set up start & stop flags 
   flags_mode=AUDIO_HAL_REG_CLEAR;

   retStatus = audio_hal_create_reg_vsymbol
   (
      &(capture_context->hal_devh),
      &flags_mode,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_TERM,          AUDIO_HAL_BIT_CLEAR,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_INT,       AUDIO_HAL_BIT_CLEAR,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_INT,       AUDIO_HAL_BIT_SET,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_ADDR_MODE, AUDIO_HAL_DMA_ADDR_MODE_FIXED_CONTINOUS,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_ADDR_MODE, AUDIO_HAL_DMA_ADDR_MODE_LINEAR,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_LINK_LIST, AUDIO_HAL_BIT_SET,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_WRITE_EN,       AUDIO_HAL_BIT_SET,
      /* The burst size should be multi of capture chunk size: 48Khz*10ms = 1920 bytes, so the burst size could not be 256
       * Otherwise, the interrupts interval could be less than 10ms (not exactly 10ms) which cause buffer overflow or underrun
       */
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_BURST_SZ,      capture_context->dma_burst_size,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_XBURST_SZ,     capture_context->dma_xburst_size,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_XDMA_GAP,      AUDIO_HAL_XDMA_GAP_SIZE_0000,
      BITFIELD_NULL_TERM()   
   );    
      
   VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, retStatus);

   flags_mode_stop=AUDIO_HAL_REG_CLEAR;
   retStatus = audio_hal_create_reg_vsymbol
   (
      &(capture_context->hal_devh),
      &flags_mode_stop,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_TERM,          AUDIO_HAL_BIT_SET,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_INT,       AUDIO_HAL_BIT_CLEAR,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_INT,       AUDIO_HAL_BIT_SET,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_ADDR_MODE, AUDIO_HAL_DMA_ADDR_MODE_FIXED_CONTINOUS,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_ADDR_MODE, AUDIO_HAL_DMA_ADDR_MODE_LINEAR,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_LINK_LIST, AUDIO_HAL_BIT_SET,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_WRITE_EN,       AUDIO_HAL_BIT_SET,
      /* The burst size should be multi of capture chunk size: 48Khz*10ms = 1920 bytes, so the burst size could not be 256
       * Otherwise, the interrupts interval could be less than 10ms (not exactly 10ms) which cause buffer overflow or underrun
       */
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_BURST_SZ,      capture_context->dma_burst_size,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_XBURST_SZ,     capture_context->dma_xburst_size,
      DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_XDMA_GAP,      AUDIO_HAL_XDMA_GAP_SIZE_0000,
      BITFIELD_NULL_TERM()   
   );
   VERIFY_HAL_RETSTATUS(capture_context->hal_devh.devh, retStatus);

   /* We need all these variables later */
   capture_context->max_nodes = nodeCount;
   capture_context->flags_mode_stop = flags_mode_stop;
   capture_context->flags_mode = flags_mode;
   capture_context->rxSARRAddr = rxSARRAddr;
   capture_context->nodeBaseAddrPhys = nodeBaseAddrPhys;

   /* Assign pointer to nodes location */
   capture_context->dma_nodes = ((audio_hal_linked_list_node_t *)nodeBaseAddrVirt);

   for(i=0; i < nodeCount; i++)
   {
      //Last node case
      if(i == (nodeCount-1)){
         capture_context->dma_nodes[i].dma_descriptor.NEXT_DESC    = nodeBaseAddrPhys;
         capture_context->dma_nodes[i].dma_descriptor.FLAGS_MODE   = flags_mode_stop;
         capture_context->dma_nodes[i].dma_descriptor.DSTDMA_START = 0;
         capture_context->dma_nodes[i].dma_descriptor.SRCDMA_START = rxSARRAddr;
         capture_context->dma_nodes[i].dma_descriptor.SRCDMA_SIZE  = 0;
         capture_context->last_node_phys_addr = nodeBaseAddrPhys + (SIZE_OF_DMA_LINKED_LIST_NODE * (i));
      }
      else {
         capture_context->dma_nodes[i].dma_descriptor.NEXT_DESC = nodeBaseAddrPhys + (SIZE_OF_DMA_LINKED_LIST_NODE * (i+1));
         capture_context->dma_nodes[i].dma_descriptor.FLAGS_MODE   = flags_mode_stop;
         capture_context->dma_nodes[i].dma_descriptor.DSTDMA_START = 0;
         capture_context->dma_nodes[i].dma_descriptor.SRCDMA_START = rxSARRAddr;
         capture_context->dma_nodes[i].dma_descriptor.SRCDMA_SIZE  = 0;
      }
       
      /* Keep track of physical addresses also */
      capture_context->dma_nodes[i].phys_addr = nodeBaseAddrPhys + (SIZE_OF_DMA_LINKED_LIST_NODE * (i));
      //OS_PRINT("cnt:%d, phys: 0x%x \n", i, capture_context->dma_nodes[i].phys_addr);
   }

   goto end;

error:      
   //Error handler
end:
   //Clean up and exit code
      
   AUDIO_EXIT(capture_context->hal_devh.devh);
   return retStatus;
}

static void
audio_pvt_hal_capture_linked_list_free_node(audio_hal_capture_context_t *capture_context)
{
   /* Call the callback function to de-ref the buffer */
   (*(capture_context->buffer_callback_func)) 
     (capture_context->user_context,  
      capture_context->dma_nodes[capture_context->curr_dma_node_index].buffer_id,
      AUDIO_CAPTURE_BUFFER_DONE); 

   /*Decrement the DMA buffer level*/
   capture_context->dma_buffer_level -= capture_context->dma_nodes[capture_context->curr_dma_node_index].buffer_size;

   /* Decrement the count, and advance the current dma index */
   capture_context->curr_node_count--;
   INCREMENT_INDEX(capture_context->curr_dma_node_index, capture_context->max_nodes);

   return;
}


static void
audio_pvt_hal_capture_linked_list_handle_interrupt(audio_hal_capture_context_t *capture_context)
{
   /* Exactly same as audio_pvt_hal_render_linked_list_handle_interrupt */
   int32_t dma_flags_active = 0;
   int32_t dma_curr_node = 0;
   int32_t buffer_id = ISMD_BUFFER_HANDLE_INVALID;
   int32_t free_loop = 0;
   int32_t free_node_count = 0;
   ismd_result_t result = ISMD_SUCCESS;

   dma_curr_node = READ_IO(capture_context->hal_devh.devh, DMA_OFFSET(capture_context->dma_context) + BITFIELD_AUD_IO_DMA0_CURR_DESCR); 
   dma_flags_active = READ_IO(capture_context->hal_devh.devh, DMA_OFFSET(capture_context->dma_context)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_ACTIVE_DMA);

   //OS_PRINT("INTRPT: dma_curr: 0x%x, dma_active?: 0x%x \n", dma_curr_node, dma_flags_active);
   
   AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, capture_context->hal_devh.devh, 
      SVEN_MODULE_EVENT_AUD_IO_HAL_CAPTURE_LL_INTERUPT, 
      (unsigned int) capture_context->dma_context, 
      (unsigned int) dma_curr_node , 
      (unsigned int) dma_flags_active, 
      (unsigned int) capture_context->curr_node_count, 
      (unsigned int) capture_context->level_node_count, 0);

   /* Check to see how far the DMA had advanced since the last interrupt and free those nodes. */
   free_node_count = audio_pvt_hal_capture_linked_list_get_free_node_count(capture_context, dma_curr_node );

   for(free_loop = free_node_count; free_loop > 0; free_loop--){
      audio_pvt_hal_capture_linked_list_free_node(capture_context);
   }

   /* Special case where the DMA is not active, free all remaining nodes (probably always 1) */
   if((capture_context->state != AUDIO_HAL_STATE_STOPPED) && (!dma_flags_active) && (capture_context->curr_node_count > 0)) {

      for(free_loop = capture_context->curr_node_count; free_loop > 0; free_loop--) {  
         audio_pvt_hal_capture_linked_list_free_node(capture_context);
      }
   }

   /* If we have no nodes we are empty and need to perform an empty callback, else request more data! */
   if(capture_context->curr_node_count == 0){
      
      capture_context->first_node_added = false;
      capture_context->curr_node_index = 0;

      /* If we are NOT closing just signal an underrun, if we are closing signal for the safe to close. */
      if((!capture_context->start_to_close) && (capture_context->state != AUDIO_HAL_STATE_STOPPED)){
         (*(capture_context->buffer_callback_func)) (capture_context->user_context,  buffer_id, AUDIO_CAPTURE_BUFFER_EMPTY); 
      }
      else if((capture_context->start_to_close) || (capture_context->state == AUDIO_HAL_STATE_STOPPED)){
         (*(capture_context->buffer_callback_func)) (capture_context->user_context,  capture_context->curr_node_count, AUDIO_CAPTURE_SAFE_TO_CLOSE);
      }
   }
   else{

      //This gets set in start DMA, make sure its never zero or we will stall.
      if(capture_context->level_node_count > 0) {

         //This should keep us level if we missed an interrupt or so. 
         while((!capture_context->start_to_close) && (result == ISMD_SUCCESS) && (capture_context->level_node_count >= capture_context->curr_node_count)){
            result = ((*(capture_context->buffer_callback_func)) (capture_context->user_context,  buffer_id, AUDIO_CAPTURE_REQUEST_BUFFER)); 
         }
      }
   }

   return;
}

static int
audio_pvt_hal_capture_linked_list_get_free_node_count(audio_hal_capture_context_t *capture_context, int dma_curr_node)
{
   int32_t first_count = 0;
   int32_t second_count = 0;
   int32_t my_curr_node = capture_context->dma_nodes[capture_context->curr_dma_node_index].phys_addr;
   int32_t free_node_count = 0;
   
   //Handle index wrap case.
   if(dma_curr_node < my_curr_node){

     first_count = (dma_curr_node - capture_context->nodeBaseAddrPhys) /SIZE_OF_DMA_LINKED_LIST_NODE;

     second_count = ((capture_context->last_node_phys_addr - my_curr_node) / SIZE_OF_DMA_LINKED_LIST_NODE) + 1;

     free_node_count = (first_count + second_count);
   }

   //Normal case
   else{
      free_node_count = (dma_curr_node - my_curr_node) / SIZE_OF_DMA_LINKED_LIST_NODE;
   }

   return free_node_count;
}

static void
audio_pvt_hal_capture_linked_list_shutdown_cleanup(audio_hal_capture_context_t *capture_context, bool close)
{

   while(capture_context->curr_node_count) {

      AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW,capture_context->hal_devh.devh, 
         SVEN_MODULE_EVENT_AUD_IO_HAL_CAPTURE_NODE_CLEAN_UP, 
         (unsigned int) capture_context->dma_context, 
         (unsigned int) capture_context->dma_nodes[capture_context->curr_dma_node_index].buffer_id , 
         (unsigned int) capture_context->curr_node_count, 0, 0, 0);

      audio_pvt_hal_capture_linked_list_free_node(capture_context);
   }

   capture_context->first_node_added = false;
   capture_context->curr_node_index = 0;

   if(close){
      /* Tell the driver we are done cleaning up the nodes. */
      (*(capture_context->buffer_callback_func)) (capture_context->user_context,  capture_context->curr_node_count, AUDIO_CAPTURE_SAFE_TO_CLOSE);
   }
   
   return;
}

