
/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_hal_capture.h"
#include "auto_eas/gen4_aud_io.h"
#include "auto_eas/gen4_hdvcap.h" /* Needed for de-jitter code. */
#include "clock_control.h"

static os_devhandle_t *hdvcap_devh; /* Needed for de-jitter code. */

void
audio_ce41xx_hal_init_hdvcap_devh()
{
   int result;
   /* hdvcap_devh needed by software timestamp dejitter code. */
   hdvcap_devh = devhandle_factory(NULL);
   OS_ASSERT( hdvcap_devh != NULL );
   devh_SVEN_SetModuleUnit( hdvcap_devh, SVEN_module_GEN4_HDVCAP, 0 );
   result = devhandle_connect_name(hdvcap_devh, "HDVCAP");
   OS_ASSERT( result != 0 );
}

void
audio_ce41xx_hal_deinit_hdvcap_devh()
{
   if ( hdvcap_devh != NULL ) {
      devh_Delete( hdvcap_devh );
   }
}


ismd_result_t
audio_pvt_ce41xx_hal_rx_reset(audio_hal_dev_t *hal_devh, audio_rx_context_t rx_num)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   AUDIO_ENTER(hal_devh->devh);

   switch(rx_num)
   {
      case AUDIO_RX_CONTEXT_RX0:
         WRITE_IO(hal_devh->devh, RX_OFFSET(rx_num)+BITFIELD_AUD_IO_RX0SACR0_RX_ENABLE,                   AUDIO_HAL_BIT_CLEAR);
         WRITE_IO(hal_devh->devh, RX_OFFSET(rx_num)+BITFIELD_AUD_IO_RX0SACR1_DMA_CONTEXT,                 AUDIO_DMA_CONTEXT3);
         WRITE_IO(hal_devh->devh, RX_OFFSET(rx_num)+BITFIELD_AUD_IO_RX0SACR1_ALT_MODE,                    AUDIO_HAL_ALT_MODE_I2S);
         break;
            
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }

   goto end;
error:
   //Error handler

end:
   //Clean up and exit code

   DEVH_FUNC_EXIT(hal_devh->devh);
   return retStatus;
}

/**
This function is responsible for configuring sample size of incoming data that I2S instance should capture.

@param[in] capture_context : I2S instance to set capture sample size.
@param[in] sample_size : Sample size enumeration value of incoming data.

@retval ISMD_SUCCESS : Interface is now configured for capturing sample size "sample_size".
*/
ismd_result_t 
audio_pvt_ce41xx_hal_capture_set_sample_size(audio_hal_capture_context_t* capture_context, audio_cap_hal_sample_size_t sample_size)
{
   int32_t sample_size_value = 0;
   ismd_result_t result = ISMD_SUCCESS;
   AUDIO_ENTER(capture_context->hal_devh.devh);

   switch(sample_size){
      case AUDIO_CAP_HAL_SAMPLE_SIZE_16BIT:
      case AUDIO_CAP_HAL_SAMPLE_SIZE_20BIT:
         sample_size_value = 0;
         break;
      case AUDIO_CAP_HAL_SAMPLE_SIZE_24BIT:
         sample_size_value = 1;
         break;
      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         break;
   }

   if(result == ISMD_SUCCESS){
      WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SACR1_SAMPLE_SIZE, sample_size_value);
   }
   
   AUDIO_EXIT(capture_context->hal_devh.devh);
   return result;
}


/**
This function is responsible for configuring channels that I2S instance will capture.

@param[in] capture_context : I2S instance to set capture channel characteristics.
@param[in] channel_config : Channel configuration of the data being captured.

@retval ISMD_SUCCESS : Interface is now configured for capturing channels specified by "channel_config".
*/
ismd_result_t 
audio_pvt_ce41xx_hal_capture_set_channel_configuration(audio_hal_capture_context_t* capture_context, audio_hal_i2s_input_type_t i2s_input_type)
{
   AUDIO_ENTER(capture_context->hal_devh.devh);

   WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SACR0_I2S_INPUT_TYPE_SELECT, i2s_input_type);

   AUDIO_EXIT(capture_context->hal_devh.devh);
   return ISMD_SUCCESS;
}

ismd_result_t 
audio_ce41xx_hal_capture_select_input_interface(audio_hal_capture_context_t* capture_context, audio_hal_input_sel_t input_select)
{
   AUDIO_ENTER(capture_context->hal_devh.devh);

   // CE41xx doesn't have separate stereo and multichannel i2s input interface. It has only 1 i2s multichannel input interface which supports 2, 6 and 8 channel.
   // To maintain backward compatibility use the same i2s interface for both i2s0 and i2s1
   if(input_select == AUDIO_HAL_INPUT_SEL_I2S0){
      input_select = AUDIO_HAL_INPUT_SEL_I2S1;    
   }

   WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SACR0_INPUT_INTERFACE_SELECT, input_select);

   AUDIO_EXIT(capture_context->hal_devh.devh);
   return ISMD_SUCCESS;
}

ismd_result_t 
audio_ce41xx_hal_capture_get_block_timestamp(audio_hal_capture_context_t* capture_context, ismd_time_t *time)
{
   ismd_time_t          presentation_time_27mhz; 
   ismd_time_t          presentation_time_90khz;
   os_irqlock_local_t   irqlocal;
   volatile uint32_t    blockBufferPtr;
   volatile uint32_t    timestamp;
   volatile int32_t     timestamp_fifo_level = 0;
   ismd_result_t        result = ISMD_SUCCESS;

   AUDIO_ENTER(capture_context->hal_devh.devh);

   timestamp_fifo_level = READ_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SASR0_TIMESTAMP_FIFO_LEVEL);
   if( timestamp_fifo_level >= 1 ){

      if ( capture_context->startup < 3) {

         os_irqlock_acquire(&capture_context->acap_irq_lock, &irqlocal); 
         capture_context->current_ts_27mhz = (ismd_time_t)READ_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SATS);
         blockBufferPtr = READ_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SABAP);

         result = ismd_clock_get_time_th_safe( capture_context->clock, &presentation_time_90khz );

         os_irqlock_release(&capture_context->acap_irq_lock, &irqlocal);

         if( result == ISMD_SUCCESS ){
            
            presentation_time_90khz -= capture_context->chunk_size_ticks; // need to adjust it to point to start of frame. 

            presentation_time_27mhz = presentation_time_90khz * (uint64_t)300;

            capture_context->constant_offset_27mhz = presentation_time_27mhz - capture_context->current_ts_27mhz;

            capture_context->startup++;

            *time = presentation_time_90khz;
         }

      }

      else {

         timestamp = READ_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SATS);
         blockBufferPtr = READ_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SABAP);

         capture_context->current_ts_27mhz = ((capture_context->current_ts_27mhz & ((ismd_time_t)0xFFFFFFFF<<32)) | (ismd_time_t)timestamp);

         if ( capture_context->current_ts_27mhz < capture_context->previous_ts_27mhz ) {

            capture_context->current_ts_27mhz += ((ismd_time_t)(1)<<32);

         }

         presentation_time_27mhz = capture_context->current_ts_27mhz + capture_context->constant_offset_27mhz;

         presentation_time_90khz = OSAL_DIV64( presentation_time_27mhz, 300 );

         *time = presentation_time_90khz;
      }   

      capture_context->previous_ts_27mhz = capture_context->current_ts_27mhz;

   }
   else {
      result = ISMD_ERROR_NO_DATA_AVAILABLE;      
   }

   AUDIO_EXIT(capture_context->hal_devh.devh);
   return (result);
}


ismd_result_t 
audio_ce41xx_hal_capture_set_rxframe_size(audio_hal_capture_context_t* capture_context, unsigned int rxframe_size)
{
   AUDIO_ENTER(capture_context->hal_devh.devh);

   WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SADESC_RX_FRAME_SIZE, rxframe_size);
   
   AUDIO_EXIT(capture_context->hal_devh.devh);
   return ISMD_SUCCESS;
}

ismd_result_t 
audio_ce41xx_hal_capture_get_block_sw_timestamp(audio_hal_capture_context_t* capture_context, ismd_time_t *time)
{
   os_irqlock_local_t   irqlocal;
   uint32_t             block_hw_timestamp; /* 27MHz counter read when DMA started for the block */
   uint32_t             current_hw_timestamp; /* 27MHz counter read when this function executes. */
   ismd_time_t          block_smd_time = ISMD_NO_PTS; /* derived 90kHz counter for when the DMA started for this block. */
   ismd_time_t          current_smd_time; /* 90kHz counter read when this function executes. */
   int32_t              timestamp_fifo_level = 0;
   ismd_result_t        result = ISMD_SUCCESS;

   AUDIO_ENTER( capture_context->hal_devh.devh );

   timestamp_fifo_level = READ_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SASR0_TIMESTAMP_FIFO_LEVEL);
   if ( timestamp_fifo_level < 1 ) {
      result = ISMD_ERROR_NO_DATA_AVAILABLE;
   }
   else if ( capture_context->clock == ISMD_CLOCK_HANDLE_INVALID ) {
      result = ISMD_ERROR_OPERATION_FAILED;
   }
   else {
      /* Lock so we can atomically read 3 counters. */
      os_irqlock_acquire( &capture_context->acap_irq_lock, &irqlocal );

      block_hw_timestamp = READ_IO( capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SATS );
      READ_IO( capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SABAP );
      current_hw_timestamp = devh_ReadReg32( hdvcap_devh, ROFF_HDVCAP_TS_COUNTER_LSB );
      result = ismd_clock_get_time_th_safe( capture_context->clock, &current_smd_time );

      os_irqlock_release(&capture_context->acap_irq_lock, &irqlocal);

      if ( result == ISMD_SUCCESS ) {
         /* 
          * Hardware workaround:  We should need to do this only for the very 
          * first block, since in the CE4100/CE4200, the timestamps for the first 
          * block may not be valid due to the timestamp FIFO not resetting.  
          */
         if ( capture_context->startup < 2 ) {
            capture_context->startup++;
            block_smd_time = current_smd_time - capture_context->chunk_size_ticks;
         }

         /* Calculate the block timestamp based on the SMD time but use the hardware timestamp to remove jitter. */
         else {
            block_smd_time = current_smd_time - ( (current_hw_timestamp - block_hw_timestamp) / 300 );
         }         
      }

   }

   *time = block_smd_time;

   AUDIO_EXIT( capture_context->hal_devh.devh );

   return result;

}

ismd_result_t 
audio_ce41xx_hal_capture_set_spdif_clock_update_rate(audio_hal_capture_context_t* capture_context, bool spdif_clock_update_rate)
{
   AUDIO_ENTER(capture_context->hal_devh.devh);
   
   WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_CGR_SPDIF_CLK_RATE, spdif_clock_update_rate);

   AUDIO_EXIT(capture_context->hal_devh.devh);
   return ISMD_SUCCESS;
}

ismd_result_t
audio_ce41xx_hal_configure_master_clock(unsigned int frequency, ismd_audio_clk_src_t clk_src)
{
   ismd_result_t result = ISMD_SUCCESS;
   clock_control_ret_t clock_result = CLOCK_ERROR_INVALID_RESOURCE;
   int freq_select_bit = 3; 

   if(clk_src == ISMD_AUDIO_CLK_SRC_EXTERNAL){
      switch(frequency) {
         case 22579200: 
            freq_select_bit = 0;//22.5792 MHz -0
            break;
         case 24576000:  
            freq_select_bit = 1;//24.576 MHz - 1
            break;
         case 33868800:
            freq_select_bit = 2; //33.868 MHz - 2 can be used for sampling freq family 44100 with appropriate ADIV value
            break;
         case 36864000:
            freq_select_bit = 3; //Default reg setting is 36.864 MHz  - 3  can be used sampling freq family 48000 with appropriate ADIV value
            break;
         case 16384000:
            freq_select_bit = -1;
            break;
         default:
            OS_INFO("ERROR: %s - %s \n", __FUNCTION__, "Audio Master clock frequency apart from Intel reference CE41xx board!");
            break;
      }

      if(freq_select_bit != -1){
         if((clock_result = clock_control_write(CLOCK_EXT_AUD_CLKX, freq_select_bit, CLOCK_TRUE)) != CLOCK_RET_OK) {
            OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "clock_control_write failed on CLOCK_APLL_FREQ_SEL!", clock_result);
            result = ISMD_ERROR_OPERATION_FAILED;
         }
      }

   }
   else if(clk_src == ISMD_AUDIO_CLK_SRC_INTERNAL){
      result = ISMD_ERROR_INVALID_PARAMETER;
   }
   
   return result;
}

ismd_result_t
audio_ce41xx_hal_capture_set_channel_configuration(audio_hal_capture_context_t *capture_context, int ch_count)
{
   ismd_result_t result = ISMD_SUCCESS;

   switch (ch_count) {
      case 2:
      audio_pvt_ce41xx_hal_capture_set_channel_configuration(capture_context, AUDIO_HAL_I2S_MONO_OR_STEREO_MODE);
      break;

      case 1:
      audio_pvt_ce41xx_hal_capture_set_channel_configuration(capture_context, AUDIO_HAL_I2S_MONO_OR_STEREO_MODE);
      break;

      case 6:
      audio_pvt_ce41xx_hal_capture_set_channel_configuration(capture_context, AUDIO_HAL_I2S_5_1_MODE);
      break;

      case 8:
      audio_pvt_ce41xx_hal_capture_set_channel_configuration(capture_context, AUDIO_HAL_I2S_7_1_MODE);
      break;

      default:
      audio_pvt_ce41xx_hal_capture_set_channel_configuration(capture_context, AUDIO_HAL_I2S_MONO_OR_STEREO_MODE);
      result = ISMD_ERROR_INVALID_PARAMETER;            
      break;
   }

   return result;
}

ismd_result_t 
audio_ce41xx_hal_capture_set_sample_size(audio_hal_capture_context_t* capture_context, int sample_size, unsigned int *sample_packing_size)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(capture_context->hw_dev_id == ISMD_AUDIO_HW_INPUT_SPDIF){

      switch(sample_size){
         case 16:
            result = audio_pvt_ce41xx_hal_capture_set_sample_size(capture_context, AUDIO_CAP_HAL_SAMPLE_SIZE_16BIT);
            break;
         case 20:
            result = audio_pvt_ce41xx_hal_capture_set_sample_size(capture_context, AUDIO_CAP_HAL_SAMPLE_SIZE_20BIT);
            break;
         case 24:
            result = audio_pvt_ce41xx_hal_capture_set_sample_size(capture_context, AUDIO_CAP_HAL_SAMPLE_SIZE_24BIT);
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }
      if(result == ISMD_SUCCESS){
         *sample_packing_size = 32;
      }
   }
   else if((capture_context->hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S0) || (capture_context->hw_dev_id == ISMD_AUDIO_HW_INPUT_I2S1)){
   
      switch(sample_size){
         case 16:
            result = audio_pvt_ce41xx_hal_capture_set_sample_size(capture_context, AUDIO_CAP_HAL_SAMPLE_SIZE_16BIT);
            *sample_packing_size = 16;
            break;
         case 24:
            result = audio_pvt_ce41xx_hal_capture_set_sample_size(capture_context, AUDIO_CAP_HAL_SAMPLE_SIZE_24BIT);
            *sample_packing_size = 32;
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }
   }
   
   return result;
}


