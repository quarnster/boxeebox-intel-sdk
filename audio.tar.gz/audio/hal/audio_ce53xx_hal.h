/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_CE53XX_HAL_H_
#define _AUDIO_CE53XX_HAL_H_

#include "ismd_audio_defs.h"

/** APLL modes for CE53xx */
typedef enum ENUM_AUDIO_HAL_PLL_MODE
{
   AUDIO_HAL_PLL_MODE1,
   AUDIO_HAL_PLL_MODE4,
   AUDIO_HAL_PLL_MODE7,
   AUDIO_HAL_PLL_MODE12,
   AUDIO_HAL_PLL_MODE23,
   AUDIO_HAL_PLL_MODE15,
   AUDIO_HAL_PLL_MODE16,
   AUDIO_HAL_PLL_MODE17,
   AUDIO_HAL_PLL_MODE17_1,
   AUDIO_HAL_PLL_MODE24
} audio_hal_pll_mode_t;


/** Mode1 APLL clk out = 36.864Mhz clock input = APLL_EXT_CLK */
#define APLL_MODE1_CR0 0x1001000 
#define APLL_MODE1_CR1 0x50032
#define APLL_MODE1_CR2 0x50019
#define APLL_MODE1_CR3 0xD0
#define APLL_MODE1_CR4 0x0
#define APLL_MODE1_CR5 0x0
#define APLL_MODE1_CR6 0x0
#define APLL_MODE1_CR7 0x4000

/** Mode4 APLL clk out = 33.8688Mhz clock input = APLL_EXT_CLK */
#define APLL_MODE4_CR0 0x1001000
#define APLL_MODE4_CR1 0x90032
#define APLL_MODE4_CR2 0x90019
#define APLL_MODE4_CR3 0xD0
#define APLL_MODE4_CR4 0xC
#define APLL_MODE4_CR5 0x0
#define APLL_MODE4_CR6 0x0
#define APLL_MODE4_CR7 0x4000

/** Mode7 APLL clk out = 24.576Mhz clock input = APLL_EXT_CLK */
#define APLL_MODE7_CR0 0x1040000
#define APLL_MODE7_CR1 0x50032
#define APLL_MODE7_CR2 0x90019
#define APLL_MODE7_CR3 0xD0
#define APLL_MODE7_CR4 0x104
#define APLL_MODE7_CR5 0x0
#define APLL_MODE7_CR6 0x0
#define APLL_MODE7_CR7 0x4000

/** Mode12 APLL clk out = 22.5792Mhz clock input = APLL_EXT_CLK */
#define APLL_MODE12_CR0 0x1040000
#define APLL_MODE12_CR1 0x50032
#define APLL_MODE12_CR2 0x90019
#define APLL_MODE12_CR3 0xD0
#define APLL_MODE12_CR4 0x4
#define APLL_MODE12_CR5 0x0
#define APLL_MODE12_CR6 0x0
#define APLL_MODE12_CR7 0x4000

/** Mode23 APLL clk out = 16.384Mhz clock input = APLL_EXT_CLK */
#define APLL_MODE23_CR0 0x1040000
#define APLL_MODE23_CR1 0x90024
#define APLL_MODE23_CR2 0x90024
#define APLL_MODE23_CR3 0xD0
#define APLL_MODE23_CR4 0x44
#define APLL_MODE23_CR5 0x0
#define APLL_MODE23_CR6 0x0
#define APLL_MODE23_CR7 0x4000

/** Mode15 APLL clk out = 36.864Mhz clock input = CLK_IN_FPLL_NOSSC */
#define APLL_MODE15_CR0 0x2800
#define APLL_MODE15_CR1 0x90020
#define APLL_MODE15_CR2 0x40719
#define APLL_MODE15_CR3 0xD0
#define APLL_MODE15_CR4 0x48
#define APLL_MODE15_CR5 0x0
#define APLL_MODE15_CR6 0x0
#define APLL_MODE15_CR7 0x4000

/** Mode16 APLL clk out = 33.8688Mhz clock input = CLK_IN_FPLL_NOSSC */
#define APLL_MODE16_CR0 0x2800
#define APLL_MODE16_CR1 0x90131
#define APLL_MODE16_CR2 0x63305
#define APLL_MODE16_CR3 0xD0
#define APLL_MODE16_CR4 0x40
#define APLL_MODE16_CR5 0x0
#define APLL_MODE16_CR6 0x0
#define APLL_MODE16_CR7 0x4000

/** Mode17 APLL clk out = 24.576Mhz clock input = CLK_IN_FPLL_NOSSC */
#define APLL_MODE17_CR0 0x2800
#define APLL_MODE17_CR1 0x90020
#define APLL_MODE17_CR2 0x63309
#define APLL_MODE17_CR3 0xD0
#define APLL_MODE17_CR4 0x48
#define APLL_MODE17_CR5 0x0
#define APLL_MODE17_CR6 0x0
#define APLL_MODE17_CR7 0x4000

/** Mode17_1 APLL clk out = 22.5792Mhz clock input = CLK_IN_FPLL_NOSSC */
#define APLL_MODE17_1_CR0 0x2000
#define APLL_MODE17_1_CR1 0x6270B
#define APLL_MODE17_1_CR2 0x5017D
#define APLL_MODE17_1_CR3 0xD0
#define APLL_MODE17_1_CR4 0x48
#define APLL_MODE17_1_CR5 0x0
#define APLL_MODE17_1_CR6 0x0
#define APLL_MODE17_1_CR7 0x4000

/** Mode24 APLL clk out = 16.384Mhz clock input = CLK_IN_FPLL_NOSSC */
#define APLL_MODE24_CR0 0x104800
#define APLL_MODE24_CR1 0x90020
#define APLL_MODE24_CR2 0x6330F
#define APLL_MODE24_CR3 0xD0
#define APLL_MODE24_CR4 0x48
#define APLL_MODE24_CR5 0x0
#define APLL_MODE24_CR6 0x0
#define APLL_MODE24_CR7 0x4000

#define PLL_RESET_REGISTER_OFFSET 0x88
#define PLL_RESET_REGISTER_APLL_VCO_RESET_MASK 0x10
#define PLL_RESET_REGISTER_APLL_DIV_RESET_MASK 0x20
#define PLL_RESET_REGISTER_APLL_VCO_DIV_RESET_MASK (PLL_RESET_REGISTER_APLL_VCO_RESET_MASK | PLL_RESET_REGISTER_APLL_DIV_RESET_MASK)

#define APLL_CR0_OFFSET 0
#define APLL_CR0_CHANGE_CONFIGURATION_MASK 0x1
#define APLL_MAX_CONFIG_REGS 8

typedef struct {
   uint32_t apll_cr[APLL_MAX_CONFIG_REGS];
} audio_pll_configuration;

ismd_result_t 
audio_ce53xx_hal_configure_master_clock(unsigned int frequency, ismd_audio_clk_src_t clk_src);


#endif  /* _AUDIO_CE53XX_HAL_H_ */
