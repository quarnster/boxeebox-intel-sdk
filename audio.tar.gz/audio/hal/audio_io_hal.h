/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _AUDIO_IO_HAL_H_
#define _AUDIO_IO_HAL_H_

#include "audio_io_hal_defs.h"
#include "auto_eas/gen3_aud_io.h"

/**
Initialization of the audio IO HAL layer. This function will initialize
semaphores, record any debug handle given and initialize the 
context structures.

@param[in] debug_handle : Handle used to convey debug information.

@retval ISMD_SUCCESS : Audio IO HAL was successfully initialized.
@retval ISMD_ERROR_INVALID_HANDLE : Debug handle was NULL.
*/
ismd_result_t
audio_io_hal_init(void *debug_handle);


/**
Deinitialization of the audio IO HAL layer. This will free up any resources
created during intitialization and should be called when nothing more is
to be done in the audio IO HAL.

@retval ISMD_SUCCESS : Audio IO HAL was successfully deinitialized.
*/
ismd_result_t
audio_io_hal_deinit(void);


/**
Open an audio IO HAL context. Based on the hardware id requested, the HAL
will return a handle to be used to control the hardware input/output device
specified in this function call. This function call is requred to be called first
to access any other audio IO HAL function. 

@param[in] hardware_id : The hardware device ID of the deviced requested to control.
@param[in] callback : A callback function implemented by the caller to receive HAL events.
@param[out] handle: Audio IO HAL handle used to control the requested context.

@retval ISMD_SUCCESS : Audio IO HAL context was successfully opened.
@retval ISMD_ERROR_NO_RESOURCES : The spcified hardware id is not available.
*/
ismd_result_t
audio_io_hal_open(int hardware_id, audio_io_hal_callback_t callback, int *handle);


/**
Close the specificed context control of the audio IO HAL. This will free up the device to be
used by subsequent callers. Close can be called at any time and will force a 
stop on the active context. 

@param[in] handle: Audio IO HAL handle to the context.

@retval ISMD_SUCCESS : Audio IO HAL context was successfully closed.
@retval ISMD_ERROR_INVALID_HANDLE : The handle specified is invalid.
*/
ismd_result_t
audio_io_hal_close(int handle);


/**
Stop any audio IO hardware operations. Call this function to send the 
command to the hardware to stop capturing or rendering audio data.

@param[in] handle: Audio IO HAL handle to the context.

@retval ISMD_SUCCESS : Audio IO HAL context was successfully stopped.
@retval ISMD_ERROR_INVALID_HANDLE : The handle specified is invalid.
*/
ismd_result_t
audio_io_hal_stop(int handle);


/**
Start audio IO hardware operations. Call this function to send the 
command to the hardware to start capturing or rendering audio data.

@param[in] handle: Audio IO HAL handle to the context.

@retval ISMD_SUCCESS : Audio IO HAL context was successfully started.
@retval ISMD_ERROR_INVALID_HANDLE : The handle specified is invalid.
@retval ISMD_ERROR_NO_RESOURCES : No memory has been added. 
*/
ismd_result_t
audio_io_hal_start(int handle);


/**
Add a region of memory to the audio IO HAL. This is a
physical memory region where the hardware can write or
read from depending on the audio IO operation of the hardware
that is in use. Call this function multiple times to add several regions
of memory that the HAL will form into a list and write or read from 
sequentially. When the end of the memory regions added has been 
reached the HAL will start back over to the first one added and continue
its operation into that memory region. The caller must call this function
and add at least one region of memory before calling start, otherwise
the call to start will fail. This must be called in the stopped state.

@param[in] handle: Audio IO HAL handle to the context.
@param[in] phys_addr: The base physical address of the memory region.
@param[in] size: The size of the memory region. 

@retval ISMD_SUCCESS : The memory region was added to the list.
@retval ISMD_ERROR_INVALID_HANDLE : The handle specified is invalid.
@retval ISMD_ERROR_INVALID_REQUEST : Was not in a stopped state. 
*/
ismd_result_t
audio_io_hal_add_memory(int handle, uint32_t phys_addr, int size);


/**
Set the transmittal audio data attributes. This information will be used
to configure the audio hardware to perform its designated operation
at the given frequency. 

@param[in] handle: Audio IO HAL handle to the context.
@param[in] sample_rate: Sampling rate of the audio data.
@param[in] sample_size: Sampling size of the audio data.
@param[in] channel_count: Channel count of the audio data.
@param[in] endianness: The endianess of the audio data.

@retval ISMD_SUCCESS : The audio data attributes we set successfully.
@retval ISMD_ERROR_INVALID_HANDLE : The handle specified is invalid.
@retval ISMD_ERROR_INVALID_PARAMETER : Invalid parameters specified.
*/
ismd_result_t
audio_io_hal_set_data_attributes(audio_io_hal_handle_t handle, int sample_rate, int sample_size, 
   int channel_count, audio_io_hal_endianness_t endianness);


/**
Set the audio data format. This call notfies the HAL of the 
expected data format it is to process or generate. 

@param[in] handle: Audio IO HAL handle to the context.
@param[in] format: Sampling rate of the audio data.

@retval ISMD_SUCCESS : The audio format we set successfully.
@retval ISMD_ERROR_INVALID_HANDLE : The handle specified is invalid.
@retval ISMD_ERROR_INVALID_PARAMETER : The format is invald.
*/
ismd_result_t
audio_io_hal_set_data_format(int handle, ismd_audio_format_t format);


/**
Set the IEC 60958 channel status information for the audio hardware
being used. This function is to be called for audio output hardware, 
tipically renders. This information is 40 bits. 

@param[in] handle: Audio IO HAL handle to the context.
@param[in] lsw: The least significant word of the 40 bits. 
@param[in] msb: The most significant btye of the 40 bits.

@retval ISMD_SUCCESS : The channel status was set successfully. 
@retval ISMD_ERROR_INVALID_HANDLE : The handle specified is invalid.
@retval ISMD_ERROR_INVALID_PARAMETER : The channel status information is invald.
*/
ismd_result_t 
audio_io_hal_set_channel_status(int handle, uint32_t lsw, uint8_t msb);


/**
Get the IEC 60958 channel status information for the audio hardware in use.

@param[in] handle: Audio IO HAL handle to the context.
@param[out] lsw: The least significant word of the 40 bits. 
@param[out] msb: The most significant btye of the 40 bits.

@retval ISMD_SUCCESS : Returned channel status bits successfully. 
@retval ISMD_ERROR_INVALID_HANDLE : The handle specified is invalid.
*/
ismd_result_t 
audio_io_hal_get_channel_status(int handle, uint32_t *lsw, uint8_t *msb);


#endif

