/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUD_HAL_CAPTURE_H_
#define _AUD_HAL_CAPTURE_H_

#include "ismd_global_defs.h"
#include "audio_hal_defs.h"
#include "audio_hal_common.h"
#include "audio_ce41xx_hal.h"
#include "ismd_core_protected.h"
#include "audio_ce42xx_hal.h"
#include "audio_ce53xx_hal.h"
#include "audio_ce31xx_hal.h"

ismd_result_t audio_hal_capture_init_context(
                        audio_hal_capture_context_t *capture_context,
                        void *caller_context,
                        os_devhandle_t *devh,
                        int hw_dev_id,
                        uint32_t mem_addr_phys,
                        void *mem_addr_virt,
                        size_t mem_size,
                        capture_callback_t callback_function,
                        int dma_burst_size,
                        int dma_xburst_size,
                        unsigned int  chunk_size_ticks,
                        ismd_clock_t clock,
                        bool bitclk_direction, 
                        bool msb_justified,
                        bool spdif_clock_update_rate);

void audio_hal_capture_deinit_context(
                        audio_hal_capture_context_t *capture_context);

ismd_result_t audio_hal_capture_start(
                        audio_hal_capture_context_t *capture_context);

ismd_result_t audio_hal_capture_stop(
                        audio_hal_capture_context_t* capture_context, bool shutdown);

ismd_result_t audio_hal_capture_reset(
                        audio_hal_capture_context_t* capture_context);

ismd_result_t audio_hal_capture_set_channel_configuration(
                        audio_hal_capture_context_t* capture_context, 
                        int ch_count);

ismd_result_t audio_hal_capture_set_bit_clock_divider(
                        audio_hal_capture_context_t* capture_context, 
                        unsigned int divider,
                        int sample_rate);

ismd_result_t audio_hal_capture_set_sample_size(
                        audio_hal_capture_context_t* capture_context, 
                        int sample_size,
                        unsigned int *sample_size_based_on_mem);


ismd_result_t audio_hal_capture_set_clk_direction(
                        audio_hal_capture_context_t *capture_context, 
                        bool bitclk_direction);

ismd_result_t audio_hal_capture_i2sc_set_clk_direction(
                        os_devhandle_t *devh, 
                        bool bitclk_direction);

ismd_result_t audio_hal_capture_set_alt_mode(
                        audio_hal_capture_context_t *capture_context, 
                        bool msb_justified);

ismd_result_t audio_hal_capture_set_spdif_clock_update_rate(
                        audio_hal_capture_context_t *capture_context,
                        bool spdif_clock_update_rate);

ismd_result_t audio_hal_capture_buffer_add(
                        audio_hal_capture_context_t *capture_context,
                        uint32_t buf_addr_phys,
                        void *buf_addr_virt,
                        size_t buf_size,
                        int buf_id);

void audio_hal_capture_handle_interrupt(unsigned int isrx_value);

void
audio_hal_capture_shutdown_cleanup(audio_hal_capture_context_t* capture_context);

void
audio_hal_capture_set_dma_burst_size(audio_hal_capture_context_t* capture_context, int dma_burst_size, int dma_xburst_size);

ismd_result_t 
audio_hal_capture_set_rxframe_size(audio_hal_capture_context_t* capture_context, unsigned int rxframe_size);

void 
audio_hal_capture_set_chunk_ticks(audio_hal_capture_context_t* capture_context, unsigned int chunk_ticks);

ismd_result_t 
audio_pvt_hal_reset_fifo(audio_hal_capture_context_t* capture_context, audio_rx_context_t rx_num);

void
audio_hal_capture_wr_swap_endianism(audio_hal_capture_context_t* capture_context, bool do_swap);

static inline bool
audio_hal_capture_check_dma_link_list_state(audio_hal_capture_context_t* capture_context)
{
   return (capture_context->first_node_added); 
}

ismd_result_t
audio_hal_capture_set_power_mode (os_devhandle_t *devh, audio_hal_power_management_mode_t power_mode);

ismd_result_t
audio_hal_capture_get_block_timestamp( 
                                    audio_hal_capture_context_t* capture_context, 
                                    ismd_time_t *capture_time, 
                                    bool clock_locked,
                                    bool is_primary);

ismd_result_t
audio_hal_capture_valid_hw_id(int hw_input_id);

ismd_result_t 
audio_hal_program_rx_interface(
                              audio_hal_capture_context_t* capture_context,
                              audio_hal_capture_params capture_params,
                              int hw_dev_id);

ismd_result_t 
audio_hal_fifo_reset_restore_rx_registers(
                              audio_hal_capture_context_t* capture_context,
                              bool bitclk_direction,
                              bool msb_justified,
                              bool spdif_clock_update_rate,                              
                              int hw_dev_id);

void
audio_hal_capture_init(void);

void
audio_hal_capture_deinit(void);

#endif //_AUD_HAL_CAPTURE_H_

