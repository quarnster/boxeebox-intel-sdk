
/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


/* GEN3 AUDIO HAL */

#ifndef _AUDIO_HAL_COMMON_C_
#define _AUDIO_HAL_COMMON_C_

#include "audio_hal_common.h"
#include "auto_eas/gen3_aud_io.h"
#include "intel_ce_device_ids.h"


#define STRING_MATCH 0
#define AUDIO_HAL_DSP0_FAST_PATH_ENABLE_BIT 11
#define AUDIO_HAL_DSP1_FAST_PATH_ENABLE_BIT 13
#define SOC_NORTHBRIDGE_PORT_IO_ARBITER 0x00
#define SOC_NORTHBRIDGE_PORT_IO_ARBITER_MEM_CTL_OFFSET 0x30


audio_hal_debug_t audio_hal_debug = AUDIO_HAL_DEBUG_ALL;
os_interrupt_t audio_io_interrupt = NULL;
os_irqlock_t   audio_hal_irq_lock;
extern pal_soc_info_t audio_soc_info;

/********** Private Function Declarations *****************/

static ismd_result_t
audio_pvt_hal_register_interrupt(audio_hal_dev_t *hal_devh);

static ismd_result_t 
audio_pvt_hal_io_reset_hw(audio_hal_dev_t *hal_devh);

static ismd_result_t 
audio_pvt_hal_io_clock_enable( audio_hal_dev_t *hal_devh, audio_io_state_t state);

static ismd_result_t 
audio_pvt_hal_io_reset(audio_hal_dev_t *hal_devh, audio_io_state_t state);

/****************************************************/

ismd_result_t audio_hal_init(os_devhandle_t *devh )
{
   ismd_result_t retStatus = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_hal_dev_t hal_devh;

   hal_devh.devh = devh;
   hal_devh.devName = "AUD_IO";
   hal_devh.svenModule = SVEN_module_GEN3_AUD_IO;
   hal_devh.svenUnit = 0;   

   DEVH_FUNC_ENTER(devh);

   /* enable device */
   if (os_pci_enable_device(CE_SOC_VENDOR_ID_INTEL, CE_SOC_DEVICE_ID_AUDIO_DSP0) != OSAL_SUCCESS) {
      OS_INFO("audio dsp0 enable pci device failed!\n");
   }
   if (os_pci_enable_device(CE_SOC_VENDOR_ID_INTEL, CE_SOC_DEVICE_ID_AUDIO_DSP1) != OSAL_SUCCESS) {
      OS_INFO("audio dsp1 enable pci device failed!\n");
   }
   if (os_pci_enable_device(CE_SOC_VENDOR_ID_INTEL, CE_SOC_DEVICE_ID_AUDIO_IF) != OSAL_SUCCESS) {
      OS_INFO("audio io enable pci device failed!\n");
   }

   /*** Initialize the render HW ***/
   if( (retStatus = audio_pvt_hal_io_reset_hw(&(hal_devh))) != ISMD_SUCCESS){
      OS_INFO("audio_hal_reset_io_hw failed!\n");
   }
   /*Register interrupt*/
  else if((retStatus = audio_pvt_hal_register_interrupt(&(hal_devh))) != ISMD_SUCCESS)
  {
     OS_INFO("audio_pvt_hal_render_register_interrupt failed!\n");
  }

   else {
      os_irqlock_init(&audio_hal_irq_lock);
      retStatus = ISMD_SUCCESS;
   }

   DEVH_FUNC_EXIT(devh);
   return retStatus;
}

ismd_result_t audio_hal_deinit(os_devhandle_t *devh )
{
   ismd_result_t retStatus = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_hal_dev_t hal_devh;

   AUDIO_ENTER(devh);

   hal_devh.devh = devh;
   hal_devh.devName = "AUD_IO";
   hal_devh.svenModule = SVEN_module_GEN3_AUD_IO;
   hal_devh.svenUnit = 0;   

   /** Reset HW **/
   if( (retStatus = audio_pvt_hal_io_reset_hw(&(hal_devh))) != ISMD_SUCCESS){
      OS_INFO("audio_hal_reset_io_hw failed!\n");
   }

   /** Release AUDIO IO interrupt **/
   os_release_interrupt(audio_io_interrupt);
   audio_io_interrupt = NULL;

   os_irqlock_destroy(&audio_hal_irq_lock);

   return retStatus;

   AUDIO_EXIT(devh);
}

ismd_result_t audio_hal_dma_reset(audio_hal_dev_t *hal_devh, audio_dma_context_t dma)
{
    ismd_result_t retStatus=ISMD_SUCCESS;
    DEVH_FUNC_ENTER(hal_devh->devh);

   switch(dma)
   {  
      case AUDIO_DMA_CONTEXT0:
      case AUDIO_DMA_CONTEXT1:
      case AUDIO_DMA_CONTEXT2:
      case AUDIO_DMA_CONTEXT3:
         WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE,  AUDIO_HAL_REG_CLEAR);
         break;
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }

   goto end;
error:
    //Error handler

end:
    //Clean up and exit code

    DEVH_FUNC_EXIT(hal_devh->devh);
    return retStatus;
}

/*
ismd_result_t audio_hal_dma_poll_complete(audio_hal_dev_t *hal_devh, audio_dma_context_t dma, uint32_t timeout)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   int32_t bmsk_src, src;

   AUDIO_ENTER(hal_devh->devh);

   switch(dma)
   {  
      case AUDIO_DMA_CONTEXT0:
      case AUDIO_DMA_CONTEXT1:
      case AUDIO_DMA_CONTEXT2:
      case AUDIO_DMA_CONTEXT3:
         bmsk_src = BMSK_AUD_IO_ISRX_DMA0_SRC << (dma<<1);
         break;
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }

   retStatus = ISMD_SUCCESS;
   src = bmsk_src & READ_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX);
   while(bmsk_src != src)
   {
      os_sleep(1);     
      ++retStatus;
      if(retStatus>timeout) 
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus)
      src = bmsk_src & READ_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX);
   }  
   retStatus=ISMD_SUCCESS;

   goto end;
error:
   //Error handler

end:
   //Clean up and exit code

   AUDIO_EXIT(hal_devh->devh);
   return retStatus;
}*/

ismd_result_t 
audio_hal_dma_flush(audio_hal_dev_t *hal_devh, audio_dma_context_t dma)
{
      ismd_result_t retStatus=ISMD_SUCCESS;
      int32_t dmaStartAddr;
      
      AUDIO_ENTER(hal_devh->devh);

      switch(dma)
      {
            case AUDIO_DMA_CONTEXT0:
            case AUDIO_DMA_CONTEXT1:
            case AUDIO_DMA_CONTEXT2:
            case AUDIO_DMA_CONTEXT3:
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_READ_EN, AUDIO_HAL_BIT_CLEAR);
                  dmaStartAddr = READ_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_SRCDMA_BOT);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_SRCDMA_START, dmaStartAddr);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_SRCDMA_STOP, dmaStartAddr);
                  WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_READ_EN, AUDIO_HAL_BIT_SET);
                  break;                              
            default:
                  retStatus = ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
      }

      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      AUDIO_EXIT(hal_devh->devh);
      return retStatus;
}

static ismd_result_t 
audio_pvt_hal_io_reset_hw(audio_hal_dev_t *hal_devh){

   ismd_result_t retStatus = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   DEVH_FUNC_ENTER(hal_devh->devh);

   /*** Initialize the render HW ***/
   if( (retStatus = audio_pvt_hal_io_clock_enable(hal_devh, AUDIO_IO_STATE_RELEASE)) != ISMD_SUCCESS){
      OS_INFO("audio_pvt_hal_io_clock_enable failed!\n");
   }
   else if((retStatus = audio_pvt_hal_io_reset(hal_devh, AUDIO_IO_STATE_RESET)) != ISMD_SUCCESS){
      OS_INFO("audio_pvt_hal_io_reset failed!\n");
   }
   else if(( retStatus = audio_pvt_hal_io_reset(hal_devh, AUDIO_IO_STATE_RELEASE) ) != ISMD_SUCCESS){
      OS_INFO("audio_pvt_hal_io_reset failed!\n");
   }
   /*Reset all DMA contexts*/
   else if((retStatus = audio_hal_dma_reset(hal_devh, AUDIO_DMA_CONTEXT0)) != ISMD_SUCCESS){
      OS_INFO("audio_pvt_hal_dma_reset failed!\n");
   }
   else if((retStatus = audio_hal_dma_reset(hal_devh, AUDIO_DMA_CONTEXT1)) != ISMD_SUCCESS){
      OS_INFO("audio_pvt_hal_dma_reset failed!\n");
   }
   else if((retStatus = audio_hal_dma_reset(hal_devh, AUDIO_DMA_CONTEXT2)) != ISMD_SUCCESS){
      OS_INFO("audio_pvt_hal_dma_reset failed!\n");
   }
   else if((retStatus = audio_hal_dma_reset(hal_devh, AUDIO_DMA_CONTEXT3)) != ISMD_SUCCESS){
      OS_INFO("audio_pvt_hal_dma_reset failed!\n");
   }
   /*Reset all TX Contexts*/
   else if((retStatus = audio_hal_render_reset_tx_channels(hal_devh)) != ISMD_SUCCESS){
      OS_INFO("hal_render_reset_tx_channels failed!\n");
   }
   /*Reset all RX Contexts*/

   DEVH_FUNC_EXIT(hal_devh->devh);

   return retStatus;
}

static ismd_result_t audio_pvt_hal_io_clock_enable(audio_hal_dev_t *hal_devh, audio_io_state_t state)
{
    ismd_result_t retStatus=ISMD_SUCCESS;
    AUDIO_ENTER(hal_devh->devh);

    switch(state)
    {
        case AUDIO_IO_STATE_RESET:
        case AUDIO_IO_STATE_RELEASE:
            break;
        default:
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
    }

    WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_CSR_CLKEN, state);

    goto end;
error:
    //Error handler

end:
    //Clean up and exit code

    AUDIO_EXIT(hal_devh->devh);
    return retStatus;
}

static ismd_result_t 
audio_pvt_hal_io_reset(audio_hal_dev_t *hal_devh, audio_io_state_t state)
{
    ismd_result_t retStatus=ISMD_SUCCESS;
    AUDIO_ENTER(hal_devh->devh);

    switch(state)
    {
        case AUDIO_IO_STATE_RESET:
        case AUDIO_IO_STATE_RELEASE:
            break;
        default:
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
    }

    WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_CSR_SWRST, state);

    goto end;
error:
    //Error handler

end:
    //Clean up and exit code

    AUDIO_EXIT(hal_devh->devh);
    return retStatus;
}


static ismd_result_t
audio_pvt_hal_register_interrupt(audio_hal_dev_t *hal_devh)
{
   pal_result_t pal_ret;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   pal_info_t pal_info_audio_io;
   pal_info_t *pal_info_audio_io_ptr = &pal_info_audio_io;

   AUDIO_ENTER(hal_devh->devh);

   /*If IO interrupt is registered, do nothing */
   if(audio_io_interrupt != NULL){
      result = ISMD_SUCCESS;
   }else{

      /*Make sure all interrupts are disabled in IMRX*/
      WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_IMRX, 0x00000000);

      /*Make sure ISRX is clear*/
      WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX, ISRX_CLEAR_INTERRUPTS);
              
      pal_ret = pal_get_base_and_irq ( AUDIO_0, &pal_info_audio_io_ptr );
      if ( pal_ret == PAL_SUCCESS )
      {
         audio_io_interrupt = os_acquire_interrupt(pal_info_audio_io_ptr->irq_num, AUDIO_0, "Audio_Rend_ISR", audio_hal_handle_io_interrupt, (void *)hal_devh->devh);
         OS_ASSERT(audio_io_interrupt);

         result = ISMD_SUCCESS;
      }
      else {
         result = ISMD_ERROR_OPERATION_FAILED;
      }
   }
   AUDIO_EXIT(hal_devh->devh);
   return result;
}

static ismd_result_t
audio_pvt_hal_msgbus_read(int port, uint32_t reg, uint32_t* val)
{
   ismd_result_t ret = ISMD_SUCCESS;
   os_pci_dev_t pci_dev;

   OS_ASSERT(val != NULL);
   
   if ( os_pci_device_from_address(&pci_dev, 0, 0, 0) != OSAL_SUCCESS ) {
      OS_INFO( "%s: Unable to access PCI bus 0 device 0 function 0.\n",__FUNCTION__ );
      ret = ISMD_ERROR_OPERATION_FAILED;
   }
   else if ( os_pci_write_config_32(pci_dev, 0xd0, 0xd00000f0| (port<<16) | (reg<<8)) != OSAL_SUCCESS ) {
      ret = ISMD_ERROR_OPERATION_FAILED;      
   }
   else if ( os_pci_read_config_32(pci_dev, 0xd4, val) != OSAL_SUCCESS ) {
      ret = ISMD_ERROR_OPERATION_FAILED;      
   }

   return ret;
}

static ismd_result_t
audio_pvt_hal_msgbus_write(int port, uint32_t reg, uint32_t val)
{
   ismd_result_t ret = ISMD_SUCCESS;
   os_pci_dev_t pci_dev;

   if ( os_pci_device_from_address(&pci_dev, 0, 0, 0) != OSAL_SUCCESS ) {
      OS_INFO( "%s: Unable to access PCI bus 0 device 0 function 0.\n",__FUNCTION__ );
      ret = ISMD_ERROR_OPERATION_FAILED;
   }
   else if ( os_pci_write_config_32(pci_dev, 0xd4, val) != OSAL_SUCCESS ) {
      ret = ISMD_ERROR_OPERATION_FAILED;      
   }
   else if ( os_pci_write_config_32(pci_dev, 0xd0, 0xe00000f0|(port<<16) |(reg<<8)) != OSAL_SUCCESS ) {
      ret = ISMD_ERROR_OPERATION_FAILED;      
   }

   return ret;
}


void
audio_hal_handle_io_interrupt(void *data)
{
   unsigned int isrx_value = 0;
   os_devhandle_t *devh = (os_devhandle_t *) data;

   /* Read the Interrupt Status Register */
   isrx_value = READ_IO(devh, BITFIELD_AUD_IO_ISRX); 

   /*Send the ISRX value to render HAL*/
   audio_hal_render_handle_interrupt(isrx_value);

   /*Send the ISRX value to capture HAL*/
   audio_hal_capture_handle_interrupt(isrx_value);

   return;
}


ismd_result_t audio_hal_write_vsymbol(audio_hal_dev_t *device, ...)
{ // SYMDEF signiture: int reg, int32_t lsb, int32_t width, int32_t mask, int32_t val
      va_list args;
      ismd_result_t retStatus=ISMD_SUCCESS;
      int i, reg, regx=0;
      int32_t lsb,  width,  mask,  val;
      int32_t maskx=0,  valx=0;

      AUDIO_ENTER(device->devh);
      va_start(args, device);
      for(i=0; i<=ENTIRE_REGISTER;++i)
      {
            // get the SYMDEF arguments
            reg = va_arg(args, int);                  
            lsb = va_arg(args, int32_t);
            width = va_arg(args, int32_t);
            mask = va_arg(args, int32_t);
            val = va_arg(args, int32_t);
            if(!(reg || lsb || width || mask))
            {//BITFIELD_NULL_TERM() found
                  break;
            }
            if(i)
            {// if not the first time in the loop(i)
                  if(regx != reg)
                  {
                        AUDIO_HAL_DEBUG(AUDIO_HAL_DEBUG_ALL, "error: [%s:%d] %s different reg-offsets in SYMDEF parameters not allowed 0x%08X : 0x%08X\n", __FILE__ , __LINE__, __FUNCTION__, regx, reg);
                        DEVH_WARN(device->devh, "different reg-offsets in SYMDEF parameters not allowed");
                        retStatus=ISMD_ERROR_INVALID_PARAMETER;
                        VERIFY_HAL_RETSTATUS(device->devh, retStatus);
                  }
            }
            else
            {// first time in loop(i)
                  regx = reg;
            }
            maskx |= mask;
            valx |= (mask & (val << lsb));            
      };
      if(i>ENTIRE_REGISTER)
      {
            AUDIO_HAL_DEBUG(AUDIO_HAL_DEBUG_ALL, "error: [%s:%d] %s too many SYMDEF parameters %d (max = %d)\n", __FILE__ , __LINE__, __FUNCTION__, i, ENTIRE_REGISTER);
            retStatus=ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_HAL_RETSTATUS(device->devh, retStatus);
      }

      if(!maskx)
      {//BITFIELD_NULL_TERM() found nothing to do
            AUDIO_HAL_DEBUG(AUDIO_HAL_DEBUG_ALL, "error: [%s:%d] %s recieved an invalid or empty SYMDEF parameter\n", __FILE__ , __LINE__, __FUNCTION__);
            retStatus=ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_HAL_RETSTATUS(device->devh, retStatus);
      }

      //finally write the thing
      devh_SetMaskedReg32(device->devh, regx, ~maskx, maskx & valx);

      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      va_end(args);
      AUDIO_EXIT(device->devh);
      return retStatus;
}


ismd_result_t audio_hal_read_vsymbol(audio_hal_dev_t *device, ...)
{ // SYMDEF signiture: int reg, int32_t lsb, int32_t width, int32_t mask, int32_t *val
      va_list args;
      ismd_result_t retStatus=ISMD_SUCCESS;
      int i, reg, regx=0;
      int32_t lsb,  width,  mask,  *val;
      int32_t valx=0;

      AUDIO_ENTER(device->devh);
      va_start(args, device);

      for(i=0; i<=ENTIRE_REGISTER;++i)
      {
            // get the SYMDEF arguments
            reg = va_arg(args, int);                  
            lsb = va_arg(args, int32_t);
            width = va_arg(args, int32_t);
            mask = va_arg(args, int32_t);
            val = va_arg(args, int32_t*);
            if(!(reg || lsb || width || mask))
            {//BITFIELD_NULL_TERM() found
                  break;
            }
            if(!i)
            {// first time in loop(i) - once only
                  regx = reg;
                  valx = devh_ReadReg32(device->devh, regx); 
            }
            else
            {// if not the first time in the loop(i)
                  if(regx != reg)
                  {
                        AUDIO_HAL_DEBUG(AUDIO_HAL_DEBUG_ALL, "error: [%s:%d] %s different reg-offsets in SYMDEF parameters not allowed %d : %d\n", __FILE__ , __LINE__, __FUNCTION__, regx, reg);
                        retStatus=ISMD_ERROR_INVALID_PARAMETER;
                        VERIFY_HAL_RETSTATUS(device->devh, retStatus);
                  }
            }
            if(!mask)
            {//BITFIELD_NULL_TERM() found nothing to do
                  AUDIO_HAL_DEBUG(AUDIO_HAL_DEBUG_ALL, "error: [%s:%d] %s recieved an invalid or empty SYMDEF parameter\n", __FILE__ , __LINE__, __FUNCTION__);
                  retStatus=ISMD_ERROR_INVALID_PARAMETER;
                  VERIFY_HAL_RETSTATUS(device->devh, retStatus);
            }

            *val = (valx & mask) >> lsb;

      };
      if(i>ENTIRE_REGISTER)
      {
            AUDIO_HAL_DEBUG(AUDIO_HAL_DEBUG_ALL, "error: [%s:%d] %s too many SYMDEF parameters %d (max = %d)\n", __FILE__ , __LINE__, __FUNCTION__, i, ENTIRE_REGISTER);
            retStatus=ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_HAL_RETSTATUS(device->devh, retStatus);
      }

      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      va_end(args);
      AUDIO_EXIT(device->devh);
      return retStatus;
}

ismd_result_t audio_hal_create_reg_vsymbol(audio_hal_dev_t *hal_devh, int32_t *new_register, ...)
{ // SYMDEF signiture: int reg, int32_t lsb, int32_t width, int32_t mask, int32_t val
      va_list args;
      ismd_result_t retStatus=ISMD_SUCCESS;
      int i, reg, regx=0;
      int32_t lsb,  width,  mask,  val;
      int32_t maskx=0,  valx=0;

      va_start(args, new_register);

      retStatus = (new_register==NULL?ISMD_ERROR_INVALID_PARAMETER:ISMD_SUCCESS);

      VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);

      for(i=0; i<=ENTIRE_REGISTER;++i)
      {
         // get the SYMDEF arguments
         reg = va_arg(args, int);                  
         lsb = va_arg(args, int32_t);
         width = va_arg(args, int32_t);
         mask = va_arg(args, int32_t);
         val = va_arg(args, int32_t);
         if(!(reg || lsb || width || mask))
         {//BITFIELD_NULL_TERM() found
               break;
         }
         if(i)
         {// if not the first time in the loop(i)
             
             //check different reg-offsets in SYMDEF parameters not allowed
             retStatus = (regx!=reg?ISMD_ERROR_INVALID_PARAMETER:ISMD_SUCCESS);
             VERIFY_HAL_RETSTATUS(hal_devh->devh, (retStatus));
         }
         else
         {// first time in loop(i)
               regx = reg;
         }
         maskx |= mask;
         valx |= (mask & (val << lsb));            
      };

      if(i>ENTIRE_REGISTER)
      {
         //check too many SYMDEF parameters
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
      }

      if(!maskx)
      {//BITFIELD_NULL_TERM() found nothing to do
         //check recieved an invalid or empty SYMDEF parameter
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
      }

      //finally return the thing
      *new_register = maskx & valx;

      goto end;
error:      
      //Error handler      

end:
      //Clean up and exit code
      
      va_end(args);
      return retStatus;
}

ismd_result_t  audio_hal_clear_dma_status_register(audio_hal_dev_t *hal_devh, audio_dma_context_t dma)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   DEVH_FUNC_ENTER(hal_devh->devh);

   switch(dma)
   {  //Dont use DMA_OFFSET() - this is ISRX register
      case AUDIO_DMA_CONTEXT0:
         WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX_DMA0_SRC, AUDIO_HAL_BIT_SET);
         WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX_DMA0_DES, AUDIO_HAL_BIT_SET);
         break;
      case AUDIO_DMA_CONTEXT1:
         WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX_DMA1_SRC, AUDIO_HAL_BIT_SET);
         WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX_DMA1_DES, AUDIO_HAL_BIT_SET);
         break;
      case AUDIO_DMA_CONTEXT2:
         WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX_DMA2_SRC, AUDIO_HAL_BIT_SET);
         WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX_DMA2_DES, AUDIO_HAL_BIT_SET);
         break;
      case AUDIO_DMA_CONTEXT3:
         WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX_DMA3_SRC, AUDIO_HAL_BIT_SET);
         WRITE_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX_DMA3_DES, AUDIO_HAL_BIT_SET);
         break;
      default:
      retStatus = ISMD_ERROR_INVALID_PARAMETER;
      VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }  

   goto end;
error:   
   //Error handler   

end:
   //Clean up and exit code
   
   DEVH_FUNC_EXIT(hal_devh->devh);
   return retStatus;
}

ismd_result_t  audio_hal_clear_dma_flags(audio_hal_dev_t *hal_devh, audio_dma_context_t dma)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   AUDIO_ENTER(hal_devh->devh);

   switch(dma)
   {
      case AUDIO_DMA_CONTEXT0:
      case AUDIO_DMA_CONTEXT1:
      case AUDIO_DMA_CONTEXT2:
      case AUDIO_DMA_CONTEXT3:
         WRITE_IO(hal_devh->devh, DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE, AUDIO_HAL_REG_CLEAR);
         break;               
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }

   
   goto end;
error:   
   //Error handler   

end:
   //Clean up and exit code
   
   DEVH_FUNC_EXIT(hal_devh->devh);
   return retStatus;
}

ismd_result_t  audio_hal_set_dma_flags(audio_hal_dev_t *hal_devh, audio_dma_context_t dma)   
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   AUDIO_ENTER(hal_devh->devh);

   switch(dma)
   {
      case AUDIO_DMA_CONTEXT0:
      case AUDIO_DMA_CONTEXT1:
      case AUDIO_DMA_CONTEXT2:
      case AUDIO_DMA_CONTEXT3:
         retStatus = WRITE_IO_VA
         (
            *hal_devh,
            DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_BURST_SZ,      DEFAULT_RENDER_DMA_BURST_SIZE,
            DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_INT,       AUDIO_HAL_BIT_SET,
            DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_INT,       AUDIO_HAL_BIT_SET,
            DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_SRC_ADDR_MODE, AUDIO_HAL_DMA_ADDR_MODE_CIRCULAR,
            DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_DST_ADDR_MODE, AUDIO_HAL_DMA_ADDR_MODE_FIXED_CONTINOUS,
            DMA_OFFSET(dma)+BITFIELD_AUD_IO_DMA0_FLAGS_MODE_READ_EN,       AUDIO_HAL_BIT_SET,
            BITFIELD_NULL_TERM()            
         );
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
         break;               
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }
   VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   
   goto end;
error:   

end:
   //Clean up and exit code
   
   AUDIO_EXIT(hal_devh->devh);
   return retStatus;
}

ismd_result_t audio_hal_poll_dma_complete(audio_hal_dev_t *hal_devh, audio_dma_context_t dma, uint32_t timeout)
{
   ismd_result_t retStatus=ISMD_SUCCESS;
   int32_t bmsk_src, src;

   AUDIO_ENTER(hal_devh->devh);

   switch(dma)
   {  
      case AUDIO_DMA_CONTEXT0:
      case AUDIO_DMA_CONTEXT1:
      case AUDIO_DMA_CONTEXT2:
      case AUDIO_DMA_CONTEXT3:
         bmsk_src = BMSK_AUD_IO_ISRX_DMA0_SRC << (dma<<1);
         break;
      default:
         retStatus = ISMD_ERROR_INVALID_PARAMETER;
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus);
   }

   retStatus = ISMD_SUCCESS;
   src = bmsk_src & READ_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX);
   while(bmsk_src != src)
   {
      os_sleep(1);     
      ++retStatus;
      if(retStatus>timeout) 
         VERIFY_HAL_RETSTATUS(hal_devh->devh, retStatus)
      src = bmsk_src & READ_IO(hal_devh->devh, BITFIELD_AUD_IO_ISRX);
   }  
   retStatus=ISMD_SUCCESS;

   goto end;
error:
   //Error handler

end:
   //Clean up and exit code

   AUDIO_EXIT(hal_devh->devh);
   return retStatus;
}

ismd_result_t audio_hal_set_dsp_memory_path(audio_dsp_memory_path_t *dsp_mem_path)
{
   // assume fast_path was enabled
   ismd_result_t ret = ISMD_SUCCESS;
   uint32_t mem_path_value = 0;
   uint32_t new_path_value = 0;
   char *msg;

   /*Non-Coherent (fast) path is NOT supported on CE3100.*/
   if(audio_soc_info.name == SOC_NAME_CE3100){
      *dsp_mem_path = AUDIO_DSP_MEM_PATH_COHERENT;
   }

   if((audio_soc_info.name == SOC_NAME_CE3100) || (audio_soc_info.name == SOC_NAME_CE4100) || (audio_soc_info.name == SOC_NAME_CE4200)){
      /*Read the current setting.*/
      if ((ret = audio_pvt_hal_msgbus_read(SOC_NORTHBRIDGE_PORT_IO_ARBITER, SOC_NORTHBRIDGE_PORT_IO_ARBITER_MEM_CTL_OFFSET, &mem_path_value)) != ISMD_SUCCESS) {
         OS_INFO("Audio unable to read msgbus port:0, reg:0x30 \n");
      }
      else {
         /*Check for the coherent path*/
         if(*dsp_mem_path == AUDIO_DSP_MEM_PATH_COHERENT) {
            new_path_value = mem_path_value & ~(1 << AUDIO_HAL_DSP0_FAST_PATH_ENABLE_BIT);
            new_path_value &= ~(1 << AUDIO_HAL_DSP1_FAST_PATH_ENABLE_BIT); 
            msg = "coherent";
         }
         /*Default is non coherent (fast) path*/
         else{
            *dsp_mem_path = AUDIO_DSP_MEM_PATH_NON_COHERENT;
            new_path_value = mem_path_value | (1 << AUDIO_HAL_DSP0_FAST_PATH_ENABLE_BIT);
            new_path_value |= (1 << AUDIO_HAL_DSP1_FAST_PATH_ENABLE_BIT); 
            msg = "non-coherent (fast)";
         }

         /*If the new value is different than what is set, write back the new value.*/
         if(new_path_value != mem_path_value) {
            ret = audio_pvt_hal_msgbus_write(SOC_NORTHBRIDGE_PORT_IO_ARBITER, SOC_NORTHBRIDGE_PORT_IO_ARBITER_MEM_CTL_OFFSET, new_path_value);
         }

         OS_PRINT("\nAudio DSP memory path is %s.\n", msg);
      }
   }
   else {
      OS_PRINT("\nAUDIO: Warning: SoC method for setting DSP memory path not defined and the status is unknown!!\n");
      //TODO: Need method for CE5300, currently hanging if we attempt.
   }
   
   return ret;
}




/**
Utility Functions.
**/
const char *osal_result_to_string(const int osalResult)
{
   const char *ch="";
   switch(osalResult)
   {
      case OSAL_ERROR: ch="OSAL_ERROR"; break;
      case OSAL_SUCCESS: ch="OSAL_SUCCESS"; break;
      case OSAL_INVALID_STATE: ch="OSAL_INVALID_STATE"; break;
      case OSAL_INVALID_HANDLE: ch="OSAL_INVALID_HANDLE"; break;
      case OSAL_INVALID_PARAM: ch="OSAL_INVALID_PARAM"; break;
      case OSAL_NOT_IMPLEMENTED: ch="OSAL_NOT_IMPLEMENTED"; break;
      case OSAL_INVALID_OPERATION: ch="OSAL_INVALID_OPERATION"; break;
      case OSAL_INVALID_SETTING: ch="OSAL_INVALID_SETTING"; break;
      case OSAL_INSUFFICIENT_RESOURCES: ch="OSAL_INSUFFICIENT_RESOURCES"; break;
      case OSAL_INSUFFICIENT_MEMORY: ch="OSAL_INSUFFICIENT_MEMORY"; break;
      case OSAL_INVALID_PERMISSION: ch="OSAL_INVALID_PERMISSION"; break;
      case OSAL_COMPLETED: ch=""; break;
      case OSAL_NOT_DONE: ch=""; break;
      case OSAL_PENDING: ch="OSAL_PENDING"; break;
      case OSAL_TIMEOUT: ch="OSAL_TIMEOUT"; break;
      case OSAL_CANCELED: ch="OSAL_CANCELED"; break;
      case OSAL_REJECT: ch="OSAL_REJECT"; break;
      case OSAL_OVERRUN: ch="OSAL_OVERRUN"; break;
      case OSAL_NOT_FOUND: ch="OSAL_NOT_FOUND"; break;
      case OSAL_UNAVAILABLE: ch="OSAL_UNAVAILABLE"; break;
      case OSAL_BUSY: ch="OSAL_BUSY"; break;
      case OSAL_DISCONNECT: ch="OSAL_DISCONNECT"; break;
      case OSAL_DUPLICATE: ch="OSAL_DUPLICATE"; break;
      case OSAL_STATUS_COUNT: ch="OSAL_STATUS_COUNT"; break;
      default: ch="UNKNOWN ERROR";      
   }
   return ch;
}

const char *ismd_result_to_string(const int ismdResult)
{
   const char *ch="";
   switch(ismdResult)
   {
      case ISMD_SUCCESS:                        ch="ISMD_SUCCESS"; break;
      case ISMD_ERROR_FEATURE_NOT_IMPLEMENTED:  ch="ISMD_ERROR_FEATURE_NOT_IMPLEMENTED"; break;
      case ISMD_ERROR_FEATURE_NOT_SUPPORTED:    ch="ISMD_ERROR_FEATURE_NOT_SUPPORTED"; break;
      case ISMD_ERROR_INVALID_VERBOSITY_LEVEL:  ch="ISMD_ERROR_INVALID_VERBOSITY_LEVEL"; break;
      case ISMD_ERROR_INVALID_PARAMETER:        ch="ISMD_ERROR_INVALID_PARAMETER"; break;
      case ISMD_ERROR_INVALID_HANDLE:           ch="ISMD_ERROR_INVALID_HANDLE"; break;
      case ISMD_ERROR_NO_RESOURCES:             ch="ISMD_ERROR_NO_RESOURCES"; break;
      case ISMD_ERROR_INVALID_RESOURCE:         ch="ISMD_ERROR_INVALID_RESOURCE"; break;
      case ISMD_ERROR_INVALID_QUEUE_TYPE:       ch="ISMD_ERROR_INVALID_QUEUE_TYPE"; break;
      case ISMD_ERROR_NO_DATA_AVAILABLE:        ch="ISMD_ERROR_NO_DATA_AVAILABLE"; break;
      case ISMD_ERROR_NO_SPACE_AVAILABLE:       ch="ISMD_ERROR_NO_SPACE_AVAILABLE"; break;
      case ISMD_ERROR_TIMEOUT:                  ch="ISMD_ERROR_TIMEOUT"; break;
      case ISMD_ERROR_EVENT_BUSY:               ch="ISMD_ERROR_EVENT_BUSY"; break;
      case ISMD_ERROR_OBJECT_DELETED:           ch="ISMD_ERROR_OBJECT_DELETED"; break;
      case ISMD_ERROR_ALREADY_INITIALIZED:      ch="ISMD_ERROR_ALREADY_INITIALIZED"; break;
      case ISMD_ERROR_IOCTL_FAILED:             ch="ISMD_ERROR_IOCTL_FAILED"; break;
      case ISMD_ERROR_INVALID_BUFFER_TYPE:      ch="ISMD_ERROR_INVALID_BUFFER_TYPE"; break;
      case ISMD_ERROR_INVALID_FRAME_TYPE:       ch="ISMD_ERROR_INVALID_FRAME_TYPE"; break;
      case ISMD_ERROR_QUEUE_BUSY:               ch="ISMD_ERROR_QUEUE_BUSY"; break;
      case ISMD_ERROR_NOT_FOUND:                ch="ISMD_ERROR_NOT_FOUND"; break;
      case ISMD_ERROR_OPERATION_FAILED:         ch="ISMD_ERROR_OPERATION_FAILED"; break;
      case ISMD_ERROR_PORT_BUSY:                ch="ISMD_ERROR_PORT_BUSY"; break;
      case ISMD_ERROR_NULL_POINTER:             ch="ISMD_ERROR_NULL_POINTER"; break;
      case ISMD_ERROR_INVALID_REQUEST:          ch="ISMD_ERROR_INVALID_REQUEST"; break;
      case ISMD_ERROR_UNSPECIFIED:              ch="ISMD_ERROR_UNSPECIFIED"; break;
      default:                                  ch="UNKNOWN ERROR";  
   }
   return ch;
}

#endif //_GEN3_AUD_HAL_PVT_DEVH_C

