/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_hal_capture.h"
#if 0
#include "iosf.h"

static ismd_result_t   
audio_pvt_ce53xx_hal_set_pll_configuration_mode(audio_pll_configuration *configure_mode_ptr)
{
   uint32_t bus_id = 0;
   iosf_result_t iosf_result;
   ismd_result_t result = ISMD_SUCCESS;
   iosf_handle iosf_h;
   int32_t i;

   if((iosf_result = iosf_open(bus_id, &iosf_h)) == IOSF_OK){
      // Turn off PLL by setting CP unit's PLL_RESET_REGISTER[APLL_VCO_RESET] and PLL_RESET_REGISTER[APLL_DIV_RESET] to a 1
      if((iosf_result = iosf_modify(iosf_h, IOSF_PORT_CPUNIT, PLL_RESET_REGISTER_OFFSET, PLL_RESET_REGISTER_APLL_VCO_DIV_RESET_MASK, 0x30)) != IOSF_OK){
         OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "iosf_modify failed", iosf_result);
      }
      else {
         //Configure the APLL for the desired mode of operation by programming registers via IOSF SB inside the APLL
         for(i=0; i<APLL_MAX_CONFIG_REGS; i++){
            if((iosf_result = iosf_write32(iosf_h, IOSF_PORT_APLL, i, configure_mode_ptr->apll_cr[i])) != IOSF_OK){
               OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "iosf_write32 failed", iosf_result);
               break;
            }
         }
      }

      if(iosf_result == IOSF_OK){
         // enforce the new configuration
         if((iosf_result = iosf_modify(iosf_h, IOSF_PORT_APLL, APLL_CR0_OFFSET, APLL_CR0_CHANGE_CONFIGURATION_MASK, 1)) != IOSF_OK){
            OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "iosf_modify failed", iosf_result);
         }
         //Set CP Unit's PLL_RESET_REGISTER[APLL_VCO_RESET] to a 0
         else if((iosf_result = iosf_modify(iosf_h, IOSF_PORT_CPUNIT, PLL_RESET_REGISTER_OFFSET, PLL_RESET_REGISTER_APLL_VCO_RESET_MASK, 0)) != IOSF_OK){
            OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "iosf_modify failed", iosf_result);
         }
      }
      
      if(iosf_result == IOSF_OK){
         //Wait for APLL to relock.  
         os_sleep(1);
         
         // Set CP Unit's PLL_RESET_REGISTER[APLL_DIV_RESET] to a 0
         if((iosf_result = iosf_modify(iosf_h, IOSF_PORT_CPUNIT, PLL_RESET_REGISTER_OFFSET, PLL_RESET_REGISTER_APLL_DIV_RESET_MASK, 0)) != IOSF_OK){
            OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "iosf_modify failed", iosf_result);
         }
      }
      
      if((iosf_result = iosf_close(iosf_h)) != IOSF_OK){
         OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "iosf_close failed", iosf_result);
      }
      
   }
   else {
      OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "iosf_open failed", iosf_result);
   }

   if(iosf_result != IOSF_OK){
      result = ISMD_ERROR_OPERATION_FAILED;
   }
}
#else
static ismd_result_t   
audio_pvt_ce53xx_hal_set_pll_configuration_mode(audio_pll_configuration *configure_mode_ptr)
{
   (void)configure_mode_ptr;
   return ISMD_SUCCESS;
}
#endif

static void   
audio_pvt_ce53xx_hal_get_pll_mode_configuration (audio_pll_configuration *configure_mode_ptr, uint32_t r0, uint32_t r1, uint32_t r2, 
                                                      uint32_t r3, uint32_t r4, uint32_t r5, uint32_t r6, uint32_t r7)
{
   configure_mode_ptr->apll_cr[0] = r0;
   configure_mode_ptr->apll_cr[1] = r1;
   configure_mode_ptr->apll_cr[2] = r2;
   configure_mode_ptr->apll_cr[3] = r3;
   configure_mode_ptr->apll_cr[4] = r4;
   configure_mode_ptr->apll_cr[5] = r5;
   configure_mode_ptr->apll_cr[6] = r6;
   configure_mode_ptr->apll_cr[7] = r7;
}


ismd_result_t 
audio_ce53xx_hal_get_pll_mode_configuration(audio_hal_pll_mode_t apll_mode, audio_pll_configuration *configure_mode_ptr)
{
   ismd_result_t result = ISMD_SUCCESS;

   switch(apll_mode){
      case AUDIO_HAL_PLL_MODE1:
         audio_pvt_ce53xx_hal_get_pll_mode_configuration(configure_mode_ptr, APLL_MODE1_CR0, APLL_MODE1_CR1, APLL_MODE1_CR2, APLL_MODE1_CR3,
                                                      APLL_MODE1_CR4, APLL_MODE1_CR5, APLL_MODE1_CR6, APLL_MODE1_CR7);
         break;
      case AUDIO_HAL_PLL_MODE4:
         audio_pvt_ce53xx_hal_get_pll_mode_configuration(configure_mode_ptr, APLL_MODE4_CR0, APLL_MODE4_CR1, APLL_MODE4_CR2, APLL_MODE4_CR3,
                                                      APLL_MODE4_CR4, APLL_MODE4_CR5, APLL_MODE4_CR6, APLL_MODE4_CR7);
         break;
      case AUDIO_HAL_PLL_MODE7:
         audio_pvt_ce53xx_hal_get_pll_mode_configuration(configure_mode_ptr, APLL_MODE7_CR0, APLL_MODE7_CR1, APLL_MODE7_CR2, APLL_MODE7_CR3,
                                                      APLL_MODE7_CR4, APLL_MODE7_CR5, APLL_MODE7_CR6, APLL_MODE7_CR7);
         break;
      case AUDIO_HAL_PLL_MODE12:
         audio_pvt_ce53xx_hal_get_pll_mode_configuration(configure_mode_ptr, APLL_MODE12_CR0, APLL_MODE12_CR1, APLL_MODE12_CR2, APLL_MODE12_CR3,
                                                      APLL_MODE12_CR4, APLL_MODE12_CR5, APLL_MODE12_CR6, APLL_MODE12_CR7);
         break;
      case AUDIO_HAL_PLL_MODE23:
         audio_pvt_ce53xx_hal_get_pll_mode_configuration(configure_mode_ptr, APLL_MODE23_CR0, APLL_MODE23_CR1, APLL_MODE23_CR2, APLL_MODE23_CR3,
                                                      APLL_MODE23_CR4, APLL_MODE23_CR5, APLL_MODE23_CR6, APLL_MODE23_CR7);
         break;
      case AUDIO_HAL_PLL_MODE15:
         audio_pvt_ce53xx_hal_get_pll_mode_configuration(configure_mode_ptr, APLL_MODE15_CR0, APLL_MODE15_CR1, APLL_MODE15_CR2, APLL_MODE15_CR3,
                                                      APLL_MODE15_CR4, APLL_MODE15_CR5, APLL_MODE15_CR6, APLL_MODE15_CR7);
         break;
      case AUDIO_HAL_PLL_MODE16:
         audio_pvt_ce53xx_hal_get_pll_mode_configuration(configure_mode_ptr, APLL_MODE16_CR0, APLL_MODE16_CR1, APLL_MODE16_CR2, APLL_MODE16_CR3,
                                                      APLL_MODE16_CR4, APLL_MODE16_CR5, APLL_MODE16_CR6, APLL_MODE16_CR7);
         break;
      case AUDIO_HAL_PLL_MODE17:
         audio_pvt_ce53xx_hal_get_pll_mode_configuration(configure_mode_ptr, APLL_MODE17_CR0, APLL_MODE17_CR1, APLL_MODE17_CR2, APLL_MODE17_CR3,
                                                      APLL_MODE17_CR4, APLL_MODE17_CR5, APLL_MODE17_CR6, APLL_MODE17_CR7);
         break;
      case AUDIO_HAL_PLL_MODE17_1:
         audio_pvt_ce53xx_hal_get_pll_mode_configuration(configure_mode_ptr, APLL_MODE17_1_CR0, APLL_MODE17_1_CR1, APLL_MODE17_1_CR2, APLL_MODE17_1_CR3,
                                                      APLL_MODE17_1_CR4, APLL_MODE17_1_CR5, APLL_MODE17_1_CR6, APLL_MODE17_1_CR7);
         break;
      case AUDIO_HAL_PLL_MODE24:
         audio_pvt_ce53xx_hal_get_pll_mode_configuration(configure_mode_ptr, APLL_MODE24_CR0, APLL_MODE24_CR1, APLL_MODE24_CR2, APLL_MODE24_CR3,
                                                      APLL_MODE24_CR4, APLL_MODE24_CR5, APLL_MODE24_CR6, APLL_MODE24_CR7);
         break;
      default: 
         result = ISMD_ERROR_INVALID_PARAMETER;
         break;
   }
   
   return result;
}

ismd_result_t 
audio_ce53xx_hal_configure_master_clock(unsigned int frequency, ismd_audio_clk_src_t clk_src)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_pll_configuration configure_mode;

   if(clk_src == ISMD_AUDIO_CLK_SRC_EXTERNAL){
      switch(frequency) {
         case 22579200: 
            result = audio_ce53xx_hal_get_pll_mode_configuration(AUDIO_HAL_PLL_MODE12, &configure_mode);
            break;
         case 24576000:  
            result = audio_ce53xx_hal_get_pll_mode_configuration(AUDIO_HAL_PLL_MODE7, &configure_mode);
            break;
         case 33868800:
            result = audio_ce53xx_hal_get_pll_mode_configuration(AUDIO_HAL_PLL_MODE4, &configure_mode);
            break;
         case 36864000:
            result = audio_ce53xx_hal_get_pll_mode_configuration(AUDIO_HAL_PLL_MODE1, &configure_mode);
            break;
         case 16384000:
            result = audio_ce53xx_hal_get_pll_mode_configuration(AUDIO_HAL_PLL_MODE23, &configure_mode);
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }
   }
   else if(clk_src == ISMD_AUDIO_CLK_SRC_INTERNAL){
      switch(frequency) {
         case 22579200: 
            result = audio_ce53xx_hal_get_pll_mode_configuration(AUDIO_HAL_PLL_MODE17_1, &configure_mode);
            break;
         case 24576000:  
            result = audio_ce53xx_hal_get_pll_mode_configuration(AUDIO_HAL_PLL_MODE17, &configure_mode);
            break;
         case 33868800:
            result = audio_ce53xx_hal_get_pll_mode_configuration(AUDIO_HAL_PLL_MODE16, &configure_mode);
            break;
         case 36864000:
            result = audio_ce53xx_hal_get_pll_mode_configuration(AUDIO_HAL_PLL_MODE15, &configure_mode);
            break;
         case 16384000:
            result = audio_ce53xx_hal_get_pll_mode_configuration(AUDIO_HAL_PLL_MODE24, &configure_mode);
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }
   }

   if(result == ISMD_SUCCESS){
      result = audio_pvt_ce53xx_hal_set_pll_configuration_mode(&configure_mode);
   }
   
   return result;
}

