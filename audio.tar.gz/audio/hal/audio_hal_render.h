/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2008 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_HAL_RENDER_H_
#define _AUDIO_HAL_RENDER_H_

#include "ismd_global_defs.h"
#include "audio_hal_defs.h"
#include "audio_hal_common.h"

/*
GEN3 Audio HAL Render Functions
*/

/**
This function is responsible for enabling a render device.  It 
will be used in both the start and resume cases.

@param[in] tx_num : I2S instance to enable.

@retval ISMD_SUCCESS : Interface enabled.
*/
ismd_result_t 
audio_hal_render_start
(
   audio_hal_render_context_t *render_context
);


/**
This function is responsible for disabling a render device.  It 
will be used in both the stop and pause cases.

@param[in] tx_num : I2S instance to disable.

@retval ISMD_SUCCESS : Interface disabled.
*/
ismd_result_t 
audio_hal_render_stop
(
   audio_hal_render_context_t *render_context
);

/**
This function is responsible for putting the I2S hardware back into its reset configuration.

@param[in] tx_num : I2S instance to reset.

@retval ISMD_SUCCESS : Interface reset.
*/
ismd_result_t 
audio_hal_render_reset
(
   audio_hal_render_context_t *render_context
);


/**
Initialize the render HW context based on the hw_output_id specified the id's are specified
in gen3_audio_h. The function decides which TX and DMA context to use and returns the 
tx_context to the driver.  

@param[in] hw_output_id : Hardware ID of the desired output interface.
@param[in] mode : Output buffer mode, linked list or circular mode.
@param[in] mem_addr_phy : In linked list mode, this is the memory used to create nodes, in
   circular mode this is the DMA buffer space. 
@param[in] mem_addr_virt : The virtual address of the mem_addr_phy parameter.
@param[in] callback_function : Pointer to the function that will be called when a render interrupt (event) occurs.
@param[out] tx_num : Function will fill this value in for the driver to be used as a handle to the context.

@retval ISMD_SUCCESS : The render HW was configured properly.
@retval ISMD_ERROR_NO_RESOURCES : Spcified interface is in use.
*/
ismd_result_t
audio_hal_render_init_context
(
   audio_hal_render_context_t *render_context,
   void *caller_context,
   os_devhandle_t *devh,
   int hw_dev_id,
   audio_hal_render_buffer_mode_t mode,
   uint32_t mem_addr_phys,
   void *mem_addr_virt,
   size_t mem_size,
   buffer_callback_t callback_function
);

/**
Clean up for HAL render context. 

@param[in] render_context : Render context on which to perform the cleanup.

@retval ISMD_SUCCESS : The properties were configured properly.
@retval ISMD_ERROR_OPERATION_FAILED : Operation failed.
*/
void
audio_hal_render_deinit_context(audio_hal_render_context_t *render_context);


/**
Set the properties on the render buffer. 

@param[in] max_buffer_size : The maximum size of the render buffer. (mainly useful in linked list mode)
@param[in] high_watermark : When the buffer fills past this value the hal will generate the callback to the driver.
@param[in] low_watermark : When the buffer drains past this value the hal will generate the callback to the driver.

@retval ISMD_SUCCESS : The properties were configured properly.
@retval ISMD_ERROR_OPERATION_FAILED : Operation failed.
*/
ismd_result_t
audio_hal_render_buffer_set_config
(
   audio_hal_render_context_t *render_context, 
   size_t max_buffer_size,
   size_t high_watermark,
   size_t low_watermark
);


/**
Get the current amount of data waiting to be rendered.

@param[in] tx_num : The tx context (dma context) to get the level on.
@param[out] level : The level returned to the caller. 

@retval ISMD_SUCCESS : The level was succesfully returned.
@retval ISMD_ERROR_OPERATION_FAILED : Operation failed.
*/
ismd_result_t
audio_hal_render_buffer_get_level
(
   audio_hal_render_context_t *render_context,
   size_t *level
);


/**
Add a audio data buffer to the dma buffer to be rendered. 

@param[in] tx_num : The tx context (dma context) on which to add the buffer.
@param[in] buf_addr_phys :The physical address of the buffer to write to the DMA.
@param[in] buf_size : The size of the buffer to add. 
@param[in] buf_id : The id of the buffer to write in. This id is passed back in the callback function for the
   driver to dereference. 

@retval ISMD_SUCCESS : The buffer was put in line to be rendered.
@retval ISMD_ERROR_OPERATION_FAILED : Operation failed.
*/
ismd_result_t
audio_hal_render_buffer_add
(
   audio_hal_render_context_t *render_context,
   uint32_t buf_addr_phys,
   void *buf_addr_virt,
   size_t buf_size,
   int buf_id
);


/**
Flush all data that has not been already rendered unless the drain flag is set to true. In the case that
the drain flag is set to true let remaining data drain and render silence, and ensures that 
the callback function is called often enough free all buffers.

@param[in] tx_num : The tx context (dma context) on which to add the buffer.
@param[in] drain : Flag to tell HAL to let data drain (play out) or not.  

@retval ISMD_SUCCESS : The flush completed successfully.
@retval ISMD_ERROR_OPERATION_FAILED : Operation failed.
*/
ismd_result_t
audio_hal_render_flush
(
   audio_hal_render_context_t *render_context,
   bool drain
);


/**
This function is responsible for enabling the an I2S pin. 

@param[in] tx_num : I2S instance.
@param[in] pin_num: Pin number 0-1 for I2S0 and 0-3 for I2S1
@param[in] enable : enable/disable.

@retval ISMD_SUCCESS : I2S pin set.
*/
ismd_result_t 
audio_hal_render_i2s_set_pin
(
   audio_hal_render_context_t *render_context, 
   audio_i2s_pin_t pin_num, 
   bool enable
);


ismd_result_t 
audio_hal_render_i2s_set_clk_invert
(
   audio_hal_render_context_t *render_context, 
   bool invert_bit_clk
);

//The reason for the direct version of this function is to be able to call it at module init time
ismd_result_t 
audio_hal_render_i2s_set_clk_invert_direct
(
   os_devhandle_t *devh, 
   audio_hal_output_sel_t i2s_context, 
   bool invert_bit_clk
);


ismd_result_t 
audio_hal_render_i2s_set_ws_select
(
   audio_hal_render_context_t *render_context, 
   audio_hal_i2s_ws_select_t state
);

//The reason for the direct version of this function is to be able to call it at module init time
ismd_result_t 
audio_hal_render_i2s_set_ws_select_direct
(
   os_devhandle_t *devh, 
   audio_hal_output_sel_t i2s_context, 
   audio_hal_i2s_ws_select_t state
);


/**
This function is responsible for configuring the I2S hardware S/PDIF validity bit. 

@param[in] tx_num : I2S instance.
@param[in] is_valid : Should be set true if validity bit of S/PDIF stream should be set, false otherwise.

@retval ISMD_SUCCESS : Hardware configured I2S bus "tx_num" to set validity bit in S/PDIF stream to "is_valid".
*/
ismd_result_t 
audio_hal_render_spdif_set_validity_bit
( 
   audio_hal_render_context_t *render_context, 
   bool is_valid
);


/**
This function is responsible for configuring the I2S hardware S/PDIF user data. 

@param[in] tx_num : I2S instance.
@param[in] data : Desired data to be place in user data field of S/PDIF stream.
@param[in] size : Size in bytes of data, must be less than 48 bytes.

@retval ISMD_SUCCESS : Hardware configured I2S bus "tx_num" to set user data in S/PDIF stream to "data".
*/
ismd_result_t 
audio_hal_render_spdif_set_user_data
(  
   audio_hal_render_context_t *render_context, 
   uint8_t *data, 
   unsigned int size
);


/**
This function is responsible for configuring the I2S hardware S/PDIF channel status bits. 

@param[in] tx_num : I2S instance.
@param[in] lsw : Desired data to be place in bits 0..31 of channel status.
@param[in] msb : Desired data to be place in bits 32..39 of channel status.

@retval ISMD_SUCCESS : Hardware configured I2S bus "tx_num" to set channel status in S/PDIF stream to "lsw" and "msb".
*/
ismd_result_t 
audio_hal_render_spdif_set_channel_status
( 
   audio_hal_render_context_t *render_context, 
   uint32_t lsw, 
   uint8_t msb
);

void
audio_hal_render_handle_interrupt(unsigned int isrx_value);


ismd_result_t 
audio_hal_render_set_atl_mode
(
   audio_hal_render_context_t *render_context, 
   audio_hal_alt_mode_t state
);

ismd_result_t 
audio_hal_render_reset_tx_channels(audio_hal_dev_t *hal_devh);


/**
This function is responsible for configuring I2S hardware for sample size. 

@param[in] tx_num : I2S instance.
@param[in] sample_size : Sample size of the samples being sent to I2S instance "tx_num".

@retval ISMD_SUCCESS : Hardware configured I2S bus "tx_num" for sample size of "sample_size".
*/
ismd_result_t 
audio_hal_render_set_sample_size
( 
   audio_hal_render_context_t *render_context, 
   audio_hal_sample_size_t sample_size
);


/**
This function is responsible for setting the data storage modes. 

@param[in] tx_num : TX instance.
@param[in] dsm:  data storage mode

@retval ISMD_SUCCESS : Data storage mode set correctly.
*/
ismd_result_t 
audio_hal_render_set_data_storage_mode
( 
   audio_hal_render_context_t *render_context,  
   audio_hal_data_storage_mode_t dsm
);


/**
This function is responsible for configuring the I2S hardware for the channel configuration of the data. 

@param[in] tx_num : I2S instance.
@param[in] channel_config : Channel configuration of data being played.

@retval ISMD_SUCCESS : Hardware configured I2S bus "tx_num" for sample channel configuration of "channel_config".
*/
ismd_result_t 
audio_hal_render_set_channel_configuration
( 
   audio_hal_render_context_t *render_context, 
   audio_hal_data_storage_mode_t channel_config
);


/**
This function is responsible for configuring the I2S hardware for the sample rate desired based on pll input and 
desired output bit clock for peripherals like DAC, HDMI and S/PDIF.
@param[in] tx_num : I2S instance.
@param[in] desired_bit_clock_divider : Clock Divider.
@retval ISMD_SUCCESS : Desired bit clock divider has been set.
*/
ismd_result_t 
audio_hal_render_set_bit_clock_divider
( 
   audio_hal_render_context_t *render_context, 
   int32_t desired_bit_clock_divider
);   


/**
This function is responsible for setting the watermark levels on the FIFO 

@param[in] context : TX context
@param[in] level : Fifo thresh hold Level

@retval ISMD_SUCCESS : fifo_thresh_level set
*/
ismd_result_t 
audio_hal_render_set_fifo_thresh_level
( 
   audio_hal_render_context_t *render_context, 
   int32_t level
);

ismd_result_t
audio_hal_render_set_power_mode(os_devhandle_t *devh, audio_hal_power_management_mode_t power_mode);

#endif //_AUDIO_HAL_RENDER_H_

