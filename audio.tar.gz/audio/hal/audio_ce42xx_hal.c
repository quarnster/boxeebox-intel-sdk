
/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_hal_capture.h"
#include "auto_eas/gen4_aud_io.h"
#include "clock_control.h"


ismd_result_t 
audio_ce42xx_hal_capture_select_input_interface(audio_hal_capture_context_t* capture_context, audio_hal_input_sel_t input_select)
{
   DEVH_FUNC_ENTER(capture_context->hal_devh.devh);
   
   WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SACR0_INPUT_INTERFACE_SELECT, input_select);

   DEVH_FUNC_EXIT(capture_context->hal_devh.devh);
   return ISMD_SUCCESS;
}

ismd_result_t
audio_ce42xx_hal_configure_master_clock(unsigned int frequency, ismd_audio_clk_src_t clk_src)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   clock_control_ret_t clock_result = CLOCK_ERROR_INVALID_RESOURCE;
   unsigned int freq_select_bit = 0; 

   if(clk_src == ISMD_AUDIO_CLK_SRC_INTERNAL){
      switch(frequency) {
         case 22579200: 
            freq_select_bit = 3;//22.5792 MHz 
            break;
         case 24576000:  
            freq_select_bit = 2;//24.576 MHz 
            break;
         case 33868800:
            freq_select_bit = 1; //33.868 MHz -  can be used for sampling freq family 44100 with appropriate ADIV value
            break;
         case 36864000:
            freq_select_bit = 0; //Default reg setting is 36.864 MHz  -  can be used sampling freq family 48000 with appropriate ADIV value
            break;
         default:
            OS_INFO("ERROR: %s - %s \n", __FUNCTION__, "Audio Master clock frequency apart from Intel reference CE42xx board!");
            break;
      }

      if((clock_result = clock_control_write(CLOCK_AU_CLK_SELECT, freq_select_bit, CLOCK_TRUE)) != CLOCK_RET_OK) {
         OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "clock_control_write failed on CLOCK_AU_CLK_SELECT!", clock_result);
      }
      else {
         result = ISMD_SUCCESS;      
      }

   }
   else if(clk_src == ISMD_AUDIO_CLK_SRC_EXTERNAL){
      result = ISMD_ERROR_INVALID_PARAMETER;
   }
   
   return result;
}

