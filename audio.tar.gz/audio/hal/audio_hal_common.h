/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

/* GEN3 AUDIO HAL */

#ifndef _AUDIO_HAL_COMMON_H_
#define _AUDIO_HAL_COMMON_H_

#include "osal.h"
#include "pal.h"
#include "pal_interrupt.h"
#include "sven_module.h"
#include "sven_devh.h"
#include "audio_hal_defs.h"
#include "audio_hal_defs_pvt.h"
#include "audio_hal_render.h"
#include "audio_hal_capture.h"
#include "../core/audio_core_defs.h"


extern audio_hal_debug_t audio_hal_debug;
extern audio_hal_dev_t GEN3_DEVICE_AUD_IO;
extern os_irqlock_t   audio_hal_irq_lock;

#define AUDIO_HAL_DEBUG(num,...) if(num&audio_hal_debug){OS_INFO(__VA_ARGS__);};

#define VERIFY_HAL_RETSTATUS(devh,retStat) if(ISMD_SUCCESS!=retStat) \
{ \
      AUDIO_HAL_DEBUG(AUDIO_HAL_DEBUG_ALL, "error: [%s:%d] %s: ISMD return status failed: %d (%s)\n",__FILE__ ,__LINE__,__FUNCTION__,retStat,ismd_result_to_string(retStat)); \
      if(ISMD_ERROR_INVALID_PARAMETER==retStat) \
            DEVH_INVALID_PARAM(devh); \
      else \
      { \
            DEVH_WARN(devh, "ISMD return status failed"); \
            DEVH_AUTO_TRACE(devh); \
      }; \
      goto error; \
};

typedef enum {
   AUDIO_INDEPENDENT_CLOCK_RECOVERY_MODE_NORMAL = 0,
   AUDIO_INDEPENDENT_CLOCK_RECOVERY_MODE_PHASE_ADJUST = 1
} audio_independent_clock_recovery_mode_t;

/*
GEN3 Audio HAL Functions
*/

/**
This function is required to initialize the HAL and must be called prior to calling any other HAL API functions.

@retval ISMD_SUCCESS : Hal Initialized sucessfully.
*/
ismd_result_t 
audio_hal_init(os_devhandle_t *devh );

ismd_result_t 
audio_hal_deinit(os_devhandle_t *devh );

ismd_result_t 
audio_hal_dma_reset(audio_hal_dev_t *hal_devh, audio_dma_context_t dma);

ismd_result_t 
audio_hal_dma_flush(audio_hal_dev_t *hal_devh, audio_dma_context_t dma);

void
audio_hal_handle_io_interrupt(void *data);


ismd_result_t 
audio_hal_write_vsymbol( audio_hal_dev_t *device,  ...);


ismd_result_t 
audio_hal_read_vsymbol( audio_hal_dev_t *device, ...);


ismd_result_t 
audio_hal_create_reg_vsymbol(audio_hal_dev_t *hal_devh, int32_t *new_register, ...);


/**
This function clears the DMA src and des status bits in the ISRX register

@param[in] dma : DMA_CONTEXT

@retval ISMD_SUCCESS : src and des status bits  cleared successfully
*/
ismd_result_t  
audio_hal_clear_dma_status_register(audio_hal_dev_t *hal_devh, audio_dma_context_t dma);


/**
This function clears the FLAGS_MODE register for a DMA_CONTEXT

@param[in] dma : DMA_CONTEXT

@retval ISMD_SUCCESS : flags_mode cleared successfully
*/
ismd_result_t  
audio_hal_clear_dma_flags(audio_hal_dev_t *hal_devh, audio_dma_context_t dma);


/**
This function sets the FLAGS_MODE register for a DMA_CONTEXT

@param[in] dma : DMA_CONTEXT

@retval ISMD_SUCCESS : flags_mode cleared successfully
*/
ismd_result_t  
audio_hal_set_dma_flags(audio_hal_dev_t *hal_devh, audio_dma_context_t dma);


ismd_result_t 
audio_hal_poll_dma_complete( audio_hal_dev_t *hal_devh, audio_dma_context_t dma, uint32_t timeout);

ismd_result_t
audio_hal_set_dsp_memory_path(audio_dsp_memory_path_t *dsp_mem_path);


/**
Utility Functions.
**/
const char 
*osal_result_to_string(const int osalResult);


const char 
*ismd_result_to_string(const int ismdResult);

#endif //_GEN3_AUD_HAL_PVT_DEVH_H

