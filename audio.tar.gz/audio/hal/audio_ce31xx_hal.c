/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_hal_capture.h"
#include "clock_control.h"
#include "auto_eas/gen3_aud_io.h"

ismd_result_t
audio_ce31xx_hal_capture_set_channel_configuration(audio_hal_capture_context_t *capture_context, int ch_count)
{
   ismd_result_t result = ISMD_SUCCESS;

   switch (ch_count) {
      case 2:
      WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SACR1_STORAGE_MODE, AUDIO_HAL_DATA_STORAGE_MODE_STEREO);
      break;

      case 1:
      WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SACR1_STORAGE_MODE, AUDIO_HAL_DATA_STORAGE_MODE_LEFT);
      break;

      default:
      result = ISMD_ERROR_INVALID_PARAMETER;
      WRITE_IO(capture_context->hal_devh.devh, RX_OFFSET(capture_context->rx_context)+BITFIELD_AUD_IO_RX0SACR1_STORAGE_MODE, AUDIO_HAL_DATA_STORAGE_MODE_STEREO);
      break;
   }

   return result;
}

ismd_result_t 
audio_ce31xx_hal_capture_set_sample_size(audio_hal_capture_context_t* capture_context, int sample_size, unsigned int *sample_packing_size)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(sample_size == 16){
      *sample_packing_size = sample_size;
   }
   else {
      result = ISMD_ERROR_INVALID_PARAMETER;
   }

   return result;
}

ismd_result_t
audio_ce31xx_hal_configure_master_clock(unsigned int frequency, ismd_audio_clk_src_t clk_src)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   clock_control_ret_t clock_result = CLOCK_ERROR_INVALID_RESOURCE;
   unsigned int freq_select_bit = 0; 


   if(clk_src == ISMD_AUDIO_CLK_SRC_INTERNAL){

      switch(frequency) {

         case 33868800:
            freq_select_bit = 1; //33.868 MHz can be used for sampling freq family 44100 with appropriate ADIV value
            break;
         case 36864000:
            freq_select_bit = 0; //Default is 36.864 MHz can be used for sampling freq family 48000 with appropriate ADIV value
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }

      //Gate audio_clk_out by clearing AU_REF_CLK_EN bit
      if((clock_result = clock_control_write(CLOCK_AU_REF_CLK_EN, 0, CLOCK_TRUE)) != CLOCK_RET_OK) {
         OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "clock_control_write failed on clearing CLOCK_AU_REF_CLK_EN!", clock_result);
      }

      //Switch APLL_FREQ_SEL bit.
      else if((clock_result = clock_control_write(CLOCK_APLL_FREQ_SEL, freq_select_bit, CLOCK_TRUE)) != CLOCK_RET_OK) {
         OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "clock_control_write failed on setting CLOCK_APLL_FREQ_SEL!", clock_result);
      }

      //Put Audio PLL divider into reset by writing 1 to AUDIO_PLL_DIV_RESET bit.
      else if((clock_result = clock_control_write(CLOCK_AUDIO_PLL_DIV_RST, 1, CLOCK_TRUE)) != CLOCK_RET_OK) {
         OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "clock_control_write failed on setting CLOCK_AUDIO_PLL_DIV_RST!", clock_result);
      }

      //Release Audio PLL from reset by writing 0 to AUDIO_PLL_RESET bit
      else if((clock_result = clock_control_write(CLOCK_AUDIO_PLL_RESET, 0, CLOCK_TRUE)) != CLOCK_RET_OK) {
         OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "clock_control_write failed on clearing CLOCK_AUDIO_PLL_RESET!", clock_result);
      }

      else {
      //Wait one millisecond for APLL to relock.  APLL output will be running at the new frequency.
         os_sleep(1);
      }

      if(clock_result == CLOCK_RET_OK) {

         //Release Audio PLL divider from reset by writing 0 to AUDIO_PLL_DIV_RESET bit.
         if((clock_result = clock_control_write(CLOCK_AUDIO_PLL_DIV_RST, 0, CLOCK_TRUE)) != CLOCK_RET_OK) {
            OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "clock_control_write failed on clearing CLOCK_AUDIO_PLL_DIV_RST!", clock_result);
         }

         //Ungate audio_clk_out by setting AU_REF_CLK_EN bit.
         else if((clock_result = clock_control_write(CLOCK_AU_REF_CLK_EN, 1, CLOCK_TRUE)) != CLOCK_RET_OK) {
            OS_INFO("ERROR: %s - %s: %d \n", __FUNCTION__, "clock_control_write failed on clearing CLOCK_AU_REF_CLK_EN!", clock_result);
         }
         else {
            result = ISMD_SUCCESS;
         }
      }
   }
   else if(clk_src == ISMD_AUDIO_CLK_SRC_EXTERNAL){
      result = ISMD_SUCCESS;
   }
   
   return result;
}

