/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2008 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_HAL_RENDER_PVT_H_
#define _AUDIO_HAL_RENDER_PVT_H_

#include "ismd_global_defs.h"
#include "audio_hal_defs.h"
#include "gen3_audio.h"


/*********************************************************************************************/

/* Audio Render HAL Private Functions */

static ismd_result_t
audio_pvt_hal_render_linked_list_dma_setup
(
      audio_hal_render_context_t *render_context,
      unsigned int nodeCount,
      int32_t nodeBaseAddrPhys,
      int32_t nodeBaseAddrVirt,
      size_t nodeMemSize
);

static void
audio_pvt_hal_init_render_context_variables(audio_hal_render_context_t *render_context);

static ismd_result_t 
audio_pvt_hal_set_output_interface(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num, audio_hal_output_sel_t out_mode);

static ismd_result_t
audio_pvt_hal_dma_get_pointers(audio_hal_dev_t *hal_devh, audio_dma_context_t dma, uint32_t *srcdma_start, uint32_t *srcdma_stop);

static ismd_result_t 
audio_pvt_hal_dma_set_circ_buf
(
      audio_hal_dev_t *hal_devh, 
      audio_tx_context_t tx_num, 
      audio_dma_context_t dma,
      int32_t dmaBaseAddr,
      int32_t dmaSize
);

static ismd_result_t 
audio_pvt_hal_tx_reset(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num);

/*static ismd_result_t 
audio_pvt_hal_tx_dma_poll_complete( audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num, uint32_t timeout);

static ismd_result_t  
audio_pvt_hal_tx_fifo_wait_for_thrsh_level(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num, int timeout_ms); 

static int  
audio_pvt_hal_tx_fifo_get_level(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num);*/

static ismd_result_t  
audio_pvt_hal_tx_fifo_set_thrsh_level(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num, int level);   

static ismd_result_t 
audio_pvt_hal_tx_fifo_flush(audio_hal_dev_t *hal_devh, audio_tx_context_t tx_num);

static ismd_result_t 
audio_pvt_hal_render_circ_buf_init(audio_render_buffer_producer_t *wl, audio_render_circbuf_t *buf);

static ismd_result_t 
audio_pvt_hal_render_circ_buf_deinit(audio_render_buffer_producer_t *wl, audio_render_circbuf_t *buf);

static ismd_result_t 
audio_pvt_hal_render_circ_buf_write(audio_render_buffer_producer_t *wl, char *data, audio_render_circbuf_t  *buf, unsigned int count);

static ismd_result_t 
audio_pvt_hal_render_circ_buf_get_write_cnt(audio_render_buffer_producer_t *wl, audio_render_circbuf_t * buf, unsigned int *amt_avail);

static void
audio_pvt_hal_render_linked_list_handle_interrupt(audio_hal_render_context_t *render_context);

static void
audio_pvt_hal_render_linked_list_free_node(audio_hal_render_context_t *render_context);

static void
audio_pvt_hal_render_linked_list_shutdown_cleanup(audio_hal_render_context_t *render_context);

static int
audio_pvt_hal_render_linked_list_get_free_node_count(audio_hal_render_context_t *render_context, int dma_curr_node);

static void 
*audio_pvt_hal_render_low_watermark_thread(void *context);


#endif //_AUDIO_HAL_RENDER_H_

