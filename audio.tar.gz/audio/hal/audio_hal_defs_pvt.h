/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



/* GEN3 AUDIO HAL */

#ifndef _AUDIO_HAL_DEFS_PVT_H_
#define _AUDIO_HAL_DEFS_PVT_H_


#define GEN3_AUD_IO   "AUD_IO"
#define GEN3_AUD_DEV_NULL_TERM() {NULL,"",0,0,NULL}
#define BITFIELD_NULL_TERM() 0, 0, 0, 0
#define SINGLE_BIT 1
#define ENTIRE_REGISTER 32
#define BYTES_PER_REGISTER sizeof(int32_t)
#define USER_DATA_MAX_SIZE 48
#define BYTE_SHIFT(bytes) (bytes<<3)
#define AUDIO_HAL_WAIT_FOR_THRESH_LEVEL_TIMEOUT_mS 100
#define DEFAULT_RENDER_DMA_BURST_SIZE AUDIO_HAL_DMA_BURST_SIZE_256
#define OS_SLEEP_1_mS() os_sleep(1)
#define OS_SLEEP_100_mS() os_sleep(100)

#define AUDIO_TX_FIFO_THRESHOLD_LEVEL 63 //In 32b words.
#define AUDIO_RX_FIFO_THRESHOLD_LEVEL 63


//SYMBOL Definitions read writ macros based on SYMDEF in AUTO_EAS
//SYM  auto_eas roff, auto_eas lsb, auto_eas bit width, auto_eas mask
#define WRITE_IO(DEVH,SYM,VAL)   DEVH_WRITE_BITFIELD_UNWRAPPED(DEVH, SYM, (int32_t)VAL)
#define READ_IO(DEVH,SYM)   DEVH_READ_BITFIELD_UNWRAPPED(DEVH, SYM)

#define WRITE_IO_VA(HAL_DEVH,...)   audio_hal_write_vsymbol(&HAL_DEVH,__VA_ARGS__)
#define READ_IO_VA(HAL_DEVH,...)   audio_hal_read_vsymbol(&HAL_DEVH,__VA_ARGS__)

/***************** Interrupt Defines - Table 1-5 in Audio IO EAS *******************/

#define DMA0_SOURCE_INTERRUPT_PENDING              (1 << 3)
#define DMA0_DESTINATION_INTERRUPT_PENDING    (1 << 4)
#define DMA1_SOURCE_INTERRUPT_PENDING              (1 << 5)
#define DMA1_DESTINATION_INTERRUPT_PENDING    (1 << 6)
#define DMA2_SOURCE_INTERRUPT_PENDING              (1 << 7)
#define DMA2_DESTINATION_INTERRUPT_PENDING    (1 << 8)
#define DMA3_SOURCE_INTERRUPT_PENDING              (1 << 9)
#define DMA3_DESTINATION_INTERRUPT_PENDING    (1 << 10)

#define RX0_INTERRUPT_PENDING                               (1 << 19)
#define TX0_INTERRUPT_PENDING                               (1 << 21) 
#define TX1_INTERRUPT_PENDING                               (1 << 22) 
#define TX2_INTERRUPT_PENDING                               (1 << 23) 

#define ISRX_CLEAR_INTERRUPTS 0x00E807F8



/**************************************************************************/

#define INCREMENT_INDEX(curr_index, max_count)\
   if(curr_index == (max_count -1)){\
      curr_index = 0;\
   }\
   else{\
      curr_index++;\
   }\

#define DECREMENT_INDEX(curr_index, max_count)\
   if(curr_index == 0){\
      curr_index = (max_count -1);\
   }\
   else{\
      curr_index--;\
   }\

/*****************************************************************************/
// ENUM_AUDIO_HAL

typedef enum ENUM_AUDIO_HAL_DEBUG
{
    AUDIO_HAL_DEBUG_OFF = 0x0,
    AUDIO_HAL_DEBUG_ALL = 0xffffffff,
    AUDIO_HAL_DEBUG_FATAL     = (1<<31),
    AUDIO_HAL_DEBUG_WRITE_DSP1= (1<<6),
    AUDIO_HAL_DEBUG_WRITE_DSP0= (1<<5),
    AUDIO_HAL_DEBUG_WRITE_IO  = (1<<4),
    AUDIO_HAL_DEBUG_READ_IO   = (1<<3),
    AUDIO_HAL_DEBUG_ERROR     = (1<<2),
    AUDIO_HAL_DEBUG_WARNING   = (1<<1),
    AUDIO_HAL_DEBUG_INFO      = (1<<0)
} audio_hal_debug_t;


typedef enum ENUM_AUDIO_HAL_BIT_SET
{
     AUDIO_HAL_BIT_CLEAR,
     AUDIO_HAL_BIT_SET
} audio_hal_bit_set_t;

typedef enum ENUM_AUDIO_HAL_I2S_CLEAN_SHUTDOWN
{
     AUDIO_HAL_I2S_CLEAN_SHUTDOWN_COMPLETE,
     AUDIO_HAL_I2S_CLEAN_SHUTDOWN_IN_PROCESS
} audio_hal_i2s_clean_shutdown_t;

typedef enum ENUM_AUDIO_HAL_REG_SET
{
     AUDIO_HAL_REG_CLEAR,
     AUDIO_HAL_REG_SET = 0xFFFFFFFF
} audio_hal_reg_set_t;

typedef enum ENUM_AUDIO_HAL_IO_PORT
{
     AUDIO_HAL_IO_PORT_I2S0,
     AUDIO_HAL_IO_PORT_I2S1,
     AUDIO_HAL_IO_PORT_SPDIF,
     AUDIO_HAL_IO_PORT_I2SC
} audio_hal_io_port_t;

typedef enum ENUM_AUDIO_HAL_DMA_STATE
{
     AUDIO_HAL_DMA_STATE_STOP,
     AUDIO_HAL_DMA_STATE_START
} audio_hal_dma_state_t;

typedef enum ENUM_AUDIO_HAL_IO_ID
{
     AUDIO_HAL_IO_ID0
} audio_hal_io_id_t;

typedef enum ENUM_AUDIO_HAL_DSP_CACHE_STATE
{
     AUDIO_HAL_DSP_CACHE_STATE_LOCK,
     AUDIO_HAL_DSP_CACHE_STATE_UNLOCK
} audio_hal_dsp_cache_state_t;

typedef enum ENUM_AUDIO_HAL_DMA_ADDR_MODE
{
     AUDIO_HAL_DMA_ADDR_MODE_LINEAR,
     AUDIO_HAL_DMA_ADDR_MODE_CIRCULAR,
     AUDIO_HAL_DMA_ADDR_MODE_FIXED,
     AUDIO_HAL_DMA_ADDR_MODE_FIXED_CONTINOUS
} audio_hal_dma_addr_mode_t;

typedef enum ENUM_AUDIO_HAL_DMA_BURST_SIZE
{
     AUDIO_HAL_DMA_BURST_SIZE_004,
     AUDIO_HAL_DMA_BURST_SIZE_008,
     AUDIO_HAL_DMA_BURST_SIZE_016,
     AUDIO_HAL_DMA_BURST_SIZE_032,
     AUDIO_HAL_DMA_BURST_SIZE_064,
     AUDIO_HAL_DMA_BURST_SIZE_128,
     AUDIO_HAL_DMA_BURST_SIZE_256,
     AUDIO_HAL_DMA_BURST_SIZE_UNDEFINED
} audio_hal_dma_burst_size_t;

typedef enum ENUM_AUDIO_HAL_DMA_XBURST_SIZE
{
     AUDIO_HAL_DMA_XBURST_SIZE_004,
     AUDIO_HAL_DMA_XBURST_SIZE_008,
     AUDIO_HAL_DMA_XBURST_SIZE_016,
     AUDIO_HAL_DMA_XBURST_SIZE_032,
     AUDIO_HAL_DMA_XBURST_SIZE_064,
     AUDIO_HAL_DMA_XBURST_SIZE_128,
     AUDIO_HAL_DMA_XBURST_SIZE_256,
     AUDIO_HAL_DMA_XBURST_SIZE_UNDEFINED
} audio_hal_dma_xburst_size_t;

typedef enum ENUM_AUDIO_HAL_XDMA_GAP_SIZE
{
     AUDIO_HAL_XDMA_GAP_SIZE_0000,
     AUDIO_HAL_XDMA_GAP_SIZE_0016,
     AUDIO_HAL_XDMA_GAP_SIZE_0064,
     AUDIO_HAL_XDMA_GAP_SIZE_0256,
     AUDIO_HAL_XDMA_GAP_SIZE_1024,
     AUDIO_HAL_XDMA_GAP_SIZE_2048,
     AUDIO_HAL_XDMA_GAP_SIZE_4096,
     AUDIO_HAL_XDMA_GAP_SIZE_8192,
     AUDIO_HAL_XDMA_GAP_SIZE_UNDEFINED
} audio_hal_xma_gap_size_t;

typedef struct AUDIO_HAL_DMA_DESCRIPTOR 
{
   int32_t NEXT_DESC;
   int32_t SRCDMA_SIZE;
   int32_t SRCDMA_START;
   int32_t DSTDMA_START;
   int32_t FLAGS_MODE;
}audio_hal_dma_descriptor_t;
#define SIZE_OF_STRUCT_AUDIO_HAL_DMA_DESCRIPTOR sizeof(struct_audio_hal_dma_descriptor_t)

/*typedef union UNION_AUDIO_HAL_DMA_DESCRIPTOR 
{
   int32_t indx[SIZE_OF_STRUCT_AUDIO_HAL_DMA_DESCRIPTOR/sizeof(int32_t)];
   struct_audio_hal_dma_descriptor_t name;
}audio_hal_dma_descriptor_t;*/

#define SIZE_OF_AUDIO_HAL_DMA_DESCRIPTOR sizeof(audio_hal_dma_descriptor_t)
#define WORD_COUNT_AUDIO_HAL_DMA_DESCRIPTOR (SIZE_OF_AUDIO_HAL_DMA_DESCRIPTOR/sizeof(int32_t))


#endif 

