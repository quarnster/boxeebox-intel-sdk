/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_HAL_DEFS_H_
#define _AUDIO_HAL_DEFS_H_

#include "osal_thread.h"
#include "ismd_global_defs.h"
#include "sven_devh.h"
#include "audio_hal_defs_pvt.h"
#include "pal_soc_info.h"
#include "osal.h"

#define TX_OFFSET(tx_num)     (tx_num *0x100)
#define RX_OFFSET(rx_num)     (rx_num *0x0)
#define DMA_OFFSET(dma_num)   (dma_num*0x040)

#define RENDER_HAL_MAX_DEVICES 4
#define CAPTURE_HAL_MAX_DEVICES 1

typedef enum{
   AUDIO_RENDER_BUFFER_FULL, //
   AUDIO_RENDER_BUFFER_EMPTY, // LL when list has no audio data to render, Circ - empty
   AUDIO_RENDER_INPUT_BUFFER_DONE, // Node complete interrupt
   AUDIO_RENDER_BUFFER_REQUEST_DATA, //Render is hungry!
   AUDIO_RENDER_BUFFER_LOW_WATERMARK,
   AUDIO_RENDER_BUFFER_HIGH_WATERMARK,
   AUDIO_RENDER_SAFE_TO_CLOSE
}audio_hal_render_event_t;

typedef enum{
   AUDIO_CAPTURE_BUFFER_EMPTY,
   AUDIO_CAPTURE_BUFFER_DONE,
   AUDIO_CAPTURE_REQUEST_BUFFER,
   AUDIO_CAPTURE_BUFFER_LOW_WATERMARK,
   AUDIO_CAPTURE_BUFFER_HIGH_WATERMARK,
   AUDIO_CAPTURE_SAFE_TO_CLOSE,
}audio_hal_capture_event_t;

typedef ismd_result_t (* buffer_callback_t)(void *context, int buffer_id, audio_hal_render_event_t buf_event);
typedef ismd_result_t (* capture_callback_t)(void *context, int buffer_id, audio_hal_capture_event_t buf_event);

typedef enum {
   AUDIO_HAL_STATE_INVALID = 0,
   AUDIO_HAL_STATE_STOPPED = 1,
   AUDIO_HAL_STATE_PAUSED  = 2,
   AUDIO_HAL_STATE_STARTED = 3
} audio_hal_state_t;


typedef enum{
   AUDIO_RENDER_BUFFER_MODE_LINKED_LIST,
   AUDIO_RENDER_BUFFER_MODE_CIRCULAR
}audio_hal_render_buffer_mode_t;

typedef enum ENUM_AUDIO_IO_STATE
{
     AUDIO_IO_STATE_RESET,
     AUDIO_IO_STATE_RELEASE
} audio_io_state_t;

typedef enum ENUM_AUDIO_TX_CONTEXT
{
     AUDIO_TX_CONTEXT_TX0,  // TX context 0
     AUDIO_TX_CONTEXT_TX1,  // TX context 1
     AUDIO_TX_CONTEXT_TX2,  // TX context 2
     AUDIO_TX_CONTEXT_COUNT
} audio_tx_context_t;

typedef enum ENUM_AUDIO_I2S_PIN
{
     AUDIO_I2S_PIN0,  // pin 0
     AUDIO_I2S_PIN1,  // pin 1
     AUDIO_I2S_PIN2,  // pin 2
     AUDIO_I2S_PIN3   // pin 3
} audio_i2s_pin_t;

typedef enum ENUM_AUDIO_RX_CONTEXT
{
     AUDIO_RX_CONTEXT_RX0,  // RX context 0
     AUDIO_RX_CONTEXT_COUNT,
} audio_rx_context_t;

/* These enum vals used as an index into an arry in the HAL.
  * Do not change order or value.  
  */
typedef enum ENUM_AUDIO_DMA_CONTEXT
{
     AUDIO_DMA_CONTEXT0,    // DMA context 0
     AUDIO_DMA_CONTEXT1,    // DMA context 1
     AUDIO_DMA_CONTEXT2,    // DMA context 2
     AUDIO_DMA_CONTEXT3,    // DMA context 3
     AUDIO_DMA_CONTEXT_COUNT
} audio_dma_context_t;


typedef enum ENUM_AUDIO_I2S_CONTEXT
{
     AUDIO_I2S_CONTEXT_I2S0,
     AUDIO_I2S_CONTEXT_I2S1,
     AUDIO_I2S_CONTEXT_I2SC
} audio_i2s_context_t;

typedef enum ENUM_AUDIO_HAL_DATA_STORAGE_MODE
{
     AUDIO_HAL_DATA_STORAGE_MODE_7_1,
     AUDIO_HAL_DATA_STORAGE_MODE_STEREO,
     AUDIO_HAL_DATA_STORAGE_MODE_LEFT,
     AUDIO_HAL_DATA_STORAGE_MODE_RIGHT
} audio_hal_data_storage_mode_t;

typedef enum ENUM_AUDIO_HAL_I2S_INPUT_TYPE
{
     AUDIO_HAL_I2S_MONO_OR_STEREO_MODE,
     AUDIO_HAL_RESERVED,
     AUDIO_HAL_I2S_5_1_MODE,
     AUDIO_HAL_I2S_7_1_MODE
} audio_hal_i2s_input_type_t;

typedef enum ENUM_AUDIO_HAL_AUDIO_MODE
{
     AUDIO_HAL_AUDIO_MODE_I2S,
     AUDIO_HAL_AUDIO_MODE_SPDIF,
     AUDIO_HAL_AUDIO_MODE_HDMI
} audio_hal_audio_mode_t;

typedef enum {
   AUDIO_HAL_PM_POWER_ON = 0,
   AUDIO_HAL_PM_POWER_DOWN = 1,
   AUDIO_HAL_PM_GATE = 2
}audio_hal_power_management_mode_t;


typedef enum ENUM_AUDIO_HAL_OUTPUT_SEL
{
     AUDIO_HAL_OUT_SEL_I2S1,
     AUDIO_HAL_OUT_SEL_I2S0,
     AUDIO_HAL_OUT_SEL_NOT_USED,
     AUDIO_HAL_OUT_SEL_SPDIF
} audio_hal_output_sel_t;

typedef enum ENUM_AUDIO_HAL_INPUT_SEL
{
   AUDIO_HAL_INPUT_SEL_I2S1 = 0,
   AUDIO_HAL_INPUT_SEL_I2S0 = 1,
   AUDIO_HAL_INPUT_SEL_SPDIF = 2
} audio_hal_input_sel_t;

typedef enum ENUM_AUDIO_HAL_I2S_PIN_ENABLE
{
   AUDIO_HAL_I2S_PIN_ENABLE,
   AUDIO_HAL_I2S_PIN_LEFT_ENABLE,
   AUDIO_HAL_I2S_PIN_RIGHT_ENABLE,
   AUDIO_HAL_I2S_PIN_DISABLE
} audio_hal_i2s_pin_en_t;

typedef enum ENUM_AUDIO_HAL_SAMPLE_SIZE
{
   AUDIO_HAL_SAMPLE_SIZE_16BIT,
   AUDIO_HAL_SAMPLE_SIZE_24BIT
} audio_hal_sample_size_t;

typedef enum ENUM_AUDIO_HAL_ALT_MODE
{
   AUDIO_HAL_ALT_MODE_I2S,
   AUDIO_HAL_ALT_MODE_MSB_JUSTIFIED
} audio_hal_alt_mode_t;

typedef enum ENUM_AUDIO_HAL_I2S_WS_SELECT
{
   AUDIO_HAL_I2S_WS_SELECT_FALLING,
   AUDIO_HAL_I2S_WS_SELECT_RISING
} audio_hal_i2s_ws_select_t;

typedef enum ENUM_AUDIO_HAL_I2S_BIT_CLK_INV
{
   AUDIO_HAL_I2S_BIT_CLK_DEFAULT,
   AUDIO_HAL_I2S_BIT_CLK_INVERTED
} audio_hal_i2s_bit_clk_inv_t;

typedef enum ENUM_AUDIO_CAP_HAL_SAMPLE_SIZE
{
   AUDIO_CAP_HAL_SAMPLE_SIZE_16BIT,
   AUDIO_CAP_HAL_SAMPLE_SIZE_20BIT,
   AUDIO_CAP_HAL_SAMPLE_SIZE_24BIT
} audio_cap_hal_sample_size_t;

typedef struct audio_render_circbuf_t{
   unsigned int base; //base address of the buffer
   unsigned int size; //size of the buffer in bytes
   uint32_t read_reg_addr; //address of shadow read register
   uint32_t write_reg_addr; //address of shadow write register
   uint32_t saved_read_ptr_val; //used to save reg val for reconnctions
   uint32_t saved_write_ptr_val;//used to save reg val for reconnctions
   uint32_t *virt_write_ptr;
   uint32_t *virt_read_ptr;
   uint8_t  *virt_buf_ptr;
   unsigned int phys_end_addr;   // = base + size
}audio_render_circbuf_t;

typedef struct audio_render_buffer_producer_t{
   bool in_use;
   uint8_t *buf_ptr; //beginning of buf, maps whole buffer
   uint32_t *sw_read_ptr;
   uint32_t *shadow_write_ptr;
   uint32_t local_write_ptr;
   bool connected;
   bool disc_sent;
} audio_render_buffer_producer_t;

typedef struct STRUCT_AUDIO_HAL_LINKED_LIST_NODE_T
{
   audio_hal_dma_descriptor_t dma_descriptor;
   int buffer_id;
   int buffer_size;
   int phys_addr;
} audio_hal_linked_list_node_t;

#define SIZE_OF_DMA_LINKED_LIST_NODE (sizeof(audio_hal_linked_list_node_t))

typedef struct STRUCT_AUDIO_HAL_DEVICE
{
    os_devhandle_t *devh;
    const char *devName;
    enum SVEN_Module svenModule;
    int svenUnit;
} audio_hal_dev_t;

typedef union {
   struct { 
      bool bitclk_direction;
      bool msb_justified;
   } i2s;
   struct {
      bool clock_update_rate;
   } spdif;
} audio_hal_capture_params;

typedef enum {
   AUDIO_DSP_MEM_PATH_COHERENT = 0,     /** Setting for DSP memory path is coherent with the IA*/
   AUDIO_DSP_MEM_PATH_NON_COHERENT = 1  /** Setting for DSP memory path is not coherent with the IA (Fast Path)*/
}audio_dsp_memory_path_t;

typedef struct STRUCT_AUDIO_HAL_RENDER_CONTEXT
{
   void *user_context; //Caller can use this as a context storage
   bool in_use;
   bool start_to_close;
   audio_hal_dev_t hal_devh;
   audio_hal_render_buffer_mode_t buffer_mode;
   buffer_callback_t buffer_callback_func;

   audio_dma_context_t dma_context;
   audio_tx_context_t tx_context;
   audio_hal_output_sel_t output;

   //Stuctures need to manage circular buffer
   audio_render_circbuf_t circ_buf;
   audio_render_buffer_producer_t circ_buf_wl;
   os_thread_t low_wtrmrk_thread;

   //Linked List variables
   uint32_t curr_node_index;
   uint32_t curr_dma_node_index;
   uint32_t curr_node_count;
   uint32_t level_node_count; //The desired level we want the render at.
   uint32_t max_nodes;
   bool first_node_added;
   bool underrun;
   audio_hal_linked_list_node_t *dma_nodes;
   int32_t flags_mode; 
   int32_t flags_mode_stop;
   int32_t txSATRAddr;
   int32_t nodeBaseAddrPhys;
   int32_t last_node_phys_addr;
   int32_t interrupt_mask;

   size_t dma_buffer_size;
   size_t dma_buffer_level;
   size_t max_dma_buffer_size;
   size_t high_watermark;
   size_t low_watermark;
   
} audio_hal_render_context_t;

typedef struct STRUCT_AUDIO_HAL_CAPTURE_CONTEXT
{
   void* user_context;
   bool in_use;
   bool start_to_close;
   audio_hal_dev_t hal_devh;
   audio_dma_context_t dma_context;
   audio_rx_context_t rx_context;
   capture_callback_t buffer_callback_func;
   audio_hal_state_t state;
   int32_t hw_dev_id;

   //Linked List variables
   uint32_t curr_node_index;     // driver control
   uint32_t curr_dma_node_index; // DMA control
   uint32_t curr_node_count;
   uint32_t level_node_count; //The desired level we want the render at.
   uint32_t max_nodes;

   bool first_node_added;
   bool overflow;
   audio_hal_linked_list_node_t *dma_nodes;
   
   int32_t flags_mode; 
   int32_t flags_mode_stop;
   int32_t rxSARRAddr;
   int32_t nodeBaseAddrPhys;
   int32_t last_node_phys_addr;
   int32_t interrupt_mask;

   size_t dma_buffer_size;       // total buffer size of all node description
   size_t dma_buffer_level;
   size_t max_dma_buffer_size;
   size_t high_watermark;
   size_t low_watermark;
   int32_t dma_burst_size;
   int32_t dma_xburst_size;
   ismd_clock_t clock;
   int32_t startup;
   uint32_t  chunk_size_ticks; // in terms of 90KHz
   ismd_time_t current_ts_27mhz; 
   ismd_time_t constant_offset_27mhz; 
   ismd_time_t previous_ts_27mhz;   
   os_irqlock_t   acap_irq_lock;  //Used to disable interrupts 
} audio_hal_capture_context_t;



#endif


