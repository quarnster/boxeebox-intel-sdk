/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_DSP_COMMON_H_
#define _AUDIO_DSP_COMMON_H_

#include "sven_fw_globals.h"

/* Overall Memory Map. Currently the size is set at 3MB. */

/* --------------------------------------------------------------------------- */
/* Memory map of the kernel and memory region */
/* --------------------------------------------------------------------------- */
/* 2 MB is allocated for the kernel which includes the codec APIs, Stack, Heap etc */
/* Vector setup									start address / size 
	Reset Vector 									0x180 / 0x2e0
	Kernel (Stacked) Exception Vector 		0x464 / 0x1c
	User (Program) Exception Vector 			0x484 / 0x1c
	Double Exception Vector 					0x4a4/ 0xe0
	Window Register Overflow Vector			0x0/ 0x180
	Level 2 Interrupt Vector 					0x588 / 0x1c	*/

#define AUDIO_DSP_MAX_DEVICES 2 


/* Note- Any change in  AUDIO_DSP_KERNEL_SIZE needs to change the memory map and rebuild LSP */
#define AUDIO_DSP_KERNEL_SIZE 0x1ff800 //2MB - 2KB for mail boxes
#define AUDIO_DSP_KERNEL_OFFSET 0

/* Allocate the rest of the SMD buffer between Host->DSP mailbox,
   DSP->Host mailbox, sven header and sven circbuf. 
   The SVEN stuff would be removed when dfx is enabled.
   NOTE: SVEN circ buf size needs to be power of 2. */
   
#define AUDIO_DSP_H_TO_D_MAILBOX_SIZE 0x400   //1KB
#define AUDIO_DSP_H_TO_D_MAILBOX_OFFSET (AUDIO_DSP_KERNEL_OFFSET + AUDIO_DSP_KERNEL_SIZE)

#define AUDIO_DSP_D_TO_H_MAILBOX_SIZE 0x400   //1KB
#define AUDIO_DSP_D_TO_H_MAILBOX_OFFSET (AUDIO_DSP_H_TO_D_MAILBOX_OFFSET + AUDIO_DSP_H_TO_D_MAILBOX_SIZE) 

/* --------------------------------------------------------------------------- */


#define MAX_BUFFER_COUNT 12
/* --------------------------------------------------------------------------- */
/* Doorbell register values. */
/* --------------------------------------------------------------------------- */
#define AUDIO_DSP_DBREG_BUSY 0x80
#define AUDIO_DSP_DBREG_DONE 0x40
#define AUDIO_DSP_DBREG_DONE_NO_HOST_INTERRUPT 0x0
/* --------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------- */
/* WARNING : Do not change the bit breakdown of this register. There are other 
 * places in FW that this structure is used. Proceed with caution. */
/* IPCX Register breakdown */
/* 31 - 24 : Status */
/* 23 - 16 : wl_id */
/* 15 - 8  : message */
/* 7  - 0  : message_data */
/* --------------------------------------------------------------------------- */
#define AUDIO_DSP_DBREG_TO_MESSAGE_DATA(x) (x & 0xff)
#define AUDIO_DSP_DBREG_TO_MESSAGE_ID(x) ((x & 0xff00) >> 8)
#define AUDIO_DSP_DBREG_TO_WL_ID(x) ((x & 0xff0000) >> 16)
#define AUDIO_DSP_DBREG_TO_STATUS(x) ((x & 0xff000000) >> 24)
/* --------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------- */
/* Messages from DSP->HOST. */
/* --------------------------------------------------------------------------- */
#define AUDIO_DSP_MESSAGE_DTOH_FW_INIT_COMPLETE 1
#define AUDIO_DSP_MESSAGE_DTOH_OUTPUT_JOB_AVAILABLE 2
#define AUDIO_DSP_MESSAGE_DTOH_INPUT_JOB_CONSUMED 3
#define AUDIO_DSP_MESSAGE_DTOH_STAGE_EXE_ERROR 4
#define AUDIO_DSP_MESSAGE_DTOH_MAILBOX_CONTAINS_MESSAGE 5
#define AUDIO_DSP_MESSAGE_DTOH_NOTIFICATION_EVENT 6
#define AUDIO_DSP_MESSAGE_DTOH_CODEC_AVAILABLE 7
#define AUDIO_DSP_MESSAGE_DTOH_CODEC_VER_STRING 8
#define AUDIO_DSP_MESSAGE_DTOH_PIPE_ADDED 9

/* --------------------------------------------------------------------------- */
/* Messages from HOST->DSP */
/* --------------------------------------------------------------------------- */
#define AUDIO_DSP_MESSAGE_HTOD_PIPE_ADD 1
#define AUDIO_DSP_MESSAGE_HTOD_PIPE_REMOVE 2
#define AUDIO_DSP_MESSAGE_HTOD_PIPE_START 3
#define AUDIO_DSP_MESSAGE_HTOD_PIPE_STOP 4
#define AUDIO_DSP_MESSAGE_HTOD_CFG_PARAM_SET 5
#define AUDIO_DSP_MESSAGE_HTOD_CFG_PARAM_GET 6
#define AUDIO_DSP_MESSAGE_HTOD_INPUT_JOB_AVAILABLE 7
#define AUDIO_DSP_MESSAGE_HTOD_PIPE_CONFIGURE 8
#define AUDIO_DSP_MESSAGE_HTOD_OUTPUT_JOB_AVAILABLE 9
#define AUDIO_DSP_MESSAGE_HTOD_BUFFER_AVAILABLE 10
#define AUDIO_DSP_MESSAGE_HTOD_PIPE_FLUSH 11
#define AUDIO_DSP_MESSAGE_HTOD_CODEC_AVAILABLE 12
#define AUDIO_DSP_MESSAGE_HTOD_GET_CODEC_VER_STRING 13
#define AUDIO_DSP_MESSAGE_HTOD_STAGE_CONFIGURE 14
#define AUDIO_DSP_MESSAGE_HTOD_INIT_INFO 15  
#define AUDIO_DSP_MESSAGE_HTOD_ENABLE_SVEN_DEBUG 16
#define AUDIO_DSP_MESSAGE_HTOD_GET_STREAM_INFO 17
#define AUDIO_DSP_MESSAGE_HTOD_GET_STAGE_PARAMS 18


/* Host to DSP mail box message formats */
/* 
   NOTE - The size of the structure may differ on IA and DSP 
   So depending on the elements used you may need to to do appropriate padding
*/
/* AUDIO_DSP_MESSAGE_HTOD_PIPE_CONFIGURE */
typedef struct audio_htod_pipe_conf_s
{
   audio_psm_stage_t *psm_stages;
   audio_psm_job_desc_t *cur_in_job;
   audio_psm_job_desc_t *prev_in_job;
   audio_psm_pipe_output_queues_t *output_queues;
}audio_htod_pipe_conf_t;

typedef struct audio_dsp_reg_s
{
   volatile unsigned int      *csr_reg[AUDIO_DSP_MAX_DEVICES];  
}audio_dsp_reg_t;

/* AUDIO_DSP_MESSAGE_HTOD_INIT_INFO */
typedef struct audio_htod_init_info_s
{
   audio_psm_buf_desc_t *psm_bufs;
   uint32_t psm_bufs_count;
   struct SVEN_FW_Globals  sven_fw_globals;
   audio_dsp_reg_t dsp_regs;
}audio_htod_init_info_t;

typedef union audio_htod_msg_u
{
   audio_htod_pipe_conf_t pipe_conf; 
   audio_htod_init_info_t init_info;
}audio_htod_mgs_t;

/* DSP to Host mail box message formats */
/* All messages are passed as string */

#endif

