/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"

#define NEO6_MAX_CHANNELS 7
#define NEO6_MIN_CHANNELS 3

ismd_result_t
audio_dts_neo6_set_decode_param(audio_psm_stage_params_t *psm_stage_params, int param_id, ismd_audio_decoder_param_t *param_value)
{

   ismd_result_t result = ISMD_SUCCESS;
   
   ismd_audio_dts_neo6_num_output_channels_t *output_channels;
   ismd_audio_dts_neo6_mode_t *mode;
   ismd_audio_dts_neo6_cgain_t *cgain;
   
   
   switch(param_id)
      {
           
         case ISMD_AUDIO_DTS_NEO6_NUM_OUTPUT_CHANNELS :
            
             output_channels = (ismd_audio_dts_neo6_num_output_channels_t *) param_value;
            
            if(*output_channels >= NEO6_MIN_CHANNELS && *output_channels <= NEO6_MAX_CHANNELS) {            
                  psm_stage_params->decoder.host.codec.config.neo6_params.channels = *output_channels;
                  //OS_INFO("Output channels = %d\n",psm_stage_params->neo6.neo6_config.channels);
            }
            else {
                  result = ISMD_ERROR_INVALID_PARAMETER;
                  AUDIO_ERROR("dts neo6: output_channels param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
            }
            
            break;

         case ISMD_AUDIO_DTS_NEO6_MODE:

            mode = (ismd_audio_dts_neo6_mode_t *)param_value;
            
            if(*mode == AUDIO_DTS_NEO6_MODE_CINEMA || *mode == AUDIO_DTS_NEO6_MODE_MUSIC) {            
                  psm_stage_params->decoder.host.codec.config.neo6_params.mode = *mode;
                  //OS_INFO("Mode = %d\n",psm_stage_params->neo6.neo6_config.mode);
            }
            else {
                  result = ISMD_ERROR_INVALID_PARAMETER;
                  AUDIO_ERROR("dts neo6: mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
            }
            
            break;

         case ISMD_AUDIO_DTS_NEO6_CGAIN:

            cgain = (ismd_audio_dts_neo6_cgain_t *)param_value;
            
            if(*cgain >= 0 && *cgain <= 100) {            
                  psm_stage_params->decoder.host.codec.config.neo6_params.cgain = *cgain;
            }
            else {
                  result = ISMD_ERROR_INVALID_PARAMETER;
                  AUDIO_ERROR("dts neo6: cgain param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
            }
            
            break;


         default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("dts: invalid config param type!", result, audio_devh[AUDIO_DEBUG_APM]);    
         break;
      }

   return result;
}

ismd_result_t
audio_dts_neo6_set_default_decode_params(audio_psm_decode_params_t *neo6_stage_params) 
{
   ismd_result_t result = ISMD_SUCCESS;

   neo6_stage_params->host.codec.config.neo6_params.channels = 6;
   neo6_stage_params->host.codec.config.neo6_params.cgain = 100;
   neo6_stage_params->host.codec.config.neo6_params.mode = AUDIO_DTS_NEO6_MODE_CINEMA;
   neo6_stage_params->host.codec.config.neo6_params.samplebitdepth = 24;
   neo6_stage_params->host.codec.config.neo6_params.samplerate = 48000;//This get changed on output setup.
   neo6_stage_params->host.codec.config.neo6_params.samplesperframe = 512;

   /*OS_PRINT("psm_stage_params->neo6.neo6_config.channels = %d\n", neo6_stage_params->host.codec.config.neo6_params.channels);
   OS_PRINT("psm_stage_params->neo6.neo6_config.cgain = %d\n",neo6_stage_params->host.codec.config.neo6_params.cgain);
   OS_PRINT("psm_stage_params->neo6.neo6_config.mode = %d\n",neo6_stage_params->host.codec.config.neo6_params.mode);
   OS_PRINT("psm_stage_params->neo6.samplebitdepth = %d\n",neo6_stage_params->host.codec.config.neo6_params.samplebitdepth);
   OS_PRINT("psm_stage_params->neo6.samplerate = %d\n",neo6_stage_params->host.codec.config.neo6_params.samplerate);
   OS_PRINT("psm_stage_params->neo6.samplesperframe = %d\n",neo6_stage_params->host.codec.config.neo6_params.samplesperframe);*/
   
   return result;
}

