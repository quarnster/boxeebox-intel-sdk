/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2009-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2008-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"
#include "audio_apm_common.h"


ismd_result_t
audio_dts_bc_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value)
{
   ismd_result_t result = ISMD_SUCCESS;

   enum_dtshd_speaker_activity_mask_t *spkrout;
   ismd_audio_dts_dynamic_range_compression_percent_t *dyn_rng_comp_prct;
   ismd_audio_dts_lfe_downmix_t *lfe_downmx;
   ismd_audio_dts_downmixmode_t *downmixmode;
   ismd_audio_dts_bitspersample_t *pcmsize;
   ismd_audio_dts_mixout_mode_t *mixoutmode;
   ismd_audio_dts_disabledialnorm_t *disable_dialnorm;
   
   switch(param_id)
   {
      case ISMD_AUDIO_DTS_SPKROUT :

         spkrout = (enum_dtshd_speaker_activity_mask_t *) param_value;
         
         switch(*spkrout) {
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_DEFAULT:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_C:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_C_LFE1:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_L_R:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_L_R_LFE1:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_LT_RT:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_C_L_R:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_C_L_R_LFE1:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_L_R_CS:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_L_R_CS_LFE1:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_C_L_R_CS:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_C_L_R_CS_LFE1:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_L_R_LS_RS:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_L_R_LS_RS_LFE1:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_C_L_R_LS_RS_LFE1:
            case ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_Lt_Rt_LFE1:

               psm_decode_params->host.codec.config.dts_bc_params.spkrout = *spkrout;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("dts bc: speaker_output_acctivity_mask param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         
         break;
         
      case  ISMD_AUDIO_DTS_DRCPERCENT :
         
         dyn_rng_comp_prct = (ismd_audio_dts_dynamic_range_compression_percent_t *) param_value;

         if(*dyn_rng_comp_prct >= ISMD_AUDIO_DTS_DRC_PERCENT_MIN && *dyn_rng_comp_prct <= ISMD_AUDIO_DTS_DRC_PERCENT_MAX)
            {

            psm_decode_params->host.codec.config.dts_bc_params.drc_prsent = 1;
            psm_decode_params->host.codec.config.dts_bc_params.drcpercent = *dyn_rng_comp_prct;
            }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("dts bc: dynamic_range_compression_percent param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         break;

      case ISMD_AUDIO_DTS_LFEDNMX :

         lfe_downmx = (ismd_audio_dts_lfe_downmix_t *) param_value;

         if(*lfe_downmx == ISMD_AUDIO_DTS_LFE_DOWNMIX_NONE ||  *lfe_downmx == ISMD_AUDIO_DTS_LFE_DOWNMIX_10DB)
            {
         psm_decode_params->host.codec.config.dts_bc_params.lfednmix = *lfe_downmx;
            }
         else
            {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("dts bc: lfedownmixmode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
        
         break;

      case  ISMD_AUDIO_DTS_DOWNMIXMODE :
         
         downmixmode = (ismd_audio_dts_downmixmode_t *) param_value;

         if( *downmixmode == ISMD_AUDIO_DTS_DOWNMIX_MODE_EXTERNAL || *downmixmode == ISMD_AUDIO_DTS_DOWNMIX_MODE_INTERNAL ) {

            psm_decode_params->host.codec.config.dts_bc_params.dwnmixmode = *downmixmode;
         }
         else if ( *downmixmode != ISMD_AUDIO_DTS_DOWNMIX_MODE_INVALID) {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("dts bc: downmixmode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;


     case ISMD_AUDIO_DTS_PCMSIZE :

       pcmsize = (ismd_audio_dts_bitspersample_t *) param_value;

       if(*pcmsize == ISMD_AUDIO_DTS_PCMSIZE_16 || *pcmsize == ISMD_AUDIO_DTS_PCMSIZE_24)
         {
         
         psm_decode_params->host.codec.config.dts_bc_params.pcmsize = *pcmsize;
         
         }
       else{
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("dts bc: unsupported value of input sample size!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
       break;

      case ISMD_AUDIO_DTS_MIXOUT_MODE :

         mixoutmode = (ismd_audio_dts_mixout_mode_t *) param_value;

         switch(*mixoutmode)
            {

             case ISMD_AUDIO_DTS_MIXOUT_2_0:
             case ISMD_AUDIO_DTS_MIXOUT_5_1:
             case ISMD_AUDIO_DTS_MIXOUT_7_1:
               psm_decode_params->host.codec.config.dts_bc_params.playermixoutmode = *mixoutmode;
               break;
             default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("dts bc: unsupported value of dts mixout mode!", result, audio_devh[AUDIO_DEBUG_APM]);
            }

         break;

      case ISMD_AUDIO_DTS_DISABLEDIALNORM :

         disable_dialnorm = (ismd_audio_dts_disabledialnorm_t *) param_value;

         if(*disable_dialnorm != 1 && *disable_dialnorm != 0)
            {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("dts bc:disable dialnorm flag can only be true or false\n",result, audio_devh[AUDIO_DEBUG_APM]);
            }
         else if(*disable_dialnorm == 1)
            {
         psm_decode_params->host.codec.config.dts_bc_params.disdialnorm_flag = *disable_dialnorm;
         psm_decode_params->host.codec.config.dts_bc_params.disable_dialnorm = 1;
            }

         break;

      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("dts: invalid config param type!", result, audio_devh[AUDIO_DEBUG_APM]);    
         break;

   
   }

   return result;
}

ismd_result_t
audio_dts_bc_set_default_decode_params(audio_psm_decode_params_t *dec_params )
{
   ismd_result_t result = ISMD_SUCCESS;

   OS_MEMSET((char *)dec_params, 0, sizeof(audio_psm_stage_params_t)); 

   dec_params->host.codec.config.dts_bc_params.drc_prsent = 0;
   dec_params->host.codec.config.dts_bc_params.lfednmix = 0;
   dec_params->host.codec.config.dts_bc_params.pcmsize = 24;
   dec_params->host.codec.config.dts_bc_params.dwnmixmode = ISMD_AUDIO_DTS_DOWNMIX_MODE_INTERNAL;
   dec_params->host.codec.config.dts_bc_params.spkrout = ISMD_AUDIO_DTS_SPEAKER_ACTIVITY_MASK_C_L_R_LS_RS_LFE1;
   dec_params->host.codec.config.dts_bc_params.playermixoutmode = 1; //5.1 mixing enabled by default
   dec_params->host.codec.config.dts_bc_params.disdialnorm_flag = 0; //This has to set explicitly by the app. Flag to signal if disabling dialnorm api is to be called by the fw.
 
   return result;
}


