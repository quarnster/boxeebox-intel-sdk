/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2008-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2008-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"
#include "pal.h"
#include "pal_interrupt.h"
#include "audio_apm_common.h"


ismd_result_t
audio_dts_hd_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_dts_hd_sample_width_t *sample_width;
   ismd_audio_dts_hd_speaker_activity_mask_t *spkrout;
   ismd_audio_dts_hd_dynamic_range_compression_percent_t *dyn_rng_comp_prct;
   ismd_audio_dts_hd_lfe_downmix_t *lfe_downmx;
   ismd_audio_dts_hd_decode_type_t *decode_type;
   ismd_audio_dts_hd_downmix_mode_t *downmix_mode;
   ismd_audio_dts_hd_spkr_remap_mode_t *spkr_remap_mode;
   ismd_audio_dts_hd_audio_prstn_select_t *audiopresentselect; 
   ismd_audio_dts_hd_replacement_set_t *repset; 
   bool *param_value_ptr;
   switch(param_id)
   {
      case ISMD_AUDIO_DTS_HD_PCM_SAMPLE_WIDTH:
         sample_width = (ismd_audio_dts_hd_sample_width_t *) param_value;
         switch(*sample_width) 
         {
            case ISMD_AUDIO_DTS_HD_SAMPLE_WIDTH_16:
            case ISMD_AUDIO_DTS_HD_SAMPLE_WIDTH_24:
               psm_decode_params->host.codec.config.dts_hd_params.sample_width= *sample_width;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("DTS HD: PCM sample width param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         break;
      case ISMD_AUDIO_DTS_HD_SPKROUT:
         spkrout = (ismd_audio_dts_hd_speaker_activity_mask_t *) param_value;
         switch(*spkrout) 
         {
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_DEFAULT:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_LFE1:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_L_R:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_L_R_LFE1:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_LT_RT:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_LFE1:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_L_R_CS:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_L_R_CS_LFE1:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_CS:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_CS_LFE1:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_L_R_LS_RS:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_L_R_LS_RS_LFE1:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_LS_RS_LFE1:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_LS_RS_LFE1_LHS_RHS:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_LFE1_LSR_RSR_LSS_RSS:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_LS_RS_LFE1_LH_RH:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_LS_RS_LFE1_LSR_RSR:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_LS_RS_LFE1_CS_CH:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_LS_RS_LFE1_CS_OH:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_LS_RS_LFE1_LW_RW:
            case ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_C_L_R_LS_RS_LFE1_CS:
               psm_decode_params->host.codec.config.dts_hd_params.spkrout = *spkrout;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("DTS HD: speaker_output_acctivity_mask param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         break;

      case  ISMD_AUDIO_DTS_HD_DRC_PERCENT:

         dyn_rng_comp_prct = (ismd_audio_dts_hd_dynamic_range_compression_percent_t *) param_value;

         if(*dyn_rng_comp_prct >= 0 && *dyn_rng_comp_prct <=100) {
            psm_decode_params->host.codec.config.dts_hd_params.drc_percent = *dyn_rng_comp_prct;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("DTS HD: dynamic_range_compression_percent param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;

      case ISMD_AUDIO_DTS_HD_LFEDNMX:
         lfe_downmx = (ismd_audio_dts_hd_lfe_downmix_t *) param_value;
         switch(*lfe_downmx) 
         {
            case ISMD_AUDIO_DTS_HD_LFE_DOWNMIX_NONE:
            case ISMD_AUDIO_DTS_HD_LFE_DOWNMIX_10DB:
               psm_decode_params->host.codec.config.dts_hd_params.lfe_index = *lfe_downmx;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("DTS HD: LFE Downmix param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         break;
      case ISMD_AUDIO_DTS_HD_DECODE_TYPE:
         decode_type = (ismd_audio_dts_hd_decode_type_t *) param_value;
         switch(*decode_type) 
         {
            case ISMD_AUDIO_DTS_HD_DECODE_NATIVE:
            case ISMD_AUDIO_DTS_HD_DECODE_ONLY_96KFROM192K:
            case ISMD_AUDIO_DTS_HD_DECODE_ONLY_CORE:
            case ISMD_AUDIO_DTS_HD_DECODE_ONLY_CORE_SUBSTREAM:
               psm_decode_params->host.codec.config.dts_hd_params.decode_type = *decode_type;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("DTS HD: decode type param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         break;
      case ISMD_AUDIO_DTS_HD_DOWNMIX_MODE:
         downmix_mode = (ismd_audio_dts_hd_downmix_mode_t *) param_value;
         switch(*downmix_mode) 
         {
            case ISMD_AUDIO_DTS_DOWNMIX_MODE_EXTERNAL:
            case ISMD_AUDIO_DTS_DOWNMIX_MODE_INTERNAL:
            case ISMD_AUDIO_DTS_DOWNMIX_MODE_PARTIAL:               
               psm_decode_params->host.codec.config.dts_hd_params.downmix_mode = *downmix_mode;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("DTS HD: dowmix mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         break;
      case ISMD_AUDIO_DTS_HD_SPKR_REMAP_MODE:
         spkr_remap_mode = (ismd_audio_dts_hd_spkr_remap_mode_t *) param_value;
         switch(*spkr_remap_mode) 
         {
            case ISMD_AUDIO_DTS_HD_SPKR_REMAP_MODE_EXTERNAL:
            case ISMD_AUDIO_DTS_HD_SPKR_REMAP_MODE_INTERNAL:
               psm_decode_params->host.codec.config.dts_hd_params.spkr_remap_mode = *spkr_remap_mode;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("DTS HD: spkr remap mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         break;         
      case ISMD_AUDIO_DTS_HD_MULTILE_ASSET_DECODE:
         param_value_ptr = (bool *) param_value;
         if((*param_value_ptr == true)||(*param_value_ptr == false)){
            psm_decode_params->host.codec.config.dts_hd_params.multi_asset_decoding = *param_value_ptr;
         }
         else{
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("DTS HD: multi asset decoding param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
      case ISMD_AUDIO_DTS_HD_ENABLE_DTS_ES_61_MATRIX:
         param_value_ptr = (bool *) param_value;
         if((*param_value_ptr == true)||(*param_value_ptr == false)){
            psm_decode_params->host.codec.config.dts_hd_params.enable_dts_es_matrix_sound_track = *param_value_ptr;
         }
         else{
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("DTS HD: multi asset decoding param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
      case ISMD_AUDIO_DTS_HD_DISABLE_DIALNORM:
         param_value_ptr = (bool *) param_value;
         if((*param_value_ptr == true)||(*param_value_ptr == false)){
            psm_decode_params->host.codec.config.dts_hd_params.disable_dialogue_normalization = *param_value_ptr;
         }
         else{
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("DTS HD: multi asset decoding param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
      case ISMD_AUDIO_DTS_HD_NO_DEFAULT_SPKR_REMAP:
         param_value_ptr = (bool *) param_value;
         if((*param_value_ptr == true)||(*param_value_ptr == false)){
            psm_decode_params->host.codec.config.dts_hd_params.no_default_speaker_remapping = *param_value_ptr;
         }
         else{
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("DTS HD: multi asset decoding param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
      case ISMD_AUDIO_DTS_HD_AUDIO_PRESENTATION_SELECT:
         audiopresentselect = (ismd_audio_dts_hd_audio_prstn_select_t *) param_value;
         psm_decode_params->host.codec.config.dts_hd_params.audiopresentindex = *audiopresentselect; 
         break;
      case ISMD_AUDIO_DTS_HD_REPLACEMENT_SET_SELECT:
         repset = (ismd_audio_dts_hd_replacement_set_t *) param_value;
         psm_decode_params->host.codec.config.dts_hd_params.replacementsetconfig[psm_decode_params->host.codec.config.dts_hd_params.number_repchsets] = *repset;
         psm_decode_params->host.codec.config.dts_hd_params.number_repchsets++;
         break;

      case ISMD_AUDIO_DTS_HD_SEC_AUD_SCALING:
      
         param_value_ptr = (bool *) param_value;

         if((*param_value_ptr == true)||(*param_value_ptr == false)){
            psm_decode_params->host.codec.config.dts_hd_params.secondary_audio_present= *param_value_ptr;
         }
   	   else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("dts: secondary audio scaling param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
         
      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("DTS HD: invalid config param type!", result, audio_devh[AUDIO_DEBUG_APM]);    
         break;
   }

   return result;
}

ismd_result_t
audio_dts_hd_set_default_decode_params(audio_psm_decode_params_t *dec_params )
{
   ismd_result_t result = ISMD_SUCCESS;

   OS_MEMSET((char *)dec_params, 0, sizeof(audio_psm_stage_params_t)); 

   dec_params->host.codec.config.dts_hd_params.sample_width = ISMD_AUDIO_DTS_HD_SAMPLE_WIDTH_24;
   dec_params->host.codec.config.dts_hd_params.spkrout = ISMD_AUDIO_DTS_HD_SPEAKER_ACTIVITY_MASK_DEFAULT;
   dec_params->host.codec.config.dts_hd_params.drc_percent = 0;
   dec_params->host.codec.config.dts_hd_params.lfe_index = ISMD_AUDIO_DTS_HD_LFE_DOWNMIX_NONE;
   dec_params->host.codec.config.dts_hd_params.decode_type = ISMD_AUDIO_DTS_HD_DECODE_NATIVE;
   dec_params->host.codec.config.dts_hd_params.downmix_mode = ISMD_AUDIO_DTS_HD_DOWNMIX_MODE_INTERNAL;
   dec_params->host.codec.config.dts_hd_params.spkr_remap_mode = ISMD_AUDIO_DTS_HD_SPKR_REMAP_MODE_INTERNAL;
   dec_params->host.codec.config.dts_hd_params.multi_asset_decoding = false;
   dec_params->host.codec.config.dts_hd_params.enable_dts_es_matrix_sound_track = false;
   dec_params->host.codec.config.dts_hd_params.disable_dialogue_normalization = false;
   dec_params->host.codec.config.dts_hd_params.no_default_speaker_remapping = false;
   dec_params->host.codec.config.dts_hd_params.number_repchsets = 0;
   // We are not suppose to set the default value to audiopresentindex.
   // For example, the default value 0 will force the decoder to decode 
   // audio presentation index=0 in the Extension SubStream with index=0.
   // However, if the test stream only has audio presentation at index=0 in 
   // the Extension SubStream with index=2, we got no output.
   // On the other hand, if we don't set audiopresentindex, the decoder will 
   // look for audio presentation with index=0 in all Extension SubStreams.
   // As a result, an invalid value, 0xffff, is set as default value, so the
   // audiopresentindex setting API in dtshd_set_parameters() will have no function.  
   dec_params->host.codec.config.dts_hd_params.audiopresentindex = 0xffff;
   dec_params->host.codec.config.dts_hd_params.secondary_audio_present = false;
   return result;
}


