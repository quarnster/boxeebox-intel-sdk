/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2008 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"

#define AC3_MAX_CHANNELS 6

#define LEFT_CHAN_INDEX                 0
#define CENTER_CHAN_INDEX               1
#define RIGHT_CHAN_INDEX                2
#define LEFT_SUR_CHAN_INDEX             3
#define RIGHT_SUR_CHAN_INDEX            4
#define LFE_CHAN_INDEX                  5 

#define AC3_SCALE_FACTOR_MAX 0x007FFFFF
#define AC3_SCALE_DEFAULT AC3_SCALE_FACTOR_MAX
#define AC3_EXT_DOWNMIX_ARRAY_MAX 36


ismd_result_t
audio_dd_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_ac3_karaoke_reproduction_mode_t *karaoke_mode;
   ismd_audio_ac3_dynamic_range_compression_mode_t *dyn_rng_comp_mode;
   ismd_audio_ac3_lfe_channel_output_t *lfe_ch_output;
   ismd_audio_ac3_output_configuration_t *output_config;
   ismd_audio_ac3_stereo_output_mode_t *stereo_out_mode;
   ismd_audio_ac3_dual_mono_reproduction_mode_t *dual_mono_rep_mode;
   ismd_audio_ac3_channel_route_t *ch_route;
   ismd_audio_ac3_pcm_scale_factor_t *pcm_scale_factor;
   ismd_audio_ac3_high_freq_dynamic_cut_scale_factor_t *hi_freq_dyn_cut_scale;
   ismd_audio_ac3_low_freq_dynamic_boost_scale_factor_t *low_freq_dyn_bst_scale;
   ismd_audio_ac3_num_output_channels_t *output_channels;
   ismd_audio_ac3_block_repeat_count_t *block_repeat_cnt;

   switch(param_id)
   {
      case ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE :

         karaoke_mode = (ismd_audio_ac3_karaoke_reproduction_mode_t *) param_value;
         
         switch(*karaoke_mode) {
            
            case ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE_NO_VOCAL:
            case ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE_LEFT_VOCAL:
            case ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE_RIGHT_VOCAL:
            case ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE_BOTH_VOCALS:
               psm_decode_params->host.codec.config.ac3_params.karac = *karaoke_mode;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: karaoke_repro_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         
         break;
         
      case  ISMD_AUDIO_AC3_DYNAMIC_RANGE_COMPRESSION_MODE :
         
         dyn_rng_comp_mode = (ismd_audio_ac3_dynamic_range_compression_mode_t *) param_value;
         
         switch(*dyn_rng_comp_mode) {
            
            case ISMD_AUDIO_AC3_CUSTOM_MODE_ANALOG_DIALOG_NORMALIZATION:
            case ISMD_AUDIO_AC3_CUSTOM_MODE_DIGITAL_DIALOG_NORMALIZATION:
            case ISMD_AUDIO_AC3_LINE_OUT_MODE:
            case ISMD_AUDIO_AC3_RF_REMOTE_MODE:
               psm_decode_params->host.codec.config.ac3_params.dynrng_mode = *dyn_rng_comp_mode;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: dyn_rng_comp_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         
         break;
         
      case ISMD_AUDIO_AC3_LFE_CHANNEL_OUTPUT :

         lfe_ch_output = (ismd_audio_ac3_lfe_channel_output_t *) param_value;
         
         switch(*lfe_ch_output) {
            
            case ISMD_AUDIO_AC3_LFE_CHANNEL_OUTPUT_NONE:
            case ISMD_AUDIO_AC3_LFE_CHANNEL_OUTPUT_ENABLED:
            case ISMD_AUDIO_AC3_LFE_CHANNEL_OUTPUT_DUAL:
               psm_decode_params->host.codec.config.ac3_params.lfe_out = *lfe_ch_output;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: lfe_ch_output param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         
         break;
         
      case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION :
                  
         output_config = (ismd_audio_ac3_output_configuration_t *) param_value;
         
         switch(*output_config) {
            
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_RESERVED:
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_1_0_C:
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_2_0_LR:
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_3_0_LCR:
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_2_1_LRl:
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_3_1_LCRl:        
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_2_2_LRlr:           
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_3_2_LCRlr:       
               psm_decode_params->host.codec.config.ac3_params.ocfg = *output_config;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: output_config param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         
         break;
         
      case ISMD_AUDIO_AC3_STEREO_OUTPUT_MODE :

         stereo_out_mode = (ismd_audio_ac3_stereo_output_mode_t *) param_value;
         
         switch(*stereo_out_mode) {
            
            case ISMD_AUDIO_AC3_STEREO_OUTPUT_MODE_AUTO_DETECT:
            case ISMD_AUDIO_AC3_STEREO_OUTPUT_MODE_SURROUND_COMPATIBLE:
            case ISMD_AUDIO_AC3_STEREO_OUTPUT_MODE_STEREO:
               psm_decode_params->host.codec.config.ac3_params.stereo_mode = *stereo_out_mode;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: stereo_out_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         
         break;
         
      case  ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE :

         dual_mono_rep_mode = (ismd_audio_ac3_dual_mono_reproduction_mode_t *) param_value;
         
         switch(*dual_mono_rep_mode) {
            
            case ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE_STEREO:
            case ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE_LEFT_MONO:
            case ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE_RIGHT_MONO:
            case ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE_MIXED_MONO:
               psm_decode_params->host.codec.config.ac3_params.mono_rep = *dual_mono_rep_mode;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: dual_mono_rep_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         
         break;
         
      case  ISMD_AUDIO_AC3_CHANNEL_ROUTE_L :

         ch_route = (ismd_audio_ac3_channel_route_t *) param_value;

         if(*ch_route >= -1 && *ch_route < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_params.chan_map[LEFT_CHAN_INDEX] = *ch_route;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3: ch_route left param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
            
         break;
         
      case ISMD_AUDIO_AC3_CHANNEL_ROUTE_C :
         
         ch_route = (ismd_audio_ac3_channel_route_t *) param_value;

         if(*ch_route >= -1 && *ch_route < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_params.chan_map[CENTER_CHAN_INDEX] = *ch_route;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3: ch_route center param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
         
      case ISMD_AUDIO_AC3_CHANNEL_ROUTE_R :
                  
         ch_route = (ismd_audio_ac3_channel_route_t *) param_value;

         if(*ch_route >= -1 && *ch_route < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_params.chan_map[RIGHT_CHAN_INDEX] = *ch_route;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3: ch_route right param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
  
         break;
         
      case ISMD_AUDIO_AC3_CHANNEL_ROUTE_Ls :
                           
         ch_route = (ismd_audio_ac3_channel_route_t *) param_value;

         if(*ch_route >= -1 && *ch_route < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_params.chan_map[LEFT_SUR_CHAN_INDEX] = *ch_route;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3: ch_route left_sur param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
  
         break;
         
      case ISMD_AUDIO_AC3_CHANNEL_ROUTE_Rs :
                           
         ch_route = (ismd_audio_ac3_channel_route_t *) param_value;

         if(*ch_route >= -1 && *ch_route < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_params.chan_map[RIGHT_SUR_CHAN_INDEX] = *ch_route;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3: ch_route right_sur param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         break;
         
      case  ISMD_AUDIO_AC3_CHANNEL_ROUTE_LFE :
                  
         ch_route = (ismd_audio_ac3_channel_route_t *) param_value;

         if(*ch_route >= -1 && *ch_route < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_params.chan_map[LFE_CHAN_INDEX] = *ch_route;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3: ch_route lfe param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         break;
         
      case ISMD_AUDIO_AC3_PCM_SCALE_FACTOR :

         pcm_scale_factor = (ismd_audio_ac3_pcm_scale_factor_t *) param_value;
         
         if(*pcm_scale_factor>= 0 && *pcm_scale_factor <= AC3_SCALE_FACTOR_MAX) {            
               psm_decode_params->host.codec.config.ac3_params.pcm_scale = *pcm_scale_factor;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: pcm_scale_factor param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }
         
         break;
         
      case ISMD_AUDIO_AC3_DYNAMIC_RANGE_HIGH_FREQ_CUT_SCALE_FACTOR :

         hi_freq_dyn_cut_scale = (ismd_audio_ac3_high_freq_dynamic_cut_scale_factor_t *) param_value;
         
         if(*hi_freq_dyn_cut_scale>= 0 && *hi_freq_dyn_cut_scale <= AC3_SCALE_FACTOR_MAX) {            
               psm_decode_params->host.codec.config.ac3_params.dyn_cut_hi = *hi_freq_dyn_cut_scale;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: hi_freq_dyn_cut_scale param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }
         
         break;
         
      case ISMD_AUDIO_AC3_DYNAMIC_RANGE_LOW_FREQ_BOOST_SCALE_FACTOR :

         low_freq_dyn_bst_scale = (ismd_audio_ac3_low_freq_dynamic_boost_scale_factor_t *) param_value;
         
         if(*low_freq_dyn_bst_scale>= 0 && *low_freq_dyn_bst_scale <= AC3_SCALE_FACTOR_MAX) {            
               psm_decode_params->host.codec.config.ac3_params.dyn_boost_lo = *low_freq_dyn_bst_scale;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: low_freq_dyn_bst_scale param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }
         
         break;
         
      case ISMD_AUDIO_AC3_NUM_OUTPUT_CHANNELS :
         
          output_channels = (ismd_audio_ac3_num_output_channels_t *) param_value;
         
         if(*output_channels > 0 && *output_channels <= AC3_MAX_CHANNELS) {            
               psm_decode_params->host.codec.config.ac3_params.num_och = *output_channels;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: output_channels param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }
         
         break;

      case ISMD_AUDIO_AC3_BLOCK_REPEAT_COUNT:
         
          block_repeat_cnt = (ismd_audio_ac3_block_repeat_count_t *) param_value;
         
         if((*block_repeat_cnt >= -1) && (*block_repeat_cnt < (int)sizeof(int))) {            
               psm_decode_params->host.codec.config.ac3_params.block_repeat = *block_repeat_cnt;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ac3: block_repeat_cnt param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }
         
         break;

/* This parameter not needed for cert, don't use this unless you know what you are doing 
      case ISMD_AUDIO_AC3_EXTERNAL_DOWNMIX_TABLE:
         
          exernal_downmix_table = (ismd_audio_ac3_external_downmix_table_t *) param_value;
         
         for(loop = 0; loop < AC3_EXT_DOWNMIX_ARRAY_MAX; loop++) {
            psm_decode_params->host.codec.config.ac3_params.ext_dnmixtab[loop] = *exernal_downmix_table[loop];
         }
         
         break; */

      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("ac3: invalid config param type!", result, audio_devh[AUDIO_DEBUG_APM]);    
         break;
   }

   return result;
}

ismd_result_t
audio_dd_set_default_decode_params(audio_psm_decode_params_t *dec_params)
{
   ismd_result_t result = ISMD_SUCCESS;

   OS_MEMSET((char *)dec_params, 0, sizeof(audio_psm_stage_params_t)); 

   //Set AC3 default codec params here.
   dec_params->host.codec.config.ac3_params.num_och = 6;//Always set to max since we have a mixer/downmixer
   dec_params->host.codec.config.ac3_params.ocfg = 7;                 
   dec_params->host.codec.config.ac3_params.lfe_out = ISMD_AUDIO_AC3_LFE_CHANNEL_OUTPUT_ENABLED;
   dec_params->host.codec.config.ac3_params.block_repeat = -1;
   dec_params->host.codec.config.ac3_params.karac = ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE_BOTH_VOCALS;
   dec_params->host.codec.config.ac3_params.dynrng_mode = ISMD_AUDIO_AC3_LINE_OUT_MODE;
   dec_params->host.codec.config.ac3_params.pcm_scale = AC3_SCALE_DEFAULT;
   dec_params->host.codec.config.ac3_params.stereo_mode = ISMD_AUDIO_AC3_STEREO_OUTPUT_MODE_AUTO_DETECT;
   dec_params->host.codec.config.ac3_params.mono_rep = ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE_STEREO;
   dec_params->host.codec.config.ac3_params.dyn_cut_hi = AC3_SCALE_DEFAULT;
   dec_params->host.codec.config.ac3_params.dyn_boost_lo = AC3_SCALE_DEFAULT;
   
   /* Channel map order: [L, C, R, Ls, Rs, LFE]. */         		
   dec_params->host.codec.config.ac3_params.chan_map[LEFT_CHAN_INDEX] =        0;
   dec_params->host.codec.config.ac3_params.chan_map[LFE_CHAN_INDEX] =         1;
   dec_params->host.codec.config.ac3_params.chan_map[LEFT_SUR_CHAN_INDEX] =    2;
   dec_params->host.codec.config.ac3_params.chan_map[RIGHT_CHAN_INDEX] =       3;
   dec_params->host.codec.config.ac3_params.chan_map[CENTER_CHAN_INDEX] =      4;
   dec_params->host.codec.config.ac3_params.chan_map[RIGHT_SUR_CHAN_INDEX] =   5;      		

  
   return result;
}


