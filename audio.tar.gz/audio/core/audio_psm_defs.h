/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_PSM_DEFS_H_
#define _AUDIO_PSM_DEFS_H_

/* --------------------------------------------------------------------------- */
/* !!! WARNING NOTICE !!! */
/* --------------------------------------------------------------------------- */
/* The HOST and DSP FW need to be recompiled if changes are made to this file  */
/* --------------------------------------------------------------------------- */

#include "ismd_audio_defs.h"
#include "audio_packetizer_defs.h"
#include "audio_quality_defs.h"
#include "audio_psm_codec_param_defs.h"

#define PSM_MAX_INPUT AUDIO_MAX_INPUTS
#define PSM_MAX_OUTPUT AUDIO_MAX_INPUTS
#define AUDIO_PSM_MAX_WORKLOADS 8

#define SMD_1KB_BUFFERS (1*1024)
#define SMD_2KB_BUFFERS (2*1024)
#define SMD_4KB_BUFFERS (4*1024)
#define SMD_8KB_BUFFERS (8*1024)
#define SMD_16KB_BUFFERS (16*1024)
#define SMD_32KB_BUFFERS (32*1024)
#define SMD_64KB_BUFFERS (64*1024)
#define SMD_256KB_BUFFERS (256*1024)
#define SMD_512KB_BUFFERS (512*1024)
#define SMD_1MB_BUFFERS (1*1024*1024)
#define SMD_2MB_BUFFERS (2*1024*1024)
#define SMD_4MB_BUFFERS (4*1024*1024)

#if PSM_MAX_INPUT > PSM_MAX_OUTPUT
	#define PSM_MAX_IO_COUNT PSM_MAX_INPUT
#else
	#define PSM_MAX_IO_COUNT PSM_MAX_OUTPUT	//maximum number of parameters than a user can configure per decoder
#endif

/** This is the max queue depth of the DSP job queues.*/
#define PSM_PIPE_JOB_QUEUE_DEPTH 3
/** This is how many output queues we support per DSP PSM pipe. */
#define PSM_PIPE_MAX_NUM_OUT_QUEUES AUDIO_MAX_OUTPUTS

/**The maximum number of stages we need per processor, 
   this value may need to increase if more stages could be potentially 
   added and running simultaniously.*/
#define PSM_STAGES_NEEDED_PER_PROCESSOR 21 
#define PSM_MIN_STAGES_NEEDED_FOR_MAX_PROCESSORS AUDIO_MAX_PROCESSORS * PSM_STAGES_NEEDED_PER_PROCESSOR

#define AUDIO_DESCRIPTION_NOT_VALID 0
#define AUDIO_DESCRIPTION_VALID     1
#define AUDIO_DESCRIPTION_ERROR     2
#define AD_MAX_TRANSMIT_COUNT       1

/*Use this to specify no buffer for tags */
#define AUDIO_TAG_BUF_ID_INVALID -1

/** The maximum number of SRS output contexts supported **/
#define AUDIO_SRS_MAX_OUTPUTS 1

typedef enum {
   METADATA_ASSOCIATION_QUEUE_FIRST_OUTPUT_PTR = 0,
   METADATA_ASSOCIATION_QUEUE_SECOND_OUTPUT_PTR,
   METADATA_ASSOCIATION_QUEUE_MAX_OUTPUT_POINTER_NUM
} audio_psm_metadata_association_queue_output_index_t;

#define CODEC_ATTACH_MS10_FLAG(x) ((x) | 0x00000080)
#define CODEC_DETACH_MS10_FLAG(x) ((x) & 0xFFFFFF7F)

#define CODEC_ATTACH_DCV_FLAG(x) ((x) | 0x00000040)

typedef int audio_psm_buf_desc_handle_t;
typedef int audio_psm_stage_handle_t;
typedef int audio_psm_pipe_handle_t;
typedef int audio_psm_job_handle_t;

/** Used to track the format of the output buffer from the encoder.*/
typedef enum {
   ENCODE_OUTPUT_INDEX_FRAME = 0,       /** The index of the output that has the encoded frame.*/
   ENCODE_OUTPUT_INDEX_IEC61937,        /** The index of the output that has the encoded frame IEC-61937 formatted.*/
   ENCODE_OUTPUT_COUNT
}audio_psm_encoder_output_index_t;

/* --------------------------------------------------------------------------- */
/* Buffer descriptor. A buffer desc is just like the SMD buffer desc. 
   It is there since DSP cannot access SMD buffer descriptors. But for conformity
   all implementations of PSM would use this buffer desc instead of the SMD buffer
   desc. Also this allows us to store additional info that is not part of SMD buf desc. */
/* --------------------------------------------------------------------------- */
typedef struct 
{
   int handle; /* Usually the index into the array to which this element belongs to. */
   void *smd_buf_desc;	/* SMD Buffer desc that the host uses to manage the buffer */

   /* Is used only in the DSP */
   void *dsp_phys_address; /* Address is always specified in DSP address range. IA_phys_add - remap_address */
   void *md_wl; /* Pointer to the metadata association struct, used by the encoder and down stream components. */
   unsigned int size;
   unsigned int level;  /* Level of the valid data inside the buffer. */
   unsigned int eos;   /* eos tag. */
   unsigned int tags; /* buffer has tags */
   /* Metadata  */
   audio_buffer_attr_t metadata;
   bool in_all_output_queues; //To know if this buffer has gone out to all of its output queues.
   bool in_use; 
   uint8_t output_id; //Only need up to PSM_MAX_INPUTS values so 8 bits is ok.

   char cacheline_pad[5];
} audio_psm_buf_desc_t;
/* --------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------- */
/* Tasks and their corresponding structures. Each task would require different 
	information as input, hence different structures. */
/* --------------------------------------------------------------------------- */
typedef enum
{
   PSM_TASK_UNKNOWN, // 0
   PSM_TASK_ECHO, // 1
   PSM_TASK_IN, 	// 2
   PSM_TASK_OUT, // 3
   PSM_TASK_DECODE, // 4
   PSM_TASK_ENCODE, // 5
   PSM_TASK_MIX, // 6
   PSM_TASK_SRC, // 7
   PSM_TASK_DOWNMIX,  // 8
   PSM_TASK_CONVERT, // 9
   PSM_TASK_INTERLEAVER, // 10
   PSM_TASK_DEINTERLEAVER, // 11
   PSM_TASK_BM, // 12
   PSM_TASK_DM, // 13
   PSM_TASK_DATA_DIV, //14
   PSM_TASK_PCM_DECODE, //15
   PSM_TASK_PACKETIZE_ENCODED_DATA, //16
   PSM_TASK_WAIT_IO_EVENT,  //17
   PSM_TASK_PIPE_TIME,    //18
   PSM_TASK_DATA_ACCUMULATOR, //19
   PSM_TASK_PRESRC,       // 20
   PSM_TASK_WATERMARK,     //21
   PSM_TASK_BIT_DEPTH_CONVERTER,     //22
   PSM_TASK_AUDIO_QUALITY, //23
   PSM_TASK_PER_OUTPUT_DELAY,  //24
   PSM_TASK_MS10_DDC_SYNC,     //25
   PSM_TASK_CAPP, //26
   PSM_TASK_IEC_PARSER, //27
   PSM_TASK_BIT_BUCKET,//28
   PSM_TASK_SRS //29
}audio_psm_stage_task_t;


/* --- Definitions for optional in-band metadata (mixer and downmixer coefficients, etc.) --- */
#define OPT_METADATA_INVALID (-1)
#define DMIX_COEFF_CNT_DTS 64

typedef struct{
   int bsid;                           /* Bitstream identification: bsid = 6 (Annex D bit-stream id), bsid = 16 (DDPlus bit-stream id) */
   int acmod;                          /* acmod */
   bool xbsi1e;                        /* Flag to indicate Extra BSI1 info exists. For AC3 packet, if xbsile is set to TRUE, ltrt_dmixlevs/loro_dmixlevs should be used */
   bool mixmdate;		                  /* Mixing metadata exists flag for DDPlus packet */
   dolby_dmixlevs_t dd_dmixlevs;	      /* Legacy AC3 downmix levels*/
   dolby_dmixlevs_t ltrt_dmixlevs;     /* Lt/Rt downmix levels 		*/
   dolby_dmixlevs_t loro_dmixlevs;     /* Lo/Ro downmix levels 		*/   
   int ocfg;  /*for dolby codec, put the ocfg value here. downmixer stage need this parameter */ 
}dolby_downmix_coeff_t;

typedef struct {
   int acmod;                          /* acmod */
   bool upmix_decoder_done;            /* flag to indicate if upmix is done in decoder stage */
   bool dmix_decoder_done;             /* flag to indicate if downmix is done in decoder stage */
   /*MPEG downmix metadata*/
   int aac_id;                         /* tell the AAC stream is MPEG2 or MPEG4 */
   int matrix_mixdown_idx_present;     /* flag to indicate if matrix_mixdown_idx is present in the stream */
   int matrix_mixdown_idx;             /* index to choose downmix coefficent */
   int PCE_present;                    /* flag to indicate if PCE is present in the stream */
   bool pseudo_surround_enable;        /* flag to indicate if pseudo_surround is enabled */
   /*DVB downmix metadata*/
   int center_mix_level;
   int surround_mix_level;
} aac_downmix_metadata_t;

typedef enum {
   AUDIO_SCALE_TYPE_NONE     = 0,  /* Invalid or not present. */
   AUDIO_SCALE_TYPE_DEFAULT  = 1,  /* Gains for input scaled straight-through to output (1-to-1). */
   AUDIO_SCALE_TYPE_MONO     = 2   /* Gains for a mono independently scaled to each output channel (for panning, etc.). */
} audio_scale_type_t;

typedef struct {
   audio_scale_type_t type; 
   audio_int16_t      coeff_index[AUDIO_MAX_OUTPUT_CHANNELS]; /* Index to the gain coefficient in our custom mixer coefficient table. */
} output_mix_config_t;

typedef struct {
   audio_scale_type_t   type; 
   int                  valid_mono_ch;
   int secondary_audio_additional_scaling; //Rev2Aux support
   audio_int16_t        coeff_index[AUDIO_MAX_OUTPUT_CHANNELS]; /* Index to the gain coefficient in our custom mixer coefficient table. */
} output_sec_mix_config_t;

typedef int dmix_coeff_5171_t[4][6];

typedef struct {
   int num_input_channels;                      /** Number of input channels */
   int num_output_channels;                     /** Number of output channels */
   uint32_t ch_map_after_dmix;                  /** The channel map of the output of the DTS downmixer */
   uint8_t scale_lfe;                           /** Flag to indicate if we should perform LFE scaling or not.*/
   uint8_t smooth_coeff;                        /** Flag to disable smoothing of downmix coefficients on first samples PCM (since old coefficients are 0) */
   union {
      int downmixcoeff[DMIX_COEFF_CNT_DTS];        /** Populated by DTS Library on XA_DTSHDDEC_CONFIG_PARAM_DOWNMIXCOEFF */ 
      dolby_downmix_coeff_t ddp_coeff;             /** Populated by DD/DDPlus Library */
      aac_downmix_metadata_t aac_dmix;
   };
   int output_dmix_mode;                        /** The SMD API downmix mode needed on the specific output. */
   ismd_audio_format_t algo;                    /** Indicates the downmix codec type */
} downmix_metadata_context_t;


typedef struct {
   int dec_dmix_mode;                                    /** Indicates if the downmix is happening internal to the decoder or to use the external downmixer.*/
   downmix_metadata_context_t context[AUDIO_MAX_OUTPUTS]; /** Downmix metadata information for each downmix context */
   dmix_coeff_5171_t downmixcoeff71to51;                 /** Populated by DTS Library on XA_DTSHDDEC_CONFIG_PARAM_DOWNMIXCOEFF_71_51 */   
} output_downmix_config_t;


/* 
 * Optional metadata in the buffer payload.  This can be found in the buffer payload at base + opt_metadata_offset. 
 * It is separate from the standard metadata becuase it is not always used and it can be quite large.  
 */
typedef struct {
   output_mix_config_t pri_scale;         /* Per-channel scaling for primary stream applied during mixing. */
   output_sec_mix_config_t sec_scale;         /* Per-channel scaling for secondary stream applied during mixing. */
   output_mix_config_t master_scale;      /* Per-channel scaling applied post-mix. */
   output_downmix_config_t dmix_config;
} opt_metadata_t;

/* --------------------------------------------------------------------------- */

/*****************************************************************/
/******** PSM stage host updatable prameters declarations ********/
/*****************************************************************/


/** Mixer stage parameters configurable from the HOST.*/
typedef struct {
   int32_t        coeff_changed;                   /** Counter to tell us whether there was change in the mixer coeffiecients. Which causes the mixer to smoothly transition. */
   int32_t        output_ch_gains_id;              /** channel id for output channel gains to be applied for individual channel volume control */
   int32_t        output_sample_size;              /** Sample size of output data. */
   uint32_t       operate_in_default_mode;         /** Flag to tell us to operate in default mix mode (1:1)*/
   int32_t        primary_index;                   /** index of the primary stream in the input_config array, this one may have downmixing metadata*/
   int32_t        secondary_index;                 /** index of the secondary stream in the input_config array, this one may have mixing metadata*/
   uint32_t       use_stream_metadata;             /** Flag to tell us to use the mix metadata in the stream or the user-specified mix coefficients.*/
   int32_t        oob_gains_set;                   /** Flag to tell us out of band, (user) mixer coefficients have been specified.*/
   int32_t        output_ch_config;                /** Output channel ordering*/
   int32_t        ch_config_mode;                  /** User sets this to control the output channel configuration at the mixer. */
   int32_t        ch_config_mode_fixed_ch_cfg;     /** When ch_config_mode is set to FIXED need to use this variable as the output channel config for the mixer.*/
   int32_t        output_ch_gains[AUDIO_MAX_OUTPUT_CHANNELS]; /** output channel gains to be applied for individual channel volume control*/
   /* Since we are only updating one input's coeff at a time no need to store the entire array.*/
   ismd_audio_channel_mix_config_t channel_mix_config;/** Channel mix configuration of the input being updated.*/
   uint32_t       input_index;                     /** The index of the current input config being updated.*/
} audio_mixer_config_params_host_t;


/** Information the codec needs about the output configurations. */
typedef struct {
   unsigned int ch_count;
   ismd_audio_downmix_mode_t dmix_mode;
}audio_ouput_info_t;


/** Variables used by the codec stage that are changed by the host and picked up by the DSP.  */
typedef struct {
   int                                 pri_dec_stage_addr;                       /** Host physical address of primary decoder. Used for mix metadata purposes. */
   bool_shared_t                       ignore_eos;                               /** Flag to force codec to ignore eos (don't deinit) but propagate. Used for post processing stages i.e. enccoders. */
   bool_shared_t                       packetize_output;                         /** Flag to tell encoder to packetize output or not */
   ismd_audio_format_t                 algo;                                     /** Codec to be used for processing in the stage. */     
   audio_psm_decode_config_params_t    config;                                   /** Parameters supplied to configure the codec's knobs. */  
   audio_ouput_info_t                  outputs[AUDIO_MAX_OUTPUTS];               /** Contains the downmix mode of each output to the processor. Used for downmix coeff. */
}audio_codec_params_host_t;

/** Variables used by the packetizer stage that are changed by the host and picked up by the DSP.  */
typedef struct {
   bool_shared_t                       init_done;                                /** Reinit the packetizer if this flag is set to false.. */
   bool_shared_t                       expand_for_hw;                            /** Expand to 32b if needed. */
   bool_shared_t                       disable_stage;                            /** Disables the packetizer completely. (Will discard all input data). */
   int                                 pass_through_sample_rate;                 /** Sample rate to notify direct mode of transmit sample rate. */     
   ismd_audio_pass_through_mode_t      pass_through_mode;                        /** Passthrough mode see \ref ismd_audio_pass_through_mode_t */  
}audio_packetizer_params_host_t;

/** Variables used by the pcm decode stage that are changed by the host and picked up by the DSP.  */
typedef struct {
   bool_shared_t                       disable_stage;                            /** Disables the packetizer completely. (Will discard all input data). */
   bool_shared_t                       output_byte_swap;                         /** Byte swap output if set to true. */
   bool_shared_t                       allign_output_for_src;                    /** Set this flag to have PCM handler limit and sample allign for pre src*/
   int                                 output_sample_size;                       /** Optionally set the output sample size to convert to.*/
}audio_pcm_decode_params_host_t;

/** State variables for custom audio processing stage, picked up by the host at runtime.*/
typedef struct audio_capp_host_params_s {
   uint32_t local_storage_base;  /**Address and size (bytes) of the local storage area for the custom library*/
   uint32_t local_storage_size;   
   uint32_t msg_handle;          /** Message handle to be used for sending messages from the custom library to the host */
   uint32_t enabled;             /** Whether the host wants the stage enabled */
} audio_capp_host_params_t;

/** An instance of an SRS pipe per output.*/
typedef struct {
   bool_shared_t in_use;
   ismd_audio_srs_pipe_params_t pipe;   
   int srs_params_change_notifier;
   
}audio_output_srs_pipe_t;

/** State variables for IEC parser stage, picked up by the host at runtime.*/
typedef struct audio_iec_parser_params_host_s {
   ismd_audio_input_parsing_mode_t parsing_mode;   /** Parsing mode the IEC stage is running in. */
   bool_shared_t packetized_output_enabled;        /** Flag to tell if we need a packetized output or not. */
   ismd_audio_stream_info_t user_set_stream_info;  /** Stream info given by APM about how the input is configured. */
   unsigned int event_mask;                        /** Event mask to specifiy which events to trigger on.*/
} audio_iec_parser_params_host_t;

/** SRS pipeline host parameters. */
typedef struct {
   audio_output_srs_pipe_t context[AUDIO_SRS_MAX_OUTPUTS];     
}audio_srs_params_host_t;

/** Per-output delay stage host-updateable parameters specific to each stage output */
typedef struct {
   int new_delay;
} audio_per_output_delay_host_output_info_t;

/** Per-output delay stage host-updateable parameters */
typedef struct {
   audio_per_output_delay_host_output_info_t host_output_params[PSM_MAX_OUTPUT];   
} audio_per_output_delay_host_params_t;

/** SRC stage host parameters. */
typedef struct {
   int primary_index;
   ismd_audio_mix_sample_rate_mode_t mix_src_mode;
   ismd_audio_src_quality_t src_quality;
   int vsrc_set_var_on[AUDIO_MAX_INPUTS];
   int output_sample_rate[AUDIO_MAX_INPUTS];
} audio_src_params_host_t;

/** These are the stage parameters only updated by the host. Copied
    over by the DSP to its local copy. This should be used by
    all stages that need "on the fly" updates to parameters. */
typedef struct {
   union {
      audio_mixer_config_params_host_t    mixer;
      audio_codec_params_host_t           codec;
      audio_iec_parser_params_host_t      iec_parse;
      audio_packetizer_params_host_t      packetize;
      audio_pcm_decode_params_host_t      pcm_dec;
      audio_capp_host_params_t            capp;
      audio_srs_params_host_t             srs;
      audio_per_output_delay_host_params_t per_output_delay;
      audio_src_params_host_t             src;
   };
   char cachline_pad[16];
} audio_psm_stage_parms_host_t;


/*****************************************************************/
/*****************************************************************/
/*****************************************************************/
/** Various bit masks for different SRS blocks */
#define FILTER_1_CHANGED       1
#define FILTER_2_CHANGED       1<<1
#define TRU_VOLUME_CHANGED     1<<2
#define CS_DECODER_CHANGED     1<<3
#define TRU_DIALOG_CHANGED     1<<4
#define TRU_SUR_HD_CHANGED     1<<5
#define HARD_LIMITER_CHANGED   1<<6
#define GRAPHIC_EQ_CHANGED     1<<7
#define PARAMETRIC_EQ_CHANGED  1<<8
#define MASTER_BYPASS_ENABLE   1<<9

/** Mask to find out if SRS params changed or not */
#define SRS_PARAMS_CHANGED_MASK 0x7FC00

/**Stage parameters for SRS stage.*/
typedef struct {
   audio_psm_stage_parms_host_t     host;  /** Host's copy of config parameters.*/
   audio_srs_params_host_t          dsp;   /** DSP's copy of config parameters.*/
   /* Params used by the DSP only. When multiple contexts of SRS need to eb supported, these will become arrays as well */  
   audio_psm_buf_desc_t             aux_buffer[AUDIO_SRS_MAX_OUTPUTS]; /** Used to store tables, scratch, persistant memory needed by different instances of SRS */
   bool_shared_t                    init_done;   
   int                              prev_sample_rate[AUDIO_SRS_MAX_OUTPUTS];
   unsigned int*                    p_scratch_memory[AUDIO_SRS_MAX_OUTPUTS];
   unsigned int*                    p_persistent_memory[AUDIO_SRS_MAX_OUTPUTS];
   unsigned int*                    p_studiosound_object[AUDIO_SRS_MAX_OUTPUTS];
} audio_srs_params_t;

typedef struct {
   int current_delay;             //store customer delay input
   char *read_ptr;
   char *write_ptr;
   int bytes_buffered;       //current buffering level of circular buffer
   int delay_bytes_count;    //delay bytes required calculated from customer input
   int silence_bytes_count;  //silence bytes need to insert into output

   int prev_sample_rate;
   int prev_sample_size;
   int prev_channel_count;
   
   audio_psm_buf_desc_t aux_buffer;   
   char *start_address;      //circular buffer start address
   char *end_address;        //circular buffer end address   
   bool buffer_reset;   
   
   bool_shared_t is_changing_non_pcm_delay;
   int search_non_pcm_frame_status;
} audio_per_output_delay_output_info_t;

typedef struct {
   audio_psm_stage_parms_host_t host;  /**Host copy of config params*/
   audio_per_output_delay_host_params_t dsp;
   bool enabled;
   int max_delay_ms;   
   int buffer_size;   
   audio_per_output_delay_output_info_t output_params[PSM_MAX_OUTPUT];
} audio_per_output_delay_params_t;

/* Max number of frames that the decoder can keep internally. */
#define MAX_INFLIGHT_FRAMES 400

typedef struct {
   int                 frame_id;
   int                 input_range_begin;
   int                 input_range_end;
   int                 eos;
   int                 tags_only;
   audio_buffer_attr_t metadata;
} metadata_node_t;

typedef struct {
   int                  input_index;        /* association queue input pointer */
   int                  output_index[METADATA_ASSOCIATION_QUEUE_MAX_OUTPUT_POINTER_NUM];/* association queue output pointer */
   metadata_node_t      association_queue[MAX_INFLIGHT_FRAMES];
} metadata_association_t;


typedef struct capp_metadata_association_t_{
   int byte_position;
   int size;
   int opt_metadata_offset;
   //TODO:  opt_metadata structure can be large, can we find a better place to store it?
   opt_metadata_t opt_metadata;
   audio_buffer_attr_t attribs;
   int eos;
   int tags;
} capp_metadata_association_t;

typedef struct {
   int transmit_count;
   unsigned char valid;
   unsigned char fade;
   unsigned char pan;
   unsigned char pad;
}audio_description_t;

typedef struct{
   int index_history[AUDIO_MAX_INPUT_CHANNELS]; //Used for the 44.1-32 to 48 SRC
   int sample_history[AUDIO_MAX_INPUT_CHANNELS]; //Used for the 44.1-32 to 48 SRC  
} src_44_1_to_48_state_info_t;

typedef struct
{
   /* Host and DSP copy of configureable parameters.*/
   audio_psm_stage_parms_host_t host;
   audio_src_params_host_t dsp;
   
   int auto_output_sample_rate;
   int vsrc_init_flag[AUDIO_MAX_INPUTS];
   int history_buf_index[AUDIO_MAX_INPUTS];
   audio_psm_buf_desc_t aux_buffer[AUDIO_MAX_INPUTS]; /* Used to store SRC history. */
   src_44_1_to_48_state_info_t state_info[AUDIO_MAX_INPUTS];
   ismd_audio_status_t state[AUDIO_MAX_INPUTS];
} audio_psm_src_params_t;


/*********** Start Mixer Parameters ****************/
#define INPUT_INDEX_VALID(index) (((index >= 0) && (index < AUDIO_MAX_INPUTS)))

#define MIX_COEFF_STEPS_PER_DB      8 /* 8 steps per dB (0.125dB increments) */
#define MIX_COEFF_INDEX_MAX         0 /* Index of max gain (+18dB) */
#define MIX_COEFF_INDEX_0_DB      144 /* Index of 0 db gain */
#define MIX_COEFF_INDEX_MUTE     1304 /* Index of Mute (negative infinity) */
#define AUDIO_MAX_GAIN_TABLE 2

//Han added for mixer coefficient smoothing using aux_buffer
typedef struct {
	ismd_audio_channel_mix_config_t	stream_channel_mix_config_pri;         // Channel mix configuration for primary 
	ismd_audio_channel_mix_config_t	stream_channel_mix_config_sec;         // Channel mix configuration for sec 
   int32_t stream_output_ch_gains[AUDIO_MAX_OUTPUT_CHANNELS]; //output channel gains to be applied for individual channel volume control
	int    delta[AUDIO_MAX_INPUTS][AUDIO_MAX_INPUT_CHANNELS][AUDIO_MAX_OUTPUT_CHANNELS];  // For coefficient smoothing
	int    master_delta[AUDIO_MAX_OUTPUT_CHANNELS];                               // For coefficient smoothing
   int new_gain_index;
   int32_t        coeff_changed;                   // Counter to tell us whether there was change in the mixer coeffiecients. 
   short  input_gain_index[AUDIO_MAX_GAIN_TABLE][AUDIO_MAX_INPUTS][AUDIO_MAX_INPUT_CHANNELS][AUDIO_MAX_OUTPUT_CHANNELS];
   short  master_gain_index[AUDIO_MAX_GAIN_TABLE][AUDIO_MAX_OUTPUT_CHANNELS];
	short  sub_flag[AUDIO_MAX_INPUTS][AUDIO_MAX_INPUT_CHANNELS][AUDIO_MAX_OUTPUT_CHANNELS];                 // For coefficient smoothing
   short  number_of_input_channels[AUDIO_MAX_INPUTS];
   short  master_sub_flag[AUDIO_MAX_OUTPUT_CHANNELS];                               // For coefficient smoothing
   bool stream_input_config_valid_pri; 
   bool stream_input_config_valid_sec; 
   bool stream_output_ch_gains_valid; 
   audio_scale_type_t type;
}mixer_internal_mem_layout_t;


/* Mixer input configuration */
typedef struct {
   ismd_audio_channel_mix_config_t	channel_mix_config;         // Channel mix configuration of this input
   uint32_t                         valid;                      // Flag to tell mixer to process this input. Used by FW only.
   int32_t                         *buffer;                     // Pointer to input data
   uint32_t                         num_channels;               // Number of channels in this input
   int32_t                          sample_size;                // Sample size of this input. This must be 32!
   int32_t                          input_ch_config;            // Input channel ordering
   uint32_t                         copy_to_old_metadata_array; // Flag to tell us to copy 
} mixer_input_t;

/** Mixer stage parameters */
typedef struct {
   
   /** The parameters the host updates */
   audio_psm_stage_parms_host_t host;

   /** The parameters the DSP looks at only updated when host notifies of changes. */
   audio_mixer_config_params_host_t dsp;

   /** Used to store internal state of the mixer, allocated by host but then used by the DSP from then on. */
   audio_psm_buf_desc_t aux_buffer;                

   /** These parameters are used by the DSP ONLY.*/
   mixer_input_t  input_config[AUDIO_MAX_INPUTS];  //Input configuration for each input. 
   uint32_t       input_buffer_count;              // Number of inputs
   uint32_t       num_input_samples;               // Number of samples in each input buffer
   int32_t       *output_buffer;                   // Pointer to the output (mixed) buffer
   uint32_t       num_output_channels;             // Number of output channels. 
} audio_mixer_params_t;

/*********** END Mixer Parameters ****************/


/** Variables needed to support codec operation in the decode stage in the DSP.  */
typedef struct
{
   audio_psm_stage_parms_host_t     host;                      /** Params for the codec stage, written to only by the host. Read by DSP. */
   audio_codec_params_host_t        dsp;                       /** DSP's copy of the host updatable parameters.*/
   
   /* Host initializes these variables once, then they are used by the DSP during runtime. */
   audio_psm_buf_desc_t             aux_buffer;                /** Used to store tables, scratch, persistant memory needed by codecs. */
   audio_psm_buf_desc_t             encode_buffer;             /** Used as a temporary memory location to packetize the encoder's output*/
   audio_psm_buf_desc_t             mda_buffer;                /** Meta-data association buffer storage..*/
   audio_psm_buf_desc_t             decode_buffer;             /** Decoder input buffer, data waiting to be decoded stored here. */
   audio_psm_buf_desc_t             fifo_buffer;               /** used for MS10 DDT PP */
   audio_description_t              ad;                        /** Audio description metadata container */
   
   /* These variables are only read and written to by the DSP. */
   void                             *xa_process_api;           /** Tensilica decoder API object.*/
   void                             *xa_process_handle;        /** Tensilica function pointer.*/
   void                             *error_info;               /** Tensilica error info strucute pointer. */
   metadata_association_t           *md_associate;             /** Pointer to metadata association queue memory. */
   
   int                              codec_init_done;           /** Used by codec wrapper to know if it has been initialized yet.*/
   int                              new_input;                 /** Used by codec wrapper to know if a new input buffer has arrived.*/
   int                              metadata_changed;          /** Used to specify if stream in-band metadata has changed. */
   unsigned int                     input_requested;           /** Flag to show know how much the codec requests before it starts operating.*/
   unsigned int                     input_buf_offset;          /** Offset into the input buffer to know how much has been used already.*/
   unsigned int                     stream_position;           /** Total amount of bytes consumed by the encoders. */
   unsigned int                     prev_stream_position;      /** Needed to keep track of the stream position from the previous do_execute. */
   unsigned int                     total_input_bytes;         /** Total amount of bytes given to the encoders. */
   audio_uint64_t                   total_bytes_since_pts;     /** Total bytes since first valid PTS found, used in encoder PTS interpolation.*/
   audio_uint64_t                   curr_interpolated_pts;     /** The current interpolated PTS in use, used in encoder PTS interpolation.*/
   audio_uint64_t                   encode_sync_pts;           /** The first PTS value found to start encoder PTS interpolation. */

   int                              reinit_after_eos;          /** Used to reinit the decoder after EOS is encountered.*/
   int                              processing_eos;            /** Flag used to know if the decoder is in the middle of processing EOS. */
	int										bytes_consumed;				/** Bytes consumed by the codec information for metadata association */

   unsigned int                     out_ch_count;              /** Use to store output channel count from the decoder. */
   unsigned int                     out_samp_freq;             /** Use to store output sample freq from the decoder. */
   unsigned int                     out_data_rate;             /** Use to store output bit rate from the decoder. */
   uint32_t                         out_ch_config;             /** Use to store output ch config from the decoder. */ 
   uint32_t                         prev_ch_map;               /** Use to keep track of the previous channel configuration to determine when it changes. */
   int                              prev_sample_rate;          /** Use to keep track of the previous sample rate to determine when it changes.*/
   int                              acmod;
   int                              prev_exe_status;           /** Use to keep track of the previous DO_EXECUTE status. value could be DECODE_ERROR, SYNC_LOST, SYNC_FOUND */
   bool                             ms10dec_enabled;           /** Flag to tell the DSP this DECODE is for MS10 specific purpose */
   bool                             ms10dec_main;              /** Flag to tell the DSP this is ms10 main DCV decoder */
   int                              ms10dec_ddc_sync;          /** Hosst physical address of ddc frame sync stage. */

   bool                             ddplus_dcv_enabled;        /** Flag to tell the DSP this DECODE is for standalone DCV specific purpose */
   int                              output_buffer_level;       /** Flag used in subframe decoders to advance the pointer to the output buffer. */
   bool                             subframes_avail;           /** The decoder has not finished outputting subframes for the current frame.. */
   ismd_audio_format_specific_stream_info_t stream_info;       /** Stream information provided to the user from the codec stream. */
} audio_psm_decode_params_t;


/* Used for the DTS-HD packetizer*/
typedef enum {
   ISMD_AUDIO_SAMPLE_RATE_NORMAL             =  0,
   ISMD_AUDIO_SAMPLE_RATE_SCALE_TWO          =  2,
   ISMD_AUDIO_SAMPLE_RATE_SCALE_FOUR         =  4,
   ISMD_AUDIO_SAMPLE_RATE_SCALE_EIGHT        =  8,
   ISMD_AUDIO_SAMPLE_RATE_SCALE_SIXTEEN      =  16,
} ismd_audio_sample_rate_scale_t;

typedef struct	{
	unsigned int *pointer_to_inp_pcm_buffer;
	unsigned int *pointer_to_out_spkrremap_pcm_buffer;
	int i_num_inp_channels;
	int i_num_out_channels;
	unsigned int *pointer_to_spkrremap_coefficients;
	int i_number_of_samples_in_single_channel;
    int i_inp_bitwidth;
    int i_out_bitwidth;
    int ch_map_config;
    int output_ch_config;
	int spkrremap_scale;
	int embedded_downmix;
} spkrremap_input_t;
typedef struct	{
   spkrremap_input_t inputs[PSM_MAX_OUTPUT];
   audio_psm_buf_desc_t aux_buffer;
} audio_spkrremap_params_t; 

typedef struct	{
   unsigned int *pointer_to_inp_pcm_buffer;
   unsigned int *pointer_to_out_downmixed_pcm_buffer;
   int i_num_inp_channels;
   int i_num_out_channels;
   unsigned int *pointer_to_downmix_coefficients;
   unsigned int *pointer_to_downmix_coefficients_c2;//2nd set of downmixer coeff for dolby stereo downmix
   unsigned int pointer_to_downmix_coefficients_old[DMIX_COEFF_CNT_DTS]; //Number of coefficients from decoder.
   int i_inp_bitwidth;
   int i_out_bitwidth;
   int i_number_of_samples_in_single_channel;
   int i_flag_noninterleaved;
   int ch_map_config;
   int acmod;
   int ch_indexes[AUDIO_MAX_INPUT_CHANNELS];
   int dolby_cert_mode;
   int b_dtsado_scale_LFE;
   int output_ch_config;
   int dmix_mode;
   int input_buffer_level;
   int final_output_num_ch;
} downmixer_input_t;

/** Enumeration to describe the type of upmix to perform.*/
typedef enum {
   AUDIO_UPMIX_INVALID = -1,
   AUDIO_UPMIX_1_0_to_2_0,
   AUDIO_UPMIX_2_1_to_2_2,
   AUDIO_UPMIX_2_1_to_3_2,
   AUDIO_UPMIX_3_1_to_3_2,
   AUDIO_UPMIX_5_1_to_7_1
} audio_upmix_t;

typedef struct	{
   downmixer_input_t inputs[AUDIO_MAX_OUTPUTS];
   audio_psm_buf_desc_t aux_buffer;          // Auxilliary buffer for storing downnmix coeffients while ramping up or down.
} audio_downmix_params_t;

#define MAX_ES_HEADER_BYTES 20

typedef enum {
   DTS_HD_CORE_SUBSTREAM,
   DTS_HD_EXTENSION_SUBSTREAM,
} dts_hd_substream_type;

typedef enum {
   DTS_HD_CORE_SUBSTREAM_EXIST                          = 1,
   DTS_HD_EXTENSION_SUBSTREAM_ONLY                      = 2,
} dts_hd_frame_payload_structure_t;

typedef struct  {
   bool first_syncframe;
   bool sub2_exist;
   int substream1_num;
   int substream2_num;
   int substream1_cnt;
   int substream2_cnt;
   bool sub1_complete;
   bool sub2_complete;
   bool found_sub1;
   bool found_sub2;
   int strmtyp;
   int substreamid;
   int numblkscod;
   int frame_payload;
   int sub_frame_size;
   int bsid;
   int dd_exist;
} audio_packetizer_ddp_params_t;

typedef struct  {
   bool found_core;
   bool found_extension;
   bool pack_complete;
   int sync_word;   
   int  first_ext_index;
   int  core_syncword_byte_index;
   int  ext_syncword_byte_index;
   dts_hd_substream_type first_sub_type;
   int current_ext_index;
   int frame_payload;
   bool first_sub;
   int frame_size;
   int core_numblk;
   int extension_frame_duration;
   int core_sample_rate;
   int extension_sample_rate;
   ismd_audio_sample_rate_scale_t sample_rate_scale;
   ismd_audio_format_t stream_type;
   dts_hd_frame_payload_structure_t payload_structure;
} audio_packetizer_dts_hd_params_t;


typedef struct  {
   int eos;
   int new_input;
   int input_bytes_copied;
   int sync_found;
   int format;
   metadata_association_t *md_associate;
   /* Function pointers for different packetizer implementations. */
   packetize_get_lib_info_func_t get_lib_info;
   packetize_get_persistant_size_func_t get_persistant_size;
   packetize_mem_set_persistant_ptr_func_t set_persistant_ptr;
   packetize_get_input_bytes_req_func_t get_input_bytes_req;
   packetize_mem_set_input_ptr_func_t set_input_ptr;
   packetize_mem_set_output_ptr_func_t set_output_ptr;
   packetize_set_output_size_func_t set_output_size;
   packetize_set_input_bytes_func_t set_input_bytes;
   packetize_set_input_over_func_t set_input_over;
   packetize_get_input_bytes_consumed_func_t get_input_bytes_consumed;
   packetize_do_execute_func_t do_execute;
   packetize_get_output_bytes_func_t get_output_bytes;
   packetize_exe_done_query_func_t exe_done_query;
   packetize_set_byte_swap_func_t set_byte_swap;
   packetize_set_expand_to_32b_func_t set_expand_to_32b;
   packetize_get_stream_position_func_t get_stream_position;
   packetize_get_frame_start_stream_position_func_t get_frame_start_stream_position;
   packetize_get_stream_info_func_t get_stream_info;
#ifdef PKT_OPT
   int circ_aux_start;
   packetize_set_circ_info_t set_circ_info;
#endif
} audio_packetizer_internal_t;

typedef struct	{
   /*Host copy of the parameters it updates.*/
   audio_psm_stage_parms_host_t host;

   /*DSP copy of the host parmeters.*/
   audio_packetizer_params_host_t dsp;
   
   int eos;
   int bytes_till_next_syncword;
   int syncword_byte_index;
   int input_bytes_copied;
   int found_sync_need_frame_info;
   int header_bytes_found;
   int input_pts_buffer_used;
   int sample_rate;
   int new_input;
   unsigned char header[MAX_ES_HEADER_BYTES];
   audio_packetizer_internal_t internal_params;
   audio_psm_buf_desc_t aux_buffer;
   audio_psm_buf_desc_t persistant_buffer;
   audio_psm_buf_desc_t mda_buffer; /* Meta-data association buffer storage..*/
   audio_packetizer_ddp_params_t ddp_param;
   audio_packetizer_dts_hd_params_t dtshd_param;
} audio_packetizer_params_t;

typedef struct	{
   int output_smpl_size;
   int output_ch_map;
   int reorder_for_hw;
   int output_ch_count;
} interleaver_input_t;

typedef struct	{
   interleaver_input_t inputs[PSM_MAX_OUTPUT];
} audio_interleaver_params_t;

/** State variables needed by the deinterleaver stage.*/
typedef struct {
   bool trans_protection_init_done;             /** Flag to know if init is done for transition protection code. */
   bool trans_protect_enabled[AUDIO_MAX_INPUTS];/** Indicates how many of the inputs can support transition protection.*/
   int trans_protection_buffer_size;            /** Indicates how much memory is available for transition protection algo.*/  
   audio_psm_buf_desc_t aux_buffer;             /** Memory used for state variables for transition protection algorithm.*/
} audio_deinterleaver_params_t;

#define MAX_BYTES_PER_SAMPLE ((AUDIO_MAX_INPUT_CHANNELS * 32)/8)

/** PCM decoder parameters for PCM formatting (decode) stage.*/
typedef struct {
   /** Host updatable copy of the stage's parameters.*/
   audio_psm_stage_parms_host_t host;
   /** DSP's copy of the hosts parameters.*/
   audio_pcm_decode_params_host_t dsp;
   int out_buffer_level;
   int curr_bytes_till_pts;
   int input_bytes_copied;
   int sample_size;
   int sample_rate;
   int channel_count;
   int channel_config;
   int prev_channel_config; //used to keep track of change for event firing
   int prev_sample_rate; //used to keep track of change for event firing
   int offset;
   int partial_sample_bytes;
   char partial_sample[MAX_BYTES_PER_SAMPLE];
   audio_psm_buf_desc_t aux_buffer;
   ismd_audio_format_specific_stream_info_t stream_info;
} audio_pcm_decode_params_t;

typedef struct	{
   unsigned int out_buffer_level;
   unsigned int input_bytes_copied;
} audio_chunk_divider_t;

typedef struct	{
   unsigned int out_buffer_level;
   unsigned int time_quantum;
} audio_chunk_accumulator_t;

#define BIT_DEPTH_CONVERT_PASSTHROUGH -1

typedef struct	{
   int forced_hw_output_ch_count;
   int output_sample_size;
} audio_bit_depth_converter_context_t;

typedef struct	{
   audio_bit_depth_converter_context_t context[AUDIO_MAX_OUTPUTS];
} audio_bit_depth_converter_t;

typedef struct	{
   int enabled;
   ismd_audio_per_speaker_setting_t speaker_settings;
   int init_done;
   int crossover_freq;//Currently not used. 
   audio_psm_buf_desc_t aux_buffer;
} audio_bass_managemnt_params_t;

typedef struct{
   audio_psm_buf_desc_t aux_buffer;
   int delay_ms;             //store customer delay input
   char *start_address;      //circular buffer start address
   char *end_address;        //circular buffer end address
   char *read_ptr;
   char *write_ptr;
   int bytes_buffered;       //current buffering level of circular buffer
   int delay_bytes_count;    //delay bytes required calculated from customer input
   int silence_bytes_count;  //silence bytes need to insert into output
}ismd_audio_delay_buffering_info_t;

typedef struct {
   ismd_audio_delay_buffering_info_t buf_mgmt[8];
   int per_channel_delay[8];
   bool enabled;
   bool buffer_reset;
   bool delay_change;
} audio_delay_management_params_t;

//audio water mark  use of  aux_buffer
typedef struct {
   unsigned char detector_buffer[SMD_64KB_BUFFERS];
}audio_wm_internal_aux_buf_mem_layout_t;

typedef struct {
   unsigned char params[AUDIO_WM_MAX_PARAMS_LEN];
   int handle;
   int wl_id;
   int detector; //the detector object
   const int *notif_events;
   audio_psm_buf_desc_t aux_buffer;  
   bool detector_exe_started;
   bool callback_needed;
   bool host_notified;
   bool enabled; //input
} audio_watermark_management_params_t;

// FIXME: increase this buffer to 256KB as a workaround to satisfy the memory need of ACE stage.
#define AUDIO_QUALITY_PARAMS_BUFFER_SIZE (256 * 1024)
#define AUDIO_QUALITY_MAX_CONTEXTS ( AUDIO_QUALITY_PARAMS_BUFFER_SIZE/sizeof(audio_quality_context_t) )

typedef struct {
   bool init_done;
   bool in_use;
   bool bypass_change;
   bool flt_param_change;
   bool ctl_param_change;
   bool config_change;
   bool avl_config_change;
   //bool have_mute_stage;
   //bool have_vol_stage;
   //bool have_avl_stage;
   char cacheline_pad[57];// 64 byte alligned.
}audio_quality_state_t;

typedef struct {
   audio_quality_state_t state;
   ACESYSTEM ace_system;
}audio_quality_context_t;

typedef struct {
   audio_quality_context_t context[AUDIO_QUALITY_MAX_CONTEXTS];
} audio_quality_params_t;

typedef enum {
   AUDIO_MS10_DDT_INVALID = 0,
   AUDIO_MS10_DDT_MAIN = 1,
   AUDIO_MS10_DDT_ASSOC = 2,
} audio_ms10_stream_type_t;

typedef struct {
   int sbr_type;
   int aac_format;
   bool decoder_reset;
} aac_metadata_t;

typedef enum {
   AUDIO_MS10_DDC_FRAME_DECODED = 0,      /** frame decoded successfully */
   AUDIO_MS10_DDC_FRAME_PENDING,          /** frame pending on more input data */
   AUDIO_MS10_DDC_FRAME_ERROR,            /** frame decoding error */
}audio_ms10_ddc_codec_status_t;

typedef struct {
   bool sync_enable;
   int  main_ddc_sync;                         /** keep the main pipeline's ddc_sync stage address */
   uint32_t frame_index_main;                  /** decoded frame count since new input from main audio */
   uint32_t frame_index_assoc;                 /** decoded frame count since new input from associate audio */
   audio_ms10_ddc_codec_status_t cur_main_status;          /** current decoded frame status from main */
   audio_ms10_ddc_codec_status_t cur_assoc_status;         /** current decoded frame status from assoc */

   int sample_rate;
   int blk_per_frame;
   int convsync_main_in_associated;
   int repeat_or_misordered_main;
   int repeat_or_misordered_assoc;
   //bool DD_PAUSE_SAMPLES  // information for App to add silence.
}audio_ms10_ddc_sync_params_t;


//Parameters and context information for custom processing stage
typedef struct audio_capp_params_s {

   audio_psm_stage_parms_host_t host;  /**Host copy of conifg params*/
   audio_capp_host_params_t dsp;       /**DSP copy of host config params*/

   //Intermediate storage buffers used by this stage to interface with the custom library, initialized by the host when stage is added and only used by DSP after
   audio_psm_buf_desc_t in_buffer;
   audio_psm_buf_desc_t out_buffer;
   audio_psm_buf_desc_t mda_buffer;

   //Remap offset to use for the DSP to calculate the local storage base address
   uint32_t local_storage_remap;

   //Flag indicating whether the capp stage is enabled
   bool enabled;    
   //Flag indicating that the stage is in the process of finalizing in order to be disabled
   bool finalizing;
   //Address of the local storage area for the custom library (in DSP address space)
   void * dsp_local_storage_base;   
   //Transparent handle generated by the custom library and used to identify context when calling the library
   void * handle;   
   //Output mode used by the custom library implementation (buffered or unbuffered)
   int mode;
   //Flag that tells us whether we have read the stage input buffer for the first time
   bool input_buffer_first_read;
   //Flag telling the stage that the current stage input buffer has been completely consumed
   bool input_buffer_finished; 
   //The byte position in the stream from whence the next input buffer will be consumed
   int input_byte_pos;
   //The byte position in the stream to which the next byte output from the custom library function will be written 
   int output_byte_pos;
   //Offset into the stage input buffer to begin reading at
   int input_read_offset;
   //How many bytes were produced by the last call to the custom library 
   int last_bytes_produced;
   //Index into the custom library output buffer to copy data from into the stage output buffer
   int out_buffer_read_index;
   //State variables for the metadata association queue, which is stored as a circular buffer
   int mda_buff_start;
   int mda_buff_end;
   int mda_buff_elements;
   int mda_queue_level;
   //Pointer to storage for the metadata association queue node that will be used to fill the next stage output buffer
   capp_metadata_association_t * output_metadata;
   //Some additional stage information needed in order to pass data from in_buffer to the custom library, due to the accumulation of stage input data
   bool in_buffer_valid;
   int in_buffer_pts_offset;
   int in_buffer_discontinuity_offset;
} audio_capp_params_t;


/** Detection state variables for IEC6XXXX parsing stage*/
typedef struct audio_iec_auto_detect_s {
   int AutoDetectState;   /** state 0=unknown, 1=PCM, 2=codec */
   int LockState;         /** 1=dumping data, 0=otherwise */
   int I2S_sync_loss;      /** state 1= sync loss, 0=no sync */
   int DetectSR;          /** sample rate of PCM, if detected */
   int DetectWL;          /** word length of PCM, if detected */
   int DetectCodec;       /** type of codec detected */
} audio_iec_auto_detect_t;

/** State variables for IEC parsing stage*/
typedef struct audio_iec_parsing_state_s
{
   /** Host updates these parameters, DSP copies them over to read.*/
   audio_psm_stage_parms_host_t host;
   /** DSP copy of the host parameters.*/
   audio_iec_parser_params_host_t dsp;
   /**Additional memory needed by the stage.*/
   audio_psm_buf_desc_t aux_buffer; 
   /** The detected stream info, written by DSP, read by the host.*/
   ismd_audio_input_parsing_status_t parser_status;

   /** Future state variables will be used for 60958 parsing.*/
   // TODO: Must be converted to SMD coding standards when enabled!
   audio_iec_auto_detect_t AutoDetect;
   int init_done;
   int AutoDetectOn;    /** if false, then we don't worry about autodectect */

   // these are for 60958 parse
   int BlkState;
   int BlkSubFrames;
   int IECChannel;
   char CSBytes[24];
   int CSIndex;
   int BitCnt;
   char UBytes[24];
   int UIndex;
   int Pts_60958_offset;
   int Pts_start_60958_low;
   int Pts_start_60958_high;

   // this is for storing up the first 40 words until we have
   // enough info to detect a change
   int *IEC60958_packet; // this should point to at least 6144 bytes
   int *IECBuffer; // this should point to at least 4096 bytes
    
   // these flags are for state if 
   // we are sending specific style thru I2S to
   // deal with I2S bug
   int I2S32bState;
   int I2S32bWord[4];
   int LastFlag;
   int LastData;
   int FlagError;
   int Word16Cnt;
   int NextParse;
 
   // for the comb filter
   int CombState;
   int CombSkip;
   int CombSkipRemain;
   
   // these parms are for 61937
   int EncState;
   int BurstLen;
   int StreamID;
   int EncDataType;
   int EncDataSubType;
   int DetectEncType;
   int PendByte;
} audio_iec_parsing_state_t;


/** Stage configuration parameters for each type of stage. */
typedef union 
{	
   audio_psm_buf_desc_t params_buffer;
   
   audio_mixer_params_t      mixer;
   audio_pcm_decode_params_t pcm_dec;
   audio_psm_decode_params_t decoder;
   audio_psm_src_params_t    src;  
   audio_watermark_management_params_t watermark;
   audio_downmix_params_t    downmixer;
   audio_spkrremap_params_t    spkrremap;
   audio_interleaver_params_t    interleaver;
   audio_packetizer_params_t packetizer;
   audio_chunk_divider_t chunk_div;
   audio_bass_managemnt_params_t bass_man;
   audio_delay_management_params_t delay_mgmt;
   audio_chunk_accumulator_t acumultr;
   audio_bit_depth_converter_t bit_depth_converter;
   audio_per_output_delay_params_t per_output_delay;
   audio_ms10_ddc_sync_params_t ms10_ddc_sync;
   audio_capp_params_t capp;
   audio_iec_parsing_state_t iec_parse;
   audio_srs_params_t srs;
   audio_deinterleaver_params_t deinterleaver;
}audio_psm_stage_params_t;


/* --------------------------------------------------------------------------- */

//Use this structure to store metadata about inputs/outputs connected to the stage.
typedef struct {
   int output[AUDIO_MAX_OUTPUTS];
   int input[AUDIO_MAX_INPUTS];
} audio_psm_stage_connection_metadata_t;


struct audio_psm_stage_s;
typedef int (* stage_func_t)(struct audio_psm_stage_s *stage, int wl_id);


/** This structure describes a single stage in the DSP pipe. A Stage could 
    be a decode stage, a mix stage etc. Sequence of stages make a pipe. */
typedef struct audio_psm_stage_s 
{
   /*Keep stage_params at top of struct to ensure cachline
     allignment of host params that are invalidated during 
     PSM pipe run time. Since the stage structure is cache alligned. */
   audio_psm_stage_params_t stage_params;
   
	int handle; /* Usually the index into the array to which this element belongs to. */
	audio_psm_stage_task_t task; //the task that should be executed for during that stage.
	unsigned int in_use; 

	void *phys_address; /* Address is always specified in IA address range. */
	void *dsp_phys_address; /* Address is always specified in DSP address range. IA_phys_add - remap_address */
	
	audio_psm_buf_desc_t *virt_inputs[PSM_MAX_INPUT];
	void *dsp_phys_inputs[PSM_MAX_INPUT];
   void *dsp_phys_inputs_orig[PSM_MAX_INPUT];
	
	unsigned int inputs_count;

	audio_psm_buf_desc_t outputs[PSM_MAX_OUTPUT];
	unsigned int outputs_count;

   audio_psm_stage_connection_metadata_t conn_mda;

   stage_func_t func;
   stage_func_t flush_func;

   /* Important flag. In general, "done" indicates a stage has consumed its input buffer. 
      E.g - The decoder has copied the input data into the cubby decode buffer. 
      Not necessarily decoded the buffer but it has consumed it. Most other stages always 
      consume the given buffer but the decode stage acts differently. If the cubby decode buffer
      is full the decode stage can consume part or nothing of the input buffer. 
      In the case of input and output stages this flag takes on a slightly different
      meaning. 
      Input Stage - There was an input job in the input queue. 
                    False means there is no input job in the input job queue. 
      Output Stage - The output buffers were successfully enqueued into the output job queue. 
                     False means there is no space in the output job queue. */      
	unsigned int done;

   /*This is a flag that a stage can set to indicate to the pipeline logic that even 
     though this stage has consumed its input buffer, it has internal data that still
     needs to be processed after the stage has been executed. */
   unsigned int work_to_do; 

	struct audio_psm_stage_s *virt_next;	/* Used by HOST */
	void *phys_next;					
	void *dsp_phys_next; /* Used by DSP  next stage pointer */

   unsigned long long stage_cycle_count;
   unsigned long long stage_sample_count;

   /** Flag to determine if the input data has not been consumed yet.*/
   uint8_t input_data_new[PSM_MAX_INPUT];

   unsigned int cacheline_pad[15];
} audio_psm_stage_t;
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Job descriptor. A job is basically an input and output to a PSM pipe. 
	It is a collection of buffers and a pipe ID so that the buffers can be 
	taken through (processed) pipe. 
	TODO: Add output job comment. */
/* --------------------------------------------------------------------------- */
typedef struct audio_psm_job_desc_s
{
	int handle;

	/* This is a special case flag used to handle stopping a pipe. 
		When a pipe is stopped we need to make sure all the outputs belonging to that pipe
		get enqueued to the output queues. This is done outside the main thread which usually 
		handles enqueuing of buffers to output queue. Hence this special flag to notify that 
		the data in this buffer is alredy consumed/stale so that the thread can move on to the next one. */
	unsigned int stale_data;	
	unsigned int cleanup;
	
	int wl_handle;

   void *phys_address; /* Address is always specified in IA address range. */
	void *dsp_phys_address; /* Address is always specified in DSP address range. IA_phys_add - remap_address */
	struct audio_psm_job_desc_s *virt_next;	/* Used by HOST */
	void *phys_next;						
	void *dsp_phys_next;						/* Used by DSP */
	audio_psm_buf_desc_t buffers[PSM_MAX_IO_COUNT]; /* */
	
	unsigned int buffers_count;

      /* Puting this at the end of the struct because the host reads this flag to know if the 
          job is ready for pick up or not and it just so happens that this struct is 2 cachelines
          and there is a potential for the host to read it early but the DSP not to finish writeback
          invalidate on both cache lines.*/
   	unsigned int valid;	

	int cacheline_pad[5];
} audio_psm_job_desc_t;
/* --------------------------------------------------------------------------- */

/** Pointers to current and previous locations in the DSP queue.*/
typedef struct audio_psm_queue_tracker_s {
   audio_psm_job_desc_t *cur_out_job;    /** An array of pointers for to track curr buffer location in a DSP queue.*/
   audio_psm_job_desc_t *prev_out_job;   /** An array of pointers for to track prev buffer location in a DSP queue.*/
}audio_psm_queue_tracker_t;
   
/** This is the DSP queue structure that the DSP and Host transfer data in/out from.*/
typedef struct audio_psm_job_queue_s {
   audio_psm_job_desc_t jobs[PSM_PIPE_JOB_QUEUE_DEPTH];  /** These are the buffer slots in the queue. */
   int in_use;                                           /** Flag to indicate the queue is in use.*/
}audio_psm_job_queue_t;

/** Output queues container structure for output queues used by a single PSM pipe.*/
typedef struct audio_psm_pipe_output_queues_s {
   audio_psm_job_queue_t queue[PSM_PIPE_MAX_NUM_OUT_QUEUES];  /** The output queues availabe for an allocated pipe.*/
   void *dsp_phys_address;                                    /** DSP address of this structure.*/
}audio_psm_pipe_output_queues_t;


/* --------------------------------------------------------------------------- */
/* Future proofing PSM. */
/* --------------------------------------------------------------------------- */
typedef enum 
{
	PSM_PIPE_TYPE_UNKNOWN, 
	PSM_PIPE_TYPE_DECODE,
	PSM_PIPE_TYPE_POST_ATC
}audio_psm_pipe_type_t;
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* This structure describes a single stage in the DSP pipe. A Stage could 
	be a decode stage, a mix stage etc. Sequence of stages make a pipe. */
/* --------------------------------------------------------------------------- */
typedef struct 
{
   int handle;
   audio_psm_stage_t *stages;
   audio_psm_pipe_type_t type;
}audio_psm_pipe_t;
/* --------------------------------------------------------------------------- */


typedef struct {
   bool codec_exists[ISMD_AUDIO_MAX_LIBS];
   bool codec_ms10_ddt;
   bool codec_ms10_ddc;
   bool codec_ddplus_dcv;
   bool done_flag;
   char cacheline_pad[37];
}codecs_available_t;

typedef enum {
   AAC_ACMOD_INVALID             = 0,
   AAC_ACMOD_1_0                 = 1,
   AAC_ACMOD_PS                  = 2,      /*only for AACPlus V2*/
   AAC_ACMOD_DUAL_MONO           = 3,
   AAC_ACMOD_2_0                 = 4,
   AAC_ACMOD_3_0                 = 5,
   AAC_ACMOD_2_1                 = 6,
   AAC_ACMOD_2_2                 = 7,
   AAC_ACMOD_3_1                 = 8,
   AAC_ACMOD_3_2                 = 9,
   AAC_ACMOD_3_2_1               = 10,
   AAC_ACMOD_3_2_2               = 11,
   AAC_ACMOD_2_0_LFE             = 12,
   AAC_ACMOD_3_0_LFE             = 13,
   AAC_ACMOD_2_0_1_LFE           = 14,
   AAC_ACMOD_2_2_LFE             = 15,
   AAC_ACMOD_3_0_1_LFE           = 16,
   AAC_ACMOD_3_2_LFE             = 17,
   AAC_ACMOD_3_2_1_LFE           = 18,
   AAC_ACMOD_3_2_2_LFE           = 19
}audio_aac_acmod_t;

typedef enum {
   DOLBY_ACMOD_INVALID = -1,
   DOLBY_ACMOD_DUAL_MONO,
   DOLBY_ACMOD_1,
   DOLBY_ACMOD_2_0,
   DOLBY_ACMOD_3_0,
   DOLBY_ACMOD_2_1,
   DOLBY_ACMOD_3_1,
   DOLBY_ACMOD_2_2,   
   DOLBY_ACMOD_3_2,
   DOLBY_ACMOD_3_2_2_LFE = 21,  /* special for DDP */
}audio_dolby_acmod_t;

#endif

