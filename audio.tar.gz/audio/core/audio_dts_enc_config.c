/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"


ismd_result_t
audio_dts_enc_set_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value)
{
   ismd_result_t result = ISMD_SUCCESS;
   int *param = NULL; //All the encoder params are int. 

   switch(param_id)
   {
      case  ISMD_AUDIO_DTS_ENC_LFE_PRESENT :

         param = (int *) param_value;

         if((*param == 0) || (*param == 1)) {
            psm_decode_params->host.codec.config.dts_enc_params.lfe_present = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("dts enc: lfe_present param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }            
         break;
         
      case  ISMD_AUDIO_DTS_ENC_NUM_INPUT_CH :

         param = (int *) param_value;

         if((*param == 1) || (*param == 2) || (*param == 3) || (*param == 4) || (*param == 5)) {
            psm_decode_params->host.codec.config.dts_enc_params.num_input_ch = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("dts enc: num_input_channels is invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }      
         break;   

      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("dts encoder: invalid config param type!", result, audio_devh[AUDIO_DEBUG_APM]);    
         break;
   }

   psm_decode_params->host.codec.config.dts_enc_params.total_num_input_ch = 
     (psm_decode_params->host.codec.config.dts_enc_params.num_input_ch +
      psm_decode_params->host.codec.config.dts_enc_params.lfe_present);
   
   return result;
}

ismd_result_t
audio_dts_enc_set_default_params(audio_psm_decode_params_t *dec_params)
{
   ismd_result_t result = ISMD_SUCCESS;

   OS_MEMSET((char *)dec_params, 0, sizeof(audio_psm_stage_params_t)); 

   dec_params->host.codec.algo = ISMD_AUDIO_ENCODE_FMT_DTS;
   dec_params->host.codec.packetize_output = true;

   dec_params->host.codec.config.dts_enc_params.lfe_present = 1; // 1 or 0 for present or not present.
   dec_params->host.codec.config.dts_enc_params.sample_rate = 48000; //Encoder only supports 48kHz
   dec_params->host.codec.config.dts_enc_params.sample_size = 24;
   dec_params->host.codec.config.dts_enc_params.num_input_ch = 5;
   dec_params->host.codec.config.dts_enc_params.encode_format = 3;

   //Keep this for use in pipe construction. 
   dec_params->host.codec.config.dts_enc_params.total_num_input_ch = 6;
   
   return result;
}


