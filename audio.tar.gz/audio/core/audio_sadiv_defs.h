
/*
* File Name: ismd_audio_sadiv_defs.h
*/

/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2008 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


/* The audio bit clock is obtained by dividing the frequency of external audio master clock connected 
   to the AUDIO_CLOCK pin by a programmable divisor specified in bits 6:0 of the clock control register. 
   Normally, the audio clock is running at 36.864 MHz, or 768*Fs.  For I2S output, the bit clock frequency 
   should be set to 64*Fs therefore, the ADIV = 36864/ (64*Fs). For instance, when 48 kHz sampling rate 
   is selected, ADIV=12, when 96 kHz sampling rate is selected, ADIV=6. The software should set up
   the divisor before starting I2S interface to avoid unpredictable behavior. 

   For SPDIF output the bitclock frequency should be set to 128*Fs. So for a sampling rate of 48 KHz the 
   bit-clock used would be 6.144Mhz and the ADIV value should be 6. To achieve a sampling rate of 192 KHz 
   on SPDIF output, the internal bit clock frequency has to be 24.576 MHz.  To get this bitclock rate, 
   the AUDIO_CLOCK frequency has to be changed to 24.576 MHz and ADIV should be set to 0.  The PLL 
   driving AUDIO_CLOCK can be programmed to generate this frequency. 

   When ADIV = 0, the input AUDIO_CLOCK is passed on to the bitclock. The divider is bypassed in this case. 
   To achieve a sampling frequency of 44.1Khz in both the I2S and SPDIF output modes, the  input AUDIO_CLOCK 
   frequency can be set at 33.8688Mhz and ADIV = 12 for I2S and 6 for SPDIF.
   
*/


#ifndef _ISMD_AUDIO_SADIV_DEFS_H_
#define _ISMD_AUDIO_SADIV_DEFS_H_


/***** VALID FOR  MASTER AUDIO CLOCK @ 36.864 MHz **************/
//For I2S output,  SADIV = 36864/ (64*Fs). 
#define AUDIO_MC_36_864_MHZ_SADIV_I2S_12KHZ    48
#define AUDIO_MC_36_864_MHZ_SADIV_I2S_24KHZ    24
#define AUDIO_MC_36_864_MHZ_SADIV_I2S_32KHZ    18
#define AUDIO_MC_36_864_MHZ_SADIV_I2S_48KHZ    12
#define AUDIO_MC_36_864_MHZ_SADIV_I2S_64KHZ    9
#define AUDIO_MC_36_864_MHZ_SADIV_I2S_96KHZ    6
#define AUDIO_MC_36_864_MHZ_SADIV_I2S_192KHZ   3

//For SPDIF output,  SADIV = 36864/ (128*Fs). 
#define AUDIO_MC_36_864_MHZ_SADIV_SPDIF_12KHZ    24
#define AUDIO_MC_36_864_MHZ_SADIV_SPDIF_24KHZ    12
#define AUDIO_MC_36_864_MHZ_SADIV_SPDIF_32KHZ    9
#define AUDIO_MC_36_864_MHZ_SADIV_SPDIF_48KHZ    6
#define AUDIO_MC_36_864_MHZ_SADIV_SPDIF_96KHZ    3
/***************************************************************/

// To achieve a sampling rate of 192 KHz on SPDIF output, 
// the internal bit clock frequency has to be 24.576 MHz.  
// To get this bitclock rate, the AUDIO_CLOCK frequency 
// has to be changed to 24.576 MHz and ADIV should be set 
// to 0.  

/***** VALID FOR  MASTER AUDIO CLOCK @ 24.576 MHz *************/
//For I2S output,  SADIV = 24576/ (64*Fs). 
#define AUDIO_MC_24_576_MHZ_SADIV_I2S_12KHZ    32
#define AUDIO_MC_24_576_MHZ_SADIV_I2S_24KHZ    16
#define AUDIO_MC_24_576_MHZ_SADIV_I2S_32KHZ    12
#define AUDIO_MC_24_576_MHZ_SADIV_I2S_48KHZ    8
#define AUDIO_MC_24_576_MHZ_SADIV_I2S_64KHZ    6
#define AUDIO_MC_24_576_MHZ_SADIV_I2S_96KHZ    4
#define AUDIO_MC_24_576_MHZ_SADIV_I2S_192KHZ   2

//For SPDIF output,  SADIV = 24576/ (128*Fs). 
#define AUDIO_MC_24_576_MHZ_SADIV_SPDIF_12KHZ    16
#define AUDIO_MC_24_576_MHZ_SADIV_SPDIF_24KHZ    8
#define AUDIO_MC_24_576_MHZ_SADIV_SPDIF_32KHZ    6
#define AUDIO_MC_24_576_MHZ_SADIV_SPDIF_48KHZ    4
#define AUDIO_MC_24_576_MHZ_SADIV_SPDIF_64KHZ    3
#define AUDIO_MC_24_576_MHZ_SADIV_SPDIF_96KHZ    2
#define AUDIO_MC_24_576_MHZ_SADIV_SPDIF_192KHZ   0
/***************************************************************/

/***** VALID FOR  MASTER AUDIO CLOCK @ 33.8688 Mhz ************/
#define AUDIO_MC_33_8688_MHZ_SADIV_I2S_44_1_KHZ    12
#define AUDIO_MC_33_8688_MHZ_SADIV_SPDIF_44_1_KHZ  6

#define AUDIO_MC_33_8688_MHZ_SADIV_I2S_88_2_KHZ    6
#define AUDIO_MC_33_8688_MHZ_SADIV_SPDIF_88_2_KHZ  3

#define AUDIO_MC_33_8688_MHZ_SADIV_I2S_176_4_KHZ    3
/***************************************************************/

/***** VALID FOR  MASTER AUDIO CLOCK @ 22.5792 Mhz ************/
#define AUDIO_MC_22_5792_MHZ_SADIV_I2S_44_1_KHZ    8
#define AUDIO_MC_22_5792_MHZ_SADIV_SPDIF_44_1_KHZ  4

#define AUDIO_MC_22_5792_MHZ_SADIV_I2S_88_2_KHZ    4
#define AUDIO_MC_22_5792_MHZ_SADIV_SPDIF_88_2_KHZ  2

#define AUDIO_MC_22_5792_MHZ_SADIV_I2S_176_4_KHZ    2
#define AUDIO_MC_22_5792_MHZ_SADIV_SPDIF_176_4_KHZ  1

/***************************************************************/



#endif

