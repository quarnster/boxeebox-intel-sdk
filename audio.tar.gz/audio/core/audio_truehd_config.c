/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"

ismd_result_t
audio_truehd_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value)
{
   ismd_result_t result = ISMD_SUCCESS;
   
   ismd_audio_truehd_decode_mode_t *decode_mode;
   ismd_audio_truehd_zero_unused_chans_t *zero_chan;
   ismd_audio_truehd_block_crc_t *block_crc;
   ismd_audio_truehd_lossless_t *lossless;
   ismd_audio_truehd_drc_enable_t *drc_en;
   ismd_audio_truehd_drc_cut_t *drc_cut;
   ismd_audio_truehd_drc_boost_t *drc_boost;
   ismd_audio_truehd_dialog_ref_t *dialog_ref;
   ismd_audio_truehd_fba_chan_reorder_t *fba_chan_reorder;

   switch(param_id)
   {

      case ISMD_AUDIO_TRUEHD_DECODE_MODE :
         
          decode_mode = (ismd_audio_truehd_decode_mode_t *) param_value;
         
         if((*decode_mode == 2) || (*decode_mode == 6) ||(*decode_mode == 8)) {            
               psm_decode_params->host.codec.config.truehd_params.decmode = *decode_mode;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("truehd: decode_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }         
         break;

      case ISMD_AUDIO_TRUEHD_ZERO_UNUSED_CHANS :
         
          zero_chan = (ismd_audio_truehd_zero_unused_chans_t *) param_value;
         
         if(*zero_chan >= 0) {            
               psm_decode_params->host.codec.config.truehd_params.zero_unused_chans = *zero_chan;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("truehd: zero_chan param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }         
         break;   

      case ISMD_AUDIO_TRUEHD_BLOCK_CRC :
         
          block_crc = (ismd_audio_truehd_block_crc_t *) param_value;
         
         if((*block_crc == 0) || (*block_crc == 1)) {            
               psm_decode_params->host.codec.config.truehd_params.blockcrc = *block_crc;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("truehd: block_crc param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }         
         break;  

      case ISMD_AUDIO_TRUEHD_LOSSLESS :
         
          lossless = (ismd_audio_truehd_lossless_t *) param_value;
         
         if((*lossless == 0) || (*lossless == 1)) {            
               psm_decode_params->host.codec.config.truehd_params.lossless = *lossless;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("truehd: lossless param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }         
         break;  

      case ISMD_AUDIO_TRUEHD_DRC_ENABLE :
         
          drc_en = (ismd_audio_truehd_drc_enable_t *) param_value;
         
         if((*drc_en == 0) || (*drc_en == 1) || (*drc_en == 2)) {            
               psm_decode_params->host.codec.config.truehd_params.drc_enable = *drc_en;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("truehd: drc_en param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }         
         break;  

      case ISMD_AUDIO_TRUEHD_DRC_CUT :
         
          drc_cut = (ismd_audio_truehd_drc_cut_t *) param_value;
         
         if((*drc_cut >= 0) && (*drc_cut <= 100)) {            
               psm_decode_params->host.codec.config.truehd_params.drc_cut = *drc_cut;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("truehd: drc_cut param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }         
         break;  

      case ISMD_AUDIO_TRUEHD_DRC_BOOST :
         
          drc_boost = (ismd_audio_truehd_drc_boost_t *) param_value;
         
         if((*drc_boost >= 0) && (*drc_boost <= 100)) {            
               psm_decode_params->host.codec.config.truehd_params.drc_boost = *drc_boost;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("truehd: drc_boost param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }         
         break;  

      case ISMD_AUDIO_TRUEHD_DIALOG_REF :
         
          dialog_ref = (ismd_audio_truehd_dialog_ref_t *) param_value;
         
         if((*dialog_ref >= -48) && (*dialog_ref <= 0)) {            
               psm_decode_params->host.codec.config.truehd_params.dialref = *dialog_ref;
               psm_decode_params->host.codec.config.truehd_params.dialrefsupplied = 1; //Flag to indicate setting of dialref parameter by fw.
         }
         else if (*dialog_ref == ISMD_AUDIO_TRUEHD_DIALOG_REF_DEFAULT)
         {
            psm_decode_params->host.codec.config.truehd_params.dialref = *dialog_ref;
            psm_decode_params->host.codec.config.truehd_params.dialrefsupplied = 0;            
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("truehd: dialog_ref param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }         
         break; 

      case ISMD_AUDIO_TRUEHD_FBA_CH_REORDER :
         
          fba_chan_reorder = (ismd_audio_truehd_fba_chan_reorder_t *) param_value;
         
         if((*fba_chan_reorder == 0) || (*fba_chan_reorder == 1)) {       
               psm_decode_params->host.codec.config.truehd_params.fbachannelorder = *fba_chan_reorder;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("truehd: fba_chan_reorder param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }         
         break; 

      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("truehd: invalid config param type!", result, audio_devh[AUDIO_DEBUG_APM]);    
         break;
   }

   return result;
}

ismd_result_t
audio_truehd_set_default_decode_params(audio_psm_decode_params_t *dec_params)
{
   ismd_result_t result = ISMD_SUCCESS;

   OS_MEMSET((char *)dec_params, 0, sizeof(audio_psm_stage_params_t)); 

   dec_params->host.codec.config.truehd_params.decmode = 8;
   dec_params->host.codec.config.truehd_params.zero_unused_chans = 1; //Need to zero out unused channels.
   dec_params->host.codec.config.truehd_params.blockcrc =  1;
   dec_params->host.codec.config.truehd_params.lossless =  0;
   dec_params->host.codec.config.truehd_params.drc_enable =  1; //auto drc-enable
   dec_params->host.codec.config.truehd_params.drc_cut =  100;
   dec_params->host.codec.config.truehd_params.drc_boost = 100;
   //dec_params->host.codec.config.truehd_params.dialref =  -31;                  // do not explicitly set.
   dec_params->host.codec.config.truehd_params.dialrefsupplied = 0; //By default dialref value is not supplied by the application. Any default for dialref is set by the library.
   dec_params->host.codec.config.truehd_params.fbachannelorder = 0;

   return result;
}


