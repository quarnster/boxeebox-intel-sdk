/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"
#include "pal.h"
#include "pal_interrupt.h"
#include "audio_dsp_pvt.h"
#include <auto_eas/gen3_dfx.h>

#define LOG_ERROR 0
#define LOG_INFO_LEVEL_0 0
#define LOG_INFO_LEVEL_1 1
#define LOG_INFO_LEVEL_2 2
#define LOG_INFO_LEVEL_3 3

#define ALL_DSP_FW_SVEN_EVENTS_ENABLED 0xFFFFFFFF

#define SMD_1KB_BUFFERS (1*1024)
#define SMD_2KB_BUFFERS (2*1024)
#define SMD_4KB_BUFFERS (4*1024)
#define SMD_8KB_BUFFERS (8*1024)
#define SMD_16KB_BUFFERS (16*1024)
#define SMD_32KB_BUFFERS (32*1024)
#define SMD_64KB_BUFFERS (64*1024)
#define SMD_256KB_BUFFERS (256*1024)
#define SMD_512KB_BUFFERS (512*1024)
#define SMD_1MB_BUFFERS (1*1024*1024)
#define SMD_2MB_BUFFERS (2*1024*1024)
#define SMD_3MB_BUFFERS (3*1024*1024)
#define SMD_4MB_BUFFERS (4*1024*1024)
#define PSM_STAGES_BUFFER_SIZE SMD_1MB_BUFFERS

#define PSM_BUFFER_SIZE SMD_64KB_BUFFERS

/* Sizes of buffers used in DSP. */
#define PSM_AUX_BUF_DESC_BUF_SIZE SMD_2KB_BUFFERS
#define PSM_JOBS_BUF_SIZE SMD_8KB_BUFFERS
 
#define DSP_RESPONSE_WAIT_NO_TIMEOUT 0xFFFFFFFF
#define DEC_MAXPCMCHANS 8

static audio_dsp_device_t dsp_device[AUDIO_DSP_MAX_DEVICES];
static audio_dsp_wl_t dsp_wl[AUDIO_DSP_MAX_WORKLOADS];

#define AUDIO_FIRMWARE_SIZE AUDIO_DSP_KERNEL_SIZE 
#define DSP_MAX_REQD_POOL_BUFFERS 16

/* --------------------------------------------------------------------------- */
/* The following variables are defined in audio_dsp_fw_kernel_core_16x32.c and 
	audio_dsp_fw_kernel_core_16x32.c */
/* --------------------------------------------------------------------------- */
extern const unsigned int audio_fw_kernel_dsp0[AUDIO_FIRMWARE_SIZE/4];
extern const unsigned int audio_fw_kernel_dsp1[AUDIO_FIRMWARE_SIZE/4];
/* --------------------------------------------------------------------------- */

/* Defines to show which DSP number is the large or small DSP. */
#define DSP_LARGE 1
#define DSP_SMALL 0

#define DSP_MS_TO_WAIT_ON_EVENT_TIMEOUT 3000
#define DSP_MAX_TRIES_FOR_NON_BUSY_STATUS 100

static int dsp_num_decode = DSP_LARGE;
static int dsp_num_post_processing = DSP_SMALL;

static bool dsp_initialized = false;

static void audio_init_sven_fw_globals(struct SVEN_FW_Globals  *fw_globals, uint32_t remap)
{
   os_devhandle_t          *devh;

   /* Create a fake sven handle */
   if ( NULL != (devh = devhandle_factory(NULL)) )
   {
      if ( devhandle_connect_name( devh, "DFX" ) )
      {
         unsigned char           *regs;

         /* Initialize Globals */
         fw_globals->en                = (struct SVENEvent *)(devh->devh_svenh.hdr->buffers[0].svc_physaddr -remap);
         fw_globals->eventbuf_size     = devh->devh_svenh.hdr->buffers[0].svc_size;
         regs                          = (unsigned char *) (devh->devh_regs_phys_addr - remap);

         /* Make sure these registers are adjusted for DSP using the remap*/
         fw_globals->sven_dfx_hot      = (volatile unsigned int *)(regs + ROFF_DFX_DBG_SCRATCH);
         fw_globals->sven_dfx_time     = (volatile unsigned int *)(regs + ROFF_DFX_DBG_TIMESTAMP);
         fw_globals->sven_dfx_inc_tx   = (volatile unsigned int *)(regs + ROFF_DFX_DBG_COUNT_INC) ;
         fw_globals->sven_dfx_cur_tx   = (volatile unsigned int *)(regs + ROFF_DFX_DBG_COUNT_GET) ;

      }
      else
      {
         OS_INFO("ERR: Cannot devhandle_connect_name( devh, \"DFX\" )\n");
      }

      devh_Delete(devh);
   }
   else
   {
      OS_INFO("ERR: Cannot devhandle_factory()\n");
   }
   
   return;
}


static void audio_init_reg_addr(audio_dsp_reg_t *dsp_regs, uint32_t remap)
{
   os_devhandle_t          *devh;
   int i;
   char dev_name[20];
   
   for(i=0;i<AUDIO_DSP_MAX_DEVICES;i++)
   {
      snprintf(dev_name, 20, "AU_DSP%d", i);
      
      if ( NULL != (devh = devhandle_factory(NULL)) )
      {
         if ( devhandle_connect_name( devh, dev_name ) )
         {
            unsigned char           *regs;

            regs = (unsigned char *) (devh->devh_regs_phys_addr - remap);

            /* Make sure these registers are adjusted for DSP using the remap*/
            dsp_regs->csr_reg[i] = (volatile unsigned int *)(regs + CSR);
         }
         else
         {
            OS_INFO("ERR: Cannot devhandle_connect_name( devh, \"AU_DSP1\" )\n");
         }

         devh_Delete(devh);
      }
      else
      {
         OS_INFO("ERR: Cannot devhandle_factory()\n");
      }
   }
   return;
}

/* --------------------------------------------------------------------------- */
/* This function is used to perform initialization tasks for audio firmware unit. 
	Examples of tasks perform here are audio firmware loading, data structure 
	initialization and semaphore creation.*/
/* --------------------------------------------------------------------------- */
/* TODO: How to do I prevent someone from calling deinitialize when I am still in initialize?? */
ismd_result_t audio_dsp_initialize(void)
{
   pal_result_t pal_ret;
   osal_result osal_res;
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_dsp_device_t *dsp_dev = NULL;
   uint32_t i=0, j=0;
   audio_psm_pipe_type_t pipe_type = PSM_PIPE_TYPE_UNKNOWN;
   static char interrupt_handler_name[AUDIO_DSP_MAX_DEVICES][16];

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_DSP]);	

   if (dsp_initialized)
   {
      AUDIO_INFO ( LOG_INFO_LEVEL_1, audio_devh[AUDIO_DEBUG_DSP], "Initialize already called.%c", 0 );
      ismd_res = ISMD_SUCCESS;
      goto exit;
   }
   dsp_initialized = true;

   //Look at platform config to see which DSP is used for decode or post processing.
   AUDIO_CONFIG_GET_DSP_DECODE(dsp_num_decode);
   AUDIO_CONFIG_GET_DSP_POST_PROCESSING(dsp_num_post_processing);

   //Check to make sure the values from platform config is valid. If not set to defaults.
   if((dsp_num_decode != DSP_LARGE) && (dsp_num_decode != DSP_SMALL)) {
      dsp_num_decode = DSP_LARGE;
   }
   if((dsp_num_post_processing != DSP_LARGE) && (dsp_num_post_processing != DSP_SMALL)) {
      dsp_num_post_processing = DSP_SMALL;
   }
   

   //Go ahead and zero out the structure memory. Can do that the first time around. 
   OS_MEMSET((void *)&dsp_device, 0, sizeof(dsp_device)); //Would this zero out the whole array. 
   OS_MEMSET((void *)dsp_wl, 0, sizeof(dsp_wl)); //Would this zero out the whole array. 

   //reset the work loads
   for (i=0; i<AUDIO_DSP_MAX_WORKLOADS; i++)
   {
      audio_dsp_pvt_wl_reset(&(dsp_wl[i]));
      dsp_wl[i].handle = i; //important: you have assign the index here since it is used later to see whats the index of the wl is
      os_mutex_init(&(dsp_wl[i].lock));
      
      /* Initialize input and output pool of buffers.
      This was separated out becuase this init function was getting waaaay toooo loooong. */
      ismd_res = audio_dsp_pvt_init_jobs(&(dsp_wl[i]));
      if (ismd_res != ISMD_SUCCESS)
      {
         goto exit;
      }	
   }	

   /* Need to do the same thing for each DSP so the rest of this code is in a for loop*/
   for (i=0; i<AUDIO_DSP_MAX_DEVICES; i++)
   {			
      dsp_dev = &(dsp_device[i]); //set this to a local varable since this would make the naming shorted throughout the loop 

      dsp_dev->device_num = i;	//IMPORTANT : Always call this before reseting device variables. This way SVEN and PALIDs are set correctly. 
      audio_dsp_pvt_device_reset(dsp_dev); //initialize the local variables

      /* Allocate the Lock for the DSP device */
      if ( os_mutex_init ( &dsp_dev->lock) != OSAL_SUCCESS )
      {
         goto exit;
      }

      audio_dsp_pvt_device_lock(dsp_dev);

      /* Allocate the Lock for the IPC communication lock */
      if ( os_mutex_init ( &dsp_dev->ipc_lock ) != OSAL_SUCCESS )
      {
         audio_dsp_pvt_device_unlock(dsp_dev);
         goto exit;
      }		

      /* Allocate the event needed to be signaled when FW finishes power on init*/
      osal_res = os_event_create ( & ( dsp_dev->fw_init_done_event ), 0 );
      if ( osal_res != OSAL_SUCCESS )
      {
         AUDIO_ERROR("Could not create fw_init_done_event.", osal_res, audio_devh[AUDIO_DEBUG_DSP]);
         audio_dsp_pvt_device_unlock(dsp_dev);
         goto exit;
      }
      dsp_dev->fw_init_done_event_created = true;

      /* Allocate the event needed to be signaled when an message has finished processing by FW*/
      osal_res = os_event_create ( & ( dsp_dev->sync_msg_proc_done_event ), 0 );
      if ( osal_res != OSAL_SUCCESS )
      {
         AUDIO_ERROR("Could not create sync_msg_proc_done_event.", osal_res, audio_devh[AUDIO_DEBUG_DSP]);
         audio_dsp_pvt_device_unlock(dsp_dev);
         goto exit;
      }
      dsp_dev->sync_msg_proc_done_event_created = true;   

      /* Allocate the buffer that holds the kernel and all the persistent and scratch memory */ 
      ismd_res = ismd_audio_buffer_alloc_typed_direct ( ISMD_BUFFER_TYPE_PHYS, SMD_2MB_BUFFERS, &dsp_dev->kernel_smd_buf_desc);
      if ( ismd_res != ISMD_SUCCESS )
      {
         AUDIO_ERROR( "kernel buffer allocation failed.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );       
         audio_dsp_pvt_device_unlock(dsp_dev);
         goto exit;
      }

      /* --------------------------------------------------------------------------- */
      /* Allocation of the pool of buffers used to replenish the output stage input  */
      /* --------------------------------------------------------------------------- */
      /* This buffer being allocated here holds the PSM buffer descriptors for the pool of buffers */
      ismd_res = ismd_audio_buffer_alloc_typed_direct ( ISMD_BUFFER_TYPE_PHYS, PSM_AUX_BUF_DESC_BUF_SIZE, &dsp_dev->psm_bufs_smd_buf_desc);
      if ( ismd_res != ISMD_SUCCESS )
      {
         AUDIO_ERROR( "psm buffer descriptors buffer allocation failed.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );			
         audio_dsp_pvt_device_unlock(dsp_dev);
         goto exit;
      }
      OS_MEMSET(dsp_dev->psm_bufs_smd_buf_desc->virt.base, 0, dsp_dev->psm_bufs_smd_buf_desc->phys.size);

      /* Using this pointer to access the memory that will be an array of PSM buffer descirptors for our pool. */
      dsp_dev->psm_bufs = (audio_psm_buf_desc_t *)dsp_dev->psm_bufs_smd_buf_desc->virt.base;
      dsp_dev->psm_bufs_count = dsp_dev->psm_bufs_smd_buf_desc->phys.size / sizeof(audio_psm_buf_desc_t);

      /* Ensure we have enough descriptors for our buffer pool. */
      OS_ASSERT(dsp_dev->psm_bufs_count >= DSP_MAX_REQD_POOL_BUFFERS);

      /* Here we are allocating an smd buffer for each buffer that is in the pool of buffers. */
      for (j=0; j<dsp_dev->psm_bufs_count; j++)
      {
         audio_dsp_pvt_buffer_reset(&(dsp_dev->psm_bufs[j]), false);
         dsp_dev->psm_bufs[j].handle = j;

         /* The 'i' in this case is the DSP number in this case, need to ensure we allocated cached buffers for decode DSP. */
         if(dsp_dev->device_num == dsp_num_decode) {
            pipe_type = PSM_PIPE_TYPE_DECODE;
         }
         else if(dsp_dev->device_num == dsp_num_post_processing) {
            pipe_type = PSM_PIPE_TYPE_POST_ATC;
         }

         ismd_res = audio_dsp_pvt_buffer_allocate(&(dsp_dev->psm_bufs[j]), pipe_type, PSM_BUFFER_SIZE, dsp_dev->kernel_smd_buf_desc->phys.base);
         if ( ismd_res != ISMD_SUCCESS )
         {
            audio_dsp_pvt_device_unlock(dsp_dev);				
            goto exit;
         }

         /* Marking the buffers not in use since we are at init time.*/
         dsp_dev->psm_bufs[i].in_use = false;
      }
      /* --------------------------------------------------------------------------- */


      /* --------------------------------------------------------------------------- */
      /* Here we make a call to PAL to get the device information for each DSP.*/
      /* --------------------------------------------------------------------------- */
      dsp_dev->pal_info_ptr = &(dsp_dev->pal_info);
      pal_ret = pal_get_base_and_irq ( dsp_dev->pal_dev_id, &(dsp_dev->pal_info_ptr) );
      if ( pal_ret != PAL_SUCCESS )
      {
         AUDIO_ERROR( "getting pal info failed.", pal_ret, audio_devh[AUDIO_DEBUG_DSP] );						
         audio_dsp_pvt_device_unlock(dsp_dev);			
         goto exit;
      }
      
      //Creating the SVEN handle here for each DSP      
      if ( NULL != (dsp_dev->devh = devhandle_factory (NULL)) )
      {
         if ( devhandle_connect_physical_address ( dsp_dev->devh, dsp_dev->pal_info_ptr->base_addr0, AUDIO_DSP_PCI_SIZE ) )
         {
            devh_SVEN_SetModuleUnit ( dsp_dev->devh, dsp_dev->sven_dev_id, 0 );
         }
      }

      /* Enable IPCD and IPCX interrupt on IA. */	
      devh_WriteReg32 ( dsp_dev->devh, IMRX, 3);

      strcpy(interrupt_handler_name[i], "Audio_DSPx_ISR");

      /* Change the name from "Audio DSPx ISR" to "Audio DSP0 ISR" ... */
      interrupt_handler_name[i][9] = '0' + (char)i;
      OS_ASSERT( i < 10 );

      dsp_dev->intr_handle = os_acquire_interrupt( dsp_dev->pal_info_ptr->irq_num, 
         			dsp_dev->pal_dev_id, 
         			interrupt_handler_name[i], 
         			audio_dsp_pvt_interrupt_handler, 
         			(void *)dsp_dev->device_num);
      OS_ASSERT(dsp_dev->intr_handle);	   

      /* --------------------------------------------------------------------------- */

      /* --------------------------------------------------------------------------- */
      /* Put the DSP into reset. Download FW and then bring it out of reset. */
      /* --------------------------------------------------------------------------- */
      audio_dsp_reset(i);
      audio_dsp_pvt_download_fw(i);

      /* Wait here untill we are signaled that FW is done loading */
      osal_res = os_event_hardwait ( & ( dsp_dev->fw_init_done_event ), EVENT_NO_TIMEOUT );
      if ( osal_res != OSAL_SUCCESS )
      {
         AUDIO_ERROR("os_event_wait failed.", osal_res, audio_devh[AUDIO_DEBUG_DSP]);
         audio_dsp_pvt_device_unlock(dsp_dev);
         goto exit;
      }

      audio_dsp_pvt_enable_fw_sven(i);
      /* Get the FW version */
      OS_PRINT("Audio FW for DSP %d Initialized. Built on %s\n",  dsp_dev->device_num, dsp_dev->build_time);

      /* --------------------------------------------------------------------------- */

      audio_dsp_pvt_device_unlock(dsp_dev);
   }

   ismd_res = ISMD_SUCCESS;
   exit:
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP]);		
   return ismd_res;
   }
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_deinitialize(void)
{
   uint32_t i=0;
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_dsp_device_t *dev;
   osal_result osal_res;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_DSP]);	

   osal_res = OSAL_ERROR;

   if (!dsp_initialized)
   {
      AUDIO_INFO ( LOG_INFO_LEVEL_1, audio_devh[AUDIO_DEBUG_DSP], "Not initialized.%c", 0 );
      ismd_res = ISMD_SUCCESS;
      goto exit;
   }

   for (i=0; i<AUDIO_DSP_MAX_DEVICES; i++)
   {
      dev = &(dsp_device[i]);

      audio_dsp_pvt_device_lock (dev);

      /* Release the interrupt. */
      os_release_interrupt (dev->intr_handle);

      /* Put the DSP in reset. */
      devh_WriteReg32 (dev->devh, CSR, 0);	

      /* This is where most of the cleanup happens. Buffer deallocation, thread destoy, variable setting etc. */
      audio_dsp_pvt_device_reset (dev);
   }


   for (i=0; i<AUDIO_DSP_MAX_WORKLOADS; i++)
   {
      audio_dsp_pvt_wl_release (&(dsp_wl[i]));
   }

   ismd_res = ISMD_SUCCESS;
   exit:
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP]);		
   return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* This function gets the handle to the event given from the PSM to wake up the thread when needed */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_io_event_set(os_event_t *io_event)
{
   ismd_result_t ismd_res = ISMD_SUCCESS;
   uint32_t i = 0;
   audio_dsp_device_t *dsp_dev = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_DSP]);	

   for (i=0; i<AUDIO_DSP_MAX_DEVICES; i++)
   {
      dsp_dev = &(dsp_device[i]);
      audio_dsp_pvt_device_lock(dsp_dev);
      dsp_dev->psm_io_event = io_event;
      audio_dsp_pvt_device_unlock(dsp_dev);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP]);		
   return ismd_res;

}
/* --------------------------------------------------------------------------- */

ismd_result_t audio_dsp_codec_available( audio_dsp_handle_t	handle, uint8_t dsp_num, codecs_available_t *codec_status )
{
   ismd_result_t result = ISMD_ERROR_INVALID_RESOURCE;
   audio_dsp_wl_t *wl = NULL;
   codecs_available_t *codec_available_status;
   uint8_t temp_dsp_num;
   if ( !(wl = audio_dsp_pvt_wl_get ( handle )) ) {
      
      AUDIO_ERROR( "Invalid DSP layer handle!", result, audio_devh[AUDIO_DEBUG_DSP] );
   }
   else {
      audio_dsp_pvt_wl_lock(wl);
      temp_dsp_num = wl->dsp_num;
      wl->dsp_num = dsp_num;
      /*Clear the "done" flag before sending to the DSP*/
      codec_available_status =  &(dsp_device[wl->dsp_num].codecs_available);
      codec_available_status->done_flag = false;

      //Ask the DSP if this codec is available. 
      if ((result = audio_dsp_pvt_send_message ( wl, AUDIO_DSP_MESSAGE_HTOD_CODEC_AVAILABLE, 0, true)) != ISMD_SUCCESS) {
         
         AUDIO_ERROR( "Sending 'codec available' message to DSP failed.", result, audio_devh[AUDIO_DEBUG_DSP] );				
      }
      else {

         /* Call down to flush the chipset caches. */
         pal_flush_chipset_cache();

         /* Copy over the structure from the mailbox to the local structure */
         memcpy((void*)codec_status, (void*)&(dsp_device[wl->dsp_num].codecs_available), sizeof(codecs_available_t));

         /* This is to ensure the DSP is done writing out to memory, were seeing issues with this data getting to memory in time. */
         if(!codec_available_status->done_flag) {
            OS_PRINT("\nAUDIO WARNING: Done flag not set when DSP wrote out codec info!\n");
         }
      }
      wl->dsp_num = temp_dsp_num;
      audio_dsp_pvt_wl_unlock(wl);
   }
   
   return result;
}

ismd_result_t
audio_dsp_get_codec_ver_string ( audio_dsp_handle_t handle, uint8_t dsp_num, uint8_t codec, char *codec_ver_string )
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_dsp_wl_t *wl = NULL;
   uint8_t temp_dsp_num;
   char ver_string[256];

   if ( !(wl = audio_dsp_pvt_wl_get ( handle )) ) {
      
      AUDIO_ERROR( "Invalid DSP layer handle!", result, audio_devh[AUDIO_DEBUG_DSP] );
   }
   else {
      audio_dsp_pvt_wl_lock(wl);
      temp_dsp_num = wl->dsp_num;
      wl->dsp_num = dsp_num;
      dsp_device[wl->dsp_num].codec_ver_string = ver_string;
      //Ask the DSP if this codec is available. 
      if ((result = audio_dsp_pvt_send_message ( wl, AUDIO_DSP_MESSAGE_HTOD_GET_CODEC_VER_STRING, codec, true)) != ISMD_SUCCESS) {
         
         AUDIO_ERROR( "Sending 'get codec ver string' message to DSP failed.", result, audio_devh[AUDIO_DEBUG_DSP] );				
      }
      else {

         //workaround untill we figure out this problem. This function is only called at init time. 
         pal_flush_chipset_cache();

         strncpy(codec_ver_string, dsp_device[wl->dsp_num].codec_ver_string, (strlen(dsp_device[wl->dsp_num].codec_ver_string)+1));
      }
      wl->dsp_num = temp_dsp_num;
      audio_dsp_pvt_wl_unlock(wl);
   }
   
   return result;
}


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_pipe_add( audio_psm_pipe_t *pipe, audio_dsp_handle_t *handle )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_dsp_wl_t *wl = NULL;
   uint32_t i=0;
   (void)audio_dsp_pvt_wl_get_by_fw_handle; //AVOID WARNING
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_DSP]);	

   //Make sure we have a valid handle.
   if (handle != NULL) {

      /*For now just iterate through all available work loads and assign the first available one.*/
      for (i=0; i<AUDIO_DSP_MAX_WORKLOADS; i++) {
         
         wl = audio_dsp_pvt_wl_get (i);
         
         audio_dsp_pvt_wl_lock(wl);
         if (!wl->in_use) {

            /* Assign the wl to a DSP. Important to assign the DSP since address translation of the physical addresses depends on the DSP.*/
            if((result = audio_dsp_pvt_assign_dsp(wl, pipe->type)) != ISMD_SUCCESS) {
               AUDIO_ERROR( "Could not assign DSP to workload.", result, audio_devh[AUDIO_DEBUG_DSP] );
            }
            else if((result = audio_dsp_pvt_send_message( wl, AUDIO_DSP_MESSAGE_HTOD_PIPE_ADD, 0, true)) != ISMD_SUCCESS) {
               AUDIO_ERROR( "Sending 'Pipe Add' message to DSP failed.", result, audio_devh[AUDIO_DEBUG_DSP] );
            }
            else {

               	/* This pipe is supplied by the PSM. The assumption is the PSM abstraction layer is not going modify the pipe without following protocol. */	
               wl->pipe = pipe;
               wl->in_use = true;
               *handle = wl->handle;
            }
            
            result = ISMD_SUCCESS;
            i = AUDIO_DSP_MAX_WORKLOADS;//Break out
         }
         audio_dsp_pvt_wl_unlock(wl);
      }

      if(result != ISMD_SUCCESS) {
         result = ISMD_ERROR_NO_RESOURCES;
         AUDIO_ERROR("No available DSP workloads.", result,  audio_devh[AUDIO_DEBUG_DSP]);
      }     
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid DSP handle.", result, audio_devh[AUDIO_DEBUG_DSP] );
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP]);		
   return result;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_pipe_remove( audio_dsp_handle_t handle )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_dsp_wl_t *wl = NULL;
   audio_psm_job_desc_t *cur_job = NULL;
   uint32_t i=0, q=0;
   audio_psm_queue_tracker_t *queue = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_DSP]);	

   wl = audio_dsp_pvt_wl_get ( handle );
   if ( !wl )
   {
      ismd_res = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid Handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
      goto exit;
   }

   audio_dsp_pvt_wl_lock(wl);	//get the lock on the workload

   OS_ASSERT(!wl->started);

   /* If the wl is not in use, then return success since its already removed.
   Sometimes we dont call start, which allocs the impl layer pipe, then we 
   call free without calling start, we dont want this to fail in that case. */  
   if(!wl->in_use) {

      ismd_res = ISMD_SUCCESS;
      audio_dsp_pvt_wl_unlock(wl);
      goto exit;
   }

   /* Go ahead and flush the pipe. This would make the data stale. */
   ismd_res = audio_dsp_pvt_pipe_flush(wl);
   if ( ismd_res != ISMD_SUCCESS )
   {	
      audio_dsp_pvt_wl_unlock(wl);   
      goto exit;	
   }


   /* Cannot stop a work load that is not started */
   AUDIO_INFO ( LOG_INFO_LEVEL_1, audio_devh[AUDIO_DEBUG_DSP], "Sending 'Teardown' message to DSP.%c", 0 );
   ismd_res = audio_dsp_pvt_send_message ( wl, 	AUDIO_DSP_MESSAGE_HTOD_PIPE_REMOVE, 0, true);
   if (ismd_res != ISMD_SUCCESS)
   {
      AUDIO_ERROR( "Sending 'Teardown' message to DSP failed, still trying to clean up....", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );		
   }

   /* Go through all the input and output jobs and deallocate them. 
   In the case of output jobs replenish the aux buffers. */  
   for(q = 0; q < PSM_PIPE_MAX_NUM_OUT_QUEUES; q++) {

      if(wl->output_queues->queue[q].in_use) {
         queue = &wl->out_queue_track[q];
         cur_job = queue->cur_out_job;
         do {
      audio_core_flush_cache(cur_job, sizeof(audio_psm_job_desc_t));
            if (cur_job->valid) {
               
               for (i=0; i<cur_job->buffers_count; i++) {

            /* Only replenish the buffers if the DSP actually asked the Host for a new buffer. */
            if(cur_job->buffers[i].smd_buf_desc != NULL) {

               /* Replace the consumed buffer with a new SMD buffer */ 				
               ismd_res = audio_dsp_pvt_buffer_allocate(&(dsp_device[wl->dsp_num].psm_bufs[cur_job->buffers[i].handle]), 
               wl->pipe->type,
               PSM_BUFFER_SIZE,
               dsp_device[wl->dsp_num].kernel_smd_buf_desc->phys.base);
               if ( ismd_res != ISMD_SUCCESS )
               {
                  AUDIO_ERROR( "Error allocating PSM Aux buffers.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
                  audio_dsp_pvt_wl_unlock(wl);
                  goto exit;
               }
               /* This is flag that the DSP and Host look at to see whether a buffer is available to be used or not. 
               Unitl in_use is set to false FW would not pick it up. */
               dsp_device[wl->dsp_num].psm_bufs[cur_job->buffers[i].handle].in_use = false;	 
            }                      
         }
      }
            cur_job = cur_job->virt_next;
         }while (cur_job != queue->cur_out_job);
      }
   }

   audio_dsp_pvt_wl_reset(wl);

   audio_dsp_pvt_wl_unlock(wl);
   ismd_res = ISMD_SUCCESS;
   exit:	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP]);		
   return ismd_res;	
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_pipe_start ( audio_dsp_handle_t	handle )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_dsp_wl_t *wl = NULL;	

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_DSP]);	

   wl = audio_dsp_pvt_wl_get ( handle );
   if ( !wl )
   {
      AUDIO_ERROR( "Invalid Handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
      ismd_res = ISMD_ERROR_INVALID_HANDLE;
      goto exit;
   }
   audio_dsp_pvt_wl_lock(wl);	//get the lock on the workload

   OS_ASSERT (wl->in_use);
   OS_ASSERT (wl->configured);
   OS_ASSERT (!wl->started);

   ismd_res = audio_dsp_pvt_send_message ( wl, AUDIO_DSP_MESSAGE_HTOD_PIPE_START, 0, true);
   if (ismd_res != ISMD_SUCCESS)
   {
      AUDIO_ERROR( "Sending 'Pipe Start' message to DSP failed.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );				
      audio_dsp_pvt_wl_unlock(wl);
      goto exit;	
   }
   wl->started = true;

   audio_dsp_pvt_wl_unlock(wl);
   ismd_res = ISMD_SUCCESS;
   exit:	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP]);		
   return ismd_res;	
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_pipe_stop( audio_dsp_handle_t handle )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_dsp_wl_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_DSP]);	

   wl = audio_dsp_pvt_wl_get ( handle );
   if ( !wl )
   {
      ismd_res = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid Handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
      goto exit;
   }

   audio_dsp_pvt_wl_lock(wl);	//get the lock on the workload

   /* The workload is already stopped if its not in use, return success */
   if (!wl->in_use)
   {
      ismd_res = ISMD_SUCCESS;
      audio_dsp_pvt_wl_unlock(wl);
      goto exit;
   }

   if (wl->started)
   {
      AUDIO_INFO ( LOG_INFO_LEVEL_1, audio_devh[AUDIO_DEBUG_DSP], "Sending 'Stop' message to DSP.%c", 0 );
      ismd_res = audio_dsp_pvt_send_message ( wl, 	AUDIO_DSP_MESSAGE_HTOD_PIPE_STOP, 0, true);
      if (ismd_res != ISMD_SUCCESS)
      {
         AUDIO_ERROR( "Sending 'Stop' message to DSP failed.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );		
         audio_dsp_pvt_wl_unlock(wl);
         goto exit;	
      }
   }
   wl->started = false; /* Set this first so that buffers to do not get processed. */

   audio_dsp_pvt_wl_unlock(wl);
   ismd_res = ISMD_SUCCESS;
   
   exit:	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP]);		
   return ismd_res;	
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Currently flush is implemented as flush and discard.
   During flush there is no message to send to the DSP just iterate through 
   the input and output queue and mark the data belonging to this as stale. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_pipe_flush ( audio_dsp_handle_t	handle )
{
	ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
	audio_dsp_wl_t *wl = NULL;
   
	AUDIO_ENTER(audio_devh[AUDIO_DEBUG_DSP]);	

	wl = audio_dsp_pvt_wl_get ( handle );
   if ( !wl )
   {
      ismd_res = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid Handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
	   goto exit;
   }

	audio_dsp_pvt_wl_lock(wl);	//get the lock on the workload

	OS_ASSERT(wl->in_use);

   /* Go ahead and flush the pipe. This would make the data stale. */
   ismd_res = audio_dsp_pvt_pipe_flush(wl);
   if ( ismd_res != ISMD_SUCCESS )
   {	
		audio_dsp_pvt_wl_unlock(wl);   
		goto exit;	
   }

	audio_dsp_pvt_wl_unlock(wl);
   
	ismd_res = ISMD_SUCCESS;
exit:	
	AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP]);		
   return ismd_res;	
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_pipe_configure( audio_dsp_handle_t handle )
{	
 	ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
	audio_dsp_wl_t *wl = NULL;
	audio_htod_mgs_t *mb_ptr = NULL; 
  // uint8_t *d_to_h_mb_ptr = 0;
   
	AUDIO_ENTER(audio_devh[AUDIO_DEBUG_DSP]);	
	
	wl = audio_dsp_pvt_wl_get ( handle );
   if ( !wl )
   {
      AUDIO_ERROR( "Invalid Handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
      ismd_res = ISMD_ERROR_INVALID_HANDLE;
	   goto exit;
   }
	audio_dsp_pvt_wl_lock(wl);	//get the lock on the workload

	OS_ASSERT(wl->in_use);
	OS_ASSERT(!wl->started);

	/* Preprocess all the addresses. */
	ismd_res = audio_dsp_pvt_wl_preprocess(wl); 
	if ( ismd_res != ISMD_SUCCESS )
   {	
		audio_dsp_pvt_wl_unlock(wl);
		goto exit;	
   }	
	
	/* --------------------------------------------------------------------------- */
	/* Store all the initialization addresses in the X->D mailbox. */
	/* --------------------------------------------------------------------------- */
	mb_ptr = ( audio_htod_mgs_t * ) (dsp_device[wl->dsp_num].kernel_smd_buf_desc->virt.base + AUDIO_DSP_H_TO_D_MAILBOX_OFFSET);
	OS_ASSERT ( mb_ptr );

	/*Store the physical address of the first stage of the psm pipe. */
	mb_ptr->pipe_conf.psm_stages = wl->pipe->stages->dsp_phys_address;

   /*Make sure the job queues are written to main memory. */
   audio_core_flush_cache(wl->output_queues, sizeof(audio_psm_pipe_output_queues_t));
   audio_core_flush_cache(wl->input_jobs, (sizeof(audio_psm_job_desc_t) * wl->input_jobs_count));

	/*Set the pointers of the input and output jobs queues to the DSP */
	mb_ptr->pipe_conf.cur_in_job = wl->cur_in_job->dsp_phys_address;
	mb_ptr->pipe_conf.prev_in_job = wl->prev_in_job->dsp_phys_address;

   /*Setting the address of the output queues structure for the FW to pick it up.*/
	mb_ptr->pipe_conf.output_queues = wl->output_queues->dsp_phys_address;

	/* TODO:Add other info if necessary into the X->D mailbox here. */	
	ismd_res = audio_dsp_pvt_send_message ( wl, 	AUDIO_DSP_MESSAGE_HTOD_PIPE_CONFIGURE, 0, true);
	if (ismd_res != ISMD_SUCCESS)
	{
      AUDIO_ERROR( "Sending 'Configure' message to DSP failed.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );				
		audio_dsp_pvt_wl_unlock(wl);
		goto exit;	
	}
	wl->configured = true;
   
	audio_dsp_pvt_wl_unlock(wl);
	ismd_res = ISMD_SUCCESS;
 exit:	
	AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP]);		
   return ismd_res;	
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Configure a stage down on the DSP pipe. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_stage_configure( audio_dsp_handle_t handle, int stage_handle)
{	
   ismd_result_t result = ISMD_ERROR_INVALID_RESOURCE;
   audio_dsp_wl_t *wl = NULL;

   if ( !(wl = audio_dsp_pvt_wl_get ( handle )) ) {
      
      AUDIO_ERROR( "Invalid DSP layer handle!", result, audio_devh[AUDIO_DEBUG_DSP] );
   }
   else {
      audio_dsp_pvt_wl_lock(wl);

      if ((result = audio_dsp_pvt_send_message ( wl, AUDIO_DSP_MESSAGE_HTOD_STAGE_CONFIGURE, (uint8_t)stage_handle, true)) != ISMD_SUCCESS) {
         
         AUDIO_ERROR( "Sending 'stage configure' message to DSP failed.", result, audio_devh[AUDIO_DEBUG_DSP] );				
      }

      audio_dsp_pvt_wl_unlock(wl);
   }
   
   return result;
}
/* --------------------------------------------------------------------------- */


ismd_result_t audio_dsp_stage_get_stream_info( audio_dsp_handle_t handle, int stage_handle)
{	
   ismd_result_t result = ISMD_ERROR_INVALID_RESOURCE;
   audio_dsp_wl_t *wl = NULL;

   if ( !(wl = audio_dsp_pvt_wl_get ( handle )) ) {
      
      AUDIO_ERROR( "Invalid DSP layer handle!", result, audio_devh[AUDIO_DEBUG_DSP] );
   }
   else {
      audio_dsp_pvt_wl_lock(wl);

      if ((result = audio_dsp_pvt_send_message ( wl, AUDIO_DSP_MESSAGE_HTOD_GET_STREAM_INFO, (uint8_t)stage_handle, true)) != ISMD_SUCCESS) {         
         AUDIO_ERROR( "Sending 'stage configure' message to DSP failed.", result, audio_devh[AUDIO_DEBUG_DSP] );				
      }

      audio_dsp_pvt_wl_unlock(wl);
   }
   
   return result;
}

ismd_result_t audio_dsp_stage_get_stage_params( audio_dsp_handle_t handle, int stage_handle)
{	
   ismd_result_t result = ISMD_ERROR_INVALID_RESOURCE;
   audio_dsp_wl_t *wl = NULL;

   if ( !(wl = audio_dsp_pvt_wl_get ( handle )) ) {
      
      AUDIO_ERROR( "Invalid DSP layer handle!", result, audio_devh[AUDIO_DEBUG_DSP] );
   }
   else {
      audio_dsp_pvt_wl_lock(wl);

      if ((result = audio_dsp_pvt_send_message ( wl, AUDIO_DSP_MESSAGE_HTOD_GET_STAGE_PARAMS, (uint8_t)stage_handle, true)) != ISMD_SUCCESS) {         
         AUDIO_ERROR( "Sending 'get stage params' message to DSP failed.", result, audio_devh[AUDIO_DEBUG_DSP] );				
      }

      audio_dsp_pvt_wl_unlock(wl);
   }
   
   return result;
}


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_write_input_job ( audio_dsp_handle_t handle, audio_psm_job_desc_t *job )
{
   ismd_result_t ismd_res = ISMD_SUCCESS;
   audio_dsp_wl_t *wl = NULL;
   uint32_t i=0;
   audio_dsp_device_t *dsp_dev = NULL;
   ismd_buffer_descriptor_t *smd_buf_desc = NULL;

   if ((wl = audio_dsp_pvt_wl_get ( handle )) == NULL) {
      ismd_res = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid Handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
   }
   else {
      audio_dsp_pvt_wl_lock(wl);//get the lock on the workload
      dsp_dev = &dsp_device[wl->dsp_num];

      /*Flush IA cache before reading if the job is valid from DSP.*/
      audio_core_flush_cache(&wl->cur_in_job->valid, sizeof(wl->cur_in_job->valid));
      
      /* If the cur input job desc is not valid then populate it and mark it as valid. */
      if (!wl->cur_in_job->valid) {

         /*We know its valid now flush entire size of job.*/
         audio_core_flush_cache(wl->cur_in_job, sizeof(audio_psm_job_desc_t));
         
         AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_DSP], SVEN_MODULE_EVENT_AUD_IO_DSP_WRITE_INPUT_JOB, 
            wl->handle, wl->cur_in_job->handle, wl->cur_in_job->valid, wl->prev_in_job->handle, wl->prev_in_job->valid, -1);
         
         /* Cleanup if necessary */
         if (wl->cur_in_job->cleanup) {
            audio_dsp_pvt_job_reset(wl->cur_in_job, true);
         }

         /* Copy the received job into the current job. */
         wl->cur_in_job->wl_handle = wl->fw_handle; /* Copy the fw workload handle associated with this wl. */
         wl->cur_in_job->buffers_count = job->buffers_count;

         for (i=0; i<job->buffers_count; i++) {

            wl->cur_in_job->buffers[i] = job->buffers[i];

            /* If there is a valid SMD buffer in this slot, translate the phys address so DSP can read that location.*/
            if (wl->cur_in_job->buffers[i].smd_buf_desc != NULL) {
               smd_buf_desc = (ismd_buffer_descriptor_t *)wl->cur_in_job->buffers[i].smd_buf_desc;
               wl->cur_in_job->buffers[i].dsp_phys_address = (void *)(smd_buf_desc->phys.base - dsp_dev->kernel_smd_buf_desc->phys.base);
            }
         }
         
         /*Flush the IA cache to commit previous changes, change flag, then flush again.*/
         audio_core_flush_cache(wl->cur_in_job, sizeof(audio_psm_job_desc_t));
         wl->cur_in_job->valid = true;
         audio_core_flush_cache(&wl->cur_in_job->valid, sizeof(wl->cur_in_job->valid));
         
         /* If the previous job is not valid (empty) then we know that there is a chance 
            that the DSP is waiting for an input job.  */
         audio_core_flush_cache(wl->prev_in_job, sizeof(audio_psm_job_desc_t));
         if (!wl->prev_in_job->valid) {
            wl->notify_fw_input_job_available = true;
            wl->dev_wl->needs_io_notification = true;
         }

         /*Update the linked list to next node in the DSP queue */
         wl->prev_in_job = wl->cur_in_job;
         wl->cur_in_job = wl->cur_in_job->virt_next;
         
      }
      /* Current job is valid DSP still using it, do nothing.*/
      else {
         ismd_res = ISMD_ERROR_NO_SPACE_AVAILABLE;
      }
      
      audio_dsp_pvt_wl_unlock(wl);
   }

   return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_read_output_job ( audio_dsp_handle_t handle, audio_psm_job_desc_t *job, int queue_id )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_dsp_wl_t *wl = NULL;
   bool deref_buffer = false;
   audio_dsp_device_t *dsp_dev = NULL;
   ismd_buffer_descriptor_t *smd_buf_desc = NULL;
   audio_buffer_attr_t *audio_buf_attr = NULL;
   audio_psm_queue_tracker_t *queue = NULL;
   audio_psm_buf_desc_t *dsp_buffer = NULL;

   if ((wl = audio_dsp_pvt_wl_get ( handle )) == NULL) {
      ismd_res = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid Handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
      goto exit;
   }

   audio_dsp_pvt_wl_lock(wl);
   dsp_dev = &dsp_device[wl->dsp_num];

   /*Caller wants a job from this queue, use the queue_id to look into that queue.*/
   queue = &wl->out_queue_track[queue_id];

   AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_DSP], SVEN_MODULE_EVENT_AUD_IO_DSP_READ_OUTPUT_JOB, 
      wl->handle, queue->cur_out_job->handle, queue->cur_out_job->valid, 0, 0, 0);

   /*Flush the cache before checking if the output job is valid.*/
   audio_core_flush_cache(&queue->cur_out_job->valid, sizeof(queue->cur_out_job->valid));
   if ( queue->cur_out_job->valid ) { 

      /*Flush entire job now we know its valid.*/
      audio_core_flush_cache(queue->cur_out_job, sizeof(audio_psm_job_desc_t));

      /*Doing a check to ensure we have a buffer from the DSP here.*/
      if(queue->cur_out_job->buffers_count != 1) {
         AUDIO_ERROR( "DSP queue did not send correct buffer count!", ISMD_ERROR_UNSPECIFIED, audio_devh[AUDIO_DEBUG_DSP] );
      }

      /* This job might be a stale job in which case it should be just discarded and the 
         cur job pointer incremented. But remember to still replenish the psm buffers like we do on a normal output. */
      if (queue->cur_out_job->stale_data)
      {
         dsp_buffer = &queue->cur_out_job->buffers[0]; //Only one buffer per job in the queue.
         
            //Only try to replace the buffer, if it was actually populated by the output stage. 
         if(dsp_buffer->smd_buf_desc != NULL) {
               
               /* Replace the consumed buffer with a new SMD buffer */
               ismd_res = audio_dsp_pvt_buffer_allocate(&(dsp_dev->psm_bufs[dsp_buffer->handle]), wl->pipe->type, PSM_BUFFER_SIZE, dsp_dev->kernel_smd_buf_desc->phys.base);
               if ( ismd_res != ISMD_SUCCESS ) {
                  AUDIO_ERROR( "Error allocating PSM Aux buffers.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
                  goto exit_with_unlock;
               }
               
               /* This is flag that the DSP and Host look at to see whether a buffer is available to be used or not. 
               Unitl in_use is set to false FW would not pick it up. */
            dsp_dev->psm_bufs[dsp_buffer->handle].in_use = false;
            }

         /*Need to ensure this buffer is dereferenced.*/
         deref_buffer = true;
         ismd_res = ISMD_ERROR_NO_DATA_AVAILABLE;
      }

      /* Valid data in job from DSP*/
      else {
         job->wl_handle = wl->handle;
          
         /* Check to see whether the handle was invalid. Should never happen. */
         if (job->wl_handle == -1) {
            AUDIO_ERROR( "Error finding associated DSP wl for FW wl.", ISMD_ERROR_INVALID_HANDLE, 
               audio_devh[AUDIO_DEBUG_DSP] );
            goto exit_with_unlock;
         }
       
         job->handle = queue->cur_out_job->handle;
         job->stale_data = queue->cur_out_job->stale_data;
         job->buffers_count = queue->cur_out_job->buffers_count;

         dsp_buffer = &queue->cur_out_job->buffers[0]; //Only one buffer per job in the queue.
            
            /* Populate the SMD buffer and descriptor structure. */
         smd_buf_desc = (ismd_buffer_descriptor_t *)dsp_buffer->smd_buf_desc;
         if(dsp_buffer->smd_buf_desc != NULL) {

            smd_buf_desc->phys.level = dsp_buffer->level;
               audio_buf_attr = ( audio_buffer_attr_t* ) ( smd_buf_desc->attributes );

               /* Get the metadata from the PSM buffer and put it into the SMD attributes field.*/
            *(audio_buf_attr) = dsp_buffer->metadata;             

               /* If we see the output has an EOS tag, reset the tag on the SMD buffer. */
            if (dsp_buffer->eos) {               
                  if ( ismd_tag_set_eos (smd_buf_desc->unique_id) != ISMD_SUCCESS) {
                     AUDIO_ERROR("Could not set eos tag", ismd_res, audio_devh[AUDIO_DEBUG_DSP]);
                  }               
               }

               /* Replace the buffer that was consumed by the output stage from the pool of buffers with a new one.*/
               ismd_res = audio_dsp_pvt_buffer_allocate(&(dsp_dev->psm_bufs[dsp_buffer->handle]), wl->pipe->type, PSM_BUFFER_SIZE, dsp_dev->kernel_smd_buf_desc->phys.base);
               if ( ismd_res != ISMD_SUCCESS ) {
                  AUDIO_ERROR( "Error allocating PSM Aux buffers.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
                  goto exit_with_unlock;
               }

            dsp_dev->psm_bufs[dsp_buffer->handle].in_use = false;
            } 

            /* Copy over the buffer to the job passed in, even if its NULL, that way the PSM knows if there is a buffer or not. */
         job->buffers[0] = *dsp_buffer;

         
         ismd_res = ISMD_SUCCESS;
      }

      /*Reset this location in the DSP jobs queue.*/
      audio_dsp_pvt_job_reset (queue->cur_out_job, deref_buffer);

      /*Need to flush the newest changes, reset valid flag, then flush for DSP to pick it up.*/
      audio_core_flush_cache(queue->cur_out_job, sizeof(audio_psm_job_desc_t));
      queue->cur_out_job->valid = false;
      audio_core_flush_cache(&queue->cur_out_job->valid, sizeof(queue->cur_out_job->valid));

      /* If the previous output job was valid then we know that the FW is waiting for an output job to free up. */
      audio_core_flush_cache(queue->prev_out_job, sizeof(audio_psm_job_desc_t));
      if (queue->prev_out_job->valid) {
         wl->notify_fw_output_job_consumed = true;  
         wl->dev_wl->needs_io_notification = true;
      }

      /* Update our linked list to the next node in the DSP queue.*/
      queue->prev_out_job = queue->cur_out_job;
      queue->cur_out_job = queue->cur_out_job->virt_next;
   }    
   /*No job to read out from the DSP queue.*/
   else {
      ismd_res = ISMD_ERROR_NO_DATA_AVAILABLE;
   }

exit_with_unlock:
   audio_dsp_pvt_wl_unlock(wl);
   
exit:
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP]);
   return ismd_res;

}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Called by the PSM when one iteration of inputs are processed. 
   At this time it is determined whether the FW should be interrupted or not. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_dsp_notify_jobs_done (void) 
{
   ismd_result_t result = ISMD_SUCCESS;
   int dsp_dev_num =0;

   /* For each DSP see if it needs wake up notification. */
   for (dsp_dev_num=0; dsp_dev_num<AUDIO_DSP_MAX_DEVICES; dsp_dev_num++) {  
      if(dsp_device[dsp_dev_num].needs_io_notification) {
         audio_dsp_pvt_send_msg_direct ( dsp_dev_num, 0, AUDIO_DSP_MESSAGE_HTOD_INPUT_JOB_AVAILABLE, 0, false, NULL);
         dsp_device[dsp_dev_num].needs_io_notification = false;
      }
   }
            
   if (audio_core_fast_path_enabled()) {
      pal_flush_chipset_cache();
   }
   
   return result;
}
/* --------------------------------------------------------------------------- */


ismd_result_t audio_dsp_reset(int device_num) 
{  
   uint32_t reg_val = 0;
   audio_dsp_device_t* dsp_dev = dsp_device + device_num;
   /****************************************************************************
   * Put DSP into reset status
   ****************************************************************************/
   reg_val = ( uint32_t ) devh_ReadReg32 ( dsp_dev->devh, CSR );
   reg_val = 0;
   devh_WriteReg32 ( dsp_dev->devh, CSR, reg_val );   //put the DSP in reset 
   
   return ISMD_SUCCESS;
}
 
ismd_result_t audio_dsp_wakeup(int device_num)
{
   osal_result osal_res = OSAL_SUCCESS;
   audio_dsp_device_t* dsp_dev = dsp_device + device_num;
      
   /* --------------------------------------------------------------------------- */
   /* Enable IPCD and IPCX interrupt on IA. */	
   devh_WriteReg32 ( dsp_dev->devh, IMRX, 3 );
   /****************************************************************************
   * wake up DSP
   *****************************************************************************/
   /* clear event */
   os_event_reset(&dsp_dev->fw_init_done_event);

   audio_dsp_reset(device_num);
   
   audio_dsp_pvt_download_fw(device_num);
   
   /* Wait here untill we are signaled that FW is done loading */
   osal_res = os_event_hardwait ( & ( dsp_dev->fw_init_done_event ), EVENT_NO_TIMEOUT );
   if ( osal_res != OSAL_SUCCESS ){
      AUDIO_ERROR("os_event_wait failed.", osal_res, audio_devh[AUDIO_DEBUG_DSP]);
      goto exit;
   }
   
   audio_dsp_pvt_enable_fw_sven(device_num);

   OS_PRINT("Audio FW for DSP %d Initialized. Built on %s\n",  dsp_dev->device_num, dsp_dev->build_time);
   exit: 
   return ISMD_SUCCESS;
}
/* --------------------------------------------------------------------------- */
/* Private Functions */
/* --------------------------------------------------------------------------- */
static audio_dsp_wl_t *audio_dsp_pvt_wl_get ( audio_dsp_handle_t     handle )
{
   if ( ( handle < 0 ) || ( handle > AUDIO_DSP_MAX_WORKLOADS - 1 ) )
      return NULL;
	
   return & ( dsp_wl[handle] );

}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_wl_reset(audio_dsp_wl_t *wl)
{
   audio_psm_job_desc_t *cur_job = NULL;
   int i = 0;
   audio_psm_queue_tracker_t *queue = NULL;
  
	/* TODO: Go through and deallocate all psm_stages and stage output buffers if already allocated. */
   wl->fw_handle = -1;
   wl->dsp_num = 0;
   wl->started = false;
   wl->in_use = false;
	wl->configured = false;
   wl->pipe = NULL;

	/* Go through all the valid input jobs and deallocate the buffers. */
	if (wl->cur_in_job)
	{
		cur_job = wl->cur_in_job;
		do 
		{
		   audio_core_flush_cache(cur_job, sizeof(audio_psm_job_desc_t));
			if ( (cur_job->valid) || (cur_job->cleanup) )
			{
				audio_dsp_pvt_job_reset (cur_job, true);
            cur_job->valid = false;
			}
         audio_core_flush_cache(cur_job, sizeof(audio_psm_job_desc_t));
			cur_job = cur_job->virt_next;		
		}while(cur_job != wl->cur_in_job);
	}

   for(i = 0; i < PSM_PIPE_MAX_NUM_OUT_QUEUES; i++) {
      queue = &wl->out_queue_track[i];
      
      if((wl->output_queues != NULL) && wl->output_queues->queue[i].in_use){
         if (queue->cur_out_job) {
            
            cur_job = queue->cur_out_job;
            do {
         audio_core_flush_cache(cur_job, sizeof(audio_psm_job_desc_t));
               if (cur_job->valid){
				audio_dsp_pvt_job_reset (cur_job, true);
            cur_job->valid = false;
			}
         audio_core_flush_cache(cur_job, sizeof(audio_psm_job_desc_t));
               cur_job = cur_job->virt_next;
               
            }while(cur_job != queue->cur_out_job);
	}

         /* Set the output job traversal pointers */
         queue->cur_out_job = &wl->output_queues->queue[i].jobs[0];
         queue->prev_out_job = &wl->output_queues->queue[i].jobs[PSM_PIPE_JOB_QUEUE_DEPTH- 1];
         wl->output_queues->queue[i].in_use = false;
      }
   }

   if(wl->input_jobs != NULL) {
      /* Set the input job traversal pointers back to first and last */
      wl->cur_in_job = &(wl->input_jobs[0]);
      wl->prev_in_job = &wl->input_jobs[wl->input_jobs_count - 1];
   }

   wl->notify_fw_input_job_available = false;
   wl->notify_fw_output_job_consumed = false;

}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* This function is called only when deinitialize is called. */
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_wl_release(audio_dsp_wl_t *wl)
{   
   audio_dsp_pvt_wl_reset(wl);

   OS_UNMAP_IO_FROM_MEM(wl->input_jobs , wl->input_jobs_smd_buf_desc->phys.size);
   OS_UNMAP_IO_FROM_MEM(wl->output_queues , wl->output_jobs_smd_buf_desc->phys.size);
   
	if (wl->input_jobs_smd_buf_desc)
		ismd_audio_buffer_dereference (wl->input_jobs_smd_buf_desc->unique_id);
	wl->input_jobs_smd_buf_desc = NULL;
	wl->input_jobs = NULL;
	wl->input_jobs_count = 0;

 	if (wl->output_jobs_smd_buf_desc)
		ismd_audio_buffer_dereference (wl->output_jobs_smd_buf_desc->unique_id);
	wl->output_jobs_smd_buf_desc = NULL;

	wl->cur_in_job = NULL;
	wl->prev_in_job = NULL;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* This function assumes that the device_num is set. */
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_device_reset(audio_dsp_device_t *dev)
{	
	uint32_t i=0;
		
	/* TODO: Go through and deallocate allocated buffers if already allocated. */
	if (dev->device_num == 0)
		dev->pal_dev_id = TDSP_0;
	else
		dev->pal_dev_id = TDSP_1;

	if (dev->device_num == 0)
		dev->sven_dev_id = SVEN_module_GEN3_AUD_DSP0;
	else
		dev->sven_dev_id = SVEN_module_GEN3_AUD_DSP1;

	dev->pal_info_ptr = &dev->pal_info;

	dev->fw_loaded = false;
	dev->intr_handle = NULL;	
	dev->pal_info_ptr = &dev->pal_info;	// this would be set to &pal_info defined in the structure	  
	dev->devh = NULL;
   dev->needs_io_notification = false;

	if (dev->kernel_smd_buf_desc)
		ismd_audio_buffer_dereference (dev->kernel_smd_buf_desc->unique_id);
	dev->kernel_smd_buf_desc = NULL;	



	for (i=0; i<dev->psm_bufs_count; i++)
	{
      if (!dev->psm_bufs[i].in_use)
   		audio_dsp_pvt_buffer_reset(&(dev->psm_bufs[i]), true);
      else
         audio_dsp_pvt_buffer_reset(&(dev->psm_bufs[i]), false);
      dev->psm_bufs[i].in_use = false;
	}	
	if (dev->psm_bufs_smd_buf_desc)
		ismd_audio_buffer_dereference (dev->psm_bufs_smd_buf_desc->unique_id);

   return;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* This function is responsible for assigning a worload(pipe) to a particular DSP. 
	Once a wl is assigned to a DSP it cannot be changed. 
	This function would take into account what other workloads are currently active 
   on each DSP, their MIPS count and allocate the a current DSP.  
   Currently it merely allocates it to the DSP-S by default. */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_dsp_pvt_assign_dsp (audio_dsp_wl_t *wl, audio_psm_pipe_type_t type)
{
   ismd_result_t ismd_res = ISMD_SUCCESS;

   if (type == PSM_PIPE_TYPE_DECODE)
   {
      wl->dsp_num = dsp_num_decode;
   }
   else if (type == PSM_PIPE_TYPE_POST_ATC)
   {
      wl->dsp_num = dsp_num_post_processing;
   }
   else { 
      AUDIO_ERROR("Tried to assign a DSP number with out a pipe type value. Assiging to DSP 0.", ISMD_ERROR_UNSPECIFIED, audio_devh[AUDIO_DEBUG_DSP]);
      wl->dsp_num = 0;
   }

   /*Make the workload aware of the device workload its associated with. */
   wl->dev_wl = &dsp_device[wl->dsp_num];

   return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_wl_lock(audio_dsp_wl_t *wl)
{
   os_mutex_lock(&wl->lock);
  // OS_INFO("wl lock\n");
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_wl_unlock(audio_dsp_wl_t *wl)
{
   os_mutex_unlock(&wl->lock);
  // OS_INFO("wl unlock\n");
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_device_lock(audio_dsp_device_t *dev)
{
   os_mutex_lock(&dev->lock);
  // OS_INFO("dev ock\n");
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_device_unlock(audio_dsp_device_t *dev)
{
   os_mutex_unlock(&dev->lock);
  // OS_INFO("dev unlock\n");
}
/* --------------------------------------------------------------------------- */

static void audio_dsp_pvt_set_event(os_event_t *event, char *error_message)
{
   if ( os_event_set (event) != OSAL_SUCCESS ) {
      AUDIO_ERROR(error_message, ISMD_ERROR_OPERATION_FAILED, audio_devh[AUDIO_DEBUG_DSP]);
   }
}


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_interrupt_handler ( void * data )
{
   int device_num = (int)data;
   audio_dsp_device_t *dsp_dev = NULL;
   uint32_t isrx_val = 0;
   uint32_t imrx_val = 0;
   uint32_t ipcd_val = 0;
   uint32_t ipcx_val = 0;
   uint32_t message = 0;
   int32_t wl_id = 0;
   uint32_t fw_wl_id = 0;
   uint32_t message_data = 0;
   uint32_t *d_to_h_mb_ptr = 0;
   ismd_event_t  *notification_events;
   char error_msg[AUDIO_DSP_D_TO_H_MAILBOX_SIZE];
   bool set_msg_done_event = false;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_DSP] );

   /*Get the DSP device's context workload.*/
   OS_ASSERT((device_num >= 0) && (device_num < AUDIO_DSP_MAX_DEVICES));
   dsp_dev = &(dsp_device[device_num]);

   /*Get pointer to mailbox.*/
   d_to_h_mb_ptr = ( uint32_t * ) (dsp_dev->kernel_smd_buf_desc->virt.base + AUDIO_DSP_D_TO_H_MAILBOX_OFFSET);
   OS_ASSERT ( d_to_h_mb_ptr );

   /*Get the current status of any pending interrupts. */
   isrx_val = devh_ReadReg32 ( dsp_dev->devh, ISRX );
   imrx_val = devh_ReadReg32 ( dsp_dev->devh, IMRX );

   /*While we still have pending interrupts to service.*/
   while ( isrx_val & imrx_val )
   {
      /* We know that there is an unmasked interrupt. 3 cases to handle. */
      /* 1. IPCD interrupt (Bit 1 of ISRX is set. )
         2. IPCX interrupt (Bit 0 of ISRX is set)
         3. IPCD and IPCX interrupt. */

      /*** This case is when the DSP is generating a message to the HOST directly. In this case */
      /*** (IPCD interrupt) we do not want the DSP telling the HOST to move on by setting the   */
      /*** sync_msg event. That is taken care of when the DSP signals this at the end of the    */
      /*** interrupt handler that the HOST initiated message is now done (via IPCX interrupt).  */
      if ( isrx_val & imrx_val & AUDIO_DSP_IPCD_INTR ) {

         /* Read IPCD and get message info from the DSP. */
         ipcd_val = devh_ReadReg32 ( dsp_dev->devh, IPCD );
         fw_wl_id = AUDIO_DSP_DBREG_TO_WL_ID(ipcd_val);
         message = AUDIO_DSP_DBREG_TO_MESSAGE_ID(ipcd_val);
         message_data = AUDIO_DSP_DBREG_TO_MESSAGE_DATA(ipcd_val);    

         AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_DSP], SVEN_MODULE_EVENT_AUD_IO_DSP_IPCD_INTR, 
            wl_id, message, device_num, 0, 0, 0);
         
         /* Process the interrupt. */
         switch (message)
         {
            case AUDIO_DSP_MESSAGE_DTOH_FW_INIT_COMPLETE:
               
               strcpy(dsp_dev->build_time, (char *)d_to_h_mb_ptr);
               /*Clear out the mailbox. */
               *((char *)d_to_h_mb_ptr) = '\0';
               
               audio_dsp_pvt_set_event( &dsp_dev->fw_init_done_event, "Could not set fw_init_done_event.");      
               break;
            
            case AUDIO_DSP_MESSAGE_DTOH_INPUT_JOB_CONSUMED:
            case AUDIO_DSP_MESSAGE_DTOH_OUTPUT_JOB_AVAILABLE:
               /*Set the event that wakes up the PSM IO thread.*/
               audio_dsp_pvt_set_event( dsp_dev->psm_io_event, "Could not set psm_io_event.");
               break;

            /* The DSP has event its reporting, need to get the event from the message data, and set the event. */
            case AUDIO_DSP_MESSAGE_DTOH_NOTIFICATION_EVENT:
               notification_events = (ismd_event_t *)(*d_to_h_mb_ptr);
               audio_core_notify_event_top_half(notification_events, (ismd_audio_notification_t)message_data);
               /*If this is the codec change event, need to fire the IEC parser status change event. Remove this logic
                 we it is decided we end of life the PARSER using the codec change event. */
               if(((ismd_audio_notification_t)message_data) == ISMD_AUDIO_NOTIFY_CODEC_CHANGE) {
                  audio_core_notify_event_top_half(notification_events, ISMD_AUDIO_NOTIFY_PARSER_STATUS_CHANGE);
               }
               break; 

            case AUDIO_DSP_MESSAGE_DTOH_CODEC_AVAILABLE:
               memcpy((void*)&(dsp_dev->codecs_available), (void*)(d_to_h_mb_ptr), sizeof(codecs_available_t));
               break;
               
            case AUDIO_DSP_MESSAGE_DTOH_CODEC_VER_STRING:
               if(dsp_dev->codec_ver_string != NULL){
                  strcpy(dsp_dev->codec_ver_string, (char *)(d_to_h_mb_ptr));
               }
               break;

            /* Get the firmware handle when a pipe is added. */
            case AUDIO_DSP_MESSAGE_DTOH_PIPE_ADDED:
               dsp_dev->fw_handle = (int)(*d_to_h_mb_ptr);
               break;

            case AUDIO_DSP_MESSAGE_DTOH_MAILBOX_CONTAINS_MESSAGE:
               /*Print out the generic message sent from the DSP.*/
               OS_PRINT("Audio FW says: %s\n", (char *)d_to_h_mb_ptr);
               *((char *)d_to_h_mb_ptr) = '\0';
               break;

            case AUDIO_DSP_MESSAGE_DTOH_STAGE_EXE_ERROR:
               
               // TODO: This event/message is not relavant anymore need to EOL
               AUDIO_EVENT (AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_DSP], 
                  SVEN_MODULE_EVENT_AUD_IO_DSP_HTOD_MESSAGE_DSP_SENT_ERROR, wl_id, message, message_data, 0, 0, 0);
               
               if(message_data != PSM_TASK_DECODE) {
                  AUDIO_ERROR( "DSP send error. FW returned error.", 0, audio_devh[AUDIO_DEBUG_DSP] );
               }
               break;
               
            default:
               OS_PRINT("Audio DSP sent a message not recognized by the host!\n");
               break;
         }

         /* Clear the busy bit so the interrupt can be acknowledged, and DSP know it can move on.*/
         devh_WriteReg32 ( dsp_dev->devh, IPCD, (ipcd_val & 0x00ffffff) | AUDIO_DSP_IPCD_HOST_DONE ); 

         /* Read ISRX value again to get current status, then acknowledge the interrupt.*/
         isrx_val = devh_ReadReg32 ( dsp_dev->devh, ISRX );
         devh_WriteReg32 ( dsp_dev->devh, ISRX, (isrx_val & 0xfffffffd) | AUDIO_DSP_IPCD_INTR );
         
      }

      /*** This case is the call used by the DSP to tell the HOST its finished processing the last message sent */
      /*** It is important to remember that its in this interrupt type where the event to tell the host to move */
      /*** on and can accept another message to process. That is why only here we set the sync_msg event. If    */
      /*** this protocall is not adheared to, you WILL get unpredictable behavior.                              */
      else if ( isrx_val & imrx_val & AUDIO_DSP_IPCX_INTR)
      {

         /* Read IPCX and get message info from the DSP. */
         ipcx_val = devh_ReadReg32 ( dsp_dev->devh, IPCX );
         fw_wl_id = AUDIO_DSP_DBREG_TO_WL_ID(ipcx_val);
         message = AUDIO_DSP_DBREG_TO_MESSAGE_ID(ipcx_val);
         message_data = AUDIO_DSP_DBREG_TO_MESSAGE_DATA(ipcx_val);      
         set_msg_done_event = false;

         AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_DSP], SVEN_MODULE_EVENT_AUD_IO_DSP_IPCX_INTR, 0, 0, 0, 0, 0, 0);

         /* When the DSP writes back into the IPCX, message_data 
            is the return value of the message just processed. Making
            sure we didn't get an error from that. */
         if ( message_data != 0 ) { 
            
            /*Error reporting for this problem.  */
            snprintf(error_msg, AUDIO_DSP_D_TO_H_MAILBOX_SIZE, "Sending %s to dsp %d failed.\nFW returned error: %s.",
            audio_dsp_pvt_message_get_name(message), dsp_dev->handle, (char *)d_to_h_mb_ptr);             
            AUDIO_ERROR( error_msg, ISMD_ERROR_OPERATION_FAILED, audio_devh[AUDIO_DEBUG_DSP] );
            AUDIO_EVENT (AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_DSP], SVEN_MODULE_EVENT_AUD_IO_DSP_HTOD_MESSAGE_DSP_RETURNED_ERROR, \
               dsp_wl[wl_id].handle, message, message_data, ipcx_val, message_data, 0);

            /*Clear out the mailbox for next message.*/
            memset(d_to_h_mb_ptr, 0, AUDIO_DSP_D_TO_H_MAILBOX_SIZE);
         }
         
         /* Update our last status. */
         dsp_dev->last_sync_msg_status = message_data; 
         
         /* These messages are done when there is no FW workload to compare yet.
            They also are special because the host starts the message to the DSP, 
            then the DSP sends back information requested by the message in its
            interrupt handler, waits for host response then finishes the call by
            generating the IPCX interrupt (means DSP interrupt is done), so here
            we have to ensure the msg_sync event is set since its signaling the DSP is done.*/
         if((message == AUDIO_DSP_MESSAGE_HTOD_CODEC_AVAILABLE) ||
            (message == AUDIO_DSP_MESSAGE_HTOD_GET_CODEC_VER_STRING) ||
            (message == AUDIO_DSP_MESSAGE_HTOD_PIPE_ADD))
         {
            set_msg_done_event = true;
         }
         /*All other messages are sent with a context workload and need to compare
           to the sender to ensure proper synchronization. */
         else if (((fw_wl_id == dsp_dev->last_sync_msg_fw_wl) && (message == dsp_dev->last_sync_msg))){
            set_msg_done_event = true;
         }

         /* Clear out IPCX to let DSP know we are finished with the message.*/
         devh_WriteReg32 ( dsp_dev->devh, IPCX, 0 ); 

         /* Read ISRX value again to get current status, then acknowledge the interrupt.*/
         isrx_val = devh_ReadReg32 ( dsp_dev->devh, ISRX );
         devh_WriteReg32 ( dsp_dev->devh, ISRX, (isrx_val & 0xfffffffe) | AUDIO_DSP_IPCX_INTR );

         /*Now set any message processing event to let the next host message go.*/
         if(set_msg_done_event) {
            audio_dsp_pvt_set_event( &dsp_dev->sync_msg_proc_done_event, "Could not set sync_msg_proc_done_event");
         }
      }

      /* Read the interrupt status registers again, to process pending interrupts.*/
      isrx_val = devh_ReadReg32 ( dsp_dev->devh, ISRX );
      imrx_val = devh_ReadReg32 ( dsp_dev->devh, IMRX );
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_DSP] );

   return;
}

static ismd_result_t audio_dsp_pvt_send_message ( audio_dsp_wl_t *wl, 
                                                  uint8_t message_id,
                                                  uint8_t message_data,
                                                  bool wait_for_response)
{
   
   return audio_dsp_pvt_send_msg_direct( wl->dsp_num, 
                                         wl->fw_handle,
                                         message_id,
                                         message_data,
                                         wait_for_response,
                                         &wl->fw_handle);
}


/* --------------------------------------------------------------------------- */
/* --------------------------------------------------------------------------- */
/* This function assumes that mailbox X->D is already set by the calling function. */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_dsp_pvt_send_msg_direct( unsigned int dsp_num,
                                                    unsigned int fw_handle,
                                                    uint8_t message_id,
                                                    uint8_t message_data,
                                                    bool wait_for_response, 
                                                    int *new_fw_handle)
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   uint32_t ipcx_val = 0;
   unsigned int temp_reg_val = 0;
   int dsp_response_wait_count = 0;
   os_devhandle_t  *dsp_devh = NULL;
   osal_result osal_res;	
   
   /*Need to protect against potential race condition if task is swapped out */   
   os_mutex_lock ( &dsp_device[dsp_num].ipc_lock );
   dsp_devh = dsp_device[dsp_num].devh;

   AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_DSP], SVEN_MODULE_EVENT_AUD_IO_DSP_HTOD_MESSAGE, \
      fw_handle, message_id, message_data, 0, 0, 0);

   /* Make sure that register is not in use. */
   ipcx_val = ( uint32_t ) devh_ReadReg32 ( dsp_devh, IPCX );

   //check to see if it is PSM message
   if((message_id == AUDIO_DSP_MESSAGE_HTOD_INPUT_JOB_AVAILABLE)||(message_id == AUDIO_DSP_MESSAGE_HTOD_OUTPUT_JOB_AVAILABLE)) 
   {
      if((AUDIO_DSP_DBREG_TO_STATUS(ipcx_val) & AUDIO_DSP_DBREG_BUSY)&&(
            (AUDIO_DSP_DBREG_TO_MESSAGE_ID(ipcx_val) == AUDIO_DSP_MESSAGE_HTOD_INPUT_JOB_AVAILABLE) ||
            (AUDIO_DSP_DBREG_TO_MESSAGE_ID(ipcx_val) == AUDIO_DSP_MESSAGE_HTOD_OUTPUT_JOB_AVAILABLE)
         ))
      {
         os_mutex_unlock ( &dsp_device[dsp_num].ipc_lock );
         return ISMD_SUCCESS;
      }
   }
   
   while ( (AUDIO_DSP_DBREG_TO_STATUS(ipcx_val) & AUDIO_DSP_DBREG_BUSY) == AUDIO_DSP_DBREG_BUSY )
   {
      dsp_response_wait_count++;
      if (dsp_response_wait_count > DSP_MAX_TRIES_FOR_NON_BUSY_STATUS)
      {
         ismd_res = ISMD_ERROR_TIMEOUT;
         AUDIO_EVENT (AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_DSP], SVEN_MODULE_EVENT_AUD_IO_DSP_HTOD_MESSAGE_DSP_BUSY, \
         fw_handle, message_id, message_data, ipcx_val, 0, 0);
         OS_PRINT("\nAUDIO FATAL ERROR: Sending message %s on DSP num: %d failed! DSP is not responding!\n",audio_dsp_pvt_message_get_name(message_id), dsp_num);

         /*Clear out the wait count and try again, if DSP has crashed we are DOA.*/
         dsp_response_wait_count = 0;

         /*Signal to core we have a critical/fatal error*/
         ismd_signal_critical_error();
      }
      os_sleep (1);  
      ipcx_val = ( uint32_t ) devh_ReadReg32 ( dsp_devh, IPCX );
   }
   dsp_response_wait_count = 0;

   //Do these assignments first before sending the message, otherwise you will get a hang.
   if (wait_for_response)
   {
      /* Before waiting set the event and the wl_id we are waiting on. */
      dsp_device[dsp_num].last_sync_msg = message_id;
      dsp_device[dsp_num].last_sync_msg_fw_wl = fw_handle;
      dsp_device[dsp_num].fw_handle = 0;      
   }

   /* write the ipc register to interrupt the FW */
   audio_dsp_pvt_set_dbreg_value(&temp_reg_val, AUDIO_DSP_DBREG_BUSY, fw_handle, message_id, message_data);	

   if (audio_core_fast_path_enabled()) {
      pal_flush_chipset_cache();
   }

   devh_WriteReg32 ( dsp_devh, IPCX, temp_reg_val );

   if (wait_for_response)
   {
      /* Here we are waiting for the DSP host interrupt handler to set this event. Ideally this event should not have a time out, but
         since we want to be notified if the DSP has crashed, we have put the timeout to be very large. Then if the timeout happens 
         we will check the IPCX to see if the DSP really crashed or not. Keep in mind some times other drivers misbehave and could 
         starve out our DSP host bottom half handler's time slice so we are keeping this timeout very large. */
      osal_res = os_event_hardwait ( & ( dsp_device[dsp_num].sync_msg_proc_done_event ), DSP_MS_TO_WAIT_ON_EVENT_TIMEOUT);
      if ( osal_res != OSAL_SUCCESS ) {
         if ( osal_res == OSAL_TIMEOUT ) {

            /*Read IPCX, to see if the DSP never exited its interrupt handler, (still busy)*/
            ipcx_val = ( uint32_t ) devh_ReadReg32 ( dsp_devh, IPCX );
            if(AUDIO_DSP_DBREG_TO_STATUS(ipcx_val) & AUDIO_DSP_DBREG_BUSY) {

               /* Do a bunch of error reporting. SVEN and to the console */
               AUDIO_EVENT (AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_DSP], SVEN_MODULE_EVENT_AUD_IO_DSP_HTOD_MESSAGE_DSP_NO_RESPONSE, fw_handle, message_id, message_data, ipcx_val, 0, 0);  
               OS_PRINT("\nAUDIO FATAL ERROR: DSP didn't respond after sending message %s to DSP %d!\n",audio_dsp_pvt_message_get_name(message_id), dsp_num);
               ismd_res = ISMD_ERROR_TIMEOUT;
               
               /*Signal to core we have a critical/fatal error*/
               ismd_signal_critical_error();
            }
            /* DSP actually cleared the IPCX and is not busy, our DSP bottom half handler just never serviced the interrupt with in the timeout.*/
            else{
               OS_PRINT("\nAUDIO WARNING: DSP Host waited for the handler for %dms, DSP reports 'not busy', moving on!\n", DSP_MS_TO_WAIT_ON_EVENT_TIMEOUT);
            }
         }
         else {
            AUDIO_ERROR("os_event_wait failed.", osal_res, audio_devh[AUDIO_DEBUG_DSP]);	
         }
      }

      /* Check to see the return status of the operation. If it failed return operation failed
         so that the caller can handle it accordingly. */
      if (dsp_device[dsp_num].last_sync_msg_status)
      {
         goto exit_with_unlock;
      }  
      else  
      {
         if (message_id == AUDIO_DSP_MESSAGE_HTOD_PIPE_ADD)
         {
            if(new_fw_handle != NULL) {
               *new_fw_handle = dsp_device[dsp_num].fw_handle;
            }
         }
      }
	}

   ismd_res = ISMD_SUCCESS;

exit_with_unlock:
   os_mutex_unlock ( &dsp_device[dsp_num].ipc_lock );
   
//exit:		
   return ismd_res;	
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* WARNING: Do not reset the in_use flag. If this buffer is shared then the 
   in_use flag is used to tell the DSP that the buffer is ready for consumption. 
   Setting this in this function might lead to some race condition because there 
   might be other things that the host might want to do before releasing this buffer. 
   Hence leave this flag at the mercy of the calling function. */
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_buffer_reset( audio_psm_buf_desc_t *psm_buf, 
																bool dereference_buf )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   ismd_buffer_descriptor_t *smd_buf_desc;

   audio_core_reset_buffer_metadata(&psm_buf->metadata);

   psm_buf->dsp_phys_address = 0;
   psm_buf->size = 0;
   psm_buf->level = 0;
   psm_buf->in_all_output_queues = false;
   psm_buf->tags = false;
   psm_buf->eos = false;
   smd_buf_desc = (ismd_buffer_descriptor_t *) psm_buf->smd_buf_desc;

   if (dereference_buf && (psm_buf->smd_buf_desc != NULL))
   {
      ismd_res = ismd_audio_buffer_dereference(smd_buf_desc->unique_id);
      if ( ismd_res != ISMD_SUCCESS)
      {
         AUDIO_ERROR( "Error dereferencing buffer.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
      }
   }
   psm_buf->smd_buf_desc = NULL;

}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* WARNING: Do not reset the in_use flag. If this buffer is shared then the 
   in_use flag is used to tell the DSP that the buffer is ready for consumption. 
   Setting this in this function might lead to some race condition because there 
   might be other things that the host might want to do before releasing this buffer. 
   Hence leave this flag at the mercy of the calling function. */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_dsp_pvt_buffer_allocate(audio_psm_buf_desc_t *psm_buf,
                                                   audio_psm_pipe_type_t pipe_type,
																	uint32_t size,
																	uint32_t remap)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   ismd_buffer_descriptor_t *smd_buf_desc = NULL;	
   ismd_buffer_type_t smd_buffer_type = ISMD_BUFFER_TYPE_PHYS;

   /*Want the buffers going from Decoder to ATC to be cached. */
   if(pipe_type == PSM_PIPE_TYPE_DECODE) {
      smd_buffer_type = ISMD_BUFFER_TYPE_PHYS_CACHED;
   }

   if ( (result = ismd_audio_buffer_alloc_typed_direct(smd_buffer_type, size, &smd_buf_desc)) == ISMD_SUCCESS )
   {									
      psm_buf->smd_buf_desc = (void *)smd_buf_desc;
      psm_buf->dsp_phys_address = (void *)(smd_buf_desc->phys.base - remap);

      psm_buf->size = size;
      psm_buf->level = 0;
      psm_buf->eos = false;
      psm_buf->tags = false;

      /*Initialize the buffer metadata*/
      audio_core_reset_buffer_metadata(&psm_buf->metadata);
   }
   else{
      AUDIO_ERROR( "DSP Host buffer alloc failed :(", result, audio_devh[AUDIO_DEBUG_DSP] );											
   }
   
   return result;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Set the IPCD, IPCX registers given the bit breakdown. It is in a function so
 * when the bitbreakdown changes there is only one place to change.
   The caller passes 4 int which are packed in the necessary format and written 
   to the doorbell register. 
   + -- - + -- - + -- - + -- - + -- - + -- - + -- - + -- - +
   | Status (We only care about bit 31 and 30              |   - 0
   + -- - + -- - + -- - + -- - + -- - + -- - + -- - + -- - +
   | wl_id (ID of the fw workload                          |   - 1
   + -- - + -- - + -- - + -- - + -- - + -- - + -- - + -- - +
   | Message (See audio_dsp_common.h for list of messages  |   - 2
   + -- - + -- - + -- - + -- - + -- - + -- - + -- - + -- - +
   | Data (Use it any way you want. Usually return code    |   - 3
   + -- - + -- - + -- - + -- - + -- - + -- - + -- - + -- - +
   */ 
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_set_dbreg_value(uint32_t *reg_val,
														uint32_t status,
														uint32_t wl_id,
														uint32_t message,
														uint32_t data)
{   
   OS_ASSERT( (status == AUDIO_DSP_DBREG_BUSY) ||
               (status == AUDIO_DSP_DBREG_DONE) || 
               (status == 0) );
   
 	*reg_val = ( (status & 0x000000ff) << 24) | ( (wl_id & 0x000000ff) << 16) |
               ((message & 0x000000ff) << 8) | (data & 0x000000ff); 
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_dsp_pvt_init_jobs(audio_dsp_wl_t *wl)
{	
	ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
	uint32_t j=0, k=0;  
   uint32_t queue = 0, job = 0;

     void * jobs_cached_addr = NULL;


	/* --------------------------------------------------------------------------- */
	/* Input jobs. */
	/* --------------------------------------------------------------------------- */
	//buffer to hold input job descriptors
	/* 1K = 4 job descriptors. */
	ismd_res = ismd_audio_buffer_alloc_typed_direct ( ISMD_BUFFER_TYPE_PHYS, PSM_JOBS_BUF_SIZE, &(wl->input_jobs_smd_buf_desc));
   if ( ismd_res != ISMD_SUCCESS )
   {
      AUDIO_ERROR( "input job descriptors buffer allocation failed.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );													
      goto exit;
   }
      OS_MEMSET(wl->input_jobs_smd_buf_desc->virt.base, 0, wl->input_jobs_smd_buf_desc->phys.size);
   
   /*We want to cache the DSP to Host job queue since several struct copies happen during the transitions.*/
   jobs_cached_addr = OS_MAP_IO_TO_MEM_CACHE(wl->input_jobs_smd_buf_desc->phys.base, wl->input_jobs_smd_buf_desc->phys.size);
   wl->input_jobs = (audio_psm_job_desc_t *)jobs_cached_addr;
      
	wl->input_jobs_count = (((wl->input_jobs_smd_buf_desc->phys.size / sizeof(audio_psm_job_desc_t)) > PSM_PIPE_JOB_QUEUE_DEPTH) ? PSM_PIPE_JOB_QUEUE_DEPTH : 0);

    //Check to see if we have the correct job count. 
     if(wl->input_jobs_count == 0) {
      OS_PRINT("The audio_psm_job_desc_t is too large to generate our queues of %d jobs deep!! AUDIO FATALITY!!", PSM_PIPE_JOB_QUEUE_DEPTH);
      OS_ASSERT(wl->input_jobs_count == PSM_PIPE_JOB_QUEUE_DEPTH);
     }
   
	/* Set the next pointers in each job structure. */
	for (j=0; j<wl->input_jobs_count; j++)
	{
		wl->input_jobs[j].handle = j;
      /* Set the physical address. */
      wl->input_jobs[j].phys_address = (void *)(wl->input_jobs_smd_buf_desc->phys.base + (j * sizeof(audio_psm_job_desc_t)));         
		wl->input_jobs[j].phys_next = (void *)( wl->input_jobs_smd_buf_desc->phys.base +
                                       ((sizeof(audio_psm_job_desc_t) * ( (j+1) % wl->input_jobs_count))) ); 
      /* Need to set dsp_phys_next when we allocat the pipe to a particular DSP. We do not know that info right now. */
		//wl->input_jobs[j].dsp_phys_next = (void *)(wl->input_jobs[j].phys_next - wl->kernel_smd_buf_desc->phys.base);
		wl->input_jobs[j].virt_next = &(wl->input_jobs[(j+1) % wl->input_jobs_count]);

		for (k=0; k<PSM_MAX_IO_COUNT; k++)
		{
			audio_dsp_pvt_buffer_reset(&(wl->input_jobs[j].buffers[k]), false);
			wl->input_jobs[j].buffers[k].handle = k;
			wl->input_jobs[j].buffers[k].in_use = false;
		}
	}
   
	/* Set the input job traversal pointers */
   wl->cur_in_job = &(wl->input_jobs[0]);
	wl->prev_in_job = &wl->input_jobs[wl->input_jobs_count - 1];

	/* --------------------------------------------------------------------------- */


   /* --------------------------------------------------------------------------- */
   /* Output jobs. */
   /* --------------------------------------------------------------------------- */
   //buffer to hold output job buffer descriptors
   /* 1K = 4 job descriptors. */
   ismd_res = ismd_audio_buffer_alloc_typed_direct ( ISMD_BUFFER_TYPE_PHYS, SMD_64KB_BUFFERS, &(wl->output_jobs_smd_buf_desc));
   if ( ismd_res != ISMD_SUCCESS )
   {
      AUDIO_ERROR( "output job descriptors buffer allocation failed.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );															
      goto exit;
   }
   OS_MEMSET(wl->output_jobs_smd_buf_desc->virt.base, 0, wl->output_jobs_smd_buf_desc->phys.size);

   /*Assert if there is not enough memory for all output queues.*/
   OS_ASSERT((wl->output_jobs_smd_buf_desc->phys.size / sizeof(audio_psm_job_queue_t)) >= PSM_PIPE_MAX_NUM_OUT_QUEUES);

   /*We want to cache the DSP to Host job queue since several struct copies happen during the transitions.*/
   jobs_cached_addr = OS_MAP_IO_TO_MEM_CACHE(wl->output_jobs_smd_buf_desc->phys.base, wl->output_jobs_smd_buf_desc->phys.size);
   wl->output_queues = (audio_psm_pipe_output_queues_t*)jobs_cached_addr;

   /* Setup the output job queues here.*/
   for (queue=0; queue<PSM_PIPE_MAX_NUM_OUT_QUEUES; queue++) {
 
      int queue_phys_addr = ((queue * sizeof(audio_psm_job_queue_t)) + (int)wl->output_jobs_smd_buf_desc->phys.base);
      
      /*Indication this queue is not in use. */
      wl->output_queues->queue[queue].in_use = false;
      
   /* Set the next pointers in each job structure. */
      for (job =0; job < PSM_PIPE_JOB_QUEUE_DEPTH; job++) {
      
         wl->output_queues->queue[queue].jobs[job].handle = job;
         wl->output_queues->queue[queue].jobs[job].phys_address = (void*)(queue_phys_addr + (job*sizeof(audio_psm_job_desc_t)));  
         wl->output_queues->queue[queue].jobs[job].phys_next = (void*)(queue_phys_addr + (((job+1)%PSM_PIPE_JOB_QUEUE_DEPTH)*sizeof(audio_psm_job_desc_t)));

      /* Need to set dsp_phys_next when we allocat the pipe to a particular DSP. We do not know that info right now. */
         wl->output_queues->queue[queue].jobs[job].virt_next = &(wl->output_queues->queue[queue].jobs[(job+1) % PSM_PIPE_JOB_QUEUE_DEPTH]);

      /* These are jobs and dont have any valid buffers yet, but init the psm_buf_descriptors. */
         for (k=0; k<PSM_MAX_IO_COUNT; k++) {
            
            audio_dsp_pvt_buffer_reset(&(wl->output_queues->queue[queue].jobs[job].buffers[k]), false);
            wl->output_queues->queue[queue].jobs[job].buffers[k].handle = AUDIO_INVALID_HANDLE;
            wl->output_queues->queue[queue].jobs[job].buffers[k].in_use = false;
      }
   }
      
   /* Set the output job traversal pointers */
      wl->out_queue_track[queue].cur_out_job = &(wl->output_queues->queue[queue].jobs[0]);
      wl->out_queue_track[queue].prev_out_job = &(wl->output_queues->queue[queue].jobs[PSM_PIPE_JOB_QUEUE_DEPTH - 1]);
   }

	/* --------------------------------------------------------------------------- */

	ismd_res = ISMD_SUCCESS;
exit:
	return ismd_res;
}
/* --------------------------------------------------------------------------- */

/**
Set up the dsp physical address, size, and location for a psm buffer descriptor, given an ismd buffer descriptor and the DSP base address.

@param[in] psm_buf_desc : Pointer to a psm buffer descriptor

*/
static void audio_dsp_pvt_preprocess_psm_buffer(audio_psm_buf_desc_t * psm_buf_desc, ismd_buffer_descriptor_t *smd_buf_desc, uint32_t dsp_base){
   if(psm_buf_desc != NULL && smd_buf_desc != NULL){
      OS_ASSERT(smd_buf_desc);
      psm_buf_desc->dsp_phys_address = (void *)(smd_buf_desc->phys.base - dsp_base);
      psm_buf_desc->size = smd_buf_desc->phys.size;
      psm_buf_desc->level = smd_buf_desc->phys.level;
   }
}


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_dsp_pvt_wl_preprocess( audio_dsp_wl_t *wl )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   uint32_t i=0, q=0;
   audio_psm_stage_t *stage = NULL;
   uint32_t dsp_base = dsp_device[wl->dsp_num].kernel_smd_buf_desc->phys.base;

   /* Go through all the stages of the pipe and set all the physical addresses 
   	of the stage and buffers in every stage */		
   stage = wl->pipe->stages;

   wl->output_queues->dsp_phys_address = (void*)((uint32_t)wl->output_jobs_smd_buf_desc->phys.base - dsp_base);

   while (stage)
   {		
      stage->dsp_phys_address = stage->phys_address - dsp_base;
      	
      if (stage->phys_next)
      {
         stage->dsp_phys_next = stage->phys_next - dsp_base;
      }
      else {
         stage->dsp_phys_next = NULL;
      }

      for (i=0; i<stage->inputs_count; i++)
      {
         if (stage->dsp_phys_inputs[i])
         {
            stage->dsp_phys_inputs[i] = stage->dsp_phys_inputs[i] - dsp_base; 
            stage->dsp_phys_inputs_orig[i] = stage->dsp_phys_inputs[i];
         }
         else {
            stage->dsp_phys_inputs[i] = NULL;
            stage->dsp_phys_inputs_orig[i] = NULL;
         }

         /*In the output stage every input to the stage
           represents an output queue in use. Mark which
           queues will need to be in use here. */
         if (stage->task == PSM_TASK_OUT) {
            wl->output_queues->queue[i].in_use = true;
      }
      }

      for (i=0; i<stage->outputs_count; i++)
      {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->outputs[i]), stage->outputs[i].smd_buf_desc, dsp_base );
      }

      if (stage->task == PSM_TASK_AUDIO_QUALITY)
      {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.params_buffer), stage->stage_params.params_buffer.smd_buf_desc, dsp_base );
      }   

      if ( (stage->task == PSM_TASK_DECODE)  || (stage->task == PSM_TASK_ENCODE))
      {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.decoder.aux_buffer), stage->stage_params.decoder.aux_buffer.smd_buf_desc, dsp_base );
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.decoder.decode_buffer), stage->stage_params.decoder.decode_buffer.smd_buf_desc, dsp_base );
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.decoder.encode_buffer), stage->stage_params.decoder.encode_buffer.smd_buf_desc, dsp_base );
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.decoder.mda_buffer), stage->stage_params.decoder.mda_buffer.smd_buf_desc, dsp_base );
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.decoder.fifo_buffer), stage->stage_params.decoder.fifo_buffer.smd_buf_desc, dsp_base );
      }

      if ( stage->task == PSM_TASK_CAPP )
      {  
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.capp.in_buffer), stage->stage_params.capp.in_buffer.smd_buf_desc, dsp_base );
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.capp.out_buffer), stage->stage_params.capp.out_buffer.smd_buf_desc, dsp_base );
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.capp.mda_buffer), stage->stage_params.capp.mda_buffer.smd_buf_desc, dsp_base );
         stage->stage_params.capp.local_storage_remap = dsp_base;
      }


      if ( stage->task == PSM_TASK_PACKETIZE_ENCODED_DATA )
      {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.packetizer.mda_buffer), stage->stage_params.packetizer.mda_buffer.smd_buf_desc, dsp_base );      
      }

      if ( stage->task == PSM_TASK_MIX ) {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.mixer.aux_buffer), stage->stage_params.mixer.aux_buffer.smd_buf_desc, dsp_base );      
      }

      if ( stage->task == PSM_TASK_DOWNMIX ) {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.downmixer.aux_buffer), stage->stage_params.downmixer.aux_buffer.smd_buf_desc, dsp_base );      
      }

      if (stage->task == PSM_TASK_SRC)
      {
         for(i = 0; i < AUDIO_MAX_INPUTS; i++) {
            audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.src.aux_buffer[i]), stage->stage_params.src.aux_buffer[i].smd_buf_desc, dsp_base );      
         }
      }

      if (stage->task == PSM_TASK_SRS){
        for(i = 0; i < AUDIO_SRS_MAX_OUTPUTS; i++) {
            audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.srs.aux_buffer[i]), stage->stage_params.srs.aux_buffer[i].smd_buf_desc, dsp_base );      
        }
      }

      if (stage->task == PSM_TASK_PRESRC)
      {
         for(i = 0; i < stage->inputs_count; i++) {
            audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.src.aux_buffer[i]), stage->stage_params.src.aux_buffer[i].smd_buf_desc, dsp_base );      
         }
      }

      if (stage->task == PSM_TASK_PCM_DECODE)
      {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.pcm_dec.aux_buffer), stage->stage_params.pcm_dec.aux_buffer.smd_buf_desc, dsp_base );      
      }

      if (stage->task == PSM_TASK_PACKETIZE_ENCODED_DATA)
      {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.packetizer.aux_buffer), stage->stage_params.packetizer.aux_buffer.smd_buf_desc, dsp_base );      
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.packetizer.persistant_buffer), stage->stage_params.packetizer.persistant_buffer.smd_buf_desc, dsp_base );      
      }     

      if (stage->task == PSM_TASK_WATERMARK)
      {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.watermark.aux_buffer), stage->stage_params.watermark.aux_buffer.smd_buf_desc, dsp_base );      
      }    

      if (stage->task == PSM_TASK_BM)
      {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.bass_man.aux_buffer), stage->stage_params.bass_man.aux_buffer.smd_buf_desc, dsp_base );      
      }    

      if (stage->task == PSM_TASK_DM)
      {
         for(i = 0; i< AUDIO_MAX_INPUT_CHANNELS; i++)
         {
            audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.delay_mgmt.buf_mgmt[i].aux_buffer), 
               stage->stage_params.delay_mgmt.buf_mgmt[i].aux_buffer.smd_buf_desc, dsp_base );      
            stage->stage_params.delay_mgmt.buf_mgmt[i].start_address = (char *)stage->stage_params.delay_mgmt.buf_mgmt[i].aux_buffer.dsp_phys_address;
            stage->stage_params.delay_mgmt.buf_mgmt[i].end_address = (char *)stage->stage_params.delay_mgmt.buf_mgmt[i].aux_buffer.dsp_phys_address + 
               stage->stage_params.delay_mgmt.buf_mgmt[i].aux_buffer.size;
            stage->stage_params.delay_mgmt.buf_mgmt[i].write_ptr = stage->stage_params.delay_mgmt.buf_mgmt[i].start_address;
            stage->stage_params.delay_mgmt.buf_mgmt[i].read_ptr = stage->stage_params.delay_mgmt.buf_mgmt[i].start_address;
         }
      }
      if (stage->task == PSM_TASK_PER_OUTPUT_DELAY)
      {
         for(i = 0; i< stage->outputs_count; i++)
         {
            int index = stage->conn_mda.output[i];
            audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.per_output_delay.output_params[index].aux_buffer), 
               stage->stage_params.per_output_delay.output_params[index].aux_buffer.smd_buf_desc, dsp_base );      
            stage->stage_params.per_output_delay.output_params[index].start_address = (char *)stage->stage_params.per_output_delay.output_params[index].aux_buffer.dsp_phys_address;
            stage->stage_params.per_output_delay.output_params[index].end_address = (char *)stage->stage_params.per_output_delay.output_params[index].aux_buffer.dsp_phys_address + 
               stage->stage_params.per_output_delay.output_params[index].aux_buffer.size;
            stage->stage_params.per_output_delay.output_params[index].write_ptr = stage->stage_params.per_output_delay.output_params[index].start_address;
            stage->stage_params.per_output_delay.output_params[index].read_ptr = stage->stage_params.per_output_delay.output_params[index].start_address;
         }
      }
      if (stage->task == PSM_TASK_IEC_PARSER) {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.iec_parse.aux_buffer), stage->stage_params.iec_parse.aux_buffer.smd_buf_desc, dsp_base );      
      } 

      if ((stage->task == PSM_TASK_DEINTERLEAVER) && (stage->stage_params.deinterleaver.aux_buffer.smd_buf_desc != NULL)) {
         audio_dsp_pvt_preprocess_psm_buffer( &(stage->stage_params.deinterleaver.aux_buffer), stage->stage_params.deinterleaver.aux_buffer.smd_buf_desc, dsp_base );      
      } 
             
      stage = stage->virt_next; /* increment stage pointer to point to next stage in the pipe */
   }
     
   /* Now set addresses of the input and output jobs queues. */
   for (i=0; i<wl->input_jobs_count; i++)
   {
      /* Need to set dsp_phys addresses. */
      wl->input_jobs[i].dsp_phys_address = (void *)(wl->input_jobs[i].phys_address - 
                                             dsp_base);
      wl->input_jobs[i].dsp_phys_next = (void *)(wl->input_jobs[i].phys_next - 
                                             dsp_base);
   }

   /*For every job in every queue we need to assign DSP phys address*/
   for (q=0; q<PSM_PIPE_MAX_NUM_OUT_QUEUES; q++) {
      if(wl->output_queues->queue[q].in_use) {
         for (i=0; i<PSM_PIPE_JOB_QUEUE_DEPTH; i++) {
      /* Need to set dsp_phys addresses. */
            wl->output_queues->queue[q].jobs[i].dsp_phys_address = (void *)((uint32_t)wl->output_queues->queue[q].jobs[i].phys_address - dsp_base);
            wl->output_queues->queue[q].jobs[i].dsp_phys_next = (void *)((uint32_t)wl->output_queues->queue[q].jobs[i].phys_next - dsp_base);
   }
      }
   }

   ismd_res = ISMD_SUCCESS;

   //exit:
   return ismd_res;

}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* WARNING: Do not set the valid flag in this function. The DSP might pick it up
   as soon as the valid flag is set to false. Hence let the caller do it.
   Also I dont want to reset the pointers in the DSP module. These were set during init
	to form a linked list of input and output jobs. */   
/* --------------------------------------------------------------------------- */
static void audio_dsp_pvt_job_reset ( audio_psm_job_desc_t *job, bool dereference_buf )
{
	uint32_t i;
	
	job->stale_data = 0;
	job->cleanup = 0;
	job->wl_handle = -1;
   
	for (i=0; i<job->buffers_count; i++)
	{
		audio_dsp_pvt_buffer_reset (&(job->buffers[i]), dereference_buf);
      job->buffers[i].in_use = false;
	}

	job->buffers_count = 0;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
static char * audio_dsp_pvt_message_get_name(int message_id)
{
   switch (message_id)
   {
      case AUDIO_DSP_MESSAGE_HTOD_PIPE_ADD:
         return "PIPE_ADD";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_PIPE_REMOVE:
         return "PIPE_REMOVE";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_PIPE_START:
         return "PIPE_START";
         break;
      
      case AUDIO_DSP_MESSAGE_HTOD_PIPE_STOP:
         return "PIPE_STOP";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_CFG_PARAM_SET:
         return "CFG_PARAM_SET";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_CFG_PARAM_GET:
         return "CFG_PARAM_SET";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_INPUT_JOB_AVAILABLE:
         return "INPUT_JOB_AVAILABLE";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_PIPE_CONFIGURE:
         return "PIPE_CONFIGURE";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_CODEC_AVAILABLE:
         return "CODEC_AVAILABLE";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_PIPE_FLUSH:
         return "PIPE_FLUSH";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_GET_CODEC_VER_STRING:
         return "GET_CODEC_VER_STRING";
         break;
         
      case AUDIO_DSP_MESSAGE_HTOD_OUTPUT_JOB_AVAILABLE:
         return "OUTPUT_JOB_AVAILABLE";
         break;
         
      case AUDIO_DSP_MESSAGE_HTOD_BUFFER_AVAILABLE:
         return "BUFFER_AVAILABLE";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_STAGE_CONFIGURE:
         return "STAGE_CONFIGURE";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_INIT_INFO:
         return "INIT_INFO";
         break;
         
      case AUDIO_DSP_MESSAGE_HTOD_ENABLE_SVEN_DEBUG:
         return "SVEN_DEBUG";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_GET_STREAM_INFO:
         return "GET_STREAM_INFO";
         break;

      case AUDIO_DSP_MESSAGE_HTOD_GET_STAGE_PARAMS:
         return "GET_STAGE_PARAMS";
         break;
         
      default:
         return "UNKNOWN MESSAGE";
         break;
   }

}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_dsp_pvt_pipe_flush( audio_dsp_wl_t *wl )
{
	ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_job_desc_t *cur_job = NULL; 
   int i =0;

   /* TODO: We need to STOP the pipe before flushing it. */
   
   /* Need to tell the DSP to stop processing data and flush out decoder */
   if ((ismd_res = audio_dsp_pvt_send_message ( wl, 	AUDIO_DSP_MESSAGE_HTOD_PIPE_FLUSH, 0, true)) != ISMD_SUCCESS)
   {
      AUDIO_ERROR( "Sending 'FLUSH' message to DSP failed.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );			
   }
   else
   {
      /* Now that we have stopped the pipe go through the input and output job queues 
      	and mark jobs that belong to this wl as stale. 
      	TODO: This is more or less a hack. Need to find a better solution. */
      cur_job = wl->cur_in_job;
      do 
      {
      	/* If the input job belongs to this pipe mark it as stale. */
         audio_core_flush_cache(cur_job, sizeof(audio_psm_job_desc_t));
      	if ( cur_job->valid )
      	{                  
      		cur_job->stale_data = true;
      	}
         audio_core_flush_cache(cur_job, sizeof(audio_psm_job_desc_t));
      	cur_job = cur_job->virt_next;		
      }while(cur_job != wl->cur_in_job);


      for(i = 0; i < PSM_PIPE_MAX_NUM_OUT_QUEUES; i++) {

         if(wl->output_queues->queue[i].in_use) {
            cur_job = wl->out_queue_track[i].cur_out_job;
      do 
      {
      	/* If the input job belongs to this pipe mark it as stale. */
         audio_core_flush_cache(cur_job, sizeof(audio_psm_job_desc_t));
      	if (cur_job->valid)
      	{
      		cur_job->stale_data = true;
      		cur_job->cleanup = true;
      	}
         audio_core_flush_cache(cur_job, sizeof(audio_psm_job_desc_t));
               cur_job = cur_job->virt_next;
            }while(cur_job != wl->out_queue_track[i].cur_out_job);
         }
      }

      ismd_res = ISMD_SUCCESS;
   }
//exit:

   /* TODO: Now that we have marked all the jobs in the queue as being stale go ahead
      and start the pipe again. */

	return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static audio_dsp_handle_t audio_dsp_pvt_wl_get_by_fw_handle ( int dsp_num, int fw_handle )
{
	int i=0;

	for (i=0; i<AUDIO_DSP_MAX_WORKLOADS; i++)
	{      
      if ( (dsp_wl[i].in_use) && (dsp_wl[i].dsp_num == (uint32_t)dsp_num) && (dsp_wl[i].fw_handle == fw_handle) )
         return i;
	}

   return -1;
}

static void audio_dsp_pvt_download_fw(int dsp_num)
{
   void *cached_fw_buf = NULL;

   audio_dsp_device_t *dsp_dev = &dsp_device[dsp_num];
   int reg_val = 0;

   /* Cache the entire FW buffer and only memset the region after code. */
   cached_fw_buf = OS_MAP_IO_TO_MEM_CACHE( dsp_dev->kernel_smd_buf_desc->phys.base, dsp_dev->kernel_smd_buf_desc->phys.size );
   if ( cached_fw_buf == NULL ) {
      cached_fw_buf = dsp_dev->kernel_smd_buf_desc->virt.base;
   }
   OS_MEMSET( (void *)((uint32_t)cached_fw_buf + AUDIO_FIRMWARE_SIZE), 0, dsp_dev->kernel_smd_buf_desc->phys.size - AUDIO_FIRMWARE_SIZE);

   /*Store this phy add in X-->D mailbox so that when the DSP comes out of reset it can read it and initialize 
   its internal buffer descriptor pointers to input and output buffer descriptor location in memory */
   audio_dsp_pvt_store_init_to_mailbox(dsp_num);

   /*Copy the DSP FW from the array into the kernel buffer memory. */
   OS_MEMCPY (cached_fw_buf, ((dsp_num == 0) ? audio_fw_kernel_dsp0 : audio_fw_kernel_dsp1), AUDIO_FIRMWARE_SIZE );

   /* Flush the buffer if we have coherant path disabled. Then unmap the cached buffer. */
   if ( cached_fw_buf != dsp_dev->kernel_smd_buf_desc->virt.base ) {

      if (audio_core_fast_path_enabled()) {
         cache_flush_buffer(cached_fw_buf, dsp_dev->kernel_smd_buf_desc->phys.size);
      } 
      OS_UNMAP_IO_FROM_MEM( cached_fw_buf, dsp_dev->kernel_smd_buf_desc->phys.size );
   }

   pal_flush_chipset_cache();

   /*CSR 
     31:25(7) - Reserved
     24:20(5) - Codec_Fuse
     19:18(2) - Reserved
     17:16(2) - Reserved. (Used to be remap size field)
     15:4(12) - Remap.This value is added to addresses coming out on the SAP bus
     3:2(2)   - Reserved
     1(1)     - Reset. (1:Out of reset 0:Reset)
     0(1)     - Reserved
   */	
   reg_val = ( 0x0 ) | ( (dsp_dev->kernel_smd_buf_desc->phys.base & 0xfff00000 ) >> 16 ) | 0x00000002;
   devh_WriteReg32 (dsp_dev->devh, CSR, reg_val );	//take the DSP out of reset

   return;
}

static void audio_dsp_pvt_store_init_to_mailbox(int dsp_num)
{
   audio_dsp_device_t* dsp_dev = dsp_device + dsp_num; 
   audio_htod_mgs_t *mb_ptr = NULL;
   uint32_t reg_val = 0;

   mb_ptr = ( audio_htod_mgs_t * ) (dsp_dev->kernel_smd_buf_desc->virt.base + AUDIO_DSP_H_TO_D_MAILBOX_OFFSET);
   OS_ASSERT ( mb_ptr );

   /* PSM Pool of buffer information to send to the DSP */
   mb_ptr->init_info.psm_bufs = (audio_psm_buf_desc_t *)(dsp_dev->psm_bufs_smd_buf_desc->phys.base - dsp_dev->kernel_smd_buf_desc->phys.base);
   mb_ptr->init_info.psm_bufs_count = dsp_dev->psm_bufs_count;

   /* SVEN register and buffer location global information to send to the DSP */
   audio_init_sven_fw_globals(&mb_ptr->init_info.sven_fw_globals, dsp_dev->kernel_smd_buf_desc->phys.base);
   audio_init_reg_addr(&mb_ptr->init_info.dsp_regs, dsp_dev->kernel_smd_buf_desc->phys.base);

   /* write the ipc register to message AUDIO_DSP_MESSAGE_HTOD_INIT_INFO 
     to send the information about the pool of buffers */
   audio_dsp_pvt_set_dbreg_value(&reg_val, 0, 0, AUDIO_DSP_MESSAGE_HTOD_INIT_INFO, 0);   
   devh_WriteReg32 ( dsp_dev->devh, IPCX, reg_val );

}

static void audio_dsp_pvt_enable_fw_sven(int dsp_num)
{
   int32_t enable_fw_sven_dsp_num = 0xDEAD;
   audio_dsp_device_t* dsp_dev = dsp_device + dsp_num;
   
   /* Ask platform config if we should enable FW sven TX, if we should , tell DSP to allow TX of FW module events. */
   AUDIO_CONFIG_GET_DSP_SVEN_DEBUG_ENABLE(enable_fw_sven_dsp_num);
    if(((uint32_t)enable_fw_sven_dsp_num == (unsigned int)dsp_num) || ((uint32_t)enable_fw_sven_dsp_num == ALL_DSP_FW_SVEN_EVENTS_ENABLED)) {
      
      /* send_message needs to know which DSP number it is, so set it, call, then reset. */
      dsp_wl[0].dsp_num = dsp_num;
      audio_dsp_pvt_send_message ( &dsp_wl[0], (uint8_t) AUDIO_DSP_MESSAGE_HTOD_ENABLE_SVEN_DEBUG, (uint8_t)enable_fw_sven_dsp_num, false);
      dsp_wl[0].dsp_num = 0;

      OS_PRINT("Audio DSP: %d Tx SVEN FW events enabled!\n",  dsp_dev->device_num);
   }
}
/* --------------------------------------------------------------------------- */


#if 0 /* For later use if needed. */
/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static bool audio_dsp_pvt_psm_buf_available(audio_dsp_device_t *dsp_dev)
{
   int i=0; 

   for (i=0; i<dsp_dev->psm_bufs_count; i++)
   {
      if (dsp_dev->psm_bufs[i].in_use == false)
         return true;
   }

   return false;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static bool audio_dsp_pvt_job_queue_full(audio_psm_job_desc_t *job)
{
	/* We need to go through the linked list of input/output jobs to see whether there are any availble. */
   audio_psm_job_desc_t *cur_job = job;
   
	do 
	{
      /* If the job is NOT valid then it is empty and hence the queue is not full. */
		if (!cur_job->valid)
		{
			return false;
		}
		cur_job = cur_job->virt_next;		
	}while(cur_job != job);
	
   return true;   
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static bool audio_dsp_pvt_job_queue_empty(audio_psm_job_desc_t *job)
{
	/* We need to go through the linked list of input/output jobs to see whether there are any availble. */
   audio_psm_job_desc_t *cur_job = job;
   
	do 
	{
      /* If the job is valid then it has valid data in there and hence the queue is not empty. */
		if (cur_job->valid)
		{
			return false;
		}
		cur_job = cur_job->virt_next;		
	}while(cur_job != job);
	
   return true;   
}
/* --------------------------------------------------------------------------- */

#endif

