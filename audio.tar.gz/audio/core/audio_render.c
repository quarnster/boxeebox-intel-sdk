
/*
* File Name: audio_render.c
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "audio_render.h"
#include "audio_render_pvt.h"
#include "audio_apm_common.h"

static ismd_audio_render_context_t render_context[AUDIO_MAX_RENDER_DEVICES];
static bool render_initialized = false;

os_irqlock_t render_irq_lock;

/** Dereference a buffer as long as it's not the silence buffer */
static inline ismd_result_t
audio_pvt_render_dereference_buffer_safe(ismd_audio_render_context_t *wl, int buffer_id){
   ismd_result_t result = ISMD_SUCCESS;

   if(wl->silence_buffer == NULL || buffer_id != wl->silence_buffer->unique_id){
      result = ismd_audio_buffer_dereference(buffer_id);
   }
   
   return result;
}

ismd_result_t
audio_render_initialize(void)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_t handle;
   int invert_i2s0_bit_clk = true; //Defualt values for bitclock inversion
   int invert_i2s1_bit_clk = true;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if(!render_initialized){

      /*Initialize workload memory.*/
      OS_MEMSET(render_context, 0, sizeof(render_context));

      result = ISMD_SUCCESS;
      /*Initialze device variables.*/
      for(handle = 0; handle < AUDIO_MAX_RENDER_DEVICES; handle++){

         audio_pvt_render_init_wl(&(render_context[handle]));

         /*Init semaphores*/
         if(os_mutex_init(&(render_context[handle].lock)) != OSAL_SUCCESS){

           result = ISMD_ERROR_OPERATION_FAILED;
            AUDIO_ERROR("Semaphore init failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }
      }
      if(result == ISMD_SUCCESS){

         /* Check platform config for output bit clock inversions, just warn if fails, not a fatal error*/
         AUDIO_CONFIG_GET_I2S0_BIT_CLK_INVERT(invert_i2s0_bit_clk);
         if(audio_hal_render_i2s_set_clk_invert_direct(audio_devh[AUDIO_DEBUG_RENDER], AUDIO_HAL_OUT_SEL_I2S0, invert_i2s0_bit_clk) != ISMD_SUCCESS){

            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "audio_hal_render_i2s_set_clk_invert failed!", audio_devh[AUDIO_DEBUG_RENDER]);
         }

         AUDIO_CONFIG_GET_I2S1_BIT_CLK_INVERT(invert_i2s1_bit_clk);
         if(audio_hal_render_i2s_set_clk_invert_direct(audio_devh[AUDIO_DEBUG_RENDER], AUDIO_HAL_OUT_SEL_I2S1, invert_i2s1_bit_clk) != ISMD_SUCCESS){

            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "audio_hal_render_i2s_set_clk_invert failed!", audio_devh[AUDIO_DEBUG_RENDER]);
         }

         /*Init the irqlock for the render, needed to disable interrupts for ATOMIC operations.*/
         os_irqlock_init(&render_irq_lock);

         render_initialized = true;
      }
   }
   else {
      result = ISMD_ERROR_ALREADY_INITIALIZED;
      AUDIO_ERROR("Already initialized!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

ismd_result_t
audio_render_deinitialize(void)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_t handle;

   if(render_initialized){

      /*deinitialze semaphores.*/
      for(handle = 0; handle < AUDIO_MAX_RENDER_DEVICES; handle++){

         os_mutex_destroy(&(render_context[handle].lock));
      }

      os_irqlock_destroy(&render_irq_lock);
      
      render_initialized = false;
      result = ISMD_SUCCESS;
   }
   else {
      result = ISMD_ERROR_OPERATION_FAILED;
      AUDIO_ERROR("Render not initialized!\n", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }
   return result;
}


ismd_result_t
audio_render_get_samples_rendered_by_id(int hw_id, uint64_t *samples_rendered)
{
   int handle = 0;
   ismd_result_t result = ISMD_ERROR_NO_DATA_AVAILABLE;
   ismd_audio_render_context_t *wl = NULL;
   os_irqlock_local_t irqlocal;

   /* Need to get this information with out locking to not stall the ATC. */
   os_irqlock_acquire(&render_irq_lock, &irqlocal);
   for (handle = 0; handle  < AUDIO_MAX_RENDER_DEVICES; handle ++) {

      wl = &(render_context[handle]);
      if((wl->hw_dev_id == hw_id) && wl->in_use && wl->render_hw_started && (wl->state == ISMD_DEV_STATE_PLAY)) {
         *samples_rendered = wl->samples_rendered;
         result = ISMD_SUCCESS;
         break;
      }
   }
   os_irqlock_release(&render_irq_lock, &irqlocal);
   
   return result;
}


ismd_result_t
audio_render_get_current_status(int association_id, unsigned int *prefill_samples, uint64_t *samples_rendered)
{
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;
   ismd_audio_render_context_t *wl = NULL;
   os_irqlock_local_t irqlocal;
   int handle = 0;
   unsigned int sample_size = 0;
   unsigned int sample_rate = 0;
   unsigned int ch_count = 0;
   unsigned int prefill_bytes_max = 0;

   /*NOTE: This operation needs to be atomic. The ATC makes a call to this function
    to determine where the render is at any given time. There are instances where
    the ATC is running and calls this function but the render could be shutting down. 
    In that case it would get stuck if we tried to lock the render devices for up to
    40ms waiting for the render to drain. This is a very cheap operation and breaks
    as soon as it finds the active render.*/

   os_irqlock_acquire(&render_irq_lock, &irqlocal);
   for (handle = 0; handle  < AUDIO_MAX_RENDER_DEVICES; handle ++) {

      wl = &(render_context[handle]);
      if(wl->in_use && (wl->processor_id == association_id)) {         

         //If someone removes an output and starts to add it back while
         //the pipe is running there is a chance we get swapped out by the 
         //OS before the render is completely started. In that case we 
         //do not want to return this as an active configuaration. Also to ensure
         //we dont get numbers from a render shutting down, ensure its in a playing
         //state, that way the ATC doesnt think it should send out more data.
         if(wl->render_hw_started && (wl->state == ISMD_DEV_STATE_PLAY)) {

            /* Fill out our base numbers, and break out of the for loop */
            *samples_rendered = wl->samples_rendered;

            /*Get number needed for prefill sample calculation */
            sample_size = wl->sample_size;
            sample_rate = wl->sample_rate;
            ch_count = wl->ch_count;
            prefill_bytes_max = wl->prefill_bytes_max;
            
            result = ISMD_SUCCESS;
            break;
         }
      }  
   }
   os_irqlock_release(&render_irq_lock, &irqlocal);

   /*Doing this calculation outside the IRQ lock to minimize time in the cirtical region.*/
   if(result == ISMD_SUCCESS){
      *prefill_samples = audio_core_normalize_sample_count(
         ((uint64_t)audio_core_bytes_to_samples( sample_size, ch_count, prefill_bytes_max)), AUDIO_NORMAL_SAMPLE_RATE, sample_rate);
   }
   
   return result;
}


ismd_result_t
audio_render_set_clock_handle(ismd_clock_t *clock_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_render_context_t *wl = NULL;
   int handle = 0;
      
   for (handle = 0; handle  < AUDIO_MAX_RENDER_DEVICES; handle ++) {

      wl = &(render_context[handle]);

      if(wl->in_use) {
         
         wl->clock_h = clock_h;
      }
   }

   return result;
}

ismd_result_t
audio_render_set_base_time(ismd_time_t base_time)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_render_context_t *wl = NULL;
   int handle = 0;
      
   for (handle = 0; handle  < AUDIO_MAX_RENDER_DEVICES; handle ++) {

      wl = &(render_context[handle]);

      if(wl->in_use) {
         
         wl->smd_base_time = base_time;
      }
   }

   return result;
}

ismd_result_t
audio_render_set_sync_clock(ismd_audio_clk_mode_t clk_mode, clock_sync_t clock_sync_h, audio_independent_clock_recovery_mode_t clock_recovery_mode)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_render_context_t *wl = NULL;
   int handle = 0;
   bool set_sync_clock = false;
   ismd_clock_t *clock_h_ptr = NULL;
   os_irqlock_local_t irqlocal;

   if(clock_recovery_mode == AUDIO_INDEPENDENT_CLOCK_RECOVERY_MODE_PHASE_ADJUST){
      return result;
   }

   /*   The sync handle is used when the render buffer is done in the BH so need to update this variable atomically. 
            The semaphore lock is not use by the BH callback function so use the irqlock */
   
   os_irqlock_acquire(&render_irq_lock, &irqlocal);
      
   for (handle = 0; handle  < AUDIO_MAX_RENDER_DEVICES; handle ++) {

      wl = &(render_context[handle]);
      
      if(clk_mode == ISMD_AUDIO_CLK_INDEPENDENT){
         wl->clock_sync_h = clock_sync_h;
         if((wl->heartbeat_timer_clock_h_ptr != NULL) && (*(wl->heartbeat_timer_clock_h_ptr) != ISMD_CLOCK_HANDLE_INVALID)){
            set_sync_clock = true;
            clock_h_ptr = wl->heartbeat_timer_clock_h_ptr;
         }
      }
      else {
         wl->clock_sync_h = ISMD_DEV_HANDLE_INVALID;          
      }
   }
   os_irqlock_release(&render_irq_lock, &irqlocal);

   if((set_sync_clock) && (clock_sync_h != ISMD_DEV_HANDLE_INVALID)){
      if((result =  ismd_clock_sync_reset(clock_sync_h)) != ISMD_SUCCESS){
         AUDIO_ERROR("ismd_clock_sync_reset failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }
      else if((result = ismd_clock_sync_set_clock(clock_sync_h, *clock_h_ptr)) != ISMD_SUCCESS){
         AUDIO_ERROR("ismd_clock_sync_set_clock failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }
   }

   return result;
}

void
audio_render_get_time(ismd_audio_render_context_t *wl)
{
      
   if((wl->heartbeat_timer_clock_h_ptr != NULL) && (*(wl->heartbeat_timer_clock_h_ptr) != ISMD_CLOCK_HANDLE_INVALID)){
      if((ismd_clock_get_time_th_safe(*(wl->heartbeat_timer_clock_h_ptr), &wl->render_time)) != ISMD_SUCCESS) {
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "audio_render_get_time: ismd_clock_get_time_th_safe failed!", audio_devh[AUDIO_DEBUG_CAPTURE]);
      }
   }         

}

ismd_result_t
audio_render_set_heartbeat_timer_clock_handle(ismd_clock_t *clock_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_render_context_t *wl = NULL;
   int handle = 0;
   os_irqlock_local_t irqlocal;
   bool reset_sync_clock = false;
   clock_sync_t clock_sync_h = ISMD_DEV_HANDLE_INVALID;
   ismd_clock_info_t heartbeat_timer_clock_info;

   
   if((result = ismd_clock_get_info(*clock_h, &heartbeat_timer_clock_info)) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_clock_get_info for heartbeat timer clock failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   if(heartbeat_timer_clock_info.type == ISMD_CLOCK_TYPE_SW_CONTROLLED){
      os_irqlock_acquire(&render_irq_lock, &irqlocal);
         
      for (handle = 0; handle  < AUDIO_MAX_RENDER_DEVICES; handle ++) {
         
         wl = &(render_context[handle]);
         // check if changed then only update. Also need to reset the sync clock  
         if((wl->heartbeat_timer_clock_h_ptr == NULL) || (wl->heartbeat_timer_clock_h != *clock_h)){
            wl->heartbeat_timer_clock_h_ptr = clock_h;
            wl->heartbeat_timer_clock_h = *clock_h;
            if((ismd_clock_get_time_th_safe(wl->heartbeat_timer_clock_h, &wl->render_time)) != ISMD_SUCCESS) {
               AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "audio_render: ismd_clock_get_time_th_safe failed!", audio_devh[AUDIO_DEBUG_CAPTURE]);
            }
            reset_sync_clock = true;
            clock_sync_h = wl->clock_sync_h;
         }         

      }
      os_irqlock_release(&render_irq_lock, &irqlocal);

      if((reset_sync_clock) && (clock_sync_h != ISMD_DEV_HANDLE_INVALID)){
         if((result =  ismd_clock_sync_reset(clock_sync_h)) != ISMD_SUCCESS){
            AUDIO_ERROR("ismd_clock_sync_reset failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }
         else if((result = ismd_clock_sync_set_clock(clock_sync_h, *clock_h)) != ISMD_SUCCESS){
            AUDIO_ERROR("ismd_clock_sync_set_clock failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }
      }
   }
   return result;
}

ismd_result_t
audio_render_open(ismd_audio_render_t *render_h, int hw_dev_id, ismd_queue_handle_t input_queue, audio_render_buffer_mode_t buffer_mode, int association_id)
{
   int dev_index;
   gdl_ret_t gdl_result = GDL_SUCCESS;
   osal_result os_result = OSAL_ERROR;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   /*Validate incoming params*/
   if((buffer_mode == ISMD_AUDIO_RENDER_BUFFER_MODE_CIRCULAR ||
        buffer_mode == ISMD_AUDIO_RENDER_BUFFER_MODE_LINKED_LIST)){

      if(input_queue != ISMD_QUEUE_HANDLE_INVALID){

         result = ISMD_ERROR_NO_RESOURCES;

         /*Check to see if the device is available, and assign the handle.*/
         for (dev_index = 0; dev_index  < AUDIO_MAX_RENDER_DEVICES; dev_index ++) {

            wl = &(render_context[dev_index ]);

            /*If device in use and equals hw id requested, return error*/
            if (wl->in_use && (hw_dev_id == wl->hw_dev_id)){

               result = ISMD_ERROR_NO_RESOURCES;
               dev_index = AUDIO_MAX_RENDER_DEVICES;
            }
            else {
               if(!wl->in_use){

                  result = ISMD_SUCCESS;
                  *render_h  = dev_index;
                  wl->processor_id = association_id;
                  dev_index = AUDIO_MAX_RENDER_DEVICES;
               }
            }
         }

         /*If the handle is still invalid, all devices are in use.*/
         if(result == ISMD_SUCCESS && ((result = audio_pvt_render_valid_hw_id(wl,  hw_dev_id)) == ISMD_SUCCESS)){

            /*Fill out workload variables*/
            wl->in_use = true;
            wl->hw_dev_id = hw_dev_id;
            wl->buffer_mode = buffer_mode;
            wl->input_queue = input_queue;
            wl->hal_render_h.user_context = (void *)wl;

            if((os_result = os_event_create(&(wl->safe_to_close_event), false)) != OSAL_SUCCESS){
               AUDIO_OSAL_ERROR("os_event_create failed ", result, audio_devh[AUDIO_DEBUG_RENDER]);
            }

            if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI){

               /* Buffer mode setup */
               if(wl->buffer_mode == ISMD_AUDIO_RENDER_BUFFER_MODE_CIRCULAR) {

                  if((result = audio_pvt_render_setup_circular_buffer_mode(wl)) != ISMD_SUCCESS){
                     AUDIO_ERROR("render_setup_circular_buffer_mode failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
                  }
               }

               else if(wl->buffer_mode == ISMD_AUDIO_RENDER_BUFFER_MODE_LINKED_LIST){

                   if((result = audio_pvt_render_setup_linked_list_mode(wl)) != ISMD_SUCCESS){
                     AUDIO_ERROR("render_setup_linked_list_mode failed!\n", result, audio_devh[AUDIO_DEBUG_RENDER]);
                   }
               }
            }

            /* HDMI AUDIO */
            else {

               /*Create a queue to keep track of buffers that HDMI might not clean up */
               if((result = ismd_queue_alloc(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, BUFFER_TRACKING_QUEUE_DEPTH, &wl->hdmi_wl.buffer_tracking_queue)) != ISMD_SUCCESS) {
                  AUDIO_ERROR( "ismd_queue_alloc failed for hdmi buffer tracking queue!", result, audio_devh[AUDIO_DEBUG_RENDER] );
               }
               
               else if ( (os_result = os_event_create ( &(wl->hdmi_wl.stop_event), 0 )) != OSAL_SUCCESS ) {
                  AUDIO_OSAL_ERROR( "os_event_create failed for HDMI stop event!", result, audio_devh[AUDIO_DEBUG_RENDER] );
               }

               else if((gdl_result = abd_open(GDL_HDMI_AUDIO_ID_0, &(wl->hdmi_wl.hdmi_audio_h))) != GDL_SUCCESS) {

                  result = ISMD_ERROR_NO_RESOURCES;
                  AUDIO_GDL_ERROR("abd_open failed!", gdl_result, audio_devh[AUDIO_DEBUG_RENDER]);
               }
               else {
                  result = ISMD_SUCCESS;
               }
            }

            if(result == ISMD_SUCCESS) {

               //Allocate the silence buffer.
               if((result = ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS, (64*1024), &(wl->silence_buffer))) != ISMD_SUCCESS) {

                  AUDIO_ERROR("silence buffer_alloc_typed_direct failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
               }
               else {
                  //Initialize silence buffer metadata. 
                  audio_core_reset_buffer_metadata((audio_buffer_attr_t*) &(wl->silence_buffer->attributes));
               }
            }

         }
         else {

            result = ISMD_ERROR_NO_RESOURCES;
            AUDIO_ERROR("Could not get a handle!", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }
      }
      else {

         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Queue handle invalid!", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }
   }
   else {

      result = ISMD_ERROR_INVALID_PARAMETER;
      AUDIO_ERROR("Buffer mode invalid!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

ismd_result_t
audio_render_close(ismd_audio_render_t render_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   gdl_ret_t gdl_result = GDL_ERR_FAILED;
   ismd_audio_render_context_t *wl = NULL;
   ismd_buffer_descriptor_t* buffer_tracking_descr = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      
      /*Signal shutdown.*/
      wl->start_to_close = true;

      if(wl->hw_output_interface == AUDIO_RENDER_INTERFACE_HDMI){

         /* Doing a stop on ABD. Only do a sync stop if a previous call to stop has succeeded 
            and we already waited on the safe to close event. Otherwise do an async stop and 
            then we need to wait for HDMI render safe to close event (HW shutdown). */
         if((gdl_result = audio_pvt_render_hdmi_stop( wl->hdmi_wl.hdmi_audio_h, &wl->hdmi_wl.stop_event, !wl->render_hw_started) ) != GDL_SUCCESS) {
            result = ISMD_ERROR_INVALID_REQUEST;
         }

         /** Try to close the render.  If it fails, reset abd and keep trying. */
         while((gdl_result = abd_close(wl->hdmi_wl.hdmi_audio_h)) != GDL_SUCCESS) {
            
            AUDIO_GDL_ERROR("abd_close failed!", gdl_result, audio_devh[AUDIO_DEBUG_RENDER]);
         
            os_sleep(AUDIO_CHUNK_TIME_PERIOD_MS);
            
            /** If abd_close() failed, call abd_reset() to get abd into the right state so we can attempt abd_close() again */
            while( abd_reset(wl->hdmi_wl.hdmi_audio_h) != GDL_SUCCESS ){
               
               AUDIO_GDL_ERROR("abd_reset failed!", gdl_result, audio_devh[AUDIO_DEBUG_RENDER]);
               
               os_sleep(AUDIO_CHUNK_TIME_PERIOD_MS);
            }
         }

         
         if ( os_event_destroy ( &(wl->hdmi_wl.stop_event)) != OSAL_SUCCESS ) {
            AUDIO_ERROR( "os_event_destroy failed for HDMI stop event!", ISMD_ERROR_OPERATION_FAILED, audio_devh[AUDIO_DEBUG_RENDER] );
         }

         // In case we missed HDMI_STOP event before we free the buffer_tracking_queue. 
         // Release all buffers here, because there maybe no HDMI_STOP event comes.
         while((ismd_queue_dequeue(wl->hdmi_wl.buffer_tracking_queue, &buffer_tracking_descr)) == ISMD_SUCCESS) {
            audio_pvt_render_dereference_buffer_safe(wl, buffer_tracking_descr->unique_id);         
         }
         
         /** Try to free the tracking queue.  If it's already freed, it's not a fatal error, we are trying to close this render anyway. */
         result = ismd_queue_free(wl->hdmi_wl.buffer_tracking_queue);
         if( result != ISMD_SUCCESS && result != ISMD_ERROR_INVALID_HANDLE ) {
            AUDIO_ERROR( "ismd_queue_free failed for hdmi buffer tracking queue!", result, audio_devh[AUDIO_DEBUG_RENDER] );
         }
         else{
            result = ISMD_SUCCESS;
         }

      }
      else{
         if(wl->render_hw_started) {
            result = audio_pvt_render_stop_hw( wl, false ); 
         }
      }

      if(os_event_destroy(&(wl->safe_to_close_event))!= OSAL_SUCCESS){
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "os_event_destroy failed in render_close", audio_devh[AUDIO_DEBUG_RENDER]);
      }

      audio_hal_render_deinit_context(&(wl->hal_render_h));
         
      if(wl->dma_buffer_des != NULL){
         ismd_audio_buffer_dereference(wl->dma_buffer_des->unique_id);
      }     

      /* Deref remaining cubby and output buffers */
      if(wl->output_buffer != NULL){
         audio_pvt_render_dereference_buffer_safe(wl, wl->output_buffer->unique_id);      
      }

      if(wl->cubby_buffer != NULL){
         ismd_audio_buffer_dereference(wl->cubby_buffer->unique_id);
      }

      //Dereference the silence buffer
      ismd_audio_buffer_dereference(wl->silence_buffer->unique_id);

      /*Reset the workload.*/
      audio_pvt_render_init_wl(wl);

      audio_pvt_render_unlock(wl);
   }
   else {

      AUDIO_ERROR("render_validate_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

void
audio_render_enable_clk_recovery(ismd_audio_render_context_t *wl)
{
   ismd_audio_render_context_t *local_wl = NULL;
   os_irqlock_local_t irqlocal;
   int handle = 0;
   bool enable_clk_recovery = true;
   bool only_hdmi_enabled = false;
   int hdmi_handle = 0;
   bool sync_reset = false;

   os_irqlock_acquire(&render_irq_lock, &irqlocal);

   if(wl->state == ISMD_DEV_STATE_PLAY) {
   //  when set to play if this is the only render then do recovery with this
   //  when set to play if this is not the 1st render to be set to play and render which is doing 
   //  clock recovery is HDMI then change the render which will do recovery to this render
      for (handle = 0; handle  < AUDIO_MAX_RENDER_DEVICES; handle ++) {

         local_wl = &(render_context[handle]);
         if(local_wl->in_use && (local_wl->state == ISMD_DEV_STATE_PLAY)) {         
            if(local_wl->do_heartbeat_timer_clock_recovery){
               if(local_wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI){               
                  enable_clk_recovery = false;
               }
               else if(local_wl->hw_output_interface == AUDIO_RENDER_INTERFACE_HDMI) {
                  local_wl->do_heartbeat_timer_clock_recovery = false; 
                  sync_reset = true;
               }
               break;
            }
         }  
      }

      wl->do_heartbeat_timer_clock_recovery = enable_clk_recovery;
   }
   else if(wl->state != ISMD_DEV_STATE_INVALID){
   //	when set to stop/pause then if that render is doing clock recovery then check which all 
   //  render are in play state, change it to other render which is in play state and preferably
   //  not the HDMI      
      if(wl->do_heartbeat_timer_clock_recovery){
         for (handle = 0; handle  < AUDIO_MAX_RENDER_DEVICES; handle ++) {
         
            local_wl = &(render_context[handle]);
            if(local_wl->in_use && (local_wl->state == ISMD_DEV_STATE_PLAY)) {
               sync_reset = true;
               if(local_wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI){               
                  local_wl->do_heartbeat_timer_clock_recovery = true;
                  only_hdmi_enabled = false;
                  break;
               }
               else if(local_wl->hw_output_interface == AUDIO_RENDER_INTERFACE_HDMI) {
                  only_hdmi_enabled = true;
                  hdmi_handle = handle;
               }
            }  
         }

         if(only_hdmi_enabled) {
            render_context[hdmi_handle].do_heartbeat_timer_clock_recovery = true;
         }
         wl->do_heartbeat_timer_clock_recovery = false;
      }
   }

   os_irqlock_release(&render_irq_lock, &irqlocal);

   if(sync_reset){
      ismd_clock_sync_reset(wl->clock_sync_h);
   }
   
}

ismd_result_t
audio_render_set_state(ismd_audio_render_t render_h, ismd_dev_state_t state)
{
   ismd_result_t result = ISMD_ERROR_INVALID_REQUEST;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){
      /* If we are already in the requested state return success */
      if(wl->state == state) {
         
         result = ISMD_SUCCESS;
      }
      else {

         //Make sure to keep this updated here.
         wl->state = state;

         if(wl->clock_sync_h != ISMD_DEV_HANDLE_INVALID){ 
            audio_render_enable_clk_recovery(wl);
         }

         if(wl->hw_output_interface == AUDIO_RENDER_INTERFACE_HDMI) {

            result = audio_pvt_render_hdmi_set_state(wl, state);
         }
         else {

            switch(state){
               case ISMD_DEV_STATE_PAUSE:
                  
                  result = audio_pvt_render_stop_hw( wl, true );
                  
                  break;
               case ISMD_DEV_STATE_STOP:

                  result = audio_pvt_render_stop_hw( wl, false );
                  
                  break;

               case ISMD_DEV_STATE_PLAY:

                  result = ISMD_SUCCESS;

                  if((result = audio_pvt_render_adjust_output_based_on_fmt( wl )) == ISMD_SUCCESS) {

                      //Make sure to re-calculate the buffer pre-fill time.
                     audio_pvt_render_set_buffer_prefill_time( wl, wl->prefill_milliseconds);

                     //We have all the data to get the chunk size, set the silence buffer appropriately and start render. 
                     wl->chunk_size_bytes = audio_core_calc_chunk_size(wl->sample_size, wl->sample_rate, wl->ch_count, AUDIO_CORE_GET_CHUNK_PERIOD(wl));
                     wl->chunk_size_samples = audio_core_bytes_to_samples(wl->sample_size, wl->ch_count, wl->chunk_size_bytes); 
                     wl->silence_buffer->phys.level = wl->chunk_size_bytes;
                     wl->chunk_size_ticks = audio_core_chunk_size_ticks(wl->chunk_size_bytes, wl->sample_rate, wl->sample_size, wl->ch_count);
                     audio_render_get_time(wl);

                     //Call down to build the silence/data burst buffer now that we know the format.
                     audio_pvt_render_build_silence_buffer( wl->silence_buffer, wl->silence_buffer->phys.level, wl->data_format);

                     //Check all the renders for a base sample count if they are running.
                     wl->samples_rendered = audio_pvt_render_get_base_sample_count();

                     //If this context is SPDIF set the channel status info before we start since we 
                     //have all information we need that is updated here (ie sample rate). 
                     audio_pvt_render_iec60958_set_channel_status(wl);

                     //Flush the input queue right before we start in case we have left over buffers from a reconfig.
                     ismd_queue_flush(wl->input_queue);
                     //Need to call the callback to start the DMA's engine. 
                     audio_pvt_render_buffer_callback((void *) wl, 0, AUDIO_RENDER_BUFFER_EMPTY); 
                  }
              
                  break;

               case ISMD_DEV_STATE_INVALID:
               default:

                  result = ISMD_ERROR_INVALID_PARAMETER;
                  AUDIO_ERROR("State set to INVALID in render_set_state.\n", result, audio_devh[AUDIO_DEBUG_RENDER]);

                  break;
            }
         }
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("render_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

ismd_result_t
audio_render_get_state(ismd_audio_render_t render_h, ismd_dev_state_t *state)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
    ismd_audio_render_context_t *wl = NULL;

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      *state = wl->state;

      audio_pvt_render_unlock(wl);
   }
   else{
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   return result;
}


ismd_result_t
audio_render_set_timed_mode(ismd_audio_render_t render_h, bool use_time_stamps)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      wl->use_time_stamps = use_time_stamps;

      audio_pvt_render_unlock(wl);
   }
   else{
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);
   return result;
}


ismd_result_t
audio_render_flush(ismd_audio_render_t render_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      if((result = audio_hal_render_flush(&(wl->hal_render_h), false)) != ISMD_SUCCESS){
         AUDIO_ERROR("audio_hal_render_flush failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);
   return result;
}

ismd_result_t
audio_render_disable(ismd_audio_render_t render_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      wl->disabled = true;

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);
   return result;
}

ismd_result_t
audio_render_enable(ismd_audio_render_t render_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      wl->disabled = false;

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);
   return result;
}


ismd_result_t
audio_render_set_buffer_prefill_time(ismd_audio_render_t render_h, unsigned int milliseconds)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   //This needs to be removed, just put here for extreme cases.
   if((milliseconds > 500) || (milliseconds < 5)){
      milliseconds = 75;
   }

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS) {

      audio_pvt_render_set_buffer_prefill_time( wl, milliseconds);

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

//Set whether or not its PCM data we are processing
ismd_result_t
audio_render_set_data_format(ismd_audio_render_t render_h, ismd_audio_format_t data_format)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_render_context_t *wl = NULL;
   bool set_valid_bit = false;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      switch(data_format){

         case ISMD_AUDIO_MEDIA_FMT_PCM:
         case ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM:
         case ISMD_AUDIO_MEDIA_FMT_DVD_PCM:
            data_format = ISMD_AUDIO_MEDIA_FMT_PCM;
            break;
            
         case ISMD_AUDIO_MEDIA_FMT_DD:
         case ISMD_AUDIO_MEDIA_FMT_DTS: 
         case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:    
         case ISMD_AUDIO_MEDIA_FMT_TRUE_HD:           
         case ISMD_AUDIO_MEDIA_FMT_DTS_HD:
         case ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA:      
         case ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA:  
         case ISMD_AUDIO_MEDIA_FMT_AAC:
         case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS: 
            break;
            
         case ISMD_AUDIO_MEDIA_FMT_WM9:
         case ISMD_AUDIO_MEDIA_FMT_DTS_LBR:
         case ISMD_AUDIO_MEDIA_FMT_MPEG:           
            result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
            break;
            
         case ISMD_AUDIO_MEDIA_FMT_INVALID: 
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }

      if( result == ISMD_SUCCESS ) {
         
         wl->data_format = data_format;

         /*If this is SPDIF, ensure the validity bit is correct.*/
         if(wl->hw_output_interface == AUDIO_RENDER_INTERFACE_SPDIF){
            
            /*Set validity bit per IEC 60958 it is noted that for applications not using a linear PCM coding the bit may be set
               to "1", in which case it can prevent accidental decoding of non-audio data to analogue before a
               complete channel status block is recieved. If its PCM we will clear the bit, if its encoded we will set the bit. */
            if(data_format == ISMD_AUDIO_MEDIA_FMT_PCM) {
               wl->ch_status.is_pcm = true;
               set_valid_bit = false;
            }
            else {
               wl->ch_status.is_pcm = false;
               set_valid_bit = true;
            }

            /*Set the validity bit now that we know the format. */
            if((result = audio_hal_render_spdif_set_validity_bit(&(wl->hal_render_h), set_valid_bit)) != ISMD_SUCCESS){
                  AUDIO_ERROR("audio_hal_render_spdif_set_validity_bit failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
            }
         }
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}


ismd_result_t
audio_render_set_ext_bit_clock_div(ismd_audio_render_t render_h, int div_val)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI) {
         if((result = audio_hal_render_set_bit_clock_divider(&(wl->hal_render_h), div_val)) != ISMD_SUCCESS){
            AUDIO_ERROR("render_set_bit_clock_divider failed in render_set_ext_bit_clock_div!\n", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

ismd_result_t
audio_render_set_channel_config(ismd_audio_render_t render_h, ismd_audio_channel_config_t ch_config)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;
   audio_hal_data_storage_mode_t hal_storage_mode = AUDIO_HAL_DATA_STORAGE_MODE_STEREO;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      switch(ch_config) {

         case ISMD_AUDIO_DUAL_MONO:

            wl->ch_config = ch_config;
            hal_storage_mode = AUDIO_HAL_DATA_STORAGE_MODE_STEREO;
            wl->hdmi_wl.speaker_map = GDL_HDMI_AUDIO_SPEAKER_MAP_FLFR;

               wl->ch_count = 2;
               wl->hdmi_wl.num_channels = 2;

            break;
         case ISMD_AUDIO_STEREO:

            wl->ch_config = ch_config;
            hal_storage_mode = AUDIO_HAL_DATA_STORAGE_MODE_STEREO;
            wl->hdmi_wl.speaker_map = GDL_HDMI_AUDIO_SPEAKER_MAP_FLFR;

               wl->ch_count = 2;
               wl->hdmi_wl.num_channels = 2;

            break;
         case ISMD_AUDIO_5_1:

            wl->ch_config = ch_config;
            hal_storage_mode = AUDIO_HAL_DATA_STORAGE_MODE_7_1;
            wl->hdmi_wl.speaker_map = GDL_HDMI_AUDIO_SPEAKER_MAP_FLFR |
                                      GDL_HDMI_AUDIO_SPEAKER_MAP_LFE  |
                                      GDL_HDMI_AUDIO_SPEAKER_MAP_FC   |
                                      GDL_HDMI_AUDIO_SPEAKER_MAP_RLRR ;

               wl->ch_count = 6;
               wl->hdmi_wl.num_channels = 6;

            break;
         case ISMD_AUDIO_7_1:

            wl->ch_config = ch_config;
            hal_storage_mode = AUDIO_HAL_DATA_STORAGE_MODE_7_1;
            wl->hdmi_wl.speaker_map = GDL_HDMI_AUDIO_SPEAKER_MAP_FLFR |
                                      GDL_HDMI_AUDIO_SPEAKER_MAP_LFE  |
                                      GDL_HDMI_AUDIO_SPEAKER_MAP_FC   |
                                      GDL_HDMI_AUDIO_SPEAKER_MAP_RLRR |
                                      GDL_HDMI_AUDIO_SPEAKER_MAP_RLCRRC ;
            
               wl->ch_count = 8;
               wl->hdmi_wl.num_channels = 8;

            break;
         default:

            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("invalid ch_config!", result, audio_devh[AUDIO_DEBUG_RENDER]);

            break;
      }

      if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI){

         if((result = audio_hal_render_set_channel_configuration(&(wl->hal_render_h), hal_storage_mode)) != ISMD_SUCCESS){

            AUDIO_ERROR("render_set_channel_configuration failed in render_set_channel_config!\n", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }

         //If we have 6 channels disable the last pin. probably need to think this over, but should be ok for now.
         if(wl->ch_count == 6){

            if((result = audio_hal_render_i2s_set_pin(&(wl->hal_render_h), AUDIO_I2S_PIN3, false)) != ISMD_SUCCESS){

               AUDIO_ERROR("audio_hal_render_i2s_set_pin failed!\n", result, audio_devh[AUDIO_DEBUG_RENDER]);
            }

         }
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }
   //audio_hal_render_spdif_set_validity_bit(&(wl->hal_render_h), true);

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

ismd_result_t
audio_render_set_sample_size(ismd_audio_render_t render_h, int sample_size)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;
   audio_hal_sample_size_t hal_sample_size;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      switch(sample_size) {
         case 8:
         case 16:
            hal_sample_size = AUDIO_HAL_SAMPLE_SIZE_16BIT;
            wl->sample_size = 16;
            wl->hdmi_wl.sample_size = GDL_HDMI_AUDIO_SS_16;

            //HDMI always needs samples in 32bit width.
            if(wl->hw_dev_id == GEN3_HW_OUTPUT_HDMI) {
               wl->sample_size = 32;
            }
            break;
         case 20:
            hal_sample_size = AUDIO_HAL_SAMPLE_SIZE_24BIT;
            wl->sample_size = 32;//32 because render output only supports 32b or 16b
            wl->hdmi_wl.sample_size = GDL_HDMI_AUDIO_SS_20;
            break;
         case 24:
            hal_sample_size = AUDIO_HAL_SAMPLE_SIZE_24BIT;
            wl->sample_size = 32;//32 because render output only supports 32b or 16b
            wl->hdmi_wl.sample_size = GDL_HDMI_AUDIO_SS_24;
            break;
         case 32:
            hal_sample_size = AUDIO_HAL_SAMPLE_SIZE_24BIT;
            wl->sample_size = 32;
            wl->hdmi_wl.sample_size = GDL_HDMI_AUDIO_SS_24;
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }

      if(result == ISMD_SUCCESS) {

         /* Force 16bit if interface will be getting spdif packetized. */
         if(((wl->hw_output_interface == AUDIO_RENDER_INTERFACE_SPDIF ) || (wl->hw_output_interface == AUDIO_RENDER_INTERFACE_HDMI ))
            && ((wl->data_format == ISMD_AUDIO_MEDIA_FMT_DD) 
                || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_DTS) 
                || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_DTS_HD)
                || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA)
                || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA)
                || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_DD_PLUS)
                || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_TRUE_HD)
                || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_AAC)
                || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_AAC_LOAS))) {

            hal_sample_size = AUDIO_HAL_SAMPLE_SIZE_24BIT;
            wl->sample_size = 32;
        }

         /* Call only if we are doing SPDIF and I2S*/
         if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI){

            if((result = audio_hal_render_set_sample_size(&(wl->hal_render_h), hal_sample_size)) != ISMD_SUCCESS){
               AUDIO_ERROR("audio_hal_render_set_sample_size failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
            }
         }

      }
      else {
         AUDIO_ERROR("Invalid sample size!", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

ismd_result_t
audio_render_set_sample_rate(ismd_audio_render_t render_h, int sample_rate)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_render_context_t *wl = NULL;
   int frame_rate_scale = 1;//Convert sample rate to frame rate in case of HBR passthrough case.

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      if(wl->data_format != ISMD_AUDIO_MEDIA_FMT_INVALID){

         switch(sample_rate) {
            case 12000 :
               wl->sample_rate = 12000;
               wl->hdmi_wl.sample_rate = 0; //HDMI not support this rate?
               frame_rate_scale = 16;
               break;
            case 24000:
               wl->sample_rate = 24000;
                wl->hdmi_wl.sample_rate = 0; //HDMI not support this rate?
                frame_rate_scale = 8;
               break;
            case 32000 :
               wl->sample_rate = 32000;
               wl->hdmi_wl.sample_rate = GDL_HDMI_AUDIO_FS_32_KHZ;
               frame_rate_scale = 6;
               break;
            case 44100:
               wl->sample_rate = 44100;
               wl->hdmi_wl.sample_rate = GDL_HDMI_AUDIO_FS_44_1_KHZ;
               frame_rate_scale = 4;
               break;
            case 88200:
               wl->sample_rate = 88200;
               wl->hdmi_wl.sample_rate = GDL_HDMI_AUDIO_FS_88_2_KHZ;
               frame_rate_scale = 2;
               break;
            case 48000:
               wl->sample_rate = 48000;
               wl->hdmi_wl.sample_rate = GDL_HDMI_AUDIO_FS_48_KHZ;
               frame_rate_scale = 4;
               break;
            case 96000 :
               wl->sample_rate = 96000;
               wl->hdmi_wl.sample_rate = GDL_HDMI_AUDIO_FS_96_KHZ;
               frame_rate_scale = 2;
               break;
            case 176400 :
               
               if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_SPDIF) {
                  wl->sample_rate = 176400;
                  wl->hdmi_wl.sample_rate = GDL_HDMI_AUDIO_FS_176_4_KHZ;
               }
               else {
                  AUDIO_ERROR("Invalid sample rate for SPDIF: 176400Hz not supported!", result, audio_devh[AUDIO_DEBUG_RENDER]);
                  result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
               }           
               break;
            case 192000:
               wl->sample_rate = 192000;
               wl->hdmi_wl.sample_rate = GDL_HDMI_AUDIO_FS_192_KHZ;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("Invalid sample rate!", result, audio_devh[AUDIO_DEBUG_RENDER]);
               break;
         }

         if(result == ISMD_SUCCESS) {
            
            //If the inteface is HDMI and we are passing through a high bitrate stream, force sample rate 
            // to be equal to the frame rate we need. 
             if((wl->hw_output_interface == AUDIO_RENDER_INTERFACE_HDMI) &&
               ((wl->data_format == ISMD_AUDIO_MEDIA_FMT_DTS_HD)
               || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA)
               || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA)
               || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_DD_PLUS
               || (wl->data_format == ISMD_AUDIO_MEDIA_FMT_TRUE_HD)))) {

                  wl->sample_rate = wl->sample_rate * frame_rate_scale;
             }
         }  
      }
      else{
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("Format not set, please call set render format first!", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

ismd_result_t
audio_render_i2s_set_word_select_format(ismd_audio_render_t render_h, audio_render_i2s_word_select_format_t i2s_ws_format)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;
   audio_hal_i2s_ws_select_t state = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI && wl->hw_output_interface != AUDIO_RENDER_INTERFACE_SPDIF) {

         switch(i2s_ws_format) {

            case AUDIO_RENDER_I2S_WS_SELECT_FALLING:

               state = AUDIO_HAL_I2S_WS_SELECT_FALLING;

               break;

            case AUDIO_RENDER_I2S_WS_SELECT_RISING:

               state = AUDIO_HAL_I2S_WS_SELECT_RISING;

               break;

            case AUDIO_RENDER_I2S_WS_SELECT_INVALID:
            default:

               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("Invalid word select format!", result, audio_devh[AUDIO_DEBUG_RENDER]);

               break;
         }

         if((result = audio_hal_render_i2s_set_ws_select(&(wl->hal_render_h), state) != ISMD_SUCCESS)) {

            AUDIO_ERROR("hal_render_i2s_set_ws_select failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }

      }

      else {

         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid output interface for this call!", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

ismd_result_t
audio_render_i2s_set_clock_invert(ismd_audio_render_t render_h, bool invert_i2s_clock)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS) {

      if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI && wl->hw_output_interface != AUDIO_RENDER_INTERFACE_SPDIF) {

         if((result = audio_hal_render_i2s_set_clk_invert(&(wl->hal_render_h), invert_i2s_clock)) != ISMD_SUCCESS) {

            AUDIO_ERROR("hal_render_i2s_set_clk_invert failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }

      }
      else {

         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid output interface for this call!", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);
   return result;
}

ismd_result_t
audio_render_spdif_set_validity_bit(ismd_audio_render_t render_h, bool is_valid)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      if(wl->hw_dev_id == GEN3_HW_OUTPUT_SPDIF){
         if((result = audio_hal_render_spdif_set_validity_bit(&(wl->hal_render_h), is_valid)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_hal_render_spdif_set_validity_bit failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);
   return result;
}

void audio_render_hw_set_power_mode(audio_hal_power_management_mode_t power_mode)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(ISMD_SUCCESS != (result = audio_hal_render_set_power_mode(audio_devh[AUDIO_DEBUG_RENDER], power_mode))){
      AUDIO_ERROR("audio_hal_render_gate failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }   

}


ismd_result_t
audio_render_set_early_discard_policy(ismd_audio_render_t render_h, audio_render_early_discard_policy_t policy, unsigned int max_early_ms)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   /* Ensure we lock the context we are working on.*/
   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      /* On fixed mode need to update the max_early_ms value. */
      if(policy == AUDIO_RENDER_EARLY_POLICY_DISCARD_FIXED_MS) {
         wl->max_early_ms = max_early_ms;
      }
      else if(policy == AUDIO_RENDER_EARLY_POLICY_DISCARD_NEVER) {
         wl->max_early_ms = 0;
      }
      else {
         result = ISMD_ERROR_INVALID_PARAMETER;
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);
   return result;
}


int
audio_pvt_render_get_ch_count_from_cfg( ismd_audio_channel_config_t ch_config )
{
   int result = 0;

   switch(ch_config) {
      case ISMD_AUDIO_STEREO:
      case ISMD_AUDIO_DUAL_MONO:
         result = 2;
         break;
      case ISMD_AUDIO_5_1:
         result = 6;
         break;
      case ISMD_AUDIO_7_1:
         result = 8;
         break;
      case ISMD_AUDIO_CHAN_CONFIG_INVALID:
      default:
         break;
   }

   return result;
}

ismd_result_t
audio_render_resume(ismd_audio_render_t render_h)
{
   ismd_result_t result = ISMD_ERROR_INVALID_REQUEST;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){
      result = ISMD_SUCCESS;
      if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI) {
         if((result = audio_hal_render_init_context(
                      &(wl->hal_render_h),
                      (void *) wl,
                      audio_devh[AUDIO_DEBUG_RENDER],
                      wl->hw_dev_id,
                      wl->buffer_mode,
                      wl->dma_buffer_des->phys.base,
                      wl->dma_buffer_des->virt.base,
                      wl->dma_buffer_des->phys.size,
                      (buffer_callback_t) audio_pvt_render_buffer_callback)) != ISMD_SUCCESS){

            AUDIO_ERROR("audio_hal_render_init_context failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }
      }
      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("render_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}

ismd_result_t
audio_render_suspend(ismd_audio_render_t render_h)
{
   ismd_result_t result = ISMD_ERROR_INVALID_REQUEST;
   ismd_audio_render_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){
      if ((result = audio_pvt_render_stop_hw( wl, true )) != ISMD_SUCCESS) {
         AUDIO_ERROR("audio_pvt_render_stop_hw failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }
      wl->state = ISMD_DEV_STATE_STOP;
      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("render_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;

}

ismd_result_t
audio_pvt_render_adjust_output_based_on_fmt( ismd_audio_render_context_t *wl )
{
   ismd_result_t result = ISMD_SUCCESS;

   wl->disabled = false;
   
   switch(wl->data_format){

      case ISMD_AUDIO_MEDIA_FMT_PCM:
      case ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM:
      case ISMD_AUDIO_MEDIA_FMT_DVD_PCM:
         wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_PCM;
         break;

      case ISMD_AUDIO_MEDIA_FMT_DD:
         wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_AC3;

         //Here we need to make sure that the tranmisson of this codec over 
         //a HW interface is set to the appropriate channel count, in this case AC3 is 2 ch. 
         //This will happen in the following case statments for each codec. 
         //Per IEC 61937 spec for compressed data transmission.
         wl->ch_count = 2;
         wl->hdmi_wl.num_channels = 2;
         break;

      case ISMD_AUDIO_MEDIA_FMT_DTS:
         wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_DTS;
         wl->ch_count = 2;
         wl->hdmi_wl.num_channels = 2;
         break;

      case ISMD_AUDIO_MEDIA_FMT_MPEG:
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_MPEG2;
         break;
         
      case ISMD_AUDIO_MEDIA_FMT_AAC:
      case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS: 
         wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_AAC;         
         wl->ch_count = 2;
         wl->hdmi_wl.num_channels = 2;
         break;
         
      case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:
         
         if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI ) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"Requested render interface does not support DDPLUS passthrough! Disabling interface.", audio_devh[AUDIO_DEBUG_RENDER]);
            wl->disabled = true;
         }
         else{
            wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_DDP;
            wl->ch_count = 2;
            wl->hdmi_wl.num_channels = 2;
         }                   
         break;
         
      case ISMD_AUDIO_MEDIA_FMT_TRUE_HD:  
         
         if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI ) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"Requested render interface does not support TRUEHD passthrough! Disabling interface.", audio_devh[AUDIO_DEBUG_RENDER]);
            wl->disabled = true;
         }
         else{
            wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_MLP;
            wl->hdmi_wl.num_channels = 2; //Hack until ABD can support checking actual stream ch count against EDID.    
            wl->ch_count = 8;
         }            
         break;
         
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA:
         
         if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI ) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"Requested render interface does not support DTSHD passthrough! Disabling interface.", audio_devh[AUDIO_DEBUG_RENDER]);
            wl->disabled = true;
         }
         else{
            wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_DTSHD;
            wl->hdmi_wl.hdmi_transport_type = AUDIO_HDMI_LAYOUT0;
            wl->hdmi_wl.num_channels = 2;
            wl->ch_count = 2;
         }       
         break;
      
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA:
         if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI ) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"Requested render interface does not support DTSHD passthrough! Disabling interface.", audio_devh[AUDIO_DEBUG_RENDER]);
            wl->disabled = true;
         }
         else{
            wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_DTSHD;
            wl->hdmi_wl.hdmi_transport_type = AUDIO_HDMI_HBR;
            wl->hdmi_wl.num_channels = 8;// TODO: HDMI BUG - expects 8ch always! need a way to give orginal ch_count.  audio_pvt_render_get_ch_count_from_cfg( wl->ch_config ); //For HBR HDMI needs to know orginal ch_count to check on EDID.
            wl->ch_count = 8;
         }
         break;
         
      case ISMD_AUDIO_MEDIA_FMT_WM9:
      case ISMD_AUDIO_MEDIA_FMT_DTS_LBR:
      
         wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_UNDEFINED;
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"Passthrough not supported on specified audio format. Disabling interface.", audio_devh[AUDIO_DEBUG_RENDER]);
         wl->disabled = true;
         break;
         
      case ISMD_AUDIO_MEDIA_FMT_INVALID: 
      default:

         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid codec specified for render passthrough.", result, audio_devh[AUDIO_DEBUG_RENDER]);

         break;
   }

   return result;
}
static void
audio_pvt_render_spdif_make_ch_status_bytes(
   ismd_audio_render_context_t *wl,
   uint32_t *least_sig_word, 
   uint8_t *most_sig_byte)
{
   unsigned char       chstat[6];
   uint32_t            val, msb;
   uint32_t   samp_rate = 0;
   audio_render_iec60958_channel_status_t *ch_status = &wl->ch_status;


   /* Set everything to defualt first */
   chstat[0] = SPDIF_DEFAULT_CHSTAT_BYTE0;
   chstat[1] = SPDIF_DEFAULT_CHSTAT_BYTE1;
   chstat[2] = SPDIF_DEFAULT_CHSTAT_BYTE2;
   chstat[3] = SPDIF_DEFAULT_CHSTAT_BYTE3;
   chstat[4] = SPDIF_DEFAULT_CHSTAT_BYTE4;
   chstat[5] = SPDIF_DEFAULT_CHSTAT_BYTE5;

   switch(ch_status->sample_rate){

      case 32000:
         samp_rate = SPDIF_CHSTAT_SYMFREQ_32k;
         break;
      case 44100:
         samp_rate = SPDIF_CHSTAT_SYMFREQ_44k;
         break;
      case 48000:
         samp_rate = SPDIF_CHSTAT_SYMFREQ_48k;
         break;
      case 96000:
         samp_rate = SPDIF_CHSTAT_SYMFREQ_96k;
         break;
      case 192000:
         samp_rate = SPDIF_CHSTAT_SYMFREQ_192k;
         break;
         
      case 12000:
      case 24000:
      default:
         samp_rate = SPDIF_CHSTAT_SYMFREQ_NOT_INDICATED;
         break;
   }

   /*Apply pcm and copyright settings*/
   /* chstat[0]:  a     pcm  copy  info   mode0 
                  bit0  bit1 bit2  bit3-5 bit6-7 */
   if (ch_status->is_pcm) {
      chstat[0] = ( (0) | (0<<1) | ((ch_status->status.copyright & 0x1)<<2) | ((ch_status->status.pcm_audio_mode & 0x7)<<3) | (0<<6) );
   }
   else {
      chstat[0] = ( (0) | (1<<1) | ((ch_status->status.copyright & 0x1)<<2) | (0<<3) | (0<<6) );      
   }

   /* category code */
   chstat[1] = ch_status->status.category_code;

   /*Going to set "no indication" for the L bit by default */
   if(ch_status->status.gen_status)
   {
      chstat[1] = (chstat[1] |(1<<7) );
   }
   else{
      chstat[1] = (chstat[1] |(0<<7) );
   }

   /*Keep the L bit to 1, if anyone wants to tweak this we might need to change this*/

   /* Apply the sample rate setting */
   chstat[3] = (chstat[3] & 0xF0) | (samp_rate & 0xF);


   /* Apply the Catagory Code setting */

   /*Pack it into the 32bit value*/
   val = ( ((uint32_t)chstat[0] <<  0) |
            ((uint32_t)chstat[1] <<  8) |
            ((uint32_t)chstat[2] << 16) |
            ((uint32_t)chstat[3] << 24) );

   // Only set b32~b35 for PCM output
   if (ch_status->is_pcm)
   {
      // Fill the word length bits in chstat[4]
      if (wl->sample_size == 16) // 8 bits, 16 bits -> AUDIO_HAL_SAMPLE_SIZE_16BIT
      {
         chstat[4] = (chstat[4] | SPDIF_CHSTAT_WORDLEN_16b);
      }
      else if (wl->sample_size == 32) // 20 bits, 24 bits, 32 bits -> AUDIO_HAL_SAMPLE_SIZE_24BIT
      {
         chstat[4] = (chstat[4] | SPDIF_CHSTAT_WORDLEN_24b);
      }
   }
   // Pack it into the 32bit value
   msb = ((uint32_t)chstat[4] <<  0);

   *least_sig_word = val;
   *most_sig_byte = (uint8_t)msb;

   return ;
}

static ismd_result_t
audio_pvt_render_hdmi_make_ch_status_bytes(ismd_audio_render_context_t *wl, uint32_t *least_sig_word, uint32_t *most_sig_word)
{
   ismd_result_t ret = ISMD_SUCCESS;
   gdl_ret_t gdl_result = GDL_SUCCESS;
   uint32_t lsw;
   uint8_t  msb;
   
   OS_ASSERT(wl);
   OS_ASSERT(least_sig_word);
   OS_ASSERT(most_sig_word);

   // It should be called after abd_open(...)
   if ((gdl_result = abd_get_channel_status(wl->hdmi_wl.hdmi_audio_h, least_sig_word, most_sig_word)) != GDL_SUCCESS) {
      ret = ISMD_ERROR_INVALID_REQUEST;
      AUDIO_ERROR("abd_get_channel_status return failed!", ret, audio_devh[AUDIO_DEBUG_RENDER]);
   }
   else {
      // we only touch byte0 and byte1 (channel status bit0-bit15). All other bytes should keep as before.
      audio_pvt_render_spdif_make_ch_status_bytes(wl, &lsw, &msb);
      
      ((char*) least_sig_word)[0] = ((char*)&lsw)[0];
      ((char*) least_sig_word)[1] = ((char*)&lsw)[1];

      ret = ISMD_SUCCESS;
   }

   return ret;
}


ismd_result_t
audio_pvt_render_iec60958_set_channel_status( ismd_audio_render_context_t *wl )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;

   if(wl->hw_output_interface == AUDIO_RENDER_INTERFACE_SPDIF) {
      uint32_t least_sig_word;
      uint8_t most_sig_byte;
   
      //Get the latest sample_rate info
      wl->ch_status.sample_rate = wl->sample_rate;

      //Generate what we need to send to SPDIF interface.
      audio_pvt_render_spdif_make_ch_status_bytes( wl, &least_sig_word, &most_sig_byte);

      if((result = audio_hal_render_spdif_set_channel_status(&(wl->hal_render_h), least_sig_word, most_sig_byte)) != ISMD_SUCCESS){
         AUDIO_ERROR("spdif_set_channel_status failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }
   }

   else if(wl->hw_output_interface == AUDIO_RENDER_INTERFACE_HDMI) {
      uint32_t least_sig_word;
      uint32_t most_sig_word;

      if (wl->state == ISMD_DEV_STATE_PLAY) {
         //Get the latest sample_rate info
         wl->ch_status.sample_rate = wl->sample_rate;

         //Generate what we need to send to HDMI interface.
         audio_pvt_render_hdmi_make_ch_status_bytes( wl, &least_sig_word, &most_sig_word);

         if (abd_set_channel_status(wl->hdmi_wl.hdmi_audio_h, least_sig_word, most_sig_word) != GDL_SUCCESS) {
            result = ISMD_ERROR_OPERATION_FAILED;
            AUDIO_ERROR("hdmi adb_set_channel_status failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
         }
         else {
            result = ISMD_SUCCESS;
         }
      }
      else {
         // will set the status after ISMD_DEV_STATE_PLAY
         result = ISMD_SUCCESS;
      }
   }

   return result;
}


ismd_result_t
audio_render_iec60958_set_channel_status(
   ismd_audio_render_t render_h,
   ismd_audio_iec60958_channel_status_t channel_status)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      //Copy over the info from the user
      wl->ch_status.status = channel_status;

      result = audio_pvt_render_iec60958_set_channel_status(wl);
      
      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("render_validate_and_get_wl failed!\n", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   return result;
}

ismd_result_t
audio_render_get_buffer_level(ismd_audio_render_t render_h, unsigned int *buffer_level_bytes)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;
   size_t level = 0;

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      if((result = audio_hal_render_buffer_get_level(&(wl->hal_render_h), &level)) != ISMD_SUCCESS){

         AUDIO_ERROR("hal_render_buffer_get_level failed!\n", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }
      else{

         *buffer_level_bytes = level;
      }

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }
   return result;

}

ismd_result_t
audio_render_get_samples_rendered(ismd_audio_render_t render_h, uint64_t *samples_rendered)
{

   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      *samples_rendered = wl->samples_rendered;

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }
   return result;
}

ismd_result_t
audio_render_get_samples_prefilled(ismd_audio_render_t render_h, unsigned int *prefill_samples)
{

   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_render_context_t *wl = NULL;

   if((result = audio_pvt_render_lock_and_get_wl(render_h, &wl)) == ISMD_SUCCESS){

      //Since we are dealing with sample count only in terms of 192kHz now, return this count in terms of 192kHz.
      *prefill_samples = audio_core_normalize_sample_count(
         ((uint64_t)audio_core_bytes_to_samples( wl->sample_size, wl->ch_count, wl->prefill_bytes_max)), 
         AUDIO_NORMAL_SAMPLE_RATE, 
         wl->sample_rate);

      audio_pvt_render_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_pvt_render_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }
   return result;
}

/*********************************************************************************************/

/* Render Private Functions*/

static void
audio_pvt_render_init_wl( ismd_audio_render_context_t *wl)
{
   wl->hw_dev_id = 0;
   wl->processor_id = AUDIO_INVALID_HANDLE;
   wl->sample_size = 0;
   wl->sample_rate = 0;
   wl->ch_count = 0;
   wl->prefill_bytes_max = AUDIO_RENDER_DEFAULT_BUFFER_PREFILL_BYTES;
   wl->prefill_bytes = 0;
   wl->prefill_milliseconds = 0;
   wl->max_early_ms = 0;
   wl->curr_buffer_cnt = 0;
   wl->smd_base_time = 0;
   wl->in_use = false;
   wl->start_to_close = false;
   wl->render_hw_started = false;
   wl->use_time_stamps = true;
   wl->push_buffers = true;
   wl->disabled = false;
   wl->dma_buffer_des = NULL;
   wl->buffer_mode = AUDIO_RENDER_BUFFER_MODE_LINKED_LIST;
   wl->input_data_event = ISMD_EVENT_HANDLE_INVALID;
   wl->state = ISMD_DEV_STATE_INVALID;
   wl->ch_config = ISMD_AUDIO_CHAN_CONFIG_INVALID;
   wl->input_queue = ISMD_QUEUE_HANDLE_INVALID;
   wl->data_format = ISMD_AUDIO_MEDIA_FMT_INVALID;
   wl->state = ISMD_DEV_STATE_STOP;
   wl->output_buffer = NULL;
   wl->chunk_size_bytes = 0;
   wl->silence_buffer = NULL;
   wl->cubby_buffer = NULL;
   wl->samples_rendered = 0;
   wl->clock_h = NULL;
   wl->ch_status.is_pcm = true;
   wl->ch_status.sample_rate = 48000;
   wl->ch_status.status.category_code = 0; // SPDIF_CATEGORY_GENERAL
   wl->ch_status.status.copyright = 0x01;  // with no copyright
   wl->ch_status.status.gen_status = 0;
   wl->ch_status.status.pcm_audio_mode = 0; // non-preemphasis

   //Init HDMI audio variables
   wl->hdmi_wl.format = GDL_HDMI_AUDIO_FORMAT_UNDEFINED;
   wl->hdmi_wl.hdmi_audio_h = NULL;
   wl->hdmi_wl.num_channels = 0;
   wl->hdmi_wl.sample_rate = 0;
   wl->hdmi_wl.sample_size = GDL_HDMI_AUDIO_SS_UNDEFINED;
   wl->hdmi_wl.speaker_map = 0;
   wl->hdmi_wl.tranfer_size_changed =  false;
   wl->hdmi_wl.buffer_tracking_queue = ISMD_QUEUE_HANDLE_INVALID;

   wl->heartbeat_timer_clock_h_ptr = NULL;  
   wl->clock_sync_h = ISMD_DEV_HANDLE_INVALID;
   wl->heartbeat_timer_clock_h = ISMD_CLOCK_HANDLE_INVALID;
   wl->do_heartbeat_timer_clock_recovery = false;
   wl->chunk_size_ticks = 0;
   wl->render_time = ISMD_NO_PTS;
}


static ismd_result_t
audio_pvt_render_lock_and_get_wl(ismd_audio_render_t render_h,  ismd_audio_render_context_t **wl)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;

   if (audio_pvt_render_valid_handle(render_h)) {

      audio_pvt_render_lock(&(render_context[render_h]));

      if( render_context[render_h].in_use ){

         /*Return workload to caller*/
         *wl = &(render_context[render_h]);
         result = ISMD_SUCCESS;
      }
      else {
         audio_pvt_render_unlock(&(render_context[render_h]));
         AUDIO_ERROR("Render handle requested not in use!", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }

   } else {
      AUDIO_ERROR("Invalid render handle.", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   return result;
}


static ismd_result_t
audio_pvt_render_stop_hw( ismd_audio_render_context_t *wl, bool reinit_hal)
{
   ismd_result_t result = ISMD_SUCCESS;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_RENDER]);
   
   /* If the render hardware is not running we will never get the set on this event, so only wait if its running.*/
   if(wl->render_hw_started){

      /*Stop the render HW*/
      if((result = audio_hal_render_stop(&(wl->hal_render_h))) != ISMD_SUCCESS){
          AUDIO_ERROR( "audio_hal_render_stop failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }

      else if(os_event_hardwait(&(wl->safe_to_close_event), EVENT_NO_TIMEOUT) != OSAL_SUCCESS){
         AUDIO_OSAL_ERROR( "os_event_hardwait failed in render_close.", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }

      else{

         if(reinit_hal){
            //Re-init the render context, I dont like this, but someday we will clean up the HAL.
            if((result = audio_hal_render_init_context(
               &(wl->hal_render_h),
               (void *) wl,
               audio_devh[AUDIO_DEBUG_RENDER],
               wl->hw_dev_id,
               AUDIO_RENDER_BUFFER_MODE_LINKED_LIST,
               wl->dma_buffer_des->phys.base,
               wl->dma_buffer_des->virt.base,
               wl->dma_buffer_des->phys.size,
               (buffer_callback_t) audio_pvt_render_buffer_callback)) != ISMD_SUCCESS){

               AUDIO_ERROR("audio_hal_render_init_context failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
            }
         }

         wl->render_hw_started = false;
         wl->samples_rendered = 0;
      }

   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_RENDER]);

   return result;
}


static uint64_t
audio_pvt_render_get_base_sample_count(void)
{
   int handle = 0;
   uint64_t samples_rendered = 0;
   
   //Want to check any active render for a current sample count.
   for (handle = 0; handle  < AUDIO_MAX_RENDER_DEVICES; handle ++) {
      if (render_context[handle ].in_use ) {
         samples_rendered =  render_context[handle].samples_rendered;
         break;
      }
   }
   return samples_rendered;
}

static bool
audio_pvt_render_valid_handle( ismd_audio_render_t render_h)
{
   bool result = false;
   if ( (render_h >= 0) && (render_h < AUDIO_MAX_RENDER_DEVICES) ) {
      result = true;
   }
   else
      AUDIO_ERROR("Invalid Render Handle!", ISMD_ERROR_INVALID_HANDLE, audio_devh[AUDIO_DEBUG_APM] );

   return ( result );
}

static void
audio_pvt_render_lock(ismd_audio_render_context_t *wl)
{
   os_mutex_lock(&(wl->lock));
}

static void
audio_pvt_render_unlock(ismd_audio_render_context_t *wl)
{
   os_mutex_unlock(&(wl->lock));
}

static ismd_result_t
audio_pvt_render_valid_hw_id(ismd_audio_render_context_t *wl, int hw_output_id)
{
   ismd_result_t result = ISMD_SUCCESS;

   switch(hw_output_id)
   {
      case GEN3_HW_OUTPUT_I2S0:
         wl->hw_output_interface = AUDIO_RENDER_INTERFACE_I2S0;
         break;
      case GEN3_HW_OUTPUT_I2S1:
         wl->hw_output_interface = AUDIO_RENDER_INTERFACE_I2S1;
         break;
      case GEN3_HW_OUTPUT_SPDIF:
         wl->hw_output_interface = AUDIO_RENDER_INTERFACE_SPDIF;
         break;
      case GEN3_HW_OUTPUT_HDMI:
         wl->hw_output_interface = AUDIO_RENDER_INTERFACE_HDMI;
         break;
      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid render HW ID! ", result, audio_devh[AUDIO_DEBUG_RENDER]);
         break;
   }

   return result;
}

static ismd_result_t
audio_pvt_render_setup_circular_buffer_mode( ismd_audio_render_context_t *wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   if((result = ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS, AUDIO_RENDER_CIRC_BUF_SIZE, &(wl->dma_buffer_des))) != ISMD_SUCCESS){
      AUDIO_ERROR("dma_buffer alloc failed ", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   /*Call HAL for context HW setup*/
   else if((
      result = audio_hal_render_init_context(
         &(wl->hal_render_h),
         (void *) wl,
         audio_devh[AUDIO_DEBUG_RENDER],
         wl->hw_dev_id,
         AUDIO_RENDER_BUFFER_MODE_CIRCULAR,
         wl->dma_buffer_des->phys.base,
         wl->dma_buffer_des->virt.base,
         wl->dma_buffer_des->phys.size,
         (buffer_callback_t) audio_pvt_render_buffer_callback)) != ISMD_SUCCESS){

      AUDIO_ERROR("audio_hal_render_init_context failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }
   else{

      /*Set the high water mark same as buffer full, and set low water mark 1/4 buffer size.*/
      if((result = audio_hal_render_buffer_set_config(
         &(wl->hal_render_h),
         wl->dma_buffer_des->phys.size,
         wl->dma_buffer_des->phys.size,
         (wl->dma_buffer_des->phys.size/2))) != ISMD_SUCCESS){

         AUDIO_ERROR("audio_hal_render_buffer_set_config failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }
   }

   /*Clean up if we failed */
   if(result != ISMD_SUCCESS) {

      os_event_destroy(&(wl->safe_to_close_event));
      ismd_audio_buffer_dereference(wl->dma_buffer_des->unique_id);
   }

   return result;

}

static ismd_result_t
audio_pvt_render_setup_linked_list_mode( ismd_audio_render_context_t *wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   // Allocate Memory for the linked list nodes.
   if((result = ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS, AUDIO_RENDER_LINKED_LIST_NODE_MEM_SIZE, &(wl->dma_buffer_des))) != ISMD_SUCCESS){
      AUDIO_ERROR("dma_buffer alloc failed ", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   /*Call HAL for context HW setup*/
   else if((
      result = audio_hal_render_init_context(
         &(wl->hal_render_h),
         (void *) wl,
         audio_devh[AUDIO_DEBUG_RENDER],
         wl->hw_dev_id,
         AUDIO_RENDER_BUFFER_MODE_LINKED_LIST,
         wl->dma_buffer_des->phys.base,
         wl->dma_buffer_des->virt.base,
         wl->dma_buffer_des->phys.size,
         (buffer_callback_t) audio_pvt_render_buffer_callback)) != ISMD_SUCCESS){

      AUDIO_ERROR("audio_hal_render_init_context failed!", result, audio_devh[AUDIO_DEBUG_RENDER]);
   }

   /*Clean up if we failed */
   if(result != ISMD_SUCCESS) {

      os_event_destroy(&(wl->safe_to_close_event));
      ismd_audio_buffer_dereference(wl->dma_buffer_des->unique_id);
   }

   return result;
}


static void
audio_pvt_render_time_update(ismd_audio_render_context_t *wl)
{
   ismd_time_t actual_time; 

   if(wl->render_time != ISMD_NO_PTS){
      wl->render_time += wl->chunk_size_ticks;
   }

   if((wl->do_heartbeat_timer_clock_recovery) && (wl->clock_sync_h != ISMD_DEV_HANDLE_INVALID)){
      if((wl->heartbeat_timer_clock_h_ptr != NULL) && (*(wl->heartbeat_timer_clock_h_ptr) != ISMD_CLOCK_HANDLE_INVALID)){
         if((ismd_clock_get_time_th_safe(*(wl->heartbeat_timer_clock_h_ptr), &actual_time)) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "audio_render: ismd_clock_get_time_th_safe failed!", audio_devh[AUDIO_DEBUG_CAPTURE]);
         }
         else if(ismd_clock_sync_add_pair_th_safe(wl->clock_sync_h, wl->render_time, actual_time) != ISMD_SUCCESS) {
            OS_INFO("audio_pvt_render_time_update : couldn't add pair\n");
         } 
         else {
            AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_RENDER],
               SVEN_MODULE_EVENT_AUD_IO_RENDER_CLOCK_RECOVERY,
               (unsigned int)wl->hw_dev_id, 
               (unsigned int) (wl->render_time >> 32), 
               (unsigned int) (wl->render_time),
               (unsigned int) (actual_time >> 32),
               (unsigned int) (actual_time), 
               (int) (actual_time - wl->render_time));
         }
      }
   }
}

static ismd_result_t
audio_pvt_render_buffer_callback(void *context, int buffer_id, audio_hal_render_event_t buf_event)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_render_context_t *wl = ( ismd_audio_render_context_t *)context; 
   ismd_buffer_descriptor_t *buffer_tracking_descr = NULL;

   /* Make sure the render is still available. 
    * To handle the case: render get abd_close() failed. HDMI render is still active, 
    * while audio driver already reset all render_context members. 
    */
   if (wl->in_use == false) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
   switch(buf_event){

      case AUDIO_RENDER_BUFFER_FULL:

         break;

      case AUDIO_RENDER_BUFFER_EMPTY:

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_RENDER],
            SVEN_MODULE_EVENT_AUD_IO_RENDER_BUFFER_EMPTY_CALLBACK,
            (unsigned int)wl->hw_dev_id, 0, 0, 0, 0, 0);

        if( (wl->state == ISMD_DEV_STATE_PLAY) && !wl->start_to_close) {

            if ( wl->hdmi_wl.hdmi_audio_h != NULL ) { 
               //Syncronous stop to ABD.
               audio_pvt_render_hdmi_stop( wl->hdmi_wl.hdmi_audio_h, &wl->hdmi_wl.stop_event, true);        
            } 

            /* DMA is empty, HW is stopped, need to restart DMA*/
            wl->render_hw_started = false;
            audio_pvt_render_rebuffer(wl, true);
        }

         break;

      case AUDIO_RENDER_INPUT_BUFFER_DONE:

         /* Need to dequeue from our tracking queue if HDMI called us back with a descriptor to deref. 
            There is no ned to do anything with the descriptor as it will be deref'd as normal. */
         if ( wl->hdmi_wl.hdmi_audio_h != NULL ) { 
            if(ismd_queue_dequeue(wl->hdmi_wl.buffer_tracking_queue, &buffer_tracking_descr) != ISMD_SUCCESS) {
               OS_PRINT("AUDIO WARNING: Could not dequeue from HDMI buffer tracking queue!\n");
            }
         }
         
         //Update total samples rendered.
         wl->samples_rendered += AUDIO_CHUNK_SIZE_SAMPLES(wl);
         wl->curr_buffer_cnt--;

         audio_pvt_render_time_update(wl); 

         //Used for PTS/timing debug info, no need to check return value.
         audio_pvt_render_report_timing_info(wl, buffer_id); 


         if(buffer_id != ISMD_BUFFER_HANDLE_INVALID){
            if((result = audio_pvt_render_dereference_buffer_safe(wl, buffer_id)) != ISMD_SUCCESS){
               //AUDIO_ERROR("ismd_audio_buffer_dereference failed, invalid buffer ID returned from audio render HAL.", result, audio_devh[AUDIO_DEBUG_RENDER]);
               OS_PRINT("AUDIO RENDER callback: buffer_deref failed: HW_ID: 0x%x, buf_id: 0x%x, silnc_buf_id: 0x%x\n", wl->hw_dev_id, buffer_id, wl->silence_buffer->unique_id);
            }
         }

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_RENDER],
            SVEN_MODULE_EVENT_AUD_IO_RENDER_BUFFER_DONE,
            (unsigned int) wl->hw_dev_id,
            (unsigned int) buffer_id, 
            (unsigned int) (wl->samples_rendered>>32), 
            (unsigned int) wl->samples_rendered, 
            (unsigned int) wl->curr_buffer_cnt, 0);

         break;

      case AUDIO_RENDER_BUFFER_REQUEST_DATA:
         result = audio_pvt_render_rebuffer(wl, false);

         break;

      case AUDIO_RENDER_BUFFER_LOW_WATERMARK:
         OS_INFO("low_watermark callback\n");
         wl->push_buffers = true;

         break;

      case AUDIO_RENDER_BUFFER_HIGH_WATERMARK:
        // OS_INFO("AUDIO_RENDER_BUFFER_HIGH_WATERMARK!\n");
         break;

      case AUDIO_RENDER_SAFE_TO_CLOSE:

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_RENDER],
            SVEN_MODULE_EVENT_AUD_IO_RENDER_SAFE_TO_CLOSE_CALLBACK,
            wl->hw_dev_id,
            buffer_id, 0, 0, 0, 0);

        if(os_event_set(&(wl->safe_to_close_event)) != OSAL_SUCCESS){
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "os_event_set failed!", audio_devh[AUDIO_DEBUG_RENDER]);
        }
         break;

      default:
         OS_INFO("Buffer event not recognized!\n");
         break;

   }
   }

   return result;
}


static gdl_ret_t
audio_pvt_render_hdmi_stop( void *abd_handle, os_event_t *stop_event, bool syncronous) 
{
   gdl_ret_t gdl_result = GDL_ERR_FAILED;
   osal_result os_result = OSAL_SUCCESS;

   gdl_result = abd_stop(abd_handle, syncronous); 

   if(gdl_result != GDL_SUCCESS){
      os_sleep(50); // give other task time to run as caller is going to keep trying until abd_stop returns success
   }

   if(!syncronous && (gdl_result == GDL_SUCCESS)) {
      if((os_result = os_event_hardwait(stop_event, EVENT_NO_TIMEOUT)) != OSAL_SUCCESS){ 
         OS_PRINT("\nAUDIO RENDER WARNING: event wait failed waiting on ABD callback for async stop!result: %d\n", os_result);
         gdl_result = GDL_ERR_FAILED;
      }
   }

   return gdl_result;
}


static ismd_result_t
audio_pvt_render_hdmi_set_state( ismd_audio_render_context_t *wl, ismd_dev_state_t state) 
{
   ismd_result_t result = ISMD_SUCCESS;
   gdl_ret_t gdl_result = GDL_ERR_FAILED;
   uint32_t least_sig_word = 0;
   uint32_t most_sig_word = 0;

   switch(state) {

      case ISMD_DEV_STATE_PLAY:

         if((result = audio_pvt_render_adjust_output_based_on_fmt( wl )) == ISMD_SUCCESS) {

            //Make sure to re-calculate the buffer pre-fill time.
            audio_pvt_render_set_buffer_prefill_time( wl, wl->prefill_milliseconds);
            
            //Do these calculations after possible paramater adjustments.  
            wl->chunk_size_bytes = audio_core_calc_chunk_size(wl->sample_size, wl->sample_rate, wl->ch_count, AUDIO_CORE_GET_CHUNK_PERIOD(wl));
            wl->chunk_size_samples = audio_core_bytes_to_samples(wl->sample_size, wl->ch_count, wl->chunk_size_bytes);      
            //Call down to build the silence/data burst buffer now that we know the format.
            audio_pvt_render_build_silence_buffer( wl->silence_buffer, wl->silence_buffer->phys.level, wl->data_format);
            wl->silence_buffer->phys.level = wl->chunk_size_bytes;
            wl->chunk_size_ticks = audio_core_chunk_size_ticks(wl->chunk_size_bytes, wl->sample_rate, wl->sample_size, wl->ch_count);
            audio_render_get_time(wl);
            //OS_PRINT("\n%d, %d, %d, %d, %d\n", wl->hdmi_wl.format, wl->hdmi_wl.num_channels, wl->hdmi_wl.sample_rate, wl->hdmi_wl.sample_size, wl->hdmi_wl.speaker_map);

            if((gdl_result = abd_set_event_callback(wl->hdmi_wl.hdmi_audio_h, (gdl_hdmi_event_cb_t) audio_pvt_render_hdmi_audio_callback, (void *) wl)) != GDL_SUCCESS)
            {
               result = ISMD_ERROR_INVALID_REQUEST;
               AUDIO_GDL_ERROR("abd_set_event_callback failed!", gdl_result, audio_devh[AUDIO_DEBUG_RENDER]);
            }
         
            else if((gdl_result = abd_set_format(wl->hdmi_wl.hdmi_audio_h,
                              wl->hdmi_wl.format,
                              wl->hdmi_wl.num_channels,
                              wl->hdmi_wl.sample_rate,
                              wl->hdmi_wl.sample_size,
                              wl->hdmi_wl.speaker_map)) != GDL_SUCCESS) {

               AUDIO_GDL_ERROR("abd_set_format failed!", gdl_result, audio_devh[AUDIO_DEBUG_RENDER]);
               result = ISMD_ERROR_INVALID_REQUEST;

               if(gdl_result == GDL_ERR_NO_HW_SUPPORT) {
                  result = ISMD_ERROR_NOT_FOUND;
                  AUDIO_GDL_ERROR("abd_set_format failed, make sure your source supports the desired audio config.", gdl_result, audio_devh[AUDIO_DEBUG_RENDER]);
               }
            }
            else if(wl->ch_status.status.copyright == 0 || wl->ch_status.status.gen_status || wl->ch_status.status.pcm_audio_mode != 0) {

               wl->ch_status.sample_rate = wl->sample_rate;
   	
               // get abd_get_channel_status first
               audio_pvt_render_hdmi_make_ch_status_bytes(wl, &least_sig_word, &most_sig_word);

               gdl_result = abd_set_channel_status(wl->hdmi_wl.hdmi_audio_h, least_sig_word, most_sig_word);
               if (gdl_result != GDL_SUCCESS) {
                  result = ISMD_ERROR_OPERATION_FAILED;
                  AUDIO_GDL_ERROR("abd_set_channel_status failed, make sure your source supports the desired audio config.", gdl_result, audio_devh[AUDIO_DEBUG_RENDER]);
               }
            }

            if(result == ISMD_SUCCESS){

               //Flush the input queue right before we start in case we have left over buffers from a reconfig.
               ismd_queue_flush(wl->input_queue);
               
               //Need to call the callback to start the DMA's engine. 
               audio_pvt_render_buffer_callback((void *) wl, 0, AUDIO_RENDER_BUFFER_EMPTY); 
            }
         }

         break;

      case ISMD_DEV_STATE_PAUSE:
      case ISMD_DEV_STATE_STOP:

         //Only attempt to stop if we in a running state. 
         if(wl->render_hw_started){
            //Asyncronous stop to ABD, ignore value
            do{
               gdl_result = audio_pvt_render_hdmi_stop( wl->hdmi_wl.hdmi_audio_h, &wl->hdmi_wl.stop_event, false);
            }while(gdl_result != GDL_SUCCESS);
         }
         result = ISMD_SUCCESS;

         wl->samples_rendered = 0;
         wl->render_hw_started = false;
         
         break;

      case ISMD_DEV_STATE_INVALID:
      default:
         break;      
   }

   return result;
}


void
audio_pvt_render_hdmi_audio_callback(void  * user_data, gdl_hdmi_audio_event_t   event, unsigned int id)
{ 
   ismd_buffer_descriptor_t *buffer_tracking_descr = NULL;
   ismd_audio_render_context_t *wl = ( ismd_audio_render_context_t *)user_data; 
   
   switch(event){

      case GDL_HDMI_AUDIO_EVENT_TRANSFER_DONE:        
         audio_pvt_render_buffer_callback(user_data, id, AUDIO_RENDER_INPUT_BUFFER_DONE); 
         audio_pvt_render_buffer_callback(user_data, ISMD_BUFFER_HANDLE_INVALID, AUDIO_RENDER_BUFFER_REQUEST_DATA);      
      break;
      
      case GDL_HDMI_AUDIO_EVENT_EMPTY:
         audio_pvt_render_buffer_callback(user_data, ISMD_BUFFER_HANDLE_INVALID, AUDIO_RENDER_BUFFER_EMPTY);
      break;

      case GDL_HDMI_AUDIO_EVENT_CLEAN_UP:
      case GDL_HDMI_AUDIO_EVENT_REJECT:
         audio_pvt_render_buffer_callback(user_data, id, AUDIO_RENDER_INPUT_BUFFER_DONE);
      break;

      case GDL_HDMI_AUDIO_EVENT_STOP_DONE:

         /* If HDMI has told us we are done, our tracking queue should be empty. If it is not
            empty, dequeue and need to dereference the buffer so it is not leaked. */
         while((ismd_queue_dequeue(wl->hdmi_wl.buffer_tracking_queue, &buffer_tracking_descr)) == ISMD_SUCCESS) {
            audio_pvt_render_dereference_buffer_safe(wl, buffer_tracking_descr->unique_id);
            //OS_PRINT("HDMI LEAKED A BUFFER, BUT AUDIO DRIVER CAUGHT IT!\n");
         }
         
         /*Set the safe to close event when finished*/
         os_event_set(&((( ismd_audio_render_context_t *)user_data)->hdmi_wl.stop_event));
      break;
      
   }
   return;
}

static void
audio_pvt_render_report_timing_info(ismd_audio_render_context_t *wl, int buffer_id)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_buffer_attr_t *buffer_attr = NULL;
   ismd_buffer_descriptor_t *done_buffer = NULL;
   ismd_time_t clock_time = 0;
   int32_t clock_drift = 0;
   
   if(buffer_id != ISMD_BUFFER_HANDLE_INVALID) 
   {
      if((result = ismd_buffer_find_descriptor(buffer_id, &done_buffer)) == ISMD_SUCCESS){

         buffer_attr = (audio_buffer_attr_t *) &(done_buffer->attributes);

         if( buffer_attr->local_pts != ISMD_NO_PTS ) {          

            if((wl->clock_h != NULL) && (*(wl->clock_h) != ISMD_CLOCK_HANDLE_INVALID) && !wl->start_to_close) {
               
               if((result = ismd_clock_get_time_th_safe(*(wl->clock_h), &clock_time)) != ISMD_SUCCESS) {
                  
                  wl->clock_h = NULL; //Todo Need to figure this out.
               }
               else {             

                  clock_drift = (int32_t)(buffer_attr->local_pts - (clock_time - wl->smd_base_time));
                     
                  AUDIO_EVENT(AUDIO_SVEN_LOG_GENERAL, audio_devh[AUDIO_DEBUG_RENDER],
                     SVEN_MODULE_EVENT_AUD_IO_RENDER_CLOCK_ACCURACY,
                     (unsigned int) (clock_drift), 0, 0, 0, 0, 0);
               }
            }  

               AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_RENDER],
                  SVEN_MODULE_EVENT_AUD_IO_RENDER_BUFFER_DONE_TIMING_INFO,
                  (unsigned int) (clock_time>>32), 
                  (unsigned int) (clock_time),
                  (unsigned int) (buffer_attr->original_pts>> 32), 
                  (unsigned int) (buffer_attr->original_pts), 
                  (unsigned int) (buffer_attr->local_pts >> 32), 
                  (unsigned int) (buffer_attr->local_pts));

         }
      }
      else {
         AUDIO_ERROR("buffer_find_descriptor failed, invalid buffer ID returned from audio render HAL.", result, audio_devh[AUDIO_DEBUG_RENDER]);
      }
   }
   
   return;
}


static ismd_result_t
audio_pvt_render_rebuffer(ismd_audio_render_context_t *wl, bool need_to_start_dma)
{
   ismd_result_t result = ISMD_SUCCESS;
   gdl_ret_t gdl_result = GDL_ERR_BUSY;
   unsigned int bytes_sent = 0;
      
   if(!wl->start_to_close){

      while(need_to_start_dma && !wl->render_hw_started && !wl->start_to_close) {
         bytes_sent = audio_pvt_render_send_buffer_to_dma(wl);
         wl->prefill_bytes += bytes_sent;
   
         /*Start render when specified buffering is reached.*/
         if(wl->prefill_bytes >= wl->prefill_bytes_max){

            //Sync the associated renders right before we start up.
            audio_pvt_render_sync_associated_renders(wl->processor_id);

            if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI) {
               if((result = audio_hal_render_start(&(wl->hal_render_h))) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_hal_render_start FAILED!", result, audio_devh[AUDIO_DEBUG_RENDER]);
               }
            }
            else {
               if((gdl_result = abd_start(wl->hdmi_wl.hdmi_audio_h)) != GDL_SUCCESS) {
                  AUDIO_GDL_ERROR("abd_start failed", gdl_result, audio_devh[AUDIO_DEBUG_RENDER]);
               }
            }

            if(result == ISMD_SUCCESS){

               AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_RENDER],
                  SVEN_MODULE_EVENT_AUD_IO_RENDER_STARTED,
                  wl->hw_dev_id,
                  wl->prefill_bytes,
                  wl->prefill_bytes_max,
                  wl->prefill_milliseconds, 0, 0);

               wl->render_hw_started = true;
               wl->prefill_bytes = 0;
            }
         }

      }

      if(!need_to_start_dma) {

         bytes_sent = audio_pvt_render_send_buffer_to_dma(wl);
      }
      
   }

   /* If nothing was sent return an error. */
   if(bytes_sent == 0){
      result = ISMD_ERROR_NO_SPACE_AVAILABLE;
   }
   
   return result;
}

static bool
audio_pvt_render_buffer_on_time(ismd_audio_render_context_t* wl, ismd_audio_format_t format, uint64_t render_time_slot, uint64_t buffer_time_slot)
{
   bool result = false;
   int rts_diff = 0;

   //Find the difference between the render time slot and the buffer time slot.
   rts_diff = (int)(render_time_slot - buffer_time_slot);


   //Make sure we are either the render is ahead (the buffer is late), or on time, if we are early we dont want to succeed here.
   if(rts_diff > 0){
      
      //There is a chance this could be up to 3 time slices off because of encode delay. Consider it on time in that case.
      if(((format == ISMD_AUDIO_MEDIA_FMT_DD) || (format == ISMD_AUDIO_MEDIA_FMT_DTS)) 
         && (rts_diff <= AUDIO_RENDER_TIME_STAMP_ENCODE_DRIFT_CHUNK * AUDIO_CHUNK_SIZE_SAMPLES(wl))) {              
            result = true;
      }
   }
   //If there is no difference we are spot on!
   else if(rts_diff == 0){
      result = true;
   }
   else{
      //The buffer is early, don't return that we are on time.
   }

   return result;
}


static int
audio_pvt_render_fill_to_chunk_size(bool is_pcm, void *buffer_base_addr, int level, int max_level)
{
   int bytes_added = 0;
   
   //Calculate new address where to start the pause burst.
   int burst_start_addr = (int)buffer_base_addr + level;

   //Update how many bytes we have added. 
   bytes_added = (max_level - level);
   
   //Memset the memory where the pause burst will be.
   OS_MEMSET((void*)burst_start_addr, 0, bytes_added);

   //Determine if there is enough room for a pause burst preamble. Note: renders are taking 16b contained in 32b, so mult by 2. 
   if((bytes_added > (BYTES_NEEDED_FOR_PAUSE_BURST_HEADER * 2) + (BYTES_NEEDED_FOR_PAUSE_BURST_PAYLOAD * 2)) && !is_pcm) {
      
      audio_pvt_render_build_pause_burst((void*)burst_start_addr, bytes_added);
   } 

   return bytes_added; 
}


static unsigned int
audio_pvt_render_send_buffer_to_dma(ismd_audio_render_context_t *wl)
{
   ismd_result_t result = ISMD_SUCCESS; 
   unsigned int bytes_sent = 0;
   gdl_ret_t gdl_result = GDL_ERR_BUSY;
   audio_buffer_attr_t *input_buf_attrib = NULL;
   uint64_t render_time_slot = 0;
   uint64_t buffer_time_slot = 0;

   if(wl->cubby_buffer == NULL) {
      if((result = ismd_queue_dequeue(wl->input_queue, &(wl->cubby_buffer))) == ISMD_SUCCESS) {
      input_buf_attrib = (audio_buffer_attr_t *) &(wl->cubby_buffer->attributes);
      AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_RENDER],
         SVEN_MODULE_EVENT_AUD_IO_RENDER_DEQUEUE,
         (unsigned int) wl->hw_dev_id,
         (unsigned int) wl->cubby_buffer->phys.level, 
         (unsigned int) (input_buf_attrib->local_pts >> 32), 
         (unsigned int) (input_buf_attrib->local_pts),
         (unsigned int) (input_buf_attrib->render_time_stamp >> 32), 
         (unsigned int) (input_buf_attrib->render_time_stamp));

         //Handle zero-length buffers, and if the interface was disabled.
         if((wl->cubby_buffer->phys.level == 0) || (wl->disabled) || (input_buf_attrib->render_time_stamp == 0)) {
            ismd_audio_buffer_dereference(wl->cubby_buffer->unique_id);
            wl->cubby_buffer = NULL;
         }

         //If we are expecting encoded data, need to discard if we dont see encoded data.
         //This means the ATC is filling silence. 
         //Then the silence buffer will be formatted for a pause burst. 
         else if((wl->data_format != ISMD_AUDIO_MEDIA_FMT_PCM) && (!input_buf_attrib->is_encoded_data)){
            ismd_audio_buffer_dereference(wl->cubby_buffer->unique_id);
            wl->cubby_buffer = NULL;
         }

         //If data is not a full chunk size need to fill remainder of the data with silence or pause burst. 
         else if(wl->cubby_buffer->phys.level != (int)wl->chunk_size_bytes) {

            if(wl->cubby_buffer->phys.level < (int)wl->chunk_size_bytes) {

               //Function will return the amount of data added to this buffer.
               wl->cubby_buffer->phys.level += audio_pvt_render_fill_to_chunk_size((wl->data_format == ISMD_AUDIO_MEDIA_FMT_PCM), 
                                                wl->cubby_buffer->virt.base, wl->cubby_buffer->phys.level, wl->chunk_size_bytes);
            }
            else if(wl->cubby_buffer->phys.level > (int)wl->chunk_size_bytes) {
               
               OS_PRINT("\nAudio Render: ERROR: Chunk size render is processing is bigger than configured chunk size! Expect no AUDIO!\n");
               
               AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_RENDER],
                  SVEN_MODULE_EVENT_AUD_IO_RENDER_CHUNK_SIZE_MISMATCH,
                  input_buf_attrib->sample_rate, input_buf_attrib->sample_size, input_buf_attrib->channel_count, 
                  wl->sample_rate, wl->sample_size, wl->ch_count);         
            }
         }
      }
      else {
         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_RENDER],
            SVEN_MODULE_EVENT_AUD_IO_RENDER_DEQUEUE_FAILED,
            (unsigned int) wl->hw_dev_id,
            (unsigned int) result, wl->input_queue, 0, 0, 0);      
      }
   }

   //Check to see if we need to look at timestamps.
   if(!wl->use_time_stamps) {
      
      if(wl->cubby_buffer != NULL) {
         wl->output_buffer = wl->cubby_buffer;
      }
   }
   
   else {
     //Cubby buffer full need to check time-stamp again.
     if(wl->cubby_buffer != NULL) {

         /* Get the buffer attributes and calulate the render time slot */
         input_buf_attrib = (audio_buffer_attr_t *) &(wl->cubby_buffer->attributes);
         
         //We could have added this offset in the ATC, but here we have an EXACT count of how many buffers
         //are queued up, so its a bit more accurate. This number is already in terms of the normalized sample rate. 
         render_time_slot = (wl->samples_rendered + (uint64_t)(wl->curr_buffer_cnt * AUDIO_CHUNK_SIZE_SAMPLES(wl)));

         //This is already in terms of the normalized sample rate.
         buffer_time_slot = input_buf_attrib->render_time_stamp;
         
         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_RENDER],
            SVEN_MODULE_EVENT_AUD_IO_RENDER_TRY_TO_PLAY,
            (unsigned int) wl->hw_dev_id,
            (unsigned int) wl->cubby_buffer->phys.level, 
            (unsigned int) (buffer_time_slot >> 32), 
            (unsigned int) (buffer_time_slot), 
            (unsigned int) (render_time_slot >> 32), 
            (unsigned int) (render_time_slot) );

         /* If the render_time_stamp is equal to where the render is at, then send it to be rendered. */
         if(audio_pvt_render_buffer_on_time(wl, wl->data_format, render_time_slot, buffer_time_slot)) {
            wl->output_buffer = wl->cubby_buffer;
         }

         //The render timestamp is late
         else if(buffer_time_slot < render_time_slot) {
            audio_pvt_render_handle_out_of_range_time_stamp(wl, render_time_slot, buffer_time_slot, true);
         }

         //The render time stamp is early
         else if(buffer_time_slot > render_time_slot) {

            //If the time stamp is out of our early range policy, need to try to recover.
            if(!audio_pvt_render_early_buffer_in_range(wl, render_time_slot, buffer_time_slot)) {
               audio_pvt_render_handle_out_of_range_time_stamp(wl, render_time_slot, buffer_time_slot, false);
            }
         }
        
      }
   }


   /* If our output buffer is NULL, send silence for this chunk*/
   if(wl->output_buffer == NULL) {

      audio_pvt_render_prepare_silence_buffer(wl);

      wl->output_buffer = wl->silence_buffer;      
   }
   /* Make sure the output buffer isn't NULL, then try adding the buffer. */
   if(wl->output_buffer != NULL) {
      if(wl->hw_output_interface != AUDIO_RENDER_INTERFACE_HDMI) {
         if((result = audio_hal_render_buffer_add(&(wl->hal_render_h),
                      wl->output_buffer->phys.base, wl->output_buffer->virt.base,
                      wl->output_buffer->phys.level, wl->output_buffer->unique_id)) == ISMD_SUCCESS) {

            AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_RENDER],
               SVEN_MODULE_EVENT_AUD_IO_RENDER_PULL_BUFFER,
               (unsigned int) wl->hw_dev_id,
               (unsigned int) wl->output_buffer->unique_id,
               (unsigned int) wl->output_buffer->phys.level, 
               (unsigned int) (wl->samples_rendered >> 32), 
               (unsigned int) (wl->samples_rendered ), 0);

            bytes_sent = (unsigned int) wl->output_buffer->phys.level;
            wl->curr_buffer_cnt++;

            if(wl->output_buffer == wl->cubby_buffer) { 

               wl->cubby_buffer = NULL;
            }
            wl->output_buffer = NULL;          
         }
         //HAL didnt take the buffer
         else {
            //If we tried and failed to enqueue the silence buffer, don't try to send it again
            if( wl->output_buffer == wl->silence_buffer) {
               wl->output_buffer = NULL; //Output buffer holder is done.
            }
         }
      }
      else {

         //Try to write the buffer to HDMI audio, if successful, HDMI will call us back to dereference the buffer when it's done.
         if((gdl_result = abd_write(wl->hdmi_wl.hdmi_audio_h, wl->output_buffer->phys.base, wl->silence_buffer->phys.base, wl->output_buffer->phys.level, (unsigned int)wl->output_buffer->unique_id)) != GDL_SUCCESS) {

            /** Dereference the buffer */
            audio_pvt_render_dereference_buffer_safe(wl, wl->output_buffer->unique_id);
         
            /** Handle the case where write failed because the HDMI audio buffer is already full, don't send any more data to ABD */
            if(gdl_result == GDL_ERR_HDMI_AUDIO_BUFFER_FULL){
            
               /** Force playback to begin even though we didn't send a buffer*/
               bytes_sent = wl->prefill_bytes_max;
            }
            else{
               //AUDIO_GDL_ERROR("abd_write failed", gdl_result, audio_devh[AUDIO_DEBUG_RENDER]);               
            }         
           
         }
         else {

            /*Enqueue the buffer we just gave to HDMI to track its reference in case HDMI never cleans up.*/
            if(ismd_queue_enqueue(wl->hdmi_wl.buffer_tracking_queue, wl->output_buffer) != ISMD_SUCCESS) {
               OS_PRINT("AUDIO Warning: Could not enqueue to HDMI buffer tracking queue!\n");
            }

            //Update how much data we sent out
            bytes_sent = (unsigned int) wl->output_buffer->phys.level;
            wl->curr_buffer_cnt++;

            if(wl->output_buffer == wl->cubby_buffer) {
               wl->cubby_buffer = NULL;
            } 

            wl->output_buffer = NULL;
         }
      }
   }

   return bytes_sent;
}

static bool
audio_pvt_render_early_buffer_in_range(ismd_audio_render_context_t *wl, uint64_t render_time_slot, uint64_t buffer_time_slot)
{
   bool result = true;
   uint64_t ms_early = 0;
   
   /*If max_early_ms is 0, we are in never throw away policy. */
   if(wl->max_early_ms != 0) {

      /* Calculate how early we are */
      ms_early = ((OSAL_DIV64((buffer_time_slot - render_time_slot), (uint64_t)AUDIO_CHUNK_SIZE_SAMPLES(wl))) * (uint64_t)AUDIO_CORE_GET_CHUNK_PERIOD(wl));

      /*If we are too early, need to signal that we are not in range. (Out of specified policy)*/
      if(ms_early > (uint64_t)wl->max_early_ms) {
         result = false;
      }
   }

   return result;
}

static void
audio_pvt_render_handle_out_of_range_time_stamp(ismd_audio_render_context_t *wl, uint64_t render_time_slot, uint64_t buffer_time_slot, bool late)
{
   bool try_to_recover = true;
   audio_buffer_attr_t *input_buf_attrib = NULL;
   int module_event;
            
   while(try_to_recover && !wl->start_to_close) {

      /*Based on if we are late or early print the appropriate SVEN message.*/
      module_event = (late) ? SVEN_MODULE_EVENT_AUD_IO_RENDER_TIME_STAMP_LATE: SVEN_MODULE_EVENT_AUD_IO_RENDER_TIME_STAMP_EARLY;
      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_RENDER], module_event,
         (unsigned int) wl->hw_dev_id, 
         (unsigned int) (buffer_time_slot >> 32), 
         (unsigned int) (buffer_time_slot), 
         (unsigned int) (render_time_slot >> 32), 
         (unsigned int) (render_time_slot),
         (int) (render_time_slot - buffer_time_slot));

      if(wl->cubby_buffer != NULL){
         ismd_audio_buffer_dereference(wl->cubby_buffer->unique_id);
         wl->cubby_buffer = NULL;
      }

      //Since we are in recovery mode and if we fail a dequeue, we need to notify the ATC to reset.
      if(ismd_queue_dequeue(wl->input_queue, &(wl->cubby_buffer)) != ISMD_SUCCESS) {
         try_to_recover = false;

         if(ismd_event_strobe(atc_render_resync_event) != ISMD_SUCCESS) {
            AUDIO_ERROR("ismd_event_strobe FAILED!", ISMD_ERROR_OPERATION_FAILED, audio_devh[AUDIO_DEBUG_RENDER]);
         }

         //Make sure we sync up all associated renders' timestamps if we hit this condition.
         audio_pvt_render_sync_associated_renders(wl->processor_id);

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_RENDER],
            SVEN_MODULE_EVENT_AUD_IO_RENDER_BEHIND_NOTIFY_ATC, (unsigned int) wl->hw_dev_id, 0, 0, 0, 0, 0);         
      }
      else {     
         
         input_buf_attrib = (audio_buffer_attr_t *) &(wl->cubby_buffer->attributes);
         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_RENDER],
            SVEN_MODULE_EVENT_AUD_IO_RENDER_DEQUEUE,
            (unsigned int) wl->hw_dev_id,
            (unsigned int) wl->cubby_buffer->phys.level, 
            (unsigned int) (input_buf_attrib->local_pts >> 32), 
            (unsigned int) (input_buf_attrib->local_pts),
            (unsigned int) (input_buf_attrib->render_time_stamp >> 32), 
            (unsigned int) (input_buf_attrib->render_time_stamp));
         buffer_time_slot = input_buf_attrib->render_time_stamp;

         //Make sure the calcuation went ok, will return zero if not.
         if((buffer_time_slot != 0) && (wl->cubby_buffer->phys.level != 0)) {

            //If its equal we are done, break out and render
            if(audio_pvt_render_buffer_on_time(wl, input_buf_attrib->audio_format, render_time_slot, buffer_time_slot)) {

               wl->output_buffer = wl->cubby_buffer;
               try_to_recover = false;                 
            }
            //Here we got an early buffer from the queue. 
            else if(buffer_time_slot > render_time_slot) {

               //If the time stamp was within the early range, stop recovery mode.
               if(audio_pvt_render_early_buffer_in_range(wl, render_time_slot, buffer_time_slot)) {
                  wl->output_buffer = NULL;
                  try_to_recover = false;    
               }
               late = false;
            }
         }
         else {
            ismd_audio_buffer_dereference(wl->cubby_buffer->unique_id);
            wl->cubby_buffer = NULL;
         }
      }
   }

   return;
}

static void
audio_pvt_render_prepare_silence_buffer(ismd_audio_render_context_t *wl)
{
   AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_RENDER],
      SVEN_MODULE_EVENT_AUD_IO_RENDER_ADDED_SILENCE,
      (unsigned int) wl->hw_dev_id,
      (unsigned int) wl->silence_buffer->unique_id,
      (unsigned int) wl->silence_buffer->phys.level, 0, 0, 0);

   return;
}

static void
audio_pvt_render_sync_associated_renders(int association_id)
{
   int dev_index = 0;
   int active_renders_count = 0;
   ismd_audio_render_context_t *active_renders[AUDIO_MAX_RENDER_DEVICES];  
   ismd_audio_render_context_t *wl = NULL;
   uint64_t largest_timestamp = 0;
   uint64_t orig_timestamp = 0; //for SVEN

   //Find associated render deivces and get the largest sample count (time stamp)
   for (dev_index = 0; dev_index  < AUDIO_MAX_RENDER_DEVICES; dev_index ++) {
      
      wl = &(render_context[dev_index ]);

      /* Need to only sync renders associated with this processor instance*/
      if (wl->in_use && (association_id == wl->processor_id)) {

         active_renders[active_renders_count] = wl;
         active_renders_count++;
         
         if(wl->samples_rendered > largest_timestamp) {
            largest_timestamp = wl->samples_rendered;
         }
      }
   }

   //We actually only want to do this if we have more than one render active.
   if(active_renders_count > 1) {

      //Set the largest sample count to all associated renders here.
      for (dev_index = 0; dev_index  < active_renders_count; dev_index ++) {

         orig_timestamp = active_renders[dev_index]->samples_rendered;
         active_renders[dev_index]->samples_rendered = largest_timestamp;

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_RENDER],
            SVEN_MODULE_EVENT_AUD_IO_RENDER_SAMPLE_COUNT_RESYNC, 
            (unsigned int) active_renders[dev_index]->hw_dev_id, 
            (unsigned int) (orig_timestamp >> 32), 
            (unsigned int) (orig_timestamp), 
            (unsigned int) (active_renders[dev_index]->samples_rendered >> 32), 
            (unsigned int) (active_renders[dev_index]->samples_rendered), 0);
      }
   }
   
   return;
}

static void
audio_pvt_render_set_buffer_prefill_time( ismd_audio_render_context_t *wl, unsigned int milliseconds)
{
   unsigned int sample_size_bytes = 0 ;

   /*Break down the Sample size*/
   sample_size_bytes = (wl->sample_size /8);

   wl->prefill_bytes_max = (wl->sample_rate * wl->ch_count * sample_size_bytes * milliseconds)/1000;

   wl->prefill_milliseconds = milliseconds;

   return ;
} 

static void
audio_pvt_render_build_pause_burst_hbr( ismd_buffer_descriptor_t * buffer)
{
   unsigned char *out_buf = buffer->virt.base;
   int i = 0;
   int num_of_bursts = 4;//Fill out for worst case in HBR case. 192kHz @ 8ch. This is ok for 5ms also. 

   if(AUDIO_CHUNK_TIME_PERIOD_MS > 10){
      OS_PRINT("Audio Render: Warning: Puase burst build not expecting chunk period greater than 10ms.");
   }

   //We know the exact transmission rate of HBR. So building the buffer appropriately.

   for (i = 0; i<num_of_bursts; i++) {

      out_buf[0] = 0x00;
      out_buf[1] = 0x00;
      out_buf[2] = SPDIF_BURST_PREAMBLE_SYNCWORD_PA_LSB;  /* Pa LSB */
      out_buf[3] = SPDIF_BURST_PREAMBLE_SYNCWORD_PA_MSB; /* Pa MSB */
      out_buf[4] = 0x00;
      out_buf[5] = 0x00;
      out_buf[6] = SPDIF_BURST_PREAMBLE_SYNCWORD_PB_LSB;  /* Pb LSB */
      out_buf[7] = SPDIF_BURST_PREAMBLE_SYNCWORD_PB_MSB;  /* Pb MSB */
      out_buf[8] = 0x00;
      out_buf[9] = 0x00;
      out_buf[10] = 0x03;                                    /* Pc LSB 3 = PAUSE data burst type*/
      out_buf[11] = 0x00;
      out_buf[12] = 0x00;
      out_buf[13] = 0x00;
      out_buf[14] = 0xF8;                                  /* Pd LSB (ES packet size in bits)*/
      out_buf[15] = 0x1D;                                  /* Pd MSB (ES packet size in bits)*/

      //Advance the out_buffer pointer 1/4 of 61440
      out_buf =(unsigned char *)( (int)buffer->virt.base + ((i+1)*15360));

   }


   return;
}


static void
audio_pvt_render_build_pause_burst( void * buffer_addr, int level)
{
   unsigned char *out_buf = (unsigned char *)buffer_addr;
   int framebytes = level - BYTES_NEEDED_FOR_PAUSE_BURST_HEADER;
   
   int losize = (framebytes << 3) & 0xFF;
   int hisize = ((framebytes << 3) >> 8) & 0xFF;

   out_buf[0] = 0x00;
   out_buf[1] = 0x00;
   out_buf[2] = SPDIF_BURST_PREAMBLE_SYNCWORD_PA_LSB;  /* Pa LSB */
   out_buf[3] = SPDIF_BURST_PREAMBLE_SYNCWORD_PA_MSB; /* Pa MSB */
   out_buf[4] = 0x00;
   out_buf[5] = 0x00;
   out_buf[6] = SPDIF_BURST_PREAMBLE_SYNCWORD_PB_LSB;  /* Pb LSB */
   out_buf[7] = SPDIF_BURST_PREAMBLE_SYNCWORD_PB_MSB;  /* Pb MSB */
   out_buf[8] = 0x00;
   out_buf[9] = 0x00;
   out_buf[10] = 0x03;                                    /* Pc LSB 3 = PAUSE data burst type*/
   out_buf[11] = 0x00;
   out_buf[12] = 0x00;
   out_buf[13] = 0x00;
   out_buf[14] = losize;                                  /* Pd LSB (ES packet size in bits)*/
   out_buf[15] = hisize;                                  /* Pd MSB (ES packet size in bits)*/

   return;
}

static void
audio_pvt_render_build_silence_buffer( ismd_buffer_descriptor_t * buffer, int level, ismd_audio_format_t data_format)
{
   //Always memset the buffer to create silence or padding for pause burst. 
   OS_MEMSET(buffer->virt.base, 0, buffer->phys.size);
   
   switch(data_format){
      
      case ISMD_AUDIO_MEDIA_FMT_DD:
      case ISMD_AUDIO_MEDIA_FMT_DTS:
      case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:
      case ISMD_AUDIO_MEDIA_FMT_AAC:
         audio_pvt_render_build_pause_burst( buffer->virt.base, level);
         break;

      case ISMD_AUDIO_MEDIA_FMT_TRUE_HD:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA:
         audio_pvt_render_build_pause_burst_hbr( buffer);
         break;
         
      //Unsupported or PCM cases, all silence. 
      case ISMD_AUDIO_MEDIA_FMT_PCM:
      case ISMD_AUDIO_MEDIA_FMT_MPEG:
      case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA:
      case ISMD_AUDIO_MEDIA_FMT_WM9:
      case ISMD_AUDIO_MEDIA_FMT_DTS_LBR:       
      case ISMD_AUDIO_MEDIA_FMT_INVALID: 
      default:
         break;
   }

   return ;
} 


