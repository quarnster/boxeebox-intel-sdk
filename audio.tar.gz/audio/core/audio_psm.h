/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_PSM_H_
#define _AUDIO_PSM_H_

#include "audio_core.h"
#include "ismd_audio_defs.h"
#include "audio_psm_defs.h"

/* Initialize the PSM.  One time call at driver load. */
ismd_result_t audio_psm_initialize( void );

/* De-initialize the PSM.  One time call at driver unload. */
ismd_result_t audio_psm_deinitialize( void );

/* 
Allocate a new pipe.
@param[in] type : type of the pipe.  This is for future-proofing the API.
@param[out] pipe_handle : handle to the new pipe.
*/
ismd_result_t audio_psm_pipe_alloc( audio_psm_pipe_type_t   type, 
                         				audio_psm_pipe_handle_t *pipe_handle );

/* 
Free a pipe.
@param[in] pipe_handle : handle to a pipe.
*/
ismd_result_t audio_psm_pipe_free( audio_psm_pipe_handle_t pipe_handle );

/* 
Start data flowing through a pipe.
@param[in] pipe_handle : handle to a pipe.
*/
ismd_result_t audio_psm_pipe_start( audio_psm_pipe_handle_t pipe_handle );

/* 
Set the handle to a lock that gaurds the input queues from dequeue-ing at the wrong time.
@param[in] pipe_handle : handle to a pipe.
*/
ismd_result_t audio_psm_pipe_set_input_queue_lock( audio_psm_pipe_handle_t pipe_handle, os_mutex_t *input_queue_lock );

/* 
Stop data flowing through a pipe.
@param[in] pipe_handle : handle to a pipe.
*/
ismd_result_t audio_psm_pipe_stop( audio_psm_pipe_handle_t pipe_handle );

/* 
Flush the output queues connected to each pipe.
@param[in] pipe_handle : handle to a pipe.
*/
ismd_result_t audio_psm_pipe_flush( audio_psm_pipe_handle_t pipe_handle );

/*
Retrieve the physical address of a stage.
@param[in] stage_handle : handle to a stage.
@param[out] stage_addr : physical address of the stage.
*/
ismd_result_t 
audio_psm_pipe_get_stage_phys_address( audio_psm_stage_handle_t stage_handle, 
                                       int32_t                *stage_addr );

/* 
Check to see if a pipe has the ability to decode with a certain codec.
@param[in] pipe_handle : handle to a pipe.
*/
ismd_result_t audio_psm_codec_available( audio_psm_pipe_handle_t pipe_handle, uint8_t dsp_num, codecs_available_t *codec_status );

/* 
Gets the version string info of a certain codec.
@param[in] pipe_handle : handle to a pipe.
*/
ismd_result_t audio_psm_get_codec_ver_string( audio_psm_pipe_handle_t pipe_handle, uint8_t dsp_num, ismd_audio_format_t codec, char *codec_ver_string );

/* 
Add a stage to a pipe.
@param[in] pipe_handle : handle to a pipe.
@param[in] stage_type : type of stage to add.
@param[out] stage_handle : handle to the new stage.
*/
ismd_result_t audio_psm_stage_add( audio_psm_pipe_handle_t            pipe_handle, 
	                         			audio_psm_stage_task_t  			stage_task,
  	                                 uint32_t 								input_count, 
	                                 uint32_t 								output_count,	                         			
	                                 audio_psm_stage_handle_t         *stage_handle);

/* 
Configure a pipe stage.
@param[in] pipe_handle : handle to a pipe.
@param[in] stage_handle : handle to a stage.
@param[in] stage_params : configuration parameters for the stage.
*/
ismd_result_t audio_psm_stage_config( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      audio_psm_stage_params_t *stage_params );


ismd_result_t audio_psm_stage_config_direct( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      audio_psm_stage_params_t *stage_params);


ismd_result_t audio_psm_stage_config_metadata( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      audio_psm_stage_connection_metadata_t *metadata );

/* 
Get the configuration of the stage. This is helpful if your stage has an 
aux buffer and the dsp_phys_address has been set, you will need to 
query this funtion then set the new parameters then set back the config.
@param[in] pipe_handle : handle to a pipe.
@param[in] stage_handle : handle to a stage.
@param[out] stage_params : configuration parameters for the stage.
*/
ismd_result_t audio_psm_stage_get_config( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      audio_psm_stage_params_t *stage_params );

/* 
Get a pointer to the stage configuration structure.  Useful if, for example, you want to modify certain parameters
and notify the host of these changes.

@param[in] pipe_handle : handle to a pipe.
@param[in] stage_handle : handle to a stage.
@param[out] stage_params : pointer to the configuration parameters for the stage.
*/
ismd_result_t audio_psm_stage_get_config_pointer( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      audio_psm_stage_params_t **stage_params );


ismd_result_t audio_psm_stage_get_stream_info( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      ismd_audio_format_specific_stream_info_t *stream_info );

/* 
Add an input_queue to a pipe.
@param[in] pipe_handle : handle to a pipe.
@param[in] queue_handle : handle to a queue.
@param[in] output_id : id of the output of the input stage. 
*/
ismd_result_t audio_psm_input_queue_add( audio_psm_pipe_handle_t  pipe_handle, 
			                                  ismd_queue_handle_t queue_handle, 
			                                  int output_id);

/* 
Remove an input_queue from a pipe.
@param[in] pipe_handle : handle to a pipe.
@param[in] queue_handle : handle to a queue.
*/
ismd_result_t audio_psm_input_queue_remove( audio_psm_pipe_handle_t  pipe_handle, 
				                                  	ismd_queue_handle_t queue_handle);

/* 
Add an output_queue to a pipe.
@param[in] pipe_handle : handle to a pipe.
@param[in] queue_handle : handle to a queue.
@param[in] input_id : id of the input of the output stage. 
*/
ismd_result_t audio_psm_output_queue_add( audio_psm_pipe_handle_t  pipe_handle, 
			                                  ismd_queue_handle_t output_queue, 
			                                  int input_id);


/* 
Remove an output_queue from a pipe.
@param[in] pipe_handle : handle to a pipe.
@param[in] queue_handle : handle to a queue.
*/
ismd_result_t audio_psm_output_queue_remove( audio_psm_pipe_handle_t  pipe_handle, 
				                                  ismd_queue_handle_t output_queue);

ismd_result_t audio_psm_output_queue_disable( audio_psm_pipe_handle_t  pipe_handle, 
				                                  		ismd_queue_handle_t queue_handle);

ismd_result_t audio_psm_output_queue_enable( audio_psm_pipe_handle_t  pipe_handle, 
				                                  		ismd_queue_handle_t queue_handle);


/** 
Allocates an SMD buffer of the specified size, initializes the PSM buffer descriptor.
The smd buffer descriptor is stored in the psm buffer descriptor. 
@param[in] psm_buf : Pointer to the PSM buffer descriptor.
@param[in] size : Size of the buffer to allocate. 
*/
ismd_result_t audio_psm_buffer_allocate(audio_psm_buf_desc_t *psm_buf, int size);

/** 
Frees a SMD buffer using the PSM buffer descriptor. Resets the PSM descriptor. 
@param[in] psm_buf : Pointer to the PSM buffer descriptor.
*/
ismd_result_t audio_psm_buffer_free(audio_psm_buf_desc_t *psm_buf);

/* 
Connect two pipe stages together.  Connects the output of one stage to 
the input of another stage.  
@param[in] pipe_handle : handle to a pipe.
@param[in] output_stage_handle : handle to stage with an output.
@param[in] output_id : id of the ouput in the output stage.
@param[in] input_stage_handle : handle to stage with an input.
@param[in] input_id : id of the input in the output stage.
*/
ismd_result_t audio_psm_stage_connect( audio_psm_pipe_handle_t  pipe_handle, 
	                                      audio_psm_stage_handle_t output_stage_handle, 
	                                      int                		output_id,
	                                      audio_psm_stage_handle_t input_stage_handle,
	                                      int                		input_id );

ismd_result_t audio_psm_resume(void);
ismd_result_t audio_psm_suspend(void);



#if 0
/* 
Disconnect a stage.

Don't think we actually need this if we can just assume that a connect will 
also be able to re-connect (i.e. succeed even if either the input or output 
is already connected).
*/

ismd_result_t audio_psm_stage_disconnect( audio_psm_pipe_handle_t  pipe_handle, 
		                                         audio_psm_stage_handle_t stage_handle, 
      		                                   bool		               input, /* is it an input or an output */
            		                             int      			         id ); /* the input or output id */

#endif
#endif
