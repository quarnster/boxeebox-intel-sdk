/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/*
* File Name: ismd_audio_timing_control.c
*/

#include "audio_timing_control.h"
#include "audio_timing_control_pvt.h"
#include "audio_apm_common.h"
#include "ismd_core.h"

/* Global ATC device, stores ATC and ATC stream workloads etc. */
static audio_atc_device_t atc_device;
os_devhandle_t *atc_devh = NULL;
static int atc_discontinuity = ATC_DEFAULT_MS_DISCONTINUITY;

ismd_result_t
audio_timing_control_initialize(void)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   int loop = 0;
   int enable_timed_trick_modes = 1;
   atc_devh = audio_devh[AUDIO_DEBUG_ATC];

   AUDIO_ENTER(atc_devh);

   (void)audio_pvt_atc_output_queue_io_callback;

   /* Get Platform Config options for the ATC.*/
   AUDIO_CONFIG_GET_ENABLE_TIMED_TRICK_MODES(enable_timed_trick_modes);
   AUDIO_CONFIG_GET_ATC_DISCONTINUITY(atc_discontinuity);

   /* Initialize Device variables */
   atc_device.enable_timed_trick_modes = enable_timed_trick_modes;
   atc_device.start_to_close = false;
   atc_device.queue_io_event = ISMD_EVENT_HANDLE_INVALID;
   atc_device.clock_alarm_event = ISMD_EVENT_HANDLE_INVALID;
   atc_device.event_list_count = 0;
   atc_device.timer_clock_alarm_h = ISMD_CLOCK_HANDLE_INVALID;
   atc_device.default_clock_h = ISMD_CLOCK_HANDLE_INVALID;
   atc_device.primary_clock_h = ISMD_CLOCK_HANDLE_INVALID;
   atc_device.timer_clock_h = ISMD_CLOCK_HANDLE_INVALID;
   atc_device.last_clock_alarm_time = 0;
   atc_device.timer_clock_stream_wl = NULL;
   atc_device.clock_alarm_period = 0;
   atc_device.clk_mode = ISMD_AUDIO_CLK_LOCKED; 
   atc_device.render_prev_sample_count = 0;
   atc_device.render_no_sample_change_count = 0;

   atc_device.wait_with_timeout = false;

   os_irqlock_init(&(atc_device.irq_lock));

   if(os_mutex_init(&(atc_device.lock)) != OSAL_SUCCESS){
      AUDIO_ERROR("atc semaphore init failed!", ISMD_ERROR_OPERATION_FAILED, atc_devh);
      result = ISMD_ERROR_OPERATION_FAILED;
   }

   /*Init all locks and ATC workloads*/
   for(loop = 0; loop < AUDIO_MAX_ATC_CONTEXTS; loop++)
   {
      if(os_mutex_init(&(atc_device.atc_contexts[loop].lock)) != OSAL_SUCCESS){
         result = ISMD_ERROR_OPERATION_FAILED;
         AUDIO_ERROR("atc semaphore init failed!", result, atc_devh);
      } 

      /* Initialize workload for each context */
      audio_pvt_atc_init_wl(&(atc_device.atc_contexts[loop]));
   }

   if((result = ismd_event_alloc(&atc_device.queue_io_event)) != ISMD_SUCCESS){
      AUDIO_ERROR("queue_io_event event_alloc failed!", result, atc_devh);
   }

   if((result = ismd_event_alloc(&atc_device.clock_alarm_event)) != ISMD_SUCCESS){
      AUDIO_ERROR("clock_alarm event_alloc failed!", result, atc_devh);
   }

   /* Alloc the clock handle that will be used if no clock present */
   else if((result = ismd_clock_alloc(ISMD_CLOCK_TYPE_FIXED, &atc_device.default_clock_h)) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_clock_alloc failed!", result, atc_devh);
   }
   else if((result = ismd_clock_make_primary(atc_device.default_clock_h)) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_clock_make_primary failed!", result, atc_devh);
   }
   else {

      audio_pvt_atc_add_event_to_list( &atc_device, atc_device.clock_alarm_event);
      audio_pvt_atc_add_event_to_list( &atc_device, atc_device.queue_io_event);
      audio_pvt_atc_add_event_to_list( &atc_device, atc_render_resync_event);

      //Set the timer clock to our reserve clock by default.
      audio_pvt_atc_set_new_alarm_clock(&atc_device, atc_device.default_clock_h, AUDIO_CHUNK_TIME_PERIOD_MS);
   }

   /* Create the thread that will handle all ATC contexts. */
   if((create_prioritized_thread(&(atc_device.atc_manager_thread), audio_pvt_atc_manager_thread, (void *)&atc_device, 0, "Audio_Timing")) != OSAL_SUCCESS){      
      AUDIO_OSAL_ERROR("create_prioritized_thread failed!", result, atc_devh);
   }


   AUDIO_EXIT(atc_devh);

   return result;
}


ismd_result_t
audio_timing_control_deinitialize(void)
{
   ismd_result_t result = ISMD_SUCCESS;
   int loop = 0;

   AUDIO_ENTER(atc_devh);

   /* Shut down the thread. */
   atc_device.start_to_close = true;

   /* Strobe the event the thread might be waiting on.*/
   if((result = ismd_event_strobe(atc_device.queue_io_event)) != ISMD_SUCCESS){
      AUDIO_ERROR("event_set queue_io_event failed!", result, atc_devh);
   }

   if(os_thread_wait(&(atc_device.atc_manager_thread),1) != OSAL_SUCCESS){      
      AUDIO_OSAL_ERROR("os_thread_wait failed ", result, atc_devh);
   }

   if(os_thread_destroy(&(atc_device.atc_manager_thread)) != OSAL_SUCCESS){      
      AUDIO_OSAL_ERROR("os_thread_destroy failed ", result, atc_devh);
   }

   audio_pvt_atc_remove_event_from_list( &atc_device, atc_device.clock_alarm_event);
   audio_pvt_atc_remove_event_from_list( &atc_device, atc_device.queue_io_event);

   /*Deinit all semaphores*/
   for(loop = 0; loop < AUDIO_MAX_ATC_CONTEXTS; loop++)
   {
      /*Ensure all instances are closed*/
      if(atc_device.atc_contexts[loop].in_use){
         audio_timing_control_close(atc_device.atc_contexts[loop].handle);
      }
      os_mutex_destroy(&(atc_device.atc_contexts[loop].lock));
   }

   if((result = ismd_event_free(atc_device.queue_io_event)) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_event_free failed!", result, atc_devh);
   }

   if((result = ismd_event_free(atc_device.clock_alarm_event)) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_event_free failed!", result, atc_devh);
   }

   if((result = ismd_clock_free(atc_device.default_clock_h)) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_clock_free failed!", result, atc_devh);
   }

   os_mutex_destroy(&(atc_device.lock));
   
   os_irqlock_destroy(&(atc_device.irq_lock));

   AUDIO_EXIT(atc_devh);
   atc_devh = NULL;

   return result;
}

ismd_result_t
audio_timing_control_open(audio_atc_t *atc_h, int association_id)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_t handle = AUDIO_INVALID_HANDLE;
   audio_atc_context_t *wl = NULL;
   int transition_protection_buffer_size = 0;

   AUDIO_ENTER(atc_devh);

   *atc_h = AUDIO_INVALID_HANDLE;

   /*Check for an available atc instance, and return the handle.*/
   for (handle=0; handle < AUDIO_MAX_ATC_CONTEXTS; handle++) {

      wl = &(atc_device.atc_contexts[handle]);

      audio_pvt_atc_lock( wl );

      /*We have a free instance if not in use*/
      if (!wl->in_use) {

         /* Fill in context variables */
         wl->in_use = true;
         wl->handle = handle;
         wl->dev_wl = &atc_device;
         wl->clock_alarm_event = atc_device.clock_alarm_event;
         wl->processor_id = association_id;
         *atc_h  = handle;

         /*See if we have a buffer for transition protection in the de-interleaver for this processor. */
         AUDIO_CONFIG_GET_MEMORY_LAYOUT_BUFFER_SIZE("smd_buffers_AUD_TRANS_PROTECT_", association_id, transition_protection_buffer_size);         
         wl->transition_protection_enabled = (transition_protection_buffer_size == 0) ? false : true;
   
        /*Avoided using break in loop*/
        handle = AUDIO_MAX_ATC_CONTEXTS;
      }

      audio_pvt_atc_unlock(wl);
   }

   /*Return failure if handle still invalid*/
   result = (*atc_h == AUDIO_INVALID_HANDLE) ? ISMD_ERROR_NO_RESOURCES : ISMD_SUCCESS;

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_close(audio_atc_t atc_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_context_t *wl = NULL;
   int loop = 0;

   AUDIO_ENTER(atc_devh);

   audio_pvt_atc_dev_lock(&atc_device);

   if((result = audio_pvt_atc_lock_and_get_wl(atc_h, &wl)) == ISMD_SUCCESS) {

      wl->start_to_close = true;
      wl->in_use = false;

      /* Remove all streams attached to this ATC context */
      for(loop = 0; loop < AUDIO_MAX_ATC_STREAMS; loop++)
      {
         if(wl->streams[loop].in_use){
            audio_pvt_atc_stream_remove(wl, wl->streams[loop].handle);
         }
      }

      /*Set context back to default settings.*/
      audio_pvt_atc_init_wl(wl);

      audio_pvt_atc_unlock(wl);
   }
   else{
      AUDIO_ERROR("atc_lock_and_get_wl failed!", result, atc_devh);
   }

   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_change_chunk_period(audio_atc_t atc_h, int chunk_period)
{
   ismd_result_t result = ISMD_SUCCESS;

   audio_atc_context_t *atc_wl = NULL;

   AUDIO_ENTER(atc_devh);

   audio_pvt_atc_dev_lock(&atc_device);

   if((result = audio_pvt_atc_lock_and_get_wl(atc_h, &atc_wl)) == ISMD_SUCCESS) {

      // dev_wl->timer_clock_h should valid at this time.
      OS_ASSERT(atc_wl->dev_wl->timer_clock_h != ISMD_CLOCK_HANDLE_INVALID);

      result = audio_pvt_atc_set_new_alarm_clock(atc_wl->dev_wl, atc_wl->dev_wl->timer_clock_h, chunk_period);
      if (result != ISMD_SUCCESS) {
         AUDIO_ERROR("audio_timing_control_change_chunk_period failed to change chunk period.", result, atc_devh);
      }

      audio_pvt_atc_unlock(atc_wl);
   }
   else{
      AUDIO_ERROR("atc_lock_and_get_wl failed!", result, atc_devh);
   }

   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_get_clock_alarm_period(audio_atc_t atc_h, int *chunk_period)
{
   ismd_result_t result = ISMD_SUCCESS;

   audio_atc_context_t *atc_wl = NULL;

   AUDIO_ENTER(atc_devh);

   audio_pvt_atc_dev_lock(&atc_device);

   if((result = audio_pvt_atc_lock_and_get_wl(atc_h, &atc_wl)) == ISMD_SUCCESS) {

      OS_ASSERT(chunk_period != NULL);
      *chunk_period = atc_wl->dev_wl->clock_alarm_period;

      audio_pvt_atc_unlock(atc_wl);
   }
   else{
      AUDIO_ERROR("atc_lock_and_get_wl failed!", result, atc_devh);
   }

   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_clock_t *
audio_timing_control_get_timer_clock()
{
   ismd_clock_t *timer_clock_h;

   AUDIO_ENTER(atc_devh);

   //Lock down the Device and ATC since we have update them with primary and timer clock info.
   audio_pvt_atc_dev_lock(&atc_device);

   timer_clock_h = &(atc_device.timer_clock_h);

   /* Unlock down the device */
   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return (timer_clock_h);
}


ismd_result_t
audio_timing_control_set_clock_mode(ismd_audio_clk_mode_t clk_mode)
{
   ismd_result_t result = ISMD_SUCCESS;

   AUDIO_ENTER(atc_devh);

   audio_pvt_atc_dev_lock(&atc_device);

   atc_device.clk_mode = clk_mode;

   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_set_output_queue_lock( audio_atc_t atc_h, os_mutex_t *output_queue_lock)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_context_t *wl = NULL;

   AUDIO_ENTER(atc_devh);

   if((result = audio_pvt_atc_lock_and_get_wl(atc_h, &wl)) == ISMD_SUCCESS) {

      wl->output_queue_lock = output_queue_lock;

      audio_pvt_atc_unlock(wl);
   }
   else{
      AUDIO_ERROR("atc_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_get_message_context
(
   audio_atc_t atc_h,
   audio_atc_stream_t atc_stream_h,
   uint32_t *message_context
)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_context_t *wl = NULL;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   if((result = audio_pvt_atc_lock_and_get_wl(atc_h, &wl)) == ISMD_SUCCESS){
      stream_wl = &(wl->streams[atc_stream_h]);
      *message_context = stream_wl->message_context;
      audio_pvt_atc_unlock(wl);
   }
   else{
      AUDIO_ERROR("atc_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_add_stream
(
   audio_atc_t atc_h,
   bool is_timed_stream,
   bool is_encoded_data,
   ismd_queue_handle_t input_queue,
   ismd_queue_handle_t output_queue,
   const ismd_event_t event_list[],
   int input_smd_h,
   audio_atc_stream_t *atc_stream_h
)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_context_t *wl = NULL;
   audio_atc_stream_context_t *stream_wl = NULL;
   audio_atc_stream_t handle = AUDIO_INVALID_HANDLE;

   AUDIO_ENTER(atc_devh);

   *atc_stream_h = AUDIO_INVALID_HANDLE;

   if((result = audio_pvt_atc_lock_and_get_wl(atc_h, &wl)) == ISMD_SUCCESS){

      for (handle=0; handle < AUDIO_MAX_ATC_STREAMS; handle++) {

         stream_wl = &(wl->streams[handle]); 
         if(!stream_wl->in_use){

         //   if((result = ismd_queue_connect_input(output_queue,(ismd_producer_func_t) audio_pvt_atc_output_queue_io_callback, (void*) wl->dev_wl, ISMD_QUEUE_WATERMARK_NONE)) != ISMD_SUCCESS){
         //      AUDIO_ERROR("queue_connect failed!", result, atc_devh);
         //   }
            if((result = ismd_queue_connect_output(input_queue, (ismd_consumer_func_t) audio_pvt_atc_input_queue_io_callback, (void*)stream_wl, ISMD_QUEUE_WATERMARK_NONE)) != ISMD_SUCCESS){
               AUDIO_ERROR("queue_connect failed!", result, atc_devh);
            }
            else if((result = ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS, (64 * 1024), &stream_wl->drop_buffer)) != ISMD_SUCCESS){
               AUDIO_ERROR("ismd_audio_buffer_alloc_typed_direct failed!", result, atc_devh);
            }
            else if((result = ismd_message_context_alloc(&stream_wl->message_context)) != ISMD_SUCCESS) {
               AUDIO_ERROR("ismd_message_context_alloc failed!", result, atc_devh);
            } 
            else{
               stream_wl->handle = handle;
               stream_wl->in_use = true;
               stream_wl->input_queue = input_queue;
               stream_wl->output_queue = output_queue;
               stream_wl->is_timed_stream = is_timed_stream;
               stream_wl->is_encoded_data = is_encoded_data;
               stream_wl->atc_wl = wl;
               stream_wl->notif_events = event_list;
               // update chunk size period time
               stream_wl->time_period_ms = AUDIO_CORE_GET_CHUNK_PERIOD(stream_wl->atc_wl);
               stream_wl->fixed_back_end_delay_ms = FIXED_BACK_END_PIPE_DELAY_CHUNK * stream_wl->time_period_ms;
               stream_wl->input_smd_h = input_smd_h;

               wl->active_stream_count++;
               *atc_stream_h = handle;

               handle = AUDIO_MAX_ATC_STREAMS;
            }
         } 
      }

      result = (*atc_stream_h == AUDIO_INVALID_HANDLE) ? ISMD_ERROR_NO_RESOURCES : ISMD_SUCCESS;

      audio_pvt_atc_unlock(wl);
   }
   else{
      AUDIO_ERROR("atc_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;
}


ismd_result_t
audio_timing_control_remove_stream( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_context_t *wl = NULL;

   AUDIO_ENTER(atc_devh);

   //Need to lock on remove, since we check for a new clock adjustment.
   audio_pvt_atc_dev_lock(&atc_device);

   if(((result = audio_pvt_atc_lock_and_get_wl(atc_h, &wl)) == ISMD_SUCCESS)){ 

      result = audio_pvt_atc_stream_remove(wl, atc_stream_h);
 
      audio_pvt_atc_unlock(wl);
   }
   else{
      AUDIO_ERROR("atc_lock_and_get_wl failed!", result, atc_devh);
      os_backtrace();
   }

   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_set_stream_pos_mem_locaton(audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_audio_stream_position_info_t *stream_pos_ptr)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS){

      stream_wl->stream_pos_shared = stream_pos_ptr;

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else{
      AUDIO_ERROR("audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;

}


ismd_result_t
audio_timing_control_set_silence_insert(audio_atc_t atc_h, bool insert_silence)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_context_t *wl = NULL;

   AUDIO_ENTER(atc_devh);

   if(((result = audio_pvt_atc_lock_and_get_wl(atc_h, &wl)) == ISMD_SUCCESS)){

      wl->insert_silence = insert_silence;

      audio_pvt_atc_unlock(wl);
   }
   else{
      AUDIO_ERROR("atc_lock_and_get_wl failed!", result, atc_devh);
      os_backtrace();
   }

   AUDIO_EXIT(atc_devh);
   return result;
}


ismd_result_t
audio_timing_control_set_fast_output(audio_atc_t atc_h, bool fast_output)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_context_t *wl = NULL;

   AUDIO_ENTER(atc_devh);

   if(((result = audio_pvt_atc_lock_and_get_wl(atc_h, &wl)) == ISMD_SUCCESS)){

      wl->fast_output = fast_output;

      audio_pvt_atc_unlock(wl);
   }
   else{
      AUDIO_ERROR("atc_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;
}


ismd_result_t
audio_timing_control_stream_set_fast_output(audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, bool fast_output)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS){

      stream_wl->fast_output = fast_output;

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else{
      AUDIO_ERROR("audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;
}


ismd_result_t
audio_timing_control_set_output_discard_policy(audio_atc_t atc_h, atc_output_discard_policy_t discard_policy)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_context_t *wl = NULL;

   AUDIO_ENTER(atc_devh);

   if(((result = audio_pvt_atc_lock_and_get_wl(atc_h, &wl)) == ISMD_SUCCESS)){

      wl->output_discard_policy = discard_policy;

      audio_pvt_atc_unlock(wl);
   }
   else{
      AUDIO_ERROR("atc_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;
}


ismd_result_t
audio_timing_control_set_base_time( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_time_t base_time)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS){

      if(stream_wl->state != ISMD_DEV_STATE_PLAY) {

         stream_wl->smd_base_time = base_time;
         stream_wl->stream_pos.base_time = base_time;

         audio_pvt_atc_reset_for_new_stream(stream_wl);

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
            SVEN_MODULE_EVENT_AUD_IO_ATC_SET_BASE_TIME,
            (unsigned int) atc_h,
            (unsigned int) atc_stream_h,
            (unsigned int) (base_time>>32),
            (unsigned int) (base_time), 0, 0);
      }
      else {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("ATC cannot set base time while in a playing state!", result, atc_devh);
      }

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else{
      AUDIO_ERROR("audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;
}


ismd_result_t
audio_timing_control_set_as_primary( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;
   audio_atc_context_t *atc_wl = NULL;

   AUDIO_ENTER(atc_devh);

   //Lock down the Device and ATC since we have update them with primary and timer clock info.
   audio_pvt_atc_dev_lock(&atc_device);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS){

      atc_wl = stream_wl->atc_wl;
      result = ISMD_ERROR_INVALID_REQUEST;

      /* If we dont have a primary stream, or its the primary stream, take action.*/
      if((atc_wl->primary_stream_wl == NULL) || (atc_wl->primary_stream_wl == stream_wl)){

         stream_wl->is_primary = true;
         atc_wl->primary_stream_wl = stream_wl;
         atc_wl->dev_wl->timer_clock_stream_wl = stream_wl;//Make sure the device knows about which wl has the timer clock.
         result = ISMD_SUCCESS;

         //If this streams clock handle is already set and its not the primary clock, need to set it as the primary clock.
         if((stream_wl->clock_h != ISMD_CLOCK_HANDLE_INVALID) && (atc_wl->dev_wl->primary_clock_h != stream_wl->clock_h) ){

            atc_wl->dev_wl->primary_clock_h = stream_wl->clock_h;
            result = audio_pvt_atc_set_new_alarm_clock(atc_wl->dev_wl, stream_wl->clock_h, AUDIO_CORE_GET_CHUNK_PERIOD(atc_wl));
         }
      }
      audio_pvt_atc_unlock(atc_wl);
   }
   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return result;
}


ismd_result_t
audio_timing_control_set_clock( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_clock_t clock_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;
   audio_atc_context_t *atc_wl = NULL;

   AUDIO_ENTER(atc_devh);

   //Lock down the Device and ATC since we have update them with primary and timer clock info.
   audio_pvt_atc_dev_lock(&atc_device);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS){

      atc_wl = stream_wl->atc_wl;
      stream_wl->clock_h = clock_h;

      /*If run in original time domain, 
       *register the clock discontinuity event
       */
      if(stream_wl->timing_mode == ISMD_TIMING_MODE_ORIGINAL && stream_wl->discontinuity_event != ISMD_EVENT_HANDLE_INVALID) {
         ismd_clock_set_time_discontinuity_event(stream_wl->clock_h, stream_wl->discontinuity_event, ATC_MAX_CLOCK_DRIFT);
      }
      else{
         ismd_clock_set_time_discontinuity_event(stream_wl->clock_h, ISMD_EVENT_HANDLE_INVALID, ATC_MAX_CLOCK_DRIFT);
      }

      /* Check the device to see if we already have a handle.*/
      if(atc_wl->dev_wl->timer_clock_h == ISMD_CLOCK_HANDLE_INVALID) {

         /* Check to see if its a timed stream, if so, set it as primary*/
         if(stream_wl->is_timed_stream && stream_wl->is_primary) {
            atc_wl->dev_wl->primary_clock_h = clock_h;
         }
         result = audio_pvt_atc_set_new_alarm_clock(atc_wl->dev_wl, clock_h, AUDIO_CORE_GET_CHUNK_PERIOD(atc_wl));
      }

      /*We have a clock, but its not a primary clock, reset the clock alarm to the new clock*/
      else if(stream_wl->is_primary && (atc_wl->dev_wl->primary_clock_h == ISMD_CLOCK_HANDLE_INVALID)){

         atc_wl->dev_wl->primary_clock_h = clock_h;
         result = audio_pvt_atc_set_new_alarm_clock(atc_wl->dev_wl, clock_h, AUDIO_CORE_GET_CHUNK_PERIOD(atc_wl));
      }

      AUDIO_EVENT(1, atc_devh,
         SVEN_MODULE_EVENT_AUD_IO_ATC_SET_CLOCK,
         (unsigned int) atc_h,
         (unsigned int) atc_stream_h,
         (unsigned int) clock_h,
         (unsigned int) stream_wl->time_period_ms, 0, 0);

      audio_pvt_atc_unlock(atc_wl);
   }

   /* Unlock down the device */
   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_get_stream_info( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, audio_buffer_attr_t *stream_info)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS){

      stream_info->audio_format = stream_wl->curr_stream_info.audio_format;
      stream_info->bitrate = stream_wl->curr_stream_info.bitrate;
      stream_info->sample_rate = stream_wl->curr_stream_info.sample_rate;
      stream_info->sample_size = stream_wl->curr_stream_info.sample_size;
      stream_info->channel_config = stream_wl->curr_stream_info.channel_config;
      stream_info->channel_count  = stream_wl->curr_stream_info.channel_count;

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else{
      AUDIO_ERROR("audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_set_state( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_dev_state_t state)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;
   bool send_final_buffer_with_discont_mda = false;

   AUDIO_ENTER(atc_devh);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS){

      /*Only need to do anything if we are actually changing states.*/
      if(state != stream_wl->state) {
         switch(state)
         {
            case ISMD_DEV_STATE_PAUSE:
               stream_wl->underrun_amount = 0;
               stream_wl->underrun_count = 0;

               /*If we are transitioning from play to pause and have not 
                 found the start of segment, we didn't get the new segment, 
                 need to force this to true so we will pause correctly. The next 
                 time we get a new segment it will clear this to false and fire
                 the start of segment event, as it should. This is a robustness
                 case to handle if the app never sends a new segment. */
                  if(stream_wl->state == ISMD_DEV_STATE_PLAY) {

                     if(!stream_wl->start_of_seg_found) {
                        stream_wl->start_of_seg_found = true;
                     }
                     /*Tranistioning to puase, need to notify next output buffer to ramp down.*/
                     send_final_buffer_with_discont_mda = true;
                  }
               break;
            case ISMD_DEV_STATE_STOP:
               stream_wl->underrun_amount = 0;
               stream_wl->underrun_count = 0;
               /*Tranistioning to stop from play, notify to send */
               if(stream_wl->state == ISMD_DEV_STATE_PLAY) {
                  send_final_buffer_with_discont_mda = true;
               }
               break;
            case ISMD_DEV_STATE_PLAY:
                  /*Tranistioning to play, need to notify next output buffer to ramp up.*/
                  stream_wl->add_ramp_up_mda = true;
               break;
            case ISMD_DEV_STATE_INVALID:
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ATC: Invalid state!", result, atc_devh);
               break;
         }
      }


      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM], SVEN_MODULE_EVENT_AUD_IO_ATC_SET_STATE,
         atc_h, atc_stream_h, stream_wl->state, state, 0, 0);

      /*Send the final buffer if needed, before we unlock.*/
      if(send_final_buffer_with_discont_mda) {
         audio_pvt_atc_discont_mda_send_last_buffer(stream_wl);
      }

      stream_wl->state = state;
      
      audio_pvt_atc_unlock(stream_wl->atc_wl);

   }
   else{
      AUDIO_ERROR("audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_get_state( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_dev_state_t *state)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS){

      *state = stream_wl->state;

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else{
      AUDIO_ERROR("audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_flush( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h )
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS){

      audio_pvt_atc_discont_mda_send_last_buffer(stream_wl);

      /*Reset all state for a new stream, this frees up in/out cubby buffers also.*/
      audio_pvt_atc_reset_for_new_stream(stream_wl);

      //Need to reset our segment state info on a flush.
      stream_wl->rebase_info.curr_seg_info.linear_start = 0;
      stream_wl->rebase_info.curr_seg_info.start = ISMD_NO_PTS;
      stream_wl->rebase_info.curr_seg_info.stop = ISMD_NO_PTS;
      stream_wl->rebase_info.curr_seg_info.requested_rate = ISMD_NORMAL_PLAY_RATE;
      stream_wl->rebase_info.last_linear_rate_change_time = 0;
      stream_wl->rebase_info.last_scaled_rate_change_time = 0;
      stream_wl->rebase_info.curr_rate = ISMD_NORMAL_PLAY_RATE;
      stream_wl->rate                  = ISMD_NORMAL_PLAY_RATE;
      stream_wl->has_newsegment = false;
      stream_wl->have_eos = false;
      stream_wl->start_of_seg_found = false;

      /* Reset for new stream */
      stream_wl->interpolated_info.segment_pts = ISMD_NO_PTS;
      stream_wl->interpolated_info.linear_pts = ISMD_NO_PTS;
      stream_wl->interpolated_info.local_pts = ISMD_NO_PTS;
      stream_wl->interpolated_info.adjust_ticks = 0;

      //Dont ignore inband rate change anymore.
      stream_wl->ignore_inband_rate_change = false;
      //Reset linear_start_pts if user call flush.
      stream_wl->linear_start_pts = ISMD_NO_PTS;
      
      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else{
      AUDIO_ERROR("audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh);
   }

   AUDIO_EXIT(atc_devh);

   return result;
}

ismd_result_t
audio_timing_control_set_playback_rate( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_pts_t current_linear_time, int rate )
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;
   ismd_time_t scaled_rate_change_time;

   AUDIO_ENTER(atc_devh);

   if ( (result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl )) == ISMD_SUCCESS ) {

      if (stream_wl->state == ISMD_DEV_STATE_PLAY) {
         AUDIO_ERROR("Cannot set playback rate while in a playing state.", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
            SVEN_MODULE_EVENT_AUD_IO_APM_INPUT_SET_PLAY_RATE,
            stream_wl->atc_wl->handle,
            stream_wl->handle,
            rate,
            (unsigned int) ( current_linear_time >> 32 ),
            (unsigned int) ( current_linear_time ), 0);

         /* If we are in timed mode and the rate is actually changing, update state.*/
         if(stream_wl->is_timed_stream && (rate != stream_wl->rebase_info.curr_rate)) {

            ismd_convert_linear_time_to_scaled_time(current_linear_time,
                                      stream_wl->rebase_info.last_linear_rate_change_time,
                                      stream_wl->rebase_info.last_scaled_rate_change_time,
                                     stream_wl->rebase_info.curr_rate,
                                     &scaled_rate_change_time);

            //Updating my curr_segment information
            stream_wl->rebase_info.last_linear_rate_change_time = current_linear_time;
            stream_wl->rebase_info.last_scaled_rate_change_time = scaled_rate_change_time;
            stream_wl->rebase_info.curr_rate = rate;

            //Need to ignore inband rate changes untill a flush.
            stream_wl->ignore_inband_rate_change = true;

            stream_wl->rate = rate;

            //Reset the variable used for the stop check cacluation on a rate change.
            stream_wl->curr_position_ticks = ISMD_NO_PTS;
         }

         // clear linear_start_pts if it is reverse playback
         if (stream_wl->rate < 0) {
            stream_wl->linear_start_pts = ISMD_NO_PTS;
         }

      }
      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return ( result );
}


ismd_result_t
audio_timing_control_set_start_pts( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_pts_t start_pts )
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl );
   if ( result == ISMD_SUCCESS) {
      if ((stream_wl->ignore_inband_rate_change && stream_wl->rate < 0)
            || (!stream_wl->ignore_inband_rate_change && stream_wl->rebase_info.curr_rate < 0)) {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("Cannot set start pts while in reverse rate.", result, audio_devh[AUDIO_DEBUG_ATC]);
      }
      else {
         stream_wl->linear_start_pts = start_pts;
      }

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return ( result );
}


ismd_result_t
audio_timing_control_disable_stream( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl );
   if ( result == ISMD_SUCCESS ) {

      stream_wl->disabled = true;

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return ( result );
}


ismd_result_t
audio_timing_control_enable_stream( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl );
   if ( result == ISMD_SUCCESS ) {

      stream_wl->disabled = false;

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return ( result );
}


ismd_result_t
audio_timing_control_set_timing_accuracy( audio_atc_t atc_h,
                              audio_atc_stream_t atc_stream_h,
                              int allowed_ms_drift_ahead,
                              int allowed_ms_drift_behind)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   if ( (result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl )) == ISMD_SUCCESS ) {

      result = ISMD_ERROR_INVALID_PARAMETER;

      /* Check in the input parameters to make sure we have correct input from the user */
      if(allowed_ms_drift_ahead < 0 || allowed_ms_drift_behind < 0){
         AUDIO_ERROR("Please specify a positive value in milliseconds for timing accuracy!", result, atc_devh);
      }

      else {

         stream_wl->allowed_ms_drift_ahead = allowed_ms_drift_ahead;
         stream_wl->allowed_ms_drift_behind = allowed_ms_drift_behind;

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL,atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_SET_TIMING_ACCURACY,
            atc_h,
            atc_stream_h,
            allowed_ms_drift_ahead,
            allowed_ms_drift_behind, 0, 0);

         result = ISMD_SUCCESS;
      }

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return result;
}

ismd_result_t
audio_timing_control_get_underrun_amount( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_time_t *underrun_amount)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl );
   if ( result == ISMD_SUCCESS ) {

      *underrun_amount = stream_wl->underrun_amount ;

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return ( result );
}


ismd_result_t
audio_timing_control_set_underrun_event( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_event_t underrun_event)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl );
   if ( result == ISMD_SUCCESS ) {

      stream_wl->underrun_event = underrun_event;

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return ( result );
}



ismd_result_t
audio_timing_control_set_fixed_delay( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, unsigned int fixed_back_end_delay_chunk)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl );
   if ( result == ISMD_SUCCESS ) {

      if (fixed_back_end_delay_chunk > FIXED_BACK_END_PIPE_DELAY_CHUNK) {
         fixed_back_end_delay_chunk = FIXED_BACK_END_PIPE_DELAY_CHUNK;
      }
      stream_wl->fixed_back_end_delay_ms = fixed_back_end_delay_chunk * AUDIO_CORE_GET_CHUNK_PERIOD(stream_wl->atc_wl);
      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_timing_control_set_fixed_delay failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return ( result );
}

ismd_result_t
audio_timing_control_set_segment_info( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, audio_time_rebase_info_t seg_info)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl );
   if ( result == ISMD_SUCCESS ) {

      stream_wl->rebase_info = seg_info;
      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_timing_control_set_fixed_delay failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return ( result );
}

ismd_result_t audio_timing_control_suspend(void)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(ismd_event_strobe(atc_device.clock_alarm_event) != ISMD_SUCCESS){
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed on data_avail_event in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);
   }
   else if(ismd_event_strobe(atc_device.queue_io_event) != ISMD_SUCCESS){
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed on out_port_full_event in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);
   }
   else if(ismd_event_strobe(atc_render_resync_event) != ISMD_SUCCESS){
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed on out_port_full_event in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);
   }
   atc_device.wait_with_timeout = true;     /*timeout is 10ms*/
   return result;
}

ismd_result_t audio_timing_control_resume(void)
{
   ismd_result_t result = ISMD_SUCCESS;
   atc_device.wait_with_timeout = false;

   return result;
}

/*
* Enable VSRC support. 
*/
ismd_result_t
audio_timing_control_enable_vsrc_support(audio_atc_t atc_h, audio_atc_stream_t atc_stream_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl );
   if ( result == ISMD_SUCCESS ) {
      if (audio_core_is_valid_sample_rate(stream_wl->asrc.target_sample_rate)){
         stream_wl->asrc.vsrc_support_enabled = true;
         audio_pvt_atc_asrc_reset(stream_wl);
      }
      else {
         result = ISMD_ERROR_INVALID_PARAMETER;
      }
      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return result;
}

/*
* Disable support VSRC support, calling this will cause vchunk adjustment stop immediately.
*/
ismd_result_t
audio_timing_control_disable_vsrc_support(audio_atc_t atc_h, audio_atc_stream_t atc_stream_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   result = audio_pvt_atc_stream_lock_and_get_wl( atc_h, atc_stream_h, &stream_wl );
   if ( result == ISMD_SUCCESS ) {
     
      if(stream_wl->asrc.vsrc_support_enabled){
         stream_wl->asrc.vsrc_support_enabled = false;
         audio_pvt_atc_asrc_reset(stream_wl);
      }
      
      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }
   else {
      AUDIO_ERROR( "audio_pvt_atc_stream_lock_and_get_wl failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return result;
}

/* Caller must specify the valid mixer sample-rate, thus ATC could adjust each chunk with best quality.
* If the mixer_sample_rate is not valid it will return ERROR 
*/
ismd_result_t
audio_timing_control_asrc_set_target_sample_rate(audio_atc_t atc_h, unsigned int mixer_sample_rate)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_atc_context_t *wl = NULL;
   audio_atc_stream_context_t *stream_wl = NULL;
   audio_atc_stream_t handle = AUDIO_INVALID_HANDLE;

   AUDIO_ENTER(atc_devh);

   if((result = audio_pvt_atc_lock_and_get_wl(atc_h, &wl)) == ISMD_SUCCESS){

      for (handle=0; handle < AUDIO_MAX_ATC_STREAMS; handle++) {

         stream_wl = &(wl->streams[handle]);
         
         if(stream_wl->in_use){
            
            if (audio_core_is_valid_sample_rate(mixer_sample_rate)) {
               stream_wl->asrc.target_sample_rate = mixer_sample_rate;
               stream_wl->asrc.minimal_adjust = ATC_ASRC_MINIMAL_ADJUST;
            }
            else {
               AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"atc asrc set target sample rate inavlid!\n", atc_devh);
            }
         }
      }
      
      audio_pvt_atc_unlock(wl);
   }
   else {
      AUDIO_ERROR( "audio_pvt_atc_lock_and_get_wl failed!", result, atc_devh );
   }

   AUDIO_EXIT(atc_devh);

   return result;
}


/*********************************************************************************************/

/* Private Audio Functions*/

static ismd_result_t
audio_pvt_atc_enqueue_output_buffer(audio_atc_stream_context_t *stream_wl)
{

   /* Before enqueuing out the buffer, writeback/invalidate output buffer payload. */
   if (audio_core_fast_path_enabled()) {
      cache_flush_buffer(stream_wl->output_buffer->virt.base, stream_wl->output_buffer->phys.level);
   }
   
   return ismd_queue_enqueue(stream_wl->output_queue, stream_wl->output_buffer);
}

static void
audio_pvt_atc_discont_metadata_update(audio_atc_stream_context_t *stream_wl, int silence_bytes ) 
{
   audio_buffer_attr_t *metadata = (audio_buffer_attr_t*)&stream_wl->output_buffer->attributes;

   /*Do a check first to see if this buffer already has an assigned action.*/
   if(metadata->discontinuity_desc.action == AUDIO_DISCONTINUITY_ACTION_NONE) {

      /*If there is a pending forced action handle that here. This currently is only when
        we have requested to ramp up the first buffer at the start of the stream.*/
      if(silence_bytes == ATC_DISCONT_CHECK_FOR_PENDING_ACTION) {

         /*This check is made when we are about to enqueue to post processing DSP. 
           Need to ensure this buffer has valid metadata and has data, otherwise the
           notification of a ramp will never get to the transition algorithm. */
         if(audio_core_is_valid_metadata(metadata->sample_rate, metadata->sample_size, metadata->channel_count) &&
           (stream_wl->output_buffer->phys.level > 0) && !stream_wl->output_buffer_is_silence && stream_wl->add_ramp_up_mda) 
         {
            metadata->discontinuity_desc.action = AUDIO_DISCONTINUITY_ACTION_RAMP_UP;
            metadata->discontinuity_desc.offset = 0;
            stream_wl->add_ramp_up_mda = false;
         }
      }

      /*If there is already data in the buffer, then we have a ramp down because 
        we are filling the rest of the buffer with silence and need the transition to 
        be ramped down to the silence that we have just filled. */
      else if(stream_wl->output_buffer->phys.level > 0) {

         /*If this silence add fills the entire buffer to chunks size we can safely say ramp down.*/
         if((silence_bytes + stream_wl->output_buffer->phys.level) == stream_wl->curr_chunk_size) {
            metadata->discontinuity_desc.action = AUDIO_DISCONTINUITY_ACTION_RAMP_DOWN;
            metadata->discontinuity_desc.offset = stream_wl->output_buffer->phys.level;

            if(silence_bytes > 0) {
               stream_wl->last_out_buf_ended_in_silence = true;
            }
         }
         else{
            metadata->discontinuity_desc.action = AUDIO_DISCONTINUITY_ACTION_NONE;
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "Silence requested does not fill buffer!", atc_devh);
         }
      }

      /*The case where the bufer is empty. */
      else if(stream_wl->output_buffer->phys.level == 0 ) {

         /*Make sure this buffer is not going to be completely filled with silence.
           Then we mark this buffer as a need to ramp up since the first samples
           here will be silence and presumably we will add data after the silence. */
         if( silence_bytes < stream_wl->curr_chunk_size ) {

            /*If the last buffer ended in silence, just ramp up. If it had data, then need to
              specify reamp down and then ramp back up at the offset. */
            if(stream_wl->last_out_buf_ended_in_silence) {
               metadata->discontinuity_desc.action = AUDIO_DISCONTINUITY_ACTION_RAMP_UP;
            }
            else {
               metadata->discontinuity_desc.action = AUDIO_DISCONTINUITY_ACTION_RAMP_DOWN_PREV_UP_AT_OFFSET;
            }
            metadata->discontinuity_desc.offset = silence_bytes;
         }
         
         /*If the entire buffer is filled with silence, specify a ramp down w/ no offset 
           only if the previous buffer we sent ended with valid audio data. This signals
           to the transition protection buffering that a ramp down was needed. */
         else if(silence_bytes == stream_wl->curr_chunk_size) {
            
            if(!stream_wl->last_out_buf_ended_in_silence) {
               metadata->discontinuity_desc.action = AUDIO_DISCONTINUITY_ACTION_RAMP_DOWN;
               metadata->discontinuity_desc.offset = 0;
            }
            stream_wl->last_out_buf_ended_in_silence = true;
            /*Next valid buffer needs to be ramped up.*/
            stream_wl->add_ramp_up_mda = true;
         }
      }

      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
         SVEN_MODULE_EVENT_AUD_IO_ATC_DISCONTINUITY_UPDATE,
         metadata->discontinuity_desc.action, metadata->discontinuity_desc.offset,
         stream_wl->output_buffer->phys.level, silence_bytes,
         stream_wl->curr_chunk_size, stream_wl->last_out_buf_ended_in_silence);
   }
   
   /*Need to handle the case where there was by chance a bit of data in between 2 silence requests. Going 
     to silence the entire buffer, since there is no time for ramping in the buffer and this would be an 
     extreme stream error condition.*/
   else if(silence_bytes != ATC_DISCONT_CHECK_FOR_PENDING_ACTION){

      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
         SVEN_MODULE_EVENT_AUD_IO_ATC_DISCONTINUITY_SILENCE_FILL,
         metadata->discontinuity_desc.action,metadata->discontinuity_desc.offset,
         stream_wl->output_buffer->phys.level, silence_bytes,
         stream_wl->curr_chunk_size, stream_wl->last_out_buf_ended_in_silence);

      /*Silence the entire buffer.*/
      OS_MEMSET(stream_wl->output_buffer->virt.base, 0, stream_wl->curr_chunk_size);

      /*If the last buffer did not end in silence, need to flag this one as a ramp down since its full of silence.*/
      if(!stream_wl->last_out_buf_ended_in_silence) {
         metadata->discontinuity_desc.action = AUDIO_DISCONTINUITY_ACTION_RAMP_DOWN;
         metadata->discontinuity_desc.offset = 0;
      }
      stream_wl->last_out_buf_ended_in_silence = true;
      /*Next valid buffer needs to be ramped up.*/
      stream_wl->add_ramp_up_mda = true;
   }
   
   /*Ramp up was already filled out for this buffer, clear request to ramp up.*/
   else if(silence_bytes == ATC_DISCONT_CHECK_FOR_PENDING_ACTION){
      stream_wl->add_ramp_up_mda = false;
   }
  
}

static void
audio_pvt_atc_discont_mda_send_last_buffer(audio_atc_stream_context_t *stream_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_buffer_attr_t *metadata = NULL;
   int silence_bytes = 0;
   
   /*Only want to attempt to do this if we were in a playing state and transition protection is enabled.*/
   if(stream_wl->state == ISMD_DEV_STATE_PLAY && stream_wl->atc_wl->transition_protection_enabled) {
  
      /*Send last buffer with discontinuity info*/
      if(stream_wl->output_buffer == NULL) {
         result = audio_pvt_atc_alloc_out_buffer(stream_wl);
      }
      /*Send a silence buffer.*/
      if(result == ISMD_SUCCESS) {
         
         /*Give the buffer output metadata.*/
         metadata = (audio_buffer_attr_t*)&stream_wl->output_buffer->attributes;
         if(metadata->sample_rate == ATC_OUT_BUFFER_NEEDS_METADATA) {
            metadata->sample_rate = stream_wl->curr_stream_info.sample_rate;
            metadata->channel_count = stream_wl->curr_stream_info.channel_count;
            metadata->channel_config= stream_wl->curr_stream_info.channel_config;
            metadata->sample_size = stream_wl->curr_stream_info.sample_size;
         }
         /*Assign the next timestamp to send to the render. */
         if((metadata->render_time_stamp == ISMD_NO_PTS) && (stream_wl->prev_time_stamp != ISMD_NO_PTS)) {
            metadata->render_time_stamp = stream_wl->prev_time_stamp + 
               (uint64_t)audio_core_bytes_to_samples(metadata->sample_size, metadata->channel_count, stream_wl->curr_chunk_size);
         }
         else {
            /*Render will throw this away, but notification will get to the transition protection stage.*/
            metadata->render_time_stamp = 0; 
         }

         /*If the buffer has data, just fill remaining with silence which will fill out the discont metadata, 
           only want to fill in with silence if the ATC mode has specified silence insert is ok.*/

         if(stream_wl->atc_wl->insert_silence &&
            stream_wl->output_buffer->phys.level < stream_wl->curr_chunk_size ) 
         {
            silence_bytes = stream_wl->curr_chunk_size - stream_wl->output_buffer->phys.level;
            OS_MEMSET( (void*)((int)stream_wl->output_buffer->virt.base + stream_wl->output_buffer->phys.level), 0, silence_bytes);
         }
         audio_pvt_atc_discont_metadata_update(stream_wl, silence_bytes );
         stream_wl->output_buffer->phys.level += silence_bytes;

         /*Enqueue the output buffer, if we fail, something is bad, just dref and move on.*/
         if(audio_pvt_atc_enqueue_output_buffer(stream_wl) != ISMD_SUCCESS) {
            ismd_buffer_dereference(stream_wl->output_buffer->unique_id);
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"ATC disc mda: could not enqueue last buffer.\n", atc_devh);
         }

         /*Either way we got rid of the buffer, set it back to NULL.*/
         stream_wl->output_buffer = NULL;
      }
   }
}

static bool
audio_pvt_atc_stream_info_changed(audio_buffer_attr_t *curr_info, audio_buffer_attr_t *next_info) 
{

   /* Need to see if any of the stream information changed so we dont group samples incorrectly. */
   if((curr_info->sample_rate != next_info->sample_rate) ||
     (curr_info->sample_size != next_info->sample_size) ||
     (curr_info->channel_count != next_info->channel_count) ||
     (curr_info->channel_config != next_info->channel_config)) 
   {
      return true;
   }
   return false;
}

static ismd_result_t
audio_pvt_atc_input_buffer_dereference(audio_atc_stream_context_t *stream_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   
   if(stream_wl->input_buffer != NULL) {
      
      /* If the input buffer was cached by ATC, need to unmap*/
      if(stream_wl->in_cached_address != NULL) {  
         OS_UNMAP_IO_FROM_MEM(stream_wl->in_cached_address , stream_wl->input_buffer->phys.level);
         stream_wl->in_cached_address = NULL;
      }
      result = ismd_audio_buffer_dereference(stream_wl->input_buffer->unique_id);
   }

   stream_wl->input_buffer = NULL;

   return result;
}

static ismd_result_t
audio_pvt_atc_output_buffer_discard(audio_atc_stream_context_t *stream_wl)
{
   audio_buffer_attr_t *buffer_mda = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);

   /*If we are about to throw away a buffer with ramping info, 
     need to make sure the next output buffer gets the metadata set.*/
   if(buffer_mda->discontinuity_desc.action != AUDIO_DISCONTINUITY_ACTION_NONE) {

      /*Indicate next buffer needs ramp up information.*/
      if(buffer_mda->discontinuity_desc.action == AUDIO_DISCONTINUITY_ACTION_RAMP_UP) {
         stream_wl->add_ramp_up_mda = true;
      }
      /*Try to send off a last silence buffer with ramp down indication.*/
      else {
         buffer_mda->discontinuity_desc.offset = 0;
         buffer_mda->discontinuity_desc.action = AUDIO_DISCONTINUITY_ACTION_NONE;
         stream_wl->output_buffer->phys.level = 0;
         audio_pvt_atc_discont_mda_send_last_buffer(stream_wl);
      }
   }

   if(stream_wl->output_buffer != NULL) {
      ismd_audio_buffer_dereference(stream_wl->output_buffer->unique_id);
   }
 
   return ISMD_SUCCESS;
}

static void
audio_pvt_atc_check_for_stop_time(audio_atc_stream_context_t *stream_wl)
{
   int samples = 0;
   int ticks = 0;
   int bytes_to_discard = 0;
   audio_buffer_attr_t *buffer_mda = (audio_buffer_attr_t *) &(stream_wl->input_buffer->attributes);
   ismd_time_t buffer_end_time = 0;
   ismd_pts_t stop_time = stream_wl->rebase_info.curr_seg_info.stop;

   /* Every time we get a PTS on the input buffer, update our current postion in ticks, this is
      so if there is a bit of a drift in our data vs PTS time representation, we will pull it back based
      on the stream's PTS values. In cases like BD disks the values are exact almost always. */
   if(buffer_mda->original_pts != ISMD_NO_PTS) {
      stream_wl->curr_position_ticks = buffer_mda->original_pts;
   }

   /*Only attempt to do this calculation if we have valid metadata on the buffer.*/
   if((stop_time != ISMD_NO_PTS) && (stream_wl->curr_position_ticks != ISMD_NO_PTS)){

      /* Calculate where we will be after this entire input buffer is used. Need to see if we should stop early.*/
      samples = audio_core_bytes_to_samples(buffer_mda->sample_size, buffer_mda->channel_count, stream_wl->input_buffer->phys.level);
      ticks = (samples * CLOCK_SPEED_HZ)/buffer_mda->sample_rate;

      /* Advance our stream postion to where we will be after this buffer is processed. This is our end time for this buffer. */
      stream_wl->curr_position_ticks += ticks;
      buffer_end_time = stream_wl->curr_position_ticks;

      /* Check to see if the data at the end of this buffer is beyond our stop time.*/
      if(buffer_end_time > stop_time) {

          /*Adjust the buffer's level to reflect how much data we should throw away.*/
          ticks =  (int)(buffer_end_time - stop_time);
          samples = (int)(((int)(buffer_end_time - stop_time)*buffer_mda->sample_rate)/CLOCK_SPEED_HZ);
          bytes_to_discard = audio_core_samples_to_bytes(buffer_mda->sample_size, buffer_mda->channel_count, samples);

         /* Finally make the adjustment to level of the buffer. This is throwing out data beyond our stop point. */
         stream_wl->input_buffer->phys.level -= bytes_to_discard;
          if(stream_wl->input_buffer->phys.level < 0) {
            stream_wl->input_buffer->phys.level = 0;
          }

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
            SVEN_MODULE_EVENT_AUD_IO_ATC_STOP_TIME_CHECK,
            (unsigned int) stream_wl->input_buffer->phys.level,
            (unsigned int) bytes_to_discard,
            (unsigned int) buffer_mda->original_pts,
            (unsigned int) ticks,
            (unsigned int) buffer_end_time,
            (unsigned int) stop_time);
      }
   }
   return;
}


static void
audio_pvt_atc_reset_buffer_metadata(audio_buffer_attr_t *metadata)
{
   audio_core_reset_buffer_metadata(metadata);
   metadata->sample_rate = ATC_OUT_BUFFER_NEEDS_METADATA;//Marking this so we know we need to fill out metadata later.
   metadata->render_time_stamp = ISMD_NO_PTS;
   return ;
}

static ismd_result_t
audio_pvt_atc_stream_remove(audio_atc_context_t *wl, audio_atc_stream_t atc_stream_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   stream_wl = &(wl->streams[atc_stream_h]);

   /*While the thread is locked, attempt to send the final discontinuity metadata buffer.*/
   audio_pvt_atc_discont_mda_send_last_buffer(stream_wl);

   stream_wl->start_to_remove = true;

   stream_wl->in_use = false;

   /* Check to see if this stream had the timer */
   audio_pvt_atc_check_if_clock_is_timer(stream_wl, stream_wl->atc_wl->dev_wl);

   if((result = ismd_queue_disconnect_input(stream_wl->output_queue)) != ISMD_SUCCESS){
      AUDIO_ERROR("queue_disconnect input failed!", result, atc_devh);
   }

   if((result = ismd_queue_disconnect_output(stream_wl->input_queue)) != ISMD_SUCCESS){
      AUDIO_ERROR("queue_disconnect output failed!", result, atc_devh);
   }

   if (stream_wl->is_primary ){
      stream_wl->atc_wl->primary_stream_wl = NULL;
   }

   /* If we have a temp buffer still free it up. */
   if(stream_wl->output_buffer  != NULL) {
      ismd_audio_buffer_dereference(stream_wl->output_buffer->unique_id);
   }

   audio_pvt_atc_input_buffer_dereference(stream_wl);

   if(stream_wl->drop_buffer != NULL) {
      ismd_audio_buffer_dereference(stream_wl->drop_buffer->unique_id);
   }

   if(stream_wl->message_context != ISMD_MESSAGE_CONTEXT_INVALID) {
      ismd_message_context_free(stream_wl->message_context);
   }

   if(stream_wl->discontinuity_event != ISMD_EVENT_HANDLE_INVALID) {
      
      /* Unregister the discontinuity event from clock*/
      ismd_clock_set_time_discontinuity_event(stream_wl->clock_h, ISMD_EVENT_HANDLE_INVALID, ATC_MAX_CLOCK_DRIFT);

      /* Remove discontinuity event from event list if it's there */
      audio_pvt_atc_remove_event_from_list( &atc_device, stream_wl->discontinuity_event);

      /* Free discontinuity event */
      ismd_event_free(stream_wl->discontinuity_event);
      stream_wl->discontinuity_event = ISMD_EVENT_HANDLE_INVALID;
   }

   /*Reset the stream workload variables*/
   audio_pvt_atc_stream_init_wl(stream_wl);

   wl->active_stream_count--;

   AUDIO_EXIT(atc_devh);
   return result;
}

/** Use this function to reinit stream context variables that get re-initialized to the
    same default values on stream reset as well as stream context initialization. */
static void
audio_pvt_atc_init_stream_wl_reset_values(audio_atc_stream_context_t *stream_wl) 
{
   stream_wl->first_buffer_dequeued = false;
   stream_wl->first_pts_found = false;
   stream_wl->have_base_numbers = false;
   stream_wl->sent_first_frame = false;
   stream_wl->last_pts_recvd = ISMD_NO_PTS;
   stream_wl->prev_time_stamp = ISMD_NO_PTS;
   stream_wl->prev_render_time = ISMD_NO_PTS;
   stream_wl->curr_chunk_size = 0;
   stream_wl->next_chunk_size = 0;
   stream_wl->atc_base_time = 0;
   stream_wl->render_sample_count = 0;
   stream_wl->render_delay_samples = 0;
   stream_wl->render_delay_ticks = 0;
   stream_wl->pad_silence_bytes = 0;
   stream_wl->drift_error_smpl_cnt = 0;
   stream_wl->drop_bytes = 0;
   stream_wl->last_pts_smpl_cnt = 0;
   stream_wl->bytes_since_last_pts = 0;
   stream_wl->in_buf_bytes_copied = 0;
   stream_wl->bytes_to_fix = 0;
   stream_wl->fixing_samples = false;
   stream_wl->underrun_count = 0;
   stream_wl->underrun_amount = 0;
   stream_wl->last_buffer_discrd_pts_past_stop_value = false;
   stream_wl->discontinuity = true;
   stream_wl->curr_position_ticks = ISMD_NO_PTS;
   stream_wl->out_buf_ready = false;
   stream_wl->out_buf_forced_ready = false;
   stream_wl->rend_ts_normalized = false;
   stream_wl->output_buffer_is_silence = false;
   stream_wl->last_out_buf_ended_in_silence = true;
   /*Ramp up since this will be begining of a new stream.*/
   stream_wl->add_ramp_up_mda = true; 
   OS_MEMSET(&stream_wl->curr_stream_info, 0, sizeof(audio_buffer_attr_t));
   OS_MEMSET(&stream_wl->next_stream_info, 0, sizeof(audio_buffer_attr_t));

   return;
}


static void
audio_pvt_atc_reset_for_new_stream(audio_atc_stream_context_t *stream_wl) {

   AUDIO_ENTER(atc_devh);

   audio_pvt_atc_init_stream_wl_reset_values(stream_wl);

   /*Resetting so flag this as a discontinuity.*/
   stream_wl->discontinuity = true;

   /*Clear out our drop buffer used in trick modes.*/
   stream_wl->drop_buffer->phys.level = 0;

   audio_pvt_atc_input_buffer_dereference(stream_wl);

   if(stream_wl->output_buffer != NULL) {
      ismd_audio_buffer_dereference(stream_wl->output_buffer->unique_id);
      stream_wl->output_buffer = NULL;
   }

   // vchunk reset for new stream
   audio_pvt_atc_asrc_reset(stream_wl);

   audio_core_notify_event( stream_wl->notif_events, ISMD_AUDIO_NOTIFY_TIMING_INFO_UNAVAILABLE);

   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_RESET_STREAM,
      stream_wl->atc_wl->handle,
      stream_wl->handle, 0,0,0,0);

   AUDIO_EXIT(atc_devh);

   return;
}

static ismd_result_t
audio_pvt_atc_input_queue_io_callback(void *context, ismd_queue_event_t queue_event, ismd_buffer_handle_t buffer )
{
   audio_atc_stream_context_t *stream_wl = (audio_atc_stream_context_t *)context;
   audio_atc_context_t *wl = stream_wl->atc_wl;
   audio_atc_device_t *dev_wl = wl->dev_wl;
   (void)buffer;

   //Only stobe the event rapidly when we move into trick modes and only one stream is attached.
   if( (stream_wl->rate > AUDIO_MIN_PLAY_RATE) && (stream_wl->rate <= AUDIO_MAX_PLAY_RATE) && stream_wl->is_timed_stream && (wl->active_stream_count == 1)) {
      if(ismd_event_strobe(dev_wl->queue_io_event) != ISMD_SUCCESS){
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"atc event_strobe failed!\n", atc_devh);
      }
   }
   else {
      if ( queue_event & (ISMD_QUEUE_EVENT_NOT_EMPTY | ISMD_QUEUE_EVENT_HIGH_WATERMARK) ) {

         if(ismd_event_strobe(dev_wl->queue_io_event) != ISMD_SUCCESS){
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"atc event_strobe failed!\n", atc_devh);
         }
      }
   }

   return ISMD_ERROR_NO_SPACE_AVAILABLE;
}

static ismd_result_t
audio_pvt_atc_output_queue_io_callback(void *context, ismd_queue_event_t queue_event, ismd_buffer_handle_t *buffer )
{
   audio_atc_device_t *dev_wl = (audio_atc_device_t *)context;
   (void)queue_event;
   (void)buffer;

   if(ismd_event_strobe(dev_wl->queue_io_event) != ISMD_SUCCESS){
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"atc event_strobe failed!\n", atc_devh);
   }

   return ISMD_ERROR_NO_DATA_AVAILABLE;
}

static void
audio_pvt_atc_handle_output_eos(audio_atc_stream_context_t *stream_wl, bool *discard_buffer)
{
   audio_buffer_attr_t *attr = (audio_buffer_attr_t*)&stream_wl->output_buffer->attributes;

   if(!stream_wl->did_eos_check) {

      /*First check the EOS to see if its on the output buffer*/
      if (ismd_tag_get_eos(stream_wl->output_buffer->unique_id) == ISMD_SUCCESS) {
         //Do nothing the output buffer has the EOS
         stream_wl->did_eos_check = true;
      }

      /* IF we have the eos and the output buffer is empty or input buffer was already discarded, set the EOS. */
      else if(stream_wl->have_eos && ((stream_wl->output_buffer->phys.level == 0) ||(stream_wl->input_buffer == NULL))) {
         ismd_tag_set_eos(stream_wl->output_buffer->unique_id);
         stream_wl->have_eos = false;
         stream_wl->did_eos_check = true;
      }
   }

   /*If this is encoded data, the metadata is invalid because of a silence fill and 
     there are no tags present to propagate, no reason to send it down stream.*/
   if(stream_wl->is_encoded_data && !stream_wl->output_buffer->tags_present &&
      !audio_core_is_valid_metadata(attr->sample_rate, attr->sample_size, attr->channel_count)) 
   {
      *discard_buffer = true;
   }

   return;
}

static void
audio_pvt_atc_handle_output_eos_encoded(audio_atc_stream_context_t *stream_wl)
{
   //Need to check to see if the output buffer has the EOS and is not complete, if so send it.
   if (ismd_tag_get_eos(stream_wl->output_buffer->unique_id) == ISMD_SUCCESS) {
      // Got last incomplete bufffer, mark as ready. Render will fill pause/silence later.
      stream_wl->out_buf_ready = true;
   }
   //Need to check to see if ATC has EOS never set it on the output buffer, need to set then send.
   else if(stream_wl->have_eos) {
      if ( ismd_tag_set_eos (stream_wl->output_buffer->unique_id) == ISMD_SUCCESS) {
         stream_wl->out_buf_ready = true;
         stream_wl->have_eos = false;
      }
   }
   return;
}

static void
audio_pvt_atc_update_next_stream_info(audio_atc_stream_context_t *stream_wl) 
{
   /*If the stream attributes have changed need to update and notify to get new data from the render.*/
   if(audio_pvt_atc_stream_info_changed(&stream_wl->curr_stream_info, &stream_wl->next_stream_info)) {
      
      /*Output buffer shipped, change to new chunk size.*/
      stream_wl->curr_chunk_size = stream_wl->next_chunk_size;
      stream_wl->curr_stream_info = stream_wl->next_stream_info;

      /*Since its a new stream need to query render and calculate stream start again. */
      stream_wl->have_base_numbers = false;
      stream_wl->prev_time_stamp = ISMD_NO_PTS;
      stream_wl->sent_first_frame = false;
   }

   return;
}

static ismd_result_t
audio_pvt_atc_send_output_buffers(audio_atc_context_t *wl, ismd_event_t triggered_event)
{
   int handle = 0;
   bool discard_buffer = false;
   audio_atc_stream_context_t *stream_wl = NULL;
   atc_render_base_numbers_t render_numbers;
   bool time_stamp_ready = true;
   ismd_result_t result = ISMD_SUCCESS;
   ismd_result_t final_result = ISMD_ERROR_NO_DATA_AVAILABLE;
   bool fast_output = false;
   int output_level = 0;
   audio_buffer_attr_t *output_buff_attrib = NULL;
   
   //Lock the outputs queues so the PSM doesnt take anything untill all queues have been filled.
   audio_pvt_atc_lock_output_queues(wl->output_queue_lock);

   //Need to get new base numbers from the render each
   render_numbers.refresh_numbers = true;

   for(handle = 0; handle < AUDIO_MAX_ATC_STREAMS; handle++)
   {
      discard_buffer = false;

      stream_wl = &(wl->streams[handle]);

      /*See if we have fast output enabled.*/
      fast_output = (wl->fast_output || stream_wl->fast_output) ? true:false;

      /*Need to determine if the current output buffer still has data to process.*/
      output_level = (stream_wl->input_buffer == NULL) ? 0 : stream_wl->output_buffer->phys.level;

      /* Process this input if, the alarm went off, or the stream is set to fast output, or the ATC context is set to fast output */
      if(((triggered_event == wl->clock_alarm_event) || fast_output) && ((stream_wl->state == ISMD_DEV_STATE_PLAY) || (output_level > 0))) {

         if(stream_wl->in_use && (stream_wl->output_buffer != NULL)) {

            if ((!fast_output) && (stream_wl->asrc.vsrc_support_enabled)) {
               audio_pvt_atc_calculate_asrc_drift(wl, stream_wl);
            }

            /* If the output buffer isn't ready and we have a valid chunks size and we are trying to output after a clock alarm has triggered need possibly add silence.
               If this stream context is outputting on the fast output, we are not adding silence. */
            if( !stream_wl->out_buf_ready && (stream_wl->curr_chunk_size != 0) && stream_wl->first_buffer_dequeued ) {

               //Doing a series of checks here for trick modes, having trouble resuming if we dont do this.
               if((stream_wl->state != ISMD_DEV_STATE_PAUSE) || !stream_wl->is_timed_stream) {

                  //Check for EOS propagation differently for encoded streams.
                  if(stream_wl->is_encoded_data) {
                     audio_pvt_atc_handle_output_eos_encoded(stream_wl);
                  }
                  // PCM case
                  else if((stream_wl->rate == ISMD_NORMAL_PLAY_RATE)) {

                     //We have been told to insert silence by default, if not, just flag the buffer ready to go.
                     if(wl->insert_silence && !fast_output) {
                        audio_pvt_atc_top_off_buffer(stream_wl);
                     }
                     else {
                        stream_wl->out_buf_ready = true;
                     }
                  }
                  else{
                     stream_wl->out_buf_ready = true;
                  }
               }
            }

            /*If we are on the fast output, dont want to send a buffer that the legnth < chunksize, unless its EOS or has tags.*/
            if(fast_output && !stream_wl->have_eos && (stream_wl->output_buffer->phys.level != stream_wl->curr_chunk_size) && (!stream_wl->output_buffer->tags_present)) {
               stream_wl->out_buf_ready = stream_wl->out_buf_forced_ready;
            }

            /*Handling the case where we have never received any input, have no output but have the EOS.*/
            if(stream_wl->have_eos && !stream_wl->first_buffer_dequeued && (stream_wl->output_buffer->phys.level == 0)) {
               stream_wl->out_buf_ready = true;
            }

            /* Check to see if the buffer can be released, on fast output only execute this once when the buffer is ready. */
            if((!fast_output) || (fast_output && stream_wl->out_buf_ready)) {
               time_stamp_ready = audio_pvt_atc_buffer_ts_ready_for_release(stream_wl, &render_numbers, &discard_buffer );
            }

            if(stream_wl->out_buf_ready && time_stamp_ready) {

               audio_pvt_atc_handle_output_eos(stream_wl, &discard_buffer);

               // update output buffer interpolated_info.
               audio_pvt_atc_interpolate_info_for_output_buffer(stream_wl);
               
               audio_pvt_atc_update_stream_position(stream_wl);
               
               //If we had a discontinuity, need to ensure we flag our output buffer
               if(stream_wl->discontinuity == true){

                  output_buff_attrib = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);
                  output_buff_attrib->discontinuity = true;
                  stream_wl->discontinuity = false;
               }

               audio_pvt_atc_discont_metadata_update(stream_wl, ATC_DISCONT_CHECK_FOR_PENDING_ACTION);

               if(stream_wl->disabled || discard_buffer) {
                  result = audio_pvt_atc_output_buffer_discard(stream_wl);
               }
               else {
                  result = audio_pvt_atc_enqueue_output_buffer(stream_wl);             
                  }

               if(result == ISMD_SUCCESS){
                  
                  //We have queued one output buffer successfully,
                  //This is the right place to adjust the slave clock
                  if(stream_wl->slave_clock_h != ISMD_CLOCK_HANDLE_INVALID) {
                     audio_pvt_atc_adjust_slave_clock(stream_wl);
                  }

                  /*If the buffer just sent is not completely silence and we didn't deref, hit the data being rendered event.*/
                  if(!stream_wl->output_buffer_is_silence && !stream_wl->disabled && !discard_buffer) {
                     audio_core_notify_event(stream_wl->notif_events, ISMD_AUDIO_NOTIFY_DATA_RENDERED);
                  }

                  stream_wl->did_eos_check = false;
                  stream_wl->output_buffer = NULL;
                  stream_wl->out_buf_ready = false;
                  stream_wl->out_buf_forced_ready = false;
                  stream_wl->rend_ts_normalized = false;
                  final_result = ISMD_SUCCESS;//At least one buffer enqueued, so return success.

                  /*Do a check to see if we need to change to a stream with different attributes.*/
                  audio_pvt_atc_update_next_stream_info(stream_wl);
               }
                else{

                  if(stream_wl->output_buffer != NULL){
                     AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
                        SVEN_MODULE_EVENT_AUD_IO_ATC_OUTPUT_ENQUEUE_FAILED,
                        stream_wl->atc_wl->handle,
                        stream_wl->handle,
                        stream_wl->output_buffer->phys.level,
                        (unsigned int)(((audio_buffer_attr_t *)stream_wl->output_buffer->attributes)->render_time_stamp >> 32),
                        (unsigned int)(((audio_buffer_attr_t *)stream_wl->output_buffer->attributes)->render_time_stamp ), result);
                  }
               }
            }
         }
      }
   }

   audio_pvt_atc_unlock_output_queues(wl->output_queue_lock);

   return final_result;
}

static void
audio_pvt_atc_process_context(audio_atc_context_t *wl, ismd_event_t triggered_event, bool reset_streams)
{
   audio_atc_stream_t handle = 0;
   audio_atc_stream_context_t *stream_wl = NULL;
   bool work_to_do =  false;
   bool try_to_prepare = true;
   bool pre_stream_fast_output = false;
   bool fast_output = false;
   bool has_timed_stream = false;

   while(try_to_prepare && !wl->start_to_close) {

      try_to_prepare = false;
      work_to_do = true;

      while(work_to_do) {

         work_to_do = false;
         pre_stream_fast_output = false;
         has_timed_stream = false;

         for(handle = 0; handle < AUDIO_MAX_ATC_STREAMS; handle++)
         {
            stream_wl = &(wl->streams[handle]);

            if(stream_wl->in_use) {

               //Reset the stream if we got the notification from the ATC device.
               //or there is discontinuity in this stream
               if(reset_streams || ((triggered_event != ISMD_EVENT_HANDLE_INVALID) && (triggered_event == stream_wl->discontinuity_event))) {
                  
                  /*If there isnt a pending ramp up request, we are about to reset the stream, send the notification to ramp down..*/
                  if(!stream_wl->add_ramp_up_mda && !stream_wl->fast_output && !stream_wl->atc_wl->fast_output) {
                     audio_pvt_atc_discont_mda_send_last_buffer(stream_wl);
                  }
                  audio_pvt_atc_reset_for_new_stream(stream_wl);
               }
               
               pre_stream_fast_output |= stream_wl->fast_output;
               //Check if there's another timed stream other than streams with fast_output enabled
               has_timed_stream |= ((stream_wl->state == ISMD_DEV_STATE_PLAY) && (stream_wl->is_timed_stream) && (!stream_wl->fast_output));

               //Always have a buffer ready.
               if(audio_pvt_atc_alloc_out_buffer(stream_wl) != ISMD_SUCCESS) {
                  continue;
               }

               /* Try to dequeue an input buffer if:
                 - We are playing. 
                 - Paused but need to find start of the segement. 
                 - Paused but have to advance to a certain PTS. */
               if((stream_wl->state == ISMD_DEV_STATE_PLAY) || 
                 ((stream_wl->state == ISMD_DEV_STATE_PAUSE) && (!stream_wl->start_of_seg_found)) ||
                 ((stream_wl->state == ISMD_DEV_STATE_PAUSE) && (stream_wl->linear_start_pts != ISMD_NO_PTS))){
                  
                  audio_pvt_atc_input_dequeue(stream_wl, &work_to_do);
               }

               //If we have an input buffer but don't have base numbers need to get them for the start of the stream.
               if( !stream_wl->have_base_numbers && (stream_wl->input_buffer != NULL) && (stream_wl->state == ISMD_DEV_STATE_PLAY)) {
                  
                  if(audio_pvt_atc_get_base_numbers(stream_wl) == ISMD_SUCCESS) {
                     
                     if ((stream_wl->timing_mode != ISMD_TIMING_MODE_ORIGINAL) ||
                        !stream_wl->is_timed_stream ||
                        (stream_wl->atc_base_time != 0)) 
                     { 
                        stream_wl->have_base_numbers = true;
                     }
                     else {
                        AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "atc: no valid clock time", atc_devh);
                     }
                  }
               }

               if( !stream_wl->out_buf_ready && stream_wl->first_buffer_dequeued && stream_wl->have_base_numbers) {

                  //Need to take a different path for trick modes
                  if( (stream_wl->rate > AUDIO_MIN_PLAY_RATE) && (stream_wl->rate <= AUDIO_MAX_PLAY_RATE) && stream_wl->is_timed_stream) {

                     audio_pvt_atc_assign_time_slot_trick_modes( stream_wl );
                  }
                  else {

                      //Assign a render time stamp to the output buffer.
                     audio_pvt_atc_assign_time_slot( stream_wl );
                  }

                  //If we moved data from input to output buffer, still work to do.
                  if(audio_pvt_atc_prepare_output_buffer(stream_wl)) {

                     work_to_do = true;
                  }
               }
            }

            if(triggered_event == stream_wl->discontinuity_event) {
               triggered_event = ISMD_EVENT_HANDLE_INVALID;
            }
         }

         reset_streams = false;

         /* Make sure we dont reset the stream if we still have work to do */
         if(triggered_event == atc_render_resync_event) {
            triggered_event = ISMD_EVENT_HANDLE_INVALID;
         }
      }

      /* Disable fast_output if there's another timed stream */
      fast_output = ((wl->fast_output || pre_stream_fast_output) && (!has_timed_stream));

      /* When we have a clock alarm, need to handle the enqueue of the output buffers */
      if((triggered_event == wl->clock_alarm_event) || fast_output) {

         /* Will return success if at least one buffer was sent, need to keep the thread trying to prepare. */
         if(audio_pvt_atc_send_output_buffers(wl, triggered_event) == ISMD_SUCCESS){
            try_to_prepare = true;
         }

         triggered_event = ISMD_EVENT_HANDLE_INVALID;//Alarm work done, reset event.
      }

   }

   return;
}

int
audio_pvt_atc_check_render_health(audio_atc_device_t *atc_dev, int hw_id)
{
   uint64_t curr_sample_count = 0;
      
   /* Currently there is only and issue with HDMI. Get the sample count, this is in terms of 192kHz.  */
   if(audio_core_get_render_sample_count(hw_id, &curr_sample_count) == ISMD_SUCCESS){

      if(atc_dev->render_prev_sample_count != 0) {

         /*If the sample count didnt change, increment the count to track this. */
         if(atc_dev->render_prev_sample_count == curr_sample_count) {
            atc_dev->render_no_sample_change_count++;
         }
         /*If it changed, we are still alive. */
         else {
            atc_dev->render_no_sample_change_count = 0;
         }

         /*Need to wait at least a good amount of time before we signal render is dead, we dont want
            to signal to early so wait at least as many chunks as several render prefills to ensure its dead. */
         if(atc_dev->render_no_sample_change_count >= ATC_MAX_TIME_PER_BEFR_DEAD_RNDR_SIG) {

            OS_PRINT("ISMD AUDIO: Warning: Audio critical overrun detected on HW dev: 0x%x. Resetting audio interface!\n", hw_id);

            /*Set the event that is waiting to recover the renderer */
            if(ismd_event_set(render_recovery_event) == ISMD_SUCCESS) {
               curr_sample_count = 0;
               atc_dev->render_no_sample_change_count = 0;
            }
         }
      }

      atc_dev->render_prev_sample_count = curr_sample_count;
   }
   /*IF this function returns in error that means the HDMI driver is not running. So reset our state variables.*/
   else {
      atc_dev->render_prev_sample_count = 0;
      atc_dev->render_no_sample_change_count = 0;
   }

   return 0;
}

static bool
audio_pvt_atc_need_to_reset_streams(ismd_event_t triggered_event)
{
   bool reset_streams = false;
   ismd_time_t curr_time;
   int diff = 0;
   int actual_diff = 0;
   int max_clock_drift_per_alarm = ATC_DEFAULT_MAX_CLOCK_DRIFT_PER_ALARM;
   ismd_result_t result;

   /* Check the clock every Xms alarm for a possible clock drift adjustment done by the buffer monitor */
   if(triggered_event == atc_device.clock_alarm_event ) {

      //Get the current time.
      if((result = ismd_clock_get_time_th_safe(atc_device.timer_clock_h, &curr_time)) != ISMD_SUCCESS) {
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "atc: ismd_clock_get_time_th_safe failed!", atc_devh);
      }
      else {

         //Make sure this isnt the first time around.
         if((atc_device.last_clock_alarm_time != 0) && (curr_time != 0)) {

            //Need one of these for SVEN reporting
            diff = actual_diff = (int)(curr_time - atc_device.last_clock_alarm_time);
            diff = ABS(diff);

            // whether we are using default clock handle
            if (atc_device.timer_clock_h != ISMD_CLOCK_HANDLE_INVALID && atc_device.timer_clock_h != atc_device.default_clock_h) {
               if (atc_device.timer_clock_stream_wl != NULL) {
                  max_clock_drift_per_alarm = ATC_MAX_CLOCK_DRIFT_PER_ALARM(atc_device.timer_clock_stream_wl->atc_wl);
               }
            }

            //If we drift in either direction, reset the streams in the ATC.
            if( diff > max_clock_drift_per_alarm ) {

               reset_streams = true;

               //If this thread had drifted we cant accurately track the renders. Need to reset. 
               atc_device.render_prev_sample_count = 0;
               atc_device.render_no_sample_change_count = 0;

               AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
                  SVEN_MODULE_EVENT_AUD_IO_ATC_CLOCK_DRIFT_DETECT,
                  actual_diff, diff,
                  (unsigned int)(curr_time  >> 32),
                  (unsigned int)(curr_time ),
                  (unsigned int)(atc_device.last_clock_alarm_time  >> 32),
                  (unsigned int)(atc_device.last_clock_alarm_time ));
            }
            else {

               /*For know only check HDMI health, its known to die on us. */
               audio_pvt_atc_check_render_health(&atc_device, GEN3_HW_OUTPUT_HDMI);
            }

            
         }

         //Record the time for next time around.
         atc_device.last_clock_alarm_time = curr_time;
      }
   }

   /*Also check to see if we received the resync_event need to reset on that event also.*/
   else if(triggered_event == atc_render_resync_event) {
      reset_streams = true;
   }

   return reset_streams;
}

static void
*audio_pvt_atc_manager_thread(void *context)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_device_t *dev_wl = (audio_atc_device_t *) context;
   audio_atc_context_t *atc_context = NULL;
   ismd_event_t triggered_event = ISMD_EVENT_HANDLE_INVALID;
   int handle = 0;
   bool reset_streams = false;

   AUDIO_ENTER(atc_devh);

   while(!dev_wl->start_to_close)
   {
      
      /* Wait on clock alarm event, should get woken up every n ms dependent on time slice. */
      if((result = ismd_event_wait_multiple(dev_wl->event_list, dev_wl->event_list_count, ISMD_TIMEOUT_NONE, &(triggered_event))) != ISMD_SUCCESS
         && result != ISMD_ERROR_OBJECT_DELETED) {
         AUDIO_ERROR("ismd_event_wait_multiple failed!", result,  atc_devh);
      }

      else if((result = ismd_event_acknowledge(triggered_event)) != ISMD_SUCCESS){
         AUDIO_ERROR("event_acknowledge failed!", result,  atc_devh);
      }

      else {
         AUDIO_EVENT(AUDIO_SVEN_LOG_GENERAL, atc_devh,
            SVEN_MODULE_EVENT_AUD_IO_ATC_AFTER_EVENT_WAIT,
            triggered_event,
            dev_wl->event_list_count, 0, 0, 0, 0);
      }
      
      /*Lock the ATC device */
      audio_pvt_atc_dev_lock(dev_wl);

      //Check to see if we need to reset the streams on certain events.
      reset_streams = audio_pvt_atc_need_to_reset_streams(triggered_event);

      /* Try to process each atc context if its in use */
      for(handle = 0; handle < AUDIO_MAX_ATC_CONTEXTS; handle ++) {

         atc_context = &(dev_wl->atc_contexts[handle]);

         audio_pvt_atc_lock(atc_context);

         if(atc_context->in_use) {
            audio_pvt_atc_process_context(&(dev_wl->atc_contexts[handle]), triggered_event, reset_streams);
         }
         audio_pvt_atc_unlock(atc_context);
      }

      /*Unlock the device */
      audio_pvt_atc_dev_unlock(dev_wl);
   }

   AUDIO_EXIT(atc_devh);
   return NULL;
}


static bool
audio_pvt_atc_buffer_ts_ready_for_release(audio_atc_stream_context_t *stream_wl, atc_render_base_numbers_t *base_numbers, bool *discard )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   bool reset = false;
   bool release_buffer = false;
   audio_buffer_attr_t *buff_attrib = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);
   uint64_t curr_render_time  = 0;
   uint64_t curr_render_time_cached  = 0;
   int drift = 0;

   //If we are processing a timed stream, and its an invalid PTS, make sure to flag the buffer NOT ready.
   if(stream_wl->is_timed_stream && (buff_attrib->render_time_stamp == ISMD_NO_PTS)){
      stream_wl->out_buf_ready = false;
   }

   else if(stream_wl->first_buffer_dequeued) {

      /* Need to normalize the render timestamp once before checking for a release time. */
      if(stream_wl->is_timed_stream && (buff_attrib->render_time_stamp != ISMD_NO_PTS) && !stream_wl->rend_ts_normalized){
         buff_attrib->render_time_stamp = audio_core_normalize_sample_count(buff_attrib->render_time_stamp, AUDIO_NORMAL_SAMPLE_RATE, stream_wl->curr_stream_info.sample_rate);
         stream_wl->rend_ts_normalized = true;
      }

      //Since this is inside a for loop and we are trying to send out buffers alligned need to only get these
      //variables once in the for loop for multiple streams. The refresh_numbers will get set back to true
      //on the next clock alarm. Get the render numbers in terms of 192kHz.
      if(base_numbers->refresh_numbers){
         result = audio_core_get_render_base_numbers(stream_wl->atc_wl->processor_id, AUDIO_NORMAL_SAMPLE_RATE, &base_numbers->render_smpl_cnt, &base_numbers->render_level_in_smpls);
         base_numbers->refresh_numbers = false;
      }
      else{
         result = ISMD_SUCCESS;
      }

      //Ask the render where he is at in processing the data, if there is no render active, just release the buffer, we are in file output only mode.
      if(result == ISMD_SUCCESS) {

         //Add the back end delay to the render numbers and see if we are ok to release the buffer.
         curr_render_time = base_numbers->render_level_in_smpls + base_numbers->render_smpl_cnt + (AUDIO_CHUNK_SIZE_SAMPLES(stream_wl->atc_wl) * ((stream_wl->fixed_back_end_delay_ms/stream_wl->time_period_ms)));
         curr_render_time_cached = curr_render_time;

         //If this is the first time through set the first current render time.
         if(stream_wl->prev_render_time == ISMD_NO_PTS) {
            stream_wl->prev_render_time = curr_render_time;
         }

         //Since we incremented the render_time from last time exactly 1 chunk, if we dont match up
         //the render has not yet updated the samples_rendered variable usually by one chunk, since
         //the call is asyncronous. Ajdust the current render time to be what the timestamp is giong to
         //be so that we will release the buffer to the render. If we are more than 1 time slots drifted,
         //reset our counter (prev_render_time) to match the current time.
         drift = (int)(stream_wl->prev_render_time -curr_render_time);
         if( ABS(drift) == AUDIO_CHUNK_SIZE_SAMPLES(stream_wl->atc_wl)) {
             curr_render_time = stream_wl->prev_render_time;
         }
         else if(ABS(drift) > AUDIO_CHUNK_SIZE_SAMPLES(stream_wl->atc_wl)){

            AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
               SVEN_MODULE_EVENT_AUD_IO_ATC_RENDER_DRIFT_DETECTED,
               stream_wl->atc_wl->handle,
               stream_wl->handle,
               drift,
               (int)stream_wl->prev_render_time,
               (int)curr_render_time,
               true);

            stream_wl->prev_render_time = curr_render_time;
         }

         //If we are in an untimed stream, just use the current time first for the time-stamp
         if(!stream_wl->is_timed_stream){
            buff_attrib->render_time_stamp =  stream_wl->prev_render_time;
         }

         //Make sure the current render time is at least further along then we need to be
         if(curr_render_time == buff_attrib->render_time_stamp) {
            release_buffer = true;
         }
         //If for some reason the current render time has gone past the time we have to
         //send out the buffer, need to reset the stream if we are more than 1 chunk off.
         else if(curr_render_time > buff_attrib->render_time_stamp) {

            if((curr_render_time - buff_attrib->render_time_stamp) > (uint64_t)(AUDIO_CHUNK_SIZE_SAMPLES(stream_wl->atc_wl) )){

               AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
                  SVEN_MODULE_EVENT_AUD_IO_ATC_OUTPUT_ATEMPT_LATE,
                  stream_wl->handle,
                  (int)(curr_render_time - buff_attrib->render_time_stamp),
                  drift,
                  (int)curr_render_time,
                  (int)buff_attrib->render_time_stamp,
                  (int)curr_render_time_cached );

               audio_pvt_atc_reset_for_new_stream(stream_wl);
               reset = true;
            }
            else{
               release_buffer = true;
            }
         }

         //If we have reset we dont want to increment the prev_render_time since it will roll over.
         if(!reset) {
            //Increment this one time slice to compare for next time around.
            stream_wl->prev_render_time += AUDIO_CHUNK_SIZE_SAMPLES(stream_wl->atc_wl);
         }
      }
      //No active render processing audio data.
      else {

         //If we have been told to discard on bad render data. If not
         //Do not attempt to throw away the buffer, just go ahead to send it.
         //The idea here is we dont want to send out data to renders when
         //none of them are active.
         if(stream_wl->atc_wl->output_discard_policy == ATC_OUTPUT_DISCARD_ON_RENDER_NOT_PRESENT){
            *discard = true;
         }
         
         release_buffer = true;
         base_numbers->refresh_numbers = true;
      }
   }

   //This handles the case where we not filling silence, and we never recieved any data to process,
   //but we recieved the EOS. Still need to propagate it.
   else if(stream_wl->have_eos) {
      release_buffer = true;
      stream_wl->out_buf_ready = true;
      if ( ismd_tag_set_eos (stream_wl->output_buffer->unique_id) != ISMD_SUCCESS) {
         AUDIO_ERROR("ATC Could not set eos tag", ISMD_ERROR_NOT_FOUND, atc_devh);
      }
      stream_wl->have_eos = false;
      stream_wl->output_buffer->phys.level = 0;
   }
   if(!reset) {
   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
      SVEN_MODULE_EVENT_AUD_IO_ATC_CLOCK_ALARM,
      stream_wl->handle,
      stream_wl->output_buffer->phys.level,
      (unsigned int)(buff_attrib->render_time_stamp  >> 32),
      (unsigned int)(buff_attrib->render_time_stamp ),
      (unsigned int)(curr_render_time_cached  >> 32),
      (unsigned int)(curr_render_time_cached ));
   }

   return release_buffer;
}

static ismd_result_t
audio_pvt_atc_alloc_out_buffer(audio_atc_stream_context_t *stream_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   //If the output buffer is null and we are not in passthrough mode, alloc a new buffer for output
   if( stream_wl->output_buffer == NULL ){

      if( (result = ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS_CACHED, ATC_OUTPUT_BUFFER_SIZE, &(stream_wl->output_buffer))) == ISMD_SUCCESS) {
         audio_pvt_atc_reset_buffer_metadata((audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes));
         stream_wl->output_buffer_is_silence = false;
      }
      else {
         OS_PRINT("Audio Timing Control thread cannot allocate an SMD buffer!\n");
      }
   }
   return result;
}

static ismd_result_t
audio_pvt_atc_get_base_numbers(audio_atc_stream_context_t *stream_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   unsigned int render_level_samples = 0;

   if(stream_wl->is_timed_stream) {

      //Get info from the renders
      audio_core_get_render_base_numbers(stream_wl->atc_wl->processor_id, stream_wl->curr_stream_info.sample_rate, &(stream_wl->render_sample_count), &render_level_samples);

      //clock_ticks =  (audio_samples * 90000)/aud_sample_rate
      stream_wl->render_delay_ticks = ((render_level_samples * (uint32_t)CLOCK_SPEED_HZ)/((uint32_t)stream_wl->curr_stream_info.sample_rate));
      stream_wl->render_delay_samples = render_level_samples;

      /* If we dont have a clock on this input grab the main clock handle.*/
      if(stream_wl->clock_h == ISMD_CLOCK_HANDLE_INVALID) {
         stream_wl->clock_h = stream_wl->atc_wl->dev_wl->default_clock_h;
      }

      //Get our base time from the STC
      result = ismd_clock_get_time_th_safe(stream_wl->clock_h, &stream_wl->atc_base_time);
      if(result != ISMD_SUCCESS) {
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "atc: ismd_clock_get_time_th_safe failed!", atc_devh);
      }


      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
         SVEN_MODULE_EVENT_AUD_IO_ATC_GET_BASE_NUMBERS,
         (unsigned int) stream_wl->atc_wl->handle,
         (unsigned int) stream_wl->handle,
         (unsigned int) (stream_wl->render_sample_count >> 32),
         (unsigned int) (stream_wl->render_sample_count),
         (unsigned int) (stream_wl->atc_base_time >> 32),
         (unsigned int) (stream_wl->atc_base_time));
   }

   return result;
}

static bool
audio_pvt_atc_top_off_buffer(audio_atc_stream_context_t *stream_wl)
{
   bool result = false;
   int copy_base_addr = 0;
   size_t copy_size = 0;
   int incoming_level = 0;
   audio_buffer_attr_t *buff_attrib =  NULL;

   AUDIO_ENTER(atc_devh);

   if(stream_wl->output_buffer != NULL) {

      //If the buffer is not full fill the rest of it with silence, upto chunck sizes
      if(stream_wl->output_buffer->phys.level < stream_wl->curr_chunk_size) {

         //Only top off the buffer if we have sent the first buffer for a timed stream.
         if(stream_wl->sent_first_frame) {

            incoming_level = stream_wl->output_buffer->phys.level;
            copy_base_addr = (((int)stream_wl->output_buffer->virt.base) + stream_wl->output_buffer->phys.level);
            copy_size = stream_wl->curr_chunk_size - stream_wl->output_buffer->phys.level;

            //Make sure the copy size + level is not bigger than the buffer.
            if((int)(copy_size + stream_wl->output_buffer->phys.level) < stream_wl->output_buffer->phys.size) {

               /*Add the silence in, call to update the discontinuity metadata.*/
               OS_MEMSET((void*)copy_base_addr, 0, copy_size);
               audio_pvt_atc_discont_metadata_update(stream_wl, copy_size);
               stream_wl->output_buffer->phys.level += copy_size;

               stream_wl->out_buf_ready = true;
               result = true;

               /*If we filled the buffer completely with silence, set the flag.*/
               if(stream_wl->output_buffer->phys.level == (int)copy_size) {
                  stream_wl->output_buffer_is_silence = true;
               }

               //Make sure we dont have any invalid metadata when filling silence.
               buff_attrib = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);
               if(buff_attrib->sample_rate == ATC_OUT_BUFFER_NEEDS_METADATA) {

                  buff_attrib->sample_rate = stream_wl->curr_stream_info.sample_rate;
                  buff_attrib->sample_size = stream_wl->curr_stream_info.sample_size;
                  buff_attrib->channel_count = stream_wl->curr_stream_info.channel_count;
                  buff_attrib->channel_config = stream_wl->curr_stream_info.channel_config;
                  buff_attrib->audio_format = stream_wl->curr_stream_info.audio_format;
               }

               //Record the event
               AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
                  SVEN_MODULE_EVENT_AUD_IO_ATC_FILL_SILENCE,
                  (unsigned int) stream_wl->atc_wl->handle,
                  (unsigned int) stream_wl->handle,
                  (unsigned int) incoming_level,
                  (unsigned int) copy_size,
                  ((stream_wl->output_buffer != NULL) ? (unsigned int) stream_wl->output_buffer->phys.level : 0), 0);
            }

            else {

               AUDIO_ERROR("level + copy is bigger than buffer", result,  atc_devh);
            }
         }
      }

      else if(stream_wl->output_buffer->phys.level == stream_wl->curr_chunk_size) {
         stream_wl->out_buf_ready = true;
      }

      else {
         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_SILENCE_TOP_OFF_ERROR,
                  stream_wl->atc_wl->handle, stream_wl->handle, __LINE__, stream_wl->curr_chunk_size, stream_wl->output_buffer->phys.level, 0);

         stream_wl->output_buffer->phys.level = stream_wl->curr_chunk_size;
         stream_wl->out_buf_ready = true;
      }
   }

   AUDIO_EXIT(atc_devh);

   return result;

}


/*
   This function returns the amount of silence it actually padded as the return value,
   which may differ from the desired amount to pad. The maximum pad limit is calulated
   based off of the current chunk size we can send out.
*/
static int
audio_pvt_atc_pad_silence(audio_atc_stream_context_t *stream_wl, size_t num_bytes, int curr_chunk_size)
{
   int bytes_padded = 0;
   ismd_buffer_descriptor_t *buffer = stream_wl->output_buffer;

   if( num_bytes ) {

      /* If the amount we want to pad is larger than the current chunk size, only copy a chunk size.*/
      if((num_bytes + (uint32_t)buffer->phys.level)  >= (uint32_t)curr_chunk_size){

         bytes_padded = curr_chunk_size - buffer->phys.level;
      }
      else {
         bytes_padded = num_bytes;
      }

      if(bytes_padded > 0){
         /*Add the silence in, call to update the discontinuity metadata.*/
         OS_MEMSET((void*)((int)buffer->virt.base + buffer->phys.level), 0, bytes_padded);
         audio_pvt_atc_discont_metadata_update(stream_wl, bytes_padded);
         buffer->phys.level += bytes_padded;
      }
   }

   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
      SVEN_MODULE_EVENT_AUD_IO_ATC_PAD_SILENCE,
      (unsigned int) buffer->phys.level,
      (unsigned int) curr_chunk_size,
      (unsigned int) num_bytes,
      (unsigned int) bytes_padded, 0, 0);

   return bytes_padded;
}

static void
audio_pvt_atc_drop_samples(audio_atc_stream_context_t *stream_wl)
{
   int bytes_avail_to_drop = 0;
   int actual_bytes_dropped = 0;
   int total_bytes_cached = 0;
   int bytes_from_out_buffer = 0;

   AUDIO_ENTER(atc_devh);

   /*Need to check the output buffer to see if we have any samples to drop out of it. This only applies if we are doing trick modes.*/
   if((stream_wl->output_buffer->phys.level > 0) && (stream_wl->rate != ISMD_NORMAL_PLAY_RATE)) {

      /* Check to see if we have more bytes in the output buffer than we have to drop*/
      if(stream_wl->output_buffer->phys.level >= (int)stream_wl->drop_bytes) {

         bytes_from_out_buffer = stream_wl->drop_bytes;
      }
      else {
         bytes_from_out_buffer = stream_wl->output_buffer->phys.level;
      }

      /*Make sure we dont overrun our fix-up buffer, if these numbers are bad spit out a warning.*/
      if((stream_wl->drop_buffer->phys.level + bytes_from_out_buffer) <= stream_wl->drop_buffer->phys.size){

         /*Store these also in the temp buffer for processing on the output.*/
         OS_MEMCPY((void*)((int)stream_wl->drop_buffer->virt.base + stream_wl->drop_buffer->phys.level), (void*)stream_wl->output_buffer->virt.base, bytes_from_out_buffer);
         stream_wl->drop_buffer->phys.level += bytes_from_out_buffer;
         stream_wl->bytes_to_fix += bytes_from_out_buffer;
      }
      else{
         OS_PRINT("\nAUDIO WARN: Blocked sample clean up buffer overrun. Report this as a non-fatal bug.\n");
         stream_wl->bytes_to_fix = 0;
         stream_wl->drop_buffer->phys.level = 0;
      }

      stream_wl->drop_bytes -= bytes_from_out_buffer;
      stream_wl->output_buffer->phys.level -= bytes_from_out_buffer;

      /* If we still have data left in the output buffer shift it back to the base of the buffer.
        * Note this is a very rare case, so this memcpy will not happen very often.*/
      if(stream_wl->output_buffer->phys.level > 0) {
         OS_MEMCPY(stream_wl->output_buffer->virt.base, (void*)((int)stream_wl->output_buffer->virt.base + bytes_from_out_buffer), stream_wl->output_buffer->phys.level);
      }
   }

   /*If there is still more to drop, start dropping from the input buffer.*/
   if(stream_wl->drop_bytes > 0) {

      bytes_avail_to_drop = (stream_wl->input_buffer->phys.level - stream_wl->in_buf_bytes_copied);
      total_bytes_cached = stream_wl->drop_bytes; //For sven event

      /* If the amount we want to drop is more than we have to drop, only drop what we have availalble currently */
      if( (int)stream_wl->drop_bytes >= bytes_avail_to_drop ) {

         actual_bytes_dropped = bytes_avail_to_drop;
      }
      else {
         actual_bytes_dropped = stream_wl->drop_bytes;
      }

      /*Only try to "fix up" samples when we are in trick modes. There are other cases where we dont want
       *samples to be fixed, like seamless connection cases, when a new segment describes the need to drop
       *samples we shouldn't try to fix them. */
      if((stream_wl->rate != ISMD_NORMAL_PLAY_RATE)) {

         /*Make sure we dont overrun our fix-up buffer, if these numbers are bad spit out a warning.*/
         if((stream_wl->drop_buffer->phys.level + actual_bytes_dropped) <= stream_wl->drop_buffer->phys.size){

            /*Save the dropped samples for processing later on */
            OS_MEMCPY((void*)((int)stream_wl->drop_buffer->virt.base + stream_wl->drop_buffer->phys.level), (void*)( (int)stream_wl->input_buffer->virt.base + stream_wl->in_buf_bytes_copied), actual_bytes_dropped);
            stream_wl->drop_buffer->phys.level += actual_bytes_dropped;
            stream_wl->bytes_to_fix += actual_bytes_dropped;
         }
         else{
            OS_PRINT("\nAUDIO WARN: Blocked sample clean up buffer overrun. Report this as a non-fatal bug.\n");
            stream_wl->bytes_to_fix = 0;
            stream_wl->drop_buffer->phys.level = 0;
         }
      }

      /* Update our stream state variables */
      stream_wl->drop_bytes -= actual_bytes_dropped;
      stream_wl->in_buf_bytes_copied += actual_bytes_dropped;
      stream_wl->bytes_since_last_pts += actual_bytes_dropped;

   }

   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
      SVEN_MODULE_EVENT_AUD_IO_ATC_DROPPED_SAMPLES,
      (unsigned int) total_bytes_cached,
      (unsigned int) bytes_avail_to_drop,
      (unsigned int) actual_bytes_dropped, 0, 0, 0);

AUDIO_EXIT(atc_devh);
   return;
}


static void
audio_pvt_atc_handle_sample_cleanup(audio_atc_stream_context_t *stream_wl)
{
   audio_buffer_attr_t *buff_attrib =  (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);
   int smpl_cnt_output = audio_core_bytes_to_samples(buff_attrib->sample_size, buff_attrib->channel_count, stream_wl->output_buffer->phys.level );
   int smpl_cnt_drop = audio_core_bytes_to_samples(buff_attrib->sample_size, buff_attrib->channel_count, stream_wl->drop_buffer->phys.level );
   int drop_buffer_index = smpl_cnt_drop - ((int)audio_core_bytes_to_samples(buff_attrib->sample_size, buff_attrib->channel_count, stream_wl->bytes_to_fix));

   AUDIO_ENTER(atc_devh);

   // 16 bit case not supported in other algo, also want to use this on normal dropping cases.
   if(stream_wl->rate == ISMD_NORMAL_PLAY_RATE) {

      audio_fixup_discontinuity(
         (int *) stream_wl->drop_buffer->virt.base,
         stream_wl->output_buffer->virt.base,
         smpl_cnt_output,
         buff_attrib->sample_size,
         buff_attrib->channel_count,
         smpl_cnt_output);

      stream_wl->bytes_to_fix = 0;
   }

   else if((buff_attrib->sample_size == 32) ||(buff_attrib->sample_size == 16)){

      if((stream_wl->drop_buffer->phys.level - stream_wl->bytes_to_fix) > stream_wl->drop_buffer->phys.size){
         OS_PRINT("AUDIO_TM_ERROR: drop buffer is overrun: %d\n", (stream_wl->drop_buffer->phys.level - stream_wl->bytes_to_fix));
         stream_wl->bytes_to_fix = 0;
      }
      else {
         audio_fix_samples(
            (int *) (((int)stream_wl->drop_buffer->virt.base) + (stream_wl->drop_buffer->phys.level - stream_wl->bytes_to_fix)),
            smpl_cnt_drop,
            (int *)stream_wl->output_buffer->virt.base,
            smpl_cnt_output,
            drop_buffer_index,
            buff_attrib->channel_count,
            buff_attrib->sample_size);

         stream_wl->bytes_to_fix -= stream_wl->output_buffer->phys.level;
      }
   }

   //Cases we dont support for cleanup, ie 24bit 20bit
   else {
      stream_wl->bytes_to_fix = 0;
   }

   //Done with the buffer, so reset the level.
   if(stream_wl->bytes_to_fix == 0) {
      stream_wl->drop_buffer->phys.level = 0;
      stream_wl->fixing_samples = false; //Ended stream of fixing samples.
   }

   AUDIO_EXIT(atc_devh);
   return;
}

static void
audio_pvt_atc_handle_metadata(audio_atc_stream_context_t *stream_wl)
{
   audio_uint64_t render_time_stamp = ISMD_NO_PTS;
   audio_discont_desc_t discont_desc_saved;
   audio_buffer_attr_t *output_buff_attr = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);
   audio_buffer_attr_t *input_buff_attr = (audio_buffer_attr_t *) &(stream_wl->input_buffer->attributes);
   unsigned int adjust_ticks = 0;

   /*If the output buffer doesnt have metadata copy it over.*/
   if (output_buff_attr->sample_rate == ATC_OUT_BUFFER_NEEDS_METADATA) {
      
      /* Copy over the metadata, save/restore render timestamp.*/
      render_time_stamp = output_buff_attr->render_time_stamp;
      discont_desc_saved = output_buff_attr->discontinuity_desc;
      *output_buff_attr = *input_buff_attr;
      output_buff_attr->render_time_stamp = render_time_stamp;
      output_buff_attr->discontinuity_desc = discont_desc_saved;
         
      /*Clear out the PTS values since that is handled below.*/
      output_buff_attr->original_pts = ISMD_NO_PTS;
      output_buff_attr->linear_pts = ISMD_NO_PTS;
      output_buff_attr->local_pts = ISMD_NO_PTS;
      /*Reset outbuffer's opt metadata offset*/
      output_buff_attr->opt_metadata_offset = OPT_METADATA_INVALID;
   }

   /* Since this function is called when we know we have input
      data to copy to the output, need to update the PTS on the
      output buffer if it so happens that this buffer has a valid 
      PTS that associated with the begining of the samples. */
   if((stream_wl->in_buf_bytes_copied == 0) && (input_buff_attr->original_pts != ISMD_NO_PTS)) {
      
      output_buff_attr->original_pts = input_buff_attr->original_pts;
      output_buff_attr->linear_pts = input_buff_attr->linear_pts;
      output_buff_attr->local_pts = input_buff_attr->local_pts;

      /* If there is data in the output buffer, need to account for that data and subtract
        that amount in terms of clock ticks to the PTS value. Store this in segment_pts
        PTS slot in the interpolated_info. */
      if(stream_wl->output_buffer->phys.level > 0) {
         
         adjust_ticks = (unsigned int)audio_core_bytes_to_ticks(input_buff_attr->sample_size, 
                                   input_buff_attr->sample_rate, 
                                   input_buff_attr->channel_count, 
                                   (uint64_t)stream_wl->output_buffer->phys.level);
      }
      /* Assign the PTS making the adjustment for the data in the output buffer. 
       * For both ATC UNTIMED mode or TIMED mode 
       */
      stream_wl->interpolated_info.adjust_ticks = adjust_ticks;
   }

   /* Handle copying over optional metadata from the input buffer.*/
   if ( !VALID_OPT_METADATA(stream_wl->output_buffer) ) {
      copy_opt_metadata( stream_wl->output_buffer, stream_wl->input_buffer );
   }

}

//This function returns true if data moves from input buffer to output buffer, else false.
static bool
audio_pvt_atc_prepare_output_buffer(audio_atc_stream_context_t *stream_wl)
{
   bool moved_data = false;
   size_t copy_size = 0;
   int in_buf_new_base = 0;
   int out_buf_new_base = 0;
   int bytes_padded = 0;
   int client_id;
   int tag_input_handle;
   int vchunk_adjust_bytes = 0;
   audio_buffer_attr_t *audio_buffer_attr;
   audio_buffer_attr_t *audio_tag_buf_attr;
   void *input_virt_addr = NULL;


      //Only try this copy if the input_buffer is not emptry
      if( (stream_wl->input_buffer != NULL) && (stream_wl->output_buffer != NULL) && !stream_wl->out_buf_ready) {
         
         vchunk_adjust_bytes = stream_wl->curr_chunk_size; // Initialize to chunk size in bytes

         if ((stream_wl->drop_bytes == 0 && stream_wl->pad_silence_bytes == 0) && (stream_wl->asrc.vsrc_support_enabled) ){
         /* atc varible of chunk size is a very fine adjustment, just few samples for several chunks
                  * if there is bytes padding or dropped, means ATC already try to adjust AV sync. we will reset vchunk adjustment.
                  * variable chunk size take effect and try to avoid padding or dropping bytes from ATC
                  */
            if(stream_wl->asrc.sample_drift_per_chunk != 0){      
               vchunk_adjust_bytes -= (audio_core_samples_to_bytes(
                     stream_wl->curr_stream_info.sample_size, 
                     stream_wl->curr_stream_info.channel_count, 
                     stream_wl->asrc.sample_drift_per_chunk));
            }
         }

         /* If during a PTS calc we need to add silence, do it here */
         if(stream_wl->pad_silence_bytes) {
            
            bytes_padded = audio_pvt_atc_pad_silence(stream_wl, stream_wl->pad_silence_bytes, stream_wl->curr_chunk_size) ;
            stream_wl->pad_silence_bytes = (stream_wl->pad_silence_bytes - bytes_padded);

            /*If we filled the buffer completely with silence, set the flag.*/
            if(stream_wl->output_buffer->phys.level == bytes_padded) {
               stream_wl->output_buffer_is_silence = true;
            }
         }

         /* For trick modes, need to drop samples ocacionaly, only drop if we are not in the middle of a fix */
         if(stream_wl->drop_bytes && !stream_wl->fixing_samples) {
            audio_pvt_atc_drop_samples(stream_wl);
         }

         //See how much data we need to copy from the input buffer
         copy_size = ( vchunk_adjust_bytes - stream_wl->output_buffer->phys.level );

         //If the copy size is bigger than what we have in the input_buffer, only copy what we have.
         if(copy_size > (size_t)(stream_wl->input_buffer->phys.level - stream_wl->in_buf_bytes_copied)) {
            copy_size = (size_t)(stream_wl->input_buffer->phys.level - stream_wl->in_buf_bytes_copied);
         }
         
         /* Only do the copy if we actually have something to copy*/
         if(copy_size > 0) {

            /*Call handling metadata only if we have data to copy since this indicates we have
              an input buffer with valid metadata to copy over. Keep this call inside this if block. */
            audio_pvt_atc_handle_metadata(stream_wl);

            /* Make sure to use the correct virtual address, some buffers are cached inside the ATC. */
            input_virt_addr = (stream_wl->in_cached_address == NULL) ? stream_wl->input_buffer->virt.base : stream_wl->in_cached_address;

            /* Adjust the base addresses for both input and output buffers, they both could be partial. */
            in_buf_new_base = (((int)input_virt_addr) + stream_wl->in_buf_bytes_copied);
            out_buf_new_base = (((int)stream_wl->output_buffer->virt.base) + stream_wl->output_buffer->phys.level);

            AUDIO_EVENT(AUDIO_SVEN_LOG_GENERAL, atc_devh,
               SVEN_MODULE_EVENT_AUD_IO_ATC_PRE_BUFFER_CHOP,
               (unsigned int) vchunk_adjust_bytes,
               (unsigned int) copy_size,
               (unsigned int) stream_wl->input_buffer->phys.level,
               (unsigned int) stream_wl->output_buffer->phys.level,
               (unsigned int) in_buf_new_base,
               (unsigned int) out_buf_new_base);

            /* Do the copy. The input/output buffers are both cached at this point. */
            OS_MEMCPY((void*)out_buf_new_base, (void*)in_buf_new_base, copy_size);

            moved_data = true; //Data has moved at this point, mark true..

            //Update the levels on input and output buffers
            stream_wl->output_buffer->phys.level += copy_size;
            stream_wl->in_buf_bytes_copied += copy_size;

            //This variable is only used in trick modes.
            if(stream_wl->rate != ISMD_NORMAL_PLAY_RATE) {
               stream_wl->bytes_since_last_pts += copy_size;
            }
         }

         //If the output buffer level is the correct chunk size, flag it ready to go.
         if(stream_wl->output_buffer->phys.level >= vchunk_adjust_bytes) {

            stream_wl->out_buf_ready = true;
            stream_wl->asrc.sample_drift_per_chunk = 0;
            stream_wl->last_out_buf_ended_in_silence = false;
            
            //If we need to fix the discontinuity do it here.
            if(stream_wl->bytes_to_fix) {
               stream_wl->fixing_samples = true; //started stream of fixing samples.
               audio_pvt_atc_handle_sample_cleanup(stream_wl);
            }

            //Update the total amount of samples we have processed for stats.
            stream_wl->stream_pos.sample_count += (uint64_t)audio_core_bytes_to_samples(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, stream_wl->output_buffer->phys.level);

            /*If the output buffer is ever bigger than the chunk size its a major error.*/
            if(stream_wl->output_buffer->phys.level > vchunk_adjust_bytes) {
               OS_PRINT("\nSMD AUDIO: ERROR: ATC output buffer level is larger than time slice!!\n");
            }
         }

         AUDIO_EVENT(AUDIO_SVEN_LOG_GENERAL, atc_devh,
            SVEN_MODULE_EVENT_AUD_IO_ATC_POST_BUFFER_CHOP,
            (unsigned int) stream_wl->atc_wl->handle,
            (unsigned int) stream_wl->handle,
            (unsigned int) stream_wl->out_buf_ready,
            (unsigned int) stream_wl->in_buf_bytes_copied,
            (unsigned int) stream_wl->output_buffer->phys.level,
            (unsigned int)(stream_wl->input_buffer->phys.level -stream_wl->in_buf_bytes_copied));

         //If the amount of bytes we copied is the equal to the level, dereference the buffer, we are done with  it.
         if(stream_wl->input_buffer->phys.level == stream_wl->in_buf_bytes_copied) {

            audio_buffer_attr = (audio_buffer_attr_t *)(stream_wl->input_buffer->attributes);
            tag_input_handle = audio_buffer_attr->tag_input_h;
            audio_buffer_attr->tag_input_h = AUDIO_INVALID_HANDLE;
            audio_tag_buf_attr = (audio_buffer_attr_t *)(stream_wl->output_buffer->attributes);
            audio_tag_buf_attr->tag_input_h = tag_input_handle;

            if ((ismd_tag_get_client_id(stream_wl->input_buffer->unique_id, &client_id)) == ISMD_SUCCESS) {
               if(ismd_tag_set_client_id(stream_wl->output_buffer->unique_id, client_id) != ISMD_SUCCESS){
                  AUDIO_ERROR("ATC Could not set client ID tag", ISMD_ERROR_NOT_FOUND, audio_devh[AUDIO_DEBUG_SCRUB]);
               }
            }

            /* If we get EOS on the input, tag the output buffer with EOS*/
            if (stream_wl->have_eos) {
               if ( ismd_tag_set_eos (stream_wl->output_buffer->unique_id) != ISMD_SUCCESS) {
                  AUDIO_ERROR("ATC Could not set eos tag", ISMD_ERROR_NOT_FOUND, audio_devh[AUDIO_DEBUG_SCRUB]);
               }
               stream_wl->have_eos = false;
            }

            audio_pvt_atc_input_buffer_dereference(stream_wl);
            stream_wl->in_buf_bytes_copied = 0;
         }

      }

   return moved_data;
}


static ismd_result_t
audio_pvt_atc_input_validate_metadata(audio_atc_stream_context_t *stream_wl, audio_buffer_attr_t * buffer_attrib, bool *discard_buffer)
{
   ismd_result_t result = ISMD_SUCCESS;

      /* Do a sanity check on the the metadata. If it is not valid discard buffer and notify user. */
   if (!audio_core_is_valid_metadata(buffer_attrib->sample_rate, buffer_attrib->sample_size, buffer_attrib->channel_count)) {

      *discard_buffer = true;

      result = ISMD_ERROR_INVALID_PARAMETER;

      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_INVALID_METADATA,
         stream_wl->handle,
         stream_wl->input_buffer->tags_present,
         stream_wl->input_buffer->phys.level,
         buffer_attrib->sample_rate,
         buffer_attrib->sample_size,
         buffer_attrib->channel_count);
   }

   return result;
}


static ismd_result_t
audio_pvt_atc_handle_newsegment_timed( audio_atc_stream_context_t *stream_wl )
{
   ismd_newsegment_tag_t newsegment_data;
   ismd_result_t result = ISMD_SUCCESS;

   if ( stream_wl->input_buffer->tags_present ) {

      if ((result = ismd_tag_get_newsegment( stream_wl->input_buffer->unique_id, &newsegment_data )) == ISMD_SUCCESS ) {

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_ATC],
            SVEN_MODULE_EVENT_AUD_IO_ATC_NEWSEGMENT,
            stream_wl->handle,
            (unsigned int) newsegment_data.start,
            (unsigned int) newsegment_data.stop,
            (unsigned int) newsegment_data.linear_start,
            newsegment_data.requested_rate,
            stream_wl->rebase_info.curr_rate);

         /* Only update these variables if the rate is actually changing. */
         if(newsegment_data.rate_valid && (stream_wl->rate != newsegment_data.requested_rate) && !stream_wl->ignore_inband_rate_change) {

            /* Figure out the new "last_scaled_rate_change_time" */
            ismd_convert_linear_time_to_scaled_time(
                  newsegment_data.linear_start,
                  stream_wl->rebase_info.last_linear_rate_change_time,
                  stream_wl->rebase_info.last_scaled_rate_change_time,
                  stream_wl->rebase_info.curr_rate,
                  & stream_wl->rebase_info.last_scaled_rate_change_time);

            /* Update the last linear rate change time */
            stream_wl->rebase_info.last_linear_rate_change_time =  newsegment_data.linear_start;

            /* If we are changing rates and we will actually do the trick mode we need to flush up to the ATC */
            if((newsegment_data.requested_rate >= AUDIO_MIN_PLAY_RATE) &&
               (newsegment_data.requested_rate <= AUDIO_MAX_PLAY_RATE)) {

               stream_wl->rate = newsegment_data.requested_rate;
            }

            /* Update the last linear rate change time to the current linear start time. */
            stream_wl->rebase_info.curr_rate = newsegment_data.requested_rate;
         }

         /*Flag that we have the new segment, and reset so the start of 
           segment event will fire again for the new segment. */
         stream_wl->has_newsegment = true;
         stream_wl->start_of_seg_found = false;
         
         /*Record the current segement info */
         memcpy(&(stream_wl->rebase_info.curr_seg_info), &newsegment_data, sizeof(ismd_newsegment_tag_t));

         /* Need to reset the current position when a newsegment comes in. */
         stream_wl->curr_position_ticks = ISMD_NO_PTS;

         stream_wl->last_buffer_discrd_pts_past_stop_value = false;

      }
   }

   return ( result );
}


static ismd_result_t
audio_pvt_atc_handle_pts_scaling( audio_atc_stream_context_t *stream_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_pts_t  segment_pts = ISMD_NO_PTS;
   ismd_pts_t scaled_pts = ISMD_NO_PTS;
   ismd_pts_t linear_pts = ISMD_NO_PTS;

   if(stream_wl->input_buffer != NULL) {

      /*Get the original PTS value from the stream to scale.*/
      segment_pts = ((audio_buffer_attr_t *)&(stream_wl->input_buffer->attributes))->original_pts;

      //Rebase the PTS if its valid.
      if( segment_pts != ISMD_NO_PTS) {

         //Check to see if we have a valid start time, if not assign it to the first PTS
         if( stream_wl->rebase_info.curr_seg_info.start == ISMD_NO_PTS ) {
            stream_wl->rebase_info.curr_seg_info.start = segment_pts; //Might be -1 in reverse, should be error other wise if in forward playback.
         }

         result = ismd_convert_segment_time_to_linear_time(
                              segment_pts,
                              stream_wl->rebase_info.curr_seg_info.start,
                              stream_wl->rebase_info.curr_seg_info.stop,
                              stream_wl->rebase_info.curr_rate,
                              stream_wl->rebase_info.curr_seg_info.linear_start,
                              &linear_pts );

         if(ISMD_SUCCESS == result){
           result = ismd_convert_linear_time_to_scaled_time(
                                 linear_pts,
                                 stream_wl->rebase_info.last_linear_rate_change_time,
                                 stream_wl->rebase_info.last_scaled_rate_change_time,
                                 stream_wl->rebase_info.curr_rate,
                                 &scaled_pts);
         }

         //If these functions didnt actually convert correctly, just put no PTS since no conversion could happen.
         if(result != ISMD_SUCCESS) {
            scaled_pts = ISMD_NO_PTS;
            linear_pts = ISMD_NO_PTS;
         }

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_ATC],
            SVEN_MODULE_EVENT_AUD_IO_ATC_SCALE_PTS,
            (unsigned int) (segment_pts >>32),
            (unsigned int) (segment_pts),
            (unsigned int) (linear_pts >> 32),
            (unsigned int) (linear_pts),
            (unsigned int) (scaled_pts >> 32),
            (unsigned int) (scaled_pts));

         /*Re-assign the new PTS as the PTS to use down-stream */
         ((audio_buffer_attr_t *)&(stream_wl->input_buffer->attributes))->local_pts = scaled_pts;
         ((audio_buffer_attr_t *)&(stream_wl->input_buffer->attributes))->linear_pts = linear_pts;
         ((audio_buffer_attr_t *)&(stream_wl->input_buffer->attributes))->original_pts = segment_pts;

      }
      else {
         ((audio_buffer_attr_t *)&(stream_wl->input_buffer->attributes))->local_pts = ISMD_NO_PTS;
         ((audio_buffer_attr_t *)&(stream_wl->input_buffer->attributes))->linear_pts = ISMD_NO_PTS;
         ((audio_buffer_attr_t *)&(stream_wl->input_buffer->attributes))->original_pts = ISMD_NO_PTS;

      }
   }

   return ( ISMD_SUCCESS );
}

static bool
audio_pvt_atc_found_start_of_segment(audio_atc_stream_context_t *stream_wl, ismd_pts_t segment_pts)
{
   bool result = false;

   /*Need to have current segment information and a valid PTS*/
   if(stream_wl->has_newsegment && (segment_pts != ISMD_NO_PTS)) {

      /* If the PTS is after the start PTS and is before the stop point.*/
      if((segment_pts >= stream_wl->rebase_info.curr_seg_info.start) &&
         (segment_pts < stream_wl->rebase_info.curr_seg_info.stop)) {

         result = true;
      }

      /*If in reverse the start PTS is invalid, but PTS is before the stop value.*/
      if ((stream_wl->rebase_info.curr_seg_info.start == ISMD_NO_PTS) && 
          (segment_pts <= stream_wl->rebase_info.curr_seg_info.stop)) {
          
         result = true;
      }
   }

   return result;
}

/* This will parse the timing info (newsegment/pts) and discard buffer until
 * certain condition(eos or first pts fits into segment) meet. After this condition,
 * a soseg event will be generated and the input stream will be paused.
 * The next start of segment search will be performed after a flush of the 
 * input stream. */
static void
audio_pvt_atc_check_for_start_of_segment(audio_atc_stream_context_t *stream_wl, ismd_pts_t segment_pts, bool *discard_buffer)
{
   /*If we have not found the start of the segment look for it.*/
   if (!stream_wl->start_of_seg_found) {

      /*If EOS is found before we find start of segment, notify we have start of segment.*/
      if(stream_wl->have_eos) {
         
         stream_wl->start_of_seg_found = true;
         audio_core_notify_event(stream_wl->notif_events, ISMD_AUDIO_NOTIFY_SEGMENT_START);
         
      } else if (audio_pvt_atc_found_start_of_segment(stream_wl, segment_pts)) {
      
         stream_wl->start_of_seg_found = true;
         audio_core_notify_event(stream_wl->notif_events, ISMD_AUDIO_NOTIFY_SEGMENT_START);

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, atc_devh,
               SVEN_MODULE_EVENT_AUD_IO_ATC_START_OF_SEGMENT_FOUND,
               stream_wl->atc_wl->handle,
               stream_wl->handle,
               (unsigned int) (segment_pts>>32),
               (unsigned int) (segment_pts),
               (unsigned int) stream_wl->rebase_info.curr_seg_info.start,
               (unsigned int) stream_wl->rebase_info.curr_seg_info.stop);
         
      } else if (stream_wl->newsegment_policy == ISMD_NEWSEGMENT_POLICY_STRICT) {
      
         /* Only drop data when we are in strict policy
          * No buffer discarding in loose policy
          * The generation of soseg event is also not guaranteed in loose policy */
         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_OUT_OF_SEGMENT_DROP,
               stream_wl->atc_wl->handle,
               stream_wl->handle,
               (unsigned int) (segment_pts>>32),
               (unsigned int) (segment_pts),
               (unsigned int) stream_wl->rebase_info.curr_seg_info.start,
               (unsigned int) stream_wl->rebase_info.curr_seg_info.stop);
         
         *discard_buffer = true;
      }
   }

   return;
}

/* This function is to handle untimed case.
 * ATC untimed mode: We need to insert a rebase_info 
 */
static void
audio_pvt_atc_interpolate_rebase_info_for_untimed(audio_atc_stream_context_t* stream_wl) 
{
   /* for ATC untimed mode playback, we need insert rebase_info
    * case1: stream has not PTS:
    *          segment_pts = start from 0, and increase with chunk_period
    *          linear_pts = segment_pts
    *          scaled_pts = ISMD_NO_PTS
    * case2: stream has PTS:
    *          segment_pts = stream_original_pts, and increase with chunk_period until next valid original_pts
    *          linear_pts = start from rebase_info.curr_seg_info.linear_start (=0), and calculated from segment_pts
    *          scaled_pts = ISMD_NO_PTS
    *
    * for ATC timed mode: 
    * case1: stream has PTS: 
    * case2: stream discard buffer till valid original PTS
    * case3: trickmode
    */
      
   audio_buffer_attr_t *input_buf_attr = (audio_buffer_attr_t *)(stream_wl->input_buffer->attributes);

   if (!stream_wl->is_timed_stream) {

      if(stream_wl->rebase_info.curr_seg_info.start == ISMD_NO_PTS) {
         //no rebase_info yet, initialize interpolate_info to 0
         if (stream_wl->interpolated_info.segment_pts == ISMD_NO_PTS) {
            stream_wl->interpolated_info.segment_pts = 0;
            stream_wl->interpolated_info.linear_pts = 0;
            stream_wl->interpolated_info.local_pts = ISMD_NO_PTS;
         }

         // we have valid PTS, intialize the rebase_info
         if (input_buf_attr->original_pts != ISMD_NO_PTS) {
            stream_wl->rebase_info.curr_seg_info.start = input_buf_attr->original_pts;
         }
      }
   }

   return;
}


/* This function is to interpolate segment PTS for those discarded buffer. 
 * We need interpolated segment PTS, no matter TIMED or UNTIMED input stream.
 */
static void
audio_pvt_atc_interpolate_info_for_discard_buffer(audio_atc_stream_context_t* stream_wl) 
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_pts_t linear_pts = ISMD_NO_PTS;
   
   audio_buffer_attr_t *input_buf_attr = NULL;

   // we at least had a valid segment time before interpolation
   if (stream_wl->input_buffer != NULL && stream_wl->interpolated_info.segment_pts != ISMD_NO_PTS) {
      
      input_buf_attr = (audio_buffer_attr_t *)(stream_wl->input_buffer->attributes);
      // store stream segment time
      if (input_buf_attr->original_pts != ISMD_NO_PTS) {
         stream_wl->interpolated_info.segment_pts = input_buf_attr->original_pts;
      }
      else {
         // increase with discarded buffer duration
         stream_wl->interpolated_info.segment_pts += audio_core_bytes_to_ticks(
            input_buf_attr->sample_size,
            input_buf_attr->sample_rate,
            input_buf_attr->channel_count,
            stream_wl->input_buffer->phys.level);
      }

      if (stream_wl->rebase_info.curr_seg_info.start != ISMD_NO_PTS) {
         // have rebase_info.  this cover both UNTIMED and TIMED cases.
         
         result = ismd_convert_segment_time_to_linear_time(
                              stream_wl->interpolated_info.segment_pts,
                              stream_wl->rebase_info.curr_seg_info.start,
                              stream_wl->rebase_info.curr_seg_info.stop,
                              stream_wl->rebase_info.curr_rate,
                              stream_wl->rebase_info.curr_seg_info.linear_start,
                              &linear_pts );
         
         stream_wl->interpolated_info.linear_pts = (result == ISMD_SUCCESS) ? linear_pts : ISMD_NO_PTS;
      }
      else if (!stream_wl->is_timed_stream){
         stream_wl->interpolated_info.linear_pts = stream_wl->interpolated_info.segment_pts;
      }

      // keep local_pts untouched
      // stream_wl->interpolated_info.local_pts;

      // update stream_position, since this buffer had discard, no output ready, we need to call it 
      audio_pvt_atc_update_stream_position(stream_wl);
   }

   return;
}

/* This function is to interpolate segment PTS for each ATC output buffer. 
 * We need interpolated segment PTS, no matter TIMED or UNTIMED input stream.
 */
static void
audio_pvt_atc_interpolate_info_for_output_buffer(audio_atc_stream_context_t* stream_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   audio_buffer_attr_t* output_buf_attr = (audio_buffer_attr_t*) stream_wl->output_buffer->attributes;
   
   ismd_pts_t linear_pts = ISMD_NO_PTS;
   ismd_pts_t scaled_pts = ISMD_NO_PTS;
   
   uint32_t chunk_size_ticks = stream_wl->time_period_ms * CLOCK_TICKS_PER_MS;

   if (output_buf_attr->original_pts != ISMD_NO_PTS) {

      // accurated segment time
      stream_wl->interpolated_info.segment_pts = output_buf_attr->original_pts - stream_wl->interpolated_info.adjust_ticks;
      stream_wl->interpolated_info.adjust_ticks = 0;
   }
   else {
      // increase chunk period for next output buffer
      stream_wl->interpolated_info.segment_pts += chunk_size_ticks;
   }

   if (stream_wl->is_timed_stream) {
      
      result = ismd_convert_segment_time_to_linear_time(
                           stream_wl->interpolated_info.segment_pts,
                           stream_wl->rebase_info.curr_seg_info.start,
                           stream_wl->rebase_info.curr_seg_info.stop,
                           stream_wl->rebase_info.curr_rate,
                           stream_wl->rebase_info.curr_seg_info.linear_start,
                           &linear_pts );
   
      stream_wl->interpolated_info.linear_pts = (result == ISMD_SUCCESS) ? linear_pts : ISMD_NO_PTS;
      
      if(ISMD_SUCCESS == result){
         
         result = ismd_convert_linear_time_to_scaled_time(
                              stream_wl->interpolated_info.linear_pts,
                              stream_wl->rebase_info.last_linear_rate_change_time,
                              stream_wl->rebase_info.last_scaled_rate_change_time,
                              stream_wl->rebase_info.curr_rate,
                              &scaled_pts);
   
         stream_wl->interpolated_info.local_pts = (result == ISMD_SUCCESS) ? scaled_pts : ISMD_NO_PTS;
      }
   }
   else if (stream_wl->rebase_info.curr_seg_info.start != ISMD_NO_PTS) {
      // untimed stream, with rebase_info
      result = ismd_convert_segment_time_to_linear_time(
                           stream_wl->interpolated_info.segment_pts,
                           stream_wl->rebase_info.curr_seg_info.start,
                           stream_wl->rebase_info.curr_seg_info.stop,
                           stream_wl->rebase_info.curr_rate,
                           stream_wl->rebase_info.curr_seg_info.linear_start,
                           &linear_pts );
   
      stream_wl->interpolated_info.linear_pts = (result == ISMD_SUCCESS) ? linear_pts : ISMD_NO_PTS;
      stream_wl->interpolated_info.local_pts = ISMD_NO_PTS;
   }
   else {
      // untimed stream without rebase_info
      stream_wl->interpolated_info.linear_pts = stream_wl->interpolated_info.segment_pts;
   }

   return;
}


static void
audio_pvt_atc_handle_pts_and_segments(audio_atc_stream_context_t *stream_wl, bool *discard_buffer)
{
   ismd_pts_t curr_pts = ISMD_NO_PTS;

   /*Get the original PTS value from the stream.*/
   curr_pts = ((audio_buffer_attr_t *)&(stream_wl->input_buffer->attributes))->original_pts;
   
   /* Scale only if timed stream, and the current PTS is with in the segment */
   if(stream_wl->is_timed_stream) {

      audio_pvt_atc_handle_newsegment_timed( stream_wl );

      /* Need to check for the start of the segment. */
      audio_pvt_atc_check_for_start_of_segment(stream_wl, curr_pts, discard_buffer);
      
      if(audio_pvt_atc_handle_pts_scaling( stream_wl) != ISMD_SUCCESS){
         *discard_buffer = true;
      }

      /* Handle stop case, if the PTS is beyond the stop value discard. */
      if((stream_wl->rebase_info.curr_seg_info.stop != ISMD_NO_PTS) && (curr_pts != ISMD_NO_PTS) && (curr_pts > stream_wl->rebase_info.curr_seg_info.stop)) {
         *discard_buffer = true;

         /* Make sure we only fire off the end of segement event once */
         if(!stream_wl->last_buffer_discrd_pts_past_stop_value){
            audio_core_notify_event(stream_wl->notif_events, ISMD_AUDIO_NOTIFY_SEGMENT_END);
            stream_wl->last_buffer_discrd_pts_past_stop_value = true;
         }
      }

      /* If the last PTS was discarded because it was past the stop value make sure to discard in case
         there are buffers without PTS values that are found after the stop value as well. This flag gets
         reset on the next new segment we get. */
      if(stream_wl->last_buffer_discrd_pts_past_stop_value){
         *discard_buffer = true;
      }

      /* If trick modes are not enabled and we are not in normal play rate, discard the buffer */
      if(!atc_device.enable_timed_trick_modes && (stream_wl->rebase_info.curr_rate != ISMD_NORMAL_PLAY_RATE))
      {
         *discard_buffer = true;
      }

      /* If the new rate is not what we support, we need to discard */
      if ((stream_wl->rebase_info.curr_rate < AUDIO_MIN_PLAY_RATE) ||
          (stream_wl->rebase_info.curr_rate > AUDIO_MAX_PLAY_RATE) )
      {
         *discard_buffer = true;
      }
   }
   else {
      /*Not a timed stream set start of segment to true
        since the pause mechanism is based off this variable
        being true to pause any stream. */
      stream_wl->start_of_seg_found = true;

      /* insert rebase info for ATC PTS interpolation */
      audio_pvt_atc_interpolate_rebase_info_for_untimed(stream_wl);
   }

   return ;
}


static ismd_result_t
audio_pvt_atc_input_dequeue(audio_atc_stream_context_t *stream_wl, bool *work_to_do)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_result_t mda_result = ISMD_SUCCESS;
   audio_buffer_attr_t *input_buf_attrib = NULL;
   bool discard_buffer = false;
   bool save_first_buffer_dequeued = stream_wl->first_buffer_dequeued;
   void *input_virt_addr = NULL;

   AUDIO_ENTER(atc_devh);

   /*If we are attempting to advance to a particular PTS, need to deref the current input buffer.*/
   if((stream_wl->input_buffer != NULL) && (stream_wl->state == ISMD_DEV_STATE_PAUSE) && (stream_wl->linear_start_pts != ISMD_NO_PTS)){

      input_buf_attrib =( audio_buffer_attr_t *) &(stream_wl->input_buffer->attributes);
      
      audio_pvt_atc_interpolate_info_for_discard_buffer(stream_wl);

      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_DISCARDED_BUFFER,
         stream_wl->atc_wl->handle, stream_wl->handle, stream_wl->input_buffer->phys.level,
         (unsigned int) (input_buf_attrib->original_pts >>32), (unsigned int) (input_buf_attrib->original_pts) ,stream_wl->is_timed_stream);
      
      audio_pvt_atc_input_buffer_dereference(stream_wl);
      stream_wl->last_pts_recvd = ISMD_NO_PTS; 
   }

   /*Only attempt to dequeue if we dont have an input buffer.*/
   if(stream_wl->input_buffer == NULL){

      if((result = ismd_queue_dequeue(stream_wl->input_queue, &(stream_wl->input_buffer))) == ISMD_SUCCESS) {

         *work_to_do = true;

         input_buf_attrib = (audio_buffer_attr_t *) &(stream_wl->input_buffer->attributes);

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_INPUT_DEQUEUE,
            (unsigned int) stream_wl->atc_wl->handle,
            (unsigned int) stream_wl->handle,
            ((stream_wl->input_buffer != NULL) ? (unsigned int) (stream_wl->input_buffer->phys.level) : 0),
            ((stream_wl->input_buffer != NULL) ? (unsigned int) (input_buf_attrib->original_pts>>32): 0),
            ((stream_wl->input_buffer != NULL) ? (unsigned int) (input_buf_attrib->original_pts) : 0),
            (unsigned int) stream_wl->is_timed_stream);

         /*Since we are getting a new buffer, reset the EOS flag, has already been used.*/
         stream_wl->have_eos = false;

         /* Check for EOS on this input buffer*/
         if (ismd_tag_get_eos(stream_wl->input_buffer->unique_id) == ISMD_SUCCESS) {
            stream_wl->have_eos = true;
            /*Ensure the buffer has the correct input association handle.*/
            input_buf_attrib->tag_input_h = stream_wl->input_smd_h;
         }

         audio_pvt_atc_handle_pts_and_segments(stream_wl, &discard_buffer);

         /* Check for valid metadata on the input buffer, and see if we can process it. */
         mda_result = audio_pvt_atc_input_validate_metadata(stream_wl, input_buf_attrib, &discard_buffer);

         /*Check to see if this buffer's data will put us beyond the stop value specified.*/
         if((stream_wl->rate == ISMD_NORMAL_PLAY_RATE) && (mda_result == ISMD_SUCCESS)) {
           audio_pvt_atc_check_for_stop_time(stream_wl);
         }

         /*Process the buffer if we are not going to throw it out.*/
         if (!discard_buffer){

            /* Check for stream info changing, also updates curr chunk size variables. */
            audio_pvt_atc_handle_stream_info_change(stream_wl, input_buf_attrib);

            if( stream_wl->is_timed_stream ) {

               /*If the incoming PTS is valid, need to update the stream's state.*/
               if(input_buf_attrib->local_pts != ISMD_NO_PTS) {
                  stream_wl->last_pts_recvd = input_buf_attrib->local_pts;
                  stream_wl->first_pts_found = true;
                  stream_wl->first_buffer_dequeued = true;

                  /* If we are not trying drop in trick modes, we are trying to drop bytes
                   * becasue of a late PTS, if we get a PTS while trying to drop, need to clear 
                   * out this value since the new received PTS will now dictate what to do next.*/
                  if(stream_wl->rate == ISMD_NORMAL_PLAY_RATE) {
                     stream_wl->drop_bytes = 0;
                  }
               }

               /* Discard all buffers before we encounter the first buffer with a valid PTS. */
               if(!stream_wl->first_pts_found) {

                  AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_FIRST_PTS_NOT_FOUND,
                     stream_wl->atc_wl->handle,
                     stream_wl->handle,
                     stream_wl->input_buffer->phys.level,
                     (unsigned int) (input_buf_attrib->local_pts>>32),
                     (unsigned int) (input_buf_attrib->local_pts),
                     (unsigned int) stream_wl->is_timed_stream);

                  discard_buffer = true;
               }
               /* If advance_to_pts mode is active. */
               else if ( stream_wl->linear_start_pts != ISMD_NO_PTS ) {
                  /*
                   * If buffer has a valid PTS and the PTS is less than the target PTS.
                   * If the buffer has no PTS and the prev PTS was less than the target PTS.
                   */
                  if ( input_buf_attrib->linear_pts != ISMD_NO_PTS ) {
                     if ( input_buf_attrib->linear_pts < stream_wl->linear_start_pts ) {
                        discard_buffer = true;
                     }
                     else {
                        stream_wl->linear_start_pts = ISMD_NO_PTS;
                     }
                  }
                  else {
                     discard_buffer = true;
                  }
               }
            }
            else {
               stream_wl->first_buffer_dequeued = true;
            }

            if ( !save_first_buffer_dequeued && stream_wl->first_buffer_dequeued ) {
               audio_core_notify_event( stream_wl->notif_events, ISMD_AUDIO_NOTIFY_STREAM_BEGIN );
            }
         }

         if ( discard_buffer ) {

            audio_pvt_atc_interpolate_info_for_discard_buffer(stream_wl);
            
            AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_DISCARDED_BUFFER,
               (unsigned int) stream_wl->atc_wl->handle,
               (unsigned int) stream_wl->handle,
               ((stream_wl->input_buffer != NULL) ? (unsigned int) (stream_wl->input_buffer->phys.level) : 0),
               ((stream_wl->input_buffer != NULL) ? (unsigned int) (input_buf_attrib->local_pts>>32): 0),
               ((stream_wl->input_buffer != NULL) ? (unsigned int) (input_buf_attrib->local_pts) : 0),
               (unsigned int) stream_wl->is_timed_stream);

            audio_pvt_atc_input_buffer_dereference(stream_wl);
               
            stream_wl->last_pts_recvd = ISMD_NO_PTS;
            result = ISMD_ERROR_NO_DATA_AVAILABLE; //Since we dont have a buffer to process, make sure to return an error.
         }
         else{
            
            /* Need to cache this buffer if its not cached.*/
            if(stream_wl->input_buffer->buffer_type != ISMD_BUFFER_TYPE_PHYS_CACHED) {        
               stream_wl->in_cached_address = OS_MAP_IO_TO_MEM_CACHE(((int)stream_wl->input_buffer->phys.base), stream_wl->input_buffer->phys.level);             
            }

            /* If the mapping failed or we didnt map, use input buffer virtual base.*/
            input_virt_addr = (stream_wl->in_cached_address == NULL) ? stream_wl->input_buffer->virt.base : stream_wl->in_cached_address;

            /* Invalidate the input buffer before reading */
            if (audio_core_fast_path_enabled()) {
               cache_flush_buffer(input_virt_addr, stream_wl->input_buffer->phys.level);
            }

         }
      }
      else {
         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_INPUT_DEQUEUE_FAILED,
            (unsigned int) stream_wl->atc_wl->handle,
            (unsigned int) stream_wl->handle, stream_wl->is_timed_stream, 0, 0, 0);
      }
   }

   AUDIO_EXIT(atc_devh);

   return result;
}


static void
audio_pvt_atc_update_stream_position(audio_atc_stream_context_t *stream_wl)
{
   ismd_newsegment_tag_t *ns = &stream_wl->rebase_info.curr_seg_info;

   /* Do reporting on both timed and untimed stream.
    * In case of timed stream, all the fields of stream_pos reported should be correct.
    * For untimed stream, we do not guarantee all the fields are correct because the rendering
    * is not controlled by PTS. But user can still get the original PTS in this case.
    */

   stream_wl->stream_pos.segment_time = stream_wl->interpolated_info.segment_pts;
   stream_wl->stream_pos.linear_time = stream_wl->interpolated_info.linear_pts;
   stream_wl->stream_pos.scaled_time= stream_wl->interpolated_info.local_pts;

   ismd_convert_segment_time_to_stream_position(stream_wl->interpolated_info.segment_pts,
         ns->start,
         ns->stop,
         ns->requested_rate,
         ns->applied_rate,
         ns->segment_position,
         &stream_wl->stream_pos.stream_position);

   /*Copy this over the current stream info to the shared stream postion memory location. (Shared by APM)*/
   audio_core_stream_position_copy(stream_wl->stream_pos_shared, &stream_wl->stream_pos);

   return;
}


static void
audio_pvt_atc_handle_stream_info_change(audio_atc_stream_context_t *stream_wl, audio_buffer_attr_t * buffer_attrib)
{
   int new_chunk_size = 0;
   audio_buffer_attr_t *out_buffer_attr = (audio_buffer_attr_t*)stream_wl->output_buffer->attributes;

   /*Calculate the new time slice chunks size in bytes. Metadata already validated previously.*/
   new_chunk_size = audio_core_calc_chunk_size(
      (int) buffer_attrib->sample_size,
      (int) buffer_attrib->sample_rate,
      (int) buffer_attrib->channel_count,
      AUDIO_CORE_GET_CHUNK_PERIOD(stream_wl->atc_wl));

   AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_INPUT_METADATA,
      new_chunk_size,
      buffer_attrib->channel_config,
      stream_wl->input_buffer->phys.level,
      buffer_attrib->sample_rate,
      buffer_attrib->sample_size,
      buffer_attrib->channel_count);

   /*If this is the first valid buffer need to initialize chunk size.*/
   if(stream_wl->curr_chunk_size == 0) {
      stream_wl->curr_chunk_size = new_chunk_size;
   }

   /*If this is the first valid buffer update stream info first.*/
   if(stream_wl->curr_stream_info.sample_rate == 0) {
      stream_wl->curr_stream_info = *buffer_attrib;
   }

   /*Update the next chunk size with the new value.*/
   stream_wl->next_chunk_size = new_chunk_size;
   stream_wl->next_stream_info = *buffer_attrib;

   /*If we have data in the output buffer, need to finalize and send it since it has the previous stream attributes.*/
   if(audio_pvt_atc_stream_info_changed(&stream_wl->curr_stream_info, &stream_wl->next_stream_info) && 
      (stream_wl->output_buffer->phys.level > 0)) 
   {

      /*If we are inserting silence need to make the outbut buffer to Xms chunk size.*/
      if(stream_wl->atc_wl->insert_silence) {
         audio_pvt_atc_top_off_buffer(stream_wl);
      }
      else {
         stream_wl->out_buf_forced_ready = true;
         stream_wl->out_buf_ready = true;

         /*Warn if we are not sample alligned on the output buffer.*/
         if( (stream_wl->output_buffer->phys.level %((out_buffer_attr->sample_size/8)*out_buffer_attr->channel_count)) != 0){
            OS_PRINT("\nSMD AUDIO: WARNING: ATC output buffer sent is NOT sample alligned!\n");
         }
      }

      if(stream_wl->message_context != ISMD_MESSAGE_CONTEXT_INVALID) {
         ismd_message_write(stream_wl->message_context, ISMD_AUDIO_MESSAGE_STREAM_INFO_CHANGE, 1, 0);
      }
   }
   /*Otherwise update current stream information immediately.*/
   else {
      stream_wl->curr_chunk_size = new_chunk_size;
      stream_wl->curr_stream_info = *buffer_attrib;
   }

   return;
}

static int
audio_pvt_atc_get_allowed_smple_cnt_drift(audio_atc_stream_context_t *stream_wl, bool early )
{
   int samples_allowed = 3; //Default to allow for at least 3 samples of drift, most accurate.

   // If we want to get the early tolerance, return the allowed number of samples to drift when we are ahead EARLY.
   if(early) {

      //If its set to zero we want the most accurate calculation
      if(stream_wl->allowed_ms_drift_ahead != 0) {
       samples_allowed = -MS_TO_SAMPLES(stream_wl->allowed_ms_drift_ahead, stream_wl->curr_stream_info.sample_rate);
      }
   }

   //If we want to get the late tolerance, return the allowed number of samples to drift when are behind LATE.
   else {

      //If its set to zero we want the most accurate calculation
      if(stream_wl->allowed_ms_drift_behind != 0) {
         samples_allowed = MS_TO_SAMPLES(stream_wl->allowed_ms_drift_behind, stream_wl->curr_stream_info.sample_rate);
      }
   }

   return samples_allowed;
}


static void
audio_pvt_atc_assign_time_slot(audio_atc_stream_context_t *stream_wl )
{
   audio_buffer_attr_t *buf_attrib = NULL;
   int64_t smpls_until_rndr = 0;
   uint64_t left_over_samples = 0;
   uint32_t chunk_size_samples = 0;
   int64_t sample_cnt_drift = 0;
   int64_t clk_ticks_until_rndr = 0;
   int early_samples_allowed = 0;

   buf_attrib = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);

   /* Timed stream */
   if( stream_wl->is_timed_stream ) {

      //Get the current time chunk size in samples
      chunk_size_samples = audio_core_bytes_to_samples(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, stream_wl->curr_chunk_size);
      if(buf_attrib->render_time_stamp == ISMD_NO_PTS) {
         /* Assign the output buffer with the next render_time_stamp */
         buf_attrib->render_time_stamp = stream_wl->prev_time_stamp + (uint64_t)chunk_size_samples; //will be overwritten on the first frame.
      }

      if((stream_wl->last_pts_recvd != ISMD_NO_PTS) && stream_wl->first_pts_found) {

         /* Get the latest PTS we got on the input and store it on the output buffer. */
         buf_attrib->local_pts = stream_wl->last_pts_recvd;

         /* 
          * Get the PTS specified rendering time (We call this PTS-Clock time stamp). Formula:
          * 1) If ATC runs in scaled PTS mode, 
          * (scaled_PTS + SMD_base ) - atc_base_time 
          * 2) If ATC runs in original PTS mode, the clock and atc_base_time are both in original time domain,
          * so the PTS specified rendering time is simply:
          * original_PTS - atc_base_time
          * Please note, smd_base_time is not used here since original_pts and atc_base_time is in the same time domain.
          * If clock is not initialized yet, we need to wait.
          */
         if(stream_wl->timing_mode == ISMD_TIMING_MODE_ORIGINAL) {
            /* Clock is not initialized
             * discard buffer and return
             */
            if (stream_wl->atc_base_time == 0) {
               //Mark to get atc_base_time next time
               stream_wl->have_base_numbers = false;
               return; 
            }
            clk_ticks_until_rndr = ((audio_buffer_attr_t *) &(stream_wl->input_buffer->attributes))->original_pts - stream_wl->atc_base_time;
         } else {
            clk_ticks_until_rndr = (int64_t)((buf_attrib->local_pts + stream_wl->smd_base_time) - stream_wl->atc_base_time);
         }

         //Convert the PTS specified rendering time to sample count: audio_samples = (clock_ticks * aud_sample_rate) / 90000, clock_ticks =  (audio_samples * 90000)/aud_sample_rate. We call this sample count the PTS-Clock calculated sample count.
         smpls_until_rndr = AUDIO_DIV64((int64_t)(clk_ticks_until_rndr * (int64_t)stream_wl->curr_stream_info.sample_rate) , (int64_t)CLOCK_SPEED_HZ);

         /* Add the render sample count to the PTS-Clock calculated samples */
         smpls_until_rndr += (int64_t)stream_wl->render_sample_count;

         /* If we did not send the first frame we need to ensure it starts on a N ms time boundary */
         if(!stream_wl->sent_first_frame ) {

            audio_pvt_atc_calc_first_frame(stream_wl,  clk_ticks_until_rndr, smpls_until_rndr, chunk_size_samples);
            
            if (stream_wl->sent_first_frame) {
               // enable vchunk logic after we find first PTS               
               if (stream_wl->asrc.vsrc_support_enabled) {
                  // reset vchunk logic before starting
                  audio_pvt_atc_asrc_reset(stream_wl);
               }
            }
         }

         //Not first frame
         else {

            /* Find the difference between our time slot and the PTS-Clock sample count*/
            left_over_samples = (uint64_t)audio_core_bytes_to_samples(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, stream_wl->output_buffer->phys.level );

            /* Subtract our render time stamp from the adjusted PTS-Clock time stamp to see if there is a timing error in samples. */
            sample_cnt_drift = (((int64_t)(buf_attrib->render_time_stamp) - stream_wl->asrc.cumulative_sample_correction) -  (smpls_until_rndr  - (int64_t)left_over_samples)); 
            /* If the number is positive, we are LATE, call function to get number of samples we can allow for.*/
            if(sample_cnt_drift > ((int64_t)audio_pvt_atc_get_allowed_smple_cnt_drift(stream_wl, false ))) {
               audio_pvt_atc_handle_late_pts(stream_wl, buf_attrib, sample_cnt_drift, false);
            }

            /* We are EARLY notify chopper to add silence, call function to get number of samples we can allow for.*/
            else if(sample_cnt_drift < ((int64_t)audio_pvt_atc_get_allowed_smple_cnt_drift(stream_wl, true ))) {
               /*
                * If the buffer is early by more than x second, it's a discontinuity
                * and we need to throw buffers away until the Demux sends us a proper
                * newsegment in scaled PTS mode. 
                *
                * If we are in original timing mode, The clock is driven by video renderer
                * There are 4 cases of discontinuity:
                * 1. Clock forward jumping
                *    Case1: Audio PTS jump first
                *    Video PTS 100, 200, 300,  1000, 1001, 1002, ..
                *    Clock     100, 200, 300,  1000, 1001, 1002, ..
                *    Audio PTS 100, 200, 1000, 1001, 1002... 
                *    Audio frame with PTS 1000 should be hold until clock jumping
                *
                *    Case2: Video PTS jump first
                *    Video PTS 100, 200, 1000, 1001, 1002, ..
                *    Clock     100, 200, 1000, 1001, 1002, ..
                *    Audio PTS 100, 200, 300,  1000, 1001, 1002... 
                *    Audio frames with PTS 300 will be discard until audio PTS catch clock time
                *
                *    In clock forward jumping, the audio timing algorithm is the SAME with normal case
                *
                * 2. Clcok backward jumping
                *    Case3: Audio PTS jump first
                *    Video PTS 100, 200, 300,  1, 2, 3, ..
                *    Clock     100, 200, 300,  1, 2, 3, ..
                *    Audio PTS 100, 200, 1,    2, 3... 
                *    Audio frame with PTS 1/2/3... will be discarded and this may cause audio buffer under flow. 
                *    There is no good way to deal with this since at audio frame with pts 1, the clock has not 
                *    jumped yet. This function will return NULL with ipq emptied. Rebuffering is possible after
                *    clock jumping
                *
                *    Case4: Video PTS jump first
                *    Video PTS 100, 200, 300,  1,  2, 3, ..
                *    Clock     100, 200, 300,  1,  2, 3, ..
                *    Audio PTS 100, 200, 300,  400,1, 2, 3... 
                *    Audio frame with PTS 400 should be discarded until see matched PTS.Otherwise, you may 
                *    be stalled here "forever" if PTS jumping gap is big enough
                *
                *    Case2 and case3 can be handled through the "late pts" logic above.
                *
                *    Case1 and Case4 can't be handled through the "early pts" logic and should be handled through the
                *    discontinuity logic: Throw away samples until clock jumping. Reset all the global state variables to:
                *    1) Find the next PTS
                *    2) re-query the base numbers
                *    3) re-calc the prev_time_stamp
                *
                * Note that this applies only after the first PTS is found.
                */
               early_samples_allowed = (((-(int)stream_wl->curr_stream_info.sample_rate)*stream_wl->allowed_ms_discontinuity)/1000);
               if ( sample_cnt_drift < early_samples_allowed) {

                  if(stream_wl->timing_mode == ISMD_TIMING_MODE_ORIGINAL) {
                     AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_PTS_EARLY_DISCONTINUITY_DISCARD,
                           stream_wl->handle,
                           stream_wl->input_buffer->phys.level,
                           (int)sample_cnt_drift,
                           (int)early_samples_allowed,
                           (unsigned int) (buf_attrib->original_pts>>32),
                           (unsigned int) (buf_attrib->original_pts));
                  } else if (stream_wl->timing_mode == ISMD_TIMING_MODE_CONVERTED) {
                     AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh, SVEN_MODULE_EVENT_AUD_IO_ATC_PTS_EARLY_DISCONTINUITY_DISCARD,
                           stream_wl->handle,
                           stream_wl->input_buffer->phys.level,
                           (int)sample_cnt_drift,
                           (int)early_samples_allowed,
                           (unsigned int) (buf_attrib->local_pts>>32),
                           (unsigned int) (buf_attrib->local_pts));
                  }

                  audio_pvt_atc_input_buffer_dereference(stream_wl);
                  buf_attrib->local_pts = ISMD_NO_PTS;
                  stream_wl->first_pts_found = false;

               }
               else {
                  audio_pvt_atc_handle_early_pts(stream_wl, buf_attrib, -sample_cnt_drift);
               }
            }

            /*We are exactly on time here!*/
            else {
               // PTS late/early in previous buffer
               if (stream_wl->underrun_amount != 0) {
                  audio_core_notify_event(stream_wl->notif_events, ISMD_AUDIO_NOTIFY_PTS_VALUE_RECOVERED);
               }
               
               //Clear out our underrun variables since we are on time.
               stream_wl->underrun_amount = 0;
               stream_wl->underrun_count = 0;
            }
        }
         stream_wl->last_pts_recvd = ISMD_NO_PTS;
      }

      //Keep track of the new render_time_stamp for the next buffer.
      stream_wl->prev_time_stamp = buf_attrib->render_time_stamp;
   }
   else{
      stream_wl->sent_first_frame = true;
   }

   return;
}

static void
audio_pvt_atc_assign_time_slot_trick_modes(audio_atc_stream_context_t *stream_wl )
{
   audio_buffer_attr_t *buf_attrib = NULL;
   uint64_t smpls_until_rndr = 0;
   uint32_t chunk_size_samples = 0;
   uint32_t samples_since_last_pts = 0;
   int64_t clk_ticks_until_rndr = 0;

   buf_attrib = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);


   //Get the current time chunk size in samples
   chunk_size_samples = audio_core_bytes_to_samples(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, stream_wl->curr_chunk_size);

   if(buf_attrib->render_time_stamp == ISMD_NO_PTS) {
      /* Assign the output buffer with the next render_time_stamp */
      buf_attrib->render_time_stamp = stream_wl->prev_time_stamp + (uint64_t)chunk_size_samples; //will be overwritten on the first frame.
   }

   //If we have a PTS use it..
   if(stream_wl->last_pts_recvd != ISMD_NO_PTS) {

      buf_attrib->local_pts = stream_wl->last_pts_recvd;
      stream_wl->last_pts_recvd = ISMD_NO_PTS;

      if(!stream_wl->drop_bytes) {

         /* Get the difference to add to the base sample count (PTS + SMD_base ) - atc_base_time */
         clk_ticks_until_rndr = (int64_t)((buf_attrib->local_pts + stream_wl->smd_base_time) - stream_wl->atc_base_time);

         //Convert clock ticks to sample count: audio_samples = (clock_ticks * aud_sample_rate) / 90000, clock_ticks =  (audio_samples * 90000)/aud_sample_rate
         smpls_until_rndr = OSAL_DIV64(((uint64_t)clk_ticks_until_rndr * (uint64_t)stream_wl->curr_stream_info.sample_rate) , (uint64_t)CLOCK_SPEED_HZ);

         /* Keep last PTS calculated in sample count, for determining position of samples upto the next PTS */
         stream_wl->last_pts_smpl_cnt = smpls_until_rndr;

         /*When we see a PTS reset this sample count*/
         stream_wl->bytes_since_last_pts = 0;

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, atc_devh,
               SVEN_MODULE_EVENT_AUD_IO_ATC_TIME_STAMP,
               (unsigned int) stream_wl->handle,
               (unsigned int) (clk_ticks_until_rndr),
               (unsigned int) (smpls_until_rndr >> 32),
               (unsigned int) (smpls_until_rndr),
               (unsigned int) (buf_attrib->local_pts >> 32),
               (unsigned int) (buf_attrib->local_pts) );

      }
   }

      /* If we did not send the first frame we need to ensure it starts on a N ms time boundary */
   if(!stream_wl->sent_first_frame) {

      if(buf_attrib->local_pts != ISMD_NO_PTS) {

         /* Add the render sample count to the PTS-Clock calculated samples only for the first frame in TM */
         smpls_until_rndr += stream_wl->render_sample_count;

         audio_pvt_atc_calc_first_frame(stream_wl,  clk_ticks_until_rndr, smpls_until_rndr, chunk_size_samples);
         buf_attrib->local_pts = ISMD_NO_PTS; //Done with this PTS, we have our values.
      }
   }
   else {

      //We only want to make this calcuation if a silence and/or dropping is not going on.
      if((stream_wl->drop_bytes == 0) && (stream_wl->pad_silence_bytes == 0)) {

         /* Calculate our next time stamp based on the point we are at in processing the input buffers. */
         if(buf_attrib->local_pts == ISMD_NO_PTS) {

            samples_since_last_pts = audio_core_bytes_to_samples(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, stream_wl->bytes_since_last_pts);
            smpls_until_rndr = stream_wl->last_pts_smpl_cnt + ((samples_since_last_pts * ISMD_NORMAL_PLAY_RATE) /stream_wl->rate);
         }
         else {
            buf_attrib->local_pts = ISMD_NO_PTS; //We cached this value, dont need to do it again.
         }

         audio_pvt_atc_calc_drift_trick_modes(stream_wl, smpls_until_rndr );
      }
   }

   //Keep track of the new render_time_stamp for the next buffer.
   stream_wl->prev_time_stamp = buf_attrib->render_time_stamp;

   return;
}


static void
audio_pvt_atc_calc_drift_trick_modes(audio_atc_stream_context_t *stream_wl, uint64_t smpls_until_rndr)
{
   uint64_t left_over_samples = 0;
   int64_t sample_cnt_drift = 0;
   audio_buffer_attr_t *buf_attrib = NULL;
   int samples_to_drop_in_ffwd = 0;

   buf_attrib = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);
   samples_to_drop_in_ffwd = (stream_wl->curr_stream_info.sample_rate * 3) / 100;

   /* Find the difference between our time slot and the PTS-Clock sample count*/
   left_over_samples = (uint64_t)audio_core_bytes_to_samples(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, stream_wl->output_buffer->phys.level );

   /* Need to add in the render sample count for this calculation for it to be accurate. */
   smpls_until_rndr += stream_wl->render_sample_count;

   /* Subtract our render time stamp from the adjusted PTS-Clock time stamp to see if there is a timing error in samples. */
   sample_cnt_drift = (((int64_t)(buf_attrib->render_time_stamp) - stream_wl->asrc.cumulative_sample_correction) -  (((int64_t)smpls_until_rndr ) - (int64_t)left_over_samples));

   //Check to see if we are late here, if we are drop the requested amount.
   if(sample_cnt_drift > (samples_to_drop_in_ffwd /2)) {

      if(stream_wl->bytes_to_fix == 0) {
         stream_wl->drop_bytes = audio_core_samples_to_bytes(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, samples_to_drop_in_ffwd);
      }

      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
         SVEN_MODULE_EVENT_AUD_IO_ATC_PTS_LATE_FFWD,
         (unsigned int) stream_wl->handle,
         (unsigned int) (sample_cnt_drift >> 32),
         (unsigned int) (sample_cnt_drift),
         (unsigned int) (samples_to_drop_in_ffwd),
         (unsigned int) (samples_to_drop_in_ffwd / 2),
         0);
   }

   //We are early
   else if(sample_cnt_drift < -samples_to_drop_in_ffwd) {

      //This is a huge > 1 sec discontinutiy, reset for new stream.
      if ( sample_cnt_drift < (-(int32_t)(stream_wl->curr_stream_info.sample_rate)) ) {

         audio_pvt_atc_reset_for_new_stream(stream_wl);
      }
      else {
         stream_wl->pad_silence_bytes = audio_core_samples_to_bytes(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, (-sample_cnt_drift));
      }

      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
         SVEN_MODULE_EVENT_AUD_IO_ATC_PTS_EARLY_FFWD,
         (unsigned int) stream_wl->handle,
         (unsigned int) (-sample_cnt_drift >> 32),
         (unsigned int) (-sample_cnt_drift),
         (unsigned int) (samples_to_drop_in_ffwd),
         (unsigned int) (samples_to_drop_in_ffwd / 2),
         (unsigned int) stream_wl->pad_silence_bytes);

   }

   //We are good to play out
   else {
   }

   return;
}


static void
audio_pvt_atc_calc_first_frame(audio_atc_stream_context_t *stream_wl, int64_t clk_ticks_until_rndr, int64_t smpls_until_rndr, uint32_t chunk_size_samples)
{
   audio_buffer_attr_t *buf_attrib = NULL;
   uint32_t smpls_left_over  = 0;
   int back_end_delay_samples = 0;

   AUDIO_ENTER(atc_devh);

   buf_attrib = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);

   /* Make sure we are in the future, and also that we compensate for the time it will take to get through the back end DSP pipe.
      if not we are late. This could use some optimizing by interpolating buffers with no PTS values untill we are far enough ahead.
    */
   if(clk_ticks_until_rndr > (stream_wl->render_delay_ticks + (stream_wl->fixed_back_end_delay_ms * CLOCK_TICKS_PER_MS ))) {
      /* This is our first un-adjusted render_time_stamp */
      buf_attrib->render_time_stamp = (uint64_t)smpls_until_rndr;

      /* Use this calculation to find out the remainder samples we need to pad for the stream to start in the right place.*/
      if((smpls_left_over = (uint32_t)(OSAL_MOD64(buf_attrib->render_time_stamp, (uint64_t)chunk_size_samples)))) {

         stream_wl->pad_silence_bytes = audio_core_samples_to_bytes(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, smpls_left_over);

         /* Adjust the timestamp to reflect the stream start adjustment */
         buf_attrib->render_time_stamp -= (uint64_t)smpls_left_over;
      }

      /* calculate the back-end delay in samples.*/
      back_end_delay_samples= ((stream_wl->fixed_back_end_delay_ms *stream_wl->curr_stream_info.sample_rate)/CLOCK_SPEED_HZ);
      /* If our timestamp is less than or equal to the overall delay, we are too late */
      if( buf_attrib->render_time_stamp <= (uint64_t)(stream_wl->render_delay_samples + back_end_delay_samples) ) {

         audio_pvt_atc_handle_late_pts(stream_wl, buf_attrib, smpls_until_rndr, true);
         buf_attrib->render_time_stamp = ISMD_NO_PTS;
         stream_wl->have_base_numbers = false;
      }

      else {
         stream_wl->sent_first_frame = true;
      }

   }

    /* If we are negative, we are late on the first frame */
   else {

      audio_pvt_atc_handle_late_pts(stream_wl, buf_attrib, smpls_until_rndr, true);
      buf_attrib->render_time_stamp = ISMD_NO_PTS;
      stream_wl->have_base_numbers = false;
   }

   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
      SVEN_MODULE_EVENT_AUD_IO_ATC_CALC_FIRST_FRAME,
      (unsigned int) stream_wl->handle,
      (int)stream_wl->render_delay_ticks,
      (int)clk_ticks_until_rndr,
      (unsigned int) (buf_attrib->render_time_stamp >> 32),
      (unsigned int) (buf_attrib->render_time_stamp),
      (unsigned int) ((uint64_t)stream_wl->render_delay_samples + stream_wl->render_sample_count));


   AUDIO_EXIT(atc_devh);
   return;
}

static void
audio_pvt_atc_handle_late_pts(audio_atc_stream_context_t *stream_wl, audio_buffer_attr_t *buf_attrib, int64_t drift_samples, bool first_frame)
{
   bool drop_buffers_till_next_pts = true;

   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
      SVEN_MODULE_EVENT_AUD_IO_ATC_PTS_LATE,
      (unsigned int) stream_wl->handle,
      (unsigned int) (buf_attrib->local_pts >> 32),
      (unsigned int) (buf_attrib->local_pts),
      (unsigned int) (drift_samples >> 32),
      (unsigned int) (drift_samples),
      (unsigned int) first_frame);

   //If we are not processing the first frame, try to only drop a few samples.
   if(!first_frame ) {

      /* Usually when we are late we want to drop buffers until the next PTS value we get. This is
       * to recover as fast as we can. However, if we are late only by several milliseconds this could be
       * the result of a new segment that specifically wanted us to discard several samples to make 
       * a connection seamless. No need to discard several buffers if we are only late by a few samples. */
      if(drift_samples <= (int64_t)MS_TO_SAMPLES(ATC_MAX_MS_TO_DROP_SAMPLS, stream_wl->curr_stream_info.sample_rate )) {

         buf_attrib->local_pts = ISMD_NO_PTS;

         //If its not an encoded stream try to drop samples exactly.
         if(!stream_wl->is_encoded_data) {

            /*If we have bytes to fix and are coming back to drop more samples, There was not enough
            input data to perform the fix, so clear out the fix buffer.
            */
            if(stream_wl->bytes_to_fix != 0){
               stream_wl->bytes_to_fix = 0;
               stream_wl->drop_buffer->phys.level = 0;
               stream_wl->fixing_samples = false;
            }
            stream_wl->drop_bytes = audio_core_samples_to_bytes(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, ABS(drift_samples));
         }
         //For an encoded buffer, an entire IEC frame comes to the ATC in one buffer, just deref and
         //dont try to drop samples from within the frame.
         else{
            audio_pvt_atc_input_buffer_dereference(stream_wl);
         }

         drop_buffers_till_next_pts = false;
      }
   }
   else{
      /* If we have any data in the output buffer, reset */
      audio_pvt_atc_reset_buffer_metadata((audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes));
      stream_wl->output_buffer->phys.level = 0;
   }

   if(drop_buffers_till_next_pts) {

      audio_pvt_atc_input_buffer_dereference(stream_wl);
      stream_wl->first_pts_found = false; //Force the input to search for the next PTS.
      buf_attrib->local_pts = ISMD_NO_PTS;
   }

   /* Fire off event */
   audio_core_notify_event(stream_wl->notif_events, ISMD_AUDIO_NOTIFY_PTS_VALUE_LATE);

   /* Need to track and notify if underrun occurs. */
   audio_core_handle_underrun_tracking(
      stream_wl->handle,
      stream_wl->underrun_event,
      &stream_wl->underrun_count,
      &stream_wl->underrun_amount,
      SAMPLES_TO_CLOCK_TICKS_64(ABS(drift_samples - (int64_t)((first_frame == true) ? stream_wl->render_sample_count : 0)), (int)stream_wl->curr_stream_info.sample_rate));

   return;
}


static void
audio_pvt_atc_handle_early_pts(audio_atc_stream_context_t *stream_wl, audio_buffer_attr_t *buf_attrib, int64_t drift_samples)
{
   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
      SVEN_MODULE_EVENT_AUD_IO_ATC_PTS_EARLY,
      (unsigned int) stream_wl->handle,
      (unsigned int) (buf_attrib->local_pts >> 32),
      (unsigned int) (buf_attrib->local_pts),
      (unsigned int) (drift_samples >> 32),
      (unsigned int) (drift_samples), 0);

      /* Flag so we know how much silence to add */
      stream_wl->pad_silence_bytes = audio_core_samples_to_bytes(stream_wl->curr_stream_info.sample_size, stream_wl->curr_stream_info.channel_count, drift_samples);

   buf_attrib->local_pts = ISMD_NO_PTS;

    /* Fire off event */
   audio_core_notify_event(stream_wl->notif_events, ISMD_AUDIO_NOTIFY_PTS_VALUE_EARLY);

   return;
}


static void
audio_pvt_atc_init_wl(audio_atc_context_t *wl)
{
   int loop = 0;

   /*Initialize procssor stucture members. */
   wl->in_use = false;
   wl->start_to_close = false;
   wl->insert_silence = true;// By default we insert silence.
   wl->active_stream_count = 0;
   wl->handle = AUDIO_INVALID_HANDLE;
   wl->processor_id = AUDIO_INVALID_HANDLE;
   wl->clock_alarm_event = ISMD_EVENT_HANDLE_INVALID;
   wl->output_queue_lock = NULL;
   wl->primary_stream_wl = NULL;
   wl->fast_output = false;
   wl->output_discard_policy = ATC_OUTPUT_DISCARD_ON_RENDER_NOT_PRESENT;
   wl->transition_protection_enabled = false;

   for(loop = 0; loop < AUDIO_MAX_ATC_STREAMS; loop++)
   {
      audio_pvt_atc_stream_init_wl(&(wl->streams[loop]));
   }

   return;
}

static ismd_result_t
audio_pvt_atc_lock_and_get_wl(audio_atc_t atc_h, audio_atc_context_t **wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   AUDIO_ENTER(atc_devh);

   if (audio_pvt_atc_valid_handle(atc_h)) {

      audio_pvt_atc_lock ( &(atc_device.atc_contexts[atc_h]) );

      if (atc_device.atc_contexts[atc_h].in_use) {

         *wl = &(atc_device.atc_contexts[atc_h]);
         result = ISMD_SUCCESS;
      }
      else {
         audio_pvt_atc_unlock ( &(atc_device.atc_contexts[atc_h]) );
         result = ISMD_ERROR_INVALID_RESOURCE;
      }
   }else{
      result = ISMD_ERROR_INVALID_HANDLE;
   }

   AUDIO_EXIT(atc_devh);
   return result;
}

static ismd_result_t
audio_pvt_atc_stream_lock_and_get_wl(audio_atc_t atc_h, audio_atc_stream_t stream_h, audio_atc_stream_context_t **stream_wl)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   audio_atc_context_t *wl = NULL;

   AUDIO_ENTER(atc_devh);

   if(audio_pvt_atc_stream_valid_handle(stream_h)) {
      if(((result = audio_pvt_atc_lock_and_get_wl(atc_h, &wl)) == ISMD_SUCCESS)) { 

         if(wl->streams[stream_h].in_use) {
            *stream_wl = &(wl->streams[stream_h]);
            result = ISMD_SUCCESS;
         }
         else {
            audio_pvt_atc_unlock(wl);
            result = ISMD_ERROR_INVALID_REQUEST;
            AUDIO_ERROR("ATC stream not in use!",result, atc_devh );
         }
      }
   }

   AUDIO_EXIT(atc_devh);
   return result;
}

static void
audio_pvt_atc_lock_output_queues (os_mutex_t *lock) {

   if(lock != NULL){
      os_mutex_lock(lock);
   }
}

static void
audio_pvt_atc_unlock_output_queues (os_mutex_t *lock) {

   if(lock != NULL){
      os_mutex_unlock(lock);
   }
}

static void
audio_pvt_atc_lock (audio_atc_context_t *atc_instance) {
   //AUDIO_ENTER(atc_devh);
   os_mutex_lock(&atc_instance->lock);
   //AUDIO_EXIT(atc_devh);
}

static void
audio_pvt_atc_unlock (audio_atc_context_t *atc_instance) {
   //AUDIO_ENTER(atc_devh);
   os_mutex_unlock(&atc_instance->lock);
   //AUDIO_EXIT(atc_devh);
} 

static void
audio_pvt_atc_dev_lock (audio_atc_device_t *dev) {
   //AUDIO_ENTER(atc_devh);
   os_mutex_lock(&dev->lock);
   //AUDIO_EXIT(atc_devh);
}

static void
audio_pvt_atc_dev_unlock (audio_atc_device_t *dev) {
   //AUDIO_ENTER(atc_devh);
   os_mutex_unlock(&dev->lock);
   //AUDIO_EXIT(atc_devh);
}

static void
audio_pvt_atc_stream_init_wl(audio_atc_stream_context_t *stream_wl)
{
   audio_pvt_atc_init_stream_wl_reset_values(stream_wl) ;
   stream_wl->handle = AUDIO_INVALID_HANDLE;
   stream_wl->atc_wl = NULL;
   stream_wl->drop_buffer = NULL;
   stream_wl->in_use = false;
   stream_wl->have_eos = false;
   stream_wl->disabled = false;
   stream_wl->start_to_remove = false;
   stream_wl->is_timed_stream = false;
   stream_wl->is_encoded_data = false;
   stream_wl->is_primary = false;
   stream_wl->state = ISMD_DEV_STATE_STOP;
   stream_wl->notif_events = NULL;
   stream_wl->rate = ISMD_NORMAL_PLAY_RATE;
   stream_wl->linear_start_pts = ISMD_NO_PTS;
   stream_wl->underrun_event = ISMD_EVENT_HANDLE_INVALID;
   stream_wl->did_eos_check = false;
   stream_wl->ignore_inband_rate_change = false;
   stream_wl->discontinuity = false;
   stream_wl->fast_output = false;
   stream_wl->input_smd_h = AUDIO_INVALID_HANDLE;
   stream_wl->in_cached_address = NULL;
   stream_wl->smd_base_time = 0;
   stream_wl->clock_h = ISMD_CLOCK_HANDLE_INVALID;
   stream_wl->slave_clock_h = ISMD_CLOCK_HANDLE_INVALID;
   stream_wl->slave_clock_initialized = false; 
   stream_wl->original_pts_on_slave_clock_adjustment = ISMD_NO_PTS;
   stream_wl->render_sample_count_on_slave_clock_adjustment = 0;
   stream_wl->timing_mode = ISMD_TIMING_MODE_CONVERTED;
   stream_wl->last_clock_time = ISMD_NO_PTS;
   stream_wl->output_queue = ISMD_QUEUE_HANDLE_INVALID;
   stream_wl->input_queue = ISMD_QUEUE_HANDLE_INVALID;
   stream_wl->input_buffer = NULL;
   stream_wl->output_buffer = NULL;
   stream_wl->stream_pos.base_time = 0;
   stream_wl->stream_pos.current_time = 0;
   stream_wl->stream_pos.sample_count = 0;
   stream_wl->stream_pos.segment_time = ISMD_NO_PTS;
   stream_wl->stream_pos.linear_time = ISMD_NO_PTS;
   stream_wl->stream_pos.scaled_time= ISMD_NO_PTS;
   stream_wl->stream_pos_shared = NULL;
   stream_wl->allowed_ms_drift_ahead = ATC_DEFAULT_MS_DRIFT_AHEAD;
   stream_wl->allowed_ms_drift_behind = ATC_DEFAULT_MS_DRIFT_BEHIND;
   stream_wl->message_context = ISMD_MESSAGE_CONTEXT_INVALID;

   /* Make sure stream discontinuity event is freed */
   if(stream_wl->discontinuity_event != ISMD_EVENT_HANDLE_INVALID) {
      ismd_event_free(stream_wl->discontinuity_event);
   }
   stream_wl->discontinuity_event = ISMD_EVENT_HANDLE_INVALID;

   /* Rebasing variables */
   stream_wl->rebase_info.curr_seg_info.linear_start = 0;
   stream_wl->rebase_info.curr_seg_info.start = ISMD_NO_PTS;
   stream_wl->rebase_info.curr_seg_info.stop = ISMD_NO_PTS;
   stream_wl->rebase_info.curr_seg_info.requested_rate = 0;
   stream_wl->rebase_info.last_linear_rate_change_time = 0;
   stream_wl->rebase_info.last_scaled_rate_change_time = 0;
   stream_wl->rebase_info.curr_rate = ISMD_NORMAL_PLAY_RATE;
   stream_wl->newsegment_policy = ISMD_NEWSEGMENT_POLICY_LOOSE;
   stream_wl->has_newsegment = false;
   stream_wl->start_of_seg_found = false;
   stream_wl->have_eos = false;
   stream_wl->allowed_ms_discontinuity = atc_discontinuity;

   /*Variable time quantam (chunk size) variables.*/
   stream_wl->asrc.vsrc_support_enabled = false;
   stream_wl->asrc.drift_detection_started = false;
   stream_wl->asrc.cumulative_sample_correction = 0;
   stream_wl->asrc.minimal_adjust = ATC_ASRC_MINIMAL_ADJUST;

   /* Reset for new stream */
   stream_wl->interpolated_info.segment_pts = ISMD_NO_PTS;
   stream_wl->interpolated_info.linear_pts = ISMD_NO_PTS;
   stream_wl->interpolated_info.local_pts = ISMD_NO_PTS;
   stream_wl->interpolated_info.adjust_ticks = 0;
}


static bool
audio_pvt_atc_valid_handle( audio_atc_t atc_h )
{
   bool result = false;

   if ( (atc_h >= 0) && (atc_h < AUDIO_MAX_ATC_CONTEXTS) ) {
      result = true;
   }
   else {
      AUDIO_ERROR("Invalid ATC Handle",ISMD_ERROR_INVALID_HANDLE, atc_devh );
   }

   return ( result );
}


static bool
audio_pvt_atc_stream_valid_handle( audio_atc_stream_t atc_stream_h )
{
   bool result = false;

   if ( (atc_stream_h >= 0) && (atc_stream_h < AUDIO_MAX_ATC_STREAMS) ) {
      result = true;
   }
   else {
      AUDIO_ERROR("Invalid ATC stream handle",ISMD_ERROR_INVALID_HANDLE, atc_devh );
   }

   return ( result );
}

static ismd_result_t
audio_pvt_atc_set_new_alarm_clock(audio_atc_device_t *dev_wl, ismd_clock_t clock_h, int chunk_period)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_time_t alarm_interval = 0;
   ismd_time_t new_timer_current_time = 0;
   ismd_time_t prev_timer_current_time = 0;
   static ismd_time_t first_alarm_time = 0;
   uint32_t ticks_since_last_alarm = 0;
   ismd_clock_t prev_handle = ISMD_CLOCK_HANDLE_INVALID;
   os_irqlock_local_t   irqlocal;

   /* Figure out clock ticks interval we want to be alarmed on based on the ms chunk given*/
   alarm_interval = (ismd_time_t)(CLOCK_TICKS_PER_MS * chunk_period);

   prev_handle = dev_wl->timer_clock_h;

   //Check to see if we already have an alarm setup
   if(dev_wl->timer_clock_alarm_h != ISMD_CLOCK_HANDLE_INVALID && dev_wl->timer_clock_h != ISMD_CLOCK_HANDLE_INVALID) {

      ismd_clock_alarm_cancel(dev_wl->timer_clock_h, dev_wl->timer_clock_alarm_h);
      dev_wl->timer_clock_alarm_h = ISMD_CLOCK_HANDLE_INVALID;
      dev_wl->timer_clock_h = ISMD_CLOCK_HANDLE_INVALID;
   }

   /* Set the new clock to our timer clock */
   dev_wl->timer_clock_h = clock_h;

   os_irqlock_acquire( &dev_wl->irq_lock, &irqlocal );

   if(prev_handle != ISMD_CLOCK_HANDLE_INVALID){
      if((result =  ismd_clock_get_time_th_safe(prev_handle, &(prev_timer_current_time))) != ISMD_SUCCESS) {
         AUDIO_ERROR("ismd_clock_get_time_th_safe failed!", result, atc_devh);
      }
   }

   if(dev_wl->timer_clock_h != ISMD_CLOCK_HANDLE_INVALID){
      if((result =  ismd_clock_get_time_th_safe(dev_wl->timer_clock_h, &(new_timer_current_time))) != ISMD_SUCCESS) {
         AUDIO_ERROR("ismd_clock_get_time_th_safe failed!", result, atc_devh);
      }
   }
   
   os_irqlock_release(&dev_wl->irq_lock, &irqlocal);

   if(first_alarm_time == 0){
      first_alarm_time = new_timer_current_time;      
   }
   else {
      ticks_since_last_alarm = (uint32_t)(OSAL_MOD64((prev_timer_current_time - first_alarm_time), alarm_interval));
      first_alarm_time = new_timer_current_time + (alarm_interval - ticks_since_last_alarm);   
   }

   if((result = ismd_clock_alarm_schedule(dev_wl->timer_clock_h, (first_alarm_time), alarm_interval, dev_wl->clock_alarm_event, &(dev_wl->timer_clock_alarm_h))) != ISMD_SUCCESS) {
      AUDIO_ERROR("clock_alarm_schedule failed!", result, atc_devh);
   }
   else {
      dev_wl->clock_alarm_period = chunk_period;
   }

   /* Reset our last_time counter for the new clock */
   atc_device.last_clock_alarm_time = 0;

   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
      SVEN_MODULE_EVENT_AUD_IO_ATC_SET_NEW_ALARM_CLOCK,
      dev_wl->default_clock_h,
      dev_wl->primary_clock_h,
      dev_wl->timer_clock_h,
      prev_handle,
      (unsigned int) alarm_interval, ticks_since_last_alarm);

   return result;
}

static void
audio_pvt_atc_check_if_clock_is_timer(audio_atc_stream_context_t *stream_wl, audio_atc_device_t *dev_wl)
{
   bool change_timer_clock = true;
   ismd_clock_t new_clock_h = ISMD_CLOCK_HANDLE_INVALID;
   ismd_clock_t clock_h = stream_wl->clock_h;

   /*If the clock is our timer clock but NOT our default clock set it back*/
   if((clock_h == dev_wl->timer_clock_h) && (clock_h != dev_wl->default_clock_h)) {

      //If the clock was our primary clock, make sure to reset the clock.
      if(dev_wl->primary_clock_h == clock_h){

         //Make sure we are going to free the primary clock the device has. If not dont reset the timer.
         //This is for instances where we have a passthrough stream that uses the same clock handle as the primary.
         if(dev_wl->timer_clock_stream_wl == stream_wl ) {
            dev_wl->primary_clock_h = ISMD_CLOCK_HANDLE_INVALID;
            dev_wl->timer_clock_stream_wl = NULL;
         }
         else{
            change_timer_clock = false;
         }
      }
   
      new_clock_h = dev_wl->default_clock_h;

      //Finally set the clock.
      if(change_timer_clock){
         audio_pvt_atc_set_new_alarm_clock(dev_wl, new_clock_h, AUDIO_CORE_GET_CHUNK_PERIOD(stream_wl->atc_wl));
      }
   }

   return ;
}


static void
audio_pvt_atc_add_event_to_list( audio_atc_device_t *dev_wl, ismd_event_t event)
{
   int loop = 0;
   bool found = false;

   /* If the specified event is already in the event list, don't add it again */
   for(loop = 0; loop < dev_wl->event_list_count; loop++){
      if(event == dev_wl->event_list[loop]){
         found = true;
         loop = dev_wl->event_list_count;
      }
   }

   if(!found){
      /* Don't add an event to the list if the list is already full */
      if(dev_wl->event_list_count < ISMD_EVENT_LIST_MAX){
         dev_wl->event_list[dev_wl->event_list_count] =  event;
         dev_wl->event_list_count++;
      }
      else{
         AUDIO_ERROR("Failed to add event to list, list full!", ISMD_ERROR_NO_SPACE_AVAILABLE, atc_devh);
      }
   }

   return;
}


static void
audio_pvt_atc_remove_event_from_list(audio_atc_device_t *dev_wl, ismd_event_t event)
{
   int loop = 0;
   int shift_loop = 0;

   for(loop = 0; loop < dev_wl->event_list_count; loop++) {

      if(event == dev_wl->event_list[loop]) {

         shift_loop = loop;

         while((shift_loop + 1) < dev_wl->event_list_count) {

            dev_wl->event_list[shift_loop] = dev_wl->event_list[shift_loop +1];
            shift_loop++;
         }

         dev_wl->event_list_count--;
         break;
      }
   }

   return;
}

void audio_fix_samples(int *pi_drop, int i_length_drop, int *pi_keep, int i_length_fix, int i_index_drop,int i_num_channels,int sample_size)
{
int i=0, j=0;
int i_current_start=0, i_current_end=0;
int i_sample_drop=0;
int i_sample_fix=0;
int i_tmp=0;

   int16_t *pi_drop_16bit;
   int16_t *pi_keep_16bit;

   pi_drop_16bit = (int16_t*)pi_drop;
   pi_keep_16bit = (int16_t*)pi_keep;


	i_current_start = i_index_drop;
	i_current_end = i_current_start + i_length_fix;
   if (sample_size >16)
   {
	for( i=i_current_start; i<i_current_end; i++)
	{
		//Pick one-by-one of single-channel samples:
		for( j=0; j<i_num_channels; j++ )
		{
			/*
			Pick drop and fix samples.
			*/
            i_sample_drop = (*(pi_drop + j));
            i_sample_drop = i_sample_drop >> 16;
            i_sample_fix  = *pi_keep;
            i_sample_fix = i_sample_fix >> 16;
			/*
			Smooth
			*/
			i_tmp = ( i_sample_fix - i_sample_drop) * ( i );
			i_tmp = i_tmp / (i_length_drop);
			i_tmp += i_sample_drop;
			/* Handle Saturation*/
			if (i_tmp >= 1 << 15) {
			   /* saturate on overflow */
			   i_tmp = (1 << 15) - 1;
			}
			else if (i_tmp <= -1 << 15) {
			   /* saturate on underflow */
			   i_tmp = (-1 << 15) + 1;
			}
			/* Put the sample back in input keep buffer */
			*(pi_keep++) = (i_tmp << 16);
		}

         pi_drop += i_num_channels;

	}

   }
   else
   {
   	for( i=i_current_start; i<i_current_end; i++)
   	{
   		//Pick one-by-one of single-channel samples:
   		for( j=0; j<i_num_channels; j++ )
   		{
   			/*
   			Pick drop and fix samples.
   			*/
            i_sample_drop = (*(pi_drop_16bit+ j));

            i_sample_fix  = *pi_keep_16bit;
   			/*
   			Smooth
   			*/
   			i_tmp = ( i_sample_fix - i_sample_drop) * ( i );
   			i_tmp = i_tmp / (i_length_drop);
   			i_tmp += i_sample_drop;
   			/* Handle Saturation*/
   			if (i_tmp >= 1 << 15) {
   			   /* saturate on overflow */
   			   i_tmp = (1 << 15) - 1;
   			}
   			else if (i_tmp <= -1 << 15) {
   			   /* saturate on underflow */
   			   i_tmp = (-1 << 15) + 1;
   			}
   			/* Put the sample back in input keep buffer */
   			*(pi_keep_16bit++) = i_tmp;
   		}

            pi_drop_16bit += i_num_channels;

   	}
   }

}


static void
audio_fixup_discontinuity(int *first_samples_to_drop, void *samples_to_keep,
   int num_samples_to_keep, int sample_size, int num_channels, int num_samples_to_adjust)
{
   int i;
   int channel;
   int bytes_per_sample;
   int consecutive_sample_dist;
   int16_t * pfirst_samples_to_drop = NULL;

   OS_ASSERT(sample_size >= 16 && sample_size <= 32);
   OS_ASSERT(num_channels >= 1 && num_channels <= 8);

   if (num_samples_to_adjust > num_samples_to_keep) {
      num_samples_to_adjust = num_samples_to_keep;
   }

   if (sample_size > 16) {
      bytes_per_sample = 4;
   } else {
      bytes_per_sample = 2;
   }
   consecutive_sample_dist = bytes_per_sample * num_channels;

   for (channel = 0; channel < num_channels; channel++) {
      void *sample_ptr;

      if (sample_size > 16) {
         first_samples_to_drop[channel] >>= 16;
      }
      else if(sample_size == 16)
      {
          pfirst_samples_to_drop = (int16_t*)first_samples_to_drop;
      }

      sample_ptr = (void*)(samples_to_keep + bytes_per_sample * channel);
      for (i = 0; i < num_samples_to_adjust; i++) {
         int sample;
         int avg_component1;
         int avg_component2;

         if (sample_size > 16) {
            sample = *(int32_t*)sample_ptr;
            sample >>= (sample_size - 16);
         } else {
            sample = *(int16_t*)sample_ptr;
         }

         /* do weighted average of the current sample and the first sample
            dropped*/
         if(sample_size > 16)
         {
            avg_component1 = first_samples_to_drop[channel] * (num_samples_to_adjust - i);
         }
         else
         {
            avg_component1 = pfirst_samples_to_drop[channel] * (num_samples_to_adjust - i);
         }
         avg_component2 = sample * i;
         sample = (avg_component1 + avg_component2) / num_samples_to_adjust;

         if (sample >= 1 << 15) {
            /* saturate on overflow */
            sample = (1 << 15) - 1;
         } else if (sample <= -1 << 15) {
            /* saturate on underflow */
            sample = (-1 << 15) + 1;
         }

         if (sample_size > 16) {
            int32_t *temp;

            sample <<= 16;
            temp = (int32_t*)sample_ptr;
            *temp = sample;
         } else {
            int16_t *temp;
            temp = (int16_t*)sample_ptr;
            *temp = (int16_t)sample;
         }

         sample_ptr += consecutive_sample_dist;
      }
   }
}

ismd_result_t
audio_timing_control_set_slave_clock( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_clock_t clock_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;
   
   AUDIO_ENTER(atc_devh);

   //Lock down the Device and ATC 
   audio_pvt_atc_dev_lock(&atc_device);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS) {

      stream_wl->slave_clock_h = clock_h;

      AUDIO_EVENT(1, atc_devh,
         SVEN_MODULE_EVENT_AUD_IO_ATC_SET_SLAVE_CLOCK,
         (unsigned int) atc_h,
         (unsigned int) atc_stream_h,
         (unsigned int) clock_h,
         (unsigned int) stream_wl->time_period_ms, 0, 0);

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }

   /* Unlock down the device */
   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_set_timing_mode( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_timing_mode_t timing_mode )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;
   audio_atc_context_t *atc_wl = NULL;

   AUDIO_ENTER(atc_devh);

   //Lock down the Device and ATC 
   audio_pvt_atc_dev_lock(&atc_device);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS) {

      atc_wl = stream_wl->atc_wl;
      stream_wl->timing_mode = timing_mode;

      /* If run in original time domain, make sure discontinuity event is allocated, added to the list, and registered with the clock */
      
      if(timing_mode == ISMD_TIMING_MODE_ORIGINAL) {

         /* If stream does not have a discontinuity event allocated, allocate it now and add it to the event list  */
         if(stream_wl->discontinuity_event == ISMD_EVENT_HANDLE_INVALID){
            if ((result = ismd_event_alloc(&stream_wl->discontinuity_event)) != ISMD_SUCCESS) {
               AUDIO_ERROR("ismd_event_alloc failed!", result, atc_devh);
            }
            else{
               audio_pvt_atc_add_event_to_list(&atc_device, stream_wl->discontinuity_event);
            }
            
         }

         /* Register the discontinuity event with the clock */
         if (stream_wl->clock_h != ISMD_CLOCK_HANDLE_INVALID ) {
            ismd_clock_set_time_discontinuity_event(stream_wl->clock_h, stream_wl->discontinuity_event, ATC_MAX_CLOCK_DRIFT);
         }
         
      }
      else{
         /* When setting to another time doman (not original), make sure there isn't a discontinuity event allocated or in the event list */
         if(stream_wl->discontinuity_event != ISMD_EVENT_HANDLE_INVALID){            
         
            /* Unregister the discontinuity event from clock if we have a valid handle */
            if (stream_wl->clock_h != ISMD_CLOCK_HANDLE_INVALID ) {
               ismd_clock_set_time_discontinuity_event(stream_wl->clock_h, ISMD_EVENT_HANDLE_INVALID, ATC_MAX_CLOCK_DRIFT);            
            }

            /* Remove event from wait list */
            audio_pvt_atc_remove_event_from_list(&atc_device, stream_wl->discontinuity_event);

            /* Free discontinuity event */
            ismd_event_free(stream_wl->discontinuity_event);
            stream_wl->discontinuity_event = ISMD_EVENT_HANDLE_INVALID;
         }            

      }

      AUDIO_EVENT(1, atc_devh,
         SVEN_MODULE_EVENT_AUD_IO_ATC_SET_PTS_MODE,
         (unsigned int) atc_h,
         (unsigned int) atc_stream_h,
         (unsigned int) timing_mode,
         0, 0, 0);

      audio_pvt_atc_unlock(atc_wl);
   }

   /* Unlock down the device */
   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return result;
}

ismd_result_t
audio_timing_control_set_newsegment_policy( audio_atc_t atc_h, audio_atc_stream_t atc_stream_h, ismd_newsegment_policy_t policy)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   audio_atc_stream_context_t *stream_wl = NULL;

   AUDIO_ENTER(atc_devh);

   //Lock down the Device and ATC 
   audio_pvt_atc_dev_lock(&atc_device);

   if((result = audio_pvt_atc_stream_lock_and_get_wl(atc_h, atc_stream_h, &stream_wl)) == ISMD_SUCCESS) {

      stream_wl->newsegment_policy = policy;

      audio_pvt_atc_unlock(stream_wl->atc_wl);
   }

   /* Unlock down the device */
   audio_pvt_atc_dev_unlock(&atc_device);

   AUDIO_EXIT(atc_devh);
   return result;
}

//A simple helper function for audio_pvt_atc_adjust_slave_clock
static void
audio_pvt_atc_set_slave_clock(audio_atc_stream_context_t *stream_wl)
{
   uint64_t render_sample_count = 0;
   uint32_t render_level_samples = 0;
   audio_buffer_attr_t *buf_attrib = NULL;

   buf_attrib = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);
   stream_wl->original_pts_on_slave_clock_adjustment = buf_attrib->original_pts;

   audio_core_get_render_base_numbers(stream_wl->atc_wl->processor_id, stream_wl->curr_stream_info.sample_rate, &render_sample_count, &render_level_samples);
   //Maybe should compensate on samples on ATC output queue and samples in post-ATC pipe(dsp0)
   //But in polling mode, thoes queue should always be full then a constant value
   stream_wl->render_sample_count_on_slave_clock_adjustment = render_sample_count;

   ismd_clock_set_time(stream_wl->slave_clock_h, buf_attrib->original_pts);

   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
         SVEN_MODULE_EVENT_AUD_IO_ATC_ADJUST_SLAVE_CLOCK,
         (unsigned int) stream_wl->atc_wl->handle,
         (unsigned int) stream_wl->handle,
         (unsigned int)(buf_attrib->original_pts >>32),
         (unsigned int)(buf_attrib->original_pts),
         (unsigned int)(render_sample_count>>32),
         (unsigned int)render_sample_count);
}

/*******************************************************************************
 *   Function: audio_pvt_atc_adjust_slave_clock
 *
 *   Abstract:
 *       Adjust the slave clock using the original PTS 
 *   
 *   Algorithm:
 *       On stream playback start, the slave clock will be reset by the first PTS
 *       After that, the clock will run at 90KHz. Since the PTS should also be 
 *       samples of a 90KHz clock (encoder does this), the PTS values hearafter
 *       should always match the slave clock counter except there is a PTS 
 *       discontinuity.
 *       Although you can set/adjust the slave on every original PTS you get, but
*       this will definitely introduce slave clock jittering due to software latency.
*       So here we only adjust clock when PTS discontinuity detected.
*       How to detect PTS discontinuity? This is done through the relationship between
*       the PTS value and audio samples that we have rendered. The PTS value should be
*       in proportion with the rendered sample number. When they get out of proportion, 
*       we know there is a PTS discontinuity.
*
*******************************************************************************/
static void
audio_pvt_atc_adjust_slave_clock(audio_atc_stream_context_t *stream_wl)
{
   uint64_t render_sample_count = 0;
   uint32_t render_level_samples = 0;
   int64_t pts_difference = 0;
   uint64_t abs_pts_difference = 0;
   ismd_pts_t ticks_by_samples_rendered = 0;
   audio_buffer_attr_t *buf_attrib = NULL;
   uint64_t delta;

   buf_attrib = (audio_buffer_attr_t *) &(stream_wl->output_buffer->attributes);

   //This can only be called when slave clock is set
   //Put an asseert here
   OS_ASSERT(stream_wl->slave_clock_h != ISMD_CLOCK_HANDLE_INVALID);

   //If there is no original PTS, just return
   if (buf_attrib->original_pts == ISMD_NO_PTS) {
      return;
   }

   //On the first call of this function, reset the slave clock using original PTS
   if(!stream_wl->slave_clock_initialized) {
      audio_pvt_atc_set_slave_clock(stream_wl);
      stream_wl->slave_clock_initialized = true;
      return;
   }

   //Try to figure out whether there is a PTS discontinuity and adjust clock accordingly
   audio_core_get_render_base_numbers(stream_wl->atc_wl->processor_id, stream_wl->curr_stream_info.sample_rate, &render_sample_count, &render_level_samples);
   render_sample_count -= stream_wl->render_sample_count_on_slave_clock_adjustment;
   ticks_by_samples_rendered = OSAL_DIV64((render_sample_count * (uint32_t)CLOCK_SPEED_HZ), (uint32_t)stream_wl->curr_stream_info.sample_rate);

   pts_difference = buf_attrib->original_pts - stream_wl->original_pts_on_slave_clock_adjustment;

   //Always adjust slave clock on pts backward jumping
   if(pts_difference < 0) {
      audio_pvt_atc_set_slave_clock(stream_wl);
   } else {
      abs_pts_difference = pts_difference;
      delta = ticks_by_samples_rendered>abs_pts_difference?ticks_by_samples_rendered-abs_pts_difference:abs_pts_difference-ticks_by_samples_rendered;
      if(delta > ATC_MAX_CLOCK_DRIFT) {
         audio_pvt_atc_set_slave_clock(stream_wl);
      }
   }
}

ismd_result_t
audio_pvt_atc_calculate_asrc_drift(audio_atc_context_t *wl, audio_atc_stream_context_t *stream_wl)
{
   ismd_time_t stream_time, timer_time;
   os_irqlock_local_t   irqlocal;
   int64_t timer_clk_ticks, stream_clk_ticks;
   int64_t timer_sample_count, stream_sample_count;
   int64_t cumulative_sample_drift;
   int sample_drift_per_chunk;
   audio_atc_device_t *dev_wl = wl->dev_wl;
   ismd_result_t result = ISMD_SUCCESS;

   os_irqlock_acquire( &dev_wl->irq_lock, &irqlocal );
   if((result = ismd_clock_get_time_th_safe(dev_wl->timer_clock_h, &timer_time)) != ISMD_SUCCESS) {
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "atc: ismd_clock_get_time for timer failed!", atc_devh);
   }
   else if((result = ismd_clock_get_time_th_safe(stream_wl->clock_h, &stream_time)) != ISMD_SUCCESS) {
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "atc: ismd_clock_get_time for stream failed!", atc_devh);
   }
   os_irqlock_release(&dev_wl->irq_lock, &irqlocal);
   
   if(result == ISMD_SUCCESS){
      //if first time then save the time and set the cumulative sample correction = 0
      if(!stream_wl->asrc.drift_detection_started){
         stream_wl->asrc.timer_time = timer_time;
         stream_wl->asrc.stream_time = stream_time;
         stream_wl->asrc.cumulative_sample_correction = 0;
         stream_wl->asrc.drift_detection_started = true;
      }
      else {
         //Calculate sample drift and if it is more than min then apply. Add that value to cumulative sample correction if we apply.
         timer_clk_ticks = (int64_t)(timer_time - stream_wl->asrc.timer_time);
         stream_clk_ticks = (int64_t)(stream_time - stream_wl->asrc.stream_time);
         timer_sample_count = AUDIO_DIV64((timer_clk_ticks * (int64_t)stream_wl->curr_stream_info.sample_rate) , (int64_t)CLOCK_SPEED_HZ);
         stream_sample_count = AUDIO_DIV64((stream_clk_ticks * (int64_t)stream_wl->curr_stream_info.sample_rate) , (int64_t)CLOCK_SPEED_HZ);
         cumulative_sample_drift = timer_sample_count - stream_sample_count;
         sample_drift_per_chunk = (int)(cumulative_sample_drift - stream_wl->asrc.cumulative_sample_correction);
         if(abs(sample_drift_per_chunk) >= stream_wl->asrc.minimal_adjust){
            stream_wl->asrc.sample_drift_per_chunk = sample_drift_per_chunk;
            stream_wl->asrc.cumulative_sample_correction += sample_drift_per_chunk;
         }
         
         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, atc_devh,
            SVEN_MODULE_EVENT_AUD_IO_ATC_INPUT_CLOCK_DRIFT_DETECT,
            stream_wl->handle, 
            (int)(cumulative_sample_drift),                            
            sample_drift_per_chunk, stream_wl->asrc.minimal_adjust, (int)stream_wl->asrc.cumulative_sample_correction, 0);
      }
   }
   
   return result;
}

void
audio_pvt_atc_asrc_reset(audio_atc_stream_context_t *stream_wl)
{
   stream_wl->asrc.drift_detection_started = false;
   stream_wl->asrc.cumulative_sample_correction = 0;
   stream_wl->asrc.sample_drift_per_chunk = 0;
}
