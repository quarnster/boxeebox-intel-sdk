
/*
* File Name: audio_linked_list.c
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2008 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "audio_linked_list.h"

/*
 * Initialize a linked-list.
 */
void audio_list_init( audio_list_t *list )
{
   osal_result os_result;

   list->head = NULL;
   list->tail = NULL;
   os_result = os_mutex_init( &(list->lock));

   OS_ASSERT( os_result == OSAL_SUCCESS );
}


/*
 * Deinitialize a linked-list.
 */
void audio_list_deinit( audio_list_t *list )
{
   list->head = NULL;
   list->tail = NULL;
   os_mutex_destroy( &(list->lock) );
}


/*
 * Lock a linked list.
 */
void audio_list_lock( audio_list_t *list )
{
   os_mutex_lock( &(list->lock) );
}


/*
 * Unlock a linked list.
 */
void audio_list_unlock( audio_list_t *list )
{
   os_mutex_unlock( &(list->lock) );
}


/*
 * Insert a new node into a list at the position after the specified node.
 * Specify NULL to insert the new node at the head of the list.
 * Note that there is no way for this function to synchronize the prev_node.
 * I.e. if the prev_node was deleted before calling this function, bad things
 * are going to happen.  The caller must lock the prev_node so that it cannot
 * be manipulated within the list before calling this function.
 */
void audio_list_insert( audio_list_t      *list,
                        audio_list_node_t *prev_node,
                        audio_list_node_t *new_node )
{
   OS_ASSERT( list != NULL );
   OS_ASSERT( new_node != NULL );

   audio_list_lock( list );

   new_node->prev = prev_node;

   if ( prev_node == NULL ) {
      new_node->next = list->head;
      list->head = new_node;
   }
   else {
      new_node->next = prev_node->next;
      prev_node->next = new_node;
   }

   if ( new_node->next == NULL ) {
      list->tail = new_node;
   }
   else {
      (new_node->next)->prev = new_node;
   }

   audio_list_unlock( list );
}


/*
 * Remove the specified node from the list.
 * Note that there is no way for this function to synchronize the node. I.e.
 * if node was deleted before calling this function, bad things are going to
 * happen.  The caller must lock node so that it cannot be manipulated within
 * the list before calling this function.
 */
void audio_list_delete( audio_list_t      *list,
                        audio_list_node_t *node )
{
   OS_ASSERT( list != NULL );
   OS_ASSERT( node != NULL );

   audio_list_lock( list );

   if ( node->prev == NULL ) {
      list->head = node->next;
   }
   else {
      (node->prev)->next = node->next;
   }

   if ( node->next == NULL ) {
      list->tail = node->prev;
   }
   else {
      (node->next)->prev = node->prev;
   }

   audio_list_unlock( list );
}


/*
 * Add a node to the tail of a list.
 * This function locks the list so it is thread-safe.
 */
void audio_list_enqueue( audio_list_t *list, audio_list_node_t *node )
{
   OS_ASSERT( list != NULL );
   OS_ASSERT( node != NULL );

   audio_list_lock( list );

   if ( list->tail == NULL ) {
      list->head = node;
   }
   else {
      (list->tail)->next = node;
   }

   node->next = NULL;
   node->prev = list->tail;
   list->tail = node;

   audio_list_unlock( list );
}


/*
 * Remove the node at the head of a list and return a pointer to the node.
 * This function locks the list so it is thread-safe.
 */
audio_list_node_t *audio_list_dequeue( audio_list_t *list )
{
   audio_list_node_t *node;

   OS_ASSERT( list != NULL );

   audio_list_lock( list );

   node = list->head;

   if ( node != NULL ) {
      list->head = node->next;

      if ( list->head == NULL ) {
         list->tail = NULL;
      }
      else {
         (list->head)->prev = NULL;
      }
   }

   audio_list_unlock( list );

   return ( node );
}

