/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef _AUDIO_QUALITY_DEFS_H_
#define _AUDIO_QUALITY_DEFS_H_

#ifdef ACEDEVENV
#define AUDIO_MAX_INPUT_CHANNELS 8
#define AUDIO_MAX_OUTPUT_CHANNELS 8
#define AUDIO_QUALITY_MAX_FILTERS 40
#define AUDIO_QUALITY_MAX_CONTROLS 16
#else
#include "ismd_audio_defs.h"
#endif

#define ACE_INVALID_HANDLE -1
#define ACE_INVALID_STAGE -1
#define ACE_INVALID_CHANNEL -1

#define ACETYP_NONE		0
#define ACETYP_HPF2		1
#define ACETYP_LPF2		2
#define ACETYP_HPF1		3
#define ACETYP_LPF1		4
#define ACETYP_SHLF_L2	5
#define ACETYP_SHLF_H2	6
#define ACETYP_SHLF_L1	7
#define ACETYP_SHLF_H1  8
#define ACETYP_PEQ2		9
#define ACETYP_AVLCTL	10
#define ACETYP_PCVOLCTL	11
#define ACETYP_LOUDBASSCTL	13
#define ACETYP_LOUDTREBCTL	14


#define NUMACE_CHANNELS AUDIO_MAX_OUTPUT_CHANNELS
#define NUMACE_FLTDSCR AUDIO_QUALITY_MAX_FILTERS
#define NUMACE_CTLDSCR AUDIO_QUALITY_MAX_CONTROLS
#define NUMACE_STAGES_PER_CHAN 22
#define NUMACE_STATE_DEPTH 6
#define NUMACE_EVENTS 8
#define ACE_INTERNAL_DATASZ 256

// for errors, or SUCCESS
#define ACE_SUCCESS 0
#define ACE_ERROR   1

typedef 
struct tACECTLPRM
{
	int type;
	int Parms[12];
} ACECTLPRM;

typedef struct tACEFltParm
{
	// the order is important, assembly code
	// uses this order
	int b[3];
	int a[2];
	int tmp;
} ACEFLTPRM;

typedef struct tACEAVLDSCR
{
	int GainRatioX;
	int K2;
	int T2;
	int T2Gain;
	int T1;
	int T1Gain;
	int K0;
	int Offset;
	int Attack;
	int Release;
} ACEAVLDSCR;

typedef struct tACEAVLParm
{
	int WindowSz;
	int WindowCnt;
	int EnergyWindowSz;
	int EnergyWindowCnt;
	int AvgEstFactor;
	int CurGainRatio;
	
	// these are order sensitive, do not move
	int T3;
	int Set3;
	int K2;
	int T2;
	int Set2;
	int K1;
	int T1;
	int Set1;
	int K0;
	int Offset;
	// end sensitive order
	
	int Attack;
	int Release;
	
	unsigned int AccumL[NUMACE_CHANNELS];
	unsigned int AccumH[NUMACE_CHANNELS];
} ACEAVLPRM;


typedef struct tACEPIMIX4DSCR
{
	// which channels, channels start with zero
	int MixSrc[4];
	int dBx10[4];
	int PhInv[4];
	// the units of the ramp are naperian time consstant in 0.1 milliseconds
	int RampTC[4];
} ACEPIMIX4DSCR;

typedef struct tACEPIMIX4Parm
{
	int IsMix;
	int MixSrc[4];
	int TargetGain[4];
	int CurCoeff[4];
	int RampCoeff[4];
} ACEPIMIX4PRM;


typedef struct tACEREVERBDSCR
{
	int cnt;
	int Delay[4];
	int Mix[4];
} ACEREVERBDSCR;

typedef
struct tReverbParms
{
	int *pLastBuffElem;
	int *pFirstBuffElem;
	int Init;
	int *pLastEntry;
	int MixCnt;
	int Mix1LastAddr;
	int Mix1Coeff;
	int Mix2LastAddr;
	int Mix2Coeff;
	int Mix3LastAddr;
	int Mix3Coeff;
	int Mix4LastAddr;
	int Mix4Coeff;
} ACEREVERBPRM;

typedef struct tACEFLTDSCR
{
	int type; // type, use ACETYP_*
	int Fc;   // cutoff frequency
	int Q;    // Q factor of filter
	int Gain; // Gain of filter
} ACEFLTDSCR;

typedef struct tACECTLDSCR
{
    int type;		// type of control, use ACETYP_*
    int NumParms;   // number of valid parms, fixed per control type
    int Parms[8];   // contents vary per control type
} ACECTLDSCR;

typedef struct tACEChan
{
	int *pIn;
	int *pOut;
	int nSamples; 
	int Bypass[NUMACE_STAGES_PER_CHAN];
	void (*pFunc[NUMACE_STAGES_PER_CHAN])(int *pIn,int *pOut,int nSmpls,void *Parms,void *State);
	void *pParms[NUMACE_STAGES_PER_CHAN];
	int State[NUMACE_STAGES_PER_CHAN][NUMACE_STATE_DEPTH];
} ACECHAN;

typedef 
struct tACEUser
{
	// these are descriptors, for each channel there are NUMACE_STAGES_PER_CHAN
	// of stages, the stages contain handles to descriptors, as follows:
	// 0        means no dscr, processing ends with this stage
	// 1-100    for filter descriptors 0-99
	// 101-200  for control descriptors 0-99
    int IAChannels[NUMACE_CHANNELS][NUMACE_STAGES_PER_CHAN];
    
    // Bypass
    char IABypass[NUMACE_CHANNELS][NUMACE_STAGES_PER_CHAN];
    
  
    // these are the filter descriptors, the handles range from 
    // (1 to NUMACE_FLTDSCR + 1), the index to the array is one less than
    // the handle. This is where the type of filter desired and its parameters 
    // are stored. Several stages for several channels may all reference the 
    // same Filter
	ACEFLTDSCR IAFilters[NUMACE_FLTDSCR];

    // these are the control descriptors, the handles range from
    // 101 to (NUMACE_CTLDSCR + 100), the index to the array is 101 less than
    // the handle. This is where the type of control is stored, and its parameters.
    // Several stages for several channels may all reference the same Control.   
	ACECTLDSCR IAControls[NUMACE_CTLDSCR];
	
	// this is for channel duplication / splits
	int DupBypass;
	int DupBeforeStage;
	int DupFrom[NUMACE_CHANNELS];
	
	int PIMix4Bypass;
	ACEPIMIX4DSCR PIMix4[NUMACE_CHANNELS];
	
	int IAAVLBypass;
	ACEAVLDSCR IACtlAVL;
	
	// master volume control
	int MasterVolBypass;
	int MasterVol;
	int MasterVolRamp;
	
	// master mute control
	int MasterMuteBypass;
	int MasterMuteOn;
	int MasterMuteRamp;
	
	int IAClampBypass;  
	int IAClamp10xdB[NUMACE_CHANNELS];
	
	// for Reverb
	int IAReverbBypass;
	int *DelayLine[NUMACE_CHANNELS];
	int DelayLineSz;
	ACEREVERBDSCR IAReverb[NUMACE_CHANNELS];
}ACEUSER;


typedef 
struct tACESystem
{
      ACEUSER IAParams;
	
	// IA side
	/**************************************************************************/
	// IA and DSP side
	int CacheBuffZone1[16]; // cache line buffer, to separate the two regions
	
	// used for callbacks, the queue is 8 long, and there can be up to 5 values
	// per event, the first value is the event type
	int NumCallBacks; // tells how many callback events are valid, the DSP
	                  // side sets this, the IA side clears this after pushing the
	                  // messages up to the application
	int CallBackEvent[NUMACE_EVENTS][5];
	
	
	int CacheBuffZone2[16]; // cache line buffer, to separate the two regions
	/**************************************************************************/
	// DSP side

	// we keep a copy of the sample rate for which all of the parameters 
	// where last computed. If this value changes, all of the parameters on
	// the DSP side will need to be recomputed
	int CurSampleRate;
	
	// dsp area change flags // dkl 8-27-2010
	char dsp_bypass_change;
	char dsp_flt_param_change;
	char dsp_ctl_param_change;
	char dsp_config_change;
	char dsp_avl_config_change;
	char dsp_ace_init;
	char ctag0;
	char ctag1;
	
	int AVLBypass;
	
	int PIMix4WindowSz;
	int PIMix4WindowCnt;
	int PIMix4Bypass;
	ACEPIMIX4PRM PIMix4Parms[NUMACE_CHANNELS];
	
	// one of these for each channel,
	// they hold history info, pointers to buffers for each
	// channel, and the list of stages parameters, and stage functions
	ACECHAN Channels[NUMACE_CHANNELS];
	
	// filter parameter references - for storing filter parms
	// a single one of these can be referenced by multiple stages
	ACEFLTPRM FilterParms[NUMACE_FLTDSCR];
	
	ACECTLPRM CtlParms[NUMACE_CTLDSCR];
	
	// for Master volume
	int MasterVolBypass;
	ACECTLPRM MasterVolume;
	int MasterVolState[NUMACE_CHANNELS][NUMACE_STATE_DEPTH];
	
	// for Master Mute
	int MasterMuteBypass;
	ACECTLPRM MasterMute;
	int MasterMuteState[NUMACE_CHANNELS][NUMACE_STATE_DEPTH];
	
	// for the one allowable AVL module
	ACEAVLPRM AVLParms;
	
	int ClampBypass;
	int ClampHi[NUMACE_CHANNELS];
	int ClampLo[NUMACE_CHANNELS];
	
	// Reve;rb 
	int ReverbBypass;
	ACEREVERBPRM ReverbParms[NUMACE_CHANNELS];
	
	// this is for channel duplication / splits
	int DupBypass;
	int DupBeforeStage;
	int DupFrom[NUMACE_CHANNELS];
	
	int BuffLn;
	int Buff[NUMACE_CHANNELS][ACE_INTERNAL_DATASZ];
	
	// internal use for the DSP side only, contains precomputed logs base
	// 2 of certain value sets
	int LogTables[100];
	
	int XCoeffcients[16];
	
	// to make even number of cache lines
	int padspace[6];
	
} ACESYSTEM;





#endif

