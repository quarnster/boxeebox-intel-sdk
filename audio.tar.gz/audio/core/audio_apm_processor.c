
/*
* File Name: audio_apm_processor.c
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_apm_common.h"
#include "pal.h"
#include "clock_control.h"

/*********************************************************************************************/
/* Audio Processor private fucntion declarations */
/*********************************************************************************************/

static ismd_result_t
audio_pvt_processor_psm_pipe_init(ismd_audio_processor_context_t *wl);

static ismd_result_t
audio_pvt_init_locks(ismd_audio_processor_context_t *wl);

static void
audio_pvt_deinit_locks(ismd_audio_processor_context_t *wl);

static void
audio_pvt_get_avail_codecs(void);

static void
audio_pvt_print_avail_codecs(void) ;

static void
audio_pvt_free_stage_param_buffer(audio_psm_post_atc_pipe_t *pipe);

static ismd_result_t
audio_pvt_alloc_stage_param_buffer(audio_psm_post_atc_pipe_t *pipe);

static ismd_result_t
audio_pvt_psm_pipe_add_input(ismd_audio_processor_context_t *wl, ismd_audio_input_wl_t *input_wl, 
   int mixer_input_index, audio_psm_output_configs_t *output_configs, bool is_associated_stream);

static ismd_result_t
audio_pvt_processor_post_atc_pipe_setup_and_start(ismd_audio_processor_context_t *wl, bool lock);

static ismd_result_t 
audio_pvt_insert_srs_stage(ismd_audio_processor_context_t *wl,int stage_index);

/*********************************************************************************************/



/*********************************************************************************************/
/* Audio Processor global variables  */
/*********************************************************************************************/

/*  For now, we suport only a fixed number of processor devices. */
ismd_audio_processor_context_t processor_context[AUDIO_MAX_PROCESSORS];

/*Flag to show if the highlevel code has been initialized.*/
static int apm_initialized;

/*Global processor handle and lock*/
static ismd_audio_processor_t global_processor_handle = AUDIO_INVALID_HANDLE;
static int global_processor_alias = 0;
static int global_processor_ref_count = 0;
static os_mutex_t global_processor_lock;

pal_soc_info_t audio_soc_info;

audio_available_codecs_t available_codecs[ISMD_AUDIO_MAX_LIBS];
audio_available_codecs_t available_ms10_codecs[ISMD_AUDIO_MAX_LIBS];
audio_available_codecs_t available_dcv_codec;

/**Variable to use when asking platform config for max inputs we should support per processor.*/
int max_num_inputs_per_processor = AUDIO_MAX_INPUTS;


static ismd_audio_power_state_t power_state;
//Should only be called when global processor is locked.
#define ALIAS_GLOBAL_H (global_processor_handle | (global_processor_alias++ << 16))
#define UNALIAS_GLOBAL_H( processor_h) (processor_h & 0xFFFF)
/*********************************************************************************************/


/*********************************************************************************************/
/* Audio Processor Fucntion Implementations  */
/*********************************************************************************************/
ismd_result_t
ismd_audio_open_global_processor(ismd_audio_processor_t *global_processor_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_t handle = AUDIO_INVALID_HANDLE;
   

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   os_mutex_lock(&global_processor_lock);

   /*If our global handle has already been allocated, just return the handle, else init the global processor*/
   if (global_processor_handle != AUDIO_INVALID_HANDLE) {

      result = ISMD_SUCCESS;
   }
   else if ((result = ismd_audio_open_processor(&handle)) == ISMD_SUCCESS) {
   
      global_processor_handle = handle;
      processor_context[handle].is_global_processor = true;
   }

   if(result == ISMD_SUCCESS) {
      
      global_processor_ref_count++;
      *global_processor_h = ALIAS_GLOBAL_H;
   }
   

   os_mutex_unlock(&global_processor_lock);

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

/* Audio Processor APIs */
ismd_result_t
ismd_audio_open_processor(ismd_audio_processor_t *processor_h)
{
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;
   ismd_audio_processor_t handle = AUDIO_INVALID_HANDLE;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   *processor_h = AUDIO_INVALID_HANDLE;

   /*Check for an available processor instance, and return the handle.*/
   for (handle=0; handle < AUDIO_MAX_PROCESSORS; handle++) {

      wl = &(processor_context[handle]);

      audio_processor_lock( wl );

      if (!wl->in_use) {

         if ( (result = ismd_event_alloc(&(wl->input_port_event))) != ISMD_SUCCESS ) {
            AUDIO_ERROR("ismd_event_alloc failed on input event.", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         else if((result = audio_timing_control_open(&(wl->atc_h), handle)) != ISMD_SUCCESS){
            AUDIO_ERROR("aud_timing_control_open failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         else if((result = audio_timing_control_set_output_queue_lock(wl->atc_h, &wl->atc_psm_queue_lock)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_timing_control_set_output_queue_lock failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         else if((result = audio_pvt_processor_psm_pipe_init(wl)) != ISMD_SUCCESS) {
            AUDIO_ERROR("processor_psm_pipe_init failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         //Allocate all the stage parameter buffers needed for each post ATC pipe stage.
         else if((result = audio_pvt_alloc_stage_param_buffer(&wl->psm_pa_pipe)) != ISMD_SUCCESS) {
            AUDIO_ERROR("alloc_stage_param_buffer failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         else if(create_prioritized_thread(&(wl->input_port_manager_thread), audio_input_port_manager_thread, (void *) wl, 0, "Audio_Input") != OSAL_SUCCESS){
            result = ISMD_ERROR_NO_RESOURCES;
            AUDIO_ERROR("create_prioritized_thread failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         else{
            
            wl->in_use = true;
            wl->is_global_processor = false;
            wl->handle_id = handle;
            wl->atc_timer_clock_h = audio_timing_control_get_timer_clock();
            /*Fill in the handle for the caller*/
            *processor_h = handle;
         }

        /*Avoided using break in loop*/
        handle = AUDIO_MAX_PROCESSORS;
      }

      audio_processor_unlock(wl);

   }

   if(result != ISMD_SUCCESS && (*processor_h != AUDIO_INVALID_HANDLE)) {

      ismd_event_free(wl->input_port_event);
      audio_timing_control_close(wl->atc_h);
      audio_psm_pipe_free(wl->psm_pa_pipe.pipe_h);
     // ismd_audio_psm_close(wl->psm_h);
   }

   if(*processor_h == AUDIO_INVALID_HANDLE){

      result = ISMD_ERROR_NO_RESOURCES;
      AUDIO_ERROR("No processor instances available!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t ismd_audio_config_processor_to_ms10_compatible(ismd_audio_processor_t processor_h, bool enable)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   
   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS){

      if (wl->input_count != 0 || wl->output_count != 0) {
         AUDIO_ERROR("Error to config processor with input/output associated.", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         wl->process_mode = (enable) ? AUDIO_PROCESS_MODE_MS10 : AUDIO_PROCESS_MODE_NORMAL;
         result = ISMD_SUCCESS;
      }
      
      audio_processor_unlock(wl);
      
   }else{
      AUDIO_ERROR("Error getting processor workload.", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


ismd_result_t
ismd_audio_close_processor(ismd_audio_processor_t processor_h)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;

   ismd_connection_unregister(ismd_audio_close_processor_callback, (void*)processor_h);

   if ((result = ismd_audio_do_close_processor(processor_h)) != ISMD_SUCCESS){
      AUDIO_ERROR("do_close_processor failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}

ismd_result_t
ismd_audio_do_close_processor(ismd_audio_processor_t processor_h)
{
   int handle = 0;
   int max_loops = 0;
   bool close_processor = true;
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS){

      /*
         At a minimum, we could keep track of the number of apps that currently have a handle to
         the global processor by incrementing a counter on open and decrementing on close, but this
         is only a partial solution because an app may attempt to close a processor more than once.
         We probably need to return a unique handle for each global processor open and alias those
         handles to the real global processor.
      */

      if(wl->is_global_processor) {

         if((--global_processor_ref_count) != 0) {
            close_processor = false;
         }
         else {
            global_processor_handle = AUDIO_INVALID_HANDLE;
         }
      }

      if(close_processor) {
         
         max_loops = (AUDIO_MAX_INPUTS > AUDIO_MAX_OUTPUTS) ? AUDIO_MAX_INPUTS : AUDIO_MAX_OUTPUTS;

         /*Remove the inputs and outputs*/
         for(handle = 0; handle < max_loops; handle++){

            if(handle < AUDIO_MAX_INPUTS){
               /*No need to lock the input because to add you need the processor lock.*/
               if(wl->inputs[handle].in_use){
                  result = audio_remove_input_no_reconfig(processor_h, wl->inputs[handle].smd_dev_h);
                  if(result != ISMD_SUCCESS){
                     AUDIO_ERROR("audio_pvt_remove_input failed!", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
            }
            if(handle < AUDIO_MAX_OUTPUTS){
               /*No need to lock the output because to add you need the processor lock.*/
               if(wl->outputs[handle].in_use){
                  result = audio_remove_output_no_reconfig(&wl->outputs[handle]);
                  if(result != ISMD_SUCCESS){
                     AUDIO_ERROR("audio_pvt_remove_output failed!", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
            }
         }//End for loop

         /*Kill the main thread and clean up resources.*/
         wl->start_to_close = true;

         if((result = ismd_event_strobe(wl->input_port_event)) != ISMD_SUCCESS) {

            AUDIO_ERROR("ismd_event_strobe failed input_port_event!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         if(os_thread_wait(&(wl->input_port_manager_thread),1) != OSAL_SUCCESS) {

            AUDIO_OSAL_ERROR("os_thread_wait failed !", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         if(os_thread_destroy(&(wl->input_port_manager_thread)) != OSAL_SUCCESS) {

            AUDIO_OSAL_ERROR("os_thread_destroy failed !", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         if((result = audio_timing_control_close(wl->atc_h))  != ISMD_SUCCESS){

            AUDIO_ERROR("audio_timing_control_close failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         if((result = audio_psm_pipe_free(wl->psm_pa_pipe.pipe_h))  != ISMD_SUCCESS){

            AUDIO_ERROR("audio_psm_pipe_free failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         if ( (result = ismd_event_free(wl->input_port_event)) != ISMD_SUCCESS ) {
            AUDIO_ERROR("ismd_event_free failed on input event.", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         audio_pvt_free_stage_param_buffer(&(wl->psm_pa_pipe));
         
         if(wl->clock_sync_h != ISMD_CLOCK_HANDLE_INVALID){ 
            if((result = ismd_clock_sync_close(wl->clock_sync_h)) != ISMD_SUCCESS){
               AUDIO_ERROR("clock_sync_close failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         
          /* Reset the workload context */
          audio_processor_init_wl(wl);
      }

       audio_processor_unlock(wl);

   }else{
      AUDIO_ERROR("Error getting processor workload in close_processor.", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

bool
audio_pvt_available_codec(int codec_id){
   bool result = false; 
   
   if(codec_id < ISMD_AUDIO_MAX_LIBS){

      /* If we want to decode DTS core and we have DTS HD, the codec is available for decode. */
      if((codec_id == ISMD_AUDIO_MEDIA_FMT_DTS) && available_codecs[ISMD_AUDIO_MEDIA_FMT_DTS_HD].availability){
         result = true;
      }
      else {
         result = available_codecs[codec_id].availability;
      }
      
      return result;   
   }

   return (false);
}

ismd_result_t
ismd_audio_codec_available(ismd_audio_format_t format)
{
   ismd_result_t result = ISMD_ERROR_NOT_FOUND;

   if(audio_pvt_available_codec(format) == true ) {
      result = ISMD_SUCCESS;
   }
   return result;
}

bool
audio_pvt_available_ms10_codec(int codec_id)
{
   if(codec_id < ISMD_AUDIO_MAX_LIBS){
      return available_ms10_codecs[codec_id].availability;
   }

   return (false);

}

ismd_result_t
ismd_audio_ms10_codec_available(ismd_audio_format_t format)
{
   ismd_result_t result = ISMD_ERROR_NOT_FOUND;

   if(audio_pvt_available_ms10_codec(format) == true ) {
      result = ISMD_SUCCESS;
   }
   return result;
}

ismd_result_t
ismd_audio_set_render_period(ismd_audio_processor_t processor_h, int render_period_ms)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   result = audio_processor_lock_and_get_wl(processor_h, &wl);

   if(result == ISMD_SUCCESS) {

      // check weather it is safe to change the chunksize
      if (wl->input_count != 0 || wl->output_count != 0) {
         result = ISMD_ERROR_OPERATION_FAILED;
         AUDIO_ERROR("ismd_audio_set_render_period change chunk size failed, make sure you do not have any inputs and outputs added.", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if (render_period_ms != 10 && render_period_ms != 5) {
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("ismd_audio_set_render_period change chunk size failed, only accept 10ms or 5ms chunksize now.", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         /* NOTE:
          * we will not change the clock alarm period now. 
          * We will change the clock alarm period at the time we add atc stream, 
          * because only that time we know weather the processor accetp this chunksize or not.
          */
         wl->chunk_size_period = render_period_ms;
      }
      
      audio_processor_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
      
   return result;
}

ismd_result_t
ismd_audio_get_render_period(ismd_audio_processor_t processor_h, int* render_period_ms)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   result = audio_processor_lock_and_get_wl(processor_h, &wl);

   if(result == ISMD_SUCCESS) {
      if (render_period_ms == NULL) {
         AUDIO_ERROR("ismd_audio_get_render_period change chunk size failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         result = ISMD_ERROR_NULL_POINTER;
      }
      else {
         *render_period_ms = wl->chunk_size_period;
      }

      audio_processor_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
      
   return result;
}


ismd_result_t
ismd_audio_set_master_volume(ismd_audio_processor_t processor_h, int master_volume)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;
   int i = 0;
   int volume = 0;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   result = audio_processor_lock_and_get_wl(processor_h, &wl);

   if(result == ISMD_SUCCESS) {

      if (wl->muted){
         wl->master_volume_enable = true;
         wl->master_volume = ENSURE_VALID_GAIN(master_volume);
         for (i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++)
         {
            if(wl->per_channel_volume_enable){
               volume = ENSURE_VALID_GAIN(wl->master_volume + wl->per_channel_volume[i]);
            }
            else {
               volume = wl->master_volume;
            }

            result = audio_core_user_gain_to_coeff_index(volume, &(wl->post_mix_ch_gain[i]));
         }
      }
      else {

         if(result == ISMD_SUCCESS){
            wl->master_volume_enable = true;
         
            wl->master_volume = ENSURE_VALID_GAIN(master_volume);
         
            for (i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++)
            {
               if(wl->per_channel_volume_enable){
                  volume = ENSURE_VALID_GAIN(wl->master_volume + wl->per_channel_volume[i]);
               }
               else {
                  volume = wl->master_volume;
               }

               result = audio_core_user_gain_to_coeff_index(volume, &(wl->post_mix_ch_gain[i]));
               wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains[i] = wl->post_mix_ch_gain[i]; 
            }
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains_id = 0x76543210;
            
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.coeff_changed++;
         }
      
         if ( wl->psm_pa_pipe.pipe_configured ) {
            /* Commit the changes to the post-processing pipe. */
            result = audio_psm_stage_config_direct( wl->psm_pa_pipe.pipe_h, 
                                             wl->psm_pa_pipe.stages[MIXER_STAGE].handle, 
                                             &(wl->psm_pa_pipe.stages[MIXER_STAGE].params) );
            if ( result != ISMD_SUCCESS ) {
               AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }
      audio_processor_unlock(wl);
   }
   else {

      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_get_master_volume(ismd_audio_processor_t processor_h, int *master_volume)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(master_volume == NULL) {
      result = ISMD_ERROR_NULL_POINTER;
   }
   else {

         if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

            *master_volume = wl->master_volume;

            audio_processor_unlock(wl);

         } else {

            AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_disable_master_volume(ismd_audio_processor_t processor_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;
   int i = 0;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   result = audio_processor_lock_and_get_wl(processor_h, &wl);
   
   if (result == ISMD_SUCCESS) {
      if (wl->muted){
         wl->master_volume_enable = false;
         for ( i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++ ) {

            if(wl->per_channel_volume_enable){
               result = audio_core_user_gain_to_coeff_index(wl->per_channel_volume[i], &(wl->post_mix_ch_gain[i]));
            }
            else {
               wl->post_mix_ch_gain[i] = MIX_COEFF_INDEX_0_DB;
            }
         }
      }
      else {
         if(result == ISMD_SUCCESS) {  
            wl->master_volume_enable = false;
  
            for ( i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++ ) {
          
               if(wl->per_channel_volume_enable){
                  result = audio_core_user_gain_to_coeff_index(wl->per_channel_volume[i], &(wl->post_mix_ch_gain[i]));
                  wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains[i] = wl->post_mix_ch_gain[i];
               }
               else {
                  wl->post_mix_ch_gain[i] = MIX_COEFF_INDEX_0_DB;
                  wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains[i] = wl->post_mix_ch_gain[i];
               }
            }
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains_id = 0x76543210;
            
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.coeff_changed++;
            
            /* Commit changes if the pipe is up and runing.*/
            if ( wl->psm_pa_pipe.pipe_configured ) {
               result = audio_psm_stage_config_direct( wl->psm_pa_pipe.pipe_h, 
                                                wl->psm_pa_pipe.stages[MIXER_STAGE].handle, 
                                                &(wl->psm_pa_pipe.stages[MIXER_STAGE].params) );
               if ( result != ISMD_SUCCESS ) {
                  AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
         }
      }
      audio_processor_unlock(wl);
   } else {

      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_mute(ismd_audio_processor_t processor_h, bool mute)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;
   int i = 0; 
   bool update_stage = false;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      //check to see if we have even setup the back end pipe, if not just record state.
      if(wl->psm_pa_pipe.pipe_configured){

         //Already muted.
         if(wl->muted && mute){
            result = ISMD_SUCCESS;
         }

         //Already not muted.
         else if(!wl->muted && !mute) {
            result = ISMD_SUCCESS;
         }

         //Not muted need to mute.
         else if(!wl->muted && mute) {
               
            for ( i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++ ) {
               wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains[i] = MIX_COEFF_INDEX_MUTE;
            }
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.use_stream_metadata = false;

            //Need to flag that we have changed the mixer coefficients for ramping down to a mute. 
            //This flag will get cleared down in the mixer after the ramp has occured. 
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.coeff_changed++;

            update_stage = true;

            //If this stream has a passthrough stream, disable it at the ATC. 
            for(i = 0; i < AUDIO_MAX_INPUTS; i++) {
                         
               if((wl->inputs[i].in_use) && (wl->inputs[i].pass_atc_stream_h != AUDIO_INVALID_HANDLE)) {
               
                  audio_timing_control_disable_stream(wl->atc_h, wl->inputs[i].pass_atc_stream_h);
               }
            }
         }

         //Muted and need to un-mute
         else if(wl->muted && !mute) { 

            for ( i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++ ) {
               wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains[i] = wl->post_mix_ch_gain[i];
            }
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains_id = 0x76543210;
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.use_stream_metadata = USE_STREAM_METADATA;

            //Need to flag that we have changed the mixer coefficients for ramping down to a mute. 
            //This flag will get cleared down in the mixer after the ramp has occured.
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.coeff_changed++;

            update_stage = true;

            //If this stream has a passthrough stream, enable it at the ATC.
            for(i = 0; i < AUDIO_MAX_INPUTS; i++) {

               if((wl->inputs[i].in_use) && (wl->inputs[i].pass_atc_stream_h != AUDIO_INVALID_HANDLE)) {
                  audio_timing_control_enable_stream(wl->atc_h, wl->inputs[i].pass_atc_stream_h);
               } 
            }
         }

         /*Update the PSM pipe if needed.*/
         if(update_stage){
            if((result = audio_psm_stage_config_direct(wl->psm_pa_pipe.pipe_h, wl->psm_pa_pipe.stages[MIXER_STAGE].handle, 
                               &wl->psm_pa_pipe.stages[MIXER_STAGE].params)) != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_psm_stage_config_direct mixer failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         wl->muted = mute;
      }
      audio_processor_unlock(wl);
   } else {

      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t 
ismd_audio_is_muted( ismd_audio_processor_t processor_h, bool *muted )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t  *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(muted == NULL) {
      result = ISMD_ERROR_NULL_POINTER;
   }
   else {
      result = audio_processor_lock_and_get_wl( processor_h, &wl );
      if (result == ISMD_SUCCESS){

         *muted = wl->muted;
         audio_processor_unlock(wl);
      }
      else {
         AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}

ismd_result_t
ismd_audio_set_per_channel_volume( ismd_audio_processor_t          processor_h, 
                                   ismd_audio_per_channel_volume_t channel_volume )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t  *wl = NULL;
   int i = 0;
   int volume = 0;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   result = audio_processor_lock_and_get_wl( processor_h, &wl );   

   if ( result == ISMD_SUCCESS ) {

      if (wl->muted){
         wl->per_channel_volume_enable = true;

         wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LEFT]           = ENSURE_VALID_GAIN(channel_volume.front_left);
         wl->per_channel_volume[ISMD_AUDIO_CHANNEL_RIGHT]          = ENSURE_VALID_GAIN(channel_volume.front_right);
         wl->per_channel_volume[ISMD_AUDIO_CHANNEL_CENTER]         = ENSURE_VALID_GAIN(channel_volume.center);
         wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LFE]            = ENSURE_VALID_GAIN(channel_volume.lfe);
         wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LEFT_SUR]       = ENSURE_VALID_GAIN(channel_volume.surround_left);
         wl->per_channel_volume[ISMD_AUDIO_CHANNEL_RIGHT_SUR]      = ENSURE_VALID_GAIN(channel_volume.surround_right);
         wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LEFT_REAR_SUR]  = ENSURE_VALID_GAIN(channel_volume.rear_surround_left);
         wl->per_channel_volume[ISMD_AUDIO_CHANNEL_RIGHT_REAR_SUR] = ENSURE_VALID_GAIN(channel_volume.rear_surround_right);
 
         for ( i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++ ) {
            if(wl->master_volume_enable){
               volume = ENSURE_VALID_GAIN(wl->per_channel_volume[i]+wl->master_volume);
            }
            else {
               volume = wl->per_channel_volume[i];
            }
            result = audio_core_user_gain_to_coeff_index(volume, &(wl->post_mix_ch_gain[i]));
         }   
      }
      else {

         if ( result == ISMD_SUCCESS ) {
            wl->per_channel_volume_enable = true;

            wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LEFT]           = ENSURE_VALID_GAIN(channel_volume.front_left);
            wl->per_channel_volume[ISMD_AUDIO_CHANNEL_RIGHT]          = ENSURE_VALID_GAIN(channel_volume.front_right);
            wl->per_channel_volume[ISMD_AUDIO_CHANNEL_CENTER]         = ENSURE_VALID_GAIN(channel_volume.center);
            wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LFE]            = ENSURE_VALID_GAIN(channel_volume.lfe);
            wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LEFT_SUR]       = ENSURE_VALID_GAIN(channel_volume.surround_left);
            wl->per_channel_volume[ISMD_AUDIO_CHANNEL_RIGHT_SUR]      = ENSURE_VALID_GAIN(channel_volume.surround_right);
            wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LEFT_REAR_SUR]  = ENSURE_VALID_GAIN(channel_volume.rear_surround_left);
            wl->per_channel_volume[ISMD_AUDIO_CHANNEL_RIGHT_REAR_SUR] = ENSURE_VALID_GAIN(channel_volume.rear_surround_right);

            for ( i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++ ) {
               if(wl->master_volume_enable){
                  volume = ENSURE_VALID_GAIN(wl->per_channel_volume[i]+wl->master_volume);
               }
               else {
                  volume = wl->per_channel_volume[i];
               }      
               result = audio_core_user_gain_to_coeff_index(volume, &(wl->post_mix_ch_gain[i]));

               wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains[i] = wl->post_mix_ch_gain[i];
            }
         
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains_id = 0x76543210;
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.coeff_changed++;

            /*If the PSM pipe is running, update the state.*/
            if ( wl->psm_pa_pipe.pipe_configured ) {
               result = audio_psm_stage_config_direct( wl->psm_pa_pipe.pipe_h, 
                                                wl->psm_pa_pipe.stages[MIXER_STAGE].handle, 
                                                &(wl->psm_pa_pipe.stages[MIXER_STAGE].params) );
               if ( result != ISMD_SUCCESS ) {
                  AUDIO_ERROR("audio_psm_stage_config_direct failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
         }
      }
      audio_processor_unlock( wl );
   }
   else {
      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
 
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}


ismd_result_t 
ismd_audio_enable_mix_metadata( ismd_audio_processor_t processor_h, 
                                bool                   enable )
{
   ismd_result_t                   result     = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl         = NULL;
   audio_mixer_params_t           *mix_params = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   result = audio_processor_lock_and_get_wl( processor_h, &wl );
   if ( result == ISMD_SUCCESS ) {
      
      mix_params = &(wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer);

      if ( enable ) {
         mix_params->host.mixer.use_stream_metadata = true;
         result = ISMD_SUCCESS;
      }
      else {
         mix_params->host.mixer.use_stream_metadata = false;
         result = ISMD_SUCCESS;
         mix_params->host.mixer.coeff_changed++;
      }

      /*If the PSM pipe is running, update the state.*/
      if ( wl->psm_pa_pipe.pipe_configured ) {
         /* Commit the changes to the post-processing pipe. */
         result = audio_psm_stage_config_direct( wl->psm_pa_pipe.pipe_h, 
                                          wl->psm_pa_pipe.stages[MIXER_STAGE].handle, 
                                          &wl->psm_pa_pipe.stages[MIXER_STAGE].params );
         if ( result != ISMD_SUCCESS) {
            AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
      audio_processor_unlock( wl );
   }
   else {
      AUDIO_ERROR("processor_lock_and_get_wl failed.", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}

ismd_result_t
ismd_audio_set_mixing_sample_rate( ismd_audio_processor_t processor_h, 
                                ismd_audio_mix_sample_rate_mode_t sample_rate_mode,
                                int sample_rate)
{
   ismd_result_t                   result     = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl         = NULL;
   int i = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if ((result = audio_processor_lock_and_get_wl( processor_h, &wl )) == ISMD_SUCCESS ) {

      switch(sample_rate_mode){
         case ISMD_AUDIO_MIX_SAMPLE_RATE_MODE_AUTO:
         case ISMD_AUDIO_MIX_SAMPLE_RATE_MODE_PRIMARY:
            break;
         case ISMD_AUDIO_MIX_SAMPLE_RATE_MODE_FIXED:
            if(!audio_core_is_valid_sample_rate(sample_rate)){
               result = ISMD_ERROR_INVALID_PARAMETER;
            }
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;     
      }

      if(result == ISMD_SUCCESS) {

         /* Set new SRC mode only on pre mixer SRC, post mixer SRC should NOT be set with this mode.  */
         wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.mix_src_mode = sample_rate_mode;

         /* If its a fixed mode, set the output sampling rate to the fixed sampling rate. */
         if(sample_rate_mode == ISMD_AUDIO_MIX_SAMPLE_RATE_MODE_FIXED) { 
            for(i = 0; i < AUDIO_MAX_INPUTS; i++){
               wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.output_sample_rate[i] = sample_rate;
            }
         }

          /* Commit the changes back to the mixer if the post ATC pipe is running. */
         if ( wl->psm_pa_pipe.pipe_configured ) {       
            result = audio_psm_stage_config_direct( wl->psm_pa_pipe.pipe_h, 
                                             wl->psm_pa_pipe.stages[SRC_STAGE].handle, 
                                             &wl->psm_pa_pipe.stages[SRC_STAGE].params );
            if ( result != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_psm_stage_config for the SRC failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }

      audio_processor_unlock( wl );

   }
   else {
      AUDIO_ERROR("processor_lock_and_get_wl failed.", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}

ismd_result_t
audio_get_mixing_sample_rate( ismd_audio_processor_context_t *wl, 
                                                int mixer_input_index,
                                                ismd_audio_mix_sample_rate_mode_t *sample_rate_mode,
                                                int *sample_rate)
{
   ismd_result_t  result = ISMD_SUCCESS;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /* First get the current state of the SRC parameters if its already running. */
   if (( wl->psm_pa_pipe.pipe_configured ) && (wl->psm_pa_pipe.stages[SRC_STAGE].handle != AUDIO_INVALID_HANDLE)){
      if((result = audio_psm_stage_get_config(wl->psm_pa_pipe.pipe_h, 
                          wl->psm_pa_pipe.stages[SRC_STAGE].handle, 
                          &wl->psm_pa_pipe.stages[SRC_STAGE].params)) != ISMD_SUCCESS) {

         AUDIO_ERROR("audio_psm_stage_get_config  for the SRC stage failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   /*Since we are just reading, ok to read from DSP parameters side.*/
   *sample_rate_mode = wl->psm_pa_pipe.stages[SRC_STAGE].params.src.dsp.mix_src_mode; 
   *sample_rate = wl->psm_pa_pipe.stages[SRC_STAGE].params.src.dsp.output_sample_rate[mixer_input_index];

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}


ismd_result_t
ismd_audio_set_mixing_channel_config( ismd_audio_processor_t processor_h, 
                                ismd_audio_mix_ch_cfg_mode_t ch_cfg_mode,
                                int ch_cfg)
{
   ismd_result_t                   result     = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl         = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if ((result = audio_processor_lock_and_get_wl( processor_h, &wl )) == ISMD_SUCCESS ) {

      switch(ch_cfg_mode){
         case ISMD_AUDIO_MIX_CH_CFG_MODE_AUTO:
         case ISMD_AUDIO_MIX_CH_CFG_MODE_PRIMARY:
            break;
         case ISMD_AUDIO_MIX_CH_CFG_MODE_FIXED:
            if(!audio_core_is_valid_ch_config(ch_cfg)){
               result = ISMD_ERROR_INVALID_PARAMETER;
            }
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;     
      }

      if(result == ISMD_SUCCESS) {

         /* Set mode and a default invalid channel config */
         wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.ch_config_mode = ch_cfg_mode;
         wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.ch_config_mode_fixed_ch_cfg = 0xFFFFFFFF;

         /* If we are in fixed mode, then set channel config. */
         if(ch_cfg_mode == ISMD_AUDIO_MIX_CH_CFG_MODE_FIXED){
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.ch_config_mode_fixed_ch_cfg = ch_cfg;
         }

          /* Commit the changes back to the mixer if the post ATC pipe is running. */
         if ( wl->psm_pa_pipe.pipe_configured ) {       
            result = audio_psm_stage_config_direct( wl->psm_pa_pipe.pipe_h, 
                                             wl->psm_pa_pipe.stages[MIXER_STAGE].handle, 
                                             &wl->psm_pa_pipe.stages[MIXER_STAGE].params );
            if ( result != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_psm_stage_config_direct for the mixer failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }
      audio_processor_unlock( wl );
   }
   else {
      AUDIO_ERROR("processor_lock_and_get_wl failed.", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}


ismd_result_t
ismd_audio_get_per_channel_volume(ismd_audio_processor_t processor_h,
                            ismd_audio_per_channel_volume_t *channel_volume)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(channel_volume == NULL) {
   
      result = ISMD_ERROR_NULL_POINTER;
   }
   else {
      
         if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {
            channel_volume->front_left          = wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LEFT];
            channel_volume->front_right         = wl->per_channel_volume[ISMD_AUDIO_CHANNEL_RIGHT];
            channel_volume->center              = wl->per_channel_volume[ISMD_AUDIO_CHANNEL_CENTER];
            channel_volume->lfe                 = wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LFE];
            channel_volume->surround_left       = wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LEFT_SUR];
            channel_volume->surround_right      = wl->per_channel_volume[ISMD_AUDIO_CHANNEL_RIGHT_SUR];
            channel_volume->rear_surround_left  = wl->per_channel_volume[ISMD_AUDIO_CHANNEL_LEFT_REAR_SUR];
            channel_volume->rear_surround_right = wl->per_channel_volume[ISMD_AUDIO_CHANNEL_RIGHT_REAR_SUR];

            audio_processor_unlock(wl);

         } else {

            AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
   } 
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_disable_per_channel_volume(ismd_audio_processor_t processor_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;
   int32_t volume = 0;
   int i = 0;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   
   result = audio_processor_lock_and_get_wl(processor_h, &wl);

   if(result == ISMD_SUCCESS) {
      if (wl->muted) {
         wl->per_channel_volume_enable = false;
         if (wl->master_volume_enable){
            result = audio_core_user_gain_to_coeff_index(wl->master_volume, &volume);
         }
         else {
            volume = MIX_COEFF_INDEX_0_DB;
         }

         for ( i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++ ) {
            wl->post_mix_ch_gain[i] = volume;
         }
      }
      else {
         wl->per_channel_volume_enable = false;
     
         if (wl->master_volume_enable){
            result = audio_core_user_gain_to_coeff_index(wl->master_volume, &volume);
         }
         else {
            volume = MIX_COEFF_INDEX_0_DB;
         }

         if(result ==ISMD_SUCCESS) {
            
            for ( i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++ ) {
               wl->post_mix_ch_gain[i] = volume;
               wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains[i] = wl->post_mix_ch_gain[i];
            }
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains_id = 0x76543210;
            wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.coeff_changed++;

            /* If the post-processing pipe is running ... */
            if ( wl->psm_pa_pipe.pipe_configured ) {
                     /* Commit the changes to the post-processing pipe. */
               result = audio_psm_stage_config_direct( wl->psm_pa_pipe.pipe_h, 
                                                wl->psm_pa_pipe.stages[MIXER_STAGE].handle, 
                                                &(wl->psm_pa_pipe.stages[MIXER_STAGE].params) );
               if ( result != ISMD_SUCCESS ) {
                  AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
         }
      }
      audio_processor_unlock(wl);
   }
   else {
      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_set_bass_management(ismd_audio_processor_t processor_h,
                              ismd_audio_crossover_freq_t crossover_freq,
                              ismd_audio_per_speaker_setting_t speaker_settings)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      //Only support 80Hz right now.
      if(crossover_freq == ISMD_AUDIO_CROSSOVER_FREQ_80HZ) {

         /* First read the stage config from PSM, modify, then write it back to the PSM*/
         if(wl->psm_pa_pipe.pipe_configured) {
            if((result = audio_psm_stage_get_config(wl->psm_pa_pipe.pipe_h, 
                                wl->psm_pa_pipe.stages[BASS_MAN_STAGE].handle, 
                                &wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params)) != ISMD_SUCCESS) {

               AUDIO_ERROR("audio_psm_stage_get_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }

         wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params.bass_man.crossover_freq = crossover_freq;
         wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params.bass_man.speaker_settings = speaker_settings;
         wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params.bass_man.enabled = true;

         /* Send changes down the psm only if we have already configured the back end pipe*/
         if(wl->psm_pa_pipe.pipe_configured) {
            
            if((result = audio_psm_stage_config(wl->psm_pa_pipe.pipe_h, 
                                wl->psm_pa_pipe.stages[BASS_MAN_STAGE].handle, 
                                &wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params)) != ISMD_SUCCESS) {

               AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }
      else {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         AUDIO_ERROR("Bass managment currently only supports 80Hz!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      audio_processor_unlock(wl);
   } else {

      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_get_bass_management(ismd_audio_processor_t processor_h,
                              ismd_audio_crossover_freq_t *crossover_freq,
                              ismd_audio_per_speaker_setting_t *speaker_settings)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      //Check to see if bass management is even enabled. 
      if(wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params.bass_man.enabled) {

         *crossover_freq = wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params.bass_man.crossover_freq;
         *speaker_settings = wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params.bass_man.speaker_settings;
      }
      else {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("Bass Management has not been enabled. Call ismd_audio_set_bass_management to enable.", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      audio_processor_unlock(wl);
   } else {

      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_disable_bass_management(ismd_audio_processor_t processor_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      /* If the POST ATC pipe had be configured read the stage config 
         from PSM, modify, then write it back to the PSM*/
      if(wl->psm_pa_pipe.pipe_configured) {
         if((result = audio_psm_stage_get_config(wl->psm_pa_pipe.pipe_h, 
                             wl->psm_pa_pipe.stages[BASS_MAN_STAGE].handle, 
                             &wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params)) != ISMD_SUCCESS) {

            AUDIO_ERROR("audio_psm_stage_get_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
      
      //Only do anything if its actually enabled. 
      if(wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params.bass_man.enabled && (result == ISMD_SUCCESS)) {
         
         wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params.bass_man.crossover_freq = 0;
         wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params.bass_man.enabled = false;

         /* Send changes down the psm only if we have already configured the back end pipe*/
         if(wl->psm_pa_pipe.pipe_configured) {
            
            if((result = audio_psm_stage_config(wl->psm_pa_pipe.pipe_h, 
                                wl->psm_pa_pipe.stages[BASS_MAN_STAGE].handle, 
                                &wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params)) != ISMD_SUCCESS) {

               AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }

      audio_processor_unlock(wl);
   } else {

      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_set_per_channel_delay(ismd_audio_processor_t processor_h,
                              ismd_audio_per_channel_delay_t channel_delay)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = NULL;
   int *per_channel_delay = NULL;
   bool delay_change = false;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   
   if( channel_delay.front_left > ISMD_AUDIO_PER_CHANNEL_MAX_DELAY_MS         || channel_delay.front_right > ISMD_AUDIO_PER_CHANNEL_MAX_DELAY_MS
     ||channel_delay.center > ISMD_AUDIO_PER_CHANNEL_MAX_DELAY_MS             || channel_delay.lfe > ISMD_AUDIO_PER_CHANNEL_MAX_DELAY_MS
     ||channel_delay.surround_left > ISMD_AUDIO_PER_CHANNEL_MAX_DELAY_MS      || channel_delay.surround_right > ISMD_AUDIO_PER_CHANNEL_MAX_DELAY_MS
     ||channel_delay.rear_surround_left > ISMD_AUDIO_PER_CHANNEL_MAX_DELAY_MS || channel_delay.rear_surround_right > ISMD_AUDIO_PER_CHANNEL_MAX_DELAY_MS){

      result = ISMD_ERROR_INVALID_PARAMETER;

   }
   else if(channel_delay.front_left < ISMD_AUDIO_PER_CHANNEL_MIN_DELAY_MS     || channel_delay.front_right < ISMD_AUDIO_PER_CHANNEL_MIN_DELAY_MS
     ||channel_delay.center < ISMD_AUDIO_PER_CHANNEL_MIN_DELAY_MS             || channel_delay.lfe < ISMD_AUDIO_PER_CHANNEL_MIN_DELAY_MS
     ||channel_delay.surround_left < ISMD_AUDIO_PER_CHANNEL_MIN_DELAY_MS      || channel_delay.surround_right < ISMD_AUDIO_PER_CHANNEL_MIN_DELAY_MS
     ||channel_delay.rear_surround_left < ISMD_AUDIO_PER_CHANNEL_MIN_DELAY_MS || channel_delay.rear_surround_right < ISMD_AUDIO_PER_CHANNEL_MIN_DELAY_MS){

      result = ISMD_ERROR_INVALID_PARAMETER;
   }

   if(result == ISMD_SUCCESS){
      if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

         if(wl->psm_pa_pipe.pipe_configured) {
            if((result = audio_psm_stage_get_config(wl->psm_pa_pipe.pipe_h,
                            wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].handle,
                            &wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params)) != ISMD_SUCCESS) {

               AUDIO_ERROR("audio_psm_stage_get_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         
         per_channel_delay = &(wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params.delay_mgmt.per_channel_delay[0]);
         
         if(per_channel_delay[ISMD_AUDIO_CHANNEL_LEFT] != channel_delay.front_left) {
            per_channel_delay[ISMD_AUDIO_CHANNEL_LEFT] = channel_delay.front_left;
            delay_change = true;
         } 
         if(per_channel_delay[ISMD_AUDIO_CHANNEL_RIGHT] != channel_delay.front_right) {
            per_channel_delay[ISMD_AUDIO_CHANNEL_RIGHT] = channel_delay.front_right;
            delay_change = true;
         } 
         if(per_channel_delay[ISMD_AUDIO_CHANNEL_CENTER] != channel_delay.center) {
            per_channel_delay[ISMD_AUDIO_CHANNEL_CENTER] = channel_delay.center;
            delay_change = true;
         } 
         if(per_channel_delay[ISMD_AUDIO_CHANNEL_LFE] != channel_delay.lfe) {
            per_channel_delay[ISMD_AUDIO_CHANNEL_LFE] = channel_delay.lfe;
            delay_change = true;
         }
         if(per_channel_delay[ISMD_AUDIO_CHANNEL_LEFT_SUR] != channel_delay.surround_left) {
            per_channel_delay[ISMD_AUDIO_CHANNEL_LEFT_SUR] = channel_delay.surround_left;
            delay_change = true;
         } 
         if(per_channel_delay[ISMD_AUDIO_CHANNEL_RIGHT_SUR] != channel_delay.surround_right) {
            per_channel_delay[ISMD_AUDIO_CHANNEL_RIGHT_SUR] = channel_delay.surround_right;
            delay_change = true;
         }
         if(per_channel_delay[ISMD_AUDIO_CHANNEL_LEFT_REAR_SUR] != channel_delay.rear_surround_left) {
            per_channel_delay[ISMD_AUDIO_CHANNEL_LEFT_REAR_SUR] = channel_delay.rear_surround_left;
            delay_change = true;
         }
         if(per_channel_delay[ISMD_AUDIO_CHANNEL_RIGHT_REAR_SUR] != channel_delay.rear_surround_right) {
            per_channel_delay[ISMD_AUDIO_CHANNEL_RIGHT_REAR_SUR] = channel_delay.rear_surround_right;
            delay_change = true;
         }

         if(delay_change){
            wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params.delay_mgmt.delay_change = true;
         }

         wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params.delay_mgmt.enabled = true;

         /* Send changes down the psm only if we have already configured the back end pipe*/
         if(wl->psm_pa_pipe.pipe_configured && delay_change) {

            if((result = audio_psm_stage_config(wl->psm_pa_pipe.pipe_h,
                            wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].handle,
                            &wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params)) != ISMD_SUCCESS) {

               AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }

         audio_processor_unlock(wl);
      } else {

         AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_get_per_channel_delay(ismd_audio_processor_t processor_h,
                              ismd_audio_per_channel_delay_t *channel_delay)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;
   int *per_channel_delay = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   if(channel_delay == NULL) {
      result = ISMD_ERROR_NULL_POINTER;
   }
   else {
      if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

         //     Check to see if bass management is even enabled.
         if(wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params.delay_mgmt.enabled) {

            per_channel_delay = &(wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params.delay_mgmt.per_channel_delay[0]);

            channel_delay->front_left          = per_channel_delay[ISMD_AUDIO_CHANNEL_LEFT];
            channel_delay->front_right         = per_channel_delay[ISMD_AUDIO_CHANNEL_RIGHT];
            channel_delay->center              = per_channel_delay[ISMD_AUDIO_CHANNEL_CENTER];
            channel_delay->lfe                 = per_channel_delay[ISMD_AUDIO_CHANNEL_LFE];
            channel_delay->surround_left       = per_channel_delay[ISMD_AUDIO_CHANNEL_LEFT_SUR];
            channel_delay->surround_right      = per_channel_delay[ISMD_AUDIO_CHANNEL_RIGHT_SUR];
            channel_delay->rear_surround_left  = per_channel_delay[ISMD_AUDIO_CHANNEL_LEFT_REAR_SUR];
            channel_delay->rear_surround_right = per_channel_delay[ISMD_AUDIO_CHANNEL_RIGHT_REAR_SUR];

         }
         else {
            result = ISMD_ERROR_INVALID_REQUEST;
            AUDIO_ERROR("Delay Management has not been enabled. Call ismd_audio_set_per_channel_delay to enable.", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         audio_processor_unlock(wl);
      } else {

      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;

}


ismd_result_t
ismd_audio_disable_per_channel_delay(ismd_audio_processor_t processor_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      if(wl->psm_pa_pipe.pipe_configured) {
         if((result = audio_psm_stage_get_config(wl->psm_pa_pipe.pipe_h,
                             wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].handle,
                             &wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params)) != ISMD_SUCCESS) {

            AUDIO_ERROR("audio_psm_stage_get_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      //Only do anything if its actually enabled.
      if(wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params.delay_mgmt.enabled && (result == ISMD_SUCCESS)) {

         wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params.delay_mgmt.enabled = false;

         /* Send changes down the psm only if we have already configured the back end pipe*/
         if(wl->psm_pa_pipe.pipe_configured) {

            if((result = audio_psm_stage_config(wl->psm_pa_pipe.pipe_h,
                                wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].handle,
                                &wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params)) != ISMD_SUCCESS) {

               AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }

      audio_processor_unlock(wl);
   } else {

      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_enable_watermark_detection(ismd_audio_processor_t processor_h, audio_wm_params_block_t audio_wm_params)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = NULL;
   audio_watermark_management_params_t *watermark_stage_params_ptr;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   
   if((audio_wm_params.len <= AUDIO_WM_MAX_PARAM_BLOCK_SIZE)&&(audio_wm_params.offset < AUDIO_WM_MAX_PARAMS_LEN)){
      if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {
         if(wl->psm_pa_pipe.pipe_configured) {
            if((result = audio_psm_stage_get_config(wl->psm_pa_pipe.pipe_h,
                            wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle,
                            &wl->psm_pa_pipe.stages[WATERMARK_STAGE].params)) != ISMD_SUCCESS) {
         
               AUDIO_ERROR("audio_psm_stage_get_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         
         watermark_stage_params_ptr = &(wl->psm_pa_pipe.stages[WATERMARK_STAGE].params.watermark);
         if(watermark_stage_params_ptr->enabled == false){
            watermark_stage_params_ptr->enabled = true;
            OS_MEMCPY((unsigned char *)(watermark_stage_params_ptr->params + audio_wm_params.offset), (unsigned char *)&(audio_wm_params.params[0]), audio_wm_params.len);        

            /* Send changes down the psm only if we have already configured the back end pipe*/
            if((wl->psm_pa_pipe.pipe_configured) && (result == ISMD_SUCCESS)){
               if((result = audio_psm_stage_config(wl->psm_pa_pipe.pipe_h,
                               wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle,
                               &wl->psm_pa_pipe.stages[WATERMARK_STAGE].params)) != ISMD_SUCCESS) {
            
                  AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
         }
         audio_processor_unlock(wl);
      } else {

         AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      result = ISMD_ERROR_INVALID_PARAMETER;  
      AUDIO_ERROR("ismd_audio_enable_watermark_detection failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_disable_watermark_detection(ismd_audio_processor_t processor_h, audio_wm_params_block_t *audio_wm_params)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;
   audio_watermark_management_params_t *watermark_stage_params_ptr;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   
   if((audio_wm_params->len <= AUDIO_WM_MAX_PARAM_BLOCK_SIZE)&&(audio_wm_params->offset < AUDIO_WM_MAX_PARAMS_LEN)){

      if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {
         if(wl->psm_pa_pipe.pipe_configured) {
            if((result = audio_psm_stage_get_config(wl->psm_pa_pipe.pipe_h,
                                wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle,
                                &wl->psm_pa_pipe.stages[WATERMARK_STAGE].params)) != ISMD_SUCCESS) {

               AUDIO_ERROR("audio_psm_stage_get_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }

         watermark_stage_params_ptr = &(wl->psm_pa_pipe.stages[WATERMARK_STAGE].params.watermark);

         //Only do anything if its actually enabled.
         if(watermark_stage_params_ptr->enabled && (result == ISMD_SUCCESS)) {
            
            OS_MEMCPY((void *)&(audio_wm_params->params[0]),
                  (void *)(watermark_stage_params_ptr->params + audio_wm_params->offset), 
                  audio_wm_params->len);

            wl->psm_pa_pipe.stages[WATERMARK_STAGE].params.watermark.enabled = false;

            /* Send changes down the psm only if we have already configured the back end pipe*/
            if(wl->psm_pa_pipe.pipe_configured) {

               if((result = audio_psm_stage_config(wl->psm_pa_pipe.pipe_h,
                                   wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle,
                                   &wl->psm_pa_pipe.stages[WATERMARK_STAGE].params)) != ISMD_SUCCESS) {

                  AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
         }
         else {
            result = ISMD_ERROR_OPERATION_FAILED; // stage is already disabled
         }
         
         audio_processor_unlock(wl);
      } else {

         AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      result = ISMD_ERROR_INVALID_PARAMETER;  
      AUDIO_ERROR("ismd_audio_disable_watermark_detection failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_set_watermark_detection(ismd_audio_processor_t processor_h, audio_wm_params_block_t audio_wm_params)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = NULL;
   audio_watermark_management_params_t *watermark_stage_params_ptr;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((audio_wm_params.len <= AUDIO_WM_MAX_PARAM_BLOCK_SIZE)&&(audio_wm_params.offset < AUDIO_WM_MAX_PARAMS_LEN)){

      if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {
         if(wl->psm_pa_pipe.pipe_configured) {
            if((result = audio_psm_stage_get_config(wl->psm_pa_pipe.pipe_h,
                         wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle,
                         &wl->psm_pa_pipe.stages[WATERMARK_STAGE].params)) != ISMD_SUCCESS) {

               AUDIO_ERROR("audio_psm_stage_get_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }

         watermark_stage_params_ptr = &(wl->psm_pa_pipe.stages[WATERMARK_STAGE].params.watermark);
         if(watermark_stage_params_ptr->enabled){
         
            OS_MEMCPY((void *)(watermark_stage_params_ptr->params + audio_wm_params.offset), (void *)&(audio_wm_params.params[0]), audio_wm_params.len);

            /* Send changes down the psm only if we have already configured the back end pipe*/
            if((wl->psm_pa_pipe.pipe_configured) && (result == ISMD_SUCCESS)){
               if((result = audio_psm_stage_config(wl->psm_pa_pipe.pipe_h,
                               wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle,
                               &wl->psm_pa_pipe.stages[WATERMARK_STAGE].params)) != ISMD_SUCCESS) {

                  AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
         }
         else {
            result = ISMD_ERROR_INVALID_REQUEST;
            AUDIO_ERROR("Watermark stage has not been enabled. Call ismd_audio_enable_watermark_detection to enable.", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         audio_processor_unlock(wl);
      } else {
         AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      result = ISMD_ERROR_INVALID_PARAMETER;  
      AUDIO_ERROR("ismd_audio_set_watermark_detection failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}



ismd_result_t
ismd_audio_get_watermarks(ismd_audio_processor_t processor_h, audio_wm_params_block_t *audio_wm_params, ismd_buffer_handle_t awm_output_params_buffer)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = NULL;
   audio_watermark_management_params_t *watermark_stage_params_ptr;
   ismd_buffer_descriptor_t *buf_descr = NULL;
   void *audio_wm_params_ptr = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(audio_wm_params->offset < AUDIO_WM_MAX_PARAMS_LEN){
   
      if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {
         if(audio_wm_params->len <= AUDIO_WM_MAX_PARAM_BLOCK_SIZE){
            audio_wm_params_ptr = audio_wm_params->params;
         }
         else if((result = ismd_buffer_find_descriptor(awm_output_params_buffer, &buf_descr)) == ISMD_SUCCESS) {
            if(buf_descr->phys.size >= 2048) {
               audio_wm_params_ptr = (void *)buf_descr->virt.base;
            }
            else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("Please supply a buffer of at least 2KB for AWM information!", result, audio_devh[AUDIO_DEBUG_APM]);
            }   
         }

         if(result == ISMD_SUCCESS) {         
            if(wl->psm_pa_pipe.pipe_configured) {
               if((result = audio_psm_stage_get_config(wl->psm_pa_pipe.pipe_h,
                            wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle,
                            &wl->psm_pa_pipe.stages[WATERMARK_STAGE].params)) != ISMD_SUCCESS) {

                  AUDIO_ERROR("audio_psm_stage_get_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
            watermark_stage_params_ptr = &(wl->psm_pa_pipe.stages[WATERMARK_STAGE].params.watermark);
            // check to see if watermark stage is enabled
            if(watermark_stage_params_ptr->enabled){
               OS_MEMCPY(audio_wm_params_ptr,
                     (void *)(watermark_stage_params_ptr->params + audio_wm_params->offset), 
                        audio_wm_params->len);

               watermark_stage_params_ptr->host_notified = true;
               if((wl->psm_pa_pipe.pipe_configured) && (result == ISMD_SUCCESS)){
                  if((result = audio_psm_stage_config(wl->psm_pa_pipe.pipe_h,
                                  wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle,
                                  &wl->psm_pa_pipe.stages[WATERMARK_STAGE].params)) != ISMD_SUCCESS) {

                     AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
            }
            else {
               result = ISMD_ERROR_INVALID_REQUEST;
               AUDIO_ERROR("Watermark stage has not been enabled. Call ismd_audio_enable_watermark_detection to enable.", result, audio_devh[AUDIO_DEBUG_APM]);
            }

         }
         audio_processor_unlock(wl);
      } else {
         AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      result = ISMD_ERROR_INVALID_PARAMETER;  
      AUDIO_ERROR("ismd_audio_get_watermarks failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_set_sample_rate_convert_quality(ismd_audio_processor_t processor_h,
                              audio_src_quality_t  src_quality)
{
   (void)src_quality;
   (void)processor_h;
   OS_PRINT("\nSMD Audio: Please call ismd_audio_set_sampling_rate_conversion_quality.\n");
   return ISMD_ERROR_INVALID_REQUEST;
}


ismd_result_t
ismd_audio_enable_matrix_decoder(ismd_audio_processor_t processor_h, ismd_audio_matrix_decoder_t matrix_decoder)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      if(matrix_decoder == ISMD_AUDIO_MATRIX_DECODER_DTS_NEO6){

         //Only setup if the NEO6 stage is not enabled yet. 
         if(!wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].in_use) {

            //Mark the stage in use to be picked up at the post ATC reconfig time.
            wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].in_use = true;

            //Only reconfig the post ATC pipe if its already up.
            if(wl->psm_pa_pipe.pipe_configured) {
               audio_processor_post_atc_pipe_reconfig(wl, true, false);  
            }

            //If this comes back as disabled, we couldnt setup the decoder based on the outputs' setup.
            if(!wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].in_use){
               result = ISMD_ERROR_INVALID_REQUEST;
            }
         }
      }
      else{
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         AUDIO_ERROR("Matrix decoder not supported.", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      if(result == ISMD_SUCCESS){
         wl->active_matrix_decoder = matrix_decoder;
      } 
      
      audio_processor_unlock(wl);
   } else {
      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
 

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_disable_matrix_decoder(ismd_audio_processor_t processor_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      if(wl->active_matrix_decoder != (int)ISMD_AUDIO_MEDIA_FMT_INVALID){

         //Mark the matrix decode stages as not in use. 
         wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].in_use = false;
         wl->psm_pa_pipe.stages[DATA_DIV_STAGE].in_use = false;   
         wl->active_matrix_decoder = ISMD_AUDIO_MEDIA_FMT_INVALID;

         //Only reconfig the post ATC pipe if its already up.
         if(wl->psm_pa_pipe.pipe_configured) {
            audio_processor_post_atc_pipe_reconfig(wl, true, false);  
         }
      }

      audio_processor_unlock(wl);
   } else {

      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_set_matrix_decoder_param(ismd_audio_processor_t processor_h,
                              int param_type,
                              ismd_audio_decoder_param_t *param_value )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      switch(param_type){
         case ISMD_AUDIO_DTS_NEO6_MODE:
         case ISMD_AUDIO_DTS_NEO6_CGAIN:
         case ISMD_AUDIO_DTS_NEO6_NUM_OUTPUT_CHANNELS:
            result = audio_dts_neo6_set_decode_param(&wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].params, param_type, param_value);
            break;
      }

      audio_processor_unlock(wl);

   } else {
       AUDIO_ERROR("audio_processor_lock_and_get_wl failed !", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t 
ismd_audio_configure_master_clock(ismd_audio_processor_t processor_h, unsigned int frequency, ismd_audio_clk_src_t clk_src)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {
      
      if(wl->master_clk_freq_hz != frequency){
         
         switch(audio_soc_info.name){
            case SOC_NAME_CE3100:
                  result = audio_ce31xx_hal_configure_master_clock(frequency, clk_src);
               break;
            case SOC_NAME_CE4100:
                  result = audio_ce41xx_hal_configure_master_clock(frequency, clk_src);
               break;
            case SOC_NAME_CE4200:
                  result = audio_ce42xx_hal_configure_master_clock(frequency, clk_src);
                  break;
               case SOC_NAME_CE5300:
                  result = audio_ce53xx_hal_configure_master_clock(frequency, clk_src);
               break;
            default:
                  result = ISMD_ERROR_OPERATION_FAILED;
               break;
         }

         if(result == ISMD_SUCCESS){
            wl->master_clk_freq_hz = frequency;            
         }
      }
      
      audio_processor_unlock(wl);

   } else {
       AUDIO_ERROR("audio_processor_lock_and_get_wl failed !", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;

}

ismd_result_t 
ismd_audio_set_clock_mode(ismd_audio_processor_t processor_h, ismd_audio_clk_mode_t clk_mode)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      if((clk_mode == ISMD_AUDIO_CLK_INDEPENDENT) && (wl->clock_sync_h == ISMD_DEV_HANDLE_INVALID) && (wl->clock_recovery_mode == AUDIO_INDEPENDENT_CLOCK_RECOVERY_MODE_NORMAL)){
         result = ismd_clock_sync_open(&(wl->clock_sync_h));
         if (result == ISMD_SUCCESS) {
            if((result = ismd_clock_sync_set_algorithm(wl->clock_sync_h, PID_FILTERING)) !=  ISMD_SUCCESS){
               AUDIO_ERROR("ismd_clock_sync_set_algorithm failed !", result, audio_devh[AUDIO_DEBUG_APM]);
               if((result = ismd_clock_sync_close(wl->clock_sync_h)) != ISMD_SUCCESS){ 
                  AUDIO_ERROR("ismd_clock_sync_close failed !", result, audio_devh[AUDIO_DEBUG_APM]);
               }
               wl->clock_sync_h = ISMD_DEV_HANDLE_INVALID;
            }
         }
      }
      if (result == ISMD_SUCCESS) {
         if((result = audio_render_set_sync_clock(clk_mode, wl->clock_sync_h, wl->clock_recovery_mode)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_render_set_clock_mode failed !", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else if((result = audio_timing_control_set_clock_mode(clk_mode)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_timing_control_set_clock_mode failed !", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else if((result = audio_capture_set_clock_mode(clk_mode)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_capture_set_clock_mode failed !", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else {
            wl->clk_mode = clk_mode;
         }
      }

      audio_processor_unlock(wl);

   } else {
      AUDIO_ERROR("audio_processor_lock_and_get_wl failed !", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;

}


ismd_result_t 
ismd_audio_set_sampling_rate_conversion_quality(ismd_audio_processor_t processor_h,
                              ismd_audio_src_quality_t src_quality)

{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      switch(src_quality){
         case ISMD_AUDIO_SRC_QUALITY_DEFAULT:
         case ISMD_AUDIO_SRC_QUALITY_HIGH:
            
            wl->src_quality = src_quality;
            
            /* Commit the changes back to the SRC if the post processing pipe is running. */
            if ( wl->psm_pa_pipe.pipe_configured ) { 
               
               wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.src_quality = src_quality;
               result = audio_psm_stage_config_direct( wl->psm_pa_pipe.pipe_h, 
                  wl->psm_pa_pipe.stages[SRC_STAGE].handle, &wl->psm_pa_pipe.stages[SRC_STAGE].params);
               if ( result != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_psm_stage_config for the SRC failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
            
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }

      audio_processor_unlock(wl);
   } else {
       AUDIO_ERROR("Invalid processor handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t 
ismd_audio_get_sampling_rate_conversion_quality(ismd_audio_processor_t processor_h,
                              ismd_audio_src_quality_t *src_quality)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

      *src_quality = wl->src_quality;
            
      audio_processor_unlock(wl);
   } else {
      AUDIO_ERROR("Invalid processor handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


/*********************************************************************************************/
/* APM common processor functions*/
/*********************************************************************************************/

bool
audio_processor_valid_handle( ismd_audio_processor_t handle )
{
   bool result = false;

   handle = UNALIAS_GLOBAL_H(handle);
   
   if ( (handle >= 0) && (handle < AUDIO_MAX_PROCESSORS) ) {
      result = true;
   }
   else {
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"Invalid Processor Handle",  audio_devh[AUDIO_DEBUG_APM] );
   }

   return ( result );
}


void
audio_processor_init_wl(ismd_audio_processor_context_t *wl)
{
   int loop = 0;
   int max_loops = 0;

   /*Find largest value to use in for loop.*/
   max_loops = (AUDIO_MAX_INPUTS > AUDIO_MAX_OUTPUTS) ?  AUDIO_MAX_INPUTS : AUDIO_MAX_OUTPUTS;

   /*Initialize procssor stucture members. */
   wl->in_use = false;
   wl->muted = false;
   wl->primary_input_wl = NULL;
   wl->secondary_input_wl = NULL;
   wl->start_to_close = false;
   wl->is_global_processor = false;
   wl->passthrough_output_count = 0;
   wl->primary_input_format = ISMD_AUDIO_MEDIA_FMT_PCM;
   wl->input_count = 0;
   wl->output_count = 0;
   wl->timed_input_count = 0;
   wl->enable_atc_fast_output = false; 
   wl->master_volume = ISMD_AUDIO_GAIN_0_DB;
   wl->master_volume_enable = false;
   wl->per_channel_volume_enable = false;
   wl->wait_with_timeout = false;
   wl->active_matrix_decoder = ISMD_AUDIO_MEDIA_FMT_INVALID;
   wl->master_clk_freq_hz = 0;
   wl->clk_mode = ISMD_AUDIO_CLK_LOCKED; 
   wl->clock_sync_h = ISMD_DEV_HANDLE_INVALID;   
   wl->atc_timer_clock_h = NULL; 
   wl->chunk_size_period = AUDIO_CHUNK_TIME_PERIOD_MS;
   wl->process_mode = AUDIO_PROCESS_MODE_NORMAL;
   wl->src_quality = ISMD_AUDIO_SRC_QUALITY_DEFAULT;
   /*Need to have a valid set of defualt mixer coeff to init the mixer stage inputs with.*/
   audio_input_mixer_config_set_gain(&wl->default_mix_coeff, MIX_COEFF_INDEX_0_DB, MIX_COEFF_INDEX_MUTE);
   
   audio_processor_init_psm_pipe_wl(&(wl->psm_pass_pipe));
   audio_processor_init_psm_pipe_wl(&(wl->psm_pa_pipe));
  
   for(loop = 0; loop < max_loops; loop++){

      /*Initialize all possible input struct members.*/
      if(loop < AUDIO_MAX_INPUTS){
         audio_input_init_wl(&(wl->inputs[loop]));
      }

      /*Initialize all possible output struct members.*/
      if(loop < AUDIO_MAX_OUTPUTS){
         audio_output_init_wl(&(wl->outputs[loop]));
      }
   }

   for ( loop = 0; loop < AUDIO_MAX_OUTPUT_CHANNELS; loop++ ) {
      wl->per_channel_volume[loop] = ISMD_AUDIO_GAIN_0_DB;
   }
   for ( loop = 0; loop < AUDIO_MAX_OUTPUT_CHANNELS; loop++ ) {
      wl->post_mix_ch_gain[loop] = MIX_COEFF_INDEX_0_DB;
   }

   return;

}


ismd_result_t
audio_processor_get_wl(ismd_audio_processor_t proc_h, ismd_audio_processor_context_t **wl)
{

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   proc_h = UNALIAS_GLOBAL_H(proc_h);

   if(!audio_processor_valid_handle(proc_h))
      return ISMD_ERROR_INVALID_HANDLE;

   *wl = &(processor_context[proc_h]);

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ISMD_SUCCESS;
}


ismd_result_t
audio_processor_lock_and_get_wl(ismd_audio_processor_t proc_h, ismd_audio_processor_context_t **wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   proc_h = UNALIAS_GLOBAL_H(proc_h);

   if (audio_processor_valid_handle(proc_h)) {

      audio_processor_lock ( &(processor_context[proc_h]) );

      if (processor_context[proc_h].in_use) {

         *wl = &(processor_context[proc_h]);
         result = ISMD_SUCCESS;
      }
      else {
         audio_processor_unlock ( &(processor_context[proc_h]) );
         result = ISMD_ERROR_INVALID_HANDLE;
      }
   }else{
      result = ISMD_ERROR_INVALID_HANDLE;
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

void
audio_processor_lock (ismd_audio_processor_context_t *instance) {
   if(instance != NULL) {
      os_mutex_lock(&instance->lock);
   }
}

void
audio_processor_unlock (ismd_audio_processor_context_t *instance) {
   if(instance != NULL) {
      os_mutex_unlock(&instance->lock);
   }
}

void
audio_processor_init_psm_pipe_wl(audio_psm_post_atc_pipe_t *pipe)
{
   int loop = 0;

   pipe->pipe_configured = false;
   pipe->pipe_h = AUDIO_INVALID_HANDLE;
   pipe->stage_count = 0;
   pipe->ddco_test_mode_en = false;
   pipe->encode_hw_path_out_index= AUDIO_INVALID_HANDLE;
   pipe->encode_sw_path_out_index = AUDIO_INVALID_HANDLE;

   for(loop = 0; loop < PA_PSM_PIPE_MAX_STAGES; loop++) {
      
      pipe->stages[loop].handle = AUDIO_INVALID_HANDLE;
      pipe->stages[loop].task = PSM_TASK_UNKNOWN;
      pipe->stages[loop].input_count = 0;
      pipe->stages[loop].output_count = 0;
      pipe->stages[loop].in_use = false;
      OS_MEMSET((void *) &(pipe->stages[loop].params), 0, sizeof(audio_psm_stage_params_t));    
      OS_MEMSET((void *) &(pipe->stages[loop].conn_mda), 0, sizeof(audio_psm_stage_connection_metadata_t));    
   }
   return;
}


/* 
  * This function exists for the case that outputs are setup and started and then the application calls 
  * input_set_as_prmary, then the outputs need to be sync'd with the changes so we have to 
  * notify the renders to change format and process at the correct rate. Not locking the processor
  * here since we have already locked it in the calling function. Keep in mind here that this function
  * assumes that the user already took into account that anything its going to feed as passthrough,
  * the reciever already supports it (app read EDID info, in HDMI case). 
  */
ismd_result_t
audio_processor_reconfig_passthrough_outptus(ismd_audio_processor_context_t *wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   int index = 0;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(wl->primary_input_wl != NULL){

      for(index = 0; index < AUDIO_MAX_OUTPUTS; index++) {

         os_mutex_lock(&wl->outputs[index].lock);
         
         if((wl->outputs[index].in_use) && (wl->outputs[index].output_mode == ISMD_AUDIO_OUTPUT_PASSTHROUGH)){

            //Disabling and then re-enabling the output allows it to lock to the current primary input's format.
            if(wl->outputs[index].render_format != wl->primary_input_format){
               if(wl->outputs[index].enabled){
                  if((result = audio_output_disable(&wl->outputs[index])) == ISMD_SUCCESS){
                     result = audio_output_enable(&wl->outputs[index]);
                  }
               }
            }
         }
         os_mutex_unlock(&wl->outputs[index].lock);
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}

ismd_result_t
audio_processor_post_atc_pipe_reconfig(ismd_audio_processor_context_t *wl, bool force_reconfig, bool reconfig_pass_pipe)
{
   ismd_result_t result = ISMD_SUCCESS;

   /*NOTE: Yout must have the processor context (API) LOCKED when calling this function!*/

   //Check to see if we have any remaining inputs and if the post atc pipe is up and running.
   //If that is the case we need to bring down the pipe and bring it back up. 
   if(((wl->input_count > 0) && wl->psm_pa_pipe.pipe_configured) || force_reconfig) {

      /*Going to free up the older PSM pipe, need to signal its not configured.*/
      wl->psm_pa_pipe.pipe_configured = false; 
      
      if((result = audio_psm_pipe_free(wl->psm_pa_pipe.pipe_h))  != ISMD_SUCCESS){
         AUDIO_ERROR("audio_psm_pipe_free failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if ((result = audio_pvt_processor_post_atc_pipe_setup_and_start(wl, !force_reconfig)) != ISMD_SUCCESS) {
         AUDIO_ERROR("audio_pvt_processor_post_atc_pipe_setup_and_start failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      AUDIO_EVENT(1, audio_devh[AUDIO_DEBUG_APM], SVEN_MODULE_EVENT_AUD_IO_APM_POST_ATC_PIPE_RECONFIG,
               wl->handle_id, force_reconfig, wl->input_count, wl->output_count, 0, 0);
   }

   //If we need to, resetup the packetizer passthrough pipe. 
   if(reconfig_pass_pipe && (result == ISMD_SUCCESS)){

      if(wl->psm_pass_pipe.pipe_h != AUDIO_INVALID_HANDLE) {
         if((result = audio_psm_pipe_free(wl->psm_pass_pipe.pipe_h)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_pipe_free failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else {
            audio_processor_init_psm_pipe_wl(&(wl->psm_pass_pipe));
            if((result = audio_psm_pipe_alloc(PSM_PIPE_TYPE_POST_ATC ,&(wl->psm_pass_pipe.pipe_h)))  != ISMD_SUCCESS){
               AUDIO_ERROR("audio_psm_pipe_alloc failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
            else if((result = audio_processor_setup_pass_through_pipe(wl, wl->primary_input_wl, !force_reconfig)) != ISMD_SUCCESS){
               AUDIO_ERROR("Attempt to setup passthrough pipe failed in post ATC pipe reconfig!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }
   }
   
   return result;
}


ismd_result_t
audio_processor_psm_pipe_remove_input(ismd_audio_processor_context_t *wl, int input_id)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;
   audio_psm_pipe_stage_t *mixer_stage = &wl->psm_pa_pipe.stages[MIXER_STAGE];
   audio_psm_pipe_stage_t *src_stage = &wl->psm_pa_pipe.stages[SRC_STAGE];
   bool need_to_update_psm = false;
   int mixer_input_index = 0;
   bool associated_stream_added = false;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /*Get the input context we are going to remove from the POST ATC pipe.*/
   input_wl = &wl->inputs[input_id];
   mixer_input_index = input_id;

   /* Tell backend PSM the queue is removed*/
   if((wl->psm_pa_pipe.pipe_configured) && input_wl->added_to_post_atc_pipe) {
      
      /*Remove the queue from the PSM post ATc pipe*/
      result = audio_psm_input_queue_remove(wl->psm_pa_pipe.pipe_h, input_wl->atc_out_queue_h);

      /*If we previously connected an associated stream, also remove that queue.*/
      if (AUDIO_CORE_IS_MS10(input_wl) && 
         audio_core_is_ms10_ddc(input_wl->format) &&
         (input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_AND_ASSOC)) 
      {
         result = audio_psm_input_queue_remove(wl->psm_pa_pipe.pipe_h, input_wl->assoc_atc_out_queue_h);
         associated_stream_added = true;
      }
   }

   if(result == ISMD_SUCCESS) {
      
      /*Need to update the mixer and SRC status if the input is Primary or Secondary.*/
      if ( input_wl->input_type == AUDIO_INPUT_TYPE_SECONDARY ) {
         mixer_stage->params.mixer.host.mixer.secondary_index = AUDIO_INVALID_HANDLE;
         wl->secondary_input_wl = NULL;
         need_to_update_psm = true;
      }

      /* Do some clean up if it is a primary input */
      if ( input_wl->input_type == AUDIO_INPUT_TYPE_PRIMARY ) {
         mixer_stage->params.mixer.host.mixer.primary_index = AUDIO_INVALID_HANDLE;
         src_stage->params.src.host.src.primary_index = AUDIO_INVALID_HANDLE;
         wl->primary_input_wl = NULL;
         wl->primary_input_format = ISMD_AUDIO_MEDIA_FMT_PCM;
         need_to_update_psm = true;
      }

      /*Clear out any previous SRC state information for this context. And associated stream if needed. */
      src_stage->params.src.history_buf_index[mixer_input_index] = 0;
      src_stage->params.src.state[mixer_input_index] = 0;  
      OS_MEMSET(&src_stage->params.src.state_info[mixer_input_index], 0, sizeof(src_44_1_to_48_state_info_t));

      if(associated_stream_added) {
         src_stage->params.src.history_buf_index[ASSOC_STREAM_MIXER_INPUT_INDEX] = 0;
         src_stage->params.src.host.src.output_sample_rate[ASSOC_STREAM_MIXER_INPUT_INDEX] = 0;
         src_stage->params.src.state[ASSOC_STREAM_MIXER_INPUT_INDEX] = 0;  
         OS_MEMSET(&src_stage->params.src.state_info[ASSOC_STREAM_MIXER_INPUT_INDEX], 0, sizeof(src_44_1_to_48_state_info_t));
      }
      

      /* Need to do a set on the Mixer and SRC stage since they have both been updated. */
      if(wl->psm_pa_pipe.pipe_configured && input_wl->added_to_post_atc_pipe && need_to_update_psm) {
         if((result = audio_psm_stage_config_direct(wl->psm_pa_pipe.pipe_h, mixer_stage->handle, &mixer_stage->params)) == ISMD_SUCCESS){
            result = audio_psm_stage_config_direct(wl->psm_pa_pipe.pipe_h, src_stage->handle, &src_stage->params);
         }
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}

ismd_result_t
audio_processor_psm_pipe_add_input(ismd_audio_input_wl_t *input_wl, int mixer_input_index, audio_psm_output_configs_t *output_configs)
{
   ismd_result_t result = ISMD_SUCCESS;

   /*Ensure we have not already added it to post ATC pipe.*/
   if(!input_wl->added_to_post_atc_pipe) {
      
      if((result = audio_pvt_psm_pipe_add_input(input_wl->processor_wl, input_wl, mixer_input_index, output_configs, false)) == ISMD_SUCCESS) {

         /* Check to see if this is an MS10 type input with an associated stream. When we add the associated stream
            we are using a fixed position in the mixer input, this position will not be taken by an input when in MS10 
            process mode, since we have blocked resources for 1 input when in MS10 mode. */
         if (AUDIO_CORE_IS_MS10(input_wl) && 
            audio_core_is_ms10_ddc(input_wl->format) &&
            (input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_AND_ASSOC)) 
         {
            result = audio_pvt_psm_pipe_add_input(input_wl->processor_wl, input_wl, ASSOC_STREAM_MIXER_INPUT_INDEX, output_configs, true);
         }
      }
   }
   return result;
}


ismd_result_t
audio_processor_start_post_atc_pipe(ismd_audio_processor_context_t *wl, audio_psm_pipe_handle_t pipe_h, bool lock_outputs)
{
   int out_id = 0;
   ismd_audio_output_wl_t *output = NULL;
   ismd_result_t result = ISMD_SUCCESS;

   //Go through the outputs and check for disabled queues.
   for(out_id = 0; out_id < AUDIO_MAX_OUTPUTS; out_id++) {

      output = &wl->outputs[out_id];
      
      if(lock_outputs){
         os_mutex_lock(&output->lock);
      }

      //If we have an output disabled but in use, make sure to disable the PSM queue.
      if(output->in_use &&  !output->enabled) {

         //Check to see which post ATC pipe we should disable the queue on. 
         if((output->output_mode == ISMD_AUDIO_OUTPUT_PASSTHROUGH) && (pipe_h == wl->psm_pass_pipe.pipe_h)){           
            audio_psm_output_queue_disable(pipe_h, output->psm_output_queue);
            output->psm_output_queue_disabled = true;
         }

         if((output->output_mode != ISMD_AUDIO_OUTPUT_PASSTHROUGH) && (pipe_h == wl->psm_pa_pipe.pipe_h)){           
            audio_psm_output_queue_disable(pipe_h, output->psm_output_queue);
            output->psm_output_queue_disabled = true;
         }
      }
      
      if(lock_outputs){
         os_mutex_unlock(&output->lock);
      }
   }

   result = audio_psm_pipe_start(pipe_h);

   return result;
}


static ismd_result_t
audio_pvt_processor_post_atc_pipe_setup_and_start(ismd_audio_processor_context_t *wl, bool lock)
{
   ismd_result_t result = ISMD_SUCCESS;
   int input_h = 0;

   /*Need to ensure each input is re-added since we are going to rebuild the post ATC pipe.
     No need to lock the input wl, since we have the API lock when this happens. */
   for(input_h = 0; input_h< AUDIO_MAX_INPUTS; input_h++) {
      if(wl->inputs[input_h].in_use) {
         wl->inputs[input_h].added_to_post_atc_pipe = false;
      }
   }

   if((result = audio_psm_pipe_alloc(PSM_PIPE_TYPE_POST_ATC ,&(wl->psm_pa_pipe.pipe_h)))  != ISMD_SUCCESS){
      AUDIO_ERROR("audio_psm_pipe_free failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_psm_pipe_set_input_queue_lock(wl->psm_pa_pipe.pipe_h, &wl->atc_psm_queue_lock)) != ISMD_SUCCESS) {
      AUDIO_ERROR("audio_psm_pipe_set_input_queue_lock failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   else if( (result = audio_processor_psm_pipe_connect_stages(wl)) != ISMD_SUCCESS) {
      AUDIO_ERROR("audio_processor_psm_pipe_connect_stages failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   /*Force reconfig only happens when an output is locked*/
   else if((result = audio_processor_start_post_atc_pipe(wl, wl->psm_pa_pipe.pipe_h, lock)) != ISMD_SUCCESS){
      AUDIO_ERROR("start_post_atc_pipe PCM pipe failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else {
      wl->psm_pa_pipe.pipe_configured = true;
   }
   return result;
}

static ismd_result_t
audio_pvt_config_stages(audio_psm_post_atc_pipe_t *pipe)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   int loop = 0;

   for(loop = 0; loop < PA_PSM_PIPE_MAX_STAGES; loop++) {

      /* Only add/config the stage if we have flagged it that we needed it */
      if(pipe->stages[loop].in_use) {

         /* Commmit config changes to the PSM  */
         if((result = audio_psm_stage_config(pipe->pipe_h, 
                             pipe->stages[loop].handle, 
                             &pipe->stages[loop].params)) != ISMD_SUCCESS) {

            AUDIO_ERROR("psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }
   return result;
}


static ismd_result_t
audio_pvt_add_stages(audio_psm_post_atc_pipe_t *pipe)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   int loop = 0;

   for(loop = 0; loop < PA_PSM_PIPE_MAX_STAGES; loop++) {

      /* Only add/config the stage if we have flagged it that we needed it */
      if(pipe->stages[loop].in_use) {
         
         if((result = audio_psm_stage_add(pipe->pipe_h, 
                             pipe->stages[loop].task, 
                             pipe->stages[loop].input_count,
                             pipe->stages[loop].output_count, 
                             &(pipe->stages[loop].handle))) != ISMD_SUCCESS) {

            AUDIO_ERROR("psm_stage_add add failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }

   return result;
}


static ismd_result_t
audio_pvt_stages_add_conn_mda(audio_psm_post_atc_pipe_t *pipe)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   int loop = 0;

   for(loop = 0; loop < PA_PSM_PIPE_MAX_STAGES; loop++) {

      /* Only add/config the stage if we have flagged it that we needed it */
      if(pipe->stages[loop].in_use) {
         
         if((result = audio_psm_stage_config_metadata(pipe->pipe_h, 
                             pipe->stages[loop].handle, 
                             &pipe->stages[loop].conn_mda)) != ISMD_SUCCESS) {

            AUDIO_ERROR("psm_stage_config_metadat failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }

   return result;
}


static ismd_result_t
audio_pvt_connect_encoder_build_path_to_output(ismd_audio_processor_context_t *wl, bool is_sw_output, int output_index) 
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   
   /*If we are in this function and its SW output(s) only, dont connect the data divider, output frame only*/
   if(is_sw_output) {
      if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                       wl->psm_pa_pipe.stages[ENCODE_STAGE].handle, ENCODE_OUTPUT_INDEX_FRAME, 
                       wl->psm_pa_pipe.stages[OUTPUT_STAGE].handle, output_index)) != ISMD_SUCCESS)
      {
         AUDIO_ERROR("ENCODE_STAGE -OUTPUT_STAGE connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }   
      wl->psm_pa_pipe.encode_sw_path_out_index = output_index;
   }
   /*Hardware output paths needs the data divider to maintain render timestamps and time quantam. */
   else { 
      if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                       wl->psm_pa_pipe.stages[ENCODE_STAGE].handle, ENCODE_OUTPUT_INDEX_IEC61937, 
                       wl->psm_pa_pipe.stages[DATA_DIV_STAGE].handle, 0)) != ISMD_SUCCESS) 
      {
         AUDIO_ERROR("ENCODE_STAGE -DATA_DIV_STAGE connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                       wl->psm_pa_pipe.stages[DATA_DIV_STAGE].handle, 0, 
                       wl->psm_pa_pipe.stages[OUTPUT_STAGE].handle, output_index)) != ISMD_SUCCESS) 
      {
         AUDIO_ERROR("DATA_DIV_STAGE -OUTPUT_STAGE connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      wl->psm_pa_pipe.encode_hw_path_out_index = output_index;
   }
   return result;
}


static ismd_result_t
audio_pvt_connect_encoder_duplicate_to_output(ismd_audio_processor_context_t *wl, psm_output_t *output, int *output_index)
{
   ismd_result_t result = ISMD_SUCCESS;
   int output_indx = 0;
   bool build_path = false;

   /*If we have gotten here the SW or HW encode path has already been built*/
   
   /* Check for need to build paths. */
   if(output->is_sw_output ) {
      if(wl->psm_pa_pipe.encode_sw_path_out_index == AUDIO_INVALID_HANDLE) {
         build_path = true;
      }
   }
   else {
      if(wl->psm_pa_pipe.encode_hw_path_out_index == AUDIO_INVALID_HANDLE) {
        build_path = true;
      }
   }

   /*Build out the path to the output if needed.*/
   if(build_path) {
      /*Increment the master output index since this output will be taking another output stage slot*/
      *output_index = (*output_index + 1);
      result = audio_pvt_connect_encoder_build_path_to_output(wl, output->is_sw_output, *output_index); 
   }

   if(result == ISMD_SUCCESS) {
      /*Get index after path is built.*/
      output_indx = (output->is_sw_output) ? wl->psm_pa_pipe.encode_sw_path_out_index : wl->psm_pa_pipe.encode_hw_path_out_index;
      
      /*Add the queue to the constructed path.*/
      if((result = audio_psm_output_queue_add(wl->psm_pa_pipe.pipe_h, output->output_queue, output_indx)) != ISMD_SUCCESS) {
         AUDIO_ERROR("psm_output_queue_add failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }  
   }

   return result;
}


static ismd_result_t
audio_pvt_connect_encoder_to_output(ismd_audio_processor_context_t *wl, psm_output_t *output, int index, int output_index)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   
   /*About to contruct the encode pipe, init these flags so we can track what is built.*/
   wl->psm_pa_pipe.encode_hw_path_out_index= AUDIO_INVALID_HANDLE;
   wl->psm_pa_pipe.encode_sw_path_out_index = AUDIO_INVALID_HANDLE;
   
   if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
        wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].handle, index,
        wl->psm_pa_pipe.stages[ENCODE_STAGE].handle, 0)) != ISMD_SUCCESS) 
   {
      AUDIO_ERROR("INTERLVR_STAGE to ENCODE_STAGE connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else {
      result = audio_pvt_connect_encoder_build_path_to_output(wl, output->is_sw_output, output_index);
   }

   if(result == ISMD_SUCCESS) {

      //First handle common settings that apply to all encoders
      //If we are using an encoder, we have to reorder. They always accept 32b for now.
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].reorder_for_hw = true;
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_smpl_size = 32;

      //By default set to ignore, but propagate, eos. 
      wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.ignore_eos = true;

      if(output->is_sw_output){
         //If we want file output, also tell the encoder to output directly, no packetization, by default this is true.
         wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.packetize_output = false;
         
         //If we have gotten here and this is a SW output, it does NOT have a duplicate HW output, 
         //because when a HW and SW output exist and are duplicated only the SW output is duplicated,
         //in the encoder/decoder case, see read_output_configs. Do not ignore EOS in this scenario.  
         wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.ignore_eos = false; 
      }
      
      //Need to setup all kinds of special sauce for DTS encoder.
      if(output->encode_format == ISMD_AUDIO_ENCODE_FMT_DTS){

         //Handle 2ch encode cases.
         if(wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.config.dts_enc_params.total_num_input_ch == 2) {

            //Tell the downmixer and interleaver to output the correct number of channels.
            wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_count = 2;
            wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[index].i_num_out_channels = 2;

            // 1.1 = C, LFE
            if(wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.config.dts_enc_params.lfe_present && 
               (wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.config.dts_enc_params.num_input_ch == 1)){
               
               wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_map = 0xFFFFFF71;
            }
            // 2.0 L R
            else{
               wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_map = 0xFFFFFF20;
            }
         }
         //Handle 4ch encode cases.
         else if(wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.config.dts_enc_params.total_num_input_ch == 4) {

            wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_count = 4;
            wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[index].i_num_out_channels = 4;

            //If its LFE, need to set the interleaver to output appropriately.
            if(wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.config.dts_enc_params.lfe_present){
               // 3.1 = LFE, L, R, C
               wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_map = 0xFFFF7120;
            }
            else{
               // 4 = L , R, Lsur, Rsur
               wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_map = 0xFFFF4320;
            }
         }
         else if(wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.config.dts_enc_params.total_num_input_ch == 6) {
            //5.1
            wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_map = 0xFF714320;
            wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_count = 6;
            wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[index].i_num_out_channels = 6;
         }
         else{
            result = ISMD_ERROR_INVALID_REQUEST;
            AUDIO_ERROR("DTS encoder configuration is invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
		 // Check for Valid Sample rate
		 if(output->sample_rate != 48000){
		   OS_PRINT("AUDIO WARNING: The DTS encoded output only supports 48kHz currently! Please reconfigure the output.\n");
		 }			 
      }

      //AC3 DDCO settings. 
      else if(output->encode_format == ISMD_AUDIO_ENCODE_FMT_AC3){
         wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_map = 0xFF412370;
         wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_count = 6;
         wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[index].i_num_out_channels = 6;
		 // Check for Valid Sample rate
		 if(output->sample_rate != 48000){
		   OS_PRINT("AUDIO WARNING: The AC3 encoded output only supports 48kHz currently! Please reconfigure the output.\n");
		 }		 
      }
	  
	  //AAC Encoder settings. 
      else if(output->encode_format == ISMD_AUDIO_ENCODE_FMT_AAC){

         //Handle 2ch encode cases.
         if(wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.config.aac_enc_params.num_input_ch == 2) {

            //Tell the downmixer and interleaver to output the correct number of channels.
            // 2.0 L R
            wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_map = 0xFFFFFF20;            
            wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_count = 2;
            wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[index].i_num_out_channels = 2;
         }
         //Handle 4ch encode cases.
         //Handle 6ch encode cases.
         else{
            result = ISMD_ERROR_INVALID_REQUEST;
            AUDIO_ERROR("AAC encoder configuration is invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
		 // Check for Valid Sample rate
		 if(audio_aac_enc_valid_output_sample_rate(output->sample_rate) == ISMD_SUCCESS){
            wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.config.aac_enc_params.sample_rate = output->sample_rate; 
       } else {
		   OS_PRINT("AUDIO WARNING: The AAC encoded output only supports 8kHz to 96kHz currently! Please reconfigure the output.\n");
		 }		 
      }
      else{
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("FATAL: Setup encoders with the output not specified for encode!!!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   return result;
}


static  ismd_result_t
audio_pvt_connect_matrix_dec_to_output(ismd_audio_processor_context_t *wl, psm_output_t *output, int index, int output_index)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   
   if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                    wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].handle, index,
                    wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].handle, 0)) != ISMD_SUCCESS) {

      AUDIO_ERROR("PER_OUTPUT_DELAY_STAGE -MATRIX_DEC_STAGE connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                    wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].handle, 0, 
                    wl->psm_pa_pipe.stages[DATA_DIV_MATRX_DEC_STAGE].handle, 0)) != ISMD_SUCCESS) {

      AUDIO_ERROR("MATRIX_DEC_STAGE -ACCUMULATOR_STAGE connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                    wl->psm_pa_pipe.stages[DATA_DIV_MATRX_DEC_STAGE].handle, 0, 
                    wl->psm_pa_pipe.stages[OUTPUT_STAGE].handle, output_index)) != ISMD_SUCCESS) {

      AUDIO_ERROR("ACCUMULATOR_STAGE -OUTPUT_STAGE connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else {

      //Set up the up stream stages to only 2 channels before it hits NEO6 since only accepts 2ch input.
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_count = 2;
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_smpl_size = 32;
      wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[index].i_num_out_channels = 2;

      //Neo6 decoder always ouputs 32bit samples even if the input sample size is 16 or 24
      output->sample_size = 32;

      //Set default to ignore EOS.
      wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].params.decoder.host.codec.ignore_eos = true;

      if(output->is_sw_output) {
         //If we have gotten here and this is a SW output, it does NOT have a duplicate HW output, 
         //because when a HW and SW output exist and are duplicated only the SW output is duplicated,
         //in the encoder/decoder case, see read_output_configs. Do not ignore EOS in this scenario.  
         wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].params.decoder.host.codec.ignore_eos = false;
      }
          
   }
 
   return result;
}


static  ismd_result_t
audio_pvt_connect_to_output(ismd_audio_processor_context_t *wl, psm_output_t *output, int index, int output_index)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;

   if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                 wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].handle, index,
                 wl->psm_pa_pipe.stages[OUTPUT_STAGE].handle, output_index)) != ISMD_SUCCESS) {

      AUDIO_ERROR("PER_OUTPUT_DELAY_STAGE -OUTPUT_STAGE connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else{

      if(output->is_sw_output){
         
         if(output->channel_map == 0){
            wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].reorder_for_hw = false;
         }
         else{
            wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_map = output->channel_map;
         }
         //Interleaver will look at this and use the input ch count and pass it through.
         wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_count = 0;
      }
      else{
         wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_ch_count = output->channel_count;
      }

      //Assinging these values directly, since these values have already been validated already when the output was added. 
      wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[index].i_num_out_channels = output->channel_count;
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[index].output_smpl_size = output->sample_size;
   }

   return result;
}


static  ismd_result_t
audio_pvt_connect_post_mixer_stages(ismd_audio_processor_context_t *wl, audio_psm_output_configs_t *output_configs)
{
   int i = 0, j = 0;
   int stage_index = 0;
   int output_index = 0;
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;

   /*** Need to now connect all stages that are 1 to 1, one input one output from the mixer. ***/
   if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                       wl->psm_pa_pipe.stages[MIXER_STAGE].handle,  
                       0,
                       wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle,  
                       0)) != ISMD_SUCCESS) {

      AUDIO_ERROR("mixer - watermark connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /* Connect the the Watermark to the bass management's input */
   else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                       wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle,  
                       0,
                       wl->psm_pa_pipe.stages[BASS_MAN_STAGE].handle,  
                       0)) != ISMD_SUCCESS) {

      AUDIO_ERROR("watermark - bass_management connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h,
                       wl->psm_pa_pipe.stages[BASS_MAN_STAGE].handle,
                       0,
                       wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].handle,
                       0)) != ISMD_SUCCESS) {

      AUDIO_ERROR("bass - delay_management connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /***  Now for EVERY ouput we connect all stages that are NOT 1 to 1 ****/
   else {
      for(i = 0; i < output_configs->count; i++) { 

         if(output_configs->outputs[i].duplicate_index == NO_DUPLICATE_OUTPUT){
            
            if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                                wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].handle, 0, //Only one output from the delay management stage always. 
                                wl->psm_pa_pipe.stages[DOWNMIX_STAGE].handle, stage_index)) != ISMD_SUCCESS) {

               AUDIO_ERROR("Delay man to downmix connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                                wl->psm_pa_pipe.stages[DOWNMIX_STAGE].handle, stage_index, 
                                wl->psm_pa_pipe.stages[POST_SRC_STAGE].handle, stage_index)) != ISMD_SUCCESS) {

               AUDIO_ERROR("Downmix to Post SRC stage connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            else if((result=audio_pvt_insert_srs_stage(wl,stage_index))!=ISMD_SUCCESS){
               AUDIO_ERROR("SRS Insert Stage failed", result, audio_devh[AUDIO_DEBUG_APM]);            
            }

            else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                                wl->psm_pa_pipe.stages[QUALITY_STAGE].handle, stage_index, 
                                wl->psm_pa_pipe.stages[INTERLVR_STAGE].handle, stage_index)) != ISMD_SUCCESS) {

               AUDIO_ERROR("Post Qaulity to interlevr connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
            else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h,
                                wl->psm_pa_pipe.stages[INTERLVR_STAGE].handle, stage_index,
                                wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].handle, stage_index)) != ISMD_SUCCESS) {

               AUDIO_ERROR("Interlevr to per output delay connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
            else {
    
               //Audio quality and per output need know the handle of the ouptut this connection is associated with. 
               //This is to properly associate the contexts. 
               wl->psm_pa_pipe.stages[QUALITY_STAGE].conn_mda.output[stage_index] = output_configs->outputs[i].output_handle;
               wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].conn_mda.output[stage_index] = output_configs->outputs[i].output_handle;
               wl->psm_pa_pipe.stages[DOWNMIX_STAGE].conn_mda.output[stage_index] = output_configs->outputs[i].output_handle;
               wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[stage_index].final_output_num_ch = output_configs->outputs[i].channel_count;
               wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.output_params[output_configs->outputs[i].output_handle].buffer_reset = true;
               wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.host.per_output_delay.host_output_params[output_configs->outputs[i].output_handle].new_delay = 
                  output_configs->outputs[i].delay_ms;
                  
               //Configure the POST SRC
               wl->psm_pa_pipe.stages[POST_SRC_STAGE].params.src.host.src.output_sample_rate[stage_index] = output_configs->outputs[i].sample_rate;
               wl->psm_pa_pipe.stages[POST_SRC_STAGE].params.src.host.src.src_quality = wl->src_quality;

               //Configure the SRS Stage
               wl->psm_pa_pipe.stages[SRS_STAGE].conn_mda.output[stage_index] = output_configs->outputs[i].srs_output_context;
              
               //If we have encoders, connect them up.
               if(output_configs->outputs[i].is_encoder_output) {
                  result = audio_pvt_connect_encoder_to_output(wl, &output_configs->outputs[i], stage_index, output_index);
               }
               else if(output_configs->outputs[i].matrix_dec_enabled) {
                  result = audio_pvt_connect_matrix_dec_to_output(wl, &output_configs->outputs[i], stage_index, output_index);
               }
               else {
                  result = audio_pvt_connect_to_output(wl, &output_configs->outputs[i], stage_index, output_index);
               }

               //Set the downmix standard on this input to the downmix stage. 
               wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[stage_index].dmix_mode = output_configs->outputs[i].dmix_mode;
            }

            /* Add the queue to associate to the output stage output. */
            if(output_configs->outputs[i].output_queue != ISMD_QUEUE_HANDLE_INVALID){
               if((result = audio_psm_output_queue_add(wl->psm_pa_pipe.pipe_h, output_configs->outputs[i].output_queue, output_index)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("psm_output_queue_add failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }

            //Search in the outputs for a duplicate index then add that queue also. 
            for(j = 0; j < output_configs->count; j++) { 
               
               if( output_configs->outputs[j].duplicate_index == i ) {

                  /*If the output is encoded and has a mix of HW and SW need to tap into the correct output of the encoder. */
                  if(output_configs->outputs[j].is_encoder_output ) {
                     audio_pvt_connect_encoder_duplicate_to_output(wl, &output_configs->outputs[j], &output_index);
                  }
                  else{
                     if((result = audio_psm_output_queue_add(wl->psm_pa_pipe.pipe_h, output_configs->outputs[j].output_queue, output_index)) != ISMD_SUCCESS) {
                        AUDIO_ERROR("psm_output_queue_add failed", result, audio_devh[AUDIO_DEBUG_APM]);
                     }
                  }
               }  
            }
            stage_index++;
            output_index++;
         }     
      }
   }

   return result;
}


static ismd_result_t
audio_pvt_psm_pipe_add_input(ismd_audio_processor_context_t *wl, ismd_audio_input_wl_t *input_wl, 
   int mixer_input_index, audio_psm_output_configs_t *output_configs, bool is_associated_stream)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_queue_handle_t mixer_input_queue_h;
   audio_psm_pipe_stage_t *mixer_stage = &wl->psm_pa_pipe.stages[MIXER_STAGE];
   audio_psm_pipe_stage_t *src_stage = &wl->psm_pa_pipe.stages[SRC_STAGE];
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /*If we have an associated stream, use the correct queue.*/
   if(is_associated_stream) {
      mixer_input_queue_h = input_wl->assoc_atc_out_queue_h;
   }
   else {
      mixer_input_queue_h = input_wl->atc_out_queue_h;
   }

   /* Get the stage info if the post ATC PSM pipe is running. */
   if(wl->psm_pa_pipe.pipe_configured) {
      result = audio_psm_stage_get_config(wl->psm_pa_pipe.pipe_h, src_stage->handle, &src_stage->params);
   }
   if(result == ISMD_SUCCESS) {
      
      /* Add the input queue use the input's mixer input index to know which queue is associated to which input. */
      if((result = audio_psm_input_queue_add(wl->psm_pa_pipe.pipe_h, mixer_input_queue_h, mixer_input_index)) != ISMD_SUCCESS) {
         AUDIO_ERROR("psm_input_queue_add failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         
         /* Mark this input as added to the post ATC pipe.  */
         input_wl->added_to_post_atc_pipe = true;

         /* If the pipe is running, need to update just the host side.
            Else we need update the DSP copy which gets picked up when the
            pipe starts. This is because we just keep 1 copy of the mixer coeff in
            the host params to save some major space. */
         if (input_wl->processor_wl->psm_pa_pipe.pipe_configured ) {
            if (is_associated_stream && input_wl->psm_ms10_pipe_assoc.dual_ch_mix != ISMD_AUDIO_DDC_SINGLE_INPUT_DUAL_CH_MIX_ASSOC) {
               // Do not update associated audio mixer_coeff, if not CH_MIX_DUP or CH_MIX_MAIN mode.
            }            
            else {
               input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.channel_mix_config = input_wl->mixer_coeff;
               input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.input_index = mixer_input_index;       
            }
            
         }
         else {
            if(is_associated_stream) {
               switch(input_wl->psm_ms10_pipe_assoc.dual_ch_mix) {
                  case ISMD_AUDIO_DDC_SINGLE_INPUT_DUAL_CH_MIX_DUP:
                     // add ch_mixer into associated audio index.
                     input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.input_config[mixer_input_index].channel_mix_config = input_wl->mixer_coeff;
                     break;
                  case ISMD_AUDIO_DDC_SINGLE_INPUT_DUAL_CH_MIX_MAIN:
                      // no need special for associated audio. 
                     break;
                  case ISMD_AUDIO_DDC_SINGLE_INPUT_DUAL_CH_MIX_ASSOC:
                     // clear main audio ch_mixer_coeff
                     // add associated audio ch mixer_coeff.
                     input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.input_config[input_wl->mixer_input_index].channel_mix_config = input_wl->processor_wl->default_mix_coeff;
                     input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.input_config[mixer_input_index].channel_mix_config = input_wl->mixer_coeff;
                     break;
                  default:
                     break;
                 }
            }
            else {
                  input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.input_config[input_wl->mixer_input_index].channel_mix_config = input_wl->mixer_coeff;
            }
         }
         

         /*If its a secondary stream associated with the input, no need to update primary, secondary again.*/
         if(!is_associated_stream) {
            if ( input_wl->input_type == AUDIO_INPUT_TYPE_PRIMARY ) {
               wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.primary_index = input_wl->mixer_input_index;
               wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.primary_index = input_wl->mixer_input_index;
            }
            else if ( input_wl->input_type == AUDIO_INPUT_TYPE_SECONDARY ) {
               wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.secondary_index = input_wl->mixer_input_index;
            }
         }

         //Set the SRC output sampling rate if in AUTO mode.
         if(wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.mix_src_mode == ISMD_AUDIO_MIX_SAMPLE_RATE_MODE_AUTO){

            //If all output sample rates match just set the sampling rate to the that rate. 
            if(output_configs->output_fs_match){
               wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.output_sample_rate[mixer_input_index] = output_configs->outputs[0].sample_rate;
            }
            //If they dont match, put everything down to 48kHz, for now. This can be optmized to look
            //at each output and decide the best rate to convert to. Difficult because we dont know the input sampling rate.
            else{
               wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.output_sample_rate[mixer_input_index] = 48000;
            }
         }

         //The SRC needs to fire events. Give each input the pointer to the notification events.
         //This pointer will only be used on IA so no need to translate the address for the DSP.
         wl->psm_pa_pipe.stages[SRC_STAGE].conn_mda.input[mixer_input_index] = (int)input_wl->notification_events;

         //Update the SRC quality parameter. 
         wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.src_quality = wl->src_quality;

         /*Notify the decoders about the downmix modes*/
         audio_input_notify_decoder_of_dmix_modes(input_wl, output_configs);
      }

      /* Commit the stage info if the post ATC PSM pipe is running. */
      if(wl->psm_pa_pipe.pipe_configured) {
         wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.coeff_changed++;
         if((result = audio_psm_stage_config_direct(wl->psm_pa_pipe.pipe_h, mixer_stage->handle, &mixer_stage->params)) == ISMD_SUCCESS){
            result = audio_psm_stage_config(wl->psm_pa_pipe.pipe_h, src_stage->handle, &src_stage->params);
         }
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


static  ismd_result_t
audio_pvt_connect_pre_mixer_stages(ismd_audio_processor_context_t *wl, audio_psm_output_configs_t *output_configs)
{
   ismd_result_t result = ISMD_SUCCESS;
   int mixer_input_index = 0;
   ismd_audio_input_wl_t *input_wl = NULL;

   //Handle connections up to the mixer
   for(mixer_input_index = 0; mixer_input_index < AUDIO_MAX_INPUTS; mixer_input_index++) {

       /* Connect the input to the deinterleaver stage */
      if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                          wl->psm_pa_pipe.stages[INPUT_STAGE].handle, 
                          mixer_input_index,
                          wl->psm_pa_pipe.stages[DEINTERLVR_STAGE].handle, 
                          mixer_input_index)) != ISMD_SUCCESS) {

         AUDIO_ERROR("input -deintrlv connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /* Connect the the deinterleaver to the SRC stage */
      else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                          wl->psm_pa_pipe.stages[DEINTERLVR_STAGE].handle, 
                          mixer_input_index,
                          wl->psm_pa_pipe.stages[SRC_STAGE].handle, 
                          mixer_input_index)) != ISMD_SUCCESS) {

         AUDIO_ERROR("deintrlv- src connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /* Connect the the SRC to the mixer's input */
      else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                          wl->psm_pa_pipe.stages[SRC_STAGE].handle,  
                          mixer_input_index,
                          wl->psm_pa_pipe.stages[MIXER_STAGE].handle,  
                          mixer_input_index)) != ISMD_SUCCESS) {

         AUDIO_ERROR("src - mixer connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
      } 

      else {

         /* Get the workload of this specific input. */
         input_wl = &wl->inputs[mixer_input_index];

         /* Need to add the input if it is in use. */
         if(input_wl->in_use) {       
            result = audio_processor_psm_pipe_add_input(input_wl, mixer_input_index, output_configs);
         }
      }
   }
   
   return result;
}



static  ismd_result_t
audio_pvt_connect_ddco_test_mode_pipe(ismd_audio_processor_context_t *wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
   int i;

   //Disable all other stages except for the encoder. INPUT/OUTPUT always on.
   wl->psm_pa_pipe.stages[DEINTERLVR_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[SRC_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[MIXER_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[WATERMARK_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[BASS_MAN_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[INTERLVR_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[PACKETIZE_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[DATA_DIV_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[ENCODE_STAGE].in_use = true;

   audio_timing_control_set_silence_insert(wl->atc_h, false);
   audio_timing_control_set_output_discard_policy(wl->atc_h, ATC_OUTPUT_DISCARD_NEVER);
   wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.packetize_output = false;

   /* Search for the first usable input  */
   for(i = 0; i < AUDIO_MAX_INPUTS; i++) {
      /* Add 1 input queue only!Its all this mode supports */
      if( wl->inputs[i].in_use){
         if((result = audio_psm_input_queue_add(wl->psm_pa_pipe.pipe_h, wl->inputs[i].atc_out_queue_h, 0)) != ISMD_SUCCESS) {
            AUDIO_ERROR("psm_input_queue_add failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }  
         break;
      }
   }

   /* Only add/config the stage if we have flagged it that we needed it */       
   if((result = audio_psm_stage_add(wl->psm_pa_pipe.pipe_h, 
                       wl->psm_pa_pipe.stages[INPUT_STAGE].task, 1,1, 
                       &(wl->psm_pa_pipe.stages[INPUT_STAGE].handle))) != ISMD_SUCCESS) {

      AUDIO_ERROR("psm_stage_add add failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   else if((result = audio_psm_stage_add(wl->psm_pa_pipe.pipe_h, 
                       wl->psm_pa_pipe.stages[ENCODE_STAGE].task, 1,1, 
                       &(wl->psm_pa_pipe.stages[ENCODE_STAGE].handle))) != ISMD_SUCCESS) {

      AUDIO_ERROR("psm_stage_add add failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_psm_stage_add(wl->psm_pa_pipe.pipe_h, 
                       wl->psm_pa_pipe.stages[OUTPUT_STAGE].task, 1,1, 
                       &(wl->psm_pa_pipe.stages[OUTPUT_STAGE].handle))) != ISMD_SUCCESS) {

      AUDIO_ERROR("psm_stage_add add failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                    wl->psm_pa_pipe.stages[INPUT_STAGE].handle, 0, 
                    wl->psm_pa_pipe.stages[ENCODE_STAGE].handle, 0)) != ISMD_SUCCESS) {

      AUDIO_ERROR("INPUT_STAGE -ENCODE_STAGE connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   else if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
                 wl->psm_pa_pipe.stages[ENCODE_STAGE].handle, 0, 
                 wl->psm_pa_pipe.stages[OUTPUT_STAGE].handle, 0)) != ISMD_SUCCESS) {

      AUDIO_ERROR("ENCODE_STAGE -OUTPUT_STAGE connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   else if((result = audio_psm_stage_config(wl->psm_pa_pipe.pipe_h, 
                 wl->psm_pa_pipe.stages[ENCODE_STAGE].handle, 
                 &wl->psm_pa_pipe.stages[ENCODE_STAGE].params)) != ISMD_SUCCESS) {

      AUDIO_ERROR("audio_psm_stage_config failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   if(result == ISMD_SUCCESS) {

      /*If we have more than 1 output, add all of them to recieve the DDCO test mode output!*/
      for(i = 0; i < AUDIO_MAX_OUTPUTS; i++) {

         if( wl->outputs[i].in_use) {
            if((result = audio_psm_output_queue_add(wl->psm_pa_pipe.pipe_h, wl->outputs[i].psm_output_queue, 0)) != ISMD_SUCCESS) {
               AUDIO_ERROR("psm_input_queue_add failed", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
            }  
         }
      }
   }
   
   return result;
}

static bool 
outputs_match(psm_output_t *output, psm_output_t *output1)
{
   bool result = false;
   
   //Dont include the queue number in the match. 
   if(output->encode_format != output1->encode_format){
   }
   else if(output->sample_rate != output1->sample_rate){
   }
   else if(output->sample_size != output1->sample_size){
   }
   else if(output->channel_count != output1->channel_count){
   }
   else if(output->channel_map != output1->channel_map){
   }
   else if(output->matrix_dec_enabled != output1->matrix_dec_enabled){
   }
   else if(output->dmix_mode != output1->dmix_mode){
   }
   else{
      result = true;
   }
   
   return result;
}

static void
audio_pvt_check_for_duplicate_configs(audio_psm_output_configs_t *output_configs)
{
   int i = 0, j = 0;

   for(i = 0; i < output_configs->count; i++) { 

      if(output_configs->outputs[i].duplicate_index == NO_DUPLICATE_OUTPUT) {
         
         for(j = 0; j < output_configs->count; j++) {
            
            //Make sure we arent comparing the same config and that the one we are comparing is in use.
            if((i != j) && output_configs->outputs[j].in_use) {

               //If the outputs have the same config, need to ensure we know its a duplicate configuration.
               if(outputs_match(&output_configs->outputs[i], &output_configs->outputs[j])){

                  //Need to make sure we only mark the SW as duplicates when HW is present.
                  if(!output_configs->only_have_sw_output) {
                     
                     if(!output_configs->outputs[i].is_sw_output) {                  
                        output_configs->outputs[j].duplicate_index = i;
                     }
                  }
                  else{
                     output_configs->outputs[j].duplicate_index = i;
                  }
               }          
            }
         }
      }  
   }
   return;   
}


static bool 
outputs_match_enc_dec(psm_output_t *output, psm_output_t *output1)
{
   bool result = false;

   /* Check to see if outputs match format for encoder/matrix decoder. */
   if(output->is_encoder_output || output1->is_encoder_output || output->matrix_dec_enabled || output1->matrix_dec_enabled) {
      
      if(output->encode_format != output1->encode_format){
      }
      else if(output->matrix_dec_enabled != output1->matrix_dec_enabled){
      }
      else{
         result = true;
      }
   }
   return result;
}


static void
audio_pvt_check_for_duplicate_enc_dec_configs(audio_psm_output_configs_t *output_configs)
{
   int i = 0, j = 0;

   for(i = 0; i < output_configs->count; i++) { 

      if(output_configs->outputs[i].duplicate_index == NO_DUPLICATE_OUTPUT) {
         
         for(j = 0; j < output_configs->count; j++) {
            
            //Make sure we arent comparing the same config and that the one we are comparing is in use.
            if((i != j) && output_configs->outputs[j].in_use) {

               //If the outputs have the same config, need to ensure we know its a duplicate configuration.
               if(outputs_match_enc_dec(&output_configs->outputs[i], &output_configs->outputs[j])){

                  //Need to make sure we only mark the SW as duplicates when HW is present.
                  if(!output_configs->only_have_sw_output) {

                     /*If the output we are checking is HW and we find a duplicate, mark it.*/
                     if(!output_configs->outputs[i].is_sw_output) {                  
                        output_configs->outputs[j].duplicate_index = i;
                     }
                  }
                  else{
                     output_configs->outputs[j].duplicate_index = i;
                  }
               }          
            }
         }
      }  
   }
   return;   
}


static bool
audio_pvt_output_sample_rates_match(audio_psm_output_configs_t *output_configs)
{
   int i = 0, sample_rate = 0;
   bool result = true;

   //Only test if more than one output. 
   if(output_configs->count > 1) {
      
      for(i = 0; i < output_configs->count; i++) { 

         //Grab the first sample rate to compare to all. 
         if(i == 0){
            sample_rate = output_configs->outputs[i].sample_rate;
         }
         //Check the same sample rate against all other outputs. 
         if( sample_rate != output_configs->outputs[i].sample_rate){
            result = false;
            break;
         }     
      }
   }

   return result;
}

static bool
output_acceptable_for_neo6(ismd_audio_processor_context_t *wl, psm_output_t *output)
{
   bool result = false;
   audio_neo6_management_params_t *neo6_params = &wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].params.decoder.host.codec.config.neo6_params;

   //Need to check to see if the sample rate and channle count is supported by
   //the NEO6 decoder, if it is enable NEO6 for this output. As of now the 
   //sample rates supported by NEO6 are listed in the switch statement. 
   if( wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].in_use){

      switch(output->sample_rate){
         case 32000:
         case 44100:
         case 48000:
         case 64000:
         case 88200:
         case 96000:

            /*Ensure that we dont have an encoded output.*/
            if((int)output->encode_format == (int)ISMD_AUDIO_MEDIA_FMT_INVALID) {
               
               if(((neo6_params->channels <= 6) && (output->channel_count == 6)) ||((neo6_params->channels == 7) && (output->channel_count == 8))){
                  neo6_params->samplerate = output->sample_rate;
                  output->matrix_dec_enabled = true;
                  result = true;
               }
            }
            
            break;
         default:
            break;
      }
   }

   return result;
}


static bool
output_acceptable_for_srs (psm_output_t *output)
{
   bool result = false;

   switch(output->sample_rate){
      case 32000:
      case 44100:
      case 48000:
         if (output->channel_count==2){
            result = true;           
         }
         break;
      default:
         break;
   } 
   return result;
}


void
audio_set_fast_output_mode(ismd_audio_processor_context_t *wl)
{
   int enable_atc_fast_output = false;
   
   //If the application goes and removes all the outputs, then adds them again, so on a certain
   //scenario there could be NO outputs, we don't want to switch over fast mode when we transition from
   //having outputs, to no outputs, but when we do have outputs attached, make sure we modify these.	   

   // The ATC fast output mode should be disabled for timed input streams.	
   // The ATC fast output mode should be disabled for timed output streams. 	
   // In the case of multiple Inputs and SW output the ATC fast output enqueue will not be aligned. 			  
   // This can lead to misaligned data in the post ATC pipeline (eg: for secondary stream mixing purpose). 
   // Hence the ATC fast output mode should be disabled.  
   // In the case of SW output and just one untimed input, the ATC Fast output mode should be enabled.			   
  if((wl->timed_input_count == 0) && (wl->output_configs.only_have_sw_output) && (wl->input_count <=1)) {
     enable_atc_fast_output = true;
  }

  // Set the fast output mode only if the state changed. 
  if (wl->enable_atc_fast_output != enable_atc_fast_output) {
     wl->enable_atc_fast_output = enable_atc_fast_output;
     audio_timing_control_set_fast_output(wl->atc_h, wl->enable_atc_fast_output);
  }	  
	
}

static  ismd_result_t
audio_pvt_read_output_configs(ismd_audio_processor_context_t *wl, audio_psm_output_configs_t *output_configs)
{
   ismd_result_t result = ISMD_SUCCESS;
   int loop = 0;
   int total_outputs_in_use = 0;
   atc_output_discard_policy_t discard_policy = 0;
   bool matrix_decoder_enabled = wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].in_use;
   bool sw_encode_out = false;
   bool hw_encode_out = false;
   
   //Scanning all output and matching the config to that output.
   //Since we are locked with the processor we dont need to lock down the outputs for this read.
   for(loop = 0; loop < AUDIO_MAX_OUTPUTS; loop++) {

      if(wl->outputs[loop].in_use ) {

         //Need to see if we only have a SW output.
         /// TODO: COMMENT THIS IN DETAIL...
         if(!wl->outputs[loop].is_sw_output) {
            output_configs->only_have_sw_output = false;
         }
        
         //Scan for all non passthrough outputs, get our configs.
         if(wl->outputs[loop].output_mode != ISMD_AUDIO_OUTPUT_PASSTHROUGH) {

            output_configs->outputs[output_configs->count].output_handle = wl->outputs[loop].handle;
            output_configs->outputs[output_configs->count].in_use = true;
            output_configs->outputs[output_configs->count].channel_count = wl->outputs[loop].channel_count;
            output_configs->outputs[output_configs->count].sample_size = wl->outputs[loop].sample_size;
            output_configs->outputs[output_configs->count].sample_rate = wl->outputs[loop].sample_rate;
            output_configs->outputs[output_configs->count].hw_id = wl->outputs[loop].hw_id;

            /* Check for encoded outputs. */
            if(wl->outputs[loop].output_mode == ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL){
               output_configs->outputs[output_configs->count].encode_format = ISMD_AUDIO_ENCODE_FMT_AC3;
            }
            if(wl->outputs[loop].output_mode == ISMD_AUDIO_OUTPUT_ENCODED_DTS){
               output_configs->outputs[output_configs->count].encode_format = ISMD_AUDIO_ENCODE_FMT_DTS;
            }
            if(wl->outputs[loop].output_mode == ISMD_AUDIO_OUTPUT_ENCODED_AAC){
               output_configs->outputs[output_configs->count].encode_format = ISMD_AUDIO_ENCODE_FMT_AAC;
            }

            if((int)output_configs->outputs[output_configs->count].encode_format != (int)ISMD_AUDIO_MEDIA_FMT_INVALID) {
               /*Flag this as an encoded output, take note of SW or HW output.*/
               output_configs->outputs[output_configs->count].is_encoder_output = true;
               (wl->outputs[loop].is_sw_output) ? (sw_encode_out = true) : (hw_encode_out = true);
            }

            //Get the dmix standard from the output.
            output_configs->outputs[output_configs->count].dmix_mode = wl->outputs[loop].dmix_mode;

            //If we have a SW output, get the channel map if specified. Its already been validated in add_output_port. 
            if(wl->outputs[loop].is_sw_output && (wl->outputs[loop].ch_map != 0)) {
               output_configs->outputs[output_configs->count].channel_map = wl->outputs[loop].ch_map;
            }
            
            //Record the queue associated with this output.
            output_configs->outputs[output_configs->count].output_queue = wl->outputs[loop].psm_output_queue;

            //If its a HW output, make sure we force sample sizes. 
            if(!wl->outputs[loop].is_sw_output){
               
               if(wl->outputs[loop].sample_size <= 16){
                  output_configs->outputs[output_configs->count].sample_size = 16;
               }
               else{
                  output_configs->outputs[output_configs->count].sample_size = 32;
               }
            }
            else{
               output_configs->outputs[output_configs->count].is_sw_output = true;
            }

            /* Right now we are just checking for NEO6, in the future if we have more matrix decoders, 
               need to check based on the decoder enabled. */
            if( matrix_decoder_enabled ) {
               output_configs->outputs[output_configs->count].matrix_dec_enabled = output_acceptable_for_neo6(wl, &output_configs->outputs[output_configs->count]);
            }

            //Check for SRS stage enabling
            if(output_acceptable_for_srs(&output_configs->outputs[output_configs->count]) && (wl->outputs[loop].srs_context_info != AUDIO_INVALID_HANDLE)) {
               output_configs->outputs[output_configs->count].srs_output_context = wl->outputs[loop].srs_context_info;
            }

            output_configs->outputs[output_configs->count].delay_ms = wl->outputs[loop].delay_ms;            

            /*We are updating this count based on NON passthrough outputs only.*/
            output_configs->count++;
         }
         /* Updating the count of ALL outputs in use. */
         total_outputs_in_use++;
      }
   }

   /*Set the flag that tells us if we have both HW and SW encode outputs.*/
   output_configs->have_dual_encoder_output = (sw_encode_out && hw_encode_out) ? true:false;

   //Check for duplicate output configurations, and if we have matching sample rates. 
   if(output_configs->count > 1){
      output_configs->output_fs_match = audio_pvt_output_sample_rates_match(output_configs);

      //TODO: We need to only check for duplicates if its an encoded path or NEO6 output enabled. 
      // Since we cant have the encoder and decoder decode twice. If the need arises in the future
      // need to break this out if per output delay needs to occur on outputs that are encoded or matrix decoded. 
      audio_pvt_check_for_duplicate_enc_dec_configs(output_configs);

      //This was the only method of checking for a complete match, not used currently.
      (void) audio_pvt_check_for_duplicate_configs;
   }

   //If we have no outputs, setup a default pipe so data will keep flowing.
   if(output_configs->count == 0){
      output_configs->outputs[0].in_use = true;
      output_configs->outputs[0].channel_count = 2;
      output_configs->outputs[0].sample_size = 32;
      output_configs->outputs[0].sample_rate = 48000;
      output_configs->outputs[0].output_handle = 0;//Even though we have no outputs, give a valid index since this is used to index into an array in the FW.
      output_configs->count = 1;
   }

   /* Store the working copy of the output configurations. */
   wl->output_configs = *output_configs;

   //If we are only outputting to a SW port tell ATC not to insert silence. Its important to be able 
   //to switch these values back and forth from inserting silence, because the application can add
   //a HW output at any time. So don't hard code the parameter to true. There is also the case
   //where an application goes and removes all the outputs, then adds them again, so on a certain
   //scenario there could be NO outputs, we don't want to switch these over when we transition from
   //having outputs, to no outputs, but when we do have outputs attached, make sure we modify these. 
   if(total_outputs_in_use > 0) {
      audio_timing_control_set_silence_insert(wl->atc_h, !output_configs->only_have_sw_output);
	  audio_set_fast_output_mode(wl);

      //Need to notify the ATC if we only have a SW output so it will not discard if it doesn't get render base numbers.
      discard_policy = (output_configs->only_have_sw_output) ? ATC_OUTPUT_DISCARD_NEVER:ATC_OUTPUT_DISCARD_ON_RENDER_NOT_PRESENT;
      audio_timing_control_set_output_discard_policy(wl->atc_h, discard_policy);
   }

   return result;
}

static  ismd_result_t
audio_pvt_add_stages_needed(ismd_audio_processor_context_t *wl, audio_psm_output_configs_t *output_configs)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   int i = 0;

   //Only re-init a few of the important stages at this point. However we need
   //to conisder breaking this out into a function and attempting to re-init all
   //stage attributes in the APM that need to be set back to default on a reconfig. 
   //I would call processor_psm_pipe_init here but that will cause other issues. 
   wl->psm_pa_pipe.stages[POST_SRC_STAGE].input_count = 0;
   wl->psm_pa_pipe.stages[POST_SRC_STAGE].output_count = 0;
   wl->psm_pa_pipe.stages[INTERLVR_STAGE].input_count = 0;
   wl->psm_pa_pipe.stages[INTERLVR_STAGE].output_count = 0;
   wl->psm_pa_pipe.stages[DOWNMIX_STAGE].input_count = 0;
   wl->psm_pa_pipe.stages[DOWNMIX_STAGE].output_count = 0;
   wl->psm_pa_pipe.stages[OUTPUT_STAGE].input_count = 0;
   wl->psm_pa_pipe.stages[SRS_STAGE].input_count = 0;
   wl->psm_pa_pipe.stages[SRS_STAGE].output_count = 0;
   wl->psm_pa_pipe.stages[QUALITY_STAGE].input_count = 0;
   wl->psm_pa_pipe.stages[QUALITY_STAGE].output_count = 0;
   wl->psm_pa_pipe.stages[ENCODE_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[DATA_DIV_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[DATA_DIV_MATRX_DEC_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].in_use = false;
   wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].input_count = 0;
   wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].output_count = 0;
   wl->psm_pa_pipe.stages[SRS_STAGE].in_use = false;

   for ( i = 0; i < AUDIO_MAX_INPUTS; i++ ) {

      /* Need to re-init the interleaver params. */
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[i].output_ch_count = 0;
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[i].reorder_for_hw = true;
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[i].output_ch_map = AUDIO_CHAN_CONFIG_INVALID;

      /*Need to re-init the SRC history information*/
      OS_MEMSET(&wl->psm_pa_pipe.stages[SRC_STAGE].params.src.state_info, 0, sizeof(src_44_1_to_48_state_info_t));
      OS_MEMSET(&wl->psm_pa_pipe.stages[POST_SRC_STAGE].params.src.state_info, 0, sizeof(src_44_1_to_48_state_info_t));
      wl->psm_pa_pipe.stages[SRC_STAGE].params.src.history_buf_index[i] = 0;
      wl->psm_pa_pipe.stages[SRC_STAGE].params.src.vsrc_init_flag[i] = 0;
      wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.vsrc_set_var_on[i] = 0;
      wl->psm_pa_pipe.stages[POST_SRC_STAGE].params.src.history_buf_index[i] = 0;
   }

   //Everything we need is added except any encoder stages. 
   for(i = 0; i < output_configs->count; i++) {
      
      if(output_configs->outputs[i].is_encoder_output){       
         wl->psm_pa_pipe.stages[ENCODE_STAGE].in_use = true;
         wl->psm_pa_pipe.stages[DATA_DIV_STAGE].in_use = true;
      }
      else if(output_configs->outputs[i].matrix_dec_enabled){
         wl->psm_pa_pipe.stages[DATA_DIV_MATRX_DEC_STAGE].in_use = true;
         wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].in_use = true;
      }

      if(output_configs->outputs[i].srs_output_context != AUDIO_INVALID_HANDLE){
         wl->psm_pa_pipe.stages[SRS_STAGE].input_count++;
         wl->psm_pa_pipe.stages[SRS_STAGE].output_count++;
         wl->psm_pa_pipe.stages[SRS_STAGE].in_use = true;
      }

      //If this output is not a duplicate, than add the count to these stages that are always present. 
      if(output_configs->outputs[i].duplicate_index == NO_DUPLICATE_OUTPUT){
         //update the counts for each stage.
         wl->psm_pa_pipe.stages[POST_SRC_STAGE].input_count++;
         wl->psm_pa_pipe.stages[POST_SRC_STAGE].output_count++;
			if(wl->psm_pa_pipe.stages[SRS_STAGE].in_use){
				wl->psm_pa_pipe.stages[SRS_STAGE].input_count++;
				wl->psm_pa_pipe.stages[SRS_STAGE].output_count++;
			}
         wl->psm_pa_pipe.stages[QUALITY_STAGE].input_count++;
         wl->psm_pa_pipe.stages[QUALITY_STAGE].output_count++;
         wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].input_count++;
         wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].output_count++;
         wl->psm_pa_pipe.stages[INTERLVR_STAGE].input_count++;
         wl->psm_pa_pipe.stages[INTERLVR_STAGE].output_count++;
         wl->psm_pa_pipe.stages[DOWNMIX_STAGE].input_count++;
         wl->psm_pa_pipe.stages[DOWNMIX_STAGE].output_count++;
         wl->psm_pa_pipe.stages[OUTPUT_STAGE].input_count++;
      }
   }

   /*If we have dual encode outputs, make sure output stage is updated.*/
   if(output_configs->have_dual_encoder_output ) {
      wl->psm_pa_pipe.stages[OUTPUT_STAGE].input_count++;
   }

   //Update the total output count. 
   wl->psm_pa_pipe.stages[OUTPUT_STAGE].output_count = output_configs->count;

   //Now we have all the info we need, add the stages
   result = audio_pvt_add_stages(&(wl->psm_pa_pipe)); 

   return result;  
}

static  void
audio_pvt_init_output_config_struct(audio_psm_output_configs_t *output_configs)
{
   int i = 0;
   output_configs->count = 0;
   output_configs->only_have_sw_output = true;//Until set false by read_output_configs.
   output_configs->output_fs_match = true;
   output_configs->have_dual_encoder_output = false;
      
   for(i =0; i < AUDIO_MAX_OUTPUTS; i++) {
      output_configs->outputs[i].in_use = false;
      output_configs->outputs[i].is_encoder_output = false;
      output_configs->outputs[i].encode_format = ISMD_AUDIO_MEDIA_FMT_INVALID;
      output_configs->outputs[i].matrix_dec_enabled = false;
      output_configs->outputs[i].channel_count = 0;
      output_configs->outputs[i].channel_map = 0;
      output_configs->outputs[i].is_sw_output = false;
      output_configs->outputs[i].sample_rate = 0;
      output_configs->outputs[i].sample_size = 0;
      output_configs->outputs[i].output_handle = AUDIO_INVALID_HANDLE;
      output_configs->outputs[i].srs_output_context = AUDIO_INVALID_HANDLE;
      output_configs->outputs[i].output_queue = ISMD_QUEUE_HANDLE_INVALID;
      output_configs->outputs[i].duplicate_index = NO_DUPLICATE_OUTPUT;
      output_configs->outputs[i].dmix_mode = ISMD_AUDIO_DOWNMIX_DEFAULT;
      output_configs->outputs[i].hw_id = AUDIO_INVALID_HANDLE;
   }
}


ismd_result_t
audio_processor_psm_pipe_connect_stages(ismd_audio_processor_context_t *wl)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_output_configs_t output_configs;

   //If we have special DDCO test mode, build special pipe.
   if(wl->psm_pa_pipe.ddco_test_mode_en) {
      result = audio_pvt_connect_ddco_test_mode_pipe(wl);
   }
   else {

      audio_pvt_init_output_config_struct(&output_configs);

      if((result = audio_pvt_read_output_configs(wl, &output_configs)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Reading output configs failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      //Go through and add all the stages to the PSM pipe.
      else if((result = audio_pvt_add_stages_needed(wl, &output_configs)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Could not add all POST ATC PSM pipe stages!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      //Here we connect the stages that are inputs up to the mixer
      else if((result = audio_pvt_connect_pre_mixer_stages(wl, &output_configs)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Connecting the pre mixer stages failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      // Build the post mixer pipe
      else if((result = audio_pvt_connect_post_mixer_stages(wl, &output_configs)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Connecting the POST mixer stages failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      else if((result = audio_pvt_config_stages(&wl->psm_pa_pipe)) != ISMD_SUCCESS) {
         AUDIO_ERROR("audio_pvt_config_stages failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      else if((result = audio_pvt_stages_add_conn_mda(&wl->psm_pa_pipe)) != ISMD_SUCCESS) {
         AUDIO_ERROR("audio_pvt_add_conn_mda_stages failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      
   }
   return result;
}

static void
audio_pass_through_pipe_read_output_configs(ismd_audio_processor_context_t *wl, audio_psm_output_configs_t *output_configs)
{
   int loop = 0;
   
   //Scanning all output and matching the config to that output.
   for(loop = 0; loop < AUDIO_MAX_OUTPUTS; loop++) {

      if(wl->outputs[loop].in_use ) {

         /* Always check outside the mode loop, in case an output reconfig is taking place!*/
         if(!wl->outputs[loop].is_sw_output) {
            output_configs->only_have_sw_output = false;
         }
        
         //Scan for all  passthrough outputs, get our configs.
         if(wl->outputs[loop].output_mode == ISMD_AUDIO_OUTPUT_PASSTHROUGH) {
            
            output_configs->outputs[output_configs->count].in_use = true;
            output_configs->outputs[output_configs->count].output_handle = wl->outputs[loop].handle;
            output_configs->outputs[output_configs->count].channel_count = wl->outputs[loop].channel_count;
            output_configs->outputs[output_configs->count].sample_size = wl->outputs[loop].sample_size;
            output_configs->outputs[output_configs->count].sample_rate = wl->outputs[loop].sample_rate;
            output_configs->outputs[output_configs->count].hw_id = wl->outputs[loop].hw_id;
            
            //Record the queue associated with this output.
            output_configs->outputs[output_configs->count].output_queue = wl->outputs[loop].psm_output_queue;

            //If its a HW output, make sure we force sample sizes. 
            if(!wl->outputs[loop].is_sw_output){
               
               if(wl->outputs[loop].sample_size <= 16){
                  output_configs->outputs[output_configs->count].sample_size = 16;
               }
               else{
                  output_configs->outputs[output_configs->count].sample_size = 32;
               }
            }
            else{
               output_configs->outputs[output_configs->count].is_sw_output = true;
            }         
            output_configs->outputs[output_configs->count].delay_ms = wl->outputs[loop].delay_ms;
            
            output_configs->count++;
         }
      }     
   }

   //If we have no outputs, setup a default pipe. 
   if(output_configs->count == 0){
      output_configs->outputs[0].in_use = true;
      output_configs->outputs[0].channel_count = 2;
      output_configs->outputs[0].sample_size = 32;
      output_configs->outputs[0].sample_rate = 48000;
      output_configs->outputs[0].output_handle = 0;//Even though we have no outputs, give a valid index since this is used to index into an array in the FW.
      output_configs->count = 1;
   }
   
   return ;
}

static void
audio_pass_through_pipe_init_stages(audio_psm_post_atc_pipe_t *pass_pipe)
{
   int buffer_size = 0;
   int i = 0;
   /* Initialize all stages needed for the post ATC passthrough psm pipe. */

   /* Setup passthrough input stage */
   pass_pipe->stages[INPUT_STAGE].task = PSM_TASK_IN;
   pass_pipe->stages[INPUT_STAGE].in_use = true;
   pass_pipe->stages[INPUT_STAGE].input_count = 1; //Always 1 
   pass_pipe->stages[INPUT_STAGE].output_count =  1;//Always 1

   /* Need bit depth converter for packetized data, and for PCM reformat for HDMI. */
   pass_pipe->stages[BIT_DEPTH_CONV_STAGE].task = PSM_TASK_BIT_DEPTH_CONVERTER;
   pass_pipe->stages[BIT_DEPTH_CONV_STAGE].in_use = true;
   pass_pipe->stages[BIT_DEPTH_CONV_STAGE].input_count = 1; //Always 1
   pass_pipe->stages[BIT_DEPTH_CONV_STAGE].output_count = 1; //Will be adjusted based on output cfg.
   /* Make sure to init the params */
   for(i = 0; i < AUDIO_MAX_OUTPUTS; i++) {
      pass_pipe->stages[BIT_DEPTH_CONV_STAGE].params.bit_depth_converter.context[i].output_sample_size = BIT_DEPTH_CONVERT_PASSTHROUGH;
      pass_pipe->stages[BIT_DEPTH_CONV_STAGE].params.bit_depth_converter.context[i].forced_hw_output_ch_count = 0;
   }

  /* Setup per output delay stage */
   pass_pipe->stages[PER_OUTPUT_DELAY_STAGE].task = PSM_TASK_PER_OUTPUT_DELAY;
   pass_pipe->stages[PER_OUTPUT_DELAY_STAGE].in_use = true;
   pass_pipe->stages[PER_OUTPUT_DELAY_STAGE].input_count = 1;//Will be adjusted based on output cfg
   pass_pipe->stages[PER_OUTPUT_DELAY_STAGE].output_count = 1;//Will be adjusted based on output cfg
   pass_pipe->stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.enabled = false;
   pass_pipe->stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.max_delay_ms = 0;
   
   /* Check for output delay buffer size, then enable and calculate max delay we can handle.*/
   AUDIO_CONFIG_GET_PER_OUTPUT_DELAY_BUFFER_SIZE(buffer_size);
   if(buffer_size > 0){
      pass_pipe->stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.max_delay_ms = buffer_size / (192 * 8 * 4);
      pass_pipe->stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.buffer_size = buffer_size;
      pass_pipe->stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.enabled = true;
   }
   /*Set connection metadata to 0 to be initialized, since these values index into an array for each context.*/
   for(i = 0; i < AUDIO_MAX_OUTPUTS; i++) {
      pass_pipe->stages[PER_OUTPUT_DELAY_STAGE].conn_mda.output[i] = 0;      
   }
 
   /* Always need an output. */
   pass_pipe->stages[OUTPUT_STAGE].task = PSM_TASK_OUT;
   pass_pipe->stages[OUTPUT_STAGE].in_use = true;   
   pass_pipe->stages[OUTPUT_STAGE].input_count = 1;//Will be adjusted based on output cfg
   pass_pipe->stages[OUTPUT_STAGE].output_count = 1;//Will be adjusted based on output cfg

   /* Update stage count. In post ATC passthrough we just have 4 stages. */ 
   pass_pipe->stage_count = 4;

   return;   
}


ismd_result_t
audio_processor_setup_pass_through_pipe(ismd_audio_processor_context_t *wl, ismd_audio_input_wl_t *input_wl, bool lock_outputs)
{
   ismd_result_t result = ISMD_SUCCESS;
   int loop = 0;
   audio_psm_output_configs_t output_cfgs;
   audio_psm_pipe_stage_t *input_stage = &wl->psm_pass_pipe.stages[INPUT_STAGE];
   audio_psm_pipe_stage_t *output_stage = &wl->psm_pass_pipe.stages[OUTPUT_STAGE];
   audio_psm_pipe_stage_t *bit_dept_conv_stage = &wl->psm_pass_pipe.stages[BIT_DEPTH_CONV_STAGE];
   audio_psm_pipe_stage_t *per_output_delay_stage = &wl->psm_pass_pipe.stages[PER_OUTPUT_DELAY_STAGE];

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(wl->primary_input_wl != NULL) {

      /*Ensure we have default values for the pipe.*/
      audio_pass_through_pipe_init_stages(&wl->psm_pass_pipe);

      /* Get our passthrough outputs' configuration. */
      audio_pvt_init_output_config_struct(&output_cfgs);
      audio_pass_through_pipe_read_output_configs(wl, &output_cfgs);

      /* Update stage counts here */
      bit_dept_conv_stage->input_count = output_cfgs.count;
      bit_dept_conv_stage->output_count = output_cfgs.count;
      per_output_delay_stage->input_count = output_cfgs.count;
      per_output_delay_stage->output_count = output_cfgs.count;
      output_stage->input_count = output_cfgs.count;
      output_stage->output_count = output_cfgs.count;

      /* Add all the stages now that we have our count. */
      if((result = audio_pvt_add_stages(&(wl->psm_pass_pipe))) != ISMD_SUCCESS) {
         AUDIO_ERROR("Add PSM stages failed for the pass-through pipe!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      
      /* Go through all passthrough ouptputs and adjust the pipeline based on output attributes, connect the rest of the pipe. */
      for(loop = 0; loop < output_cfgs.count; loop++) {

            /* Every passthrough output needs an independent path after the input from the bit depth converter stage because of the per output delay. Connect them here.*/
            if((result = audio_psm_stage_connect(wl->psm_pass_pipe.pipe_h, input_stage->handle, 0, bit_dept_conv_stage->handle, loop)) != ISMD_SUCCESS) {
               AUDIO_ERROR("input -pass input to bit conv stages connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }  
            else if((result = audio_psm_stage_connect(wl->psm_pass_pipe.pipe_h, bit_dept_conv_stage->handle, loop, per_output_delay_stage->handle, loop)) != ISMD_SUCCESS) {
               AUDIO_ERROR("input -pass  bit conv to per output delay stages connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
            else if((result = audio_psm_stage_connect(wl->psm_pass_pipe.pipe_h, per_output_delay_stage->handle, loop, output_stage->handle, loop)) != ISMD_SUCCESS) {
               AUDIO_ERROR("input -pass  bit conv to per output delay stages connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
            else {

               /* Add the output queue to PSM pipe, if we have a valid queue. */
               if(output_cfgs.outputs[loop].output_queue != ISMD_QUEUE_HANDLE_INVALID) {
                  if((result = audio_psm_output_queue_add(wl->psm_pass_pipe.pipe_h, output_cfgs.outputs[loop].output_queue, loop)) != ISMD_SUCCESS){
                     AUDIO_ERROR("psm_input_queue_add failed", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
               
               /*By default convert to 32b (encoded and HDMI req'd), unless we have PCM.*/
               bit_dept_conv_stage->params.bit_depth_converter.context[loop].output_sample_size = 32;      
                             
               /* If our primary input's format is PCM specify output sample size of bit depth converter, and force HW channel reorder if a HW output */
               if((wl->primary_input_wl->format == ISMD_AUDIO_MEDIA_FMT_PCM) || 
                  (wl->primary_input_wl->format == ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM) || 
                  (wl->primary_input_wl->format == ISMD_AUDIO_MEDIA_FMT_DVD_PCM)) {

                  if( output_cfgs.outputs[loop].hw_id != GEN3_HW_OUTPUT_HDMI){
                     bit_dept_conv_stage->params.bit_depth_converter.context[loop].output_sample_size = output_cfgs.outputs[loop].sample_size;
                  }

                  /*Only force the channel map if its NOT a SW output AND its PCM! Note the HW's output channel count for the remap if needed. */
                  if(!output_cfgs.outputs[loop].is_sw_output) {
                     bit_dept_conv_stage->params.bit_depth_converter.context[loop].forced_hw_output_ch_count = output_cfgs.outputs[loop].channel_count;
                  }
               } 

               /* If this is a SW output just put the bit depth converter in passthrough mode */
               if(output_cfgs.outputs[loop].is_sw_output){
                 bit_dept_conv_stage->params.bit_depth_converter.context[loop].output_sample_size = BIT_DEPTH_CONVERT_PASSTHROUGH;
               }

               /* Need to associate per_output_delay context with the output its tied to. Use the output handle for this. */
               per_output_delay_stage->conn_mda.output[loop] = output_cfgs.outputs[loop].output_handle;              
               per_output_delay_stage->params.per_output_delay.output_params[per_output_delay_stage->conn_mda.output[loop]].buffer_reset = true;
               per_output_delay_stage->params.per_output_delay.host.per_output_delay.host_output_params[per_output_delay_stage->conn_mda.output[loop]].new_delay = 
                  output_cfgs.outputs[loop].delay_ms;
               
            }
      }

      /* Finally commit stage configuration, and start the pipe.*/
      if(result == ISMD_SUCCESS){
         
         if((result = audio_pvt_config_stages(&(wl->psm_pass_pipe))) != ISMD_SUCCESS) {
            AUDIO_ERROR("Add PSM stages failed for the pass-through pipe!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else if((result = audio_pvt_stages_add_conn_mda(&wl->psm_pass_pipe)) != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_pvt_add_conn_mda_stages failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         /* Add the ATC passthrough queue to the input of the PSM passthrough pipe.*/
         else if((result = audio_psm_input_queue_add(wl->psm_pass_pipe.pipe_h, wl->primary_input_wl->pass_atc_out_queue_h, 0)) != ISMD_SUCCESS) { 
            AUDIO_ERROR("psm_input_queue_add failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }

          /* Finally start the Post ATC passthrough pipe.*/
         else if((result = audio_processor_start_post_atc_pipe(wl, wl->psm_pass_pipe.pipe_h, lock_outputs)) != ISMD_SUCCESS){
            AUDIO_ERROR("start_post_atc_pipe pass through failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else {
            wl->psm_pass_pipe.pipe_configured = true;
         }

         /* Here we need to take care of starting the input's packetizer pipe, if needed. */
         if((input_wl != NULL) && (result == ISMD_SUCCESS)){

            /*Update the input packetizer stage with proper output info.*/
            if((input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].task == PSM_TASK_PACKETIZE_ENCODED_DATA) &&
               input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].in_use)
            {          
               /*Set the new parameters.*/
               input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].params.packetizer.host.packetize.init_done = false;
               input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].params.packetizer.host.packetize.expand_for_hw = !output_cfgs.only_have_sw_output;
               /*If the primary input is a physical input, and passthrough mode direct is set, force expand_for_hw to false, 
                 this will disable HW formatting (byte swap) since already correct endianess.*/
               if(!input_wl->is_sw_input && (input_wl->pass_through_mode == ISMD_AUDIO_PASS_THROUGH_MODE_DIRECT)) {
                  input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].params.packetizer.host.packetize.expand_for_hw = false;
               }  
               /*if no passthrough output is enabled, just assign a sample rate to allow data to flow in DSP.*/
               input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].params.packetizer.host.packetize.pass_through_sample_rate = (output_cfgs.count > 0)?output_cfgs.outputs[0].sample_rate:48000;
               
               /*Commit the new params to packetizer pipe.*/
               if (input_wl->psm_dec_pipe.pipe_started) { 
                  if((result = audio_psm_stage_config_direct(input_wl->psm_dec_pipe.pipe_h, 
                                      input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].handle, 
                                      &input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].params)) != ISMD_SUCCESS) 
                  {
                     AUDIO_ERROR("audio_psm_stage_config for the Packetizer stage failed", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
            } 
         }
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


/*********************************************************************************************/


/*********************************************************************************************/
/* Private Audio Functions*/
/*********************************************************************************************/

static ismd_result_t
audio_pvt_alloc_stage_param_buffer(audio_psm_post_atc_pipe_t *pipe)
{
   ismd_result_t result = ISMD_SUCCESS;
   unsigned int i = 0;

   // TODO: Do an analysis of how much memory we can give back based on how much each stage needs for params.
   // TODO: Convert more backend stages to this method. 

            
   /* Allocate a buffer via PSM, to get a compatable PSM buffer descriptor.*/
   if((result = audio_psm_buffer_allocate(&pipe->stages[QUALITY_STAGE].params.params_buffer, AUDIO_QUALITY_PARAMS_BUFFER_SIZE)) == ISMD_SUCCESS) {      
      //Initialize the Audio quality instances.
      for(i = 0; i < AUDIO_QUALITY_MAX_CONTEXTS; i++) {
         audio_quality_pipe_init(&(((audio_quality_params_t *)(((ismd_buffer_descriptor_t *)pipe->stages[QUALITY_STAGE].params.params_buffer.smd_buf_desc)->virt.base))->context[i]));             
      }
   }
   return result;
}

static void
audio_pvt_free_stage_param_buffer(audio_psm_post_atc_pipe_t *pipe)
{
      
   if(pipe->stages[QUALITY_STAGE].params.params_buffer.smd_buf_desc != NULL){
      audio_psm_buffer_free(&pipe->stages[QUALITY_STAGE].params.params_buffer);
   }
   return ;
}

static ismd_result_t
audio_pvt_processor_psm_pipe_init(ismd_audio_processor_context_t *wl)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   int dolby_dmix_echo = false;
   int buffer_size = 0;
   int i;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   //See if we need to execute the downmix echo or not.
   AUDIO_CONFIG_GET_DOLBY_DMIX_EHCO(dolby_dmix_echo);

   /* In this function we simply add all the necessary stages for the post ATC pipe and put everything to 1 input and 1 output.
       as inputs and outputs are added we will modify these stages.
     */

   if((result = audio_psm_pipe_alloc(PSM_PIPE_TYPE_POST_ATC, &(wl->psm_pa_pipe.pipe_h))) != ISMD_SUCCESS) {
      AUDIO_ERROR("audio_psm_pipe_alloc failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_psm_pipe_set_input_queue_lock(wl->psm_pa_pipe.pipe_h, &wl->atc_psm_queue_lock)) != ISMD_SUCCESS) {
      AUDIO_ERROR("audio_psm_pipe_set_input_queue_lock failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else {

      /*Note EVERY stage up to the input of the mixer needs to attempt to service every input to avoid
        tearing down the PSM pipe on removal and addition of each input, so put input/output 
        count to max so each stage will attempt to service each input if its available.  Here each 
        stage before the mixer is set to MAX input and outputs for that reason. Each of these stages
        are 1 input and 1 output that is matched. So input/output is the same. */
      wl->psm_pa_pipe.stages[INPUT_STAGE].input_count =        max_num_inputs_per_processor;
      wl->psm_pa_pipe.stages[INPUT_STAGE].output_count =       max_num_inputs_per_processor;
      wl->psm_pa_pipe.stages[DEINTERLVR_STAGE].input_count =   max_num_inputs_per_processor; 
      wl->psm_pa_pipe.stages[DEINTERLVR_STAGE].output_count =  max_num_inputs_per_processor;
      wl->psm_pa_pipe.stages[SRC_STAGE].input_count =          max_num_inputs_per_processor; 
      wl->psm_pa_pipe.stages[SRC_STAGE].output_count =         max_num_inputs_per_processor;
      wl->psm_pa_pipe.stages[MIXER_STAGE].input_count =        max_num_inputs_per_processor; 

      wl->psm_pa_pipe.stages[INPUT_STAGE].task = PSM_TASK_IN;
      wl->psm_pa_pipe.stages[INPUT_STAGE].in_use = true;

      /* Need to preform a de-interleave */
      wl->psm_pa_pipe.stages[DEINTERLVR_STAGE].task = PSM_TASK_DEINTERLEAVER;
      wl->psm_pa_pipe.stages[DEINTERLVR_STAGE].in_use = true;
      /*See if we have a buffer for transition protection in the de-interleaver for this processor. */
      AUDIO_CONFIG_GET_MEMORY_LAYOUT_BUFFER_SIZE("smd_buffers_AUD_TRANS_PROTECT_", wl->handle_id, buffer_size);
      wl->psm_pa_pipe.stages[DEINTERLVR_STAGE].params.deinterleaver.trans_protection_buffer_size = buffer_size;

      /* SRC stage */
      wl->psm_pa_pipe.stages[SRC_STAGE].task = PSM_TASK_SRC;
      wl->psm_pa_pipe.stages[SRC_STAGE].in_use = true;
      wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.primary_index = AUDIO_INVALID_HANDLE;
      wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.mix_src_mode = ISMD_AUDIO_MIX_SAMPLE_RATE_MODE_AUTO;
      wl->psm_pa_pipe.stages[SRC_STAGE].params.src.auto_output_sample_rate = 48000;
      for (i = 0; i < AUDIO_MAX_INPUTS; i++)
      {
         wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.vsrc_set_var_on[i] = 0;
      }
      
      /* Post SRC stage */
      wl->psm_pa_pipe.stages[POST_SRC_STAGE].task = PSM_TASK_SRC;
      wl->psm_pa_pipe.stages[POST_SRC_STAGE].in_use = true;
      wl->psm_pa_pipe.stages[POST_SRC_STAGE].input_count = 0;
      wl->psm_pa_pipe.stages[POST_SRC_STAGE].output_count = 0;
      wl->psm_pa_pipe.stages[POST_SRC_STAGE].params.src.host.src.primary_index = AUDIO_INVALID_HANDLE;
      wl->psm_pa_pipe.stages[POST_SRC_STAGE].params.src.host.src.mix_src_mode = ISMD_AUDIO_MIX_SAMPLE_RATE_MODE_AUTO;
      wl->psm_pa_pipe.stages[POST_SRC_STAGE].params.src.auto_output_sample_rate = 48000;
      for (i = 0; i < AUDIO_MAX_INPUTS; i++)
      {
         wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.output_sample_rate[i] = 0;
         wl->psm_pa_pipe.stages[SRC_STAGE].params.src.state[i] = ISMD_AUDIO_STATUS_NO_DATA_AVAIL;
         wl->psm_pa_pipe.stages[POST_SRC_STAGE].params.src.host.src.output_sample_rate[i] = 0;
         wl->psm_pa_pipe.stages[POST_SRC_STAGE].params.src.state[i] = ISMD_AUDIO_STATUS_NO_DATA_AVAIL;
      }

      /* SRS Stage */
      wl->psm_pa_pipe.stages[SRS_STAGE].task = PSM_TASK_SRS;
      wl->psm_pa_pipe.stages[SRS_STAGE].in_use = false;
      wl->psm_pa_pipe.stages[SRS_STAGE].input_count = 0; 
      wl->psm_pa_pipe.stages[SRS_STAGE].output_count = 0;


      /* Mixer stage */
      wl->psm_pa_pipe.stages[MIXER_STAGE].task = PSM_TASK_MIX;
      wl->psm_pa_pipe.stages[MIXER_STAGE].in_use = true;
      wl->psm_pa_pipe.stages[MIXER_STAGE].output_count = 1; //ALWAYS one output only
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.coeff_changed = 1;
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.operate_in_default_mode = false;
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.primary_index = -1; /* No primary stream initially. */
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.secondary_index = -1; /* No secondary stream with mixing metadata initially. */
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_config = 0x76543210;
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_sample_size = 32; /* Mixer currenty operates only on 32-bit samples. */
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.use_stream_metadata = USE_STREAM_METADATA; /* Use or don't mixer metadata embedded in streams */
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.ch_config_mode = ISMD_AUDIO_MIX_CH_CFG_MODE_AUTO;
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.ch_config_mode_fixed_ch_cfg = 0xFFFFFFFF; /* Default mode is AUTO, dont specify a valid config */
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains_id = 0x76543210; /* Added for output_ch_gains_id initialization for per channel volume control*/
      wl->master_volume = ISMD_AUDIO_GAIN_0_DB;
      for ( i = 0; i < AUDIO_MAX_OUTPUT_CHANNELS; i++ ) {
         wl->per_channel_volume[i] = ISMD_AUDIO_GAIN_0_DB;
         wl->post_mix_ch_gain[i] = MIX_COEFF_INDEX_0_DB;
         wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.output_ch_gains[i] = MIX_COEFF_INDEX_0_DB;
      }
      /* Ensure all mixer inputs have valid default gain values. */
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.channel_mix_config = wl->default_mix_coeff;
      wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.input_index = AUDIO_INVALID_HANDLE;

      /*Updating the DSP copy here since this is called in open processor, and will be committed before running the pipe.*/
      for ( i = 0; i < AUDIO_MAX_INPUTS; i++ ) {
         wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.input_config[i].channel_mix_config = wl->default_mix_coeff;
      }

      wl->psm_pa_pipe.stages[WATERMARK_STAGE].task = PSM_TASK_WATERMARK;
      wl->psm_pa_pipe.stages[WATERMARK_STAGE].in_use = true;//Always on for now.
      wl->psm_pa_pipe.stages[WATERMARK_STAGE].input_count = 1; 
      wl->psm_pa_pipe.stages[WATERMARK_STAGE].output_count = 1;
      wl->psm_pa_pipe.stages[WATERMARK_STAGE].params.watermark.enabled = false;
      wl->psm_pa_pipe.stages[WATERMARK_STAGE].params.watermark.handle = AUDIO_INVALID_HANDLE;
      wl->psm_pa_pipe.stages[WATERMARK_STAGE].params.watermark.host_notified = false;

      wl->psm_pa_pipe.stages[BASS_MAN_STAGE].task = PSM_TASK_BM;
      wl->psm_pa_pipe.stages[BASS_MAN_STAGE].in_use = true;//Always on for now.
      wl->psm_pa_pipe.stages[BASS_MAN_STAGE].input_count = 1; 
      wl->psm_pa_pipe.stages[BASS_MAN_STAGE].output_count = 1;
      wl->psm_pa_pipe.stages[BASS_MAN_STAGE].params.bass_man.enabled = false;

         /*Delay Man Stage*/
      wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].task = PSM_TASK_DM;
      wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].in_use = true;//Always on for now.
      wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].input_count = 1;
      wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].output_count = 1;
      wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params.delay_mgmt.enabled = false;
      wl->psm_pa_pipe.stages[DELAY_MAN_STAGE].params.delay_mgmt.buffer_reset = false;

      /* Downmix */
      wl->psm_pa_pipe.stages[DOWNMIX_STAGE].task = PSM_TASK_DOWNMIX;
      wl->psm_pa_pipe.stages[DOWNMIX_STAGE].in_use = true;
      wl->psm_pa_pipe.stages[DOWNMIX_STAGE].input_count = 0; 
      wl->psm_pa_pipe.stages[DOWNMIX_STAGE].output_count = 0; 
      for ( i = 0; i < AUDIO_MAX_OUTPUTS; i++ ) {
         wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[i].dolby_cert_mode = dolby_dmix_echo;
         wl->psm_pa_pipe.stages[DOWNMIX_STAGE].params.downmixer.inputs[i].dmix_mode = ISMD_AUDIO_DOWNMIX_INVALID;
      }

      /* Audio Quality stage */
      wl->psm_pa_pipe.stages[QUALITY_STAGE].task = PSM_TASK_AUDIO_QUALITY;
      wl->psm_pa_pipe.stages[QUALITY_STAGE].in_use = true;
      wl->psm_pa_pipe.stages[QUALITY_STAGE].input_count = 0; 
      wl->psm_pa_pipe.stages[QUALITY_STAGE].output_count = 0;

      /* Need to preform an interleave */
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].task = PSM_TASK_INTERLEAVER;
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].in_use = true;
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].input_count = 0; 
      wl->psm_pa_pipe.stages[INTERLVR_STAGE].output_count = 0;
      for ( i = 0; i < AUDIO_MAX_INPUTS; i++ ) {
         wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[i].output_ch_count = 0;
         wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[i].reorder_for_hw = true;
         wl->psm_pa_pipe.stages[INTERLVR_STAGE].params.interleaver.inputs[i].output_ch_map = AUDIO_CHAN_CONFIG_INVALID;
      }

      wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].task = PSM_TASK_PER_OUTPUT_DELAY;
      wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].in_use = true;
      wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].input_count = 0; //Updated in connect stages. 
      wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].output_count = 0;

      /* Check to see if we have a buffer to support per output delay. */
      buffer_size = 0;
      AUDIO_CONFIG_GET_PER_OUTPUT_DELAY_BUFFER_SIZE(buffer_size);
      if(buffer_size > 0){
         wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.max_delay_ms = buffer_size / (192 * 8 * 4);
         wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.buffer_size = buffer_size;
         wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.enabled = true;
      }
      else {
         wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.enabled = false;
         wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.max_delay_ms = 0;
         wl->psm_pa_pipe.stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.buffer_size = 0;
      }

      wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].task = PSM_TASK_DECODE;
      wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].in_use = false;
      wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].input_count = 1; 
      wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].output_count = 1;
      wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].params.decoder.host.codec.algo = ISMD_AUDIO_MATRIX_DECODER_DTS_NEO6;
      audio_dts_neo6_set_default_decode_params(&(wl->psm_pa_pipe.stages[MATRIX_DEC_STAGE].params.decoder));

      /*The encoder will have both SW & HW bound outputs, specify outputs up front.*/
      wl->psm_pa_pipe.stages[ENCODE_STAGE].task = PSM_TASK_ENCODE;
      wl->psm_pa_pipe.stages[ENCODE_STAGE].in_use = false;
      wl->psm_pa_pipe.stages[ENCODE_STAGE].input_count = ENCODE_OUTPUT_COUNT; 
      wl->psm_pa_pipe.stages[ENCODE_STAGE].output_count = ENCODE_OUTPUT_COUNT;

      wl->psm_pa_pipe.stages[PACKETIZE_STAGE].task = PSM_TASK_PACKETIZE_ENCODED_DATA;
      wl->psm_pa_pipe.stages[PACKETIZE_STAGE].in_use = false;
      wl->psm_pa_pipe.stages[PACKETIZE_STAGE].input_count = 1; 
      wl->psm_pa_pipe.stages[PACKETIZE_STAGE].output_count = 1;

      /*This stage is for after the encoders */
      wl->psm_pa_pipe.stages[DATA_DIV_STAGE].task = PSM_TASK_DATA_DIV;
      wl->psm_pa_pipe.stages[DATA_DIV_STAGE].in_use = false;
      wl->psm_pa_pipe.stages[DATA_DIV_STAGE].input_count = 1; 
      wl->psm_pa_pipe.stages[DATA_DIV_STAGE].output_count = 1;

      /*This stage is for after the matrix decoder */
      wl->psm_pa_pipe.stages[DATA_DIV_MATRX_DEC_STAGE].task = PSM_TASK_DATA_DIV;
      wl->psm_pa_pipe.stages[DATA_DIV_MATRX_DEC_STAGE].in_use = false;
      wl->psm_pa_pipe.stages[DATA_DIV_MATRX_DEC_STAGE].input_count = 1; 
      wl->psm_pa_pipe.stages[DATA_DIV_MATRX_DEC_STAGE].output_count = 1;

      wl->psm_pa_pipe.stages[OUTPUT_STAGE].task = PSM_TASK_OUT;
      wl->psm_pa_pipe.stages[OUTPUT_STAGE].in_use = true;
      wl->psm_pa_pipe.stages[OUTPUT_STAGE].input_count = 0; //Updated in connect stages. 
      wl->psm_pa_pipe.stages[OUTPUT_STAGE].output_count = 0;

   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_open_global_processor_track(unsigned long connection, ismd_audio_processor_t *global_processor_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_t proc_handle;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = ismd_audio_open_global_processor(global_processor_h)) == ISMD_SUCCESS) {

      proc_handle = *global_processor_h; // TODO: kind of wierd here, take a look at ordering here.

      /*Register the connection giving it the input handle*/
      if((result = ismd_connection_register(connection, ismd_audio_close_processor_callback, (void*)*global_processor_h)) != ISMD_SUCCESS){

        ismd_audio_do_close_processor(proc_handle);
        AUDIO_ERROR("connection_register failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      AUDIO_ERROR("open_global_processor failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_open_processor_track(unsigned long connection, ismd_audio_processor_t *global_processor_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_t proc_handle;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = ismd_audio_open_processor(global_processor_h)) == ISMD_SUCCESS) {

      proc_handle = *global_processor_h;

      /*Register the connection giving it the input handle*/
      if((result = ismd_connection_register(connection, ismd_audio_close_processor_callback, (void*)*global_processor_h)) != ISMD_SUCCESS){

        ismd_audio_do_close_processor(proc_handle);
        AUDIO_ERROR("connection_register failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      AUDIO_ERROR("open_processor failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;

}

void
ismd_audio_close_processor_callback(void *data)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_t processor_h =  UNALIAS_GLOBAL_H((ismd_audio_processor_t) data);

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(apm_initialized){

      if((result = ismd_audio_do_close_processor(processor_h)) != ISMD_SUCCESS) {

         AUDIO_ERROR("audio_close_processor callback failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return;
}
ismd_result_t
audio_apm_suspend(ismd_audio_processor_context_t* proc_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t* input_wl = NULL;
   ismd_audio_output_wl_t* output_wl = NULL;
   int i = 0;

   /*Suspend starting at the front (inputs) and work to the end (outputs)*/

   /*Stop all the inputs*/
   for(i = 0; i < proc_wl->input_count; i++) {
      input_wl = &(proc_wl->inputs[i]);
      if (input_wl->in_use) {
         if (ISMD_SUCCESS != (result = audio_input_suspend(input_wl))) {
            AUDIO_ERROR("audio_input_suspend failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }

   /*Put the timing control in suspend mode.*/
   if(ISMD_SUCCESS != (result = audio_timing_control_suspend())){
      AUDIO_ERROR("audio_timing_control_suspend failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Free the PCM post processing pipe*/
   if(proc_wl->psm_pa_pipe.pipe_h != AUDIO_INVALID_HANDLE){
      if((result = audio_psm_pipe_free(proc_wl->psm_pa_pipe.pipe_h))  != ISMD_SUCCESS){
         AUDIO_ERROR("Post atc audio_psm_pipe_free failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      proc_wl->psm_pa_pipe.pipe_configured = false;
   }

   /* Suspend all the outputs in use.*/
   for(i = 0; i < proc_wl->output_count; i++) {
      output_wl = &(proc_wl->outputs[i]);
      if (output_wl->in_use) {
         if(ISMD_SUCCESS != (result = audio_output_suspend(output_wl))){
            AUDIO_ERROR("audio_output_suspend failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }
   return result;
}

ismd_result_t
audio_apm_resume(ismd_audio_processor_context_t* proc_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t* input_wl = NULL;
   ismd_audio_output_wl_t* output_wl = NULL;
   int loop = 0;

   /*Resume starting at the end (outputs) and work to the front (inputs)*/

   /*Resume the outputs*/
   for(loop = 0; loop < proc_wl->output_count; loop++) {
      output_wl = &(proc_wl->outputs[loop]);

      if (output_wl->in_use) {
         if(ISMD_SUCCESS != (result = audio_output_resume(output_wl))){
            AUDIO_ERROR("audio_output_suspend failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }

   /*Start the PCM post processing pipe*/
   if(proc_wl->psm_pa_pipe.pipe_h != AUDIO_INVALID_HANDLE) {
      if (ISMD_SUCCESS != (result = audio_pvt_processor_post_atc_pipe_setup_and_start(proc_wl, true))) {
         AUDIO_ERROR("audio_pvt_processor_post_atc_pipe_setup_and_start failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   /*Start ATC back up*/
   if(ISMD_SUCCESS != (result = audio_timing_control_resume())) {
      AUDIO_ERROR("audio_timing_control_resume failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Finally start up all the inputs.*/
   for (loop = 0; loop < proc_wl->input_count; loop++) {
      input_wl = &(proc_wl->inputs[loop]);
      if(ISMD_SUCCESS != (result = audio_input_resume(input_wl))){
         AUDIO_ERROR("audio_input_resume failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   

   
   return result;
}

ismd_result_t ismd_audio_suspend(void)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t* wl = NULL;
   int handle = 0;

   /* enumator all processors, asking whether ready to suspend? */
   for(handle=0; handle<AUDIO_MAX_PROCESSORS; handle++)
   {
      wl = &(processor_context[handle]);
      audio_processor_lock(wl);
      if (wl->in_use) {
         if ((result = audio_apm_suspend(wl))!= ISMD_SUCCESS) {
             /* break out*/
             handle = AUDIO_MAX_PROCESSORS;
         }
      }
      audio_processor_unlock(wl);
   }

   audio_psm_suspend();
   /*clock-gate TX0/TX1/TX2 */
   audio_render_hw_set_power_mode(AUDIO_HAL_PM_GATE);

   /*clock-gate RX0 */
   audio_capture_hw_set_power_mode(AUDIO_HAL_PM_GATE);

   return result;
}

ismd_result_t ismd_audio_resume(void)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t* wl = NULL;
   int handle = 0;

   /**************************************************************************
   **start TX0/TX1/TX2/RX0
   *****************************************************************************/

   audio_render_hw_set_power_mode(AUDIO_HAL_PM_POWER_ON);

   audio_capture_hw_set_power_mode(AUDIO_HAL_PM_POWER_ON);
   /****************************************************************************
    * startup DSP
   *****************************************************************************/
   audio_psm_resume();

   if((result = audio_hal_init(audio_devh[AUDIO_DEBUG_RENDER])) != ISMD_SUCCESS) {
      AUDIO_ERROR("audio_hal_init failed in core init!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   /* enumator all processors, asking whether ready to suspend? */
   for(handle=0; handle<AUDIO_MAX_PROCESSORS; handle++)
   {
      wl = &(processor_context[handle]);
      audio_processor_lock(wl);
      if (wl->in_use) {
         if ((result = audio_apm_resume(wl))!= ISMD_SUCCESS) {
            /* break out*/
            handle = AUDIO_MAX_PROCESSORS;
         }
      }
      audio_processor_unlock(wl);
   }
   return result;
}

#ifdef POWER_MANAGEMENT
int ismd_audio_pm_suspend(struct pci_dev *dev, pm_message_t state)
{
   ismd_result_t result = ISMD_SUCCESS;
   icepm_ret_t icepm_result = ICEPM_OK;
   
   if(power_state == ISMD_AUDIO_POWER_STATE_D3){
      OS_INFO("Audio driver already in D3 state\n");
   }
   else if(ISMD_SUCCESS != (result = ismd_audio_suspend())){
      AUDIO_ERROR("ismd_audio_suspend failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      icepm_result = -EBUSY;
   }
   else if (ICEPM_OK != (icepm_result = icepm_set_power_state( "audio", ICEPM_D3))){
      AUDIO_ERROR("icepm_set_power_state failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else {
      power_state = ISMD_AUDIO_POWER_STATE_D3;
   }

   return icepm_result;
}

int ismd_audio_pm_resume(struct pci_dev *dev)
{
   ismd_result_t result = ISMD_SUCCESS;
   icepm_ret_t icepm_result = ICEPM_OK;

   if(power_state == ISMD_AUDIO_POWER_STATE_D0){
      OS_INFO("Audio driver already in D0 state\n");
   }
   else if (ICEPM_OK != (icepm_result = icepm_set_power_state( "audio", ICEPM_D0))){
      AUDIO_ERROR("icepm_set_power_state failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if (ISMD_SUCCESS != (result = ismd_audio_resume())) {
      AUDIO_ERROR("ismd_audio_resume failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      icepm_result = -EBUSY;
   }
   else {
      power_state = ISMD_AUDIO_POWER_STATE_D0;
   }

   return icepm_result;
}
#endif

/*********************************************************************************************/
/* Audio module Init and Deinit functions.*/
/*********************************************************************************************/

ismd_result_t
ismd_audio_initialize(void)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   int loop = 0; 
   int clock_recovery_mode = AUDIO_INDEPENDENT_CLOCK_RECOVERY_MODE_NORMAL;
   int asrc_support_enable = 0;
#ifdef POWER_MANAGEMENT
   icepm_ret_t icepm_result = ICEPM_OK;
   icepm_functions_t audio_pm_func = {&ismd_audio_pm_suspend, &ismd_audio_pm_resume};
#endif

   AUDIO_CONFIG_GET_CLOCK_RECOVERY_MODE(clock_recovery_mode);
   AUDIO_CONFIG_GET_ASRC_SUPPORT(asrc_support_enable);

   if (!apm_initialized) {

      /** Check platform config to determine how many inputs we should support.*/
      AUDIO_CONFIG_GET_MAX_INPUTS_SUPPORTED(max_num_inputs_per_processor);    

      /** Do not allow the number to go above the defined max supported. */
      if(max_num_inputs_per_processor > AUDIO_MAX_INPUTS) {
         OS_PRINT("\nISMD AUDIO: WARNING: Number of inputs per processor specified " \
            "in platform config exceeds maximum supported! Forcing to %d!\n", AUDIO_MAX_INPUTS);
         max_num_inputs_per_processor = AUDIO_MAX_INPUTS;
      }

      if(PAL_SUCCESS != pal_get_soc_info(&(audio_soc_info))) {
         OS_INFO("%s, couldn't extract soc_info\n",__FILE__);
      }
      
      if((result = ismd_audio_core_sven_init()) != ISMD_SUCCESS) {

         OS_INFO("FATAL ERROR: SVEN initialization failed in ISMD AUDIO DRIVER.\n");
      }
      else if((result = ismd_audio_core_initialize()) != ISMD_SUCCESS){

         AUDIO_ERROR("ismd_audio_core_initialize failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else{

         /*Initialize global processor semaphore*/
         if(os_mutex_init(&(global_processor_lock)) != OSAL_SUCCESS){

            result = ISMD_ERROR_OPERATION_FAILED;
            AUDIO_ERROR("global sema failed init!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         /*Initialize APM Processor contexts.*/
         for(loop = 0; loop < AUDIO_MAX_PROCESSORS; loop++) {

            audio_processor_init_wl(&(processor_context[loop]));

            if((result = audio_pvt_init_locks(&(processor_context[loop]))) != ISMD_SUCCESS){

               result = ISMD_ERROR_OPERATION_FAILED;
               AUDIO_ERROR("audio_pvt_initialize_locks failed in init!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
            }
           
            processor_context[loop].atc_timer_clock_h = audio_timing_control_get_timer_clock();
            processor_context[loop].clock_recovery_mode = clock_recovery_mode;
            processor_context[loop].asrc_support_enabled = ((asrc_support_enable == 0) ? false : true);
         }
      }
#ifdef POWER_MANAGEMENT
   icepm_result = icepm_device_register("audio", &audio_pm_func);

   if (ICEPM_OK != icepm_result) {
      result = ISMD_ERROR_OPERATION_FAILED;
      AUDIO_ERROR("icepm_device_register failed!", icepm_result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else {
      //OS_PRINT("audio driver registered for power management\n");
   }

#endif      
      apm_initialized = true;
      power_state = ISMD_AUDIO_POWER_STATE_D0;

      if(result != ISMD_SUCCESS){

         // TODO: why is this commented out?
        // ismd_audio_deinitialize();
         apm_initialized = false;
      }
      else{
         
         /* Determine which codecs are available. */
         audio_pvt_get_avail_codecs();

         OS_PRINT("Intel SMD Audio driver initialized. Built on %s at %s.\nAvailable Audio Codecs:\n",  __DATE__, __TIME__);
         audio_pvt_print_avail_codecs();
         
      }

   } else {

      AUDIO_ERROR("APM already initialized!", result, audio_devh[AUDIO_DEBUG_APM]);
      result = ISMD_ERROR_ALREADY_INITIALIZED;
   }

   return result;
}

ismd_result_t
ismd_audio_deinitialize(void)
{
   int handle = 0;
#ifdef POWER_MANAGEMENT
   icepm_ret_t icepm_result = ICEPM_OK;
#endif
   ismd_result_t result = ISMD_SUCCESS;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(apm_initialized){

     /* Before trying to deinit, ensure all processors are closed. 
        put the global reference count to 1 in case we have a 
        global processor open, it will decrement then close it. */
      if(global_processor_ref_count > 1){
         global_processor_ref_count = 1;
      }
      for(handle = 0; handle < AUDIO_MAX_PROCESSORS; handle++) {
         if(processor_context[handle].in_use) {
            ismd_audio_close_processor(handle);
         }
      }

      
#ifdef POWER_MANAGEMENT
      icepm_result = icepm_device_unregister("audio");
      if(ICEPM_OK != icepm_result){
         AUDIO_ERROR("icepm_device_register failed!", icepm_result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         //OS_PRINT("audio un-registered power management\n");
      }
#endif
      /*Deinit audio sub-units*/
      if((result = ismd_audio_core_deinitialize()) != ISMD_SUCCESS){
         AUDIO_ERROR("audio_core_deinitialize failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /*Destroy all semaphores*/
      os_mutex_destroy(&(global_processor_lock));

      for(handle = 0; handle < AUDIO_MAX_PROCESSORS; handle++) {
         audio_pvt_deinit_locks(&(processor_context[handle]));
      }

      ismd_audio_core_sven_deinit();

   }else{
      result = ISMD_ERROR_INVALID_REQUEST;
      AUDIO_ERROR("APM not initialized!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   apm_initialized = false;
   power_state = ISMD_AUDIO_POWER_STATE_D3;

   OS_PRINT("\nIntel SMD Audio Driver: Deinitialize complete.\n");

   return result;
}



/*********************************************************************************************/
/* Private locking init functions.*/
/*********************************************************************************************/

static ismd_result_t
audio_pvt_init_locks(ismd_audio_processor_context_t *wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   osal_result os_result;
   int loop = 0;
   int max_loops = 0;

   /*Find largest value to use in for loop.*/
   max_loops = (AUDIO_MAX_INPUTS > AUDIO_MAX_OUTPUTS) ?  AUDIO_MAX_INPUTS : AUDIO_MAX_OUTPUTS;

   result = ISMD_SUCCESS;

   /*Initialize procssor semaphores*/
   if((os_result = os_mutex_init(&(wl->lock))) != OSAL_SUCCESS){
      AUDIO_ERROR("processor semaphore init failed!", os_result,  audio_devh[AUDIO_DEBUG_APM]);
      result = ISMD_ERROR_OPERATION_FAILED;
   }
   if((os_result = os_mutex_init(&(wl->atc_psm_queue_lock))) != OSAL_SUCCESS){
      AUDIO_ERROR("processor atc psm lock!", os_result,  audio_devh[AUDIO_DEBUG_APM]);
      result = ISMD_ERROR_OPERATION_FAILED;
   }   

   for(loop = 0; loop < max_loops; loop++){

      if(loop < AUDIO_MAX_INPUTS){
         if((os_result = os_mutex_init(&(wl->inputs[loop].lock))) != OSAL_SUCCESS){
            AUDIO_ERROR("processor input semaphore init failed!", os_result,  audio_devh[AUDIO_DEBUG_APM]);
            result = ISMD_ERROR_OPERATION_FAILED;
         }
      }

      if(loop < AUDIO_MAX_OUTPUTS){
         if((os_result = os_mutex_init(&(wl->outputs[loop].lock))) != OSAL_SUCCESS){
            AUDIO_ERROR("processor output semaphore init failed!", os_result, audio_devh[AUDIO_DEBUG_APM]);
            result = ISMD_ERROR_OPERATION_FAILED;
         }
      }
   }

   return result;
}


static void
audio_pvt_deinit_locks(ismd_audio_processor_context_t *wl)
{
   int loop = 0;
   int max_loops = 0;

   /*Find largest value to use in for loop.*/
   max_loops = (AUDIO_MAX_INPUTS > AUDIO_MAX_OUTPUTS) ?  AUDIO_MAX_INPUTS : AUDIO_MAX_OUTPUTS;

   /*Deinit all wl semaphores.*/
   os_mutex_destroy(&(wl->lock));
   os_mutex_destroy(&(wl->atc_psm_queue_lock));

   for(loop = 0; loop < max_loops; loop++){

      if(loop < AUDIO_MAX_INPUTS){
         os_mutex_destroy(&(wl->inputs[loop].lock));
      }

      if(loop < AUDIO_MAX_OUTPUTS){
         os_mutex_destroy(&(wl->outputs[loop].lock));
      }
   }

   return;
}

static void
audio_pvt_get_avail_codecs( void )
{
   int codec_id;
   ismd_result_t result;
   codecs_available_t codec_status;
   int count = 0;
   uint8_t dsp_num;
   // init all codecs to unavailable
   for ( codec_id = 0; codec_id < ISMD_AUDIO_MAX_LIBS; codec_id ++ ) {
      available_codecs[codec_id].availability = false;
      available_codecs[codec_id].dsp_num = 0;
      available_codecs[codec_id].ddplus_dcv_in_use = false;
      
      available_ms10_codecs[codec_id].availability = false;
      available_ms10_codecs[codec_id].dsp_num = 0;
      available_ms10_codecs[codec_id].ddplus_dcv_in_use = false;

      available_dcv_codec.availability = false;
      available_dcv_codec.dsp_num = 0;
   }

   /* Call down to the DSP to get the codecs that are available. */
   for (dsp_num = 0; dsp_num < 2; dsp_num++) {
      if ( (result = audio_psm_codec_available(0, dsp_num, &codec_status)) == ISMD_SUCCESS ) {

         for ( codec_id = 0; codec_id < ISMD_AUDIO_MAX_LIBS; codec_id ++ ) {
            if(codec_status.codec_exists[codec_id]) {
               available_codecs[codec_id].availability = true;
               available_codecs[codec_id].dsp_num = dsp_num;
               count++;
            }
         }

         if (codec_status.codec_ms10_ddc) {
            available_ms10_codecs[ISMD_AUDIO_MEDIA_FMT_DD].availability = true;
            available_ms10_codecs[ISMD_AUDIO_MEDIA_FMT_DD].dsp_num = dsp_num;
            available_ms10_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].availability = true;
            available_ms10_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].dsp_num = dsp_num;
         }

         if (codec_status.codec_ms10_ddt){
            available_ms10_codecs[ISMD_AUDIO_MEDIA_FMT_AAC].availability = true;
            available_ms10_codecs[ISMD_AUDIO_MEDIA_FMT_AAC].dsp_num = dsp_num;
            available_ms10_codecs[ISMD_AUDIO_MEDIA_FMT_AAC_LOAS].availability = true;
            available_ms10_codecs[ISMD_AUDIO_MEDIA_FMT_AAC_LOAS].dsp_num = dsp_num;
         }

         if (codec_status.codec_ddplus_dcv) {
            available_dcv_codec.availability = true;
            available_dcv_codec.dsp_num = dsp_num;
            if (!available_codecs[ISMD_AUDIO_MEDIA_FMT_DD].availability) {
               available_codecs[ISMD_AUDIO_MEDIA_FMT_DD].availability = true;
               available_codecs[ISMD_AUDIO_MEDIA_FMT_DD].dsp_num = dsp_num;
               available_codecs[ISMD_AUDIO_MEDIA_FMT_DD].ddplus_dcv_in_use = true;
            }
            if (!available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].availability) {
               available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].availability = true;
               available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].dsp_num = dsp_num;
               available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].ddplus_dcv_in_use = true;
            }
         } 
      }
   }
}


static void 
audio_pvt_print_codec_ver_string( int codec_id, char *codec_name )
{
   char ver_string[256];

   /* Check for MS10 codecs available */
   if ( audio_pvt_available_ms10_codec(codec_id)) {
      if (codec_id == ISMD_AUDIO_MEDIA_FMT_DD) {
         // bypass DD, since MS10 DD and DDPlus are same codec 
      }
      else {
         audio_psm_get_codec_ver_string(0, available_ms10_codecs[codec_id].dsp_num, CODEC_ATTACH_MS10_FLAG(codec_id), ver_string);
         OS_PRINT( " -Dolby MS10 %s: %s\n", codec_name, ver_string );
      }
   }

   if ( audio_pvt_available_codec(codec_id)) {

      if ((codec_id == ISMD_AUDIO_MEDIA_FMT_DTS) && available_codecs[ISMD_AUDIO_MEDIA_FMT_DTS_HD].availability) {
         // Dont need to go down the DSP to ask if we have DTSHD since either one or the other is installed.
      }
      else if (codec_id == ISMD_AUDIO_MEDIA_FMT_DD) {
         if (available_codecs[ISMD_AUDIO_MEDIA_FMT_DD].ddplus_dcv_in_use){
            audio_psm_get_codec_ver_string(0, available_codecs[codec_id].dsp_num, CODEC_ATTACH_DCV_FLAG(codec_id), ver_string);
            OS_PRINT( " -%s: Standalone DCV %s\n", codec_name, ver_string );
         }
         // Print out the AC3 codec ver string if dcv in not installed.
         else {
            audio_psm_get_codec_ver_string(0, available_codecs[codec_id].dsp_num, codec_id, ver_string);
            OS_PRINT( " -%s: %s\n", codec_name, ver_string );
         }
      }
      else if (codec_id == ISMD_AUDIO_MEDIA_FMT_DD_PLUS) {
         // Print out the dcv codec ver string if DD+ is not installed.
         if (available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].ddplus_dcv_in_use){
            audio_psm_get_codec_ver_string(0, available_codecs[codec_id].dsp_num, CODEC_ATTACH_DCV_FLAG(codec_id), ver_string);
            OS_PRINT( " -%s: Standalone DCV %s\n", codec_name, ver_string );
         }
         // Print out the DD+ codec ver string if dcv in not installed.
         else {
            audio_psm_get_codec_ver_string(0, available_codecs[codec_id].dsp_num, codec_id, ver_string);
            OS_PRINT( " -%s: %s\n", codec_name, ver_string );
         }
      }
      else {
         audio_psm_get_codec_ver_string(0, available_codecs[codec_id].dsp_num, codec_id, ver_string);
         OS_PRINT( " -%s: %s\n", codec_name, ver_string );
      }
   }

   if (available_dcv_codec.availability && codec_id == ISMD_AUDIO_MEDIA_FMT_DD_PLUS) {
      audio_psm_get_codec_ver_string(0, available_dcv_codec.dsp_num, CODEC_ATTACH_DCV_FLAG(codec_id), ver_string);
      OS_PRINT( " -Standalone DCV: %s\n", ver_string );
   }
}

static void
audio_pvt_print_avail_codecs( void ) 
{   
   /*Dolby Codecs.*/
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MEDIA_FMT_DD,      "Dolby Digital (AC3)" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_ENCODE_FMT_AC3,    "Dolby Digital Compatible Output (DDCO)" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MEDIA_FMT_TRUE_HD, "Dolby TRUEHD" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_ENCODE_FMT_TRUEHD_MAT,    "Dolby TrueHD MAT Encoder" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MEDIA_FMT_DD_PLUS, "Dolby Digital Plus (EAC3)" );

   /*Other codecs/libs*/
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MEDIA_FMT_AAC,     "Advanced Audio Codec (AAC)" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_ENCODE_FMT_AAC,    "AAC-LC (Low Complexity) Encoder" );    
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MEDIA_FMT_MPEG,    "MPEG" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MEDIA_FMT_WM9,     "Windows Media Audio (WMA9)" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_SPECIALIZED_PROCESSING_SRS, "SRS" ); 

   /*DTS Codecs*/
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MEDIA_FMT_DTS,     "DTS Core" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MEDIA_FMT_DTS_LBR, "DTS-LBR (Low Bitrate)" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MEDIA_FMT_DTS_HD,  "DTS-HD" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_ENCODE_FMT_DTS,    "DTS Encoder" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MATRIX_DECODER_DTS_NEO6,    "DTS-NEO6" );
   audio_pvt_print_codec_ver_string( ISMD_AUDIO_MEDIA_FMT_DTS_BC,  "DTS-BC (Broadcast)" );
   
   OS_PRINT("\n");
   
}
/*********************************************************************************************/


static ismd_result_t
audio_pvt_insert_srs_stage(ismd_audio_processor_context_t *wl, int stage_index)
{
   ismd_result_t result=ISMD_SUCCESS;
   if(wl->psm_pa_pipe.stages[SRS_STAGE].in_use){
      //Need to insert SRS stage here. If SRS is enabled, post_src->srs->quality, else post_src->quality)
      if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
         wl->psm_pa_pipe.stages[POST_SRC_STAGE].handle, stage_index, 
         wl->psm_pa_pipe.stages[SRS_STAGE].handle, stage_index )) != ISMD_SUCCESS){
         AUDIO_ERROR("Post SRC to SRS stage connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
         wl->psm_pa_pipe.stages[SRS_STAGE].handle, stage_index, 
         wl->psm_pa_pipe.stages[QUALITY_STAGE].handle, stage_index)) != ISMD_SUCCESS) {
         AUDIO_ERROR("SRS to Quality connect failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      if((result = audio_psm_stage_connect(wl->psm_pa_pipe.pipe_h, 
         wl->psm_pa_pipe.stages[POST_SRC_STAGE].handle, stage_index, 
         wl->psm_pa_pipe.stages[QUALITY_STAGE].handle, stage_index)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Post SRC to Quality connect failed", result, audio_devh[AUDIO_DEBUG_APM]);	
      }
   }
   return result;
}



