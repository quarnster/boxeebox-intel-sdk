/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2008-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2008-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"
#include "audio_apm_common.h"

#define AAC_MAX_CHANNELS 8

/* TODO: This is the same as audio_ddplus_config.c. Until I find a better place 
   I am going to leave it here. */
#define LEFT_CHAN_ROUTE_INDEX             0
#define RIGHT_CHAN_ROUTE_INDEX            2 
#define LFE_CHAN_ROUTE_INDEX              5 
#define CENTER_CHAN_ROUTE_INDEX           1
#define LEFT_SUR_CHAN_ROUTE_INDEX         3
#define RIGHT_SUR_CHAN_ROUTE_INDEX        4
#define LEFT_REAR_SUR_CHAN_ROUTE_INDEX    6
#define RIGHT_REAR_SUR_CHAN_ROUTE_INDEX   7
#define AUDIO_AAC_TARGET_LEVEL_MAX 127
#define AUDIO_AAC_TARGET_LEVEL_MIN 0
#define AUDIO_AAC_DRC_COMPRESS_FAC_MAX 100
#define AUDIO_AAC_DRC_COMPRESS_FAC_MIN 0
#define AUDIO_AAC_DRC_BOOST_FAC_MAX 100
#define AUDIO_AAC_DRC_BOOST_FAC_MIN 0






#define CHANNEL_0_VALUE (0 << 8) 
#define CHANNEL_1_VALUE (1 << 8)
#define CHANNEL_2_VALUE (2 << 8)
#define CHANNEL_3_VALUE (3 << 8)  
#define CHANNEL_4_VALUE (4 << 8)      
#define CHANNEL_5_VALUE (5 << 8) 
#define CHANNEL_6_VALUE (6 << 8) 
#define CHANNEL_7_VALUE (7 << 8)


// TODO: CH ROUTE CONFIG when we are ready.
/*#define AUDIO_DEFAULT_LEFT_CH_ROUTE       CHANNEL_0_VALUE | LEFT_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_LFE_CH_ROUTE      CHANNEL_1_VALUE | LFE_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_L_SUR_CH_ROUTE        CHANNEL_2_VALUE | LEFT_SUR_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_L_REAR_SUR_CH_ROUTE     CHANNEL_3_VALUE | LEFT_REAR_SUR_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_RIGHT_CH_ROUTE      CHANNEL_4_VALUE | RIGHT_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_CENTER_CH_ROUTE      CHANNEL_5_VALUE | CENTER_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_R_SUR_CH_ROUTE CHANNEL_6_VALUE | RIGHT_SUR_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_R_REAR_SUR_CH_ROUTE CHANNEL_7_VALUE | RIGHT_REAR_SUR_CHAN_ROUTE_INDEX;*/

#define AUDIO_DEFAULT_LEFT_CH_ROUTE       CHANNEL_0_VALUE | LEFT_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_RIGHT_CH_ROUTE      CHANNEL_1_VALUE | RIGHT_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_LFE_CH_ROUTE        CHANNEL_2_VALUE | LFE_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_CENTER_CH_ROUTE     CHANNEL_3_VALUE | CENTER_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_L_SUR_CH_ROUTE      CHANNEL_4_VALUE | LEFT_SUR_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_R_SUR_CH_ROUTE      CHANNEL_5_VALUE | RIGHT_SUR_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_L_REAR_SUR_CH_ROUTE CHANNEL_6_VALUE | LEFT_REAR_SUR_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_R_REAR_SUR_CH_ROUTE CHANNEL_7_VALUE | RIGHT_REAR_SUR_CHAN_ROUTE_INDEX;

ismd_result_t
audio_aac_downmixer_control(audio_psm_decode_pipe_t *pt_psm_dec_pipe, audio_psm_decode_params_t *psm_decode_params)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_aac_downmixer_t t_aac_downmixer = psm_decode_params->host.codec.config.aac_params.b_aac_downmixer;

   /*Record the user's input to AAC params.*/
   pt_psm_dec_pipe->stages[DECODE_STAGE].params.decoder.host.codec.config.aac_params.b_aac_downmixer = t_aac_downmixer;

   /*If the decoder is running need to update the decoder stage parameters.*/
   if(pt_psm_dec_pipe->pipe_started) {
      if((result = audio_psm_stage_config_direct(
                          pt_psm_dec_pipe->pipe_h, 
                          pt_psm_dec_pipe->stages[DECODE_STAGE].handle, 
                          &pt_psm_dec_pipe->stages[DECODE_STAGE].params)) != ISMD_SUCCESS) {

         AUDIO_ERROR("audio_psm_stage_config_direct failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   return result;
}

ismd_result_t
audio_aac_set_decode_param(audio_psm_decode_pipe_t *pt_psm_dec_pipe, audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_aac_downmixer_t *t_aac_downmixer;
   ismd_audio_aac_mono_to_stereo_t *mono_stereo;
   ismd_audio_aac_surround_mono_to_stereo_t *t_aac_surround_mono_to_stereo;
   int host_params;

   switch(param_id)
   {    

     case ISMD_AUDIO_AAC_DOWNMIXER_ON_OFF :
         
         t_aac_downmixer = (ismd_audio_aac_downmixer_t *)param_value;
         
         if( (*t_aac_downmixer == ISMD_AUDIO_AAC_DOWNMIXER_DISABLE)||(*t_aac_downmixer == ISMD_AUDIO_AAC_DOWNMIXER_ENABLE) ) {

               psm_decode_params->host.codec.config.aac_params.b_aac_downmixer = *t_aac_downmixer;

               audio_aac_downmixer_control(pt_psm_dec_pipe, psm_decode_params);

         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("aac: AAC_DOWNMIXER_ON_OFF param failed", result, audio_devh[AUDIO_DEBUG_APM]);    
         }
         break;

     case ISMD_AUDIO_AAC_MONO_TO_STEREO_MODE :

          mono_stereo = (ismd_audio_aac_mono_to_stereo_t *) param_value;
         
         if((*mono_stereo == ISMD_AUDIO_AAC_MONO_TO_STEREO_SINGLE_CHANNEL) || (*mono_stereo == ISMD_AUDIO_AAC_MONO_TO_STEREO_2_CHANNELS)) {            
               psm_decode_params->host.codec.config.aac_params.to_stereo = *mono_stereo;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("aac: MONO_TO_STEREO param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }
         break;

     case ISMD_AUDIO_AAC_SURROUND_MONO_TO_STEREO_MODE :

         t_aac_surround_mono_to_stereo = (ismd_audio_aac_surround_mono_to_stereo_t *) param_value;
         
         if((*t_aac_surround_mono_to_stereo == ISMD_AUDIO_AAC_SURROUND_MONO_TO_STEREO_SINGLE_CHANNEL) || (*t_aac_surround_mono_to_stereo == ISMD_AUDIO_AAC_SURROUND_MONO_TO_STEREO_2_CHANNELS)) {
               psm_decode_params->host.codec.config.aac_params.b_aac_surround_mono_to_stereo = *t_aac_surround_mono_to_stereo;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("aac: SURROUND_MONO_TO_STEREO param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }
         break;

     case ISMD_AUDIO_AAC_PRL_ENABLE:
        host_params = *((int *)param_value);
        if (host_params >= 0 && host_params <= 1) {
           psm_decode_params->host.codec.config.aac_params.enable_prl = host_params;
        }
        else {
           result = ISMD_ERROR_INVALID_PARAMETER;
           AUDIO_ERROR("aac: ISMD_AUDIO_AAC_PRL_ENABLE param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
        }
        break;

     case ISMD_AUDIO_AAC_DRC_ENABLE:
        host_params = *((int *)param_value);
        if (host_params >= 0 && host_params <= 1) {
           psm_decode_params->host.codec.config.aac_params.enable_drc = host_params;
        }
        else {
           result = ISMD_ERROR_INVALID_PARAMETER;
           AUDIO_ERROR("aac: ISMD_AUDIO_AAC_DRC_ENABLE param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
        }
        break;

     case ISMD_AUDIO_AAC_TARGET_LEVEL:
        host_params = *((int *)param_value);
        if (host_params >= AUDIO_AAC_TARGET_LEVEL_MIN && host_params <= AUDIO_AAC_TARGET_LEVEL_MAX) {
           psm_decode_params->host.codec.config.aac_params.target_level = host_params;
        }
        else {
           result = ISMD_ERROR_INVALID_PARAMETER;
           AUDIO_ERROR("aac: ISMD_AUDIO_AAC_TARGET_LEVEL param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
        }
        break;

     case ISMD_AUDIO_AAC_DRC_COMPRESS_FAC:
        host_params = *((int *)param_value);
        if (host_params >= AUDIO_AAC_DRC_COMPRESS_FAC_MIN && host_params <= AUDIO_AAC_DRC_COMPRESS_FAC_MAX) {
           psm_decode_params->host.codec.config.aac_params.drc_cut_fac = (int)((host_params <<23)/100);
        }
        else {
           result = ISMD_ERROR_INVALID_PARAMETER;
           AUDIO_ERROR("aac: ISMD_AUDIO_AAC_DRC_COMPRESS_FAC param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
        }

        break;
     case ISMD_AUDIO_AAC_DRC_BOOST_FAC:
        host_params = *((int *)param_value);
        if (host_params >= AUDIO_AAC_DRC_BOOST_FAC_MIN && host_params <= AUDIO_AAC_DRC_BOOST_FAC_MAX) {
           psm_decode_params->host.codec.config.aac_params.drc_boost_fac = (int)((host_params <<23)/100);
        }
        else {
           result = ISMD_ERROR_INVALID_PARAMETER;
           AUDIO_ERROR("aac: ISMD_AUDIO_AAC_DRC_BOOST_FAC param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
        }
        break;

     case ISMD_AUDIO_AAC_BS_FORMAT:
        host_params = *((int *)param_value);
        switch (host_params) {
           case ISMD_AUDIO_AAC_BS_FORMAT_ADIF:
           case ISMD_AUDIO_AAC_BS_FORMAT_ADTS:
           case ISMD_AUDIO_AAC_BS_FORMAT_LOAS:
           case ISMD_AUDIO_AAC_BS_FORMAT_RAW:
              psm_decode_params->host.codec.config.aac_params.bsformat = host_params;
              break;
           default:
              result = ISMD_ERROR_INVALID_PARAMETER;
              AUDIO_ERROR("aac: ISMD_AUDIO_AAC_BS_FORMAT param invalid!", host_params, audio_devh[AUDIO_DEBUG_APM]);
              break;
        }
        break;
        
     case ISMD_AUDIO_AAC_EXTERNAL_SAMPLE_RATE:
        host_params = *((int *)param_value);
        switch (host_params) {
           case 32000:
           case 44100:
           case 48000:
           case 88200:
           case 96000:
              psm_decode_params->host.codec.config.aac_params.externalsr = host_params;
              break;
           default:
              result = ISMD_ERROR_INVALID_PARAMETER;
              AUDIO_ERROR("aac: ISMD_AUDIO_AAC_EXTERNAL_SAMPLE_RATE param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
              break;
        } 
        break;
      // TODO: ADD more params here.


      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("aac: invalid config param type!", result, audio_devh[AUDIO_DEBUG_APM]);    
         break;
   }

   return result;
}

ismd_result_t
   audio_aac_set_default_decode_params(audio_psm_decode_params_t *dec_params, ismd_audio_format_t format)
{
   ismd_result_t result = ISMD_SUCCESS;

   OS_MEMSET((char *)dec_params, 0, sizeof(audio_psm_stage_params_t)); 

   //Params able to be modified by the user.            
   dec_params->host.codec.config.aac_params.sbr_signaling = 2; //auto mode

   /* Default values */
   dec_params->host.codec.config.aac_params.to_stereo = ISMD_AUDIO_AAC_MONO_TO_STEREO_2_CHANNELS;
   dec_params->host.codec.config.aac_params.b_aac_surround_mono_to_stereo = ISMD_AUDIO_AAC_SURROUND_MONO_TO_STEREO_2_CHANNELS;


   //Params not changable by the user. 
   dec_params->host.codec.config.aac_params.pcm_wdsz = 24;
   dec_params->host.codec.config.aac_params.downmix = 0;
   dec_params->host.codec.config.aac_params.bdownsample = 0;  
   dec_params->host.codec.config.aac_params.externalsr = 44100;
   dec_params->host.codec.config.aac_params.zero_unused_chans = 0; // Why is this not 1? Seems like we would want zero out unused channel slots.
   // dec_params->host.codec.config.aac_params.bsformat = 0; //not set
   dec_params->host.codec.config.aac_params.outnchans = 8; //Always set to max since we have a mixer/downmixer
   dec_params->host.codec.config.aac_params.chanrouting[LEFT_CHAN_ROUTE_INDEX] = AUDIO_DEFAULT_LEFT_CH_ROUTE;
   dec_params->host.codec.config.aac_params.chanrouting[RIGHT_CHAN_ROUTE_INDEX] = AUDIO_DEFAULT_RIGHT_CH_ROUTE; 
   dec_params->host.codec.config.aac_params.chanrouting[LFE_CHAN_ROUTE_INDEX] = AUDIO_DEFAULT_LFE_CH_ROUTE;
   dec_params->host.codec.config.aac_params.chanrouting[CENTER_CHAN_ROUTE_INDEX] = AUDIO_DEFAULT_CENTER_CH_ROUTE;
   dec_params->host.codec.config.aac_params.chanrouting[LEFT_SUR_CHAN_ROUTE_INDEX] = AUDIO_DEFAULT_L_SUR_CH_ROUTE;
   dec_params->host.codec.config.aac_params.chanrouting[RIGHT_SUR_CHAN_ROUTE_INDEX] = AUDIO_DEFAULT_R_SUR_CH_ROUTE;
   dec_params->host.codec.config.aac_params.chanrouting[LEFT_REAR_SUR_CHAN_ROUTE_INDEX] = AUDIO_DEFAULT_L_REAR_SUR_CH_ROUTE;
   dec_params->host.codec.config.aac_params.chanrouting[RIGHT_REAR_SUR_CHAN_ROUTE_INDEX] = AUDIO_DEFAULT_R_REAR_SUR_CH_ROUTE;
   if(format == ISMD_AUDIO_MEDIA_FMT_AAC_LOAS){
      dec_params->host.codec.config.aac_params.bsformat = ISMD_AUDIO_AAC_BS_FORMAT_LOAS;
   }
   else if(format == ISMD_AUDIO_MEDIA_FMT_AAC){
      dec_params->host.codec.config.aac_params.bsformat = ISMD_AUDIO_AAC_BS_FORMAT_ADTS;
   }

   dec_params->host.codec.config.aac_params.enable_drc = 0;
   dec_params->host.codec.config.aac_params.enable_prl = 0;
   dec_params->host.codec.config.aac_params.drc_cut_fac = 0;
   dec_params->host.codec.config.aac_params.drc_boost_fac = 0;
   dec_params->host.codec.config.aac_params.target_level = 124;
   return result;
}


