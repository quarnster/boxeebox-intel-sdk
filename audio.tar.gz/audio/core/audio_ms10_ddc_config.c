/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2008-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2008-2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"
#include "audio_apm_common.h"

#define SCALE_FACTOR_MAX 0x007FFFFF
#define SCALE_DEFAULT SCALE_FACTOR_MAX

#define DDPLUS_MAX_CHANNELS 8
#define START_OF_STREAM 0
#define END_OF_STREAM -1
#define DEFAULT_SUBSTREAM_ID -1

/* Routing indices and channel values per Tensillica's Documentation
 * See page 42 of HiFi2-DDPlus71-DecoderProgrammersGuide.pdf
 */

ismd_result_t
audio_ms10_ddc_set_param(audio_psm_ms10dec_pipe_t* psm_ms10_pipe, int param_id, ismd_audio_decoder_param_t *param_value)
{
   ismd_result_t result = ISMD_SUCCESS;

   if (param_id == ISMD_AUDIO_DDC_SINGLE_INPUT_DUAL_MODE) {
      // should ignore here.
   }
   else {
      if ((result = audio_ms10_ddplus_set_decode_param(&psm_ms10_pipe->dec_stage_params.decoder, param_id, param_value)) != ISMD_SUCCESS) {
         AUDIO_ERROR("ddc: main dec param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   
   return result;   
}

ismd_result_t
audio_ms10_ddplus_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_ddplus_karaoke_reproduction_mode_t *karaoke_mode;
   ismd_audio_ddplus_dynamic_range_compression_mode_t *dyn_rng_comp_mode;
   ismd_audio_ddplus_stereo_output_mode_t *stereo_out_mode;
   ismd_audio_ddplus_dual_mono_reproduction_mode_t *dual_mono_rep_mode;
   ismd_audio_ddplus_pcm_scale_factor_t *pcm_scale_factor;
   ismd_audio_ddplus_high_freq_dynamic_cut_scale_factor_t *hi_freq_dyn_cut_scale;
   ismd_audio_ddplus_low_freq_dynamic_boost_scale_factor_t *low_freq_dyn_bst_scale;
   ismd_audio_ddplus_quitonerr_t *quitonerr;
   ismd_audio_ddplus_framestart_t *framestart;
   ismd_audio_ddplus_frameend_t *frameend;

   switch(param_id)
   {
      case ISMD_AUDIO_DDC_DCV_PACKETIZE:
         psm_decode_params->host.codec.config.ddc_params.packetize = *(ismd_audio_ms10_ddc_packetizer_enable_t*)param_value;
         break;
      case ISMD_AUDIO_DDPLUS_KARAOKE_REPRODUCTION_MODE :

         karaoke_mode = (ismd_audio_ddplus_karaoke_reproduction_mode_t *) param_value;

         switch(*karaoke_mode) {

            case ISMD_AUDIO_DDPLUS_KARAOKE_REPRODUCTION_MODE_NO_VOCAL:
            case ISMD_AUDIO_DDPLUS_KARAOKE_REPRODUCTION_MODE_LEFT_VOCAL:
            case ISMD_AUDIO_DDPLUS_KARAOKE_REPRODUCTION_MODE_RIGHT_VOCAL:
            case ISMD_AUDIO_DDPLUS_KARAOKE_REPRODUCTION_MODE_BOTH_VOCALS:
               psm_decode_params->host.codec.config.ddc_params.karac = *karaoke_mode;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddc: karaoke_repro_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }

         break;

      case  ISMD_AUDIO_DDPLUS_DYNAMIC_RANGE_COMPRESSION_MODE :

         dyn_rng_comp_mode = (ismd_audio_ddplus_dynamic_range_compression_mode_t *) param_value;

         switch(*dyn_rng_comp_mode) {

            case ISMD_AUDIO_DDPLUS_CUSTOM_MODE_ANALOG_DIALOG_NORMALIZATION:
            case ISMD_AUDIO_DDPLUS_CUSTOM_MODE_DIGITAL_DIALOG_NORMALIZATION:
            case ISMD_AUDIO_DDPLUS_LINE_OUT_MODE:
            case ISMD_AUDIO_DDPLUS_RF_REMOTE_MODE:
               psm_decode_params->host.codec.config.ddc_params.dynrng_mode = *dyn_rng_comp_mode;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddc: dyn_rng_comp_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }

         break;


      case ISMD_AUDIO_DDPLUS_STEREO_OUTPUT_MODE :

         stereo_out_mode = (ismd_audio_ddplus_stereo_output_mode_t *) param_value;

         switch(*stereo_out_mode) {

            case ISMD_AUDIO_DDPLUS_STEREO_OUTPUT_MODE_AUTO_DETECT:
            case ISMD_AUDIO_DDPLUS_STEREO_OUTPUT_MODE_SURROUND_COMPATIBLE:
            case ISMD_AUDIO_DDPLUS_STEREO_OUTPUT_MODE_STEREO:
               psm_decode_params->host.codec.config.ddc_params.stereo_mode = *stereo_out_mode;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddc: stereo_out_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }

         break;

      case  ISMD_AUDIO_DDPLUS_DUAL_MONO_REPRODUCTION_MODE :

         dual_mono_rep_mode = (ismd_audio_ddplus_dual_mono_reproduction_mode_t *) param_value;

         switch(*dual_mono_rep_mode) {

            case ISMD_AUDIO_DDPLUS_DUAL_MONO_REPRODUCTION_MODE_STEREO:
            case ISMD_AUDIO_DDPLUS_DUAL_MONO_REPRODUCTION_MODE_LEFT_MONO:
            case ISMD_AUDIO_DDPLUS_DUAL_MONO_REPRODUCTION_MODE_RIGHT_MONO:
            case ISMD_AUDIO_DDPLUS_DUAL_MONO_REPRODUCTION_MODE_MIXED_MONO:
               psm_decode_params->host.codec.config.ddc_params.mono_rep = *dual_mono_rep_mode;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddc: dual_mono_rep_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }

         break;

      case ISMD_AUDIO_DDPLUS_PCM_SCALE_FACTOR :

         pcm_scale_factor = (ismd_audio_ddplus_pcm_scale_factor_t *) param_value;

         if(*pcm_scale_factor>= 0 && *pcm_scale_factor <= SCALE_FACTOR_MAX) {
               psm_decode_params->host.codec.config.ddc_params.pcm_scale = *pcm_scale_factor;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddc: pcm_scale_factor param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         break;

      case ISMD_AUDIO_DDPLUS_DYNAMIC_RANGE_HIGH_FREQ_CUT_SCALE_FACTOR :

         hi_freq_dyn_cut_scale = (ismd_audio_ddplus_high_freq_dynamic_cut_scale_factor_t *) param_value;

         if(*hi_freq_dyn_cut_scale>= 0 && *hi_freq_dyn_cut_scale <= SCALE_FACTOR_MAX) {
               psm_decode_params->host.codec.config.ddc_params.dyn_cut_hi = *hi_freq_dyn_cut_scale;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddc: hi_freq_dyn_cut_scale param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         break;

      case ISMD_AUDIO_DDPLUS_DYNAMIC_RANGE_LOW_FREQ_BOOST_SCALE_FACTOR :

         low_freq_dyn_bst_scale = (ismd_audio_ddplus_low_freq_dynamic_boost_scale_factor_t *) param_value;

         if(*low_freq_dyn_bst_scale>= 0 && *low_freq_dyn_bst_scale <= SCALE_FACTOR_MAX) {
               psm_decode_params->host.codec.config.ddc_params.dyn_boost_lo = *low_freq_dyn_bst_scale;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddc: low_freq_dyn_bst_scale param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         break;

	 case ISMD_AUDIO_DDPLUS_QUITONERR :

		quitonerr = (ismd_audio_ddplus_quitonerr_t *) param_value;

		psm_decode_params->host.codec.config.ddc_params.quitonerr = *quitonerr;

		break;

	 case ISMD_AUDIO_DDPLUS_FRAMESTART :

		framestart = (ismd_audio_ddplus_framestart_t *) param_value;

		psm_decode_params->host.codec.config.ddc_params.framestart = *framestart;

		break;


	case ISMD_AUDIO_DDPLUS_FRAMEEND :

		frameend = (ismd_audio_ddplus_frameend_t *) param_value;

		psm_decode_params->host.codec.config.ddc_params.frameend = *frameend;

		if (*frameend != -1 && *frameend <= psm_decode_params->host.codec.config.ddc_params.framestart)
			{
			result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ddp: framestart and frameend params invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
			}

		break;

   default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("ddc: invalid config param type!", result, audio_devh[AUDIO_DEBUG_APM]);
         break;


   }

   return result;
}

ismd_result_t
audio_ms10_ddc_set_default_decode_params(audio_psm_decode_params_t *dec_params )
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_decode_ddc_config_params_t*   ddc_params = & dec_params->host.codec.config.ddc_params;

   OS_MEMSET((char *)dec_params, 0, sizeof(audio_psm_stage_params_t));

   dec_params->host.codec.config.ddc_params.assoc_audio_enable = false;
   dec_params->host.codec.config.ddc_params.main_audio_dd_enabled = false;
   dec_params->host.codec.config.ddc_params.packetize = true;
   
   ddc_params->num_och = 2; // Force to 2 under MS10 DDC case
   ddc_params->lfe_out = ISMD_AUDIO_DDPLUS_LFE_CHANNEL_OUTPUT_NONE;
   ddc_params->ocfg = ISMD_AUDIO_DDPLUS_OUTPUT_CONFIGURATION_RAW_MODE;
   ddc_params->stereo_mode = ISMD_AUDIO_DDPLUS_STEREO_OUTPUT_MODE_AUTO_DETECT;
   ddc_params->mono_rep = ISMD_AUDIO_DDPLUS_DUAL_MONO_REPRODUCTION_MODE_STEREO;
   ddc_params->karac = ISMD_AUDIO_DDPLUS_KARAOKE_REPRODUCTION_MODE_BOTH_VOCALS;
   ddc_params->pcm_scale = SCALE_DEFAULT;
   ddc_params->dynrng_mode = ISMD_AUDIO_DDPLUS_LINE_OUT_MODE;
   ddc_params->dyn_cut_hi = SCALE_DEFAULT;
   ddc_params->dyn_boost_lo = SCALE_DEFAULT;
   ddc_params->quitonerr = ISMD_AUDIO_DDPLUS_QUITONERR_DISABLED;
   ddc_params->framestart = START_OF_STREAM;
   ddc_params->frameend = END_OF_STREAM;
   ddc_params->substream_id = DEFAULT_SUBSTREAM_ID;

   return result;
}


