
/*
* File Name: audio_apm_inputs.c
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_apm_common.h"
#include "audio_apm_inputs_pvt.h"

extern pal_soc_info_t audio_soc_info;

/*********************************************************************************************/
/* Audio Input Private function declarations */
/*********************************************************************************************/

static void 
audio_pvt_input_lock(ismd_audio_input_wl_t *instance);

static void 
audio_pvt_input_unlock(ismd_audio_input_wl_t *instance);

void
audio_pvt_input_api_unlock(ismd_audio_input_wl_t *instance);

ismd_result_t
audio_pvt_input_flush(ismd_audio_input_wl_t *input_wl);

ismd_result_t
audio_pvt_input_post_port_flush(ismd_audio_input_wl_t *input_wl);

ismd_result_t
audio_pvt_input_validate_wl(ismd_dev_t input_h, ismd_audio_input_wl_t **input_wl);

ismd_result_t
audio_pvt_input_api_dev_lock(ismd_dev_t input_h, ismd_audio_input_wl_t **input_wl);

static ismd_result_t
audio_pvt_input_api_lock(ismd_audio_processor_t proc_h, ismd_dev_t input_h, ismd_audio_input_wl_t **input_wl);

static ismd_result_t
audio_pvt_input_validate_format(ismd_audio_format_t format);

static ismd_result_t
audio_pvt_input_validate_required_param(ismd_audio_input_wl_t *input_wl);

static ismd_result_t
audio_pvt_input_validate_wma_param(audio_psm_decode_wm9_config_params_t *wma_params);

static ismd_result_t
audio_pvt_input_validate_pcm_param(  bool is_sw_input, int sample_size, int sample_rate);

static bool
audio_pvt_input_valid_sample_size(int sample_size);

static bool
audio_pvt_input_valid_capture_sample_size(int sample_size);

static bool
audio_pvt_input_valid_sample_rate(int sample_rate);

static ismd_result_t
audio_pvt_input_flush_queues(ismd_audio_input_wl_t *input_wl);

static ismd_result_t
audio_pvt_input_decoder_setup(ismd_audio_input_wl_t *input_wl);

static ismd_result_t
audio_pvt_input_decoder_teardown(ismd_audio_input_wl_t *input_wl,     ismd_dev_state_t input_state);

static ismd_result_t
audio_pvt_input_decoder_set_default_params(ismd_audio_input_wl_t *input_wl); 

static ismd_result_t
audio_pvt_input_alloc_resources(ismd_audio_input_wl_t *input_wl);

static ismd_result_t 
audio_pvt_remove_input(ismd_audio_input_wl_t *input_wl);

static void 
audio_pvt_input_add_oob_buf_attr(ismd_audio_input_wl_t *input_wl, ismd_buffer_descriptor_t * buffer );

ismd_result_t
audio_pvt_input_read_port_buffer(ismd_audio_input_wl_t *input_wl, ismd_port_handle_t port_h,  ismd_buffer_descriptor_t **buffer_des);

void
audio_pvt_set_dec_ch_ouput_cfg(ismd_audio_input_wl_t *input_wl) ; //Remove this when mixer is fully functional. 

ismd_result_t 
audio_pvt_get_event( ismd_audio_input_wl_t     *input_workload,
                     ismd_audio_notification_t  event_type,
                     ismd_event_t              *event_handle );

static ismd_result_t
audio_pvt_input_feed_pass_and_primary_queue( ismd_audio_input_wl_t *input_wl, ismd_queue_handle_t pass_queue, ismd_queue_handle_t primary_queue, bool *work_to_do );

static ismd_result_t 
audio_pvt_input_configure_port( ismd_audio_input_wl_t *input_wl );

static ismd_result_t
audio_pvt_phys_input_startup(ismd_audio_input_wl_t *input_wl);

static ismd_result_t
audio_pvt_phys_input_shutdown(ismd_audio_input_wl_t *input_wl);

static ismd_result_t
audio_pvt_add_input(ismd_audio_processor_context_t *wl, 
                              bool is_sw_input,
                              bool timed_stream,
                              ismd_dev_t *input_h,
                              ismd_port_handle_t *port_h);

static ismd_result_t 
audio_pvt_configure_input_dependencies( ismd_audio_processor_context_t *processor_wl );

static ismd_result_t
audio_pvt_input_start_decoder_pipe(ismd_audio_input_wl_t *input_wl);

static ismd_result_t
audio_pvt_change_queue_max_depth( ismd_queue_handle_t queue_h, int max_depth);

static ismd_result_t
audio_pvt_input_configure_asrc_support(ismd_audio_input_wl_t *input_wl);

ismd_result_t
ismd_audio_pvt_input_set_asrc_mode(ismd_audio_processor_context_t *wl, int input_id, bool enable_asrc);

static ismd_result_t
audio_pvt_input_set_to_play(ismd_audio_input_wl_t *input_wl);

void
audio_input_init_dec_pipe(ismd_audio_input_wl_t *input_wl);

void
audio_input_init_dec_for_new_format(ismd_audio_input_wl_t *input_wl);

static ismd_result_t
audio_pvt_input_start_post_atc_pipes(ismd_audio_input_wl_t *input_wl);

/*********************************************************************************************/


/*********************************************************************************************/
//TODO: THESE FUNCTIONS ARE CANDIDATES FOR REMOVAL FROM THE AUDIO API
/*********************************************************************************************/

ismd_result_t ismd_audio_input_set_sample_size(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int sample_size)
{
   //Avoid compiler warnings
   (void) sample_size;
   (void)processor_h;
   (void)input_h;
   
   OS_INFO("\nAUDIO INFO:  Please call ismd_input_set_pcm_format to set the sample size for PCM streams.\n ");
   return ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
}

ismd_result_t
ismd_audio_input_get_sample_rate(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int *sample_rate)
{
   (void)processor_h;
   (void)input_h;
   (void)sample_rate;

   OS_INFO("\nAUDIO INFO: Please call ismd_input_get_stream_info to get the sample rate.\n ");
   return ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
}

ismd_result_t
ismd_audio_input_get_bitrate(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int *bitrate)
{
   (void)processor_h;
   (void)input_h;
   (void)bitrate;

   OS_INFO("\nAUDIO INFO: Please call ismd_input_get_stream_info to get the bit rate.\n ");
   return ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
}

ismd_result_t
ismd_audio_input_get_sample_size(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int *sample_size)
{
   (void)processor_h;
   (void)input_h;
   (void)sample_size;

   OS_INFO("\nAUDIO INFO: Please call ismd_input_get_stream_info to get the sample size.\n ");
   return ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
}

ismd_result_t ismd_audio_input_set_data_format_mpeg_layer(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_mpeg_layer_t mpeg_layer)
{
   (void)input_h;
   (void)processor_h;
   (void)mpeg_layer;

   OS_INFO("\nAUDIO INFO: This call is no longer needed for MPEG audio streams!\n ");
   return ISMD_SUCCESS; 
}

ismd_result_t
ismd_audio_input_get_channel_config(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int *ch_config)
{
   (void)processor_h;
   (void)input_h;
   (void)ch_config;

   return ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
}


/*********************************************************************************************/
/*********************************************************************************************/



/*********************************************************************************************/
/* Audio Input APIs */
/*********************************************************************************************/

ismd_result_t
ismd_audio_input_get_message_context(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              uint32_t *message_context)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   
   if (message_context == NULL) {
      AUDIO_ERROR("input parameter failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){

      result = audio_timing_control_get_message_context(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, message_context);

      if( result != ISMD_SUCCESS){
         AUDIO_ERROR("timing_control_get_message context failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      audio_pvt_input_api_unlock(input_wl);
   } else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_input_get_status(ismd_audio_processor_t processor_h,
                            ismd_dev_t input_h,
                            ismd_audio_input_status_type_t type,
                            ismd_audio_input_status_t *value)
{
   ismd_result_t result = ISMD_ERROR_INVALID_REQUEST;
   ismd_audio_input_wl_t *input_wl    = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(value == NULL) {
      result = ISMD_ERROR_NULL_POINTER;
   }
   else {
      result = audio_pvt_input_api_lock( processor_h, input_h, &input_wl);
      if(result == ISMD_SUCCESS) {
         switch (type) {
            case ISMD_AUDIO_INPUT_STATUS_CURRENT_STATE:

               if ( input_wl->processor_wl->psm_pa_pipe.pipe_configured ) {
                  result = audio_psm_stage_get_config( input_wl->processor_wl->psm_pa_pipe.pipe_h,
                                                       input_wl->processor_wl->psm_pa_pipe.stages[SRC_STAGE].handle,
                                                       &(input_wl->processor_wl->psm_pa_pipe.stages[SRC_STAGE].params) );
                  if ( result != ISMD_SUCCESS) {
                     AUDIO_ERROR("audio_psm_stage_get_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }

               value->status = input_wl->processor_wl->psm_pa_pipe.stages[SRC_STAGE].params.src.state[input_wl->input_id];

               break;

            case ISMD_AUDIO_INPUT_STATUS_ASRC_MODE:

               if ( input_wl->processor_wl->psm_pa_pipe.pipe_configured ) {
                  result = audio_psm_stage_get_config( input_wl->processor_wl->psm_pa_pipe.pipe_h,
                                                       input_wl->processor_wl->psm_pa_pipe.stages[SRC_STAGE].handle,
                                                       &(input_wl->processor_wl->psm_pa_pipe.stages[SRC_STAGE].params) );
                  if ( result != ISMD_SUCCESS) {
                     AUDIO_ERROR("audio_psm_stage_get_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
               if(input_wl->processor_wl->asrc_support_enabled){
			   	   value->asrc_mode = ISMD_AUDIO_ASRC_AUTO;
               }
			   else{
                   value->asrc_mode = input_wl->asrc_enabled ? ISMD_AUDIO_ASRC_ENABLE : ISMD_AUDIO_ASRC_DISABLE;
			   }

               break;
            default:
               result = ISMD_ERROR_INVALID_REQUEST;
               break;
         }

         audio_pvt_input_api_unlock(input_wl);
      }
      else {
         AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_add_input_port(ismd_audio_processor_t processor_h,
                              bool timed_stream,
                              ismd_dev_t *input_h,
                              ismd_port_handle_t *port_h)
{
   ismd_result_t result;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /*Get processor workload.*/
   result = audio_processor_lock_and_get_wl(processor_h, &wl);
   if ( result != ISMD_SUCCESS ) {

      AUDIO_ERROR("Error getting proc workload!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else {
      /* Attempt to get an input context/handle to give to the user.  */
      if ( (result = audio_pvt_add_input(wl, true, timed_stream, input_h, port_h)) != ISMD_SUCCESS) {

         *port_h = ISMD_PORT_HANDLE_INVALID;
         AUDIO_ERROR("audio_pvt_add_input failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      
      audio_processor_unlock(wl);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


ismd_result_t
ismd_audio_add_phys_input(ismd_audio_processor_t processor_h,
                              int hw_id,
                              bool timed_stream,
                              ismd_dev_t *input_h)
{
   ismd_result_t result;
   ismd_audio_processor_context_t *wl = NULL;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /*Get processor workload.*/
   result = audio_processor_lock_and_get_wl(processor_h, &wl);
   if ( result != ISMD_SUCCESS ) {

      AUDIO_ERROR("Error getting proc workload!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else {
      /* allocate a input_wl according to sw_input or not, we dont need a sw port so pass in NULL for port handle. */
      if ( (result = audio_pvt_add_input(wl, false, timed_stream, input_h, NULL)) != ISMD_SUCCESS){
         AUDIO_ERROR("audio_pvt_add_input failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /* initial capture input port specific properties to input_wl */
      else if ( (result = audio_pvt_input_validate_wl(*input_h, &input_wl)) != ISMD_SUCCESS) {
         AUDIO_ERROR("audio_pvt_input_validate_and_lock_wl failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         audio_pvt_input_lock(input_wl);
         
         /* safe to use input_wl now */
         input_wl->hw_id = hw_id;
         input_wl->sample_rate = 48000;
         input_wl->format = ISMD_AUDIO_MEDIA_FMT_PCM;
         
         /* set POST-ATC fixed delay 10ms */
         input_wl->fixed_back_end_delay_chunk = 1; //TODO: MAKE THIS A PLATFORM CONFIG PARAM.
         audio_timing_control_set_fixed_delay(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, input_wl->fixed_back_end_delay_chunk);

         audio_pvt_input_unlock(input_wl);
      }
      
      audio_processor_unlock(wl);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}



ismd_result_t
ismd_audio_remove_input(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(audio_processor_valid_handle(processor_h)){
      result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl);
      if(result == ISMD_SUCCESS) {

         ismd_connection_unregister(ismd_audio_remove_input_callback, (void *) input_h);

         if ((result = ismd_audio_do_remove_input(processor_h, input_h, true)) != ISMD_SUCCESS){
            AUDIO_ERROR("do_remove_input failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         audio_pvt_input_api_unlock(input_wl);
      }
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
         AUDIO_ERROR("Invalid processor or input handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else{
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
ismd_audio_do_remove_input(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h, bool reconfig)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   (void)processor_h;
   result = audio_pvt_input_validate_wl(input_h, &input_wl);
   /* Lock the input if reconfig is false this means the process is calling this and processor is already locked */
   /* Caller with reconfig set to true should take API loack before calling this function */
   if(!reconfig) {
      if(result == ISMD_SUCCESS) {
         audio_pvt_input_lock(input_wl);
      }
   }
   if(result == ISMD_SUCCESS) {

      wl = input_wl->processor_wl;
         
      if((result = audio_pvt_remove_input(input_wl)) != ISMD_SUCCESS) {

         AUDIO_ERROR("audio_pvt_remove_input failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /* Unlock if necessary. */
      if(!reconfig) {
        audio_pvt_input_unlock(input_wl);
      }
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or input handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }


   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_input_disable(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){

      if(!input_wl->disabled){
         
         input_wl->disabled = true;

         if (input_wl->atc_stream_h != AUDIO_INVALID_HANDLE) {
            result = audio_timing_control_disable_stream(input_wl->processor_wl->atc_h, input_wl->atc_stream_h);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_disable_stream failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }

         if (result == ISMD_SUCCESS && input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) {
            result = audio_timing_control_disable_stream(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_disable_stream failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }

         if (result == ISMD_SUCCESS && input_wl->assoc_atc_stream_h != AUDIO_INVALID_HANDLE) {
            result |= audio_timing_control_disable_stream(input_wl->processor_wl->atc_h, input_wl->assoc_atc_stream_h);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_disable_stream failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }

      audio_pvt_input_api_unlock(input_wl);

   } else {

       AUDIO_ERROR("Invalid processor or input handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_input_enable(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){

      if(input_wl->disabled){
         
         input_wl->disabled = false;

         if (input_wl->atc_stream_h != AUDIO_INVALID_HANDLE) {
            result = audio_timing_control_enable_stream(input_wl->processor_wl->atc_h, input_wl->atc_stream_h);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_enable_stream failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         
         if (result == ISMD_SUCCESS && input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) {
            result = audio_timing_control_enable_stream(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_enable_stream failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         
         if (result == ISMD_SUCCESS && input_wl->assoc_atc_stream_h != AUDIO_INVALID_HANDLE) {
            result |= audio_timing_control_enable_stream(input_wl->processor_wl->atc_h, input_wl->assoc_atc_stream_h);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_enable_stream failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }

      audio_pvt_input_api_unlock(input_wl);

   } else {

       AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_input_get_port(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_port_handle_t *port_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS) {

      if((input_wl->is_sw_input) || ((!input_wl->is_sw_input) && (input_wl->format != ISMD_AUDIO_MEDIA_FMT_PCM))) {
         
         *port_h = input_wl->input_port;   
      
      }
      else {
         
         result = ISMD_ERROR_INVALID_REQUEST;       
      }

      audio_pvt_input_api_unlock(input_wl);
   } 
   else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
  
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


ismd_result_t
ismd_audio_input_get_data_format(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_format_t *fmt)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){

      if(input_wl->format != ISMD_AUDIO_MEDIA_FMT_INVALID){
         *fmt = input_wl->format;
      }
      else {
         result = ISMD_ERROR_OPERATION_FAILED;
         AUDIO_ERROR("Audio format not present!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      audio_pvt_input_api_unlock(input_wl);

   } else {

       AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_input_get_stream_info(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_stream_info_t *stream_info)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   ismd_audio_format_specific_stream_info_t fmt_stream_info;
   audio_psm_pipe_handle_t pipe_h;
   audio_psm_stage_handle_t stage_h;
   bool pipe_configured = false;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){

      //If its just raw PCM just fill out the info we have
      if(input_wl->format == ISMD_AUDIO_MEDIA_FMT_PCM ) {
         stream_info->algo = ISMD_AUDIO_MEDIA_FMT_PCM;
         stream_info->sample_rate = input_wl->sample_rate;
         stream_info->sample_size= input_wl->sample_size;
         stream_info->channel_config = input_wl->channel_config;
         stream_info->channel_count = input_wl->channel_count;
         stream_info->bitrate = input_wl->sample_size * input_wl->sample_rate * input_wl->channel_count;
      }
      else {

         if (AUDIO_CORE_IS_VALID_MS10_INPUT(input_wl, input_wl->format)){
            if (input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_AND_ASSOC) {
               pipe_h =input_wl->psm_ms10_pipe_assoc.dec_pipe_h;
               stage_h =input_wl->psm_ms10_pipe_assoc.dec_stage_h;
               pipe_configured = input_wl->psm_ms10_pipe_assoc.dec_pipe_configured;
            }
            else {
               pipe_h =input_wl->psm_ms10_pipe.dec_pipe_h;
               stage_h =input_wl->psm_ms10_pipe.dec_stage_h;
               pipe_configured = input_wl->psm_ms10_pipe.dec_pipe_configured;
            }
         }
         else {
            pipe_h = input_wl->psm_dec_pipe.pipe_h;
            stage_h = input_wl->psm_dec_pipe.stages[DECODE_STAGE].handle;
            pipe_configured = input_wl->psm_dec_pipe.pipe_started;
            
         }
         
         if(pipe_h != AUDIO_INVALID_HANDLE && pipe_configured){
            //Make a direct call to the PSM to get the stream info using the decode stage handle.
            if((result = audio_psm_stage_get_stream_info( pipe_h, stage_h, &fmt_stream_info )) == ISMD_SUCCESS) {
               
               *stream_info = fmt_stream_info.basic_stream_info;
            }
         }
         else{
            result = ISMD_ERROR_NO_DATA_AVAILABLE;
         }
      }
      audio_pvt_input_api_unlock(input_wl);
   } else {

      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_input_get_format_specific_stream_info(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_buffer_handle_t stream_info_buffer)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   ismd_audio_format_specific_stream_info_t stream_info;
   ismd_buffer_descriptor_t *buf_descr = NULL;
   audio_psm_pipe_handle_t pipe_h;
   audio_psm_stage_handle_t stage_h;
   bool pipe_configured = false;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){

      if((result = ismd_buffer_find_descriptor(stream_info_buffer, &buf_descr)) == ISMD_SUCCESS) {

         /* Ensure the buffer we got is enough space to do the copy.*/
         if(buf_descr->phys.size >= (int)sizeof(ismd_audio_format_specific_stream_info_t)) {
      
            //If its just raw PCM just fill out the info we have
            if(input_wl->format == ISMD_AUDIO_MEDIA_FMT_PCM ) {
               stream_info.basic_stream_info.algo = ISMD_AUDIO_MEDIA_FMT_PCM;
               stream_info.basic_stream_info.sample_rate = input_wl->sample_rate;
               stream_info.basic_stream_info.sample_size= input_wl->sample_size;
               stream_info.basic_stream_info.channel_config = input_wl->channel_config;
               stream_info.basic_stream_info.channel_count = input_wl->channel_count;
               stream_info.basic_stream_info.bitrate = input_wl->sample_size * input_wl->sample_rate * input_wl->channel_count;
               //Copy over the stream informatin into the user supplied buffer.
               OS_MEMCPY(buf_descr->virt.base, &stream_info, sizeof(stream_info));
            }
            else {

               if (AUDIO_CORE_IS_VALID_MS10_INPUT(input_wl, input_wl->format)){
                  pipe_h =input_wl->psm_ms10_pipe.dec_pipe_h;
                  stage_h =input_wl->psm_ms10_pipe.dec_stage_h;
                  pipe_configured = input_wl->psm_ms10_pipe.dec_pipe_configured;
               }
               else {
                  pipe_h = input_wl->psm_dec_pipe.pipe_h;
                  stage_h = input_wl->psm_dec_pipe.stages[DECODE_STAGE].handle;
                  pipe_configured = input_wl->psm_dec_pipe.pipe_started;
               }

               if(pipe_h != AUDIO_INVALID_HANDLE && pipe_configured){
                  
                  //If the pipe has been allocated and configured, make a direct call to the PSM to get the stream info
                  if((result = audio_psm_stage_get_stream_info( 
                        pipe_h, stage_h, &stream_info )) == ISMD_SUCCESS) {

                        //Copy over the stream informatin into the user supplied buffer.
                        OS_MEMCPY(buf_descr->virt.base, &stream_info, sizeof(stream_info));                                  
                  }
               }
               else{
                  result = ISMD_ERROR_NO_DATA_AVAILABLE;
               }
            }
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            OS_PRINT("ISMD AUDIO: ERROR: Please supply a buffer of at least %d bytes for stream information!", sizeof(ismd_audio_format_specific_stream_info_t));
         }
      }

      audio_pvt_input_api_unlock(input_wl);

   } else {

      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_input_get_watermarks(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int *studio_watermark,
                              int *theatrical_watermark)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS) {

      //Avoid warnings.
      (void) studio_watermark;
      (void) theatrical_watermark;


      audio_pvt_input_api_unlock(input_wl);

   } else {

      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }


   return ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
}


ismd_result_t
ismd_audio_input_set_decoder_param(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int param_type,
                              ismd_audio_decoder_param_t *param_value )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   ismd_audio_format_t format;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   
   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){

      /*Decoder parameters cannot be set on the fly yet, force to be in stopped state. The only parameter where this works currently is AAC downmix on/off. */
      if(((input_wl->state != ISMD_DEV_STATE_PLAY) && (input_wl->state != ISMD_DEV_STATE_PAUSE)) || (ISMD_AUDIO_AAC_DOWNMIXER_ON_OFF == (uint32_t)param_type) ) {

         /*If DTS core is in the input stream, but only DTSHD decoder, need to force format to DTSHD since we will use the DTSHD decoder. */
         if((input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS) && audio_pvt_available_codec(ISMD_AUDIO_MEDIA_FMT_DTS_HD)) {
            format = ISMD_AUDIO_MEDIA_FMT_DTS_HD;
         }
         else{
            format = input_wl->format;
         }

         if(AUDIO_CORE_IS_VALID_MS10_INPUT(input_wl, input_wl->format)){
            if(audio_core_is_ms10_ddc(input_wl->format)){

               if (param_type == ISMD_AUDIO_DDC_SINGLE_INPUT_DUAL_MODE) {
                  // Single input with dual decode mode. The input will have up to 3 atc stream instance.
                  if (*(ismd_audio_ms10_ddc_single_input_dual_mode_t *) param_value >= 1) {
                     input_wl->ms10_input_type = AUDIO_INPUT_MS10_MAIN_AND_ASSOC;
                     input_wl->psm_ms10_pipe_assoc.substream_id = *(int *) param_value;
                     result = audio_pvt_input_ms10dec_setup_assoc_pipe(input_wl);
                  }
                  else {
                     audio_pvt_input_ms10dec_teardown_assoc_pipe(input_wl);
                     input_wl->ms10_input_type = AUDIO_INPUT_MS10_MAIN_OR_ASSOC_ONLY;
                  }
               }
               else if (param_type == ISMD_AUDIO_DDC_SINGLE_INPUT_DUAL_CH_MIX_MODE) {
                  /*Mode to determine if user input channel mixer coeff apply into main audio or assoc audio or both.*/
                  /*This mode is only avaible under ISMD_AUDIO_DDC_SINGLE_INPUT_DUAL_MODE case. */
                  input_wl->psm_ms10_pipe_assoc.dual_ch_mix = *(int *) param_value;
               }
               else if((result = audio_ms10_ddc_set_param(&input_wl->psm_ms10_pipe, param_type, param_value)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_ms10_ddplus_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
            else if(audio_core_is_ms10_ddt(input_wl->format)){
               if(param_type == ISMD_AUDIO_DDT_DDCE_TESTMODEON) { 
                  if (*(ismd_audio_ms10_ddt_ddce_testmode_t *) param_value == 1) {
                    OS_PRINT("\nMS10 DDT DDCE WHITE BOX TEST MODE SET!\n\n");
                    input_wl->psm_ms10_pipe.ddt_ddce_testmode = true;
   				  input_wl->psm_ms10_pipe.enc_stage_params.decoder.host.codec.config.ddt_params.ddt_ac3_enc.testmodeon = true;
                  }
               }
               else if ((result = audio_ms10_ddt_set_param(&input_wl->psm_ms10_pipe, param_type, param_value)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_ddt_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
         }
         else {


            switch(format) {

            case ISMD_AUDIO_MEDIA_FMT_PCM:
            case ISMD_AUDIO_MEDIA_FMT_DVD_PCM:
            case ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM:

               result = ISMD_SUCCESS;
               AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "Codec parameters not set, format is PCM!", audio_devh[AUDIO_DEBUG_APM]);

               break;

            case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:
               if(available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].ddplus_dcv_in_use) {
                  if ((result = audio_ddplus_dcv_set_decode_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {

                     AUDIO_ERROR("audio_ddplus_dcv_set_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
               else {
                  if((result = audio_ddplus_set_decode_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {

                     AUDIO_ERROR("audio_ddplus_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
               break;

            case ISMD_AUDIO_MEDIA_FMT_DD:
               if(available_codecs[ISMD_AUDIO_MEDIA_FMT_DD].ddplus_dcv_in_use) {
                  if ((result = audio_ddplus_dcv_set_decode_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {

                     AUDIO_ERROR("audio_ddplus_dcv_set_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
               else {
                  if((result = audio_dd_set_decode_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {

                     AUDIO_ERROR("audio_dd_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
               break;
               
            case ISMD_AUDIO_MEDIA_FMT_DTS:

               if((result = audio_dts_set_decode_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {

                  AUDIO_ERROR("audio_dts_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }

               break;
             case ISMD_AUDIO_MEDIA_FMT_DTS_BC: 

               if((result = audio_dts_bc_set_decode_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {

                  AUDIO_ERROR("audio_dts_bc_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }

               break;
            case ISMD_AUDIO_MEDIA_FMT_MPEG:
               result = ISMD_SUCCESS;
               if((result = audio_mpeg_set_decode_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_mpeg_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
               break;
               
            case ISMD_AUDIO_MEDIA_FMT_WM9:  
               result = ISMD_SUCCESS;
               if((result = audio_wma_set_decode_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_wma_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
               break;

            case ISMD_AUDIO_MEDIA_FMT_TRUE_HD:
               result = ISMD_SUCCESS;
               if((result = audio_truehd_set_decode_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_truehd_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
               break;

            case ISMD_AUDIO_MEDIA_FMT_DTS_HD: 
            case ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA:
            case ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA:  
               if((result = audio_dts_hd_set_decode_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {

                  AUDIO_ERROR("audio_dts_hd_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
               break; 
               
            case ISMD_AUDIO_MEDIA_FMT_AAC:
            case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS:
               if((result = audio_aac_set_decode_param(&(input_wl->psm_dec_pipe), &(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_aac_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
               break;
               
            default:
            
            case ISMD_AUDIO_MEDIA_FMT_COUNT:
            case ISMD_AUDIO_MEDIA_FMT_INVALID:

               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("No decoder is setup on the input!", result, audio_devh[AUDIO_DEBUG_APM]);

               break;

            }
         }
      }
      else {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("Input must be in a stopped state to set decoder params!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      audio_pvt_input_api_unlock(input_wl);
   } else {
       AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_input_get_decoder_param(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int param_type,
                              ismd_audio_decoder_param_t *param_value )
{
   (void)processor_h;
   (void)input_h;
   (void) param_type;
   (void) param_value;

   return ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
}


static ismd_result_t
audio_pvt_input_primary_set_src_index(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   //If the primary index is not the same as the primary input's index, set and send down the new index.
   if(input_wl->processor_wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.primary_index != input_wl->mixer_input_index){

      input_wl->processor_wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.primary_index = input_wl->mixer_input_index;
      
      if (input_wl->processor_wl->psm_pa_pipe.pipe_configured ) {
         if (( result = audio_psm_stage_config_direct(input_wl->processor_wl->psm_pa_pipe.pipe_h, 
                                               input_wl->processor_wl->psm_pa_pipe.stages[SRC_STAGE].handle, 
                                               &input_wl->processor_wl->psm_pa_pipe.stages[SRC_STAGE].params)) != ISMD_SUCCESS ) {
            AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }
   return result;
}



static ismd_result_t
audio_pvt_input_primary_set_mixer_index(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   if (input_wl->mixer_input_index != AUDIO_INVALID_HANDLE){

      if(result == ISMD_SUCCESS){

         //If the primary index is not the same as the primary input's index, set and send down the new index.
         if(input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.primary_index != input_wl->mixer_input_index){

            input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.primary_index = input_wl->mixer_input_index;
         
            if (input_wl->processor_wl->psm_pa_pipe.pipe_configured ) {
               if (( result = audio_psm_stage_config_direct(input_wl->processor_wl->psm_pa_pipe.pipe_h, 
                                                     input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].handle, 
                                                     &input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params)) != ISMD_SUCCESS ) {
                  AUDIO_ERROR("audio_psm_stage_config_direct failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
         }
      }
   }

   return result;
}

static ismd_result_t
audio_pvt_input_primary_set_awm_notification(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   //Get the current primary index from the mixer if its running. 
   if (input_wl->processor_wl->psm_pa_pipe.pipe_configured ) {
      if (( result = audio_psm_stage_get_config(input_wl->processor_wl->psm_pa_pipe.pipe_h, 
                                            input_wl->processor_wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle, 
                                            &input_wl->processor_wl->psm_pa_pipe.stages[WATERMARK_STAGE].params)) != ISMD_SUCCESS ) {
         AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   if(result == ISMD_SUCCESS){
      input_wl->processor_wl->psm_pa_pipe.stages[WATERMARK_STAGE].params.watermark.notif_events = input_wl->notification_events;

      
      if (input_wl->processor_wl->psm_pa_pipe.pipe_configured ) {
         if (( result = audio_psm_stage_config(input_wl->processor_wl->psm_pa_pipe.pipe_h, 
                                               input_wl->processor_wl->psm_pa_pipe.stages[WATERMARK_STAGE].handle, 
                                               &input_wl->processor_wl->psm_pa_pipe.stages[WATERMARK_STAGE].params)) != ISMD_SUCCESS ) {
            AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }

   return result;
}

ismd_result_t
audio_pvt_input_primary_resync_atc_stream(ismd_audio_input_wl_t *input_wl, audio_atc_stream_t atc_stream_h)
{
   ismd_result_t result = ISMD_SUCCESS;

   // Here we want to sync up the timing control stream of the passthrough stream with the primary stream information. 
   // This is because at any given time the passthrough stream can be added and removed and sometimes we disable the decode
   // stream while a packetizer is running. (ie. MAT ENCODER). In the case of the primary we are only going to send the rebase
   // info down again since that is the only peice of information that is out of sync when its disabled. 
   
   if(input_wl->smd_base_time != 0){ 
      if(AUDIO_INVALID_HANDLE != atc_stream_h){
         result = audio_timing_control_set_base_time(input_wl->processor_wl->atc_h, atc_stream_h, input_wl->smd_base_time);
      }
   }
   
   if((result == ISMD_SUCCESS) && (input_wl->clock != ISMD_CLOCK_DEV_HANDLE_INVALID) && (AUDIO_INVALID_HANDLE != atc_stream_h)){
      result = audio_timing_control_set_clock(input_wl->processor_wl->atc_h, atc_stream_h, input_wl->clock);
   }
   
   if(result == ISMD_SUCCESS){

      if(AUDIO_INVALID_HANDLE != atc_stream_h){
         result = audio_timing_control_set_segment_info(input_wl->processor_wl->atc_h, atc_stream_h, input_wl->rebase_info);
      }
      //Update primary stream rebase information. 
      result = audio_timing_control_set_segment_info(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, input_wl->rebase_info);
   }
   
   if((result == ISMD_SUCCESS) && (input_wl->state != ISMD_DEV_STATE_INVALID)){
      if(AUDIO_INVALID_HANDLE != atc_stream_h){
         result = audio_timing_control_set_state(input_wl->processor_wl->atc_h, atc_stream_h, input_wl->state);
      }
   }      

   return result;
}

static ismd_result_t
audio_pvt_input_set_packetizer_stage(ismd_audio_input_wl_t *input_wl, bool_shared_t disable)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_decode_pipe_t *dec_pipe = &input_wl->psm_dec_pipe;

   /*If the packetizer stage is in use.*/
   if(input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].in_use) {
      /*Check for which stage is being operated on, then disable or enable as requested.*/
      if(dec_pipe->stages[PACKETIZER_STAGE].task == PSM_TASK_PACKETIZE_ENCODED_DATA) {
         if(disable != dec_pipe->stages[PACKETIZER_STAGE].params.packetizer.host.packetize.disable_stage) {
            dec_pipe->stages[PACKETIZER_STAGE].params.packetizer.host.packetize.disable_stage = disable;
            dec_pipe->stages[PACKETIZER_STAGE].params.packetizer.host.packetize.init_done = false;
         }
      }
      else if(dec_pipe->stages[PACKETIZER_STAGE].task == PSM_TASK_PCM_DECODE) {
         if(disable != dec_pipe->stages[PACKETIZER_STAGE].params.pcm_dec.host.pcm_dec.disable_stage) {
            dec_pipe->stages[PACKETIZER_STAGE].params.pcm_dec.host.pcm_dec.disable_stage = disable;
         }
      }

      /*If the pipe is started, try to update the packetizer stage real-time.*/
      if (dec_pipe->pipe_started && input_wl->processor_wl->psm_pass_pipe.pipe_configured) { 
         if((result = audio_psm_stage_config_direct(dec_pipe->pipe_h, dec_pipe->stages[PACKETIZER_STAGE].handle, 
                             &dec_pipe->stages[PACKETIZER_STAGE].params)) != ISMD_SUCCESS) 
         {
            AUDIO_ERROR("audio_psm_stage_config for the Packetizer stage failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }

   /*If IEC parsing is enabled, need to enable the packetized output.*/
   if(input_wl->psm_dec_pipe.stages[IEC_PARSER_STAGE].in_use) {
      dec_pipe->stages[IEC_PARSER_STAGE].params.iec_parse.host.iec_parse.packetized_output_enabled = !disable;
      if (dec_pipe->pipe_started) { 
         if((result = audio_psm_stage_config_direct(dec_pipe->pipe_h, dec_pipe->stages[IEC_PARSER_STAGE].handle, 
                             &dec_pipe->stages[IEC_PARSER_STAGE].params)) != ISMD_SUCCESS) 
         {
            AUDIO_ERROR("audio_psm_stage_config for the IEC parser stage failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }

   return result;
}

static ismd_result_t
audio_pvt_input_manage_passthrough_stream(ismd_audio_input_wl_t *input_wl, ismd_dev_state_t input_state, bool enable)
{
   ismd_result_t result = ISMD_SUCCESS;
   bool is_encoded_data = true;
   int psm_output_queue_id = DEC_PSM_PIPE_PASS_OUT_INDEX; /*Default is the passthrough output.*/

   /*Enable the passthrough stream on this input.*/
   if(enable) {
      if(audio_core_supported_passthrough_format(input_wl->format) && 
        (input_wl->pass_atc_stream_h == AUDIO_INVALID_HANDLE) && 
        (input_wl->psm_dec_pipe.pipe_h != AUDIO_INVALID_HANDLE)) 
      {
      
         /* Need to allocate the post ATC passthrough pipe if not already allocated.*/
         if(input_wl->processor_wl->psm_pass_pipe.pipe_h == AUDIO_INVALID_HANDLE) {
            if((result = audio_psm_pipe_alloc(PSM_PIPE_TYPE_POST_ATC, &(input_wl->processor_wl->psm_pass_pipe.pipe_h))) != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_psm_pipe_alloc PSM pass-through pipe failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }

         /* Tell the ATC if it will be recieving PCM or not. */
         if((input_wl->format == ISMD_AUDIO_MEDIA_FMT_PCM) || 
            (input_wl->format == ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM) || 
            (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DVD_PCM))
         {
            is_encoded_data = false;
         }
         
         /*Add the timing control input queue.*/
         if((result = audio_timing_control_add_stream(
                     input_wl->processor_wl->atc_h, 
                     input_wl->is_timed_stream, 
                     is_encoded_data, input_wl->pass_atc_in_queue_h, 
                     input_wl->pass_atc_out_queue_h, 
                     input_wl->notification_events,
                     input_wl->smd_dev_h,
                     &input_wl->pass_atc_stream_h)) != ISMD_SUCCESS)
         {               
            AUDIO_ERROR("audio_timing_control_add_stream failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         /* TODO: Workaround for MAT streams with sloppy PTS values, allow for 20ms drift. */
         if(input_wl->format == ISMD_AUDIO_MEDIA_FMT_TRUE_HD){
            if((result = audio_timing_control_set_timing_accuracy(input_wl->processor_wl->atc_h,input_wl->pass_atc_stream_h, 20, 20)) != ISMD_SUCCESS) {
               AUDIO_ERROR("Error adding ATC input!",  result, audio_devh[AUDIO_DEBUG_APM]);
            }     
         }

         if((result == ISMD_SUCCESS) && (!input_wl->is_sw_input)){
            if((result = audio_timing_control_set_fixed_delay(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h, input_wl->fixed_back_end_delay_chunk)) != ISMD_SUCCESS){
               AUDIO_ERROR("Error setting fixed delay for phy passthrough input!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         
         /*Add the PSM output queue, if the packetizer is not in use, hook up the queue to the deocder's output. */
         if( (input_wl->format == ISMD_AUDIO_MEDIA_FMT_PCM) || (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DVD_PCM) || (input_wl->format == ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM))  {
            psm_output_queue_id = DEC_PSM_PIPE_DEC_OUT_INDEX;
         }
         
         if ((result = audio_psm_output_queue_add(input_wl->psm_dec_pipe.pipe_h, input_wl->pass_atc_in_queue_h, psm_output_queue_id)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_output_queue_add atc_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         if(result == ISMD_SUCCESS) {
            
            input_wl->has_passthr_stream = true;
            
            /*Set the packetizer stage to enabled, will be updated when post atc pipe is started.*/
            audio_pvt_input_set_packetizer_stage(input_wl, false);
            
            /*If we are in PAUSE or PLAY need to restart post ATC pass pipe since it was freed previously.*/
            if((input_state == ISMD_DEV_STATE_PLAY) || (input_state == ISMD_DEV_STATE_PAUSE)) {
               result = audio_pvt_input_start_post_atc_pipes(input_wl);
            }
         }

         //Need reconfigure renders setup as passthrough to notify them of a possible new input format. 
         audio_processor_reconfig_passthrough_outptus(input_wl->processor_wl);
      }
   }
   /*Disable the passthrough stream on this input.*/
   else {

      /*Disable the packetizer stage first.*/
      audio_pvt_input_set_packetizer_stage(input_wl, true);
      
      /*If the passthrough has been previously hooked up, remove it.*/
      if(input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) {
         /*Remove timing control stream.*/
         if((result = audio_timing_control_remove_stream(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h)) != ISMD_SUCCESS) {               
            AUDIO_ERROR("audio_timing_control_remove_stream failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      /*Remove the PSM output queue from the decoder pipe to disable it. */
      if((input_wl->psm_dec_pipe.pipe_h != AUDIO_INVALID_HANDLE) && input_wl->has_passthr_stream) {
         if ((result = audio_psm_output_queue_remove(input_wl->psm_dec_pipe.pipe_h, input_wl->pass_atc_in_queue_h)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_output_queue_remove atc_pass_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if(input_wl->processor_wl->psm_pass_pipe.pipe_h != AUDIO_INVALID_HANDLE) {
         /*Remove the post ATC passthrough pipeline.*/
         if (audio_psm_pipe_free(input_wl->processor_wl->psm_pass_pipe.pipe_h) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_pipe_free failed in passthrough post ATC pipe.", result, audio_devh[AUDIO_DEBUG_APM]);
         } 
      }

      /* Re-init the post ATC passthrough pipe, since it was freed. */
      audio_processor_init_psm_pipe_wl(&(input_wl->processor_wl->psm_pass_pipe));

      /*Since we removed the ATC stream, re-init handle.*/
      input_wl->pass_atc_stream_h = AUDIO_INVALID_HANDLE;
      input_wl->has_passthr_stream = false;
      input_wl->pass_needs_basetime = false;
      input_wl->pass_needs_clock = false;
      
      /* Flush the queue leading to the ATC. */
      ismd_queue_flush(input_wl->pass_atc_in_queue_h);
   }
   
   return result;
}

ismd_result_t
ismd_audio_input_set_as_primary(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_input_pass_through_config_t pass_through_config )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   ismd_audio_processor_context_t *wl = NULL;
  // bool atc_passthrough = false;

  AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /*Have to lock the processor here since we are touching the processor context here. */
   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS) {

      wl = input_wl->processor_wl;
      
      /* If there is no other existing primary input, set this input as primary if its stopped. 
         If the input is already primary allow it to turn on and off the passthrough flag. */
      if(((wl->primary_input_wl == NULL) && (input_wl->state != ISMD_DEV_STATE_PLAY) && (input_wl->state != ISMD_DEV_STATE_PAUSE)) || 
         ((wl->primary_input_wl != NULL) && (wl->primary_input_wl->smd_dev_h == input_wl->smd_dev_h))) {

         if((result = audio_timing_control_set_as_primary(wl->atc_h, input_wl->atc_stream_h)) != ISMD_SUCCESS) {
            AUDIO_ERROR("Error making input stream primary! Make sure to make the input primary before setting the clock!",  result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else{
            
            if(input_wl->format != ISMD_AUDIO_MEDIA_FMT_INVALID) {
               if(pass_through_config.dts_or_dolby_convert && 
                  input_wl->format == ISMD_AUDIO_MEDIA_FMT_DD_PLUS && 
                  available_dcv_codec.availability) {
                  input_wl->ddplus_dcv_enabled = true;
                  input_wl->ddplus_dcv_dd_enabled = true;
                  
                  // DD+ decoder is installed or not cannot be determined by only check 
                  // available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].availability.
                  // That is because when DCV is installed and DD+ decoder is not installed, 
                  // available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].availability will still be set true. 
                  // Therefore, in order to make sure DD+ deocder's availability, one more condition, 
                  // "!available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].ddplus_dcv_in_use" should be added.
                  if(available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].availability && !available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].ddplus_dcv_in_use) {
                     // If DD+ decoder is installed, the dcv should be used in secondary decode stage.
                     input_wl->dcv_on_secondary_decode_stage = true;
                  }
               }
               
               /*Record this input as the primary input context.*/
               wl->primary_input_wl = input_wl;

               /* Check the passthrough flag to switch to and from passthrough enable.*/
               if(pass_through_config.is_pass_through && !input_wl->has_passthr_stream) {

                  if((result = audio_pvt_input_ms10_setup_passthrough_pipe(input_wl)) != ISMD_SUCCESS) { 
                     result = audio_pvt_input_manage_passthrough_stream(input_wl, input_wl->state, true);
                  }
               }
               else if(!pass_through_config.is_pass_through) {

                  if((result = audio_pvt_input_ms10_passthrough_teardown(input_wl)) != ISMD_SUCCESS) {   
                     result = audio_pvt_input_manage_passthrough_stream(input_wl, input_wl->state, false);
                  }
               }
               if(result == ISMD_SUCCESS){

                  if((result = audio_pvt_input_primary_resync_atc_stream(input_wl, input_wl->pass_atc_stream_h)) == ISMD_SUCCESS){
                     /* Update all the primary input variables */
                     input_wl->input_type = AUDIO_INPUT_TYPE_PRIMARY;
                     input_wl->pass_config = pass_through_config;
                     input_wl->processor_wl->primary_input_format = (audio_core_supported_passthrough_format(input_wl->format)) ? input_wl->format : ISMD_AUDIO_MEDIA_FMT_PCM;
                     /*If the input is primary always goes on the DSP for processing.*/
                     input_wl->needs_pcm_preprocessing = true;

                     if((result = audio_pvt_input_primary_set_mixer_index(input_wl)) != ISMD_SUCCESS) {
                        AUDIO_ERROR("Could not set mixer's primary input index.",  result, audio_devh[AUDIO_DEBUG_APM]);
                     }
                     else if((result = audio_pvt_input_primary_set_src_index(input_wl)) != ISMD_SUCCESS) {
                        AUDIO_ERROR("Could not set SRC's primary input index.",  result, audio_devh[AUDIO_DEBUG_APM]);
                     }
                     else if((result = audio_pvt_input_primary_set_awm_notification(input_wl)) != ISMD_SUCCESS) {
                        AUDIO_ERROR("Could not set AWM primary input notification event!",  result, audio_devh[AUDIO_DEBUG_APM]);
                     }
                     else if((result = audio_processor_reconfig_passthrough_outptus(input_wl->processor_wl)) != ISMD_SUCCESS){
                        AUDIO_ERROR("Reconfiguring passthrough outputs failed!",  result, audio_devh[AUDIO_DEBUG_APM]);
                     }
                     else if((result = audio_pvt_configure_input_dependencies( input_wl->processor_wl )) != ISMD_SUCCESS){
                        AUDIO_ERROR("Could not configure input dep for primary input.",  result, audio_devh[AUDIO_DEBUG_APM]);
                     }
                  }
               }                
            }
            else {
               result = ISMD_ERROR_INVALID_REQUEST;
               AUDIO_ERROR("Please call ismd_audio_input_set_format first!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }
      else {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("Processor already contains a primary input! Or input is not in a STOP state!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
         
      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR(" Invalid processor or input handle.", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   if(result != ISMD_SUCCESS){
      if(NULL != input_wl){  
         input_wl->input_type = AUDIO_INPUT_TYPE_OTHER;
      }
      if(NULL != wl){    /* check to prevent chance of NULL pointer dereferenced  */
         wl->primary_input_wl = NULL;
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t 
ismd_audio_input_set_pass_through_mode(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_pass_through_mode_t mode )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /*Make sure we have a valid pass through mode. */
   if((mode == ISMD_AUDIO_PASS_THROUGH_MODE_DIRECT) || (mode == ISMD_AUDIO_PASS_THROUGH_MODE_IEC61937)) {

      /* Validate and lock the API, this locks the input and the processor. */
      if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS) {

         input_wl->pass_through_mode = mode;

         if((input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].task == PSM_TASK_PACKETIZE_ENCODED_DATA) &&
            input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].in_use)
         {    
            /*Set the mode*/
            input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].params.packetizer.host.packetize.pass_through_mode = input_wl->pass_through_mode;

            /*If the pipe is started, try to update the packetizer stage real-time.*/
            if (input_wl->psm_dec_pipe.pipe_started) { 
               
                /*Need to reinit if called during run time.*/
                input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].params.packetizer.host.packetize.init_done = false;
               if((result = audio_psm_stage_config_direct(input_wl->psm_dec_pipe.pipe_h, 
                                   input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].handle, 
                                   &input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].params)) != ISMD_SUCCESS) 
               {
                  AUDIO_ERROR("audio_psm_stage_config for the Packetizer stage failed", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
         }
         audio_pvt_input_api_unlock(input_wl);
      }
      else {
         AUDIO_ERROR("Invalid input or processor handle!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_input_set_as_secondary( ismd_audio_processor_t processor_h,
                                   ismd_dev_t             input_h )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /* Validate and lock the processor  */
   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS) {

      wl = input_wl->processor_wl;

      /* The secondary stream cannot be a physical input. */
      if ( !input_wl->is_sw_input ) {
         AUDIO_ERROR("Audio physical input can not be secondary input!", result, audio_devh[AUDIO_DEBUG_APM]);
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
      /* The secondary stream cannot also be the primary input. */
      else if ( input_wl->input_type == AUDIO_INPUT_TYPE_PRIMARY ) {
         AUDIO_ERROR("Audio primary input cannot be secondary input!", result, audio_devh[AUDIO_DEBUG_APM]);
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
      /* Is this input already the secondary input? */
      else if ( input_wl->input_type == AUDIO_INPUT_TYPE_SECONDARY ) {
         result = ISMD_SUCCESS;
      }
      /* Is there already a different secondary input. */
      else if ( wl->secondary_input_wl != NULL ) {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("Audio processor already has a secondary input!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {

         input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.secondary_index = input_wl->mixer_input_index;
         input_wl->input_type = AUDIO_INPUT_TYPE_SECONDARY;
         wl->secondary_input_wl = input_wl;

         if ( wl->psm_pa_pipe.pipe_configured ) {
            result = audio_psm_stage_config_direct( wl->psm_pa_pipe.pipe_h, 
                                             wl->psm_pa_pipe.stages[MIXER_STAGE].handle, 
                                            &wl->psm_pa_pipe.stages[MIXER_STAGE].params );
            if ( result != ISMD_SUCCESS ) {
               AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
               input_wl->input_type = AUDIO_INPUT_TYPE_OTHER;
               wl->secondary_input_wl = NULL;
               input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.secondary_index = AUDIO_INVALID_HANDLE;
            }
         }

         audio_pvt_configure_input_dependencies( input_wl->processor_wl );
      }
      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR("Invalid input or processor handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

static ismd_result_t 
audio_pvt_configure_input_dependencies( ismd_audio_processor_context_t *processor_wl )
{
   ismd_audio_input_wl_t *secondary_wl       = NULL;
   ismd_audio_input_wl_t *primary_wl         = NULL;
   int32_t                pri_dec_stage_addr = 0; 
   ismd_result_t          result             = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   /* No processor workload means we don't care. */
   if ( processor_wl == NULL ) {
      result = ISMD_SUCCESS; 
   }

   /* No secondary workload means no dependencies, we're done. */
   else if ( processor_wl->secondary_input_wl == NULL ) {
      result = ISMD_SUCCESS;
   }

   /* Configure the dependencies. */
   else {
      secondary_wl = processor_wl->secondary_input_wl;
      primary_wl   = processor_wl->primary_input_wl;

      if ( primary_wl != NULL ) {
        if ( primary_wl->psm_dec_pipe.pipe_h != AUDIO_INVALID_HANDLE ) {
            audio_psm_pipe_get_stage_phys_address( primary_wl->psm_dec_pipe.stages[DECODE_STAGE].handle, &pri_dec_stage_addr );
         }
      }

      result = ISMD_SUCCESS;

      /*If the decoder stage is setup to decode actual encoded data, update primary decoder stage address. PCM
        decoder stage does not have an entry to do this.*/
      if(secondary_wl->psm_dec_pipe.stages[DECODE_STAGE].task == PSM_TASK_DECODE) {

         secondary_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.pri_dec_stage_addr = pri_dec_stage_addr;

         if ( secondary_wl->psm_dec_pipe.pipe_started&& 
              (secondary_wl->psm_dec_pipe.pipe_h != AUDIO_INVALID_HANDLE) ) {
            result = audio_psm_stage_config_direct( secondary_wl->psm_dec_pipe.pipe_h, 
                                             secondary_wl->psm_dec_pipe.stages[DECODE_STAGE].handle, 
                                             &(secondary_wl->psm_dec_pipe.stages[DECODE_STAGE].params));
         }
      }

   }

   return ( result );
}


void audio_pvt_input_port_config( ismd_audio_input_wl_t *input_wl, 
                                  ismd_port_config_t    *port_config )
{
   port_config->attributes = ISMD_PORT_QUEUE_ON | 
                             ISMD_PORT_QUEUE_MAX_DEPTH_BUFFERS | 
                             ISMD_PORT_QUEUE_DISCONNECT_BLOCK;
   port_config->event_mask = ISMD_QUEUE_EVENT_ALWAYS;
   port_config->max_depth  = 16;
   port_config->watermark  = ISMD_QUEUE_WATERMARK_NONE;
   port_config->event      = (input_wl->processor_wl)->input_port_event;

   return;
}


static ismd_result_t 
audio_pvt_input_configure_port( ismd_audio_input_wl_t *input_wl )
{
   ismd_result_t result;
   int port_depth;
   ismd_port_config_t port_config;


   /* Select the port depth based on the media format. */
   switch ( input_wl->format ) {
      case ( ISMD_AUDIO_MEDIA_FMT_TRUE_HD):
      case ( ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM ):
         /* Blu-Ray PCM is the worst case where PTS values occur every 5ms and 
          * the demux creates a new buffer every time it encounters a PTS, so 
          * 1/2 second of buffering with 1 buffer every 5ms is a total of 100 
          * buffers. */
         port_depth = 150;
         break;

      case ( ISMD_AUDIO_MEDIA_FMT_DVD_PCM ):
         /* DVD PCM typically has a PTS on every packet spaced at intervals 
          * of 20ms, so that makes about 50 buffers per second.  We were able
          * to play all test streams with only 16 buffers.  TODO: find out if 
          * the DVD spec defines the worst case. */
         port_depth = 50;
         break;
       
      case ( ISMD_AUDIO_MEDIA_FMT_DTS):
         /* DTS in some cases has very small chunks with a PTS every 10ms seen i Blu-Ray*/
         port_depth = 75;   
         break;   

      default:
#if 0
         /* For all other compressed data formats, 16 buffers is enough.
          * Compressed audio formats do not have PTS values on every packet
          * and RAW PCM is either untimed or is output from a soft decoder
          * where PTS values occur at the same rate as the compressed stream.
          */
         port_depth = 16;
#else
         /* Google(johngro) : raising this default to be significantly higher.
          * We have encountered some streams where the behavior of the ffmpeg
          * mp4 demux is such that an audio queue which is only 16 entries deep
          * is not deep enough.  The audio queue fills and then blocks the
          * demux preventing it from demuxing any video.  If the video is
          * behind in its presentation schedule, it ends up not being able to
          * catch up because the demux cannot supply any more data to the video
          * codec because it is blocked attempting to push data to the audio
          * renderer.  The simple fix here is to simply raise the size of the
          * audio queue.  Eventually, once we move away from the Intel ISMD
          * Gstreamer wrappers, we will have our own application level queues
          * which will be able to service the kernel driver queues in an event
          * driven fashion, and we should be able to relax this limit back to
          * 16.
          */
         port_depth = 128;
#endif
         break;
   }

   audio_pvt_input_port_config( input_wl, &port_config );
   port_config.max_depth = port_depth;

   result = ismd_port_set_config( input_wl->input_port, &port_config );
   if ( result != ISMD_SUCCESS ) {
      AUDIO_ERROR("Unable to set input port depth!", result, audio_devh[AUDIO_DEBUG_APM]);   
   }

   return ( result );
}


ismd_result_t ismd_audio_input_set_data_format(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_format_t format)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   ismd_audio_format_t previous_format = ISMD_AUDIO_MEDIA_FMT_INVALID;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS) {

      if((input_wl->state != ISMD_DEV_STATE_PLAY) && (input_wl->state != ISMD_DEV_STATE_PAUSE) ) {

         if((format == ISMD_AUDIO_MEDIA_FMT_DD))
         {
            if(available_codecs[ISMD_AUDIO_MEDIA_FMT_DD].ddplus_dcv_in_use)
            {
               input_wl->ddplus_dcv_enabled = true;
               input_wl->ddplus_dcv_pcm_enabled = true;
            }
            else
            {
               input_wl->ddplus_dcv_enabled = false;
            }
            
         }
         else if(format == ISMD_AUDIO_MEDIA_FMT_DD_PLUS)
         {
            if(available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].ddplus_dcv_in_use)
            {
               input_wl->ddplus_dcv_enabled = true;
               input_wl->ddplus_dcv_pcm_enabled = true;
            }
            /* For the case where DD+ decoder is availabe and we want to passthrough DD+ as AC3, 
               input_wl->ddplus_dcv_enabled will be set "true" in ismd_audio_input_set_as_primary()*/
            else
            {
               input_wl->ddplus_dcv_enabled = false;
            }
         }
         else
         {
            input_wl->ddplus_dcv_enabled = false;
         }

         /*Keep track of previous media format*/
         previous_format = input_wl->format;

         /*Make sure we have a valid algorithm*/
         if((result = audio_pvt_input_validate_format(format)) != ISMD_SUCCESS) {
            AUDIO_ERROR("Invalid audio input format!!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         /*If the desired format is the same, just return success*/
         else if(format == input_wl->format){
            result = ISMD_SUCCESS;
         }
         else {
            input_wl->format = format;

            /*Since this is a new codec, need to re-init decoder pipe to init the 
              codec parameters for the new codec. */
            audio_input_init_dec_for_new_format(input_wl);

            /*Check to see if the codec is installed.*/ 
            if(!audio_pvt_available_codec(input_wl->format)) {
               
               if(audio_core_supported_passthrough_format(input_wl->format)) {
                  OS_PRINT("SMD AUDIO: Warning: A decoder for this audio format is not installed, but can be passed through to an output configured as passthrough.\n");          
               }
               else {
                  OS_PRINT("\nSMD AUDIO: Warning: Decode or passthrough of %s is not supported! Input data will be discarded! \n", audio_core_format_to_string(input_wl->format));   
               }
            }
            /*Codec available, set default parameters.*/
            else if((result = audio_pvt_input_decoder_set_default_params(input_wl)) != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_decoder_set_default_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
            
            if(result == ISMD_SUCCESS){
            
               /* if we are changing primary input codec change the primary_codec also */
               if (input_wl == input_wl->processor_wl->primary_input_wl) {
                  input_wl->processor_wl->primary_input_format = input_wl->format;
               }

               /*Change port depth depending on the codec.*/
               audio_pvt_input_configure_port( input_wl );

               /* If the previous format is invalid, we just started up */
               if((result == ISMD_SUCCESS) && ( previous_format == ISMD_AUDIO_MEDIA_FMT_INVALID )) {
                  if (AUDIO_CORE_IS_VALID_MS10_INPUT(input_wl, format)) {
                     if ((result = audio_pvt_input_ms10dec_setup(input_wl))!= ISMD_SUCCESS) {
                        AUDIO_ERROR( "audio_pvt_input_ms10dec_setup failed!", result, audio_devh[AUDIO_DEBUG_APM]);
                     }
                  }
                  /*Allocate a decoder pipe now if the input is not PCM, if the input needs the decoder pipe will be allocated later.*/
                  else if((input_wl->psm_dec_pipe.pipe_h == AUDIO_INVALID_HANDLE) && (input_wl->format != ISMD_AUDIO_MEDIA_FMT_PCM)) {
                     if ((result = audio_psm_pipe_alloc(PSM_PIPE_TYPE_DECODE, &input_wl->psm_dec_pipe.pipe_h))!= ISMD_SUCCESS) {
                         AUDIO_ERROR("Decoder audio_psm_pipe_alloc failed!", result, audio_devh[AUDIO_DEBUG_APM]);
                     }
                  }
               }
               else {
                  
                  /* Proprogate input rebase info to atc_stream_h. atc stream0 has no change to get rebase info with this flag set. restore it here. */
                  if (input_wl->disable_primary_output == true) {
                     audio_timing_control_set_segment_info(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, input_wl->rebase_info);
                  }  
               } 
            }
         }
      }
      else {
         AUDIO_ERROR("Input in play state!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR("Processor or input handle is invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


ismd_result_t ismd_audio_input_set_wma_format(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_wma_format_t wma_stream_format)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);


   if ((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) != ISMD_SUCCESS) {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or input handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   else {

      if(input_wl->format != ISMD_AUDIO_MEDIA_FMT_WM9) {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR( "Format not setup for WMA! Please call ismd_audio_set_format", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         result = audio_pvt_input_validate_wma_param((audio_psm_decode_wm9_config_params_t *)&wma_stream_format);
         if (result == ISMD_SUCCESS) {
            //Set the decode params then setup the decoder.
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.config.wma_params.samp_freq = wma_stream_format.sample_rate;
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.config.wma_params.num_channels = wma_stream_format.num_channels;
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.config.wma_params.w_format_tag = wma_stream_format.format_tag;
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.config.wma_params.pcm_wdsz = wma_stream_format.sample_size;
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.config.wma_params.block_align = wma_stream_format.block_align;
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.config.wma_params.wma_encode_opt = wma_stream_format.encode_option;
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.config.wma_params.avg_bytes_per_sec = wma_stream_format.bitrate;
         }
      }

      audio_pvt_input_api_unlock(input_wl);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}



ismd_result_t ismd_audio_input_set_pcm_format(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int sample_size,
                              int sample_rate,
                              int channel_config)
{

   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl))  == ISMD_SUCCESS) {

      result = audio_pvt_input_validate_pcm_param(input_wl->is_sw_input, sample_size, sample_rate);

      if(result == ISMD_SUCCESS){
         input_wl->sample_size = sample_size;
         input_wl->sample_rate = sample_rate;
         input_wl->out_of_band = true; //Set to out of band notification to tag buffers.

         /* Make sure we have a valid channel config on the input PCM attributes. */
         if(!audio_core_is_valid_ch_config(channel_config)) {
            OS_PRINT("ISMD AUDIO: Warning: Invalid channel configuration suppiled, assuming 2ch default!");
             input_wl->channel_config = AUDIO_CHAN_CONFIG_2_CH;
         }
         else {
            input_wl->channel_config = channel_config;
         }
         
         input_wl->channel_count = audio_core_get_channel_cnt_from_config(input_wl->channel_config);

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
         SVEN_MODULE_EVENT_AUD_IO_APM_SET_PCM_FORMAT,
         input_wl->processor_wl->handle_id,
         input_wl->sample_size,
         input_wl->sample_rate,
         input_wl->channel_config,
         input_wl->channel_count, 0);

         result = ISMD_SUCCESS;

         //For untimed PCM we want to make this queue 3 deep for minimum latency.
         if(!input_wl->is_timed_stream) {
            result = audio_pvt_change_queue_max_depth( input_wl->atc_in_queue_h, 3);
         }
            
      }
      audio_pvt_input_api_unlock(input_wl);

   } else {

      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t 
ismd_audio_input_set_channel_mix( ismd_audio_processor_t          processor_h,
                                  ismd_dev_t                      input_h,
                                  ismd_audio_channel_mix_config_t ch_mix_config )
{
   ismd_result_t                    result        = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t           *input_wl      = NULL;
   ismd_audio_channel_mix_config_t *mixer_config  = NULL;
   int                              input_ch      = 0;
   int                              output_ch     = 0;
   int                              coeff_index   = 0;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   //audio_core_print_mix_config(&ch_mix_config);
    
   result = audio_pvt_input_api_lock( processor_h, input_h, &input_wl );
   if ( result == ISMD_SUCCESS ) {

      mixer_config = &input_wl->mixer_coeff;

      for ( input_ch = 0; input_ch < AUDIO_MAX_INPUT_CHANNELS && result == ISMD_SUCCESS; input_ch++ ) {
         
         mixer_config->input_channels_map[input_ch].input_channel_id = ch_mix_config.input_channels_map[input_ch].input_channel_id;

         //validate the input channel_id
         if((mixer_config->input_channels_map[input_ch].input_channel_id >= 0) && (mixer_config->input_channels_map[input_ch].input_channel_id < AUDIO_MAX_INPUT_CHANNELS)){

         for ( output_ch = 0; output_ch < AUDIO_MAX_OUTPUT_CHANNELS && result == ISMD_SUCCESS; output_ch++ ) {

            result = audio_core_user_gain_to_coeff_index( ch_mix_config.input_channels_map[input_ch].output_channels_gain[output_ch], &coeff_index );

            if ( result == ISMD_SUCCESS ) {
               mixer_config->input_channels_map[input_ch].output_channels_gain[output_ch] = coeff_index;
            }
            else {
               AUDIO_ERROR("Mixer gain parameter is out of range!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         }
         else{
            AUDIO_ERROR("Mixer gain input_channel_id is out of range!", result, audio_devh[AUDIO_DEBUG_APM]);
            result = ISMD_ERROR_INVALID_PARAMETER;
            input_ch = AUDIO_MAX_INPUT_CHANNELS;//Break out.
         }
      } /* for ( input_ch = 0; ... */

      if ( result == ISMD_SUCCESS ) {

         //Need to tell mixer we got coefficients from the user. (out of band)
         input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.oob_gains_set = true;
         //Notify mixer so it will perform a ramp on the next buffer between coefficients. 
         //This flag gets cleared in the FW by the mixer when its done ramping. 
         input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.coeff_changed++;

         /* If the pipe is running, need to update just the host side.
            Else we need update the DSP copy which gets picked up when the
            pipe starts. This is because we just keep 1 copy of the mixer coeff in
            the host params to save some major space. */
         if (input_wl->processor_wl->psm_pa_pipe.pipe_configured ) {
            input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.channel_mix_config = input_wl->mixer_coeff;
            input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.host.mixer.input_index = input_wl->mixer_input_index;
         }
         else {
            input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params.mixer.input_config[input_wl->mixer_input_index].channel_mix_config = input_wl->mixer_coeff;
         }

         /* If the post-processing pipe is running and we are not muted... */
         if ( input_wl->processor_wl->psm_pa_pipe.pipe_configured && !input_wl->processor_wl->muted ) {

            /* Commit the changes to the post-processing pipe. */
            result = audio_psm_stage_config_direct( input_wl->processor_wl->psm_pa_pipe.pipe_h, 
                                             input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].handle, 
                                             &input_wl->processor_wl->psm_pa_pipe.stages[MIXER_STAGE].params );
            if ( result != ISMD_SUCCESS ) {
               AUDIO_ERROR("audio_psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }

      } /* if ( result == ISMD_SUCCESS ) */

      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}


ismd_result_t ismd_audio_input_set_timing_accuracy(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int allowed_ms_drift_ahead,
                              int allowed_ms_drift_behind)
{

   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl))  == ISMD_SUCCESS) {

      if (input_wl->atc_stream_h != AUDIO_INVALID_HANDLE) {
         result = audio_timing_control_set_timing_accuracy(
            input_wl->processor_wl->atc_h, 
            input_wl->atc_stream_h,
            allowed_ms_drift_ahead, 
            allowed_ms_drift_behind);

         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Setting audio_timing_control_set_timing_accuracy failed", (result), audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (result == ISMD_SUCCESS && input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) {
         result = audio_timing_control_set_timing_accuracy(
            input_wl->processor_wl->atc_h, 
            input_wl->pass_atc_stream_h,
            allowed_ms_drift_ahead, 
            allowed_ms_drift_behind);

         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Setting audio_timing_control_set_timing_accuracy failed", (result), audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (result == ISMD_SUCCESS && input_wl->assoc_atc_stream_h != AUDIO_INVALID_HANDLE) {
         result |= audio_timing_control_set_timing_accuracy(
            input_wl->processor_wl->atc_h, 
            input_wl->assoc_atc_stream_h,
            allowed_ms_drift_ahead, 
            allowed_ms_drift_behind);

         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Setting audio_timing_control_set_timing_accuracy failed", (result), audio_devh[AUDIO_DEBUG_APM]);
         }
      }
      
      if(result == ISMD_SUCCESS) {
         input_wl->allowed_ms_drift_ahead = allowed_ms_drift_ahead;
         input_wl->allowed_ms_drift_behind = allowed_ms_drift_behind;
      }

      audio_pvt_input_api_unlock(input_wl);
   } else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t ismd_audio_input_get_timing_accuracy(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int *allowed_ms_drift_ahead,
                              int *allowed_ms_drift_behind)
{

   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl))  == ISMD_SUCCESS) {

      *allowed_ms_drift_ahead = input_wl->allowed_ms_drift_ahead;
      *allowed_ms_drift_behind = input_wl->allowed_ms_drift_behind;
 
      audio_pvt_input_api_unlock(input_wl);

   } else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t ismd_audio_input_enable_watermark_detection(ismd_audio_processor_t processor_h,
                              ismd_dev_t  input_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS) {

      // TODO: Implement me
      result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR("input_validate_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}


ismd_result_t ismd_audio_input_disable_watermark_detection(ismd_audio_processor_t processor_h,
                              ismd_dev_t  input_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl))  == ISMD_SUCCESS) {

      // TODO: Implement me
      result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}

ismd_result_t
ismd_audio_input_get_notification_event( ismd_audio_processor_t    processor_h, 
                                         ismd_dev_t                input_h, 
                                         ismd_audio_notification_t event_type, 
                                         ismd_event_t             *event_handle )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_workload = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   result = audio_pvt_input_api_lock( processor_h, 
                                      input_h, 
                                      &input_workload );
   if ( result == ISMD_SUCCESS ) {
      result = audio_pvt_get_event( input_workload, event_type, event_handle );
      audio_pvt_input_api_unlock(input_workload);
   }
   else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}

ismd_result_t
ismd_audio_reset_notification_event( ismd_audio_processor_t    processor_h,
                              ismd_dev_t input_h, 
                              ismd_audio_notification_t type )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_workload = NULL;
   ismd_event_t event_handle;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if ( (result = audio_pvt_input_api_lock( processor_h, input_h, &input_workload )) == ISMD_SUCCESS ) {

      if((result = audio_pvt_get_event( input_workload, type, &event_handle )) == ISMD_SUCCESS) {
         result = ismd_event_acknowledge(event_handle);
      }      
      audio_pvt_input_api_unlock(input_workload);
   }
   else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}


ismd_result_t 
ismd_audio_input_advance_to_pts( ismd_audio_processor_t    processor_h,
                                 ismd_dev_t                input_h, 
                                 ismd_pts_t                linear_pts )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   result = audio_pvt_input_api_lock( processor_h, input_h, &input_wl );
   if ( result == ISMD_SUCCESS ) {

      if (input_wl->atc_stream_h != AUDIO_INVALID_HANDLE) {
         result = audio_timing_control_set_start_pts(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, linear_pts);
         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Setting audio_timing_control_set_start_pts failed", (result), audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (result == ISMD_SUCCESS && input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) {
         result = audio_timing_control_set_start_pts(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h, linear_pts);
         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Setting audio_timing_control_set_start_pts failed", (result), audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (result == ISMD_SUCCESS && input_wl->assoc_atc_stream_h != AUDIO_INVALID_HANDLE) {
         result |= audio_timing_control_set_start_pts(input_wl->processor_wl->atc_h, input_wl->assoc_atc_stream_h, linear_pts);
         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Setting audio_timing_control_set_start_pts failed", (result), audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (result == ISMD_SUCCESS) {

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
            SVEN_MODULE_EVENT_AUD_IO_APM_ADVANCE_TO_PTS,
            input_wl->processor_wl->handle_id,
            input_wl->input_id,
            (unsigned int) 0, 
            (unsigned int) 0,
            (unsigned int) (linear_pts >> 32), 
            (unsigned int) (linear_pts));
      }

      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}

ismd_result_t 
ismd_audio_input_get_client_id( ismd_audio_processor_t    processor_h,
                                 ismd_dev_t                input_h, 
                                 int                           *client_id )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(client_id == NULL){
      result = ISMD_ERROR_NULL_POINTER;
      return (result);
   }

   result = audio_pvt_input_api_lock( processor_h, input_h, &input_wl );
   if ( result == ISMD_SUCCESS ) {
      
      *client_id = input_wl->client_id_last_seen;
      
      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}

ismd_result_t
ismd_audio_input_get_stream_position( ismd_audio_processor_t    processor_h,
                              ismd_dev_t         input_h, 
                              ismd_audio_stream_position_info_t *position)
{
   ismd_audio_input_wl_t *input_wl = NULL;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if ( (result = audio_pvt_input_api_lock( processor_h, input_h, &input_wl )) == ISMD_SUCCESS ) {

      if((input_wl->rate < AUDIO_MIN_PLAY_RATE) || (input_wl->rate > AUDIO_MAX_PLAY_RATE)){
         
         position->base_time = input_wl->smd_base_time;
         position->scaled_time = input_wl->last_scaled_pts;
         position->segment_time = input_wl->last_segment_pts;
         position->linear_time = input_wl->last_linear_pts;
         position->stream_position = ISMD_NO_PTS;
      }
      else {
         /* Get the stream postion from the ATC stream. */
         audio_core_stream_position_copy(position, &input_wl->atc_stream_pos);
      } 

      /*Give the user the current time*/
      if((result =  ismd_clock_get_time_th_safe(input_wl->clock, &(position->current_time))) != ISMD_SUCCESS) {
         AUDIO_ERROR("No clock set on input, cannot return current time!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


/*********************************************************************************************/
/* APM common input functions*/
/*********************************************************************************************/

void
audio_input_init_dec_pipe(ismd_audio_input_wl_t *input_wl)
{
   /*Init the entire decode pipe.*/
   OS_MEMSET(&(input_wl->psm_dec_pipe), 0, sizeof(audio_psm_decode_pipe_t));
   input_wl->psm_dec_pipe.pipe_h = AUDIO_INVALID_HANDLE;
   input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.ad.valid = AUDIO_DESCRIPTION_NOT_VALID;
   input_wl->psm_dec_pipe.stages[DECODE_STAGE].task = PSM_TASK_DECODE;
   input_wl->psm_dec_pipe.stages[SECONDARY_DECODE_STAGE].params.decoder.ad.valid = AUDIO_DESCRIPTION_NOT_VALID;
   input_wl->psm_dec_pipe.stages[SECONDARY_DECODE_STAGE].task = PSM_TASK_DECODE;
   input_wl->psm_dec_pipe.stages[IEC_PARSER_STAGE].task = PSM_TASK_IEC_PARSER;
   input_wl->psm_dec_pipe.stages[IN_STAGE].task = PSM_TASK_IN;
   input_wl->psm_dec_pipe.stages[OUT_STAGE].task = PSM_TASK_OUT;
   input_wl->psm_dec_pipe.stages[CAPP_STAGE].task = PSM_TASK_CAPP;
   input_wl->psm_dec_pipe.stages[ACCUMLATOR_STAGE].task = PSM_TASK_DATA_ACCUMULATOR;
   input_wl->psm_dec_pipe.stages[PRE_SRC_STAGE].task = PSM_TASK_PRESRC;
   input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].task = PSM_TASK_PACKETIZE_ENCODED_DATA;
   /*These stages are always added to the pipe.*/
   input_wl->psm_dec_pipe.stages[IN_STAGE].in_use = true;
   input_wl->psm_dec_pipe.stages[OUT_STAGE].in_use = true;
   input_wl->psm_dec_pipe.stages[DECODE_STAGE].in_use = true;
   input_wl->psm_dec_pipe.stages[PACKETIZER_STAGE].in_use = true;
}

#if defined(__KERNEL__)
# include <linux/slab.h>
# define __stack_alloc(x)	kmalloc(x, in_atomic() ? GFP_ATOMIC : GFP_KERNEL)
# define __stack_free(x)	kfree(x)
#else
# define __stack_alloc(x)	alloca(x)
# define __stack_free(x)	(void)0
#endif

void
audio_input_init_dec_for_new_format(ismd_audio_input_wl_t *input_wl)
{
   audio_psm_stage_params_t *capp_params = NULL;

   /*Need to save off stored state for stages that dont have their
     host parameters updated during decoder pipe build time.*/
   if (input_wl->psm_dec_pipe.stages[CAPP_STAGE].in_use) {
     capp_params = __stack_alloc(sizeof(*capp_params));
     if (capp_params)
       *capp_params = input_wl->psm_dec_pipe.stages[CAPP_STAGE].params;
   }

   audio_input_init_dec_pipe(input_wl);

   /*Restore saved off parameters.*/
   if (input_wl->psm_dec_pipe.stages[CAPP_STAGE].in_use && capp_params) {
      input_wl->psm_dec_pipe.stages[CAPP_STAGE].params = *capp_params;
      __stack_free(capp_params);
   }
}

#undef __stack_alloc
#undef __stack_free

void
audio_input_init_wl(ismd_audio_input_wl_t *input_wl)
{
   input_wl->processor_id = AUDIO_INVALID_HANDLE;
   input_wl->in_use = false;
   input_wl->disable_primary_output = false;
   input_wl->input_type = AUDIO_INPUT_TYPE_OTHER;
   input_wl->state = ISMD_DEV_STATE_INVALID;
   input_wl->smd_dev_h = ISMD_DEV_HANDLE_INVALID;
   input_wl->is_sw_input = false;
   input_wl->pass_pipe_enabled = false;
   input_wl->pass_queue_has_buf = false;
   input_wl->primary_queue_has_buf = false;
   input_wl->pass_buf_has_ref = false;
   input_wl->out_of_band = false;
   input_wl->disabled = false;
   input_wl->has_passthr_stream = false;
   input_wl->ignore_inband_rate_change = false;
   input_wl->format = ISMD_AUDIO_MEDIA_FMT_INVALID;
   input_wl->sample_size = 16;
   input_wl->sample_rate = 0;
   input_wl->channel_config = 0;
   input_wl->channel_count = 0;
   input_wl->smd_base_time = 0;
   input_wl->capture_h = AUDIO_INVALID_HANDLE;
   input_wl->atc_stream_h = AUDIO_INVALID_HANDLE;
   input_wl->smd_dev_h = ISMD_DEV_HANDLE_INVALID;
   input_wl->mixer_input_index = AUDIO_INVALID_HANDLE;
   input_wl->added_to_post_atc_pipe = false;
   input_wl->rate = ISMD_NORMAL_PLAY_RATE;
   input_wl->pass_atc_stream_disabled = false;
   input_wl->client_id_last_seen = 0;
   input_wl->ad_valid = false;
   input_wl->pass_needs_basetime = true;
   input_wl->pass_needs_clock = true;
   input_wl->last_buffer_discrd_pts_past_stop_value = false;
   input_wl->underrun_event = ISMD_EVENT_HANDLE_INVALID;
   input_wl->allowed_ms_drift_ahead = ATC_DEFAULT_MS_DRIFT_AHEAD;
   input_wl->allowed_ms_drift_behind = ATC_DEFAULT_MS_DRIFT_BEHIND;
   input_wl->parsing_mode = ISMD_AUDIO_INPUT_PARSING_MODE_DISABLED;
   input_wl->pass_through_mode = ISMD_AUDIO_PASS_THROUGH_MODE_IEC61937;
   input_wl->parsing_mode = ISMD_AUDIO_INPUT_PARSING_MODE_DISABLED;
   input_wl->needs_pcm_preprocessing = false;

   input_wl->audio_in_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->audio_in_passthrough_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->pass_psm_pipe_in_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->dec_in_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->atc_in_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->atc_out_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->input_port = ISMD_PORT_HANDLE_INVALID;

   input_wl->pass_atc_stream_h = AUDIO_INVALID_HANDLE;
   input_wl->pass_atc_in_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->pass_atc_out_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->pass_config.is_pass_through = false;

   input_wl->assoc_ms10dec_in_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->assoc_atc_in_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->assoc_atc_out_queue_h = ISMD_QUEUE_HANDLE_INVALID;
   input_wl->assoc_atc_stream_h = AUDIO_INVALID_HANDLE;
   input_wl->ms10_input_type = AUDIO_INPUT_MS10_MAIN_OR_ASSOC_ONLY;     // only valid with MS10 mode

   input_wl->output_buffer = NULL;
   input_wl->clock = ISMD_CLOCK_DEV_HANDLE_INVALID;
   input_wl->slave_clock = ISMD_CLOCK_DEV_HANDLE_INVALID;
   input_wl->timing_mode = ISMD_TIMING_MODE_CONVERTED;
   input_wl->ddplus_dcv_enabled = false;
   input_wl->ddplus_dcv_pcm_enabled = false;
   input_wl->ddplus_dcv_dd_enabled = false;
   input_wl->dcv_on_secondary_decode_stage = false;
   
   audio_input_init_dec_pipe(input_wl);
   audio_input_init_ms10dec_pipe(&input_wl->psm_ms10_pipe);
   audio_input_init_ms10dec_pipe(&input_wl->psm_ms10_pipe_assoc);

   input_wl->wait_with_timeout = false;
   input_wl->apm_base_time = 0;
   input_wl->last_scaled_pts = ISMD_NO_PTS;
   input_wl->last_linear_pts = ISMD_NO_PTS;
   input_wl->last_segment_pts = ISMD_NO_PTS;
   input_wl->curr_scaled_pts = ISMD_NO_PTS;
   input_wl->fixed_back_end_delay_chunk = FIXED_BACK_END_PIPE_DELAY_CHUNK;
   input_wl->capture_sync_clock = ISMD_CLOCK_HANDLE_INVALID;
   
   /* Rebasing variables */
   input_wl->rebase_info.curr_seg_info.linear_start = 0;
   input_wl->rebase_info.curr_seg_info.start = ISMD_NO_PTS;
   input_wl->rebase_info.curr_seg_info.stop = ISMD_NO_PTS;
   input_wl->rebase_info.curr_seg_info.requested_rate = 0;
   
   input_wl->rebase_info.last_linear_rate_change_time = 0;
   input_wl->rebase_info.last_scaled_rate_change_time = 0;
   input_wl->rebase_info.curr_rate = ISMD_NORMAL_PLAY_RATE;

   input_wl->atc_stream_pos.base_time = 0;
   input_wl->atc_stream_pos.current_time = 0;
   input_wl->atc_stream_pos.sample_count = 0;
   input_wl->atc_stream_pos.segment_time = ISMD_NO_PTS;
   input_wl->atc_stream_pos.linear_time = ISMD_NO_PTS;
   input_wl->atc_stream_pos.scaled_time= ISMD_NO_PTS;

   input_wl->input_port_status.cur_depth = 0;
   input_wl->input_port_status.max_depth = 0;
   input_wl->input_port_status.watermark = 0;
   input_wl->asrc_enabled = false;
   OS_MEMSET(&input_wl->parser_status, 0, sizeof(ismd_audio_input_parsing_status_t));
   input_wl->parser_status.triggered_event = ISMD_AUDIO_PARSER_EVENT_NONE;
   input_wl->parser_status.stream_info.algo = ISMD_AUDIO_MEDIA_FMT_INVALID;
   input_wl->parser_status.stream_info.channel_config = AUDIO_CHAN_CONFIG_INVALID;
   input_wl->parser_status.curr_status = ISMD_AUDIO_PARSER_STATUS_SYNC_NOT_FOUND;
   input_wl->parser_event_mask = ISMD_AUDIO_PARSER_EVENT_NONE;
      

   audio_input_mixer_config_set_gain(&input_wl->mixer_coeff, MIX_COEFF_INDEX_0_DB, MIX_COEFF_INDEX_MUTE);

   return;
}


ismd_result_t
audio_remove_input_no_reconfig(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(audio_processor_valid_handle(processor_h)){

      ismd_connection_unregister(ismd_audio_remove_input_callback, (void *) input_h);

      if ((result = ismd_audio_do_remove_input(processor_h, input_h, false)) != ISMD_SUCCESS){
         AUDIO_ERROR("do_remove_input failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else{
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
audio_remove_input_reconfig(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl);
   if(result == ISMD_SUCCESS) {
      ismd_audio_do_remove_input(processor_h, input_h, true);
      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or input handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

void
audio_input_mixer_config_set_gain( ismd_audio_channel_mix_config_t *channel_mix_config, 
                                    int one_to_one_val, int n_by_m_value )
{
   int input_channel, output_channel;

   for ( input_channel = 0; input_channel < AUDIO_MAX_INPUT_CHANNELS; input_channel++ ) {
      channel_mix_config->input_channels_map[input_channel].input_channel_id = input_channel;
      for ( output_channel = 0; output_channel < AUDIO_MAX_OUTPUT_CHANNELS; output_channel++ ) {
         if ( input_channel == output_channel ) {
            channel_mix_config->input_channels_map[input_channel].output_channels_gain[output_channel] = one_to_one_val;
         }
         else {
            channel_mix_config->input_channels_map[input_channel].output_channels_gain[output_channel] = n_by_m_value;
         }
      }
   }  
}

ismd_result_t
audio_input_notify_decoder_of_dmix_modes(ismd_audio_input_wl_t *input_wl, audio_psm_output_configs_t *output_configs)
{
   ismd_result_t result = ISMD_SUCCESS;
   int output = 0;
   int output_index = 0;

   /* Only notify the decoders that support extracting downmix coefficients. */
   if((input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS) || 
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS_HD) ||
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA) ||
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA) || 
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DD) || 
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DD_PLUS) ||
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_AAC) ||
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_AAC_LOAS)) {

      /*Initialize the decoder params struct that stores the output info. */
      for(output = 0; output < AUDIO_MAX_OUTPUTS; output++) {

         if(input_wl->psm_dec_pipe.stages[DECODE_STAGE].task == PSM_TASK_DECODE) {
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.outputs [output].dmix_mode = ISMD_AUDIO_DOWNMIX_INVALID;
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.outputs [output].ch_count = 0;
         }

         input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.outputs [output].dmix_mode = ISMD_AUDIO_DOWNMIX_INVALID;
         input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.outputs [output].ch_count = 0;

         input_wl->psm_ms10_pipe_assoc.dec_stage_params.decoder.host.codec.outputs [output].dmix_mode = ISMD_AUDIO_DOWNMIX_INVALID;
         input_wl->psm_ms10_pipe_assoc.dec_stage_params.decoder.host.codec.outputs [output].ch_count = 0;
      }

      /* Populate the downmix modes into the decoder parameters.*/
      for(output = 0; output < output_configs->count; output++) {
         
         /*This index is the output handle which is used to index in to the array storing the downmix coefficients.*/
         output_index = output_configs->outputs[output].output_handle; 
         if(input_wl->psm_dec_pipe.stages[DECODE_STAGE].task == PSM_TASK_DECODE) {
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.outputs[output_index].dmix_mode= output_configs->outputs[output].dmix_mode;
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.outputs[output_index].ch_count = output_configs->outputs[output].channel_count;
         }

         input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.outputs[output_index].dmix_mode= output_configs->outputs[output].dmix_mode;
         input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.outputs[output_index].ch_count = output_configs->outputs[output].channel_count;

         input_wl->psm_ms10_pipe_assoc.dec_stage_params.decoder.host.codec.outputs[output_index].dmix_mode= output_configs->outputs[output].dmix_mode;
         input_wl->psm_ms10_pipe_assoc.dec_stage_params.decoder.host.codec.outputs[output_index].ch_count = output_configs->outputs[output].channel_count;
      }
      if ( input_wl->psm_dec_pipe.pipe_started && (input_wl->psm_dec_pipe.pipe_h != AUDIO_INVALID_HANDLE) &&
         (input_wl->psm_dec_pipe.stages[DECODE_STAGE].task == PSM_TASK_DECODE)) 
      {
         result = audio_psm_stage_config_direct( input_wl->psm_dec_pipe.pipe_h, 
            input_wl->psm_dec_pipe.stages[DECODE_STAGE].handle, &input_wl->psm_dec_pipe.stages[DECODE_STAGE].params);
      }

      if ( input_wl->psm_ms10_pipe.dec_pipe_configured && (input_wl->psm_ms10_pipe.dec_pipe_h != AUDIO_INVALID_HANDLE) ) {
         result = audio_psm_stage_config_direct( input_wl->psm_ms10_pipe.dec_pipe_h, 
            input_wl->psm_ms10_pipe.dec_stage_h, &input_wl->psm_ms10_pipe.dec_stage_params);
      }

      if ( input_wl->psm_ms10_pipe_assoc.dec_pipe_configured && (input_wl->psm_ms10_pipe_assoc.dec_pipe_h != AUDIO_INVALID_HANDLE) ) {
         result = audio_psm_stage_config_direct( input_wl->psm_ms10_pipe_assoc.dec_pipe_h, 
            input_wl->psm_ms10_pipe_assoc.dec_stage_h, &input_wl->psm_ms10_pipe_assoc.dec_stage_params);
      }
      
   }

   return result;
}


static ismd_result_t
audio_pvt_change_queue_max_depth( ismd_queue_handle_t queue_h, int max_depth)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_queue_config_t config;

   /* Ensure we are passed a postive number. */
   if(max_depth > 0) {
      
      if((result = ismd_queue_get_config( queue_h, &config )) != ISMD_SUCCESS) {
         AUDIO_ERROR("ismd_queue_get_config failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         
         /* Set the queue's new max depth. */
         config.max_depth = max_depth;
         
         if((result = ismd_queue_set_config( queue_h, &config )) != ISMD_SUCCESS) {
            AUDIO_ERROR("ismd_queue_set_config failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }
   return result;
}


static ismd_result_t
audio_pvt_input_chk_disable_pass_stream( ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   
   //If we have a passthrough and going into trick modes, disable it. We are disabling right before the ATC since we do not want to 
   //spend the MIPS on the cleanup algorithm on this stream. 
   if((input_wl->rate != ISMD_NORMAL_PLAY_RATE) && !input_wl->pass_atc_stream_disabled && (input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE)){
      audio_psm_output_queue_disable(input_wl->psm_dec_pipe.pipe_h, input_wl->pass_atc_in_queue_h);
      input_wl->pass_atc_stream_disabled = true;
   }
    //If we have a passthrough and coming out of trick modes, enable it.
   else if((input_wl->rate == ISMD_NORMAL_PLAY_RATE) && input_wl->pass_atc_stream_disabled && (input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE)){

      //Restore the segment information on the passthrough stream, then enable the queue. 
      audio_timing_control_set_segment_info(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h, input_wl->rebase_info);
      audio_psm_output_queue_enable(input_wl->psm_dec_pipe.pipe_h, input_wl->pass_atc_in_queue_h);
      input_wl->pass_atc_stream_disabled = false;
   }

   return result;
}

static inline void 
audio_pvt_apm_update_wait(ismd_audio_input_wl_t  *input_wl)  
{
   int loop;
   ismd_audio_input_wl_t  *local_input_wl;

   input_wl->processor_wl->wait_with_timeout = false;
   for(loop = 0; loop < input_wl->processor_wl->input_count; loop++){
      local_input_wl = &(input_wl->processor_wl->inputs[loop]);
      if((local_input_wl != NULL) && (local_input_wl->wait_with_timeout)){
         input_wl->processor_wl->wait_with_timeout = true;
         break;
      }
   }
}

static ismd_result_t
audio_pvt_apm_handle_newsegment_timed( ismd_audio_input_wl_t *input_wl, ismd_buffer_descriptor_t *buffer_des )
{
   ismd_newsegment_tag_t newsegment_data;
   ismd_result_t result = ISMD_SUCCESS;
   ismd_pts_t prev_scaled_rate_change_time = 0;

   if ( buffer_des->tags_present ) {
      
      if ((result = ismd_tag_get_newsegment( buffer_des->unique_id, &newsegment_data )) == ISMD_SUCCESS ) {

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_APM],
            SVEN_MODULE_EVENT_AUD_IO_APM_NEWSEGMENT,
            input_wl->input_id,
            (unsigned int) newsegment_data.start,
            (unsigned int) newsegment_data.stop,
            (unsigned int) newsegment_data.linear_start,
            newsegment_data.requested_rate,
            input_wl->rebase_info.curr_rate);

         /* Cache the previous scaled rate change time */
         prev_scaled_rate_change_time = input_wl->rebase_info.last_scaled_rate_change_time;

         /* Figure out the new "last_scaled_rate_change_time" */
         ismd_convert_linear_time_to_scaled_time(
                  newsegment_data.linear_start,   
                  input_wl->rebase_info.last_linear_rate_change_time,
                  prev_scaled_rate_change_time,
                  input_wl->rebase_info.curr_rate,
                  & input_wl->rebase_info.last_scaled_rate_change_time);

         /*Check for a valid rate, and if we are not in oob rate mode change with out a flush.*/
         if(newsegment_data.rate_valid && !input_wl->ignore_inband_rate_change ) {
            
            input_wl->rate = newsegment_data.requested_rate;
            
            if ((input_wl->rate < AUDIO_MIN_PLAY_RATE) || (input_wl->rate > AUDIO_MAX_PLAY_RATE) ) {
               input_wl->wait_with_timeout = true;
               if(ismd_event_strobe(input_wl->processor_wl->input_port_event) != ISMD_SUCCESS){
                  AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed in handle new seg!\n", audio_devh[AUDIO_DEBUG_APM]);
               }
            }
            else {
               input_wl->wait_with_timeout = false;
            }
            audio_pvt_apm_update_wait(input_wl); 
            
            /* Update the last linear rate change time to the current linear start time. */
            input_wl->rebase_info.curr_rate = newsegment_data.requested_rate;
         }

         /* Update the last linear rate change time */
         input_wl->rebase_info.last_linear_rate_change_time =  newsegment_data.linear_start;

         /*Record the current segement info */
         input_wl->rebase_info.curr_seg_info.start = newsegment_data.start;
         input_wl->rebase_info.curr_seg_info.stop = newsegment_data.stop;
         input_wl->rebase_info.curr_seg_info.linear_start = newsegment_data.linear_start;

         /*Reset this since we have a new stop value.*/
         input_wl->last_buffer_discrd_pts_past_stop_value = false;
      }    
   }
   
   return ( result );
}


static void
audio_pvt_apm_handle_pts_scaling( ismd_audio_input_wl_t *input_wl, ismd_pts_t *scaled_pts_ptr, ismd_pts_t *linear_pts_ptr, ismd_buffer_descriptor_t *buffer_des )
{
   ismd_pts_t  segment_pts = ISMD_NO_PTS;
   ismd_pts_t scaled_pts = ISMD_NO_PTS;
   ismd_pts_t linear_pts = ISMD_NO_PTS;

   if(buffer_des != NULL) {
      
      segment_pts = ((ismd_es_buf_attr_t *)&(buffer_des->attributes))->original_pts;

     //Rebase the PTS if its valid. 
      if( segment_pts != ISMD_NO_PTS) {

         //Check to see if we have a valid start time, if not assign it to the first PTS
         if( input_wl->rebase_info.curr_seg_info.start == ISMD_NO_PTS ) {
            input_wl->rebase_info.curr_seg_info.start = segment_pts; //Might be -1 in reverse, should be error other wise if in forward playback. 
         }
         

         ismd_convert_segment_time_to_linear_time(
                              segment_pts, 
                              input_wl->rebase_info.curr_seg_info.start, 
                              input_wl->rebase_info.curr_seg_info.stop, 
                              input_wl->rebase_info.curr_rate, 
                              input_wl->rebase_info.curr_seg_info.linear_start,
                              &linear_pts );

         ismd_convert_linear_time_to_scaled_time(
                              linear_pts, 
                              input_wl->rebase_info.last_linear_rate_change_time,
                              input_wl->rebase_info.last_scaled_rate_change_time,
                              input_wl->rebase_info.curr_rate,
                              &scaled_pts);

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_APM],
            SVEN_MODULE_EVENT_AUD_IO_APM_SCALE_PTS,
            (unsigned int) (segment_pts >>32),
            (unsigned int) (segment_pts),
            (unsigned int) (linear_pts >> 32),
            (unsigned int) (linear_pts),
            (unsigned int) (scaled_pts >> 32),
            (unsigned int) (scaled_pts));

         /*Re-assign the new PTS as the PTS to use down-stream */
         *scaled_pts_ptr = scaled_pts;
         *linear_pts_ptr = linear_pts;

      }
     
   }
  
   return ;
}

static void
audio_pvt_apm_handle_pts_and_segments(ismd_audio_input_wl_t *input_wl, bool *dequeue, ismd_buffer_descriptor_t *buffer_des)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_pts_t curr_pts = ISMD_NO_PTS;
   ismd_pts_t scaled_pts = ISMD_NO_PTS;
   ismd_pts_t linear_pts = ISMD_NO_PTS;

   curr_pts = ((ismd_es_buf_attr_t *)&(buffer_des->attributes))->original_pts;
   audio_pvt_apm_handle_newsegment_timed( input_wl, buffer_des );

   /*Get the current time from the clock manager.*/
   if((result = ismd_clock_get_time_th_safe(input_wl->clock, &input_wl->apm_base_time)) != ISMD_SUCCESS) {
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "APM: ismd_clock_get_time_th_safe failed!", audio_devh[AUDIO_DEBUG_APM]);
   }

   /* Scale only if timed stream, and the current PTS is with in the segment. BLURAY PCM decode and DVD LPCM decoding require PTS values always execute in that case. */
   if(input_wl->is_timed_stream || (input_wl->format == ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM) ||(input_wl->format == ISMD_AUDIO_MEDIA_FMT_DVD_PCM)) {
      
      if((curr_pts == ISMD_NO_PTS)||(curr_pts == 0)||(input_wl->rate < 0)){
         *dequeue = true;
         input_wl->curr_scaled_pts = ISMD_NO_PTS;
      }
      else {
         
         audio_pvt_apm_handle_pts_scaling( input_wl, &scaled_pts, &linear_pts, buffer_des);

         /* This is a check to see if we should dequeue and throw away while we are in trick modes at a rate we dont support. */   
         if(((input_wl->timing_mode == ISMD_TIMING_MODE_ORIGINAL) && (curr_pts <= input_wl->apm_base_time + AUDIO_PIPE_TIME_TICKS)) ||
            ((input_wl->timing_mode != ISMD_TIMING_MODE_ORIGINAL) && (scaled_pts + input_wl->smd_base_time <= input_wl->apm_base_time + AUDIO_PIPE_TIME_TICKS))) {
            *dequeue = true; 
            
            input_wl->last_linear_pts = linear_pts;
            input_wl->last_segment_pts = curr_pts;
            input_wl->last_scaled_pts = scaled_pts;
            input_wl->curr_scaled_pts = scaled_pts;//Used for APM timing lite, reset on ISMD_NO_PTS.
            
            AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_APM],
               SVEN_MODULE_EVENT_AUD_IO_APM_HANDLE_PTS,
               (unsigned int) (scaled_pts >>32),
               (unsigned int) (scaled_pts),
               (unsigned int) (input_wl->smd_base_time >> 32),
               (unsigned int) (input_wl->smd_base_time),
               (unsigned int) (input_wl->apm_base_time >> 32),
               (unsigned int) (input_wl->apm_base_time));
         }
         /* While we are in normal timed mode, always updat the variables. */
         else if ((input_wl->rate >= AUDIO_MIN_PLAY_RATE) && (input_wl->rate <= AUDIO_MAX_PLAY_RATE) ) {
            input_wl->last_linear_pts = linear_pts;
            input_wl->last_segment_pts = curr_pts;
            input_wl->last_scaled_pts = scaled_pts;
            input_wl->curr_scaled_pts = scaled_pts; //Used for APM timing lite, reset on ISMD_NO_PTS.
         }
         
      }
   }
   else {
      *dequeue = true;
   }

   return ;
}

static bool
audio_pvt_input_need_to_discard( ismd_audio_input_wl_t *input_wl)
{
   ismd_newsegment_tag_t newsegment_data;
   ismd_buffer_descriptor_t *tags_buffer = NULL;
   bool discard_buffer = false;
   audio_buffer_attr_t *audio_buf_attr;   
   int temp_tag_input_h;
   ismd_pts_t curr_pts = ISMD_NO_PTS;
   int64_t pts_time = 0;

   curr_pts = ((ismd_es_buf_attr_t *)&(input_wl->output_buffer->attributes))->original_pts;
   
   /* Want to discard before the decoder if we are playing at a rate that is out of playback rate range.*/
   if (input_wl->state == ISMD_DEV_STATE_PLAY &&
      ((input_wl->rate < AUDIO_MIN_PLAY_RATE) || (input_wl->rate > AUDIO_MAX_PLAY_RATE))
      ) {
      discard_buffer = true;
   }

   /* Handle stop case, if the PTS is beyond the stop value discard. */
   if(((input_wl->rebase_info.curr_seg_info.stop != ISMD_NO_PTS) && (curr_pts != ISMD_NO_PTS) && (curr_pts > input_wl->rebase_info.curr_seg_info.stop)) || 
      input_wl->last_buffer_discrd_pts_past_stop_value) {
      
      discard_buffer = true;
      
      /* Make sure we only fire off the end of segement event once */
      if(!input_wl->last_buffer_discrd_pts_past_stop_value){
         audio_core_notify_event(input_wl->notification_events, ISMD_AUDIO_NOTIFY_SEGMENT_END);
         input_wl->last_buffer_discrd_pts_past_stop_value = true;
      }
   }

   /* Here we are doing a "timing lite" check to see if we have time to actually decode and send to ATC
      if not discard this buffer.*/
   pts_time = (RENDER_PREFILL_CHUNK + input_wl->fixed_back_end_delay_chunk) * AUDIO_CORE_GET_CHUNK_PERIOD(input_wl) * CLOCK_TICKS_PER_MS;
   if(input_wl->timing_mode == ISMD_TIMING_MODE_ORIGINAL) {
      pts_time = curr_pts - pts_time;
   } else {
      pts_time = input_wl->curr_scaled_pts + input_wl->smd_base_time - pts_time;
   }
   if((pts_time < (int64_t)(input_wl->apm_base_time)) && 
      input_wl->is_timed_stream && 
      (input_wl->smd_base_time != 0) && 
      (input_wl->state == ISMD_DEV_STATE_PLAY) && 
      (input_wl->curr_scaled_pts!= 0) && 
      (input_wl->curr_scaled_pts != ISMD_NO_PTS)) {
      
      discard_buffer = true;
      
      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
         SVEN_MODULE_EVENT_AUD_IO_APM_PTS_LATE,
         (unsigned int) ( input_wl->curr_scaled_pts >> 32), 
         (unsigned int) ( input_wl->curr_scaled_pts ),
         (unsigned int) ( input_wl->smd_base_time >> 32), 
         (unsigned int) ( input_wl->smd_base_time ),
         (unsigned int) ( input_wl->apm_base_time >> 32), 
         (unsigned int) ( input_wl->apm_base_time ));

      /* Need to track and notify if underrun occurs. */
      audio_core_handle_underrun_tracking(
         input_wl->input_id,
         input_wl->underrun_event, 
         &input_wl->underrun_count, 
         &input_wl->underrun_amount,  
         ABS((int64_t)(input_wl->apm_base_time - pts_time)));

      audio_core_notify_event(input_wl->notification_events, ISMD_AUDIO_NOTIFY_PTS_VALUE_LATE);
      
   }   
   //Dont reset the counter if its an invalid PTS. 
   else if(input_wl->curr_scaled_pts != ISMD_NO_PTS){

      // underrun happened in previous buffer.
      if (input_wl->underrun_amount != 0) {
         audio_core_notify_event(input_wl->notification_events, ISMD_AUDIO_NOTIFY_PTS_VALUE_RECOVERED);
      }
      
      input_wl->underrun_amount = 0;
      input_wl->underrun_count = 0;
   }

   if ( input_wl->output_buffer->tags_present ) {
      
      if (ismd_tag_get_newsegment( input_wl->output_buffer->unique_id, &newsegment_data ) == ISMD_SUCCESS ) {

         //Need to propagate this buffer with tags if we are throwing away.
         //So allocate a 0 size buffer put the tags on it and send it down stream.
         if (discard_buffer ) {

            if(ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS, 0, &tags_buffer) != ISMD_SUCCESS){
               OS_PRINT("\nAudio Warning: could not allocate buffer at input to propagate tags. Tags lost!\n");
            }
            else if(ismd_tag_copy_all(input_wl->output_buffer->unique_id, tags_buffer->unique_id) != ISMD_SUCCESS){
               OS_PRINT("\nAudio Warning: could not copy tags at input to propagate tags. Tags lost!\n");
            }
            else{
               audio_buf_attr = (audio_buffer_attr_t *)(input_wl->output_buffer->attributes);
               temp_tag_input_h = audio_buf_attr->tag_input_h;
               audio_buf_attr->tag_input_h = AUDIO_INVALID_HANDLE;
               audio_buf_attr = (audio_buffer_attr_t *)(tags_buffer->attributes);
               audio_buf_attr->tag_input_h = temp_tag_input_h;
               ismd_audio_buffer_dereference(input_wl->output_buffer->unique_id);
               input_wl->output_buffer = tags_buffer;
               discard_buffer = false;
            }         
         }

         audio_pvt_input_chk_disable_pass_stream(input_wl);
         
      }    
   }
   
   return ( discard_buffer );
}

void
audio_pvt_input_handle_port_status(ismd_audio_input_wl_t* input_wl)
{
   /* This function assumes the caller is passing a valid input_wl  */
   ismd_port_status_t curr_status;
   ismd_port_status_t prev_status = input_wl->input_port_status;

   if ( input_wl->notification_events[ISMD_AUDIO_NOTIFY_INPUT_EMPTY-1] != ISMD_EVENT_HANDLE_INVALID 
      || input_wl->notification_events[ISMD_AUDIO_NOTIFY_INPUT_FULL-1] != ISMD_EVENT_HANDLE_INVALID
      || input_wl->notification_events[ISMD_AUDIO_NOTIFY_INPUT_RECOVERED-1] != ISMD_EVENT_HANDLE_INVALID) {
      // user request input status events. 
      if (ismd_port_get_status(input_wl->input_port, &curr_status) == ISMD_SUCCESS) {

         if (curr_status.cur_depth >= curr_status.max_depth 
            && prev_status.cur_depth < prev_status.max_depth) {
            // Not full --> Full
            audio_core_notify_event(input_wl->notification_events, ISMD_AUDIO_NOTIFY_INPUT_FULL);
         }
         else if(curr_status.cur_depth == 0 && prev_status.cur_depth > 0) {
            // Not empty --> empty
            audio_core_notify_event(input_wl->notification_events, ISMD_AUDIO_NOTIFY_INPUT_EMPTY);
         }
         else if(curr_status.cur_depth > 0 && prev_status.cur_depth == 0) {
            // Empty --> not empty
            audio_core_notify_event(input_wl->notification_events, ISMD_AUDIO_NOTIFY_INPUT_RECOVERED);
         }
         else {
            // ignore any other case
         }

         input_wl->input_port_status = curr_status;
      }
   }
   
   return;
}

void *
audio_input_port_manager_thread(void *context)
{
   ismd_result_t result;
   ismd_audio_processor_context_t *wl = (ismd_audio_processor_context_t *) context;
   ismd_audio_input_wl_t  *input_wl = NULL;
   int handle = 0;
   bool ports_need_servicing = true;
   audio_buffer_attr_t *audio_buffer_attr;   
   int client_id;
   unsigned int timeout;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   while(!wl->start_to_close)
   {
      if(wl->wait_with_timeout){
         timeout = AUDIO_APM_WAIT_TIMEOUT_MS;
      }
      else {
         timeout = ISMD_TIMEOUT_NONE;
      }

      result = ismd_event_wait(wl->input_port_event, timeout);
      if((result != ISMD_SUCCESS)&&(result != ISMD_ERROR_TIMEOUT)){
         AUDIO_ERROR("input port thread: ismd_event_wait failed!", result,  audio_devh[AUDIO_DEBUG_APM]);
      }
      if((result = ismd_event_acknowledge(wl->input_port_event)) != ISMD_SUCCESS) {
         AUDIO_ERROR("ismd_event_acknowledge failed!", result,  audio_devh[AUDIO_DEBUG_APM]);
      }

      ports_need_servicing = true;

      while(ports_need_servicing && !wl->start_to_close) {

         ports_need_servicing = false;

         for(handle = 0; handle < AUDIO_MAX_INPUTS; handle++)
         {
            input_wl = &(wl->inputs[handle]);

            audio_pvt_input_lock(input_wl);

            if(input_wl->in_use) {

               /* notify audio input port status to user */
               audio_pvt_input_handle_port_status(input_wl);

               /* If the output_buffer is NULL, try to get another, if not try to enqueue on output */
               if(input_wl->output_buffer == NULL) {

                  if(audio_pvt_input_read_port_buffer(input_wl, input_wl->input_port, &(input_wl->output_buffer)) == ISMD_SUCCESS) {
                     ports_need_servicing = true;
                     audio_buffer_attr = (audio_buffer_attr_t *)(input_wl->output_buffer->attributes);
                     if (input_wl->output_buffer->tags_present){
                        audio_buffer_attr->tag_input_h = input_wl->smd_dev_h;
                        if (ismd_tag_get_client_id(input_wl->output_buffer->unique_id, &client_id) == ISMD_SUCCESS) {
                           
                           input_wl->client_id_last_seen = client_id;
                        }                     
                     }
                     else {
                        audio_buffer_attr->tag_input_h = AUDIO_INVALID_HANDLE;
                     }
                     
                     /* Check for conditions that would make us need to discard the buffer. */
                     if (audio_pvt_input_need_to_discard( input_wl)) {
                        
                        ismd_audio_buffer_dereference(input_wl->output_buffer->unique_id);
                        input_wl->output_buffer = NULL;
                     }
                     else {

                        /* Got valid input buffer, flush cache if fast_path enabled */
                        if ((input_wl->output_buffer != NULL) && audio_core_fast_path_enabled()) {
                           // under fast_path_enabled case, make sure the data of input buffer is flushed from cache.
                           cache_flush_buffer( input_wl->output_buffer->virt.base, input_wl->output_buffer->phys.level );
                        }
                        
                        /* Need to fill out the buffer with OOB buffer attributes, if we got the OOB call*/
                        if(input_wl->out_of_band && input_wl->format == ISMD_AUDIO_MEDIA_FMT_PCM){
                           audio_pvt_input_add_oob_buf_attr(input_wl, input_wl->output_buffer);
                        }
                        else {
                           audio_buffer_attr_t *audio_buffer_attr = (audio_buffer_attr_t *)((input_wl->output_buffer)->attributes);
                           audio_buffer_attr->opt_metadata_offset = OPT_METADATA_INVALID;
                        }

                     }
                  }
               }

               if(input_wl->output_buffer != NULL) {

                  //Need to send buffer to passthrough pipe if its enabled.
                  if (AUDIO_CORE_IS_MS10(input_wl) && input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_AND_ASSOC){ 
                     audio_pvt_input_feed_pass_and_primary_queue( input_wl, input_wl->assoc_ms10dec_in_queue_h, input_wl->audio_in_queue_h, &ports_need_servicing );
                  }
                  else if(!AUDIO_CORE_IS_MS10(input_wl) && input_wl->pass_pipe_enabled) {
                     audio_pvt_input_feed_pass_and_primary_queue( input_wl, input_wl->audio_in_passthrough_queue_h, input_wl->audio_in_queue_h, &ports_need_servicing );
                  }

                  else{
                     //Only enqueue if we have a valid handle, if no valid handle, deref since no available output.
                     if(input_wl->audio_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
                        if((result = ismd_queue_enqueue(input_wl->audio_in_queue_h, input_wl->output_buffer)) == ISMD_SUCCESS){
                              input_wl->output_buffer = NULL;
                              ports_need_servicing = true;
                        }
                     }
                     else {
                        ismd_buffer_dereference(input_wl->output_buffer->unique_id);
                        input_wl->output_buffer = NULL;
                        ports_need_servicing = true;
                     }
                  }
               }
            }

            //If the input is not in use make sure the output buffer is discarded, since we could be flushing.
            else {

               if( input_wl->output_buffer != NULL){
                  ismd_audio_buffer_dereference(input_wl->output_buffer->unique_id);
                  input_wl->output_buffer = NULL;
               }
            }
            audio_pvt_input_unlock(input_wl);
         }
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return NULL;
}


/*********************************************************************************************/


/*********************************************************************************************/
/* Input private functions. */
/*********************************************************************************************/

static ismd_result_t
audio_pvt_input_feed_pass_and_primary_queue( ismd_audio_input_wl_t *input_wl, ismd_queue_handle_t pass_queue, ismd_queue_handle_t primary_queue, bool *work_to_do )
{
   ismd_result_t result = ISMD_SUCCESS;

   
   if((!input_wl->pass_buf_has_ref)&& (!input_wl->disable_primary_output)){

      if(ismd_buffer_add_reference(input_wl->output_buffer->unique_id) == ISMD_SUCCESS){
         input_wl->pass_buf_has_ref = true;
      }
   }

   if(!input_wl->pass_queue_has_buf){

      if((result = ismd_queue_enqueue(pass_queue, input_wl->output_buffer)) == ISMD_SUCCESS) {

         input_wl->pass_queue_has_buf = true;
         *work_to_do = true;
      }
   }

   if(!input_wl->primary_queue_has_buf){

      if(input_wl->disable_primary_output) {
         input_wl->primary_queue_has_buf = true;
         *work_to_do = true;
      }
      else {
         if((result = ismd_queue_enqueue(primary_queue, input_wl->output_buffer)) == ISMD_SUCCESS) {

            input_wl->primary_queue_has_buf = true;
            *work_to_do = true;
         }
      }
   }

   if(input_wl->pass_queue_has_buf && input_wl->primary_queue_has_buf){

      input_wl->output_buffer = NULL;
      input_wl->primary_queue_has_buf = false;
      input_wl->pass_queue_has_buf = false;
      input_wl->pass_buf_has_ref = false;
   }

   return result;
}


ismd_result_t
audio_pvt_input_queue_callback(void *context, ismd_queue_event_t queue_event, ismd_buffer_handle_t *buffer )
{
   ismd_audio_input_wl_t *input_wl = (ismd_audio_input_wl_t *)context;
   ismd_audio_processor_context_t  *wl = input_wl->processor_wl;

   //Avoid compiler warnings
   (void) buffer;
      if ( queue_event & (ISMD_QUEUE_EVENT_NOT_FULL | ISMD_QUEUE_EVENT_LOW_WATERMARK | ISMD_QUEUE_EVENT_EMPTY) ) {
         if(ismd_event_strobe(wl->input_port_event) != ISMD_SUCCESS)
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed input queue callback!\n", audio_devh[AUDIO_DEBUG_APM]);
      }
  return ISMD_ERROR_NO_DATA_AVAILABLE;
}

static void
audio_pvt_input_add_oob_buf_attr( ismd_audio_input_wl_t    *input_wl, 
                                  ismd_buffer_descriptor_t *buffer )
{
   audio_buffer_attr_t *audio_buffer_attr = (audio_buffer_attr_t *)(buffer->attributes);

   audio_buffer_attr->sample_rate    = input_wl->sample_rate;
   audio_buffer_attr->sample_size    = input_wl->sample_size;
   audio_buffer_attr->channel_config = input_wl->channel_config;
   audio_buffer_attr->channel_count  = input_wl->channel_count;
   audio_buffer_attr->audio_format   = input_wl->format;
   audio_buffer_attr->opt_metadata_offset = OPT_METADATA_INVALID;

/*
      AUDIO_EVENT(4, audio_devh[AUDIO_DEBUG_APM],
         SVEN_MODULE_EVENT_AUD_IO_APM_SET_OOB_BUF_ATTR,
         input_wl->smd_dev_h,
         (unsigned int)(audio_buffer_attr->local_pts>>32),
         (unsigned int)(audio_buffer_attr->local_pts),
         audio_buffer_attr->sample_rate,
         audio_buffer_attr->sample_size,
         audio_buffer_attr->channel_count );
 */
   return;
}

static bool
audio_pvt_input_check_chunk_period(ismd_audio_input_wl_t* input_wl)
{
   ismd_audio_processor_context_t* another_processor_wl = NULL;
   ismd_audio_input_wl_t *another_input_wl = NULL;
   int handle_proc = 0;
   int handle_input = 0;
   bool ready_to_commit = true;

   /* There are limitations to change chunk period, if two audio processor had different chunksize:
    * Case1: This is first audio processor in use, or the another processor has no inputs  -- OK to change
    * Case1.1: Two audio processors are in use, and have same chunk period -- OK to change
    * Case2: There already two processors in use, and current audio processor is going to add an untimed capture input with different chunksize -- OK to change 
    * Case3: There already two processors in use, and current audio processor is going to add an normal input with same chunksize -- OK to change
    * Case4: There already two processors in use, and another audio processor only have an untimed capture input -- OK to change
    * All other case, should return error.
    */
   
   // this function should only be called with audio_pvt_input_lock. 
   for(handle_proc=0; handle_proc < AUDIO_MAX_PROCESSORS; handle_proc++) {
   
      if (input_wl->processor_id == handle_proc) {
         // skip current processor
      }
      else if (audio_processor_lock_and_get_wl(handle_proc, &another_processor_wl) == ISMD_SUCCESS) {
   
         if (AUDIO_CORE_GET_CHUNK_PERIOD(input_wl) == another_processor_wl->chunk_size_period){
            // Case1.1 two processors have same chunk period
            ready_to_commit = true;
         }
         else if (!input_wl->is_sw_input) {
            // case2. current processor is adding untimed capture pipeline
            ready_to_commit = true;
         }
         else if (another_processor_wl->input_count == 0) {
            // Case1. another processor have no audio input yet. Safe to commit chunk period change
            ready_to_commit = true;
         }
         else if (another_processor_wl->input_count == 1) {
            
            // find out that this input is untimed capture mode. 
            for(handle_input = 0; handle_input < AUDIO_MAX_INPUTS; handle_input ++) {
   
               another_input_wl = another_processor_wl->inputs + handle_input;
               /*Lock input instance*/
               audio_pvt_input_lock(another_input_wl);
               if (another_input_wl->in_use) {
   
                  if (!another_input_wl->is_sw_input && !another_input_wl->is_timed_stream) {
                     // Case 4, the another processor has only one untimed capture port
                     ready_to_commit = true;
                  }
                  else {
                     ready_to_commit = false;
                  }
   
                  // break out
                  handle_input = AUDIO_MAX_INPUTS;
               }
               audio_pvt_input_unlock(another_input_wl);
            }
         }
         else {
            ready_to_commit = false;
         }
         
         audio_processor_unlock(another_processor_wl);
      }
   } // end of for loop

   return ready_to_commit;
}

static ismd_result_t
audio_pvt_input_commit_chunk_period_change(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   int current_clock_alarm_period = 0;

   OS_ASSERT(input_wl != NULL);

   /*
    * This function will first do consistency check weather we are safe to change the period. 
    * Then, commit the chunk period if necessary. 
    */

   // this function should only be called with audio_pvt_input_lock. 
   if (AUDIO_CORE_GET_PROCESSOR(input_wl)->input_count == 0) {
      
      // check wheather we are allowed to change chunk_period
      if (audio_pvt_input_check_chunk_period(input_wl)) {

         if (!input_wl->is_sw_input && !input_wl->is_timed_stream) {
            // we will bypass ATC under this case, so no need to commit chunk period  
            result = ISMD_SUCCESS;
         }
         else {

            if ((result = audio_timing_control_get_clock_alarm_period(
               AUDIO_CORE_GET_PROCESSOR(input_wl)->atc_h, &current_clock_alarm_period)) != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_timing_control_get_clock_alarm_period failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            if (current_clock_alarm_period == AUDIO_CORE_GET_CHUNK_PERIOD(input_wl)) {
               // no need to change current setting
               result = ISMD_SUCCESS;
            }
            // OK we need to change chunk period in ATC's clock alarm
            else if ((result = audio_timing_control_change_chunk_period(
                  AUDIO_CORE_GET_PROCESSOR(input_wl)->atc_h,
                  AUDIO_CORE_GET_CHUNK_PERIOD(input_wl))
               ) != ISMD_SUCCESS) {
               
               AUDIO_ERROR("audio_timing_control_change_chunk_period failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }
      else {
         result = ISMD_ERROR_OPERATION_FAILED;
      }
   }
   else {
      // this is not first input. We do not need to commit change.
      result = ISMD_SUCCESS;
   }

   return result;
}

static ismd_result_t
audio_pvt_add_input(ismd_audio_processor_context_t *wl, 
                              bool is_sw_input,
                              bool timed_stream,
                              ismd_dev_t *input_h, 
                              ismd_port_handle_t *port_h)
{
   int handle;
   int audio_max_inputs = max_num_inputs_per_processor;
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   ismd_dev_ops_t ops;
   ismd_audio_input_wl_t *input_wl = NULL;

   OS_ASSERT( wl != NULL);
   OS_ASSERT( input_h != NULL);

   /*If we are in MS10 mode need to reserve one input's resources for the associated stream.*/
   if(wl->process_mode == AUDIO_PROCESS_MODE_MS10) {
      audio_max_inputs --;
   }

   /* Query Processor for an available input instance */
   for (handle =0; handle < audio_max_inputs; handle++) {

      input_wl = &(wl->inputs[handle]);

      /*Lock input instance*/
      audio_pvt_input_lock( input_wl );

      if (!input_wl->in_use) {

         /*If handle found, setup an SMD device for this stream.*/
         ops.close = ismd_audio_close_stream;
         ops.flush = ismd_audio_flush_stream;
         ops.set_base_time = ismd_audio_set_stream_base_time;
         ops.set_clock = ismd_audio_set_stream_clock;
         ops.set_state = ismd_audio_set_stream_state;
         ops.set_play_rate = ismd_audio_set_stream_play_rate;
         ops.set_underrun_event = ismd_audio_set_underrun_event;
         ops.get_underrun_amount = ismd_audio_get_underrun_amount;
         ops.get_state = ismd_audio_get_stream_state;
         ops.get_base_time = ismd_audio_get_stream_base_time;
         ops.get_play_rate = ismd_audio_get_stream_play_rate;
         ops.set_slave_clock = ismd_audio_set_stream_slave_clock;

         //Needed in alloc_resources
         input_wl->processor_id = wl->handle_id;
         input_wl->processor_wl = wl;
         input_wl->is_timed_stream = timed_stream;
         input_wl->is_sw_input = is_sw_input;
         input_wl->input_id = handle;

         /* Each input has a fixed location (index) for every stage leading up to the mixer. The fixed location is 
            input_id of each input context which happens to be the input context index used when 
            the input is created.*/
         input_wl->mixer_input_index = handle;

         if ( (result = ismd_dev_handle_alloc(ops, input_h)) != ISMD_SUCCESS ) {
            AUDIO_ERROR("dev_handle_alloc failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         else if((result = ismd_dev_set_user_data(*input_h, (uint32_t)input_wl)) != ISMD_SUCCESS ) {
               AUDIO_ERROR("dev_set_user_data failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         /* Allocate all resources needed for an input*/
         else if((result = audio_pvt_input_alloc_resources(input_wl)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_pvt_input_alloc_resources failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         else if((result = audio_timing_control_add_stream(
                        input_wl->processor_wl->atc_h, 
                        timed_stream, 
                        false, input_wl->atc_in_queue_h, 
                        input_wl->atc_out_queue_h, 
                        input_wl->notification_events,
                        *input_h,
                        &input_wl->atc_stream_h)) != ISMD_SUCCESS)
         {               
            AUDIO_ERROR("audio_timing_control_add_stream failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         /* Notify the ATC of the memory location of where it should put it stream information so the APM can access that location.*/
         else if((result = audio_timing_control_set_stream_pos_mem_locaton(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, &input_wl->atc_stream_pos)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_timing_control_set_stream_pos_mem_locaton failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else if ( (result = audio_pvt_input_commit_chunk_period_change(input_wl)) != ISMD_SUCCESS) {
            AUDIO_ERROR("failed to change chunk period!\n", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else {

            result = ISMD_SUCCESS;
            input_wl->processor_wl = wl;
            input_wl->in_use = true;
            input_wl->smd_dev_h = *input_h;
            audio_input_initialize_events( input_wl );
            /*Default input queue feeds the decoder*/
            input_wl->audio_in_queue_h = input_wl->dec_in_queue_h;

            wl->input_count ++;

			// If the Input stream is a timed stream, increment the number of timed streams count.
			if(input_wl->is_timed_stream) {
			   wl->timed_input_count++;
			}

            /*Assign the port handle if its not a phys input. */
            if(port_h != NULL) {
               *port_h = input_wl->input_port;
            }

            AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
               SVEN_MODULE_EVENT_AUD_IO_APM_INPUT_PORT_ADD,
               input_wl->input_id, input_wl->input_port, input_wl->is_timed_stream,
               input_wl->atc_stream_h,0,0);
            
            /*Avoid break statement.*/
            handle = AUDIO_MAX_INPUTS;
         }

         /* Clean up on failure.*/
         if(result != ISMD_SUCCESS && input_wl != NULL){

            audio_timing_control_remove_stream(input_wl->processor_wl->atc_h, input_wl->atc_stream_h);
            ismd_queue_disconnect_input(input_wl->atc_in_queue_h);

            if (is_sw_input) {
               ismd_queue_disconnect_input(input_wl->pass_atc_in_queue_h);
            }

            ismd_dev_handle_free(*input_h);
            *input_h = AUDIO_INVALID_HANDLE;
            audio_input_init_wl(input_wl);
            
            handle = AUDIO_MAX_INPUTS;
         }

      }

      audio_pvt_input_unlock( input_wl );
   }

   // Test if the fast output mode has to be changed. 
   audio_set_fast_output_mode(wl);

   return result;
}

static ismd_result_t
audio_pvt_remove_input(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *processor_wl = input_wl->processor_wl;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /* This sections removes Phys/SW (port) inputs. */
   {
      input_wl->in_use = false; //Notify port manager not to use this input anymore.

	  // If the Input stream is a timed stream, decrement the number of timed streams count.
	  if(input_wl->is_timed_stream) {
		 processor_wl->timed_input_count--;
      }

      if(audio_timing_control_remove_stream(processor_wl->atc_h , input_wl->atc_stream_h ) != ISMD_SUCCESS){
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"timing_control_remove_stream failed!", audio_devh[AUDIO_DEBUG_APM]);
      }

      /* Take care of removing any passthrough stream associated with the input. */
      if(input_wl->has_passthr_stream){
         audio_pvt_input_ms10_passthrough_teardown( input_wl);
      }

      /*This tears down pass through and decoder pipe.*/
      audio_pvt_input_decoder_teardown(input_wl, ISMD_DEV_STATE_STOP);

      /* Notify post ATC PSM pipe we are removing the input. */
      if((result = audio_processor_psm_pipe_remove_input(processor_wl, input_wl->input_id) != ISMD_SUCCESS)) {
         AUDIO_ERROR("Error in removing the input from the audio post processing pipe.\n", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      // try to release MS10 resource
      if (audio_pvt_input_ms10dec_teardown(input_wl) != ISMD_SUCCESS) {
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"audio_pvt_input_ms10dec_teardown failed decoder pipe!", audio_devh[AUDIO_DEBUG_APM]);
      }
      
      /* Make sure our out_buffer is de-ref'd*/
      if(input_wl->output_buffer != NULL) {
         ismd_audio_buffer_dereference(input_wl->output_buffer->unique_id);
         input_wl->output_buffer = NULL;
      }

      /* Flush and free the input port. */
      if (ismd_port_flush(input_wl->input_port) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"port_flush failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);

      if (ismd_port_free(input_wl->input_port) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"port_free failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);

      /* This section removes hardware inputs. */
      if (!input_wl->is_sw_input) {
         if (audio_pvt_phys_input_shutdown(input_wl) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"phys input shutdown failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      /* Free all queues associated with the input. */
      if (input_wl->audio_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if (ismd_queue_free(input_wl->audio_in_queue_h) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free of audio_in_queue failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (input_wl->pass_psm_pipe_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if (ismd_queue_free(input_wl->pass_psm_pipe_in_queue_h) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free of pass_psm failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (input_wl->pass_atc_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if (ismd_queue_free(input_wl->pass_atc_in_queue_h) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free of passthrough_queue_h failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (input_wl->assoc_ms10dec_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if (ismd_queue_free(input_wl->assoc_ms10dec_in_queue_h) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free of assoc_ms10dec_in_queue_h failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (input_wl->pass_atc_out_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if (ismd_queue_free(input_wl->pass_atc_out_queue_h) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free of passthrough_queue_h failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (input_wl->assoc_atc_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if (ismd_queue_free(input_wl->assoc_atc_in_queue_h) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free of assoc_atc_in_queue_h failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (input_wl->assoc_atc_out_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if (ismd_queue_free(input_wl->assoc_atc_out_queue_h) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free of assoc_atc_out_queue_h failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (input_wl->dec_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if (ismd_queue_free(input_wl->dec_in_queue_h) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free of dec_in_queue failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (input_wl->atc_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if (ismd_queue_free(input_wl->atc_in_queue_h) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free of atc_in_queue failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (input_wl->atc_out_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if (ismd_queue_free(input_wl->atc_out_queue_h) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free of atc_out_queue failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      audio_input_deinitialize_events( input_wl );
   }

   result = ismd_dev_handle_free(input_wl->smd_dev_h);
   if (result != ISMD_SUCCESS) {
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"ismd_dev_handle_free failed in remove_input!\n", audio_devh[AUDIO_DEBUG_APM]);
   }

   /* Reset all input workload variables. */
   audio_input_init_wl(input_wl);

   if((result = audio_render_set_heartbeat_timer_clock_handle(processor_wl->atc_timer_clock_h)) != ISMD_SUCCESS){
      AUDIO_ERROR("audio_render_set_heartbeat_timer_clock_handle failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   processor_wl->input_count --;

   audio_pvt_apm_update_wait(input_wl);  

   // Test if the fast output mode has to be changed. 
   audio_set_fast_output_mode(processor_wl);
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
audio_pvt_input_validate_wl(ismd_dev_t input_h, ismd_audio_input_wl_t **input_wl)
{
   ismd_result_t  result = ISMD_ERROR_INVALID_HANDLE;
   ismd_audio_input_wl_t *in_wl = NULL;
   uint32_t smd_data = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if ((result = ismd_dev_get_user_data(input_h, &smd_data)) == ISMD_SUCCESS) {

      in_wl = (ismd_audio_input_wl_t *) smd_data;
      if(in_wl != NULL){
         if(input_h != in_wl->smd_dev_h){
            AUDIO_ERROR("ismd_dev_get_user_data failed to get correct handle", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else{
            *input_wl = in_wl;
            result = ISMD_SUCCESS;
         }
      }
      else {
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"ismd_dev_get_user_data failed, tag notification cannot be done!", audio_devh[AUDIO_DEBUG_APM]);
      }
   } 

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
audio_pvt_input_api_dev_lock(ismd_dev_t input_h, ismd_audio_input_wl_t **input_wl)
{
   ismd_result_t  result = ISMD_ERROR_INVALID_HANDLE;
   ismd_audio_input_wl_t *in_wl = NULL;
   uint32_t smd_data = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if ((result = ismd_dev_get_user_data(input_h, &smd_data)) == ISMD_SUCCESS) {

      in_wl = (ismd_audio_input_wl_t *) smd_data;

      /*Lock down the processor and input before checking context variables.*/
      audio_processor_lock(in_wl->processor_wl);
      audio_pvt_input_lock(in_wl);

      /* If the input handle doesn't match what the core gave us 
         or the context is not is use return an error.*/
      if((input_h != in_wl->smd_dev_h) || (!in_wl->in_use)){
         result = ISMD_ERROR_INVALID_HANDLE;
         audio_pvt_input_unlock(in_wl);
         audio_processor_unlock(in_wl->processor_wl);
      } else {
         *input_wl = in_wl;
      }
   } else {
      AUDIO_ERROR("ismd_dev_get_user_data failed in input_validate", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


static ismd_result_t
audio_pvt_input_api_lock(ismd_audio_processor_t proc_h, ismd_dev_t input_h, ismd_audio_input_wl_t **input_wl)
{
   ismd_result_t  result = ISMD_ERROR_INVALID_HANDLE;
   ismd_audio_processor_context_t *wl = NULL;
   ismd_audio_input_wl_t *in_wl = NULL;
   uint32_t smd_data = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(audio_processor_lock_and_get_wl(proc_h, &wl) == ISMD_SUCCESS) {

      if (ismd_dev_get_user_data(input_h, &smd_data) == ISMD_SUCCESS) {

         in_wl = (ismd_audio_input_wl_t *) smd_data;

         audio_pvt_input_lock(in_wl);

         if (!in_wl->in_use) {

            audio_pvt_input_unlock(in_wl);
            audio_processor_unlock(wl);
         } else {

            *input_wl = in_wl;
            result = ISMD_SUCCESS;
         }
      } else {
      	audio_processor_unlock(wl);
      	AUDIO_ERROR("ismd_dev_get_user_data failed in input_validate", result, audio_devh[AUDIO_DEBUG_APM]);
      }

   } else {
      AUDIO_ERROR("Invalid processor handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


static ismd_result_t
audio_pvt_input_validate_format(ismd_audio_format_t format)
{
   ismd_result_t  result = ISMD_ERROR_INVALID_PARAMETER;

   switch(format) {

      case ISMD_AUDIO_MEDIA_FMT_PCM:
      case ISMD_AUDIO_MEDIA_FMT_DVD_PCM:
      case ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM:
      case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:
      case ISMD_AUDIO_MEDIA_FMT_DD:
      case ISMD_AUDIO_MEDIA_FMT_MPEG:
      case ISMD_AUDIO_MEDIA_FMT_AAC:
      case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS:
      case ISMD_AUDIO_MEDIA_FMT_DTS:
      case ISMD_AUDIO_MEDIA_FMT_WM9:
      case ISMD_AUDIO_MEDIA_FMT_TRUE_HD:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA:     
      case ISMD_AUDIO_MEDIA_FMT_DTS_LBR:
	   case ISMD_AUDIO_MEDIA_FMT_DTS_BC:
         result = ISMD_SUCCESS;
         break;
      case ISMD_AUDIO_MEDIA_FMT_INVALID:
      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         break;
   }

   return result;
}

static ismd_result_t
audio_pvt_input_validate_required_param(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;

   if(input_wl != NULL) {

      switch(input_wl->format) {
         case ISMD_AUDIO_MEDIA_FMT_WM9:
            result = audio_pvt_input_validate_wma_param(&(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.config.wma_params));
            break;
         case ISMD_AUDIO_MEDIA_FMT_PCM:
            result = audio_pvt_input_validate_pcm_param(input_wl->is_sw_input,
                                                        input_wl->sample_size,
                                                        input_wl->sample_rate);
            break;
         default:
            //Not necessary to check other formats
            result = ISMD_SUCCESS;
            break;
      }
   }
   else {
      result = ISMD_ERROR_NULL_POINTER;
   }
   
   return result;
}

static ismd_result_t
audio_pvt_input_validate_pcm_param(  bool is_sw_input,
                                                   int sample_size,
                                                   int sample_rate)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   
   if(is_sw_input){
      if(!audio_pvt_input_valid_sample_size(sample_size)){
         AUDIO_ERROR("Invalid input sample size!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else{
         result = ISMD_SUCCESS;
      }
   }
   else{
      if(!audio_pvt_input_valid_capture_sample_size(sample_size)){
         AUDIO_ERROR("Invalid input sample size!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else{
         result = ISMD_SUCCESS;
      }
   }
   
   if(result == ISMD_SUCCESS){
      if(!audio_pvt_input_valid_sample_rate(sample_rate)){
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid input sample rate!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   return result;
}


static ismd_result_t
audio_pvt_input_validate_wma_param(audio_psm_decode_wm9_config_params_t *wma_params)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;

   if(wma_params != NULL) {
      switch(wma_params->samp_freq){
         case 8000:
         case 11025:
         case 12000:
         case 16000:
         case 22050:
         case 32000:
         case 44100:
         case 48000:
            result = ISMD_SUCCESS;
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;            
            AUDIO_ERROR("Invalid input sample frequency!", result, audio_devh[AUDIO_DEBUG_APM]);
            break;
      }
      if(result == ISMD_SUCCESS){
         switch(wma_params->num_channels){
            case 1:
            case 2:
               result = ISMD_SUCCESS;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;               
               AUDIO_ERROR("Invalid input number of channels!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
      }
      if(result == ISMD_SUCCESS){
         if(wma_params->w_format_tag == 0x161){
            result = ISMD_SUCCESS;
         }
         else{
            /* For now, we only support standard WMA, not WMA Pro, etc. */            
            AUDIO_ERROR("Invalid input format tag!", result, audio_devh[AUDIO_DEBUG_APM]);
            result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         }
      }
      if(result == ISMD_SUCCESS){
         /* Check number of bits per output sample */
         if(wma_params->pcm_wdsz != 16){            
            AUDIO_ERROR("Invalid input number of bits per output sample!", result, audio_devh[AUDIO_DEBUG_APM]);
            result = ISMD_ERROR_INVALID_PARAMETER;
         }
      }
   }
   return result;
}

static bool
audio_pvt_input_valid_sample_size(int sample_size)
{
   bool result = false;

   switch(sample_size){
      case 8:
      case 16:
      case 20:
      case 24:
      case 32:
         result = true;
         break;
      default:
         break;
   }
   return result;
}

static bool
audio_pvt_input_valid_capture_sample_size(int sample_size)
{
   bool result = false;

   switch(sample_size){
      case 16:
      case 24:
         result = true;
         break;
      default:
         break;
   }
   return result;
}


static bool
audio_pvt_input_valid_sample_rate(int sample_rate)
{
   bool result = false;
   switch(sample_rate){
      case 8000:
      case 11025:
      case 12000:
      case 16000:
      case 22050:
      case 24000:
      case 32000:
      case 44100:
      case 48000:
      case 88200:
      case 96000:
      case 176400:
      case 192000:
         result = true;
         break;
      default:
         AUDIO_ERROR("Sample rate not supported at this time!", ISMD_ERROR_FEATURE_NOT_SUPPORTED, audio_devh[AUDIO_DEBUG_APM]);
         break;
   }
   return result;
}

static void
audio_pvt_input_lock(ismd_audio_input_wl_t *instance) {
   //AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   if(instance != NULL) {
      os_mutex_lock(&instance->lock);
   }

   //AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
}


void
audio_pvt_input_unlock(ismd_audio_input_wl_t *instance) {
   //AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   if(instance != NULL) {
      os_mutex_unlock(&instance->lock);
   }

   //AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
}

void
audio_pvt_input_api_unlock(ismd_audio_input_wl_t *instance) {
   audio_pvt_input_unlock(instance);
   audio_processor_unlock(instance->processor_wl);
}


static ismd_result_t
audio_pvt_input_alloc_resources(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_port_config_t port_config;
   char port_name[SMD_PORT_NAME_LENGTH];
   int32_t atc_input_queue_depth;
   int32_t atc_pass_input_queue_depth;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);


   /*Build PCM pipe by default, allocate all the queues we will ever need on this input.

      PCM_Input:           in_port == ATC == PSM
      DECODER_Input:   in_port == dec_in_queue_h == ATC == PSM
   */
   if(!input_wl->is_sw_input){
      if(!input_wl->is_timed_stream){
         atc_input_queue_depth = 3;
         atc_pass_input_queue_depth = 3;
      }
      else {
         atc_input_queue_depth = 30;
         atc_pass_input_queue_depth = 30;
      }
   }
   else {
      atc_input_queue_depth = 6;
      atc_pass_input_queue_depth = 6;
   }

   /*Configure input port.*/
   audio_pvt_input_port_config( input_wl, &port_config );

   strncpy(port_name, "audio input port", SMD_PORT_NAME_LENGTH);

   /*Allocate input port: <user_app> == IN_PORT */
   if((result = ismd_port_alloc_named(ISMD_PORT_TYPE_INPUT, &port_config, port_name, 16, 0, &(input_wl->input_port))) != ISMD_SUCCESS){
      AUDIO_ERROR("Error alloc input port from SMD!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Allocate queue: IN_PORT===pass_through Packetizer */
   else if((result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, 3,"pass psm input queue", 20, 0, &(input_wl->pass_psm_pipe_in_queue_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("Error alloc srub input queue!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Allocate queue: IN_PORT===associated audio for ms10 mode */
   else if((result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, 3,"assoc audio input queue", 20, 0, &(input_wl->assoc_ms10dec_in_queue_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("Error alloc ms10_assoc input queue!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Allocate queue: IN_PORT===Decoder.*/
   else if((result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, 3,"dec input queue", 15, 0, &(input_wl->dec_in_queue_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("Error alloc decoder input queue!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Allocate queue: Decoder===ATC */
   else if((result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, atc_input_queue_depth,"atc input queue", 15, 0, &(input_wl->atc_in_queue_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("alloc atc input queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Allocate queue: ATC=== POST_ATC PSM */
   else if((result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, 3,"atc output queue", 16, 0, &(input_wl->atc_out_queue_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("alloc atc output queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Allocate Passthrough queue: pass_through Packetizer===ATC */
   else if((result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, atc_pass_input_queue_depth,"pass_atc_in_q", 24, 0, &(input_wl->pass_atc_in_queue_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_queue_alloc_named failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Allocate Passthrough queue: ATC === POST_PASS_ATC PSM */
   else if((result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, 3,"pass_atc_out_q", 24, 0, &(input_wl->pass_atc_out_queue_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_queue_alloc_named failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Allocate MS10 associate audio queue: assoc_dec ===ATC */
   else if((result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, atc_input_queue_depth,"atc input queue", 15, 0, &(input_wl->assoc_atc_in_queue_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("alloc atc input queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   /*Allocate MS10 associate audio queue: ATC === POST_ATC */
   else if((result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, 3,"atc output queue", 16, 0, &(input_wl->assoc_atc_out_queue_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("alloc atc output queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }   

   /*Clean up if we failed*/
   if(result != ISMD_SUCCESS){
      ismd_queue_free(input_wl->audio_in_queue_h);
      ismd_queue_free(input_wl->dec_in_queue_h);
      ismd_queue_free(input_wl->atc_in_queue_h);
      ismd_queue_free(input_wl->atc_out_queue_h);
      ismd_queue_free(input_wl->pass_atc_in_queue_h);
      ismd_queue_free(input_wl->pass_atc_out_queue_h);
      ismd_port_free(input_wl->input_port);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


static ismd_result_t
audio_pvt_phys_input_startup(ismd_audio_input_wl_t *input_wl)
{
   /* start up capture port */
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_capture_t* capture_h = &input_wl->capture_h;

   /*Open and start up the capture device always writes to the decoder input queue.*/
   if(input_wl->capture_h == AUDIO_INVALID_HANDLE){
      if ((result = audio_capture_open(capture_h, input_wl->hw_id, input_wl->dec_in_queue_h,(void*)input_wl)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Error in capture_open, in phys_input_startup.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   if(result == ISMD_SUCCESS){
      if (!audio_core_is_valid_metadata(input_wl->sample_rate, input_wl->sample_size, input_wl->channel_count)) {
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid metadata, in phys_input_startup.\n", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if((result = audio_capture_set_sample_rate(*capture_h, input_wl->sample_rate))!= ISMD_SUCCESS) {
         AUDIO_ERROR("Error in capture set sample_rate, in phys_input_startup.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if((result = audio_capture_set_sample_size(*capture_h, input_wl->sample_size))!= ISMD_SUCCESS) {
         AUDIO_ERROR("Error in capture set sample_size, in phys_input_startup.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if((result = audio_capture_set_channel_config(*capture_h, input_wl->channel_config, input_wl->channel_count))!= ISMD_SUCCESS) {
         AUDIO_ERROR("Error in capture set channel_config, in phys_input_startup.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if((result = audio_capture_set_sync_clock(*capture_h, input_wl->capture_sync_clock))!= ISMD_SUCCESS) {
         AUDIO_ERROR("Error in capture set sync_clock, in phys_input_startup.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if((result = audio_capture_set_data_format(*capture_h, input_wl->format))!= ISMD_SUCCESS) {
         AUDIO_ERROR("Error in capture set audio format, in phys_input_startup.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if((result = audio_capture_set_state(*capture_h, ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Error in capture_set_state, in phys_input_startup.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         /* setup successful */
      }
   }
   if (result != ISMD_SUCCESS) {
      audio_capture_close(*capture_h);
      input_wl->capture_h = AUDIO_INVALID_HANDLE;
   }
   return result;
}

static ismd_result_t
audio_pvt_phys_input_shutdown(ismd_audio_input_wl_t *input_wl)
{
   /* shutdown capture port */
   ismd_result_t result = ISMD_SUCCESS;

   if(input_wl->capture_h != AUDIO_INVALID_HANDLE){

      if((result = audio_capture_close(input_wl->capture_h)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Error in capture_close, in remove_phys_input.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         /* remove phys input successful */
         input_wl->capture_h = AUDIO_INVALID_HANDLE;
      }
   }
   return result;
}


ismd_result_t
audio_pvt_input_flush(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

    AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);   

   /* NOTE: we are only flushing everything up to the input of the ATC, since flush only flushes INPUTS.
        If we were to flush after the ATC it would cause timing issues with the backend of the pipe.
     */

   /* Flush pipe starting from the port--> ES_SCRUB-->PSM_DEC-->ATC_IN */
   if(input_wl->input_port != ISMD_PORT_HANDLE_INVALID){
      if((result = ismd_port_flush(input_wl->input_port)) != ISMD_SUCCESS){
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "ismd_port_flush failed!", audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   
   result = audio_pvt_input_post_port_flush(input_wl);

   //Flush the ATC
   if (input_wl->atc_stream_h != AUDIO_INVALID_HANDLE) {
      result = audio_timing_control_flush(input_wl->processor_wl->atc_h, input_wl->atc_stream_h);
      if (result != ISMD_SUCCESS) {
         AUDIO_ERROR("Setting audio_timing_control_flush failed", (result), audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   
   if (result == ISMD_SUCCESS && input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) {
      result = audio_timing_control_flush(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h);
      if (result != ISMD_SUCCESS) {
         AUDIO_ERROR("Setting audio_timing_control_flush failed", (result), audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   
   if (result == ISMD_SUCCESS && input_wl->assoc_atc_stream_h != AUDIO_INVALID_HANDLE) {
      result = audio_timing_control_flush(input_wl->processor_wl->atc_h, input_wl->assoc_atc_stream_h);
      if (result != ISMD_SUCCESS) {
         AUDIO_ERROR("Setting audio_timing_control_flush failed", (result), audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   input_wl->pass_needs_basetime = true;
   input_wl->pass_needs_clock = true;
   input_wl->rebase_info.curr_seg_info.linear_start = 0;
   input_wl->rebase_info.curr_seg_info.start = ISMD_NO_PTS;
   input_wl->rebase_info.curr_seg_info.stop = ISMD_NO_PTS;
   input_wl->rebase_info.curr_seg_info.requested_rate = ISMD_NORMAL_PLAY_RATE;
   input_wl->last_buffer_discrd_pts_past_stop_value = false;
   
   input_wl->rebase_info.last_linear_rate_change_time = 0;
   input_wl->rebase_info.last_scaled_rate_change_time = 0;
   input_wl->rebase_info.curr_rate = ISMD_NORMAL_PLAY_RATE;

   input_wl->last_linear_pts = ISMD_NO_PTS;
   input_wl->last_scaled_pts = ISMD_NO_PTS;
   input_wl->last_segment_pts = ISMD_NO_PTS;
   input_wl->apm_base_time = 0;
   input_wl->wait_with_timeout = false;
   input_wl->rate = ISMD_NORMAL_PLAY_RATE;

   //Don't ignore rate changes in band any more since we called flush. 
   input_wl->ignore_inband_rate_change = false;

   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
      SVEN_MODULE_EVENT_AUD_IO_APM_FLUSH, input_wl->processor_wl->handle_id, input_wl->smd_dev_h, 0, 0, 0, 0);

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);  

   return result;
}

ismd_result_t
audio_pvt_input_post_port_flush(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

    AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);   

   /* NOTE: we are only flushing everything up to the input of the ATC, since flush only flushes INPUTS. */

   //If the input cubby buffer is not empty get rid of it
   if(input_wl->output_buffer != NULL) {

      if ( input_wl->pass_buf_has_ref && (input_wl->pass_queue_has_buf == false) && (input_wl->primary_queue_has_buf == false)) { 
         ismd_audio_buffer_dereference(input_wl->output_buffer->unique_id);
      }
      
      ismd_audio_buffer_dereference(input_wl->output_buffer->unique_id);
      
      input_wl->pass_queue_has_buf = false;
      input_wl->primary_queue_has_buf = false;
      input_wl->pass_buf_has_ref = false;
      input_wl->output_buffer = NULL;
   }

   if(input_wl->audio_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
      if((result = ismd_queue_flush(input_wl->audio_in_queue_h)) != ISMD_SUCCESS){
         AUDIO_ERROR( " ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   if(input_wl->psm_dec_pipe.pipe_started){
      if((result = ismd_queue_flush(input_wl->dec_in_queue_h)) != ISMD_SUCCESS){
         AUDIO_ERROR("ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   if(result == ISMD_SUCCESS){

      if(input_wl->psm_dec_pipe.pipe_h != AUDIO_INVALID_HANDLE) {
         if((result = audio_psm_pipe_flush(input_wl->psm_dec_pipe.pipe_h)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }     
      }

      if(input_wl->psm_ms10_pipe.dec_pipe_h != AUDIO_INVALID_HANDLE) {
         if((result = audio_psm_pipe_flush(input_wl->psm_ms10_pipe.dec_pipe_h)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if(input_wl->psm_ms10_pipe_assoc.dec_pipe_h != AUDIO_INVALID_HANDLE) {
         if((result = audio_psm_pipe_flush(input_wl->psm_ms10_pipe_assoc.dec_pipe_h)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if(input_wl->pass_atc_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if((result = ismd_queue_flush(input_wl->pass_atc_in_queue_h)) != ISMD_SUCCESS){
            AUDIO_ERROR( "ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if(input_wl->pass_psm_pipe_in_queue_h != ISMD_QUEUE_HANDLE_INVALID) {
         if((result = ismd_queue_flush(input_wl->pass_psm_pipe_in_queue_h)) != ISMD_SUCCESS){
            AUDIO_ERROR( "ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if((result = ismd_queue_flush(input_wl->atc_in_queue_h)) != ISMD_SUCCESS){
         AUDIO_ERROR( "ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }                     
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);  

   return result;
}


static ismd_result_t
audio_pvt_input_flush_queues(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /* NOTE: only use this function when closing out an input. */
   if (input_wl->pass_psm_pipe_in_queue_h != ISMD_QUEUE_HANDLE_INVALID){
      if((result = ismd_queue_flush(input_wl->pass_psm_pipe_in_queue_h)) != ISMD_SUCCESS){
         AUDIO_ERROR( " ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   if (input_wl->dec_in_queue_h != ISMD_QUEUE_HANDLE_INVALID){
      if((result = ismd_queue_flush(input_wl->dec_in_queue_h)) != ISMD_SUCCESS){
         AUDIO_ERROR( "ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   if (input_wl->atc_in_queue_h != ISMD_QUEUE_HANDLE_INVALID){
      if((result = ismd_queue_flush(input_wl->atc_in_queue_h)) != ISMD_SUCCESS){
         AUDIO_ERROR( "ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   if (input_wl->atc_out_queue_h != ISMD_QUEUE_HANDLE_INVALID){
      if((result = ismd_queue_flush(input_wl->atc_out_queue_h)) != ISMD_SUCCESS){
         AUDIO_ERROR( "ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   if (input_wl->pass_atc_in_queue_h != ISMD_QUEUE_HANDLE_INVALID){
      if((result = ismd_queue_flush(input_wl->pass_atc_in_queue_h)) != ISMD_SUCCESS){
         AUDIO_ERROR( "ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   if (input_wl->pass_atc_out_queue_h != ISMD_QUEUE_HANDLE_INVALID){ 
      if((result = ismd_queue_flush(input_wl->pass_atc_out_queue_h)) != ISMD_SUCCESS){
         AUDIO_ERROR( "ismd_queue_flush failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

static bool
audio_pvt_input_needs_src_stage(ismd_audio_input_wl_t *input_wl)
{
   bool result = false;

   if((input_wl->format == ISMD_AUDIO_MEDIA_FMT_PCM)) {
      if(input_wl->sample_rate == 11025 || input_wl->sample_rate == 22050) {
         result = true;
      }
   }
   else {
      result = audio_core_format_supports_22_05_and_11_025(input_wl->format);
   }
   return result;
}

static ismd_result_t
audio_pvt_input_decoder_pipe_add_stages(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   int stage = 0;
   audio_psm_decode_pipe_t *pipe = &input_wl->psm_dec_pipe;

   /*Init all stages to 1:1 until otherwise changed.*/
   for(stage = 0; stage < DECODE_PSM_PIPE_MAX_STAGES; stage++) {
      pipe->stages[stage].input_count = 1;
      pipe->stages[stage].output_count = 1;
   }

   /*Reinit stages that can be turned off or on by decoder setup functions.*/
   pipe->stages[PACKETIZER_STAGE].in_use = true;
   pipe->stages[SECONDARY_DECODE_STAGE].in_use = false;
   pipe->stages[IEC_PARSER_STAGE].in_use = false;
   pipe->stages[ACCUMLATOR_STAGE].in_use = false;
   pipe->stages[PRE_SRC_STAGE].in_use = false;

   /*By default output stage will get primary and passthrough as outputs. Until otherwise set.*/
   pipe->stages[OUT_STAGE].input_count = 2;
   pipe->stages[OUT_STAGE].output_count = 2;

   /*Check for the need to add the acummulator.*/
   if(input_wl->format == ISMD_AUDIO_MEDIA_FMT_TRUE_HD) {
      pipe->stages[ACCUMLATOR_STAGE].in_use = true;
      pipe->stages[ACCUMLATOR_STAGE].params.acumultr.time_quantum = TIME_QUANTUM_DATA_ACCUM_MS;
   }
   
   /*Check for need of SRC on formats that need it, this includes PCM. */
   if (audio_pvt_input_needs_src_stage( input_wl)) {
      pipe->stages[PRE_SRC_STAGE].in_use = true;
   }
   
   /*Check if IEC parser is enabled. */
   if((input_wl->parsing_mode == ISMD_AUDIO_INPUT_PARSING_MODE_IEC60958_CUSTOM) || 
      (input_wl->parsing_mode == ISMD_AUDIO_INPUT_PARSING_MODE_IEC60958) ||
      (input_wl->parsing_mode == ISMD_AUDIO_INPUT_PARSING_MODE_IEC61937)) 
   {
      pipe->stages[IEC_PARSER_STAGE].in_use = true;
      /*IEC needs 2 outputs, one for packetized output and the other to feed the decoder.*/
      pipe->stages[IEC_PARSER_STAGE].output_count = 2;
      /*Dont need packetizer here since IEC_STAGE outputs 61937 frames.*/
      pipe->stages[PACKETIZER_STAGE].in_use = false;
   }

   /*Setup pipe for special BD/DVD PCM handling cases.*/
   if( (input_wl->format == ISMD_AUDIO_MEDIA_FMT_PCM)
      || (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DVD_PCM)
      || (input_wl->format == ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM)) 
   {
      /*Use the decoder stage as PCM decoder stage*/
      pipe->stages[DECODE_STAGE].task = PSM_TASK_PCM_DECODE;

      /*Dont need to do PCM decode twice, will hook up passthrough 
        stream to same output as the decoder in the PCM case. */
      pipe->stages[PACKETIZER_STAGE].in_use = false;
   }
   else {
      pipe->stages[DECODE_STAGE].task = PSM_TASK_DECODE;
      pipe->stages[PACKETIZER_STAGE].task = PSM_TASK_PACKETIZE_ENCODED_DATA;
   }

   /*If this isnt a primary input, don't add the packetizer stage, and limit the pipe to 1 output.*/
   if(input_wl->input_type != AUDIO_INPUT_TYPE_PRIMARY) {
      pipe->stages[PACKETIZER_STAGE].in_use = false;
      pipe->stages[OUT_STAGE].input_count = 1;
      pipe->stages[OUT_STAGE].output_count = 1;
      pipe->stages[IEC_PARSER_STAGE].output_count = 1;
   }

   /*If we have disabled the packetizer in PCM case, and not using IEC stage, limit output to 1.*/
   if(!pipe->stages[PACKETIZER_STAGE].in_use && !pipe->stages[IEC_PARSER_STAGE].in_use) {
      pipe->stages[OUT_STAGE].input_count = 1;
      pipe->stages[OUT_STAGE].output_count = 1;
   }

   /*If we dont have a decoder, turn the decode stage into a throw away stage.*/
   if(!audio_pvt_available_codec(input_wl->format)) {
      pipe->stages[DECODE_STAGE].task = PSM_TASK_BIT_BUCKET;
   }

   if(input_wl->ddplus_dcv_enabled) {
      /* When ddplus dcv is enabled, there are two use cases. */
      /* Case 1:
         DECODE_STAGE is for DD+ decoder to decode DD+ to PCM.
         SECONDARY_DECODE_STAGE is for DCV to transcode DD+ to AC3*/
      
      if(input_wl->dcv_on_secondary_decode_stage) {
         pipe->stages[SECONDARY_DECODE_STAGE].in_use = true;
         pipe->stages[PACKETIZER_STAGE].in_use = false;
      }
      /* Case 2:
         DECODE_STAGE is for DCV to decode DD+ to PCM.
         Use DCV to decode DD+ to PCM, no stage change is needed.
         If passthrough DD+ to AC3 is needed, we need to 
         set DECODE_STAGE to dual output and skip packetizer.*/
      else if(input_wl->ddplus_dcv_dd_enabled) {
         pipe->stages[DECODE_STAGE].output_count = 2;
         pipe->stages[PACKETIZER_STAGE].in_use = false;
      }
   }
   
   /*Add all stages that are in use. */
   for(stage = 0; stage < DECODE_PSM_PIPE_MAX_STAGES; stage++) {
      /* Only add/config the stage if we have flagged it that we needed it */
      if(pipe->stages[stage].in_use) {
         if((result = audio_psm_stage_add(pipe->pipe_h, 
                             pipe->stages[stage].task, 
                             pipe->stages[stage].input_count,
                             pipe->stages[stage].output_count, 
                             &(pipe->stages[stage].handle))) != ISMD_SUCCESS) {

            AUDIO_ERROR("psm_stage_add add failed", result, audio_devh[AUDIO_DEBUG_APM]);
            break;
         }
      }
   }

   return result;
}


static ismd_result_t
audio_pvt_input_decoder_pipe_connect_stages(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_decode_pipe_t *pipe = &input_wl->psm_dec_pipe;
   audio_psm_stage_handle_t dec_or_capp_stage_h;

   /*If the input mode has specified a IEC audio parser, need to connect it before the decoder.*/   
   if(input_wl->psm_dec_pipe.stages[IEC_PARSER_STAGE].in_use) {
      /* INPUT-->IEC-->DECODER (Decode)  also IEC-->OUTPUT (for passthrough)*/
      if ((result = audio_psm_stage_connect(pipe->pipe_h, 
            pipe->stages[IN_STAGE].handle, 0, 
            pipe->stages[IEC_PARSER_STAGE].handle, 0)) != ISMD_SUCCESS)
      {
         AUDIO_ERROR("psm_stage_connect input_to_IEC failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if ((result = audio_psm_stage_connect(pipe->pipe_h, 
            pipe->stages[IEC_PARSER_STAGE].handle, DEC_PSM_PIPE_DEC_OUT_INDEX, 
            pipe->stages[DECODE_STAGE].handle, 0)) != ISMD_SUCCESS)
      {
         AUDIO_ERROR("psm_stage_connect IEC to decode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      /*If this is the primary input, connect the IEC output directly to the passthrough output.*/
      else if(input_wl->input_type == AUDIO_INPUT_TYPE_PRIMARY){
         if ((result = audio_psm_stage_connect(pipe->pipe_h, 
               pipe->stages[IEC_PARSER_STAGE].handle, DEC_PSM_PIPE_PASS_OUT_INDEX, 
               pipe->stages[OUT_STAGE].handle, DEC_PSM_PIPE_PASS_OUT_INDEX)) != ISMD_SUCCESS)
         {
            AUDIO_ERROR("psm_stage_connect IEC to out failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }
   /*Connect the input to the decoder.*/
   else {
      if ((result = audio_psm_stage_connect(pipe->pipe_h, 
            pipe->stages[IN_STAGE].handle, 0, 
            pipe->stages[DECODE_STAGE].handle, 0)) != ISMD_SUCCESS)
      {
         AUDIO_ERROR("psm_stage_connect input_to_decode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      if(input_wl->ddplus_dcv_enabled) {
         if(input_wl->dcv_on_secondary_decode_stage) {
            if ((result = audio_psm_stage_connect(pipe->pipe_h, 
                  pipe->stages[IN_STAGE].handle, 0, 
                  pipe->stages[SECONDARY_DECODE_STAGE].handle, 0)) != ISMD_SUCCESS)
            {
               AUDIO_ERROR("psm_stage_connect input to SECONDARY_DECODE failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }
      /*Connect packetizer to output, if in use.*/
      if(pipe->stages[PACKETIZER_STAGE].in_use) {
         if ((result = audio_psm_stage_connect(pipe->pipe_h, 
               pipe->stages[IN_STAGE].handle, 0, 
               pipe->stages[PACKETIZER_STAGE].handle, 0)) != ISMD_SUCCESS)
         {
            AUDIO_ERROR("psm_stage_connect input_to_packetizer failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else if ((result = audio_psm_stage_connect(pipe->pipe_h, 
               pipe->stages[PACKETIZER_STAGE].handle, 0, 
               pipe->stages[OUT_STAGE].handle, DEC_PSM_PIPE_PASS_OUT_INDEX)) != ISMD_SUCCESS)
         {
            AUDIO_ERROR("psm_stage_connect packetizer_to_out failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }

   /*By default use the decoder stage, can be switched by CAPP if needed.*/
   dec_or_capp_stage_h = pipe->stages[DECODE_STAGE].handle;

   /* Connect decoder stage to the custom audio PCM processing (capp) stage */
   if(pipe->stages[CAPP_STAGE].in_use && (result == ISMD_SUCCESS)) {
      /*Use CAPP to connect the rest of the pipe.*/
      dec_or_capp_stage_h = pipe->stages[CAPP_STAGE].handle;
      if ((result = audio_psm_stage_connect(pipe->pipe_h, 
            pipe->stages[DECODE_STAGE].handle, 0, 
            pipe->stages[CAPP_STAGE].handle, 0)) != ISMD_SUCCESS)
      {
         AUDIO_ERROR("psm_stage_connect decode_to_capp failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }  
   }
   
   /* Check for the accumulator stage, if present connect  decoder|capp->accumulator->output. 
      This is ok to finish the pipe here since TrueHD does not ever need pre-src. */
   if(pipe->stages[ACCUMLATOR_STAGE].in_use && (result == ISMD_SUCCESS)) {

      if ((result = audio_psm_stage_connect(pipe->pipe_h, 
            dec_or_capp_stage_h, 0, 
            pipe->stages[ACCUMLATOR_STAGE].handle, 0)) != ISMD_SUCCESS)
      {
         AUDIO_ERROR("psm_stage_connect capp_to_acc failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      } 
      else if ((result = audio_psm_stage_connect(pipe->pipe_h, 
            pipe->stages[ACCUMLATOR_STAGE].handle, 0, 
            pipe->stages[OUT_STAGE].handle, DEC_PSM_PIPE_DEC_OUT_INDEX)) != ISMD_SUCCESS)
      {
         AUDIO_ERROR("psm_stage_connect acc_to_output failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      } 
      
      /* Pipe connection complete here. */
   }

   /* If we dont need the accumulator, check for the need for SRC stage. */
   else if(result == ISMD_SUCCESS) {

      /* If we need to add the SRC then connect  decoder|capp->SRC->output */
      if(pipe->stages[PRE_SRC_STAGE].in_use) {

         if ((result = audio_psm_stage_connect(pipe->pipe_h, 
            dec_or_capp_stage_h, 0, 
            pipe->stages[PRE_SRC_STAGE].handle, 0)) != ISMD_SUCCESS)
         {
            AUDIO_ERROR("psm_stage_connect capp_to_src failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else if ((result = audio_psm_stage_connect(pipe->pipe_h, 
            pipe->stages[PRE_SRC_STAGE].handle, 0, 
            pipe->stages[OUT_STAGE].handle, DEC_PSM_PIPE_DEC_OUT_INDEX)) != ISMD_SUCCESS)
         {
            AUDIO_ERROR("psm_stage_connect src_to_output failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         } 
         /* Pipe connection complete here. */
      }
      /* If no need for SRC just connect the capp stage to the output.  decoder|capp->output. */
      else{
         if ((result = audio_psm_stage_connect(pipe->pipe_h, 
            dec_or_capp_stage_h, 0, 
            pipe->stages[OUT_STAGE].handle, DEC_PSM_PIPE_DEC_OUT_INDEX)) != ISMD_SUCCESS)
         {
            AUDIO_ERROR("psm_stage_connect capp_to_output failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         if(input_wl->ddplus_dcv_enabled) {
            if(input_wl->dcv_on_secondary_decode_stage) {
               if ((result = audio_psm_stage_connect(pipe->pipe_h, 
                  pipe->stages[SECONDARY_DECODE_STAGE].handle, 0, 
                  pipe->stages[OUT_STAGE].handle, DEC_PSM_PIPE_PASS_OUT_INDEX)) != ISMD_SUCCESS)
               {
                  AUDIO_ERROR("psm_stage_connect SECONDARY_DECODE to output failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               } 
            }
            else if(input_wl->ddplus_dcv_dd_enabled){
               if ((result = audio_psm_stage_connect(pipe->pipe_h, 
                  dec_or_capp_stage_h, 1, 
                  pipe->stages[OUT_STAGE].handle, DEC_PSM_PIPE_PASS_OUT_INDEX)) != ISMD_SUCCESS)
               {
                  AUDIO_ERROR("psm_stage_connect capp_to_pass_output failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               } 
            }
         }
      }
      /* Pipe connection complete here. */
   }

   return result;
}

static ismd_result_t
audio_pvt_input_start_decoder_pipe(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_decode_pipe_t *pipe = &input_wl->psm_dec_pipe;
   audio_psm_pipe_stage_t *iec_stage = &input_wl->psm_dec_pipe.stages[IEC_PARSER_STAGE];
   int loop = 0;

   /*If there is no reason to put it on the DSP pipe, byapss directly to the ATC.*/
   if(!input_wl->needs_pcm_preprocessing && input_wl->is_sw_input &&
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_PCM) &&
      !audio_pvt_input_needs_src_stage( input_wl))
   {
      /*Assign the input queue to the ATC in queue to bypass DSP, if not already done.*/
      if(input_wl->audio_in_queue_h != input_wl->atc_in_queue_h) {
         
         input_wl->audio_in_queue_h = input_wl->atc_in_queue_h;
         result = ismd_queue_connect_input(input_wl->audio_in_queue_h, 
            (ismd_producer_func_t) audio_pvt_input_queue_callback, 
            (void*)input_wl, ISMD_QUEUE_WATERMARK_NONE);
      }
   }
   /*Continue to build the decoder/packetizer pipe, if not already built.*/
   else if(!input_wl->psm_dec_pipe.pipe_started) {

      /* Setup the decoder and start it up.*/
      result = audio_pvt_input_decoder_setup(input_wl);

      audio_pvt_configure_input_dependencies( input_wl->processor_wl );

      if(result == ISMD_SUCCESS) {
         /*Do final configuration of some stages.*/
         input_wl->psm_dec_pipe.stages[PRE_SRC_STAGE].params.src.host.src.output_sample_rate[0] = input_wl->processor_wl->outputs->sample_rate;
         input_wl->psm_dec_pipe.stages[IEC_PARSER_STAGE].params.iec_parse.host.iec_parse.parsing_mode = input_wl->parsing_mode;

         /* Take care of packetizer parameters if the stage is not for PCM Parsing. */
         if(pipe->stages[PACKETIZER_STAGE].task == PSM_TASK_PACKETIZE_ENCODED_DATA) {      
            pipe->stages[PACKETIZER_STAGE].params.packetizer.host.packetize.pass_through_mode = input_wl->pass_through_mode;
         }

         /*If the passthrough format is not supported, disable packeitzer stage.*/
         if(!audio_core_supported_passthrough_format(input_wl->format)) {
            pipe->stages[PACKETIZER_STAGE].params.packetizer.host.packetize.disable_stage = true;
         }

         /* Decoder and IEC stage needs the ability to fire events. Associate this input's notification events with this stage. */
         input_wl->psm_dec_pipe.stages[DECODE_STAGE].conn_mda.input[0] = (int)input_wl->notification_events;

         /*If we have the IEC stage in use populate the user set metadata.*/
         if( iec_stage->in_use) {
            iec_stage->conn_mda.input[0] = (int)input_wl->notification_events;
            iec_stage->params.iec_parse.host.iec_parse.user_set_stream_info.algo = input_wl->format;
            iec_stage->params.iec_parse.host.iec_parse.user_set_stream_info.sample_rate = input_wl->sample_rate;
            iec_stage->params.iec_parse.host.iec_parse.user_set_stream_info.sample_size = input_wl->sample_size;
            iec_stage->params.iec_parse.host.iec_parse.user_set_stream_info.channel_count = input_wl->channel_count;
            iec_stage->params.iec_parse.host.iec_parse.user_set_stream_info.channel_config = input_wl->channel_config;
            iec_stage->params.iec_parse.host.iec_parse.event_mask = input_wl->parser_event_mask;
         }

         /*Set params appropriately for PCM decoder stage.*/
         if(pipe->stages[DECODE_STAGE].task == PSM_TASK_PCM_DECODE) {
            /*PCM decoder requires no params to be set, need to init in case was decoder previously.*/
            OS_MEMSET(&pipe->stages[DECODE_STAGE].params, 0, sizeof(audio_psm_stage_params_t));

            /*If the PRE-SRC is in use with the PCM decode stage need to flag the parameters to allign in PCM decoder stage.*/
            if(pipe->stages[PRE_SRC_STAGE].in_use ) {
               pipe->stages[DECODE_STAGE].params.pcm_dec.host.pcm_dec.allign_output_for_src = true;
            }
         }

         /*"ddplus_dcv_enabled" value needs to be passed down to firmware decode state. 
            Moreover, ddplus_dcv_params is delcared as union, so we need to make sure 
            current decode stage is for dcv and not anything else. */
         if(input_wl->ddplus_dcv_enabled){
            if(input_wl->dcv_on_secondary_decode_stage) {
               /* The default value of ddplus_dcv_enabled is false. Need to set it true here. */
               input_wl->psm_dec_pipe.stages[SECONDARY_DECODE_STAGE].params.decoder.ddplus_dcv_enabled = true;
               input_wl->psm_dec_pipe.stages[SECONDARY_DECODE_STAGE].params.decoder.host.codec.config.ddplus_dcv_params.dd_enabled = true;
               input_wl->psm_dec_pipe.stages[SECONDARY_DECODE_STAGE].params.decoder.host.codec.config.ddplus_dcv_params.pcm_enabled = false;
            }
            else {
               input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.ddplus_dcv_enabled = true;
               input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.config.ddplus_dcv_params.dd_enabled = input_wl->ddplus_dcv_dd_enabled;
               input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder.host.codec.config.ddplus_dcv_params.pcm_enabled = input_wl->ddplus_dcv_pcm_enabled;
            }
         }
         
         /* Need to do configuration for each stage*/
         for(loop = 0; loop < DECODE_PSM_PIPE_MAX_STAGES; loop++) {
            if(pipe->stages[loop].in_use) {
               /* Commmit config changes to the PSM */
               if((result = audio_psm_stage_config(pipe->pipe_h, 
                          pipe->stages[loop].handle, 
                          &pipe->stages[loop].params)) != ISMD_SUCCESS) 
               {
                  AUDIO_ERROR("psm_stage_config failed", result, audio_devh[AUDIO_DEBUG_APM]);
                  break;
               }
               else if((result = audio_psm_stage_config_metadata(input_wl->psm_dec_pipe.pipe_h,
                          pipe->stages[loop].handle, 
                          &pipe->stages[loop].conn_mda)) != ISMD_SUCCESS) 
               {
                  AUDIO_ERROR("psm_stage_config_metadata failed", result, audio_devh[AUDIO_DEBUG_APM]);
                  break;
               }
            }
         }
         /*If we succeeded, start the pipe.*/
         if(result == ISMD_SUCCESS) {
            
            if((result = audio_psm_pipe_start(input_wl->psm_dec_pipe.pipe_h)) != ISMD_SUCCESS){
                AUDIO_ERROR("audio_psm_pipe_start decode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
            else{
               input_wl->psm_dec_pipe.pipe_started = true;
            }
         }
      }
   }
   
   return result;
}

static ismd_result_t
audio_pvt_input_decoder_setup(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /* Our decoders don't ensure that they all output exactly the same amount of time from the DSP. 
    * So the decoder output queue is currently programed at an arbitrary depth. For some decoders they output 
    * subframes for every input frame. This fills the decoder output queue quickly with not that much
    * time. There are cases where the application requires us to discard several milliseconds worth of 
    * data and the queue can only hold a fixed amount of time and is different for every decoder. So for
    * these decoders its necessary to increase the size of this queue to have enough data ready for such scenarios. The
    * long term fix here is to guarantee that we get EXACTLY the same amount of time output from the DSP
    * from each decoder and then fix the queue size. Remove this line when that is implemented. 12 is allowance
    * for exacly 2 sets of sub-frames for AC3 and the DTS codecs also output the same subframe chunk sizes in terms of time.*/
   if(((input_wl->format == ISMD_AUDIO_MEDIA_FMT_DD) || 
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS) ||
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS_LBR) ||
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS_HD) ||
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA)||
      (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA)) && (input_wl->is_sw_input)) {
      audio_pvt_change_queue_max_depth( input_wl->atc_in_queue_h, 12);
      audio_pvt_change_queue_max_depth( input_wl->pass_atc_in_queue_h, 12);
   }

   /*Allocate the decoder pipe if not already done so.*/
   if(input_wl->psm_dec_pipe.pipe_h == AUDIO_INVALID_HANDLE) {
      if ((result = audio_psm_pipe_alloc(PSM_PIPE_TYPE_DECODE, &input_wl->psm_dec_pipe.pipe_h))!= ISMD_SUCCESS) {
          AUDIO_ERROR("Decoder audio_psm_pipe_alloc failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   if((result = audio_pvt_input_decoder_pipe_add_stages(input_wl)) != ISMD_SUCCESS){
      AUDIO_ERROR("Adding decoder stages failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_pvt_input_decoder_pipe_connect_stages(input_wl)) != ISMD_SUCCESS) {
      AUDIO_ERROR("Connecting decoder stages failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else {
      
      if ((result = audio_psm_input_queue_add(input_wl->psm_dec_pipe.pipe_h, input_wl->dec_in_queue_h, 0)) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_input_queue_add dec_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /*Add the decode output queue to the PSM pipe output.*/
      else if ((result = audio_psm_output_queue_add(input_wl->psm_dec_pipe.pipe_h, input_wl->atc_in_queue_h, DEC_PSM_PIPE_DEC_OUT_INDEX)) != ISMD_SUCCESS){
         AUDIO_ERROR("audio_psm_output_queue_add atc_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }           
      
      else {

         input_wl->audio_in_queue_h = input_wl->dec_in_queue_h;
         input_wl->disable_primary_output = false;

         if((result = ismd_queue_connect_input(input_wl->audio_in_queue_h, (ismd_producer_func_t) audio_pvt_input_queue_callback, (void*)input_wl, ISMD_QUEUE_WATERMARK_NONE)) != ISMD_SUCCESS){
            AUDIO_ERROR("queue_connect_input failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else {
            /*For primay input, If passthrough flag is true, setup queues for passthrough, if not disable.*/
            if(input_wl == input_wl->processor_wl->primary_input_wl){
               if(input_wl->pass_config.is_pass_through) {
                  if((result = audio_pvt_input_manage_passthrough_stream(input_wl, ISMD_DEV_STATE_PLAY, true)) == ISMD_SUCCESS) {
                     result = audio_pvt_input_primary_resync_atc_stream(input_wl, input_wl->pass_atc_stream_h);
                  }
               }
               else {
                  result = audio_pvt_input_manage_passthrough_stream(input_wl, ISMD_DEV_STATE_PLAY, false);
               }
            }
         }
      }
   }

   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
      SVEN_MODULE_EVENT_AUD_IO_APM_DECODER_SETUP,
      input_wl->processor_wl->handle_id,
      input_wl->format, 0, 0, 0, 0);


   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

static ismd_result_t
audio_pvt_input_get_detected_stream_info(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_pipe_stage_t *iec_stage = NULL;
   
   if(input_wl->psm_dec_pipe.stages[IEC_PARSER_STAGE].in_use && 
     (input_wl->psm_dec_pipe.pipe_h != AUDIO_INVALID_HANDLE) && input_wl->in_use) 
   {
      iec_stage = &input_wl->psm_dec_pipe.stages[IEC_PARSER_STAGE];
      if ((result = audio_psm_stage_get_config(input_wl->psm_dec_pipe.pipe_h, 
            iec_stage->handle, &iec_stage->params)) == ISMD_SUCCESS) 
      {
         input_wl->parser_status = iec_stage->params.iec_parse.parser_status;
      }
   }
   return result;
}

static ismd_result_t
audio_pvt_input_decoder_teardown(ismd_audio_input_wl_t *input_wl, ismd_dev_state_t input_state)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(input_wl->has_passthr_stream) {
      result = audio_pvt_input_manage_passthrough_stream(input_wl, input_state, false);
   }
   
   if ((result == ISMD_SUCCESS) && (input_wl->psm_dec_pipe.pipe_h != AUDIO_INVALID_HANDLE)){

      /*If the parser stage is in use, need to get detected information before freeing the pipe. This is to
        handle the case where the application wants to get the detected stream info in the stopped state. */
      if((result = audio_pvt_input_get_detected_stream_info( input_wl)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Decoder teardown: update_detected_stream_info failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if ((result = audio_psm_pipe_free(input_wl->psm_dec_pipe.pipe_h))!= ISMD_SUCCESS) {
          AUDIO_ERROR("Decoder teardown: audio_psm_pipe_free failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         /* Disconnect input queue from input port thread, flush input queue and reset the input queue handle.*/
         ismd_queue_disconnect_input(input_wl->audio_in_queue_h);
         ismd_queue_flush(input_wl->audio_in_queue_h);
         input_wl->audio_in_queue_h = ISMD_QUEUE_HANDLE_INVALID;
         input_wl->psm_dec_pipe.pipe_h = AUDIO_INVALID_HANDLE;
         input_wl->psm_dec_pipe.pipe_started = false;
      }
   }

   return result;
}


static ismd_result_t
audio_pvt_input_decoder_set_default_params(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_format_t format = input_wl->format;
   audio_psm_decode_params_t *params = &(input_wl->psm_dec_pipe.stages[DECODE_STAGE].params.decoder);
   audio_psm_decode_params_t *secondary_decode_params = &(input_wl->psm_dec_pipe.stages[SECONDARY_DECODE_STAGE].params.decoder);
   
   /*If DTS core is in the input stream, but only DTSHD decoder, need to force format to DTSHD since we will use the DTSHD decoder. */
   if((input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS) && audio_pvt_available_codec(ISMD_AUDIO_MEDIA_FMT_DTS_HD)) {
      format = ISMD_AUDIO_MEDIA_FMT_DTS_HD;
   }

   switch(format) {

      case ISMD_AUDIO_MEDIA_FMT_DD:

         if(available_codecs[ISMD_AUDIO_MEDIA_FMT_DD].ddplus_dcv_in_use) {
            if((result = audio_ddplus_dcv_set_default_decode_params(params)) != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_ddplus_dcv_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         else {
            if((result = audio_dd_set_default_decode_params(params)) != ISMD_SUCCESS) {
               AUDIO_ERROR("dd_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }

         break;
         
      case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:

         /* If ddplus_dcv_in_use is set to true, that means DD+ decoder is NOT available for sure. */
         if(available_codecs[ISMD_AUDIO_MEDIA_FMT_DD_PLUS].ddplus_dcv_in_use) {
            // DCV is in stage[DECODE_STAGE] for sure.
            if((result = audio_ddplus_dcv_set_default_decode_params(params)) != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_ddplus_dcv_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         // DD+ decoder is available.
         else {
            if((result = audio_ddplus_set_default_decode_params(params)) != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_ddplus_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
            if(available_dcv_codec.availability) {
               /* During this time, we know DD+ decoder should be in stage[DECODE_STAGE] for sure but
                  don't know if DCV should be used on stage[SECONDARY_DECODE_STAGE] or not.
                  This will be determined in ismd_audio_input_set_as_primary(). 
                  Therefore, we simply assume DCV wil be used in stage[SECONDARY_DECODE_STAGE] 
                  and set the default parameters for it.
                  It is fine to set default parameters for DCV here, 
                  because input_wl->dcv_on_secondary_decode_stage is set "false" by default.
                  It will be set "true" in ismd_audio_input_set_as_primary() if needed. */
               if((result = audio_ddplus_dcv_set_default_decode_params(secondary_decode_params)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_ddplus_dcv_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
           }
         }

         break;

      case ISMD_AUDIO_MEDIA_FMT_MPEG:

         if((result = audio_mpeg_set_default_decode_params(params)) != ISMD_SUCCESS) {
            AUDIO_ERROR("mpeg_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         break;  
         
      case ISMD_AUDIO_MEDIA_FMT_AAC :
      case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS:

         if((result = audio_aac_set_default_decode_params(params, format)) != ISMD_SUCCESS) {
            AUDIO_ERROR("aac_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         break;
         
      case ISMD_AUDIO_MEDIA_FMT_TRUE_HD:
         
         if((result = audio_truehd_set_default_decode_params(params)) != ISMD_SUCCESS) {
            AUDIO_ERROR("truehd_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         break;
         
      case ISMD_AUDIO_MEDIA_FMT_DTS_LBR:
         
         if((result = audio_dts_lbr_set_default_decode_params(params)) != ISMD_SUCCESS) {
            AUDIO_ERROR("dts_lbr_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         break;  

      case ISMD_AUDIO_MEDIA_FMT_DTS_BC:
         
         if((result = audio_dts_bc_set_default_decode_params(params)) != ISMD_SUCCESS) {
            AUDIO_ERROR("dts_bc_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         break;   

      case ISMD_AUDIO_MEDIA_FMT_WM9:
         result = ISMD_SUCCESS;
         break;
         
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA:
         if((result = audio_dts_hd_set_default_decode_params(params)) != ISMD_SUCCESS) {
            AUDIO_ERROR("dts_hd_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
      case ISMD_AUDIO_MEDIA_FMT_DTS:
         if((result = audio_dts_set_default_decode_params(params)) != ISMD_SUCCESS) {
            AUDIO_ERROR("dts_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         break;
      case ISMD_AUDIO_MEDIA_FMT_PCM:
      case ISMD_AUDIO_MEDIA_FMT_DVD_PCM:
      case ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM:
         result = ISMD_SUCCESS;
         break;
      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid codec!", result, audio_devh[AUDIO_DEBUG_APM]);
         break;
   }


   if ((input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA) || (input_wl->format == ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA)) {
      // The DTS-HD decoder doesn't distinguish between MA and HRA formats, so we can use the common DTSHD format to simplify firmware type checking
      params->host.codec.algo = ISMD_AUDIO_MEDIA_FMT_DTS_HD;      
   } else {
      params->host.codec.algo = input_wl->format;
      secondary_decode_params->host.codec.algo = input_wl->format;
   }

   return result;
}

ismd_result_t
audio_pvt_input_read_port_buffer(ismd_audio_input_wl_t *input_wl, ismd_port_handle_t port_h,  ismd_buffer_descriptor_t **buffer_des)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   ismd_buffer_descriptor_t *buffer_des_local = NULL;
   ismd_buffer_handle_t buffer_h = ISMD_BUFFER_HANDLE_INVALID;
   ismd_pts_t original_pts = ISMD_NO_PTS;
   bool discontinuity = false;
   bool dequeue = false;
   ismd_audio_descriptor_t *ad_ptr;
   unsigned char ad_fade_byte = 0;  
   unsigned char ad_pan_byte = 0;
   bool pvt_data_valid = false;
   unsigned char ad_valid = AUDIO_DESCRIPTION_NOT_VALID;
   unsigned char ad_text_tag[] = {0x44, 0x54, 0x47, 0x41, 0x44};  

   /*Only try to read from the port in PAUSE or PLAY state*/
   if(input_wl->state == ISMD_DEV_STATE_PAUSE || input_wl->state == ISMD_DEV_STATE_PLAY) {
   
      if((input_wl->rate < AUDIO_MIN_PLAY_RATE) || (input_wl->rate > AUDIO_MAX_PLAY_RATE)){
         if((result = ismd_port_lookahead( port_h, 1, &buffer_h )) != ISMD_SUCCESS) {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"ismd_port_lookahead failed.", audio_devh[AUDIO_DEBUG_APM]);
         }
         else if((result = ismd_buffer_find_descriptor(buffer_h, &buffer_des_local))!= ISMD_SUCCESS){
            AUDIO_ERROR("Failed to find buffer descriptor from buffer handle.", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else {
            audio_pvt_apm_handle_pts_and_segments(input_wl, &dequeue, buffer_des_local);
            if(!dequeue){
               return ISMD_ERROR_OPERATION_FAILED;
            }
         }
      }

      if((result = ismd_port_read(port_h, &buffer_h)) == ISMD_SUCCESS) {

         if((result = ismd_buffer_find_descriptor(buffer_h, &buffer_des_local)) != ISMD_SUCCESS) {

            AUDIO_ERROR("Failed to find buffer descriptor from buffer handle.", result, audio_devh[AUDIO_DEBUG_APM]);
            ismd_audio_buffer_dereference(buffer_des_local->unique_id);
         }

         else {
            
            original_pts = ((ismd_es_buf_attr_t *)&(buffer_des_local->attributes))->original_pts;
            discontinuity = ((ismd_es_buf_attr_t *)&(buffer_des_local->attributes))->discontinuity;
            pvt_data_valid = ((ismd_es_buf_attr_t *)&(buffer_des_local->attributes))->pvt_data_valid;

            AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_APM],
               SVEN_MODULE_EVENT_AUD_IO_APM_INPUT_DEQUEUE,
               input_wl->processor_wl->handle_id,
               input_wl->input_id,
               input_wl->is_timed_stream, 
               buffer_des_local->phys.level,
               (unsigned int) ( original_pts >> 32), 
               (unsigned int) ( original_pts ));

            if(!dequeue){
               audio_pvt_apm_handle_pts_and_segments( input_wl, &dequeue, buffer_des_local );
            }

            if(pvt_data_valid){
               ad_ptr = (ismd_audio_descriptor_t *)((ismd_es_buf_attr_t *)&(buffer_des_local->attributes))->pvt_data; 
               if(OS_MEMCMP((unsigned char *)ad_ptr->text_tag ,(unsigned char *) ad_text_tag, sizeof(ad_text_tag)) == 0) {
                  ad_valid = AUDIO_DESCRIPTION_VALID;  
                  ad_fade_byte = ad_ptr->fade_byte;
                  ad_pan_byte = ad_ptr->pan_byte;
               }
            }

            /* Converting ismd_es_buf_attr_t to audio buffer attributes. */
            ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->local_pts = original_pts;
            ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->original_pts = original_pts;
            ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->linear_pts = ISMD_NO_PTS;
            ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->audio_format = input_wl->format;
            ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->discontinuity = discontinuity;
            ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->ad_valid = ad_valid;  
            
            if(ad_valid == AUDIO_DESCRIPTION_VALID) {
               ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->ad_fade_byte = ad_fade_byte;
               ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->ad_pan_byte = ad_pan_byte; 
               
               input_wl->ad_valid = true;
               
               AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
                  SVEN_MODULE_EVENT_AUD_IO_APM_INPUT_AD,
                  input_wl->input_id,
                  ad_valid,
                  ad_fade_byte,
                  ad_pan_byte,
                  0, 
                  0); 
            }
            else if(input_wl->ad_valid){
               ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->ad_valid = AUDIO_DESCRIPTION_ERROR;
               ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->ad_fade_byte = 0;
               ((audio_buffer_attr_t *)&(buffer_des_local->attributes))->ad_pan_byte = 0; 
               
               AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
                  SVEN_MODULE_EVENT_AUD_IO_APM_INPUT_AD,
                  input_wl->input_id,
                  ad_valid,
                  ad_fade_byte,
                  ad_pan_byte,
                  0, 
                  0); 
            }
            
            *buffer_des = buffer_des_local;
         }
      }
      else{

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
               SVEN_MODULE_EVENT_AUD_IO_APM_INPUT_DEQUEUE_FAILED,
               input_wl->processor_wl->handle_id,
               input_wl->input_id,
               input_wl->is_timed_stream, 
               input_wl->format,
               input_wl->has_passthr_stream, 0);
      }
   }
   
   return result;
}


ismd_result_t 
audio_pvt_get_event( ismd_audio_input_wl_t     *input_workload,
                     ismd_audio_notification_t  event_type,
                     ismd_event_t              *event_handle )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_event_t local_event = ISMD_EVENT_HANDLE_INVALID;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   switch ( event_type ) {

      case ( ISMD_AUDIO_NOTIFY_STREAM_END ):
      case ( ISMD_AUDIO_NOTIFY_STREAM_BEGIN ):
      case ( ISMD_AUDIO_NOTIFY_PTS_VALUE_LATE ):
      case ( ISMD_AUDIO_NOTIFY_PTS_VALUE_EARLY ):
      case ( ISMD_AUDIO_NOTIFY_PTS_VALUE_RECOVERED):
      case ( ISMD_AUDIO_NOTIFY_CLIENT_ID ):
      case ( ISMD_AUDIO_NOTIFY_WATERMARK ):
      case ( ISMD_AUDIO_NOTIFY_SEGMENT_END):
      case ( ISMD_AUDIO_NOTIFY_SAMPLE_RATE_CHANGE ):
      case ( ISMD_AUDIO_NOTIFY_CHANNEL_CONFIG_CHANGE ):
      case ( ISMD_AUDIO_NOTIFY_SRC_STATUS_CHANGE):
      case ( ISMD_AUDIO_NOTIFY_DECODE_ERROR):
      case ( ISMD_AUDIO_NOTIFY_DECODE_SYNC_FOUND):
      case ( ISMD_AUDIO_NOTIFY_DECODE_SYNC_LOST):
      case ( ISMD_AUDIO_NOTIFY_INPUT_FULL):
      case ( ISMD_AUDIO_NOTIFY_INPUT_EMPTY):
      case ( ISMD_AUDIO_NOTIFY_INPUT_RECOVERED):
      case ( ISMD_AUDIO_NOTIFY_CODEC_CHANGE):
      case ( ISMD_AUDIO_NOTIFY_SEGMENT_START):
      case ( ISMD_AUDIO_CAPTURE_OVERRUN ):
      case ( ISMD_AUDIO_NOTIFY_DATA_RENDERED):
      case ( ISMD_AUDIO_NOTIFY_PARSER_STATUS_CHANGE):
      case ( ISMD_AUDIO_NOTIFY_TIMING_INFO_UNAVAILABLE):

         local_event = input_workload->notification_events[event_type-1];
         if ( local_event == ISMD_EVENT_HANDLE_INVALID ) {
            result = ismd_event_alloc( &local_event );
            if ( result == ISMD_SUCCESS ) {
               input_workload->notification_events[event_type-1] = local_event;
               *event_handle = local_event;
            }
            else {
               AUDIO_ERROR("ismd_event_alloc failed on input event.", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         else {
            result = ISMD_SUCCESS;
            *event_handle = local_event;
         }
         break;
      case ( ISMD_AUDIO_NOTIFY_RENDER_UNDERRUN ):
      case ( ISMD_AUDIO_NOTIFY_TAG_RECEIVED ):
      case ( ISMD_AUDIO_NOTIFY_SAMPLE_SIZE_CHANGE ):
      case ( ISMD_AUDIO_NOTIFY_CORRUPT_FRAME ):
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         break;
      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         break;
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return ( result );
}

static ismd_result_t
audio_pvt_input_start_post_atc_pipes(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   //If we have a passthrough pipe need to make sure it's the primary input (contains passthrough pipe)
   //then setup the post ATC echo packetizer pipe and the input's packetizer will be started.
   if ((input_wl->processor_wl->psm_pass_pipe.pipe_h != AUDIO_INVALID_HANDLE) && 
       (input_wl == input_wl->processor_wl->primary_input_wl) &&
       (!input_wl->processor_wl->psm_pass_pipe.pipe_configured))
   {
      audio_processor_setup_pass_through_pipe(input_wl->processor_wl, input_wl, false);
   }

   /* Check to see if we have already started up the back-end pipe, if not start it up */
   if(!input_wl->processor_wl->psm_pa_pipe.pipe_configured) {
      
     if((result = audio_processor_psm_pipe_connect_stages(input_wl->processor_wl)) == ISMD_SUCCESS) {

         if((result = audio_processor_start_post_atc_pipe(input_wl->processor_wl, input_wl->processor_wl->psm_pa_pipe.pipe_h, true)) != ISMD_SUCCESS){
            AUDIO_ERROR("start_post_atc_pipe on PCM pipe failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }     
         input_wl->processor_wl->psm_pa_pipe.pipe_configured = true;
     }
   }
   
   else {
      result = audio_processor_psm_pipe_add_input( input_wl, input_wl->mixer_input_index, &input_wl->processor_wl->output_configs);
   }

   return result;
}


static ismd_result_t
audio_pvt_input_set_to_play(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /* Make sure we have a valid input format to start.*/
   if((result = audio_pvt_input_validate_format(input_wl->format)) == ISMD_SUCCESS
       && (result = audio_pvt_input_validate_required_param(input_wl)) == ISMD_SUCCESS) {

      result = audio_pvt_input_start_post_atc_pipes(input_wl);

      //If we have a decode PSM pipe set the config on the decoder then start!
      if(result == ISMD_SUCCESS){
         if (AUDIO_CORE_IS_VALID_MS10_INPUT(input_wl, input_wl->format)) {
            
            audio_pvt_configure_input_dependencies( input_wl->processor_wl );
            if ((result = audio_pvt_input_start_ms10dec_pipe(input_wl, &input_wl->psm_ms10_pipe)) != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_pvt_input_start_ms10dec_pipe failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         else if((result = audio_pvt_input_start_decoder_pipe(input_wl)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_pvt_input_start_decoder_pipe failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
         /* If this is a primary input and contains a passthrough stream, set base time and clock here, 
            Need to do this in input startup since there is a chance someone could call set base time and clock
            then call make primary.
          */
      if ( (input_wl->input_type == AUDIO_INPUT_TYPE_PRIMARY) && (input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) && (result == ISMD_SUCCESS) ) {
         if(input_wl->is_timed_stream) {

            if(input_wl->pass_needs_clock){
               audio_timing_control_set_clock(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h, input_wl->clock);
               input_wl->pass_needs_clock = false;
            }
            if(input_wl->pass_needs_basetime){
               audio_timing_control_set_base_time(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h, input_wl->smd_base_time);
               input_wl->pass_needs_basetime = false;
            }
         }
      }

      // configure ASRC support if needed for this input
      if((result = audio_pvt_input_configure_asrc_support(input_wl)) != ISMD_SUCCESS){
         AUDIO_ERROR("audio_pvt_input_configure_asrc_support failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /* if this is a phys input (capture), config capture port */
      if(!input_wl->is_sw_input && (result == ISMD_SUCCESS)) {
         
         /* put the start up code here, since untill now we know all the infomation: sample-rate, sample-size, ch_config */
         if ((result = audio_pvt_phys_input_startup(input_wl)) != ISMD_SUCCESS) {
            AUDIO_ERROR("audio_pvt_phys_input_startup failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if(result == ISMD_SUCCESS) {
         //Make sure the render has a clock handle for PTS-clock debug info need to change this when we support multi-inputs
         audio_render_set_clock_handle(&(input_wl->clock));
         audio_render_set_base_time(input_wl->smd_base_time);
         //need to update the timer clock as it may change when the input is removed
         if((result = audio_render_set_heartbeat_timer_clock_handle(input_wl->processor_wl->atc_timer_clock_h)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_render_set_heartbeat_timer_clock_handle failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }         
      }

      //If this input has no decoder, packetizer, PCM, PCM pass pipe, and is not PCM, disable the input.
      //This means we have no path to need to setup, and we just need to throw away. Corner case. 
      if ((input_wl->psm_dec_pipe.pipe_h == AUDIO_INVALID_HANDLE) && 
          (input_wl->psm_ms10_pipe.dec_pipe_h == AUDIO_INVALID_HANDLE) &&
          (input_wl->format != ISMD_AUDIO_MEDIA_FMT_PCM)) {
          
          input_wl->audio_in_queue_h = ISMD_QUEUE_HANDLE_INVALID; //Setting this to invalid will have the input port throw away. 
          input_wl->disable_primary_output = false;
      }

      /*Make sure the input port thread wakes up*/
      ismd_event_strobe(input_wl->processor_wl->input_port_event);
   }
   else {
      AUDIO_ERROR("No valid input audio format or required parameter specified.", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_pvt_input_set_asrc_mode( ismd_audio_processor_context_t *wl, int input_id, bool enable_asrc)
{
   ismd_result_t result = ISMD_SUCCESS;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(result == ISMD_SUCCESS){
      if(wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.vsrc_set_var_on[input_id] != (int)enable_asrc){
         wl->psm_pa_pipe.stages[SRC_STAGE].params.src.host.src.vsrc_set_var_on[input_id] = ((enable_asrc) ? 1:0);

          /* Commit the changes back to the SRC if the post ATC pipe is running. */
         if ( wl->psm_pa_pipe.pipe_configured ) {       
            result = audio_psm_stage_config_direct( wl->psm_pa_pipe.pipe_h, 
                                             wl->psm_pa_pipe.stages[SRC_STAGE].handle, 
                                             &wl->psm_pa_pipe.stages[SRC_STAGE].params );
            if ( result != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_psm_stage_config for the SRC failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}

ismd_result_t 
ismd_audio_input_set_asrc_mode(ismd_audio_processor_t processor_h, ismd_dev_t  input_h, bool enable_asrc)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
	
   /*Have to lock the processor here since we are touching the processor context here. */
   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS) {
       if(input_wl->state == ISMD_DEV_STATE_INVALID){
           if(input_wl->processor_wl->asrc_support_enabled){
    	   	   // automatic asrc works, return fail
    	   	   result = ISMD_ERROR_INVALID_REQUEST;
           }
    	   else{
               input_wl->asrc_enabled = enable_asrc;
    	       result = ISMD_SUCCESS;
    	   }
       }
	   else{
	   	   result = ISMD_ERROR_INVALID_REQUEST;
   	   }
	   audio_pvt_input_api_unlock(input_wl);
	   
   }
   else{
       result = ISMD_ERROR_INVALID_HANDLE;
       AUDIO_ERROR("can not set asrc for this input!", result, audio_devh[AUDIO_DEBUG_APM]);
   };
   return result;
}


/* Need to modify the below function when virtual clock support is available */

static ismd_result_t
audio_pvt_input_configure_asrc_support(ismd_audio_input_wl_t *input_wl)
{
   bool enable_asrc_support = false;
   ismd_clock_info_t heartbeat_timer_clock_info, input_clock_info;
   ismd_audio_mix_sample_rate_mode_t sample_rate_mode;
   int sample_rate;
   ismd_result_t result = ISMD_SUCCESS; 

   if((input_wl->processor_wl->asrc_support_enabled) && (input_wl->clock != ISMD_CLOCK_DEV_HANDLE_INVALID)){
      if((result = ismd_clock_get_info(*input_wl->processor_wl->atc_timer_clock_h, &heartbeat_timer_clock_info)) != ISMD_SUCCESS){
         AUDIO_ERROR("ismd_clock_get_info for heartbeat timer clock failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if((result = ismd_clock_get_info(input_wl->clock, &input_clock_info)) != ISMD_SUCCESS){
         AUDIO_ERROR("ismd_clock_get_info for input clock failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else {
         //determine if ASRC is needed for this input
         if(heartbeat_timer_clock_info.signal != input_clock_info.signal){
            enable_asrc_support = true;
         }
         else if(heartbeat_timer_clock_info.signal == ISMD_CLOCK_SIGNAL_LOCAL_DDS){
            if(*input_wl->processor_wl->atc_timer_clock_h != input_wl->clock){
               //This looks like a second push mode source
                enable_asrc_support = true;
            }
         }
      }

   }
   else{
   // automatic asrc has been disabled, so look at whether app set asrc enabled or not
      enable_asrc_support = input_wl->asrc_enabled;
   }

	if(enable_asrc_support){
   	 if((result = audio_get_mixing_sample_rate(input_wl->processor_wl, input_wl->mixer_input_index, &sample_rate_mode, &sample_rate)) != ISMD_SUCCESS){
   	    AUDIO_ERROR("audio_get_mixing_sample_rate failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   	 }
   	 else if((result = audio_timing_control_asrc_set_target_sample_rate(input_wl->processor_wl->atc_h, sample_rate)) != ISMD_SUCCESS){
   	    AUDIO_ERROR("audio_timing_control_asrc_set_target_sample_rate failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   	 }
	 else if((result = audio_timing_control_enable_vsrc_support(input_wl->processor_wl->atc_h, input_wl->atc_stream_h)) != ISMD_SUCCESS){
		AUDIO_ERROR("audio_timing_control_enable_vsrc_support failed!", result, audio_devh[AUDIO_DEBUG_APM]);
	 }
	 else if((result = ismd_audio_pvt_input_set_asrc_mode(input_wl->processor_wl, input_wl->input_id, true)) != ISMD_SUCCESS){
		AUDIO_ERROR("ismd_audio_pvt_input_set_asrc_mode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
	 }
	}
	else if((input_wl->processor_wl->asrc_support_enabled)){
	 if((result = audio_timing_control_disable_vsrc_support(input_wl->processor_wl->atc_h, input_wl->atc_stream_h)) != ISMD_SUCCESS) {
		AUDIO_ERROR("audio_timing_control_disable_vsrc_support failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
	 }
	 else if((result = ismd_audio_pvt_input_set_asrc_mode(input_wl->processor_wl, input_wl->input_id, false)) != ISMD_SUCCESS){
		AUDIO_ERROR("ismd_audio_pvt_input_set_asrc_mode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
	 }
	}
   
   return result;

}

/*********************************************************************************************/


/*********************************************************************************************/
/* Audio Driver AUTO-API tracking and close functions */
/*********************************************************************************************/

ismd_result_t
ismd_audio_add_input_port_track(unsigned long connection,
                              ismd_audio_processor_t processor_h,
                              bool timed_stream,
                              ismd_dev_t *input_h,
                              ismd_port_handle_t *port_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result =  ismd_audio_add_input_port(processor_h, timed_stream, input_h, port_h)) == ISMD_SUCCESS){

      /*Register the connection giving it the input handle*/
      if((result = ismd_connection_register(connection, ismd_audio_remove_input_callback, (void*)*input_h)) != ISMD_SUCCESS){

         audio_remove_input_reconfig(processor_h, *input_h);
         AUDIO_ERROR("connection_register failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else{
      AUDIO_ERROR("add_input_port_track failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
ismd_audio_add_phys_input_track(unsigned long connection,
                              ismd_audio_processor_t processor_h,
                              int hw_id,
                              bool timed_stream,
                              ismd_dev_t *input_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_dev_t input_handle = ISMD_DEV_HANDLE_INVALID;

    AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = ismd_audio_add_phys_input(processor_h, hw_id, timed_stream, input_h)) == ISMD_SUCCESS){

      input_handle = *input_h;

      /*Register the connection giving it the input handle*/
      if((result = ismd_connection_register(connection, ismd_audio_remove_input_callback, (void*)*input_h)) != ISMD_SUCCESS){

        audio_remove_input_reconfig(processor_h, *input_h);
        AUDIO_ERROR("connection_register failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }


   }
   else{
      AUDIO_ERROR("add_input_port_track failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

void
ismd_audio_remove_input_callback(void *data)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   ismd_dev_t input_h  =  (ismd_dev_t) data;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /*Lock the context*/
   if((result = audio_pvt_input_api_dev_lock(input_h, &input_wl)) == ISMD_SUCCESS) {

      if((result = audio_pvt_remove_input(input_wl)) != ISMD_SUCCESS){
         AUDIO_ERROR("audio_pvt_remove_input failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      
      audio_pvt_input_api_unlock(input_wl);
   }
   else{
      AUDIO_ERROR("Invalid input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
      
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return;
}

/*********************************************************************************************/


/*********************************************************************************************/
/* ISMD inherited functions, all funtions apply to inputs */
/*********************************************************************************************/

ismd_result_t
ismd_audio_close_stream(ismd_dev_t handle)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_input_wl_t *input_wl = NULL;
   uint32_t  smd_data = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if ((result = ismd_dev_get_user_data(handle, &smd_data)) == ISMD_SUCCESS) {

      input_wl = (ismd_audio_input_wl_t *) smd_data;

      if((result = ismd_audio_remove_input(input_wl->processor_wl->handle_id, handle)) != ISMD_SUCCESS){
         AUDIO_ERROR("ismd_audio_remove_input failed in ismd_audio_close_stream\n", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      
   }
   else {
      AUDIO_ERROR("ismd_dev_get_user_data failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t 
ismd_audio_set_stream_play_rate( ismd_dev_t handle, 
                               ismd_pts_t current_linear_time, 
                               int rate) 
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   ismd_time_t scaled_rate_change_time;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if ( (result = audio_pvt_input_api_dev_lock( handle, &input_wl )) == ISMD_SUCCESS ) {
      if(rate != input_wl->rate){

         /* If the rate is out of range, flush down to ATC and dont bother to set the rate on the it.*/
         if ((rate < AUDIO_MIN_PLAY_RATE) || (rate > AUDIO_MAX_PLAY_RATE) ) {
            audio_pvt_input_post_port_flush(input_wl);
            input_wl->wait_with_timeout = true;
            if(ismd_event_strobe(input_wl->processor_wl->input_port_event) != ISMD_SUCCESS){
               AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed input queue callback!\n", audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         else {
            input_wl->wait_with_timeout = false;
         }
            
         if (input_wl->atc_stream_h != AUDIO_INVALID_HANDLE) {
            result = audio_timing_control_set_playback_rate(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, current_linear_time, rate);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_set_playback_rate failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         
         if (result == ISMD_SUCCESS && input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) {
            result = audio_timing_control_set_playback_rate(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h, current_linear_time, rate);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_set_playback_rate failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         
         if (result == ISMD_SUCCESS && input_wl->assoc_atc_stream_h != AUDIO_INVALID_HANDLE) {
            result = audio_timing_control_set_playback_rate(input_wl->processor_wl->atc_h, input_wl->assoc_atc_stream_h, current_linear_time, rate);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_set_playback_rate failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }

         if(input_wl->is_timed_stream) {

            ismd_convert_linear_time_to_scaled_time(current_linear_time,
                                      input_wl->rebase_info.last_linear_rate_change_time,
                                      input_wl->rebase_info.last_scaled_rate_change_time,
                                      input_wl->rebase_info.curr_rate,
                                     &scaled_rate_change_time);

            input_wl->rebase_info.last_linear_rate_change_time = current_linear_time;
            input_wl->rebase_info.last_scaled_rate_change_time = scaled_rate_change_time;
            input_wl->rebase_info.curr_rate = rate;
         }

         input_wl->rate = rate;
         input_wl->ignore_inband_rate_change = true;   
         audio_pvt_apm_update_wait(input_wl);  
         audio_pvt_input_chk_disable_pass_stream(input_wl);
      }
      audio_pvt_input_api_unlock( input_wl );
   }
   else {
      AUDIO_ERROR("Invalid input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}

ismd_result_t 
ismd_audio_get_stream_play_rate( ismd_dev_t handle, 
                               int *rate) 
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if (rate == NULL ) {
      result = ISMD_ERROR_NULL_POINTER;
   } else if ( (result = audio_pvt_input_api_dev_lock( handle, &input_wl )) == ISMD_SUCCESS ) {

      *rate = input_wl->rate;
      result = ISMD_SUCCESS;

      audio_pvt_input_api_unlock( input_wl );
   }
   else {
      AUDIO_ERROR("Invalid input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}

ismd_result_t
ismd_audio_set_stream_state(ismd_dev_t handle, ismd_dev_state_t state)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_dev_lock(handle, &input_wl)) == ISMD_SUCCESS) {
         
      /* If we are already in the requested state return success */
      if(state == input_wl->state) {
         result = ISMD_SUCCESS;
      }
      else {
         switch(state){
            case ISMD_DEV_STATE_STOP:
               input_wl->underrun_amount = 0;
               input_wl->underrun_count = 0;
               if((!input_wl->is_sw_input) && (input_wl->state == ISMD_DEV_STATE_PLAY)){  
                  if((result = audio_capture_set_state(input_wl->capture_h, ISMD_DEV_STATE_STOP)) != ISMD_SUCCESS) {
                     AUDIO_ERROR("Error in capture_set_state, in ismd_audio_set_stream_state.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
               
               /*Stop the decode pipe and passthrough stage if enabled. This is so 
                 applications can then set decoder parameters and start it up again.*/
               result = audio_pvt_input_decoder_teardown(input_wl, state);
               
               break;
            case ISMD_DEV_STATE_PAUSE:
               input_wl->underrun_amount = 0;
               input_wl->underrun_count = 0;
               if((!input_wl->is_sw_input) && (input_wl->state == ISMD_DEV_STATE_PLAY)){  
                  if((result = audio_capture_set_state(input_wl->capture_h, ISMD_DEV_STATE_STOP)) != ISMD_SUCCESS) {
                     AUDIO_ERROR("Error in capture_set_state, in ismd_audio_set_stream_state.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
               if(input_wl->state != ISMD_DEV_STATE_PLAY) {
                  result = audio_pvt_input_set_to_play(input_wl);
               }
               break;
            case ISMD_DEV_STATE_PLAY:
               result = audio_pvt_input_set_to_play(input_wl);
               break;
            case ISMD_DEV_STATE_INVALID:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("State set to INVALID.", result, audio_devh[AUDIO_DEBUG_RENDER]);
            default:
               break;
         }

         /*Call into ATC set_state for its input streams.*/
         if(result == ISMD_SUCCESS) {

            if (input_wl->atc_stream_h != AUDIO_INVALID_HANDLE) {
               result = audio_timing_control_set_state(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, state);
               if (result != ISMD_SUCCESS) {
                  AUDIO_ERROR("Setting audio_timing_control_set_state failed", (result), audio_devh[AUDIO_DEBUG_APM]);
               }
            }

            if (result == ISMD_SUCCESS && input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) {
               result = audio_timing_control_set_state(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h, state);
               if (result != ISMD_SUCCESS) {
                  AUDIO_ERROR("Setting audio_timing_control_set_state failed", (result), audio_devh[AUDIO_DEBUG_APM]);
               }
            }

            if (result == ISMD_SUCCESS && input_wl->assoc_atc_stream_h != AUDIO_INVALID_HANDLE) {
               result = audio_timing_control_set_state(input_wl->processor_wl->atc_h, input_wl->assoc_atc_stream_h, state);
               if (result != ISMD_SUCCESS) {
                  AUDIO_ERROR("Setting audio_timing_control_set_state failed", (result), audio_devh[AUDIO_DEBUG_APM]);
               }
            }
         }

         if(result == ISMD_SUCCESS) {
            input_wl->state = state;
         }
      }

      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM], SVEN_MODULE_EVENT_AUD_IO_APM_SET_STATE,
         input_wl->processor_wl->handle_id, input_wl->input_id, input_wl->state, state, 0, 0);
      
      audio_pvt_input_api_unlock(input_wl);
   }
   else{
      AUDIO_ERROR("Invalid input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
ismd_audio_get_stream_state(ismd_dev_t handle, ismd_dev_state_t *state)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if (state == NULL ) {
       result = ISMD_ERROR_NULL_POINTER;
     } else if((result = audio_pvt_input_api_dev_lock(handle, &input_wl)) == ISMD_SUCCESS) {

       *state = input_wl->state;
       result = ISMD_SUCCESS;
      
      audio_pvt_input_api_unlock(input_wl);
   }
   else{
      AUDIO_ERROR("Invalid input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


ismd_result_t
ismd_audio_flush_stream(ismd_dev_t handle)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if((result = audio_pvt_input_api_dev_lock(handle, &input_wl)) == ISMD_SUCCESS) {

      result = audio_pvt_input_flush(input_wl);

      audio_pvt_input_api_unlock(input_wl);

   } else {
      AUDIO_ERROR("Invalid input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
ismd_audio_set_stream_base_time(ismd_dev_t handle, ismd_time_t time)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_dev_lock(handle, &input_wl)) == ISMD_SUCCESS){

      /* Cant allow base time set when in a playing state */
      if(input_wl->state != ISMD_DEV_STATE_PLAY) {

         if (input_wl->atc_stream_h != AUDIO_INVALID_HANDLE) {
            result = audio_timing_control_set_base_time(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, time);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_set_base_time failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }

         if (result == ISMD_SUCCESS && input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) {
            result = audio_timing_control_set_base_time(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h, time);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_set_base_time failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }

            input_wl->pass_needs_basetime = false;            
         }

         if (result == ISMD_SUCCESS && input_wl->assoc_atc_stream_h != AUDIO_INVALID_HANDLE) {
            result = audio_timing_control_set_base_time(input_wl->processor_wl->atc_h, input_wl->assoc_atc_stream_h, time);
            if (result != ISMD_SUCCESS) {
               AUDIO_ERROR("Setting audio_timing_control_set_base_time failed", (result), audio_devh[AUDIO_DEBUG_APM]);
            }
         }         
         
         if (result == ISMD_SUCCESS) {
            input_wl->smd_base_time = time;
         }
      }
      else {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("Audio input is in a playing state, please set to STOP or PAUSE  to change base time.", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR("Invalid input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
ismd_audio_get_stream_base_time(ismd_dev_t handle, ismd_time_t *time)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if (time == NULL ) {
       result = ISMD_ERROR_NULL_POINTER;
     } else if((result = audio_pvt_input_api_dev_lock(handle, &input_wl)) == ISMD_SUCCESS){

      *time = input_wl->smd_base_time;
      result = ISMD_SUCCESS;

      audio_pvt_input_api_unlock(input_wl);
   }
   else {
      AUDIO_ERROR("Invalid input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
ismd_audio_set_stream_clock(ismd_dev_t handle, ismd_clock_t clock)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_dev_lock(handle, &input_wl)) == ISMD_SUCCESS){

      if (input_wl->atc_stream_h != AUDIO_INVALID_HANDLE) {
         result = audio_timing_control_set_clock(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, clock);
         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Setting audio_timing_control_set_clock failed", (result), audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (result == ISMD_SUCCESS && input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE) {
         //Set the clock on the passthrough stream if attached. 
         result = audio_timing_control_set_clock(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h, clock);
         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Setting audio_timing_control_set_clock failed", (result), audio_devh[AUDIO_DEBUG_APM]);
         }

         input_wl->pass_needs_clock = false;         
      }

      if (result == ISMD_SUCCESS && input_wl->assoc_atc_stream_h != AUDIO_INVALID_HANDLE) {
         result = audio_timing_control_set_clock(input_wl->processor_wl->atc_h, input_wl->assoc_atc_stream_h, clock);
         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Setting audio_timing_control_set_clock failed", (result), audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if (result == ISMD_SUCCESS && input_wl->capture_h != AUDIO_INVALID_HANDLE ) {
         result = audio_capture_set_clock( input_wl->capture_h, clock);
         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Setting audio_capture_set_clock failed", (result), audio_devh[AUDIO_DEBUG_APM]);
         }
      }
      
      if (result == ISMD_SUCCESS) {
         input_wl->clock = clock;
      }

      audio_pvt_input_api_unlock(input_wl);

   } else {
      AUDIO_ERROR("Invalid input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
ismd_audio_set_stream_slave_clock(ismd_dev_t handle, ismd_clock_t clock)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_dev_lock(handle, &input_wl)) == ISMD_SUCCESS){
       if((result = audio_timing_control_set_slave_clock(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, clock)) != ISMD_SUCCESS){
 
          AUDIO_ERROR("audio_timing_control_set_slave_clock failed!", result, audio_devh[AUDIO_DEBUG_APM]);
 
       } else{
 
          //Do not set the slave clock on the passthrough stream - Driving the slave clock in two places may cause 
          //more jitters.
          //This is not a problem because there is always a decoder pipeline currently. If we support passthrough ONLY
          //pipeline in the futher, the code here is subject to change. 
 
          input_wl->slave_clock = clock;
       }

      audio_pvt_input_api_unlock(input_wl);

   } else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
ismd_audio_input_set_sync_clock(ismd_audio_processor_t processor_h,
                                             ismd_dev_t input_h,
                                             clock_sync_t sync_clock)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){

      input_wl->capture_sync_clock = sync_clock;
      
      /* If it's a valid clock sync handle, then reset it. */
      if ( sync_clock != ISMD_CLOCK_HANDLE_INVALID ) {
         clock_sync_reset( sync_clock );
      }

      /* If the audio capture handle has already been created, then set the clock sync handle on the capture device. */
      if ( input_wl->capture_h != AUDIO_INVALID_HANDLE ) {
         audio_capture_set_sync_clock( input_wl->capture_h, sync_clock );
      }

      audio_pvt_input_api_unlock(input_wl);

   } else {
      AUDIO_ERROR("Invalid processor or input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


ismd_result_t ismd_audio_set_underrun_event( ismd_dev_t handle, 
                               ismd_event_t underrun_event)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_dev_lock(handle, &input_wl)) == ISMD_SUCCESS){    

      result = audio_timing_control_set_underrun_event(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, underrun_event);

      input_wl->underrun_event = underrun_event;

      audio_pvt_input_api_unlock(input_wl);
   } 
   else {
      AUDIO_ERROR("Invalid input handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

  AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


ismd_result_t ismd_audio_get_underrun_amount( ismd_dev_t handle, 
                               ismd_time_t *underrun_amount)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_input_wl_t *input_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if (underrun_amount == NULL) {
      result = ISMD_ERROR_NULL_POINTER;
   } else if((result = audio_pvt_input_api_dev_lock(handle, &input_wl)) == ISMD_SUCCESS){

      /*FIXME: If this is called to often we could get a priority inversion problem.*/
      result = audio_timing_control_get_underrun_amount(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, underrun_amount);

      /* If the timing control didn't return an underrun amnt, APM must have triggered. Send that amount. */
      if(*underrun_amount == 0) {
        *underrun_amount = input_wl->underrun_amount;
      }
      
      audio_pvt_input_api_unlock(input_wl);
   } 
   else {
      AUDIO_ERROR("input_validate_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

  AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


/*****************************************************************************/


ismd_result_t 
audio_input_initialize_events( ismd_audio_input_wl_t *input_workload )
{
   ismd_result_t result = ISMD_SUCCESS;
   int event_type;

   for ( event_type = 0; event_type < ISMD_AUDIO_NOTIFY_COUNT; event_type++ ) {
      input_workload->notification_events[event_type] = ISMD_EVENT_HANDLE_INVALID;
   }

   return ( result );
}



ismd_result_t 
audio_input_deinitialize_events( ismd_audio_input_wl_t *input_workload )
{
   ismd_result_t result = ISMD_SUCCESS;
   int event_type;
   ismd_event_t local_event;

   for ( event_type = 0; event_type < ISMD_AUDIO_NOTIFY_COUNT; event_type++ ) {
      local_event = input_workload->notification_events[event_type];
      if ( local_event != ISMD_EVENT_HANDLE_INVALID ) {
         ismd_event_free( local_event );
      }
   }

   return ( result );
}


ismd_result_t
audio_input_notify_event( ismd_dev_t input_h, 
                          ismd_audio_notification_t  event_type )
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_event_t local_event = ISMD_EVENT_HANDLE_INVALID;
   ismd_audio_input_wl_t     *input_workload;

   OS_ASSERT( audio_core_validate_event_type(event_type) );      
   if ((result = audio_pvt_input_validate_wl(input_h, &input_workload)) == ISMD_SUCCESS){

      local_event = input_workload->notification_events[event_type-1];

      if ( local_event != ISMD_EVENT_HANDLE_INVALID ) {
         result = ismd_event_strobe( local_event );
      }
   }
   return ( ISMD_SUCCESS );
}

ismd_result_t
audio_input_suspend(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   if(input_wl->is_sw_input){
      if(input_wl->dec_in_queue_h != ISMD_QUEUE_HANDLE_INVALID){
         if (ISMD_SUCCESS != (result = ismd_queue_disconnect_input(input_wl->dec_in_queue_h))){
            AUDIO_ERROR("disconnect apm input failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if(input_wl->pass_psm_pipe_in_queue_h != ISMD_QUEUE_HANDLE_INVALID){
         if (ISMD_SUCCESS != (result = ismd_queue_disconnect_input(input_wl->pass_psm_pipe_in_queue_h))){
            AUDIO_ERROR("disconnect apm input failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      
      }
      if(input_wl->format == ISMD_AUDIO_MEDIA_FMT_PCM) {
         if (input_wl->pass_pipe_enabled) {
            if (ISMD_SUCCESS != (result = ismd_queue_disconnect_input(input_wl->pass_atc_in_queue_h))){
               AUDIO_ERROR("disconnect atc input failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         else {
            if (ISMD_SUCCESS != (result = ismd_queue_disconnect_input(input_wl->atc_in_queue_h))){
               AUDIO_ERROR("disconnect atc input failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }else {
               input_wl->audio_in_queue_h = ISMD_QUEUE_HANDLE_INVALID;
            }
         }
      }

      if(ISMD_SUCCESS != (result = audio_pvt_input_flush_queues(input_wl))){
         AUDIO_ERROR("audio_pvt_input_flush_queues failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      if(ISMD_SUCCESS != (audio_pvt_phys_input_shutdown(input_wl))){
         AUDIO_ERROR("audio_pvt_phys_input_shutdown failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else if(ISMD_SUCCESS != (result = ismd_queue_flush(input_wl->atc_in_queue_h))){
         AUDIO_ERROR("flush output queue failed", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   if(result == ISMD_SUCCESS) {
      result = audio_pvt_input_decoder_teardown(input_wl, ISMD_DEV_STATE_STOP);
   }

   /*This input is not added to post ATC pipe now, flag it as such.*/
   input_wl->added_to_post_atc_pipe = false;

   return result;
}

ismd_result_t
audio_input_resume(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   
   if(!input_wl->is_sw_input){
      /*handle audio physcal input case*/
      if (ISMD_SUCCESS != (result = audio_pvt_phys_input_startup(input_wl))) {
         AUDIO_ERROR("audio_pvt_phys_input_config failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      /*recover decoder pipe if any previously*/
      if((result = audio_pvt_input_start_decoder_pipe(input_wl)) != ISMD_SUCCESS){
         AUDIO_ERROR("audio_pvt_input_start_decoder_pipe failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      
   }

   return result;

}

ismd_result_t ismd_audio_set_stream_timing_mode(ismd_dev_t input_h, ismd_timing_mode_t timing_mode)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   if(timing_mode != ISMD_TIMING_MODE_CONVERTED && timing_mode != ISMD_TIMING_MODE_ORIGINAL) {
      return ISMD_ERROR_INVALID_PARAMETER;
   }

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_dev_lock(input_h, &input_wl)) == ISMD_SUCCESS){

      if((result = audio_timing_control_set_timing_mode(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, timing_mode)) != ISMD_SUCCESS){

         AUDIO_ERROR("audio_timing_control_set_timing_mode failed!", result, audio_devh[AUDIO_DEBUG_APM]);

      } else {
         input_wl->timing_mode = timing_mode;
      }

      audio_pvt_input_api_unlock(input_wl);

   } else {
      AUDIO_ERROR("audio_pvt_input_api_dev_lock failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t ismd_audio_set_stream_newsegment_policy(ismd_dev_t input_h, ismd_newsegment_policy_t policy)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_input_wl_t *input_wl = NULL;

   if(policy != ISMD_NEWSEGMENT_POLICY_STRICT && policy != ISMD_NEWSEGMENT_POLICY_LOOSE) {
      AUDIO_ERROR("audio_timing_control_set_newsegment policy: bad policy!", ISMD_ERROR_INVALID_PARAMETER, audio_devh[AUDIO_DEBUG_APM]);
      return ISMD_ERROR_INVALID_PARAMETER;
   }

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_dev_lock(input_h, &input_wl)) == ISMD_SUCCESS){

      if((result = audio_timing_control_set_newsegment_policy(input_wl->processor_wl->atc_h, input_wl->atc_stream_h, policy)) != ISMD_SUCCESS){

         AUDIO_ERROR("audio_timing_control_set_newsegment policy failed!", result, audio_devh[AUDIO_DEBUG_APM]);

      } 

      audio_pvt_input_api_unlock(input_wl);

   } else {
      AUDIO_ERROR("audio_pvt_input_api_dev_lock failed!\n", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
ismd_audio_input_enable_custom_processing( ismd_audio_processor_t processor_h, 
                                           ismd_dev_t             input_h, 
                                           uint32_t               phys_base, 
                                           unsigned int           size )
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){
      
      /* Configure the CAPP stage with the user's input*/
      input_wl->psm_dec_pipe.stages[CAPP_STAGE].params.capp.host.capp.local_storage_base = phys_base;
      input_wl->psm_dec_pipe.stages[CAPP_STAGE].params.capp.host.capp.local_storage_size = size;
      //TODO: message passing from custom library to the host is not yet implemented
      input_wl->psm_dec_pipe.stages[CAPP_STAGE].params.capp.host.capp.msg_handle = ISMD_EVENT_HANDLE_INVALID;
      input_wl->psm_dec_pipe.stages[CAPP_STAGE].params.capp.host.capp.enabled = true; 
      input_wl->psm_dec_pipe.stages[CAPP_STAGE].in_use = true;
      /*Make sure this input is put on the DSP for processing now.*/
      input_wl->needs_pcm_preprocessing = true;

      /*If the decoder pipeline is up and running need to rebuild it, setting the stage to in_use=true will include the stage.
        If the seamless enabling and disabling is needed, will need to happen when PSM supports on the fly stage addition.*/
      if(input_wl->psm_dec_pipe.pipe_started && input_wl->psm_dec_pipe.pipe_h != AUDIO_INVALID_HANDLE){
         
         if((result = audio_pvt_input_decoder_teardown(input_wl, input_wl->state)) == ISMD_SUCCESS) {
            result = audio_pvt_input_start_decoder_pipe(input_wl);
         }
      }
      audio_pvt_input_api_unlock(input_wl);
   }
   else{
       AUDIO_ERROR("Invalid processor or input handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_input_disable_custom_processing( ismd_audio_processor_t processor_h, ismd_dev_t input_h )
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;    
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){
      
      /*Disable the stage */
      input_wl->psm_dec_pipe.stages[CAPP_STAGE].params.capp.host.capp.enabled = false;
      input_wl->psm_dec_pipe.stages[CAPP_STAGE].in_use = false;
       
      /*If the decoder pipeline is up and running need to rebuild it, setting the stage to in_use=true will include the stage.
        If the seamless enabling and disabling is needed, will need to happen when PSM supports on the fly stage addition.*/
      if(input_wl->psm_dec_pipe.pipe_started && input_wl->psm_dec_pipe.pipe_h != AUDIO_INVALID_HANDLE){
            
         if((result = audio_pvt_input_decoder_teardown(input_wl, input_wl->state)) == ISMD_SUCCESS) {
            if((result = audio_pvt_input_start_decoder_pipe(input_wl)) == ISMD_SUCCESS) {

               /*Reinit the stage */
               OS_MEMSET(&input_wl->psm_dec_pipe.stages[CAPP_STAGE], 0 , sizeof(audio_psm_pipe_stage_t));
               input_wl->psm_dec_pipe.stages[CAPP_STAGE].task = PSM_TASK_CAPP;
            }
         }        
      }
      audio_pvt_input_api_unlock(input_wl);      
   }         
   else{
       AUDIO_ERROR("Invalid processor or input handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }      

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_input_set_stream_parsing_mode( ismd_audio_processor_t processor_h, 
                              ismd_dev_t input_h, 
                              ismd_audio_input_parsing_mode_t mode,
                              unsigned int event_mask)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){

      /*Ensure we are not playing or paused.*/
      if(input_wl->state != ISMD_DEV_STATE_PAUSE && input_wl->state != ISMD_DEV_STATE_PLAY) {

         /*Validate the mode and record it to our input context workload.*/
         switch(mode) {
            case ISMD_AUDIO_INPUT_PARSING_MODE_DISABLED:
            case ISMD_AUDIO_INPUT_PARSING_MODE_IEC61937:
			case ISMD_AUDIO_INPUT_PARSING_MODE_IEC60958_CUSTOM:
               input_wl->parsing_mode = mode;
               input_wl->parser_event_mask = event_mask;
               break;
            case ISMD_AUDIO_INPUT_PARSING_MODE_IEC60958:
               result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
               break;   
           
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               break;
         }
      }
      else {
         result = ISMD_ERROR_INVALID_REQUEST;
      }

      audio_pvt_input_api_unlock(input_wl);      
   }         
   else{
      AUDIO_ERROR("Invalid processor or input handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}

ismd_result_t 
ismd_audio_input_get_detected_stream_info(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_input_parsing_status_t *status_info)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t *input_wl = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_pvt_input_api_lock(processor_h, input_h, &input_wl)) == ISMD_SUCCESS){

      /*Make sure the parser is running, then call down to get the stream information.*/
      if(input_wl->psm_dec_pipe.stages[IEC_PARSER_STAGE].in_use) {

         /*Get the stage information from IEC parser.*/
         if((result = audio_pvt_input_get_detected_stream_info(input_wl))== ISMD_SUCCESS) {  
            
            /*Copy over parser status.*/
            *status_info = input_wl->parser_status;
         }
      }
      else {
         result = ISMD_ERROR_NO_DATA_AVAILABLE;
      }
      audio_pvt_input_api_unlock(input_wl);      
   }         
   else{
      AUDIO_ERROR("Invalid processor or input handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}

