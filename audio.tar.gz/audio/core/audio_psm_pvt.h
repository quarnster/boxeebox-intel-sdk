/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_PSM_PVT_H_
#define _AUDIO_PSM_PVT_H_

#include "osal.h"
#include "ismd_audio_defs.h"
#include "ismd_core.h"
#include "ismd_core_protected.h"
#include "osal.h"
#include "sven_module.h"
#include "audio_psm_defs.h"
#include "audio_dsp.h"


/* --------------------------------------------------------------------------- */
/* Function pointer definitions of PSM implementation layer functions. */
/* --------------------------------------------------------------------------- */
typedef ismd_result_t (* psm_impl_pipe_add_func_t)( audio_psm_pipe_t *pipe, int *handle );

typedef ismd_result_t (* psm_impl_pipe_remove_func_t)( int handle );

typedef ismd_result_t (* psm_impl_pipe_start_func_t) ( int handle );

typedef ismd_result_t (* psm_impl_pipe_stop_func_t) ( int handle );

typedef ismd_result_t (* psm_impl_pipe_flush_func_t) ( int handle );

typedef ismd_result_t (* psm_impl_pipe_configure_func_t)( int handle );

typedef ismd_result_t (* psm_impl_stage_configure_func_t)( int handle, int stage_handle);

typedef ismd_result_t (* psm_impl_stage_get_stream_info_func_t)( int handle, int stage_handle);

typedef ismd_result_t (* psm_impl_stage_get_stage_params_func_t)( int handle, int stage_handle);

typedef ismd_result_t (* psm_impl_job_write_input_func_t) ( int handle, audio_psm_job_desc_t *job );

typedef ismd_result_t (* psm_impl_job_read_output_func_t) ( int handle, audio_psm_job_desc_t *job, int queue_id );

typedef ismd_result_t (* psm_impl_pipe_codec_available_func_t) ( int handle, uint8_t dsp_num, codecs_available_t *codec_status );

typedef ismd_result_t (* psm_impl_get_codec_ver_func_t) ( int handle, uint8_t dsp_num, uint8_t codec, char *ver_string );


/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Structure which holds all the global variables of the PSM 
	This structure is just placeholder for global variables of PSM device. 
	NOTE: When addding vars make sure to add them to the reset function. */
/* --------------------------------------------------------------------------- */
typedef struct 
{
	bool initialized;
	os_mutex_t lock;

	/* This needs to be an SMD_Buffer so that the DSP can read it. 
	It would be allocated and initialized by the PSM layer before being passed
	into the host side fw. */
	ismd_buffer_descriptor_t *psm_stages_smd_buf_desc;
	audio_psm_stage_t *psm_stages; 
	uint32_t psm_stages_total_count;

	os_event_t input_data_event;
	bool input_data_event_created; //needed to decide whether event was created or not to destroy

	os_event_t io_event;
	bool io_event_created; //needed to decide whether event was created or not to destroy
	 
   os_thread_t io_thread;
	bool io_thread_created; //needed to decide whether thread was created or not to destroy

	/* Thread closing variables. */
	bool start_to_close_io_thread;
	bool safe_to_close_io_thread;	
	os_event_t safe_to_close_io_thread_event;
	bool safe_to_close_io_thread_event_created; //needed to decide whether event was created or not to destroy	

	int current_input_wl_handle;
	int current_output_wl_handle;
}audio_psm_device_t;
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/*  Work load structure. Corresponds to a pipe. 
	 NOTE: When addding vars make sure to add them to the reset function. */
/* --------------------------------------------------------------------------- */
typedef struct 
{
   bool initialized;
   uint32_t handle;	/* Usually the index into the array to which this element belongs to. */
   bool in_use;	/* Indicated whether this workload is in use. */
   bool added;		/* Indicates whether the pipe is already instantiated on the implementation layer */
   bool started;	/* Indicates whether the pipe is stared or stopped. There are only two states to a pipe. STARTED/STOPPED	*/
   bool reconfigure; /* Indicates whether the pipe needs to be reconfigured.*/
   bool pipe_buffers_allocated;/* Flag to indicate that the buffers for this pipe have been allocated. */
   bool start_to_stop; /* Need to to know when stop is called. */
   os_mutex_t *input_queue_lock;	/* Pointer to a lock that prevents the PSM from dequeue from queues connected to the output of the ATC */

   audio_psm_pipe_t pipe;

   audio_psm_job_desc_t output_job[PSM_PIPE_MAX_NUM_OUT_QUEUES]; /*Keep a "cubby" for an output job that didnt get enqueued for every queue.*/
   audio_psm_job_desc_t input_job; /*Keep a "cubby" for an input job that didnt get sent*/
   bool out_job_buf_sent[PSM_MAX_OUTPUT]; /* Keeps track of what queue had its buffer enqueued */

   ismd_queue_handle_t input_queues[PSM_MAX_INPUT];
   int input_queues_out_id[PSM_MAX_INPUT];
   uint32_t input_queues_count;

   ismd_queue_handle_t output_queues[PSM_MAX_OUTPUT];
   uint32_t output_queues_count;
   bool output_queue_enabled[PSM_MAX_OUTPUT]; /* Keeps track of which of the output queues are enabled. */
   /* I'll give a KUDOS to the person who understands this comment the first time they read it...
   Sorry couldn't think of a better way of explaining this. */
   /* This corresponds to the input id of the output stage. Each output queue is mapped to an input of the output stage. 
   One input of the output stage can be mapped two output queues. */
   int output_queue_input_id[PSM_MAX_OUTPUT]; 
   int num_pipe_outputs; /** This is how many outputs there are for this pipe. Or output stage output count.*/

   int psm_impl_handle;

   /*Queues to handle tags coming from a particular pipe.*/
   ismd_queue_handle_t tags_queue[PSM_MAX_OUTPUT];
   /*Reference count of the tags queue allocated per output id.*/
   int tags_queue_ref_count[PSM_MAX_OUTPUT];

   psm_impl_pipe_add_func_t psm_impl_pipe_add;
   psm_impl_pipe_remove_func_t psm_impl_pipe_remove;
   psm_impl_pipe_start_func_t psm_impl_pipe_start;
   psm_impl_pipe_stop_func_t psm_impl_pipe_stop;
   psm_impl_pipe_flush_func_t psm_impl_pipe_flush;
   psm_impl_pipe_configure_func_t psm_impl_pipe_configure;
   psm_impl_job_write_input_func_t psm_impl_job_write_input;
   psm_impl_job_read_output_func_t psm_impl_job_read_output;
   psm_impl_pipe_codec_available_func_t psm_impl_codec_available;
   psm_impl_get_codec_ver_func_t psm_impl_codec_ver;
   psm_impl_stage_configure_func_t psm_impl_stage_configure;
   psm_impl_stage_get_stream_info_func_t psm_impl_get_stream_info;
   psm_impl_stage_get_stage_params_func_t psm_impl_get_stage_params;
}audio_psm_wl_t;
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Private Functions */
/* --------------------------------------------------------------------------- */
static void audio_psm_pvt_wl_reset(audio_psm_wl_t *wl);

static ismd_result_t audio_psm_pvt_out_queue_dis_en(audio_psm_wl_t *wl, ismd_queue_handle_t queue_handle, bool enabled);

static void audio_psm_pvt_device_reset(audio_psm_device_t *device);

static void audio_psm_pvt_stage_reset(audio_psm_stage_t *stage, bool deref_output_buffers);

static audio_psm_wl_t *audio_psm_pvt_wl_get ( audio_psm_pipe_handle_t handle );

static audio_psm_wl_t *audio_psm_pvt_wl_get_by_imple_handle ( int handle );

static audio_psm_stage_t *audio_psm_pvt_stage_get ( audio_psm_stage_handle_t handle );

static void audio_psm_pvt_lock(void);

static void audio_psm_pvt_unlock(void);

static void audio_psm_pvt_lock_queues(os_mutex_t *lock);

static void audio_psm_pvt_unlock_queues(os_mutex_t *lock);

static bool audio_psm_pvt_stage_get_available( audio_psm_stage_t **stage );

static ismd_result_t audio_psm_pvt_stage_add( audio_psm_pipe_t *pipe, audio_psm_stage_t *stage );

static ismd_result_t audio_psm_pvt_input_queue_remove(audio_psm_wl_t *wl, ismd_queue_handle_t queue_handle);

static ismd_result_t audio_psm_pvt_output_queue_remove(audio_psm_wl_t *wl, ismd_queue_handle_t queue_handle);

static ismd_result_t audio_psm_pvt_queue_remove( ismd_queue_handle_t *queues, int *id_queue, int count, ismd_queue_handle_t queue_handle, int *id);

static ismd_result_t audio_psm_pvt_job_get_input ( audio_psm_wl_t *wl );

static ismd_result_t audio_psm_pvt_job_get_output ( audio_psm_wl_t *wl, int queue_id );

static ismd_result_t audio_psm_pvt_job_send_output ( audio_psm_wl_t *wl, audio_psm_job_desc_t *output_job, int queue_id);

static void *audio_psm_pvt_io_thread ( void *data );

static void audio_psm_pvt_process_input_jobs( bool *wait_for_io_event);

static void audio_psm_pvt_process_output_jobs( bool *wait_for_io_event);

static ismd_result_t audio_psm_pvt_pipe_stages_free ( audio_psm_pipe_t *pipe );

static ismd_result_t audio_psm_pvt_buffer_allocate(audio_psm_buf_desc_t *psm_buf,
																	uint32_t size);

static ismd_result_t audio_psm_pvt_buffer_reset( audio_psm_buf_desc_t *psm_buf, 
																bool dereference_buf );

static void audio_psm_pvt_set_implementation_layer( audio_psm_wl_t *wl );

static ismd_result_t audio_psm_pvt_input_callback ( void *handle, 
															ismd_queue_event_t queue_event,
													      ismd_buffer_handle_t buffer );

static ismd_result_t audio_psm_pvt_output_callback ( void *context, ismd_queue_event_t queue_event, ismd_buffer_handle_t *buffer );

static ismd_result_t audio_psm_pvt_alloc_stage_buffers( audio_psm_pipe_t *pipe );

static void audio_psm_pvt_job_reset ( audio_psm_job_desc_t *job, bool dereference_buf );

static ismd_result_t audio_psm_pvt_pipe_stop( audio_psm_wl_t *wl);

static ismd_result_t audio_psm_pvt_pipe_free( audio_psm_wl_t *wl);

/**
Function to copy the host params over to the DSP viewable memory area. 
The DSP can then invalidate the host region and get its copy of the parameters.

@param[in] stage : Pointer to the stage context.
@param[in] params : Pointer to the host params to be copied over.
@param[in] pipe_started : Flag to tell if pipe is started or not.
*/
static void 
audio_psm_pvt_copy_htod_params(audio_psm_stage_t *stage, audio_psm_stage_params_t *params, bool pipe_started);

/**
Function to take the parameters that the DSP will udpate when 
requested by the host to the host side data, then will copy that 
data into the callers viewable memory space. 

@param[in] stage : Pointer to the stage context.
@param[in] params : Pointer to the host params where the 
   DSP updated parameters will be copied into. 
*/
static void
audio_psm_pvt_copy_dtoh_params(audio_psm_stage_t *stage, audio_psm_stage_params_t *params);

const char 
*audio_psm_task_to_string(audio_psm_stage_task_t task);
/* --------------------------------------------------------------------------- */

#endif
