
/*
* File Name: audio_apm_outputs.c
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_apm_common.h"
#include "audio_sadiv_defs.h"

/*********************************************************************************************/
/* Audio Private Ouput function declarations */
/*********************************************************************************************/

static ismd_result_t
audio_pvt_remove_output(ismd_audio_output_wl_t *output_wl);

static ismd_result_t
audio_pvt_stop_recovery_thread(ismd_audio_output_wl_t *output_wl);

static void 
audio_pvt_output_lock(ismd_audio_output_wl_t *instance);

static bool 
audio_pvt_output_valid_handle( ismd_audio_processor_t handle );

static ismd_result_t
audio_pvt_output_queue_callback(void *context, ismd_queue_event_t queue_event, ismd_buffer_handle_t buffer );

static void 
*audio_pvt_output_port_thread(void *context);

static void
*audio_pvt_output_render_recovery_thread(void *context);

static ismd_result_t
audio_pvt_output_config_render_and_start(ismd_audio_output_wl_t *output_wl); 

static int
audio_pvt_output_ch_config_to_count(ismd_audio_channel_config_t ch_config );

static ismd_result_t
audio_pvt_output_validate_final_output_setup(ismd_audio_output_wl_t *output_wl);

static ismd_result_t
audio_pvt_output_validate_config(ismd_audio_output_config_t *config, bool hw_input, int hw_id);

static bool
audio_pvt_output_valid_hw_id(int hw_id);

static bool
audio_pvt_output_valid_sample_rate(int sample_rate);

static bool
audio_pvt_output_valid_sample_size(int sample_size);

static bool
audio_pvt_output_valid_output_mode(ismd_audio_output_mode_t output_mode);

static bool
audio_pvt_output_valid_channel_config(ismd_audio_channel_config_t chan_config);

static bool
audio_pvt_output_valid_stream_delay(int stream_delay);

static ismd_result_t
audio_pvt_set_sadiv_value(ismd_audio_output_wl_t *output_wl, unsigned int master_clk_freq);

static ismd_result_t
audio_pvt_output_set_delay(audio_psm_post_atc_pipe_t *pipe, int output_handle, int delay_ms);

static ismd_result_t 
audio_pvt_srs_validate_and_set_params(audio_output_srs_pipe_t* srs_context , ismd_audio_srs_pipe_params_t* params);

static ismd_result_t 
audio_pvt_srs_get_params(ismd_audio_output_wl_t *output_wl , ismd_audio_srs_pipe_params_t *params);

static ismd_result_t 
audio_pvt_srs_set_params(ismd_audio_output_wl_t *output_wl, ismd_audio_srs_pipe_params_t *params);

static ismd_result_t
audio_pvt_srs_get_context(ismd_audio_output_wl_t *output_wl);

static ismd_result_t
audio_pvt_srs_free_context(ismd_audio_output_wl_t *output_wl);

static ismd_result_t 
audio_pvt_init_srs_params(audio_output_srs_pipe_t *srs_context);




/*********************************************************************************************/


/*********************************************************************************************/
/* Audio Ouput APIs*/
/*********************************************************************************************/

ismd_result_t
ismd_audio_add_output_port(ismd_audio_processor_t processor_h,
                              ismd_audio_output_config_t config,
                              ismd_audio_output_t *output_h,
                              ismd_port_handle_t *port_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_output_t handle = AUDIO_INVALID_HANDLE;
   ismd_audio_output_t tmp_handle = AUDIO_INVALID_HANDLE;
   ismd_port_config_t port_config;
   ismd_audio_processor_context_t *wl = NULL;
   ismd_audio_output_wl_t *output_wl = NULL;
   char port_name[SMD_PORT_NAME_LENGTH];
   bool is_passthrough = false;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /*Initialize port_config structure members we check on failure case.*/
   port_config.event = ISMD_EVENT_HANDLE_INVALID;

   if ((result = audio_pvt_output_validate_config(&(config), false, 0)) == ISMD_SUCCESS) {

      /*Get processor workload.*/
      if ((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS) {

         /* Configure input port attributes*/
         port_config.attributes = ISMD_PORT_QUEUE_ON | ISMD_PORT_QUEUE_MAX_DEPTH_BUFFERS | ISMD_PORT_QUEUE_DISCONNECT_BLOCK;
         port_config.max_depth = 5;
         port_config.watermark = ISMD_QUEUE_WATERMARK_NONE;
         port_config.event_mask = ISMD_QUEUE_EVENT_NOT_FULL |ISMD_QUEUE_EVENT_EMPTY;
         strncpy(port_name, "audio output port", SMD_PORT_NAME_LENGTH);

         result = ISMD_ERROR_NO_RESOURCES;

         /*Query Processor for an available output instance */
         for(handle =0; handle < AUDIO_MAX_OUTPUTS; handle++) {

            output_wl = &(wl->outputs[handle]);
            audio_pvt_output_lock( output_wl );

            if(!output_wl->in_use) {

               /*Populate output handle, mark output in use*/
               tmp_handle = handle;
               output_wl->processor_wl = wl;
               output_wl->handle = handle;
               output_wl->in_use = true;
               output_wl->is_sw_output = true;
               output_wl->output_mode = config.out_mode;
               output_wl->output_mode = config.out_mode;
               output_wl->sample_rate = config.sample_rate;
               output_wl->sample_size = config.sample_size;
               output_wl->sample_size_actual = config.sample_size;
               output_wl->channel_config = config.ch_config;
               output_wl->ch_map = config.ch_map;
               output_wl->channel_count = audio_pvt_output_ch_config_to_count(output_wl->channel_config );
               handle = AUDIO_MAX_OUTPUTS;
               result = ISMD_SUCCESS;

               //If we have outputs already attached and the post ATC pipe is already started
               //make sure to reconfigure the pipe with this new output. 
               if(wl->psm_pa_pipe.pipe_configured){
                  output_wl->reconfig_post_atc_pipe = true;
               }

               if(wl->psm_pass_pipe.pipe_configured) {
                  output_wl->reconfig_pass_pipe = true;
               }

               if(config.out_mode ==  ISMD_AUDIO_OUTPUT_PASSTHROUGH) {
                  is_passthrough = true;
               }
               else if(config.out_mode ==  ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL) {
                  //Set encoder default params, since we know this is going to require the decoder. 
                  audio_ac3_enc_set_default_params(&output_wl->processor_wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder); 
                  output_wl->encode_params_set = true;
               }
               else if(config.out_mode ==  ISMD_AUDIO_OUTPUT_ENCODED_DTS) {
                  //Set encoder default params, since we know this is going to require the decoder. 
                  audio_dts_enc_set_default_params(&output_wl->processor_wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder); 
                  output_wl->encode_params_set = true;
               }     
               else if(config.out_mode ==  ISMD_AUDIO_OUTPUT_ENCODED_AAC) {
                  //Set encoder default params, since we know this is going to require the decoder. 
                  audio_aac_enc_set_default_params(&output_wl->processor_wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder); 
                  output_wl->encode_params_set = true;
               }  			   
            }
            audio_output_unlock(output_wl);
         }

         if (result != ISMD_SUCCESS) {
            AUDIO_ERROR("Error getting output from processor!.", result, audio_devh[AUDIO_DEBUG_APM]);
         } 
         else {

            audio_pvt_output_lock( output_wl );

            if ( (result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, 5, "render input queue", 16, 0, &(output_wl->psm_output_queue))) != ISMD_SUCCESS ) {
               AUDIO_ERROR("render_input queue alloc failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            else if ((result = ismd_queue_connect_output(output_wl->psm_output_queue, (ismd_consumer_func_t)audio_pvt_output_queue_callback, (void *)output_wl, ISMD_QUEUE_WATERMARK_NONE)) != ISMD_SUCCESS) {
               AUDIO_ERROR("q_connect_output failed output port", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            /* Allocate the event so we can trigger when there is data at the queue.*/
            else if ((result = ismd_event_alloc(&(output_wl->queue_data_avail_event))) != ISMD_SUCCESS) {
               AUDIO_ERROR("event_alloc failed for queue_data_avail_event in add_output_port.", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            /* Allocate the event so we can trigger when output port is not full.*/
            else if ((result = ismd_event_alloc(&(port_config.event))) != ISMD_SUCCESS) {
               port_config.event = ISMD_EVENT_HANDLE_INVALID;
               AUDIO_ERROR("event_alloc failed for out_port_full_event in add_output_port.", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            else if ((result = ismd_port_alloc_named(ISMD_PORT_TYPE_OUTPUT, &port_config, port_name, 16, 0, &(output_wl->output_port))) != ISMD_SUCCESS) {
               AUDIO_ERROR("Error alloc output port from SMD, in add_output.", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            else {
               output_wl->out_port_full_event = port_config.event;
               *output_h = tmp_handle;
               output_wl->handle = tmp_handle;
               *port_h = output_wl->output_port;

               /* Thread to ouput from mixer to an output port. */
               if (create_prioritized_thread(&(output_wl->output_port_thread), audio_pvt_output_port_thread, output_wl, 0, "Audio_Output") != OSAL_SUCCESS) {
                  result = ISMD_ERROR_OPERATION_FAILED;
                  AUDIO_ERROR("Could not create output port feeder thread!", result, audio_devh[AUDIO_DEBUG_APM]);
               }

               wl->output_count ++;
            }
            audio_output_unlock(output_wl);
         }
         audio_processor_unlock(wl);
      }
      else {
         AUDIO_ERROR("audio_processor_lock_and_get_wl failed!.", result, audio_devh[AUDIO_DEBUG_APM]);
      }


      /*Clean up code if we failed*/
      if(result != ISMD_SUCCESS) {

         if((wl != NULL) && (output_wl != NULL)) {
            ismd_queue_disconnect_output(output_wl->psm_output_queue);
            ismd_queue_free(output_wl->psm_output_queue);
            ismd_event_free(output_wl->queue_data_avail_event);
            if(ISMD_EVENT_HANDLE_INVALID != port_config.event){
               ismd_event_free(port_config.event);
            }
            ismd_port_free(output_wl->output_port);

         }

         *output_h = AUDIO_INVALID_HANDLE;
         *port_h = ISMD_PORT_HANDLE_INVALID;
      }
   }
   else {
      AUDIO_ERROR("invalid output_config supplied!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_add_phys_output(ismd_audio_processor_t processor_h,
                              int hw_id,
                              ismd_audio_output_config_t config,
                              ismd_audio_output_t *output_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_output_t handle = AUDIO_INVALID_HANDLE;
   ismd_audio_processor_context_t *wl = NULL;
   ismd_audio_output_wl_t *output_wl = NULL;
   bool is_passthrough = false;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   *output_h = AUDIO_INVALID_HANDLE;

   /* NOTE: If handles given to outputs change from 0 to AUDIO_MAX_OUTPUTS, this will break DSP stages that rely on the
      handles to index into context specific information. (ex. audio_quality)*/

   /* Validate the hardware ID parameter */
   if((result = audio_pvt_output_validate_config(&(config), true, hw_id)) == ISMD_SUCCESS) {

      /*Get processor workload.*/
      if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS){

         /*Query Processor for an available output instance */
         for(handle =0; handle < AUDIO_MAX_OUTPUTS; handle++) {

            output_wl = &(wl->outputs[handle]);
            audio_pvt_output_lock(output_wl);

            if(!output_wl ->in_use) {

               //Need to first setup these variables before calling output_render_setup, dont move this.
               output_wl->processor_id = wl->handle_id;
               output_wl->processor_wl = wl;
               output_wl->hw_id = hw_id;

               if(config.out_mode ==  ISMD_AUDIO_OUTPUT_PASSTHROUGH) {
                  is_passthrough = true;
               }

               if((result = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, 5,"psm output queue", 16, 0, &(output_wl->psm_output_queue)) != ISMD_SUCCESS)){
                  AUDIO_ERROR("Error alloc tcam output queue in add_output_port!", result, audio_devh[AUDIO_DEBUG_APM]);
               }           
               //Try to open the render to see if interface is available.
               else if((result = audio_render_open(&(output_wl->render_h), output_wl->hw_id, output_wl->psm_output_queue, AUDIO_RENDER_BUFFER_MODE_LINKED_LIST, output_wl->processor_id)) != ISMD_SUCCESS){
                  AUDIO_ERROR("Error in render_open, in add_phys_output.\n",  result, audio_devh[AUDIO_DEBUG_APM]);
               }

               else{

                  /*Populate output handle, mark output in use*/
                  *output_h = handle;
                  output_wl->handle = handle;
                  output_wl->in_use = true;
                  output_wl->processor_id = wl->handle_id;
                  output_wl->processor_wl = wl;
                  output_wl->is_sw_output = false;
                  output_wl->output_mode = config.out_mode;
                  output_wl->sample_rate = config.sample_rate;
                  output_wl->sample_size = config.sample_size;
                  output_wl->channel_config = config.ch_config;
                  output_wl->sample_size_actual = config.sample_size;

                  //If we have outputs already attached and the post ATC pipe is already started
                  //make sure to reconfigure the pipe with this new output. 
                  if(wl->psm_pa_pipe.pipe_configured){
                     output_wl->reconfig_post_atc_pipe = true;
                  }

                  if(wl->psm_pass_pipe.pipe_configured) {
                     output_wl->reconfig_pass_pipe = true;
                  }

                  //Set defaults for the encoders if the mode is specified. 
                  if(output_wl->output_mode == ISMD_AUDIO_OUTPUT_ENCODED_DTS){
                     audio_dts_enc_set_default_params(&output_wl->processor_wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder);
                     output_wl->encode_params_set = true;
                  }
                  if(output_wl->output_mode == ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL){
                     audio_ac3_enc_set_default_params(&output_wl->processor_wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder); 
                     output_wl->encode_params_set = true;
                  }
                  if(output_wl->output_mode == ISMD_AUDIO_OUTPUT_ENCODED_AAC){
                     audio_aac_enc_set_default_params(&output_wl->processor_wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder); 
                     output_wl->encode_params_set = true;
                  }

                  if(output_wl->channel_config == ISMD_AUDIO_5_1){
                     output_wl->channel_count = 6;
                  }
                  else if(output_wl->channel_config == ISMD_AUDIO_7_1){
                     output_wl->channel_count = 8;
                  }
                  else {
                     output_wl->channel_count = 2;
                  }

                  /*If this is HDMI need to open a thread that waits to recover if it dies. */
                  if(output_wl->hw_id == GEN3_HW_OUTPUT_HDMI) {
                     if (create_prioritized_thread(&(output_wl->render_recovery_thread), audio_pvt_output_render_recovery_thread, output_wl, 0, "Audio_Recovery") != OSAL_SUCCESS) {
                        result = ISMD_ERROR_OPERATION_FAILED;
                        AUDIO_ERROR("Could not create render recovery thread!", result, audio_devh[AUDIO_DEBUG_APM]);
                     }
                  }

                  wl->output_count ++;
               }

               handle = AUDIO_MAX_OUTPUTS;

            }

            audio_output_unlock(output_wl);
         }

         if(*output_h == AUDIO_INVALID_HANDLE){

            result = ISMD_ERROR_NO_RESOURCES;
            AUDIO_ERROR("Error getting output from processor!.", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         audio_processor_unlock(wl);

      }else {
         AUDIO_ERROR("Error getting proc workload in add_phys_output.", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /*Clean up if we failed, dont execute this if we never obtained the handle.*/
      if(result != ISMD_SUCCESS){

         if((wl != NULL) && (output_wl != NULL)){
            audio_render_close(output_wl->render_h);
            ismd_queue_free(output_wl->psm_output_queue);
            audio_output_init_wl(output_wl);
         }

         *output_h = AUDIO_INVALID_HANDLE;
      }
   }
   else {
      result = ISMD_ERROR_INVALID_PARAMETER;
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_remove_output(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_output_wl_t *output_wl = NULL;
   bool reconfig_pass_pipe = false;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

      /** Stop the render recovery thread */
      audio_output_unlock(output_wl);
      result = audio_pvt_stop_recovery_thread(output_wl);
      audio_pvt_output_lock(output_wl);

      if(output_wl->output_mode == ISMD_AUDIO_OUTPUT_PASSTHROUGH){
         reconfig_pass_pipe = true;
      }

      if((result = audio_pvt_remove_output( output_wl )) != ISMD_SUCCESS){
         AUDIO_ERROR("audio_pvt_remove_output failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /*Want to reconfig the backend after the output is unlocked, but in the processor lock.*/
      if(result == ISMD_SUCCESS) {
         result = audio_processor_post_atc_pipe_reconfig(output_wl->processor_wl, true, reconfig_pass_pipe);
      }
      audio_output_api_unlock(output_wl);
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid output handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
audio_output_disable(ismd_audio_output_wl_t *output_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(output_wl->enabled) {

      //Disable the PSM queue if the back end pipe is setup. Try both PCM and passthrough pipes. 
      if(output_wl->processor_wl->psm_pa_pipe.pipe_configured && (output_wl->output_mode != ISMD_AUDIO_OUTPUT_PASSTHROUGH)){
         if((result = audio_psm_output_queue_disable(output_wl->processor_wl->psm_pa_pipe.pipe_h, output_wl->psm_output_queue)) != ISMD_SUCCESS) {
            AUDIO_ERROR("audio_psm_output_queue_disable failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if(output_wl->processor_wl->psm_pass_pipe.pipe_configured && (output_wl->output_mode == ISMD_AUDIO_OUTPUT_PASSTHROUGH)){
         if((result = audio_psm_output_queue_disable(output_wl->processor_wl->psm_pass_pipe.pipe_h, output_wl->psm_output_queue)) != ISMD_SUCCESS) {
            AUDIO_ERROR("audio_psm_output_queue_disable on passthrough pipe failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      } 
      
      if(result == ISMD_SUCCESS) {

         if(output_wl->hw_id == GEN3_HW_OUTPUT_HDMI){
            if((result = audio_render_set_state(output_wl->render_h, ISMD_DEV_STATE_STOP)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_render_set_state failed in ismd_audio_output_disable!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
         output_wl->enabled = false;
         output_wl->psm_output_queue_disabled = true;
      }
   }

   return result;
}


ismd_result_t
ismd_audio_output_disable(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      result = audio_output_disable(output_wl);

      audio_output_api_unlock(output_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or output handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
audio_output_enable( ismd_audio_output_wl_t *output_wl)
{
   /* NOTE: When calling this function you MUST have the processor context LOCKED! */
   
   ismd_result_t result = ISMD_SUCCESS;

   if(!output_wl->enabled){ 

      if((result = audio_pvt_output_validate_final_output_setup(output_wl)) == ISMD_SUCCESS) {

         if(!output_wl->is_sw_output) {

            //If this hasnt previously been disabled by an explicit call, then dont set the render state to pause. 
            if(output_wl->psm_output_queue_disabled){ 
               if((result = audio_render_set_state(output_wl->render_h, ISMD_DEV_STATE_PAUSE)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_render_set_state failed in ismd_audio_output_enable!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
            }

            if(result == ISMD_SUCCESS){
               /*Set all the config options to the render and start it up*/
               if((result = audio_pvt_output_config_render_and_start(output_wl)) != ISMD_SUCCESS){
                  AUDIO_ERROR("output_config_render_and_start failed!",  result, audio_devh[AUDIO_DEBUG_APM]);
               }   
            }
         }

         if(result == ISMD_SUCCESS) {

            if(output_wl->psm_output_queue_disabled ) {

               //Try to enable either PCM or passthrough pipe. 
               if((output_wl->processor_wl->psm_pa_pipe.pipe_h != AUDIO_INVALID_HANDLE)) {
                  result = audio_psm_output_queue_enable(output_wl->processor_wl->psm_pa_pipe.pipe_h, output_wl->psm_output_queue);
               }

               if(((result == ISMD_SUCCESS) || (result == ISMD_ERROR_NOT_FOUND))  && 
                  (output_wl->processor_wl->psm_pass_pipe.pipe_h != AUDIO_INVALID_HANDLE)){
                  
                  result = audio_psm_output_queue_enable(output_wl->processor_wl->psm_pass_pipe.pipe_h, output_wl->psm_output_queue);
               }

               //This error from the PSM we want to ignore in some cases because of the pipe not being added yet.
               if(result == ISMD_ERROR_NOT_FOUND){
                  result = ISMD_SUCCESS;
               }
            }

            if(result != ISMD_SUCCESS){
               AUDIO_ERROR("Could not enable the PSM output queue feeding the render! Output will not have audio!", ISMD_ERROR_OPERATION_FAILED, audio_devh[AUDIO_DEBUG_RENDER]);
            }
            else {

               output_wl->enabled = true;

               //If we need to rebuild the pipe, call into the processor for a rebuild.
               if(output_wl->reconfig_post_atc_pipe) { 

                  result = audio_processor_post_atc_pipe_reconfig(output_wl->processor_wl, true, output_wl->reconfig_pass_pipe);
                  output_wl->reconfig_post_atc_pipe = false;
                  output_wl->reconfig_pass_pipe = false;                
               }

               //Need to tell ATC to resync since we have disabled the PSM queue.
               if(ismd_event_strobe(atc_render_resync_event) != ISMD_SUCCESS) {
                  AUDIO_ERROR("ismd_event_strobe FAILED!", ISMD_ERROR_OPERATION_FAILED, audio_devh[AUDIO_DEBUG_RENDER]);
               }
            }
         }            
      }

      //If we have an error flag that output still disabled. 
      if(result != ISMD_SUCCESS) {
         output_wl->enabled = false;
      }

      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
         SVEN_MODULE_EVENT_AUD_IO_APM_RENDER_SETUP,
         (unsigned int) output_wl->hw_id,
         (unsigned int) output_wl->render_format,
         (unsigned int) output_wl->channel_config,
         (unsigned int) output_wl->sample_size,
         (unsigned int) output_wl->sample_rate,
         (unsigned int) RENDER_PREFILL_CHUNK * AUDIO_CORE_GET_CHUNK_PERIOD(output_wl));
   }

   return result;
}

ismd_result_t
ismd_audio_output_enable(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;
   unsigned int master_audio_clk_freq = 0;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /*Need to lock the processor since output_enable modifies the processor context. */
   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {
      
      master_audio_clk_freq = output_wl->processor_wl->master_clk_freq_hz;
      
      if(master_audio_clk_freq != 0){      
         result = audio_pvt_set_sadiv_value(output_wl, master_audio_clk_freq);
      }
      /** Adding extra check for non passthrough mode to avoid jittery audio in non-passthrough output mute-disable-enable-unmute sequence*/
	  if(!output_wl->is_muted || (output_wl->output_mode != ISMD_AUDIO_OUTPUT_PASSTHROUGH)){
         result = audio_output_enable(output_wl);
	  }
      
      audio_output_api_unlock(output_wl);
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or output handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
 
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_output_set_downmix_mode(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h, 
                              ismd_audio_downmix_mode_t dmix_mode)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      if(!output_wl->enabled) {
      
         /** If we have outputs already attached and the post ATC pipe is already started
         make sure to reconfigure the pipe on a new downmix setting */
         if(dmix_mode != output_wl->dmix_mode && output_wl->processor_wl->psm_pa_pipe.pipe_configured){
            output_wl->reconfig_post_atc_pipe = true;
         }       

         switch(dmix_mode) {
            case ISMD_AUDIO_DOWNMIX_DEFAULT:
            case ISMD_AUDIO_DOWNMIX_1_0:
            case ISMD_AUDIO_DOWNMIX_1_0_LFE:
            case ISMD_AUDIO_DOWNMIX_2_0:
            case ISMD_AUDIO_DOWNMIX_2_0_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_LFE:
            case ISMD_AUDIO_DOWNMIX_2_1:
            case ISMD_AUDIO_DOWNMIX_2_1_LFE:
            case ISMD_AUDIO_DOWNMIX_2_0_LTRT:
            case ISMD_AUDIO_DOWNMIX_2_0_LTRT_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_DOLBY_PRO_LOGIC_II:
            case ISMD_AUDIO_DOWNMIX_2_0_DOLBY_PRO_LOGIC_II_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_DVB_AAC:
            case ISMD_AUDIO_DOWNMIX_3_0:
            case ISMD_AUDIO_DOWNMIX_3_0_LFE:
            case ISMD_AUDIO_DOWNMIX_3_1:
            case ISMD_AUDIO_DOWNMIX_3_1_LFE:
            case ISMD_AUDIO_DOWNMIX_2_2:
            case ISMD_AUDIO_DOWNMIX_2_2_LFE:
            case ISMD_AUDIO_DOWNMIX_3_2:
            case ISMD_AUDIO_DOWNMIX_3_2_LFE:
            case ISMD_AUDIO_DOWNMIX_3_0_1:
            case ISMD_AUDIO_DOWNMIX_3_0_1_LFE:
            case ISMD_AUDIO_DOWNMIX_2_2_1:
            case ISMD_AUDIO_DOWNMIX_2_2_1_LFE:
            case ISMD_AUDIO_DOWNMIX_3_2_1:
            case ISMD_AUDIO_DOWNMIX_3_2_1_LFE:   
            case ISMD_AUDIO_DOWNMIX_3_0_2:
            case ISMD_AUDIO_DOWNMIX_3_0_2_LFE:
            case ISMD_AUDIO_DOWNMIX_2_2_2:
            case ISMD_AUDIO_DOWNMIX_2_2_2_LFE:
            case ISMD_AUDIO_DOWNMIX_3_2_2:
            case ISMD_AUDIO_DOWNMIX_3_2_2_LFE:
               output_wl->dmix_mode = dmix_mode;
               break;
            case ISMD_AUDIO_DOWNMIX_INVALID:
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               break;
         }
      }
      else {
         AUDIO_ERROR("Output is enabled, please disable before trying to set downmix mode.", ISMD_ERROR_INVALID_REQUEST, audio_devh[AUDIO_DEBUG_APM]);
         result = ISMD_ERROR_INVALID_REQUEST;
      }
      
      audio_output_api_unlock(output_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or output handle.", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t 
ismd_audio_output_get_port(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_port_handle_t *port_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_output_wl_t *output_wl = NULL;

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      if(output_wl->is_sw_output) {

         *port_h = output_wl->output_port;
      }     
      else {
         result = ISMD_ERROR_INVALID_REQUEST;
      }
      
      audio_output_api_unlock(output_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or output handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}


ismd_result_t
ismd_audio_output_get_channel_config(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_channel_config_t *ch_config)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      *ch_config = output_wl->channel_config;

      audio_output_api_unlock(output_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or output handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}


ismd_result_t
ismd_audio_output_get_sample_size(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              int *sample_size)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      *sample_size = output_wl->sample_size_actual;

      audio_output_api_unlock(output_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or output handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}


ismd_result_t
ismd_audio_output_get_sample_rate(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              int *sample_rate)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      *sample_rate = output_wl->sample_rate;

      audio_output_api_unlock(output_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or output handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}


ismd_result_t
ismd_audio_output_get_mode(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_output_mode_t  *out_mode)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      *out_mode = output_wl->output_mode;

      audio_output_api_unlock(output_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or output handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}

ismd_result_t
ismd_audio_output_get_delay(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              int *delay_ms)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      *delay_ms = output_wl->delay_ms;

      audio_output_api_unlock(output_wl);

   }
   else {
      AUDIO_ERROR("Invalid processor or output handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}

ismd_result_t
ismd_audio_output_get_external_bit_clock_div(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              int *div_val)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      *div_val = output_wl->bit_clk_div_val;

      audio_output_api_unlock(output_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or output handle!!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}

ismd_result_t
ismd_audio_output_get_handle_by_hw_id(ismd_audio_processor_t processor_h,
                              int hw_id,
                              ismd_audio_output_t *output_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_processor_context_t *wl = NULL;
   int loop = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /*Validate the hardware ID parameter*/
   if(audio_pvt_output_valid_hw_id(hw_id)) {

      /*Get processor workload.*/
      if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS){

         result = ISMD_ERROR_OPERATION_FAILED;
         for(loop = 0; loop < AUDIO_MAX_OUTPUTS; loop++){

            if(hw_id == wl->outputs[loop].hw_id){

               *output_h = loop;
               result = ISMD_SUCCESS;
               loop = AUDIO_MAX_OUTPUTS;
            }
         }
         audio_processor_unlock(wl);
      }
      else {
         AUDIO_ERROR("audio_processor_lock_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else{
      result = ISMD_ERROR_INVALID_PARAMETER;
      AUDIO_ERROR("audio_pvt_output_valid_hw_id failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_output_set_channel_config(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_channel_config_t ch_config)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if(audio_pvt_output_valid_channel_config(ch_config)){

      if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

         if(!output_wl->enabled){

            //Check to see if a reconfig is in needed.
            if((ch_config != output_wl->channel_config) && output_wl->processor_wl->psm_pa_pipe.pipe_configured){
               output_wl->reconfig_post_atc_pipe = true;
            }
            
            output_wl->channel_config = ch_config;
            output_wl->channel_count = audio_pvt_output_ch_config_to_count(output_wl->channel_config );
          }
          else {
            AUDIO_ERROR("Output is enabled, please disable before trying to set channel config.", ISMD_ERROR_INVALID_REQUEST, audio_devh[AUDIO_DEBUG_APM]);
            result = ISMD_ERROR_INVALID_REQUEST;
          }

         audio_output_api_unlock(output_wl);
      }
      else{
         AUDIO_ERROR("Invalid processor or output handle!!",result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      result = ISMD_ERROR_INVALID_PARAMETER;
      AUDIO_ERROR("Invalid output channel config specified. ",result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


ismd_result_t
ismd_audio_output_set_sample_size(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              int sample_size)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

      if(audio_pvt_output_valid_sample_size(sample_size)){

         if(!output_wl->enabled) {

            //Check to see if a reconfig is in needed.
            if((sample_size != output_wl->sample_size_actual) && output_wl->processor_wl->psm_pa_pipe.pipe_configured){
               output_wl->reconfig_post_atc_pipe = true;
            }
            
            output_wl->sample_size_actual = sample_size;
            output_wl->sample_size = sample_size;          
         }
         else {
            AUDIO_ERROR("Output is enabled, please disable before trying to set sample size.", ISMD_ERROR_INVALID_REQUEST, audio_devh[AUDIO_DEBUG_APM]);
            result = ISMD_ERROR_INVALID_REQUEST;
          }
      }
      else{
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid output sample size!",result, audio_devh[AUDIO_DEBUG_APM]);
      }
      audio_output_api_unlock(output_wl);
   }
   else{
      AUDIO_ERROR("Invalid processor or output handle!",result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_output_set_sample_rate(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              int sample_rate)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      if(!output_wl->enabled){

         //Check to see if a reconfig is in needed.
         if((sample_rate != output_wl->sample_rate) && output_wl->processor_wl->psm_pa_pipe.pipe_configured){
            output_wl->reconfig_post_atc_pipe = true;
         }
         
         if((output_wl->output_mode == ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL) && (sample_rate != 48000)){
            result = ISMD_ERROR_INVALID_REQUEST;
            AUDIO_ERROR("DD encoded output only supports 48kHz output!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else {
            output_wl->sample_rate = sample_rate;
         }
      }
      else {
         AUDIO_ERROR("Output is enabled, please disable before trying to set sample rate.", ISMD_ERROR_INVALID_REQUEST, audio_devh[AUDIO_DEBUG_APM]);
         result = ISMD_ERROR_INVALID_REQUEST;
       }
      audio_output_api_unlock(output_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or output handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_output_set_mode(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_output_mode_t  out_mode)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_output_wl_t *output_wl = NULL;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   // TODO: Revisit/rewrite this function!

   if(audio_pvt_output_valid_output_mode(out_mode)){

      if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

         if(!output_wl->enabled) {

            //Check to see if a reconfig is in needed.
            if((out_mode != output_wl->output_mode) && output_wl->processor_wl->psm_pa_pipe.pipe_configured){
               output_wl->reconfig_post_atc_pipe = true;
            }

            wl = output_wl->processor_wl;

            if(output_wl->output_mode != out_mode){

               /* Disconnect the queue from the current PSM pipe. When its 
                  rebuilt, it will get connected again.*/
               ismd_queue_disconnect_input(output_wl->psm_output_queue);

               /*First figure out what the previous mode was and clean up*/
               switch(output_wl->output_mode){

                  case ISMD_AUDIO_OUTPUT_PCM:
                     break;

                  case ISMD_AUDIO_OUTPUT_PASSTHROUGH:
                     /*If current mode is passthrough we need to decrement the count on the processor*/
                     wl->passthrough_output_count--;
                     output_wl->reconfig_pass_pipe = true;

                     break;

                  case ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL:
                  case ISMD_AUDIO_OUTPUT_ENCODED_DTS:
                  case ISMD_AUDIO_OUTPUT_ENCODED_AAC:	
                     output_wl->encode_params_set = false;
                     break;

                  case ISMD_AUDIO_OUTPUT_INVALID:

                  default:
                     result = ISMD_ERROR_INVALID_PARAMETER;
                     break;
               }

               if(result == ISMD_SUCCESS) {

                  /*Now reconfigure the output with the new mode*/
                  switch(out_mode){

                     case ISMD_AUDIO_OUTPUT_PCM:
                        output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_PCM;
                        break;

                     case ISMD_AUDIO_OUTPUT_PASSTHROUGH:
                        output_wl->reconfig_pass_pipe = true;
                        break;

                     case ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL:
                        
                        output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_DD;

                        if(!output_wl->encode_params_set){
                           //Set encoder default params, since we know this is going to require the encoder. 
                           audio_ac3_enc_set_default_params(&output_wl->processor_wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder); 
                           output_wl->encode_params_set = true;
                        }
                        break;
                        
                     case ISMD_AUDIO_OUTPUT_ENCODED_DTS:
                        
                        output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_DTS;

                        if(!output_wl->encode_params_set){
                           //Set encoder default params, since we know this is going to require the encoder. 
                           audio_dts_enc_set_default_params(&output_wl->processor_wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder); 
                           output_wl->encode_params_set = true;
                        }
                        break;

                     case ISMD_AUDIO_OUTPUT_ENCODED_AAC:
                        
                        output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_AAC;

                        if(!output_wl->encode_params_set){
                           //Set encoder default params, since we know this is going to require the encoder. 
                           audio_aac_enc_set_default_params(&output_wl->processor_wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder); 
                           output_wl->encode_params_set = true;
                        }
                        break;

                     case ISMD_AUDIO_OUTPUT_INVALID:

                     default:
                        result = ISMD_ERROR_INVALID_PARAMETER;
                        break;
                  }

                  output_wl->output_mode = out_mode;

               }
            }
            else {
               result = ISMD_SUCCESS;
               AUDIO_INFO(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM], "output mode is the same: %d", out_mode);
            }
         }
         else {
            AUDIO_ERROR("Output is enabled, please disable before trying to set output mode.", ISMD_ERROR_INVALID_REQUEST, audio_devh[AUDIO_DEBUG_APM]);
            result = ISMD_ERROR_INVALID_REQUEST;
         }
         audio_output_api_unlock(output_wl);
      }
      else {
         AUDIO_ERROR("Invalid processor or output handle!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      result = ISMD_ERROR_INVALID_PARAMETER;
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_output_set_delay(ismd_audio_processor_t processor_h,
                                          ismd_audio_output_t output_h,
                                          int delay_ms)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      if(output_wl->output_mode == ISMD_AUDIO_OUTPUT_PASSTHROUGH){
         result = audio_pvt_output_set_delay(&(output_wl->processor_wl->psm_pass_pipe), output_wl->handle, delay_ms);
      }
      else if ((output_wl->output_mode == ISMD_AUDIO_OUTPUT_PCM) 
               || (output_wl->output_mode == ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL) 
               || (output_wl->output_mode == ISMD_AUDIO_OUTPUT_ENCODED_DTS)
               || (output_wl->output_mode == ISMD_AUDIO_OUTPUT_ENCODED_AAC)) {
         result = audio_pvt_output_set_delay(&(output_wl->processor_wl->psm_pa_pipe), output_wl->handle, delay_ms);
      }
      else {
         result = ISMD_ERROR_INVALID_PARAMETER;
      }

      //Keep track of current per output delay.
      if(result == ISMD_SUCCESS) {
         output_wl->delay_ms = delay_ms;
      }
      
      audio_output_api_unlock(output_wl);
   }
   else {
      AUDIO_ERROR("Invalid processor or output handle!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}

ismd_result_t
 ismd_audio_output_set_port_buffer_size(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              unsigned int buffer_size)
{
   ismd_result_t result;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

      // TODO: Implement me
      result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

      //Avoid compliler warnings.
      (void) buffer_size;

      audio_output_api_unlock(output_wl);

   }
   else{

      AUDIO_ERROR("output_validate_and_get_wl failed!",result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
ismd_audio_output_set_external_bit_clock_div(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              int div_val)
{
   ismd_result_t result;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

 if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

      if(!output_wl->enabled) {
         output_wl->bit_clk_div_val = div_val;
      }
      else {
         AUDIO_ERROR("Output is enabled, please disable before trying to set clock divider.", ISMD_ERROR_INVALID_REQUEST, audio_devh[AUDIO_DEBUG_APM]);
         result = ISMD_ERROR_INVALID_REQUEST;
      }
      audio_output_api_unlock(output_wl);
   }
   else{
      AUDIO_ERROR("Invalid processor or output handle!",result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


ismd_result_t
 ismd_audio_output_set_encode_params(ismd_audio_processor_t processor_h,
                              int param_type,
                              ismd_audio_decoder_param_t *param_value )
{
   ismd_result_t result;
   ismd_audio_processor_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS){

      if(!wl->psm_pa_pipe.pipe_configured && param_value!=NULL) {

         switch((ismd_audio_encode_format_t)wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder.host.codec.algo) {

            case ISMD_AUDIO_ENCODE_FMT_AC3:

               //If the white box testing mode is enabled flag this on the processor
               if((param_type == ISMD_AUDIO_AC3_ENC_TESTMODEON) && (*(int *) param_value == 1)) {
                  OS_PRINT("\nDDCO WHITE BOX TEST MODE SET!\n\n");
                  wl->psm_pa_pipe.ddco_test_mode_en = true;
               }
               
               if((result = audio_ac3_enc_set_param(&(wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_ac3_enc_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
               break;
               
            case ISMD_AUDIO_ENCODE_FMT_DTS:
               if((result = audio_dts_enc_set_param(&(wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_dts_enc_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
               break;

            case ISMD_AUDIO_ENCODE_FMT_AAC:
               if((result = audio_aac_enc_set_param(&(wl->psm_pa_pipe.stages[ENCODE_STAGE].params.decoder), param_type, param_value)) != ISMD_SUCCESS) {
                  AUDIO_ERROR("audio_aac_enc_set_decode_param failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
               break;
			   
            default:
               AUDIO_ERROR("An output with an encoded mode has not been added. Please add one before calling this function.", result, audio_devh[AUDIO_DEBUG_APM]);
               result = ISMD_ERROR_OPERATION_FAILED;
               break;
         }
      }
      else {
         AUDIO_ERROR("Encoder already started, this function call requires the outputs to be disabled.", result, audio_devh[AUDIO_DEBUG_APM]);
         result = ISMD_ERROR_OPERATION_FAILED;
      }

      audio_processor_unlock(wl);
   }
   else{

      AUDIO_ERROR("audio_processor_lock_and_get_wl failed!",result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
ismd_audio_output_set_spdif_channel_status(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_spdif_channel_status_t *channel_status )
{
   ismd_result_t result;
   ismd_audio_iec60958_channel_status_t iec60958_channel_status;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if (channel_status != NULL) {
      iec60958_channel_status.category_code = channel_status->cat_code;
      // iec60958 copyright 1=no copyright, 0=with copyright
      iec60958_channel_status.copyright = (channel_status->copyright) ? 0x0 : 0x1;
      iec60958_channel_status.gen_status = channel_status->gen_status;
      iec60958_channel_status.pcm_audio_mode = 0;
      result = ismd_audio_output_set_iec60958_channel_status(processor_h, 
         output_h, 
         &iec60958_channel_status);
   }
   else {
      result = ISMD_ERROR_NULL_POINTER;
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}

ismd_result_t
ismd_audio_output_set_iec60958_channel_status(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_iec60958_channel_status_t *channel_status )
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

 if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){
   
      result = audio_render_iec60958_set_channel_status(output_wl->render_h, *channel_status);

      output_wl->ch_status = *channel_status;

      audio_output_api_unlock(output_wl);
   }
   else{
      AUDIO_ERROR("Invalid processor or output handle!!",result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


ismd_result_t 
ismd_audio_output_specialized_processing_enable(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h, 
                              ismd_audio_specialized_processing_t processing_type)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){
      if(!output_wl->enabled) {
         
         switch(processing_type){
            case ISMD_AUDIO_SPECIALIZED_PROCESSING_SRS:
               result = audio_pvt_srs_get_context(output_wl);              
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               break;
         }
      }
      else {
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Output must be disabled to enabled sepcialized processing!",result, audio_devh[AUDIO_DEBUG_APM]);
      }
      audio_output_api_unlock(output_wl);
   }
   else{
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or output handle!",result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;   
}


ismd_result_t
ismd_audio_output_specialized_processing_disable(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_specialized_processing_t processing_type)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){
      if(!output_wl->enabled) {
         switch(processing_type){
            case ISMD_AUDIO_SPECIALIZED_PROCESSING_SRS:
               result = audio_pvt_srs_free_context(output_wl);
               break;
            default:
               result = ISMD_ERROR_INVALID_HANDLE;
         }
      }
      else {
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Output must be disabled to disable sepcialized processing!",result, audio_devh[AUDIO_DEBUG_APM]);
      }
      audio_output_api_unlock(output_wl);
   }

   else{
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or output handle!",result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result; 
}


ismd_result_t
ismd_audio_output_specialized_processing_set_params(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h, 
                              ismd_audio_specialized_processing_t processing_type,
                              ismd_audio_specialized_processing_params_t params)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL; 
	
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){   
   
      switch(processing_type){
         
         case ISMD_AUDIO_SPECIALIZED_PROCESSING_SRS:
            result = audio_pvt_srs_set_params(output_wl, &params.srs);
            break;

         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
      }  
      audio_output_api_unlock(output_wl);
   }
   else{
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or output handle!",result, audio_devh[AUDIO_DEBUG_APM]);
   }
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;   
}



ismd_result_t
ismd_audio_output_specialized_processing_get_params(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h, 
                              ismd_audio_specialized_processing_t processing_type,
                              ismd_audio_specialized_processing_params_t *params)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if((result = audio_output_api_lock(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){
      switch(processing_type){

         case ISMD_AUDIO_SPECIALIZED_PROCESSING_SRS:
            result = audio_pvt_srs_get_params(output_wl, &params->srs);
            break;
         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
      }
      audio_output_api_unlock(output_wl);
   }
   else{
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid processor or output handle!",result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;   
}

/*********************************************************************************************/
/* APM common input functions*/
/*********************************************************************************************/

void
audio_output_init_wl(ismd_audio_output_wl_t *output_wl)
{
   output_wl->processor_id = AUDIO_INVALID_HANDLE;
   output_wl->in_use = false;
   output_wl->is_muted = false;
   output_wl->handle = AUDIO_INVALID_HANDLE;
   output_wl->enabled = false;
   output_wl->encode_params_set = false;
   output_wl->hw_id = AUDIO_INVALID_HANDLE;
   output_wl->is_sw_output= false;
   output_wl->start_to_close = false;
   output_wl->render_h = AUDIO_INVALID_HANDLE;
   output_wl->psm_output_queue      = ISMD_QUEUE_HANDLE_INVALID;
   output_wl->queue_data_avail_event = ISMD_EVENT_HANDLE_INVALID;
   output_wl->out_port_full_event    = ISMD_EVENT_HANDLE_INVALID;
   output_wl->output_port            = ISMD_PORT_HANDLE_INVALID;
   output_wl->sample_size = 0;
   output_wl->sample_size_actual = 0;
   output_wl->channel_count = 0;
   output_wl->channel_config = 0;
   output_wl->bit_clk_div_val = 0;
   output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_PCM;
   output_wl->ch_status.category_code = 0;   // SPDIF_CATEGORY_GENERAL
   output_wl->ch_status.copyright = 0x01;   // no copyright
   output_wl->ch_status.gen_status= 0;
   output_wl->ch_status.pcm_audio_mode = 0;  // non-preemphasis
   output_wl->reconfig_post_atc_pipe = false;
   output_wl->psm_output_queue_disabled = false;
   output_wl->reconfig_pass_pipe = false;
   output_wl->dmix_mode = ISMD_AUDIO_DOWNMIX_INVALID;
   output_wl->curr_gain = 0;
   output_wl->delay_ms = 0;
   output_wl->srs_context_info = AUDIO_INVALID_HANDLE;
}

ismd_result_t
audio_remove_output_no_reconfig(ismd_audio_output_wl_t *output_wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /** Stop the render recovery thread */
   result = audio_pvt_stop_recovery_thread(output_wl);

   if((result = audio_pvt_remove_output( output_wl )) != ISMD_SUCCESS){
      AUDIO_ERROR("audio_pvt_remove_output failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
audio_output_suspend(ismd_audio_output_wl_t *output_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   audio_pvt_output_lock(output_wl);
   
   if(!output_wl->is_sw_output){
      if(ISMD_SUCCESS != (result = audio_render_set_state(output_wl->render_h,ISMD_DEV_STATE_STOP))){
      
      }
   }
   else {   
      if(ISMD_SUCCESS != ismd_event_strobe(output_wl->queue_data_avail_event)){
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed on data_avail_event in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);
      }
      else if(ISMD_SUCCESS != ismd_event_strobe(output_wl->out_port_full_event)){
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed on out_port_full_event in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);
      }
      else if (ISMD_SUCCESS != (result = ismd_queue_disconnect_output(output_wl->psm_output_queue))){
        AUDIO_ERROR("ismd_queue_disconnect_output fail\n!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }   	 

   audio_output_unlock(output_wl);
   return result;
}

ismd_result_t
audio_output_resume(ismd_audio_output_wl_t *output_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_pvt_output_lock(output_wl);
   
   if(!output_wl->is_sw_output){
   
      if(ISMD_SUCCESS != (result = audio_render_resume(output_wl->render_h))){
         AUDIO_ERROR("audio_render_resume failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      if(ISMD_SUCCESS != (result = audio_pvt_output_config_render_and_start(output_wl))){
         AUDIO_ERROR("audio_render_config render and start failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {	
      if (ISMD_SUCCESS != (result = ismd_queue_connect_output(output_wl->psm_output_queue,
                                       (ismd_consumer_func_t)audio_pvt_output_queue_callback, (void *)output_wl, ISMD_QUEUE_WATERMARK_NONE))){
         AUDIO_ERROR("ismd_queue_connect_output failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   audio_output_unlock(output_wl);
   
   return result;
}
/*********************************************************************************************/


/*********************************************************************************************/
/* Private Audio Input Functions*/
/*********************************************************************************************/

/** Stop the render recovery thread for this output */
static ismd_result_t
audio_pvt_stop_recovery_thread(ismd_audio_output_wl_t *output_wl){
   ismd_result_t result = ISMD_SUCCESS;
   osal_result o_result = OSAL_SUCCESS;

   /*Kill the recovery thread. */
   if(output_wl->hw_id == GEN3_HW_OUTPUT_HDMI) {

      /* Start the shutdown. */
      output_wl->start_to_close = true;
      ismd_event_strobe(render_recovery_event);
      
      if((o_result = os_thread_wait(&(output_wl->render_recovery_thread), 1)) != OSAL_SUCCESS){
         AUDIO_ERROR("os_thread_wait failed in remove_output!",o_result, audio_devh[AUDIO_DEBUG_APM]);
         result = ISMD_ERROR_OPERATION_FAILED;
      }

      if((o_result = os_thread_destroy(&(output_wl->render_recovery_thread))) != OSAL_SUCCESS){
         AUDIO_ERROR("os_thread_destroy failed in remove_output!",o_result, audio_devh[AUDIO_DEBUG_APM]);
         result = ISMD_ERROR_OPERATION_FAILED;
      }
   }

   return result;

}

static ismd_result_t
audio_pvt_remove_output(ismd_audio_output_wl_t *output_wl)
{
   bool is_passthrough = false;
   ismd_audio_processor_context_t *wl = output_wl->processor_wl;
   ismd_result_t result = ISMD_SUCCESS;
   audio_quality_context_t *aq_pipe = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

         // TODO: REWrite this FUNCTION>>>>>>>!! TO MESSY

   if(output_wl->output_mode == ISMD_AUDIO_OUTPUT_PASSTHROUGH){
      is_passthrough = true;
   }

   if(!output_wl->in_use)
      return ISMD_ERROR_INVALID_PARAMETER;

   /*Since we are about to shutdown the render notify PSM pipe to remove the output queue*/
   if(is_passthrough && (AUDIO_INVALID_HANDLE != output_wl->processor_wl->psm_pass_pipe.pipe_h)){
      if((result = audio_psm_output_queue_remove(output_wl->processor_wl->psm_pass_pipe.pipe_h, output_wl->psm_output_queue)) != ISMD_SUCCESS) {
         AUDIO_ERROR("psm_pipe_remove_output failed for passthrough pipe!\n", result ,audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   if(!is_passthrough && (AUDIO_INVALID_HANDLE != output_wl->processor_wl->psm_pa_pipe.pipe_h)){
      if((result =audio_psm_output_queue_remove(output_wl->processor_wl->psm_pa_pipe.pipe_h, output_wl->psm_output_queue)) != ISMD_SUCCESS) {
         AUDIO_ERROR("psm_pipe_remove_output failed for post atc pipe!\n", result ,audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   /*Tear down a port differently than a phy output.*/
   if(output_wl->is_sw_output) {

      /*Kill output thread*/
      output_wl->start_to_close = true;

      if(ismd_event_strobe(output_wl->queue_data_avail_event) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed on data_avail_event in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);

      if(ismd_event_strobe(output_wl->out_port_full_event) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed on out_port_full_event in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);

      /* Wait on thread, then destroy it */
      if(os_thread_wait(&(output_wl->output_port_thread), 1) != OSAL_SUCCESS){       
         AUDIO_OSAL_ERROR("os_thread_wait failed in remove_output!",result, audio_devh[AUDIO_DEBUG_APM]);
      }

      if(os_thread_destroy(&(output_wl->output_port_thread)) != OSAL_SUCCESS){         
         AUDIO_OSAL_ERROR("os_thread_destroy failed in remove_output!",result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /*Safe to free events now*/
      if(ismd_event_free(output_wl->queue_data_avail_event) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_free failed on data_avail_event in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);

      if(ismd_event_free(output_wl->out_port_full_event) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_free failed on out_port_full_event in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);

      /*Flush and free the output port.*/
      if(ismd_port_flush(output_wl->output_port) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"port_flush failed in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);

      if(ismd_port_free(output_wl->output_port) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"port_free failed in remove_output!\n", audio_devh[AUDIO_DEBUG_APM]);

      if(ismd_queue_free(output_wl->psm_output_queue) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free failed on tcam_output_queue in remove_output\n", audio_devh[AUDIO_DEBUG_APM]);

   } else{

      if(audio_render_set_state(output_wl->render_h, ISMD_DEV_STATE_STOP) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"audio_render_set_state failed, in remove_output!",  audio_devh[AUDIO_DEBUG_APM]);

      if(audio_render_close(output_wl->render_h) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"audio_render_close failed, in remove_output!", audio_devh[AUDIO_DEBUG_APM]);

      if(ismd_queue_free(output_wl->psm_output_queue) != ISMD_SUCCESS)
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"queue_free failed on psm_output_queue in remove_output\n", audio_devh[AUDIO_DEBUG_APM]);
   }   

   /* Reinit audio quality context, dont need to commit changes since we will rebuild post ATC pipe after this function returns. */
   audio_quality_pipe_get_context(output_wl->processor_wl, output_wl->handle, &aq_pipe);
   audio_quality_pipe_init(aq_pipe);

   /*Reset variables to free up output for next use.*/
   audio_output_init_wl(output_wl);

   if(is_passthrough){
      wl->passthrough_output_count--;
   }

   wl->output_count --;

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


static bool
audio_pvt_output_valid_handle( ismd_audio_processor_t handle )
{
   bool result = false;
   if ( (handle >= 0) && (handle < AUDIO_MAX_OUTPUTS) ) {
      result = true;
   }
   else
      AUDIO_ERROR("Invalid output handle!", ISMD_ERROR_INVALID_HANDLE, audio_devh[AUDIO_DEBUG_APM]);

   return ( result );
}


ismd_result_t
audio_output_api_lock( ismd_audio_processor_t processor_h, ismd_audio_output_t output_h, ismd_audio_output_wl_t **output_wl )
{
   ismd_result_t  result = ISMD_ERROR_INVALID_HANDLE;
   ismd_audio_processor_context_t *wl = NULL;

   if(audio_processor_lock_and_get_wl(processor_h, &wl) == ISMD_SUCCESS) {

      if(audio_pvt_output_valid_handle(output_h)){

         audio_pvt_output_lock(&(wl->outputs[output_h]));

         if(!wl->outputs[output_h].in_use){
            AUDIO_ERROR("Output handle has not been allocated.", result, audio_devh[AUDIO_DEBUG_APM]);
            audio_output_unlock(&(wl->outputs[output_h]));
            audio_processor_unlock(wl);
         }
         else {
            *output_wl = &(wl->outputs[output_h]); 
            result = ISMD_SUCCESS;
         }
      }
	  else {
		audio_processor_unlock(wl);
	  }
   }

   return result;
}

ismd_result_t
audio_output_validate_and_lock_wl( ismd_audio_processor_t processor_h, ismd_audio_output_t output_h, ismd_audio_output_wl_t **output_wl )
{
   ismd_result_t  result;
   ismd_audio_processor_context_t *wl = NULL;

   if( (result = audio_processor_get_wl(processor_h, &wl)) == ISMD_SUCCESS){

      if(audio_pvt_output_valid_handle(output_h)){

         audio_pvt_output_lock(&(wl->outputs[output_h]));

         if(!wl->outputs[output_h].in_use){
            result = ISMD_ERROR_INVALID_HANDLE;
            AUDIO_ERROR("Output handle has not been allocated.", result, audio_devh[AUDIO_DEBUG_APM]);
            audio_output_unlock(&(wl->outputs[output_h]));
         }
         else {
            *output_wl = &(wl->outputs[output_h]);          
         }
      }
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
   }

   return result;
}

static bool
audio_pvt_output_valid_dmix_mode_with_ch_config(ismd_audio_channel_config_t ch_config, ismd_audio_downmix_mode_t dmix_mode)
{
   bool result = false;

   switch(ch_config) {
      
      case ISMD_AUDIO_STEREO:
      case ISMD_AUDIO_DUAL_MONO:
         
         switch(dmix_mode){
            case ISMD_AUDIO_DOWNMIX_1_0:
            case ISMD_AUDIO_DOWNMIX_1_0_LFE:
            case ISMD_AUDIO_DOWNMIX_2_0:
            case ISMD_AUDIO_DOWNMIX_2_0_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_LTRT:
            case ISMD_AUDIO_DOWNMIX_2_0_LTRT_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_DOLBY_PRO_LOGIC_II:
            case ISMD_AUDIO_DOWNMIX_2_0_DOLBY_PRO_LOGIC_II_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_DVB_AAC:
            case ISMD_AUDIO_DOWNMIX_DEFAULT:
            case ISMD_AUDIO_DOWNMIX_INVALID://Ok since this api call is not req'd.   
               result = true;
               break;
            default:
               break;
         }
         break;
         
      case ISMD_AUDIO_5_1:
         
         switch(dmix_mode){
            case ISMD_AUDIO_DOWNMIX_1_0:
            case ISMD_AUDIO_DOWNMIX_1_0_LFE:
            case ISMD_AUDIO_DOWNMIX_2_0:
            case ISMD_AUDIO_DOWNMIX_2_0_NO_SCALE:               
            case ISMD_AUDIO_DOWNMIX_2_0_LTRT:
            case ISMD_AUDIO_DOWNMIX_2_0_LTRT_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_DOLBY_PRO_LOGIC_II:
            case ISMD_AUDIO_DOWNMIX_2_0_DOLBY_PRO_LOGIC_II_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_LFE:
            case ISMD_AUDIO_DOWNMIX_2_1:
            case ISMD_AUDIO_DOWNMIX_2_1_LFE:
            case ISMD_AUDIO_DOWNMIX_3_0:
            case ISMD_AUDIO_DOWNMIX_3_0_LFE:
            case ISMD_AUDIO_DOWNMIX_3_1:
            case ISMD_AUDIO_DOWNMIX_3_1_LFE:
            case ISMD_AUDIO_DOWNMIX_2_2:
            case ISMD_AUDIO_DOWNMIX_2_2_LFE:
            case ISMD_AUDIO_DOWNMIX_3_2:
            case ISMD_AUDIO_DOWNMIX_3_2_LFE:
            case ISMD_AUDIO_DOWNMIX_3_0_1:
            case ISMD_AUDIO_DOWNMIX_3_0_1_LFE:
            case ISMD_AUDIO_DOWNMIX_2_2_1:
            case ISMD_AUDIO_DOWNMIX_2_2_1_LFE:
            case ISMD_AUDIO_DOWNMIX_3_2_1:   
            case ISMD_AUDIO_DOWNMIX_3_0_2:
            case ISMD_AUDIO_DOWNMIX_3_0_2_LFE:
            case ISMD_AUDIO_DOWNMIX_2_2_2:
            case ISMD_AUDIO_DOWNMIX_DEFAULT:
            case ISMD_AUDIO_DOWNMIX_INVALID://Ok since this api call is not req'd.
               result = true;
               break;
            default:
               break;
         }
         break;
         
      case ISMD_AUDIO_7_1:
         
         switch(dmix_mode){
            case ISMD_AUDIO_DOWNMIX_1_0:
            case ISMD_AUDIO_DOWNMIX_1_0_LFE:
            case ISMD_AUDIO_DOWNMIX_2_0:
            case ISMD_AUDIO_DOWNMIX_2_0_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_LTRT:
            case ISMD_AUDIO_DOWNMIX_2_0_LTRT_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_DOLBY_PRO_LOGIC_II:
            case ISMD_AUDIO_DOWNMIX_2_0_DOLBY_PRO_LOGIC_II_NO_SCALE:
            case ISMD_AUDIO_DOWNMIX_2_0_LFE:
            case ISMD_AUDIO_DOWNMIX_2_1:
            case ISMD_AUDIO_DOWNMIX_2_1_LFE:
            case ISMD_AUDIO_DOWNMIX_3_0:
            case ISMD_AUDIO_DOWNMIX_3_0_LFE:
            case ISMD_AUDIO_DOWNMIX_3_1:
            case ISMD_AUDIO_DOWNMIX_3_1_LFE:
            case ISMD_AUDIO_DOWNMIX_2_2:
            case ISMD_AUDIO_DOWNMIX_2_2_LFE:
            case ISMD_AUDIO_DOWNMIX_3_2:
            case ISMD_AUDIO_DOWNMIX_3_2_LFE:
            case ISMD_AUDIO_DOWNMIX_3_0_1:
            case ISMD_AUDIO_DOWNMIX_3_0_1_LFE:
            case ISMD_AUDIO_DOWNMIX_2_2_1:
            case ISMD_AUDIO_DOWNMIX_2_2_1_LFE:
            case ISMD_AUDIO_DOWNMIX_3_2_1:   
            case ISMD_AUDIO_DOWNMIX_3_0_2:
            case ISMD_AUDIO_DOWNMIX_3_0_2_LFE:
            case ISMD_AUDIO_DOWNMIX_2_2_2:
            case ISMD_AUDIO_DOWNMIX_3_2_1_LFE:
            case ISMD_AUDIO_DOWNMIX_2_2_2_LFE:   
            case ISMD_AUDIO_DOWNMIX_3_2_2:
            case ISMD_AUDIO_DOWNMIX_3_2_2_LFE:
            case ISMD_AUDIO_DOWNMIX_DEFAULT:
            case ISMD_AUDIO_DOWNMIX_INVALID://Ok since this api call is not req'd.
               result = true;
               break;
            default:
               break;
         }
         break;

      case ISMD_AUDIO_CHAN_CONFIG_INVALID:
      default:
         break;
   }

   return result;
}

static ismd_result_t
audio_pvt_output_validate_final_output_setup(ismd_audio_output_wl_t *output_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   //If the downmix mode selected doesnt match channel count allowance, reset to default mix. 
   if(!audio_pvt_output_valid_dmix_mode_with_ch_config(output_wl->channel_config, output_wl->dmix_mode)) {
      OS_PRINT("Audio Warning: This output channel configuration cannnot support the downmix mode given. The output will recieve a default downmix.\n");
      output_wl->dmix_mode = ISMD_AUDIO_DOWNMIX_INVALID;
   }   

   if(output_wl->hw_id == GEN3_HW_OUTPUT_SPDIF) {

      if( (output_wl->output_mode == ISMD_AUDIO_OUTPUT_PCM) && ( (output_wl->channel_config != ISMD_AUDIO_STEREO) && (output_wl->channel_config != ISMD_AUDIO_DUAL_MONO) )) {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("S/PDIF interface only supports stereo output in PCM mode. ", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   else if(output_wl->hw_id == GEN3_HW_OUTPUT_I2S0) {

      if( (output_wl->channel_config != ISMD_AUDIO_STEREO) && (output_wl->channel_config != ISMD_AUDIO_DUAL_MONO) ) {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR("I2S0 only supports 2 channel (stereo) output!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }  
   //Add more possible output resitrictions?

   return result;
}


static bool
audio_pvt_output_valid_channel_map(int ch_map)
{
   bool result = true;
   int loop = 0;
   int curr_channel = 0;

   //0 = use default channel mapping.
   if(ch_map != 0){

      //Here we want to make sure there are no 0xF (invalid) channels for the given channel count.
      for(loop = 0; loop < AUDIO_MAX_OUTPUT_CHANNELS; loop++) {

         curr_channel = ((ch_map >> (loop * 4) ) & 0xF);

         //If its not invalid, check the valid range.    
         if( (curr_channel != 0xF) && (( curr_channel < 0) || (curr_channel > 7 )) ){
            result = false;
            OS_PRINT("\nAUDIO WARNING: Invalid output channel map supplied, using defaults: 0x%x\n", ch_map);
            break;
         }
      }

      if((unsigned int)ch_map == 0xFFFFFFFF){
         OS_PRINT("AUDIO WARNING: Output channel map 0xFFFFFFFF will produce no audio output!");
      }
   }

   return result;
}


static ismd_result_t
audio_pvt_output_validate_config(ismd_audio_output_config_t *config, bool hw_input, int hw_id)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;

   if (!audio_pvt_output_valid_channel_config(config->ch_config)){
   }
   else if(!audio_pvt_output_valid_output_mode(config->out_mode)){
   }
   else if(!audio_pvt_output_valid_sample_rate(config->sample_rate)){
   }
   else if(!audio_pvt_output_valid_sample_size(config->sample_size)){
   }
   else if(!audio_pvt_output_valid_stream_delay(config->stream_delay)){
   }
   else{
      if(hw_input && (!audio_pvt_output_valid_hw_id(hw_id))){
         result = ISMD_ERROR_INVALID_PARAMETER;
      }
      else{
         result = ISMD_SUCCESS;
      }
   }

   //Dont want to alarm anyone if the channel map is bad, just assume they want the defaults. 
   if(hw_id == 0){
      if(!audio_pvt_output_valid_channel_map(config->ch_map)){
         config->ch_map = 0;
      }
   }
   else{
      config->ch_map = 0;
   }

   //Dont error out if its a software port and set to bypass SRC
   if((result != ISMD_SUCCESS) && (!hw_input) && (config->sample_rate == ISMD_AUDIO_OUTPUT_SAMPLE_RATE_NO_CONVERT)) {
      result = ISMD_SUCCESS;
   }

   if((((config->out_mode == ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL) || (config->out_mode == ISMD_AUDIO_OUTPUT_ENCODED_DTS)) && (config->sample_rate != 48000))\
   		|| ( ((config->out_mode == ISMD_AUDIO_OUTPUT_ENCODED_AAC) && ( audio_aac_enc_valid_output_sample_rate(config->sample_rate)) !=ISMD_SUCCESS) )){
      result = ISMD_ERROR_INVALID_REQUEST;
      AUDIO_ERROR("Invalid Sampling Rate. AAC Encoder supports 8kHz to 96kHz. DTS or DD encoded output only support 48kHz output!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   return result;
}


static bool
audio_pvt_output_valid_hw_id(int hw_id)
{
   bool result = false;

   /* Portability tip: Replace these as output HW changes. */
   switch(hw_id){
      case GEN3_HW_OUTPUT_I2S0:
      case GEN3_HW_OUTPUT_I2S1:
      case GEN3_HW_OUTPUT_SPDIF:
      case GEN3_HW_OUTPUT_HDMI:
         result = true;
         break;
      default:
         result = false;
         AUDIO_ERROR("Invalid audio output HW ID.", result, audio_devh[AUDIO_DEBUG_APM]);
         break;
   }

   return result;
}


static bool
audio_pvt_output_valid_sample_rate(int sample_rate)
{
   bool result = false;

   switch(sample_rate){
      case 11025:
      case 12000:
      case 22050:
      case 24000:
      case 32000:
      case 44100:
      case 48000:
      case 88200:
      case 96000:
      case 176400:
      case 192000:
	  case ISMD_AUDIO_OUTPUT_SAMPLE_RATE_NO_CONVERT:
         result = true;
         break;
      default:
         AUDIO_ERROR("Sample rate not supported at this time!", ISMD_ERROR_FEATURE_NOT_SUPPORTED, audio_devh[AUDIO_DEBUG_APM]);
         break;
   }
   return result;
}


static bool
audio_pvt_output_valid_sample_size(int sample_size)
{
   bool result = false;

   switch(sample_size){
      case 8:
      case 16:
      case 20:
      case 24:
      case 32:
         result = true;
         break;
      default:
         AUDIO_ERROR(  "Output sample size not supported!", ISMD_ERROR_FEATURE_NOT_SUPPORTED, audio_devh[AUDIO_DEBUG_APM]);
         result = false;
         break;
   }
   return result;

}


static bool
audio_pvt_output_valid_output_mode(ismd_audio_output_mode_t output_mode)
{
   bool result = false;

   switch(output_mode){

      case ISMD_AUDIO_OUTPUT_PCM:
      case ISMD_AUDIO_OUTPUT_PASSTHROUGH:
         result = true;
         break;
      case ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL:
         if(audio_pvt_available_codec(ISMD_AUDIO_ENCODE_FMT_AC3)){
            result = true;
         }
         else{
            AUDIO_ERROR( "The AC3 (DD) encoder is not installed!", ISMD_ERROR_INVALID_RESOURCE, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
      case ISMD_AUDIO_OUTPUT_ENCODED_DTS: 
         if(audio_pvt_available_codec(ISMD_AUDIO_ENCODE_FMT_DTS)){
            result = true;
         }
         else{
            AUDIO_ERROR( "The DTS encoder is not installed!", ISMD_ERROR_INVALID_RESOURCE, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
      case ISMD_AUDIO_OUTPUT_ENCODED_AAC: 
         if(audio_pvt_available_codec(ISMD_AUDIO_ENCODE_FMT_AAC)){
            result = true;
         }
         else{
            AUDIO_ERROR( "The AAC encoder is not installed!", ISMD_ERROR_INVALID_RESOURCE, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;		 
      case ISMD_AUDIO_OUTPUT_INVALID:
      default:
         AUDIO_ERROR( "Invalid output mode!", ISMD_ERROR_INVALID_PARAMETER, audio_devh[AUDIO_DEBUG_APM]);
         result = false;
         break;
   }
   
   return result;
}


static bool
audio_pvt_output_valid_channel_config(ismd_audio_channel_config_t chan_config)
{
   bool result = false;

   switch(chan_config){

      case ISMD_AUDIO_STEREO:
      case ISMD_AUDIO_DUAL_MONO:
      case ISMD_AUDIO_5_1:
      case ISMD_AUDIO_7_1:
         result = true;
         break;
      case ISMD_AUDIO_CHAN_CONFIG_INVALID:
      default:
         AUDIO_ERROR( "Invalid output channel config!", ISMD_ERROR_INVALID_PARAMETER, audio_devh[AUDIO_DEBUG_APM]);
         result = false;
         break;
   }
   return result;
}


static bool
audio_pvt_output_valid_stream_delay(int stream_delay)
{
   bool result = false;

   if((stream_delay >= 0) && (stream_delay <= AUDIO_MAX_OUTPUT_STREAM_DELAY)){
      result = true;
   }
   else {
      AUDIO_ERROR( "Invalid output stream delay!!", ISMD_ERROR_INVALID_PARAMETER, audio_devh[AUDIO_DEBUG_APM]);
      result = false;
   }

   return result;
}


static void
audio_pvt_output_lock(ismd_audio_output_wl_t *instance) {

   if(instance != NULL) {
      os_mutex_lock(&instance->lock);
   }
  // OS_INFO("output lock\n");
}


void
audio_output_unlock(ismd_audio_output_wl_t *instance) {

   if(instance != NULL) {
      os_mutex_unlock(&instance->lock);
   }
  // OS_INFO("output unlock\n");
}

void
audio_output_api_unlock(ismd_audio_output_wl_t *instance) {
   audio_output_unlock(instance);
   audio_processor_unlock(instance->processor_wl);
}

static ismd_result_t
audio_pvt_output_queue_callback(void *context, ismd_queue_event_t queue_event, ismd_buffer_handle_t buffer )
{
   ismd_audio_output_wl_t  *output_wl = (ismd_audio_output_wl_t *)context;

   //Avoid compiler warnings.
   (void) queue_event;
   (void) buffer;

   if(ismd_event_strobe(output_wl->queue_data_avail_event) != ISMD_SUCCESS)
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"event_strobe failed in output queue callback!\n", audio_devh[AUDIO_DEBUG_APM]);

  /*SDM core expects this return code unless you handle dequeue-ing the buffer in this function.*/
  return ISMD_ERROR_NO_SPACE_AVAILABLE;
}


static void
*audio_pvt_output_render_recovery_thread(void *context)
{
   ismd_result_t result;
   ismd_audio_output_wl_t  *output_wl = ( ismd_audio_output_wl_t *)context;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   
   while (!output_wl->start_to_close && output_wl->in_use) {

      /** Wait on the recovery event only. */
      if ((result = ismd_event_wait(render_recovery_event, ISMD_TIMEOUT_NONE)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Event wait failed in render_recovery_thread.", result, audio_devh[AUDIO_DEBUG_APM]);
      } 

      /** Lock the output */
      audio_pvt_output_lock(output_wl);

      /** Make sure the output isn't being closed and is in use */
      if(!output_wl->start_to_close && output_wl->in_use && output_wl->enabled){

         /** The output is in use and we have the lock.  Now close and re-open the render, retrying until successful.  We assume here that the render isn't already closed. */
         do{

            /** Try to close the render */
            result = audio_render_close(output_wl->render_h);

            /** If we couldn't close the render because the render handle isn't in use, try to re-open the render anyway */
            if(result != ISMD_SUCCESS && result != ISMD_ERROR_FEATURE_NOT_IMPLEMENTED){
               AUDIO_ERROR("audio_render_close failed.\n", result, audio_devh[AUDIO_DEBUG_APM]);
            }      
            
            /** Try to re-open the render */
            else if((result = audio_render_open(&(output_wl->render_h), output_wl->hw_id, output_wl->psm_output_queue, AUDIO_RENDER_BUFFER_MODE_LINKED_LIST, output_wl->processor_id)) != ISMD_SUCCESS){
               AUDIO_ERROR("Error in render_open, in recovery thread.\n", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            /** Set the channel status */
            else if((result = audio_render_iec60958_set_channel_status(output_wl->render_h, output_wl->ch_status)) != ISMD_SUCCESS) {
               AUDIO_ERROR("audio_render_iec60958_set_channel_status failed in recovery thread.\n", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            /** Configure and start the render, using the state stored in output_wl */
            else if((result = audio_pvt_output_config_render_and_start(output_wl)) != ISMD_SUCCESS){
               AUDIO_ERROR("output_config_render_and_start failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }

            /** If any of the above steps failed, give render backend pipe time to drain before retrying, unless device has been removed */
            if(result != ISMD_SUCCESS && result != ISMD_ERROR_NOT_FOUND && !output_wl->start_to_close ){
               os_sleep(RENDER_PREFILL_CHUNK * AUDIO_CHUNK_TIME_PERIOD_MS);
            }
            
         } while (result != ISMD_SUCCESS && result != ISMD_ERROR_NOT_FOUND && !output_wl->start_to_close);
         
      }

      /** Unlock the output */
      audio_output_unlock(output_wl);
   
      /** Reset and acknowledge the render recovery event */
      if((result = ismd_event_reset(render_recovery_event)) != ISMD_SUCCESS) {
         AUDIO_ERROR("ismd_event_reset failed", result, audio_devh[AUDIO_DEBUG_APM]);
      } 

      if((result = ismd_event_acknowledge(render_recovery_event)) != ISMD_SUCCESS) {
         AUDIO_ERROR("ismd_event_acknowledge failed", result, audio_devh[AUDIO_DEBUG_APM]);
      } 

   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return NULL;
}



static void
*audio_pvt_output_port_thread(void *context)
{
   ismd_result_t result;
   bool work_to_do = true;
   ismd_audio_output_wl_t  *output_wl = ( ismd_audio_output_wl_t *)context;
   ismd_buffer_descriptor_t *buffer_des = NULL;
   ismd_event_t   event_list[ISMD_EVENT_LIST_MAX];
   int event_count = 0;
   ismd_event_t triggered_event;
   audio_buffer_attr_t *buffer_attr = NULL;
   ismd_pts_t last_pts = ISMD_NO_PTS;
   int pts_delta = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   event_list[event_count++] = output_wl->queue_data_avail_event;
   event_list[event_count++] = output_wl->out_port_full_event;

   while (! output_wl->start_to_close) {

      // Wait on both the queue event and the port event
      if ((result = ismd_event_wait_multiple(event_list, event_count, 50, &triggered_event))  != ISMD_SUCCESS) {

         if(result != ISMD_ERROR_TIMEOUT) {
            AUDIO_ERROR("Event wait failed in output port thread.", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      } 
      else if((result = ismd_event_acknowledge(triggered_event)) != ISMD_SUCCESS) {
         AUDIO_ERROR("ismd_event_acknowledge failed", result, audio_devh[AUDIO_DEBUG_APM]);
      } 

      work_to_do = true;

      while(work_to_do && !output_wl->start_to_close) {

         work_to_do = false;

         //If we dont have a buffer, try to dequeue.
         if(buffer_des == NULL) {              
            if((result = ismd_queue_dequeue(output_wl->psm_output_queue, &buffer_des)) == ISMD_SUCCESS) {
               work_to_do = true;

               /* Find the time between PTS values for SVEN event. */
               buffer_attr = (audio_buffer_attr_t*)buffer_des->attributes;
               if(buffer_attr->local_pts != ISMD_NO_PTS) {
                  if(last_pts != ISMD_NO_PTS ) {
                     pts_delta = (int)(buffer_attr->local_pts - last_pts);
                  }
                  last_pts = buffer_attr->local_pts;
               }
                   
               AUDIO_EVENT(AUDIO_SVEN_LOG_GENERAL, audio_devh[AUDIO_DEBUG_APM],
                  SVEN_MODULE_EVENT_AUD_IO_APM_OUTPUT_PORT_TIMING_INFO,
                  (unsigned int)buffer_attr->audio_format,
                  (unsigned int)buffer_attr->original_pts,
                  (unsigned int)buffer_attr->local_pts,
                  pts_delta, 0, 0);          
            }
            else{
               AUDIO_EVENT(AUDIO_SVEN_LOG_GENERAL, audio_devh[AUDIO_DEBUG_APM],
                  SVEN_MODULE_EVENT_AUD_IO_APM_OUTPUT_PORT_IN_DEQUEUE_FAILED,
                  output_wl->processor_wl->handle_id,
                  output_wl->handle,
                  output_wl->output_port,
                  output_wl->psm_output_queue, result, 0);
            }
         }

         //If we have a buffer write it to the port.
         if(buffer_des != NULL) {
            if((result = ismd_port_write(output_wl->output_port, buffer_des->unique_id)) == ISMD_SUCCESS) {
               work_to_do = true;
               buffer_des = NULL;
            }
            else{
               AUDIO_EVENT(AUDIO_SVEN_LOG_GENERAL, audio_devh[AUDIO_DEBUG_APM],
                  SVEN_MODULE_EVENT_AUD_IO_APM_OUTPUT_PORT_WRITE_FAILED,
                  output_wl->processor_wl->handle_id,
                  output_wl->handle,
                  output_wl->output_port,
                  output_wl->psm_output_queue, result, 0);
            }
         }
      }
   }

   if(buffer_des != NULL) { 
      ismd_audio_buffer_dereference(buffer_des->unique_id);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return NULL;
}


static ismd_result_t
audio_pvt_output_config_render_and_start(ismd_audio_output_wl_t *output_wl)
{
   ismd_result_t result;
   bool render_look_at_ts =  true; //True by default.
   unsigned int render_max_early_ms = 0;
   ismd_audio_format_t format;
   int sample_size;
   ismd_audio_channel_config_t channel_config;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   /* Figure out output mode */
   switch(output_wl->output_mode){

      case ISMD_AUDIO_OUTPUT_PCM:

         output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_PCM;

         break;

      case ISMD_AUDIO_OUTPUT_PASSTHROUGH:
         output_wl->processor_wl->passthrough_output_count++;
         if (AUDIO_CORE_IS_VALID_MS10_INPUT(output_wl, output_wl->processor_wl->primary_input_format)) {
            output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_DD;
         }
         else if (NULL != output_wl->processor_wl->primary_input_wl && output_wl->processor_wl->primary_input_wl->ddplus_dcv_dd_enabled){
            /* The ddplus_dcv_dd_enabled flag tells us that we are using the DCV codec on DD+ input.  
            Since DCV will output AC3, for the passthrough case, this is what should be set as the output format.  */
            output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_DD;
         }
         else {
            output_wl->render_format = output_wl->processor_wl->primary_input_format;
         }

         break;

      case ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL:

         output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_DD;
         
         break;
      case ISMD_AUDIO_OUTPUT_ENCODED_DTS:

         output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_DTS;

         break;

      case ISMD_AUDIO_OUTPUT_ENCODED_AAC:

         output_wl->render_format = ISMD_AUDIO_MEDIA_FMT_AAC;

         break;

      case ISMD_AUDIO_OUTPUT_INVALID:
      default:

         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid output mode;", result, audio_devh[AUDIO_DEBUG_APM]);

         break;
   }

   /*Update the local copy of the render format and sample size. */
   format = output_wl->render_format;
   sample_size = output_wl->sample_size_actual;
   channel_config = output_wl->channel_config;

   /*If we have a passthrough output, and the mode was set to direct (NOT IEC), we are forcing 
   the render to PCM mode, as this mode is usually used for backwards compatability for formats like
   DTS music CD where they are passing the data as if it was PCM, also set sample size to 32 as passthrough
   streams are always expanded to 32b. */
   if((output_wl->output_mode == ISMD_AUDIO_OUTPUT_PASSTHROUGH) && (output_wl->processor_wl->primary_input_wl != NULL)) {
      if(output_wl->processor_wl->primary_input_wl->pass_through_mode == ISMD_AUDIO_PASS_THROUGH_MODE_DIRECT) {
         format = ISMD_AUDIO_MEDIA_FMT_PCM;
         sample_size = 32;
         channel_config = ISMD_AUDIO_STEREO;
      }
   }
   
   /*Need to tell render to discard buffers if the arrive too early. Determine this time in terms of milliseconds.
     Basing this number off our back-end delay and render prefill time, if the ATC releases the buffer and 
     for whatever reason it arrives earlier than that, need to discard.*/
   render_max_early_ms = (output_wl->processor_wl->chunk_size_period * RENDER_EARLY_DISCARD_POLICY_MAX_PERIODS);

   /*Open and configure render device*/
   if((result = audio_render_set_timed_mode(output_wl->render_h, render_look_at_ts)) != ISMD_SUCCESS){
      AUDIO_ERROR("audio_render_set_timed_mode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_render_set_data_format(output_wl->render_h, format)) != ISMD_SUCCESS){
      AUDIO_ERROR("audio_render_set_data_format failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   } 
   else if((result = audio_render_set_sample_size(output_wl->render_h, sample_size)) != ISMD_SUCCESS){
      AUDIO_ERROR("render_set_sample_size failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_render_set_channel_config(output_wl->render_h, channel_config)) != ISMD_SUCCESS){
      AUDIO_ERROR("render_set_channel_config failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_render_set_sample_rate( output_wl->render_h, output_wl->sample_rate)) != ISMD_SUCCESS) {
      AUDIO_ERROR("render_set_sample_rate failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_render_set_ext_bit_clock_div(output_wl->render_h, output_wl->bit_clk_div_val)) != ISMD_SUCCESS){
      AUDIO_ERROR("render_set_ext_bit_clock_div failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }  
   else if((result = audio_render_set_buffer_prefill_time(output_wl->render_h, RENDER_PREFILL_CHUNK * AUDIO_CORE_GET_CHUNK_PERIOD(output_wl))) != ISMD_SUCCESS){
      AUDIO_ERROR("audio_render_set_buffer_prefill_count failed!",  result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if((result = audio_render_set_early_discard_policy(output_wl->render_h, AUDIO_RENDER_EARLY_POLICY_DISCARD_FIXED_MS, render_max_early_ms)) != ISMD_SUCCESS){
      AUDIO_ERROR("audio_render_set_early_discard_policy failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   } 
   else if((result = audio_render_set_state(output_wl->render_h, ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
      AUDIO_ERROR("audio_render_set_state failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else{

      /*Set up validity and channel Status if SPDIF, we have to handle changing this on the fly also*/
      if(output_wl->hw_id == GEN3_HW_OUTPUT_SPDIF){

         /* This isnt a show stopper if this fails, just warn */
         if(audio_render_iec60958_set_channel_status(output_wl->render_h, output_wl->ch_status) != ISMD_SUCCESS){//Might need to ask user for catagory?
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "Could not set channel status!", audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }

   //HDMI needs 32bits always on the output, so I first setup the sample size on the render,
   //Then change this to 32 since it is what is looked at when we setup the backend pipe.
   if(output_wl->hw_id == GEN3_HW_OUTPUT_HDMI) {
      output_wl->sample_size = 32;
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   return result;
}


static int
audio_pvt_output_ch_config_to_count(ismd_audio_channel_config_t ch_config )
{
   int ch_count = 0;
   
   switch(ch_config) {   
      case ISMD_AUDIO_STEREO :
      case ISMD_AUDIO_DUAL_MONO:
         ch_count = 2;
         break;
      case ISMD_AUDIO_5_1:
         ch_count = 6;
         break;
      case ISMD_AUDIO_7_1:
         ch_count = 8;
         break;
      case ISMD_AUDIO_CHAN_CONFIG_INVALID:
      default:
         AUDIO_ERROR("Invalid output channel config!", ISMD_ERROR_INVALID_PARAMETER, audio_devh[AUDIO_DEBUG_APM]);
         break;
   }
   
   return ch_count;
}

static ismd_result_t
audio_pvt_set_sadiv_value_for_default_case(ismd_audio_output_wl_t *output_wl, unsigned int master_clk_freq)
{
   ismd_result_t result = ISMD_SUCCESS;
   unsigned int i2s_bit_clk_rate = 64 * output_wl->sample_rate;
   unsigned int spdif_bit_clk_rate = 128 * output_wl->sample_rate;
   
   switch(output_wl->hw_id){
      case GEN3_HW_OUTPUT_I2S0:
      case GEN3_HW_OUTPUT_I2S1:
         if((master_clk_freq % i2s_bit_clk_rate) == 0){
            output_wl->bit_clk_div_val = master_clk_freq/i2s_bit_clk_rate;
         }
         else{
            result = ISMD_ERROR_INVALID_PARAMETER;
         }
         break;
      case GEN3_HW_OUTPUT_SPDIF:
         if((master_clk_freq % spdif_bit_clk_rate) == 0){
            output_wl->bit_clk_div_val = master_clk_freq/spdif_bit_clk_rate;
         }
         else{
            result = ISMD_ERROR_INVALID_PARAMETER;
         }
         break;
      case GEN3_HW_OUTPUT_HDMI:
      default:
      break;
   }

   return result;
}

static void
audio_pvt_set_bit_clk_div_value(ismd_audio_output_wl_t *output_wl, int i2s_val, int spdif_val)
{
   switch(output_wl->hw_id){
      case GEN3_HW_OUTPUT_I2S0:
      case GEN3_HW_OUTPUT_I2S1:
         output_wl->bit_clk_div_val = i2s_val;
         break;
      case GEN3_HW_OUTPUT_SPDIF:
         output_wl->bit_clk_div_val = spdif_val;
         break;
      case GEN3_HW_OUTPUT_HDMI:
      default:
      break;
   }
}

static ismd_result_t
audio_pvt_set_clk_div_based_on_master_freq(ismd_audio_output_wl_t *output_wl, 
                                                      unsigned int master_clk_freq)
{
   ismd_result_t result = ISMD_SUCCESS;
   unsigned int sample_rate_khz, temp_sample_rate;
   unsigned int i2s_val = AUDIO_MC_36_864_MHZ_SADIV_I2S_48KHZ;
   unsigned int spdif_val = AUDIO_MC_36_864_MHZ_SADIV_SPDIF_48KHZ;

   sample_rate_khz = output_wl->sample_rate/1000;
   temp_sample_rate = output_wl->sample_rate/100;
   
   switch(master_clk_freq){
      case 36864000:
         //For I2S output,  SADIV = 36864/ (64*Fs)
         i2s_val = 36864/(64*sample_rate_khz);
         //For SPDIF output,  SADIV = 36864/ (128*Fs).
         spdif_val = 36864/(128*sample_rate_khz);
         if(sample_rate_khz == 192){
            spdif_val = AUDIO_MC_36_864_MHZ_SADIV_SPDIF_96KHZ; 
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "SPDIF cannot support 192000Hz @ master freq 36.864 MHz!! configuring to 96000Hz", audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
      case 24576000:
         //For I2S output,  SADIV = 24576/ (64*Fs). 
         i2s_val = 24576/(64*sample_rate_khz);
         //For SPDIF output,  SADIV = 24576/ (128*Fs). 
         spdif_val = 24576/(128*sample_rate_khz);
         if(sample_rate_khz == 192){
            spdif_val = AUDIO_MC_24_576_MHZ_SADIV_SPDIF_192KHZ;            
         }
         break;
      case 33868800:
         //For I2S output,  SADIV = 33868.8/ (64*Fs)
         i2s_val = 338688/(64*temp_sample_rate);
         //For SPDIF output,  SADIV = 33868.8/ (128*Fs).
         spdif_val = 338688/(128*temp_sample_rate);
         if(temp_sample_rate == 1764){
            spdif_val = AUDIO_MC_33_8688_MHZ_SADIV_SPDIF_88_2_KHZ;
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "SPDIF cannot support 176400Hz @ master freq 33.8688 MHz!! configuring to 88200Hz", audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
      case 22579200:
         //For I2S output,  SADIV = 22579.2/ (64*Fs). 
         i2s_val = 225792/(64*temp_sample_rate);
         //For SPDIF output,  SADIV = 22579.2/ (128*Fs). 
         spdif_val = 225792/(128*temp_sample_rate);
         break;
      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         break;
   }

   

   if(result == ISMD_SUCCESS){
      audio_pvt_set_bit_clk_div_value(output_wl, i2s_val, spdif_val);
   }
   else {
      result = audio_pvt_set_sadiv_value_for_default_case(output_wl, master_clk_freq);
   }

   return result;
}


static ismd_result_t
audio_pvt_set_sadiv_value(ismd_audio_output_wl_t *output_wl, unsigned int master_clk_freq)
{
   ismd_result_t result = ISMD_SUCCESS;

   //Give a default value.
   output_wl->bit_clk_div_val = AUDIO_MC_36_864_MHZ_SADIV_I2S_48KHZ;

   switch(output_wl->sample_rate){
      case 12000:
      case 24000:
      case 32000:
      case 44100:
      case 88200:
      case 48000:
      case 96000:
      case 176400:
      case 192000:
         result = audio_pvt_set_clk_div_based_on_master_freq(output_wl, master_clk_freq);
         break;
      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid output sample rate!", ISMD_ERROR_INVALID_PARAMETER, audio_devh[AUDIO_DEBUG_APM]);
         break;
   }

   return result;
}

static ismd_result_t
audio_pvt_output_set_delay(audio_psm_post_atc_pipe_t *pipe, int output_handle, int delay_ms)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(pipe->stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.enabled){
   
      if(delay_ms <= pipe->stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.max_delay_ms){

         /* Index into our context associated with this output with the output handle, check to see if there is a change in delay. */
         if(pipe->stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.host.per_output_delay.host_output_params[output_handle].new_delay != delay_ms){

            pipe->stages[PER_OUTPUT_DELAY_STAGE].params.per_output_delay.host.per_output_delay.host_output_params[output_handle].new_delay = delay_ms;
            
            /* Send changes down the psm */
			if((pipe->pipe_h != AUDIO_INVALID_HANDLE)&&(pipe->stages[PER_OUTPUT_DELAY_STAGE].handle != AUDIO_INVALID_HANDLE)){
                if((result = audio_psm_stage_config_direct(pipe->pipe_h,
                                                    pipe->stages[PER_OUTPUT_DELAY_STAGE].handle,
                                                    &pipe->stages[PER_OUTPUT_DELAY_STAGE].params)) != ISMD_SUCCESS) {
    
                   AUDIO_ERROR("audio_psm_stage_config_direct failed", result, audio_devh[AUDIO_DEBUG_APM]);
                }
			}
         }
      }
      else{
         result = ISMD_ERROR_INVALID_PARAMETER;
      }
   }
   else {
      result = ISMD_ERROR_INVALID_REQUEST;
   }

   return result;
}


static ismd_result_t
audio_pvt_srs_get_context(ismd_audio_output_wl_t *output_wl){
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_post_atc_pipe_t *pipe = &output_wl->processor_wl->psm_pa_pipe;
   int temp;

   //If already enabled, just return success. 
   if(output_wl->srs_context_info == AUDIO_INVALID_HANDLE) {

      //Check for an instance of SRS that is not in use. 
      for(temp=0; temp < AUDIO_SRS_MAX_OUTPUTS ; temp++){               
         if(!pipe->stages[SRS_STAGE].params.srs.host.srs.context[temp].in_use){ 
            pipe->stages[SRS_STAGE].params.srs.host.srs.context[temp].in_use = true;
            output_wl->srs_context_info = temp; 
            result = audio_pvt_init_srs_params(&pipe->stages[SRS_STAGE].params.srs.host.srs.context[temp]);
            break;
         }
      }

      if(output_wl->srs_context_info == AUDIO_INVALID_HANDLE){
         result = ISMD_ERROR_NO_RESOURCES;
         AUDIO_ERROR("No available SRS contexts!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      if(output_wl->processor_wl->psm_pa_pipe.pipe_configured) {
         audio_processor_post_atc_pipe_reconfig(output_wl->processor_wl, true, false);  
      }
   }

   return result;
}

static ismd_result_t
audio_pvt_srs_free_context(ismd_audio_output_wl_t *output_wl){
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_post_atc_pipe_t *pipe = &output_wl->processor_wl->psm_pa_pipe;
   int temp = 0;
   bool disable_context_only = false;

   //If already disabled, just return success. 
   if(output_wl->srs_context_info != AUDIO_INVALID_HANDLE) {

      //Reinitialze the context and mark it not in use.
      pipe->stages[SRS_STAGE].params.srs.host.srs.context[output_wl->srs_context_info].in_use = false;
	   memset((void*)&pipe->stages[SRS_STAGE].params.srs.host.srs.context[output_wl->srs_context_info].pipe, 0, sizeof(ismd_audio_srs_pipe_params_t));
      output_wl->srs_context_info = AUDIO_INVALID_HANDLE;
      //Check to see if we have any more SRS contexts enabled.
      for(temp=0; temp < AUDIO_SRS_MAX_OUTPUTS ; temp++){ 
         if(pipe->stages[SRS_STAGE].params.srs.host.srs.context[temp].in_use){
            disable_context_only = true;
            break;
         }
      }

      //If we still have other contexts active, just disable this context.
      if(disable_context_only) {
         if((result = audio_psm_stage_config_direct(output_wl->processor_wl->psm_pa_pipe.pipe_h, 
            output_wl->processor_wl->psm_pa_pipe.stages[SRS_STAGE].handle,
            &output_wl->processor_wl->psm_pa_pipe.stages[SRS_STAGE].params)) != ISMD_SUCCESS) 
         {
            AUDIO_ERROR("Could not commit changes to SRS pipe!", result, audio_devh[AUDIO_DEBUG_APM]);
         } 
      }
      //If we have no other contexts active, reconfig post ATC pipe, that will remove SRS stage.
      else if(output_wl->processor_wl->psm_pa_pipe.pipe_configured) {
         audio_processor_post_atc_pipe_reconfig(output_wl->processor_wl, true, false);  
      }
   }

   return result;
}

static ismd_result_t 
audio_pvt_init_srs_params(audio_output_srs_pipe_t *srs_context){

   /** The SRS pipeline has everything enabled by default.
      So if the user tries to enable something, it shouldnt be mem compared as a difference! */
   ismd_audio_srs_pipe_params_t *host_params = &srs_context->pipe;
   host_params->filter1.enable       =  true;
   host_params->filter2.enable       =  true;
   host_params->graphic_eq.enable    =  true;
   host_params->hard_limiter.enable  =  true;
   host_params->parametric_eq.enable =  true;
   host_params->tru_dialog.enable    =  true;
   host_params->tru_sur_hd.enable    =  true;
   host_params->master_bypass        =  false;
   host_params->tru_volume.enable    =  true;
   srs_context->srs_params_change_notifier = 0;
	return ISMD_SUCCESS;

}

static ismd_result_t 
audio_pvt_srs_set_params(ismd_audio_output_wl_t *output_wl, ismd_audio_srs_pipe_params_t *params){
   ismd_result_t result = ISMD_SUCCESS;
   audio_output_srs_pipe_t* srs_context = &output_wl->processor_wl->psm_pa_pipe.stages[SRS_STAGE].params.srs.host.srs.context[output_wl->srs_context_info];
   
   if(output_wl->srs_context_info != AUDIO_INVALID_HANDLE && params!=NULL) { 

      /** The validate params returns success if any new parameters have been specified. */
      if((audio_pvt_srs_validate_and_set_params(srs_context, params) == ISMD_SUCCESS) && output_wl->processor_wl->psm_pa_pipe.pipe_configured){
         if((result = audio_psm_stage_config_direct(output_wl->processor_wl->psm_pa_pipe.pipe_h, 
            output_wl->processor_wl->psm_pa_pipe.stages[SRS_STAGE].handle,
            &output_wl->processor_wl->psm_pa_pipe.stages[SRS_STAGE].params)) != ISMD_SUCCESS) 
         {
            AUDIO_ERROR("Could not commit changes to SRS pipe!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }
   else {
      result = ISMD_ERROR_INVALID_REQUEST;
      AUDIO_ERROR("SRS context not enabled for this output!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   return result;
}

static ismd_result_t 
audio_pvt_srs_get_params(ismd_audio_output_wl_t *output_wl, ismd_audio_srs_pipe_params_t *params){
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   if(output_wl->srs_context_info != AUDIO_INVALID_HANDLE && params!=NULL) {
      if (( output_wl->processor_wl->psm_pa_pipe.pipe_configured ) && (output_wl->processor_wl->psm_pa_pipe.stages[SRS_STAGE].handle != AUDIO_INVALID_HANDLE)){
         if((result = audio_psm_stage_get_config(output_wl->processor_wl->psm_pa_pipe.pipe_h, 
                          output_wl->processor_wl->psm_pa_pipe.stages[SRS_STAGE].handle, 
                          &output_wl->processor_wl->psm_pa_pipe.stages[SRS_STAGE].params)) != ISMD_SUCCESS) {
            AUDIO_ERROR("audio_psm_stage_get_config  for the SRS stage failed", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
      if(memcpy((void*)params, 
         (void*)&output_wl->processor_wl->psm_pa_pipe.stages[SRS_STAGE].params.srs.host.srs.context[output_wl->srs_context_info].pipe,
         sizeof(ismd_audio_srs_pipe_params_t))) 
      {
         result=ISMD_SUCCESS;
      }
   }
   else {
      result = ISMD_ERROR_INVALID_REQUEST;
      AUDIO_ERROR("SRS context not enabled for this output!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   return result;
}


static ismd_result_t 
audio_pvt_srs_validate_and_set_params(audio_output_srs_pipe_t* srs_context , ismd_audio_srs_pipe_params_t* params){
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   int srs_params_change_notifier = 0;
   ismd_audio_srs_pipe_params_t* host_params = &srs_context->pipe;                            
   if((params->master_bypass)){
      /** if master bypass is already enabled, and parameters havent changed, no need to re do it, else re do it */
      if(!host_params->master_bypass){
         host_params->master_bypass        =  true;
         srs_params_change_notifier        =  (srs_params_change_notifier | MASTER_BYPASS_ENABLE);
         srs_context->srs_params_change_notifier = srs_params_change_notifier; 
         result = ISMD_SUCCESS;
      }
      else {         
         result = ISMD_ERROR_UNSPECIFIED; 
      }
	  return result;
   }

   else {
      if(host_params->master_bypass){
	     host_params->master_bypass = false;
		 result = ISMD_SUCCESS;
	  }
      if((memcmp((void*)&host_params->filter1,(void*)&params->filter1,sizeof(ismd_audio_srs_filter_params_t))!=0)){
         memcpy((void*)&host_params->filter1,(void*)&params->filter1,sizeof(ismd_audio_srs_filter_params_t));
         srs_params_change_notifier = (srs_params_change_notifier | FILTER_1_CHANGED );
      }
      if((memcmp((void*)&host_params->filter2,(void*)&params->filter2,sizeof(ismd_audio_srs_filter_params_t))!=0)){
         memcpy((void*)&host_params->filter2,(void*)&params->filter2,sizeof(ismd_audio_srs_filter_params_t));
         srs_params_change_notifier = (srs_params_change_notifier | FILTER_2_CHANGED); 
      }
 
      if((memcmp((void*)&host_params->tru_volume,(void*)&params->tru_volume,sizeof(ismd_audio_srs_tru_volume_params_t))!=0)){
         memcpy((void*)&host_params->tru_volume,(void*)&params->tru_volume,sizeof(ismd_audio_srs_tru_volume_params_t));
         srs_params_change_notifier = (srs_params_change_notifier | TRU_VOLUME_CHANGED);
      }

      if((memcmp((void*)&host_params->cs_decoder,(void*)&params->cs_decoder,sizeof(ismd_audio_srs_cs_decoder_params_t))!=0)){
         memcpy((void*)&host_params->cs_decoder,(void*)&params->cs_decoder,sizeof(ismd_audio_srs_cs_decoder_params_t));
         srs_params_change_notifier = (srs_params_change_notifier | CS_DECODER_CHANGED);
      }

      if((memcmp((void*)&host_params->tru_dialog,(void*)&params->tru_dialog,sizeof(ismd_audio_srs_tru_dialog_params_t))!=0)){
         memcpy((void*)&host_params->tru_dialog,(void*)&params->tru_dialog,sizeof(ismd_audio_srs_tru_dialog_params_t));
         srs_params_change_notifier = (srs_params_change_notifier | TRU_DIALOG_CHANGED);
      }

      if((memcmp((void*)&host_params->tru_sur_hd,(void*)&params->tru_sur_hd,sizeof(ismd_audio_srs_tru_sur_hd_params_t))!=0)){
         memcpy((void*)&host_params->tru_sur_hd,(void*)&params->tru_sur_hd,sizeof(ismd_audio_srs_tru_sur_hd_params_t));
         srs_params_change_notifier = (srs_params_change_notifier | TRU_SUR_HD_CHANGED); 
      }

      if((memcmp((void*)&host_params->hard_limiter,(void*)&params->hard_limiter,sizeof(ismd_audio_srs_hard_limiter_params_t))!=0)){
         memcpy((void*)&host_params->hard_limiter,(void*)&params->hard_limiter,sizeof(ismd_audio_srs_hard_limiter_params_t));
         srs_params_change_notifier = (srs_params_change_notifier | HARD_LIMITER_CHANGED);
      }

      if((memcmp((void*)&host_params->graphic_eq,(void*)&params->graphic_eq,sizeof(ismd_audio_srs_geq_params_t))!=0)){
         memcpy((void*)&host_params->graphic_eq,(void*)&params->graphic_eq,sizeof(ismd_audio_srs_geq_params_t));
         srs_params_change_notifier = (srs_params_change_notifier | GRAPHIC_EQ_CHANGED);
      }

      if((memcmp((void*)&host_params->parametric_eq,(void*)&params->parametric_eq,sizeof(ismd_audio_srs_peq_params_t))!=0)){
         memcpy((void*)&host_params->parametric_eq,(void*)&params->parametric_eq,sizeof(ismd_audio_srs_peq_params_t));
         srs_params_change_notifier = (srs_params_change_notifier | PARAMETRIC_EQ_CHANGED); 
      }
   
     
   }

   host_params->headroom_gain = params->headroom_gain;
   /** Return success if we have any changed parameters. */
   if(srs_params_change_notifier != 0){
   	srs_context->srs_params_change_notifier = srs_params_change_notifier;         
   }
   
  
   return result;
}


