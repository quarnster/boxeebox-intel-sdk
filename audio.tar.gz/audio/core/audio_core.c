
/*
* File Name: ismd_audio_core.c
*/

/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "audio_core.h"
#include "audio_apm_common.h"

/* Global debug setting variables, default settings (if plat_config fails) */
int audio_debug_method = AUDIO_LOG_DISABLE;
int audio_debug_level = 0;

int audio_sven_dbg_type = 12, audio_sven_log_level_override = 2;
bool audio_enable_sven_log[AUDIO_SVEN_LOG_NUMBERS];


os_devhandle_t *audio_devh[AUDIO_DEBUG_UNIT_MAX];

ismd_event_t atc_render_resync_event;
ismd_event_t render_recovery_event;;

//Used to disable interrupts when we dont want to lock.
os_irqlock_t   audio_irq_lock;

/*Flag to tell if we are on coherent or non-coherent (fast) path.*/
static int audio_dsp_memory_path = AUDIO_DSP_MEM_PATH_NON_COHERENT;

static ismd_result_t
audio_pvt_core_access_check(void)
{
   ismd_result_t result = ISMD_SUCCESS;

   /* Put audio memory layout check, platform_config check here */

   // Check ACE contexts
   if (AUDIO_QUALITY_MAX_CONTEXTS < AUDIO_MAX_OUTPUTS) {
      result = ISMD_ERROR_UNSPECIFIED;
      AUDIO_ERROR("check failed: insufficient ACE contexts!", result,  audio_devh[AUDIO_DEBUG_APM]);
   }

   /* Need to ensure this structure doesnt get bigger than the auto-api allows.*/
   if(sizeof(ismd_audio_specialized_processing_params_t) > MAX_AUTO_API_PARAM_SIZE) {
      OS_INFO("\nAUDIO FATALITY! ismd_audio_specialized_processing_params_t exceeds %d bytes! Size: %d\n", 
         MAX_AUTO_API_PARAM_SIZE, sizeof(ismd_audio_specialized_processing_params_t));
      OS_ASSERT(0);
   }

   /*Get the DSP memory path setting from platform config, then set it.*/
   AUDIO_CONFIG_GET_DSP_MEMORY_PATH_SETTING(audio_dsp_memory_path);
   if ((result = audio_hal_set_dsp_memory_path((audio_dsp_memory_path_t*)&audio_dsp_memory_path)) != ISMD_SUCCESS) {
      AUDIO_ERROR("Error setting DSP memory path!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   return result;
}

static void audio_pvt_read_platform_config(void)
{
   unsigned temp;

   
   audio_enable_sven_log[AUDIO_SVEN_LOG_NONE]     = false;
   audio_enable_sven_log[AUDIO_SVEN_LOG_CRITICAL] = true;
   audio_enable_sven_log[AUDIO_SVEN_LOG_DATAFLOW] = false;
   audio_enable_sven_log[AUDIO_SVEN_LOG_GENERAL]  = false;
   audio_enable_sven_log[AUDIO_SVEN_LOG_FUNCTION] = false;

   // Read the SVEN debug level from platform config.
   ISMD_AUDIO_INT_PROPERTY("sven_log_level_override", CONFIG_PATH_PLATFORM_SMD_DRIVERS, audio_sven_log_level_override);
   if(audio_sven_log_level_override == 0) {
      audio_enable_sven_log[AUDIO_SVEN_LOG_CRITICAL]  = false;
      audio_enable_sven_log[AUDIO_SVEN_LOG_DATAFLOW]  = false;
      audio_enable_sven_log[AUDIO_SVEN_LOG_GENERAL]   = false;
      audio_enable_sven_log[AUDIO_SVEN_LOG_FUNCTION]  = false;
   } else if (audio_sven_log_level_override == 1){
      audio_enable_sven_log[AUDIO_SVEN_LOG_CRITICAL]  = true;
      audio_enable_sven_log[AUDIO_SVEN_LOG_DATAFLOW]  = true;
      audio_enable_sven_log[AUDIO_SVEN_LOG_GENERAL]   = true;
      audio_enable_sven_log[AUDIO_SVEN_LOG_FUNCTION]  = true;
   }else if(audio_sven_log_level_override == 2){
      ISMD_AUDIO_INT_PROPERTY("sven_log_level", CONFIG_PATH_SMD_AUDIO, audio_sven_dbg_type); 
      if (!audio_sven_dbg_type) {
         audio_enable_sven_log[AUDIO_SVEN_LOG_CRITICAL]  = false;
      } else {
         while (1) {
            temp = audio_sven_dbg_type % 10;
            switch (temp) {
               case 1 :
                  audio_enable_sven_log[AUDIO_SVEN_LOG_CRITICAL]  = true;
                  break;
               case 2 :
                  audio_enable_sven_log[AUDIO_SVEN_LOG_DATAFLOW]  = true;
                  break;
               case 3 :
                  audio_enable_sven_log[AUDIO_SVEN_LOG_GENERAL]   = true;
                  break;
               case 4 : 
                  audio_enable_sven_log[AUDIO_SVEN_LOG_FUNCTION]  = true;
                  break;
               default :
                  break;
            }
            audio_sven_dbg_type  = audio_sven_dbg_type / 10; 
            if(!audio_sven_dbg_type) {
               break;
            }
         } //While
      }
   }//(smd_global_sven_level == 1)  

}


/*Audio Core Public functions.*/
ismd_result_t 
ismd_audio_core_initialize(void)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED; 
   int config_debug_level = 0;
   int config_debug_method = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CORE]);

   /*Get debug config parameters from platform_config*/
   if(AUDIO_CONFIG_GET_DEBUG_LEVEL(config_debug_level) == CONFIG_SUCCESS){
     audio_debug_level = config_debug_level;
   }

   if(AUDIO_CONFIG_GET_DEBUG_METHOD(config_debug_method) == CONFIG_SUCCESS){
      audio_debug_method = config_debug_method;
   }

   /** Read the platform config */
   audio_pvt_read_platform_config();
   /*Alloc event used to notify the ATC that render is late */
   if((result = ismd_event_alloc(&atc_render_resync_event)) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_event_alloc failed in core init!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   /*Alloc event used to notify need to remove, add a dead render. */
   else if((result = ismd_event_alloc(&render_recovery_event)) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_event_alloc failed in core init!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }
   
   else if((result = audio_hal_init(audio_devh[AUDIO_DEBUG_RENDER])) != ISMD_SUCCESS) {
      AUDIO_ERROR("audio_hal_init failed in core init!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }
   
   else if ((result = audio_pvt_core_access_check()) != ISMD_SUCCESS) {
      AUDIO_ERROR("audio access check failed in core init!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   else if((result = audio_timing_control_initialize()) != ISMD_SUCCESS) {
      AUDIO_ERROR("ATC initialize failed!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   else if((result = audio_psm_initialize()) != ISMD_SUCCESS) {
      AUDIO_ERROR("PSM initialize failed!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   else if((result = audio_render_initialize()) != ISMD_SUCCESS) {
      AUDIO_ERROR("Render initialize failed!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   else if((result = audio_capture_initialize()) != ISMD_SUCCESS) {
      AUDIO_ERROR("Capture initialize failed!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   else{
      os_irqlock_init(&audio_irq_lock);
   }
  
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CORE]);
   
   return result;
}

ismd_result_t 
ismd_audio_core_sven_init(void) 
{
   ismd_result_t result = ISMD_SUCCESS;
   int unit;

   /* Create a SVEN Handle for debug unit types */
   for ( unit = 0; unit < AUDIO_DEBUG_UNIT_MAX; unit++ )
   {
     if ( NULL != (audio_devh[unit] = devhandle_factory(NULL)) ) {

        devh_SVEN_SetModuleUnit( audio_devh[unit], SVEN_module_GEN3_AUD_IO, unit );

        /*Connect by name only if the handle will be touching registers.*/
        switch(unit)
        {
            case AUDIO_DEBUG_RENDER:
            case AUDIO_DEBUG_CAPTURE:    
               
              if(!devhandle_connect_name( audio_devh[unit], "AU_IF")) {
                  OS_INFO("ERROR: devhandle_connect_name failed for AUDIO IO!\n");
                  result = ISMD_ERROR_OPERATION_FAILED;
                  unit = AUDIO_DEBUG_UNIT_MAX;
               }
              
               break;
            default: 
               break;
        }
     }
     else {
      
       OS_INFO("ERROR: devhandle_factory FAILED!\n");
       result = ISMD_ERROR_OPERATION_FAILED;
       unit = AUDIO_DEBUG_UNIT_MAX; //break out of for loop
     }
   }
   
  return result;
}

void
ismd_audio_core_sven_deinit(void) 
{ 
   int unit;

   /* Delete SVEN handles */
  for ( unit = 0; unit < AUDIO_DEBUG_UNIT_MAX; unit++ )
  {
      if(audio_devh[unit] != NULL){
         devh_Delete(audio_devh[unit]);
         audio_devh[unit] = NULL;
      }
  }
  
   return ;
}

ismd_result_t 
ismd_audio_core_deinitialize(void)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CORE]);

   /*Deinit all audio sub-units.*/

   if((result = audio_timing_control_deinitialize()) != ISMD_SUCCESS)
      AUDIO_ERROR("audio_timing_control_deinit failed!\n", result, audio_devh[AUDIO_DEBUG_CORE]);

   if((result = audio_psm_deinitialize()) != ISMD_SUCCESS)
      AUDIO_ERROR("psm_deinit failed!\n", result, audio_devh[AUDIO_DEBUG_CORE]);

   if((result = audio_render_deinitialize()) != ISMD_SUCCESS)
      AUDIO_ERROR("render_deinit failed!\n", result, audio_devh[AUDIO_DEBUG_CORE]);

   if((result = audio_capture_deinitialize()) != ISMD_SUCCESS)
      AUDIO_ERROR("audio_capture_deinitialize failed!\n", result, audio_devh[AUDIO_DEBUG_CORE]);

   if((result = audio_hal_deinit(audio_devh[AUDIO_DEBUG_RENDER])) != ISMD_SUCCESS) {
      AUDIO_ERROR("audio_hal_deinit failed in core init!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   if((result = ismd_event_free(atc_render_resync_event)) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_event_free failed in core init!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   if((result = ismd_event_free(render_recovery_event)) != ISMD_SUCCESS){
      AUDIO_ERROR("ismd_event_free failed in core init!", result, audio_devh[AUDIO_DEBUG_CORE]);
   }

   os_irqlock_destroy(&audio_irq_lock);

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CORE]);
   
   return result;
}

int
audio_core_get_channel_cnt_from_config(int channel_config)
{
   int loop = 0;
   int channel_count = 0;

   for(loop = 0; loop < AUDIO_MAX_INPUT_CHANNELS; loop++) {

      if(((channel_config >> (loop * 4) ) & 0xF) != ISMD_AUDIO_CHANNEL_INVALID){
         channel_count++;
      }
   }

   return channel_count;
}

bool
audio_core_is_valid_ch_config(int channel_config)
{
   int loop = 0;
   int curr_channel = 0;
   bool ret_value = true;
   
   for(loop = 0; loop < AUDIO_MAX_INPUT_CHANNELS; loop++) {

      curr_channel = ((channel_config >> (loop * 4) ) & 0xF);

      if(( curr_channel != ISMD_AUDIO_CHANNEL_INVALID) && ( ( curr_channel < 0) || (curr_channel > 7 ))){
         ret_value = false;
         break;
      }
   }

   return ret_value;
}

//Calculate a chunk size based on audio meta-data and time period in milliseconds.
size_t
audio_core_calc_chunk_size(int sample_size, int sample_rate, int channel_count, int time_ms)
{
   size_t sample_size_bytes = 0;

   sample_size_bytes = (sample_size /8);

   return ((sample_rate * sample_size_bytes * channel_count * time_ms)/1000);
}

unsigned int
audio_core_calc_time_ms(unsigned int sample_size, unsigned int sample_rate, unsigned int channel_count, unsigned int bytes)
{
   unsigned int sample_size_bytes = 0;
   unsigned int result_ms = 0;
   
   /*Make sure we dont divide by 0 */
   if((sample_size > 0) && (sample_rate > 0) && (channel_count > 0)) {

      /*Throw a warning if we are not sample aligned.*/
      if( (bytes %((sample_size /8)*channel_count)) != 0){
         OS_PRINT("SMD AUDIO: %s: Warning num bytes is not sample aligned!", __FUNCTION__);
      }

      sample_size_bytes = (sample_size /8);
      result_ms = ((bytes * 1000) / (sample_rate * sample_size_bytes * channel_count));
   }

   return result_ms;
}

unsigned int
audio_core_bytes_to_samples(int sample_size, int channel_count, int byte_count) 
{
   int result = 0;

   /*Make sure we do not divide by zero.*/
   if((sample_size != 0) && (channel_count != 0)) {
      
      if( (byte_count %((sample_size /8)*channel_count)) != 0){
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "byte count NOT SAMPLE ALIGNED!", audio_devh[AUDIO_DEBUG_CORE]);      
      }
      result = (byte_count /((sample_size /8)*channel_count));
   }
   return result;
}

int
audio_core_samples_to_bytes(int sample_size, int channel_count, int sample_count) 
{
   return (( (sample_size /8) * channel_count) * sample_count);
}

uint64_t
audio_core_bytes_to_ticks(unsigned int sample_size, unsigned int sample_rate, unsigned int channel_count, uint64_t bytes)
{
   uint64_t result = 0;

   if(sample_size && channel_count && sample_rate) {
      result = OSAL_DIV64(((OSAL_DIV64(bytes, (uint64_t)((sample_size /8)*channel_count))) * 90000), (uint64_t)sample_rate);
   }   
   return result;  
}

uint64_t
audio_core_normalize_sample_count(uint64_t in_sample_cnt, int norm_smpl_rate, int orig_sample_rate) 
{
   uint64_t sample_count = 0; //return zero if error in calcuation occured.

   //The sample rates are equal, do nothing. 
   if(norm_smpl_rate == orig_sample_rate) {

      sample_count = in_sample_cnt;
   }

   else {

      //We cant be dividing by zero, so check for any zeros
      if(in_sample_cnt && norm_smpl_rate && orig_sample_rate) {

         sample_count = OSAL_DIV64(((uint64_t)norm_smpl_rate * in_sample_cnt), (uint64_t)orig_sample_rate);
      }
   }

   /*AUDIO_EVENT(1, audio_devh[AUDIO_DEBUG_CORE], 
      SVEN_MODULE_EVENT_AUD_IO_CORE_NORMALIZE_SAMPLES,
      (unsigned int) norm_smpl_rate, 
      (unsigned int) orig_sample_rate,
      (unsigned int) (in_sample_cnt>>32),
      (unsigned int) (in_sample_cnt), 
      (unsigned int) (sample_count>>32),
      (unsigned int) (sample_count));*/

   return sample_count;
}

ismd_result_t
audio_core_get_render_sample_count(int hw_id, uint64_t *curr_smple_cnt)
{
   return audio_render_get_samples_rendered_by_id(hw_id, curr_smple_cnt);
}

ismd_result_t
audio_core_get_render_base_numbers(int association_id, int norm_sample_rate, uint64_t *curr_smple_cnt, uint32_t *curr_lvl_in_smpls)
{
   ismd_result_t result = ISMD_ERROR_NO_DATA_AVAILABLE;
   uint64_t samples_rendered = 0;
   uint32_t curr_level_samples = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CORE]);   
   
   /* Get render base numbers here, by calling into the render */
   if((result = audio_render_get_current_status(association_id, &curr_level_samples, &samples_rendered)) == ISMD_SUCCESS) {

      if(AUDIO_NORMAL_SAMPLE_RATE != norm_sample_rate){
          /* Normalize the sample counts we are getting from the render, the render will return sample counts in terms of the AUDIO_NORMAL_SAMPLE_RATE */
         *curr_smple_cnt = audio_core_normalize_sample_count(samples_rendered, norm_sample_rate, AUDIO_NORMAL_SAMPLE_RATE);
         *curr_lvl_in_smpls = audio_core_normalize_sample_count(curr_level_samples, norm_sample_rate, AUDIO_NORMAL_SAMPLE_RATE);
      }
      else{
         *curr_smple_cnt = samples_rendered;
         *curr_lvl_in_smpls = curr_level_samples;
      }

      /* If we dont have any valid data from the render, need to return in error. */
      if((*curr_smple_cnt == 0) || (*curr_lvl_in_smpls == 0)) {
         result = ISMD_ERROR_NO_DATA_AVAILABLE;
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CORE]);

   return result;
}

ismd_result_t
audio_core_notify_event_top_half( const ismd_event_t notification_events[], ismd_audio_notification_t  event_type)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   ismd_event_t local_event = ISMD_EVENT_HANDLE_INVALID;

   if( notification_events != NULL ) {

      local_event = notification_events[event_type-1];

      if ( local_event != ISMD_EVENT_HANDLE_INVALID ) {
         result = ismd_event_strobe_nonblocking( local_event );
      }
   }

   return ( result );
}

ismd_result_t
audio_core_notify_event( const ismd_event_t notification_events[], ismd_audio_notification_t  event_type)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   ismd_event_t local_event = ISMD_EVENT_HANDLE_INVALID;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CORE]);

   OS_ASSERT( audio_core_validate_event_type(event_type) );

   if( notification_events != NULL ) {

      local_event = notification_events[event_type-1];

      if ( local_event != ISMD_EVENT_HANDLE_INVALID ) {
         result = ismd_event_strobe( local_event );
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CORE]);

   return ( result );
}


inline bool
audio_core_validate_event_type( ismd_audio_notification_t event_type ) 
{
   bool result = false;

   if ( (event_type == ISMD_AUDIO_NOTIFY_STREAM_END)            ||
        (event_type == ISMD_AUDIO_NOTIFY_RENDER_UNDERRUN)       ||
        (event_type == ISMD_AUDIO_NOTIFY_PTS_VALUE_LATE)        ||
        (event_type == ISMD_AUDIO_NOTIFY_STREAM_BEGIN)          ||
        (event_type == ISMD_AUDIO_NOTIFY_PTS_VALUE_EARLY)       ||
        (event_type == ISMD_AUDIO_NOTIFY_PTS_VALUE_RECOVERED)   ||
        (event_type == ISMD_AUDIO_NOTIFY_TAG_RECEIVED)          ||
        (event_type == ISMD_AUDIO_NOTIFY_WATERMARK)             ||
        (event_type == ISMD_AUDIO_NOTIFY_SAMPLE_RATE_CHANGE)    ||
        (event_type == ISMD_AUDIO_NOTIFY_SRC_STATUS_CHANGE)     ||
        (event_type == ISMD_AUDIO_NOTIFY_CODEC_CHANGE)          ||
        (event_type == ISMD_AUDIO_NOTIFY_SAMPLE_SIZE_CHANGE)    ||
        (event_type == ISMD_AUDIO_NOTIFY_CHANNEL_CONFIG_CHANGE) ||
        (event_type == ISMD_AUDIO_NOTIFY_CORRUPT_FRAME)         ||
        (event_type == ISMD_AUDIO_NOTIFY_SEGMENT_END)           ||
        (event_type == ISMD_AUDIO_NOTIFY_SEGMENT_START)         ||
        (event_type == ISMD_AUDIO_CAPTURE_OVERRUN)              ||
        (event_type == ISMD_AUDIO_NOTIFY_SEGMENT_END)           ||
        (event_type == ISMD_AUDIO_NOTIFY_CLIENT_ID)             ||
        (event_type == ISMD_AUDIO_NOTIFY_DECODE_ERROR)          ||
        (event_type == ISMD_AUDIO_NOTIFY_DECODE_SYNC_FOUND)     ||
        (event_type == ISMD_AUDIO_NOTIFY_DECODE_SYNC_LOST)      ||
        (event_type == ISMD_AUDIO_NOTIFY_INPUT_FULL)            ||
        (event_type == ISMD_AUDIO_NOTIFY_INPUT_EMPTY)           ||
        (event_type == ISMD_AUDIO_NOTIFY_DATA_RENDERED)         ||
        (event_type == ISMD_AUDIO_NOTIFY_PARSER_STATUS_CHANGE)  ||
        (event_type == ISMD_AUDIO_NOTIFY_TIMING_INFO_UNAVAILABLE) ||
        (event_type == ISMD_AUDIO_NOTIFY_INPUT_RECOVERED)       
      ) {
      result = true;
   }

   return ( result );
}

const char 
*audio_core_result_to_string(ismd_result_t result)
{
   const char *ch="";
   switch(result)
   {
      case ISMD_SUCCESS:                        ch="ISMD_SUCCESS"; break;
      case ISMD_ERROR_FEATURE_NOT_IMPLEMENTED:  ch="ISMD_ERROR_FEATURE_NOT_IMPLEMENTED"; break;
      case ISMD_ERROR_FEATURE_NOT_SUPPORTED:    ch="ISMD_ERROR_FEATURE_NOT_SUPPORTED"; break;
      case ISMD_ERROR_INVALID_VERBOSITY_LEVEL:  ch="ISMD_ERROR_INVALID_VERBOSITY_LEVEL"; break;
      case ISMD_ERROR_INVALID_PARAMETER:        ch="ISMD_ERROR_INVALID_PARAMETER"; break;
      case ISMD_ERROR_INVALID_HANDLE:           ch="ISMD_ERROR_INVALID_HANDLE"; break;
      case ISMD_ERROR_NO_RESOURCES:             ch="ISMD_ERROR_NO_RESOURCES"; break;
      case ISMD_ERROR_INVALID_RESOURCE:         ch="ISMD_ERROR_INVALID_RESOURCE"; break;
      case ISMD_ERROR_INVALID_QUEUE_TYPE:       ch="ISMD_ERROR_INVALID_QUEUE_TYPE"; break;
      case ISMD_ERROR_NO_DATA_AVAILABLE:        ch="ISMD_ERROR_NO_DATA_AVAILABLE"; break;
      case ISMD_ERROR_NO_SPACE_AVAILABLE:       ch="ISMD_ERROR_NO_SPACE_AVAILABLE"; break;
      case ISMD_ERROR_TIMEOUT:                  ch="ISMD_ERROR_TIMEOUT"; break;
      case ISMD_ERROR_EVENT_BUSY:               ch="ISMD_ERROR_EVENT_BUSY"; break;
      case ISMD_ERROR_OBJECT_DELETED:           ch="ISMD_ERROR_OBJECT_DELETED"; break;
      case ISMD_ERROR_ALREADY_INITIALIZED:      ch="ISMD_ERROR_ALREADY_INITIALIZED"; break;
      case ISMD_ERROR_IOCTL_FAILED:             ch="ISMD_ERROR_IOCTL_FAILED"; break;
      case ISMD_ERROR_INVALID_BUFFER_TYPE:      ch="ISMD_ERROR_INVALID_BUFFER_TYPE"; break;
      case ISMD_ERROR_INVALID_FRAME_TYPE:       ch="ISMD_ERROR_INVALID_FRAME_TYPE"; break;
      case ISMD_ERROR_QUEUE_BUSY:               ch="ISMD_ERROR_QUEUE_BUSY"; break;
      case ISMD_ERROR_NOT_FOUND:                ch="ISMD_ERROR_NOT_FOUND"; break;
      case ISMD_ERROR_OPERATION_FAILED:         ch="ISMD_ERROR_OPERATION_FAILED"; break;
      case ISMD_ERROR_PORT_BUSY:                ch="ISMD_ERROR_PORT_BUSY"; break;
      case ISMD_ERROR_NULL_POINTER:             ch="ISMD_ERROR_NULL_POINTER"; break;
      case ISMD_ERROR_INVALID_REQUEST:          ch="ISMD_ERROR_INVALID_REQUEST"; break;
      case ISMD_ERROR_UNSPECIFIED:              ch="ISMD_ERROR_UNSPECIFIED"; break;
      default:                                  ch="UNKNOWN ERROR"; break;
   }
   return ch;
}

const char 
*audio_core_gdl_result_to_string(gdl_ret_t result)
{
   const char *ch="";
   switch(result)
   {
      case GDL_SUCCESS:                         ch="GDL_SUCCESS"; break;
      case GDL_ERR_INVAL:                       ch="GDL_ERR_INVAL"; break;
      case GDL_ERR_BUSY:                        ch="GDL_ERR_BUSY"; break;
      case GDL_ERR_DISPLAY:                     ch="GDL_ERR_DISPLAY"; break;
      case GDL_ERR_SURFACE:                     ch="GDL_ERR_SURFACE"; break;
      case GDL_ERR_COMMAND:                     ch="GDL_ERR_COMMAND"; break;
      case GDL_ERR_NULL_ARG:                    ch="GDL_ERR_NULL_ARG"; break;
      case GDL_ERR_NO_MEMORY:                   ch="GDL_ERR_NO_MEMORY"; break;
      case GDL_ERR_FAILED:                      ch="GDL_ERR_FAILED"; break;
      case GDL_ERR_INTERNAL:                    ch="GDL_ERR_INTERNAL"; break;
      case GDL_ERR_NOT_IMPL:                    ch="GDL_ERR_NOT_IMPL"; break;
      case GDL_ERR_MAPPED:                      ch="GDL_ERR_MAPPED"; break;
      case GDL_ERR_NO_INIT:                     ch="GDL_ERR_NO_INIT"; break;
      case GDL_ERR_NO_HW_SUPPORT:               ch="GDL_ERR_NO_HW_SUPPORT"; break;
      case GDL_ERR_INVAL_PF:                    ch="GDL_ERR_INVAL_PF"; break;
      case GDL_ERR_INVAL_RECT:                  ch="GDL_ERR_INVAL_RECT"; break;
      case GDL_ERR_ATTR_ID:                     ch="GDL_ERR_ATTR_ID"; break;
      case GDL_ERR_ATTR_NO_SUPPORT:             ch="GDL_ERR_ATTR_NO_SUPPORT"; break;
      case GDL_ERR_ATTR_READONLY:               ch="GDL_ERR_ATTR_READONLY"; break;
      case GDL_ERR_ATTR_VALUE:                  ch="GDL_ERR_ATTR_VALUE"; break;
      case GDL_ERR_PLANE_CONFLICT:              ch="GDL_ERR_PLANE_CONFLICT"; break;
      case GDL_ERR_DISPLAY_CONFLICT:            ch="GDL_ERR_DISPLAY_CONFLICT"; break;
      case GDL_ERR_TIMEOUT:                     ch="GDL_ERR_TIMEOUT"; break;
      case GDL_ERR_MISSING_BEGIN:               ch="GDL_ERR_MISSING_BEGIN"; break;
      case GDL_ERR_PLANE_ID:                    ch="GDL_ERR_PLANE_ID"; break;
      case GDL_ERR_INVAL_PTR:                   ch="GDL_ERR_INVAL_PTR"; break;  
      case GDL_ERR_SCALING_POLICY:              ch="GDL_ERR_SCALING_POLICY"; break;
      case GDL_ERR_INVAL_IOCTL:                 ch="GDL_ERR_INVAL_IOCTL"; break;
      case GDL_ERR_SCHED_IN_ATOMIC:             ch="GDL_ERR_SCHED_IN_ATOMIC"; break;
      case GDL_ERR_MMAP:                        ch="GDL_ERR_MMAP"; break;
      case GDL_ERR_HDCP:                        ch="GDL_ERR_HDCP"; break;
      case GDL_ERR_CONFIG:                      ch="GDL_ERR_CONFIG"; break;
      case GDL_ERR_HDMI_AUDIO_PLAYBACK:         ch="GDL_ERR_HDMI_AUDIO_PLAYBACK"; break;
      case GDL_ERR_HDMI_AUDIO_BUFFER_FULL:      ch="GDL_ERR_HDMI_AUDIO_BUFFER_FULL"; break;
      case GDL_ERR_PLANE_ORIGIN_ODD:            ch="GDL_ERR_PLANE_ORIGIN_ODD"; break;
      case GDL_ERR_PLANE_HEIGHT_ODD:            ch="GDL_ERR_PLANE_HEIGHT_ODD"; break;
      case GDL_ERR_HANDLE:                      ch="GDL_ERR_HANDLE"; break;
      default:                                  ch="UNKNOWN ERROR"; break;
         
   }
   return ch;
}

const char 
*audio_core_format_to_string(ismd_audio_format_t  format)
{
   const char *ch="";
   switch(format)
   {

      case ISMD_AUDIO_MEDIA_FMT_PCM:         ch="ISMD_AUDIO_MEDIA_FMT_PCM"; break;
      case ISMD_AUDIO_MEDIA_FMT_DVD_PCM:     ch="ISMD_AUDIO_MEDIA_FMT_DVD_PCM"; break;
      case ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM:  ch="ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM"; break;
      case ISMD_AUDIO_MEDIA_FMT_MPEG:        ch="ISMD_AUDIO_MEDIA_FMT_MPEG"; break;
      case ISMD_AUDIO_MEDIA_FMT_AAC:         ch="ISMD_AUDIO_MEDIA_FMT_AAC"; break;
      case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS:    ch="ISMD_AUDIO_MEDIA_FMT_AAC_LOAS"; break;
      case ISMD_AUDIO_MEDIA_FMT_DD:          ch="ISMD_AUDIO_MEDIA_FMT_DD"; break;
      case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:     ch="ISMD_AUDIO_MEDIA_FMT_DD_PLUS"; break;
      case ISMD_AUDIO_MEDIA_FMT_TRUE_HD:     ch="ISMD_AUDIO_MEDIA_FMT_TRUE_HD"; break;
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD:      ch="ISMD_AUDIO_MEDIA_FMT_DTS_HD"; break;
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA:  ch="ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA"; break;
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA:   ch="ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA"; break;
      case ISMD_AUDIO_MEDIA_FMT_DTS:         ch="ISMD_AUDIO_MEDIA_FMT_DTS"; break;
      case ISMD_AUDIO_MEDIA_FMT_DTS_BC:      ch="ISMD_AUDIO_MEDIA_FMT_DTS_BC"; break;
      case ISMD_AUDIO_MEDIA_FMT_DTS_LBR:     ch="ISMD_AUDIO_MEDIA_FMT_DTS_LBR"; break;
      case ISMD_AUDIO_MEDIA_FMT_WM9:         ch="ISMD_AUDIO_MEDIA_FMT_WM9"; break;
      default:                               ch="UNKNOWN FORMAT"; break;
   }
   return ch;
}


bool
audio_core_is_valid_sample_rate(int sample_rate)
{
   switch (sample_rate) {
      case 8000:
      case 11025:
      case 12000:
      case 16000:
      case 22050:
      case 24000:   
      case 32000:         
      case 44100:
      case 48000:
      case 64000:      
      case 88200:
      case 96000:
      case 128000:
      case 176400:
      case 192000:
         break;
      default:
         return false;
   }

   return true;
}


bool
audio_core_is_valid_metadata(int sample_rate, int sample_size, int channel_count)
{
   bool result = false;

   result = audio_core_is_valid_sample_rate(sample_rate);

   switch (sample_size) {
      case 16:
      case 24:
      case 32:
         break;
      default:
         return false;         
   }
   
   switch (channel_count) {
      case 1:      
      case 2:
      case 3:
      case 4:
      case 5:
      case 6:         
      case 7:                  
      case 8:                  
         break;
      default:
         return false;         
   }
   
   return result;
}

bool
audio_core_is_valid_ms10_input_format(ismd_audio_format_t format)
{
   bool ret = false;
   switch(format) {
      case ISMD_AUDIO_MEDIA_FMT_AAC:
      case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS:
      case ISMD_AUDIO_MEDIA_FMT_DD:
      case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:
         ret = true;
         break;
      default:
         ret = false;
         break;
   }

   return ret;
}

bool
audio_core_is_ms10_ddc(ismd_audio_format_t format)
{
   bool ret = false;
   switch(format) {
      case ISMD_AUDIO_MEDIA_FMT_DD:
      case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:
         ret = true;
         break;
      default:
         ret = false;
         break;
   }

   return ret;
}

bool
audio_core_is_ms10_ddt(ismd_audio_format_t format)
{
   bool ret = false;
   switch(format) {
      case ISMD_AUDIO_MEDIA_FMT_AAC:
      case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS:
         ret = true;
         break;
      default:
         ret = false;
         break;
   }

   return ret;   
}


void
audio_core_reset_buffer_metadata(audio_buffer_attr_t *metadata)
{
   metadata->local_pts = ISMD_NO_PTS;
   metadata->original_pts = ISMD_NO_PTS;
   metadata->linear_pts = ISMD_NO_PTS;
   metadata->render_time_stamp = 0;
   metadata->audio_format = ISMD_AUDIO_MEDIA_FMT_INVALID;
   metadata->bitrate = 0;
   metadata->channel_config = 0xFFFFFFFF;
   metadata->channel_count = 0;
   metadata->sample_rate = 0;
   metadata->sample_size = 0;
   metadata->discontinuity = false;
   metadata->is_encoded_data = false;
   metadata->opt_metadata_offset = OPT_METADATA_INVALID;
   metadata->tags.tag_buffer_id_start = 0;
   metadata->tags.tag_buffer_id_end = 0;
   metadata->tag_input_h = AUDIO_INVALID_HANDLE;
   metadata->ad_valid = AUDIO_DESCRIPTION_NOT_VALID;
   metadata->ad_fade_byte = 0;
   metadata->ad_pan_byte = 0;
   metadata->acmod = 0;
   metadata->discontinuity_desc.action = (uint16_t)AUDIO_DISCONTINUITY_ACTION_NONE;
   metadata->discontinuity_desc.offset = 0;
   
   return;
}


ismd_result_t 
audio_core_user_gain_to_coeff_index( int  user_gain, 
                                     int *coeff_index )
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;

   if ( (user_gain >= -1450) && (user_gain <= 180) ) {
      *coeff_index = MIX_COEFF_INDEX_0_DB - ( (user_gain * MIX_COEFF_STEPS_PER_DB) / 10 );
      result = ISMD_SUCCESS;
   }

   return ( result );
}

bool
audio_core_valid_channel(ismd_audio_channel_t channel)
{
   switch(channel) {
      case ISMD_AUDIO_CHANNEL_LEFT:
      case ISMD_AUDIO_CHANNEL_RIGHT:
      case ISMD_AUDIO_CHANNEL_CENTER:
      case ISMD_AUDIO_CHANNEL_LEFT_SUR:
      case ISMD_AUDIO_CHANNEL_RIGHT_SUR:
      case ISMD_AUDIO_CHANNEL_LEFT_REAR_SUR:
      case ISMD_AUDIO_CHANNEL_RIGHT_REAR_SUR:
      case ISMD_AUDIO_CHANNEL_LFE:
         break;
      case ISMD_AUDIO_CHANNEL_INVALID:
      default:
         return false;
         break;      
   }

   return true;
}


/* Need the ATC to do an atomic write and APM to do an atomic read of the stream
   postion. We run into the case where we can get thread priority inversion if the user
   calls get_stream_position from a thread that is lower priority than the ATC, and we 
   lock the ATC stream during that call. */
void
audio_core_stream_position_copy(ismd_audio_stream_position_info_t *stream_pos_dst,  ismd_audio_stream_position_info_t *stream_pos_src)
{
   os_irqlock_local_t irqlocal;

   if((stream_pos_dst != NULL) && (stream_pos_src != NULL)){
      
      os_irqlock_acquire(&audio_irq_lock, &irqlocal);
      *stream_pos_dst = *stream_pos_src;
      os_irqlock_release(&audio_irq_lock, &irqlocal);
   }
   return;
}


performance_time_t read_hardware_counter( void )
{
   unsigned int low;
   unsigned int high;

   asm volatile ( "rdtsc" : "=a" (low), "=d" (high));  // non-serializing version.
   //asm volatile ( "rdtscp" : "=a" (low), "=d" (high) : : "%ecx");  // serializing version.

   return ( (((performance_time_t)high) << 32) | ((performance_time_t)low) );
}

void
audio_core_handle_underrun_tracking(
   int stream_h,
   ismd_event_t event, 
   int *underrun_count, 
   uint64_t *underrun_amount,  
   uint64_t drift_ticks)
{

   /* If we have hit our threshold on number of late PTS values, trigger the event.*/
   if((++*underrun_count) >= ATC_UNDERRUN_MAX_COUNT) {

      *underrun_amount = drift_ticks;      

      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_ATC], 
         SVEN_MODULE_EVENT_AUD_IO_ATC_UNDERRUN_DETECTED,
         (int) stream_h,
         (int) 0,
         (int) 0,
         (int) event, 
         (int) *underrun_amount, 0);     
      
      if(event != ISMD_EVENT_HANDLE_INVALID) {
         ismd_event_strobe(event);
      }
      *underrun_count = 0;
   }

   return;
}


void performance_counter_reset( performance_counter_t *counter )
{
   counter->count = 0;
   counter->start = (performance_time_t)0;
   counter->total = (performance_time_t)0;
   counter->min   = (performance_time_t)-1;
   counter->max   = (performance_time_t)0;
}


void performance_counter_start( performance_counter_t *counter )
{
   counter->start = read_hardware_counter();
}


void performance_counter_stop( performance_counter_t *counter )
{
   performance_time_t elapsed_time;

   if ( counter->start != (performance_time_t)0 ) {
      elapsed_time   = read_hardware_counter() - counter->start;
      counter->start = (performance_time_t)0;
      counter->min   = (elapsed_time < counter->min) ? elapsed_time : counter->min;
      counter->max   = (elapsed_time > counter->max) ? elapsed_time : counter->max;
      counter->total += elapsed_time;
      counter->count++;
   }

}

void performance_counter_print( performance_counter_t *counter, char *name )
{

   OS_PRINT( "%s: avg 0x%016llx, min 0x%016llx, max 0x%016llx, tot 0x%016llx, cnt %10d\n",
             name,
             (counter->count == 0) ? 0 : OSAL_DIV64(counter->total, counter->count),
             counter->min, 
             counter->max,
             counter->total,
             counter->count );
}




bool copy_opt_metadata( ismd_buffer_descriptor_t *dst_smd_buf, 
                        ismd_buffer_descriptor_t *src_smd_buf )
{
   bool result;
   opt_metadata_t *src_metadata;
   opt_metadata_t *dst_metadata;

   /* If there's no optional metadata in the buffer... */
   //OS_PRINT( "\n1" );
   if ( !VALID_OPT_METADATA(src_smd_buf) ) {
      SET_OPT_METADATA_OFFSET( dst_smd_buf, OPT_METADATA_INVALID);
      result = true;
   }

   /* If there's no room in the buffer to store the optional metadata... */
   else if ( (dst_smd_buf->phys.size - dst_smd_buf->phys.level) < (int)(sizeof(opt_metadata_t)) ) {
   //OS_PRINT( "2" );
      SET_OPT_METADATA_OFFSET( dst_smd_buf, OPT_METADATA_INVALID);
      result = false;
   }

   /* Otherwise, copy optional metadata from the source to destination buffer. */
   else {
   //OS_PRINT( "3\n" );
      SET_OPT_METADATA_OFFSET( dst_smd_buf, dst_smd_buf->phys.size - sizeof(opt_metadata_t) );
      src_metadata = GET_OPT_METADATA_PTR( src_smd_buf );
      dst_metadata = GET_OPT_METADATA_PTR( dst_smd_buf );
      *dst_metadata = *src_metadata;
 
      /*If we copied over the metadata need to writeback invalidate that region.*/
      if (audio_core_fast_path_enabled()) {
         cache_flush_buffer(((void*)dst_metadata), sizeof(opt_metadata_t));
      }

      result = true;
   }

   return result;
}

ismd_result_t 
audio_core_check_tags(ismd_buffer_descriptor_t *buffer_desc, ismd_dev_t input_h){
   ismd_result_t result = ISMD_SUCCESS;
   int client_id;
   
   if (ismd_tag_get_client_id(buffer_desc->unique_id, &client_id) == ISMD_SUCCESS) {
      result = audio_input_notify_event(input_h, ISMD_AUDIO_NOTIFY_CLIENT_ID);            
   } 
   
   if(ismd_tag_get_eos(buffer_desc->unique_id) == ISMD_SUCCESS){
      result = audio_input_notify_event(input_h, ISMD_AUDIO_NOTIFY_STREAM_END); 
   }

   return (result);   
}

ismd_result_t ismd_audio_buffer_dereference( ismd_buffer_handle_t buffer ) {
   ismd_result_t result = ISMD_SUCCESS;
   
   ismd_buffer_descriptor_t *buffer_desc;
   audio_buffer_attr_t *audio_buffer_attr;
   int ref_count;
   ismd_buffer_descriptor_t *tags_buffer = NULL;
   audio_buffer_attr_t *audio_tag_buf_attr;   
   bool buf_deref_needed = false;
   
   result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
   if(result == ISMD_SUCCESS){
      audio_buffer_attr = (audio_buffer_attr_t *)(buffer_desc->attributes);
      if(audio_buffer_attr->tag_input_h != AUDIO_INVALID_HANDLE){

         if(ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS, 0, &tags_buffer) != ISMD_SUCCESS){
            OS_PRINT("AUDIO WARNING: Tags buffer could not be allocated, tags notification may get missed.\n");
            buf_deref_needed = true;
         }
         else {
            audio_tag_buf_attr = (audio_buffer_attr_t *)tags_buffer->attributes;
            audio_tag_buf_attr->tag_input_h = audio_buffer_attr->tag_input_h;
            
            //Copy all the tags to our temporary buffer. 
            if(ismd_tag_copy_all(buffer, tags_buffer->unique_id) != ISMD_SUCCESS) {
               OS_PRINT("AUDIO WARNING: Could not copy over tags to temp buffer, tags notification may get missed!\n");
               buf_deref_needed = true;
            }
            else {
               result = ismd_buffer_dereference_pvt(buffer , &ref_count);
               if((result == ISMD_SUCCESS) && (ref_count == 0)){
                  if (audio_core_check_tags(tags_buffer, audio_tag_buf_attr->tag_input_h) != ISMD_SUCCESS){
                     OS_PRINT("AUDIO WARNING: audio_core_check_tags failed\n");     
                  }
               }
               audio_tag_buf_attr->tag_input_h = AUDIO_INVALID_HANDLE;
               ismd_buffer_dereference(tags_buffer->unique_id);
            }
         }
      }
      else {
         buf_deref_needed = true;   
      }
   }
   else {
      AUDIO_ERROR("ismd_buffer_find_descriptor failed in Audio", result, audio_devh[AUDIO_DEBUG_CORE]);
      buf_deref_needed = true; 
   }

   if(buf_deref_needed){
      result = ismd_buffer_dereference(buffer);   
   }
   
   return (result);
}

ismd_result_t ismd_audio_buffer_alloc_typed_direct( ismd_buffer_type_t         type,
                                              size_t                     size, 
                                              ismd_buffer_descriptor_t **buffer_descriptor ){
   ismd_result_t result = ISMD_SUCCESS;
   audio_buffer_attr_t *audio_buffer_attr;
                                              
   result = ismd_buffer_alloc_typed_direct( type, size, buffer_descriptor ); 
   if(result == ISMD_SUCCESS){
      
      audio_buffer_attr = (audio_buffer_attr_t *)((*buffer_descriptor)->attributes);
      audio_buffer_attr->tag_input_h = AUDIO_INVALID_HANDLE;
   }

   return (result);
}                                              



bool
audio_core_supported_passthrough_format(ismd_audio_format_t format)
{
   bool result = false;
   switch((int)format) {
      case ISMD_AUDIO_MEDIA_FMT_DTS:
      case ISMD_AUDIO_MEDIA_FMT_DD:
      case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_MA:
      case ISMD_AUDIO_MEDIA_FMT_DTS_HD_HRA:
      case ISMD_AUDIO_ENCODE_FMT_AC3:
      case ISMD_AUDIO_ENCODE_FMT_DTS:
      case ISMD_AUDIO_ENCODE_FMT_AAC:
      case ISMD_AUDIO_MEDIA_FMT_PCM:
      case ISMD_AUDIO_MEDIA_FMT_DVD_PCM:
      case ISMD_AUDIO_MEDIA_FMT_BLURAY_PCM:
      case ISMD_AUDIO_MEDIA_FMT_AAC:
      case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS:
         result = true;
         break;
      case ISMD_AUDIO_MEDIA_FMT_TRUE_HD:
         if(audio_pvt_available_codec(ISMD_AUDIO_ENCODE_FMT_TRUEHD_MAT)) {
            result = true;
         }
         break;
      case ISMD_AUDIO_MEDIA_FMT_DTS_LBR:   
      case ISMD_AUDIO_MEDIA_FMT_MPEG:
      case ISMD_AUDIO_MEDIA_FMT_WM9:
      case ISMD_AUDIO_MEDIA_FMT_INVALID:
      default:
         break;
   }
   
   return result; 
}

bool
audio_core_format_supports_22_05_and_11_025(ismd_audio_format_t format)
{
   /* Add formats known to support 22.05kHz and 11.025 sampling rates. */
   if ((format == ISMD_AUDIO_MEDIA_FMT_AAC)  ||
       (format == ISMD_AUDIO_MEDIA_FMT_AAC_LOAS)  ||
       (format == ISMD_AUDIO_MEDIA_FMT_MPEG) ||
       (format == ISMD_AUDIO_MEDIA_FMT_WM9)  ||
       (format == ISMD_AUDIO_MEDIA_FMT_PCM)) {
       return true;
   }
   return false;
}

void
audio_core_print_mix_config(ismd_audio_channel_mix_config_t *ch_mix_config)
{
   int input_loop = 0;
   int output_loop = 0;

   OS_PRINT("     LEFT CENTR RIGHT L_SUR R_SUR LRSUR RRSUR   LFE\n");
   for (input_loop = 0; input_loop < AUDIO_MAX_INPUT_CHANNELS; input_loop++)
   {
      OS_PRINT(" %d ", ch_mix_config->input_channels_map[input_loop].input_channel_id);
      for (output_loop = 0; output_loop < AUDIO_MAX_OUTPUT_CHANNELS; output_loop++)
      {
         OS_PRINT("%6i", ch_mix_config->input_channels_map[input_loop].output_channels_gain[output_loop]);
      }
      OS_PRINT("\n");
   }
   OS_PRINT("\n");

   return;
}

uint32_t 
audio_core_chunk_size_ticks(uint32_t chunk_size, int32_t sample_rate, int32_t sample_size, int32_t ch_count)
{
   int32_t sample_size_bytes = 0;
   uint32_t chunk_size_ticks;

   sample_size_bytes = (sample_size /8);
   
   chunk_size_ticks = ((chunk_size * 1000 * CLOCK_TICKS_PER_MS)/(sample_rate * sample_size_bytes * ch_count));

   return (chunk_size_ticks);
}

bool
audio_core_fast_path_enabled(void)
{
   return ((audio_dsp_memory_path == AUDIO_DSP_MEM_PATH_NON_COHERENT) ? true:false);
}


void
audio_core_flush_cache(void *addr, uint32_t size)
{
   if (audio_core_fast_path_enabled()) {
      cache_flush_buffer(addr, size);
      pal_flush_chipset_cache();
   }
   return;
}


/*****************************************************************************/
 
 
 
 
 
 
