/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef _AUDIO_PACKETIZER_DEFS_H_
#define _AUDIO_PACKETIZER_DEFS_H_

/** Use this switch to enable or disable packetizer optimizations. */
#define PKT_OPT 1

#define PACKETIZE_LIB_INFO_CHAR_MAX 35

#ifdef LIBRARY_COMPILE
typedef unsigned char 				bool;
typedef unsigned char 				uint8_t;     
typedef unsigned short 				uint16_t;
typedef signed int	 				int32_t;	
typedef unsigned int 				uint32_t;
#define TRUE 1
#define FALSE 0
#endif



typedef enum{
   PACKETIZE_SUCCESS = 0,
   PACKETIZE_ERROR_OPERATION_FAILED,
   PACKETIZE_ERROR_NULL_POINTER,
   PACKETIZE_ERROR_NOT_INITIALIZED,
   PACKETIZE_ERROR_INSUFFICIENT_OUTPUT_SPACE,
   PACKETIZE_ERROR_NOT_AVAILABLE = 99
}packetize_result_t;

typedef struct{
   int sample_rate_content;
   int sample_rate_transmit;
   int channel_count_transmit;
   int sample_size_transmit;
}packetize_stream_info_t;

/* Function pointers for common packetizer functions. */
typedef packetize_result_t (* packetize_get_lib_info_func_t) ( void *lib_info_string );
typedef packetize_result_t (* packetize_get_persistant_size_func_t) ( int *size );
typedef packetize_result_t (* packetize_mem_set_persistant_ptr_func_t) (void* persistant_base_addr);
typedef packetize_result_t (* packetize_get_input_bytes_req_func_t) ( int *in_bytes_req );
typedef packetize_result_t (* packetize_mem_set_input_ptr_func_t) (void *in_buf_ptr );
typedef packetize_result_t (* packetize_mem_set_output_ptr_func_t) (void *out_buf_ptr );
typedef packetize_result_t (* packetize_set_output_size_func_t) (int output_buffer_size  );
typedef packetize_result_t (* packetize_set_input_bytes_func_t) (int in_buf_bytes  );
typedef packetize_result_t (* packetize_set_input_over_func_t) (void);
typedef packetize_result_t (* packetize_get_input_bytes_consumed_func_t) (int *in_bytes_consumed);
typedef packetize_result_t (* packetize_do_execute_func_t) ( void );
typedef packetize_result_t (* packetize_get_output_bytes_func_t) ( int *output_bytes );
typedef packetize_result_t (* packetize_exe_done_query_func_t) ( int *exe_done );
typedef packetize_result_t (* packetize_set_byte_swap_func_t) ( bool byte_swap );
typedef packetize_result_t (* packetize_set_expand_to_32b_func_t) (bool expand);
typedef packetize_result_t (* packetize_get_stream_position_func_t) (int *stream_pos);
typedef packetize_result_t (* packetize_get_frame_start_stream_position_func_t) (int *stream_pos);
typedef packetize_result_t (* packetize_get_stream_info_func_t) (packetize_stream_info_t *stream_info);
#ifdef PKT_OPT
typedef void (* packetize_set_circ_info_t) (int start,int size);
#endif





#endif

