/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "audio_capture.h"
#include "audio_capture_pvt.h"
#include "audio_apm_common.h"
#include "audio_sadiv_defs.h"
#include "ismd_clock_recovery.h"

#define ISMD_AUDIO_CAPTURE_CUBBY_SIZE (64*1024)

#define AUDIO_CAPTURE_LOOP_CNT_MAX 10
static ismd_audio_capture_context_t capture_context[AUDIO_MAX_CAPTURE_DEVICES];


ismd_result_t
audio_capture_initialize(void)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_capture_t handle;
   int i2s0_bitclk_direction = 1;  // default as output to ADC
   int i2s0_msb_justified = 0;
   int i2s1_bitclk_direction = 0;  // default as input from HDMI Rx
   int i2s1_msb_justified = 0;
   int clock_recovery_mode = AUDIO_INDEPENDENT_CLOCK_RECOVERY_MODE_NORMAL;
   int spdif_clock_update_rate = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   AUDIO_CONFIG_GET_CLOCK_RECOVERY_MODE(clock_recovery_mode);
   AUDIO_CONFIG_GET_I2SC0_BIT_CLK_DIRECTION(i2s0_bitclk_direction);
   AUDIO_CONFIG_GET_I2SC0_MSB_JUSTIFIED(i2s0_msb_justified);
   AUDIO_CONFIG_GET_I2SC1_BIT_CLK_DIRECTION(i2s1_bitclk_direction);
   AUDIO_CONFIG_GET_I2SC1_MSB_JUSTIFIED(i2s1_msb_justified);
   AUDIO_CONFIG_GET_SPDIF_CLOCK_UPDATE_RATE(spdif_clock_update_rate);

   /*Initialize workload memory.*/
   OS_MEMSET(capture_context, 0, sizeof(capture_context));

   result = ISMD_SUCCESS;
   /*Initialze device variables.*/
   for(handle = 0; handle < AUDIO_MAX_CAPTURE_DEVICES; handle++){

      audio_pvt_capture_init_wl(&(capture_context[handle]));

      capture_context[handle].i2s0_bitclk_direction = i2s0_bitclk_direction;
      capture_context[handle].i2s0_msb_justified = i2s0_msb_justified;
      capture_context[handle].i2s1_bitclk_direction = i2s1_bitclk_direction;
      capture_context[handle].i2s1_msb_justified = i2s1_msb_justified;
      capture_context[handle].clock_mode = ISMD_AUDIO_CLK_LOCKED;
      capture_context[handle].clock_recovery_mode = clock_recovery_mode;
      capture_context[handle].spdif_clock_update_rate = spdif_clock_update_rate;

      /*Init semaphores*/
      if(os_mutex_init(&(capture_context[handle].lock)) != OSAL_SUCCESS){

         result = ISMD_ERROR_OPERATION_FAILED;
         AUDIO_ERROR("Semaphore init failed!", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
      }
      
   }
   
   audio_hal_capture_init();   

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
}

ismd_result_t
audio_capture_deinitialize(void)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_capture_t handle;

   /*deinitialze semaphores.*/
   for(handle = 0; handle < AUDIO_MAX_CAPTURE_DEVICES; handle++){
      os_mutex_destroy(&(capture_context[handle].lock));
   }

   audio_hal_capture_deinit();

   result = ISMD_SUCCESS;
   
   return result;
}

ismd_result_t
audio_capture_open(ismd_audio_capture_t *capture_h, int hw_id, ismd_queue_handle_t output_queue, void* input_context)
{
   int dev_index;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_capture_context_t *wl = NULL;
   ismd_audio_input_wl_t *input_wl = (ismd_audio_input_wl_t *)input_context;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);
   
   OS_ASSERT(capture_h != NULL);
   OS_ASSERT(input_context != NULL);

   result = ISMD_ERROR_NO_RESOURCES;
      
   /*Check to see if the device is available, and assign the handle.*/
   for (dev_index = 0; dev_index  < AUDIO_MAX_CAPTURE_DEVICES; dev_index ++) {
      
      wl = &(capture_context[dev_index ]);
      audio_pvt_capture_lock(wl);

      /*If device in use, return error*/
      if (wl->in_use){
         result = ISMD_ERROR_NO_RESOURCES;
         audio_pvt_capture_unlock(wl);   
         continue;
      }
      else {
         result = ISMD_SUCCESS;
         wl->in_use = true;
         *capture_h  = dev_index;
         audio_pvt_capture_unlock(wl);
         break;
      }
   }
      
   /*If the handle is still invalid, all devices are in use.*/
   if(result == ISMD_SUCCESS && ((result = audio_pvt_capture_valid_hw_id(hw_id)) == ISMD_SUCCESS)){
      
      audio_pvt_capture_lock(wl);     
      /*Fill out workload variables*/
      wl->hw_dev_id = hw_id;
      wl->output_queue = output_queue;
      wl->hal_capture_h.user_context = (void *)wl;
      wl->input_context = input_context;
      wl->processor_id = ((ismd_audio_input_wl_t*)input_context)->processor_id;
      wl->is_timed_stream = input_wl->is_timed_stream;
      wl->clock = input_wl->clock;
      wl->input_type = input_wl->input_type;
      if(hw_id == ISMD_AUDIO_HW_INPUT_I2S0){
         wl->bitclk_direction = wl->i2s0_bitclk_direction;
         wl->msb_justified = wl->i2s0_msb_justified;
      }
      else if(hw_id == ISMD_AUDIO_HW_INPUT_I2S1){
         wl->bitclk_direction = wl->i2s1_bitclk_direction;
         wl->msb_justified = wl->i2s1_msb_justified;
      }

      if((wl->clock != ISMD_CLOCK_DEV_HANDLE_INVALID) && (wl->is_timed_stream)) {
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "audio_capture_open: ISMD clock handle invalid!", audio_devh[AUDIO_DEBUG_CAPTURE]);
      }
      
      if(os_event_create(&(wl->safe_to_close_event), false) != OSAL_SUCCESS){
         AUDIO_OSAL_ERROR("os_event_create failed ", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
      }
      
      /* Buffer mode setup */
      else if((result = audio_pvt_capture_setup_linked_list_mode(wl)) != ISMD_SUCCESS){

         os_event_destroy(&wl->safe_to_close_event);
         AUDIO_ERROR("capture_setup_linked_list_mode failed!\n", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
      }
         
      audio_pvt_capture_unlock(wl);   
   }
   else {
      AUDIO_ERROR("Could not get a handle", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }
   
      
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
}

ismd_result_t
audio_capture_close(ismd_audio_capture_t capture_h)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_capture_context_t *wl = NULL;
   int osal_result;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){

      if(os_event_reset(&(wl->safe_to_close_event)) != OSAL_SUCCESS){
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "os_event_reset failed!", audio_devh[AUDIO_DEBUG_CAPTURE]);
      }

      /*Signal shutdown.*/
      wl->start_to_close = true;

      /*Stop the capture HW*/
      if((result = audio_hal_capture_stop(&(wl->hal_capture_h), true)) != ISMD_SUCCESS){
          AUDIO_ERROR( "audio_hal_capture_stop failed!", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
      }
    
      wl->samples_captured = 0;
      /* If the capture hardware is not running we will never get the set on this event, so only wait if its running.*/
      if(wl->capture_hw_started){
         // Check if the DMA link list is cleaned up  
         if(audio_hal_capture_check_dma_link_list_state(&(wl->hal_capture_h))){
            if((osal_result = os_event_hardwait(&(wl->safe_to_close_event), AUDIO_CAPTURE_MAX_WAIT_TO_CLEANUP_DMA_LL)) == OSAL_ERROR){ 
               AUDIO_ERROR( "os_event_hardwait failed in capture_close.", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
            }
            audio_hal_capture_shutdown_cleanup(&(wl->hal_capture_h));
         }
      }      

      if(os_event_destroy(&(wl->safe_to_close_event))!= OSAL_SUCCESS){
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "os_event_destroy failed in capture_close", audio_devh[AUDIO_DEBUG_CAPTURE]);
      }

      audio_pvt_hal_reset_fifo(&(wl->hal_capture_h), AUDIO_RX_CONTEXT_RX0);
      audio_hal_capture_deinit_context(&(wl->hal_capture_h));
         
      if(wl->dma_buffer_des != NULL){
         ismd_audio_buffer_dereference(wl->dma_buffer_des->unique_id);
      }     

      if(wl->cubby_buffer != NULL){
         ismd_audio_buffer_dereference(wl->cubby_buffer->unique_id);
      }

      /*Reset the workload.*/
      audio_pvt_capture_init_wl(wl);

      audio_pvt_capture_unlock(wl);
   }
   else {

      AUDIO_ERROR("capture_validate_and_get_wl failed!", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
}

ismd_result_t
audio_capture_set_state(ismd_audio_capture_t capture_h, ismd_dev_state_t state)
{
   ismd_result_t result = ISMD_ERROR_INVALID_REQUEST;
   ismd_audio_capture_context_t *wl = NULL;
   int dma_burst_size = 0;
   int dma_xburst_size = 0;
   ismd_audio_input_wl_t *input_wl;
   int osal_result;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){

      /* If we are already in the requested state return success */
      if(wl->state == state) {
         
         result = ISMD_SUCCESS;
      }
      else {

         wl->state = state;

         switch(state){
            case ISMD_DEV_STATE_PAUSE:
            case ISMD_DEV_STATE_STOP:
               if(os_event_reset(&(wl->safe_to_close_event)) != OSAL_SUCCESS){
                  AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "os_event_reset failed!", audio_devh[AUDIO_DEBUG_CAPTURE]);
               }
               if((result = audio_hal_capture_stop(&(wl->hal_capture_h), false)) != ISMD_SUCCESS){
                  AUDIO_ERROR("audio_hal_capture_stop failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
               }
               // Wait for the final DMA transaction to happen
               if((osal_result = os_event_hardwait(&(wl->safe_to_close_event), AUDIO_CAPTURE_MAX_WAIT_TO_CLEANUP_DMA_LL)) == OSAL_ERROR){ 
                  AUDIO_ERROR( "os_event_hardwait failed in capture stop.", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
               }
               if ((result = audio_hal_fifo_reset_restore_rx_registers(&(wl->hal_capture_h), wl->bitclk_direction, wl->msb_justified, wl->spdif_clock_update_rate, wl->hw_dev_id)) != ISMD_SUCCESS){
                  AUDIO_ERROR("audio_hal_fifo_reset_restore_rx_registers failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
               }
               audio_hal_capture_shutdown_cleanup(&(wl->hal_capture_h));
               wl->samples_captured = 0;
               wl->parse_pcm_count = 0; 
               wl->parse_pcm = true;
               break;

            case ISMD_DEV_STATE_PLAY:
               if (wl->sync_clock != ISMD_CLOCK_HANDLE_INVALID) {
                  clock_sync_reset( wl->sync_clock );
               }
               result = ISMD_SUCCESS;
               input_wl = (ismd_audio_input_wl_t *)wl->input_context;
               wl->input_type = input_wl->input_type;
               wl->new_segment_tagged = false;
               wl->capture_timestamp = ISMD_NO_PTS;                
               //We have all the data to get the chunk size
               wl->chunk_size_bytes = audio_core_calc_chunk_size(wl->sample_size, wl->sample_rate, wl->cap_ch_count, AUDIO_CORE_GET_CHUNK_PERIOD(wl));
               wl->chunk_size_samples = audio_core_bytes_to_samples(wl->sample_size, wl->cap_ch_count, wl->chunk_size_bytes);        
               wl->chunk_size_ticks = audio_core_chunk_size_ticks(wl->chunk_size_bytes, wl->sample_rate, wl->sample_size, wl->cap_ch_count);
               audio_hal_capture_set_chunk_ticks(&(wl->hal_capture_h), wl->chunk_size_ticks);
               if(result == ISMD_SUCCESS){
                  wl->prefill_bytes_max = CAPTURE_BUFFER_PREFILL_CHUNK * wl->chunk_size_bytes;
                  wl->prefill_milliseconds = CAPTURE_BUFFER_PREFILL_CHUNK *  AUDIO_CORE_GET_CHUNK_PERIOD(wl);
                  audio_pvt_capture_get_burst_size(wl, &dma_burst_size, &dma_xburst_size);
                  audio_hal_capture_set_dma_burst_size(&(wl->hal_capture_h), dma_burst_size, dma_xburst_size);
                  audio_hal_capture_set_rxframe_size(&(wl->hal_capture_h), wl->chunk_size_samples);
                  if (wl->chunk_size_bytes > ISMD_AUDIO_CAPTURE_CUBBY_SIZE) {
                     result = ISMD_ERROR_NO_RESOURCES;
                     AUDIO_ERROR("Chunk size bigger than CAPTURE CUBBY size!", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
                  }
                  //Need to call the callback to start the DMA's engine. 
                  audio_pvt_capture_buffer_callback((void *) wl, 0, AUDIO_CAPTURE_BUFFER_EMPTY); 
               }              
               break;

            case ISMD_DEV_STATE_INVALID:
            default:

               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("State set to INVALID in capture_set_state.\n", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
               break;
         }
      }

      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;

}

ismd_result_t
audio_capture_reset_rx_interface(ismd_audio_capture_t capture_h)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_capture_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){

      if ((result = audio_hal_fifo_reset_restore_rx_registers(&(wl->hal_capture_h), wl->bitclk_direction, wl->msb_justified, wl->spdif_clock_update_rate, wl->hw_dev_id)) != ISMD_SUCCESS){
         AUDIO_ERROR("audio_hal_fifo_reset_restore_rx_registers failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
      }

      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
}

ismd_result_t
audio_capture_set_channel_config(ismd_audio_capture_t capture_h, int ch_config, int ch_count)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_capture_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){
      wl->cap_ch_config = ch_config;
      wl->cap_ch_count = ch_count;
      result = audio_hal_capture_set_channel_configuration(&wl->hal_capture_h, ch_count); 
      if (result == ISMD_ERROR_INVALID_PARAMETER){
         AUDIO_ERROR("Invalid channel config!", ISMD_ERROR_INVALID_PARAMETER, audio_devh[AUDIO_DEBUG_CAPTURE]);
         wl->cap_ch_count = 2;
         wl->cap_ch_config = AUDIO_CHAN_CONFIG_2_CH;
         result = ISMD_SUCCESS;
      }

      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
}

ismd_result_t
audio_capture_get_channel_config(ismd_audio_capture_t capture_h, int *ch_config, int *ch_count)
{
   ismd_result_t result = ISMD_ERROR_INVALID_REQUEST;
   ismd_audio_capture_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);
   
   OS_ASSERT(ch_config != NULL);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){
      *ch_config = wl->cap_ch_config;
      *ch_count = wl->cap_ch_count;
      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
}

ismd_result_t
audio_capture_set_sample_size(ismd_audio_capture_t capture_h, int sample_size)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_capture_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){
      
      if((result = audio_hal_capture_set_sample_size(&wl->hal_capture_h, sample_size, &(wl->sample_size))) != ISMD_SUCCESS){
         AUDIO_ERROR("Invalid capture sample_size!", ISMD_ERROR_INVALID_PARAMETER, audio_devh[AUDIO_DEBUG_CAPTURE]);
         wl->sample_size = 16;
      }
      else {
         wl->actual_sample_size = sample_size;
      }

      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
}

ismd_result_t
audio_capture_get_sample_size(ismd_audio_capture_t capture_h, int *sample_size)
{
   ismd_result_t result = ISMD_ERROR_INVALID_REQUEST;
   ismd_audio_capture_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);
   
   OS_ASSERT(sample_size != NULL);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){

      *sample_size = wl->actual_sample_size;
      
      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
}

ismd_result_t
audio_capture_set_sample_rate(ismd_audio_capture_t capture_h, int sample_rate)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_capture_context_t *wl = NULL;
   ismd_audio_input_wl_t *input_wl;
   unsigned int master_clock_freq_hz;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){
      wl->sample_rate = sample_rate;
      input_wl = (ismd_audio_input_wl_t *)wl->input_context;
      master_clock_freq_hz = input_wl->processor_wl->master_clk_freq_hz;

      if(wl->bitclk_direction){
         if(master_clock_freq_hz == 0){
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("Set Audio master clock frequency using ismd_audio_configure_master_clock API!", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
            return result;
         }
         
         result = audio_pvt_get_clk_div_based_on_master_freq(wl, master_clock_freq_hz);
         if(result == ISMD_SUCCESS){
            result = audio_hal_capture_set_bit_clock_divider(&wl->hal_capture_h, wl->bit_clk_div_val, sample_rate);
         }
         
      }
      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
}

ismd_result_t
audio_capture_get_sample_rate(ismd_audio_capture_t capture_h, int *sample_rate)
{
   ismd_result_t result = ISMD_ERROR_INVALID_REQUEST;
   ismd_audio_capture_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);
   
   OS_ASSERT(sample_rate != NULL);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){
      *sample_rate = wl->sample_rate;
      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
   
}

ismd_result_t
audio_capture_set_sync_clock(ismd_audio_capture_t capture_h, ismd_clock_t sync_clock)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_capture_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){
      wl->sync_clock = sync_clock;
      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;

}


ismd_result_t
audio_capture_set_clock(ismd_audio_capture_t capture_h, ismd_clock_t clock)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_capture_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){
      wl->clock = clock;
      wl->hal_capture_h.clock = clock;
      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;

}


ismd_result_t
audio_capture_set_data_format(ismd_audio_capture_t capture_h, ismd_audio_format_t data_format)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_capture_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   switch(data_format){
      case ISMD_AUDIO_MEDIA_FMT_PCM:
      case ISMD_AUDIO_MEDIA_FMT_DD:
      case ISMD_AUDIO_MEDIA_FMT_DTS:               
         if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){
            wl->data_format = data_format;
            audio_pvt_capture_unlock(wl);
         }
         else {
            AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
         }

         break;
      default:
         break;
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;

}

ismd_result_t
audio_capture_set_output_queue(ismd_audio_capture_t capture_h, ismd_queue_handle_t output_queue)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;
   ismd_audio_capture_context_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   if((result = audio_pvt_capture_lock_and_get_wl(capture_h, &wl)) == ISMD_SUCCESS){
      wl->output_queue = output_queue;
      audio_pvt_capture_unlock(wl);
   }
   else {
      AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;
}


ismd_result_t
audio_capture_set_clock_mode(ismd_audio_clk_mode_t clock_mode)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_capture_context_t *wl = NULL;
   int handle = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_CAPTURE]);

   for (handle = 0; handle  < AUDIO_MAX_CAPTURE_DEVICES; handle ++) {
      if(capture_context[handle].in_use){
         if((result = audio_pvt_capture_lock_and_get_wl(handle, &wl)) == ISMD_SUCCESS){
            wl->clock_mode = clock_mode;
            audio_pvt_capture_unlock(wl);
         }
         else {
            AUDIO_ERROR("capture_validate_and_get_wl failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
         }
      }
      else {
         capture_context[handle].clock_mode = clock_mode;
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_CAPTURE]);

   return result;

}

void 
audio_capture_hw_set_power_mode(audio_hal_power_management_mode_t power_mode)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(ISMD_SUCCESS != (result = audio_hal_capture_set_power_mode(audio_devh[AUDIO_DEBUG_CAPTURE], power_mode))){
      AUDIO_ERROR("audio_hal_capture_gate failed", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }
}

//--------------------------------------------------------
// audio capture private functions
//--------------------------------------------------------

static void
audio_pvt_capture_init_wl( ismd_audio_capture_context_t *wl)
{
   /* bitclk_direction and msb_justified should not be initialized in this function */
   wl->processor_id = AUDIO_INVALID_HANDLE;
   wl->buffer_overflow = false;
   wl->capture_hw_started = false;
   wl->in_use = false;
   wl->state = ISMD_DEV_STATE_INVALID;
   wl->start_to_close = false;
   wl->input_context = NULL;

   wl->samples_captured = 0;
   wl->sample_rate = 48000;
   wl->sample_size = 16;
   wl->actual_sample_size = 16;
   
   wl->cap_ch_config = AUDIO_CHAN_CONFIG_2_CH;
   wl->cap_ch_count = 2;
   wl->chunk_size_bytes = 0;
   wl->chunk_size_samples = 0;
   wl->chunk_size_ticks = 0;

   wl->prefill_bytes = 0;
   wl->prefill_bytes_max = 0;
   wl->prefill_milliseconds = 0;
   wl->overflow_threshold = CAPTURE_OVERFLOW_THRESHOLD;
   
   wl->curr_buffer_cnt = 0;
   wl->data_format = ISMD_AUDIO_MEDIA_FMT_PCM;
   wl->parse_pcm = true;
   wl->parse_pcm_count = 0;
   wl->dma_buffer_des = NULL;
   wl->cubby_buffer = NULL;

   wl->output_queue = ISMD_QUEUE_HANDLE_INVALID;
   wl->bit_clk_div_val = 0;
   wl->capture_timestamp = ISMD_NO_PTS;
   wl->capture_time = ISMD_NO_PTS;
   wl->new_segment_tagged = false;
   wl->sync_clock = ISMD_CLOCK_HANDLE_INVALID;
   wl->clock = ISMD_CLOCK_DEV_HANDLE_INVALID;
   wl->input_type = AUDIO_INPUT_TYPE_OTHER;
   wl->is_timed_stream = false;
}

static ismd_result_t
audio_pvt_capture_setup_linked_list_mode( ismd_audio_capture_context_t *wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   int burst_size, xburst_size;

   // Allocate Memory for the linked list nodes.
   if((result = ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS, AUDIO_CAPTURE_LINKED_LIST_NODE_MEM_SIZE, &(wl->dma_buffer_des))) != ISMD_SUCCESS){
      AUDIO_ERROR("dma_buffer alloc failed ", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   /*Call HAL for context HW setup*/
   else {
      wl->chunk_size_bytes = audio_core_calc_chunk_size(wl->sample_size, wl->sample_rate, wl->cap_ch_count, AUDIO_CORE_GET_CHUNK_PERIOD(wl));
      wl->chunk_size_samples = audio_core_bytes_to_samples(wl->sample_size, wl->cap_ch_count, wl->chunk_size_bytes);        
      wl->chunk_size_ticks = audio_core_chunk_size_ticks(wl->chunk_size_bytes, wl->sample_rate, wl->sample_size, wl->cap_ch_count);

      if(result == ISMD_SUCCESS){
         audio_pvt_capture_get_burst_size(wl, &burst_size, &xburst_size);
         audio_hal_capture_set_rxframe_size(&(wl->hal_capture_h), wl->chunk_size_samples);
         
         result = audio_hal_capture_init_context(
            &(wl->hal_capture_h),
            (void *) wl,
            audio_devh[AUDIO_DEBUG_CAPTURE],
            wl->hw_dev_id,
            wl->dma_buffer_des->phys.base,
            wl->dma_buffer_des->virt.base,
            wl->dma_buffer_des->phys.size,
            (capture_callback_t) audio_pvt_capture_buffer_callback,
            burst_size,
            xburst_size,
            wl->chunk_size_ticks,
            wl->clock,
            wl->bitclk_direction,
            wl->msb_justified,
            wl->spdif_clock_update_rate);
      }
      
      if (result != ISMD_SUCCESS){
         AUDIO_ERROR("audio_hal_capture_init_context failed!", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
      }
   }

   /*Clean up if we failed */
   if((result != ISMD_SUCCESS) && (wl->dma_buffer_des != NULL)) {
      ismd_audio_buffer_dereference(wl->dma_buffer_des->unique_id);
   }

   return result;
}

static uint32_t
audio_pvt_capture_add_buffer_to_dma(ismd_audio_capture_context_t *wl)
{
   ismd_result_t result = ISMD_SUCCESS; 
   unsigned int bytes_sent = 0;

   if(wl->cubby_buffer == NULL) {

      // allocate smd buffer
      result = ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS_CACHED, ISMD_AUDIO_CAPTURE_CUBBY_SIZE, &wl->cubby_buffer);
      if (result != ISMD_SUCCESS) {
         AUDIO_ERROR("Failed to allocate empty buffer!", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
      }
      else {
         // empty data size
         wl->cubby_buffer->phys.level = 0;
      }
      
   }
   
   /* Make sure the cubby buffer isn't NULL, then try adding the buffer. */
   if(wl->cubby_buffer != NULL) {

      if((result = audio_hal_capture_buffer_add(&(wl->hal_capture_h),
         wl->cubby_buffer->phys.base, wl->cubby_buffer->virt.base,
         wl->chunk_size_bytes, wl->cubby_buffer->unique_id)) == ISMD_SUCCESS) {

            AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_CAPTURE],
               SVEN_MODULE_EVENT_AUD_IO_CAPTURE_ADD_BUFFER,
               (unsigned int) wl->hw_dev_id,
               (unsigned int) wl->cubby_buffer->unique_id,
               (unsigned int) wl->chunk_size_bytes, 
               (unsigned int) (wl->samples_captured>> 32), 
               (unsigned int) (wl->samples_captured), 0);

         /* set to NULL to request next buffer */
         wl->cubby_buffer = NULL;

         wl->curr_buffer_cnt++;
         bytes_sent = wl->chunk_size_bytes;
      }
      else {
         // HAL failed to add buffer
      }
   }

   if (result != ISMD_SUCCESS) {
      bytes_sent = 0;
   }

   return bytes_sent;
}

static ismd_result_t
audio_pvt_capture_rebuffer(ismd_audio_capture_context_t *wl, bool need_to_start_dma)
{
   ismd_result_t result = ISMD_SUCCESS;
   unsigned int bytes_sent = 0;
   int loop_cnt = 0;

   if(!wl->start_to_close){

      while(need_to_start_dma && !wl->capture_hw_started && loop_cnt < AUDIO_CAPTURE_LOOP_CNT_MAX) {

         /* allocate empty buffer and append to DMA */
         bytes_sent = audio_pvt_capture_add_buffer_to_dma(wl);
         wl->prefill_bytes += bytes_sent;

         /* Start capture, untill enough empty buffer in DMA link list. This is to avoid DMA run out of buffer decriptiom. */         
         if ( wl->prefill_bytes >= wl->prefill_bytes_max) {

            if((result = audio_hal_capture_start(&(wl->hal_capture_h))) == ISMD_SUCCESS) {
               AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_CAPTURE],
                  SVEN_MODULE_EVENT_AUD_IO_CAPTURE_STARTED,
                  wl->hw_dev_id,
                  wl->prefill_bytes,
                  wl->prefill_bytes_max,
                  wl->prefill_milliseconds, 0, 0);

               wl->capture_hw_started = true;
               wl->prefill_bytes = 0;
            }
            else {
               loop_cnt++;
               AUDIO_ERROR("audio_hal_capture_start FAILED!", result, audio_devh[AUDIO_DEBUG_CAPTURE]);               
            }
         }
         
      }

      if(!need_to_start_dma) {
         /* allocate empty buffer and append to DMA */
         bytes_sent = audio_pvt_capture_add_buffer_to_dma(wl);
      }
      
   }

   /* If nothing was sent return an error. */
   if(bytes_sent == 0){
      result = ISMD_ERROR_NO_DATA_AVAILABLE;
   }
   
   return result;
}

//------------------------------------------------------------------------------
// Set SMD new segment 
//------------------------------------------------------------------------------
static ismd_result_t 
audio_pvt_capture_set_new_segment(ismd_audio_capture_context_t* wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_newsegment_tag_t new_seg;
   ismd_buffer_descriptor_t *tags_buffer = NULL;

   if((result = ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS, 0, &tags_buffer)) != ISMD_SUCCESS){
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "ACAP: could not allocate buffer to set new segment tag. Tag lost!!", audio_devh[AUDIO_DEBUG_CAPTURE]);
   }
   else {
      new_seg.start = 0; // start; Need to set to 0 as application now sets the base time to only buffering time and not (current time + buffering time)
      new_seg.stop  = ISMD_NO_PTS;
      new_seg.linear_start = 0;
      new_seg.requested_rate = ISMD_NORMAL_PLAY_RATE;
      new_seg.applied_rate = ISMD_NORMAL_PLAY_RATE;
      new_seg.rate_valid = true;

      // Tag first buffer with new segment
      result = ismd_tag_set_newsegment(tags_buffer->unique_id, new_seg);
      if(result == ISMD_SUCCESS){ 
         result = ismd_queue_enqueue(wl->output_queue, tags_buffer);
      }
      else {
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "ACAP: could not set the new segment tag. Tag lost!!", audio_devh[AUDIO_DEBUG_CAPTURE]);
      }
   }   
   return result;
}

static ismd_result_t
audio_pvt_capture_push_and_flow_control(ismd_audio_capture_context_t* wl, ismd_buffer_descriptor_t* buffer)
{
   ismd_result_t result = ISMD_SUCCESS;
   bool clock_locked = true;
   bool is_primary = true;

   clock_locked = ((wl->clock_mode == ISMD_AUDIO_CLK_LOCKED) ? true : false);
   is_primary = ((wl->input_type == AUDIO_INPUT_TYPE_PRIMARY) ? true : false);
      
   if ((!wl->start_to_close) && (wl->state == ISMD_DEV_STATE_PLAY)){      
      /* safe to push */
      audio_buffer_attr_t* buf_attr = (audio_buffer_attr_t*) buffer->attributes;

         
      if ((audio_hal_capture_get_block_timestamp( &wl->hal_capture_h, &wl->capture_timestamp, clock_locked, is_primary)) != ISMD_SUCCESS){
         AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "audio_capture: timestamp not available!", audio_devh[AUDIO_DEBUG_CAPTURE]);
      }
      else if(!wl->new_segment_tagged){
         if((wl->capture_timestamp != ISMD_NO_PTS) || (!wl->is_timed_stream)){
            if(audio_pvt_capture_set_new_segment(wl) == ISMD_SUCCESS){
               wl->new_segment_tagged = true;
            }
         }
         else {
            AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_CAPTURE],
               SVEN_MODULE_EVENT_AUD_IO_CAPTURE_BUFFER_DISCARD,
               (unsigned int)wl->hw_dev_id, buffer->unique_id, buffer->phys.level, AUDIO_CAPTURE_PTS_NOT_VALID, 0, 0);
            
            ismd_audio_buffer_dereference(buffer->unique_id);
            return result;
         }
         wl->capture_time = wl->capture_timestamp;
      }
      else {
         wl->capture_time += wl->chunk_size_ticks;
      }

      if(wl->sync_clock != ISMD_CLOCK_HANDLE_INVALID){
         clock_sync_add_pair_th_safe(wl->sync_clock, wl->capture_time, wl->capture_timestamp);
      }
      else if((wl->clock_recovery_mode == AUDIO_INDEPENDENT_CLOCK_RECOVERY_MODE_PHASE_ADJUST) && (wl->clock_mode == ISMD_AUDIO_CLK_INDEPENDENT)){
         ismd_clock_adjust_phase(wl->clock, (int64_t)(wl->capture_time - wl->capture_timestamp));
      }
      
      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_CAPTURE],
                 SVEN_MODULE_EVENT_AUD_IO_CAPTURE_CLOCK_RECOVERY,
                 (unsigned int)wl->hw_dev_id, 
                 (unsigned int) (wl->capture_time >> 32), 
                 (unsigned int) (wl->capture_time),
                 (unsigned int) (wl->capture_timestamp >> 32),
                 (unsigned int) (wl->capture_timestamp), 
                 (int) (wl->capture_time - wl->capture_timestamp));
      
      buf_attr->audio_format = wl->data_format;
      buf_attr->sample_rate  = wl->sample_rate;
      buf_attr->sample_size  = wl->sample_size;
      buf_attr->channel_count = wl->cap_ch_count;
      buf_attr->linear_pts = ISMD_NO_PTS;
      buf_attr->discontinuity = 0;
      buf_attr->ad_valid = AUDIO_DESCRIPTION_NOT_VALID;
      buf_attr->local_pts = wl->capture_timestamp;
      buf_attr->original_pts = wl->capture_timestamp;
      buf_attr->render_time_stamp = 0;
      buf_attr->channel_config = wl->cap_ch_config;

      /* DMA chunk size */
      buffer->phys.level = wl->chunk_size_bytes;

      result = ismd_queue_enqueue(wl->output_queue, buffer);
      if (result != ISMD_SUCCESS) {
         /* downstream queue full or error, discard current buffer */

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_CAPTURE],
            SVEN_MODULE_EVENT_AUD_IO_CAPTURE_BUFFER_DISCARD,
            (unsigned int)wl->hw_dev_id, buffer->unique_id, buffer->phys.level, AUDIO_CAPTURE_DOWNSTREAM_QUEUE_FULL, 0, 0);

         ismd_audio_buffer_dereference(buffer->unique_id);

         /* Notify of user events of capture overrun. */
         audio_core_notify_event(((ismd_audio_input_wl_t *)wl->input_context)->notification_events, ISMD_AUDIO_CAPTURE_OVERRUN);
      }
   }
   else {
      AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_CAPTURE],
         SVEN_MODULE_EVENT_AUD_IO_CAPTURE_BUFFER_DISCARD,
         (unsigned int)wl->hw_dev_id, buffer->unique_id, buffer->phys.level, AUDIO_CAPTURE_STATE_STOP, 0, 0);
      
      audio_hal_capture_get_block_timestamp( &wl->hal_capture_h, &wl->capture_timestamp, clock_locked, is_primary);
      
      ismd_audio_buffer_dereference(buffer->unique_id);
   }

   /* return SUCCESS if ismd_queue_enqueue finished */
   return result;
}

static ismd_result_t
audio_pvt_capture_buffer_callback(void *context, int buffer_id, audio_hal_capture_event_t buf_event)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_capture_context_t *wl = ( ismd_audio_capture_context_t *)context;
   ismd_buffer_descriptor_t* buffer_to_downstream = NULL;

   switch(buf_event){

      case AUDIO_CAPTURE_BUFFER_EMPTY:
         /* start capture and buffering */
         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_CAPTURE],
            SVEN_MODULE_EVENT_AUD_IO_CAPTURE_BUFFER_EMPTY,
            (unsigned int)wl->hw_dev_id, 0, 0, 0, 0, 0);

         if( (wl->state == ISMD_DEV_STATE_PLAY) && !wl->start_to_close) {

            /* DMA is empty, HW is stopped, need to restart DMA*/
            wl->capture_hw_started = false;
            audio_pvt_capture_rebuffer(wl, true);
         }

         break;

      case AUDIO_CAPTURE_BUFFER_DONE:
         
         /* Update total samples captureed. */
         if (!wl->start_to_close) {
            wl->samples_captured += audio_core_bytes_to_samples(wl->sample_size, wl->cap_ch_count, wl->chunk_size_bytes);
         }
         
         wl->curr_buffer_cnt--;

         if (buffer_id != ISMD_BUFFER_HANDLE_INVALID
            && (result = ismd_buffer_find_descriptor(buffer_id, &buffer_to_downstream)) == ISMD_SUCCESS) {
            
            audio_pvt_capture_push_and_flow_control(wl, buffer_to_downstream);
         }
         else {
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "Invalid buffer_id failed!", audio_devh[AUDIO_DEBUG_CAPTURE]);
         }

         AUDIO_EVENT(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_CAPTURE],
            SVEN_MODULE_EVENT_AUD_IO_CAPTURE_BUFFER_DONE,
            (unsigned int) wl->hw_dev_id,
            (unsigned int) buffer_id, 
            (unsigned int) (wl->samples_captured>>32), 
            (unsigned int) wl->samples_captured, 
            (unsigned int) wl->chunk_size_bytes, 0);

         break;

      case AUDIO_CAPTURE_REQUEST_BUFFER:
         /* request a empty buffer */
         audio_pvt_capture_rebuffer(wl, false);
         break;

      case AUDIO_CAPTURE_BUFFER_LOW_WATERMARK:
         break;

      case AUDIO_CAPTURE_BUFFER_HIGH_WATERMARK:
         break;

      case AUDIO_CAPTURE_SAFE_TO_CLOSE:

         AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_CAPTURE],
            SVEN_MODULE_EVENT_AUD_IO_CAPTURE_SAFE_TO_CLOSE,
            wl->hw_dev_id,
            wl->curr_buffer_cnt, 0, 0, 0, 0);

         if(os_event_set(&(wl->safe_to_close_event)) != OSAL_SUCCESS){
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "os_event_set failed!", audio_devh[AUDIO_DEBUG_CAPTURE]);
         }
         break;

      default:
         OS_INFO("Buffer event not recognized!\n");
         break;

   }

   return result;   
}

static ismd_result_t
audio_pvt_capture_lock_and_get_wl(ismd_audio_capture_t capture_h,  ismd_audio_capture_context_t **wl)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   if (audio_pvt_capture_valid_handle(capture_h)) {

      audio_pvt_capture_lock(&(capture_context[capture_h]));

      if( capture_context[capture_h].in_use ){

         /*Return workload to caller*/
         *wl = &(capture_context[capture_h]);
         result = ISMD_SUCCESS;
      }
      else {
         audio_pvt_capture_unlock(&(capture_context[capture_h]));
         AUDIO_ERROR("Capture handle requested not in use!", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
      }

   } else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR("Invalid capture handle.", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   return result;
}

static bool
audio_pvt_capture_valid_handle( ismd_audio_capture_t capture_h)
{
   bool result = false;
   if ( (capture_h >= 0) && (capture_h < AUDIO_MAX_CAPTURE_DEVICES) ) {
      result = true;
   }
   else
      AUDIO_ERROR("Invalid Render Handle!", ISMD_ERROR_INVALID_HANDLE, audio_devh[AUDIO_DEBUG_APM] );

   return ( result );
}

static void
audio_pvt_capture_lock(ismd_audio_capture_context_t *wl)
{
   os_mutex_lock(&(wl->lock));
}

static void
audio_pvt_capture_unlock(ismd_audio_capture_context_t *wl)
{
   os_mutex_unlock(&(wl->lock));
}

static ismd_result_t
audio_pvt_capture_valid_hw_id(int hw_input_id)
{
   ismd_result_t result = ISMD_SUCCESS;

   result = audio_hal_capture_valid_hw_id(hw_input_id);
   if(result != ISMD_SUCCESS){
      AUDIO_ERROR("Invalid capture HW ID! ", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }
   
   return result;
}

static ismd_result_t
audio_pvt_get_bit_clk_div_val(ismd_audio_capture_context_t *wl, unsigned int master_clk_freq)
{
   ismd_result_t result = ISMD_SUCCESS;
   unsigned int i2s_bit_clk_rate = 64 * wl->sample_rate;
   
   switch(wl->hw_dev_id){
      case ISMD_AUDIO_HW_INPUT_I2S0:
      case ISMD_AUDIO_HW_INPUT_I2S1:         
         if((master_clk_freq % i2s_bit_clk_rate) == 0){
            wl->bit_clk_div_val = master_clk_freq/i2s_bit_clk_rate;
         }
         else{
            result = ISMD_ERROR_INVALID_PARAMETER;
         }
         break;
      default:
      break;
   }

   return result;
}

static ismd_result_t
audio_pvt_get_clk_div_based_on_master_freq(ismd_audio_capture_context_t *wl, 
                                                      unsigned int master_clk_freq)
{
   ismd_result_t result = ISMD_SUCCESS;
   unsigned int sample_rate_khz, temp_sample_rate;

   sample_rate_khz = wl->sample_rate/1000;
   temp_sample_rate = wl->sample_rate/100;
   
   switch(master_clk_freq){
      case 36864000:
         //For I2S output,  SADIV = 36864/ (64*Fs)
         if((36864%(64*sample_rate_khz)) == 0){
            wl->bit_clk_div_val = 36864/(64*sample_rate_khz);
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;   
         }
         break;
      case 24576000:
         //For I2S output,  SADIV = 24576/ (64*Fs). 
         if((24576%(64*sample_rate_khz)) == 0){
            wl->bit_clk_div_val = 24576/(64*sample_rate_khz);
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;            
         }
         break;
      case 33868800:
         //For I2S output,  SADIV = 33868.8/ (64*Fs)
         if((338688%(64*temp_sample_rate)) == 0){
            wl->bit_clk_div_val = 338688/(64*temp_sample_rate);
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;    
         }
         break;
      case 22579200:
         //For I2S output,  SADIV = 22579.2/ (64*Fs). 
         if((225792%(64*temp_sample_rate)) == 0){
            wl->bit_clk_div_val = 225792/(64*temp_sample_rate);
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;  
         }
         break;
      default:
         result = audio_pvt_get_bit_clk_div_val(wl, master_clk_freq);
         break;
   }

   if(result != ISMD_SUCCESS){
      AUDIO_ERROR("Master clock freq not correct for the sampling rate! ", result, audio_devh[AUDIO_DEBUG_CAPTURE]);
   }

   return result;
}

static ismd_result_t 
audio_pvt_capture_get_burst_size
(
   ismd_audio_capture_context_t *wl,
   int *burst_size,
   int *xburst_size
)
{
   ismd_result_t result = ISMD_SUCCESS;
   unsigned int chunk_size_bytes;
   int burst[] = {4,8,16,32,64,128};
   int i;

   if(wl != NULL){
      chunk_size_bytes = wl->chunk_size_bytes;
      *burst_size = 0;
      *xburst_size = 0;   
      for(i=5; i>=0; i--){
         if(chunk_size_bytes % burst[i] == 0){
            *burst_size = i;
            *xburst_size = i;
            break;
         }
      }
   }
   else {
      result = ISMD_ERROR_NULL_POINTER;
   }
   
   return result;   
}
