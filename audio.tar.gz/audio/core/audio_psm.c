/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



/*
   ismd_audio_psm.c

   Audio Pipeline Stage Manager (PSM) implementation.

   The audio PSM is responsible for maintaining the flow of data through the 
   audio subsystem.  The audio subsystem consists of multiple pipeline stages 
   connected together to form a complete audio pipe.  The audio PSM manages 
   the flow of data between individual pipeline stages in a consistent 
   manner so that the pipeline stages can concentrate on processing rather 
   than data flow.
*/
#include "audio_core_defs.h"
#include "audio_psm.h"
#include "audio_psm_defs.h"
#include "audio_psm_pvt.h"
#include "audio_apm_common.h"

#define LOG_ERROR 0
#define LOG_INFO_LEVEL_1 1
#define LOG_INFO_LEVEL_2 2
#define LOG_INFO_LEVEL_3 3


#define PSM_BUFFER_SIZE SMD_64KB_BUFFERS
/* Size of the buffer that would hold the pool of available PSM stages. */
#define PSM_STAGES_BUF_SIZE (256 * 1024)
#define DECODER_AUX_BUF_SIZE (384*1024) 
#define DECODE_BUF_SIZE SMD_64KB_BUFFERS
#define SRC_AUX_BUF_SIZE SMD_64KB_BUFFERS
#define MIXER_AUX_BUF_SIZE SMD_64KB_BUFFERS
#define DOWNMIXER_AUX_BUF_SIZE SMD_64KB_BUFFERS
#define SRS_AUX_BUF_SIZE SMD_64KB_BUFFERS


#define MS10_DDT_BUF_SIZE (96 * 1024)
/* DEBUG MACRO....REMOVE.*/
#define ENABLE_MY_OS_INFO 0
#define MY_OS_INFO(str, ...) \
		if (ENABLE_MY_OS_INFO) \
		{	OS_INFO(str, __VA_ARGS__); \
			OS_INFO("\n"); \
      } 

 
static audio_psm_wl_t psm_wl[AUDIO_PSM_MAX_WORKLOADS];


/* Again only one device since this corresponds to the PSM abstraction layer itself. 
	The structure is just a placeholder for all the global variables. */
static audio_psm_device_t psm_device;


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */	
ismd_result_t audio_psm_initialize( void )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   osal_result osal_res;
	
   uint32_t i;

	AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

	if (psm_device.initialized)
	{
		ismd_res = ISMD_SUCCESS;
      AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "PSM already initialized.", audio_devh[AUDIO_DEBUG_PSM] );
		goto exit;
	}

	psm_device.initialized = true;

	//Go ahead and zero out the structure memory. Can do this the first time around. 
	OS_MEMSET((char *)&psm_device, 0, sizeof(audio_psm_device_t)); 
	OS_MEMSET((char *)psm_wl, 0, sizeof(audio_psm_wl_t) * AUDIO_PSM_MAX_WORKLOADS); 

	osal_res = os_mutex_init ( &psm_device.lock);
	if ( osal_res != OSAL_SUCCESS )   //The 1 is initial value
   {
     	ismd_res = ISMD_ERROR_OPERATION_FAILED;
      AUDIO_ERROR( "psm device semaphone init failed.", osal_res, audio_devh[AUDIO_DEBUG_PSM] );
	   goto exit;
   }

   //Make sure these structures are 64 byte alligned. 
   if((sizeof(codecs_available_t) % 64) != 0) {
      OS_INFO("\n\n AUDIO FATALITY! codecs_available_t is not 64B aligned!: Off by %d bytes. Size: %d\n\n", (sizeof(codecs_available_t) % 64), sizeof(codecs_available_t));
      OS_ASSERT((sizeof(codecs_available_t) % 64) == 0);
   }
   //Make sure our metadata is not going beyond 4KB. Thats all the space we have in the 64KB buffers. 
   else if(sizeof(opt_metadata_t) > (4*1024)) {
      OS_INFO("\n\n AUDIO FATALITY! opt_metadata_t exceeds 4KB! Size: %d\n\n", sizeof(opt_metadata_t));
      OS_ASSERT((sizeof(opt_metadata_t) < (4*1024)) == 0);
   }

   //Make sure these structures are 64 byte alligned. 
   else if((sizeof(ACESYSTEM) % 64) != 0) {
      OS_INFO("\n\n AUDIO FATALITY! ACESYSTEM is not 64B aligned!: Off by %d bytes. Size: %d\n\n", (sizeof(ACESYSTEM) % 64), sizeof(ACESYSTEM));
      OS_ASSERT((sizeof(ACESYSTEM) % 64) == 0);
   }

   //Make sure these structures are 64 byte alligned. 
   else if((sizeof(audio_psm_buf_desc_t) % 64) != 0) {
      OS_INFO("\n\n AUDIO FATALITY! audio_psm_buf_desc_t is not 64B aligned!: Off by %d bytes. Size: %d\n\n", (sizeof(audio_psm_buf_desc_t) % 64), sizeof(audio_psm_buf_desc_t));
      OS_ASSERT((sizeof(audio_psm_buf_desc_t) % 64) == 0);
   }
   
   else if((sizeof(audio_psm_job_desc_t) % 64) != 0) {
      OS_INFO("\n\n AUDIO FATALITY! audio_psm_job_desc_t is not 64B aligned!: Off by %d bytes. Size: %d\n\n", (sizeof(audio_psm_job_desc_t) % 64), sizeof(audio_psm_job_desc_t));
      OS_ASSERT((sizeof(audio_psm_job_desc_t) % 64) == 0);   
   }

   else if((sizeof(audio_psm_stage_t) % 64) != 0) {
      OS_INFO("\n\n AUDIO FATALITY! audio_psm_stage_t is not 64B aligned!Off by %d bytes. Size: %d\n\n", (sizeof(audio_psm_stage_t) % 64), sizeof(audio_psm_stage_t));
      OS_ASSERT((sizeof(audio_psm_stage_t) % 64) == 0);
   }

   else if((sizeof(audio_psm_stage_parms_host_t) % 64) != 0) {
      OS_INFO("\n\n AUDIO FATALITY! audio_psm_stage_parms_host_t is not 64B aligned!Off by %d bytes. Size: %d\n\n", (sizeof(audio_psm_stage_parms_host_t) % 64), sizeof(audio_psm_stage_parms_host_t));
      OS_ASSERT((sizeof(audio_psm_stage_parms_host_t) % 64) == 0);
   }

   
   
   /* Initialize workloads. */
	for (i=0; i<AUDIO_PSM_MAX_WORKLOADS; i++)
	{		
		audio_psm_pvt_wl_reset(&(psm_wl[i])); /* Although it was memset earlier sill need this to set some variables
		                                         to non-zero default values. */
		psm_wl[i].initialized = true;
		psm_wl[i].handle = i; //important: you have assign the index here since it is used later to see whats the index of the wl is
	}


   psm_device.psm_stages_total_count = PSM_STAGES_BUF_SIZE / sizeof(audio_psm_stage_t);
   OS_ASSERT( psm_device.psm_stages_total_count );

  if(psm_device.psm_stages_total_count < PSM_MIN_STAGES_NEEDED_FOR_MAX_PROCESSORS){
   OS_PRINT("\n\n AUDIO FATALITY!NOT ENOUGH MEMORY FOR STAGE CREATION! TOTAL NUMBER OF STAGES: %d\n", psm_device.psm_stages_total_count);
   OS_ASSERT(psm_device.psm_stages_total_count >= PSM_MIN_STAGES_NEEDED_FOR_MAX_PROCESSORS);
  }

	/* --------------------------------------------------------------------------- */
	/* PSM stages buffer allocation and initialization. */
	/* --------------------------------------------------------------------------- */	
	ismd_res = ismd_audio_buffer_alloc_typed_direct ( ISMD_BUFFER_TYPE_PHYS, PSM_STAGES_BUF_SIZE, &(psm_device.psm_stages_smd_buf_desc));
   if ( ismd_res != ISMD_SUCCESS )
   {
      AUDIO_ERROR( "psm stages desc SMD buffer allocation failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
      goto exit;
   }
	OS_MEMSET(psm_device.psm_stages_smd_buf_desc->virt.base, 0, psm_device.psm_stages_smd_buf_desc->phys.size);
	psm_device.psm_stages = (audio_psm_stage_t *) psm_device.psm_stages_smd_buf_desc->virt.base;

	for (i=0; i<psm_device.psm_stages_total_count; i++)
	{
		//audio_psm_pvt_stage_reset(&(psm_device.psm_stages[i]), false); /*Not necessary since I memset earlier.*/
		psm_device.psm_stages[i].handle = i;
		/* Set the physical address. The Host side FW would minus the remap value before it passes it on to the DSP. */
		psm_device.psm_stages[i].phys_address = (void *)(psm_device.psm_stages_smd_buf_desc->phys.base + (i * sizeof(audio_psm_stage_t)));
	}
	/* --------------------------------------------------------------------------- */

	osal_res = os_event_create ( &(psm_device.io_event), 0 );
	if ( osal_res != OSAL_SUCCESS )
	{
      AUDIO_ERROR( "Could not create io_event.", osal_res, audio_devh[AUDIO_DEBUG_PSM] );
	   goto exit;
	}
	psm_device.io_event_created = true;

	osal_res = os_event_create ( &(psm_device.safe_to_close_io_thread_event), 0 );
	if ( osal_res != OSAL_SUCCESS )
	{
      AUDIO_ERROR( "Could not create safe_to_close_io_thread_event.", osal_res, audio_devh[AUDIO_DEBUG_PSM] );
	   goto exit;
	}
	psm_device.safe_to_close_io_thread_event_created = true;

	osal_res = os_event_create ( &(psm_device.input_data_event), 0 );
	if ( osal_res != OSAL_SUCCESS )
	{
      AUDIO_ERROR( "Could not create input_data_event.", osal_res, audio_devh[AUDIO_DEBUG_PSM] );
	   goto exit;
	}
	psm_device.input_data_event_created = true;
 
	osal_res = create_prioritized_thread( &(psm_device.io_thread),
                                         audio_psm_pvt_io_thread,
                                         (void *)0,
                                         0,
                                         "Audio_Pipe_Mgr" );
	if ( osal_res != OSAL_SUCCESS )
	{
      AUDIO_ERROR( "Could not create psm_io_thread.", osal_res, audio_devh[AUDIO_DEBUG_PSM] );
		goto exit;
	}
	psm_device.io_thread_created = true;
	

	/* --------------------------------------------------------------------------- */
	/* Initialize the DSP and IA. Only DSP is implemented currently. */
	/* --------------------------------------------------------------------------- */	
	ismd_res = audio_dsp_initialize ();
	if ( ismd_res != ISMD_SUCCESS )
   {
      AUDIO_ERROR( "audio dsp initialize failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
      goto exit;
   }

	/* Pass the event that the DSP can set when a input job is consumed or when a output job is available. */
	ismd_res = audio_dsp_io_event_set(&(psm_device.io_event));
	/* --------------------------------------------------------------------------- */	
	
	ismd_res = ISMD_SUCCESS;
exit:

	/* This whole cleanup thing is a big mess. How can I cleanup and cleanup routine. */
	if (ismd_res != ISMD_SUCCESS)
	{
		for (i=0; i<AUDIO_PSM_MAX_WORKLOADS; i++)
		{
			/* if the workload was initialized get the lock*/
			if (psm_wl[i].initialized)
			{
				audio_psm_pvt_wl_reset(&(psm_wl[i]));
			}
			else
			{
				audio_psm_pvt_wl_reset(&(psm_wl[i]));
			}
		}
		audio_psm_pvt_device_reset(&psm_device);		
		/* TODO: Need to know whether we have already created lock before trying to destroy it. */
		os_mutex_destroy(&(psm_device.lock)); 
	}
	
	AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */	
ismd_result_t audio_psm_deinitialize( void )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
	osal_result osal_res;
   int i;

	AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	
	
	psm_device.start_to_close_io_thread = true;
	
   /* set the event since the input thread might be stuck waiting for this event. 
   	need to notify the input thread that we are trying to close so that it would exit */	
   osal_res = os_event_set ( & ( psm_device.io_event ) );
   if ( osal_res != OSAL_SUCCESS )
   {
		AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "Could not set io_event.", audio_devh[AUDIO_DEBUG_PSM]);
      //goto exit;  //because this is deinit I want to continue on and deallocate as many resources as possible. 
   }

   osal_res = os_event_wait ( & ( psm_device.safe_to_close_io_thread_event ), EVENT_NO_TIMEOUT );
   if ( osal_res != OSAL_SUCCESS )
   {
		AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "os_event_wait on safe_to_close_io_thread_event returned failure.", audio_devh[AUDIO_DEBUG_SCRUB]);
      //goto exit;  //because this is deinit I want to continue on and deallocate as many resources as possible. 
   }
	
   /* Initialize workloads. */
   audio_psm_pvt_lock();
   for (i=0; i<AUDIO_PSM_MAX_WORKLOADS; i++) {
      
      /* if the workload was initialized get the lock*/
      if (psm_wl[i].initialized) {
         
         /*If our workload is in use, clean it up.*/
         if(psm_wl[i].in_use) {

            /* Clear the variables that would force a DSP call. */
            psm_wl[i].added = false;
            psm_wl[i].started = false;
            audio_psm_pvt_pipe_free( &psm_wl[i]);
         }

         /* Reset the workload now. */
         audio_psm_pvt_wl_reset(&(psm_wl[i]));
      }
      else{
         audio_psm_pvt_wl_reset(&(psm_wl[i]));
      }
   }
   audio_psm_pvt_unlock();

	/* --------------------------------------------------------------------------- */
	/* Deinittialize the DSP and IA. Only DSP is implemented currently. */
	/* --------------------------------------------------------------------------- */	
	ismd_res = audio_dsp_deinitialize ();
	if ( ismd_res != ISMD_SUCCESS )
   {
      AUDIO_ERROR( "audio dsp deinitialize failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
		//audio_psm_pvt_device_unlock(&psm_device);
      //goto exit;
   }

	audio_psm_pvt_device_reset(&psm_device);		
	
	/* TODO: Need to know whether we have already created lock before trying to destroy it. */
	os_mutex_destroy(&(psm_device.lock)); 

	ismd_res = ISMD_SUCCESS;

   psm_device.initialized = false;

	AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return ismd_res;
}
/* --------------------------------------------------------------------------- */

ismd_result_t audio_psm_codec_available( audio_psm_pipe_handle_t pipe_handle, uint8_t dsp_num, codecs_available_t *codec_status )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;	
   
   wl = audio_psm_pvt_wl_get ( pipe_handle );
   if ( !wl )
   {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid Handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
   else {

      audio_psm_pvt_lock();	

      if(wl->psm_impl_codec_available != NULL) {

         //Call down to implementation layer (preserve our model)
         result = wl->psm_impl_codec_available(wl->psm_impl_handle, dsp_num, codec_status);
      }
      else {
         
         //Also Need to be able to get this with out a PSM pipe handle. 
         result = audio_dsp_codec_available(pipe_handle, dsp_num, codec_status);
      }
      
      audio_psm_pvt_unlock();
   }

   return result;
}

ismd_result_t audio_psm_get_codec_ver_string( audio_psm_pipe_handle_t pipe_handle, uint8_t dsp_num, ismd_audio_format_t codec, char *codec_ver_string )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;
   
   wl = audio_psm_pvt_wl_get ( pipe_handle );
   if ( !wl )
   {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid Handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
   else {

      audio_psm_pvt_lock();	
         
      if(wl->psm_impl_codec_ver != NULL) {

         //Call down to implementation layer (preserve our model)
         result = wl->psm_impl_codec_ver(wl->psm_impl_handle, dsp_num, codec, codec_ver_string);
      }
      else {
         
         //Also Need to be able to get this with out a PSM pipe handle. 
         result = audio_dsp_get_codec_ver_string(pipe_handle, dsp_num, codec, codec_ver_string);
      }
      
      audio_psm_pvt_unlock();
   }

   return result;
}

ismd_result_t audio_psm_pipe_alloc( audio_psm_pipe_type_t   type, 
                         				audio_psm_pipe_handle_t *pipe_handle )
{
   ismd_result_t result = ISMD_ERROR_INVALID_REQUEST;
   audio_psm_wl_t 	*wl = NULL;
   int i=0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   //Make sure we have a valid handle.
   if (pipe_handle != NULL) {

      audio_psm_pvt_lock();
      /*For now just iterate through all available work loads and assign the first available one.*/
      for (i=0; i<AUDIO_PSM_MAX_WORKLOADS; i++) {
         
         wl = audio_psm_pvt_wl_get (i);
         if(NULL != wl){
            
            if (!wl->in_use) {

               //Initialze the pipe workload
               wl->in_use = true;
               wl->pipe.type = type;
               *pipe_handle = wl->handle;
               audio_psm_pvt_set_implementation_layer(wl);
               
               result = ISMD_SUCCESS;
               i = AUDIO_PSM_MAX_WORKLOADS;//Break out
            }
         }
      }
      audio_psm_pvt_unlock();

      if(result != ISMD_SUCCESS) {
         result = ISMD_ERROR_NO_RESOURCES;
         AUDIO_ERROR("No available PSM worloads.", result,  audio_devh[AUDIO_DEBUG_PSM]);
      }     
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return result;
}


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */	
ismd_result_t audio_psm_pipe_free( audio_psm_pipe_handle_t pipe_handle )
{   
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	


   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {
      
      audio_psm_pvt_lock();
      if(wl->in_use) {
         result = audio_psm_pvt_pipe_free( wl );
      }
      else {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR( "PSM pipe is not in use, cannot free pipe.", result, audio_devh[AUDIO_DEBUG_PSM] );
      }
      audio_psm_pvt_unlock();
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return result;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_psm_pipe_set_input_queue_lock( audio_psm_pipe_handle_t pipe_handle, os_mutex_t *input_queue_lock )
{   
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_wl_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();
         
      wl->input_queue_lock = input_queue_lock;

      audio_psm_pvt_unlock();
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return result;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_psm_pipe_start( audio_psm_pipe_handle_t pipe_handle )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();
      if(!wl->started) {
         
         if(!wl->pipe_buffers_allocated){
            /* Before starting we need to do some preprocessing stuff since at this point we know that the pipe is finalized. */
            if((result = audio_psm_pvt_alloc_stage_buffers( &(wl->pipe) )) != ISMD_SUCCESS) {
               AUDIO_ERROR( "audio_psm_pvt_alloc_stage_buffers failed!", result, audio_devh[AUDIO_DEBUG_PSM] );
            }
            else{
               wl->pipe_buffers_allocated = true;
            }
         }

         if(result == ISMD_SUCCESS){

            if(!wl->added) {       

               if((result = wl->psm_impl_pipe_add(&(wl->pipe), &wl->psm_impl_handle)) != ISMD_SUCCESS){
                  AUDIO_ERROR( "Could not add pipe to the PSM implementation layer.", result, audio_devh[AUDIO_DEBUG_PSM] );
               } 
               else if((result = wl->psm_impl_pipe_configure(wl->psm_impl_handle)) != ISMD_SUCCESS) {
                  AUDIO_ERROR( "PSM implementation layer configure failed!", result, audio_devh[AUDIO_DEBUG_PSM] );
               }
               else {
                  wl->added = true;
               }
            }

            //CODE REVIEW NOTE: This looks like the wrong thing to do here
            /* If the pipe needs to be re-configured go ahead the reconfigure it. This happens when a pipe is stopped, changed and started back up again. */
            else if (wl->reconfigure) {

               /* Reconfigure it. */ 
               if((result = wl->psm_impl_pipe_configure(wl->psm_impl_handle)) != ISMD_SUCCESS) {
                  AUDIO_ERROR( "PSM implementation layer configure failed!", result, audio_devh[AUDIO_DEBUG_PSM] );
               }
               wl->reconfigure = false;
            }

            if(result == ISMD_SUCCESS){
               /* Now signal to the implemenation layer to start the pipe. */
               if((result = wl->psm_impl_pipe_start(wl->psm_impl_handle)) != ISMD_SUCCESS) {
                  AUDIO_ERROR( "PSM implementation layer start failed!", result, audio_devh[AUDIO_DEBUG_PSM] );
               }
               else {
                  wl->started = true;
               }
            }
            else{
               AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL, "Could not start audio pipe!\n", audio_devh[AUDIO_DEBUG_PSM]);
            }
         }
      }
      else {
         result = ISMD_SUCCESS;//Just return success if already started
      }
      audio_psm_pvt_unlock();
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);	

   return result;
}


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */	
ismd_result_t audio_psm_pipe_stop( audio_psm_pipe_handle_t pipe_handle )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();

      if((result = audio_psm_pvt_pipe_stop( wl )) != ISMD_SUCCESS) {
            AUDIO_ERROR( "audio_psm_pvt_pipe_stop failed!", result, audio_devh[AUDIO_DEBUG_PSM] );
      }
      audio_psm_pvt_unlock();
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);	
   
   return result;
}
/* --------------------------------------------------------------------------- */	


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */	
ismd_result_t audio_psm_pipe_flush( audio_psm_pipe_handle_t pipe_handle )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;
   int i = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();
      if(wl->added) {
         
         if((result = wl->psm_impl_pipe_flush(wl->psm_impl_handle)) != ISMD_SUCCESS) {
            AUDIO_ERROR( "PSM implementation layer flush failed!", result, audio_devh[AUDIO_DEBUG_PSM] );
         }
         else {

            /*Flush out the tags queues.*/
            for (i=0; i < PSM_MAX_OUTPUT; i++) {
               if(wl->tags_queue[i] != ISMD_QUEUE_HANDLE_INVALID) {
                  ismd_queue_flush(wl->tags_queue[i]);
               }
            }
            //Reset cubby jobs. 
            for (i=0; i < PSM_PIPE_MAX_NUM_OUT_QUEUES; i++) {
               audio_psm_pvt_job_reset( &(wl->output_job[i]), true);
            }
            audio_psm_pvt_job_reset( &(wl->input_job), true);
         }
      }
      else {
         result = ISMD_SUCCESS;//Return success nothing to flush.
      }
      audio_psm_pvt_unlock();
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);	
   
   return result;
}
/* --------------------------------------------------------------------------- */	



/*
 * Retrieve the physical address of a stage.
 */
ismd_result_t 
audio_psm_pipe_get_stage_phys_address( audio_psm_stage_handle_t stage_handle, 
                                       int32_t               *stage_addr )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   *stage_addr = 0;

   AUDIO_ENTER( audio_devh[AUDIO_DEBUG_PSM] );

   if ( (stage_handle >= 0) && (stage_handle < (int)psm_device.psm_stages_total_count) ) {
      *stage_addr = (uint32_t)(psm_device.psm_stages[stage_handle].phys_address);
      result = ISMD_SUCCESS;
   }

   AUDIO_EXIT( audio_devh[AUDIO_DEBUG_PSM] );

   return ( result );
}



/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */	
ismd_result_t audio_psm_stage_add( audio_psm_pipe_handle_t           pipe_handle, 
	                         			audio_psm_stage_task_t  			stage_task,
  	                                 uint32_t 								input_count, 
	                                 uint32_t 								output_count,	                         			
	                                 audio_psm_stage_handle_t         *stage_handle)
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;
   audio_psm_stage_t *stage = NULL;
   uint32_t i=0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);

   if ( (input_count <= PSM_MAX_INPUT) && (output_count <= PSM_MAX_OUTPUT) ) {

      if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

         audio_psm_pvt_lock();

         //Make sure we havent started yet.
         if(!wl->started) {

            /* Get a free stage from the pool of stages */
            if (audio_psm_pvt_stage_get_available (&stage)) {

               /*Initialize PSM's copy of the stage params.*/
               OS_MEMSET((void*)&stage->stage_params, 0, sizeof(audio_psm_stage_params_t));
               
               *stage_handle = stage->handle;
               stage->task = stage_task;
               stage->inputs_count = input_count;
               stage->outputs_count = output_count;

               /*Keep track of how many outputs this pipe has*/
               if(stage_task == PSM_TASK_OUT) {
                  wl->num_pipe_outputs = stage->outputs_count;
               }
               
               /* Allocate buffers for the output but not for input or output stages. */
               if ( (stage_task != PSM_TASK_IN) && (stage_task != PSM_TASK_OUT) ) {
                  
                  for (i=0; i<stage->outputs_count; i++) {                  
                     if ( (result = audio_psm_pvt_buffer_allocate ( &(stage->outputs[i]), PSM_BUFFER_SIZE)) != ISMD_SUCCESS ) {
                        AUDIO_ERROR( "Buffer allocation for stage outputs failed.", result, audio_devh[AUDIO_DEBUG_PSM] );
                     }
                  }
               }
               if ( (result = audio_psm_pvt_stage_add( &(wl->pipe), stage )) != ISMD_SUCCESS ) {
                     AUDIO_ERROR( "audio_psm_pvt_stage_add failed.", result, audio_devh[AUDIO_DEBUG_PSM] );
               }
            }
            else {
               result = ISMD_ERROR_NO_RESOURCES;
               AUDIO_ERROR( "No available stages to allocate.", result, audio_devh[AUDIO_DEBUG_PSM] );
            }
         }
         else {
            result = ISMD_SUCCESS;
         }
         audio_psm_pvt_unlock();
      }
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
         AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
      }
   }
   else {
      AUDIO_ERROR( "Input or output count exceeded allowed maximum for stage.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);	
   
   return result;
}
/* --------------------------------------------------------------------------- */	


/* --------------------------------------------------------------------------- */
/* WARNING: Make sure the stage_params is fully initialized before passsing it in. */
/* --------------------------------------------------------------------------- */	
ismd_result_t audio_psm_stage_config( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      audio_psm_stage_params_t *stage_params )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;
	audio_psm_stage_t *stage = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();

      if ( (stage = audio_psm_pvt_stage_get ( stage_handle ))) {

         /*Copying over the entire stage parameters stucture.*/
         stage->stage_params = *stage_params;

         /* Copy over the the host parameters to the stage's (DSP visible) copy. */
         audio_psm_pvt_copy_htod_params(stage, stage_params, wl->started);
         
         //If the stage is started, then we need to make a call down to the DSP to notify of the new params. 
         if (wl->started) {
            
            if ((result = wl->psm_impl_stage_configure(wl->psm_impl_handle, stage->handle)) != ISMD_SUCCESS) {
               AUDIO_ERROR( "Could configure stage to the PSM implementation layer.", result, audio_devh[AUDIO_DEBUG_PSM] );		
            }
         }
         else {
            result = ISMD_SUCCESS;//Return success, since we are not started yet.
         }
      }
      
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
         AUDIO_ERROR( "Invalid Handle passed in for stage.", result, audio_devh[AUDIO_DEBUG_PSM] );
      }
      
      audio_psm_pvt_unlock();
   }
   
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return result;
}

/* --------------------------------------------------------------------------- */
/* Tells the DSP directly to invalidate and read its IA-updateable stage       */
/* paramerters, does not copy over the stage parameters again.                 */
/* --------------------------------------------------------------------------- */	
ismd_result_t audio_psm_stage_config_direct( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      audio_psm_stage_params_t *stage_params)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_wl_t *wl = NULL;
   audio_psm_stage_t *stage = NULL; 
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();

      if ( (stage = audio_psm_pvt_stage_get ( stage_handle ))) {

         /* Copy over the the host parameters to the stage's (DSP visible) copy. */
         audio_psm_pvt_copy_htod_params(stage, stage_params, wl->started);
         
         //Call down to commit the IA changes to the DSP.
         if (wl->started) {            
            if ((result = wl->psm_impl_stage_configure(wl->psm_impl_handle, stage->handle)) != ISMD_SUCCESS) {
               AUDIO_ERROR( "Couldn't configure stage to the PSM implementation layer.", result, audio_devh[AUDIO_DEBUG_PSM] );
            }
         }
      }
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
         AUDIO_ERROR( "Invalid Handle passed in for stage.", result, audio_devh[AUDIO_DEBUG_PSM] );
      }     
      audio_psm_pvt_unlock();
   }

   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);
   return result;
}


ismd_result_t audio_psm_stage_config_metadata( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      audio_psm_stage_connection_metadata_t *metadata )
{
   ismd_result_t result = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;
   audio_psm_stage_t *stage = NULL;   

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();

      if ( (stage = audio_psm_pvt_stage_get ( stage_handle ))) {

         //Copy over the connection metadata
         stage->conn_mda = *metadata;
         
         //If the stage is started, then we need to make a call down to the DSP to notify of the new params. 
         if (wl->started) {
            
            if ((result = wl->psm_impl_stage_configure(wl->psm_impl_handle, stage->handle)) != ISMD_SUCCESS) {
               AUDIO_ERROR( "Could configure stage to the PSM implementation layer.", result, audio_devh[AUDIO_DEBUG_PSM] );		
            }
         }
         else {
            result = ISMD_SUCCESS;//Return success, since we are not started yet.
         }
      }
      
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
         AUDIO_ERROR( "Invalid Handle passed in for stage.", result, audio_devh[AUDIO_DEBUG_PSM] );
      }
      
      audio_psm_pvt_unlock();
   }
   
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return result;
}
/* --------------------------------------------------------------------------- */


ismd_result_t audio_psm_stage_get_config( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      audio_psm_stage_params_t *stage_params )
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_wl_t *wl = NULL;
   audio_psm_stage_t *stage = NULL;   

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();

      if ( (stage = audio_psm_pvt_stage_get ( stage_handle ))) {

         if(wl->started) {
            if ((result = wl->psm_impl_get_stage_params(wl->psm_impl_handle, stage->handle)) != ISMD_SUCCESS) {
                  AUDIO_ERROR( "Could not get stage params from DSP!", result, audio_devh[AUDIO_DEBUG_PSM] );		
            }
         }

         /*Copy the DSP viewable parameters to the callers params.*/
         audio_psm_pvt_copy_dtoh_params(stage, stage_params);
      }     
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
         AUDIO_ERROR( "Invalid Handle passed in for stage.", result, audio_devh[AUDIO_DEBUG_PSM] );
      }      
      audio_psm_pvt_unlock();
   }
   
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return result;
}

ismd_result_t audio_psm_stage_get_config_pointer( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      audio_psm_stage_params_t **stage_params )
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_wl_t *wl = NULL;
   audio_psm_stage_t *stage = NULL;   

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();

      if ( (stage = audio_psm_pvt_stage_get ( stage_handle ))) {

         if ((result = wl->psm_impl_get_stage_params(wl->psm_impl_handle, stage->handle)) != ISMD_SUCCESS) {
               AUDIO_ERROR( "Could not get stage params from DSP!", result, audio_devh[AUDIO_DEBUG_PSM] );		
         }

         //return pointer to the current stage params.
         *stage_params = &(stage->stage_params);
      }     
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
         AUDIO_ERROR( "Invalid Handle passed in for stage.", result, audio_devh[AUDIO_DEBUG_PSM] );
      }      
      audio_psm_pvt_unlock();
   }
   
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return result;
}

ismd_result_t audio_psm_stage_get_stream_info( audio_psm_pipe_handle_t  pipe_handle, 
                                      audio_psm_stage_handle_t stage_handle, 
                                      ismd_audio_format_specific_stream_info_t *stream_info)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_wl_t *wl = NULL;
   audio_psm_stage_t *stage = NULL;   

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();

      if ( (stage = audio_psm_pvt_stage_get ( stage_handle ))) {

         //Make the call down to get the latest stream information.
         if ((result = wl->psm_impl_get_stream_info(wl->psm_impl_handle, stage->handle)) != ISMD_SUCCESS) {
               AUDIO_ERROR( "Could not get stream info from DSP!", result, audio_devh[AUDIO_DEBUG_PSM] );		
         }

         if(stage->task == PSM_TASK_DECODE) {
            *stream_info = stage->stage_params.decoder.stream_info;
         }
         else if(stage->task == PSM_TASK_PCM_DECODE) {
            *stream_info = stage->stage_params.pcm_dec.stream_info;
         }
      }     
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
         AUDIO_ERROR( "Invalid Handle passed in for stage.", result, audio_devh[AUDIO_DEBUG_PSM] );
      }      
      audio_psm_pvt_unlock();
   }
   
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return result;
}


const char 
*audio_psm_task_to_string(audio_psm_stage_task_t task)
{
   const char *ch="";
   switch(task)
   {
      case PSM_TASK_ECHO:                    ch="ECHO_STAGE"; break;
      case PSM_TASK_IN:                      ch="INPUT_STAGE"; break;
      case PSM_TASK_OUT:                     ch="OUTPUT_STAGE"; break;
      case PSM_TASK_DECODE:                  ch="DECODE_STAGE"; break;
      case PSM_TASK_ENCODE:                  ch="ENCODE_STAGE"; break;
      case PSM_TASK_MIX:                     ch="MIXER_STAGE"; break;
      case PSM_TASK_SRC:                     ch="SRC_STAGE"; break;
      case PSM_TASK_PRESRC:                  ch="PRESRC_STAGE"; break;      
      case PSM_TASK_DOWNMIX:                 ch="DOWNMIX_STAGE"; break;
      case PSM_TASK_CONVERT:                 ch="CONVERT_STAGE"; break;
      case PSM_TASK_INTERLEAVER:             ch="INTERLEVER_STAGE"; break;
      case PSM_TASK_DEINTERLEAVER:           ch="DEINTERLEAVER_STAGE"; break;
      case PSM_TASK_BM:                      ch="BASS_MANAGEMENT_STAGE"; break;
      case PSM_TASK_DM:                      ch="DELAY_MANAGEMENT_STAGE"; break;
      case PSM_TASK_DATA_DIV:                ch="DATA_DIV_STAGE"; break;
      case PSM_TASK_PCM_DECODE:              ch="PCM_DECODE_STAGE"; break;
      case PSM_TASK_PACKETIZE_ENCODED_DATA:  ch="PACKETIZER_STAGE"; break;
      case PSM_TASK_UNKNOWN:                 ch="UNKOWN_STAGE"; break;
      case PSM_TASK_MS10_DDC_SYNC:           ch="MS10 DDC FRAME SYNC STAGE";  break;
      case PSM_TASK_CAPP:                    ch="CAPP"; break;
      case PSM_TASK_SRS:                     ch="SRS"; break; 
      case PSM_TASK_IEC_PARSER:              ch="IEC_PARSING_STAGE"; break;  
      case PSM_TASK_BIT_BUCKET:              ch="BIT_BUCKET"; break;   
      default:                               ch="UNKOWN_STAGE"; break;
   }
   return ch;
}


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_psm_stage_connect( audio_psm_pipe_handle_t  pipe_handle, 
	                                      audio_psm_stage_handle_t output_stage_handle, 
	                                      int                		output_id,
	                                      audio_psm_stage_handle_t input_stage_handle,
	                                      int                		input_id )
{
   ismd_result_t result  = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;	
   audio_psm_stage_t *output_stage = NULL;
   audio_psm_stage_t *input_stage = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ((wl = audio_psm_pvt_wl_get ( pipe_handle ))) {

      audio_psm_pvt_lock();
      if(!wl->started) {

         if ( !(input_stage = audio_psm_pvt_stage_get ( input_stage_handle ))) {
            AUDIO_ERROR( "audio_psm_pvt_stage_get failed on input_stage!", result, audio_devh[AUDIO_DEBUG_PSM] );
         }
         else if ( !(output_stage = audio_psm_pvt_stage_get ( output_stage_handle ))) {
            AUDIO_ERROR( "audio_psm_pvt_stage_get failed on output_stage!", result, audio_devh[AUDIO_DEBUG_PSM] );
         }
         else {

            /* Finally do the connections here */
            input_stage->virt_inputs[input_id] = &(output_stage->outputs[output_id]);

            /* Set the physical address. Will remap later for DSP. */
            input_stage->dsp_phys_inputs[input_id] = output_stage->phys_address + ( (void *)(&(output_stage->outputs[output_id])) - (void *)output_stage );
            
            result = ISMD_SUCCESS;

         }
      }
      
      else {
         result = ISMD_ERROR_INVALID_REQUEST;
         AUDIO_ERROR( "Connot connect stages once the pipe is started!", result, audio_devh[AUDIO_DEBUG_PSM] );
      }
      audio_psm_pvt_unlock();
   }
   
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM pipe handle passed in.", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
	
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return result;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_psm_input_queue_add( audio_psm_pipe_handle_t  pipe_handle, 
			                                  ismd_queue_handle_t queue_handle, 
			                                  int output_id)
{
	ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
	audio_psm_wl_t *wl = NULL;	

	AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if((output_id < PSM_MAX_INPUT) && (output_id >= 0)) {
   
   	wl = audio_psm_pvt_wl_get ( pipe_handle );
      if ( !wl )
      {
   	   ismd_res = ISMD_ERROR_INVALID_HANDLE;
         AUDIO_ERROR( "Invalid Handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
   	   goto exit;
      }
    	audio_psm_pvt_lock();	//get the lock on the workload
   	
      /* register callback so I can handle input data */
      if((ismd_res = ismd_queue_connect_output ( 
         queue_handle, ( ismd_consumer_func_t ) 
         audio_psm_pvt_input_callback, 
         ( void * ) (&psm_device),
         3)) != ISMD_SUCCESS) { //Internal queue is 3 on the DSP only trigger when we fill up and pass 3. 

         AUDIO_ERROR( "ismd_queue_connect_output failed!", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );	
      }
      else {

         wl->input_queues[wl->input_queues_count] = queue_handle;
         wl->input_queues_out_id[wl->input_queues_count] = output_id;
         wl->input_queues_count++;
      }
      
      audio_psm_pvt_unlock();
   }
   else {
      AUDIO_ERROR( "output_id specified is invalid!", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
   }
   

   
exit:
	AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_psm_input_queue_remove( audio_psm_pipe_handle_t  pipe_handle, 
				                                  		ismd_queue_handle_t queue_handle)
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;	

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ( !(wl = audio_psm_pvt_wl_get ( pipe_handle ) ))
   {
      ismd_res = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid Handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
   }

   else 
   {
      audio_psm_pvt_lock();	//get the lock on the workload
   
      if ((ismd_res = audio_psm_pvt_input_queue_remove(wl, queue_handle)) != ISMD_SUCCESS)
      {
         AUDIO_ERROR( "Error removing queue from input queues of pipe.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
      }

      audio_psm_pvt_unlock();
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   
   return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_psm_output_queue_add( audio_psm_pipe_handle_t  pipe_handle, 
                                        ismd_queue_handle_t queue_handle,
                                        int input_id)
{
   ismd_result_t ismd_res = ISMD_SUCCESS;
   audio_psm_wl_t *wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);

   /*See if we can get the PSM handle. */
   if ( NULL != (wl = audio_psm_pvt_wl_get (pipe_handle))) {
      
      audio_psm_pvt_lock();

      wl->output_queues[wl->output_queues_count] = queue_handle;
      /* Associates the output queue with a particular input of the output stage. */
      wl->output_queue_input_id[wl->output_queues_count] = input_id;

      /*Allocate a tags queue for each output of the PSM pipe. */
      if(wl->pipe.type == PSM_PIPE_TYPE_DECODE) {
         
         if((input_id >= 0) && (input_id < PSM_MAX_OUTPUT) ) {

            /*It could be the case this output ID already has a tags queue, in that case just add a reference.*/
            if(wl->tags_queue[input_id] == ISMD_QUEUE_HANDLE_INVALID){
               if((ismd_res = ismd_queue_alloc_named(ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS, 40,"psm tags queue", 14, 0, &wl->tags_queue[input_id])) != ISMD_SUCCESS){
                  AUDIO_ERROR("tags queue alloc failed!", ismd_res, audio_devh[AUDIO_DEBUG_APM]);
               }
            }
            if(ismd_res == ISMD_SUCCESS) {
               wl->tags_queue_ref_count[input_id]++;
            }
         }
         else {
            AUDIO_ERROR("Input ID not in range to allocate tags queue for PSM output!", ismd_res, audio_devh[AUDIO_DEBUG_APM]);
         }
      }


      /* register callback so I can handle input data */
      if((ismd_res = ismd_queue_connect_input ( 
            wl->output_queues[wl->output_queues_count], 
            ( ismd_producer_func_t ) audio_psm_pvt_output_callback,
            ( void * ) (&psm_device),
            2)) != ISMD_SUCCESS) { //Internal queue to the FW is 3, trigger when 2 so that we can fill up the queue

         AUDIO_ERROR( "ismd_queue_connect_input failed!", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
      }
      
      wl->output_queues_count++;
      
      audio_psm_pvt_unlock();
   }
   else {
      ismd_res = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid PSM handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
   }
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);
   return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */
ismd_result_t audio_psm_output_queue_remove( audio_psm_pipe_handle_t  pipe_handle, 
				                                  		ismd_queue_handle_t queue_handle)
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t *wl = NULL;	

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ( !(wl = audio_psm_pvt_wl_get ( pipe_handle ) ))
   {
      ismd_res = ISMD_ERROR_INVALID_HANDLE;
      AUDIO_ERROR( "Invalid Handle passed in.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
   }

   else 
   {
      audio_psm_pvt_lock();	//get the lock on the workload
   
      if ((ismd_res = audio_psm_pvt_output_queue_remove(wl, queue_handle)) != ISMD_SUCCESS)
      {
         AUDIO_ERROR( "Error removing queue from output queues of pipe.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
      }

      audio_psm_pvt_unlock();
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   
   return ismd_res;
}
/* --------------------------------------------------------------------------- */

ismd_result_t audio_psm_output_queue_disable( audio_psm_pipe_handle_t  pipe_handle, 
				                                  		ismd_queue_handle_t queue_handle)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   audio_psm_wl_t *wl = NULL;	

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ( !(wl = audio_psm_pvt_wl_get ( pipe_handle ) )) {
      AUDIO_ERROR( "Invalid PSM pipe handle specified!", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
   else {
      audio_psm_pvt_lock();
      result = audio_psm_pvt_out_queue_dis_en(wl, queue_handle, false);
      audio_psm_pvt_unlock();
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   
   return result;
}

ismd_result_t audio_psm_output_queue_enable( audio_psm_pipe_handle_t  pipe_handle, 
				                                  		ismd_queue_handle_t queue_handle)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   audio_psm_wl_t *wl = NULL;	

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   if ( !(wl = audio_psm_pvt_wl_get ( pipe_handle ) )) {
      AUDIO_ERROR( "Invalid PSM pipe handle specified!", result, audio_devh[AUDIO_DEBUG_PSM] );
   }
   else {
      audio_psm_pvt_lock();
      result = audio_psm_pvt_out_queue_dis_en(wl, queue_handle, true);
      audio_psm_pvt_unlock();
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);		
   
   return result;
}


ismd_result_t audio_psm_buffer_allocate(audio_psm_buf_desc_t *psm_buf, int size)
{
   ismd_result_t result = ISMD_ERROR_NULL_POINTER;

   if(psm_buf != NULL){
      result = audio_psm_pvt_buffer_allocate(psm_buf, size);
   }
   return result;
}


ismd_result_t audio_psm_buffer_free(audio_psm_buf_desc_t *psm_buf)
{
   ismd_result_t result = ISMD_ERROR_NULL_POINTER;

   if(psm_buf != NULL){
      result = audio_psm_pvt_buffer_reset( psm_buf, true);
   }
   return result;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Private Functions */
/* --------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------- */
/* Reset the workload */
/* --------------------------------------------------------------------------- */

static ismd_result_t audio_psm_pvt_out_queue_dis_en(audio_psm_wl_t *wl, ismd_queue_handle_t queue_handle, bool enabled)
{
   ismd_result_t result = ISMD_ERROR_NOT_FOUND;
   uint32_t queue = 0;
   
   //Search for the queue and set the status.
   for (queue=0; queue < wl->output_queues_count; queue++) {

      if(wl->output_queues[queue] == queue_handle) {         
         wl->output_queue_enabled[queue] = enabled;
         result = ISMD_SUCCESS;
      }
   }

   return result;
}

static void audio_psm_pvt_device_reset(audio_psm_device_t *device)
{
	device->initialized = false;

	if (device->psm_stages_smd_buf_desc)
		ismd_audio_buffer_dereference (device->psm_stages_smd_buf_desc->unique_id);
	device->psm_stages_smd_buf_desc = NULL;
	device->psm_stages = NULL;
	device->psm_stages_total_count = 0;	

	if (device->input_data_event_created)
	   os_event_destroy(&(device->input_data_event));
	device->input_data_event_created = false;

	if (device->io_event_created)
	   os_event_destroy(&(device->io_event));
	device->io_event_created = false;

	if (device->io_thread_created)
		os_thread_destroy(&(device->io_thread));
	device->io_thread_created = false;

	if (device->safe_to_close_io_thread_event_created)
	   os_event_destroy(&(device->safe_to_close_io_thread_event));
	device->start_to_close_io_thread = false;
	device->safe_to_close_io_thread = false;

	device->current_input_wl_handle = 0;
	device->current_output_wl_handle = 0;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Reset the workload */
/* --------------------------------------------------------------------------- */
static void audio_psm_pvt_wl_reset(audio_psm_wl_t *wl)
{
   int i=0; 
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;

   wl->in_use = false;
   wl->started = false;
   wl->added = false;
   wl->reconfigure = false;
   wl->start_to_stop = false;
   wl->pipe_buffers_allocated = false;
   wl->input_queue_lock = NULL; //Set on pipe alloc.
   wl->num_pipe_outputs = 0;

   /* Init the output job cubby */
   OS_MEMSET(&(wl->output_job), 0, sizeof(audio_psm_job_desc_t));
   OS_MEMSET(&(wl->input_job), 0, sizeof(audio_psm_job_desc_t));
   for (i=0; i < PSM_PIPE_MAX_NUM_OUT_QUEUES; i++) {
      audio_psm_pvt_job_reset( &(wl->output_job[i]), false);
   }
   audio_psm_pvt_job_reset( &(wl->input_job), false);

   for (i=0; i < PSM_MAX_INPUT; i++) {
      wl->input_queues[i] = ISMD_QUEUE_HANDLE_INVALID;
   }
   wl->input_queues_count = 0;

   for (i=0; i < PSM_MAX_OUTPUT; i++) {
      wl->output_queues[i] = ISMD_QUEUE_HANDLE_INVALID;
      wl->output_queue_enabled[i] = true; //By default the queues are enabled.
      wl->tags_queue[i] = ISMD_QUEUE_HANDLE_INVALID;
      wl->tags_queue_ref_count[i] = 0;
   }
   wl->output_queues_count = 0;

   ismd_res = audio_psm_pvt_pipe_stages_free(&(wl->pipe));
   if (ismd_res != ISMD_SUCCESS)
   {
      AUDIO_ERROR( "Error freeing pipe.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );	
   }

}

/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Reset the stage */
/* --------------------------------------------------------------------------- */
static void audio_psm_pvt_stage_reset(audio_psm_stage_t *stage, bool deref_output_buffers)
{
   uint32_t i=0; 

   /* If it is a decode stage then make sure to deref the aux buffer. */
   if ((stage->task == PSM_TASK_DECODE) || (stage->task == PSM_TASK_ENCODE)) {
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.decoder.aux_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the aux buffer in the decode/encode stage task: %d !\n", stage->task);
      }
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.decoder.decode_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the decode buffer in the decode/encode stage task: %d !\n", stage->task);
      }
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.decoder.mda_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the mda buffer in the decode/encode stage task: %d !\n", stage->task);
      }

      if(stage->task == PSM_TASK_ENCODE){
         if(audio_psm_pvt_buffer_reset( &(stage->stage_params.decoder.encode_buffer), true ) != ISMD_SUCCESS){
            OS_PRINT("\nAUDIO: Error in freeing the encode buffer in the decode/encode stage task: %d !\n", stage->task);
         }
      }
      if(stage->task == PSM_TASK_DECODE && stage->stage_params.decoder.ms10dec_enabled
         && (stage->stage_params.decoder.host.codec.algo == ISMD_AUDIO_MEDIA_FMT_AAC || stage->stage_params.decoder.host.codec.algo == ISMD_AUDIO_MEDIA_FMT_AAC_LOAS)){
         if(audio_psm_pvt_buffer_reset( &(stage->stage_params.decoder.fifo_buffer), true ) != ISMD_SUCCESS){
            OS_PRINT("\nAUDIO: Error in freeing the encode buffer in the decode/encode stage task: %d !\n", stage->task);
         }
      }
   }

   else if ( stage->task == PSM_TASK_MIX ) {
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.mixer.aux_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the aux buffer in the Mixer stage.\n");
      }
   }

   else if ( stage->task == PSM_TASK_DOWNMIX ) {
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.downmixer.aux_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the aux buffer in the Downmixer stage task: %d !\n", stage->task);
      }
   }

   /* If it is a SRC stage then make sure to deref the aux buffer. */
   else if (stage->task == PSM_TASK_SRC)
   {
      for(i = 0; i < stage->inputs_count; i++) {
         if(audio_psm_pvt_buffer_reset( &(stage->stage_params.src.aux_buffer[i]), true ) != ISMD_SUCCESS){
            OS_PRINT("\nAUDIO: Error in freeing the aux buffer in the SRC stage task: %d !\n", stage->task);
         }
      }
   }


      /* If it is a SRS stage then make sure to deref the aux buffer. */
   if (stage->task == PSM_TASK_SRS){
      for(i = 0; i < AUDIO_SRS_MAX_OUTPUTS; i++) {
         if(audio_psm_pvt_buffer_reset( &(stage->stage_params.srs.aux_buffer[i]), true ) != ISMD_SUCCESS){
            OS_PRINT("\nAUDIO: Error in freeing the aux buffer in the SRS stage task: %d !\n", stage->task);
         }
      }
   }
   
   /* If it is a SRC stage then make sure to deref the aux buffer. */
   else if (stage->task == PSM_TASK_PRESRC)
   {
      for(i = 0; i < stage->inputs_count; i++) {
         if(audio_psm_pvt_buffer_reset( &(stage->stage_params.src.aux_buffer[i]), true )) {
            OS_PRINT("\nAUDIO: Error in freeing the aux buffer in the PRE-SRC stage task: %d !\n", stage->task);
         }
      }
   }

   /* If it is a PCM decode stage then make sure to deref the aux buffer. */
   else if (stage->task == PSM_TASK_PCM_DECODE) {
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.pcm_dec.aux_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the aux buffer in the PCM decode stage task: %d !\n", stage->task);
      }
   }

   /* If it is a custom processing stage then make sure to deref the buffers. */
   else if (stage->task == PSM_TASK_CAPP) {
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.capp.in_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the function input buffer in the capp stage task: %d !\n", stage->task);
      }
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.capp.out_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the function output buffer in the capp stage task: %d !\n", stage->task);
      }
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.capp.mda_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the metadata association buffer in the capp stage task: %d !\n", stage->task);
      }
   }

   else if (stage->task == PSM_TASK_PACKETIZE_ENCODED_DATA) {
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.packetizer.aux_buffer), true ) != ISMD_SUCCESS) {
         OS_PRINT("\nAUDIO: Error in freeing the aux buffer in the packetizer stage task: %d !\n", stage->task);
      }
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.packetizer.persistant_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the persistant mem buffer in the packetizer stage task: %d !\n", stage->task);
      }
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.packetizer.mda_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the mda buffer in the packetizer stage task: %d !\n", stage->task);
      }
   }

   else if (stage->task == PSM_TASK_WATERMARK) {
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.watermark.aux_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the Watermark aux buffer, stage task: %d !\n", stage->task);
      }
   }

   else if (stage->task == PSM_TASK_BM) {
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.bass_man.aux_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the Bass man aux buffer, stage task: %d !\n", stage->task);
      }
   }
   
   else if (stage->task == PSM_TASK_DM) {
      for(i = 0; i < AUDIO_MAX_INPUT_CHANNELS; i++) {
         if(audio_psm_pvt_buffer_reset( &(stage->stage_params.delay_mgmt.buf_mgmt[i].aux_buffer), true ) != ISMD_SUCCESS){
            OS_PRINT("\nAUDIO: Error in freeing the delay man aux buffer, stage task: %d !\n", stage->task);
         }
      }
   }
   else if (stage->task == PSM_TASK_PER_OUTPUT_DELAY) {
      for(i = 0; i < stage->outputs_count; i++)
      {
         int index = stage->conn_mda.output[i];
         if(audio_psm_pvt_buffer_reset( &(stage->stage_params.per_output_delay.output_params[index].aux_buffer), true ) != ISMD_SUCCESS){
            OS_PRINT("\nAUDIO: Error in freeing the per output delay aux buffer, stage task: %d !\n", stage->task);
         }
      }
   }
   else if (stage->task == PSM_TASK_IEC_PARSER) {
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.iec_parse.aux_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the IEC parser aux buffer, stage task: %d !\n", stage->task);
      }
   }
   else if( (stage->task == PSM_TASK_DEINTERLEAVER) && (stage->stage_params.deinterleaver.trans_protection_buffer_size > 0)) {  
      if(audio_psm_pvt_buffer_reset( &(stage->stage_params.deinterleaver.aux_buffer), true ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the deinterleaver aux buffer, stage task: %d !\n", stage->task);
      }
   }

   stage->task = PSM_TASK_UNKNOWN;
   stage->in_use = false; 

   for (i=0; i<stage->inputs_count; i++)
   {
      stage->virt_inputs[i] = NULL;
      stage->dsp_phys_inputs[i] = NULL;
      stage->input_data_new[i] = false;
   }
   stage->inputs_count = 0;

   for (i=0; i<stage->outputs_count; i++)
   {
      /* Reset the output buffers. */
      if(audio_psm_pvt_buffer_reset( &stage->outputs[i], deref_output_buffers ) != ISMD_SUCCESS){
         OS_PRINT("\nAUDIO: Error in freeing the output buffers of stage task: %d output: %d!\n", stage->task, i);
      }
   }
   stage->outputs_count = 0;	

   stage->func = NULL;
   stage->done = false;
   stage->work_to_do = false;
   stage->virt_next = NULL;	
   stage->phys_next = NULL;	
   stage->dsp_phys_next = NULL;

}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static audio_psm_wl_t *audio_psm_pvt_wl_get ( audio_psm_pipe_handle_t handle )
{
   if ( ( handle < 0 ) || ( handle > AUDIO_PSM_MAX_WORKLOADS - 1 ) )
      return NULL;
	
   return & ( psm_wl[handle] );

}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static audio_psm_wl_t *audio_psm_pvt_wl_get_by_imple_handle ( int handle )
{
	int i=0;

	for (i=0; i<AUDIO_PSM_MAX_WORKLOADS; i++)
	{
		if ( (psm_wl[i].started) && (psm_wl[i].psm_impl_handle == handle) )
			return &(psm_wl[i]);     
	}

	return NULL;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static audio_psm_stage_t *audio_psm_pvt_stage_get ( audio_psm_stage_handle_t handle )
{
   if ( ( handle < 0 ) || ( (uint32_t)handle > psm_device.psm_stages_total_count - 1 ) )
      return NULL;
	
   return & ( psm_device.psm_stages[handle] );
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static void audio_psm_pvt_lock(void)
{
   os_mutex_lock(&psm_device.lock);
}

static void audio_psm_pvt_unlock(void)
{
   os_mutex_unlock(&psm_device.lock);
}

static void audio_psm_pvt_lock_queues(os_mutex_t *lock)
{
   if(lock != NULL) {
      os_mutex_lock(lock);
   }
}

static void audio_psm_pvt_unlock_queues(os_mutex_t *lock)
{
   if(lock != NULL) {
      os_mutex_unlock(lock);
   }
}

/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static bool audio_psm_pvt_stage_get_available( audio_psm_stage_t **stage )
{
   bool ismd_res = false;
	uint32_t i; 

	/* Do I lock???*/
	for (i=0; i<psm_device.psm_stages_total_count; i++)
	{
		if (!psm_device.psm_stages[i].in_use)
		{
			*stage = &(psm_device.psm_stages[i]);
			(*stage)->in_use = true;
			ismd_res = true;
			goto exit;
		}
	}
	
exit:
   return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_psm_pvt_stage_add( audio_psm_pipe_t *pipe, audio_psm_stage_t *stage )
{
   ismd_result_t ismd_res = ISMD_SUCCESS;
   audio_psm_stage_t *cur_stage = NULL;

   //OS_PRINT("ADDED stage: %s\n", audio_psm_task_to_string(stage->task) );

   /* Is the stages linked list empty?*/
   if (!pipe->stages)
   {
      pipe->stages = stage;
      pipe->stages->virt_next = NULL;
      pipe->stages->phys_next = NULL;
      ismd_res = ISMD_SUCCESS;
   }
   else {

      cur_stage = pipe->stages;
      while(cur_stage->virt_next)
      {
         cur_stage = cur_stage->virt_next;
      }

      cur_stage->virt_next = stage;
      cur_stage->phys_next = stage->phys_address;

      //After the stage has been added explicitly NULL out the next pointers, 
      //since we are adding each new stage to the end of the linked list.
      stage->virt_next = NULL;
      stage->phys_next = NULL;
   }

   return ismd_res;
}
/* --------------------------------------------------------------------------- */


static ismd_result_t audio_psm_pvt_input_queue_remove( audio_psm_wl_t *wl, ismd_queue_handle_t queue_handle)
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   int id = 0;

   /* Don't care about return here, sometimes the queue is already freed, but always try */
   if((ismd_res = ismd_queue_disconnect_output (queue_handle)) != ISMD_SUCCESS) {
      //AUDIO_ERROR( "ismd_queue_disconnect_output failed", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
   }

   if(wl->input_queues_count > 0) {

      if ((ismd_res = audio_psm_pvt_queue_remove(wl->input_queues, wl->input_queues_out_id, wl->input_queues_count, queue_handle, &id)) != ISMD_SUCCESS) {
         AUDIO_ERROR( "Error removing queue from input queues of pipe.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
      }
      else {
         wl->input_queues_count --;
      }
   }
   else {
      wl->input_queues_count = 0;
      ismd_res = ISMD_SUCCESS;
   }

   return ismd_res;   
}

static ismd_result_t audio_psm_pvt_output_queue_remove(audio_psm_wl_t *wl, ismd_queue_handle_t queue_handle)
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   int tags_queue_index = -1;

   /* Don't care about return here, sometimes the queue is already freed, but always try */
   if((ismd_res = ismd_queue_disconnect_input (queue_handle)) != ISMD_SUCCESS) {
      //AUDIO_ERROR( "ismd_queue_disconnect_input failed", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
   }

   if(wl->output_queues_count > 0) {
      
      if ((ismd_res = audio_psm_pvt_queue_remove(wl->output_queues, wl->output_queue_input_id,
         wl->output_queues_count, queue_handle, &tags_queue_index)) != ISMD_SUCCESS)
      {
         AUDIO_ERROR( "Error removing queue from output queues of pipe.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
      }
      else {

         /*Free the tags queue if needed.*/
         if((wl->tags_queue_ref_count[tags_queue_index] == 1) && (wl->tags_queue[tags_queue_index] != ISMD_QUEUE_HANDLE_INVALID)) {
            ismd_res = ismd_queue_free(wl->tags_queue[tags_queue_index]);
            wl->tags_queue[tags_queue_index] = ISMD_QUEUE_HANDLE_INVALID;
         }
         
         /*Decrement the queue reference count.*/
         if(wl->tags_queue_ref_count[tags_queue_index] > 0) {
            wl->tags_queue_ref_count[tags_queue_index]--;
         }

         wl->output_queues_count --;
      }
   }
   else {
      wl->output_queues_count = 0;
      ismd_res = ISMD_SUCCESS;
   }
   
   return ismd_res;   
}


/* --------------------------------------------------------------------------- */
/* Comments here. */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_psm_pvt_queue_remove( ismd_queue_handle_t *queues, int *id_queue, int count, ismd_queue_handle_t queue_handle, int *id)
{
   ismd_result_t ismd_res = ISMD_SUCCESS;
   int i;

   /* Find the queue in the array of queues. */
   for (i=0; i<count; i++) {
      
      /* If found invalidate the handle and break so that the i is at the index at which the queue was found. */	
      if (queues[i] == queue_handle) {
         queues[i] = ISMD_QUEUE_HANDLE_INVALID;
         /*Return ID of the queue being removed*/
         *id = id_queue[i];
         break;
      }
   }
   /* Check to see whether we found a queue or not. */
   if (i == count) {
      ismd_res = ISMD_ERROR_NOT_FOUND;
      AUDIO_ERROR( "Queue handle not found in input queues list.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
   }
   else {

      /* If the queue count is > 1 then left shift the queue handles. */
      if ( count > 1 ) {
         for (; i<count - 1; i++)
         {
            queues[i] = queues[i+1];

            /*Need to update the queue ID as well*/
            if(id_queue != NULL) {
               id_queue[i] = id_queue[i+1];
            }
         }
         queues[i] = ISMD_QUEUE_HANDLE_INVALID;
      }
   }
   
   return ismd_res;
}
/* --------------------------------------------------------------------------- */

static void audio_psm_pvt_handle_input_tags(audio_psm_wl_t *wl, ismd_buffer_descriptor_t *buffer, unsigned int *tags, unsigned int *eos)
{  
   audio_buffer_attr_t *audio_buf_attr = NULL;
   ismd_buffer_descriptor_t *tags_buffer = NULL;
   bool copied_tags = false;
   int ref_count = 0;
   int i = 0;

   *tags = false;
   *eos = false;

   /*Get the current buffer's metadata.*/
   audio_buf_attr = (audio_buffer_attr_t *)buffer->attributes;

   /*Need to initialize these values as DSP FW depends on it for tag propagation.*/
   audio_buf_attr->tags.tag_buffer_id_start = AUDIO_TAG_BUF_ID_INVALID;
   audio_buf_attr->tags.tag_buffer_id_end = AUDIO_TAG_BUF_ID_INVALID;

   /* Need to handle tags if present. */
   if(buffer->tags_present ){

      /*Flag return value for EOS true if we have eos. This will send it to the PSM pipe.*/
      if(ismd_tag_get_eos(buffer->unique_id) == ISMD_SUCCESS){
         *eos = true;
      }

      /*If this is the decoder pipe, we are allocating a 0 sized buffer storing the 
        tags to it and tagging the buffer going to the DSP with the buffer id of the tags
        buffer so that when it appears on the output we can dequeue from the tags buffer
        and continue to propagate the tags. Some pipes can have more than one output
        so each output has a tags, queue, need to enqueue this tag to each associated 
        output tags queue.*/
      if(wl->pipe.type == PSM_PIPE_TYPE_DECODE) {
         if(ismd_audio_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS, 0, &tags_buffer) != ISMD_SUCCESS){
            OS_PRINT("AUDIO WARNING: Tags buffer could not be allocated, tags will not be available.\n");
         }
         else {
            /*After buffer alloc we have 1 reference of the tags buffer.*/
            ref_count ++;

            /*Copy all tags but EOS since it will be handled explicitly*/
            if(ismd_tag_copy_all_except_eos(buffer->unique_id, tags_buffer->unique_id, &copied_tags) != ISMD_SUCCESS) {
               OS_PRINT("AUDIO WARNING: Could not copy over tags to intermediate buffer, tag lost!\n");
            }
            
            /*Only try to enqueue if we have anything else but EOS. Since EOS is handled as a
              special case in the PSM pipelines and get propagated on its own. */
            if(copied_tags) {
               
               /*Make sure the tag has the input handle to fire events.*/
               if(audio_buf_attr->tag_input_h != AUDIO_INVALID_HANDLE){
                  ((audio_buffer_attr_t*)(tags_buffer->attributes))->tag_input_h = audio_buf_attr->tag_input_h;
                  audio_buf_attr->tag_input_h = AUDIO_INVALID_HANDLE;
               }
               
               /*Putting the tag buffer id on the start field and DSP FW will fill out start and end of out going buffer.*/
               audio_buf_attr->tags.tag_buffer_id_start = tags_buffer->unique_id;

               /*Make sure we have the tag is all output queues.*/
               for(i =0; i < PSM_MAX_OUTPUT; i++) {
                  if(wl->tags_queue[i] != ISMD_QUEUE_HANDLE_INVALID) {

                     if(ismd_buffer_add_reference(tags_buffer->unique_id) == ISMD_SUCCESS) {
                        ref_count++;
               
                        if(ismd_queue_enqueue(wl->tags_queue[i], tags_buffer) != ISMD_SUCCESS){
                           OS_PRINT("AUDIO WARNING: Tags buffer could not be enqueued, tag lost!\n");
                        }
                        else{
                           //OS_PRINT("INPUT TAG: %d, level: %d\n\n", audio_buf_attr->tags.tag_buffer_id_start, buffer->phys.level);
                           *tags = true;
                           ref_count--;
                        }  
                     }
                  }
               }
            }
            /*Clear out dangling tags buffer references*/
            for(i =0; i < ref_count; i++) {
               ismd_audio_buffer_dereference(tags_buffer->unique_id);
            }
         }
      }
      
      /* If this is the pipe after the ATC, need to fire input related events.*/
      if(wl->pipe.type == PSM_PIPE_TYPE_POST_ATC) {
         if(audio_buf_attr->tag_input_h != AUDIO_INVALID_HANDLE){
            if (audio_core_check_tags(buffer, audio_buf_attr->tag_input_h) != ISMD_SUCCESS){
               OS_PRINT("AUDIO WARNING: audio_core_check_tags failed\n");    
            }
            audio_buf_attr->tag_input_h = AUDIO_INVALID_HANDLE;
         }  
      }
   }
   return;
}

static void audio_psm_pvt_handle_output_tags(ismd_buffer_descriptor_t *buffer, ismd_queue_handle_t tags_queue)
{  
   audio_buffer_attr_t *audio_buf_attr = NULL;
   audio_buffer_attr_t *audio_tag_buf_attr = NULL;
   ismd_buffer_descriptor_t *tags_buffer = NULL;
   int count = 0;
   ismd_result_t result = ISMD_SUCCESS;

    if((buffer != NULL) && (tags_queue != ISMD_QUEUE_HANDLE_INVALID)){
      
      audio_buf_attr = (audio_buffer_attr_t *)buffer->attributes;

      audio_buf_attr->tag_input_h = AUDIO_INVALID_HANDLE;
      
      /*If we have a start range, we have at least 1 tag.*/
      if((audio_buf_attr->tags.tag_buffer_id_start != AUDIO_TAG_BUF_ID_INVALID) && (audio_buf_attr->tags.tag_buffer_id_start != 0)){
         do{         
            if((result = ismd_queue_dequeue(tags_queue, &tags_buffer)) == ISMD_SUCCESS){

               //Do a sanity check on the first buffer.
               if(!count && (audio_buf_attr->tags.tag_buffer_id_start != tags_buffer->unique_id)){
                  OS_PRINT("\nAUDIO WARNING: Start tags buffer id is incorrect!\n");   
               }
               count++;
               if(ismd_tag_copy_all(tags_buffer->unique_id, buffer->unique_id) != ISMD_SUCCESS) {
                  OS_PRINT("\nAUDIO WARNING: Could not copy over tags to output buffer, tag lost!\n");
               }
               
               audio_tag_buf_attr = (audio_buffer_attr_t *)tags_buffer->attributes;
               
               if(audio_tag_buf_attr->tag_input_h != AUDIO_INVALID_HANDLE){
                  audio_buf_attr->tag_input_h = audio_tag_buf_attr->tag_input_h;
                  audio_tag_buf_attr->tag_input_h = AUDIO_INVALID_HANDLE;
               }

               //Deref the 0 sized buffer from the tags queue. 
               ismd_audio_buffer_dereference(tags_buffer->unique_id);
               //OS_PRINT("OUTPUT TAG: cnt: %d, %d, end: %d\n\n", count, tags_buffer->unique_id, audio_buf_attr->tags.tag_buffer_id_end);         
            }
            //We shouldnt hit this ever, so if we do something is wrong!
            else {
               OS_PRINT("\nAUDIO WARNING: Tags buffer could not be dequeued, tags lost!Result: %s\n", ismd_result_to_string(result));
               audio_buf_attr->tags.tag_buffer_id_end = AUDIO_TAG_BUF_ID_INVALID;
               break;
            }   
         }while((audio_buf_attr->tags.tag_buffer_id_end != tags_buffer->unique_id) && (audio_buf_attr->tags.tag_buffer_id_end != AUDIO_TAG_BUF_ID_INVALID));
      }
    }
    
   return;
}

/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_psm_pvt_job_get_input ( audio_psm_wl_t *wl )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   ismd_result_t final_result = ISMD_ERROR_OPERATION_FAILED;
   uint32_t i=0;
   ismd_buffer_descriptor_t *smd_buf_desc = NULL;
   audio_buffer_attr_t *audio_buf_attr = NULL;
	

   /* TODO: Before dequeuing the buffers I need to look at 2 things. 
   	1. Check to see whether there is space in the input queue of the implementation layer. 
   	2. Check to see whether the output queue has space to accomodate the buffer before sending it for processing. */
   if ( (wl->started) && (!wl->start_to_stop) ) {

      //lock the queues from ATC to know we are dequeue-ing.
      audio_psm_pvt_lock_queues(wl->input_queue_lock);   
   	/* Dequeue input buffers */
   	for (i=0; i<wl->input_queues_count; i++)
   	{				
   		ismd_res = ismd_queue_dequeue ( wl->input_queues[i], &smd_buf_desc );
   		if ( ismd_res == ISMD_SUCCESS )
   		{              
   			audio_buf_attr = ( audio_buffer_attr_t* ) ( smd_buf_desc->attributes );
   			OS_ASSERT(audio_buf_attr);

            /*Handle tags and eos specifically. This will set the tags and eos flags.*/
            audio_psm_pvt_handle_input_tags(wl, smd_buf_desc, &wl->input_job.buffers[i].tags, &wl->input_job.buffers[i].eos);

            audio_buf_attr->tag_input_h = AUDIO_INVALID_HANDLE;
   			wl->input_job.buffers[i].in_use = true;
   			wl->input_job.buffers[i].level = smd_buf_desc->phys.level;
   			wl->input_job.buffers[i].size = smd_buf_desc->phys.size;
   			wl->input_job.buffers[i].smd_buf_desc = (void *)smd_buf_desc;   
            wl->input_job.buffers[i].output_id = (uint8_t)wl->input_queues_out_id[i];//Associate the output ID so it knows which path it should take in the FW. 
            
            /* Copy over the metadata structure because we cannot access the smd_buf_desc pointer from within the DSP. */
            wl->input_job.buffers[i].metadata = *(audio_buf_attr);
            
            final_result = ISMD_SUCCESS; // we have at least one buffer so flag success.
   		}

           /* Dequeue failed here, no buffer available.*/
   		else 
   		{
            wl->input_job.buffers[i].output_id = (uint8_t)wl->input_queues_out_id[i];//Associate the output ID so it knows which path it should take in the FW. 
            /* Make sure the DSP knows there is no buffer in this slot. */	
            audio_psm_pvt_buffer_reset( &wl->input_job.buffers[i], false);
   		}					
   	}
     audio_psm_pvt_unlock_queues(wl->input_queue_lock);

   	/* If all the buffers were dequeued successfully then break out of the while loop and return. */
   	if (final_result == ISMD_SUCCESS)
   	{			
   		wl->input_job.buffers_count = wl->input_queues_count; // TODO: FIX ME, THIS SHOULD BE THE NUMBER OF BUFFERS WE DEQUEUE!!! NOT THE NUMBER OF QUEUES!
   		wl->input_job.wl_handle = wl->handle;
   		wl->input_job.valid = true;

         AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_INPUT_JOB_DEQUEUED, 
					wl->handle, wl->pipe.type, wl->input_job.buffers_count, 0, 0, 0);	
   	}
   }

   return final_result;	
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_psm_pvt_job_get_output ( audio_psm_wl_t *wl, int queue_id )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;  
   unsigned int loop = 0;

   if (wl->started) {   
      if ((ismd_res = wl->psm_impl_job_read_output(wl->psm_impl_handle, &(wl->output_job[queue_id]), queue_id)) == ISMD_SUCCESS) {
         wl->output_job[queue_id].valid = true;

         /* When we first get the job, set buffer enq'd flag to false since no buffer has gone out yet.*/
         for(loop=0; loop < PSM_MAX_OUTPUT; loop++) {
            wl->out_job_buf_sent[loop] = false;
         }     

         /*Handle tags for the output buffer.*/
         if(wl->output_job[queue_id].buffers[0].smd_buf_desc != NULL) {
            audio_psm_pvt_handle_output_tags((ismd_buffer_descriptor_t*)wl->output_job[queue_id].buffers[0].smd_buf_desc, wl->tags_queue[queue_id]);
         }
         
         AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_OUTPUT_JOB_RECEIVED, 
         wl->handle, wl->pipe.type, wl->output_job[queue_id].buffers_count, 0, 0, 0);
      }
      else if (ismd_res == ISMD_ERROR_NO_DATA_AVAILABLE) {        
         AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_OUTPUT_JOB_NONE, 
         wl->handle, wl->pipe.type, 0, 0, 0, 0);  
      }
      else /* This is a genuine error. Handle it and return error. */ {
         AUDIO_ERROR( "Error obtaining output job from implemenation layer.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
         AUDIO_EVENT (AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_OUTPUT_JOB_RECEIVE_ERROR, 
         wl->handle, wl->pipe.type, 0, 0, 0, 0);
      }
   } 
   
   return ismd_res;	
}
/* --------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_psm_pvt_job_send_output ( audio_psm_wl_t *wl, audio_psm_job_desc_t *output_job, int queue_id )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   ismd_result_t final_result = ISMD_SUCCESS;
   ismd_result_t result;
   uint32_t queue=0;
   ismd_buffer_descriptor_t *smd_buf_desc = NULL;
   audio_buffer_attr_t *audio_buf_attr = NULL;
   bool buffer_done = false;  
   audio_psm_buf_desc_t *dsp_buffer = NULL;

   /*This is processed per queue, only one output buffer per job in the queue.*/
   dsp_buffer = &output_job->buffers[0];

   //Only try to process the buffer if we have one, and its not been output to all is associated queues.
   if((dsp_buffer->smd_buf_desc != NULL) && !dsp_buffer->in_all_output_queues) {

      /*Get the SMD buffer information out of the DSP buffer.*/
      smd_buf_desc = (ismd_buffer_descriptor_t *)dsp_buffer->smd_buf_desc;          
      audio_buf_attr = ( audio_buffer_attr_t* ) ( smd_buf_desc->attributes );

      buffer_done = true;

      /* Go through all the registered SMD output queues that might need this buffer. */      
      for (queue=0; queue<wl->output_queues_count; queue++)
      {
         
         /* This checks to see if the SMD queue is associated with the output DSP queue and has not already been set. */
         if ((wl->output_queue_input_id[queue] == queue_id) && (!wl->out_job_buf_sent[queue]))
         {          
            //Make sure the queue is enabled
            if(wl->output_queue_enabled[queue]){
               
               /* Need to make sure the ref count never hits zero in this loop */
               if((ismd_res = ismd_buffer_add_reference(smd_buf_desc->unique_id)) == ISMD_SUCCESS) {
                          
                  /* Try and enqueue the buffer to the output queue. */
                  if ( (ismd_res = ismd_queue_enqueue ( wl->output_queues[queue], smd_buf_desc) ) == ISMD_SUCCESS ) {
                     
                     /* Flag that this queue has its buffer */
                     wl->out_job_buf_sent[queue] = true;
                     
                     /* Write out event for output buffer enqueued with buffer attributes. */
                     AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_OUTPUT_BUFFER_ENQUEUED, 
                        wl->handle,
                        (unsigned int)(audio_buf_attr->local_pts>>32), 
                        (unsigned int)(audio_buf_attr->local_pts), 
                        audio_buf_attr->channel_count, 
                        audio_buf_attr->sample_rate,
                        audio_buf_attr->sample_size);

                     AUDIO_INFO(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], "Outjob enqueued%d%c", wl->output_queues[queue], 0); 
                  }
                  else
                  {
                     if((result = ismd_audio_buffer_dereference(smd_buf_desc->unique_id)) != ISMD_SUCCESS) {
                        //In this case something unexpected has happened, set the final result to failure and get out.
                        AUDIO_ERROR( "ismd_audio_buffer_dereference failed in send output!", result, audio_devh[AUDIO_DEBUG_PSM] );
                        final_result = ISMD_ERROR_OPERATION_FAILED;
                        goto unexpected_error;
                     }
                     final_result = ismd_res; // Here its the error returned from ismd_queue_enqueue.
                     buffer_done = false;
                     AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_OUTPUT_QUEUE_FULL, wl->handle, wl->output_queues[queue], ismd_res , wl->start_to_stop , 0, 0);						       
                  }      
               }
               else {            
                  //In this case something unexpected has happened, just get rid of this job, clean up and get out of this function.
                  OS_PRINT("AUD_PSM send_output: buffer_add_ref failed: result: %d, buf_id: 0x%x \n", ismd_res, smd_buf_desc->unique_id);
                  ismd_audio_buffer_dereference(smd_buf_desc->unique_id);
                  buffer_done = false;
                  final_result = ISMD_ERROR_OPERATION_FAILED;
                  goto unexpected_error;
               }
            }
            else {
               //The queue is disabled mark the buffer as sent.
               wl->out_job_buf_sent[queue] = true;
            }
         }
      }

      /* If all buffers are gone and enqueued then deref */
      if(buffer_done) {
         //Mark that this buffer has been put on all the queues its assigned to. 
         dsp_buffer->in_all_output_queues = true;
         if((result = ismd_audio_buffer_dereference(smd_buf_desc->unique_id)) != ISMD_SUCCESS) {
            AUDIO_ERROR( "ismd_audio_buffer_dereference failed in send output buffer done!", wl->in_use, audio_devh[AUDIO_DEBUG_PSM] );
            final_result = ISMD_ERROR_OPERATION_FAILED;
            goto unexpected_error;
         }
         else {
            dsp_buffer->smd_buf_desc = NULL;
         }
      }
   }

   unexpected_error:

   return final_result;	
}


/* --------------------------------------------------------------------------- */
/* Thread that manages all the input/output jobs' io.
   If any of the 2 things are done the loop would continue for another iteration. 
   1. Try and get an input job from a started pipe(wl)
      1.1. If there is an input job send it to the implementation layer. 
   2. Try and get an output job from the implementation layer. 
      2.1. Try and enqueue it to the output queue of that pipe(wl). 

   If none of the 2 tasks were done then we wait for an event which signifies either
      1. Input buffer available in any one of the input queues belonging to any of the pipes(wl)
      2. An output job is available from the implementation layer ready to be enqueued to the 
         output queues of the pipe(wl) */   
/* --------------------------------------------------------------------------- */    
static void *audio_psm_pvt_io_thread ( void *data )
{ 
   osal_result osal_res = OSAL_ERROR;
   audio_psm_device_t *psm_dev = &psm_device;
   bool wait_for_io_event = true;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   //Avoid warnings.
   (void)data; 
   (void)audio_psm_pvt_wl_get_by_imple_handle;
   
   OS_ASSERT(psm_dev);
          
   while ( !psm_dev->start_to_close_io_thread ) 
   {
      if (wait_for_io_event)
      {
         AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_WAITING_FOR_IO_EVENT, 0, 0, 0, 0, 0, 0);
         osal_res = os_event_wait ( &(psm_dev->io_event), EVENT_NO_TIMEOUT );
         OS_ASSERT(osal_res == OSAL_SUCCESS);
      }

      audio_psm_pvt_lock();
      if (!psm_dev->start_to_close_io_thread) {
         
         /* By default we want to wait, processing the jobs will set this to false if data moves */
         wait_for_io_event = true;
         audio_psm_pvt_process_input_jobs(&wait_for_io_event);
         audio_psm_pvt_process_output_jobs(&wait_for_io_event);

         /*Notify DSP layer jobs are processing is done, for a possible wakeup of the DSP.*/
         audio_dsp_notify_jobs_done ();
      }
      audio_psm_pvt_unlock();
   }

   if ( (osal_res = os_event_set ( &(psm_dev->safe_to_close_io_thread_event) )) != OSAL_SUCCESS ) {
      AUDIO_ERROR( "Setting safe_to_close_io_thread_event failed.", osal_res, audio_devh[AUDIO_DEBUG_PSM] );
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);
   
   return NULL;
}

/* --------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------- */
/* Input job thread operations and handling.
   1. Check to see whether there is a valid input job from the previous iteration. 
      1.1. If there is none get one from the next pipe(wl). 
   2. Try and feed the input job to the implementation layer. 
      2.1. If successful reset the job and mark wait_for_io_event to false. 
      2.2. If no space available in the implementation job queue continue and try again the next iteration. 
      2.3. If failure reset job and notify user. */
/* --------------------------------------------------------------------------- */
static void audio_psm_pvt_process_input_jobs( bool *wait_for_io_event)
{
   int handle = 0;
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_wl_t 	*wl = NULL;

   for (handle = 0; handle < AUDIO_PSM_MAX_WORKLOADS; handle++)
   { 
   
      if ( (wl = audio_psm_pvt_wl_get ( handle )) )
      {
         /* Only do something if this workload is in use*/
         if(wl->in_use) 
         {         
            /* If our cubby job is empty, try to get another */	
            if (!wl->input_job.valid)
            {
               audio_psm_pvt_job_get_input(wl); //Will set job to valid, no need to check return
            }

            /* If there is an input job try and feed it to the implementation layer. */
            if (wl->input_job.valid)
            {
            	/* send the input job to the implementation layer only if it is started and not starting_to_stop. */
            	if ( (wl->started) && (!wl->start_to_stop) )
            	{
                  
                  if ((ismd_res = wl->psm_impl_job_write_input(wl->psm_impl_handle, &wl->input_job)) == ISMD_SUCCESS)
                  {	
                     *wait_for_io_event = false;
                     AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_INPUT_JOB_SENT, 
                     					wl->handle, wl->pipe.type, wl->input_job.buffers_count, 0, 0, 0);	
                     /* Reset the input job and mark it as consumed. */
                     audio_psm_pvt_job_reset (&(wl->input_job), false);				
                  }
                  else if (ismd_res == ISMD_ERROR_NO_SPACE_AVAILABLE) 
                  {
                     AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_INPUT_JOB_QUEUE_FULL, 
                     				wl->handle, wl->pipe.type, wl->input_job.buffers_count, 0, 0, 0);	
                  }			   
                  else /* If it is a genuine error handle it. */
                  {
                     /* Handle error.*/
                     AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_INPUT_JOB_SEND_ERROR, 
                     					wl->handle, wl->pipe.type, wl->input_job.buffers_count, 0, 0, 0);	
                     audio_psm_pvt_job_reset (&wl->input_job, true);
                  }
            	}
               else	
               {
                  audio_psm_pvt_job_reset (&wl->input_job, true); /* Reset job and deref buffers already dequeued. */
               }
            }
            else
            {
               AUDIO_EVENT (AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], SVEN_MODULE_EVENT_AUD_IO_PSM_INPUT_JOB_NONE, 
                     					wl->handle, wl->pipe.type, 0, 0, 0, 0);	
            }
         }
      }
      else 
      {
         AUDIO_ERROR( "Invalid input handle in PSM io_thread, YIKES!", ismd_res, audio_devh[AUDIO_DEBUG_PSM] ); //This should never happen
         OS_ASSERT(wl != NULL);
      }
   }
   return;
}

/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */  
/* Output job thread operations and handling. 
   1. Check to see whether there is output job available from the implementation layer.  
      1.1. If there is one get it and enqueue it to the output queues of that pipe. 
         1.1.1. If the output queue is full wait. 
      1.2. If none then just continue. */
/* --------------------------------------------------------------------------- */
static void audio_psm_pvt_process_output_jobs( bool *wait_for_io_event)
{
   int handle = 0;
   audio_psm_wl_t 	*wl = NULL;
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   int out_queue = 0;
   audio_psm_job_desc_t *output_job;

   for (handle = 0; handle < AUDIO_PSM_MAX_WORKLOADS; handle++) {
      
      if ((wl = audio_psm_pvt_wl_get( handle ))) {
         /* Only do something if this workload is in use*/
         if(wl->in_use) {
            
            /*Need to try and get a job from every DSP output queue*/
            for(out_queue = 0; out_queue < wl->num_pipe_outputs; out_queue++ ) {

               output_job = &wl->output_job[out_queue];         
               /* Check to see if we need a new job, if not, we still have a one left over from last time*/
               if (!output_job->valid) {
                  audio_psm_pvt_job_get_output(wl, out_queue);           
               }
               if(output_job->valid){  
                  
                  /* Check to see if it is a stale output job. If so discard it. */
                  if (output_job->stale_data) {
                     AUDIO_INFO(AUDIO_SVEN_LOG_DATAFLOW, audio_devh[AUDIO_DEBUG_PSM], "h%d wlh%d bc%d\n", output_job->handle, output_job->wl_handle, output_job->buffers_count );
                     audio_psm_pvt_job_reset (output_job, true);
                  }

                  /* It is not stale data. */
                  else {
                     /*Try to send this job to the SMD queues it is associated with.*/
                     ismd_res = audio_psm_pvt_job_send_output(wl, output_job, out_queue);
                     if (ismd_res == ISMD_SUCCESS) {
                        audio_psm_pvt_job_reset (output_job, false);
                        *wait_for_io_event = false;
                     }
                     //Here an error occured with sending the buffers in this job, reset the job and try to deref the buffers.
                     else if(ismd_res == ISMD_ERROR_OPERATION_FAILED) {
                        audio_psm_pvt_job_reset (output_job, true);
                        *wait_for_io_event = false;
                     }
                  }
               }
            }
         }
      }
      else 
      {
         AUDIO_ERROR( "Invalid output handle in PSM io_thread, YIKES!", ismd_res, audio_devh[AUDIO_DEBUG_PSM] ); //This should never happen
         OS_ASSERT(wl != NULL);
      }
   }

   return;
}

/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_psm_pvt_pipe_stages_free(audio_psm_pipe_t *pipe)
{
	audio_psm_stage_t *stage = NULL;
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
	pipe->type = PSM_PIPE_TYPE_UNKNOWN;
	pipe->handle = 0;
   
	while(pipe->stages)
	{
		stage	= pipe->stages; /* Make stage point to the current stage. */
		pipe->stages = pipe->stages->virt_next; /* Increment stage pointer to point to next */
		
		/* TODO: Cleanup the stages and set the in_use to false. 
			Also release the smd buffers assigned to the output buffers of each stage. 
			Keep in mind that input and output stages do not have output buffers assigned to them. */
		if ( (stage->task == PSM_TASK_IN) || (stage->task == PSM_TASK_OUT) ) {
			audio_psm_pvt_stage_reset (stage, false);
		}
		else {	
			audio_psm_pvt_stage_reset (stage, true);
		}
	}

	ismd_res = ISMD_SUCCESS;

	return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* WARNING: Do not reset the in_use flag. If this buffer is shared then the 
   in_use flag is used to tell the DSP that the buffer is ready for consumption. 
   Setting this in this function might lead to some race condition because there 
   might be other things that the host might want to do before releasing this buffer. 
   Hence leave this flag at the mercy of the calling function. */
/* --------------------------------------------------------------------------- */
static void
audio_psm_pvt_init_buffer_descriptor(audio_psm_buf_desc_t *psm_buf_desc, ismd_buffer_descriptor_t *smd_buf_desc)
{
   psm_buf_desc->smd_buf_desc = (void *)smd_buf_desc;
   psm_buf_desc->dsp_phys_address = 0; /* This will be set in the implementation layer. */
   psm_buf_desc->size = smd_buf_desc->phys.size;
   psm_buf_desc->level = 0;
   psm_buf_desc->eos = false;
   psm_buf_desc->tags = false;
   psm_buf_desc->in_all_output_queues = false;

   audio_core_reset_buffer_metadata(&psm_buf_desc->metadata);

   return;
}

static ismd_result_t audio_psm_pvt_buffer_allocate(audio_psm_buf_desc_t *psm_buf, uint32_t size)
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   ismd_buffer_descriptor_t *smd_buf_desc = NULL;

   if ((ismd_res = ismd_audio_buffer_alloc_typed_direct ( ISMD_BUFFER_TYPE_PHYS, size, &smd_buf_desc)) != ISMD_SUCCESS ) {
      AUDIO_ERROR( "PSM buffer allocation failed.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
   }
   else {
      audio_psm_pvt_init_buffer_descriptor(psm_buf, smd_buf_desc);
   }
   
   return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* WARNING: Do not reset the in_use flag. If this buffer is shared then the 
   in_use flag is used to tell the DSP that the buffer is ready for consumption. 
   Setting this in this function might lead to some race condition because there 
   might be other things that the host might want to do before releasing this buffer. 
   Hence leave this flag at the mercy of the calling function. */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_psm_pvt_buffer_reset( audio_psm_buf_desc_t *psm_buf, 
																bool dereference_buf )
{
   ismd_result_t ismd_res = ISMD_SUCCESS;
   ismd_buffer_descriptor_t *smd_buf_desc;
   
   psm_buf->dsp_phys_address = 0;

   smd_buf_desc = (ismd_buffer_descriptor_t *) psm_buf->smd_buf_desc;

   if (dereference_buf && (psm_buf->smd_buf_desc != NULL))
   {
      ismd_res = ismd_audio_buffer_dereference(smd_buf_desc->unique_id);
      if ( ismd_res != ISMD_SUCCESS)
      {
      	AUDIO_ERROR( "Error dereferencing buffer.", ismd_res, audio_devh[AUDIO_DEBUG_DSP] );
      }
   }

   psm_buf->eos = false;
   psm_buf->tags = false;
   psm_buf->in_all_output_queues = false;
   psm_buf->smd_buf_desc = NULL;
   psm_buf->size = 0;
   psm_buf->level = 0;
   psm_buf->md_wl = NULL;

   /* Reset the metadata structure. */
   audio_core_reset_buffer_metadata(&psm_buf->metadata);

   return ismd_res;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Depending on the type of pipe assign it to DSP or IA. 
	Initially PSM is only implemented in the DSP hence DSP is the only supported value. */
/* --------------------------------------------------------------------------- */
static void audio_psm_pvt_set_implementation_layer(audio_psm_wl_t *wl)
{	
   wl->psm_impl_pipe_add = audio_dsp_pipe_add;
   wl->psm_impl_pipe_remove = audio_dsp_pipe_remove;
   wl->psm_impl_pipe_start = audio_dsp_pipe_start;
   wl->psm_impl_pipe_stop = audio_dsp_pipe_stop;
   wl->psm_impl_pipe_flush = audio_dsp_pipe_flush;
   wl->psm_impl_job_write_input = audio_dsp_write_input_job;
   wl->psm_impl_job_read_output = audio_dsp_read_output_job;
   wl->psm_impl_pipe_configure = audio_dsp_pipe_configure;
   wl->psm_impl_codec_available = audio_dsp_codec_available;
   wl->psm_impl_codec_ver = audio_dsp_get_codec_ver_string;
   wl->psm_impl_stage_configure = audio_dsp_stage_configure;
   wl->psm_impl_get_stream_info = audio_dsp_stage_get_stream_info;
   wl->psm_impl_get_stage_params = audio_dsp_stage_get_stage_params;
   
   return;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */ 	
static ismd_result_t audio_psm_pvt_input_callback ( void *handle, 
															ismd_queue_event_t queue_event,
													          ismd_buffer_handle_t      buffer)
{
   audio_psm_device_t *psm_dev = (audio_psm_device_t *)handle;
   osal_result osal_res;

   //AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM] );

   //Avoid compiler warnings.
   (void) buffer;
   (void) queue_event;

   if ( queue_event & (ISMD_QUEUE_EVENT_NOT_EMPTY | ISMD_QUEUE_EVENT_HIGH_WATERMARK ) ) {
	
      osal_res = os_event_set ( & (psm_dev->io_event) );
      OS_ASSERT(osal_res ==  OSAL_SUCCESS);
   }

   //AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM] );
   
   return ISMD_ERROR_NO_SPACE_AVAILABLE;
}
/* --------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------- */
/* Comments here */
/* --------------------------------------------------------------------------- */ 	
static ismd_result_t audio_psm_pvt_output_callback ( void *context, ismd_queue_event_t queue_event, ismd_buffer_handle_t *buffer )
{
   audio_psm_device_t *psm_dev = (audio_psm_device_t *)context;
   osal_result osal_res;
   //AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM] );

   //Avoid compiler warnings.
   (void) buffer;
   (void) queue_event;

  if ( queue_event & (ISMD_QUEUE_EVENT_LOW_WATERMARK | ISMD_QUEUE_EVENT_NOT_FULL | ISMD_QUEUE_EVENT_EMPTY) ){
      osal_res = os_event_set ( & (psm_dev->io_event) );
      OS_ASSERT(osal_res ==  OSAL_SUCCESS);
  }


   //AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM] );

   return ISMD_ERROR_NO_DATA_AVAILABLE;
}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
static ismd_result_t audio_psm_pvt_alloc_stage_buffers( audio_psm_pipe_t *pipe )
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   audio_psm_stage_t *stage = NULL;
   int i = 0;
   int j, k,l;

   /* Go through all the stages of the pipe and set all the physical addresses 
   of the stage and buffers in every stage */		
   stage = pipe->stages;

   while (stage)
   {
      /* If it is a decode stage... */
      if ( (stage->task == PSM_TASK_DECODE)  || (stage->task == PSM_TASK_ENCODE))
      {
         /* TODO: Change this when Tensilica overwriting given memory problem is solved. 
         For not I am just going to make this a unique size. I know I need at least 536KB for aux buffers
         which would give enough space for tensilica overwrite memory as much as they want. 
         Since I found a 1792KB space in the memory map I divided this into two since POR for PR4.x is 2 streams. 
         Anyways the final size I came up which gives enough space for corruption and doesnt change the 
         memmap too much is 536KB.
         Was 256KB change it back when corruption problem is solved. */

         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.decoder.aux_buffer), DECODER_AUX_BUF_SIZE);
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for decoder aux_buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         }

         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.decoder.decode_buffer), DECODE_BUF_SIZE);
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for decode buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         } 

         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.decoder.mda_buffer), SMD_64KB_BUFFERS);
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for MDA buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         }    

         /* Only alloc this buffer if we are using the encoders*/
         if (stage->task == PSM_TASK_ENCODE)
         {
            ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.decoder.encode_buffer), DECODE_BUF_SIZE);
            if ( ismd_res != ISMD_SUCCESS )
            {
               AUDIO_ERROR( "Buffer allocation for encode buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
               goto exit;
            }            
         }         
         
         if(stage->task == PSM_TASK_DECODE && stage->stage_params.decoder.ms10dec_enabled
           && (stage->stage_params.decoder.host.codec.algo == ISMD_AUDIO_MEDIA_FMT_AAC || stage->stage_params.decoder.host.codec.algo == ISMD_AUDIO_MEDIA_FMT_AAC_LOAS))
         {
            ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.decoder.fifo_buffer), DECODE_BUF_SIZE);
            if ( ismd_res != ISMD_SUCCESS )
            {
               AUDIO_ERROR( "Buffer allocation for encode buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
               goto exit;
            }
   
         }
      }

      /* If it is a custom processing stage, allocate the required buffers */
      if ( stage->task == PSM_TASK_CAPP )
      {
      
         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.capp.in_buffer), SMD_64KB_BUFFERS);
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for capp function input failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         } 
         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.capp.out_buffer), SMD_64KB_BUFFERS);
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for capp function output failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         } 
         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.capp.mda_buffer), SMD_64KB_BUFFERS);
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for capp metadata association failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         } 
      }

      if ( stage->task == PSM_TASK_PACKETIZE_ENCODED_DATA) {
         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.packetizer.mda_buffer), SMD_64KB_BUFFERS);
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for MDA buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         } 
      }

      if ( stage->task == PSM_TASK_MIX ) {

         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.mixer.aux_buffer), MIXER_AUX_BUF_SIZE );
         if ( ismd_res != ISMD_SUCCESS ) {
         AUDIO_ERROR( "Buffer allocation for mixer aux_buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
         goto exit;
         }
         else {
            //Mixer gain smoothing requires that we initialize the smoothing coefficients in the aux buffer. 
            mixer_internal_mem_layout_t *ptr;
            ptr = ((ismd_buffer_descriptor_t *)(stage->stage_params.mixer.aux_buffer.smd_buf_desc))->virt.base;
            ptr->new_gain_index = 0;
            ptr->stream_input_config_valid_pri = false;
            ptr->stream_input_config_valid_sec = false;
            ptr->stream_output_ch_gains_valid = false;
            ptr->coeff_changed = 0;
            for(l=0; l<AUDIO_MAX_GAIN_TABLE; l++){
               for ( k=0; k<AUDIO_MAX_OUTPUT_CHANNELS; k++ ){
                  ptr->master_gain_index[l][k] = MIX_COEFF_INDEX_0_DB;                              //0dB index
               }
            }
            for(l=0; l<AUDIO_MAX_GAIN_TABLE; l++){
               for ( i=0; i<AUDIO_MAX_INPUTS; i++ ){
                  for ( j=0; j<AUDIO_MAX_INPUT_CHANNELS; j++ ){
                     for ( k=0; k<AUDIO_MAX_OUTPUT_CHANNELS; k++ ){

                        //Make sure to use the startup coefficients given by the APM if an input is attached. 
                        if(i < (int)stage->inputs_count) {
                           ptr->input_gain_index[l][i][j][k] = stage->stage_params.mixer.input_config[i].channel_mix_config.input_channels_map[j].output_channels_gain[k];
                        }
                        else{
                           if ( j == k )
                              ptr->input_gain_index[l][i][j][k] = MIX_COEFF_INDEX_0_DB;          //0dB index
                           else
                              ptr->input_gain_index[l][i][j][k] = MIX_COEFF_INDEX_MUTE;         //-145dB index
                        }
                     }
                  }
               } 
            }
         }
      }

      if ( stage->task == PSM_TASK_DOWNMIX ) {
         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.downmixer.aux_buffer), DOWNMIXER_AUX_BUF_SIZE );
         if ( ismd_res != ISMD_SUCCESS ) {
            AUDIO_ERROR( "Buffer allocation for downmixer aux_buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         }
         else {
            OS_MEMSET((void *)(((ismd_buffer_descriptor_t *)(stage->stage_params.downmixer.aux_buffer.smd_buf_desc))->virt.base), 0, 64*sizeof(int) );
         }
      }

      if ( stage->task == PSM_TASK_SRC )
      {
         for(i = 0; i < (int)stage->inputs_count; i++) {

            /* This buffer is for the history needed for the SRC implementation. */         
            ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.src.aux_buffer[i]), SRC_AUX_BUF_SIZE);
            if ( ismd_res != ISMD_SUCCESS )
            {
               AUDIO_ERROR( "Buffer allocation for src aux_buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
               goto exit;
            }            
         }
      }

      if ( stage->task == PSM_TASK_SRS ){
         for(i = 0; i < AUDIO_SRS_MAX_OUTPUTS; i++) {      
            ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.srs.aux_buffer[i]), SRS_AUX_BUF_SIZE);
            if ( ismd_res != ISMD_SUCCESS )
            {
               AUDIO_ERROR( "Buffer allocation for srs aux_buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
               goto exit;
            }    
         }
      }

      if ( stage->task == PSM_TASK_PRESRC )
      {
         for(i = 0; i < (int)stage->inputs_count; i++) {

            /* This buffer is for the history needed for the SRC implementation. */         
            ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.src.aux_buffer[i]), SRC_AUX_BUF_SIZE);
            if ( ismd_res != ISMD_SUCCESS )
            {
               AUDIO_ERROR( "Buffer allocation for presrc aux_buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
               goto exit;
            }            
         }
      }

      if ( stage->task == PSM_TASK_PCM_DECODE )
      {  
         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.pcm_dec.aux_buffer), SRC_AUX_BUF_SIZE);
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for pcm_dec aux buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         }            
      } 

         
      if ( stage->task == PSM_TASK_PACKETIZE_ENCODED_DATA)
      {  
         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.packetizer.aux_buffer), (SMD_64KB_BUFFERS));
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for packetizer aux buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         }            

         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.packetizer.persistant_buffer), (SMD_64KB_BUFFERS));
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for packetizer persistant buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         }            
      }
         
      if ( stage->task == PSM_TASK_WATERMARK)
      {  
         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.watermark.aux_buffer), SMD_64KB_BUFFERS);
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for watermark aux buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         }            
      }
         
      if ( stage->task == PSM_TASK_BM)
      {  
         ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.bass_man.aux_buffer), SMD_64KB_BUFFERS);
         if ( ismd_res != ISMD_SUCCESS )
         {
            AUDIO_ERROR( "Buffer allocation for bass_man aux buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         }            
      }
      
      if ( stage->task == PSM_TASK_DM)
      {
         for(i = 0; i < AUDIO_MAX_INPUT_CHANNELS; i++)
         {
            ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.delay_mgmt.buf_mgmt[i].aux_buffer), SMD_64KB_BUFFERS);
            if ( ismd_res != ISMD_SUCCESS ){
               AUDIO_ERROR( "Buffer allocation for bass_man aux buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
               goto exit;
            }
         }
      }
      if ( stage->task == PSM_TASK_PER_OUTPUT_DELAY)
      {

         if(stage->stage_params.per_output_delay.enabled){
            int buffer_size = stage->stage_params.per_output_delay.buffer_size;
            for(i = 0; i < (int)stage->outputs_count; i++)
            {
               int index = stage->conn_mda.output[i];
               ismd_res = audio_psm_pvt_buffer_allocate ( &(stage->stage_params.per_output_delay.output_params[index].aux_buffer), buffer_size);
               if ( ismd_res != ISMD_SUCCESS ){
                  AUDIO_ERROR( "Buffer allocation for per_output_delay aux buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
                  goto exit;
               }
            }
         }
      }
      if ( stage->task == PSM_TASK_IEC_PARSER) {  
         if ((ismd_res = audio_psm_pvt_buffer_allocate ( &stage->stage_params.iec_parse.aux_buffer, SMD_64KB_BUFFERS)) != ISMD_SUCCESS ) {
            AUDIO_ERROR( "Buffer allocation for IEC parser stage aux buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         }            
      }

      if ( (stage->task == PSM_TASK_DEINTERLEAVER) && stage->stage_params.deinterleaver.trans_protection_buffer_size > 0) {  

         if ((ismd_res = audio_psm_pvt_buffer_allocate ( &stage->stage_params.deinterleaver.aux_buffer, 
                         stage->stage_params.deinterleaver.trans_protection_buffer_size)) != ISMD_SUCCESS ) 
         {
            AUDIO_ERROR( "Buffer allocation for deinterleaver transition protection aux buffer failed.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
            goto exit;
         }     
      }

      stage = stage->virt_next; /* increment stage pointer to point to next stage in the pipe */				
   }

	ismd_res = ISMD_SUCCESS;

exit:
   return ismd_res;

}
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Comment here. */
/* --------------------------------------------------------------------------- */
static void audio_psm_pvt_job_reset ( audio_psm_job_desc_t *job, bool dereference_buf )
{
   uint32_t i = 0;

   job->stale_data = 0;
   job->wl_handle = AUDIO_INVALID_HANDLE;
   job->virt_next = NULL;
   job->phys_next = NULL;
   job->dsp_phys_next = NULL;

   for (i=0; i<job->buffers_count; i++)
   {
      if(audio_psm_pvt_buffer_reset (&(job->buffers[i]), dereference_buf) != ISMD_SUCCESS){
         OS_INFO("\nAUDIO WARN: Freeing the buffer in job reset failed!\n");
      }
   }

   job->buffers_count = 0;
   job->valid = 0;

   return;
}
/* --------------------------------------------------------------------------- */

static ismd_result_t audio_psm_pvt_pipe_stop( audio_psm_wl_t *wl)
{
	ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;

     AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);

	OS_ASSERT (wl);
  
	wl->start_to_stop = true;	

   if (wl->added)
   {
   	/* Send the stop command to the implementation layer can initialize the pipe on IA/DSP */
   	ismd_res = wl->psm_impl_pipe_stop(wl->psm_impl_handle);
   	if (ismd_res != ISMD_SUCCESS)
   	{
         AUDIO_ERROR( "Could not stop pipe on PSM implementation layer.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );		
   		goto exit;
   	}
   }
	/* Now that the pipe is stopped we need to make sure that there are no output jobs 
		pertaining to this pipe left over in the output job queue of the implementation layer. */
	
	wl->started = false;

	ismd_res = ISMD_SUCCESS;
	
exit:

     AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);
	return ismd_res;
}


static ismd_result_t audio_psm_pvt_pipe_free( audio_psm_wl_t *wl)
{
   ismd_result_t ismd_res = ISMD_ERROR_OPERATION_FAILED;
   unsigned int loop = 0;
   uint32_t input_cnt = 0;
   uint32_t output_cnt = 0;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);	

   OS_ASSERT ( (wl) && (wl->in_use) );

   if (wl->started)
   {	
   	ismd_res = audio_psm_pvt_pipe_stop (wl);
   	if (ismd_res != ISMD_SUCCESS)	
   	{		
   		goto exit;
   	}
   }

   if (wl->added)
   {
      /* Send the teardown command to the implementation layer can initialize the pipe on IA/DSP */
      ismd_res = wl->psm_impl_pipe_remove(wl->psm_impl_handle);
      if (ismd_res != ISMD_SUCCESS)
      {
         AUDIO_ERROR( "Could not remove pipe from PSM implementation layer.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );		
         goto exit;
      }
   }

   input_cnt = wl->input_queues_count;
   output_cnt = wl->output_queues_count;

   //Need to remove all the output queues associated with this pipe.
   for(loop = 0; loop < output_cnt; loop++) {
         
      if ((ismd_res = audio_psm_pvt_output_queue_remove(wl, wl->output_queues[0])) != ISMD_SUCCESS)
      {
         AUDIO_ERROR( "Error removing queue from input queues of pipe.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
      }
   }

   //Need to remove all the input queues associated with this pipe.
   for(loop = 0; loop < input_cnt; loop++) {
         
      if ((ismd_res = audio_psm_pvt_input_queue_remove(wl, wl->input_queues[0])) != ISMD_SUCCESS)
      {
         AUDIO_ERROR( "Error removing queue from input queues of pipe.", ismd_res, audio_devh[AUDIO_DEBUG_PSM] );
      }
   }

   //Cubby job needs to free any buffers it might have.
   for(loop = 0; loop < PSM_PIPE_MAX_NUM_OUT_QUEUES; loop++) {
      audio_psm_pvt_job_reset( &(wl->output_job[loop]), true);
   }
   audio_psm_pvt_job_reset( &(wl->input_job), true);

   /*Free any tags queues allocated.*/
   for(loop = 0; loop < PSM_MAX_OUTPUT; loop++) {
      if(wl->tags_queue[loop] != ISMD_QUEUE_HANDLE_INVALID){
         ismd_queue_flush(wl->tags_queue[loop]);
         ismd_queue_free(wl->tags_queue[loop]);
         wl->tags_queue[loop] = ISMD_QUEUE_HANDLE_INVALID;
         wl->tags_queue_ref_count[loop] = 0;
      }
   }

   audio_psm_pvt_wl_reset(wl);
   ismd_res = ISMD_SUCCESS;	
exit:
      AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);	
	return ismd_res;
}

static void
audio_psm_pvt_copy_htod_params(audio_psm_stage_t *stage, audio_psm_stage_params_t *params, bool pipe_started)
{
   /*If there are host params to update, copy to stage (DSP viewable)..*/
   if(params != NULL) {

      /*All stages that have implemented host params need to be updated.*/
      /*Update the host parameters seen by DSP, and DSP's copy if pipe is not running.*/
      if(stage->task == PSM_TASK_MIX) {
         stage->stage_params.mixer.host = params->mixer.host;
         if(!pipe_started) {
            stage->stage_params.mixer.dsp = params->mixer.host.mixer;
         }
      }
      else if((stage->task == PSM_TASK_DECODE) || (stage->task == PSM_TASK_ENCODE)) {
         stage->stage_params.decoder.host = params->decoder.host;
         if(!pipe_started) {
            stage->stage_params.decoder.dsp = params->decoder.host.codec;
         }
      }
      else if(stage->task == PSM_TASK_PACKETIZE_ENCODED_DATA) {
         stage->stage_params.packetizer.host = params->packetizer.host;
         if(!pipe_started) {
            stage->stage_params.packetizer.dsp = params->packetizer.host.packetize;
         }
      }
      else if(stage->task == PSM_TASK_PCM_DECODE) {
         stage->stage_params.pcm_dec.host = params->pcm_dec.host;
         if(!pipe_started) {
            stage->stage_params.pcm_dec.dsp = params->pcm_dec.host.pcm_dec;
         }
      }
      else if(stage->task == PSM_TASK_CAPP) {
         stage->stage_params.capp.host = params->capp.host;
         if(!pipe_started) {
            stage->stage_params.capp.dsp = params->capp.host.capp;
         }
      }
      else if(stage->task == PSM_TASK_SRS) {
         stage->stage_params.srs.host = params->srs.host;
         if(!pipe_started) {
            stage->stage_params.srs.dsp = params->srs.host.srs;   
         }         
      }
      else if(stage->task == PSM_TASK_IEC_PARSER) {
         stage->stage_params.iec_parse.host = params->iec_parse.host;
         if(!pipe_started) {
            stage->stage_params.iec_parse.dsp = params->iec_parse.host.iec_parse;
         }
      }
      else if(stage->task == PSM_TASK_PER_OUTPUT_DELAY){
         stage->stage_params.per_output_delay.host = params->per_output_delay.host;
         if(!pipe_started){
            stage->stage_params.per_output_delay.dsp = params->per_output_delay.host.per_output_delay;
         }
      }   
      else if((stage->task == PSM_TASK_SRC) || (stage->task == PSM_TASK_PRESRC)){
         stage->stage_params.src.host = params->src.host;
         if(!pipe_started){
            stage->stage_params.src.dsp = params->src.host.src;
         }
      }  
   }

   return;
}

static void
audio_psm_pvt_copy_dtoh_params(audio_psm_stage_t *stage, audio_psm_stage_params_t *params)
{
   if(params != NULL) {
      
      /*For each stage that has implemented host atomic updates, 
        need to copy of the relevant stage data from DSP viewable memory
        into the callers viewable memory. */
      if(stage->task == PSM_TASK_IEC_PARSER) {
         params->iec_parse.parser_status = stage->stage_params.iec_parse.parser_status;
      }
      else if(stage->task == PSM_TASK_SRS){
         params->srs.host.srs = stage->stage_params.srs.dsp;
      }
		//TODO: when all stages have moved to atomic update, no need for this.
      else {
         *params = stage->stage_params;
      }
   }

   return;
}

ismd_result_t
audio_psm_resume()
{
   ismd_result_t result = ISMD_SUCCESS;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_PSM]);
   /* keep reset DSP0 */
   audio_dsp_wakeup(0);
   /* keep reset DSP1 */
   audio_dsp_wakeup(1);

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);
   return result;
}

ismd_result_t
audio_psm_suspend()
{
   ismd_result_t result = ISMD_SUCCESS;
   AUDIO_ENTER( audio_devh[AUDIO_DEBUG_PSM]);
   /* warmup DSP0 */
   audio_dsp_reset(0);
   /* warmup DSP1 */
   audio_dsp_reset(1);
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_PSM]);
   return result;

}
