
/*
* File Name: audio_render_spdif.h
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



/** @weakgroup ismd_audio ISMD Audio Data Types */
/** @ingroup ismd_audio */
/** @{ */



/*
Channel Status Block Details -

Reference IEC60958-3: 5.2.1 Channel status general format

      7   6   5   4   3   2   1   0
    +---+---+---+---+---+---+---+---+
    | mode0 | fmt_info  | c | b | a |   - 0
    +---+---+---+---+---+---+---+---+
    | L |     category_code         |   - 1
    +---+---+---+---+---+---+---+---+
    | channel_num   |  source_num   |   - 2
    +---+---+---+---+---+---+---+---+
    | clk_accuracy  |  sample_freq  |   - 3
    +---+---+---+---+---+---+---+---+
    | orig_samp_freq|  word_length  |   - 4
    +---+---+---+---+---+---+---+---+
    |                               |   - 5
    +---+---+---+---+---+---+---+---+

 byte 0 b[0]:       a - Consumer use of channel status block. (MUST == 0)
 byte 0 b[1]:       b - 0 Audio sample word represents linear PCM samples.
                        1 Audio sample word used for other purposes. (MUST == 1)
 byte 0 b[2]:       c - 0 Software for which copyright is asserted. (see note 3)
                        1 Software for which no copyright is asserted.
 byte 0 b[5.3]:   fmt - 000 MUST be all 000s for SPDIF
 byte 0 b[7.6]:  mode - 00 MUST be all 000s for SPDIF

Table 3  Category code groups
Bits 8 to 15 Category
   000 00000 General. Used temporarily
** 100 XXXXL Laser optical products
   010 XXXXL Digital/digital converters and signal processing products
   110 XXXXL Magnetic tape or disc based products
** 001 XXXXL Broadcast reception of digitally encoded audio signals with or without video signals
** 011 1XXXL Broadcast reception of digitally encoded audio signals with or without video signals
   101 XXXXL Musical instruments, microphones and other sources without copyright information
   011 00XXL Analogue/digital converters for analogue signals without copyright information
   011 01XXL Analogue/digital converters for analogue signals which include copyright information
               in the form of Cp-bit and L-bit status
   000 1XXXL Solid state memory based products
   000 0001L Experimental products not for commercial sale
   111 XXXXL Not defined. Reserved
   000 0XXXL Not defined. Reserved, except 000 00000 and 000 0001L

** indicates "L" bit is "reversed"

Bit 15 is referred to as the L-bit. It indicates the generation status of the digital audio signal.
Generally the L-bit is specified as:
0 No indication.
1 Commercially released pre-recorded software.
For historical reasons, the reverse situation is valid for the signals originating from:
 laser optical products (category code 100 XXXXL);
 broadcast reception (category codes 001 XXXXL and 011 1XXXL).
For these category codes, the L-bit indicates:
0 Commercially released pre-recorded software.
1 No indication.

Sampling frequency
b 24 25 26 27
 0  0  1  0  22,05 kHz
 0  0  0  0  44,1 kHz
 0  0  0  1  88,2 kHz
 0  0  1  1  176,4 kHz
 0  1  1  0  24 kHz
 0  1  0  0  48 kHz
 0  1  0  1  96 kHz
 0  1  1  1  192 kHz
 1  1  0  0  32 kHz
 1  0  0  0  Sampling frequency not indicated

Clock accuracy.
28 29
0 0 Level II
1 0 Level I
0 1 Level III
1 1 Interface frame rate not matched to sampling frequency.

Word length
b 32 33 34 35
Maximum audio sample word length is 20 bits
 0  0  0  0 Word length not indicated (default)
 0  1  0  0 16 bits
 0  0  1  0 18 bits
 0  0  0  1 19 bits
 0  1  0  1 20 bits
 0  0  1  1 17 bits
Maximum audio sample word length is 24 bits
 1  0  0  0 Word length not indicated (default)
 1  1  0  0 20 bits
 1  0  1  0 22 bits
 1  0  0  1 23 bits
 1  1  0  1 24 bits
 1  0  1  1 21 bits

Original sampling frequency
b 36 37 38 39
 1  1  1  1 44,1 kHz
 1  1  1  0 88,2 kHz
 1  1  0  1 22,05 kHz
 1  1  0  0 176,4 kHz
 1  0  1  1 48 kHz
 1  0  1  0 96 kHz
 1  0  0  1 24 kHz
 1  0  0  0 192 kHz
 0  1  1  1 Reserved
 0  1  1  0 8 kHz
 0  1  0  1 11,025 kHz
 0  1  0  0 12 kHz
 0  0  1  1 32 kHz
 0  0  1  0 Reserved
 0  0  0  1 16 kHz
 0  0  0  0 Original sampling frequency not indicated (default)

// Reference IEC 61937-1: Annex A:
// The channel status when IEC 60958 is used
// in consumer applications
// Table A.1

Table A.1  The allocation of the channel status bits
Bit[LSB..MSB]  Value[LSB..MSB]  Comments
Bit 0           0               Consumer use
Bit 1           1               Audio sample word used for other purpose than linear PCM
Bit 2           0               Software for which copyright is asserted
                1               Software for which no copyright is asserted
Bit 3 .. 5      000             Non-linear PCM audio samples, according to IEC 60958
Bit 6 .. 7      00              Mode 0
Bit 8 .. 15     xxxxxxxL        Category code, Lbit
Bit 16 .. 19    0000            Source number
Bit 20 .. 23    0000            Channel number
Bit 24 .. 27    0000            Symbol frequency = 64 ?44,1 kHz = 2,822 4 MHz
                0100            Symbol frequency = 64 ?48 kHz = 3,072 MHz
                1100            Symbol frequency = 64 ?32 kHz = 2,084 MHz
Bit 28 .. 31                    Clock accuracy (see IEC 60958-3)
Bit 32 .. 191   All 0           As defined in IEC 60958-3
*/

#ifndef _AUDIO_RENDER_SPDIF_H_
#define _AUDIO_RENDER_SPDIF_H_

#include "audio_core.h"
#include "audio_hal_common.h"

/* S/PDIF packetizer defines. */
#define SPDIF_PACKET_HEADER_SIZE 8
#define STEREO_SAMPLES_PER_AC3_ES_PKT   1536
#define SPDIF_AC3_FRAME_SIZE           (STEREO_SAMPLES_PER_AC3_ES_PKT * 4)

/*SPDIF Burst Preamble Sync word - From spec IEC 61937-1 */
#define SPDIF_BURST_PREAMBLE_SYNCWORD_PA_LSB  0x72; /* Pa LSB */
#define SPDIF_BURST_PREAMBLE_SYNCWORD_PA_MSB 0xf8; /* Pa MSB */
#define SPDIF_BURST_PREAMBLE_SYNCWORD_PB_LSB  0x1f; /* Pb LSB */
#define SPDIF_BURST_PREAMBLE_SYNCWORD_PB_MSB  0x4e; /* Pb MSB */

/*SPDIF Burst Preamble Codec types*/
#define SPDIF_BURST_PREAMBLE_TYPE_AC3 0x01
#define SPDIF_BURST_PREAMBLE_TYPE_DTS_I 0x0B
#define SPDIF_BURST_PREAMBLE_TYPE_DTS_II 0x0C // TODO: NOT DONE!!
#define SPDIF_BURST_PREAMBLE_TYPE_DTS_III 0x0B
#define SPDIF_BURST_PREAMBLE_TYPE_MP3 0x01



/********* S/PDIF channel status defines *********************************/

 /* Frequency table from IEC60958-3: 5.2.1 */
 #define SPDIF_CHSTAT_FREQ_22k   0x4
 #define SPDIF_CHSTAT_FREQ_44k   0x0
 #define SPDIF_CHSTAT_FREQ_88k   0x8
 #define SPDIF_CHSTAT_FREQ_176k  0xc
 #define SPDIF_CHSTAT_FREQ_24k   0x6
 #define SPDIF_CHSTAT_FREQ_48k   0x2
 #define SPDIF_CHSTAT_FREQ_96k   0xa
 #define SPDIF_CHSTAT_FREQ_192k  0xe
 #define SPDIF_CHSTAT_FREQ_32k   0x3
 #define SPDIF_CHSTAT_FREQ_NA    0x1

/* Clock Accuracy Defines */
 #define SPDIF_CHSTAT_CLK_ACC_L2 0x0
 #define SPDIF_CHSTAT_CLK_ACC_L1 0x1
 #define SPDIF_CHSTAT_CLK_ACC_L3 0x2
 #define SPDIF_CHSTAT_CLK_ACC_LN 0x3

 /* Frequency table from IEC 61937-1: Annex A: */
 #define SPDIF_CHSTAT_SYMFREQ_NOT_INDICATED   0x1
 #define SPDIF_CHSTAT_SYMFREQ_44k   0x0
 #define SPDIF_CHSTAT_SYMFREQ_48k   0x2
 #define SPDIF_CHSTAT_SYMFREQ_32k   0x3
 #define SPDIF_CHSTAT_SYMFREQ_22k   0x4
 #define SPDIF_CHSTAT_SYMFREQ_96k   0xA
 #define SPDIF_CHSTAT_SYMFREQ_192k 0xE

 /* Word Length Defines */
#define SPDIF_CHSTAT_WORDLEN_16b   0x2 // 0000 0010  b32
#define SPDIF_CHSTAT_WORDLEN_24b   0xb // 0000 1011  b32

                                /* a     b        c        info     mode0 */
#define SPDIF_DEFAULT_CHSTAT_BYTE0 ( (0) | (1<<1) | (0<<2) | (0<<3) | (0<<6) )

                                /* category code */
#define SPDIF_DEFAULT_CHSTAT_BYTE1 ( 0x84 )

                                /* source_num   channel_num */
#define SPDIF_DEFAULT_CHSTAT_BYTE2 ( 0            | (0<<4))

                                /* sample_freq               clk_accuracy */
#define SPDIF_DEFAULT_CHSTAT_BYTE3 ( SPDIF_CHSTAT_SYMFREQ_48k | (SPDIF_CHSTAT_CLK_ACC_L2<<4))

                                /* word_len      orig_freq */
#define SPDIF_DEFAULT_CHSTAT_BYTE4 ( 0            | (0<<4))

                                /* */
#define SPDIF_DEFAULT_CHSTAT_BYTE5 ( 0 )

#ifdef THIS_ENUM_NOW_IN_ISMD_AUDIO_DEFS_H
typedef enum{
SPDIF_CATEGORY_GENERAL = 0x00, //   000 00000 General. Used temporarily
SPDIF_CATEGORY_LASER_OPTICAL = 0x01, //** 100 XXXXL Laser optical products
SPDIF_CATEGORY_DIG_CONVERTERS_OR_SIGNAL_PROCESSING = 0x02, //   010 XXXXL Digital/digital converters and signal processing products
SPDIF_CATEGORY_MAGNETIC_TAPE_OR_DISC = 0x03,//   110 XXXXL Magnetic tape or disc based products
SPDIF_CATEGORY_DIGITAL_BROADCAST = 0x04, //** 001 XXXXL Broadcast reception of digitally encoded audio signals with or without video signals
SPDIF_CATEGORY_DIGITAL_BROADCAST1 = 0x0E, //** 011 1XXXL Broadcast reception of digitally encoded audio signals with or without video signals
SPDIF_CATEGORY_MUSICAL_RECORDING = 0x05, //   101 XXXXL Musical instruments, microphones and other sources without copyright information
SPDIF_CATEGORY_ANALOG_DIG_CONVERTERS_NO_COPYRIGHT = 0x06, //  011 00XXL Analogue/digital converters for analogue signals without copyright information
SPDIF_CATEGORY_ANALOG_DIG_CONVERTERS_COPYRIGHT = 0x16, //  011 01XXL Analogue/digital converters for analogue signals which include copyright information
SPDIF_CATEGORY_SOLID_STATE_MEMORY = 0x08, //   000 1XXXL Solid state memory based products
SPDIF_CATEGORY_EXPERIMENTAL = 0x40, //   000 0001L Experimental products not for commercial sale
SPDIF_CATEGORY_RESERVED = 0x07, // 111 XXXXL Not defined. Reserved
}spdif_chan_stat_category_code_t;
#endif

/*******************************************************************/


#endif

