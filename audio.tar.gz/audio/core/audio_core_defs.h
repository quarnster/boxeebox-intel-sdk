
/*
* File Name: audio_core.h
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



/** @weakgroup ismd_audio ISMD Audio Data Types */
/** @ingroup ismd_audio */
/** @{ */

#ifndef _ISMD_AUDIO_CORE_DEFS_H_
#define _ISMD_AUDIO_CORE_DEFS_H_

#include "ismd_audio_defs.h"
#include "ismd_global_defs.h"


extern int audio_sven_dbg_type, audio_sven_log_level_override;
extern bool audio_enable_sven_log[];
extern int audio_debug_method;

/*Devices and instances supported, numbers not finailzed yet.*/
#define AUDIO_MAX_RENDER_DEVICES 4
#define AUDIO_MAX_CAPTURE_DEVICES 1
#define AUDIO_MAX_ATC_CONTEXTS AUDIO_MAX_PROCESSORS
#define AUDIO_MAX_ATC_STREAMS AUDIO_MAX_INPUTS
#define AUDIO_MAX_PSM_DEVICES AUDIO_MAX_PROCESSORS
#define AUDIO_MAX_SCRUB_DEVICES 1
#define AUDIO_MAX_SCRUB_STREAMS 3

#define ATC_UNDERRUN_MAX_COUNT 3
#define ATC_DEFAULT_MS_DRIFT_AHEAD 2
#define ATC_DEFAULT_MS_DRIFT_BEHIND 2

#define AUDIO_INVALID_HANDLE -1

/* This is the chuck size we are using from the ATC down to the render */
#define AUDIO_CHUNK_TIME_PERIOD_MS 10
#define RENDER_PREFILL_CHUNK 4      // 4 * chunk_period
#define FIXED_BACK_END_PIPE_DELAY_CHUNK 3 // 3 * chunk_period This is the overal back end delay of the post processing pipe.

/* Want to make this a fairly large number since the ATC should never release a buffer and have it arrive that early.  */
#define RENDER_EARLY_DISCARD_POLICY_MAX_PERIODS ((FIXED_BACK_END_PIPE_DELAY_CHUNK*4)+(RENDER_PREFILL_CHUNK *4))  

#define CAPTURE_BUFFER_PREFILL_CHUNK 4    //Prepare 4 empty buffers to DMA
#define CAPTURE_OVERFLOW_THRESHOLD 80  // 80 ms delay time

// In trick mode for rate > 2x and < 1x drop the buffers from input port upto this much duration before the current time
#define AUDIO_PIPE_TIME_MS 100

#define CLOCK_SPEED_HZ 90000 // Ref clock is 90000Hz
#define CLOCK_TICKS_PER_MS (CLOCK_SPEED_HZ/1000) //Clock tics per milisecond
#define AUDIO_CHUNK_TIME_PERIOD_CLOCK_TICKS(x) (CLOCK_TICKS_PER_MS * AUDIO_CORE_GET_CHUNK_PERIOD(x))  // 
#define AUDIO_PIPE_TIME_TICKS (AUDIO_PIPE_TIME_MS * CLOCK_TICKS_PER_MS)

//Normalize all render time stamps to this sample rate.
#define AUDIO_NORMAL_SAMPLE_RATE 192000
#define AUDIO_CHUNK_SIZE_SAMPLES(x) ((AUDIO_NORMAL_SAMPLE_RATE/1000) * AUDIO_CORE_GET_CHUNK_PERIOD(x))

#define AC3_SPDIF_PACKET_CHUNK_SIZE (1536 * 4)

//Trick mode stuff.
#define AUDIO_MIN_PLAY_RATE (ISMD_NORMAL_PLAY_RATE*1)   /* 1.0x */
#define AUDIO_MAX_PLAY_RATE (ISMD_NORMAL_PLAY_RATE*2)   /* 2.0x */

//Misc defines
#define ABS(x) (((x) < 0) ? -(x) : (x))

#define MS_TO_SAMPLES(ms, smpl_rate) ((smpl_rate/1000) * ms)

#define SAMPLES_TO_CLOCK_TICKS(sample_count, smpl_rate) ( (sample_count * CLOCK_SPEED_HZ) /smpl_rate)
#define SAMPLES_TO_CLOCK_TICKS_64(sample_count, smpl_rate) ( AUDIO_DIV64( (int64_t)((int64_t)sample_count * (int64_t)CLOCK_SPEED_HZ), (int64_t)smpl_rate))
#define CLOCK_TICKS_TO_SAMPLES(clock_ticks, smpl_rate) ( (clock_ticks * smpl_rate) / CLOCK_SPEED_HZ )
#define CLOCK_TICKS_TO_SAMPLES_64(clock_ticks, smpl_rate) ( AUDIO_DIV64((int64_t)((int64_t)clock_ticks * (int64_t)smpl_rate), (int64_t)CLOCK_SPEED_HZ) )

//OSAL_DIV64 doesnt work well with negavite numbers.
#define AUDIO_DIV64(x,y) \
   ( { \
      bool neg_res = false; \
      int64_t tmp = 0; \
      int64_t _x = x, _y = y; \
      if((x < 0) && (y>0)) { \
         neg_res = true; \
         _x = -x; \
      } \
      if((x > 0) && (y<0)) { \
         neg_res = true; \
         _y = -y; \
      } \
      if((x < 0) && (y<0)) { \
         _y = -y; \
         _x = -x; \
      } \
     tmp = OSAL_DIV64(_x,_y); \
     if(neg_res) { \
         tmp = -tmp; \
     } \
      tmp; \
   } )



/**** Debug messaging macros ****/

/*
  Log level rules:
   1 - Only ERRORS will be logged.
   2 - Level 1 logs + events that dont happen very often. (ie. time base set event)
   3 - Level 1 and 2 logs + function enter and exit events will print in this level, events that happen somewhat frequently, but not all the time.
   4 - Level 1, 2, and 3 logs + events that happen very freqent often. (ie. timestamps, clock error etc.)
   5 - Level 1, 2, 3, and 4 logs +  everything should print, at this level driver performance is degraded. (ie. buffer dequeue, enqueue)

   Keep in mind that if audio_debug_method is set to AUDIO_LOG_DISABLE nothing will print.

*/
#define AUDIO_ERROR_LOG_LEVEL 1
#define AUDIO_ENTER_EXIT_LOG_LEVEL 3


#define AUDIO_ERROR(str, result, dev_h) \
      switch (audio_debug_method){ \
         case AUDIO_LOG_SVEN: \
            if(NULL != dev_h)\
               DEVH_FATAL_ERROR(dev_h, str); \
               OS_INFO(" ERROR: %s: Return Code: %d %s\n", str, result, audio_core_result_to_string(result)); \
            break; \
         case AUDIO_LOG_OS_PRINT: \
               OS_INFO(" ERROR: %s: Return Code: %d %s\n", str, result, audio_core_result_to_string(result)); \
            break; \
         case AUDIO_LOG_DISABLE: \
            break; \
         default: \
            break; \
      }

#define AUDIO_GDL_ERROR(str, result, dev_h) \
switch (audio_debug_method){ \
   case AUDIO_LOG_SVEN: \
      if(NULL != dev_h)\
         DEVH_FATAL_ERROR(dev_h, str); \
         OS_INFO(" ERROR: %s: Return Code: %d %s\n", str, result, audio_core_gdl_result_to_string(result)); \
      break; \
   case AUDIO_LOG_OS_PRINT: \
         OS_INFO(" ERROR: %s: Return Code: %d %s\n", str, result, audio_core_gdl_result_to_string(result)); \
      break; \
   case AUDIO_LOG_DISABLE: \
      break; \
   default: \
      break; \
}

#define AUDIO_OSAL_ERROR(str, result, dev_h) \
   do { \
      result = ISMD_ERROR_OPERATION_FAILED; \
      AUDIO_ERROR(str, result, dev_h); \
   } while(0) \

#define AUDIO_ENTER(dev_h) \
      switch (audio_debug_method){ \
         case AUDIO_LOG_SVEN: \
            if(NULL != dev_h && audio_enable_sven_log[AUDIO_SVEN_LOG_FUNCTION])\
               DEVH_FUNC_ENTER(dev_h); \
            break; \
         case AUDIO_LOG_OS_PRINT: \
            if(audio_enable_sven_log[AUDIO_SVEN_LOG_FUNCTION])\
               OS_INFO("Function %s Entered.\n", __FUNCTION__); \
            break; \
         case AUDIO_LOG_DISABLE: \
            break; \
         default: \
            break; \
      }

#define AUDIO_EXIT(dev_h) \
      switch (audio_debug_method){ \
         case AUDIO_LOG_SVEN: \
            if(NULL != dev_h && audio_enable_sven_log[AUDIO_SVEN_LOG_FUNCTION])\
               DEVH_FUNC_EXIT(dev_h); \
            break; \
         case AUDIO_LOG_OS_PRINT: \
            if(audio_enable_sven_log[AUDIO_SVEN_LOG_FUNCTION])\
               OS_INFO("Function %s Exited.\n", __FUNCTION__); \
            break; \
         case AUDIO_LOG_DISABLE: \
            break; \
         default: \
            break; \
      }

#define AUDIO_WARN(log_level, str, dev_h) \
      switch (audio_debug_method){ \
         case AUDIO_LOG_SVEN: \
            if(NULL != dev_h && audio_enable_sven_log[log_level]) \
               DEVH_WARN( dev_h, str); \
            break; \
         case AUDIO_LOG_OS_PRINT: \
            if(audio_enable_sven_log[log_level])\
               OS_INFO("WARNING: %s - %s\n", __FUNCTION__, str); \
            break; \
         case AUDIO_LOG_DISABLE: \
            break; \
         default: \
            break; \
      }

#define AUDIO_EVENT(log_level, dev_h, event, var1, var2, var3, var4, var5, var6) \
      switch (audio_debug_method){ \
         case AUDIO_LOG_SVEN: \
            if (NULL != dev_h && audio_enable_sven_log[log_level]){ \
            devh_SVEN_WriteModuleEvent(dev_h, event, var1, var2, var3, var4, var5, var6); \
            } \
            break; \
         case AUDIO_LOG_OS_PRINT: \
            if(audio_enable_sven_log[log_level]){\
               OS_INFO("%s: Event: %d, var1: 0x%x, var2: 0x%x, var3: 0x%x, var4: 0x%x, var5: 0x%x, var6: 0x%x,\n", __FUNCTION__,event, var1,var2,var3,var4,var5,var6); \
            }\
            break; \
         case AUDIO_LOG_DISABLE: \
            break; \
         default: \
            break; \
      }

#define AUDIO_INFO(log_level, dev_h, str, ...) \
      switch (audio_debug_method){ \
         case AUDIO_LOG_SVEN: \
            if (NULL != dev_h &&audio_enable_sven_log[log_level]){ \
               DEVH_DEBUG(dev_h, str); \
            }\
            break; \
         case AUDIO_LOG_OS_PRINT: \
            if (audio_enable_sven_log[log_level]) { \
               OS_INFO("Function %s : ", __FUNCTION__); \
               OS_INFO(str, __VA_ARGS__); \
               OS_INFO("\n"); \
            } \
            break; \
         case AUDIO_LOG_DISABLE: \
            break; \
         default: \
            break; \
      }


/**
   Unit specifc SVEN debug identifiers.
   \enum ismd_audio_debug_unit_type_t
*/
typedef enum {
   AUDIO_DEBUG_APM, /**< Audio Pipeline Manager (Highest level control code) unit. */
   AUDIO_DEBUG_CORE, /**< Audio core code control unit. */
   AUDIO_DEBUG_ATC , /**< Timed mixer, SRC, downmixing SW unit. */
   AUDIO_DEBUG_SCRUB , /**< ES Scrubber audio SW unit. */
   AUDIO_DEBUG_RENDER , /**< Audio Render SW unit. */
   AUDIO_DEBUG_CAPTURE , /**< Audio Capture SW unit. */
   AUDIO_DEBUG_PSM,  /**< PSM Host side unit */
   AUDIO_DEBUG_DSP, /**< Audio DSP unit. Applies to the Host side of implementation of PSM on DSP. */
   AUDIO_DEBUG_UNIT_MAX /**< Maximum audio units count. */
} ismd_audio_debug_unit_t;

/**
   Defines different levels of SVEN logging
   \enum ismd_audio_sven_log_t
*/
typedef enum {
   AUDIO_SVEN_LOG_NONE      = 0,
   AUDIO_SVEN_LOG_CRITICAL  = 1,
   AUDIO_SVEN_LOG_DATAFLOW  = 2,
   AUDIO_SVEN_LOG_GENERAL   = 3,
   AUDIO_SVEN_LOG_FUNCTION  = 4,
   AUDIO_SVEN_LOG_NUMBERS   = 5
}ismd_audio_sven_log_t;

/**
   Defines different methods of reporting out
   debug information.
   \enum ismd_audio_debug_print_t
*/
typedef enum {
   AUDIO_LOG_SVEN = 0,
   AUDIO_LOG_OS_PRINT = 1,
   AUDIO_LOG_DISABLE = 2
}ismd_audio_debug_log_t;

typedef enum ismd_audio_tx_context_t{
     ISMD_AUDIO_TX_CONTEXT_TX0,  // TX context 0
     ISMD_AUDIO_TX_CONTEXT_TX1,  // TX context 1
     ISMD_AUDIO_TX_CONTEXT_TX2,  // TX context 2
     ISMD_AUDIO_TX_CONTEXT_COUNT
} ismd_audio_tx_context_t;

typedef enum ismd_audio_i2s_pin_t{
     ISMD_AUDIO_I2S_PIN0,  // pin 0
     ISMD_AUDIO_I2S_PIN1,  // pin 1
     ISMD_AUDIO_I2S_PIN2,  // pin 2
     ISMD_AUDIO_I2S_PIN3   // pin 3
} ismd_audio_i2s_pin_t;

typedef enum ismd_audio_rx_context_t{
     ISMD_AUDIO_RX_CONTEXT_RX0,  // RX context 0
} ismd_audio_rx_context_t;

typedef enum ismd_audio_dma_context_t{
     ISMD_AUDIO_DMA_CONTEXT0,    // DMA context 0
     ISMD_AUDIO_DMA_CONTEXT1,    // DMA context 1
     ISMD_AUDIO_DMA_CONTEXT2,    // DMA context 2
     ISMD_AUDIO_DMA_CONTEXT3,    // DMA context 3
     ISMD_AUDIO_DMA_CONTEXT_MAX
} ismd_audio_dma_context_t;

typedef struct {
   ismd_newsegment_tag_t  curr_seg_info; //Copy of the last new segment info
   int curr_rate; //Possibly changed out of band.
   ismd_pts_t last_linear_rate_change_time;
   ismd_pts_t last_scaled_rate_change_time;
}audio_time_rebase_info_t;


/********************************************************************/


#endif

