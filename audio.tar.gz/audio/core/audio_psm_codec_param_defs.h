/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_PSM_CODEC_PARAM_DEFS_H_
#define _AUDIO_PSM_CODEC_PARAM_DEFS_H_

/* --------------------------------------------------------------------------- */
/* !!! WARNING NOTICE !!! */
/* --------------------------------------------------------------------------- */
/* The HOST and DSP FW need to be recompiled if changes are made to this file  */
/* --------------------------------------------------------------------------- */

/** Configuration parameters for the AAC decoder. */
typedef struct {
   int pcm_wdsz;
   int bdownsample;
   int downmix;
   int externalsr;
   int bsformat;
   int outnchans;
   int sbr_signaling;
   int chanrouting[8];
   int to_stereo;
   int zero_unused_chans;
   int aac_format;
   int num_channels;
   int samp_freq;
   int aac_samplerate;
   int data_rate;
   int acmod;
   int sbr_type;
   int chanmap;
   bool b_aac_surround_mono_to_stereo;
   bool b_aac_downmixer;
   int enable_drc;
   int enable_prl;
   int drc_cut_fac;
   int drc_boost_fac;
   int target_level;
} audio_psm_decode_aac_config_params_t; 

/** Configuration parameters for the WMA9 decoder. */
typedef struct {
   int samp_freq;
   int num_channels;
   int w_format_tag;
   int pcm_wdsz;
   int block_align;
   int wma_encode_opt;
   int avg_bytes_per_sec;
} audio_psm_decode_wm9_config_params_t;

/** Configuration parameters for the MPEG decoder. */
typedef struct {
   int pcm_wd_sz;
   int crc_check;
   int mch_enable;
} audio_psm_decode_mpeg_config_params_t;

/** Configuration parameters for the Dolby Digital (AC3) decoder. */
typedef struct {
   int karac;
   int dynrng_mode;
   int lfe_out;
   int ocfg;
   int num_och;
   int pcm_scale;
   int stereo_mode;
   int mono_rep;
   int dyn_cut_hi;
   int dyn_boost_lo;
   int chan_map[6];
   int ext_dnmixtab[36];
   int block_repeat;
} audio_psm_decode_ac3_config_params_t;

/** Configuration parameters for the Dolby Digital Plus decoder. */
typedef struct {
   int chanrouting[8];
   int num_och;
   int lfe_out;
   int ocfg;
   int stereo_mode;
   int mono_rep;
   int karac;
   int pcm_scale;
   int dynrng_mode;
   int dyn_cut_hi;
   int dyn_boost_lo;
   int quitonerr;
   int framestart;
   int frameend;
   int acmod;
} audio_psm_decode_ddplus_config_params_t;

/** Configuration parameters for the Dolby TrueHD decoder. */
typedef struct {
   int decmode; 
   int zero_unused_chans;
   int blockcrc;
   int lossless;
   int drc_enable;
   int drc_cut;
   int drc_boost;
   int dialref;
   int fbachannelorder;
   bool dialrefsupplied;
} audio_psm_decode_truehd_config_params_t;

/** Configuration parameters for the DTS core decoder. */
typedef struct {
   int spkrout;
   int drcpercent;
   int num_och;
   int lfeindex;
   bool secondary_audio_present;
   volatile int bitspersample;
   int downmixmode;
} audio_psm_decode_dts_config_params_t;

/** Configuration parameters for the DTS Broadcast decoder. */
typedef struct {
   int pcmsize;                   /** Bit depth of input bitstream.*/
   int spkrout;                   /** Channel config of generated output.*/
   int lfednmix;                  /** Flag to enable Lfe downmix on two front channels.*/
   int dwnmixmode;                /** Flag to specify internal or external downmix mode.*/
   int spkrremapmode;             /** Flag to specify internal or external speaker remapper mode.*/
   int playermixoutmode;          /** Type of secondary audio mixing enabled.*/
   int drcpercent;                /** Dynamic range control setting.*/
   bool disdialnorm_flag;         /** Flag to signal to the decoder if disable dialknorm is enabled.*/
   bool disable_dialnorm;         /** Flag to disable dialnorm enabled in bitstream.*/
   bool drc_prsent;               /** Flag to explicitly enable user defined DRC percent rather than the one embedded in the bitstream.*/
}audio_psm_decode_dts_bc_config_params_t;

/** Configuration parameters for the DTS HD decoder. */
typedef struct {
   int sample_width;
   int spkrout;
   int drc_percent;
   int lfe_index; 
   int decode_type;
   int downmix_mode;
   int spkr_remap_mode;
   bool multi_asset_decoding;
   bool enable_dts_es_matrix_sound_track;
   bool disable_dialogue_normalization;
   bool no_default_speaker_remapping;
   unsigned int audiopresentindex;
   unsigned int replacementsetconfig[3];
   int number_repchsets;
   bool secondary_audio_present;
} audio_psm_decode_dts_hd_config_params_t;

/** Configuration parameters for the Dolby Digital (AC3) encoder. */
typedef struct {
   int      acmod;           /** The coding mode of the encoder.*/
   int      lofreqeffon;     /**  */
   int      lfefiltinuse;    /** LFE filter in use or not. */
   int      num_ich;         /** Number of input channels given to the encoder.*/
   int      data_rate_code;  /** The bitrate of the output of the encoder. */
   int      pcm_wdsz;        /** Input sample size of the PCM data. */
   int      compchar;        /**  */
   int      compchar2;       /**  */
   int      testmodeon;      /** Flag for the test mode operation implemented in the encoder. */
   int      samp_freq;       /** Sample rate output by encoder */
   int      chanrouting[6];  /** Route how the encoder outputs the channels. */
} audio_psm_codec_ac3_enc_config_params_t;

/** Configuration parameters for the DTS core encoder.*/
typedef struct {
   int      num_input_ch;        /** Number of input channels. Currently Max of 5. */
   int      lfe_present;         /** Encode with LFE or not. */
   int      total_num_input_ch;  /** Input channels to the encoder */
   int      sample_size;         /** Encoder output sample size */
   int      sample_rate;         /** Sample rate output by encoder */
   int      encode_format;       /** Encode type valid values are 1,2,3 */
} audio_psm_codec_dts_enc_config_params_t;

/** Configuration parameters for the AAC encoder.*/
typedef struct {
   // Input stream information
   int      num_input_ch;        /** Number of input channels. Currently max of 2. */
   int      sample_size;         /** Input sample size. Must be 16. */
   int      sample_rate;         /** Input sample rate. */
   int      downsample_flag;     /** The input down sampling request. 0 means the half requested input buffer size is needed.*/
                                 /** 1 means the full requested input buffer size is needed.*/
   // Output stream information
   int      data_rate;           /** The absolute bitrate of the output of the encoder. */
   int      quality_level;       /** The output quality level of the encoder. 0: least, 1:middle or 2:best */
   int      encode_mode;         /** Encode mode. Valid values are 0 = AAC Classic, 1 = AAC v1, 2 = AAC v2. Only value 0 is supported now */
} audio_psm_codec_aac_enc_config_params_t;

/** DDPLUS DCV decode configuration parameters.*/
typedef struct {
   int karac_mode;
   int dynrng_mode;
   int lfe_out;
   int ocfg;
   int num_och;
   int pcm_scale;
   int quit_on_err;
   int stereo_mode;
   int mono_rep;
   int dyn_cut_hi;
   int dyn_boost_lo;
   int chanrouting[6];
   int pcm_enabled;                /** PCM output is enabled or not */
   int dd_enabled;                 /** DD output is enabled or not */
   bool packetizer_enabled;         /** packetizer is enabled or not */
}audio_psm_codec_ddplus_dcv_config_params_t;

/** Configuration parameters for the DTS LBR decoder.*/
typedef struct {
   unsigned short ui16BitDepth; 
   unsigned short ui16StereoDwnMix; 
   unsigned int ui32NewSampleRate;
} audio_psm_decode_dts_lbr_config_params_t;

/** Configuration parameters for the NEO6 maxtrix decoder.*/
typedef struct {
   int samplebitdepth;
   int samplerate;
   int samplesperframe;
   bool input_over;
   int cgain;
   int mode;
   int channels;
} audio_neo6_management_params_t;

/** MS10 DDC decode configuration parameters.*/
typedef struct {
   bool assoc_audio_enable;         /** whether associated audio was enabled or not. To be deprecated */
   bool main_audio_dd_enabled;      /** DD output was enabled or not */
   bool pcm_enable;                 /** PCM output was enabled or not */
   bool packetize;                  /** Enable packetizer */
   int chanrouting[2];              /** DDC: force to [0:L, 1:R] */
   int num_och;                     /** DDC: force to 2 */
   int ocfg;                        /** DDC: force to 2 */   
   int lfe_out;                     /** DDC: force to 0 */
   int stereo_mode;
   int mono_rep;
   int karac;
   int pcm_scale;
   int dynrng_mode;
   int dyn_cut_hi;
   int dyn_boost_lo;
   int quitonerr;
   int framestart;
   int frameend;
   int acmod;
   int substream_id;
   int input_over;
}audio_psm_decode_ddc_config_params_t;

/** MS10 DDT configuration parameters.*/
typedef struct {
   int RfMode;
   int LoRoDownmix;
   int drcCutFac;
   int drcBoostFac;
   int dualMode;
}audio_psm_decode_ddt_pp_config_params_t;

/** MS10 DSP pipeline configuration parameters.*/
typedef struct {
   bool assoc_audio_ddt_enabled;
   bool main_audio_ddt_enabled;
   audio_psm_decode_aac_config_params_t      ddt_aac;
   audio_psm_decode_ddt_pp_config_params_t   ddt_pp;
   audio_psm_codec_ac3_enc_config_params_t   ddt_ac3_enc;
}audio_psm_decode_ddt_config_params_t;


/** Configuration parameters used by the DSP to change the codec configurations.*/
typedef union {
   audio_psm_decode_ac3_config_params_t         ac3_params;
   audio_psm_decode_ddplus_config_params_t      ddplus_params;
   audio_psm_decode_truehd_config_params_t      truehd_params;
   audio_psm_decode_mpeg_config_params_t        mpeg_params;
   audio_psm_decode_aac_config_params_t         aac_params;
   audio_psm_decode_wm9_config_params_t         wma_params;
   audio_psm_decode_dts_config_params_t         dts_params;
   audio_psm_decode_dts_lbr_config_params_t     dts_lbr_params;
   audio_psm_codec_ac3_enc_config_params_t      ac3_enc_params;
   audio_psm_codec_dts_enc_config_params_t      dts_enc_params;
   audio_psm_codec_aac_enc_config_params_t      aac_enc_params;
   audio_psm_codec_ddplus_dcv_config_params_t   ddplus_dcv_params;
   audio_neo6_management_params_t               neo6_params;
   audio_psm_decode_dts_hd_config_params_t      dts_hd_params;
   audio_psm_decode_dts_bc_config_params_t      dts_bc_params;
   audio_psm_decode_ddc_config_params_t         ddc_params;
   audio_psm_decode_ddt_config_params_t         ddt_params;
} audio_psm_decode_config_params_t;


#endif

