
/*
* File Name: audio_apm_outputs_quality.c
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_apm_common.h"

/*********************************************************************************************/

/************************** Audio Quality private defines .**************************************/
#define AUDIO_QUALITY_FILTER_HANDLE_START 0
#define AUDIO_QUALITY_CONTROL_HANDLE_START 100
#define AQ_CTRL_HNDLE(handle) (handle -AUDIO_QUALITY_CONTROL_HANDLE_START)
#define AQ_FLTR_HNDLE(handle) (handle -AUDIO_QUALITY_FILTER_HANDLE_START)

/************************** Audio Quality pipe helper functions.**************************************/

void
audio_quality_pipe_init(audio_quality_context_t *aq_pipe)
{
   int stage;
   int chan, i;

   OS_MEMSET(aq_pipe, 0, sizeof(audio_quality_context_t));

   aq_pipe->state.init_done = false;
   aq_pipe->state.in_use = false;
   aq_pipe->state.flt_param_change = false;
   aq_pipe->state.ctl_param_change = false;
   aq_pipe->state.config_change = false;
   aq_pipe->state.avl_config_change = false;
   aq_pipe->state.bypass_change = false;

   aq_pipe->ace_system.IAParams.DupBypass = true;
   for( chan = 0; chan < AUDIO_MAX_OUTPUT_CHANNELS; chan++ )
   {
   		aq_pipe->ace_system.IAParams.DupFrom[chan] = chan;
   }

   aq_pipe->ace_system.IAParams.PIMix4Bypass = true;
   aq_pipe->ace_system.IAParams.IAAVLBypass = true;
   aq_pipe->ace_system.IAParams.IAReverbBypass = true;

   //Configure the master mute control in Audio Quality
   aq_pipe->ace_system.IAParams.MasterMuteBypass = 1;
   aq_pipe->ace_system.IAParams.MasterMuteOn = 0;
   aq_pipe->ace_system.IAParams.MasterMuteRamp = 10;
   
   //Configure the master Volume control in Audio Quality. Always same handle.
   aq_pipe->ace_system.IAParams.MasterVolBypass = 1;
   aq_pipe->ace_system.IAParams.MasterVol = 0;
   aq_pipe->ace_system.IAParams.MasterVolRamp = 10;
   
   // set clamp bypass
   aq_pipe->ace_system.IAParams.IAClampBypass = 1;
   for( chan = 0; chan < AUDIO_MAX_OUTPUT_CHANNELS; chan++ )
   {
   		aq_pipe->ace_system.IAParams.IAClamp10xdB[chan] = 0;
   }
   
   for( chan = 0; chan < AUDIO_MAX_OUTPUT_CHANNELS; chan++ )
   {
   		for( stage = 0; stage < NUMACE_STAGES_PER_CHAN; stage++ )
   		{
   			aq_pipe->ace_system.IAParams.IAChannels[chan][stage] = ACE_INVALID_HANDLE;
   		}
   }
 
   for( chan = 0; chan < AUDIO_MAX_OUTPUT_CHANNELS; chan++ )
   {
		for( i = 0; i < 4; i++ )
		{
   			aq_pipe->ace_system.IAParams.PIMix4[chan].MixSrc[i] = -1;
		}
   }

   return;
}


static ismd_result_t
audio_quality_validate_filter_params(ismd_audio_quality_filter_params_t *params)
{
   ismd_result_t result = ISMD_ERROR_INVALID_PARAMETER;

   //TODO: Probably need to revise these limits here..
   if((params->fc < AUDIO_QUALITY_FILTER_FC_MIN) || (params->fc > AUDIO_QUALITY_FILTER_FC_MAX)){
      OS_PRINT("AUDIO QUALITY FILTER CONFIG ERROR: Invalid Fc value specified for the filter!\n");
   }

   else if( params->q < 0 ){
      OS_PRINT("AUDIO QUALITY FILTER CONFIG ERROR: Invalid Q value specified for the filter!\n");
   }

   else if((params->gain < ISMD_AUDIO_GAIN_MUTE) || (params->gain > ISMD_AUDIO_GAIN_MAX)){
      OS_PRINT("AUDIO QUALITY FILTER CONFIG ERROR: Invalid gain value specified for the filter!\n");
   }
   
   else {
      result = ISMD_SUCCESS;
   }
   
   return result;
}

static ismd_result_t
audio_quality_validate_control_params(ACECTLDSCR *control, ismd_audio_quality_control_params_t *params)
{
   ismd_result_t result = ISMD_SUCCESS;

   switch(control->type) {
      case ACETYP_AVLCTL:
         params->avl.t2_gain = ENSURE_VALID_GAIN(params->avl.t2_gain);
         params->avl.t1_gain = ENSURE_VALID_GAIN(params->avl.t1_gain);
         params->avl.t2 = ENSURE_VALID_GAIN(params->avl.t2);
         params->avl.t1 = ENSURE_VALID_GAIN(params->avl.t1);
         params->avl.offset_gain = ENSURE_VALID_GAIN(params->avl.offset_gain);
         params->avl.attack_time = FLOOR_CEIL(params->avl.attack_time, AUDIO_QUALITY_ATTACK_TIME_MIN, AUDIO_QUALITY_ATTACK_TIME_MAX);
         params->avl.release_time = FLOOR_CEIL(params->avl.release_time, AUDIO_QUALITY_REL_TIME_MIN, AUDIO_QUALITY_REL_TIME_MAX);
         break;
      case ACETYP_PCVOLCTL:
         params->pc_volume.gain = ENSURE_VALID_GAIN(params->pc_volume.gain );
         params->pc_volume.ramp = ENSURE_VALID_RAMP(params->pc_volume.ramp);
         break;
      case ACETYP_LOUDBASSCTL:
      case ACETYP_LOUDTREBCTL:
         //Need to validate bass treble params?
         break;
      default:
         break;
   }
   
   return result;
}

static bool
audio_quality_valid_filter_h(ismd_audio_quality_filter_t filter_h)
{
   //Since filter handles start at 1 check for that and that its less than the max.
   if((filter_h >= AUDIO_QUALITY_FILTER_HANDLE_START) && (filter_h <= AUDIO_QUALITY_MAX_FILTERS)) {
      return true;
   }
   return false;
}

static bool
audio_quality_valid_control_h(ismd_audio_quality_control_t control_h)
{
   //Since filter handles start at 1 check for that and that its less than the max.
   //Also allow for our special AVL handle. 
   if( (control_h >= AUDIO_QUALITY_CONTROL_HANDLE_START) && 
      (control_h < (AUDIO_QUALITY_CONTROL_HANDLE_START + AUDIO_QUALITY_MAX_CONTROLS)))
      {
      return true;
   }
   return false;
}

static bool
audio_quality_valid_stage_location(int stage)
{
   //Since filter handles start at 1 check for that and that its less than the max.
   if((stage >= 0) && (stage < AUDIO_QUALITY_MAX_STAGES)) {
      return true;
   }
   return false;
}


static void
audio_quality_control_update_params(ACECTLDSCR *control, ismd_audio_quality_control_params_t *params)
{

   switch(control->type) {
      
      case ACETYP_PCVOLCTL:
         control->NumParms = 2;
         control->Parms[0] = params->pc_volume.gain;
         control->Parms[1] = params->pc_volume.ramp;
         break;

      //Bass and treble together will access the same location in the union.   
      case ACETYP_LOUDBASSCTL:
      case ACETYP_LOUDTREBCTL:
         control->NumParms = 8;
         control->Parms[0] = params->bass_loud.volume;
         control->Parms[1] = params->bass_loud.set_p;
         control->Parms[2] = params->bass_loud.set_l;
         control->Parms[3] = params->bass_loud.set_h;
         control->Parms[4] = params->bass_loud.k0;
         control->Parms[5] = params->bass_loud.k1;
         control->Parms[6] = params->bass_loud.k2;
         control->Parms[7] = params->bass_loud.fc;
         break;
      default:
         break;
   }
   
   return ;
}

static int
audio_quality_control_get_type(ismd_audio_quality_control_type_t type)
{
   switch(type) {
	  case ISMD_AUDIO_CONTROL_PC_VOLUME:
         return ACETYP_PCVOLCTL;
         break;
  
      case ISMD_AUDIO_CONTROL_BASS_LIMITER:
         return ACETYP_LOUDBASSCTL;
         break;

      case ISMD_AUDIO_CONTROL_TREBLE_LIMITER:
         return ACETYP_LOUDTREBCTL;
         break;

      case ISMD_AUDIO_CONTROL_INVALID:
      default:
         break;
   }
   return ACETYP_NONE;
}


static int
audio_quality_filter_get_type(ismd_audio_quality_filter_type_t type)
{
   switch(type) {
      case ISMD_AUDIO_FILTER_HPF2:
         return ACETYP_HPF2;
         break;
      case ISMD_AUDIO_FILTER_LPF2:
         return ACETYP_LPF2;
         break;
      case ISMD_AUDIO_FILTER_HPF1:
         return ACETYP_HPF1;
         break;
      case ISMD_AUDIO_FILTER_LPF1:
         return ACETYP_LPF1;
         break;      
      case ISMD_AUDIO_FILTER_SHLF_L2:
         return ACETYP_SHLF_L2;
         break;         
      case ISMD_AUDIO_FILTER_SHLF_H2:
         return ACETYP_SHLF_H2;
         break;
      case ISMD_AUDIO_FILTER_SHLF_L1:
         return ACETYP_SHLF_L1;
         break;
      case ISMD_AUDIO_FILTER_SHLF_H1:
         return ACETYP_SHLF_H1;
         break;
      case ISMD_AUDIO_FILTER_PEQ2:
         return ACETYP_PEQ2;
         break;      
      case ISMD_AUDIO_FILTER_INVALID:
      case ISMD_AUDIO_FILTER_COUNT:
      default:        
         break;
   }
   return ACETYP_NONE;
}


void
audio_quality_pipe_get_context(ismd_audio_processor_context_t *wl, int output_h, audio_quality_context_t **aq_pipe)
{
   audio_quality_params_t * aq_params = NULL;
   
   //Get the parameters out of the buffer.
   aq_params = (audio_quality_params_t *)(((ismd_buffer_descriptor_t *)wl->psm_pa_pipe.stages[QUALITY_STAGE].params.params_buffer.smd_buf_desc)->virt.base);

   //Return the context.
   *aq_pipe = &aq_params->context[output_h];
}


static ismd_result_t
audio_quality_pipe_validate_and_lock( ismd_audio_processor_t processor_h, ismd_audio_output_t output_h, ismd_audio_output_wl_t **output_wl,  audio_quality_context_t **aq_pipe)
{
   ismd_result_t  result;
   ismd_audio_processor_context_t *wl = NULL;
   ismd_audio_output_wl_t *out_wl = NULL;

   if( (result = audio_processor_lock_and_get_wl(processor_h, &wl)) == ISMD_SUCCESS){

      if((result = audio_output_validate_and_lock_wl(processor_h, output_h, &out_wl)) == ISMD_SUCCESS){

         if(!out_wl->in_use){
            result = ISMD_ERROR_INVALID_HANDLE;
            AUDIO_ERROR("Output handle has not been allocated.", result, audio_devh[AUDIO_DEBUG_APM]);
            audio_output_unlock(out_wl);
            audio_processor_unlock(wl);
         }
         else {
            //Return the output context
            *output_wl = out_wl;
            //Return the AQ pipe context.
            audio_quality_pipe_get_context(wl, output_h, aq_pipe);
         }
      }
      else {
         audio_processor_unlock(wl);
         result = ISMD_ERROR_INVALID_HANDLE;
      }
   }

   return result;
}

static ismd_result_t
audio_quality_pipe_commit_changes(ismd_audio_processor_context_t *wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   //Commit changes to PSM if running.
   if(wl->psm_pa_pipe.pipe_configured){
      
      if((result = audio_psm_stage_config_direct(wl->psm_pa_pipe.pipe_h, 
         wl->psm_pa_pipe.stages[QUALITY_STAGE].handle, NULL)) != ISMD_SUCCESS) {

         AUDIO_ERROR("Could not commit changes to AQ pipe!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   
   return result;
}

static ismd_result_t
audio_quality_pipe_get_filter_handle(audio_quality_context_t *aq_pipe, ismd_audio_quality_control_t *filter_h, ismd_audio_quality_filter_type_t type)
{
   int i = 0;
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;

   for(i = 0; i < AUDIO_QUALITY_MAX_FILTERS; i++) {

      //Filter handles for ACE start at 1
      if(aq_pipe->ace_system.IAParams.IAFilters[i].type == ACETYP_NONE) {

         //Marking this as used
         aq_pipe->ace_system.IAParams.IAFilters[i].type = audio_quality_filter_get_type(type);
         *filter_h = i + AUDIO_QUALITY_FILTER_HANDLE_START;
         result = ISMD_SUCCESS;
         break;
      }
   }
   
   return result;
}

//For debug.
static void
audio_quality_pipe_print_config(audio_quality_context_t *aq_pipe)
{
   int chan = 0;
   int stage = 0;

      OS_PRINT("\n\n"); 
      for(chan = 0; chan < AUDIO_MAX_OUTPUT_CHANNELS; chan++) {

         OS_PRINT("Channel %d:  ", chan);
      
         for(stage = 0; stage < AUDIO_QUALITY_MAX_STAGES; stage++) {

            OS_PRINT(" %d  ", aq_pipe->ace_system.IAParams.IAChannels[chan][stage]);
            
         }
         OS_PRINT("\n");     
      }

      
    OS_PRINT("AVL present: %d \n", !aq_pipe->ace_system.IAParams.IAAVLBypass);
      
      OS_PRINT("\n\n");
}


/***********************************************/


/*********************************************************************************************/
/* Audio Ouput Quality APIs*/
/*********************************************************************************************/


ismd_result_t  ismd_audio_output_mute(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              bool  mute,
                              int ramp_ms)
{
   int was_mute;
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   //Lock the processor and the output, get the output_wl and the audio quality pipe context.
   if((result = audio_quality_pipe_validate_and_lock(processor_h, output_h, &output_wl, &aq_pipe)) == ISMD_SUCCESS){

      if(output_wl->output_mode != ISMD_AUDIO_OUTPUT_PASSTHROUGH) {
            
		    aq_pipe->state.in_use = true;

            //Set the parameter in the AQ pipe for mute.
            was_mute = aq_pipe->ace_system.IAParams.MasterMuteOn; 
            aq_pipe->ace_system.IAParams.MasterMuteOn = mute; //Is Muted.

            //See if we have a change in mute, if yes, commit the change.
            if((mute && !was_mute) || (!mute && was_mute)) { 
               aq_pipe->state.ctl_param_change = true;
            }

        	if ( aq_pipe->ace_system.IAParams.MasterMuteRamp != ramp_ms )
        	{
        		aq_pipe->ace_system.IAParams.MasterMuteRamp = ENSURE_VALID_RAMP(ramp_ms);
        		aq_pipe->state.ctl_param_change = true;
        	}
        	
        	
        	if ( aq_pipe->ace_system.IAParams.MasterMuteBypass )
			{
				aq_pipe->ace_system.IAParams.MasterMuteBypass = 0;
				aq_pipe->state.bypass_change = true;
			}
			
            if(aq_pipe->state.ctl_param_change || aq_pipe->state.bypass_change){
			   /** Update the value of mute in the output workload */
			   output_wl->is_muted = mute;
               result = audio_quality_pipe_commit_changes(output_wl->processor_wl);
			   /** If mode is changing from passthrough to pcm under mute and then unmuted, ismd_audio_output_enable wouldnt be called explicitly again by this non-passthrough case, 
			       so need to enable the output. The mute/unmute in non passthrough case will be handled by the aq_pipe params*/
			   if((!output_wl->enabled)) {
			      result = audio_output_enable(output_wl);
			   }
            }

            //audio_quality_pipe_print_config(aq_pipe);
      }

      //handle passthrough outputs. 
      else {

         //Disable outputs for passthrough mute. 
         if(mute && !output_wl->is_muted) {
            result = audio_output_disable(output_wl);
         }
         else if (!mute && output_wl->is_muted) {
            result = audio_output_enable(output_wl);
         }
      }

      if(result == ISMD_SUCCESS) {
         output_wl->is_muted = mute;
      }
      
      audio_output_unlock(output_wl);
      audio_processor_unlock(output_wl->processor_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


ismd_result_t  ismd_audio_output_is_muted(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              bool *is_muted)
{
   ismd_result_t result  = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if((result = audio_output_validate_and_lock_wl(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){
      
      *is_muted = output_wl->is_muted;
      audio_output_unlock(output_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


ismd_result_t  ismd_audio_output_set_volume(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_gain_value_t  gain, 
                              int ramp_ms)
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   //Lock the processor and the output, get the output_wl and the audio quality pipe context.
   if((result = audio_quality_pipe_validate_and_lock(processor_h, output_h, &output_wl, &aq_pipe)) == ISMD_SUCCESS) {

      if(output_wl->output_mode != ISMD_AUDIO_OUTPUT_PASSTHROUGH) {

			aq_pipe->state.in_use = true;

            //Set the parameter in the AQ pipe for Volume. 
            if(aq_pipe->ace_system.IAParams.MasterVol != gain){
               aq_pipe->ace_system.IAParams.MasterVol = ENSURE_VALID_GAIN(gain);
               aq_pipe->state.ctl_param_change = true;
            }

            //Dont need to commit for a ramp change.
            if ( aq_pipe->ace_system.IAParams.MasterVolRamp != ramp_ms )
            {
            	aq_pipe->ace_system.IAParams.MasterVolRamp = ENSURE_VALID_RAMP(ramp_ms);
            	aq_pipe->state.ctl_param_change = true;
            }

			if ( aq_pipe->ace_system.IAParams.MasterVolBypass )
			{
				aq_pipe->ace_system.IAParams.MasterVolBypass = 0;
				aq_pipe->state.bypass_change = true;
			}
			
            if(aq_pipe->state.ctl_param_change || aq_pipe->state.bypass_change ) {
               result = audio_quality_pipe_commit_changes(output_wl->processor_wl);
            }

            output_wl->curr_gain = ENSURE_VALID_GAIN(gain);

         //audio_quality_pipe_print_config(aq_pipe);

      }
      else {
         result = ISMD_SUCCESS;
         OS_PRINT("\nAUDIO: Warning, cannot apply volume to a passthrough output.\n");
      }
      audio_output_unlock(output_wl);
      audio_processor_unlock(output_wl->processor_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


ismd_result_t  ismd_audio_output_get_volume(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_gain_value_t  *gain)
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if((result = audio_output_validate_and_lock_wl(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

      *gain = output_wl->curr_gain;
      
      audio_output_unlock(output_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


ismd_result_t  ismd_audio_output_quality_reset(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h )
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;


   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if((result = audio_output_validate_and_lock_wl(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

      audio_quality_pipe_get_context(output_wl->processor_wl, output_wl->handle, &aq_pipe);

      /* Reinit Audio Pipe context, dont commit, need to call start. */
      audio_quality_pipe_init(aq_pipe);

	  aq_pipe->state.flt_param_change = true;
	  aq_pipe->state.ctl_param_change = true;
	  aq_pipe->state.avl_config_change = true;
	  aq_pipe->state.config_change = true;
	  aq_pipe->state.bypass_change = true;
	  output_wl->is_muted = false;

      audio_output_unlock(output_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


ismd_result_t  ismd_audio_output_quality_start(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h )
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   //Lock the processor and the output, get the output_wl and the audio quality pipe context.
   if((result = audio_quality_pipe_validate_and_lock(processor_h, output_h, &output_wl, &aq_pipe)) == ISMD_SUCCESS) {

      /* Need to ensure the DSP knows this context is in use. */
      aq_pipe->state.in_use = true;

      (void)audio_quality_pipe_print_config;
     //audio_quality_pipe_print_config(aq_pipe);

      /* Send message to start the audio quality pipe to PSM. */
      result = audio_quality_pipe_commit_changes(output_wl->processor_wl);

      audio_output_unlock(output_wl);
      audio_processor_unlock(output_wl->processor_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}                              


ismd_result_t  ismd_audio_output_quality_filter_alloc(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_quality_filter_type_t type,
                              ismd_audio_quality_filter_t *filter_h )
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   //Lock the processor and the output, get the output_wl and the audio quality pipe context.
   if((result = audio_quality_pipe_validate_and_lock(processor_h, output_h, &output_wl, &aq_pipe)) == ISMD_SUCCESS) {

      result = audio_quality_pipe_get_filter_handle(aq_pipe, filter_h, type);

      audio_output_unlock(output_wl);
      audio_processor_unlock(output_wl->processor_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}                              


ismd_result_t  ismd_audio_output_quality_control_alloc(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_quality_control_type_t type,
                              ismd_audio_quality_control_t *control_h )
{
   int i;
   int ace_type;
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   //Lock the processor and the output, get the output_wl and the audio quality pipe context.
   if((result = audio_quality_pipe_validate_and_lock(processor_h, output_h, &output_wl, &aq_pipe)) == ISMD_SUCCESS) {

   		//Init the control handle to invalid.
   		*control_h = AUDIO_INVALID_HANDLE;
   		ace_type = audio_quality_control_get_type(type);

		if ( ace_type == ACETYP_NONE )
		{
			result = ISMD_ERROR_INVALID_PARAMETER;
		}
		else
		{
			result = ISMD_ERROR_NO_RESOURCES;
			
   			// make sure this is an allowable type
			for( i = 0; i < AUDIO_QUALITY_MAX_CONTROLS; i++ ) 
			{
       			//Filter handles for ACE start at 101
       			if ( aq_pipe->ace_system.IAParams.IAControls[i].type == ACETYP_NONE) 
       			{
            		//Marking this control as used.
            		aq_pipe->ace_system.IAParams.IAControls[i].type = ace_type;
            		*control_h = i + AUDIO_QUALITY_CONTROL_HANDLE_START;
            		result = ISMD_SUCCESS;
            		break;
         		}
			}
     	}
     
      audio_output_unlock(output_wl);
      audio_processor_unlock(output_wl->processor_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


ismd_result_t  ismd_audio_output_quality_filter_config(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_quality_filter_t filter_h,
                              ismd_audio_quality_filter_params_t params)
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if((result = audio_output_validate_and_lock_wl(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

      if(audio_quality_valid_filter_h(filter_h)) {

         audio_quality_pipe_get_context(output_wl->processor_wl, output_wl->handle, &aq_pipe);

         //Validate filter params.
         if((result = audio_quality_validate_filter_params(&params)) == ISMD_SUCCESS) {
            aq_pipe->ace_system.IAParams.IAFilters[AQ_FLTR_HNDLE(filter_h)].Fc = params.fc;
            aq_pipe->ace_system.IAParams.IAFilters[AQ_FLTR_HNDLE(filter_h)].Q= params.q;
            aq_pipe->ace_system.IAParams.IAFilters[AQ_FLTR_HNDLE(filter_h)].Gain = params.gain;
            aq_pipe->state.flt_param_change = true;
         }
      }
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      audio_output_unlock(output_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


ismd_result_t  ismd_audio_output_quality_control_config(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_quality_control_t control_h, 
                              ismd_audio_quality_control_params_t params)
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;
   ACECTLDSCR *control_instance = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if((result = audio_output_validate_and_lock_wl(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

      if(audio_quality_valid_control_h(control_h)) {

         audio_quality_pipe_get_context(output_wl->processor_wl, output_wl->handle, &aq_pipe);

         /* Get the control context. */
         control_instance = &aq_pipe->ace_system.IAParams.IAControls[AQ_CTRL_HNDLE(control_h)];

         /* Validate then update the control. */
         if((result = audio_quality_validate_control_params( control_instance, &params)) == ISMD_SUCCESS) {   
            audio_quality_control_update_params(control_instance, &params);         
            aq_pipe->state.ctl_param_change = true;
         }          
      }
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      audio_output_unlock(output_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}                              


ismd_result_t  ismd_audio_output_quality_stage_config_control(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_quality_control_t control_h,
                              ismd_audio_channel_t channel,
                              int stage)

{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;
   bool valid_stage = false;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

  if((result = audio_output_validate_and_lock_wl(processor_h, output_h, &output_wl)) == ISMD_SUCCESS) {

      if((valid_stage = audio_quality_valid_stage_location(stage)) && audio_quality_valid_control_h(control_h)) {

         audio_quality_pipe_get_context(output_wl->processor_wl, output_wl->handle, &aq_pipe);

         //Update stage configuration.
          aq_pipe->ace_system.IAParams.IAChannels[channel][stage] = control_h;
          aq_pipe->state.config_change = true;    
      }
      else {
         result = (valid_stage) ? ISMD_ERROR_INVALID_HANDLE : ISMD_ERROR_INVALID_PARAMETER;
      }
      audio_output_unlock(output_wl);
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


ismd_result_t  ismd_audio_output_quality_stage_config_filter(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_quality_filter_t filter_h,
                              ismd_audio_channel_t channel,
                              int stage)
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if((result = audio_output_validate_and_lock_wl(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

      if(audio_quality_valid_filter_h(filter_h) && audio_quality_valid_stage_location(stage)) {

         audio_quality_pipe_get_context(output_wl->processor_wl, output_wl->handle, &aq_pipe);

         //Update stage configuration.
         aq_pipe->ace_system.IAParams.IAChannels[channel][stage] = filter_h;

         aq_pipe->state.config_change = true;        
      }
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      audio_output_unlock(output_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}


ismd_result_t  ismd_audio_output_quality_stage_bypass(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,
                              ismd_audio_channel_t channel,
                              int stage, 
                              bool bypass)
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   ismd_audio_output_wl_t *output_wl = NULL;
   audio_quality_context_t *aq_pipe = NULL;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if((result = audio_output_validate_and_lock_wl(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

      if(audio_quality_valid_stage_location(stage) && audio_core_valid_channel(channel)) {

         audio_quality_pipe_get_context(output_wl->processor_wl, output_wl->handle, &aq_pipe);

         //Update stage configuration.
         aq_pipe->ace_system.IAParams.IABypass[channel][stage] = bypass;

         aq_pipe->state.bypass_change = true;        
      }
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      audio_output_unlock(output_wl);
    }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}

ismd_result_t
ismd_audio_output_quality_set_fixed_controls(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,int OutChannel,int type,ismd_audio_quality_control_params_t params)
{
	int mix;
	int valid;
   	ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
    ismd_audio_output_wl_t *output_wl = NULL;
   	audio_quality_context_t *aq_pipe = NULL;
    
    AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

     if((result = audio_output_validate_and_lock_wl(processor_h, output_h, &output_wl)) == ISMD_SUCCESS){

            audio_quality_pipe_get_context(output_wl->processor_wl, output_wl->handle, &aq_pipe);

  			if ( type == ISMD_AUDIO_CONTROL_MINIMIX )
  			{       
         		valid = 1;
				for( mix = 0; mix < 4; mix++ )
				{
					if ( params.minimix.mix_src[mix] > AUDIO_MAX_OUTPUT_CHANNELS )
					{
						valid = 0;
						break;
					}		
				}
			
				if ( valid )
				{
         			for( mix = 0; mix < 4; mix++ )
         			{
         				aq_pipe->ace_system.IAParams.PIMix4[OutChannel].dBx10[mix] = ENSURE_VALID_GAIN(params.minimix.gain[mix]);
         				aq_pipe->ace_system.IAParams.PIMix4[OutChannel].MixSrc[mix] = params.minimix.mix_src[mix];
         				aq_pipe->ace_system.IAParams.PIMix4[OutChannel].PhInv[mix] = params.minimix.pi[mix];
         				aq_pipe->ace_system.IAParams.PIMix4[OutChannel].RampTC[mix] = ENSURE_VALID_RAMP(params.minimix.ramp[mix]);
         			}  		
         			aq_pipe->state.ctl_param_change = true;
				}
				else
				{
					 result = ISMD_ERROR_INVALID_PARAMETER;
				}
  			}
  			else if ( type == ISMD_AUDIO_CONTROL_AVL )
  			{
  				aq_pipe->ace_system.IAParams.IACtlAVL.T1 = params.avl.t1;
  			  	aq_pipe->ace_system.IAParams.IACtlAVL.T2 = params.avl.t2;
  			  	aq_pipe->ace_system.IAParams.IACtlAVL.T1Gain = params.avl.t1_gain;
  			  	aq_pipe->ace_system.IAParams.IACtlAVL.T2Gain = params.avl.t2_gain;
				aq_pipe->ace_system.IAParams.IACtlAVL.K0 = params.avl.k0;
				aq_pipe->ace_system.IAParams.IACtlAVL.K2 = params.avl.k2;
				aq_pipe->ace_system.IAParams.IACtlAVL.Attack = params.avl.attack_time;
				aq_pipe->ace_system.IAParams.IACtlAVL.Release = params.avl.release_time;
				aq_pipe->ace_system.IAParams.IACtlAVL.Offset = params.avl.offset_gain;
				
				aq_pipe->state.avl_config_change = true;
  			}
  			else if ( type == ISMD_AUDIO_CONTROL_CLAMP )
  			{
  				aq_pipe->ace_system.IAParams.IAClamp10xdB[OutChannel] = ENSURE_VALID_GAIN(params.clamp.level);
  				aq_pipe->state.ctl_param_change = true;
  			}
  			else if ( type == ISMD_AUDIO_CONTROL_DUP )
  			{
  				aq_pipe->ace_system.IAParams.DupBeforeStage = params.dup.DupBeforeStage;
  				aq_pipe->ace_system.IAParams.DupFrom[OutChannel] = params.dup.DupFromChan;
  				aq_pipe->state.ctl_param_change = true;
  			}
			else
			{
				result = ISMD_ERROR_INVALID_PARAMETER;
			}
 
       audio_output_unlock(output_wl);
     }

    AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;     
}

ismd_result_t
ismd_audio_output_quality_fc_bypass(ismd_audio_processor_t processor_h,
                              ismd_audio_output_t output_h,int fctype,bool bypass)
{
    ismd_audio_output_wl_t *output_wl = NULL;
   	ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
	audio_quality_context_t *aq_pipe = NULL;
    
    AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

    if( audio_output_validate_and_lock_wl(processor_h, output_h, &output_wl) == ISMD_SUCCESS){

         audio_quality_pipe_get_context(output_wl->processor_wl, output_wl->handle, &aq_pipe);
       	
		switch( fctype )
		{
		case ISMD_AUDIO_CONTROL_AVL:
			aq_pipe->ace_system.IAParams.IAAVLBypass = bypass;
		break;
	
		case ISMD_AUDIO_CONTROL_VOLUME:
			aq_pipe->ace_system.IAParams.MasterVolBypass= bypass;
		break;
	
   		case ISMD_AUDIO_CONTROL_MUTE:
   			aq_pipe->ace_system.IAParams.MasterMuteBypass = bypass;
   		break;
   	
   		case ISMD_AUDIO_CONTROL_DUP:
   			aq_pipe->ace_system.IAParams.DupBypass = bypass;
   		break;
   	
   		case ISMD_AUDIO_CONTROL_MINIMIX:
   			aq_pipe->ace_system.IAParams.PIMix4Bypass = bypass;
   		break;
   	
   		case ISMD_AUDIO_CONTROL_CLAMP:
   			aq_pipe->ace_system.IAParams.IAClampBypass = bypass;
   		break;
   		
   		default:
   			audio_output_unlock(output_wl);
   			result = ISMD_ERROR_INVALID_PARAMETER;
   		break;
		}
		
		aq_pipe->state.bypass_change = true;
		
		audio_output_unlock(output_wl);

		result = ISMD_SUCCESS;
	}
   else 
   {
         result = ISMD_ERROR_INVALID_HANDLE;
   }

	
    AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   	
	return result;
}


