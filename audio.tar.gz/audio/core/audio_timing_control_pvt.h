/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_TIMING_CONTROL_PVT_H_
#define _AUDIO_TIMING_CONTROL_PVT_H_

#include "audio_core.h"
#include "audio_timing_control.h"

#define ATC_OUTPUT_BUFFER_SIZE (64 * 1024) 

#define ATC_OUT_BUFFER_NEEDS_METADATA 999
#define ATC_DEFAULT_MS_DISCONTINUITY 2000 // 2 sec

/** Value to indicate the need to check for a pending request
    to put discontinutiy metadata on the output buffer.*/
#define ATC_DISCONT_CHECK_FOR_PENDING_ACTION -1

//This is how much time we are going to allow the clock to drift between alarams before we reset all streams. This is 
//here because the buffer level monitor could adjust our clock at any time.
#define ATC_MAX_CLOCK_DRIFT_PER_ALARM(x) (AUDIO_CHUNK_TIME_PERIOD_CLOCK_TICKS(x) + (CLOCK_TICKS_PER_MS * 7))
#define ATC_DEFAULT_MAX_CLOCK_DRIFT_PER_ALARM (CLOCK_TICKS_PER_MS * AUDIO_CHUNK_TIME_PERIOD_MS + (CLOCK_TICKS_PER_MS * 7))
#define ATC_MAX_MS_TO_DROP_SAMPLS 40 //The maximum amount of late time to try to drop down to sample accurate. Anything later throw away till next PTS.
#define ATC_MAX_TIME_PER_BEFR_DEAD_RNDR_SIG (RENDER_PREFILL_CHUNK * 4)

//Below is used for detecting a slave clock drifting
#define ATC_MAX_CLOCK_DRIFT (CLOCK_SPEED_HZ>>3) // 0.125 sec

#define ATC_ASRC_MINIMAL_ADJUST 1  // Minimum sample drift that ATC will propagate to ASRC

typedef struct {
 bool refresh_numbers;
 uint64_t render_smpl_cnt;
 uint32_t render_level_in_smpls;
}atc_render_base_numbers_t;

typedef struct _audio_atc_context_t audio_atc_context_t; 
typedef struct _audio_atc_device_t audio_atc_device_t; 

typedef struct {
   int buf_fs;       // input buffer sample-rate
   int target_fs;    // mixer sample-rate
   int minimal;      // the best minimal adjust samples
}audio_vchunk_adjust_step_t;


typedef struct {
   ismd_time_t       stream_time;                  // Current stream's input clock time 
   ismd_time_t       timer_time;                   // ATC timer clock time
   int64_t           cumulative_sample_correction; // Total number of samples adjusted
   uint32_t          target_sample_rate;           // The sample_rate which mixer stage would use.
   int               sample_drift_per_chunk;       // samples adjustment from ATC for current chunk
   int               minimal_adjust;               // minimum adjustment based on stream sample rate and mixer rate
   bool              vsrc_support_enabled;         // Variable SRC enabled or not 
   bool              drift_detection_started;      // Use to initialize variables for the first time
}audio_asrc_t;

typedef struct {
   audio_uint64_t segment_pts;        /** Accurated segment(original) time for input stream. this segment time still increase even ATC input buffer discard buffers */
   audio_uint64_t linear_pts;         /** Accurated linear time. this is supplement to the ATC output buffer's linear time. */
   audio_uint64_t local_pts;          /** Accurated scaled time. this is the supplement to the ATC output buffer's scaled time */
   uint32_t       adjust_ticks;        /** Accurated adjust tickets to segment_pts */
}audio_interpolated_info_t;

typedef struct {
   
   audio_atc_stream_t         handle;
   int                        input_smd_h;
   audio_atc_context_t        *atc_wl;
   bool                       have_eos;
   bool                       did_eos_check;
   bool                       in_use;
   bool                       disabled;
   bool                       fixing_samples;
   bool                       start_to_remove;
   bool                       is_timed_stream;
   bool                       is_encoded_data;
   bool                       is_primary;
   bool                       first_pts_found;
   bool                       have_base_numbers;  
   bool                       sent_first_frame;
   bool                       first_buffer_dequeued;
   bool                       started_to_drop_bytes;
   bool                       ignore_inband_rate_change;
   bool                       last_buffer_discrd_pts_past_stop_value;
   bool                       discontinuity;
   bool                       fast_output;
   bool                       output_buffer_is_silence;
   int                        smpls_before_drop[AUDIO_MAX_INPUT_CHANNELS];
   ismd_dev_state_t           state;
   audio_buffer_attr_t        curr_stream_info;
   audio_buffer_attr_t        next_stream_info;
   ismd_buffer_descriptor_t   *drop_buffer; 
   audio_time_rebase_info_t   rebase_info;

   const ismd_event_t         *notif_events;

   unsigned int               time_period_ms;
   unsigned int               fixed_back_end_delay_ms;
   int                        curr_chunk_size;
   int                        next_chunk_size;
   uint64_t                   render_sample_count;
   uint32_t                   render_delay_ticks;
   uint32_t                   render_delay_samples;
   ismd_time_t                atc_base_time;
   uint64_t                   prev_time_stamp;
   uint64_t                   prev_render_time;
   uint32_t                   pad_silence_bytes;
   int64_t                    drift_error_smpl_cnt;
   uint32_t                   drop_bytes;
   int                        bytes_to_fix;
   uint64_t                   last_pts_smpl_cnt;
   uint64_t                   linear_start_pts;
   uint32_t                   bytes_since_last_pts;
   int                        allowed_ms_drift_ahead;
   int                        allowed_ms_drift_behind;
   int                        allowed_ms_discontinuity;
   
   ismd_time_t                smd_base_time;
   ismd_clock_t               clock_h;
   ismd_clock_t               slave_clock_h;
   bool                       slave_clock_initialized;
   ismd_pts_t                 original_pts_on_slave_clock_adjustment;
   uint64_t                   render_sample_count_on_slave_clock_adjustment;
   ismd_timing_mode_t         timing_mode;
   ismd_time_t                last_clock_time;     //Record last clock time for discontinuity detection
   ismd_pts_t                 last_pts_recvd; 
   ismd_time_t                curr_position_ticks;

   ismd_audio_stream_position_info_t stream_pos;
   ismd_audio_stream_position_info_t *stream_pos_shared;
   
   //Buffer monitor variables for underrun control
   ismd_time_t                underrun_amount;
   ismd_event_t               underrun_event;
   int                        underrun_count;

   int rate;
   
   ismd_queue_handle_t        output_queue;
   ismd_queue_handle_t        input_queue;
   
   /* Buffer management */
   bool                       out_buf_ready;       // Flag to tell if output buffer is ready for immediate release.
   bool                       out_buf_forced_ready;// Flag to force the output of a buffer even though it may not be equal to chunk size.
   bool                       rend_ts_normalized;  // Flag to know if the render timestamp has been normalized.
   int                        in_buf_bytes_copied; // Amount of data already copied from the input buffer. 
   ismd_buffer_descriptor_t   *input_buffer;       // This is the next buffer in line
   ismd_buffer_descriptor_t   *output_buffer;      // Storage for buffer when output is full.
   
   ismd_message_context_t message_context;
   void                       *in_cached_address;

   ismd_event_t               discontinuity_event;

   ismd_newsegment_policy_t   newsegment_policy;   
   bool                       has_newsegment;      /** A valid new segment tag has been recieved.*/
   bool                       start_of_seg_found;  /** Flag to tell if we have found the start of the current segment*/

   audio_asrc_t               asrc;                // ASRC specific variables

   /*Variables supporting discontinuity metadata.*/
   bool                       last_out_buf_ended_in_silence;/** If true, the last buffer sent out had silence at the end of the buffer.*/
   bool                       add_ramp_up_mda;              /** When this is set to true, its the first buffer and need to add the discont ramp up action.*/
   audio_interpolated_info_t  interpolated_info;   /** ATC interpolated PTS information for stream_pos */
} audio_atc_stream_context_t;

struct _audio_atc_context_t{
   ismd_audio_processor_t processor_id;
   bool in_use;
   bool fast_output;
   audio_atc_t handle;
   audio_atc_device_t *dev_wl;
   bool start_to_close;
   bool insert_silence;
   ismd_event_t clock_alarm_event;
   audio_atc_stream_context_t * primary_stream_wl;
   atc_output_discard_policy_t output_discard_policy;

   os_mutex_t lock; 
   os_mutex_t *output_queue_lock;
   
   int active_stream_count;
   audio_atc_stream_context_t streams[AUDIO_MAX_ATC_STREAMS];

   //Flag indicating whether transition protection in the post-ATC pipe is enabled
   bool transition_protection_enabled;
};

struct _audio_atc_device_t {

   bool start_to_close;
   int enable_timed_trick_modes;
   
   os_thread_t atc_manager_thread;

   os_mutex_t lock;
   
   ismd_event_t queue_io_event;
   ismd_event_t clock_alarm_event;
   ismd_time_t last_clock_alarm_time;

   /* Clock information */
   ismd_clock_t default_clock_h; //Clock we allocate for a backup source.
   ismd_clock_t timer_clock_h; //The clock handle that is set for the timer
   ismd_clock_t primary_clock_h;//Allows us to know which handle is primary
   audio_atc_stream_context_t * timer_clock_stream_wl;
   ismd_clock_alarm_t timer_clock_alarm_h;
   int clock_alarm_period; // current clock_alarm interval
   ismd_audio_clk_mode_t clk_mode; 

   ismd_event_t event_list[ISMD_EVENT_LIST_MAX];
   int event_list_count;
   
   audio_atc_context_t atc_contexts[AUDIO_MAX_ATC_CONTEXTS];
   bool wait_with_timeout;   

   /*Sample count variable to keep track of render health*/
   uint32_t render_prev_sample_count;
   uint32_t render_no_sample_change_count;
   os_irqlock_t  irq_lock;  //Used to disable interrupts 
} ;


/*********************************************************************************************/

/* Private ATC function declarations*/
static void
audio_pvt_atc_reset_for_new_stream(audio_atc_stream_context_t *stream_wl);

static ismd_result_t
audio_pvt_atc_input_queue_io_callback(void *context, ismd_queue_event_t queue_event, ismd_buffer_handle_t buffer );

static ismd_result_t
audio_pvt_atc_output_queue_io_callback(void *context, ismd_queue_event_t queue_event, ismd_buffer_handle_t *buffer );

static void
*audio_pvt_atc_manager_thread(void *context);

static ismd_result_t
audio_pvt_atc_get_base_numbers(audio_atc_stream_context_t *stream_wl);

static ismd_result_t
audio_pvt_atc_alloc_out_buffer(audio_atc_stream_context_t *stream_wl); 

static bool
audio_pvt_atc_buffer_ts_ready_for_release(audio_atc_stream_context_t *stream_wl, atc_render_base_numbers_t *base_numbers, bool *discard );

static void
audio_pvt_atc_update_stream_position(audio_atc_stream_context_t *stream_wl);

static void
audio_pvt_atc_handle_stream_info_change(audio_atc_stream_context_t *stream_wl, audio_buffer_attr_t * buffer_attrib);

static void
audio_pvt_atc_assign_time_slot(audio_atc_stream_context_t *stream_wl );

static void
audio_pvt_atc_assign_time_slot_trick_modes(audio_atc_stream_context_t *stream_wl );

static bool
audio_pvt_atc_top_off_buffer(audio_atc_stream_context_t *stream_wl);

static void
audio_pvt_atc_set_slave_clock(audio_atc_stream_context_t *stream_wl);

static void
audio_pvt_atc_adjust_slave_clock(audio_atc_stream_context_t *stream_wl);

static bool
audio_pvt_atc_prepare_output_buffer(audio_atc_stream_context_t *stream_wl);

static void
audio_pvt_atc_drop_samples(audio_atc_stream_context_t *stream_wl);

static ismd_result_t
audio_pvt_atc_input_validate_metadata(audio_atc_stream_context_t *stream_wl, audio_buffer_attr_t * buffer_attrib, bool *discard_buffer);

static ismd_result_t
audio_pvt_atc_input_dequeue(audio_atc_stream_context_t *stream_wl, bool *work_to_do);

static void
audio_pvt_atc_calc_drift_trick_modes(audio_atc_stream_context_t *stream_wl, uint64_t smpls_until_rndr);

static void
audio_pvt_atc_calc_first_frame(audio_atc_stream_context_t *stream_wl, int64_t clk_ticks_until_rndr, int64_t smpls_until_rndr, uint32_t chunk_size_samples);

static void
audio_pvt_atc_handle_late_pts(audio_atc_stream_context_t *stream_wl, audio_buffer_attr_t *buf_attrib, int64_t drift_samples, bool first_frame);

static void
audio_pvt_atc_handle_early_pts(audio_atc_stream_context_t *stream_wl, audio_buffer_attr_t *buf_attrib, int64_t drift_samples);

static void
audio_pvt_atc_init_wl(audio_atc_context_t *wl);

static ismd_result_t 
audio_pvt_atc_lock_and_get_wl(audio_atc_t atc_h, audio_atc_context_t **wl);

static ismd_result_t 
audio_pvt_atc_stream_lock_and_get_wl(audio_atc_t atc_h, audio_atc_stream_t stream_h, audio_atc_stream_context_t **stream_wl);

static bool 
audio_pvt_atc_valid_handle( audio_atc_t atc_h );

static void 
audio_pvt_atc_lock_output_queues (os_mutex_t *lock);

static void 
audio_pvt_atc_unlock_output_queues (os_mutex_t *lock);

static void 
audio_pvt_atc_lock (audio_atc_context_t *atc_instance) ;

static void 
audio_pvt_atc_unlock (audio_atc_context_t *atc_instance) ;

static void 
audio_pvt_atc_dev_lock (audio_atc_device_t *dev);

static void 
audio_pvt_atc_dev_unlock (audio_atc_device_t *dev);

static void
audio_pvt_atc_stream_init_wl(audio_atc_stream_context_t *stream_wl);


static bool 
audio_pvt_atc_stream_valid_handle( audio_atc_stream_t atc_stream_h );

static ismd_result_t 
audio_pvt_atc_stream_remove(audio_atc_context_t *wl, audio_atc_stream_t atc_stream_h);

static ismd_result_t
audio_pvt_atc_set_new_alarm_clock(audio_atc_device_t *dev_wl, ismd_clock_t clock_h, int chunk_period); 

static void
audio_pvt_atc_check_if_clock_is_timer(audio_atc_stream_context_t *stream_wl, audio_atc_device_t *dev_wl); 

static void
audio_pvt_atc_add_event_to_list( audio_atc_device_t *dev_wl, ismd_event_t event);

static void
audio_pvt_atc_remove_event_from_list(audio_atc_device_t *dev_wl, ismd_event_t event);


static void 
audio_fixup_discontinuity(int *first_samples_to_drop, void *samples_to_keep, 
   int num_samples_to_keep, int sample_size, int num_channels, int num_samples_to_adjust);

void 
audio_fix_samples( int *pi_drop, int i_length_drop, int *pi_keep, int i_length_keep, int i_length_fix, int i_num_channels, int sample_size);

static ismd_result_t
audio_pvt_atc_input_buffer_dereference(audio_atc_stream_context_t *stream_wl);

ismd_result_t
audio_pvt_atc_calculate_asrc_drift(audio_atc_context_t *wl, audio_atc_stream_context_t *stream_wl);

void
audio_pvt_atc_asrc_reset(audio_atc_stream_context_t *stream_wl);

static void
audio_pvt_atc_interpolate_rebase_info_for_untimed(audio_atc_stream_context_t* stream_wl);

static void
audio_pvt_atc_interpolate_info_for_discard_buffer(audio_atc_stream_context_t* stream_wl);

static void
audio_pvt_atc_interpolate_info_for_output_buffer(audio_atc_stream_context_t* stream_wl);

static void
audio_pvt_atc_discont_mda_send_last_buffer(audio_atc_stream_context_t *stream_wl);

#endif

