/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2008-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2008-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"
#include "audio_apm_common.h"


#define AC3_MAX_CHANNELS 6

#define LEFT_CHAN_INDEX                 0
#define CENTER_CHAN_INDEX               1
#define RIGHT_CHAN_INDEX                2
#define LEFT_SUR_CHAN_INDEX             3
#define RIGHT_SUR_CHAN_INDEX            4
#define LFE_CHAN_INDEX                  5 

#define BUFFER_OFFSET_0 (0 << 8)
#define BUFFER_OFFSET_1 (1 << 8)
#define BUFFER_OFFSET_2 (2 << 8)
#define BUFFER_OFFSET_3 (3 << 8)
#define BUFFER_OFFSET_4 (4 << 8)
#define BUFFER_OFFSET_5 (5 << 8)

#define AUDIO_DEFAULT_LEFT_CH_ROUTE       BUFFER_OFFSET_0 | LEFT_CHAN_INDEX;
#define AUDIO_DEFAULT_CENTER_CH_ROUTE     BUFFER_OFFSET_1 | CENTER_CHAN_INDEX;
#define AUDIO_DEFAULT_RIGHT_CH_ROUTE      BUFFER_OFFSET_2 | RIGHT_CHAN_INDEX;
#define AUDIO_DEFAULT_L_SUR_CH_ROUTE      BUFFER_OFFSET_3 | LEFT_SUR_CHAN_INDEX;
#define AUDIO_DEFAULT_R_SUR_CH_ROUTE      BUFFER_OFFSET_4 | RIGHT_SUR_CHAN_INDEX;
#define AUDIO_DEFAULT_LFE_CH_ROUTE        BUFFER_OFFSET_5 | LFE_CHAN_INDEX;

#define AC3_SCALE_FACTOR_MAX 0x007FFFFF
#define AC3_SCALE_DEFAULT AC3_SCALE_FACTOR_MAX
#define AC3_EXT_DOWNMIX_ARRAY_MAX 36

ismd_result_t
audio_ddplus_dcv_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value)
{
   ismd_result_t result = ISMD_SUCCESS;
   int *param = NULL; //All the encoder params are int. 

   switch(param_id)
   {
      case ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE :

         param = (int *) param_value;

         switch(*param) {
            case ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE_NO_VOCAL:
            case ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE_LEFT_VOCAL:
            case ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE_RIGHT_VOCAL:
            case ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE_BOTH_VOCALS:
               psm_decode_params->host.codec.config.ddplus_dcv_params.karac_mode= *param;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddplus dcv: karaoke_repro_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }

         break;
         
      case  ISMD_AUDIO_AC3_DYNAMIC_RANGE_COMPRESSION_MODE :

         param = (int *) param_value;

         switch(*param) {

            case ISMD_AUDIO_AC3_CUSTOM_MODE_ANALOG_DIALOG_NORMALIZATION:
            case ISMD_AUDIO_AC3_CUSTOM_MODE_DIGITAL_DIALOG_NORMALIZATION:
            case ISMD_AUDIO_AC3_LINE_OUT_MODE:
            case ISMD_AUDIO_AC3_RF_REMOTE_MODE:
               psm_decode_params->host.codec.config.ddplus_dcv_params.dynrng_mode = *param;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddplus dcv: dyn_rng_comp_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }

         break;

      case ISMD_AUDIO_AC3_LFE_CHANNEL_OUTPUT :
      
               param = (int *) param_value;
               
               switch(*param) {
                  case ISMD_AUDIO_AC3_LFE_CHANNEL_OUTPUT_NONE:
                  case ISMD_AUDIO_AC3_LFE_CHANNEL_OUTPUT_ENABLED:
                     psm_decode_params->host.codec.config.ddplus_dcv_params.lfe_out = *param;
                     break;
                  default:
                     result = ISMD_ERROR_INVALID_PARAMETER;
                     AUDIO_ERROR("ddplus dcv: lfe_ch_output param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
                     break;
               }
               
               break;

      case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION :
                  
         param = (int *) param_value;
         
         switch(*param) {
            
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_RESERVED:
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_1_0_C:
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_2_0_LR:
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_3_0_LCR:
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_2_1_LRl:
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_3_1_LCRl:        
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_2_2_LRlr:           
            case ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION_3_2_LCRlr:       
               psm_decode_params->host.codec.config.ddplus_dcv_params.ocfg = *param;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddplus dcv: output_config param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }
         
         break;

      case ISMD_AUDIO_AC3_NUM_OUTPUT_CHANNELS :
         
         param = (int *) param_value;
         
         if(*param > 0 && *param <= AC3_MAX_CHANNELS) {            
               psm_decode_params->host.codec.config.ddplus_dcv_params.num_och = *param;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddplus dcv: output_channels param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }
         
         break;

      case ISMD_AUDIO_AC3_PCM_SCALE_FACTOR :

         param = (int *) param_value;
         
         if(*param>= 0 && *param <= AC3_SCALE_FACTOR_MAX) {            
               psm_decode_params->host.codec.config.ddplus_dcv_params.pcm_scale = *param;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddplus dcv: pcm_scale_factor param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);    
         }
         
         break;
         
      case ISMD_AUDIO_AC3_STEREO_OUTPUT_MODE :

         param = (int *) param_value;

         switch(*param) {

            case ISMD_AUDIO_AC3_STEREO_OUTPUT_MODE_AUTO_DETECT:
            case ISMD_AUDIO_AC3_STEREO_OUTPUT_MODE_SURROUND_COMPATIBLE:
            case ISMD_AUDIO_AC3_STEREO_OUTPUT_MODE_STEREO:
               psm_decode_params->host.codec.config.ddplus_dcv_params.stereo_mode = *param;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddplus dcv: stereo_out_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }

         break;

      case  ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE :

         param = (int *) param_value;

         switch(*param) {

            case ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE_STEREO:
            case ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE_LEFT_MONO:
            case ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE_RIGHT_MONO:
            case ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE_MIXED_MONO:
               psm_decode_params->host.codec.config.ddplus_dcv_params.mono_rep = *param;
               break;
            default:
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddplus dcv: dual_mono_rep_mode param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
               break;
         }

         break;

      case ISMD_AUDIO_AC3_DYNAMIC_RANGE_HIGH_FREQ_CUT_SCALE_FACTOR :

         param = (int *) param_value;

         if(*param >= 0 && *param <= AC3_SCALE_FACTOR_MAX) {
               psm_decode_params->host.codec.config.ddplus_dcv_params.dyn_cut_hi = *param;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddplus dcv: hi_freq_dyn_cut_scale param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         break;

      case ISMD_AUDIO_AC3_DYNAMIC_RANGE_LOW_FREQ_BOOST_SCALE_FACTOR :

         param = (int *) param_value;

         if(*param >= 0 && *param <= AC3_SCALE_FACTOR_MAX) {
               psm_decode_params->host.codec.config.ddplus_dcv_params.dyn_boost_lo = *param;
         }
         else {
               result = ISMD_ERROR_INVALID_PARAMETER;
               AUDIO_ERROR("ddplus dcv: low_freq_dyn_bst_scale param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         break;

      case  ISMD_AUDIO_AC3_CHANNEL_ROUTE_L :

         param = (int *) param_value;

         if(*param >= -1 && *param < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ddplus_dcv_params.chanrouting[LEFT_CHAN_INDEX] = (*param << 8) | LEFT_CHAN_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ddplus dcv: ch_route left param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
            
         break;
         
      case ISMD_AUDIO_AC3_CHANNEL_ROUTE_C :
         
         param = (int *) param_value;

         if(*param >= -1 && *param < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ddplus_dcv_params.chanrouting[CENTER_CHAN_INDEX] = (*param << 8) | CENTER_CHAN_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ddplus dcv: ch_route center param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
         
      case ISMD_AUDIO_AC3_CHANNEL_ROUTE_R :
                  
         param = (int *) param_value;

         if(*param >= -1 && *param < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ddplus_dcv_params.chanrouting[RIGHT_CHAN_INDEX] = (*param << 8) | RIGHT_CHAN_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ddplus dcv: ch_route right param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
  
         break;
         
      case ISMD_AUDIO_AC3_CHANNEL_ROUTE_Ls :
                           
         param = (int *) param_value;

         if(*param >= -1 && *param < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ddplus_dcv_params.chanrouting[LEFT_SUR_CHAN_INDEX] = (*param << 8) | LEFT_SUR_CHAN_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ddplus dcv: ch_route left_sur param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
  
         break;
         
      case ISMD_AUDIO_AC3_CHANNEL_ROUTE_Rs :
                           
         param = (int *) param_value;

         if(*param >= -1 && *param < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ddplus_dcv_params.chanrouting[RIGHT_SUR_CHAN_INDEX] = (*param << 8) | RIGHT_SUR_CHAN_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ddplus dcv: ch_route right_sur param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         break;
         
      case  ISMD_AUDIO_AC3_CHANNEL_ROUTE_LFE :
                  
         param = (int *) param_value;
         
         if(*param >= -1 && *param < AC3_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ddplus_dcv_params.chanrouting[LFE_CHAN_INDEX] = (*param << 8) | LFE_CHAN_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ddplus dcv: ch_route lfe param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         break;
      case ISMD_AUDIO_DDPLUS_QUITONERR :

         param = (int *) param_value;

         psm_decode_params->host.codec.config.ddplus_dcv_params.quit_on_err = *param;

         break;

      default:

         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("ddplus dcv: invalid config param type!", result, audio_devh[AUDIO_DEBUG_APM]);

         break;


   }

   return result;
}

ismd_result_t
audio_ddplus_dcv_set_default_decode_params(audio_psm_decode_params_t *dec_params )
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_codec_ddplus_dcv_config_params_t* ddplus_dcv_params = &(dec_params->host.codec.config.ddplus_dcv_params);

   OS_MEMSET((char *)dec_params, 0, sizeof(audio_psm_stage_params_t));

   ddplus_dcv_params->karac_mode = ISMD_AUDIO_DDPLUS_KARAOKE_REPRODUCTION_MODE_BOTH_VOCALS;
   ddplus_dcv_params->dynrng_mode = ISMD_AUDIO_DDPLUS_LINE_OUT_MODE;
   ddplus_dcv_params->lfe_out = ISMD_AUDIO_DDPLUS_LFE_CHANNEL_OUTPUT_ENABLED;
   ddplus_dcv_params->ocfg = 7;
   ddplus_dcv_params->num_och = 6;
   ddplus_dcv_params->pcm_scale = AC3_SCALE_DEFAULT;
   ddplus_dcv_params->quit_on_err = ISMD_AUDIO_DDPLUS_QUITONERR_DISABLED;
   ddplus_dcv_params->stereo_mode = ISMD_AUDIO_DDPLUS_STEREO_OUTPUT_MODE_AUTO_DETECT;
   ddplus_dcv_params->mono_rep = ISMD_AUDIO_DDPLUS_DUAL_MONO_REPRODUCTION_MODE_STEREO;
   ddplus_dcv_params->dyn_cut_hi = AC3_SCALE_DEFAULT;
   ddplus_dcv_params->dyn_boost_lo = AC3_SCALE_DEFAULT;
   ddplus_dcv_params->chanrouting[LEFT_CHAN_INDEX] =        AUDIO_DEFAULT_LEFT_CH_ROUTE;
   ddplus_dcv_params->chanrouting[LFE_CHAN_INDEX] =         AUDIO_DEFAULT_LFE_CH_ROUTE;
   ddplus_dcv_params->chanrouting[LEFT_SUR_CHAN_INDEX] =    AUDIO_DEFAULT_L_SUR_CH_ROUTE;
   ddplus_dcv_params->chanrouting[RIGHT_CHAN_INDEX] =       AUDIO_DEFAULT_RIGHT_CH_ROUTE;
   ddplus_dcv_params->chanrouting[CENTER_CHAN_INDEX] =      AUDIO_DEFAULT_CENTER_CH_ROUTE;
   ddplus_dcv_params->chanrouting[RIGHT_SUR_CHAN_INDEX] =   AUDIO_DEFAULT_R_SUR_CH_ROUTE;
   ddplus_dcv_params->pcm_enabled = 0;
   ddplus_dcv_params->dd_enabled = 1;
   ddplus_dcv_params->packetizer_enabled = true;
   
   return result;
}


