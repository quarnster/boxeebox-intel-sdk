/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2008-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2008-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_core.h"

#define AC3_ENC_MAX_CHANNELS 6

//These are the default channel number assignments given by Tensillica.
#define LEFT_CHAN_ROUTE_INDEX             0
#define CENTER_CHAN_ROUTE_INDEX           1
#define RIGHT_CHAN_ROUTE_INDEX            2 
#define LEFT_SUR_CHAN_ROUTE_INDEX         3
#define RIGHT_SUR_CHAN_ROUTE_INDEX        4
#define LFE_CHAN_ROUTE_INDEX              5 

#define CHANNEL_0_VALUE (0 << 8) 
#define CHANNEL_1_VALUE (1 << 8)
#define CHANNEL_2_VALUE (2 << 8)
#define CHANNEL_3_VALUE (3 << 8)  
#define CHANNEL_4_VALUE (4 << 8)      
#define CHANNEL_5_VALUE (5 << 8) 

#define AUDIO_DEFAULT_LEFT_CH_ROUTE     CHANNEL_0_VALUE | LEFT_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_LFE_CH_ROUTE      CHANNEL_1_VALUE | LFE_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_L_SUR_CH_ROUTE        CHANNEL_2_VALUE | LEFT_SUR_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_RIGHT_CH_ROUTE      CHANNEL_3_VALUE | RIGHT_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_CENTER_CH_ROUTE      CHANNEL_4_VALUE | CENTER_CHAN_ROUTE_INDEX;
#define AUDIO_DEFAULT_R_SUR_CH_ROUTE CHANNEL_5_VALUE | RIGHT_SUR_CHAN_ROUTE_INDEX;

ismd_result_t
audio_ac3_enc_set_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value)
{
   ismd_result_t result = ISMD_SUCCESS;
   int *param = NULL; //All the encoder params are int. 

   switch(param_id)
   {
      case  ISMD_AUDIO_AC3_ENC_ACMOD :

         param = (int *) param_value;

         if((*param == 0) || (*param == 1) || (*param == 2) || (*param == 7)) {
            psm_decode_params->host.codec.config.ac3_enc_params.acmod = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 enc: ACMOD param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }            
         break;
         
      case  ISMD_AUDIO_AC3_ENC_WDSZ :

         param = (int *) param_value;

         if((*param == 24)) {
            psm_decode_params->host.codec.config.ac3_enc_params.pcm_wdsz = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 enc: PCM WORD SIZE param invalid! Only supporting 24 bit input currently!", result, audio_devh[AUDIO_DEBUG_APM]);
         }      
         break;   
         
      case  ISMD_AUDIO_AC3_ENC_DATA_RATE_CODE :

         param = (int *) param_value;

         if(*param > 0) {
            psm_decode_params->host.codec.config.ac3_enc_params.data_rate_code = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 enc: DATA RATE CODE param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }      
         break;  

      case  ISMD_AUDIO_AC3_ENC_LFEFILTINUSE :

         param = (int *) param_value;

         if((*param == 0) || (*param == 1)) {
            psm_decode_params->host.codec.config.ac3_enc_params.lfefiltinuse = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 enc: LFE FILTER IN USE param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }      
         break;    

      case  ISMD_AUDIO_AC3_ENC_NUM_ICH :

         param = (int *) param_value;

         if((*param == 6)) {
            psm_decode_params->host.codec.config.ac3_enc_params.num_ich = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 enc: NUM INPUT CH param invalid! Only supports 6ch input currently!", result, audio_devh[AUDIO_DEBUG_APM]);
         }            
         break;
         
      case  ISMD_AUDIO_AC3_ENC_COMPCHAR :

         param = (int *) param_value;

         if((*param == 0) || (*param == 1)) {
            psm_decode_params->host.codec.config.ac3_enc_params.compchar = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 enc: COMPCHAR param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }            
         break;

      case  ISMD_AUDIO_AC3_ENC_COMPCHAR2 :

         param = (int *) param_value;

         if((*param == 0) || (*param == 1)) {
            psm_decode_params->host.codec.config.ac3_enc_params.compchar2 = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 enc: COMPCHAR2 param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }            
         break;

      case  ISMD_AUDIO_AC3_ENC_LOFREQEFFON :

         param = (int *) param_value;

         if((*param == 0) || (*param == 1)) {
            psm_decode_params->host.codec.config.ac3_enc_params.lofreqeffon = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 enc: LOW FREQ EFF ON param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }            
         break;

      case  ISMD_AUDIO_AC3_ENC_TESTMODEON :

         param = (int *) param_value;

         if((*param == 0) || (*param == 1)) {
            psm_decode_params->host.codec.config.ac3_enc_params.testmodeon = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 enc: TEST MODE ON param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }            
         break;

      case  ISMD_AUDIO_AC3_ENC_SAMP_FREQ :

         param = (int *) param_value;

         if((*param == 48000)) { //This encoder only supports 48000kHz
            psm_decode_params->host.codec.config.ac3_enc_params.samp_freq = *param;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 enc: SAMPLING FREQ param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }            
         break;
         
      case  ISMD_AUDIO_AC3_ENC_CHANNEL_ROUTE_L :

         param = (ismd_audio_ac3_enc_ch_routing_t *) param_value;

         if(*param >= 0 && *param < AC3_ENC_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_enc_params.chanrouting[LEFT_CHAN_ROUTE_INDEX] = (*param << 8) | LEFT_CHAN_ROUTE_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 encoder: ch_route left param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
            
         break;
         
      case ISMD_AUDIO_AC3_ENC_CHANNEL_ROUTE_C :
         
         param = (ismd_audio_ac3_enc_ch_routing_t *) param_value;

         if(*param >= 0 && *param < AC3_ENC_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_enc_params.chanrouting[CENTER_CHAN_ROUTE_INDEX] = (*param << 8) | CENTER_CHAN_ROUTE_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 encoder: ch_route center param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
         
      case ISMD_AUDIO_AC3_ENC_CHANNEL_ROUTE_R :
                  
         param = (ismd_audio_ac3_enc_ch_routing_t *) param_value;

         if(*param >= 0 && *param < AC3_ENC_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_enc_params.chanrouting[RIGHT_CHAN_ROUTE_INDEX] = (*param << 8) | RIGHT_CHAN_ROUTE_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 encoder: ch_route right param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
  
         break;
         
      case ISMD_AUDIO_AC3_ENC_CHANNEL_ROUTE_Ls :
                           
         param = (ismd_audio_ac3_enc_ch_routing_t *) param_value;

         if(*param >= 0 && *param < AC3_ENC_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_enc_params.chanrouting[LEFT_SUR_CHAN_ROUTE_INDEX] = (*param << 8) | LEFT_SUR_CHAN_ROUTE_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 encoder: ch_route left_sur param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
  
         break;
         
      case ISMD_AUDIO_AC3_ENC_CHANNEL_ROUTE_Rs :
                           
         param = (ismd_audio_ac3_enc_ch_routing_t *) param_value;

         if(*param >= 0 && *param < AC3_ENC_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_enc_params.chanrouting[RIGHT_SUR_CHAN_ROUTE_INDEX] = (*param << 8) | RIGHT_SUR_CHAN_ROUTE_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 encoder: ch_route right_sur param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         break;
         
      case  ISMD_AUDIO_AC3_ENC_CHANNEL_ROUTE_LFE :
                  
         param = (ismd_audio_ac3_enc_ch_routing_t *) param_value;

         if(*param >= 0 && *param < AC3_ENC_MAX_CHANNELS) {
            psm_decode_params->host.codec.config.ac3_enc_params.chanrouting[LFE_CHAN_ROUTE_INDEX] = (*param << 8) | LFE_CHAN_ROUTE_INDEX;
         }
         else {
            result = ISMD_ERROR_INVALID_PARAMETER;
            AUDIO_ERROR("ac3 encoder: ch_route lfe param invalid!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         
         break;

      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("ac3 encoder: invalid config param type!", result, audio_devh[AUDIO_DEBUG_APM]);    
         break;
   }


   return result;
}

ismd_result_t
audio_ac3_enc_set_default_params(audio_psm_decode_params_t *dec_params)
{
   ismd_result_t result = ISMD_SUCCESS;

   OS_MEMSET((char *)dec_params, 0, sizeof(audio_psm_stage_params_t)); 

   dec_params->host.codec.algo = ISMD_AUDIO_ENCODE_FMT_AC3;
   dec_params->host.codec.packetize_output = true;

   dec_params->host.codec.config.ac3_enc_params.samp_freq = 48000;
   dec_params->host.codec.config.ac3_enc_params.acmod = 7;
   dec_params->host.codec.config.ac3_enc_params.lofreqeffon = 1;
   dec_params->host.codec.config.ac3_enc_params.lfefiltinuse = 1;
   dec_params->host.codec.config.ac3_enc_params.data_rate_code = 18;
   dec_params->host.codec.config.ac3_enc_params.num_ich = 6;
   dec_params->host.codec.config.ac3_enc_params.pcm_wdsz = 24;
   dec_params->host.codec.config.ac3_enc_params.compchar = 0;
   dec_params->host.codec.config.ac3_enc_params.compchar2 = 0;

   //Need a slot for each channel, max of 6 channels.
   dec_params->host.codec.config.ac3_enc_params.chanrouting[0] = AUDIO_DEFAULT_LEFT_CH_ROUTE;
   dec_params->host.codec.config.ac3_enc_params.chanrouting[1] = AUDIO_DEFAULT_RIGHT_CH_ROUTE;
   dec_params->host.codec.config.ac3_enc_params.chanrouting[2] = AUDIO_DEFAULT_LFE_CH_ROUTE;
   dec_params->host.codec.config.ac3_enc_params.chanrouting[3] = AUDIO_DEFAULT_CENTER_CH_ROUTE;
   dec_params->host.codec.config.ac3_enc_params.chanrouting[4] = AUDIO_DEFAULT_L_SUR_CH_ROUTE;
   dec_params->host.codec.config.ac3_enc_params.chanrouting[5] = AUDIO_DEFAULT_R_SUR_CH_ROUTE;
   
   return result;
}


