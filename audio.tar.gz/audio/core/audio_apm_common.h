/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _ISMD_AUDIO_APM_COMMON_H_
#define _ISMD_AUDIO_APM_COMMON_H_

#include "ismd_audio.h"
#include "audio_core.h"
#include "pal_soc_info.h"
#include "intel_ce_pm.h"


/*********************************************************************************************/
/* APM Common Defines and Typedefs*/
/*********************************************************************************************/

#define MIXER_GAIN_ARRAY_SIZE 326

/**Global variable to determine how many inputs will be 
   supported based on the platform configuration parameter 
   supplied. */
extern int max_num_inputs_per_processor;

#define AUDIO_INPUT_ID_INVALID -1
#define AUDIO_APM_WAIT_TIMEOUT_MS 30 

#define MAX_DEPTH_TRUEHD_DEC_PASS_CASE 190
#define MAX_DEPTH_DTS_PASS_CASE 90

/** The time quantum the data acumulator is operating on.*/
#define TIME_QUANTUM_DATA_ACCUM_MS 5

//Because post atc pipe's mixer stage input count depends on "max_num_inputs_per_processor", we need to 
//make "ASSOC_STREAM_MIXER_INPUT_INDEX" depend on "max_num_inputs_per_processor" too
#define ASSOC_STREAM_MIXER_INPUT_INDEX (max_num_inputs_per_processor -1)

#define ENSURE_VALID_RAMP(ramp_ms) (((ramp_ms)<ISMD_AUDIO_RAMP_MS_MIN) ? ISMD_AUDIO_RAMP_MS_MIN : (((ramp_ms)>ISMD_AUDIO_RAMP_MS_MAX) ? ISMD_AUDIO_RAMP_MS_MAX : (ramp_ms)))
#define ENSURE_VALID_GAIN(gain) ((gain)>ISMD_AUDIO_GAIN_MAX?ISMD_AUDIO_GAIN_MAX:((gain)<ISMD_AUDIO_GAIN_MUTE?ISMD_AUDIO_GAIN_MUTE:(gain)))
#define FLOOR_CEIL(value, min, max) ((value) > max ? max:((value) < min ? min : (value)))

/** Output index values for the possible output points
of the input decoder PSM pipeline. */
typedef enum {
   DEC_PSM_PIPE_DEC_OUT_INDEX = 0,    /** Decode output index*/
   DEC_PSM_PIPE_PASS_OUT_INDEX = 1      /** Passthrough output index.*/
}audio_dec_psm_pipe_out_index_t;

#ifdef __KERNEL__
#define POWER_MANAGEMENT
#endif

typedef enum {
   AUDIO_PROCESS_MODE_NORMAL = 0,    /**< - Audio processor work under normal decoding mode */
   AUDIO_PROCESS_MODE_MS10,          /**< - Audio processor work under Dolby MS10 compatible mode */
}audio_process_mode_t;

/* Types to differentiate audio inputs. */
typedef enum {
   AUDIO_INPUT_TYPE_OTHER = 0,
   AUDIO_INPUT_TYPE_PRIMARY = 1,
   AUDIO_INPUT_TYPE_SECONDARY = 2
} audio_input_type_t;

/* types to differentiate the MS10 input type. */
typedef enum {
   AUDIO_INPUT_MS10_MAIN_OR_ASSOC_ONLY = 0,  // indicate DDC or DDT of this input (MS10) only contains main or assoc audio input. 
   AUDIO_INPUT_MS10_MAIN_AND_ASSOC,          // indicate DDC of this input (MS10) contains main and associated audio together. the input buffer need to feed to main/associated audio twice.
} audio_input_ms10_type_t;


//Needed by APM to index into an array of stages. 
//Add stages in the order they need be in the PSM pipe.
//Important, maintain this order in the ENUM.
typedef enum {
   INPUT_STAGE = 0,
   DEINTERLVR_STAGE,
   SRC_STAGE,
   PRESRC_STAGE,
   MIXER_STAGE,
   WATERMARK_STAGE,
   BASS_MAN_STAGE,
   DELAY_MAN_STAGE,
   DOWNMIX_STAGE,
   POST_SRC_STAGE,
   SRS_STAGE,
   QUALITY_STAGE,
   INTERLVR_STAGE,
   BIT_DEPTH_CONV_STAGE,
   PER_OUTPUT_DELAY_STAGE,
   MATRIX_DEC_STAGE,
   ENCODE_STAGE,
   PACKETIZE_STAGE,
   DATA_DIV_STAGE,
   DATA_DIV_MATRX_DEC_STAGE,
   OUTPUT_STAGE ,
   //Add more stages indexes here
   PA_PSM_PIPE_MAX_STAGES         
}audio_post_atc_psm_pipe_stages_t;

/** Input pipeline (Decode/PCM), need to maintain order for PSM pipe.*/
typedef enum {
   IN_STAGE,               /** Need an input stage, duh.*/
   IEC_PARSER_STAGE,       /** Optional IEC parsing stage.*/
   DECODE_STAGE,           /** Stage can be used for PCM or encoded.*/
   SECONDARY_DECODE_STAGE, /** Secondary deocde stage only for DCV to transcode DD+ to AC3.*/
   ACCUMLATOR_STAGE,       /** Optional accumulator stage when TrueHD is the input.*/
   PACKETIZER_STAGE,       /** Finds encoded frames and IEC 61937 wraps them.*/
   CAPP_STAGE,             /** Optional custom audio processing stage.*/
   PRE_SRC_STAGE,          /** SRC stage to convert odd sample rates to 48kHz.*/
   OUT_STAGE,              /** Need an output stage, duh.*/
   DECODE_PSM_PIPE_MAX_STAGES         
}audio_decode_psm_pipe_stages_t;

/** PSM pipe stage descriptor for APM.*/
typedef struct { 
  bool in_use;             
  uint32_t input_count;
  uint32_t output_count;
  audio_psm_stage_handle_t handle;
  audio_psm_stage_task_t task;
  audio_psm_stage_params_t params;
  audio_psm_stage_connection_metadata_t conn_mda;
}audio_psm_pipe_stage_t;

/** PSM pipe for Decode/Packetizer. */
typedef struct {
   bool pipe_started;
   unsigned int stage_count;
   audio_psm_pipe_handle_t pipe_h;
   audio_psm_pipe_stage_t stages[DECODE_PSM_PIPE_MAX_STAGES];
}audio_psm_decode_pipe_t;

/** PSM pipe for POST ATC pipeline.*/
typedef struct {
   bool pipe_configured;
   bool ddco_test_mode_en;
   int encode_sw_path_out_index;
   int encode_hw_path_out_index;
   unsigned int stage_count;
   audio_psm_pipe_handle_t pipe_h;
   audio_psm_pipe_stage_t stages[PA_PSM_PIPE_MAX_STAGES];
}audio_psm_post_atc_pipe_t;

/** PSM pipe for MS10 decode.*/
typedef struct {
   bool dec_pipe_configured;
   audio_psm_pipe_handle_t dec_pipe_h;
   audio_psm_stage_handle_t in_stage_h;
   audio_psm_stage_handle_t out_stage_h;
   audio_psm_stage_handle_t dec_stage_h;
   audio_psm_stage_params_t dec_stage_params;

   audio_psm_stage_handle_t ddc_sync_stage_h;
   audio_psm_stage_handle_t enc_stage_h;   
   int substream_id;
   bool ddt_ddce_testmode;
   ismd_audio_ms10_ddc_single_input_dual_ch_mix_mode_t dual_ch_mix;
   union {
      // DDC only
      audio_psm_stage_params_t ddc_sync_parames;
      // DDT only
      audio_psm_stage_params_t enc_stage_params;
   };

   // both
   audio_psm_stage_connection_metadata_t dec_conn_mda;
}audio_psm_ms10dec_pipe_t;

typedef struct {
   bool in_use;
   bool is_sw_output;
   bool is_encoder_output;
   ismd_audio_encode_format_t encode_format;
   bool matrix_dec_enabled;
   int srs_output_context;
   int sample_size;
   int sample_rate;
   int channel_count;
   uint32_t channel_map;
   int duplicate_index;
   int output_handle;
   int hw_id;
   ismd_audio_downmix_mode_t dmix_mode;
   ismd_queue_handle_t output_queue;
   int delay_ms;
}psm_output_t;

#define NO_DUPLICATE_OUTPUT -1

typedef struct {
   int count;
   bool only_have_sw_output;
   bool output_fs_match;
   bool have_dual_encoder_output;
   psm_output_t outputs[AUDIO_MAX_OUTPUTS];
}audio_psm_output_configs_t;

typedef struct _ismd_audio_processor_context_t ismd_audio_processor_context_t; 
typedef struct {
   bool availability;
   uint8_t dsp_num;
   union {
      // To determine whether dcv is used to decode current format.
      bool ddplus_dcv_in_use;
   };
}audio_available_codecs_t;

//List of codecs supported 
//To find out what codecs we have use the codec enum to index into this array
extern audio_available_codecs_t available_codecs[ISMD_AUDIO_MAX_LIBS];
extern audio_available_codecs_t available_ms10_codecs[ISMD_AUDIO_MAX_LIBS];
extern audio_available_codecs_t available_dcv_codec;

/** Workload used to control an input stream instance.
\struct ismd_audio_input_wl_t*/
typedef struct {
ismd_audio_processor_t processor_id;
int input_id;//Index to input context contained in the processor wl.
ismd_dev_t smd_dev_h;
ismd_dev_state_t state;
ismd_audio_processor_context_t *processor_wl; //Pointer to parent processor. It should (processor_wl->handle_id == processor_id). 
ismd_audio_capture_t capture_h;               // handle of phys input port

bool in_use;
bool disable_decode;
bool is_sw_input;
bool is_timed_stream;
audio_input_type_t input_type;
bool added_to_post_atc_pipe;
bool has_passthr_stream;
bool out_of_band; //Flag to notify OOB being used for PCM buffer attribs
bool disabled;
bool disable_primary_output;//Flag to not enqueue any data to the primary output queue when in passthrough mode.
bool ignore_inband_rate_change;
bool pass_needs_basetime;
bool pass_needs_clock;
bool last_buffer_discrd_pts_past_stop_value;
int rate;//Speed of playback. TM.
int hw_id;
int mixer_input_index;
int client_id_last_seen;
bool ad_valid;
ismd_audio_input_parsing_mode_t parsing_mode;
unsigned int parser_event_mask;
bool needs_pcm_preprocessing;

/* Timing lite underrun tracking */
ismd_event_t underrun_event;
int underrun_count;
uint64_t underrun_amount;

/* Stream information */
int sample_size;
int sample_rate;
int channel_config;
int channel_count;
ismd_audio_format_t format;
ismd_audio_input_parsing_status_t parser_status;

/* Timing accuracy variables */
int allowed_ms_drift_ahead;
int allowed_ms_drift_behind;

/*Timing control unit variables*/
ismd_time_t smd_base_time;
ismd_clock_t clock;
ismd_clock_t slave_clock;
ismd_timing_mode_t timing_mode;
audio_atc_stream_t atc_stream_h;
ismd_queue_handle_t atc_in_queue_h;
ismd_queue_handle_t atc_out_queue_h;

/* Sub-unit device handles */
ismd_queue_handle_t audio_in_queue_h;
ismd_queue_handle_t audio_in_passthrough_queue_h;
ismd_queue_handle_t dec_in_queue_h;
ismd_port_handle_t input_port;
audio_psm_decode_pipe_t psm_dec_pipe;

/*Passthrough/Primary input variables*/
bool pass_pipe_enabled;
bool pass_queue_has_buf;
bool pass_buf_has_ref;
bool primary_queue_has_buf;
bool pass_atc_stream_disabled;
bool ddplus_dcv_enabled;
bool ddplus_dcv_pcm_enabled;
bool ddplus_dcv_dd_enabled;
bool dcv_on_secondary_decode_stage;
ismd_queue_handle_t pass_psm_pipe_in_queue_h;
ismd_queue_handle_t pass_atc_in_queue_h;
ismd_queue_handle_t pass_atc_out_queue_h;
audio_atc_stream_t pass_atc_stream_h;
ismd_audio_input_pass_through_config_t pass_config;
ismd_audio_pass_through_mode_t pass_through_mode;

/* MS10 DDC/DDT dual_dec mode  */
audio_psm_ms10dec_pipe_t psm_ms10_pipe;        // MS10 DDT path pipeline
audio_psm_ms10dec_pipe_t psm_ms10_pipe_assoc;  // MS10 DDC path pipeline for associated audio
ismd_queue_handle_t assoc_ms10dec_in_queue_h;      // MS10 DDC associated audio
ismd_queue_handle_t assoc_atc_in_queue_h;          // MS10 DDC associated audio
ismd_queue_handle_t assoc_atc_out_queue_h;         // MS10 DDC associated audio
audio_atc_stream_t assoc_atc_stream_h;             // MS10 DDC associated audio

/* Current mixer coefficients */
ismd_audio_channel_mix_config_t mixer_coeff;

bool wait_with_timeout;
audio_time_rebase_info_t rebase_info;
ismd_time_t apm_base_time;
ismd_pts_t  last_linear_pts;
ismd_pts_t  last_scaled_pts;   
ismd_pts_t  last_segment_pts;  
ismd_pts_t curr_scaled_pts;
unsigned int fixed_back_end_delay_chunk;

ismd_clock_t capture_sync_clock; //used by capture driver to do clock recovery

//Used as memory location where ATC writes its stream position information to.
ismd_audio_stream_position_info_t atc_stream_pos;  

ismd_buffer_descriptor_t *output_buffer; //Buffer used to store when output queue is full

ismd_event_t notification_events[ISMD_AUDIO_NOTIFY_COUNT];

ismd_event_t input_port_event;
ismd_port_status_t input_port_status;  // log port status

audio_input_ms10_type_t ms10_input_type;    // MS10 DDC assoc audio
bool asrc_enabled;
os_mutex_t lock;
   
} ismd_audio_input_wl_t;

/** Workload used to control an output stream instance.
\struct  ismd_audio_output_wl_t*/
typedef struct{
ismd_audio_processor_t processor_id;
ismd_audio_processor_context_t *processor_wl; //Pointer to parent processor.

bool in_use;
bool start_to_close;
bool is_sw_output;
bool enabled;
bool encode_params_set;
bool is_muted;
int srs_context_info;
int hw_id;
int handle;
int sample_size;
int sample_size_actual;
int sample_rate;
int channel_count;
int bit_clk_div_val;
int ch_map;
int curr_gain;
int delay_ms;
ismd_audio_iec60958_channel_status_t ch_status;
ismd_audio_channel_config_t channel_config;
ismd_audio_format_t render_format;
ismd_audio_downmix_mode_t dmix_mode;

ismd_audio_processor_t proc_h;//To identify which processor is associated with.
ismd_audio_render_t render_h;
bool psm_output_queue_disabled;
bool reconfig_post_atc_pipe;
bool reconfig_pass_pipe;
ismd_queue_handle_t psm_output_queue;
ismd_port_handle_t output_port;
ismd_audio_output_mode_t output_mode;

/*Output Port related members*/
ismd_event_t queue_data_avail_event ;
ismd_event_t out_port_full_event;
os_thread_t output_port_thread;
os_thread_t render_recovery_thread;
os_mutex_t lock;
} ismd_audio_output_wl_t;

/** Workload used to control a processor instance.
\struct  ismd_audio_output_wl_t*/
struct _ismd_audio_processor_context_t {
unsigned int handle_id;
int passthrough_output_count;
ismd_audio_matrix_decoder_t active_matrix_decoder;

bool start_to_close;
bool in_use;
bool is_global_processor;
bool muted;
bool wait_with_timeout;
audio_process_mode_t process_mode;
ismd_audio_format_t primary_input_format;
audio_psm_post_atc_pipe_t psm_pa_pipe;
audio_psm_post_atc_pipe_t psm_pass_pipe;

ismd_audio_input_wl_t *primary_input_wl;
ismd_audio_input_wl_t *secondary_input_wl;
ismd_event_t input_port_event;
os_thread_t input_port_manager_thread;
os_mutex_t lock;
os_mutex_t atc_psm_queue_lock;

audio_atc_t atc_h;
int input_count;
int output_count;
int timed_input_count;
int enable_atc_fast_output;
audio_psm_output_configs_t output_configs;
ismd_audio_input_wl_t inputs[AUDIO_MAX_INPUTS];
ismd_audio_output_wl_t outputs[AUDIO_MAX_OUTPUTS];
int per_channel_volume[AUDIO_MAX_OUTPUT_CHANNELS]; /* Per-channel volume applied post-mix. */
int master_volume;
int post_mix_ch_gain[AUDIO_MAX_OUTPUT_CHANNELS];
bool master_volume_enable;
bool per_channel_volume_enable;
unsigned int master_clk_freq_hz;
ismd_audio_clk_mode_t clk_mode; 
clock_sync_t clock_sync_h; 
ismd_clock_t *atc_timer_clock_h;
audio_independent_clock_recovery_mode_t clock_recovery_mode;
int chunk_size_period;     // chunk size period in ms
ismd_audio_channel_mix_config_t default_mix_coeff;
bool asrc_support_enabled;
ismd_audio_src_quality_t src_quality;
};

typedef struct {
  ismd_audio_processor_t processor_h;
  ismd_dev_t input_h;
} ismd_audio_input_connection_data_t;

typedef struct {
   unsigned char length_and_reserved; /* [4:7] the number of significant bytes following this length field (8) [0:3] reserved */
   unsigned char text_tag[5];   /* 0x4454474144 */
   unsigned char rev_text_tag;  /* 0x31 */
   unsigned char fade_byte;  
   unsigned char pan_byte;  
   unsigned char reserved[7];
}ismd_audio_descriptor_t;

/*power state, right now only D0(power on) and D3(power off) are used*/
typedef enum {
   ISMD_AUDIO_POWER_STATE_D0,
   ISMD_AUDIO_POWER_STATE_D1,
   ISMD_AUDIO_POWER_STATE_D2,
   ISMD_AUDIO_POWER_STATE_D3,
} ismd_audio_power_state_t;

/*********************************************************************************************/
/*********************************************************************************************/
/* APM Common Function Declarations*/
/*********************************************************************************************/
/*********************************************************************************************/
/* Processor Common Functions*/
/*********************************************************************************************/

extern ismd_audio_processor_context_t processor_context[AUDIO_MAX_PROCESSORS];

/*Audio Core inline functions.*/
static inline ismd_audio_processor_context_t* 
audio_get_processor(ismd_audio_processor_t processor_id) 
{
   ismd_audio_processor_context_t* process_wl = NULL;

   if (processor_id >=0 && processor_id < AUDIO_MAX_PROCESSORS) {
      process_wl = processor_context + processor_id;
   }
   
   return process_wl;
}

static inline int
audio_get_chunk_period(ismd_audio_processor_t processor_id)
{
   ismd_audio_processor_context_t* process_wl = NULL;
   int chunk_period;

   process_wl = audio_get_processor(processor_id);
   if(process_wl == NULL) {
      // return Processor's default chunk size, if the processor is still not valid. 
      chunk_period = AUDIO_CHUNK_TIME_PERIOD_MS;
   }
   else {
      chunk_period = process_wl->chunk_size_period;
   }

   return chunk_period;
}

static inline bool
audio_processor_is_ms10(ismd_audio_processor_t processor_id)
{
   ismd_audio_processor_context_t* process_wl = NULL;
   bool ret = false;

   process_wl = audio_get_processor(processor_id);
   if(process_wl == NULL) {
      // should not happen
      OS_ASSERT(0);
   }
   else {
      ret = (process_wl->process_mode == AUDIO_PROCESS_MODE_MS10) ? true : false;
   }

   return ret;
}


ismd_result_t 
audio_processor_lock_and_get_wl(ismd_audio_processor_t proc_h, ismd_audio_processor_context_t **wl);

void 
audio_processor_lock (ismd_audio_processor_context_t *instance); 

void 
audio_processor_unlock (ismd_audio_processor_context_t *instance);

bool
audio_pvt_available_codec(int codec_id);

bool
audio_pvt_available_ms10_codec(int codec_id);

ismd_result_t
audio_get_mixing_sample_rate( ismd_audio_processor_context_t *wl, 
                                                int mixer_input_index,
                                                ismd_audio_mix_sample_rate_mode_t *sample_rate_mode,
                                                int *sample_rate);


/*********************************************************************************************/
/* Inputs' Common Functions*/
/*********************************************************************************************/
ismd_result_t
audio_input_initialize(void);

void
audio_input_init_wl(ismd_audio_input_wl_t *input_wl);

void
audio_input_mixer_config_set_gain( ismd_audio_channel_mix_config_t *channel_mix_config, 
                                    int one_to_one_val, int n_by_m_value );

ismd_result_t
audio_remove_input_no_reconfig(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h);

ismd_result_t
audio_remove_input_reconfig(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h);

void
*audio_input_port_manager_thread(void *context);


/* Initialize the events for a new input.  Should be called when adding an input. */
ismd_result_t audio_input_initialize_events( ismd_audio_input_wl_t *input_workload );

/* Deinitialilzed the events for an input.  Should be called when removing an input. */
ismd_result_t audio_input_deinitialize_events( ismd_audio_input_wl_t *input_workload );

/* Signal an asynchronous notification for a specific input event. */
ismd_result_t audio_input_notify_event( ismd_dev_t input_h, 
                                        ismd_audio_notification_t  event_type );

/*********************************************************************************************/
/* Outputs' Common Functions*/
/*********************************************************************************************/
bool 
audio_processor_valid_handle( ismd_audio_processor_t handle );

void
audio_output_init_wl(ismd_audio_output_wl_t *output_wl);

ismd_result_t
audio_remove_output_no_reconfig(ismd_audio_output_wl_t *output_wl);

ismd_result_t
audio_output_enable( ismd_audio_output_wl_t *output_wl);

ismd_result_t
audio_output_disable( ismd_audio_output_wl_t *output_wl);

ismd_result_t
audio_output_api_lock( ismd_audio_processor_t processor_h, ismd_audio_output_t output_h, ismd_audio_output_wl_t **output_wl );

ismd_result_t
audio_output_validate_and_lock_wl( ismd_audio_processor_t processor_h, ismd_audio_output_t output_h, ismd_audio_output_wl_t **output_wl );

void
audio_output_unlock(ismd_audio_output_wl_t *instance);

void
audio_output_api_unlock(ismd_audio_output_wl_t *instance);

void
audio_quality_pipe_init(audio_quality_context_t *aq_pipe);

void
audio_quality_pipe_get_context(ismd_audio_processor_context_t *wl, int output_h, audio_quality_context_t **aq_pipe);

void
audio_processor_init_wl(ismd_audio_processor_context_t *wl);

ismd_result_t
audio_processor_get_wl(ismd_audio_processor_t proc_h, ismd_audio_processor_context_t **wl);

void
audio_processor_init_psm_pipe_wl(audio_psm_post_atc_pipe_t *pipe);

ismd_result_t
audio_processor_post_atc_pipe_reconfig(ismd_audio_processor_context_t *wl, bool force_reconfig, bool reconfig_pass_pipe);

ismd_result_t
audio_processor_reconfig_passthrough_outptus(ismd_audio_processor_context_t *wl);

ismd_result_t
audio_processor_psm_pipe_connect_stages(ismd_audio_processor_context_t *wl);

ismd_result_t
audio_processor_psm_pipe_add_input(ismd_audio_input_wl_t *input_wl, int mixer_input_index, audio_psm_output_configs_t *output_configs);

ismd_result_t
audio_processor_psm_pipe_remove_input(ismd_audio_processor_context_t *wl, int input_id);

ismd_result_t
audio_processor_setup_pass_through_pipe(ismd_audio_processor_context_t *wl, ismd_audio_input_wl_t *input_wl, bool lock_outputs);

ismd_result_t
audio_processor_start_post_atc_pipe(ismd_audio_processor_context_t *wl, audio_psm_pipe_handle_t pipe_h, bool lock_outputs);

void
audio_set_fast_output_mode(ismd_audio_processor_context_t *wl);

/*********************************************************************************************/


/*********************************************************************************************/
/* Decoder parameter configuration functions*/
/*********************************************************************************************/

ismd_result_t
audio_ddplus_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_ddplus_set_default_decode_params(audio_psm_decode_params_t *dec_params);

ismd_result_t
audio_ddplus_dcv_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_ddplus_dcv_set_default_decode_params(audio_psm_decode_params_t *dec_params );

ismd_result_t
audio_dd_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_dd_set_default_decode_params(audio_psm_decode_params_t *dec_params);

ismd_result_t
audio_ac3_enc_set_default_params(audio_psm_decode_params_t *dec_params);

ismd_result_t
audio_ac3_enc_set_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_dts_enc_set_default_params(audio_psm_decode_params_t *dec_params);

ismd_result_t
audio_dts_enc_set_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_aac_enc_set_default_params(audio_psm_decode_params_t *dec_params);

ismd_result_t
audio_aac_enc_valid_output_sample_rate(int sample_rate) ;

ismd_result_t
audio_aac_enc_set_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_truehd_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_truehd_set_default_decode_params(audio_psm_decode_params_t *dec_params);

ismd_result_t
audio_mpeg_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_mpeg_set_default_decode_params(audio_psm_decode_params_t *dec_params);

ismd_result_t
audio_wma_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_aac_set_default_decode_params(audio_psm_decode_params_t *dec_params, ismd_audio_format_t format);


ismd_result_t
audio_dts_lbr_set_default_decode_params(audio_psm_decode_params_t *dec_params);
//SS
ismd_result_t
audio_dts_neo6_set_default_decode_params(audio_psm_decode_params_t *neo6_stage_params);

ismd_result_t
audio_dts_neo6_set_decode_param(audio_psm_stage_params_t *psm_stage_params, int param_id, ismd_audio_decoder_param_t *param_value);

//DBHSD212143
ismd_result_t
audio_dts_set_default_decode_params(audio_psm_decode_params_t *dec_params );

ismd_result_t
audio_dts_bc_set_default_decode_params(audio_psm_decode_params_t *dec_params );

ismd_result_t
audio_dts_hd_set_default_decode_params(audio_psm_decode_params_t *dec_params );

ismd_result_t
audio_dts_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_dts_bc_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_dts_hd_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_dts_lbr_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_dts_hd_get_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);
//DB
ismd_result_t
audio_aac_set_decode_param(audio_psm_decode_pipe_t *pt_psm_dec_pipe, audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_ms10_ddc_set_default_decode_params(audio_psm_decode_params_t* dec_params);

ismd_result_t
audio_ms10_ddplus_set_decode_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_ms10_ddc_set_param(audio_psm_ms10dec_pipe_t* psm_ms10_pipe, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_ms10_ddt_set_default_decode_params(audio_psm_decode_params_t* dec_params);

ismd_result_t
audio_ms10_ddt_set_param(audio_psm_ms10dec_pipe_t *pt_psm_dec_pipe, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_ddt_ac3_enc_set_default_params(audio_psm_decode_params_t *dec_params);

ismd_result_t
audio_ddt_ac3_enc_set_param(audio_psm_decode_params_t *psm_decode_params, int param_id, ismd_audio_decoder_param_t *param_value);

ismd_result_t
audio_input_suspend(ismd_audio_input_wl_t *input_wl);

ismd_result_t
audio_input_resume(ismd_audio_input_wl_t *input_wl);

ismd_result_t
audio_input_notify_decoder_of_dmix_modes(ismd_audio_input_wl_t *input_wl, audio_psm_output_configs_t *output_configs);

ismd_result_t
audio_output_suspend(ismd_audio_output_wl_t *output_wl);

ismd_result_t
audio_output_resume(ismd_audio_output_wl_t *output_wl);

ismd_result_t
ismd_audio_suspend(void);

ismd_result_t
ismd_audio_resume(void);

ismd_result_t
audio_apm_suspend(ismd_audio_processor_context_t* proc_wl);

ismd_result_t
audio_apm_resume(ismd_audio_processor_context_t* proc_wl);

#ifdef POWER_MANAGEMENT
int ismd_audio_pm_suspend(struct pci_dev *dev, pm_message_t state);

int ismd_audio_pm_resume(struct pci_dev *dev);
#endif
/*******************************************************************/


#endif


