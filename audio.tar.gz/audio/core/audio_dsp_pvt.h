/*  
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_DSP_PVT_H_
#define _AUDIO_DSP_PVT_H_

#include "osal.h"

#include "ismd_audio_defs.h"
#include "ismd_core.h"
#include "ismd_core_protected.h"
#include "osal.h"
#include "sven_module.h"
#include "audio_dsp.h"
#include "audio_psm_defs.h"
#include "sven_module.h"
//#include "ismd_audio_codec_fw_defs.h"
#include "audio_dsp_common.h"
/*
Temporary defines while SVEN issue is resolved
*/
#define IPCX 0x14
#define IPCD 0x18
#define ISRX 0x4
#define IMRX 0xc
#define CSR  0x0

#define AUDIO_DSP_MAX_WORKLOADS 8

#define AUDIO_DSP_PCI_SIZE 0x1000

//#define AUDIO_DSP_MAX_AUX_PSM_BUFFERS 30


#define AUDIO_DSP_IPCX_DSP_BUSY (1 << 31)
#define AUDIO_DSP_IPCD_HOST_DONE (1 << 30)
#define AUDIO_DSP_IPCD_INTR 2
#define AUDIO_DSP_IPCX_INTR 1

//#define DSP_SVEN_RELAY 0

typedef struct _audio_dsp_device_t audio_dsp_device_t;

/* --------------------------------------------------------------------------- */
/* Structure represents a pipe in a DSP */
/* --------------------------------------------------------------------------- */
typedef struct
{
	int handle;	/* Usually the index into the array to which this element belongs to. */
   uint32_t dsp_num; /* The DSP the wl/pipe belongs to. Can be either 0 or 1. Also used as 
								index into the DSP device array. */
   int fw_handle; /* Each wl is associated with workload in the fw. This handle is used 
                     when passing messages to fw. */
   audio_dsp_device_t *dev_wl;
									
   bool started;	/* Is set to true once the pipe is added and is in a started state. */
   bool in_use;   /* in_use signifies that the wl is taken in DSP host and FW modules.  */ 
	bool configured; /* Pipe needs to be configured. */
	audio_psm_pipe_t *pipe;

	os_mutex_t lock;   

	/* This holds the input jobs to the DSP.*/
	ismd_buffer_descriptor_t *input_jobs_smd_buf_desc;
	audio_psm_job_desc_t *input_jobs;
	uint32_t input_jobs_count;

	/** This holds the output jobs to the DSP.*/
	ismd_buffer_descriptor_t *output_jobs_smd_buf_desc;
   /** Ouput queues associated with this DSP pipe.*/
   audio_psm_pipe_output_queues_t *output_queues;
   /** Tracking variables for each output queue in the DSP pipe.*/
   audio_psm_queue_tracker_t out_queue_track[PSM_PIPE_MAX_NUM_OUT_QUEUES];

	/* Input jobs pointers */
	audio_psm_job_desc_t *cur_in_job;
	audio_psm_job_desc_t *prev_in_job;

   bool notify_fw_input_job_available;
   bool notify_fw_output_job_consumed;
} audio_dsp_wl_t;
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Structure represents a physical DSP and related attributes */
/* --------------------------------------------------------------------------- */
struct _audio_dsp_device_t{
	int handle;	/* Usually the index into the array to which this element belongs to. */
   
	int device_num; /* Can be either 0 or 1. */
   bool needs_io_notification;
	bool fw_loaded;
	pal_dev_id_t pal_dev_id;
//	SVEN_Module sven_dev_id;
	uint32_t sven_dev_id;
	char build_time[256];
	os_interrupt_t intr_handle;
	
	pal_info_t pal_info;
	pal_info_t *pal_info_ptr;	// this would be set to &pal_info defined above
		
	os_devhandle_t  *devh;
	ismd_buffer_descriptor_t *kernel_smd_buf_desc;

	/* PSM buffers */
	ismd_buffer_descriptor_t *psm_bufs_smd_buf_desc;
	audio_psm_buf_desc_t *psm_bufs;
	uint32_t psm_bufs_count;
	
	os_mutex_t lock;
	os_mutex_t ipc_lock;

	os_event_t fw_init_done_event;
	bool fw_init_done_event_created; //needed to decide whether event was created or not to destroy

	os_event_t sync_msg_proc_done_event;  /* The event that is set in the interrupt handler when fw is done
	                                    processing what it needs to do in response to a message from host. */
   bool sync_msg_proc_done_event_created;                                          	

   /* */
   uint32_t last_sync_msg;   /* The last synchronous message the host is waiting for a response. */
   uint32_t last_sync_msg_fw_wl; /* wl_id associated with this message. */
   uint32_t last_sync_msg_status;  /* Status var set in the interrupt handler that signifies success or failure of that 
                                 last operation. 0 - Success 1 - Failure */
   int fw_handle; /* Each wl is associated with workload in the fw. This handle is used when passing messages to fw. */
   char *codec_ver_string;
   codecs_available_t codecs_available;
   
	/* This is the event that the io thread of the PSM abstraction layer waits on. 
		When a job is consumed or an output job is available the uppser PSM abstraction
		layer needs to be notified. */
	/* TODO: Is this safe to pass a pointer to an event from PSM to DSP?? */	
	os_event_t *psm_io_event;

};
/* --------------------------------------------------------------------------- */


/* --------------------------------------------------------------------------- */
/* Private function definitions */
/* --------------------------------------------------------------------------- */

static audio_dsp_wl_t *audio_dsp_pvt_wl_get (audio_dsp_handle_t handle );
	
static void audio_dsp_pvt_wl_reset(audio_dsp_wl_t *wl);
	
static void audio_dsp_pvt_wl_release(audio_dsp_wl_t *wl);
static void audio_dsp_pvt_device_reset(audio_dsp_device_t *dev);
	
static ismd_result_t audio_dsp_pvt_assign_dsp (audio_dsp_wl_t *wl, audio_psm_pipe_type_t type);

static void audio_dsp_pvt_wl_lock(audio_dsp_wl_t *wl);

static void audio_dsp_pvt_wl_unlock(audio_dsp_wl_t *wl);

static void audio_dsp_pvt_device_lock(audio_dsp_device_t *dev);

static void audio_dsp_pvt_device_unlock(audio_dsp_device_t *dev);

static void audio_dsp_pvt_interrupt_handler ( void * data );

static ismd_result_t audio_dsp_pvt_send_message ( audio_dsp_wl_t *wl, 
	  																 uint8_t message_id,
	  																 uint8_t message_data,
	  																 bool wait_for_response);

static ismd_result_t audio_dsp_pvt_send_msg_direct( unsigned int dsp_num,
                                                    unsigned int fw_handle,
                                                    uint8_t message_id,
                                                    uint8_t message_data,
                                                    bool wait_for_response,
                                                    int *new_fw_handle);

static void audio_dsp_pvt_buffer_reset( audio_psm_buf_desc_t *psm_buf,
														bool dereference_buf );

static ismd_result_t audio_dsp_pvt_buffer_allocate(audio_psm_buf_desc_t *psm_buf,
                                                   audio_psm_pipe_type_t pipe_type,
																	uint32_t size,
																	uint32_t remap);

static void audio_dsp_pvt_set_dbreg_value(uint32_t *reg_val,
														uint32_t status,
														uint32_t wl_id,
														uint32_t message,
														uint32_t data);


static ismd_result_t audio_dsp_pvt_init_jobs(audio_dsp_wl_t *wl);

static ismd_result_t audio_dsp_pvt_wl_preprocess( audio_dsp_wl_t *wl );

static void audio_dsp_pvt_job_reset ( audio_psm_job_desc_t *job, bool dereference_buf );

static char * audio_dsp_pvt_message_get_name(int message_id);

static ismd_result_t audio_dsp_pvt_pipe_flush( audio_dsp_wl_t *wl );

static audio_dsp_handle_t audio_dsp_pvt_wl_get_by_fw_handle ( int dsp_num, int fw_handle );

static void audio_dsp_pvt_download_fw(int dsp_num);

static void audio_dsp_pvt_store_init_to_mailbox(int dsp_num);

static void audio_dsp_pvt_enable_fw_sven(int dsp_num);
/* For later use if needed. */
/* --------------------------------------------------------------------------- 
static bool audio_dsp_pvt_psm_buf_available(audio_dsp_device_t *dsp_dev);
static bool audio_dsp_pvt_job_queue_full(audio_psm_job_desc_t *job);
static bool audio_dsp_pvt_job_queue_empty(audio_psm_job_desc_t *job);
--------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------- */

#endif

