/*
* File Name: ismd_audio_capture_pvt.h
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_CAPTURE_PVT_H_
#define _AUDIO_CAPTURE_PVT_H_

#include "audio_core.h"
#include "audio_capture.h"
#include "audio_hal_defs.h"
#include "audio_hal_capture.h"
#include "audio_apm_common.h"

#define AUDIO_CAPTURE_CIRC_BUF_SIZE (32*1024)
#define AUDIO_CAPTURE_LINKED_LIST_NODE_MEM_SIZE (8*1024)

#define AUDIO_CAPTURE_MAX_WAIT_TO_CLEANUP_DMA_LL 13

#define DD_STEREO_SAMPLES_PER_ES_PKT   1536
#define DD_PACKETIZED_FRAME_SIZE       (DD_STEREO_SAMPLES_PER_ES_PKT * 4)

#define IEC61937_AUDIO_NULL_DATA  0  
#define IEC61937_AUDIO_AC3_DATA   1
#define IEC61937_AUDIO_PAUSE_DATA 3

typedef enum {
   AUDIO_CAPTURE_PTS_NOT_VALID,
   AUDIO_CAPTURE_DOWNSTREAM_QUEUE_FULL,
   AUDIO_CAPTURE_STATE_STOP
} audio_capture_discard_buf_t;


/*Context workload structure.*/
typedef struct {
   ismd_audio_processor_t processor_id;
   int hw_dev_id;
   void* input_context;             // store the input_wl handle
   uint64_t samples_captured;
   uint32_t curr_buffer_cnt;
   unsigned int sample_size;
   unsigned int actual_sample_size;
   unsigned int sample_rate;
   unsigned int chunk_size_bytes;
   unsigned int chunk_size_samples;
   unsigned int  chunk_size_ticks; // in terms of 90KHz
   unsigned int prefill_bytes_max;
   unsigned int prefill_bytes;
   unsigned int prefill_milliseconds;
   unsigned int overflow_threshold; // overflow threshold in milliseconds or chunk numbers
   
   bool in_use;
   bool start_to_close;
   bool capture_hw_started;
   bool buffer_overflow;
   bool bitclk_direction;        // capture port bit_clk direction. 0 - as input, 1 - as output
   bool msb_justified;           // capture port 16bit input data format. 0 - I2s format, 1 - MSB Right Justified
   bool i2s0_bitclk_direction;        // capture port bit_clk direction. 0 - as input, 1 - as output
   bool i2s0_msb_justified;           // capture port 16bit input data format. 0 - I2s format, 1 - MSB Right Justified
   bool i2s1_bitclk_direction;        // capture port bit_clk direction. 0 - as input, 1 - as output
   bool i2s1_msb_justified;           // capture port 16bit input data format. 0 - I2s format, 1 - MSB Right Justified
   bool spdif_clock_update_rate;     // FALSE - SPDIF measured clk is updated every 192 stereo samples, TRUE - SPDIF measured clk is updated every stereo sample 
   
   ismd_dev_state_t state;
   int cap_ch_config;
   int cap_ch_count;
   ismd_audio_format_t data_format;
   bool parse_pcm;
   int parse_pcm_count;
   audio_hal_capture_context_t hal_capture_h;
   ismd_buffer_descriptor_t *dma_buffer_des;
   ismd_buffer_descriptor_t *cubby_buffer;//Cubby buffer for when DMA is full

   ismd_event_t input_data_event;
   os_event_t safe_to_close_event;

   ismd_queue_handle_t output_queue;
   int bit_clk_div_val;
   ismd_time_t capture_timestamp; 
   ismd_time_t capture_time; 
   bool new_segment_tagged;
   ismd_clock_t sync_clock;
   ismd_clock_t clock;
   audio_input_type_t input_type;
   bool is_timed_stream;
   ismd_audio_clk_mode_t clock_mode;
   audio_independent_clock_recovery_mode_t clock_recovery_mode;
   os_mutex_t lock;
} ismd_audio_capture_context_t;

static void
audio_pvt_capture_init_wl( ismd_audio_capture_context_t *wl);

static ismd_result_t
audio_pvt_capture_lock_and_get_wl(ismd_audio_capture_t capture_h,  ismd_audio_capture_context_t **wl);

static bool
audio_pvt_capture_valid_handle( ismd_audio_capture_t capture_h);

static void
audio_pvt_capture_lock(ismd_audio_capture_context_t *wl);

static void
audio_pvt_capture_unlock(ismd_audio_capture_context_t *wl);

static ismd_result_t
audio_pvt_capture_valid_hw_id(int hw_output_id);

static ismd_result_t
audio_pvt_capture_setup_linked_list_mode( ismd_audio_capture_context_t *wl);

static ismd_result_t
audio_pvt_capture_buffer_callback(void *context, int buffer_id, audio_hal_capture_event_t buf_event);

static ismd_result_t
audio_pvt_capture_rebuffer(ismd_audio_capture_context_t *wl, bool need_to_start_dma);

static unsigned int
audio_pvt_capture_add_buffer_to_dma(ismd_audio_capture_context_t *wl);


static ismd_result_t
audio_pvt_capture_push_and_flow_control(ismd_audio_capture_context_t* wl, ismd_buffer_descriptor_t* buffer);

static ismd_result_t
audio_pvt_get_bit_clk_div_val(ismd_audio_capture_context_t *wl, unsigned int master_clk_freq);

static ismd_result_t
audio_pvt_get_clk_div_based_on_master_freq(ismd_audio_capture_context_t *wl, 
                                                      unsigned int master_clk_freq);

static ismd_result_t 
audio_pvt_capture_get_burst_size(ismd_audio_capture_context_t *wl,
                                       int *burst_size,
                                       int *xburst_size);


#endif

