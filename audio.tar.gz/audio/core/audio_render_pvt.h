/*
* File Name: ismd_audio_render_pvt.h
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#ifndef _AUDIO_RENDER_PVT_H_
#define _AUDIO_RENDER_PVT_H_

#include "audio_render.h"
#include "audio_core.h"
#include "gen3_audio.h"
#include "audio_hal_defs.h"
#include "audio_hal_render.h"

// GDL Includes for HDMI audio HAL.
// ABD = Audio Back Door, meaning the interface to the HDMI audio HAL
#include "abd.h"
#include "gdl_types.h"
#include "gdl_pd.h"


//#define AUDIO_RENDER_DMA_BUFFER_SIZE (16 *1024*1024)
#define AUDIO_RENDER_CIRC_BUF_SIZE (32*1024)
#define AUDIO_RENDER_LINKED_LIST_NODE_MEM_SIZE (8*1024)
#define AUDIO_RENDER_DEFAULT_BUFFER_PREFILL_BYTES (26*1024)
#define AUDIO_RENDER_TIME_STAMP_ENCODE_DRIFT_CHUNK 3  // 3 * AUDIO_CHUNK_SIZE_SAMPLES()
#define BYTES_NEEDED_FOR_PAUSE_BURST_HEADER 16
#define BYTES_NEEDED_FOR_PAUSE_BURST_PAYLOAD 2 //Need at least one sample to send as pause burst. 
#define BUFFER_TRACKING_QUEUE_DEPTH 10


typedef enum ENUM_AUDIO_RENDER_OUPUT_INTERFACE {
   AUDIO_RENDER_INTERFACE_INVALID,
   AUDIO_RENDER_INTERFACE_I2S0,
   AUDIO_RENDER_INTERFACE_I2S1,
   AUDIO_RENDER_INTERFACE_SPDIF,
   AUDIO_RENDER_INTERFACE_HDMI
} audio_render_output_interface_t;

typedef enum{
   AUDIO_HDMI_HBR,
   AUDIO_HDMI_LAYOUT0,
}audio_hdmi_transport_layout_t;

typedef struct STRUCT_AUDIO_RENDER_IEC60958_CHANNEL_STATUS
{
   //User tweakable status bits
   ismd_audio_iec60958_channel_status_t status;
   
   //Internal status bits.
   bool is_pcm;
   int sample_rate;
} audio_render_iec60958_channel_status_t;

typedef struct STRUCT_AUDIO_HDMI_HAL
{
   void                         *hdmi_audio_h;
   gdl_hdmi_audio_fmt_t         format;
   unsigned int                 num_channels;
   gdl_hdmi_audio_fs_t          sample_rate;
   gdl_hdmi_audio_ss_t          sample_size;
   gdl_hdmi_audio_speaker_map_t speaker_map;
   bool                         tranfer_size_changed;
   audio_hdmi_transport_layout_t hdmi_transport_type;
   os_event_t stop_event;
   ismd_queue_handle_t buffer_tracking_queue;
} audio_hdmi_context_t;

/*Context workload structure.*/
typedef struct {
   ismd_audio_processor_t processor_id;
   int hw_dev_id;
   int bit_clock_div_value;
   uint64_t samples_rendered;
   uint64_t samples_rendered_tracker;
   uint64_t smd_base_time;
   uint32_t curr_buffer_cnt;
   audio_render_output_interface_t hw_output_interface;
   unsigned int sample_size;
   unsigned int sample_rate;
   unsigned int prefill_bytes_max;
   unsigned int prefill_bytes;
   unsigned int prefill_milliseconds;
   unsigned int chunk_size_bytes;
   unsigned int chunk_size_samples;
   unsigned int max_early_ms;
   bool in_use;
   bool disabled;
   bool use_time_stamps;
   bool start_to_close;
   bool render_hw_started;
   bool push_buffers; //Flag to tell me if I should push data rather than HW pulling from me.
   bool buffer_underrun;
   ismd_dev_state_t state;
   ismd_audio_channel_config_t ch_config;
   int ch_count;
   ismd_audio_format_t data_format;
   ismd_clock_t *clock_h;

   audio_hal_render_context_t hal_render_h;
   ismd_buffer_descriptor_t *dma_buffer_des;
   ismd_buffer_descriptor_t *cubby_buffer;//Cubby buffer for when output is full
   ismd_buffer_descriptor_t *output_buffer;
   audio_render_buffer_mode_t buffer_mode;

   audio_hdmi_context_t hdmi_wl;
   audio_render_iec60958_channel_status_t ch_status;
   
   ismd_event_t input_data_event;
   os_event_t safe_to_close_event;

   ismd_queue_handle_t input_queue;
   ismd_buffer_descriptor_t *silence_buffer;

   clock_sync_t clock_sync_h; 
   ismd_clock_t *heartbeat_timer_clock_h_ptr;
   ismd_clock_t heartbeat_timer_clock_h;
   bool do_heartbeat_timer_clock_recovery;
   unsigned int  chunk_size_ticks; // in terms of 90KHz
   ismd_time_t render_time; 

   os_thread_t render_manager_thread;
   os_mutex_t lock;
} ismd_audio_render_context_t;

static void
audio_pvt_render_init_wl( ismd_audio_render_context_t *wl);

static ismd_result_t
audio_pvt_render_lock_and_get_wl(ismd_audio_render_t render_h,  ismd_audio_render_context_t **wl);

static bool
audio_pvt_render_valid_handle( ismd_audio_render_t render_h);

static ismd_result_t
audio_pvt_render_stop_hw( ismd_audio_render_context_t *wl, bool reinit_hal);

static uint64_t
audio_pvt_render_get_base_sample_count(void);

static void
audio_pvt_render_lock(ismd_audio_render_context_t *wl);

static void
audio_pvt_render_unlock(ismd_audio_render_context_t *wl);

static ismd_result_t
audio_pvt_render_valid_hw_id(ismd_audio_render_context_t *wl, int hw_output_id);

static ismd_result_t
audio_pvt_render_setup_circular_buffer_mode( ismd_audio_render_context_t *wl);

static ismd_result_t
audio_pvt_render_setup_linked_list_mode( ismd_audio_render_context_t *wl);

static ismd_result_t
audio_pvt_render_buffer_callback(void *context, int buffer_id, audio_hal_render_event_t buf_event);

static gdl_ret_t
audio_pvt_render_hdmi_stop( void *abd_handle, os_event_t *stop_event, bool syncronous); 

static ismd_result_t
audio_pvt_render_hdmi_set_state( ismd_audio_render_context_t *wl, ismd_dev_state_t state);

void
audio_pvt_render_hdmi_audio_callback(void  * user_data, gdl_hdmi_audio_event_t   event, unsigned int id);

static void
audio_pvt_render_report_timing_info(ismd_audio_render_context_t *wl, int buffer_id);

static ismd_result_t
audio_pvt_render_rebuffer(ismd_audio_render_context_t *wl, bool need_to_start_dma);

static unsigned int
audio_pvt_render_send_buffer_to_dma(ismd_audio_render_context_t *wl);

static void
audio_pvt_render_prepare_silence_buffer(ismd_audio_render_context_t *wl);

static void
audio_pvt_render_handle_out_of_range_time_stamp(ismd_audio_render_context_t *wl, uint64_t render_time_slot, uint64_t buffer_time_slot, bool late);

static bool
audio_pvt_render_early_buffer_in_range(ismd_audio_render_context_t *wl, uint64_t render_time_slot, uint64_t buffer_time_slot);

static void
audio_pvt_render_sync_associated_renders(int association_id);

static void
audio_pvt_render_set_buffer_prefill_time( ismd_audio_render_context_t *wl, unsigned int milliseconds); 

static void
audio_pvt_render_spdif_make_ch_status_bytes(
   ismd_audio_render_context_t *wl,
   uint32_t *least_sig_word, 
   uint8_t *most_sig_byte);

ismd_result_t
audio_pvt_render_adjust_output_based_on_fmt( ismd_audio_render_context_t *wl );

static ismd_result_t
audio_pvt_render_hdmi_make_ch_status_bytes(ismd_audio_render_context_t *wl, uint32_t *least_sig_word, uint32_t *most_sig_word);

ismd_result_t
audio_pvt_render_iec60958_set_channel_status( ismd_audio_render_context_t *wl );

static void
audio_pvt_render_build_silence_buffer( ismd_buffer_descriptor_t * buffer, int level, ismd_audio_format_t data_format);

static void
audio_pvt_render_build_pause_burst( void * buffer_addr, int level);

static inline ismd_result_t
audio_pvt_render_dereference_buffer_safe(ismd_audio_render_context_t *wl, int buffer_id);

#endif

