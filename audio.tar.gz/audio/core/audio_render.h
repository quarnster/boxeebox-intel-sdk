
/*
* File Name: ismd_audio_render.h
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



/** @weakgroup ismd_audio ISMD Audio Data Types */
/** @ingroup ismd_audio */
/** @{ */

#ifndef _AUDIO_RENDER_H_
#define _AUDIO_RENDER_H_

#include "audio_core.h"
#include "audio_hal_common.h"
#include "audio_render_spdif.h"

/** Handle to a render device instance.
  ismd_audio_render_t */
typedef int ismd_audio_render_t;

typedef enum ENUM_AUDIO_RENDER_BUFFER_MODE {
   ISMD_AUDIO_RENDER_BUFFER_MODE_LINKED_LIST,
   ISMD_AUDIO_RENDER_BUFFER_MODE_CIRCULAR
} audio_render_buffer_mode_t;

typedef enum ENUM_AUDIO_RENDER_I2S_WS_SELECT {
   AUDIO_RENDER_I2S_WS_SELECT_INVALID,
   AUDIO_RENDER_I2S_WS_SELECT_FALLING,
   AUDIO_RENDER_I2S_WS_SELECT_RISING
} audio_render_i2s_word_select_format_t;


/** Use these values to select the how the render handles early time stamps. 
    See \ref audio_render_set_early_discard_policy. */
typedef enum ENUM_AUDIO_RENDER_EARLY_DISCARD_POLICY {
   AUDIO_RENDER_EARLY_POLICY_INVALID,                 /** Invalid render early policy */
   AUDIO_RENDER_EARLY_POLICY_DISCARD_NEVER,           /** No matter how early the timestamp, render will never discard. (default) */
   AUDIO_RENDER_EARLY_POLICY_DISCARD_FIXED_MS         /** On early timestamp if render has to wait beyond the specified time, it will discard. */
} audio_render_early_discard_policy_t;


/**
Initialize and allocate the software resources required for render control in
the Audio Subsystem. This function must be called before calling any other
function in the audio render sub-unit.

@retval ISMD_SUCCESS : The software resources for the audio renderer were
successfully initialized and/or allocated.
@retval ISMD_ERROR_NO_RESOURCES: No system resources to initialize the render.
*/
ismd_result_t
audio_render_initialize(void);

/**
De-initializes and free the software resources used for render control in the
Audio Subsystem.  This function should be called when the renderer module is
no longer needed (e.g. when unloading the audio driver).

@retval ISMD_SUCCESS : The software resources for the audio renderer were
successfully deinitialized and/or freed.
*/
ismd_result_t
audio_render_deinitialize(void) ;

ismd_result_t
audio_render_set_clock_handle(ismd_clock_t *clock_h);

ismd_result_t
audio_render_set_base_time(ismd_time_t base_time);


/**
Open a new instance of the audio renderer and return a handle to the new
instance.

@param[out] render_h : Handle to the render instance.
@param[out] hw_dev_id : Hardware ID of render device to open.
@param[in] input_queue : Handle to the SMD queue that will supply input
data to the new renderer instance
@param[in] buffer_mode : The type of buffering scheme (circular or linked-
list) to use within the renderer instance.
@param[in] association_id : An ID that associates multiple renders running 
together. For example I2S0 and SPDIF could be associated with one audio processor.
And HDMI and I2S1 could be associated with another processor. This enables the 
other renders to sync up time stamps to those renders who are running together
from the sampe processor.

@retval ISMD_SUCCESS : The render was opend and handle populated.
@retval ISMD_ERROR_INVALID_PARAMETER:  The specified hw_dev_id, input_queue
or buffer_mode parameter value was invalid.
@retval ISMD_ERROR_NO_RESOURCES: No render instance available.
*/
ismd_result_t
audio_render_open(ismd_audio_render_t *render_h,
                       int hw_dev_id,
                       ismd_queue_handle_t input_queue,
                       audio_render_buffer_mode_t mode,
                       int association_id);


/**
Close an instance of the audio renderer.  This function will free and
deinitialize all resources used by the instance.

@param[in] render_h : Handle to a renderer instance.

@retval ISMD_SUCCESS : The renderer instance was closed and its resources were
successfully freed and/or deinitialized.
@retval ISMD_ERROR_OPERATION_FAILED: An error occured while attempting to
close the instance.
@retval ISMD_ERROR_INVALID_HANDLE : The specificed renderer instance was not
valid.
*/
ismd_result_t
audio_render_close(ismd_audio_render_t render_h);


/**
Set the current state of a renderer instance.  See /ref ismd_dev_state_t for
a list of valid states.  If the device is already in the specified state,
this function will return success.

@param[in] render_h : Handle to a renderer instance.
@param[in] state : The desired state for the renderer instance.

@retval ISMD_SUCCESS : The renderer instance is now in the desired state.
@retval ISMD_ERROR_OPERATION_FAILED: The renderer instance state could not be
changed to the desired state.
@retval ISMD_ERROR_INVALID_HANDLE : The renderer instance handle was invalid.
*/
ismd_result_t
audio_render_set_state(ismd_audio_render_t render_h,
                            ismd_dev_state_t state);


/**
Retrieve the current state of a renderer instance.  See /ref ismd_dev_state_t
for a list of valid states.

@param[in] render_h : Handle to a renderer instance.
@param[in] state : The current state for the render instance.

@retval ISMD_SUCCESS : The renderer instance state was successfully retrieved.
@retval ISMD_ERROR_OPERATION_FAILED: Could not retrieve the instance state.
@retval ISMD_ERROR_INVALID_HANDLE : The renderer instance handle was invalid.
*/
ismd_result_t
audio_render_get_state(ismd_audio_render_t render_h,
                            ismd_dev_state_t *state);


/**
Set the mode of the render to accept incoming buffers based off of time stamps
that correlate to how many samples the render has rendered since it was first
started. By default the render is set to use time stamps. Call this function to disable/enable
using timestamps carried in buffer metadata.

@param[in] render_h : Handle to a renderer instance.
@param[in] use_time_stamps : Enable/disabled using time stamps.

@retval ISMD_SUCCESS : Operation completed successfully
@retval ISMD_ERROR_OPERATION_FAILED: An error occured while trying to set the
render to this mode.
@retval ISMD_ERROR_INVALID_HANDLE : The renderer instance handle was invalid.
*/
ismd_result_t
audio_render_set_timed_mode(ismd_audio_render_t render_h,
                            bool use_time_stamps);


/**
Flush out all data in a render instance's internal buffers.  The instance
will then begin processing new data from the input queue.

@param[in] render_h : Handle to the render instance.

@retval ISMD_SUCCESS : The flush operation completed successfully.
@retval ISMD_ERROR_OPERATION_FAILED: An error occured druing flush operation.
@retval ISMD_ERROR_INVALID_HANDLE : The renderer instance handle was invalid.
*/
ismd_result_t
audio_render_flush(ismd_audio_render_t render_h);

/*Render continues to consume, but does not render samples, just throws away.*/
ismd_result_t
audio_render_disable(ismd_audio_render_t render_h);

ismd_result_t
audio_render_enable(ismd_audio_render_t render_h);

ismd_result_t
audio_render_get_current_status(int association_id, unsigned int *prefill_samples, uint64_t *samples_rendered);

/**Get the number of samples rendered by a particular device by specifying its HW ID*/
ismd_result_t
audio_render_get_samples_rendered_by_id(int hw_id, uint64_t *samples_rendered);


/**
Set the amount of time in milliseconds to buffer up before starting the render.

@param[in] render_h : Handle to the render instance.
@param[in] milliseconds : Amount of time in milliseconds to buffer up before starting the render.

@retval ISMD_SUCCESS : Successfully set the pre_fill count.
@retval ISMD_ERROR_OPERATION_FAILED : The render couldnt buffer up that amount.
@retval ISMD_ERROR_INVALID_HANDLE : The renderer instance handle was invalid.
*/
ismd_result_t
audio_render_set_buffer_prefill_time(ismd_audio_render_t render_h, unsigned int milliseconds);

ismd_result_t
audio_render_set_data_format(ismd_audio_render_t render_h, ismd_audio_format_t data_format);

ismd_result_t
audio_render_i2s_set_word_select_format(ismd_audio_render_t render_h, audio_render_i2s_word_select_format_t i2s_ws_format);

ismd_result_t
audio_render_i2s_set_clock_invert(ismd_audio_render_t render_h, bool invert_i2s_clock);


/**
Set the value of the divider for external clock that drives the ouput
hardware assigned to the render instance.  The external clock frequency
is divided by this value to obtain the output bitclock.  The frequency of
the external clock is platform specific.

@param[in] render_h : Handle to a render instance.
@param[in] div_val : Divider value.  The sample-rate and the bit-rate of
the output can be derived from the following formulas.

   output_bit_rate = ext_clock_rate / div_val
   output_sample_rate = output_bit_rate / 32

@retval ISMD_SUCCESS : Divider setting was applied successfully
@retval ISMD_ERROR_OPERATION_FAILED : Could not set clock divider.
@retval ISMD_ERROR_INVALID_HANDLE : The renderer instance handle was invalid.
*/
ismd_result_t
audio_render_set_ext_bit_clock_div(ismd_audio_render_t render_h,
                                        int div_val);


/**
Set the channel configuration of the output data and hardware for the
specified renderer instance.

@param[in] render_h : Handle to a renderer instance.
@param[in] ch_config : Output channel configuration.

@retval ISMD_SUCCESS : Channel configuration successfully applied.
@retval ISMD_ERROR_OPERATION_FAILED : Could not set channel config.
@retval ISMD_ERROR_INVALID_PARAMETER : The specified ch_config value
is invalid or not supported.
@retval ISMD_ERROR_INVALID_HANDLE : The renderer instance handle was invalid.
*/
ismd_result_t
audio_render_set_channel_config(ismd_audio_render_t render_h,
                                     ismd_audio_channel_config_t ch_config);


/**
Set the audio sample size and configure the renderer output hardware this
sample size.

@param[in] render_h : Handle to a render instance.
@param[in] sample_size : Sample size of the audio output data.

@retval ISMD_SUCCESS : Setting was successfully applied.
@retval ISMD_ERROR_OPERATION_FAILED : Could not set channel config.
@retval ISMD_ERROR_INVALID_PARAMETER : The specified sample size is
invalid or not supported.
@retval ISMD_ERROR_INVALID_HANDLE : The renderer instance handle was invalid.
*/
ismd_result_t
audio_render_set_sample_size(ismd_audio_render_t render_h,
                                  int sample_size);


/**
Set the iec60958 channel status infomation it will send out over the SPDIF/HDMI interface.

@retval ISMD_SUCCESS : Setting was successfully applied.
@retval ISMD_ERROR_INVALID_HANDLE : The renderer instance handle was invalid.
*/
ismd_result_t
audio_render_iec60958_set_channel_status(
   ismd_audio_render_t render_h,
   ismd_audio_iec60958_channel_status_t channel_status);


/**
Use this function to set the policy on how the render will handle early timestamps when
the render is operating in timed mode. See \ref audio_render_early_discard_policy_t for
descriptions on policy options. 

@param[in] render_h : Handle to a render instance.
@param[in] policy : Select the policy for the render to use. See \audio_render_early_discard_policy_t
@param[in] max_early_ms : If the buffer arrives earlier than this value in 
           AUDIO_RENDER_EARLY_POLICY_DISCARD_FIXED_MS mode, render will discard.

@retval ISMD_SUCCESS : Setting was successfully applied.
@retval ISMD_ERROR_INVALID_HANDLE : The renderer instance handle was invalid.
*/
ismd_result_t
audio_render_set_early_discard_policy(ismd_audio_render_t render_h, audio_render_early_discard_policy_t policy,unsigned int max_early_ms);

ismd_result_t
audio_render_get_samples_rendered(ismd_audio_render_t render_h, uint64_t *samples_rendered);

ismd_result_t
audio_render_get_samples_prefilled(ismd_audio_render_t render_h, unsigned int *prefill_samples);

ismd_result_t
audio_render_set_sample_rate(ismd_audio_render_t render_h, int sample_rate);

ismd_result_t
audio_render_spdif_set_validity_bit(ismd_audio_render_t render_h, bool is_valid);

void 
audio_render_hw_set_power_mode(audio_hal_power_management_mode_t  power_mode);

ismd_result_t
audio_render_resume(ismd_audio_render_t render_h);

ismd_result_t
audio_render_suspend(ismd_audio_render_t render_h);

ismd_result_t
audio_render_set_heartbeat_timer_clock_handle(ismd_clock_t *clock_h);

ismd_result_t
audio_render_set_sync_clock(ismd_audio_clk_mode_t clk_mode, ismd_clock_sync_t clock_sync_h, audio_independent_clock_recovery_mode_t clock_recovery_mode);

#endif

