
/*
* File Name: audio_core.h
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



/** @weakgroup ismd_audio ISMD Audio Data Types */
/** @ingroup ismd_audio */
/** @{ */

#ifndef _AUDIO_CORE_H_
#define _AUDIO_CORE_H_

#include <stdint.h>

#include "osal.h"
#include "pal.h"
#include "pal_interrupt.h"
#include "sven_devh.h"
#include <auto_eas/gen3_aud_io.h>
#include "ismd_core_protected.h"
#include "ismd_core.h"
#include "gdl_types.h"
#include "x86_cache.h"

#include "platform_config.h"
#include "platform_config_paths.h"
#include "thread_utils.h"
#include "ismd_clock_recovery.h"

#include "audio_device.h"
#include "audio_core_defs.h"
#include "ismd_audio_defs.h"
#include "audio_timing_control.h"
#include "audio_psm.h"
#include "audio_psm_defs.h"
#include "audio_render.h"
#include "audio_capture.h"
#include "gen3_audio.h"
#include "audio_hal_defs_pvt.h"

//Codec parameter configurations
#include "ismd_audio_ddplus.h"
#include "ismd_audio_ac3.h"
#include "ismd_audio_ac3_enc.h"
#include "ismd_audio_dts_enc.h"
#include "ismd_audio_aac_enc.h"
#include "ismd_audio_truehd.h"
#include "ismd_audio_dts.h"
#include "ismd_audio_dtshd.h"
#include "ismd_audio_dts_neo6.h"
#include "ismd_audio_aac.h"
#include "ismd_audio_ms10.h"
//These are some handy debug switches.
#define RENDER_IGNORE_TIMESTAMPS 0 // Needs to be 0 upon checkin

/** AutoAPI only supports up to 512 byte parameters.*/
#define MAX_AUTO_API_PARAM_SIZE 512

/** Max amount of characters for platform config entry.*/
#define MAX_PLAT_CONFIG_ENTRY_CHAR 96

extern int audio_debug_method;
extern int audio_debug_level;

#define USE_STREAM_METADATA false // Set to true to use embedded mixer metadata in DD+ and DTS-LBR streams.

extern os_devhandle_t *audio_devh[AUDIO_DEBUG_UNIT_MAX];

//initialized in the aud_dsp driver
extern os_devhandle_t  *aud_dsp0_devh;
extern os_devhandle_t  *aud_dsp1_devh;

extern ismd_event_t atc_render_resync_event;
extern ismd_event_t render_recovery_event;

/********************************************************************/

////////////////////////////////////////////////////////////////////////////////
// Shortcut macros for accessing core platform configuration properties
////////////////////////////////////////////////////////////////////////////////

#define ISMD_AUDIO_INT_PROPERTY(name, path, ret) ({                                   \
   config_result_t icipret = CONFIG_SUCCESS;                                    \
   config_ref_t icip_attr_id = ROOT_NODE;                                       \
                                                                                \
   icipret = config_node_find(ROOT_NODE,                                        \
                              path,                                             \
                              &icip_attr_id);                                   \
   if (icipret == CONFIG_SUCCESS) {                                             \
      icipret = config_get_int(icip_attr_id, name, &ret);                       \
   }                                                                            \
                                                                                \
   if (icipret != CONFIG_SUCCESS) {                                             \
   }                                                                            \
   icipret;                                                                     \
})

#define AUDIO_CONFIG_GET_RENDER_PREFILL(ret)       ISMD_AUDIO_INT_PROPERTY("render.pre_fill", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_I2S0_BIT_CLK_INVERT(ret)  ISMD_AUDIO_INT_PROPERTY("render.invert_i2s0_bit_clk", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_I2S1_BIT_CLK_INVERT(ret)  ISMD_AUDIO_INT_PROPERTY("render.invert_i2s1_bit_clk", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_I2SC0_BIT_CLK_DIRECTION(ret) ISMD_AUDIO_INT_PROPERTY("capture.i2s0_bitclk_direction", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_I2SC0_MSB_JUSTIFIED(ret)   ISMD_AUDIO_INT_PROPERTY("capture.i2s0_msb_justified", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_I2SC1_BIT_CLK_DIRECTION(ret) ISMD_AUDIO_INT_PROPERTY("capture.i2s1_bitclk_direction", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_I2SC1_MSB_JUSTIFIED(ret)   ISMD_AUDIO_INT_PROPERTY("capture.i2s1_msb_justified", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_SPDIF_CLOCK_UPDATE_RATE(ret)   ISMD_AUDIO_INT_PROPERTY("capture.spdif_clock_update_rate", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_CLOCK_RECOVERY_MODE(ret)   ISMD_AUDIO_INT_PROPERTY("clock_recovery_mode", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_DSP_SVEN_DEBUG_ENABLE(ret)  ISMD_AUDIO_INT_PROPERTY("enable_fw_sven_debug", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_ENABLE_TIMED_TRICK_MODES(ret)  ISMD_AUDIO_INT_PROPERTY("enable_timed_trick_modes", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_DEBUG_LEVEL(ret)          ISMD_AUDIO_INT_PROPERTY("debug_level", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_DEBUG_METHOD(ret)         ISMD_AUDIO_INT_PROPERTY("debug_method", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_DOLBY_DMIX_EHCO(ret)         ISMD_AUDIO_INT_PROPERTY("certification.dolby_downmix_echo", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_ATC_DISCONTINUITY(ret)    ISMD_AUDIO_INT_PROPERTY("discontinuity_threshold", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_INPUTS_TRUEHD_PORT_DEPTH(ret) ISMD_AUDIO_INT_PROPERTY("truehd_inport_port_depth", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_PER_OUTPUT_DELAY_BUFFER_SIZE(ret)     ISMD_AUDIO_INT_PROPERTY("smd_buffers_AUD_PER_OUTPUT_DELAY.buf_size", CONFIG_PATH_PLATFORM_MEMORY_LAYOUT, ret)
#define AUDIO_CONFIG_GET_DSP_DECODE(ret)          ISMD_AUDIO_INT_PROPERTY("dsp_decode", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_DSP_POST_PROCESSING(ret)          ISMD_AUDIO_INT_PROPERTY("dsp_post_processing", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_MAX_INPUTS_SUPPORTED(ret)          ISMD_AUDIO_INT_PROPERTY("max_num_inputs_per_processor", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_ASRC_SUPPORT(ret)          ISMD_AUDIO_INT_PROPERTY("asrc_support", CONFIG_PATH_SMD_AUDIO, ret)
#define AUDIO_CONFIG_GET_DSP_MEMORY_PATH_SETTING(ret)          ISMD_AUDIO_INT_PROPERTY("dsp_memory_path", CONFIG_PATH_SMD_AUDIO, ret)

/**This macro will get the size of a buffer if present in the memory layout specific to an instance of the 
   processor its asociated with. . 

   @param[in] entry_str :    The name of the entry as a string. i.e. "smd_buffers_AUD_TRANS_PROTECTION_"
   @param[in] processor_id : The processor id will be appended to the entry_str to get the buffer associated 
                             with the instance of the processor that is requesting the buffer avaialability.
                             i.e. if id = '0' then the entry would besmd_buffers_AUD_TRANS_PROTECTION_0
                             and is the buffer for this feature on audio processor 0 (first instance).
   @param[out] ret_size :    The size of the buffer if the entry is in the memory layout. 
*/
#define AUDIO_CONFIG_GET_MEMORY_LAYOUT_BUFFER_SIZE(entry_str, processor_id, ret_size) \
   do{ \
      char plat_entry[MAX_PLAT_CONFIG_ENTRY_CHAR]; \
      strncpy(plat_entry, entry_str, MAX_PLAT_CONFIG_ENTRY_CHAR); \
      sprintf(plat_entry, "%s%d", plat_entry, processor_id); \
      strncat(plat_entry, ".buf_size", (MAX_PLAT_CONFIG_ENTRY_CHAR - (strlen(plat_entry) +1))); \
      ISMD_AUDIO_INT_PROPERTY(plat_entry, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT, ret_size); \
   }while(0)

typedef uint64_t performance_time_t;

typedef struct {
   unsigned int       count;
   performance_time_t start;
   performance_time_t total;
   performance_time_t min;
   performance_time_t max;
} performance_counter_t;

void performance_counter_reset( performance_counter_t *counter );
void performance_counter_start( performance_counter_t *counter );
void performance_counter_stop( performance_counter_t *counter );
void performance_counter_print( performance_counter_t *counter, char *name );

/* Given an SMD buffer, get a pointer to the optional metadata structure in the payload of the buffer. */
#define GET_OPT_METADATA_PTR(buf_desc_ptr) ((opt_metadata_t *)((buf_desc_ptr)->virt.base + ((audio_buffer_attr_t *)((buf_desc_ptr)->attributes))->opt_metadata_offset))

/* Given an SMD buffer, determine if it has valid optional metadata in its payload. */
#define VALID_OPT_METADATA(buf_desc_ptr) ( ( ((audio_buffer_attr_t *)((buf_desc_ptr)->attributes))->opt_metadata_offset                                != OPT_METADATA_INVALID      ) && \
                                           ( ((audio_buffer_attr_t *)((buf_desc_ptr)->attributes))->opt_metadata_offset                                >= (buf_desc_ptr)->phys.level) && \
                                           ((((audio_buffer_attr_t *)((buf_desc_ptr)->attributes))->opt_metadata_offset + (int)sizeof(opt_metadata_t)) <= (buf_desc_ptr)->phys.size ) )

/* Given an SMD buffer and an offset value, assign the value to the opt_metadata_offset field of the buffer attributes. */
#define SET_OPT_METADATA_OFFSET(buf_desc_ptr,offset) (((audio_buffer_attr_t *)((buf_desc_ptr)->attributes))->opt_metadata_offset = (offset))


#define AUDIO_CORE_GET_PROCESSOR(x) (audio_get_processor((x)->processor_id))
#define AUDIO_CORE_GET_CHUNK_PERIOD(x) (audio_get_chunk_period((x)->processor_id))
#define AUDIO_CORE_IS_MS10(x) (audio_processor_is_ms10((x)->processor_id))
#define AUDIO_CORE_IS_VALID_MS10_INPUT(x, format) (AUDIO_CORE_IS_MS10((x)) && audio_core_is_valid_ms10_input_format((format)))


/**
Sets up audio subsystem resources, sets audio memory window. Should be called before any other function
to properly initialize the audio subsystem. Should happen at module init time.


@retval ISMD_SUCCESS : Audio successfully initialized.
@retval ISMD_ERROR_NO_RESOURCES : Could not perform basic initialization of audio subsystem.
*/
ismd_result_t
ismd_audio_core_initialize(void);

/**
Common cleanup among all audio units. Should happen and module unload time.

@retval ISMD_SUCCESS : Audio successfully de-initialized.
@retval ISMD_ERROR_NO_RESOURCES : Could not perform basic de-initialization of audio subsystem.
*/
ismd_result_t
ismd_audio_core_deinitialize(void);


/**
SVEN initialization function.

@retval ISMD_SUCCESS : Audio SVEN successfully de-initialized.
@retval ISMD_ERROR_NO_RESOURCES : Could not perform basic SVEN de-initialization of audio subsystem.
*/
ismd_result_t
ismd_audio_core_sven_init(void);

/**
SVEN deinit function.
*/
void
ismd_audio_core_sven_deinit(void);

/**
Calculate an audio data chunk size based on audio meta-data and time period in milliseconds.

@param[in] sample_size : Audio data sample size.
@param[in] sample_rate : Audio data sample rate.
@param[in] channel_count : Audio data channel_count.
@param[in] time_ms : Period of time in milliseconds.

@retval int : The chunk size in bytes.
*/
size_t
audio_core_calc_chunk_size(int sample_size, int sample_rate, int channel_count, int time_ms);

/**
Calculate number of samples are in a sample aligned chunk of data.

@param[in] sample_size : Audio data sample size.
@param[in] byte_count : Number of bytes of audio data.

@retval unsigned int : Number of samples.
*/
unsigned int
audio_core_bytes_to_samples(int sample_size, int channel_count, int byte_count);

/**
Calculate how much time in milliseconds a chunk of audio is based on audio meta-data 
and size of audio data in bytes.

@param[in] sample_size : Audio data sample size.
@param[in] sample_rate : Audio data sample rate.
@param[in] channel_count : Audio data channel_count.
@param[in] bytes : Amount of audio data in bytes. (Ensure this is sample alligned or this calculation will be incorrect.)

@retval int : The time represented by this audio data in milliseconds.
*/
unsigned int
audio_core_calc_time_ms(unsigned int sample_size, unsigned int sample_rate, unsigned int channel_count, unsigned int bytes);

/**
Calculate how many 90kHz ticks are represented given the byte count and audio stream
information. The expectation is that the bytes parameter is sample alligned. 

@param[in] sample_size : Audio data sample size.
@param[in] sample_rate : Audio data sample rate.
@param[in] channel_count : Audio data channel_count.
@param[in] bytes : Amount of audio data in bytes. (Ensure this is sample alligned or this calculation will loose precision.)

@retval unsigned int : The number of 90kHz ticks represented in the bytes given.
*/
uint64_t
audio_core_bytes_to_ticks(unsigned int sample_size, unsigned int sample_rate, unsigned int channel_count, uint64_t bytes);

int
audio_core_samples_to_bytes(int sample_size, int channel_count, int sample_count);

unsigned int
audio_core_get_post_atc_delay(void);

uint64_t
audio_core_normalize_sample_count(uint64_t in_sample_cnt, int norm_smpl_rate, int orig_sample_rate) ;

ismd_result_t
audio_core_get_render_base_numbers(int association_id, int norm_sample_rate, uint64_t *curr_smple_cnt, uint32_t *curr_lvl_in_smpls);

ismd_result_t
audio_core_get_render_sample_count(int hw_id, uint64_t *curr_smple_cnt);

ismd_result_t
audio_core_notify_event_top_half( const ismd_event_t notification_events[], ismd_audio_notification_t  event_type);

ismd_result_t
audio_core_notify_event( const ismd_event_t notification_events[], ismd_audio_notification_t  event_type);

inline bool
audio_core_validate_event_type( ismd_audio_notification_t event_type ) ;

const char
*audio_core_result_to_string(ismd_result_t result);

const char
*audio_core_gdl_result_to_string(gdl_ret_t result);

const char 
*audio_core_format_to_string(ismd_audio_format_t  format);

bool
audio_core_is_valid_metadata(int sample_rate, int sample_size, int channel_count);

bool
audio_core_is_valid_sample_rate(int sample_rate);

bool 
audio_core_is_valid_ms10_input_format(ismd_audio_format_t format);

bool
audio_core_is_ms10_ddc(ismd_audio_format_t format);

bool
audio_core_is_ms10_ddt(ismd_audio_format_t format);

int
audio_core_get_channel_cnt_from_config(int channel_config);

bool
audio_core_is_valid_ch_config(int channel_config);

void
audio_core_reset_buffer_metadata(audio_buffer_attr_t *metadata);

ismd_result_t 
audio_core_user_gain_to_coeff_index( int  user_gain, 
                                     int *coeff_index );

bool
audio_core_valid_channel(ismd_audio_channel_t channel);

void
audio_core_stream_position_copy(ismd_audio_stream_position_info_t *stream_pos_dst,  ismd_audio_stream_position_info_t *stream_pos_src);

void
audio_core_handle_underrun_tracking(
   int stream_h,
   ismd_event_t event, 
   int *underrun_count, 
   uint64_t *underrun_amount,  
   uint64_t drift_ticks);


bool copy_opt_metadata( ismd_buffer_descriptor_t *dst_smd_buf, 
                        ismd_buffer_descriptor_t *src_smd_buf );

ismd_result_t audio_core_check_tags(ismd_buffer_descriptor_t *buffer_desc,
                                             ismd_dev_t input_h);

ismd_result_t ismd_audio_buffer_dereference( ismd_buffer_handle_t buffer );

ismd_result_t ismd_audio_buffer_alloc_typed_direct( ismd_buffer_type_t         type,
                        size_t                     size, 
                        ismd_buffer_descriptor_t **buffer_descriptor );

void
audio_core_print_mix_config(ismd_audio_channel_mix_config_t *ch_mix_config);

bool
audio_core_supported_passthrough_format(ismd_audio_format_t format);

bool
audio_core_format_supports_22_05_and_11_025(ismd_audio_format_t format);

uint32_t 
audio_core_chunk_size_ticks(uint32_t chunk_size, int32_t sample_rate, int32_t sample_size, int32_t ch_count);

bool
audio_core_fast_path_enabled(void);

void
audio_core_flush_cache(void *addr, uint32_t size);


#endif

