
/*
* File Name: audio_apm_ms10_inputs.c
*/

/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "audio_apm_common.h"
#include "audio_apm_inputs_pvt.h"


void
audio_input_init_ms10dec_pipe(audio_psm_ms10dec_pipe_t* psm_ms10_pipe)
{
   psm_ms10_pipe->substream_id = -1;
   psm_ms10_pipe->dec_pipe_configured = false;
   psm_ms10_pipe->ddt_ddce_testmode = false;
   psm_ms10_pipe->dec_pipe_h = AUDIO_INVALID_HANDLE;
   psm_ms10_pipe->dec_stage_h = AUDIO_INVALID_HANDLE;
   psm_ms10_pipe->ddc_sync_stage_h = AUDIO_INVALID_HANDLE;
   psm_ms10_pipe->in_stage_h = AUDIO_INVALID_HANDLE;
   psm_ms10_pipe->out_stage_h = AUDIO_INVALID_HANDLE;
   psm_ms10_pipe->enc_stage_h = AUDIO_INVALID_HANDLE;
   psm_ms10_pipe->dual_ch_mix = ISMD_AUDIO_DDC_SINGLE_INPUT_DUAL_CH_MIX_DUP;
   OS_MEMSET(&(psm_ms10_pipe->enc_stage_params), 0, sizeof(audio_psm_stage_params_t));
   OS_MEMSET(&(psm_ms10_pipe->dec_stage_params), 0, sizeof(audio_psm_stage_params_t));
   OS_MEMSET(&(psm_ms10_pipe->ddc_sync_parames), 0, sizeof(audio_psm_stage_params_t));   
   OS_MEMSET(&(psm_ms10_pipe->dec_conn_mda), 0, sizeof(audio_psm_stage_connection_metadata_t));
}

static ismd_result_t
audio_pvt_input_ms10dec_alloc_psm_pipe(ismd_audio_input_wl_t* input_wl, audio_psm_ms10dec_pipe_t* psm_ms10_pipe)
{
   ismd_result_t result = ISMD_SUCCESS;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   // avoid compiler warning
   OS_ASSERT(input_wl != NULL);

   // Each input has its own ms10_dec pipeline, for those DDC dual mode, single input might be at most two dec pipeline
   if (psm_ms10_pipe->dec_pipe_h == AUDIO_INVALID_HANDLE) {
      //Allocate the PSM pipe for decode if it is DDC case (only DDC might already allocated)
      if ((result = audio_psm_pipe_alloc(PSM_PIPE_TYPE_DECODE, &(psm_ms10_pipe->dec_pipe_h))) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_pipe_alloc failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

static ismd_result_t
audio_pvt_input_ms10dec_release_psm_pipe(audio_psm_ms10dec_pipe_t* psm_ms10_pipe)
{
   ismd_result_t result = ISMD_SUCCESS;
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if (psm_ms10_pipe->dec_pipe_h != AUDIO_INVALID_HANDLE) {
      // release pipeline
      if ((result = audio_psm_pipe_free(psm_ms10_pipe->dec_pipe_h)) != ISMD_SUCCESS) {
         AUDIO_ERROR("audio_psm_pipe_free failed decoder pipe!", result , audio_devh[AUDIO_DEBUG_APM]);
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}


ismd_result_t
audio_pvt_input_ms10dec_setup(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_ms10dec_pipe_t* psm_ms10_pipe = NULL;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);
   
   /**
    * Make sure we have set the correct ms10_input_type before call this function. 
    * Because this function build both Main and Assoc audio pipelines. 
    */ 

   //Make sure we have the decoder installed. 
   if(audio_core_is_valid_ms10_input_format(input_wl->format)) {

      // if we mark the input as MAIN_AND_ASSOC, we are going to setup the associated audio pipeline
      if (input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_AND_ASSOC) {
         psm_ms10_pipe = &input_wl->psm_ms10_pipe_assoc;
      }
      else {
         psm_ms10_pipe = &input_wl->psm_ms10_pipe;
      }

      if ((result = audio_pvt_input_ms10dec_alloc_psm_pipe(input_wl, psm_ms10_pipe)) != ISMD_SUCCESS){
         AUDIO_ERROR("Adding psm pipe failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      else {
         // this is first time init ms10dec pipeline
         if((result = audio_pvt_input_ms10dec_pipe_add_stages(input_wl, psm_ms10_pipe)) != ISMD_SUCCESS){
            AUDIO_ERROR("Adding decoder stages failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else if((result = audio_pvt_input_ms10dec_pipe_connect_stages(input_wl, psm_ms10_pipe)) != ISMD_SUCCESS) {
            AUDIO_ERROR("Connecting decoder stages failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else if((result = audio_pvt_input_ms10dec_pipe_connect_input_output_queue(input_wl)) != ISMD_SUCCESS) {
            AUDIO_ERROR("Connecting input/output queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else if((result = audio_pvt_input_ms10dec_set_default_params(input_wl, psm_ms10_pipe)) != ISMD_SUCCESS) {
            AUDIO_ERROR("audio_decoder_set_default_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         if (result == ISMD_SUCCESS) {
            input_wl->audio_in_queue_h = input_wl->dec_in_queue_h;
            input_wl->disable_primary_output = false;

            psm_ms10_pipe->dec_stage_params.decoder.host.codec.algo = input_wl->format;
            psm_ms10_pipe->dec_stage_params.decoder.ms10dec_enabled = true;
            psm_ms10_pipe->dec_stage_params.decoder.ms10dec_ddc_sync = 0;

            if (input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_OR_ASSOC_ONLY) {
               // config main decoder 
               // TODO: need to check other input's status. 
               psm_ms10_pipe->dec_stage_params.decoder.ms10dec_main = true;               

               if((result = ismd_queue_connect_input(input_wl->audio_in_queue_h, (ismd_producer_func_t) audio_pvt_input_queue_callback, (void*)input_wl, ISMD_QUEUE_WATERMARK_NONE)) != ISMD_SUCCESS){
                  AUDIO_ERROR("queue_connect_input failed!", result, audio_devh[AUDIO_DEBUG_APM]);
               }
               
            }
            else {
               // if we find ms10_input_type is not MAIN_OR_ASSOC_ONLY, thus it is the associated audio. 
               // config assicated decoder
               psm_ms10_pipe->dec_stage_params.decoder.ms10dec_main = false;
            }

            //Decoder stage needs the ability to fire events. Associate this input's notification events with this stage.
            input_wl->psm_ms10_pipe.dec_conn_mda.input[0] = (int)input_wl->notification_events;
            
            if((result = audio_psm_stage_config_metadata(input_wl->psm_ms10_pipe.dec_pipe_h, input_wl->psm_ms10_pipe.dec_stage_h, &input_wl->psm_ms10_pipe.dec_conn_mda)) != ISMD_SUCCESS) {
               AUDIO_ERROR("psm_stage_config_metadat failed", result, audio_devh[AUDIO_DEBUG_APM]);
            }


            if (input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_OR_ASSOC_ONLY) {
               // disable passthrought port, until user call ismd_audio_input_set_as_primary() to enble it
               audio_psm_output_queue_disable(input_wl->psm_ms10_pipe.dec_pipe_h, input_wl->pass_atc_in_queue_h);
            }
         }
      }
   }
   
   //If the codec is not available check to see if its a format we can packetize and passthrough.
   else {
      OS_PRINT("\nSMD AUDIO: Warning: MS10 Decode of %s is not supported! Input data will be discarded! \n", audio_core_format_to_string(input_wl->format));        
   }
   
   AUDIO_EVENT(AUDIO_SVEN_LOG_CRITICAL, audio_devh[AUDIO_DEBUG_APM],
      SVEN_MODULE_EVENT_AUD_IO_APM_DECODER_SETUP,
      input_wl->processor_wl->handle_id,
      input_wl->format, 0, 0, 0, 0);
   
   
   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}

ismd_result_t
audio_pvt_input_ms10dec_teardown(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   // main pipeline shoud be always here. 
   if (input_wl->psm_ms10_pipe.dec_pipe_h != AUDIO_INVALID_HANDLE) {

      if ((result = audio_pvt_input_ms10dec_teardown_assoc_pipe(input_wl)) != ISMD_SUCCESS) {
         AUDIO_ERROR("teardown assoc_pipe failed decoder pipe!", result , audio_devh[AUDIO_DEBUG_APM]);
      }
      else if ((result = audio_pvt_input_ms10dec_release_psm_pipe(&input_wl->psm_ms10_pipe)) != ISMD_SUCCESS) {
         AUDIO_ERROR("audio_psm_pipe_free failed decoder pipe!", result , audio_devh[AUDIO_DEBUG_APM]);
      }
      else if((result = ismd_queue_disconnect_input(input_wl->dec_in_queue_h)) != ISMD_SUCCESS){
         AUDIO_ERROR("ismd_queue_disconnect_input failed for decoder input queue!", result , audio_devh[AUDIO_DEBUG_APM]);
      }
      else{
         input_wl->disable_primary_output = true;
         audio_input_init_ms10dec_pipe(&input_wl->psm_ms10_pipe);
         audio_input_init_ms10dec_pipe(&input_wl->psm_ms10_pipe_assoc);
      }
   }

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);

   return result;
}

ismd_result_t
audio_pvt_input_ms10dec_ddt_testmode_setup(ismd_audio_input_wl_t* input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_ms10dec_pipe_t* psm_ms10_pipe = &input_wl->psm_ms10_pipe;
   
   AUDIO_ENTER(audio_devh[AUDIO_DEBUG_APM]);

   if ((result = audio_psm_pipe_alloc(PSM_PIPE_TYPE_DECODE, &(psm_ms10_pipe->dec_pipe_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("psm_pipe_alloc failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_IN, 1, 1, &(psm_ms10_pipe->in_stage_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("psm_stage_add INPUT failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_ENCODE, 1, 1, &(psm_ms10_pipe->enc_stage_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("psm_stage_add DECODE failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_OUT, 1, 1, &(psm_ms10_pipe->out_stage_h))) != ISMD_SUCCESS){
      AUDIO_ERROR("psm_stage_add OUTPUT failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->in_stage_h, 0, psm_ms10_pipe->enc_stage_h, 0)) != ISMD_SUCCESS){
      AUDIO_ERROR("psm_stage_connect input_to_encode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->enc_stage_h, 0, psm_ms10_pipe->out_stage_h, 0)) != ISMD_SUCCESS){
      AUDIO_ERROR("psm_stage_connect ddt_encode_to_out failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if ((result = audio_psm_input_queue_add(psm_ms10_pipe->dec_pipe_h, input_wl->dec_in_queue_h, 0)) != ISMD_SUCCESS){
      AUDIO_ERROR("psm_input_queue_add dec_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }
   else if ((result = audio_psm_output_queue_add(psm_ms10_pipe->dec_pipe_h, input_wl->pass_atc_in_queue_h, 0)) != ISMD_SUCCESS){
      AUDIO_ERROR("audio_psm_output_queue_add atc_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }  
   else if ((result = ismd_queue_connect_input(input_wl->dec_in_queue_h, (ismd_producer_func_t) audio_pvt_input_queue_callback, (void*)input_wl, ISMD_QUEUE_WATERMARK_NONE)) != ISMD_SUCCESS){
      AUDIO_ERROR("queue_connect_input failed!", result, audio_devh[AUDIO_DEBUG_APM]);
   }

   input_wl->audio_in_queue_h = input_wl->dec_in_queue_h;
   input_wl->disable_primary_output = false;

   AUDIO_EXIT(audio_devh[AUDIO_DEBUG_APM]);
   
   return result;
}

ismd_result_t
audio_pvt_input_ms10dec_pipe_add_stages(ismd_audio_input_wl_t *input_wl, audio_psm_ms10dec_pipe_t* psm_ms10_pipe)
{
   ismd_result_t result = ISMD_SUCCESS;
   //NOTE: It is important to add the stages in the order they will be called by the PSM. This is a PSM restriction.
   int dec_out_count = 0;
   if (audio_core_is_ms10_ddc(input_wl->format)) {
      // DDC stages
     
      //Add the input stage always. 
      if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_IN, 1, 1, &(psm_ms10_pipe->in_stage_h))) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_add INPUT failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      // add DDC_DCV decoder stage
      if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_DECODE, 1, 2, &(psm_ms10_pipe->dec_stage_h))) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_add DECODE failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      //Add the ddc frame sync stage.
      if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_MS10_DDC_SYNC, 2, 2, &(psm_ms10_pipe->ddc_sync_stage_h))) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_add SYNC  failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      //Add the output stage.
      if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_OUT, 2, 2, &(psm_ms10_pipe->out_stage_h))) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_add OUTPUT failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      dec_out_count = 1;
      /* DDT stages */
      if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_IN, 1, 1, &(psm_ms10_pipe->in_stage_h))) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_add INPUT failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      if(input_wl->pass_pipe_enabled){
         // add Dolby Pulse decoder stage
         if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_DECODE, 1, 2, &(psm_ms10_pipe->dec_stage_h))) != ISMD_SUCCESS){
            AUDIO_ERROR("psm_stage_add DECODE failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         // add DDCO stage
         if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_ENCODE, 1, 1, &(psm_ms10_pipe->enc_stage_h))) != ISMD_SUCCESS){
            AUDIO_ERROR("psm_stage_add DECODE failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         dec_out_count++;
      }
      else {
         //DDT Associated stream does not need DDCE stage 
         // add Dolby Pulse decoder stage
         if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_DECODE, 1, 1, &(psm_ms10_pipe->dec_stage_h))) != ISMD_SUCCESS){
            AUDIO_ERROR("psm_stage_add DECODE failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
      //Add the output stage.
      if ((result = audio_psm_stage_add(psm_ms10_pipe->dec_pipe_h, PSM_TASK_OUT, dec_out_count, dec_out_count, &(psm_ms10_pipe->out_stage_h))) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_add OUTPUT failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   
   return result;
}


ismd_result_t
audio_pvt_input_ms10dec_pipe_connect_stages(ismd_audio_input_wl_t *input_wl, audio_psm_ms10dec_pipe_t* psm_ms10_pipe)
{
   ismd_result_t result = ISMD_SUCCESS;

   if (audio_core_is_ms10_ddc(input_wl->format)) {
      /* connect DDC stages */

      // connect in_stage0 --> main_dec0
      if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->in_stage_h, 0, psm_ms10_pipe->dec_stage_h, 0)) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_connect in_stage0 --> main_dec0 failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      // connect main_dec0 --> frame_sync0
      if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->dec_stage_h, 0, psm_ms10_pipe->ddc_sync_stage_h, 0)) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_connect main_dec0 --> frame_sync0 failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      // connect main_dec1 --> frame_sync2
      if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->dec_stage_h, 1, psm_ms10_pipe->ddc_sync_stage_h, 1)) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_connect main_dec1 --> frame_sync2 failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      // connect frame_sync0 --> output0
      if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->ddc_sync_stage_h, 0, psm_ms10_pipe->out_stage_h, 0)) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_connect frame_sync0 --> output0 failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      // connect frame_sync1 --> output1
      if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->ddc_sync_stage_h, 1, psm_ms10_pipe->out_stage_h, 1)) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_connect frame_sync1 --> output1 failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
   }
   else {
      /* connect DDT stages */

      // connect in_stage0 --> dec0
      if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->in_stage_h, 0, psm_ms10_pipe->dec_stage_h, 0)) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_connect input_to_decode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      //dec0 --> out0
      if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->dec_stage_h, 0, psm_ms10_pipe->out_stage_h, 0)) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_stage_connect ddt_decode_to_ddt_pp failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      if (input_wl->pass_pipe_enabled) {
      // Main stream: dec0 --> enc0
         if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->dec_stage_h, 1, psm_ms10_pipe->enc_stage_h, 0)) != ISMD_SUCCESS){
            AUDIO_ERROR("psm_stage_connect ddt_decode_to_ddt_pp failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         // connect enc0 --> out_stage1
         if ((result = audio_psm_stage_connect(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->enc_stage_h, 0, psm_ms10_pipe->out_stage_h, 1)) != ISMD_SUCCESS){
            AUDIO_ERROR("psm_stage_connect decode_to_time_scale failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }

   return result;
}

ismd_result_t
audio_pvt_input_ms10dec_pipe_connect_input_output_queue(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   audio_psm_ms10dec_pipe_t* psm_ms10_pipe = &input_wl->psm_ms10_pipe;

   /* connect input/output queue */
   if (audio_core_is_ms10_ddc(input_wl->format)) {

      if (input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_AND_ASSOC) {
         psm_ms10_pipe = &input_wl->psm_ms10_pipe_assoc;
         
         // DEC input: dec_in_queue_h 
         if ((result = audio_psm_input_queue_add(psm_ms10_pipe->dec_pipe_h, input_wl->assoc_ms10dec_in_queue_h, 0)) != ISMD_SUCCESS){
            AUDIO_ERROR("psm_input_queue_add dec_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         // DEC PCM output: atc_in_queue_h
         else if ((result = audio_psm_output_queue_add(psm_ms10_pipe->dec_pipe_h, input_wl->assoc_atc_in_queue_h, 0)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_output_queue_add atc_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         } 
      }
      else {
         // DEC input: dec_in_queue_h 
         if ((result = audio_psm_input_queue_add(psm_ms10_pipe->dec_pipe_h, input_wl->dec_in_queue_h, 0)) != ISMD_SUCCESS){
            AUDIO_ERROR("psm_input_queue_add dec_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         // DEC PCM output: atc_in_queue_h
         else if ((result = audio_psm_output_queue_add(psm_ms10_pipe->dec_pipe_h, input_wl->atc_in_queue_h, 0)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_output_queue_add atc_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         } 
         // Main DEC DD output: pass_atc_in_queue_h
         else if ((result = audio_psm_output_queue_add(psm_ms10_pipe->dec_pipe_h, input_wl->pass_atc_in_queue_h, 1)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_output_queue_add atc_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
   }
   else {
      // for DDT path
      // DEC input: dec_in_queue_h 
      if ((result = audio_psm_input_queue_add(psm_ms10_pipe->dec_pipe_h, input_wl->dec_in_queue_h, 0)) != ISMD_SUCCESS){
         AUDIO_ERROR("psm_input_queue_add dec_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      // DEC PCM output: atc_in_queue_h
      else if ((result = audio_psm_output_queue_add(psm_ms10_pipe->dec_pipe_h, input_wl->atc_in_queue_h, 0)) != ISMD_SUCCESS){
         AUDIO_ERROR("audio_psm_output_queue_add atc_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      //connect pass atc queue for DDT main stream
      if (input_wl->pass_pipe_enabled){ 
         // Enc output :  pass_atc_in_queue_h
         if ((result = audio_psm_output_queue_add(psm_ms10_pipe->dec_pipe_h, input_wl->pass_atc_in_queue_h, 1)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_output_queue_add atc_in_queue failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }  
   }

   return result;
}

ismd_result_t
audio_pvt_input_ms10dec_setup_assoc_pipe( ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = input_wl->processor_wl;
   bool is_encoded_data = false;

   if(AUDIO_CORE_IS_MS10(input_wl) && audio_core_is_ms10_ddc(input_wl->format) && input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_AND_ASSOC) {

      if ((result = audio_pvt_input_ms10dec_setup(input_wl)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Error adding ms10 assoc pipeline!",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
      
      else if ((result = audio_pvt_input_ms10dec_configure_assoc_pipe(input_wl)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Error configure ms10 assoc pipeline!",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
      
      else if ((result = audio_pvt_input_start_ms10dec_pipe(input_wl, &input_wl->psm_ms10_pipe_assoc)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Error starting ms10 assoc pipeline!",  result, audio_devh[AUDIO_DEBUG_APM]);
      }
      
      else if((result = audio_timing_control_add_stream(wl->atc_h, input_wl->is_timed_stream, is_encoded_data, input_wl->assoc_atc_in_queue_h, 
         input_wl->assoc_atc_out_queue_h, input_wl->notification_events, input_wl->smd_dev_h, &(input_wl->assoc_atc_stream_h))) != ISMD_SUCCESS) 
      {
         AUDIO_ERROR("Error adding assoc ATC input!",  result, audio_devh[AUDIO_DEBUG_APM]);
      }

      // Here we want to sync up the timing control stream of the new atc stream with the primary stream information. 
      // This is because at any given time the associated stream can be added and removed,
      // In the case of the primary we are only going to send the rebase
      // info down again since that is the only peice of information that is out of sync when its disabled. 
      else if ((result = audio_pvt_input_primary_resync_atc_stream(input_wl, input_wl->assoc_atc_stream_h)) != ISMD_SUCCESS) {
         AUDIO_ERROR("Error sync assoc ATC input!",  result, audio_devh[AUDIO_DEBUG_APM]);
      }

      /*If the post ATC pipe is already running, need to attempt to add the input, if already added, will return success.*/
      if(input_wl->processor_wl->psm_pa_pipe.pipe_configured) {
         result = audio_processor_psm_pipe_add_input(input_wl, input_wl->mixer_input_index, &input_wl->processor_wl->output_configs);
      }

   }
   else {
      OS_INFO("\nSMD AUDIO ERROR: setup associated audio pipeline failed!\n");
   }
   
   return result;
}

ismd_result_t
audio_pvt_input_ms10dec_config_main_assoc_dependence(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_input_wl_t * sec_input = NULL;
   ismd_audio_input_wl_t * pri_input = NULL;
   int ddc_sync_stage_addr = 0;

   if(AUDIO_CORE_IS_MS10(input_wl) && audio_core_is_ms10_ddc(input_wl->format)) {

      //Get the primary and secondary input from the processor context associated with this input.
      pri_input = input_wl->processor_wl->primary_input_wl;
      sec_input = input_wl->processor_wl->secondary_input_wl;

      // only avaiable before pipe configured.
      if (input_wl->psm_ms10_pipe.dec_pipe_configured) {
         result = ISMD_ERROR_INVALID_REQUEST;
      }

      if (input_wl->pass_through_mode == ISMD_AUDIO_PASS_THROUGH_MODE_DIRECT) {
         input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.config.ddc_params.packetize = false;
      }

      if (input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_AND_ASSOC) {
         // what's ever associated or main audio who go first here, will setup all. 
         audio_psm_pipe_get_stage_phys_address( input_wl->psm_ms10_pipe.ddc_sync_stage_h, &ddc_sync_stage_addr);
         input_wl->psm_ms10_pipe.dec_stage_params.decoder.ms10dec_ddc_sync = ddc_sync_stage_addr;
         input_wl->psm_ms10_pipe.ddc_sync_parames.ms10_ddc_sync.main_ddc_sync = ddc_sync_stage_addr;
         input_wl->psm_ms10_pipe_assoc.dec_stage_params.decoder.ms10dec_ddc_sync = ddc_sync_stage_addr;
         input_wl->psm_ms10_pipe_assoc.ddc_sync_parames.ms10_ddc_sync.main_ddc_sync = ddc_sync_stage_addr;

         // enable frame sync
         input_wl->psm_ms10_pipe.ddc_sync_parames.ms10_ddc_sync.sync_enable = true;
         input_wl->psm_ms10_pipe_assoc.dec_stage_params.decoder.host.codec.config.ddc_params.substream_id = input_wl->psm_ms10_pipe_assoc.substream_id;
      }
      // the input is primary input
      else if (input_wl->input_type == AUDIO_INPUT_TYPE_PRIMARY){
         audio_psm_pipe_get_stage_phys_address( input_wl->psm_ms10_pipe.ddc_sync_stage_h, &ddc_sync_stage_addr);         
         input_wl->psm_ms10_pipe.dec_stage_params.decoder.ms10dec_ddc_sync = ddc_sync_stage_addr;
         input_wl->psm_ms10_pipe.ddc_sync_parames.ms10_ddc_sync.main_ddc_sync = ddc_sync_stage_addr;
         input_wl->psm_ms10_pipe.dec_stage_params.decoder.ms10dec_main = true;
         
         // check secondary input existing
         if (sec_input != NULL && AUDIO_CORE_IS_MS10(sec_input) && audio_core_is_ms10_ddc(sec_input->format)) {
            // we are under dual decoding mode. Enable sync logic now.
            input_wl->psm_ms10_pipe.ddc_sync_parames.ms10_ddc_sync.sync_enable = true;
            sec_input->psm_ms10_pipe.dec_stage_params.decoder.ms10dec_ddc_sync = ddc_sync_stage_addr;
            sec_input->psm_ms10_pipe.ddc_sync_parames.ms10_ddc_sync.main_ddc_sync = ddc_sync_stage_addr;
            sec_input->psm_ms10_pipe.dec_stage_params.decoder.ms10dec_main = false;
         }
      }
      // the input is not primary input, but secondary input. MS10 DDC primary input already existed. 
      else if (pri_input != NULL && input_wl->input_type == AUDIO_INPUT_TYPE_SECONDARY) {
         // This is to handle the case sec_input was first set to playback before primray. 
         // Primary input is already added, it is a dual decoding mode.
         audio_psm_pipe_get_stage_phys_address( pri_input->psm_ms10_pipe.ddc_sync_stage_h, &ddc_sync_stage_addr);
         input_wl->psm_ms10_pipe.dec_stage_params.decoder.ms10dec_ddc_sync = ddc_sync_stage_addr;
         input_wl->psm_ms10_pipe.ddc_sync_parames.ms10_ddc_sync.main_ddc_sync = ddc_sync_stage_addr;
         input_wl->psm_ms10_pipe.dec_stage_params.decoder.ms10dec_main = false;
         // enable sync on pri_input sync control stage
         pri_input->psm_ms10_pipe.ddc_sync_parames.ms10_ddc_sync.sync_enable = true;
      }
      else { // others case is non-dual decoding. 
         input_wl->psm_ms10_pipe.dec_stage_params.decoder.ms10dec_ddc_sync = 0;
         input_wl->psm_ms10_pipe.ddc_sync_parames.ms10_ddc_sync.main_ddc_sync = 0;
         input_wl->psm_ms10_pipe_assoc.dec_stage_params.decoder.ms10dec_ddc_sync = 0;
         input_wl->psm_ms10_pipe_assoc.ddc_sync_parames.ms10_ddc_sync.main_ddc_sync = 0;
      }
   }

   return result;
}


ismd_result_t
audio_pvt_input_ms10dec_teardown_assoc_pipe( ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = input_wl->processor_wl;

   if(AUDIO_CORE_IS_MS10(input_wl) && audio_core_is_ms10_ddc(input_wl->format)) {

      if ((result = audio_pvt_input_ms10dec_release_psm_pipe(&input_wl->psm_ms10_pipe_assoc)) != ISMD_SUCCESS) {
         AUDIO_ERROR("audio_psm_pipe_free failed decoder pipe!", result , audio_devh[AUDIO_DEBUG_APM]);
      }

      if(input_wl->assoc_atc_stream_h != AUDIO_INVALID_HANDLE) {
         if((result = audio_timing_control_remove_stream(wl->atc_h, input_wl->assoc_atc_stream_h)) != ISMD_SUCCESS) {
            AUDIO_ERROR("Error adding assoc ATC input!",  result, audio_devh[AUDIO_DEBUG_APM]);
         }
         else {
            // mark as invalid, since remove input handle will also check this handle
            input_wl->assoc_atc_stream_h = AUDIO_INVALID_HANDLE;
         }

         if(input_wl->output_buffer != NULL) {
            if ( input_wl->pass_buf_has_ref && (input_wl->pass_queue_has_buf == false) && (input_wl->primary_queue_has_buf == false)) { 
               ismd_audio_buffer_dereference(input_wl->output_buffer->unique_id);
            }
            
            input_wl->pass_queue_has_buf = false;
            input_wl->pass_buf_has_ref = false;
         }
      }
   }
   
   return result;
}


ismd_result_t
audio_pvt_input_start_ms10dec_pipe(ismd_audio_input_wl_t *input_wl, audio_psm_ms10dec_pipe_t* psm_ms10_pipe)
{
   ismd_result_t result = ISMD_SUCCESS;

   if ((psm_ms10_pipe->dec_pipe_h != AUDIO_INVALID_HANDLE) && (!psm_ms10_pipe->dec_pipe_configured)){

      if ((result = audio_pvt_input_ms10dec_config_main_assoc_dependence(input_wl)) != ISMD_SUCCESS) {
         AUDIO_ERROR("audio_pvt_input_ms10dec_config_main_assoc_dependence failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      if(psm_ms10_pipe->dec_stage_h != AUDIO_INVALID_HANDLE) {
         if((result = audio_psm_stage_config(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->dec_stage_h, &psm_ms10_pipe->dec_stage_params)) != ISMD_SUCCESS){
            AUDIO_ERROR("audio_psm_stage_config decode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }
	  
      if (audio_core_is_ms10_ddc(input_wl->format)) {
         // DDC only
         if (psm_ms10_pipe->ddc_sync_stage_h != AUDIO_INVALID_HANDLE) {
            if((result = audio_psm_stage_config(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->ddc_sync_stage_h, &psm_ms10_pipe->ddc_sync_parames)) != ISMD_SUCCESS){
               AUDIO_ERROR("audio_psm_stage_config decode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }
      else {
         // DDT only
         if(psm_ms10_pipe->enc_stage_h != AUDIO_INVALID_HANDLE) {
            if ((result = audio_psm_stage_config(psm_ms10_pipe->dec_pipe_h, psm_ms10_pipe->enc_stage_h, &psm_ms10_pipe->enc_stage_params)) != ISMD_SUCCESS){
               AUDIO_ERROR("audio_psm_stage_config encode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
            }
         }
      }

      if((result =audio_psm_pipe_start(psm_ms10_pipe->dec_pipe_h)) != ISMD_SUCCESS){
          AUDIO_ERROR("audio_psm_pipe_start decode failed!", result, audio_devh[AUDIO_DEBUG_APM]);
      }
      else{
         psm_ms10_pipe->dec_pipe_configured = true;
      }
   }
   return result;
}

ismd_result_t
audio_pvt_input_ms10dec_set_default_params(ismd_audio_input_wl_t *input_wl, audio_psm_ms10dec_pipe_t* psm_ms10_pipe)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_audio_format_t format = input_wl->format;

   switch(format) {

      case ISMD_AUDIO_MEDIA_FMT_DD:
      case ISMD_AUDIO_MEDIA_FMT_DD_PLUS:
         if((result = audio_ms10_ddc_set_default_decode_params(&(psm_ms10_pipe->dec_stage_params.decoder))) != ISMD_SUCCESS) {
            AUDIO_ERROR("dd_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         break;

      case ISMD_AUDIO_MEDIA_FMT_AAC :
      case ISMD_AUDIO_MEDIA_FMT_AAC_LOAS:

         OS_MEMSET((char *)(&(psm_ms10_pipe->dec_stage_params.decoder)), 0, sizeof(audio_psm_stage_params_t));

         if(format == ISMD_AUDIO_MEDIA_FMT_AAC){
            psm_ms10_pipe->dec_stage_params.decoder.host.codec.config.ddt_params.ddt_aac.bsformat = ISMD_AUDIO_MS10_DOLBY_PULSE_BSFORMAT_ADTS;
         }
         else if (format == ISMD_AUDIO_MEDIA_FMT_AAC_LOAS){
            psm_ms10_pipe->dec_stage_params.decoder.host.codec.config.ddt_params.ddt_aac.bsformat = ISMD_AUDIO_MS10_DOLBY_PULSE_BSFORMAT_LOAS;
         }

         if((result = audio_ms10_ddt_set_default_decode_params(&(psm_ms10_pipe->dec_stage_params.decoder))) != ISMD_SUCCESS) {
            AUDIO_ERROR("aac_set_default_decode_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }

         if ((result = audio_ddt_ac3_enc_set_default_params(&psm_ms10_pipe->enc_stage_params.decoder)) != ISMD_SUCCESS) {
            AUDIO_ERROR("aac_set_default_enc_params failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
         break;
      default:
         result = ISMD_ERROR_INVALID_PARAMETER;
         AUDIO_ERROR("Invalid codec!", result, audio_devh[AUDIO_DEBUG_APM]);
         break;
   }

   return result;
}

ismd_result_t
audio_pvt_input_ms10dec_configure_assoc_pipe(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   if(AUDIO_CORE_IS_MS10(input_wl) && audio_core_is_ms10_ddc(input_wl->format)
      && input_wl->ms10_input_type == AUDIO_INPUT_MS10_MAIN_AND_ASSOC) {

      audio_psm_decode_ddc_config_params_t* main_ddc_param = &input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.config.ddc_params;
      audio_psm_decode_ddc_config_params_t* assoc_ddc_param = &input_wl->psm_ms10_pipe_assoc.dec_stage_params.decoder.host.codec.config.ddc_params;
      //For ddc single input dual decodeing, copy main decode config parameters to assoc decoder
      assoc_ddc_param->dynrng_mode = main_ddc_param->dynrng_mode;
      assoc_ddc_param->karac = main_ddc_param->karac;
      assoc_ddc_param->stereo_mode = main_ddc_param->stereo_mode;
      assoc_ddc_param->mono_rep = main_ddc_param->mono_rep;
      assoc_ddc_param->pcm_scale = main_ddc_param->pcm_scale;
      assoc_ddc_param->dyn_cut_hi = main_ddc_param->dyn_cut_hi;
      assoc_ddc_param->dyn_boost_lo = main_ddc_param->dyn_boost_lo;
      assoc_ddc_param->quitonerr = main_ddc_param->quitonerr;
      assoc_ddc_param->framestart = main_ddc_param->framestart;
      assoc_ddc_param->frameend = main_ddc_param->frameend;
   }

   return result;
}

ismd_result_t
audio_pvt_input_ms10_setup_passthrough_pipe( ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_audio_processor_context_t *wl = input_wl->processor_wl;

   if(AUDIO_CORE_IS_VALID_MS10_INPUT(input_wl, input_wl->format)) {

      /*MS10 does not support PCM, so add ATC stream as no encoded data.*/
      if((result = audio_timing_control_add_stream(wl->atc_h, input_wl->is_timed_stream, false, input_wl->pass_atc_in_queue_h,
         input_wl->pass_atc_out_queue_h, input_wl->notification_events, input_wl->smd_dev_h, &(input_wl->pass_atc_stream_h))) != ISMD_SUCCESS) 
      {
         AUDIO_ERROR("Error adding ATC input!", result, audio_devh[AUDIO_DEBUG_APM]);
      }

      if((result == ISMD_SUCCESS) && (!input_wl->is_sw_input)){
         if((result = audio_timing_control_set_fixed_delay(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h, input_wl->fixed_back_end_delay_chunk)) != ISMD_SUCCESS){
            AUDIO_ERROR("Error setting fixed delay for phy passthrough input!",  result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      /* Alloc a PSM pipe for the passthrough case. */
      if((result == ISMD_SUCCESS) && wl->psm_pass_pipe.pipe_h == AUDIO_INVALID_HANDLE){ 

         if((result = audio_psm_pipe_alloc(PSM_PIPE_TYPE_POST_ATC, &(wl->psm_pass_pipe.pipe_h))) != ISMD_SUCCESS) {
            AUDIO_ERROR("audio_psm_pipe_alloc PSM pass-through pipe failed!", result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if(result == ISMD_SUCCESS) {
         input_wl->pass_pipe_enabled = true;

         /* setup packetizer if not MS10 */
         if (AUDIO_CORE_IS_VALID_MS10_INPUT(input_wl, input_wl->format)) {

            if (audio_core_is_ms10_ddc(input_wl->format)) {
               input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.config.ddc_params.main_audio_dd_enabled = true;
            }
            else {
               audio_psm_decode_config_params_t dec_params_value;
               audio_psm_decode_config_params_t enc_params_value;
 
               input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.config.ddt_params.main_audio_ddt_enabled = true;

               dec_params_value = input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.config;
               enc_params_value = input_wl->psm_ms10_pipe.enc_stage_params.decoder.host.codec.config;

               audio_pvt_input_ms10dec_teardown(input_wl); 

               // restore usr codec configration.
               input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.config = dec_params_value;
               input_wl->psm_ms10_pipe.enc_stage_params.decoder.host.codec.config = enc_params_value;

               // MS10 mode do not need packetizer 
               if (input_wl->psm_ms10_pipe.enc_stage_params.decoder.host.codec.config.ddt_params.ddt_ac3_enc.testmodeon){
                  input_wl->psm_ms10_pipe.ddt_ddce_testmode = true;

                  audio_ddt_ac3_enc_set_default_params(&input_wl->psm_ms10_pipe.enc_stage_params.decoder);
                  
                  input_wl->psm_ms10_pipe.enc_stage_params.decoder.host.codec.config.ddt_params.ddt_ac3_enc.testmodeon = true;

                  if ((result = audio_pvt_input_ms10dec_ddt_testmode_setup(input_wl)) != ISMD_SUCCESS) {
                     AUDIO_ERROR("audio ms10 ddt ddec testmode setup failed!", result, audio_devh[AUDIO_DEBUG_APM]);
                  }
               }
               else {
                  if ((result = audio_pvt_input_ms10dec_setup(input_wl))!= ISMD_SUCCESS) {
                     AUDIO_ERROR( "audio_pvt_input_ms10dec_setup failed!", result, audio_devh[AUDIO_DEBUG_APM]);
                  }

                  input_wl->psm_ms10_pipe.dec_stage_params.decoder.host.codec.config = dec_params_value;
                  input_wl->psm_ms10_pipe.enc_stage_params.decoder.host.codec.config = enc_params_value;

               }
            }
            if(input_wl->format == ISMD_AUDIO_MEDIA_FMT_AAC_LOAS) {
               input_wl->processor_wl->primary_input_format = ISMD_AUDIO_MEDIA_FMT_AAC_LOAS;
            }
            
            // enable passthrough output
            audio_psm_output_queue_enable(input_wl->psm_ms10_pipe.dec_pipe_h, input_wl->pass_atc_in_queue_h);
         }
         
         input_wl->has_passthr_stream = true;
      }
   }
   else {
      result = ISMD_ERROR_INVALID_REQUEST;
   }
   
   return result;
}


ismd_result_t
audio_pvt_input_ms10_passthrough_teardown(ismd_audio_input_wl_t *input_wl)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(AUDIO_CORE_IS_VALID_MS10_INPUT(input_wl, input_wl->format)) {
   
      if(input_wl->audio_in_passthrough_queue_h != AUDIO_INVALID_HANDLE){
         if((result = ismd_queue_disconnect_input(input_wl->audio_in_passthrough_queue_h)) != ISMD_SUCCESS){
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"ismd_queue_disconnect_input failed packetizer pipe!", audio_devh[AUDIO_DEBUG_APM]);
         }
         else if((result = ismd_queue_disconnect_output(input_wl->audio_in_passthrough_queue_h)) != ISMD_SUCCESS){
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"ismd_queue_disconnect_output failed packetizer pipe!", audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      if(input_wl->pass_atc_stream_h != AUDIO_INVALID_HANDLE){
         if((result = audio_timing_control_remove_stream(input_wl->processor_wl->atc_h, input_wl->pass_atc_stream_h)) != ISMD_SUCCESS) {
            AUDIO_ERROR("atc_remove_stream_failed",  result, audio_devh[AUDIO_DEBUG_APM]);
         }
      }

      /* Need to stop and free the post ATC passthrough pipe.  */
      if(input_wl->processor_wl->psm_pass_pipe.pipe_h != AUDIO_INVALID_HANDLE){
         if (audio_psm_pipe_free(input_wl->processor_wl->psm_pass_pipe.pipe_h) != ISMD_SUCCESS){
            AUDIO_WARN(AUDIO_SVEN_LOG_CRITICAL,"audio_psm_pipe_free failed!\n", audio_devh[AUDIO_DEBUG_APM]);
         } 
      }

      /* Re-init post ATC pass pipe wl for next use*/
      audio_processor_init_psm_pipe_wl(&(input_wl->processor_wl->psm_pass_pipe));

      /*Reinit input state variables for the passthrough stream*/
      input_wl->has_passthr_stream = false;
      input_wl->pass_pipe_enabled = false;
      input_wl->pass_atc_stream_h = AUDIO_INVALID_HANDLE;
      input_wl->pass_needs_basetime = false;
      input_wl->pass_needs_clock = false;
      input_wl->audio_in_passthrough_queue_h = AUDIO_INVALID_HANDLE;
      
      //Cleanup any remaining buffers at the input. 
      ismd_queue_flush(input_wl->pass_atc_in_queue_h);
      ismd_queue_flush(input_wl->pass_psm_pipe_in_queue_h);

      //TODO: Need to see about this logic, idea is to make sure we dont have an extra reference hanging around. 
      if(input_wl->output_buffer != NULL) {
         if ( input_wl->pass_buf_has_ref && (input_wl->pass_queue_has_buf == false) && (input_wl->primary_queue_has_buf == false)) { 
            ismd_audio_buffer_dereference(input_wl->output_buffer->unique_id);
         }
         
         input_wl->pass_queue_has_buf = false;
         input_wl->pass_buf_has_ref = false;
      }
   }
   else{
      result = ISMD_ERROR_INVALID_REQUEST;
   }
   
   return result;               
}


