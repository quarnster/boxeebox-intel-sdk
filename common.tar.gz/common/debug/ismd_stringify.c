/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "ismd_global_defs.h"
#include "osal_io.h"
#include "ismd_stringify.h"

/* Add any new error codes here */
const char *stringify_return_codes[ISMD_LAST_NORMAL_ERROR_MARKER+1] = {
   "ISMD_SUCCESS",                           // 0
   "ISMD_ERROR_FEATURE_NOT_IMPLEMENTED",     // 1
   "ISMD_ERROR_FEATURE_NOT_SUPPORTED",       // 2
   "ISMD_ERROR_INVALID_VERBOSITY_LEVEL",     // 3
   "ISMD_ERROR_INVALID_PARAMETER",           // 4
   "ISMD_ERROR_INVALID_HANDLE",              // 5
   "ISMD_ERROR_NO_RESOURCES",                // 6
   "ISMD_ERROR_INVALID_RESOURCE",            // 7
   "ISMD_ERROR_INVALID_QUEUE_TYPE",          // 8
   "ISMD_ERROR_NO_DATA_AVAILABLE",           // 9
   
   "ISMD_ERROR_NO_SPACE_AVAILABLE",          // 10
   "ISMD_ERROR_TIMEOUT",                     // 11
   "ISMD_ERROR_EVENT_BUSY",                  // 12
   "ISMD_ERROR_OBJECT_DELETED",              // 13

   "<unknown>",                              // 14
   "<unknown>",                              // 15
   "<unknown>",                              // 16
   
   "ISMD_ERROR_ALREADY_INITIALIZED",         // 17
   "ISMD_ERROR_IOCTL_FAILED",                // 18
   "ISMD_ERROR_INVALID_BUFFER_TYPE",         // 19
   "ISMD_ERROR_INVALID_FRAME_TYPE",          // 20
   "ISMD_ERROR_QUEUE_BUSY",                  // 21
   "ISMD_ERROR_NOT_FOUND",                   // 22
   "ISMD_ERROR_OPERATION_FAILED",            // 23
   "ISMD_ERROR_PORT_BUSY",                   // 24
   
   "ISMD_ERROR_NULL_POINTER",                // 25
   "ISMD_ERROR_INVALID_REQUEST",             // 26
   "ISMD_ERROR_OUT_OF_RANGE",                // 27
   "ISMD_ERROR_NOT_DONE"                     // 28

   //"ISMD_ERROR_UNSPECIFIED"                  // 99
};

/* This is a helper function to take a numeric ismd_result_t and return
the string equivalent*/
const char * ismd_stringify_error ( ismd_result_t code ) 
{
   if ( (int)code >= ISMD_SUCCESS && code < ISMD_LAST_NORMAL_ERROR_MARKER ) {
      return ( (stringify_return_codes[code]) );
   }
   else if ( ISMD_ERROR_UNSPECIFIED == code ) {
     return "ISMD_ERROR_UNSPECIFIED";
   }
   else {
     return "<Error code out of range>";
   }
}

