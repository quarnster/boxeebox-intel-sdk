#!/bin/bash

########################################################################
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#    Intel Corporation
#    2200 Mission College Blvd.
#    Santa Clara, CA  97052
########################################################################

#Build alsa-lib and aplay

# build alsa library
echo "Now build alsa-lib-1.0.23"
tar xjf alsa-lib-1.0.23.tar.bz2 && \
patch -p0 < alsa-lib-pcm-rate-stuck-fix.patch && \
cd alsa-lib-1.0.23 && \
CFLAGS="-I$BUILD_DEST/include" ./configure --host=$TARGET --build=$HOST   \
          --disable-python && \
make && \
DESTDIR=$BUILD_DEST make install || exit 1
$STRIP $BUILD_DEST/usr/lib/libasound.so.2.0.0
cd ..

# build alsa utils
tar xjf alsa-utils-1.0.23.tar.bz2 && \
cd alsa-utils-1.0.23 && \
./configure --disable-nls \
  	--host=$TARGET \
	--build=$HOST \
	--with-alsa-prefix=$BUILD_DEST/usr/lib/ \
	--with-alsa-inc-prefix=$BUILD_DEST/usr/include \
        --with-curses=ncurses \
       CFLAGS="-I$BUILD_DEST/include -I$BUILD_DEST/include/ncurses/ -L$BUILD_DEST/lib" && \
make -C aplay && \
DESTDIR=$BUILD_DEST make -C aplay install || exit 1
$STRIP $BUILD_DEST/usr/bin/aplay
