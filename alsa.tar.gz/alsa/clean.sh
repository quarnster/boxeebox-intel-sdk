#!/bin/sh

########################################################################
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#    Intel Corporation
#    2200 Mission College Blvd.
#    Santa Clara, CA  97052
########################################################################

if [ -n "$BUILD_DEST" ]; then
    rm -rf $BUILD_DEST/lib/modules/sound/acore/snd-hwdep.ko
    rm -rf $BUILD_DEST/lib/modules/sound/acore/snd.ko
    rm -rf $BUILD_DEST/lib/modules/sound/acore/snd-page-alloc.ko
    rm -rf $BUILD_DEST/lib/modules/sound/acore/snd-pcm.ko
    rm -rf $BUILD_DEST/lib/modules/sound/acore/snd-timer.ko
    rm -rf $BUILD_DEST/lib/modules/sound/acore/snd-rawmidi.ko
    rm -rf $BUILD_DEST/lib/modules/sound/acore/seq/snd-seq-device.ko
    rm -rf $BUILD_DEST/lib/modules/sound/usb/snd-usb-audio.ko
    rm -rf $BUILD_DEST/lib/modules/sound/usb/snd-usbmidi-lib.ko
    rm -rf $BUILD_DEST/usr/lib/libasound.so.2.0.0
    rm -rf $BUILD_DEST/usr/lib/libasound.so.2
    rm -rf $BUILD_DEST/usr/lib/libasound.so
    rm -rf $BUILD_DEST/usr/share/alsa
    rm -rf $BUILD_DEST/usr/bin/arecord
    rm -rf $BUILD_DEST/usr/bin/aplay
    rm -rf $BUILD_DEST/usr/bin/aserver
    rm -rf $BUILD_DEST/etc/init.d/alsa
    rm -rf $BUILD_DEST/usr/include/alsa
    rm -rf $BUILD_DEST/usr/include/sys/asoundlib.h
fi
rm -rf patch-2.5.4
rm -rf alsa-driver-1.0.23
rm -rf alsa-lib-1.0.23
rm -rf alsa-utils-1.0.23
