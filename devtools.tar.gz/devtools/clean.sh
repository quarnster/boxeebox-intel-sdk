#!/bin/sh


#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#    Intel Corporation
#    2200 Mission College Blvd.
#    Santa Clara, CA  97052

########################################################################

TOP=${PWD}

if [ -d mtp/udev-120 ]; then
	cd mtp/udev-120
	make clean || exit 1
	cd $TOP
fi

if [ -d mtp/libusb-0.1.12 ]; then
	cd mtp/libusb-0.1.12
	make clean || exit 1
	cd $TOP
fi

if [ -d mtp/libmtp-0.2.6 ]; then
	cd mtp/libmtp-0.2.6
	make clean || exit 1
	cd $TOP
fi

if [ -d zlib-1.2.3 ]; then 
	cd zlib-1.2.3
	make clean || exit 1
	cd $TOP
fi
 
if [ -d libnl-1.1 ]; then 
	cd libnl-1.1
	make clean || exit 1
	cd $TOP
fi

if [ -d dhcpv6-1.2.0 ]; then 
	cd dhcpv6-1.2.0
	make clean || exit 1
	cd $TOP
fi

if [ -d libpng-1.2.44 ]; then
	cd libpng-1.2.44
	make clean || exit 1
	cd $TOP
fi

if [ -d jpeg-6b ]; then 
	cd jpeg-6b
	make clean || exit 1
	cd $TOP
fi
 
if [ -d freetype-2.1.10 ]; then
	cd freetype-2.1.10
	make clean || exit 1
	cd $TOP
fi

if [ -d ncurses-5.6 ]; then
	cd ncurses-5.6
	make clean || exit 1
	cd $TOP
fi

if [ -d libiconv-1.11.1 ]; then 
	cd libiconv-1.11.1
	make clean || exit 1
	cd $TOP
fi

if [ -d flex-2.5.35 ]; then 
	cd flex-2.5.35
	make clean || exit 1
	cd $TOP
fi

if [ -d bison-2.3 ]; then 
	cd bison-2.3
	make clean || exit 1
	cd $TOP
fi

if [ -d dhcp-4.2.0 ]; then
	cd dhcp-4.2.0
	make clean || exit 1
	cd $TOP
fi

rm -rf bin
