#!/bin/sh

#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#    Intel Corporation
#    2200 Mission College Blvd.
#    Santa Clara, CA  97052

########################################################################
set_target_env()
{
	export	CC=$TARGET_CC    
	export 	CXX=$TARGET_CXX   
	export	CPP=$TARGET_CPP      
	export	AS=$TARGET_AS           
	export	LD=$TARGET_LD	          
	export	AR=$TARGET_AR           
	export	AR_RC=$TARGET_AR_RC    
	export	STRIP=$TARGET_STRIP    
	export	RANLIB=$TARGET_RANLIB    
	export	NM=$TARGET_NM           
	export	OBJDUMP=$TARGET_OBJDUMP 
	export	OBJCOPY=$TARGET_OBJCOPY 
	export	STRINGS=$TARGET_STRINGS 
	export	M4=$TARGET_M4		     
	export	BISON=$TARGET_BISON     
	export	YACC=$TARGET_YACC		  
	export	LEX=$TARGET_LEX		  
	export	PKG_CONFIG_PATH=$TARGET_PKG_CONFIG_PATH
}


set_host_env()
{
	export	CC=`which gcc` 
	export	CXX=`which g++`
	export	CPP=`which cpp`
	export	AS=`which as`
	export	LD=`which ld`
	export	AR=`which ar`
	export	AR_RC="$AR rc"
	export	STRIP=`which strip`
	export	RANLIB=`which ranlib`
	export	NM=`which nm`
	export	OBJDUMP=`which objdump`
	export	OBJCOPY=`which objcopy`
	export	STRINGS=`which strings`
	export	M4=`which m4`
	export	BISON=`which bison`
	export	YACC=`which yacc`
	export	LEX=`which flex`
	export	PKG_CONFIG_PATH=
}

TOP=${PWD}
mkdir -p $PREFIX/lib
mkdir -p $PREFIX/include
mkdir -p $PREFIX/bin
mkdir -p $PREFIX/src
mkdir -p $PREFIX/man/man1
mkdir -p $PREFIX/share
mkdir -p $PREFIX/sbin
mkdir -p $PREFIX/etc/udev/rules.d
mkdir -p $CURDIR/bin
if [ -e init_devtools ]; then mkdir -p $PREFIX/etc/init.d/; cp -f init_devtools $PREFIX/etc/init.d/devtools; fi

unset MV CP RM

export CFLAGS
export CPPFLAGS
export CXXFLAGS
export LDFLAGS

if [ x$1 = "x-DDEBUG" ];then 
	DEBUG_CFLAGS=-g3
	DEBUG_CPPFLAGS=-g3
	DEBUG_CXXFLAGS=-g3
	DEBUG_ENABLE=--enable-deubg
fi

# Build flex
if [ ! -d flex-2.5.35 ]; then
	cp flex-2.5.35.tar.bz2 $PREFIX/src
	echo "Extracting flex-2.5.35.tar.bz2"
	tar jxf flex-2.5.35.tar.bz2
fi
cd flex-2.5.35
set_host_env
if [ ! -f Makefile ]; then
	echo "Configuring flex..."
	./configure --prefix=$PREFIX \
		--disable-rpath --disable-nls
fi
make || exit 1
make install || exit 1
cd ..

# Build bison
if [ ! -d bison-2.3 ]; then
	cp bison-2.3.tar.bz2 $PREFIX/src
	cp bison-envvar.patch $PREFIX/src
	cp yacc-envvar.patch $PREFIX/src
	echo "Extracting bison-2.3.tar.bz2"
	tar jxf bison-2.3.tar.bz2
fi
cd bison-2.3
set_host_env
if [ ! -f Makefile ]; then
	echo "Configuring bison..."
	patch -p0 <../bison-envvar.patch
	patch -p0 <../yacc-envvar.patch
	./configure --prefix=$PREFIX/bison-2.3 \
		--disable-rpath --disable-nls
fi
make || exit 1
make install || exit 1
cd ..


# Cross-Compile libnl
if [ ! -d libnl-1.1 ]; then
	cp libnl-1.1.tar.gz $PREFIX/src
	tar -zxf libnl-1.1.tar.gz
fi
cd libnl-1.1

set_target_env
if [ ! -f Makefile.opts ]; then
	echo "Configuring libnl..."
	echo "cross_compiling=yes" >config.cache
	echo "ac_cv_func_malloc_0_nonnull=yes" >>config.cache
	echo "ac_cv_func_realloc_0_nonnull=yes" >>config.cache
	CFLAGS=$DEBUG_CFLAGS CPPFLAGS=$DEBUG_CPPFLAGS CXXFLAGS=$DEBUG_CXXFLAGS  LDFLAGS=
	./configure --prefix=$PREFIX --cache-file=config.cache   $DEBUG_ENABLE  || exit 1
fi

make || exit 1
make install || exit 1
cd ..

if [ -e ${TOP}/README_devtools.txt ]; then cp $TOP/README_devtools.txt $BUILD_DEST/README_devtools.txt; fi

# Compile mtp components
cd mtp
# Compile udev 
if [ ! -d udev-120 ]; then
	cp udev-120.tar.gz $PREFIX/src
	echo "Extracting udev-120.tar.gz" 
	tar zxf udev-120.tar.gz
fi
cd udev-120 

set_target_env
echo "Making udev-120" 

CFLAGS=$DEBUG_CFLAGS CPPFLAGS=$DEBUG_CPPFLAGS CXXFLAGS=$DEBUG_CXXFLAGS  LDFLAGS=
make CROSS_COMPILE=$CROSS_COMPILE || exit 1 

#make EXTRAS="extras/path_id extras/scsi_id extras/usb_id extras/volume_id extras/ata_id extras/edd_id" || exit 1
# Install udev programs
cp udevd \
   udevadm \
   $PREFIX/sbin || exit 1
# Install udev scripts
cp etc/udev/udev.conf $PREFIX/etc/udev || exit 1
cp ../rules/50-udev-gen3.rules $PREFIX/etc/udev/rules.d || exit 1
cp ../rules/disk_automount.sh $PREFIX/etc/udev/rules.d || exit 1
cd ..
 
# Compile libusb
if [ ! -d libusb-0.1.12 ]; then
	cp libusb-0.1.12.tar.gz $PREFIX/src
	echo "Extracting libusb-0.1.12.tar.gz"
	tar zxf libusb-0.1.12.tar.gz
fi
cd libusb-0.1.12

set_target_env
if [ ! -f Makefile ]; then
	echo "Configuring libusb..."
	echo "cross_compiling=yes" >config.cache
	echo "ac_cv_func_malloc_0_nonnull=yes" >>config.cache
	echo "ac_cv_func_realloc_0_nonnull=yes" >>config.cache
	CFLAGS=$DEBUG_CFLAGS CPPFLAGS=$DEBUG_CPPFLAGS CXXFLAGS=$DEBUG_CXXFLAGS  LDFLAGS=
	./configure --prefix=$PREFIX --cache-file=config.cache --target=$TARGET  --with-kernel=$KERNEL $DEBUG_ENABLE --disable-build-docs || exit 1
fi

echo "Making libusb"
make || exit 1
make install || exit 1
cd ..
 
# Compile libmtp
if [ ! -d libmtp-0.2.6 ]; then
	cp libmtp-0.2.6.tar.gz $PREFIX/src
	echo "Extracting libmtp-0.2.6.tar.gz"
	tar zxf libmtp-0.2.6.tar.gz
fi
cd libmtp-0.2.6

set_target_env
if [ ! -f Makefile ]; then 
	echo "Configuring libmtp..."
	echo "cross_compiling=yes" >config.cache
	echo "ac_cv_func_malloc_0_nonnull=yes" >>config.cache
	echo "ac_cv_func_realloc_0_nonnull=yes" >>config.cache
	CFLAGS=$DEBUG_CFLAGS
	CPPFLAGS=-I$PREFIX/include  CXXFLAGS=$DEBUG_CXXFLAGS
	LDFLAGS=-L$PREFIX/lib 
	./configure --prefix=$PREFIX --cache-file=config.cache --target=$TARGET  \
	--with-kernel=$KERNEL $DEBUG_ENABLE || exit 1 
fi
echo "Making libmtp"
make || exit 1
make install || exit 1
cp libmtp.rules $PREFIX/etc/udev/rules.d
cd ..

# Finish mtp components compile
cd ..

# Compile ncurses
if [ ! -d ncurses-5.6 ]; then
	cp ncurses-5.6.tar.gz $PREFIX/src
	echo "Extracting ncurses-5.6.tar.gz"
	tar zxf ncurses-5.6.tar.gz
fi
cd ncurses-5.6

set_target_env
if [ ! -f Makefile ]; then
	echo "Configuring ncurses..."
	echo cross_compiling=yes >config.cache
	echo "ac_cv_func_malloc_0_nonnull=yes" >>config.cache
	echo "ac_cv_func_realloc_0_nonnull=yes" >>config.cache
	CFLAGS=$DEBUG_CFLAGS CPPFLAGS=$DEBUG_CPPFLAGS CXXFLAGS=$DEBUG_CXXFLAGS  LDFLAGS=
	./configure  --cache-file=config.cache --with-softfloat --with-termlib --with-shared --prefix=$PREFIX \
	--bindir=$CURDIR/bin --with-terminfo-dirs=/etc/terminfo:/usr/share/terminfo:/lib/terminfo \
	--host=i686-cm-linux --build=i686-pc-linux   $DEBUG_ENABLE
fi
make || exit 1
make install || exit 1
cd ..

# Build libiconv
if [ ! -d libiconv-1.11.1 ]; then
	cp libiconv-1.11.1.tar.gz $PREFIX/src
	echo "Extracting libiconv-1.11.1.tar.gz"
	tar zxf libiconv-1.11.1.tar.gz
fi
cd libiconv-1.11.1

set_target_env
if [ ! -f Makefile ]; then
	echo "Configuring libiconv..."
        if [ ! -d $PREFIX/libiconv-1.11.1 ]; then mkdir -p $PREFIX/libiconv-1.11.1; fi || exit 1
        echo cross_compiling=yes >config.cache
        echo "ac_cv_func_malloc_0_nonnull=yes" >>config.cache
        echo "ac_cv_func_realloc_0_nonnull=yes" >>config.cache
	CFLAGS=$DEBUG_CFLAGS CPPFLAGS=$DEBUG_CPPFLAGS CXXFLAGS=$DEBUG_CXXFLAGS  LDFLAGS=
	./configure --prefix=$PREFIX/libiconv-1.11.1  --cache-file=config.cache --host=$TARGET \
		--enable-relocatable --disable-rpath --disable-nls  $DEBUG_ENABLE
fi
make || exit 1
make install || exit 1
cd ..
