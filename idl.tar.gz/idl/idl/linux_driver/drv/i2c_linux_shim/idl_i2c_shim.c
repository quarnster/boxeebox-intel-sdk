/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*------------------------------------------------------------------------------
 * File Name: idl_i2c_drv.c
 *------------------------------------------------------------------------------
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/init.h>
#include <linux/module.h>

#include <idl_i2c.h>

/* Driver identification */
MODULE_AUTHOR("Intel Corporation, (C) 2011 - All Rights Reserved");
MODULE_DESCRIPTION("Wrapper to map Intel 'IDL' I2C API to Linux I2C API");
MODULE_SUPPORTED_DEVICE("Intel CE Media Processors");
MODULE_LICENSE("Dual BSD/GPL"); /* Inform kernel that driver is not GPL. */

/* Unique name for driver */
#define I2C_DEV_NAME    "idl_i2c_shim"

#ifndef MOD_NAME
#define MOD_NAME "idl_i2c_shim.ko"
#endif

char *version_string = "#@#" MOD_NAME " " VER;

int
i2c_init(void);

void
i2c_cleanup(void);

/* Specify driver entry points for kernel */
/* Macros are defined in linux/module.h */
module_init(i2c_init);
module_exit(i2c_cleanup);

/*------------------------------------------------------------------------------
 * Export symbols for other modules
 *------------------------------------------------------------------------------
 */

EXPORT_SYMBOL(idl_i2c_open);
EXPORT_SYMBOL(idl_i2c_close);
EXPORT_SYMBOL(idl_i2c_reset);
EXPORT_SYMBOL(idl_i2c_set_mode);
EXPORT_SYMBOL(idl_i2c_enable_polling);
EXPORT_SYMBOL(idl_i2c_read_sub_addr);
EXPORT_SYMBOL(idl_i2c_write_sub_addr);

int
i2c_init(void) {
   return 0;
}

void
i2c_cleanup(void) {
}


idl_result_t
idl_i2c_open(void) {
   return IDL_SUCCESS;
}

idl_result_t
idl_i2c_close(void) {
   return IDL_SUCCESS;
}

idl_result_t
idl_i2c_reset(uint8_t bus_num) {
   return IDL_SUCCESS;
}

idl_result_t
idl_i2c_set_mode(uint8_t bus_num, idl_i2c_mode_t mode) {
   return IDL_SUCCESS;
}

idl_result_t
idl_i2c_enable_polling(uint8_t bus_num, bool to_poll) {
   return IDL_SUCCESS;
}

idl_result_t
idl_i2c_read_sub_addr(uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count) 
{
   return IDL_SUCCESS;
}

idl_result_t
idl_i2c_write_sub_addr(uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count) 
{
   return IDL_SUCCESS;
}
