/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*----------------------------------------------------------------------
 * File Name:       idl_spi_drv.c
 *----------------------------------------------------------------------
 */

#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/proc_fs.h>
#include <linux/wait.h>
#include <linux/pci.h>

#include <asm/uaccess.h>
#include <asm/irq.h>
#include <asm/io.h>
#include "idl_spi_drv.h"
#include "idl_spi.h"
#include "_spi.h"

#include <osal_event.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,28)
    #include <asm/semaphore.h>
#else
    #include <linux/semaphore.h>
#endif

#define REMOVE_PRINTS 1
//#define DEBUG

/* These are predefined macros that specify different parameters
 * for our driver */ 
MODULE_AUTHOR("Intel Corporation, (C) 2005 - 2010 - All Rights Reserved");
MODULE_DESCRIPTION("IDL SPI Device Driver");
MODULE_SUPPORTED_DEVICE("Intel Media Processors");

/* Notifies the kernel that our driver is not GPL. */
MODULE_LICENSE("Dual BSD/GPL");

/* These are the symbols we want exported to other modules */
EXPORT_SYMBOL(idl_spi_init);
EXPORT_SYMBOL(idl_spi_release);
EXPORT_SYMBOL(idl_spi_set_config);
EXPORT_SYMBOL(idl_spi_set_event_callback);
EXPORT_SYMBOL(idl_spi_event_enable);
EXPORT_SYMBOL(idl_spi_event_disable);
EXPORT_SYMBOL(idl_spi_get_status);
EXPORT_SYMBOL(idl_spi_read);
EXPORT_SYMBOL(idl_spi_write);

/* Unique name for SPI driver */
#define SPI_DEV_NAME "spi"

#ifndef MOD_NAME
#define MOD_NAME "idl_spi.ko"
#endif

char *version_string = "#@#" MOD_NAME " " VER;

/* high level init function (called by insmod when driver is loaded) */
int spi_init(void);

/* high level remove function (called by rmmod when driver is unloaded) */
void spi_cleanup(void);

/* tell the kernel the name of our entry points (these macros are defined in linux/module.h */
module_init(spi_init);
module_exit(spi_cleanup);

/* called when an application tries to open a connection to our driver */
int spi_open(struct inode *i, struct file *f);

/* called when an application disconnects from the driver */
int spi_close(struct inode *i, struct file *f);

/* called when the application requests that our driver perform a task or 
   service on the application's request. */ 
long spi_ioctl(struct file *f, unsigned int cmd, unsigned long arg);

/*  irq handler for spi (wakeup)*/
void spi_irq_handler(void *data);

/* This is the major number assigned dynamically assigned by Linux */
/* This number is required by the mknod command. */
static int m_spi_major_number;

/* structure that maps our functions to the OS */
struct file_operations m_spi_ops = { 	
					.owner = THIS_MODULE,
					.unlocked_ioctl = spi_ioctl,
					.open = spi_open,
					.release = spi_close,
				 };

uint32_t spi_irq;

/* Base address used to access spi registers */
//static uint32_t *m_idl_spi_base;
//static unsigned long *m_idl_int_ctrl;


/* The wait queue is used as an internal messaging system
 * within the driver. We need 1 Q for each spi interrupt. */
os_event_t spi_interrupt_start[NUM_SPI_PORTS];
os_event_t spi_interrupt_done[NUM_SPI_PORTS];

static int spi_irq_release = 0; 
volatile static spi_ioctl_args g_spi_args[NUM_SPI_PORTS];

static DEFINE_MUTEX(ioctl_mutex);

/* Declaration of SPI interrupt handler */
//irqreturn_t spi_irq_handler(int irq, void *dev_id, struct pt_regs *regs);
//#endif 
/*********************************************************
 * Helper function declerations
 *
 *********************************************************/

/* helper function that registers our device with the OS. */
int spi_dev_reg(void);

//We will register this function with IDL and when interrupt happens, this
//api is which will wakeup ioctl that will wake up app thread for actual procesing of 
//interrupt. APP has to create thread , this function will only only disbale and 
//wake up ioctl
void spi_call_back_function( void *pData);

/* tell the OS that we'd like to register our driver */
int spi_dev_reg()
{
	/* First we need to register our device with the OS */
	/* We'll dynamically ask the OS to assign us an available major */
	/* number. */

	if ((m_spi_major_number = register_chrdev(0, SPI_DEV_NAME, &m_spi_ops)) < 0)
	{
		/* Error occured with device registration */
		printk(KERN_ERR "%s:%4i: IDL SPI device registration failed - code %d\n", 
				__FILE__, __LINE__, m_spi_major_number);
		return m_spi_major_number;
	}
	return m_spi_major_number;
}

volatile int m_driver_callback_reentered;
/* High level spi initialization - called at driver load time 
* This function will pnly be called by insmod
*/
int spi_init()
{
	int status = 0;
	int i;
	struct pci_dev *spi_dev;

	m_driver_callback_reentered = 0;
	spi_dev = pci_get_device(0x8086, 0x2E6A, NULL);
	if (spi_dev) {
		pci_enable_device(spi_dev);
		pci_intx(spi_dev, 1);
		spi_irq = spi_dev->irq;
		pci_dev_put(spi_dev);
	}
	else{
		printk(KERN_INFO "can not get spi pci dev\n");
	}
	
	/* Register the device with the operating system */	
	status = spi_dev_reg();
	
	if (status < 0)
	{
		/* device registration failed */
		return status;
	}
	/* Initialize our wait queues prior to enabling interrupts */
	for (i = 0; i < NUM_SPI_PORTS; i++)
	{
		os_event_create(&spi_interrupt_start[i], 1);
		os_event_create(&spi_interrupt_done[i], 1);
	} 
	return 0;
}

/* called when the system unloads our driver 
*	Called only by rmmod
*/
void spi_cleanup()
{
	int i = 0;
	
	for (i = 0; i < NUM_SPI_PORTS; i++)
	{
		idl_spi_release( i);
		os_event_destroy(&spi_interrupt_start[i]);
		os_event_destroy(&spi_interrupt_done[i]);
	} 
	
	//Make sure all fd have been closed.
	unregister_chrdev(m_spi_major_number, SPI_DEV_NAME);
}

/* IDL SPI Open - lets the kernel know that an app is accessing the device */
int spi_open(struct inode *i, struct file *f)
{

#ifdef DEBUG
	printk(KERN_INFO "%s:%4i: %s (pid %d) opened idl_spi_drv.\n",
		       	__FILE__, __LINE__, current->comm, current->pid);
#endif
	//No two app on same port
	return 0;
}

/* IDL SPI close - lets the kernel know that an app is finished accessing the device */
int spi_close(struct inode *i, struct file *f)
{

#ifdef DEBUG
	printk(KERN_INFO "%s:%4i: %s (pid %d) closed idl_spi_drv.\n",
		       	__FILE__, __LINE__, current->comm, current->pid);
#endif
	
	return 0;
}
 
/* idl spi ioctl - handles user requests to access the spi device */
long spi_ioctl(struct file *f, u_int cmd, u_long arg)
{
	int status = 0;
	idl_result_t idl_status = IDL_SUCCESS; 
	osal_result osal_status;
	spi_ioctl_args spi_args;
	spi_config_t *spi_config ;
	spi_status_t *spi_status;
	spi_event_t *spi_events;
	uint32_t *data;

#ifdef DEBUG
	printk(KERN_INFO "%s:%4i: Driver received ioctl command: %x\n", __FILE__, __LINE__, cmd);
#endif
	/* make sure we have a valid pointer to our parameters */
	if (!arg)
		return -EINVAL;
	/* read the parameters from user */
	status = copy_from_user(&spi_args, (void *)arg, sizeof(spi_ioctl_args));
	
	if (status)
	{
		printk(KERN_ERR "%s:%4i: could not read ioctl arguments \n", 
				__FILE__, __LINE__);
		return status;
	}
#ifdef DEBUG
	else
	{
		printk(KERN_INFO "%s:%4i: ioctl arguments (spi_args) are:\n", __FILE__, __LINE__);
		printk(KERN_INFO "%s:%4i: -----spi_num = %lu\n", __FILE__, __LINE__, spi_args.spi_num);
		printk(KERN_INFO "%s:%4i: -----data = %lux\n", __FILE__, __LINE__, (unsigned long)spi_args.pdata);
		printk(KERN_INFO "%s:%4i: -----result = %x\n", __FILE__, __LINE__, spi_args.result);
	}
#endif
	if (unlikely(mutex_lock_interruptible(&ioctl_mutex)))
		return -ERESTARTSYS;

    if( spi_args.spi_num < NUM_SPI_PORTS) {
        g_spi_args[ spi_args.spi_num].spi_num = spi_args.spi_num;
        g_spi_args[ spi_args.spi_num].pdata = spi_args.pdata;
        g_spi_args[ spi_args.spi_num].result = spi_args.result;
    }

/* process user request */
	switch (cmd)
	{
		case SPI_IOCTL_INIT : 

			idl_status = idl_spi_init(spi_args.spi_num);
			spi_args.result= idl_status;
			if(idl_status != IDL_SUCCESS) {
#ifndef REMOVE_PRINTS
				printk(KERN_INFO "SPI_IOCTL_INIT() status=0x%08x failed\r\n", idl_status );
#endif
				status = -EINVAL;
			}	
			break;
		case SPI_IOCTL_RELEASE: 
			idl_status = idl_spi_release(spi_args.spi_num);
			spi_args.result= idl_status;
			if(idl_status != IDL_SUCCESS) {
#ifndef REMOVE_PRINTS
				printk(KERN_INFO "SPI_IOCTL_RELEASE() status=0x%08x failed\r\n", idl_status );
#endif
				status = -EINVAL;
			}	
			break;
		case SPI_IOCTL_SET_CONFIG: 
			spi_config = (spi_config_t *)spi_args.pdata;
			idl_status = idl_spi_set_config(spi_args.spi_num,spi_config);
			spi_args.result= idl_status;
			if(idl_status != IDL_SUCCESS) {
#ifndef REMOVE_PRINTS
				printk(KERN_INFO "SPI_IOCTL_SET_CONFIG() status=0x%08x failed\r\n", idl_status );
#endif
				status = -EINVAL;
			}	
			break;
		case SPI_IOCTL_SET_CALLBACK: 
			if( spi_args.pdata == NULL) {
				idl_status = idl_spi_set_event_callback(spi_args.spi_num,NULL,(void *)&(g_spi_args[spi_args.spi_num]));
			} else {
				idl_status = idl_spi_set_event_callback(spi_args.spi_num,(spi_callback_t)spi_call_back_function,(void *)&(g_spi_args[spi_args.spi_num]));
			}
			spi_args.result= idl_status;
			if(idl_status != IDL_SUCCESS) {
#ifndef REMOVE_PRINTS
				printk(KERN_INFO "SPI_IOCTL_SET_CALLBACK() status=0x%08x failed\r\n", idl_status );
#endif
				status = -EINVAL;
			}	
			break;
		case SPI_IOCTL_SET_EVENTS: 
			spi_events = (spi_event_t *)spi_args.pdata;
			idl_status = idl_spi_event_enable(spi_args.spi_num,*spi_events);
			spi_args.result= idl_status;
			if(idl_status != IDL_SUCCESS) {
#ifndef REMOVE_PRINTS
				printk(KERN_INFO "SPI_IOCTL_SET_EVENTS() status=0x%08x failed\r\n", idl_status );
#endif
				status = -EINVAL;
			}	
			break;
		case SPI_IOCTL_CLEAR_EVENTS: 
			spi_events = (spi_event_t *)spi_args.pdata;
			idl_status = idl_spi_event_disable(spi_args.spi_num,*spi_events);
			spi_args.result= idl_status;
			if(idl_status != IDL_SUCCESS) {
#ifndef REMOVE_PRINTS
				printk(KERN_INFO "SPI_IOCTL_CLEAR_EVENTS() status=0x%08x failed\r\n", idl_status );
#endif
				status = -EINVAL;
			}	
			break;
		case SPI_IOCTL_GET_STATUS: 
			spi_status = (spi_status_t *)spi_args.pdata;
			idl_status = idl_spi_get_status(spi_args.spi_num,spi_status);
			spi_args.result= idl_status;
			if(idl_status != IDL_SUCCESS) {
#ifndef REMOVE_PRINTS
				printk(KERN_INFO "SPI_IOCTL_GET_STATUS() status=0x%08x failed\r\n", idl_status );
#endif
				status = -EINVAL;
			}	
			break;
		case SPI_IOCTL_SPI_READ: 
			data = (uint32_t *)spi_args.pdata;
			idl_status = idl_spi_read(spi_args.spi_num,data);
			spi_args.result= idl_status;
			if(idl_status != IDL_SUCCESS) {
#ifndef REMOVE_PRINTS
				printk(KERN_INFO "SPI_IOCTL_SPI_READ() status=0x%08x failed\r\n", idl_status );
#endif
				status = -EINVAL;
			}	
			break;
		case SPI_IOCTL_SPI_WRITE: 
			data = (uint32_t *)spi_args.pdata;
			idl_status = idl_spi_write(spi_args.spi_num,*data);
			spi_args.result= idl_status;
			if(idl_status != IDL_SUCCESS) {
#ifndef REMOVE_PRINTS
				printk(KERN_INFO "SPI_IOCTL_SPI_WRITE() status=0x%08x failed\r\n", idl_status );
#endif
				status = -EINVAL;
			}	
			break;
		case SPI_IOCTL_WAIT_FOR_IRQ:
			// irq_release is a mechanism to allow libray to tell
			// us not to listen for interrupts any more 
			// the only other way for us to wake up this wait_queue
			// is for a interrutp to come in...
#ifndef REMOVE_PRINTS
			printk(KERN_INFO "Waiting for IRQ...\n");
#endif
			osal_status = os_event_wait(&spi_interrupt_start[spi_args.spi_num], -1 /*EVENT_NO_TIMEOUT*/);
			os_event_reset(&spi_interrupt_start[spi_args.spi_num]);
			
			if( osal_status != OSAL_SUCCESS)
			{
				printk(KERN_INFO "\r\n\r\nos_event_wait call FAILED: %x \r\n\r\n", osal_status);
				status = -ERESTARTSYS;
			} else {
#ifndef REMOVE_PRINTS
				printk(KERN_INFO "Interrupt received..\n");
#endif
			}
			spi_irq_release = 0;
			break;
		case SPI_IOCTL_ACK_IRQ:
#ifndef REMOVE_PRINTS
			printk(KERN_INFO "Interrupt processing complete...\n");
#endif
			os_event_set(&spi_interrupt_done[spi_args.spi_num]);
			break;
//		case SPI_IOCTL_RELEASE_IRQ:
//			spi_irq_release = 1;
//#ifndef REMOVE_PRINTS
//			printk(KERN_INFO "Releasing IRQ...\n");
//#endif
//			os_release_interrupt( 
//			isl_spi_release( spi_args.spi_num);
//			os_event_set(&spi_interrupt_start[spi_args.spi_num]);
//			break;

		default:
			/* so that we are POSIX compliant, return
			 * ENOTTY as the ioctl command is invalid */
			 printk(KERN_ERR "%s:%4i: ioctl command %x does not belong to this driver\n", 
				__FILE__, __LINE__, cmd);
			status = -ENOTTY;
	}

	mutex_unlock(&ioctl_mutex);

	if ( copy_to_user((void *)arg, &spi_args,sizeof(spi_ioctl_args)))
	{
		printk(KERN_ERR "%s:%4i: could not write ioctl arguments \n", 
				__FILE__, __LINE__);
	}
	return status;
}

void spi_call_back_function( void *pData)
{

	spi_ioctl_args	*sData;
	uint32_t  spi_id;

	if( m_driver_callback_reentered > 0)
	{
		printk( KERN_INFO "ERROR: driver callback re-entered %d times\r\n", m_driver_callback_reentered);
	}
	m_driver_callback_reentered++;
	
	sData = (spi_ioctl_args *)pData;
	spi_id = sData->spi_num;

#ifndef REMOVE_PRINTS
	printk(KERN_INFO "IRQ Handler called (spi # %d)\n", spi_id);
#endif

#ifndef REMOVE_PRINTS
	printk(KERN_INFO "Starting interrupt handler\n");
#endif

	os_event_set(&spi_interrupt_start[spi_id]);

#ifndef REMOVE_PRINTS
	printk(KERN_INFO "Waiting for interrupt done from user\n");
#endif

	os_event_wait(&spi_interrupt_done[spi_id], -1 /*EVENT_NO_TIMEOUT*/);
	os_event_reset(&spi_interrupt_done[spi_id]);
	
	m_driver_callback_reentered--;
}

