/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*------------------------------------------------------------------------------
 * File Name: idl_i2c_drv.c
 *------------------------------------------------------------------------------
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/interrupt.h>
#include <linux/proc_fs.h>
#include <linux/wait.h>

#include <asm/uaccess.h>
#include <asm/irq.h>
#include <asm/io.h>

#include <osal_event.h>

#include <_i2c.h>
#include <idl_i2c.h>
#include <idl_i2c_drv.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,28)
    #include <asm/semaphore.h>
#else
    #include <linux/semaphore.h>
#endif

/* Driver identification */
MODULE_AUTHOR("Intel Corporation, (C) 2005 - 2011 - All Rights Reserved");
MODULE_DESCRIPTION("IDL I2C Device Driver for Linux 2.6");
MODULE_SUPPORTED_DEVICE("Intel Media Processors");
MODULE_LICENSE("Dual BSD/GPL"); /* Inform kernel that driver is not GPL. */

/* Unique name for driver */
#define I2C_DEV_NAME    "i2c"

#ifndef MOD_NAME
#define MOD_NAME "idl_i2c.ko"
#endif

char *version_string = "#@#" MOD_NAME " " VER;

/* This function is the first function called to load the driver after an insmod */
/* command */

int
i2c_init(void);

/* This function is the first function called to unload the driver after an rmmod */
/* command */

void
i2c_cleanup(void);

/* This function is called when an application tries to open a connection to the */
/* driver */

int
i2c_open(struct inode *p_inode, struct file *p_file);

/* This function is called when an application disconnects from the driver */

int
i2c_close(struct inode *p_inode, struct file *p_file);

/* This function is called when an application requests that the driver performs a */
/* task or service on the application's behalf */

long
i2c_ioctl(struct file *p_file, u_int command,
   u_long p_args);

/* Specify driver entry points for kernel */
/* Macros are defined in linux/module.h */
module_init(i2c_init);
module_exit(i2c_cleanup);

/* This is the major number assigned dynamically assigned by Linux */
/* This number is required by the mknod command */
static int m_i2c_major_number;

static int m_open_count = 0;

/* Structure to map driver functions to kernel */
struct file_operations m_i2c_ops = { 	
   .owner = THIS_MODULE,
   .unlocked_ioctl = i2c_ioctl,
   .open = i2c_open, 
   .release = i2c_close,
};

static DEFINE_MUTEX(ioctl_mutex);

/*------------------------------------------------------------------------------
 * Support structure for user-space interrupt callback mechanism
 *------------------------------------------------------------------------------
 */
static os_event_t i2c_os_event_start[_I2C_MAX_BUS_COUNT];
static os_event_t i2c_os_event_stop[_I2C_MAX_BUS_COUNT];


void
i2c_interrupt_event_handler(uint8_t bus_num);

idl_result_t
i2c_interrupt_event_wait(uint8_t bus_num);

idl_result_t
i2c_interrupt_event_done(uint8_t bus_num);

idl_result_t
i2c_interrupt_event_exit(uint8_t bus_num);

/*------------------------------------------------------------------------------
 * Export symbols for other modules
 *------------------------------------------------------------------------------
 */

EXPORT_SYMBOL(idl_i2c_get_bus_count);
EXPORT_SYMBOL(idl_i2c_open);
EXPORT_SYMBOL(idl_i2c_close);
EXPORT_SYMBOL(idl_i2c_reset);
EXPORT_SYMBOL(idl_i2c_set_mode);
EXPORT_SYMBOL(idl_i2c_enable_polling);
EXPORT_SYMBOL(idl_i2c_enable_yield);
EXPORT_SYMBOL(idl_i2c_read_byte);
EXPORT_SYMBOL(idl_i2c_write_byte);
EXPORT_SYMBOL(idl_i2c_set_interrupt_mask);
EXPORT_SYMBOL(idl_i2c_get_interrupt_mask);
EXPORT_SYMBOL(idl_i2c_get_pending_interrupts);
EXPORT_SYMBOL(idl_i2c_register_interrupt_handler);
EXPORT_SYMBOL(idl_i2c_release_interrupt_handler);
EXPORT_SYMBOL(idl_i2c_wait_for_interrupts);
EXPORT_SYMBOL(idl_i2c_read);
EXPORT_SYMBOL(idl_i2c_read_restart);
EXPORT_SYMBOL(idl_i2c_read_sub_addr);
EXPORT_SYMBOL(idl_i2c_read_sub_addr_ex);
EXPORT_SYMBOL(idl_i2c_write);
EXPORT_SYMBOL(idl_i2c_write_restart);
EXPORT_SYMBOL(idl_i2c_write_sub_addr);
EXPORT_SYMBOL(idl_i2c_write_sub_addr_ex);
EXPORT_SYMBOL(idl_i2c_read_write_async_wait);
EXPORT_SYMBOL(idl_i2c_read_async);
EXPORT_SYMBOL(idl_i2c_read_sub_addr_async);
EXPORT_SYMBOL(idl_i2c_read_sub_addr_ex_async);
EXPORT_SYMBOL(idl_i2c_write_async);
EXPORT_SYMBOL(idl_i2c_write_sub_addr_async);
EXPORT_SYMBOL(idl_i2c_write_sub_addr_ex_async);

EXPORT_SYMBOL(i2c_interrupt_event_wait);
EXPORT_SYMBOL(i2c_interrupt_event_done);
EXPORT_SYMBOL(i2c_interrupt_event_exit);

/*------------------------------------------------------------------------------
 * Functions to support user-space interrupt callback mechanism
 *------------------------------------------------------------------------------
 */

void
i2c_interrupt_event_handler(uint8_t bus_num)
{
   /* Enable user callback function to start */
   os_event_set(&i2c_os_event_start[bus_num]);

   /* Wait for user callback function to complete */
   if (os_event_wait(&i2c_os_event_stop[bus_num], -1) ==
      OSAL_SUCCESS) {
      os_event_reset(&i2c_os_event_stop[bus_num]);
   }
}

idl_result_t
i2c_interrupt_event_wait(uint8_t bus_num)
{
   if ((bus_num > (_i2c_bus_count_value()-1))||os_event_wait(&i2c_os_event_start[bus_num], -1) != 
      OSAL_SUCCESS) {
      return IDL_FAILURE;
   } else {
      os_event_reset(&i2c_os_event_start[bus_num]);
   }
   return IDL_SUCCESS;
}

idl_result_t
i2c_interrupt_event_done(uint8_t bus_num)
{
   if ((bus_num > (_i2c_bus_count_value()-1))||(os_event_set(&i2c_os_event_stop[bus_num]) != OSAL_SUCCESS)) {
      return IDL_FAILURE;
   }
   return IDL_SUCCESS;
}

idl_result_t
i2c_interrupt_event_exit(uint8_t bus_num)
{
    if (bus_num >= _i2c_bus_count_value()) {
                return (-1);
   }
   os_event_set(&i2c_os_event_start[bus_num]);
   if (os_event_set(&i2c_os_event_stop[bus_num]) != OSAL_SUCCESS) {
      return IDL_FAILURE;
   }
   return IDL_SUCCESS;
}

/*------------------------------------------------------------------------------
 * i2c_init
 *------------------------------------------------------------------------------
 */

int
i2c_init(void)
{
   /* Register the device with the operating system */	
   if ((m_i2c_major_number = register_chrdev(0, I2C_DEV_NAME, &m_i2c_ops)) < 0)
   {
      printk(KERN_ERR "%s:%4i: i2c_init failed\n", __FILE__, __LINE__);
      return m_i2c_major_number;
   }
   _i2c_get_platform_bus_count( );
   return 0;
}

/*------------------------------------------------------------------------------
 * i2c_open
 *------------------------------------------------------------------------------
 */

void
i2c_cleanup(void)
{
   unregister_chrdev(m_i2c_major_number, I2C_DEV_NAME);
}

/*------------------------------------------------------------------------------
 * i2c_open
 *------------------------------------------------------------------------------
 */

int
i2c_open(struct inode *p_inode, struct file *p_file)
{
   return 0;
}

/*------------------------------------------------------------------------------
 * i2c_close
 *------------------------------------------------------------------------------
 */

int
i2c_close(struct inode *p_inode, struct file *p_file)
{
   return 0;
}

/*------------------------------------------------------------------------------
 * i2c_ioctl
 *------------------------------------------------------------------------------
 */

long
i2c_ioctl(struct file *p_file, u_int command,
   u_long p_args)
{
   int status = 0;
   uint8_t bus_num = 0;
   uint32_t bus_number = 0;
   i2c_ioctl_args_t i2c_ioctl_args;

   /* Check to see if the ioctl command is meant for this device */
   if (_IOC_TYPE(command) != I2C_IOCTL_MAGIC) {
      printk(KERN_ERR "%s:%4i:  i2c_ioctl failed\n", __FILE__, __LINE__);
      return -ENOTTY;
   }

   /* Check for valid pointer to the parameter list */
   if (p_args == 0) {
      printk(KERN_ERR "%s:%4i:  i2c_ioctl failed\n", __FILE__, __LINE__);
      return -EINVAL;
   }
   
   /* Copy user-space parameters into kernel space */
   if ((status = copy_from_user(&i2c_ioctl_args, (void *) p_args, 
      sizeof(i2c_ioctl_args_t))) != 0) {
         printk(KERN_ERR "%s:%4i:  i2c_ioctl failed\n", __FILE__, __LINE__);
         return status;
   }

   if (unlikely(mutex_lock_interruptible(&ioctl_mutex)))
       return -ERESTARTSYS;

   /* Execute ioctl request */
   switch (command)
   {
   case I2C_IOCTL_GET_BUS_COUNT:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_get_bus_count(
         (uint8_t *) i2c_ioctl_args.p_params[0]);
      break;
   case I2C_IOCTL_OPEN:
      if (m_open_count++ == 0) {
         for (bus_num = 0; bus_num < _i2c_bus_count_value(); bus_num++) {
            os_event_create(&i2c_os_event_start[bus_num], 0);
            os_event_create(&i2c_os_event_stop[bus_num], 0);
         }
         i2c_ioctl_args.result = (unsigned long) idl_i2c_open();
      } else {
         i2c_ioctl_args.result = (unsigned long) IDL_SUCCESS;
      }
      break;
   case I2C_IOCTL_CLOSE:
      if (--m_open_count == 0) {
         i2c_ioctl_args.result = (unsigned long) idl_i2c_close();
         for (bus_num = 0; bus_num < _i2c_bus_count_value(); bus_num++) {
            i2c_interrupt_event_exit(bus_num);
            os_event_destroy(&i2c_os_event_start[bus_num]);
            os_event_destroy(&i2c_os_event_stop[bus_num]);
         }
      } else {
         i2c_ioctl_args.result = (unsigned long) IDL_SUCCESS;
      }
      break;
   case I2C_IOCTL_RESET:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_reset(
         *((uint8_t *) i2c_ioctl_args.p_params[0]));
      break;
   case I2C_IOCTL_SET_MODE:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_set_mode(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((idl_i2c_mode_t *) i2c_ioctl_args.p_params[1]));
      break;
   case I2C_IOCTL_ENABLE_POLLING:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_enable_polling(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((bool *) i2c_ioctl_args.p_params[1]));
      break;
   case I2C_IOCTL_ENABLE_YIELD:
      printk(KERN_DEBUG "in i2c ioctl: yield\n");
      i2c_ioctl_args.result = (unsigned long) idl_i2c_enable_yield(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((bool *) i2c_ioctl_args.p_params[1]));
      break;
   case I2C_IOCTL_READ_BYTE:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_read_byte(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint32_t *) i2c_ioctl_args.p_params[1]),
         (uint8_t *) i2c_ioctl_args.p_params[2]);
      break;
   case I2C_IOCTL_WRITE_BYTE:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_write_byte(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint32_t *) i2c_ioctl_args.p_params[1]),
         *((uint8_t *) i2c_ioctl_args.p_params[2]));
      break;
   case I2C_IOCTL_SET_INTERRUPT_MASK:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_set_interrupt_mask(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint32_t *) i2c_ioctl_args.p_params[1]));
      break;
   case I2C_IOCTL_GET_INTERRUPT_MASK:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_get_interrupt_mask(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         (uint32_t *) i2c_ioctl_args.p_params[1]);
      break;
   case I2C_IOCTL_GET_PENDING_INTERRUPTS:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_get_pending_interrupts(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         (uint32_t *) i2c_ioctl_args.p_params[1]);
      break;
   case I2C_IOCTL_REGISTER_INTERRUPT_HANDLER:
      bus_number = *((uint8_t *) i2c_ioctl_args.p_params[0]);
      bus_num = bus_number;
      i2c_ioctl_args.result = (unsigned long) idl_i2c_register_interrupt_handler(
         bus_num, (os_interrupt_handler_t *) &i2c_interrupt_event_handler,
         (void *) bus_number);
      break;
   case I2C_IOCTL_RELEASE_INTERRUPT_HANDLER:
      bus_num = *((uint8_t *) i2c_ioctl_args.p_params[0]);
      i2c_ioctl_args.result = (unsigned long) idl_i2c_release_interrupt_handler(
         bus_num);
      i2c_ioctl_args.result = (unsigned long) i2c_interrupt_event_done(
         bus_num);
      break;
   case I2C_IOCTL_WAIT_FOR_INTERRUPTS:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_wait_for_interrupts(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint32_t *) i2c_ioctl_args.p_params[1]),
         *((uint32_t *) i2c_ioctl_args.p_params[2]));
      break;
   case I2C_IOCTL_READ:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_read(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint16_t *) i2c_ioctl_args.p_params[1]),
         (uint8_t *) i2c_ioctl_args.p_params[2],
         *((uint32_t *) i2c_ioctl_args.p_params[3]));
      break;
   case I2C_IOCTL_READ_RESTART:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_read_restart(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint16_t *) i2c_ioctl_args.p_params[1]),
         *((uint8_t *) i2c_ioctl_args.p_params[2]),
         (uint8_t *) i2c_ioctl_args.p_params[3],
         *((uint32_t *) i2c_ioctl_args.p_params[4]));
      break;
   case I2C_IOCTL_READ_SUB_ADDR:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_read_sub_addr(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint16_t *) i2c_ioctl_args.p_params[1]),
         *((uint8_t *) i2c_ioctl_args.p_params[2]),
         (uint8_t *) i2c_ioctl_args.p_params[3],
         *((uint32_t *) i2c_ioctl_args.p_params[4]));
      break;
   case I2C_IOCTL_READ_SUB_ADDR_EX:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_read_sub_addr_ex(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint16_t *) i2c_ioctl_args.p_params[1]),
         (uint8_t *) i2c_ioctl_args.p_params[2],
         *((uint32_t *) i2c_ioctl_args.p_params[3]),
         (uint8_t *) i2c_ioctl_args.p_params[4],
         *((uint32_t *) i2c_ioctl_args.p_params[5]));
      break;
   case I2C_IOCTL_WRITE:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_write(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint16_t *) i2c_ioctl_args.p_params[1]),
         (uint8_t *) i2c_ioctl_args.p_params[2],
         *((uint32_t *) i2c_ioctl_args.p_params[3]));
      break;
   case I2C_IOCTL_WRITE_RESTART:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_write_restart(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint16_t *) i2c_ioctl_args.p_params[1]),
         *((uint8_t *) i2c_ioctl_args.p_params[2]),
         (uint8_t *) i2c_ioctl_args.p_params[3],
         *((uint32_t *) i2c_ioctl_args.p_params[4]));
      break;
   case I2C_IOCTL_WRITE_SUB_ADDR:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_write_sub_addr(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint16_t *) i2c_ioctl_args.p_params[1]),
         *((uint8_t *) i2c_ioctl_args.p_params[2]),
         (uint8_t *) i2c_ioctl_args.p_params[3],
         *((uint32_t *) i2c_ioctl_args.p_params[4]));
      break;
   case I2C_IOCTL_WRITE_SUB_ADDR_EX:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_write_sub_addr_ex(
         *((uint8_t *) i2c_ioctl_args.p_params[0]),
         *((uint16_t *) i2c_ioctl_args.p_params[1]),
         (uint8_t *) i2c_ioctl_args.p_params[2],
         *((uint32_t *) i2c_ioctl_args.p_params[3]),
         (uint8_t *) i2c_ioctl_args.p_params[4],
         *((uint32_t *) i2c_ioctl_args.p_params[5]));
      break;
   case I2C_IOCTL_READ_WRITE_ASYNC_WAIT:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_read_write_async_wait(
         (idl_i2c_read_write_async_handle_t *) i2c_ioctl_args.p_params[0],
         *((uint32_t *) i2c_ioctl_args.p_params[1]));
      break;
   case I2C_IOCTL_READ_ASYNC:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_read_async(
         (idl_i2c_read_write_async_handle_t *) i2c_ioctl_args.p_params[0],
         *((uint8_t *) i2c_ioctl_args.p_params[1]),
         *((uint16_t *) i2c_ioctl_args.p_params[2]),
         (uint8_t *) i2c_ioctl_args.p_params[3],
         *((uint32_t *) i2c_ioctl_args.p_params[4]));
      break;
   case I2C_IOCTL_READ_SUB_ADDR_ASYNC:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_read_sub_addr_async(
         (idl_i2c_read_write_async_handle_t *) i2c_ioctl_args.p_params[0],
         *((uint8_t *) i2c_ioctl_args.p_params[1]),
         *((uint16_t *) i2c_ioctl_args.p_params[2]),
         *((uint8_t *) i2c_ioctl_args.p_params[3]),
         (uint8_t *) i2c_ioctl_args.p_params[4],
         *((uint32_t *) i2c_ioctl_args.p_params[5]));
      break;
   case I2C_IOCTL_READ_SUB_ADDR_EX_ASYNC:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_read_sub_addr_ex_async(
         (idl_i2c_read_write_async_handle_t *) i2c_ioctl_args.p_params[0],
         *((uint8_t *) i2c_ioctl_args.p_params[1]),
         *((uint16_t *) i2c_ioctl_args.p_params[2]),
         (uint8_t *) i2c_ioctl_args.p_params[3],
         *((uint32_t *) i2c_ioctl_args.p_params[4]),
         (uint8_t *) i2c_ioctl_args.p_params[5],
         *((uint32_t *) i2c_ioctl_args.p_params[6]));
      break;
   case I2C_IOCTL_WRITE_ASYNC:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_write_async(
         (idl_i2c_read_write_async_handle_t *) i2c_ioctl_args.p_params[0],
         *((uint8_t *) i2c_ioctl_args.p_params[1]),
         *((uint16_t *) i2c_ioctl_args.p_params[2]),
         (uint8_t *) i2c_ioctl_args.p_params[3],
         *((uint32_t *) i2c_ioctl_args.p_params[4]));
      break;
   case I2C_IOCTL_WRITE_SUB_ADDR_ASYNC:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_write_sub_addr_async(
         (idl_i2c_read_write_async_handle_t *) i2c_ioctl_args.p_params[0],
         *((uint8_t *) i2c_ioctl_args.p_params[1]),
         *((uint16_t *) i2c_ioctl_args.p_params[2]),
         *((uint8_t *) i2c_ioctl_args.p_params[3]),
         (uint8_t *) i2c_ioctl_args.p_params[4],
         *((uint32_t *) i2c_ioctl_args.p_params[5]));
      break;
   case I2C_IOCTL_WRITE_SUB_ADDR_EX_ASYNC:
      i2c_ioctl_args.result = (unsigned long) idl_i2c_write_sub_addr_ex_async(
         (idl_i2c_read_write_async_handle_t *) i2c_ioctl_args.p_params[0],
         *((uint8_t *) i2c_ioctl_args.p_params[1]),
         *((uint16_t *) i2c_ioctl_args.p_params[2]),
         (uint8_t *) i2c_ioctl_args.p_params[3],
         *((uint32_t *) i2c_ioctl_args.p_params[4]),
         (uint8_t *) i2c_ioctl_args.p_params[5],
         *((uint32_t *) i2c_ioctl_args.p_params[6]));
      break;

   case I2C_IOCTL_INTERRUPT_EVENT_WAIT:
      mutex_unlock(&ioctl_mutex);
      i2c_ioctl_args.result = (unsigned long) i2c_interrupt_event_wait(
         *((uint8_t *) i2c_ioctl_args.p_params[0]));
      goto out;
   case I2C_IOCTL_INTERRUPT_EVENT_DONE:
      i2c_ioctl_args.result = (unsigned long) i2c_interrupt_event_done(
         *((uint8_t *) i2c_ioctl_args.p_params[0]));
      break;
   case I2C_IOCTL_INTERRUPT_EVENT_EXIT:
      i2c_ioctl_args.result = (unsigned long) i2c_interrupt_event_exit(
         *((uint8_t *) i2c_ioctl_args.p_params[0]));
      break;

   default:
      /* POSIX compliance return returning -ENOTTY if invalid */
      status = -ENOTTY;
   }

   mutex_unlock(&ioctl_mutex);

out:
   /* Copy kernel-space parameters back to user space */
   if ((status = copy_to_user((void *) p_args, &i2c_ioctl_args, 
      sizeof(i2c_ioctl_args_t))) != 0) {
         return status;
   }

   return status;
}
