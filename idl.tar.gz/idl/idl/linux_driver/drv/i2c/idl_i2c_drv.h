/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*------------------------------------------------------------------------------
 * File Name: idl_i2c_drv.h
 *------------------------------------------------------------------------------
 *
 */

#ifndef _IDL_I2C_DRV_H_
#define _IDL_I2C_DRV_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @weakgroup idl_i2c_drv I2C Driver for Linux 2.6 */
/*@{*/

#include <linux/ioctl.h>

/* IOCTL defintions */
/* See /usr/src/linux/Documentation/ioctl-number.txt */
#define I2C_IOCTL_MAGIC                         0xD1

#define I2C_IOCTL_GET_BUS_COUNT                 _IO(I2C_IOCTL_MAGIC, 0)
#define I2C_IOCTL_OPEN                          _IO(I2C_IOCTL_MAGIC, 1)
#define I2C_IOCTL_CLOSE                         _IO(I2C_IOCTL_MAGIC, 2)
#define I2C_IOCTL_RESET                         _IO(I2C_IOCTL_MAGIC, 3)
#define I2C_IOCTL_SET_MODE                      _IO(I2C_IOCTL_MAGIC, 4)
#define I2C_IOCTL_ENABLE_POLLING                _IO(I2C_IOCTL_MAGIC, 5)
#define I2C_IOCTL_READ_BYTE                     _IO(I2C_IOCTL_MAGIC, 6)
#define I2C_IOCTL_WRITE_BYTE                    _IO(I2C_IOCTL_MAGIC, 7)
#define I2C_IOCTL_SET_INTERRUPT_MASK            _IO(I2C_IOCTL_MAGIC, 8)
#define I2C_IOCTL_GET_INTERRUPT_MASK            _IO(I2C_IOCTL_MAGIC, 9)
#define I2C_IOCTL_GET_PENDING_INTERRUPTS        _IO(I2C_IOCTL_MAGIC, 10)
#define I2C_IOCTL_REGISTER_INTERRUPT_HANDLER    _IO(I2C_IOCTL_MAGIC, 11)
#define I2C_IOCTL_RELEASE_INTERRUPT_HANDLER     _IO(I2C_IOCTL_MAGIC, 12)
#define I2C_IOCTL_WAIT_FOR_INTERRUPTS           _IO(I2C_IOCTL_MAGIC, 13)
#define I2C_IOCTL_READ                          _IO(I2C_IOCTL_MAGIC, 14)
#define I2C_IOCTL_READ_RESTART                  _IO(I2C_IOCTL_MAGIC, 15)
#define I2C_IOCTL_READ_SUB_ADDR                 _IO(I2C_IOCTL_MAGIC, 16)
#define I2C_IOCTL_READ_SUB_ADDR_EX              _IO(I2C_IOCTL_MAGIC, 17)
#define I2C_IOCTL_WRITE                         _IO(I2C_IOCTL_MAGIC, 18)
#define I2C_IOCTL_WRITE_RESTART                 _IO(I2C_IOCTL_MAGIC, 19)
#define I2C_IOCTL_WRITE_SUB_ADDR                _IO(I2C_IOCTL_MAGIC, 20)
#define I2C_IOCTL_WRITE_SUB_ADDR_EX             _IO(I2C_IOCTL_MAGIC, 21)
#define I2C_IOCTL_READ_WRITE_ASYNC_WAIT         _IO(I2C_IOCTL_MAGIC, 22)
#define I2C_IOCTL_READ_ASYNC                    _IO(I2C_IOCTL_MAGIC, 23)
#define I2C_IOCTL_READ_SUB_ADDR_ASYNC           _IO(I2C_IOCTL_MAGIC, 24)
#define I2C_IOCTL_READ_SUB_ADDR_EX_ASYNC        _IO(I2C_IOCTL_MAGIC, 25)
#define I2C_IOCTL_WRITE_ASYNC                   _IO(I2C_IOCTL_MAGIC, 26)
#define I2C_IOCTL_WRITE_SUB_ADDR_ASYNC          _IO(I2C_IOCTL_MAGIC, 27)
#define I2C_IOCTL_WRITE_SUB_ADDR_EX_ASYNC       _IO(I2C_IOCTL_MAGIC, 28)
#define I2C_IOCTL_ENABLE_YIELD                  _IO(I2C_IOCTL_MAGIC, 29)

/* Private IOCTLs used for testing-purpose only */
#define I2C_IOCTL_INTERRUPT_EVENT_WAIT         _IO(I2C_IOCTL_MAGIC, 45)
#define I2C_IOCTL_INTERRUPT_EVENT_DONE         _IO(I2C_IOCTL_MAGIC, 46)
#define I2C_IOCTL_INTERRUPT_EVENT_EXIT         _IO(I2C_IOCTL_MAGIC, 47)

/* One defined structure for all ioctl calls. */
#define I2C_MAX_ARGS    10

typedef struct
{
   unsigned int p_params[I2C_MAX_ARGS];
   unsigned int result;
} i2c_ioctl_args_t;

/*@}*/

#ifdef __cplusplus
}
#endif

#endif
