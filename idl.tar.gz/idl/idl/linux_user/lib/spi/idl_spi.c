/*
#
# This file is provided under a dual BSD/LGPLv2.1 license.  When using 
# or redistributing this file, you may do so under either license.
#
# LGPL LICENSE SUMMARY
#
# Copyright(c) 2007-2011. Intel Corporation. All rights reserved.
#
# This program is free software; you can redistribute it and/or modify 
# it under the terms of version 2.1 of the GNU Lesser General Public 
# License as published by the Free Software Foundation.
#
# This library is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public 
# License along with this library; if not, write to the Free Software 
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 
# USA. The full GNU Lesser General Public License is included in this 
# distribution in the file called LICENSE.LGPL.
#
# Contact Information:
#     Intel Corporation
#     2200 Mission College Blvd.
#     Santa Clara, CA  97052
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*----------------------------------------------------------------------
 * File Name:       idl_spi.c
 * $Revision: 0.1 $
 *----------------------------------------------------------------------
 */


#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <pthread.h>

#include "osal_memmap.h"
#include "osal_io.h"
#include "osal_thread.h"
#include "_spi.h"
#include "idl_spi_drv.h"
#include "idl.h"
#include "idl_spi.h"

//the irq does not use in user mode, define it just to avoid "undefined reference" issue in _spi.c
uint32_t spi_irq;

typedef struct spi_port_state 
{
	spi_callback_t callback_function;
	void *callback_data;
	os_thread_t event_thread;
	int m_fd;
	 int m_port_num; // for static scoped access
	 os_sema_t m_sema;
} spi_port_state;

static spi_port_state sps[ NUM_SPI_PORTS];

static volatile unsigned int state_change_in_progress = 0;

#define BLOCK_THREAD() os_sema_get( &(sps[spi_port_num].m_sema));
#define UNBLOCK_THREAD() os_sema_put( &(sps[spi_port_num].m_sema));

static unsigned int spi_state_is_initialized = 0;
static unsigned int spi_thread_is_created = 0;

static void *spi_event_thread( void *param ) ;

static int spi_open_fd (uint32_t spi_port_num)
{
	char  devbuf[128];
	const char *pathname;
	
	if (sps[spi_port_num].m_fd > 0)
		return sps[spi_port_num].m_fd;
	sprintf(devbuf, "/dev/spi%d",spi_port_num);
	pathname = devbuf;
	sps[spi_port_num].m_fd = open(pathname, O_RDWR);
	if (sps[spi_port_num].m_fd == -1){
		perror("spi_open_fd");
	}
	return (sps[spi_port_num].m_fd  );
}


idl_result_t idl_spi_init( uint32_t spi_port_num ) 
{
	idl_result_t status = IDL_NOT_IMPLEMENTED;
	int i;
	spi_ioctl_args a;
	int ioctl_error;

	if ( spi_port_num  >=  NUM_SPI_PORTS){
		OS_DEBUG("idl_spi_init: spi_port_num = %u, NUM_SPI_PORTS = %u\n", spi_port_num, NUM_SPI_PORTS);
		status = IDL_INVALID_PARAM;
		return status ;
	} else if( !(spi_thread_is_created & (1 << spi_port_num))) {
	// create the thread for this port
		os_sema_init( &(sps[spi_port_num].m_sema), 1);
		spi_thread_is_created |= 1 << spi_port_num;
		//since the IRQ not support for SPI,temp comment the event thread.
		/* 
		if ( (os_thread_create( &(sps[spi_port_num].event_thread), spi_event_thread,(void *)&(sps[spi_port_num].m_port_num), 0, 0 NULL) != OSAL_SUCCESS))
		{
			spi_thread_is_created &= ~(1 << spi_port_num);
			return IDL_FAILURE;
		}
	        */
		if( spi_open_fd(spi_port_num) < 0)
		{
			OS_DEBUG("idl_spi_init: Unable to attach to driver\n");
			UNBLOCK_THREAD();
			return IDL_NOT_INITIALIZED;
		}
	}

	BLOCK_THREAD();
	if ( !(spi_state_is_initialized & (1 << spi_port_num))){
	
		// loop was removed because the init is for the specified port "spi_port_num" not all ports (if there were more)
		sps[spi_port_num].callback_function=NULL;
		sps[spi_port_num].callback_data=NULL;
		sps[spi_port_num].m_port_num = spi_port_num; // this ensure that the callback thread has access to the port number
		spi_state_is_initialized |= 1 << spi_port_num;
		state_change_in_progress  &= ~(1 << spi_port_num);;
	}
	
	//make an ioctl call to initialize the spi
	a.spi_num= spi_port_num;
	a.pdata= NULL;
	a.result = IDL_NOT_IMPLEMENTED;
	
	ioctl_error = ioctl(sps[spi_port_num].m_fd, SPI_IOCTL_INIT, &a);
	if (ioctl_error < 0)
	{
		OS_DEBUG("idl_spi_init: IO Error = 0x%x Driver Error = 0x%x  M_FD = 0x%x\n\r", a.result, ioctl_error, sps[spi_port_num].m_fd);
	}
	UNBLOCK_THREAD();
	status=a.result;
	return ( status );
}

idl_result_t idl_spi_set_config(uint32_t spi_port_num, spi_config_t *spi_config)
{
	
	int spi_fd =-1;
	spi_ioctl_args a;
	idl_result_t status = IDL_FAILURE;

	if(NULL == spi_config) {
		OS_DEBUG("idl_spi_set_config: The second parameter, spi_config_t *, is NULL!\n");
		status = IDL_INVALID_PARAM;
		return status ;
	}

	if ( spi_port_num  >=  NUM_SPI_PORTS){
		OS_DEBUG("idl_spi_set_config: spi_port_num = %u, NUM_SPI_PORTS = %u\n", spi_port_num, NUM_SPI_PORTS);
		status = IDL_INVALID_PARAM;
		return status ;
	}
	else if (sps[spi_port_num].m_fd < 0)
	{
		OS_DEBUG("idl_spi_set_config: Unable to attach to driver\n");
	       return IDL_NOT_INITIALIZED;
	 }
	
	spi_fd =sps[spi_port_num].m_fd;
	a.spi_num= spi_port_num;
	a.pdata = (void *)spi_config;
	a.result = IDL_NOT_IMPLEMENTED;
	if (ioctl(spi_fd, SPI_IOCTL_SET_CONFIG, &a) < 0)
	{
		OS_DEBUG("idl_spi_set_config: IO Error = 0x%x\n\r",a.result);
	}
	status=a.result;

	if(IDL_SUCCESS != status) {
		OS_DEBUG("idl_spi_set_config: after ioctl status != IDL_SUCCESS; status = 0x%08X\n", status);
	}

	return ( status );
}


idl_result_t idl_spi_get_status(uint32_t spi_port_num, spi_status_t *spi_status)
{
	int spi_fd =-1;
	spi_ioctl_args a;
	idl_result_t status = IDL_FAILURE;
	
	if(NULL == spi_status) {
		OS_DEBUG("idl_spi_get_status: The second parameter, spi_status_t *, is NULL!\n");
		status = IDL_INVALID_PARAM;
		return status ;
	}

	if ( spi_port_num  >=  NUM_SPI_PORTS){
		OS_DEBUG("idl_spi_get_status: spi_port_num = %u, NUM_SPI_PORTS = %u\n", spi_port_num, NUM_SPI_PORTS);
		status = IDL_INVALID_PARAM;
		return status ;
	}
	else if (sps[spi_port_num].m_fd < 0)
	{
		OS_DEBUG("idl_spi_get_status: Unable to attach to driver\n");
	       return IDL_NOT_INITIALIZED;
	 }

	spi_fd =sps[spi_port_num].m_fd;
	a.spi_num= spi_port_num;
	a.pdata = (void *)spi_status;
	a.result = IDL_NOT_IMPLEMENTED;
	if (ioctl(spi_fd, SPI_IOCTL_GET_STATUS, &a) < 0)
	{
		OS_DEBUG("idl_spi_get_status: IO Error = 0x%x\n\r",a.result);
	}
	status=a.result;
	return ( status );
}

//callback_data is pData from spi_ioctl::SPI_IOCTL_GET_STATUS
idl_result_t idl_spi_set_event_callback(uint32_t spi_port_num, spi_callback_t callback_function, void *callback_data)
{
	int spi_fd =-1;
	spi_ioctl_args a;
	idl_result_t status = IDL_FAILURE;

	if ( spi_port_num  >=  NUM_SPI_PORTS){
		status = IDL_INVALID_PARAM;
		return status ;
	}
	else if (sps[spi_port_num].m_fd < 0)
	{
		return IDL_NOT_INITIALIZED;
	}

	BLOCK_THREAD();
	
	spi_fd =sps[spi_port_num].m_fd;
	a.spi_num= spi_port_num;
	a.pdata = callback_function;
	a.result = IDL_NOT_IMPLEMENTED;
	if (ioctl(spi_fd, SPI_IOCTL_SET_CALLBACK, &a) < 0)
	{
		OS_DEBUG("idl_spi_set_event_callback: IO Error = 0x%x\r\n",a.result);
	}
	status=a.result;

	if(status == IDL_SUCCESS)
	{
		sps[spi_port_num].callback_function = callback_function;
		sps[spi_port_num].callback_data = callback_data;
	}

	UNBLOCK_THREAD();
	
	return (status );
}

idl_result_t idl_spi_release(uint32_t spi_port_num)
{
	int spi_fd =-1;
	spi_ioctl_args a;
	idl_result_t status = IDL_FAILURE;

	
	if ( spi_port_num  >=  NUM_SPI_PORTS ){
		OS_DEBUG("idl_spi_release: Invalid SPI Port=%d\n\r",spi_port_num);
		status = IDL_INVALID_PARAM;
	}
	else if ( sps[spi_port_num].m_fd < 0) {
		status = IDL_NOT_INITIALIZED;
	        // ensure initialized state boolean is not set
	        spi_state_is_initialized &= ~(1 << spi_port_num);
	}
	else {
		BLOCK_THREAD();
		
		//make an ioctl call to release spi device
		spi_fd =sps[spi_port_num].m_fd;
		a.spi_num= spi_port_num;
		a.result = IDL_NOT_IMPLEMENTED;
		if (ioctl(spi_fd, SPI_IOCTL_RELEASE, &a) < 0)
		{
			OS_DEBUG("idl_spi_release: IO Error = 0x%x\n\r",a.result);
		}
		status=a.result;
		//make sure thread is destroyed
		if ( sps[spi_port_num].callback_function!=NULL){
			sps[spi_port_num].callback_function =NULL;
		}
	        // uninitialize the state of port
		spi_state_is_initialized &= ~(1 << spi_port_num);
		
		UNBLOCK_THREAD();
	}
	
	
	return ( status );
}

idl_result_t idl_spi_event_enable( uint32_t spi_port_num, spi_event_t spi_events )
{
	int spi_fd =-1;
	spi_ioctl_args a;
	idl_result_t status = IDL_FAILURE;

	if ( spi_port_num  >=  NUM_SPI_PORTS){
		status = IDL_INVALID_PARAM;
	}  else{
	
		
		if (!(spi_state_is_initialized & (1 << spi_port_num))|| (sps[spi_port_num].m_fd < 0))
		{
			OS_DEBUG("idl_spi_event_enable: Unable to attach to driver\n");
			status = IDL_NOT_INITIALIZED;
		} /* ioctl is not going to check if callback_function == NULL*/
		
		else
		{
			spi_fd =sps[spi_port_num].m_fd;
			a.spi_num= spi_port_num;
			a.pdata = (void *)(&spi_events);
			a.result = IDL_NOT_IMPLEMENTED;
			if (ioctl(spi_fd, SPI_IOCTL_SET_EVENTS, &a) < 0)
			{
			OS_DEBUG("idl_spi_event_enable: IO Error = 0x%x\n\r",a.result);
			}
			status=a.result;
		}
	}
	return( status );
}

idl_result_t idl_spi_event_disable( uint32_t spi_port_num, spi_event_t spi_events )
{
	
	int spi_fd =-1;
	spi_ioctl_args a;
	idl_result_t status = IDL_FAILURE;

	if ( spi_port_num  >=  NUM_SPI_PORTS){
		status = IDL_INVALID_PARAM;
	}
	
	else if (sps[spi_port_num].m_fd < 0)
	{
		OS_DEBUG("idl_spi_event_disable: Unable to attach to driver\n");
		status = IDL_NOT_INITIALIZED;
	}
	else
	{
		spi_fd =sps[spi_port_num].m_fd;
		a.spi_num= spi_port_num;
		a.pdata = (void *)(&spi_events);
		a.result = IDL_NOT_IMPLEMENTED;
		if (ioctl(spi_fd, SPI_IOCTL_CLEAR_EVENTS, &a) < 0)
		{
			OS_DEBUG("idl_spi_event_disable: IO Error = 0x%x\n\r",a.result);
		}
		status=a.result;	
	}
	return (status );
}

idl_result_t idl_spi_event_handled( uint32_t spi_port_num, spi_event_t handled_events )
{
	int spi_fd =-1;
	spi_ioctl_args a;
	idl_result_t status = IDL_FAILURE;

	if ( spi_port_num  >=  NUM_SPI_PORTS){
		status = IDL_INVALID_PARAM;
		return status ;
	}
	else if (sps[spi_port_num].m_fd < 0)
	{
		OS_DEBUG("idl_spi_event_handled: Unable to attach to driver\n");
	       return IDL_NOT_INITIALIZED;
	}
	spi_fd =sps[spi_port_num].m_fd;
	a.spi_num= spi_port_num;
	a.pdata = (void *)(&handled_events);
	a.result = IDL_NOT_IMPLEMENTED;
	if (ioctl(spi_fd, SPI_IOCTL_HANDLED_EVENTS, &a) < 0)
	{
		OS_DEBUG("idl_spi_event_handled: IO Error = 0x%x\n\r",a.result);
	}
	status=a.result;	
	return ( status );
}

idl_result_t idl_spi_write(uint32_t spi_port_num, uint32_t data)
{
	int spi_fd =-1;
	spi_ioctl_args a;
	idl_result_t status = IDL_FAILURE;
	
	if ( spi_port_num  >=  NUM_SPI_PORTS){
		status = IDL_INVALID_PARAM;
		return status ;
	}
	else if (sps[spi_port_num].m_fd < 0)
	{
		OS_DEBUG("idl_spi_write: Unable to attach to driver\n");
	       return IDL_NOT_INITIALIZED;
	}
	spi_fd =sps[spi_port_num].m_fd;
	a.spi_num= spi_port_num;
	a.pdata = (void *)(&data);
	a.result = IDL_NOT_IMPLEMENTED;
	if (ioctl(spi_fd, SPI_IOCTL_SPI_WRITE, &a) < 0)
	{
		OS_DEBUG("idl_spi_write: IO Error = 0x%x\n\r",a.result);
	}
	status=a.result;	
	return ( status );
}


idl_result_t idl_spi_read(uint32_t spi_port_num, uint32_t *data)
{
	int spi_fd =-1;
	spi_ioctl_args a;
	idl_result_t status = IDL_FAILURE;
	
	if ( spi_port_num  >=  NUM_SPI_PORTS){
		status = IDL_INVALID_PARAM;
		return status ;
	}
	else if (sps[spi_port_num].m_fd < 0)
	{
		OS_DEBUG("idl_spi_read: Unable to attach to driver\n");
	       return IDL_NOT_INITIALIZED;
	}
	spi_fd =sps[spi_port_num].m_fd;
	a.spi_num= spi_port_num;
	a.pdata = (void *)(data);
	a.result = IDL_NOT_IMPLEMENTED;
	if (ioctl(spi_fd, SPI_IOCTL_SPI_READ, &a) < 0)
	{
		OS_DEBUG("idl_spi_read: IO Error = 0x%x\n\r",a.result);
	}
	status=a.result;	
	return ( status );
}


//We will wait on ioctl for IRQ  
static void *spi_event_thread( void *param ) 
{
	uint32_t *port_num = (uint32_t *)param;
	uint32_t spi_port_num = *port_num;

	spi_ioctl_args a;
	a.spi_num = 0;
	a.pdata = NULL;
	a.result = 0;

	if (spi_port_num  >=  NUM_SPI_PORTS ){
		OS_DEBUG("spi_event_thread: Invalid SPI Port=%d\n\r",spi_port_num);
		return NULL;
	}
	/* wait for an ioctl to wake up */
	while ( 1 ) {
	
		// this blocks until an interrupt is detected
		if( ioctl( sps[spi_port_num].m_fd, SPI_IOCTL_WAIT_FOR_IRQ, &a)  >= 0)
		{
			BLOCK_THREAD();

			if ( sps[spi_port_num].callback_function != NULL ) {
				/* call the app callback function to process the event */
				(*(sps[spi_port_num].callback_function ))(sps[spi_port_num].callback_data);

			} 
			// unset "thread is blocking" flag 
			UNBLOCK_THREAD();

			// interrupt handling complete	
			if( ioctl( sps[spi_port_num].m_fd, SPI_IOCTL_ACK_IRQ, &a) < 0)
			{
				OS_DEBUG( "spi_event_thread: IOCTL_ACK_IRQ FAILED.\r\n");
			} 
		}  else {
			OS_DEBUG( "spi_event_thread: WAIT_FOR_IRQ FAILED.\r\n");
		}
	}
	
	return NULL;
}


