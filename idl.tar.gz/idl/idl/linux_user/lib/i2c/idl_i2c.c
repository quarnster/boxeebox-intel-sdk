/*
#
# This file is provided under a dual BSD/LGPLv2.1 license.  When using 
# or redistributing this file, you may do so under either license.
#
# LGPL LICENSE SUMMARY
#
# Copyright(c) 2007-2011. Intel Corporation. All rights reserved.
#
# This program is free software; you can redistribute it and/or modify 
# it under the terms of version 2.1 of the GNU Lesser General Public 
# License as published by the Free Software Foundation.
#
# This library is distributed in the hope that it will be useful, but 
# WITHOUT ANY WARRANTY; without even the implied warranty of 
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU 
# Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public 
# License along with this library; if not, write to the Free Software 
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 
# USA. The full GNU Lesser General Public License is included in this 
# distribution in the file called LICENSE.LGPL.
#
# Contact Information:
#     Intel Corporation
#     2200 Mission College Blvd.
#     Santa Clara, CA  97052
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*------------------------------------------------------------------------------
 * File Name: idl_i2c.c
 *------------------------------------------------------------------------------
 */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef IDL_DRIVER
#include <stdint.h>
#include <stdbool.h>
#endif

#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>

#include <unistd.h>
#include <signal.h>
#include <fcntl.h>
#include <pthread.h>

#include <osal_event.h>
#include <osal_thread.h>

#include <idl.h>
#include <idl_i2c.h>
#include <_i2c.h>
#include <idl_i2c_drv.h>

static int m_fd = -1;
static uint8_t m_cnt = 0;

/*------------------------------------------------------------------------------
 * Declarations (to support interrupt callback mechanism)
 *------------------------------------------------------------------------------
 */

static bool idl_to_keep_i2c_os_thread[_I2C_MAX_BUS_COUNT] = {true, true, true, true};
static os_thread_t i2c_os_thread[_I2C_MAX_BUS_COUNT + 1];
static void (*p_i2c_interrupt_handler[_I2C_MAX_BUS_COUNT])(uint8_t bus_num);
static void *p_i2c_interrupt_data[_I2C_MAX_BUS_COUNT];

static uint8_t i2c_bus_count = _I2C_GEN3_BUS_COUNT;

idl_result_t
idl_i2c_interrupt_event_wait(uint8_t bus_num);

idl_result_t
idl_i2c_interrupt_event_done(uint8_t bus_num);

idl_result_t
idl_i2c_interrupt_event_exit(uint8_t bus_num);

void
idl_i2c_interrupt_thread(void *p_data)
{
   uint32_t bus_num = (uint32_t) p_data;

   if (bus_num < i2c_bus_count) {
      while (idl_to_keep_i2c_os_thread[bus_num]) {
         /* Wait for interrupt notification from kernel driver */
         if (idl_i2c_interrupt_event_wait(bus_num) == _I2C_SUCCESS) {
            /* Call user interrupt handler if registered */
            if (p_i2c_interrupt_handler[bus_num] != NULL &&
               idl_to_keep_i2c_os_thread[bus_num]) {
               (*p_i2c_interrupt_handler[bus_num])(bus_num);
               /* Signal kernel handler to finish kernel interrupt processing */
               idl_i2c_interrupt_event_done(bus_num);
            }
         }
      }
   }
}

/*------------------------------------------------------------------------------
 * Declarations (to support asynchronous functions)
 *------------------------------------------------------------------------------
 */

typedef struct {
   uint32_t ioctl;
   bool has_valid_event;
   os_event_t os_event;
   i2c_ioctl_args_t args;
} i2c_async_data_t;

static os_thread_t i2c_async_thread[_I2C_MAX_BUS_COUNT];
static i2c_async_data_t i2c_async_data[_I2C_MAX_BUS_COUNT];

void
idl_i2c_async_thread(void *p_data)
{
   uint32_t bus_num = (uint32_t) p_data;

   if (m_fd > 0 && bus_num < i2c_bus_count) {
      ioctl(m_fd, i2c_async_data[bus_num].ioctl, 
         &i2c_async_data[bus_num].args);
      if (i2c_async_data[bus_num].has_valid_event) {
         os_event_set(&i2c_async_data[bus_num].os_event);
      }
   }
}

/*------------------------------------------------------------------------------
 * idl_i2c_get_bus_count
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_get_bus_count(uint8_t *p_bus_count)
{
   i2c_ioctl_args_t i2c_ioctl_args;

   /* If file descriptor has not been defined, then open a temporary pointer */
   int fd = m_fd;
   if (m_fd <= 0) {
      fd = open("/dev/i2c", O_RDWR);
      if (fd <= 0) {
         return IDL_FAILURE;
      }
   }

   i2c_ioctl_args.p_params[0] = (unsigned int) p_bus_count;
   ioctl(fd, I2C_IOCTL_GET_BUS_COUNT, &i2c_ioctl_args);
   
   /* Close any temporary file pointer */
   if (m_fd <= 0) {
      close(fd);
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_open
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_open()
{
   uint8_t bus_num;
   uint32_t bus_number;
   i2c_ioctl_args_t i2c_ioctl_args = {{0}, IDL_SUCCESS};

   m_cnt++;
   if (m_fd > 0) {
      return IDL_ALREADY_INITIALIZED;
   } else {
      m_fd = open("/dev/i2c", O_RDWR);
   }
   if (IDL_SUCCESS != idl_i2c_get_bus_count(&i2c_bus_count) ) {
      return IDL_FAILURE;
   }
         
   if (m_fd > 0) {
      /* EPC - Kicked off this extra thread because sometimes the first */
      /* thread doesn't get enabled */ 
      if (os_thread_create(&i2c_os_thread[_I2C_MAX_BUS_COUNT], 
         (void *) &idl_i2c_interrupt_thread, (void *) _I2C_MAX_BUS_COUNT, 0, 0, NULL) != 
         OSAL_SUCCESS) {
         i2c_ioctl_args.result = IDL_FAILURE;
      }
      for (bus_num = 0; bus_num < i2c_bus_count; bus_num++) {
         ioctl(m_fd, I2C_IOCTL_OPEN, &i2c_ioctl_args);
         /* Kick off a thread in user side to call the callback function */
         bus_number = bus_num;
         if (os_thread_create(&i2c_os_thread[bus_num], 
            (void *) &idl_i2c_interrupt_thread, (void *) bus_number, 0, 0, NULL) != 
            OSAL_SUCCESS) {
            i2c_ioctl_args.result = IDL_FAILURE;
         } else {
            idl_to_keep_i2c_os_thread[bus_num] = true;
            p_i2c_interrupt_handler[bus_num] = NULL;
            p_i2c_interrupt_data[bus_num] = NULL;
         }
      }
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_close
 *------------------------------------------------------------------------------
 */
idl_result_t
idl_i2c_close()
{
   uint8_t bus_num;
   i2c_ioctl_args_t i2c_ioctl_args;

   m_cnt--;
   if (m_cnt > 0) {
      i2c_ioctl_args.result = IDL_SUCCESS;
   } else {
      if (m_fd > 0) {
	 for (bus_num = 0; bus_num < i2c_bus_count; bus_num++) {
	    ioctl(m_fd, I2C_IOCTL_CLOSE, &i2c_ioctl_args);
	    idl_to_keep_i2c_os_thread[bus_num] = false;
	    p_i2c_interrupt_handler[bus_num] = NULL;
	    p_i2c_interrupt_data[bus_num] = NULL;
	    idl_i2c_interrupt_event_exit(bus_num);
	    os_thread_destroy(&i2c_os_thread[bus_num]);
	 }
	 os_thread_destroy(&i2c_os_thread[_I2C_MAX_BUS_COUNT]);
	 close(m_fd);
	 m_fd = -1;
      } else {
	 i2c_ioctl_args.result = IDL_FAILURE;
      }
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_reset
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_reset(uint8_t bus_num)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_RESET, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_set_mode
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_set_mode(uint8_t bus_num, idl_i2c_mode_t mode)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &mode;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_SET_MODE, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_enable_polling
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_enable_polling(uint8_t bus_num, bool to_poll)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &to_poll;

   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_ENABLE_POLLING, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_enable_yield
 *------------------------------------------------------------------------------
 */
idl_result_t
idl_i2c_enable_yield(uint8_t bus_num, bool to_yield)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &to_yield;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_ENABLE_YIELD, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_byte
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_byte(uint8_t bus_num, uint32_t control_flags, 
   uint8_t *p_data_byte)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &control_flags;
   i2c_ioctl_args.p_params[2] = (unsigned int) p_data_byte;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_READ_BYTE, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_byte
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_byte(uint8_t bus_num, uint32_t control_flags, uint8_t data_byte)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &control_flags;
   i2c_ioctl_args.p_params[2] = (unsigned int) &data_byte;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_WRITE_BYTE, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_set_interrupt_mask
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_set_interrupt_mask(uint8_t bus_num, uint32_t interrupt_mask)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &interrupt_mask;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_SET_INTERRUPT_MASK, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_get_interrupt_mask
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_get_interrupt_mask(uint8_t bus_num, uint32_t *p_interrupt_mask)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) p_interrupt_mask;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_GET_INTERRUPT_MASK, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_get_pending_interrupts
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_get_pending_interrupts(uint8_t bus_num, uint32_t *p_interrupt_flags)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) p_interrupt_flags;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_GET_PENDING_INTERRUPTS, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_register_interrupt_handler
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_register_interrupt_handler(uint8_t bus_num, 
   os_interrupt_handler_t *p_interrupt_handler, void *p_interrupt_data)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) p_interrupt_handler;
   i2c_ioctl_args.p_params[2] = (unsigned int) p_interrupt_data;
   if (m_fd > 0) {
      p_i2c_interrupt_handler[bus_num] = (void *) p_interrupt_handler;
      p_i2c_interrupt_data[bus_num] = p_interrupt_data;
      ioctl(m_fd, I2C_IOCTL_REGISTER_INTERRUPT_HANDLER, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_release_interrupt_handler
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_release_interrupt_handler(uint8_t bus_num)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_RELEASE_INTERRUPT_HANDLER, &i2c_ioctl_args);
      p_i2c_interrupt_handler[bus_num] = NULL;
      p_i2c_interrupt_data[bus_num] = NULL;
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_wait_for_interrupts
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_wait_for_interrupts(uint8_t bus_num, uint32_t interrupt_flags,
   uint32_t wait_condition)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &interrupt_flags;
   i2c_ioctl_args.p_params[2] = (unsigned int) &wait_condition;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_WAIT_FOR_INTERRUPTS, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read(uint8_t bus_num, uint16_t slave_addr, uint8_t *p_data_buffer, 
   uint32_t byte_count)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &slave_addr;
   i2c_ioctl_args.p_params[2] = (unsigned int) p_data_buffer;
   i2c_ioctl_args.p_params[3] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_READ, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_restart
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_restart(uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &slave_addr;
   i2c_ioctl_args.p_params[2] = (unsigned int) &sub_addr;
   i2c_ioctl_args.p_params[3] = (unsigned int) p_data_buffer;
   i2c_ioctl_args.p_params[4] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_READ_RESTART, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_sub_addr
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_sub_addr(uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &slave_addr;
   i2c_ioctl_args.p_params[2] = (unsigned int) &sub_addr;
   i2c_ioctl_args.p_params[3] = (unsigned int) p_data_buffer;
   i2c_ioctl_args.p_params[4] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_READ_SUB_ADDR, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_sub_addr_ex
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_sub_addr_ex(uint8_t bus_num, uint16_t slave_addr, 
   uint8_t *p_sub_addr, uint32_t sub_addr_byte_count,
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &slave_addr;
   i2c_ioctl_args.p_params[2] = (unsigned int) p_sub_addr;
   i2c_ioctl_args.p_params[3] = (unsigned int) &sub_addr_byte_count;
   i2c_ioctl_args.p_params[4] = (unsigned int) p_data_buffer;
   i2c_ioctl_args.p_params[5] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_READ_SUB_ADDR_EX, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write(uint8_t bus_num, uint16_t slave_addr, uint8_t *p_data_buffer, 
   uint32_t byte_count)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &slave_addr;
   i2c_ioctl_args.p_params[2] = (unsigned int) p_data_buffer;
   i2c_ioctl_args.p_params[3] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_WRITE, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_restart
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_restart(uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &slave_addr;
   i2c_ioctl_args.p_params[2] = (unsigned int) &sub_addr;
   i2c_ioctl_args.p_params[3] = (unsigned int) p_data_buffer;
   i2c_ioctl_args.p_params[4] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_WRITE_RESTART, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_sub_addr
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_sub_addr(uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &slave_addr;
   i2c_ioctl_args.p_params[2] = (unsigned int) &sub_addr;
   i2c_ioctl_args.p_params[3] = (unsigned int) p_data_buffer;
   i2c_ioctl_args.p_params[4] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_WRITE_SUB_ADDR, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_sub_addr_ex
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_sub_addr_ex(uint8_t bus_num, uint16_t slave_addr, 
   uint8_t *p_sub_addr, uint32_t sub_addr_byte_count, uint8_t *p_data_buffer, 
   uint32_t byte_count)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   i2c_ioctl_args.p_params[1] = (unsigned int) &slave_addr;
   i2c_ioctl_args.p_params[2] = (unsigned int) p_sub_addr;
   i2c_ioctl_args.p_params[3] = (unsigned int) &sub_addr_byte_count;
   i2c_ioctl_args.p_params[4] = (unsigned int) p_data_buffer;
   i2c_ioctl_args.p_params[5] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_WRITE_SUB_ADDR_EX, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_write_async_wait
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_write_async_wait(idl_i2c_read_write_async_handle_t *p_async_handle,
   uint32_t time_out_ms)
{
   uint8_t bus_num;
   bool is_valid_handle = false;
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) p_async_handle;
   i2c_ioctl_args.p_params[1] = (unsigned int) &time_out_ms;
   if (m_fd > 0) {
      for (bus_num = 0; bus_num < i2c_bus_count; bus_num++) {
         if (i2c_async_data[bus_num].has_valid_event) {
            if (os_event_wait(&i2c_async_data[bus_num].os_event, time_out_ms) !=
               OSAL_SUCCESS) {
               i2c_ioctl_args.result = IDL_FAILURE;
            } else {
               i2c_ioctl_args.result = IDL_SUCCESS;
            }
            os_event_reset(&i2c_async_data[bus_num].os_event);
            os_event_destroy(&i2c_async_data[bus_num].os_event);
            os_thread_destroy(&i2c_async_thread[bus_num]);
            i2c_async_data[bus_num].has_valid_event = false;
            is_valid_handle = true;
            break;
         }
      }
      if (! is_valid_handle) {
         i2c_ioctl_args.result = IDL_FAILURE;
      }
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_async(idl_i2c_read_write_async_handle_t *p_async_handle, 
   uint8_t bus_num, uint16_t slave_addr, uint8_t *p_data_buffer,
   uint32_t byte_count)
{
   uint32_t bus_number = bus_num;
   idl_result_t result = IDL_FAILURE;
   i2c_async_data[bus_num].args.p_params[0] = (unsigned int) &bus_num;
   i2c_async_data[bus_num].args.p_params[1] = (unsigned int) &slave_addr;
   i2c_async_data[bus_num].args.p_params[2] = (unsigned int) p_data_buffer;
   i2c_async_data[bus_num].args.p_params[3] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      i2c_async_data[bus_num].ioctl = I2C_IOCTL_READ;
      i2c_async_data[bus_num].has_valid_event = true;
      os_event_create(&i2c_async_data[bus_num].os_event, 0);
      if (os_thread_create(&i2c_async_thread[bus_num], 
         (void *) &idl_i2c_async_thread, (void *) bus_number, 0, 0, NULL) == 
         OSAL_SUCCESS) {
         result = IDL_SUCCESS;
      }
   } else {
      /* Return success to mimic static library case */
      result = IDL_SUCCESS;
   }
   return result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_sub_addr_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_sub_addr_async(idl_i2c_read_write_async_handle_t *p_async_handle, 
   uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   uint32_t bus_number = bus_num;
   idl_result_t result = IDL_FAILURE;
   i2c_async_data[bus_num].args.p_params[0] = (unsigned int) &bus_num;
   i2c_async_data[bus_num].args.p_params[1] = (unsigned int) &slave_addr;
   i2c_async_data[bus_num].args.p_params[2] = (unsigned int) &sub_addr;
   i2c_async_data[bus_num].args.p_params[3] = (unsigned int) p_data_buffer;
   i2c_async_data[bus_num].args.p_params[4] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      i2c_async_data[bus_num].ioctl = I2C_IOCTL_READ_SUB_ADDR;
      i2c_async_data[bus_num].has_valid_event = true;
      os_event_create(&i2c_async_data[bus_num].os_event, 0);
      if (os_thread_create(&i2c_async_thread[bus_num], 
         (void *) &idl_i2c_async_thread, (void *) bus_number, 0, 0, NULL) == 
         OSAL_SUCCESS) {
         result = IDL_SUCCESS;
      }
   } else {
      /* Return success to mimic static library case */
      result = IDL_SUCCESS;
   }
   return result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_sub_addr_ex_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_sub_addr_ex_async(idl_i2c_read_write_async_handle_t 
   *p_async_handle, uint8_t bus_num, uint16_t slave_addr, uint8_t *p_sub_addr, 
   uint32_t sub_addr_byte_count, uint8_t *p_data_buffer, uint32_t byte_count)
{
   uint32_t bus_number = bus_num;
   idl_result_t result = IDL_FAILURE;
   i2c_async_data[bus_num].args.p_params[0] = (unsigned int) &bus_num;
   i2c_async_data[bus_num].args.p_params[1] = (unsigned int) &slave_addr;
   i2c_async_data[bus_num].args.p_params[2] = (unsigned int) p_sub_addr;
   i2c_async_data[bus_num].args.p_params[3] = 
      (unsigned int) &sub_addr_byte_count;
   i2c_async_data[bus_num].args.p_params[4] = (unsigned int) p_data_buffer;
   i2c_async_data[bus_num].args.p_params[5] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      i2c_async_data[bus_num].ioctl = I2C_IOCTL_READ_SUB_ADDR_EX;
      i2c_async_data[bus_num].has_valid_event = true;
      os_event_create(&i2c_async_data[bus_num].os_event, 0);
      if (os_thread_create(&i2c_async_thread[bus_num], 
         (void *) &idl_i2c_async_thread, (void *) bus_number, 0, 0, NULL) == 
         OSAL_SUCCESS) {
         result = IDL_SUCCESS;
      }
   } else {
      /* Return success to mimic static library case */
      result = IDL_SUCCESS;
   }
   return result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_async(idl_i2c_read_write_async_handle_t *p_async_handle, 
   uint8_t bus_num, uint16_t slave_addr, uint8_t *p_data_buffer, 
   uint32_t byte_count)
{
   uint32_t bus_number = bus_num;
   idl_result_t result = IDL_FAILURE;
   i2c_async_data[bus_num].args.p_params[0] = (unsigned int) &bus_num;
   i2c_async_data[bus_num].args.p_params[1] = (unsigned int) &slave_addr;
   i2c_async_data[bus_num].args.p_params[2] = (unsigned int) p_data_buffer;
   i2c_async_data[bus_num].args.p_params[3] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      i2c_async_data[bus_num].ioctl = I2C_IOCTL_WRITE;
      i2c_async_data[bus_num].has_valid_event = true;
      os_event_create(&i2c_async_data[bus_num].os_event, 0);
      if (os_thread_create(&i2c_async_thread[bus_num], 
         (void *) &idl_i2c_async_thread, (void *) bus_number, 0, 0, NULL) == 
         OSAL_SUCCESS) {
         result = IDL_SUCCESS;
      }
   } else {
      /* Return success to mimic static library case */
      result = IDL_SUCCESS;
   }
   return result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_sub_addr_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_sub_addr_async(idl_i2c_read_write_async_handle_t *p_async_handle, 
   uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   uint32_t bus_number = bus_num;
   idl_result_t result = IDL_FAILURE;
   i2c_async_data[bus_num].args.p_params[0] = (unsigned int) &bus_num;
   i2c_async_data[bus_num].args.p_params[1] = (unsigned int) &slave_addr;
   i2c_async_data[bus_num].args.p_params[2] = (unsigned int) &sub_addr;
   i2c_async_data[bus_num].args.p_params[3] = (unsigned int) p_data_buffer;
   i2c_async_data[bus_num].args.p_params[4] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      i2c_async_data[bus_num].ioctl = I2C_IOCTL_WRITE_SUB_ADDR;
      i2c_async_data[bus_num].has_valid_event = true;
      os_event_create(&i2c_async_data[bus_num].os_event, 0);
      if (os_thread_create(&i2c_async_thread[bus_num], 
         (void *) &idl_i2c_async_thread, (void *) bus_number, 0, 0, NULL) == 
         OSAL_SUCCESS) {
         result = IDL_SUCCESS;
      }
   } else {
      /* Return success to mimic static library case */
      result = IDL_SUCCESS;
   }
   return result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_sub_addr_ex_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_sub_addr_ex_async(idl_i2c_read_write_async_handle_t 
   *p_async_handle, uint8_t bus_num, uint16_t slave_addr, uint8_t *p_sub_addr, 
   uint32_t sub_addr_byte_count, uint8_t *p_data_buffer, uint32_t byte_count)
{
   uint32_t bus_number = bus_num;
   idl_result_t result = IDL_FAILURE;
   i2c_async_data[bus_num].args.p_params[0] = (unsigned int) &bus_num;
   i2c_async_data[bus_num].args.p_params[1] = (unsigned int) &slave_addr;
   i2c_async_data[bus_num].args.p_params[2] = (unsigned int) p_sub_addr;
   i2c_async_data[bus_num].args.p_params[3] = 
      (unsigned int) &sub_addr_byte_count;
   i2c_async_data[bus_num].args.p_params[4] = (unsigned int) p_data_buffer;
   i2c_async_data[bus_num].args.p_params[5] = (unsigned int) &byte_count;
   if (m_fd > 0) {
      i2c_async_data[bus_num].ioctl = I2C_IOCTL_WRITE_SUB_ADDR_EX;
      i2c_async_data[bus_num].has_valid_event = true;
      os_event_create(&i2c_async_data[bus_num].os_event, 0);
      if (os_thread_create(&i2c_async_thread[bus_num], 
         (void *) &idl_i2c_async_thread, (void *) bus_number, 0, 0, NULL) == 
         OSAL_SUCCESS) {
         result = IDL_SUCCESS;
      }
   } else {
      /* Return success to mimic static library case */
      result = IDL_SUCCESS;
   }
   return result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_interrupt_event_wait
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_interrupt_event_wait(uint8_t bus_num)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_INTERRUPT_EVENT_WAIT, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_interrupt_event_done
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_interrupt_event_done(uint8_t bus_num)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_INTERRUPT_EVENT_DONE, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_interrupt_event_exit
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_interrupt_event_exit(uint8_t bus_num)
{
   i2c_ioctl_args_t i2c_ioctl_args;
   i2c_ioctl_args.p_params[0] = (unsigned int) &bus_num;
   if (m_fd > 0) {
      ioctl(m_fd, I2C_IOCTL_INTERRUPT_EVENT_EXIT, &i2c_ioctl_args);
   } else {
      i2c_ioctl_args.result = IDL_FAILURE;
   }
   return (idl_result_t) i2c_ioctl_args.result;
}

#ifdef __cplusplus
}
#endif
