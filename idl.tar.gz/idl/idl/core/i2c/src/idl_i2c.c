/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*------------------------------------------------------------------------------
 * File Name: idl_i2c.c
 *------------------------------------------------------------------------------
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

#ifndef LINUX_DRIVER
#include <stdint.h>
#include <stdbool.h>
#endif

#include <osal_event.h>
#include <osal_interrupt.h>
#include <osal_memmap.h>
#include <osal_memory.h>
#include <osal_thread.h>

#ifdef LINUX_DRIVER
#include <osal_sema.h>
//typedef void * os_thread_t;
#else
//#include <osal_thread.h>
#endif

#include <_i2c.h>
#include <idl_i2c.h>

#define IDL_I2C_WAIT_CONDITION      0x00001000

#ifdef LINUX_DRIVER
/* EPC - Define this to enable Linux kernel thread, which appears unstable */
//#define IDL_I2C_ENABLE_KTHREAD
#endif

/*------------------------------------------------------------------------------
 * idl_i2c_read_write_async_data_t
 *------------------------------------------------------------------------------
 */

typedef struct {
   bool to_read;
   uint8_t bus_num;
   uint16_t slave_addr;
   uint8_t *p_sub_addr;
   uint32_t sub_addr_byte_count;
   uint8_t *p_write_data_buffer;
   uint32_t write_byte_count;
   uint8_t *p_read_data_buffer;
   uint32_t read_byte_count;
   bool to_use_sub_addr;
   os_event_t *p_os_event;
   os_thread_t *p_os_thread;
   idl_result_t result;
} idl_i2c_read_write_async_data_t;

typedef struct {
   uint8_t bus_num;
   bool is_registered;
   os_event_t *p_os_event;
   uint32_t interrupt_flags;
} idl_i2c_interrupt_data_t;

/*------------------------------------------------------------------------------
 * Global declarations
 *------------------------------------------------------------------------------
 */

typedef struct {
   bool to_poll;
   idl_i2c_interrupt_data_t interrupt_data;
   bool to_yield;
} idl_i2c_state_t;

static idl_i2c_state_t *p_idl_i2c_state = NULL;
static os_sema_t *p_idl_i2c_semaphores = NULL;

#ifdef IDL_I2C_ENABLE_KTHREAD
/* EPC - Only allow up to the following count of threads running */
/* Before overwriting the oldest thread */
#define IDL_I2C_OS_EVENT_COUNT   100
static uint32_t idl_i2c_os_event_index = 0;
static os_event_t idl_i2c_os_event[IDL_I2C_OS_EVENT_COUNT];
#endif

/*------------------------------------------------------------------------------
 * Private functions
 * - idl_i2c_return_code:
 *    This function converts _i2c_result_t to idl_result_t.
 * - idl_i2c_write_read_ex:
 *    This function supports:
 *    - idl_i2c_read, idl_i2c_read_restart, idl_i2c_read_sub_addr, 
 *       idl_i2c_read_sub_addr_ex
 *    - idl_i2c_write, idl_i2c_write_restart, idl_i2c_write_sub_addr, 
 *       idl_i2c_write_sub_addr_ex
 * - idl_i2c_read_write_async
 *    This is a thread function to perform:
 *    - idl_i2c_read_async, idl_i2c_read_sub_addr_async, 
 *       idl_i2c_read_sub_addr_ex_async
 *    - idl_i2c_write_async, idl_i2c_write_sub_addr_async, 
 *       idl_i2c_write_sub_addr_ex_async
 * - idl_i2c_get_semaphore:
 *    This function gets a semaphore for the specified bus.
 * - idl_i2c_put_semaphore:
 *    This function puts/releases a semaphore for the specificed bus.
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_return_code(_i2c_result_t result);

idl_result_t
idl_i2c_write_read_ex(uint8_t bus_num, uint16_t slave_addr, 
   uint8_t *p_sub_addr, uint32_t sub_addr_byte_count,
   uint8_t *p_write_data_buffer, uint32_t write_byte_count, 
   uint8_t *p_read_data_buffer, uint32_t read_byte_count);

void
idl_i2c_read_write_async(void *p_data);

idl_result_t
idl_i2c_get_semaphore(uint8_t bus_num);

idl_result_t
idl_i2c_put_semaphore(uint8_t bus_num);

/*------------------------------------------------------------------------------
 * idl_i2c_return_code
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_return_code(_i2c_result_t result)
{
   switch (result) {
   case _I2C_SUCCESS:
      return IDL_SUCCESS;
   case _I2C_INVALID_PARAM:
      return IDL_INVALID_PARAM;
   case _I2C_NOT_INITIALIZED:
      return IDL_NOT_INITIALIZED;
   case _I2C_ALREADY_INITIALIZED:
      return IDL_ALREADY_INITIALIZED;
   case _I2C_FAILURE:
      return IDL_FAILURE;
   case _I2C_NOT_IMPLEMENTED:
      return IDL_NOT_IMPLEMENTED;
   case _I2C_DEVICE_BUSY:
      return IDL_DEVICE_BUSY;
   default:
      return IDL_FAILURE;
   }
}

/*------------------------------------------------------------------------------
 * idl_i2c_get_bus_count
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_get_bus_count(uint8_t *p_bus_count)
{
   return idl_i2c_return_code(_i2c_get_bus_count(p_bus_count));
}
/*------------------------------------------------------------------------------
 * Interrupt-related declarations
 * - idl_i2c_interrupt_data_t
 * - idl_i2c_interrupt_handler
 *------------------------------------------------------------------------------
 */

void
idl_i2c_interrupt_handler(void *p_interrupt_data)
{
   uint32_t interrupts=0;
   idl_i2c_interrupt_data_t *p_data = (idl_i2c_interrupt_data_t *)p_interrupt_data;
   _i2c_read_interrupts_status(p_data->bus_num, &interrupts);
   if (interrupts & (p_data->interrupt_flags) ){
	if(idl_i2c_return_code(_i2c_clear_interrupts(p_data->bus_num, interrupts & p_data->interrupt_flags)) != IDL_SUCCESS){
	   return;
        }
	os_event_set(p_data->p_os_event);
   }
	
}


/*------------------------------------------------------------------------------
 * idl_i2c_open
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_open()
{
   uint8_t bus_num, bus_count;
   idl_result_t result;

   if ((result = idl_i2c_return_code(_i2c_open())) == IDL_SUCCESS) {
      if (_i2c_get_bus_count(&bus_count) != _I2C_SUCCESS) {
         goto exception;
      }
      if ((p_idl_i2c_state = (idl_i2c_state_t *) OS_ALLOC(bus_count * 
         sizeof(idl_i2c_state_t))) == NULL) {
         goto exception;
      }

      /* Initialize state information for each bus */
      for (bus_num = 0; bus_num < bus_count; bus_num++) {
         p_idl_i2c_state[bus_num].to_poll = true;
         p_idl_i2c_state[bus_num].interrupt_data.bus_num = bus_num;
         p_idl_i2c_state[bus_num].to_yield = true;

         if ((p_idl_i2c_state[bus_num].interrupt_data.p_os_event = 
            (os_event_t *) OS_ALLOC(sizeof(os_event_t))) == NULL) {
            OS_FREE(p_idl_i2c_state);
            goto exception;
         }
         os_event_create(p_idl_i2c_state[bus_num].interrupt_data.p_os_event, 
            0);
      }

      /* Initialize one semaphore for each bus */
      if ((p_idl_i2c_semaphores = (os_sema_t *) OS_ALLOC((bus_count + 1) * 
         sizeof(os_sema_t))) == NULL) {
         for (bus_num = 0; bus_num < bus_count; bus_num++) {
            os_event_destroy(p_idl_i2c_state[bus_num].interrupt_data.p_os_event);
            OS_FREE(p_idl_i2c_state[bus_num].interrupt_data.p_os_event);
         }
         OS_FREE(p_idl_i2c_state);
         goto exception;
      }
      for (bus_num = 0; bus_num < bus_count + 1; bus_num++) {
         os_sema_init(&p_idl_i2c_semaphores[bus_num], 1);
      }
     /* Set default interrupt register status */
      for (bus_num = 0; bus_num < bus_count; bus_num++) {
         p_idl_i2c_state[bus_num].interrupt_data.is_registered = false;
      }
   } else if (result == IDL_ALREADY_INITIALIZED) {
      result = IDL_SUCCESS;
   }

   return result;

exception:
   p_idl_i2c_state = NULL;
   return IDL_FAILURE;
}

/*------------------------------------------------------------------------------
 * idl_i2c_close
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_close()
{
   uint8_t bus_num, bus_count;
   idl_result_t result;

   if ((result = idl_i2c_return_code(_i2c_close())) == IDL_SUCCESS) {
      /* Destroy allocated bus semaphores */
      if (_i2c_get_bus_count(&bus_count) != _I2C_SUCCESS) {
         return IDL_FAILURE;
      } else {
         if (p_idl_i2c_semaphores != NULL) {
            for (bus_num = 0; bus_num < bus_count + 1; bus_num++) {
               os_sema_destroy(&p_idl_i2c_semaphores[bus_num]);
            }
	    OS_FREE(p_idl_i2c_semaphores);
            p_idl_i2c_semaphores = NULL;
         }
      }

      for (bus_num = 0; bus_num < bus_count; bus_num++) {
         idl_i2c_release_interrupt_handler(bus_num);
      }

      if (p_idl_i2c_state != NULL) {
         for (bus_num = 0; bus_num < bus_count; bus_num++) {
            os_event_destroy(p_idl_i2c_state[bus_num].
               interrupt_data.p_os_event);
            OS_FREE(p_idl_i2c_state[bus_num].interrupt_data.p_os_event);
         }
         OS_FREE(p_idl_i2c_state);
         p_idl_i2c_state = NULL;
      }
   } else if (result == IDL_DEVICE_BUSY) {
      result = IDL_SUCCESS;
   }
   return result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_reset
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_reset(uint8_t bus_num)
{
   return idl_i2c_return_code(_i2c_reset(bus_num));
}

/*------------------------------------------------------------------------------
 * idl_i2c_set_mode
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_set_mode(uint8_t bus_num, idl_i2c_mode_t mode)
{
   _i2c_mode_t i2c_mode;
   if (mode == IDL_I2C_MODE_STANDARD) {
      i2c_mode = _I2C_MODE_STANDARD;
   } else if (mode == IDL_I2C_MODE_FAST) {
      i2c_mode = _I2C_MODE_FAST;
   } else {
      return IDL_INVALID_PARAM;
   }

   return idl_i2c_return_code(_i2c_set_mode(bus_num, i2c_mode));
}

/*------------------------------------------------------------------------------
 * idl_i2c_enable_polling
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_enable_polling(uint8_t bus_num, bool to_poll)
{
   p_idl_i2c_state[bus_num].to_poll = to_poll;
   return IDL_SUCCESS;
}

/*------------------------------------------------------------------------------
 * idl_i2c_enable_yield
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_enable_yield(uint8_t bus_num, bool to_yield)
{
   p_idl_i2c_state[bus_num].to_yield = to_yield;
   return IDL_SUCCESS;
}


/*------------------------------------------------------------------------------
 * idl_i2c_read_byte_without_dummy
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_byte_without_dummy(uint8_t bus_num, uint32_t control_flags, 
   uint8_t *p_data_byte, uint32_t interrupt_flags, uint32_t wait_condition)
{
   uint32_t i2c_control_flags = 0x00000000;

   if ((control_flags & ~(IDL_I2C_SEND_NACK | IDL_I2C_SEND_STOP)) != 
      0x00000000) {
      return IDL_INVALID_PARAM;
   }
   if (control_flags & IDL_I2C_SEND_NACK) {
      i2c_control_flags |= _I2C_SEND_NACK;
   }
   if (control_flags & IDL_I2C_SEND_STOP) {
      i2c_control_flags |= _I2C_SEND_STOP;
   }

   return idl_i2c_return_code(_i2c_read_byte_without_dummy(bus_num, i2c_control_flags, 
      p_data_byte, interrupt_flags, wait_condition));
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_byte
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_byte(uint8_t bus_num, uint32_t control_flags, 
   uint8_t *p_data_byte)
{
   uint32_t i2c_control_flags = 0x00000000;

   if ((control_flags & ~(IDL_I2C_SEND_NACK | IDL_I2C_SEND_STOP)) != 
      0x00000000) {
      return IDL_INVALID_PARAM;
   }
   if (control_flags & IDL_I2C_SEND_NACK) {
      i2c_control_flags |= _I2C_SEND_NACK;
   }
   if (control_flags & IDL_I2C_SEND_STOP) {
      i2c_control_flags |= _I2C_SEND_STOP;
   }

   return idl_i2c_return_code(_i2c_read_byte(bus_num, i2c_control_flags, 
      p_data_byte));
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_byte
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_byte(uint8_t bus_num, uint32_t control_flags, uint8_t data_byte)
{
   uint32_t i2c_control_flags = 0x00000000;

   if ((control_flags & ~(IDL_I2C_SEND_START | IDL_I2C_SEND_NACK | 
      IDL_I2C_SEND_STOP)) != 0x00000000) {
      return IDL_INVALID_PARAM;
   }
   if (control_flags & IDL_I2C_SEND_START) {
      i2c_control_flags |= _I2C_SEND_START;
   }
   if (control_flags & IDL_I2C_SEND_NACK) {
      i2c_control_flags |= _I2C_SEND_NACK;
   }
   if (control_flags & IDL_I2C_SEND_STOP) {
      i2c_control_flags |= _I2C_SEND_STOP;
   }

   return idl_i2c_return_code(_i2c_write_byte(bus_num, i2c_control_flags, 
      data_byte));
}

/*------------------------------------------------------------------------------
 * idl_i2c_set_interrupt_mask
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_set_interrupt_mask(uint8_t bus_num, uint32_t interrupt_mask)
{
   idl_result_t result;
   uint8_t bus_count;
   uint32_t i2c_interrupt_mask = IDL_I2C_NO_INTERRUPT;

   if ((interrupt_mask & ~(IDL_I2C_BUS_ERROR | IDL_I2C_RECEIVE_FULL | 
      IDL_I2C_TRANSMIT_EMPTY | IDL_I2C_ARBITRATION_LOSS)) != 0x00000000) {
      return IDL_INVALID_PARAM;
   }
   if (interrupt_mask & IDL_I2C_BUS_ERROR) {
      i2c_interrupt_mask |= _I2C_BUS_ERROR;
   }
   if (interrupt_mask & IDL_I2C_RECEIVE_FULL) {
      i2c_interrupt_mask |= _I2C_RECEIVE_FULL;
   }
   if (interrupt_mask & IDL_I2C_TRANSMIT_EMPTY) {
      i2c_interrupt_mask |= _I2C_TRANSMIT_EMPTY;
   }
   if (interrupt_mask & IDL_I2C_ARBITRATION_LOSS) {
      i2c_interrupt_mask |= _I2C_ARBITRATION_LOSS;
   }

   if (_i2c_get_bus_count(&bus_count) != _I2C_SUCCESS) {
      return IDL_FAILURE;
   }

   /* Get semaphore */
   if (idl_i2c_get_semaphore(bus_count) != IDL_SUCCESS) {
      return IDL_FAILURE;
   }

   result = idl_i2c_return_code(_i2c_set_interrupt_mask(bus_num, 
      i2c_interrupt_mask));

   /* Release semaphore */
   if (idl_i2c_put_semaphore(bus_count) != IDL_SUCCESS) {
      return IDL_FAILURE;
   }

   return result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_get_interrupt_mask
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_get_interrupt_mask(uint8_t bus_num, uint32_t *p_interrupt_mask)
{
   _i2c_result_t result;
   uint8_t bus_count;
   uint32_t i2c_interrupt_mask;

   if (_i2c_get_bus_count(&bus_count) != _I2C_SUCCESS) {
      return IDL_FAILURE;
   }

   /* Get semaphore */
   if (idl_i2c_get_semaphore(bus_count) != IDL_SUCCESS) {
      return IDL_FAILURE;
   }

   result = _i2c_get_interrupt_mask(bus_num, &i2c_interrupt_mask);

   /* Release semaphore */
   if (idl_i2c_put_semaphore(bus_count) != IDL_SUCCESS) {
      return IDL_FAILURE;
   }

   if (result != _I2C_SUCCESS) {
      return idl_i2c_return_code(result);
   }

   *p_interrupt_mask = IDL_I2C_NO_INTERRUPT;
   if (i2c_interrupt_mask & _I2C_BUS_ERROR) {
      *p_interrupt_mask |= IDL_I2C_BUS_ERROR;
   }
   if (i2c_interrupt_mask & _I2C_RECEIVE_FULL) {
      *p_interrupt_mask |= IDL_I2C_RECEIVE_FULL;
   }
   if (i2c_interrupt_mask & _I2C_TRANSMIT_EMPTY) {
      *p_interrupt_mask |= IDL_I2C_TRANSMIT_EMPTY;
   }
   if (i2c_interrupt_mask & _I2C_ARBITRATION_LOSS) {
      *p_interrupt_mask |= IDL_I2C_ARBITRATION_LOSS;
   }

   return IDL_SUCCESS;
}

/*------------------------------------------------------------------------------
 * idl_i2c_get_pending_interrupts
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_get_pending_interrupts(uint8_t bus_num, uint32_t *p_interrupt_flags)
{
   _i2c_result_t result;
   uint8_t bus_count;
   uint32_t i2c_interrupt_flags;

   if (_i2c_get_bus_count(&bus_count) != _I2C_SUCCESS) {
      return IDL_FAILURE;
   }

   /* Get semaphore */
   if (idl_i2c_get_semaphore(bus_count) != IDL_SUCCESS) {
      return IDL_FAILURE;
   }

   result = _i2c_get_pending_interrupts(bus_num, &i2c_interrupt_flags);
   
   /* Release semaphore */
   if (idl_i2c_put_semaphore(bus_count) != IDL_SUCCESS) {
      return IDL_FAILURE;
   }

   if (result != _I2C_SUCCESS) {
      return idl_i2c_return_code(result);
   }

   *p_interrupt_flags = IDL_I2C_NO_INTERRUPT;
   if (i2c_interrupt_flags & _I2C_BUS_ERROR) {
      *p_interrupt_flags |= IDL_I2C_BUS_ERROR;
   }
   if (i2c_interrupt_flags & _I2C_RECEIVE_FULL) {
      *p_interrupt_flags |= IDL_I2C_RECEIVE_FULL;
   }
   if (i2c_interrupt_flags & _I2C_TRANSMIT_EMPTY) {
      *p_interrupt_flags |= IDL_I2C_TRANSMIT_EMPTY;
   }
   if (i2c_interrupt_flags & _I2C_ARBITRATION_LOSS) {
      *p_interrupt_flags |= IDL_I2C_ARBITRATION_LOSS;
   }

   return IDL_SUCCESS;
}

/*------------------------------------------------------------------------------
 * idl_i2c_register_interrupt_handler
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_register_interrupt_handler(uint8_t bus_num, 
   os_interrupt_handler_t *p_interrupt_handler, void *p_interrupt_data)
{
   if (_i2c_release_interrupt_handler(bus_num) != _I2C_SUCCESS) {
      return IDL_FAILURE;
   }
   p_idl_i2c_state[bus_num].interrupt_data.is_registered = true;

   return idl_i2c_return_code(_i2c_register_interrupt_handler(bus_num, 
      p_interrupt_handler, p_interrupt_data));
}

/*------------------------------------------------------------------------------
 * idl_i2c_release_interrupt_handler
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_release_interrupt_handler(uint8_t bus_num)
{
   idl_result_t result;

   if ((result = idl_i2c_return_code(_i2c_release_interrupt_handler(bus_num)))
      != IDL_SUCCESS) {
         return IDL_FAILURE;
      } else {
         p_idl_i2c_state[bus_num].interrupt_data.is_registered = false;
   	 return result;
   }

}

/*------------------------------------------------------------------------------
 * idl_i2c_wait_for_interrupts
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_wait_for_interrupts(uint8_t bus_num, uint32_t interrupt_flags,
   uint32_t wait_condition)
{
   uint32_t i=0, interrupts=0;

   if (! p_idl_i2c_state[bus_num].to_poll && p_idl_i2c_state[bus_num].
      interrupt_data.is_registered) {
      /* Wait for event to signal completion of interrupt handling */
     if (os_event_hardwait (p_idl_i2c_state[bus_num].interrupt_data.p_os_event, wait_condition) != OSAL_SUCCESS) {
	return IDL_TIMED_OUT;
     }
     os_event_reset(p_idl_i2c_state[bus_num].interrupt_data.p_os_event);
   } else {
      for (i = 0; i < wait_condition; i++) {
         if (idl_i2c_get_pending_interrupts(bus_num, &interrupts) != 
            IDL_SUCCESS) {
            return IDL_FAILURE;
         }
         if ((interrupts & interrupt_flags) == interrupt_flags) {
            break;
         }
      }
      if ((interrupts & interrupt_flags) != interrupt_flags) {
	   return IDL_FAILURE;
      }
   }

   return IDL_SUCCESS;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read(uint8_t bus_num, uint16_t slave_addr, uint8_t *p_data_buffer, 
   uint32_t byte_count)
{
   return idl_i2c_write_read_ex(bus_num, slave_addr, NULL, 0, NULL, 0, 
      p_data_buffer, byte_count);
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_restart
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_restart(uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   return idl_i2c_write_read_ex(bus_num, slave_addr, &sub_addr, 1, NULL, 0, 
      p_data_buffer, byte_count);
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_sub_addr
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_sub_addr(uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   return idl_i2c_write_read_ex(bus_num, slave_addr, &sub_addr, 1, NULL, 0, 
      p_data_buffer, byte_count);
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_sub_addr_ex
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_sub_addr_ex(uint8_t bus_num, uint16_t slave_addr, 
   uint8_t *p_sub_addr, uint32_t sub_addr_byte_count,
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   return idl_i2c_write_read_ex(bus_num, slave_addr, p_sub_addr, 
      sub_addr_byte_count, NULL, 0, p_data_buffer, byte_count);
}

/*------------------------------------------------------------------------------
 * idl_i2c_write
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write(uint8_t bus_num, uint16_t slave_addr, uint8_t *p_data_buffer, 
   uint32_t byte_count)
{
   return idl_i2c_write_read_ex(bus_num, slave_addr, NULL, 0, p_data_buffer, 
      byte_count, NULL, 0);
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_restart
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_restart(uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   return idl_i2c_write_read_ex(bus_num, slave_addr, &sub_addr, 1,
      p_data_buffer, byte_count, NULL, 0);
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_sub_addr
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_sub_addr(uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   return idl_i2c_write_read_ex(bus_num, slave_addr, &sub_addr, 1,
      p_data_buffer, byte_count, NULL, 0);
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_sub_addr_ex
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_sub_addr_ex(uint8_t bus_num, uint16_t slave_addr, 
   uint8_t *p_sub_addr, uint32_t sub_addr_byte_count, uint8_t *p_data_buffer, 
   uint32_t byte_count)
{
   return idl_i2c_write_read_ex(bus_num, slave_addr, p_sub_addr, 
      sub_addr_byte_count, p_data_buffer, byte_count, NULL, 0);
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_write_async
 *------------------------------------------------------------------------------
 */

void
idl_i2c_read_write_async(void *p_data)
{
   idl_i2c_read_write_async_data_t *p_async_data = 
      (idl_i2c_read_write_async_data_t *) p_data;

   p_async_data->result = idl_i2c_write_read_ex(
      p_async_data->bus_num, 
      p_async_data->slave_addr, 
      p_async_data->p_sub_addr, 
      p_async_data->sub_addr_byte_count,
      p_async_data->p_write_data_buffer, 
      p_async_data->write_byte_count,
      p_async_data->p_read_data_buffer, 
      p_async_data->read_byte_count);
   os_event_set(p_async_data->p_os_event);

}

/*------------------------------------------------------------------------------
 * idl_i2c_read_write_async_wait
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_write_async_wait(idl_i2c_read_write_async_handle_t *p_async_handle,
   uint32_t time_out_ms)
{
   idl_i2c_read_write_async_data_t *p_async_data =
      (idl_i2c_read_write_async_data_t *) p_async_handle;

#ifndef IDL_I2C_ENABLE_KTHREAD
#ifdef LINUX_DRIVER
   return IDL_SUCCESS;
#endif
#endif

   p_async_data->result = IDL_SUCCESS;
   if (os_event_wait(p_async_data->p_os_event, time_out_ms) != 
      OSAL_SUCCESS) {
      p_async_data->result = IDL_TIMED_OUT;
   }

   os_event_reset(p_async_data->p_os_event);
   os_event_destroy(p_async_data->p_os_event);
#ifndef IDL_I2C_ENABLE_KTHREAD
   OS_FREE(p_async_data->p_os_event);
#endif
   OS_FREE(p_async_data->p_os_thread);

   return p_async_data->result;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_async(idl_i2c_read_write_async_handle_t *p_async_handle, 
   uint8_t bus_num, uint16_t slave_addr, uint8_t *p_data_buffer,
   uint32_t byte_count)
{
   idl_i2c_read_write_async_data_t *p_async_data =
      (idl_i2c_read_write_async_data_t *) p_async_handle;

#ifndef IDL_I2C_ENABLE_KTHREAD
#ifdef LINUX_DRIVER
   return idl_i2c_read(bus_num, slave_addr, p_data_buffer, byte_count);
#endif
#endif

   p_async_data->bus_num = bus_num;
   p_async_data->slave_addr = slave_addr;
   p_async_data->p_sub_addr = NULL;
   p_async_data->sub_addr_byte_count = 0;
   p_async_data->p_write_data_buffer = NULL;
   p_async_data->write_byte_count = 0;
   p_async_data->p_read_data_buffer = p_data_buffer;
   p_async_data->read_byte_count = byte_count;
#ifndef IDL_I2C_ENABLE_KTHREAD
   if ((p_async_data->p_os_event = (os_event_t *) OS_ALLOC(sizeof(os_event_t)))
      == NULL) {
      return IDL_FAILURE;
   }
#else
   p_async_data->p_os_event = &idl_i2c_os_event[idl_i2c_os_event_index++ % 
      IDL_I2C_OS_EVENT_COUNT];
#endif
   if ((p_async_data->p_os_thread = (os_thread_t *) OS_ALLOC(sizeof(os_thread_t)))
      == NULL) {
#ifndef IDL_I2C_ENABLE_KTHREAD
      OS_FREE(p_async_data->p_os_event);
#endif
      return IDL_FAILURE;
   }
   if (os_event_create(p_async_data->p_os_event, 0) != OSAL_SUCCESS) {
      goto exception;
   }
   if (os_thread_create(p_async_data->p_os_thread, 
      (void *) &idl_i2c_read_write_async, (void *) p_async_handle, 0, 0, NULL) != 
      OSAL_SUCCESS) {
      os_event_destroy(p_async_data->p_os_event);
      goto exception;
   }

   return IDL_SUCCESS;

exception:
   OS_FREE(p_async_data->p_os_thread);
#ifndef IDL_I2C_ENABLE_KTHREAD
   OS_FREE(p_async_data->p_os_event);
#endif
   return IDL_FAILURE;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_sub_addr_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_sub_addr_async(idl_i2c_read_write_async_handle_t *p_async_handle, 
   uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   idl_i2c_read_write_async_data_t *p_async_data =
      (idl_i2c_read_write_async_data_t *) p_async_handle;

#ifndef IDL_I2C_ENABLE_KTHREAD
#ifdef LINUX_DRIVER
   return idl_i2c_read_sub_addr(bus_num, slave_addr, sub_addr, p_data_buffer, 
      byte_count);
#endif
#endif

   p_async_data->bus_num = bus_num;
   p_async_data->slave_addr = slave_addr;
   p_async_data->p_sub_addr = &sub_addr;
   p_async_data->sub_addr_byte_count = 1;
   p_async_data->p_write_data_buffer = NULL;
   p_async_data->write_byte_count = 0;
   p_async_data->p_read_data_buffer = p_data_buffer;
   p_async_data->read_byte_count = byte_count;
#ifndef IDL_I2C_ENABLE_KTHREAD
   if ((p_async_data->p_os_event = (os_event_t *) OS_ALLOC(sizeof(os_event_t)))
      == NULL) {
      return IDL_FAILURE;
   }
#else
   p_async_data->p_os_event = &idl_i2c_os_event[idl_i2c_os_event_index++ % 
      IDL_I2C_OS_EVENT_COUNT];
#endif
   if ((p_async_data->p_os_thread = (os_thread_t *) OS_ALLOC(sizeof(os_thread_t)))
      == NULL) {
#ifndef IDL_I2C_ENABLE_KTHREAD
      OS_FREE(p_async_data->p_os_event);
#endif
      return IDL_FAILURE;
   }
   if (os_event_create(p_async_data->p_os_event, 0) != OSAL_SUCCESS) {
      goto exception;
   }
   if (os_thread_create(p_async_data->p_os_thread, 
      (void *) &idl_i2c_read_write_async, (void *) p_async_handle, 0, 0, NULL) != 
      OSAL_SUCCESS) {
      os_event_destroy(p_async_data->p_os_event);
      goto exception;
   }

   return IDL_SUCCESS;

exception:
   OS_FREE(p_async_data->p_os_thread);
#ifndef IDL_I2C_ENABLE_KTHREAD
   OS_FREE(p_async_data->p_os_event);
#endif
   return IDL_FAILURE;
}

/*------------------------------------------------------------------------------
 * idl_i2c_read_sub_addr_ex_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_read_sub_addr_ex_async(idl_i2c_read_write_async_handle_t 
   *p_async_handle, uint8_t bus_num, uint16_t slave_addr, uint8_t *p_sub_addr, 
   uint32_t sub_addr_byte_count, uint8_t *p_data_buffer, uint32_t byte_count)
{
   idl_i2c_read_write_async_data_t *p_async_data =
      (idl_i2c_read_write_async_data_t *) p_async_handle;

#ifndef IDL_I2C_ENABLE_KTHREAD
#ifdef LINUX_DRIVER
   return idl_i2c_read_sub_addr_ex(bus_num, slave_addr, p_sub_addr, 
      sub_addr_byte_count, p_data_buffer, byte_count);
#endif
#endif

   p_async_data->bus_num = bus_num;
   p_async_data->slave_addr = slave_addr;
   p_async_data->p_sub_addr = p_sub_addr;
   p_async_data->sub_addr_byte_count = sub_addr_byte_count;
   p_async_data->p_write_data_buffer = NULL;
   p_async_data->write_byte_count = 0;
   p_async_data->p_read_data_buffer = p_data_buffer;
   p_async_data->read_byte_count = byte_count;
#ifndef IDL_I2C_ENABLE_KTHREAD
   if ((p_async_data->p_os_event = (os_event_t *) OS_ALLOC(sizeof(os_event_t)))
      == NULL) {
      return IDL_FAILURE;
   }
#else
   p_async_data->p_os_event = &idl_i2c_os_event[idl_i2c_os_event_index++ % 
      IDL_I2C_OS_EVENT_COUNT];
#endif
   if ((p_async_data->p_os_thread = (os_thread_t *) OS_ALLOC(sizeof(os_thread_t)))
      == NULL) {
#ifndef IDL_I2C_ENABLE_KTHREAD
      OS_FREE(p_async_data->p_os_event);
#endif
      return IDL_FAILURE;
   }
   if (os_event_create(p_async_data->p_os_event, 0) != OSAL_SUCCESS) {
      goto exception;
   }
   if (os_thread_create(p_async_data->p_os_thread, 
      (void *) &idl_i2c_read_write_async, (void *) p_async_handle, 0, 0, NULL) != 
      OSAL_SUCCESS) {
      os_event_destroy(p_async_data->p_os_event);
      goto exception;
   }

   return IDL_SUCCESS;

exception:
   OS_FREE(p_async_data->p_os_thread);
#ifndef IDL_I2C_ENABLE_KTHREAD
   OS_FREE(p_async_data->p_os_event);
#endif
   return IDL_FAILURE;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_async(idl_i2c_read_write_async_handle_t *p_async_handle, 
   uint8_t bus_num, uint16_t slave_addr, uint8_t *p_data_buffer, 
   uint32_t byte_count)
{
   idl_i2c_read_write_async_data_t *p_async_data =
      (idl_i2c_read_write_async_data_t *) p_async_handle;

#ifndef IDL_I2C_ENABLE_KTHREAD
#ifdef LINUX_DRIVER
   return idl_i2c_write(bus_num, slave_addr, p_data_buffer, byte_count);
#endif
#endif

   p_async_data->bus_num = bus_num;
   p_async_data->slave_addr = slave_addr;
   p_async_data->p_sub_addr = NULL;
   p_async_data->sub_addr_byte_count = 0;
   p_async_data->p_write_data_buffer = p_data_buffer;
   p_async_data->write_byte_count = byte_count;
   p_async_data->p_read_data_buffer = NULL;
   p_async_data->read_byte_count = 0;
#ifndef IDL_I2C_ENABLE_KTHREAD
   if ((p_async_data->p_os_event = (os_event_t *) OS_ALLOC(sizeof(os_event_t)))
      == NULL) {
      return IDL_FAILURE;
   }
#else
   p_async_data->p_os_event = &idl_i2c_os_event[idl_i2c_os_event_index++ % 
      IDL_I2C_OS_EVENT_COUNT];
#endif
   if ((p_async_data->p_os_thread = (os_thread_t *) OS_ALLOC(sizeof(os_thread_t)))
      == NULL) {
#ifndef IDL_I2C_ENABLE_KTHREAD
      OS_FREE(p_async_data->p_os_event);
#endif
      return IDL_FAILURE;
   }
   if (os_event_create(p_async_data->p_os_event, 0) != OSAL_SUCCESS) {
      goto exception;
   }
   if (os_thread_create(p_async_data->p_os_thread, 
      (void *) &idl_i2c_read_write_async, (void *) p_async_handle, 0, 0, NULL) != 
      OSAL_SUCCESS) {
      os_event_destroy(p_async_data->p_os_event);
      goto exception;
   }

   return IDL_SUCCESS;

exception:
   OS_FREE(p_async_data->p_os_thread);
#ifndef IDL_I2C_ENABLE_KTHREAD
   OS_FREE(p_async_data->p_os_event);
#endif
   return IDL_FAILURE;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_sub_addr_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_sub_addr_async(idl_i2c_read_write_async_handle_t *p_async_handle, 
   uint8_t bus_num, uint16_t slave_addr, uint8_t sub_addr, 
   uint8_t *p_data_buffer, uint32_t byte_count)
{
   idl_i2c_read_write_async_data_t *p_async_data =
      (idl_i2c_read_write_async_data_t *) p_async_handle;

#ifndef IDL_I2C_ENABLE_KTHREAD
#ifdef LINUX_DRIVER
   return idl_i2c_write_sub_addr(bus_num, slave_addr, sub_addr, p_data_buffer, 
      byte_count);
#endif
#endif

   p_async_data->bus_num = bus_num;
   p_async_data->slave_addr = slave_addr;
   p_async_data->p_sub_addr = &sub_addr;
   p_async_data->sub_addr_byte_count = 1;
   p_async_data->p_write_data_buffer = p_data_buffer;
   p_async_data->write_byte_count = byte_count;
   p_async_data->p_read_data_buffer = NULL;
   p_async_data->read_byte_count = 0;
#ifndef IDL_I2C_ENABLE_KTHREAD
   if ((p_async_data->p_os_event = (os_event_t *) OS_ALLOC(sizeof(os_event_t)))
      == NULL) {
      return IDL_FAILURE;
   }
#else
   p_async_data->p_os_event = &idl_i2c_os_event[idl_i2c_os_event_index++ % 
      IDL_I2C_OS_EVENT_COUNT];
#endif
   if ((p_async_data->p_os_thread = (os_thread_t *) OS_ALLOC(sizeof(os_thread_t)))
      == NULL) {
#ifndef IDL_I2C_ENABLE_KTHREAD
      OS_FREE(p_async_data->p_os_event);
#endif
      return IDL_FAILURE;
   }
   if (os_event_create(p_async_data->p_os_event, 0) != OSAL_SUCCESS) {
      goto exception;
   }
   if (os_thread_create(p_async_data->p_os_thread, 
      (void *) &idl_i2c_read_write_async, (void *) p_async_handle, 0, 0, NULL) != 
      OSAL_SUCCESS) {
      os_event_destroy(p_async_data->p_os_event);
      goto exception;
   }

   return IDL_SUCCESS;

exception:
   OS_FREE(p_async_data->p_os_thread);
#ifndef IDL_I2C_ENABLE_KTHREAD
   OS_FREE(p_async_data->p_os_event);
#endif
   return IDL_FAILURE;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_sub_addr_async
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_sub_addr_ex_async(idl_i2c_read_write_async_handle_t 
   *p_async_handle, uint8_t bus_num, uint16_t slave_addr, uint8_t *p_sub_addr, 
   uint32_t sub_addr_byte_count, uint8_t *p_data_buffer, uint32_t byte_count)
{
   idl_i2c_read_write_async_data_t *p_async_data =
      (idl_i2c_read_write_async_data_t *) p_async_handle;

#ifndef IDL_I2C_ENABLE_KTHREAD
#ifdef LINUX_DRIVER
   return idl_i2c_write_sub_addr_ex(bus_num, slave_addr, p_sub_addr, 
      sub_addr_byte_count, p_data_buffer, byte_count);
#endif
#endif

   p_async_data->bus_num = bus_num;
   p_async_data->slave_addr = slave_addr;
   p_async_data->p_sub_addr = p_sub_addr;
   p_async_data->sub_addr_byte_count = sub_addr_byte_count;
   p_async_data->p_write_data_buffer = p_data_buffer;
   p_async_data->write_byte_count = byte_count;
   p_async_data->p_read_data_buffer = NULL;
   p_async_data->read_byte_count = 0;
#ifndef IDL_I2C_ENABLE_KTHREAD
   if ((p_async_data->p_os_event = (os_event_t *) OS_ALLOC(sizeof(os_event_t)))
      == NULL) {
      return IDL_FAILURE;
   }
#else
   p_async_data->p_os_event = &idl_i2c_os_event[idl_i2c_os_event_index++ % 
      IDL_I2C_OS_EVENT_COUNT];
#endif
   if ((p_async_data->p_os_thread = (os_thread_t *) OS_ALLOC(sizeof(os_thread_t)))
      == NULL) {
#ifndef IDL_I2C_ENABLE_KTHREAD
      OS_FREE(p_async_data->p_os_event);
#endif
      return IDL_FAILURE;
   }
   if (os_event_create(p_async_data->p_os_event, 0) != OSAL_SUCCESS) {
      goto exception;
   }
   if (os_thread_create(p_async_data->p_os_thread, 
      (void *) &idl_i2c_read_write_async, (void *) p_async_handle, 0, 0, NULL) != 
      OSAL_SUCCESS) {
      os_event_destroy(p_async_data->p_os_event);
      goto exception;
   }

   return IDL_SUCCESS;

exception:
   OS_FREE(p_async_data->p_os_thread);
#ifndef IDL_I2C_ENABLE_KTHREAD
   OS_FREE(p_async_data->p_os_event);
#endif
   return IDL_FAILURE;
}

/*------------------------------------------------------------------------------
 * idl_i2c_write_read_ex
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_write_read_ex(uint8_t bus_num, uint16_t slave_addr, 
   uint8_t *p_sub_addr, uint32_t sub_addr_byte_count,
   uint8_t *p_write_data_buffer, uint32_t write_byte_count, 
   uint8_t *p_read_data_buffer, uint32_t read_byte_count)
{
   uint8_t bus_count;
   uint32_t i;
   uint32_t control_flags;
   uint32_t interrupt_mask;
   uint32_t interrupt_flags;
   uint32_t reg_value;
   uint32_t wait_condition = IDL_I2C_WAIT_CONDITION;
   int retries;
   bool retry;
   idl_result_t result;

   if (_i2c_get_bus_count(&bus_count) != _I2C_SUCCESS) {
      return IDL_FAILURE;
   }

   /* Check slave address & valid bus number */
   /* slave_addr = 0 is a general call address which we not yet support yet */
   if ((slave_addr == 0x0) || (slave_addr > 0x007f) || (bus_num >= bus_count)) {
      return IDL_INVALID_PARAM;
   }

   /* Get semaphore */
   if (idl_i2c_get_semaphore(bus_num) != IDL_SUCCESS) {
      return IDL_FAILURE;
   }

   	retries = 10;
	while (retries >  0) {
	  retry = false;
   /* Clear interrupts and mask all i2c interrupts if polling */
   /* or enable transfer-complete interrupts */
   if (idl_i2c_get_pending_interrupts(bus_num, &interrupt_flags) != 
      IDL_SUCCESS) {
      goto exception;
   }
   if (idl_i2c_get_interrupt_mask(bus_num, &interrupt_mask) != IDL_SUCCESS) {
      goto exception;
   }
   if (p_idl_i2c_state[bus_num].to_poll) {
      if (idl_i2c_set_interrupt_mask(bus_num, IDL_I2C_NO_INTERRUPT) != 
         IDL_SUCCESS) {
         goto exception;
      }
   } else {
      if (idl_i2c_set_interrupt_mask(bus_num, IDL_I2C_TRANSMIT_EMPTY |
         IDL_I2C_RECEIVE_FULL) != IDL_SUCCESS) {
         goto exception;
      }
      if (p_idl_i2c_state[bus_num].interrupt_data.is_registered == false) {
         p_idl_i2c_state[bus_num].interrupt_data.bus_num = bus_num;
         p_idl_i2c_state[bus_num].interrupt_data.interrupt_flags = IDL_I2C_TRANSMIT_EMPTY | IDL_I2C_RECEIVE_FULL;
	 if (idl_i2c_register_interrupt_handler(bus_num, (os_interrupt_handler_t *) 
            &idl_i2c_interrupt_handler, (void *) &p_idl_i2c_state[bus_num].interrupt_data) == IDL_SUCCESS) {
            p_idl_i2c_state[bus_num].interrupt_data.is_registered = true;
         }
      }
   }

   /* Send out slave address with write bit if need to restart */
   /* Otherwise, send out read bit */
   if (idl_i2c_write_byte(bus_num, IDL_I2C_SEND_START | ((write_byte_count == 0 
      && read_byte_count == 0 && sub_addr_byte_count == 0) ? 
      (IDL_I2C_SEND_NACK | IDL_I2C_SEND_STOP) : 0), ((slave_addr << 1) | 
      ((write_byte_count == 0 && sub_addr_byte_count == 0) ? IDL_I2C_SEND_READ : 
      IDL_I2C_SEND_WRITE))) != IDL_SUCCESS) {
      goto exception;
   }
   if (idl_i2c_wait_for_interrupts(bus_num, IDL_I2C_TRANSMIT_EMPTY, 
      wait_condition) != IDL_SUCCESS) {
	  retry = true;
      goto exception;
   }

   /* Write out sub-address if desired */
   if(slave_addr != 0x26){
      for (i = 0; i < sub_addr_byte_count; i++) {
         if (i == sub_addr_byte_count - 1) {
            control_flags = IDL_I2C_SEND_NACK;
            if (write_byte_count == 0 && read_byte_count == 0) {
               control_flags |= IDL_I2C_SEND_STOP;
            }
         } else {
            control_flags = IDL_I2C_SEND_DATA;
         }
         if (idl_i2c_write_byte(bus_num, control_flags, p_sub_addr[i]) 
            != IDL_SUCCESS) {
            goto exception;
         }
         if (idl_i2c_wait_for_interrupts(bus_num, IDL_I2C_TRANSMIT_EMPTY, 
            wait_condition) != IDL_SUCCESS) {
	  		retry = true;
            goto exception;
         }
      }
   }

   /* Write out data buffer */
   for (i = 0; i < write_byte_count; i++) {
      if (i == write_byte_count - 1) {
         control_flags = IDL_I2C_SEND_NACK;
         if (read_byte_count == 0) {
            control_flags |= IDL_I2C_SEND_STOP;
         }
      } else {
         control_flags = IDL_I2C_SEND_DATA;
      }

      if (idl_i2c_write_byte(bus_num, control_flags, p_write_data_buffer[i]) 
         != IDL_SUCCESS) {
         goto exception;
      }
      if (idl_i2c_wait_for_interrupts(bus_num, IDL_I2C_TRANSMIT_EMPTY, 
         wait_condition) != IDL_SUCCESS) {
	  	 retry = true;
         goto exception;
      }
      // In order to low down cpu utilization in polling mode
      if (p_idl_i2c_state[bus_num].to_yield && p_idl_i2c_state[bus_num].to_poll) {
	  yield();
      }
   }

   if ((write_byte_count > 0 || sub_addr_byte_count > 0) && 
      read_byte_count > 0) {
      /* Send out slave address to read with a repeated START condition */
      if (idl_i2c_write_byte(bus_num, IDL_I2C_SEND_START, 
         ((slave_addr << 1) | IDL_I2C_SEND_READ)) != 
         IDL_SUCCESS) {
         goto exception;
      }
      if (idl_i2c_wait_for_interrupts(bus_num, IDL_I2C_TRANSMIT_EMPTY, 
         wait_condition) != IDL_SUCCESS) {
	  	 retry = true;
         goto exception;
      }
   }
   
   if(slave_addr == 0x26){
      /* Not sure why need to do a dummy read */
      /* This seems to read in the slave address */
      if (read_byte_count > 0) {
         if (idl_i2c_read_byte(bus_num, IDL_I2C_SEND_DATA, &p_read_data_buffer[0]) 
            != IDL_SUCCESS) {
            goto exception;
         }
         if (idl_i2c_wait_for_interrupts(bus_num, IDL_I2C_RECEIVE_FULL, 
            wait_condition) != IDL_SUCCESS) {
	  		retry = true;
            goto exception;
         }
      }
   }
   /* Read in data buffer */
   for (i = 0; i < read_byte_count; i++) {
      if (i == read_byte_count - 1) {
         control_flags = IDL_I2C_SEND_NACK | IDL_I2C_SEND_STOP;
      } else {
         control_flags = IDL_I2C_SEND_DATA;
      }
      if(slave_addr == 0x26){
         if (idl_i2c_read_byte(bus_num, control_flags, &p_read_data_buffer[i]) 
            != IDL_SUCCESS) {
            goto exception;
         }
         if (idl_i2c_wait_for_interrupts(bus_num, IDL_I2C_RECEIVE_FULL, 
            wait_condition) != IDL_SUCCESS) {
	  		retry = true;
            goto exception;
         }
      }
      else
      {
         if (idl_i2c_read_byte_without_dummy(bus_num, control_flags, &p_read_data_buffer[i], IDL_I2C_RECEIVE_FULL, wait_condition) 
            != IDL_SUCCESS) {
            goto exception;
         }
      	 // In order to low down cpu utilization in polling mode
         if (p_idl_i2c_state[bus_num].to_yield && p_idl_i2c_state[bus_num].to_poll) {
      	    yield();
	 }

      }
   }

   /* restore original interrupt mask */
   if (idl_i2c_get_pending_interrupts(bus_num, &interrupt_flags) != 
      IDL_SUCCESS) {
      goto exception;
   }
   if (idl_i2c_set_interrupt_mask(bus_num, interrupt_mask) != IDL_SUCCESS) {
      goto exception;
   }

   /* Release semaphore */
   if (idl_i2c_put_semaphore(bus_num) != IDL_SUCCESS) {
      return IDL_FAILURE;
   }

   return IDL_SUCCESS;

exception:
   if (!retry) {
   		goto abort;
	}
   _i2c_read_register(bus_num, _I2C_REG_ISR, &reg_value);
   if ((reg_value & _I2C_ISR_UNIT_BUSY) == 0) {
   		goto abort;
   }
   /*it seems like the controller is frozen ... try resetting it */
   msleep(40);
   result = idl_i2c_reset(bus_num);
   if (IDL_SUCCESS != result) {
	
	 goto abort;
  }
  retries--;

 }

abort:
   /* Release semaphore */
   idl_i2c_put_semaphore(bus_num);
   return IDL_FAILURE;
}

/*------------------------------------------------------------------------------
 * idl_i2c_get_semaphore
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_get_semaphore(uint8_t bus_num)
{
   uint8_t bus_count;

   if (_i2c_get_bus_count(&bus_count) != _I2C_SUCCESS) {
      return IDL_FAILURE;
   }
   if (bus_num < bus_count + 1) {
      if (p_idl_i2c_semaphores != NULL) {
         os_sema_get(&p_idl_i2c_semaphores[bus_num]);
         return IDL_SUCCESS;
      } else {
         return IDL_FAILURE;
      }
   } else {
      return IDL_INVALID_PARAM;
   }
}

/*------------------------------------------------------------------------------
 * idl_i2c_put_semaphore
 *------------------------------------------------------------------------------
 */

idl_result_t
idl_i2c_put_semaphore(uint8_t bus_num)
{
   uint8_t bus_count;

   if (_i2c_get_bus_count(&bus_count) != _I2C_SUCCESS) {
      return IDL_FAILURE;
   }
   if (bus_num < bus_count + 1) {
      if (p_idl_i2c_semaphores != NULL) {
         os_sema_put(&p_idl_i2c_semaphores[bus_num]);
         return IDL_SUCCESS;
      } else {
         return IDL_FAILURE;
      }
   } else {
      return IDL_INVALID_PARAM;
   }
}

#ifdef __cplusplus
}
#endif
