/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*----------------------------------------------------------------------
 * File Name:       idl_gpio.c
 * $Revision: 0.1 $
 *----------------------------------------------------------------------
 *
 */

#include "idl.h"
#include "idl_gpio.h"
#include "osal_memmap.h"
#include "osal_memory.h"
#include "osal_io.h"
#include "_gpio.h" //gen3 and gen4
#include "_gpio_gen4_5.h"  //gen4.5
#include "_gpio_gen5.h" //gen5
#include "pal_interrupt.h"
#include "pal.h"

//#define CORE_DEBUG 1

static uint32_t *m_idl_gpio_base = NULL;
static os_interrupt_t *m_interrupt_handler;
static uint32_t m_number_instances = 0;

static pal_soc_name_t soc = SOC_NAME_CE4100;

struct gpio_str_ops {
  		 int (*suspend)(void *data);
  		 int (*resume)(void *data);
	      void *data;
};
static struct gpio_str_ops str_ops;

/* gpio device suspend */
int gpio_suspend(void)
{
	/*gpio suspend */
	if (str_ops.suspend) str_ops.suspend(str_ops.data);
	else return -1;
	return 0;
}

/* gpio device resume */
int gpio_resume(void)
{
    /*gpio resume */
    if (str_ops.resume) str_ops.resume(str_ops.data);
	else return -1;
    return 0;

}
	
idl_result_t
idl_gpio_init()
{
    uint32_t base_addr = 0, i = 0;
	uint32_t size = 0;
	pal_soc_info_t pal_info;
	
    m_number_instances++;

	if (m_idl_gpio_base != NULL) 
    {
#ifdef CORE_DEBUG
		printk("m_idl_gpio_base is not NULL, m_idl_gpio_base=0x%0x\n", *m_idl_gpio_base);
#endif
		return IDL_ALREADY_INITIALIZED;
	}
	
	if( PAL_SUCCESS != pal_get_soc_info(&pal_info)) {
		_OS_ERROR("pal_get_soc_info FAILURE: could not get soc info to pal_info \n");
		return IDL_FAILURE;
	}
	soc = pal_info.name;
	
	switch(soc)
	{
		case SOC_NAME_CE3100:
			OS_PRINT("SOC CE3100 found\n");
			base_addr = _gpio_get_base_addr();
			size = _gpio_get_size();
			break;
		case SOC_NAME_CE4100:
			OS_PRINT("SOC CE4100 found\n");
			base_addr = _gpio_get_base_addr();
			size = _gpio_get_size();
			break;
		case SOC_NAME_CE4200:
			OS_PRINT("SOC CE4200 found\n");
			base_addr = _gen4d5_gpio_get_base_addr();
			size = _gen4d5_gpio_get_size();
			str_ops.suspend = _gen4d5_gpio_suspend;
			str_ops.resume = _gen4d5_gpio_resume;
			break;
		case SOC_NAME_CE5300:
			OS_PRINT("SOC CE5300 found\n");
			base_addr = _gen5_gpio_get_base_addr();
			size = _gen5_gpio_get_size();
			break;			
		default:
			OS_PRINT("SOC chip is not supported\n");
			break;
	}

#ifdef CORE_DEBUG
		printk("base_addr = 0x%0x, size = 0x%0x\n", base_addr, size);
#endif

	/* map the gpio register space to something we can actually access */
        
	 m_idl_gpio_base = (uint32_t *)OS_MAP_IO_TO_MEM_NOCACHE(base_addr, size);
	 str_ops.data = m_idl_gpio_base;
#ifdef CORE_DEBUG
		printk("m_idl_gpio_base = 0x%0x\n", m_idl_gpio_base);
#endif

	/* did it work? */
	if (m_idl_gpio_base == NULL)
	{
		// no
		OS_DEBUG("idl_gpio_init: Unable to map to: 0x%8.8X; size = 0x%x\n", 
					base_addr, size);
		return IDL_NOT_INITIALIZED;
	}

	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		/* initialize the interrupt handlers (1 per GPIO interrupt line) */
		m_interrupt_handler = (os_interrupt_t *)OS_ALLOC(_gpio_get_number_of_gpio_interrupts() * sizeof(os_interrupt_t));

		if (m_interrupt_handler == NULL)
		{
			OS_DEBUG("idl_gpio_init: Out of memory, unable to alloc interrupt table.\n");
			return IDL_NOT_INITIALIZED;
		}
		/* initialize the gpio interrupt handlers to NULL */
		for (i = 0; i < _gpio_get_number_of_gpio_interrupts(); i++)
		{
			m_interrupt_handler[i] = NULL;
		}
		_gpio_sema_init();
	}
	else if(soc == SOC_NAME_CE4200) {
		/* initialize the interrupt handlers (1 per GPIO interrupt line) */
		m_interrupt_handler = (os_interrupt_t *)OS_ALLOC(_gen4d5_gpio_get_number_of_gpio_interrupts() * sizeof(os_interrupt_t));

		if (m_interrupt_handler == NULL)
		{
			OS_DEBUG("idl_gpio_init: Out of memory, unable to alloc interrupt table.\n");
			return IDL_NOT_INITIALIZED;
		}
#ifdef CORE_DEBUG
		else {
			printk("m_interrupt_handler = 0x%0x\n", *m_interrupt_handler);
		}
#endif
		
		/* initialize the gpio interrupt handlers to NULL */
		for (i = 0; i < _gen4d5_gpio_get_number_of_gpio_interrupts(); i++)
		{
			m_interrupt_handler[i] = NULL;
		}
		_gen4d5_gpio_sema_init();
	}
	else {
		/* initialize the interrupt handlers (1 per GPIO interrupt line) */
		m_interrupt_handler = (os_interrupt_t *)OS_ALLOC(_gen5_gpio_get_number_of_gpio_interrupts() * sizeof(os_interrupt_t));

		if (m_interrupt_handler == NULL)
		{
			OS_DEBUG("idl_gpio_init: Out of memory, unable to alloc interrupt table.\n");
			return IDL_NOT_INITIALIZED;
		}
#ifdef CORE_DEBUG
		else {
			printk("m_interrupt_handler = 0x%0x\n", *m_interrupt_handler);
		}
#endif
		
		/* initialize the gpio interrupt handlers to NULL */
		for (i = 0; i < _gen5_gpio_get_number_of_gpio_interrupts(); i++)
		{
			m_interrupt_handler[i] = NULL;
		}
		_gen5_gpio_sema_init();
	}
	
	return IDL_SUCCESS;
}

idl_result_t
idl_valid_gpio_num(uint32_t gpio_num)
{
	if((soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) && !_valid_gpio_num(gpio_num))  {
			OS_DEBUG("idl_valid_gpio_num: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
	}
	else if(soc == SOC_NAME_CE4200 && !_gen4d5_valid_gpio_num(gpio_num)) {
			OS_DEBUG("idl_valid_gpio_num: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
	}
	else if(soc == SOC_NAME_CE5300 && !_gen5_valid_gpio_num(gpio_num)) {
			OS_DEBUG("idl_valid_gpio_num: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
	}	
	return IDL_SUCCESS;
}

idl_result_t
idl_gpio_supports_interrupts(uint32_t gpio_num)
{
	if((soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) && !_gpio_supports_interrupts(gpio_num))  {
			OS_DEBUG("idl_gpio_supports_interrupts: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
	}
	else if(soc == SOC_NAME_CE4200 && !_gen4d5_gpio_supports_interrupts(gpio_num)) {
			OS_DEBUG("idl_gpio_supports_interrupts: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
	}
	else if(soc == SOC_NAME_CE5300 && !_gen5_gpio_supports_interrupts(gpio_num)) {
			OS_DEBUG("idl_gpio_supports_interrupts: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
	}	
	return IDL_SUCCESS;	
}

idl_result_t
idl_gpio_line_config(uint32_t gpio_num, uint32_t gpio_config)
{
	// parameter checking
	// initialized?
	if (m_idl_gpio_base == NULL)
	{
		OS_DEBUG("idl_gpio_line_config: GPIO %ul not initialized\n", gpio_num);
		return IDL_NOT_INITIALIZED;
	}

	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		// check to see if gpio number is in range
		if (!_valid_gpio_num(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_config: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// configure the gpio based on user request
		_gpio_line_config(m_idl_gpio_base, gpio_num, gpio_config);
	}
	else if(soc == SOC_NAME_CE4200){
		// check to see if gpio number is in range
		if (!_gen4d5_valid_gpio_num(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_config: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// configure the gpio based on user request
		_gen4d5_gpio_line_config(m_idl_gpio_base, gpio_num, gpio_config);		
	}
	else {
		// check to see if gpio number is in range
		if (!_gen5_valid_gpio_num(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_config: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// configure the gpio based on user request
		_gen5_gpio_line_config(m_idl_gpio_base, gpio_num, gpio_config);		
	}	
	return IDL_SUCCESS;
}

idl_result_t 
idl_gpio_set_alt_function(uint32_t gpio_num, uint32_t fn_num)
{
	// parameter checking
	// initialized?
	if (m_idl_gpio_base == NULL)
	{
		OS_DEBUG("idl_gpio_set_alt_function: GPIO %ul not initialized\n", gpio_num);
		return IDL_NOT_INITIALIZED;
	}
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		/* check to see if gpio number is in range */
		if (!_gpio_supports_alt_function(gpio_num, fn_num))
		{
			OS_DEBUG("idl_gpio_set_alt_function: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		_gpio_set_alt_function(m_idl_gpio_base, gpio_num, fn_num);
	}
	else if(soc == SOC_NAME_CE4200){
		/* check to see if gpio number is in range */
		if (!_gen4d5_gpio_supports_alt_function(gpio_num, fn_num))
		{
			OS_DEBUG("idl_gpio_set_alt_function: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		_gen4d5_gpio_set_alt_function(m_idl_gpio_base, gpio_num, fn_num);

	}
	else {
		/* check to see if gpio number is in range */
		if (!_gen5_gpio_supports_alt_function(gpio_num, fn_num))
		{
			OS_DEBUG("idl_gpio_set_alt_function: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		_gen5_gpio_set_alt_function(m_idl_gpio_base, gpio_num, fn_num);

	}	
	return IDL_SUCCESS;
}


idl_result_t
idl_gpio_interrupt_config(uint32_t gpio_num, idl_gpio_interrupt_type_t interrupt_type)
{
	// parameter checking
	// initialized?
	if (m_idl_gpio_base == NULL)
	{
		OS_DEBUG("idl_gpio_interrupt_config: GPIO %ul not initialized\n", gpio_num);
		return IDL_NOT_INITIALIZED;
	}

	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		if (!_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_interrupt_config: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
	}
	else if(soc == SOC_NAME_CE4200){
		if (!_gen4d5_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_interrupt_config: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
	}
	else {
		if (!_gen5_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_interrupt_config: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
	}	
	switch (interrupt_type)
	{
		case IDL_GPIO_ACTIVE_HIGH_LEVEL:
		case IDL_GPIO_ACTIVE_LOW_LEVEL:
		case IDL_GPIO_RISING_UP_EDGE:
		case IDL_GPIO_FALLING_DOWN_EDGE:			
			break;
		default:
			return IDL_INVALID_PARAM;
	}
	
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		// setup the interrupts as requested by the user
		_gpio_interrupt_config(m_idl_gpio_base, gpio_num, interrupt_type);
	}
	else if (soc == SOC_NAME_CE4200){
		// setup the interrupts as requested by the user
		_gen4d5_gpio_interrupt_config(m_idl_gpio_base, gpio_num, interrupt_type);
	}
	else {
		// setup the interrupts as requested by the user
		_gen5_gpio_interrupt_config(m_idl_gpio_base, gpio_num, interrupt_type);
	}		

	return IDL_SUCCESS;
}

idl_result_t
idl_gpio_interrupt_status(uint32_t gpio_num, uint32_t *interrupt_status)
{
	// parameter checking
	// initialized?
	if (m_idl_gpio_base == NULL)
	{
		OS_DEBUG("idl_gpio_interrupt_status: Not initialized\n");
		return IDL_NOT_INITIALIZED;
	}
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		if (!_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_interrupt_status: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		// read the interrupt status value for the specified gpio
		_gpio_interrupt_status(m_idl_gpio_base, gpio_num, interrupt_status);
	}
	else if (soc == SOC_NAME_CE4200){
		if (!_gen4d5_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_interrupt_status: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		// read the interrupt status value for the specified gpio
		_gen4d5_gpio_interrupt_status(m_idl_gpio_base, gpio_num, interrupt_status);
	}
	else {
		if (!_gen5_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_interrupt_status: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		// read the interrupt status value for the specified gpio
		_gen5_gpio_interrupt_status(m_idl_gpio_base, gpio_num, interrupt_status);
	}
	return IDL_SUCCESS;
}

idl_result_t 
idl_gpio_clear_interrupt(uint32_t gpio_num)
{
	// parameter checking
	// initialized?
	if (m_idl_gpio_base == NULL)
	{
		OS_DEBUG("idl_gpio_clear_interrupt: GPIO %ul not initialized\n", gpio_num);
		return IDL_NOT_INITIALIZED;
	}
	
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		if (!_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_clear_interrupt: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		_gpio_clear_interrupt(m_idl_gpio_base, gpio_num);
	}
	else if (soc == SOC_NAME_CE4200) {
		if (!_gen4d5_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_clear_interrupt: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		_gen4d5_gpio_clear_interrupt(m_idl_gpio_base, gpio_num);
	}
	else {
		if (!_gen5_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_clear_interrupt: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		_gen5_gpio_clear_interrupt(m_idl_gpio_base, gpio_num);
	}
	
	return IDL_SUCCESS;
}

idl_result_t idl_gpio_disable_interrupt(uint32_t gpio_num)
{
	// parameter checking
	// initialized?
	if (m_idl_gpio_base == NULL)
	{
		OS_DEBUG("idl_gpio_disable_interrupt: GPIO %ul not initialized\n", gpio_num);
		return IDL_NOT_INITIALIZED;
	}

	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		if (!_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_disable_interrupt: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		_gpio_disable_interrupts(m_idl_gpio_base, gpio_num);
	}
	else if (soc == SOC_NAME_CE4200) {
		if (!_gen4d5_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_disable_interrupt: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		_gen4d5_gpio_disable_interrupts(m_idl_gpio_base, gpio_num);
	}
	else {
		if (!_gen5_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_disable_interrupt: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		_gen5_gpio_disable_interrupts(m_idl_gpio_base, gpio_num);
	}

	return IDL_SUCCESS;
}

idl_result_t 
idl_gpio_enable_interrupt(uint32_t gpio_num)
{
	// parameter checking
	// initialized?
	if (m_idl_gpio_base == NULL)
	{
		OS_DEBUG("idl_gpio_enable_interrupt: GPIO %ul not initialized\n", gpio_num);
		return IDL_NOT_INITIALIZED;
	}

	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {	
		if (!_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_enable_interrupt: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		_gpio_enable_interrupts(m_idl_gpio_base, gpio_num);
	}
	else if (soc == SOC_NAME_CE4200) {
		if (!_gen4d5_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_enable_interrupt: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		_gen4d5_gpio_enable_interrupts(m_idl_gpio_base, gpio_num);
	}
	else {
		if (!_gen5_gpio_supports_interrupts(gpio_num))
		{
			OS_DEBUG("idl_gpio_enable_interrupt: gpio number %d does not support interrupts.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		_gen5_gpio_enable_interrupts(m_idl_gpio_base, gpio_num);
	}

	return IDL_SUCCESS;
}

idl_result_t idl_gpio_multi_soc_register_interrupt_handler(uint32_t gpio_num, os_interrupt_handler_t *handler)
{
	uint32_t *irq_params = NULL;
	if (NULL == (irq_params = idl_gpio_get_irq_params(gpio_num)))
	{
		printk("get irq_param error\n");
		return IDL_INVALID_PARAM;
	}
	return idl_gpio_register_interrupt_handler(gpio_num,  handler, (void *)irq_params);
}

idl_result_t 
idl_gpio_register_interrupt_handler(uint32_t gpio_num, os_interrupt_handler_t *handler, void *data)
{
	int irq, devkey;

	/* parameter checking
	   initialized? */
	if (m_idl_gpio_base == NULL)
	{
		OS_DEBUG("idl_gpio_register_interrupt_handler: Not initialized\n");
		return IDL_NOT_INITIALIZED;
	}

	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		_gpio_get_interrupt_info(gpio_num, &irq, &devkey);
		m_interrupt_handler[gpio_num] = _gpio_os_acquire_interrupt(irq, devkey, handler, data);
	}
	else if (soc == SOC_NAME_CE4200) {
		_gen4d5_gpio_get_interrupt_info(gpio_num, &irq, &devkey);
		m_interrupt_handler[gpio_num] = _gen4d5_gpio_os_acquire_interrupt(irq, devkey, handler, data);
	}
	else {
		_gen5_gpio_get_interrupt_info(gpio_num, &irq, &devkey);
		m_interrupt_handler[gpio_num] = _gen5_gpio_os_acquire_interrupt(irq, devkey, handler, data);
	}
	
	if (m_interrupt_handler[gpio_num] == NULL)
	{
		return IDL_NOT_INITIALIZED;
	}

	return IDL_SUCCESS;
}

idl_result_t
idl_gpio_set_line(uint32_t gpio_num, uint32_t val)
{
	// parameter checking
	if (m_idl_gpio_base == NULL)
	{
		OS_DEBUG("idl_gpio_line_set: GPIO %d not initialized\n", gpio_num);
		return IDL_NOT_INITIALIZED;
	}

	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		// check to see if gpio number is in range
		if (!_valid_gpio_num(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// set the state of the gpio line specified
		_gpio_set_line(m_idl_gpio_base, gpio_num, (val & 0x1));
	}
	else if (soc == SOC_NAME_CE4200) {
		// check to see if gpio number is in range
		if (!_gen4d5_valid_gpio_num(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// set the state of the gpio line specified
		_gen4d5_gpio_set_line(m_idl_gpio_base, gpio_num, (val & 0x1));
	}
	else {
		// check to see if gpio number is in range
		if (!_gen5_valid_gpio_num(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// set the state of the gpio line specified
		_gen5_gpio_set_line(m_idl_gpio_base, gpio_num, (val & 0x1));
	}	
	return IDL_SUCCESS;
}

idl_result_t
idl_gpio_get_line(uint32_t gpio_num, uint32_t *val)
{
	// parameter checking
	if (m_idl_gpio_base == NULL)
	{
		OS_DEBUG("idl_gpio_line_set: GPIO %ul not initialized\n", gpio_num);
		return IDL_NOT_INITIALIZED;
	}

	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		// check to see if gpio number is in range
		if (!_valid_gpio_num(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gpio_get_line(m_idl_gpio_base, gpio_num, val);
	}
	else if (soc == SOC_NAME_CE4200) {
		// check to see if gpio number is in range
		if (!_gen4d5_valid_gpio_num(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen4d5_gpio_get_line(m_idl_gpio_base, gpio_num, val);
	}
	else {
		// check to see if gpio number is in range
		if (!_gen5_valid_gpio_num(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen5_gpio_get_line(m_idl_gpio_base, gpio_num, val);
	}
	
	return IDL_SUCCESS;
}

idl_result_t 
idl_gpio_release_interrupt_handler(uint32_t gpio_num)
{
	if (m_interrupt_handler[gpio_num] != NULL)
	{
		os_release_interrupt(m_interrupt_handler[gpio_num]);
		m_interrupt_handler[gpio_num] = NULL;
	}

	return IDL_SUCCESS;
}


void
idl_gpio_release()
{
	uint32_t size, num_ints, i;
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		size = _gpio_get_size();
		num_ints = _gpio_get_number_of_gpio_interrupts();
	}
	else if(soc == SOC_NAME_CE4200) {
		size = _gen4d5_gpio_get_size();
		num_ints = _gen4d5_gpio_get_number_of_gpio_interrupts();
	}
	else {
		size = _gen5_gpio_get_size();
		num_ints = _gen5_gpio_get_number_of_gpio_interrupts();
	}	
	if (m_idl_gpio_base == NULL) 
    {
		return;
    }

    if (m_number_instances > 0) 
    {
        m_number_instances--;
    }
        
	if (m_number_instances == 0)
	{
        // don't do anything if the user hasn't initialized the virtual ptr
		OS_DEBUG("idl_gpio_release: Releasing 0x%8.8X\n", (int)m_idl_gpio_base);
		OS_UNMAP_IO_FROM_MEM(m_idl_gpio_base, size);
		m_idl_gpio_base = NULL;

		// free any registered interrupt handlers
		for (i = 0; i < num_ints; i++)
		{
			if (m_interrupt_handler != NULL)
			{
				if (m_interrupt_handler[i] != NULL)
				{
					os_release_interrupt(m_interrupt_handler[i]);
					m_interrupt_handler[i] = NULL;
				}
				OS_FREE((void *)m_interrupt_handler);
				m_interrupt_handler = NULL;
			}
		}
		if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
			_gpio_sema_destroy();
		}
		else if(soc == SOC_NAME_CE4200) {
			_gen4d5_gpio_sema_destroy();
		}
		else {
			_gen5_gpio_sema_destroy();
		}
	}
}

idl_result_t idl_gpio_clear_ts(uint32_t gpio_num)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		// check to see if gpio number is in range
		if (!_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gpio_clear_ts(gpio_num);
	}
	else if(soc == SOC_NAME_CE4200) {
		// check to see if gpio number is in range
		if (!_gen4d5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen4d5_gpio_clear_ts(gpio_num);
	}
	else {
		// check to see if gpio number is in range
		if (!_gen5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen5_gpio_clear_ts(gpio_num);
	}
	
	return IDL_SUCCESS;
}

idl_result_t idl_gpio_get_ts(uint32_t gpio_num, uint32_t *setting)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		// check to see if gpio number is in range
		if (!_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gpio_get_ts(gpio_num, setting);
	}
	else if(soc == SOC_NAME_CE4200) {
		// check to see if gpio number is in range
		if (!_gen4d5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen4d5_gpio_get_ts(gpio_num, setting);
	}
	else {
		// check to see if gpio number is in range
		if (!_gen5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen5_gpio_get_ts(gpio_num, setting);
	}
	
	return IDL_SUCCESS;
}

idl_result_t idl_gpio_set_smi(uint32_t gpio_num, uint32_t setting)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		// check to see if gpio number is in range
		if (!_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gpio_set_smi(gpio_num, setting);
	}
	else  if(soc == SOC_NAME_CE4200) {
		// check to see if gpio number is in range
		if (!_gen4d5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen4d5_gpio_set_smi(gpio_num, setting);
	}
	else {
		// check to see if gpio number is in range
		if (!_gen5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen5_gpio_set_smi(gpio_num, setting);
	}
	
	return IDL_SUCCESS;
}

idl_result_t idl_gpio_set_gpe(uint32_t gpio_num, uint32_t setting)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		// check to see if gpio number is in range
		if (!_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gpio_set_gpe(gpio_num, setting);
	}
	else if (soc == SOC_NAME_CE4200) {
		// check to see if gpio number is in range
		if (!_gen4d5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen4d5_gpio_set_gpe(gpio_num, setting);
	}
	else {
		// check to see if gpio number is in range
		if (!_gen5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen5_gpio_set_gpe(gpio_num, setting);
	}
	
	return IDL_SUCCESS;
}

idl_result_t idl_gpio_set_trigger_negative(uint32_t gpio_num, uint32_t setting)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		// check to see if gpio number is in range
		if (!_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gpio_set_trigger_negative(gpio_num, setting);
	}
	else if(soc == SOC_NAME_CE4200){
		// check to see if gpio number is in range
		if (!_gen4d5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen4d5_gpio_set_trigger_negative(gpio_num, setting);
	}
	else {
		// check to see if gpio number is in range
		if (!_gen5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen5_gpio_set_trigger_negative(gpio_num, setting);
	}
	
	return IDL_SUCCESS;
}

idl_result_t idl_gpio_set_trigger_positive(uint32_t gpio_num, uint32_t setting)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		// check to see if gpio number is in range
		if (!_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
	
		// return the current value of the gpio line specified
		_gpio_set_trigger_positive(gpio_num, setting);
	}
	else if(soc == SOC_NAME_CE4200) {
		// check to see if gpio number is in range
		if (!_gen4d5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen4d5_gpio_set_trigger_positive(gpio_num, setting);
	}
	else {
		// check to see if gpio number is in range
		if (!_gen5_valid_gpio_num_NB(gpio_num))
		{
			OS_DEBUG("idl_gpio_line_set: gpio number %d invalid.\n", gpio_num);
			return IDL_INVALID_PARAM;
		}
		
		// return the current value of the gpio line specified
		_gen5_gpio_set_trigger_positive(gpio_num, setting);
	}
	
	return IDL_SUCCESS;
}

void idl_gpio_event_create()
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		_gpio_event_create();
	}
	else if(soc == SOC_NAME_CE4200){
		_gen4d5_gpio_event_create();
	}
	else {
		_gen5_gpio_event_create();
	}

}

void idl_gpio_event_destroy()
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		_gpio_event_destroy();
	}
	else if(soc == SOC_NAME_CE4200){
		_gen4d5_gpio_event_destroy();
	}
	else {
		_gen5_gpio_event_destroy();
	}
}

int idl_gpio_wait_for_irq(unsigned int gpio_num)
{
	int status = 0;
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		status = _gpio_wait_for_irq(gpio_num);
	}
	else if (soc == SOC_NAME_CE4200){
		status = _gen4d5_gpio_wait_for_irq(gpio_num);
	}
	else {
		status = _gen5_gpio_wait_for_irq(gpio_num);
	}
	
	return status;
}

void idl_gpio_irq_handler(int gpio_num)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		_gpio_irq_handler(gpio_num);
	}
	else if (soc == SOC_NAME_CE4200) {
		_gen4d5_gpio_irq_handler(gpio_num);
	}
	else {
		_gen5_gpio_irq_handler(gpio_num);
	}	
}


void idl_gpio_event_set(unsigned long gpio_num)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		_gpio_event_set(gpio_num);
	}
	else if (soc == SOC_NAME_CE4200) {
		_gen4d5_gpio_event_set(gpio_num);
	}
	else {
		_gen5_gpio_event_set(gpio_num);
	}
}


void idl_gpio_irq_release(int val)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		_gpio_irq_release(val);
	}
	else if (soc == SOC_NAME_CE4200) {
		_gen4d5_gpio_irq_release(val);
	}
	else {
		_gen5_gpio_irq_release(val);
	}	
}


void idl_gpio_set_irq_params(unsigned long gpio_num)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		_gpio_irq_set_irq_params(gpio_num);
	}
	else if (soc == SOC_NAME_CE4200) {
		_gen4d5_gpio_irq_set_irq_params(gpio_num);
	}
	else {
		_gen5_gpio_irq_set_irq_params(gpio_num);
	}	
}

uint32_t * idl_gpio_get_irq_params(unsigned long gpio_num)
{
	if(soc == SOC_NAME_CE3100 || soc == SOC_NAME_CE4100) {
		return _gpio_irq_get_irq_params(gpio_num);
	}
	else if (soc == SOC_NAME_CE4200) {
		return _gen4d5_gpio_irq_get_irq_params(gpio_num);
	}
	else {
		return _gen5_gpio_irq_get_irq_params(gpio_num);
	}
}

