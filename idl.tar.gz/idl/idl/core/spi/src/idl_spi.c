/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

#include "idl_spi.h"
#include "_spi.h"

/* Global state variables */

/* Per-port state information */
typedef struct {
	uint32_t port_number;
	spi_event_t enabled_events;
	spi_callback_t callback_function;
	void *callback_data;
} port_state_t;


static port_state_t port_status[NUM_SPI_PORTS];

static void spi_event_handler( port_state_t *port_state );


idl_result_t idl_spi_init( uint32_t spi_port_num ) 
{

	idl_result_t return_status = IDL_NOT_IMPLEMENTED;

	if ( !spi_is_valid_port_num( spi_port_num) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( spi_is_initialized(spi_port_num) ) {
		return_status = IDL_ALREADY_INITIALIZED;
	}
    else if ( !spi_init_port(spi_port_num) ) {
		return_status = IDL_NO_RESOURCES;
	}
	else {
		port_status[spi_port_num].callback_function = NULL;
		port_status[spi_port_num].callback_data     = NULL;
		port_status[spi_port_num].enabled_events    = SPI_EVENT_NONE;
		port_status[spi_port_num].port_number       = spi_port_num;
		return_status = IDL_SUCCESS;
	}

	return ( return_status );
}


idl_result_t idl_spi_release(uint32_t spi_port_num)
{
	idl_result_t return_status = IDL_NOT_IMPLEMENTED;

	if ( !spi_is_valid_port_num( spi_port_num) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_is_initialized(spi_port_num) ) {
		return_status = IDL_NOT_INITIALIZED;
	}
	else {
		/* Make sure we shutdown gracefully: disable events, callbacks, and finally the port. */
		idl_spi_event_disable( spi_port_num, SPI_EVENT_ALL );
		idl_spi_set_event_callback( spi_port_num, (spi_callback_t) NULL, NULL );
		spi_deinit_port( spi_port_num );
		return_status = IDL_SUCCESS;
	}

	return ( return_status );
}


idl_result_t idl_spi_set_config(uint32_t spi_port_num, spi_config_t *spi_config)
{
	idl_result_t return_status = IDL_NOT_IMPLEMENTED;

	if ( !spi_is_valid_port_num( spi_port_num) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_is_initialized(spi_port_num) ) {
		return_status = IDL_NOT_INITIALIZED;
	}
	else if ( !spi_set_bit_rate(spi_port_num, spi_config->clock_rate) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_set_data_size(spi_port_num, spi_config->data_size) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_set_frame_format(spi_port_num, spi_config->frame_format) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_set_clock_polarity(spi_port_num, spi_config->clock_polarity) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_set_rx_threshold( spi_port_num, spi_config->rx_threshold)  ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_set_tx_threshold( spi_port_num, spi_config->tx_threshold)  ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_set_phase_type( spi_port_num, spi_config->phase)  ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_set_chip_select( spi_port_num, spi_config->chip_select)  ) {
		return_status = IDL_INVALID_PARAM;
	}
	else {
		return_status = IDL_SUCCESS;
	}

	return ( return_status );
}


idl_result_t idl_spi_get_status(uint32_t spi_port_num, spi_status_t *spi_status)
{
	idl_result_t return_status = IDL_NOT_IMPLEMENTED;

	if ( !spi_is_valid_port_num( spi_port_num) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_is_initialized(spi_port_num) ) {
		return_status = IDL_NOT_INITIALIZED;
	}
	else {
		spi_status->rx_fifo_size   = spi_get_rx_fifo_size( spi_port_num );
		spi_status->tx_fifo_size   = spi_get_tx_fifo_size( spi_port_num );
		spi_status->rx_fifo_level  = spi_get_rx_fifo_level( spi_port_num );
		spi_status->tx_fifo_level  = spi_get_tx_fifo_level( spi_port_num );
		spi_status->event_status   = spi_get_event_status( spi_port_num );
		spi_status->events_enabled = spi_get_enabled_events( spi_port_num );
		return_status = IDL_SUCCESS;
	}

	return ( return_status );
}


idl_result_t idl_spi_set_event_callback(uint32_t spi_port_num, spi_callback_t callback_function, void *callback_data)
{
	idl_result_t return_status = IDL_NOT_IMPLEMENTED;

	if ( !spi_is_valid_port_num(spi_port_num) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_is_initialized(spi_port_num) ) {
		return_status = IDL_NOT_INITIALIZED;
	}
	else if ( port_status[spi_port_num].enabled_events != SPI_EVENT_NONE ) {
		/* Caller must disable all events on this port before calling spi_set_event_callback() */
		return_status = IDL_DEVICE_BUSY;
	}
	else {
		if ( (callback_function != NULL) && (port_status[spi_port_num].callback_function == NULL) ) {
			spi_acquire_interrupt( spi_port_num, spi_event_handler, &(port_status[spi_port_num]) );
		}
		else if ( (callback_function == NULL) && (port_status[spi_port_num].callback_function != NULL) ) {
			spi_release_interrupt( spi_port_num );
		}
		port_status[spi_port_num].callback_function = callback_function;
		port_status[spi_port_num].callback_data = callback_data;
		return_status = IDL_SUCCESS;
	}

	return ( return_status );
}


idl_result_t idl_spi_event_enable( uint32_t spi_port_num, spi_event_t spi_events )
{
	idl_result_t return_status = IDL_NOT_IMPLEMENTED;

	if ( !spi_is_valid_port_num(spi_port_num) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_is_initialized(spi_port_num) ) {
		return_status = IDL_NOT_INITIALIZED;
	}
	else if ( port_status[spi_port_num].callback_function == NULL )	{
		return_status = IDL_DEVICE_BUSY;
	}
	else if ( !spi_enable_events(spi_port_num, spi_events) ) {
		return_status = IDL_INVALID_PARAM;		
	}
	else {
		port_status[spi_port_num].enabled_events |= spi_events;
		return_status = IDL_SUCCESS;
	}

	return ( return_status );
}


idl_result_t idl_spi_event_disable( uint32_t spi_port_num, spi_event_t spi_events )
{
	
	idl_result_t return_status = IDL_NOT_IMPLEMENTED;
	if ( spi_port_num > (sizeof(port_status)/sizeof(port_status[0])-1) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_is_valid_port_num(spi_port_num) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_is_initialized(spi_port_num) ) {
		return_status = IDL_NOT_INITIALIZED;
	}
	else if ( !spi_disable_events(spi_port_num, spi_events) ) {
		return_status = IDL_INVALID_PARAM;		
	}
	else {
		port_status[spi_port_num].enabled_events &= ~spi_events;
		return_status = IDL_SUCCESS;
	}

	return ( return_status );
}


#if 0
idl_result_t idl_spi_event_handled( uint32_t spi_port_num, spi_event_t handled_events )
{
	spi_event_t enabled_events;
	idl_result_t return_status = IDL_NOT_IMPLEMENTED;

	if ( !spi_is_valid_port_num(spi_port_num) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_is_initialized(spi_port_num) ) {
		return_status = IDL_NOT_INITIALIZED;
	}
	else if ( (handled_events & ~SPI_EVENT_ALL) != 0) {
		return_status = IDL_INVALID_PARAM;
	}
	else {
		enabled_events = spi_get_enabled_events( spi_port_num );
		spi_enable_events( spi_port_num, (handled_events & enabled_events) );
		return_status = IDL_SUCCESS;
	}

	return ( return_status );
}
#endif


idl_result_t idl_spi_write(uint32_t spi_port_num, uint32_t data)
{
	idl_result_t return_status = IDL_NOT_IMPLEMENTED;

	if ( !spi_is_valid_port_num(spi_port_num) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_is_initialized(spi_port_num) ) {
		return_status = IDL_NOT_INITIALIZED;
	}
	else if ( !spi_write_data(spi_port_num, data) ) {
		return_status = IDL_DEVICE_BUSY;
	}
	else {
		return_status = IDL_SUCCESS;
	}

	return ( return_status );
}


idl_result_t idl_spi_read(uint32_t spi_port_num, uint32_t *data)
{
	idl_result_t return_status = IDL_NOT_IMPLEMENTED;

	if ( !spi_is_valid_port_num(spi_port_num) ) {
		return_status = IDL_INVALID_PARAM;
	}
	else if ( !spi_is_initialized(spi_port_num) ) {
		return_status = IDL_NOT_INITIALIZED;
	}
	else if ( !spi_read_data(spi_port_num, data) ) {
		return_status = IDL_DEVICE_BUSY;
	}
	else {
		return_status = IDL_SUCCESS;
	}

	return ( return_status );
}


/*
 * This function just invokes the user's callback function 
 * when an event occurs.  It could probably be moved to the 
 * lower layer if necessary.
 */

static void spi_event_handler( port_state_t *port_state )
{
	
	/* Invoke the user's callback function. */
	(*(port_state->callback_function))(port_state->callback_data);

	return;
}
