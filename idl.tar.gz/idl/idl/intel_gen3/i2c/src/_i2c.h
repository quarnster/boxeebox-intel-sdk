/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*------------------------------------------------------------------------------
 * File Name: _i2c.h
 *------------------------------------------------------------------------------
 */

#ifndef __I2C_H_
#define __I2C_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @weakgroup _i2c I2C Module */
/*@{*/

/* IDL_DRIVER is defined during compile process to switch between compiling for
 * kernel versus user space
 */

#ifndef IDL_DRIVER
#include <stdint.h>
#include <stdbool.h>
#endif

#include <osal_type.h>
#include <osal_interrupt.h>
#include "idl.h"
#include "idl_i2c.h"

//define HARDCODE_BAR, will use the hardcode base address, otherwise, will get base address from pal
//#define HARDCODE_BAR

/* Define _I2C_XDB as non-zero to print out XDB script */
#define _I2C_XDB                          0  /* EPC - Disable */
/* Define the routine to print out the XDB script */
#define _I2C_XDB_PRINT                    printf

/* Define _I2C_DEBUG as non-zero to print out debug messages */
#define _I2C_DEBUG                        0  /* EPC - Disable */
/* Define the routine to print out the debug messages */
#define _I2C_DEBUG_PRINT                  printf

/* Base physical address of i2c bus plus interrupt controller */
#define _I2C_BASE_ADDR                    0xdffe0000

#define _I2C_BASE_ADDR_I2C0               0xdffe0500
#define _I2C_BASE_ADDR_I2C1               0xdffe0600
#define _I2C_BASE_ADDR_I2C2               0xdffe0700
#define _I2C_BASE_ADDR_I2C3               0xdffe0e00
/* Compatible max address for the 3 bus i2c controller */
#define _I2C_COMPAT_MAX_ADDR                     0xdffe0800

/* Compatible Address range of i2c bus including interrupt controller */
#define _I2C_COMPAT_ADDR_RANGE                   (_I2C_COMPAT_MAX_ADDR - _I2C_BASE_ADDR_I2C0)

/* each i2c bus has 256 bytes memmaped space */
#define _I2C_ONE_BUS_ADDR_RANGE                 0x100

/* Bits for ICR register */
#define _I2C_ICR_DEFAULT_MODE             0x00000000
#define _I2C_ICR_FAST_MODE                (1 << 15)
#define _I2C_ICR_UNIT_RESET               (1 << 14)
#define _I2C_ICR_SLAVE_ADDRESS            (1 << 13)
#define _I2C_ICR_ARBITRATION_LOSS         (1 << 12)
#define _I2C_ICR_SLAVE_STOP               (1 << 11)
#define _I2C_ICR_BUS_ERROR                (1 << 10)
#define _I2C_ICR_RECEIVE_FULL             (1 << 9)
#define _I2C_ICR_TRANSMIT_EMPTY           (1 << 8)
#define _I2C_ICR_GENERAL_CALL_DISABLE     (1 << 7)
#define _I2C_ICR_UNIT_ENABLE              (1 << 6)
#define _I2C_ICR_SCL_ENABLE               (1 << 5)
#define _I2C_ICR_MASTER_STOP              (1 << 4)
#define _I2C_ICR_TRANSFER_BYTE            (1 << 3)
#define _I2C_ICR_NACK                     (_I2C_SEND_NACK)
#define _I2C_ICR_STOP                     (_I2C_SEND_STOP)
#define _I2C_ICR_START                    (_I2C_SEND_START)

/* Bits for ISR register */
#define _I2C_ISR_BUS_ERROR                (_I2C_BUS_ERROR)
#define _I2C_ISR_SLAVE_ADDRESS            (1 << 9)
#define _I2C_ISR_RECEIVE_FULL             (_I2C_RECEIVE_FULL)
#define _I2C_ISR_TRANSMIT_EMPTY           (_I2C_TRANSMIT_EMPTY)
#define _I2C_ISR_ARBITRATION_LOSS         (_I2C_ARBITRATION_LOSS)
#define _I2C_ISR_SLAVE_STOP               (1 << 4)
#define _I2C_ISR_BUS_BUSY                 (1 << 3)
#define _I2C_ISR_UNIT_BUSY                (1 << 2)
#define _I2C_ISR_ACK_NACK                 (1 << 1)
#define _I2C_ISR_READ_WRITE               (1 << 0)

/* Maximum number of polling a register */
#define _I2C_POLL_COUNT                   0x00001000

/** Number of i2c buses available in the system */
#define _I2C_MAX_BUS_COUNT                 4
/** Number of i2c buses available in the system */
#define _I2C_GEN3_BUS_COUNT                 3
/** Number of i2c buses available in the system */
#define _I2C_GEN5_BUS_COUNT                 4

/** Send only data onto the bus */
#define _I2C_SEND_DATA                 0
/** Send START condition onto the bus */
#define _I2C_SEND_START                (1 << 0)
/** Send STOP condition onto the bus */
#define _I2C_SEND_STOP                 (1 << 1)
/** Send NACK acknowledgement bit */
#define _I2C_SEND_NACK                 (1 << 2)

/** Interrupt flag that is empty */
#define _I2C_NO_INTERRUPT              0
/** Interrupt flag for losing arbitration */
#define _I2C_ARBITRATION_LOSS          (1 << 5)
/** Interrupt flag for bus transmitter is empty */
#define _I2C_TRANSMIT_EMPTY            (1 << 6)
/** Interrupt flag for bus receiver is full */
#define _I2C_RECEIVE_FULL              (1 << 7)
/** Interrupt flag for bus error */
#define _I2C_BUS_ERROR                 (1 << 10)

/* Physical address for status of interrupt controller */
#define GEN3_IRQ_BASE				0xBFFFF000
#define GEN3_IRQ_SIZE				256
#define GEN3_IRQ_MASK_OFFSET		0x80
#define GEN3_I2C_IRQ_MASK_OFFSET	16

/** This enumeration lists the i2c registers */

typedef enum {
   _I2C_REG_ICR = 0x00000000,    /**< Control register */
   _I2C_REG_ISR = 0x00000004,    /**< Status register */
   _I2C_REG_ISAR = 0x00000008,   /**< Slave address register */
   _I2C_REG_IDBR = 0x0000000c,   /**< Data buffer register */
   _I2C_REG_ICCR = 0x00000010,   /**< Clock control register */
   _I2C_REG_IBMR = 0x00000014,    /**< Bus monitor register */
   _I2C_REG_IWCR = 0x00000018,    /*Wait count register*/
   _I2C_REG_ISMSCR = 0x0000001C, /*Standard mode short count register*/
   _I2C_REG_ISMLCR = 0x00000020, /*standard mode long count register*/
   _I2C_REG_IFMSCR = 0x00000024, /*fast mode short count register*/
   _I2C_REG_IFMLCR = 0x00000028 /*fast mode long count register*/
} _i2c_register_t;

/** This enumeration lists the i2c operating modes */

typedef enum {
   _I2C_MODE_STANDARD,           /**< Standard mode up to 100 kb/s */
   _I2C_MODE_FAST                /**< Fast mode up to 400 kb/s */
} _i2c_mode_t;

/** This enumeration lists the return code for the i2c functions */

typedef enum {
   _I2C_SUCCESS,                 /**< Operation succeeded */
   _I2C_INVALID_PARAM,           /**< Invalid parameter passed in */
	_I2C_NOT_INITIALIZED,         /**< Bus units are not initialized */
	_I2C_ALREADY_INITIALIZED,     /**< Bus units are already initialized */
   _I2C_FAILURE,                 /**< Operation failed */
   _I2C_NOT_IMPLEMENTED,         /**< Operation not implemented */
   _I2C_DEVICE_BUSY              /**< Device is busy */
} _i2c_result_t;

/**
This function gets the number of available i2c bus units within the system.
@param[out] *p_bus_count - Number of i2c bus units within system.
@retval _I2C_SUCCESS is always returned.
*/

_i2c_result_t
_i2c_get_bus_count(uint8_t *p_bus_count);

/**
This function gets the number of available i2c bus units within the system
It is defined as the inline function and used interneally.
@retval The value of platform available i2c bus
*/
uint8_t _i2c_bus_count_value(void);

/**
This function set the number of platform available i2c bus units within the system.
@retval _I2C_SUCCESS is always returned.
*/
_i2c_result_t
_i2c_get_platform_bus_count(void);

/**
This function opens all i2c bus units within the system and resets them.
@retval IDL_SUCCESS if opened all bus units.
@retval IDL_ALREADY_INITIALIZED if already initialized or opened.
@retval IDL_FAILURE if couldn't allocate virtual page or couldn't set speed 
mode or reset individual units.
*/

_i2c_result_t
_i2c_open(void);

/**
This function closes all i2c bus units within the system and frees up 
allocated virtual page.
@retval _I2C_SUCCESS if closed all bus units.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
*/

_i2c_result_t
_i2c_close(void);

/**
This function sets the operating mode of a specified i2c bus unit.
@param[in] bus_num - Index to identify an i2c bus unit.
@param[in] mode - Operating mode.
@retval _I2C_SUCCESS if set the operating mode for the specified bus unit.
@retval _I2C_INVALID_PARAM if bus_num is out of range.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
unit.
*/

_i2c_result_t
_i2c_set_mode(uint8_t bus_num, _i2c_mode_t mode);

/**
This function resets a specified i2c bus unit.
@param[in] bus_num - Index to identify an i2c bus unit.
@retval _I2C_SUCCESS if reset the specified bus unit.
@retval _I2C_INVALID_PARAM if bus_num is out of range.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
@retval _I2C_DEVICE_BUSY if i2c bus unit is busy.
@retval _I2C_FAILURE if i2c bus unit is still busy after resetting unit or 
couldn't access registers.
*/

_i2c_result_t
_i2c_reset(uint8_t bus_num);

/**
This function reads one data byte from the bus while setting the appropriate
conditions as specified by control_flags. This fucntion is called by device which
need implement dummy read.
@param[in] bus_num - Index to identify an i2c bus unit.
@param[in] control_flags - OR'ed flags using _I2C_SEND_STOP and _I2C_SEND_ACK.
@param[in] interrupt_flags - OR'ed flags using:  IDL_I2C_RECEIVE_FULL and
IDL_I2C_TRANSMIT_EMPTY.
@param[in] wait_condition - Timed out in ms if interrupt-driven and number of
polling loops if polling.
@param[out] *p_data_byte - Data byte to be read.
@retval _I2C_SUCCESS if read one data byte.
@retval _I2C_INVALID_PARAM if bus_num is out of range or control_flags contains
more than the allowed flags.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
@retval _I2C_FAILURE if couldn't access registers.
*/

_i2c_result_t
_i2c_read_byte_without_dummy(uint8_t bus_num, uint32_t control_flags, uint8_t *p_data_byte,
 uint32_t interrupt_flags,uint32_t wait_condition);

/**
This function reads one data byte from the bus while setting the appropriate
conditions as specified by control_flags.
@param[in] bus_num - Index to identify an i2c bus unit.
@param[in] control_flags - OR'ed flags using _I2C_SEND_STOP and _I2C_SEND_ACK.
@param[out] *p_data_byte - Data byte to be read.
@retval _I2C_SUCCESS if read one data byte.
@retval _I2C_INVALID_PARAM if bus_num is out of range or control_flags contains
more than the allowed flags.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
@retval _I2C_FAILURE if couldn't access registers.
*/

_i2c_result_t
_i2c_read_byte(uint8_t bus_num, uint32_t control_flags, uint8_t *p_data_byte);

/**
This function writes one data byte to the bus while setting the appropriate
conditions as specified by control_flags.
@param[in] bus_num - Index to identify an i2c bus unit.
@param[in] control_flags - OR'ed flags using: _I2C_SEND_START, _I2C_SEND_STOP, 
and _I2C_SEND_ACK.
@param[in] data_byte - Data byte to be written.
@retval _I2C_SUCCESS if written one data byte.
@retval _I2C_INVALID_PARAM if bus_num is out of range or control_flags contains
more than the allowed flags.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
@retval _I2C_FAILURE if couldn't access registers.
*/

_i2c_result_t
_i2c_write_byte(uint8_t bus_num, uint32_t control_flags, uint8_t data_byte);

/**
This function reads a register within the selected i2c bus unit.
@param[in] bus_num - Index to identify an i2c bus unit.
@param[in] reg - Register within i2c bus unit.
@param[out] *p_reg_value - Register value to be read.
@retval _I2C_SUCCESS if successfully read the register.
@retval _I2C_INVALID_PARAM if bus_num is out of range.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
*/

_i2c_result_t
_i2c_read_register(uint8_t bus_num, _i2c_register_t reg, uint32_t *p_reg_value);

/**
This function writes a register within the selected i2c bus unit.
@param[in] bus_num - Index to identify an i2c bus unit.
@param[in] reg - Register within i2c bus unit.
@param[in] reg_value - Register value to be written.
@retval _I2C_SUCCESS is successfully written the register.
@retval _I2C_INVALID_PARAM if bus_num is out of range.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
*/

_i2c_result_t
_i2c_write_register(uint8_t bus_num, _i2c_register_t reg, uint32_t reg_value);

/**
This function reads from an address location.  The address cannot be lower than
the lowest address for interrupt controller or i2c bus units or higher than
the highest address for the same units.
@param[in] address - Address.
@param[out] *p_address_value - Address value to be read.
@retval _I2C_SUCCESS if successfully read the address location.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
*/

_i2c_result_t
_i2c_read_address(uint32_t address, uint32_t *p_address_value);

/**
This function writes to an address location.  The address cannot be lower than
the lowest address for interrupt controller or i2c bus units or higher than
the highest address for the same units.
@param[in] address - Address.
@param[in] address_value - Address value to be written.
@retval _I2C_SUCCESS if successfully written the address location.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
*/

_i2c_result_t
_i2c_write_address(uint32_t address, uint32_t address_value);

/**
This function sets the interrupt mask to enable or disable interrupts from 
the specified i2c bus unit.
@param[in] bus_num - Index to identify an i2c bus unit.
@param[in] interrupt_mask - OR'ed flags using:  _I2C_BUS_ERROR, 
_I2C_RECEIVE_FULL, _I2C_TRANSMIT_EMPTY, and _I2C_ARBITRATION_LOSS.
@retval _I2C_SUCCESS if set interrupt mask.
@retval _I2C_INVALID_PARAM if bus_num is out of range or interrupt_flags 
contains more than the allowed flags.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
@retval _I2C_FAILURE if couldn't access registers.
*/

_i2c_result_t
_i2c_set_interrupt_mask(uint8_t bus_num, uint32_t interrupt_mask);

/**
This function gets the interrupt mask to determine which interrupts are enabled
from the specified i2c bus unit.
@param[in] bus_num - Index to identify an i2c bus unit.
@param[out] *p_interrupt_mask - OR'ed flags using:  _I2C_BUS_ERROR, 
_I2C_RECEIVE_FULL, _I2C_TRANSMIT_EMPTY, and _I2C_ARBITRATION_LOSS.
@retval _I2C_SUCCESS if got interrupt mask.
@retval _I2C_INVALID_PARAM if bus_num is out of range or interrupt_flags 
contains more than the allowed flags.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
@retval _I2C_FAILURE if couldn't access registers.
*/

_i2c_result_t
_i2c_get_interrupt_mask(uint8_t bus_num, uint32_t *p_interrupt_mask);

/**
This function get the interruput status register value.
@param[in] bus_num - Index to identify an i2c bus
@param[out] *interrupt_value - The value of ISR
@retval _I2C_SUCCESS if getting the value of ISR
@retval _I2C_FAILURE if failling to get the value of ISR
**/

_i2c_result_t
_i2c_read_interrupts_status(uint8_t bus_num, uint32_t *interrupt_value);

/**
This function clear interrupts.
@param[in] bus_num - Index to identify an i2c bus
@param[in] interrupt_flags - The interrupt flags to point out which interrupt bit
will be checked.  
@retval _I2C_SUCCESS if clearing interrupt bits
@retval _I2C_INVALID_PARAM if flags are not interrupt bits.
@retval _I2C_FAILURE if failling to clear interrupt bits
*/

_i2c_result_t 
_i2c_clear_interrupts(uint8_t bus_num, uint32_t interrupt_flags);

/**
This function determines if there are pending interrupts for the specified i2c
bus unit.  This function will clear any pending interrupts.
@param[in] bus_num - Index to identify an i2c bus.
@param[out] *p_interrupt_flags - OR'ed flags using:  _I2C_BUS_ERROR, 
_I2C_RECEIVE_FULL, _I2C_TRANSMIT_EMPTY, and _I2C_ARBITRATION_LOSS.
@retval _I2C_SUCCESS if got pending interrupts.
@retval _I2C_INVALID_PARAM if bus_num is out of range.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
@retval _I2C_FAILURE if couldn't access registers or has other spurious 
interrupts.
*/

_i2c_result_t
_i2c_get_pending_interrupts(uint8_t bus_num, uint32_t *p_interrupt_flags);

/**
This function register interrupt handler for the specified i2c
bus unit.  This will first release old interrupt handler.
@param[in] bus_num - Index to identify an i2c bus.
@param[in] *p_interrupt_handler - Interrupt handler function.
@param[in] *p_interrupt_data - Parameter for interrupt handler function.
@retval _I2C_SUCCESS if registered interrupt handler.
@retval _I2C_INVALID_PARAM if bus_num is out of range.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
@retval _I2C_FAILURE if couldn't register interrupt handler.
*/

_i2c_result_t
_i2c_register_interrupt_handler(uint8_t bus_num, 
   os_interrupt_handler_t *p_interrupt_handler, void *p_interrupt_data);

/**
This function release interrupt handler for the specified i2c
bus unit.
@param[in] bus_num - Index to identify an i2c bus.
@retval _I2C_SUCCESS if released interrupt handler.
@retval _I2C_INVALID_PARAM if bus_num is out of range.
@retval _I2C_NOT_INITIALIZED if the bus units were not initialized or opened.
*/

_i2c_result_t
_i2c_release_interrupt_handler(uint8_t bus_num);

/*@}*/

#ifdef __cplusplus
}
#endif

#endif
