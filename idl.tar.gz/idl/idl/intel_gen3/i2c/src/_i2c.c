/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc. 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*------------------------------------------------------------------------------
 * File Name: _i2c.c
 *------------------------------------------------------------------------------
 *
 */

#ifdef __cplusplus
extern "C" {
#endif

#include <linux/pci.h>

#ifndef LINUX_DRIVER
#include <stdio.h>
#include <stdlib.h>
#endif
#include "osal.h"
#include <pal_interrupt.h>
#include <osal_memmap.h>

#include <_i2c.h>

/*------------------------------------------------------------------------------
 * Private declarations
 *------------------------------------------------------------------------------
 */

/* Structure to hold state of all i2c bus units */
typedef struct {
   bool is_opened;
   uint8_t num_instances;
   uint32_t virt_addr_offset;
   uint32_t virt_addr_offset_bus[_I2C_MAX_BUS_COUNT];
   os_interrupt_t interrupt_handle[_I2C_MAX_BUS_COUNT];
   _i2c_mode_t mode[_I2C_MAX_BUS_COUNT];
} _i2c_state_t;

/*------------------------------------------------------------------------------
 * Global variables
 *------------------------------------------------------------------------------
 */

/* Bits for interrupt controller registers */
const uint32_t _i2c_irq_bit[_I2C_MAX_BUS_COUNT] = {
   (1 << GEN3_I2C_IRQ_MASK_OFFSET),
   (1 << GEN3_I2C_IRQ_MASK_OFFSET),
   (1 << GEN3_I2C_IRQ_MASK_OFFSET),
   (1 << GEN3_I2C_IRQ_MASK_OFFSET)
};

/* Address offset of each i2c bus unit to allocated virtual memory page */
const uint32_t _i2c_addr_offset[_I2C_MAX_BUS_COUNT] = {
   (_I2C_BASE_ADDR_I2C0 - _I2C_BASE_ADDR_I2C0),
   (_I2C_BASE_ADDR_I2C1 - _I2C_BASE_ADDR_I2C0),
   (_I2C_BASE_ADDR_I2C2 - _I2C_BASE_ADDR_I2C0),
   (_I2C_BASE_ADDR_I2C3 - _I2C_BASE_ADDR_I2C0)
};

/* Interrupt identification for OSAL & PAL */
const pal_dev_id_t _i2c_irq_id[_I2C_MAX_BUS_COUNT] = {
   I2C_0,
   I2C_1,
   I2C_2,
   I2C_3,
};

/* Allocated structure to hold state of all i2c bus units */
static _i2c_state_t _i2c_state = {
   false,            /* is_opened */
   0x0,           
   0x00000000,       /* virt_addr_offset */
   {0x00000000,       /* virt_addr_offset bus 0*/
   0x00000000,       /* virt_addr_offset bus 1*/
   0x00000000,       /* virt_addr_offset bus 2*/
   0x00000000},       /* virt_addr_offset bus 3*/
   {NULL,             /* interrupt_handle */
   NULL,
   NULL,
   NULL},
   {_I2C_MODE_FAST,  /* mode */
   _I2C_MODE_FAST,
   _I2C_MODE_FAST,
   _I2C_MODE_FAST}
};

/* Address offset of each i2c bus unit to allocated virtual memory page */
const uint32_t _i2c_addr[_I2C_MAX_BUS_COUNT] = {
   (_I2C_BASE_ADDR_I2C0),
   (_I2C_BASE_ADDR_I2C1),
   (_I2C_BASE_ADDR_I2C2),
   (_I2C_BASE_ADDR_I2C3)
};

static pal_soc_name_t soc_name = SOC_NAME_CE4100;
static uint8_t _i2c_bus_count = _I2C_MAX_BUS_COUNT;
uint32_t irq_base = 0x0;

/*------------------------------------------------------------------------------
 * _i2c_get_bus_count
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_get_bus_count(uint8_t *p_bus_count)
{
  *p_bus_count = _i2c_bus_count;
  return _I2C_SUCCESS;
}

inline uint8_t _i2c_bus_count_value(void)
{
   return _i2c_bus_count;
}

/*------------------------------------------------------------------------------
 * _i2c_get_platform_bus_count
 *------------------------------------------------------------------------------
 */
 
_i2c_result_t
_i2c_get_platform_bus_count(void)
{

   pal_soc_info_t pal_soc_info;
   	if( PAL_SUCCESS != pal_get_soc_info(&pal_soc_info)) {
		_OS_ERROR("_i2c_get_bus_count: pal_get_soc_info FAILURE: could not get soc info to pal_info \n");
		return _I2C_FAILURE;
	}

	switch(pal_soc_info.name)
	{
          case SOC_NAME_CE3100:
          case SOC_NAME_CE4100:
          case SOC_NAME_CE4200:
	     _i2c_bus_count =  ( _I2C_MAX_BUS_COUNT <_I2C_GEN3_BUS_COUNT )? _I2C_MAX_BUS_COUNT:_I2C_GEN3_BUS_COUNT;
	     break;
          case SOC_NAME_CE5300:
             _i2c_bus_count =  ( _I2C_MAX_BUS_COUNT <_I2C_GEN5_BUS_COUNT )? _I2C_MAX_BUS_COUNT:_I2C_GEN5_BUS_COUNT;
	     break;
          default:
	     OS_PRINT("SOC chip is not supported\n");
             _i2c_bus_count = _I2C_GEN3_BUS_COUNT;
	 }

   return _I2C_SUCCESS;
}

/*------------------------------------------------------------------------------
 * _i2c_open
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_open(void)
{
   uint8_t bus_num;
    uint32_t phyad;
   pal_info_t *pal_info =NULL;
   pal_soc_info_t pal_soc_info;
   _i2c_state.num_instances++;

   if (_i2c_state.is_opened) {
      return _I2C_ALREADY_INITIALIZED;
   }
 
   	if( PAL_SUCCESS != pal_get_soc_info(&pal_soc_info)) {
		_OS_ERROR("_i2c_get_bus_count: pal_get_soc_info FAILURE: could not get soc info to pal_info \n");
		return _I2C_FAILURE;
	}
    soc_name = pal_soc_info.name;

   switch (soc_name )
    {
    	case SOC_NAME_CE3100:
    	case SOC_NAME_CE4100:
    	case SOC_NAME_CE4200:
	  //printk("in the _i2c_open 4200\n"); 
#ifdef HARDCODE_BAR
        /* One time allocation of virtual address page for all i2c devices */
        _i2c_state.virt_addr_offset = (uint32_t) OS_MAP_IO_TO_MEM_NOCACHE(
        _I2C_BASE_ADDR_I2C0, _I2C_COMPAT_ADDR_RANGE);
#else
        //get the base address from pal
        pal_info = (pal_info_t *)OS_ALLOC(sizeof(pal_info_t));
        if (pal_info == NULL)
        {
          // printk("OS_ALLOC FAILURE : could not alloc memory to pal_info \n");
          return false;
        }
        if ( pal_get_base_and_irq(I2C_0, &pal_info) != PAL_SUCCESS ) {
               OS_FREE(pal_info);
               return false;
          }
         phyad = pal_info->base_addr0;
         _i2c_state.virt_addr_offset = (uint32_t) OS_MAP_IO_TO_MEM_NOCACHE(phyad,_I2C_COMPAT_ADDR_RANGE);
        OS_FREE(pal_info);
#endif
       /* Check to see if virtual address page was allocated */
        if (_i2c_state.virt_addr_offset == 0x00000000) {
          return _I2C_FAILURE;
        } 
       break;
       
      case SOC_NAME_CE5300:
	  //printk("in the _i2c_open CE5300\n"); 
#ifdef HARDCODE_BAR
        for ( bus_num=0;bus_num< _i2c_bus_count;bus_num++) {
          /*  allocation of virtual address page for each i2c devices */
          _i2c_state.virt_addr_offset_bus[bus_num] = (uint32_t) OS_MAP_IO_TO_MEM_NOCACHE(
          _i2c_addr[bus_num], _I2C_ONE_BUS_ADDR_RANGE);
        }  
#else
        pal_info = (pal_info_t *)OS_ALLOC(sizeof(pal_info_t));
        if (pal_info == NULL)
        {
            // printk("OS_ALLOC FAILURE : could not alloc memory to pal_info \n");
            return false;
          }
          for ( bus_num=0;bus_num< _i2c_bus_count;bus_num++) {
            if ( pal_get_base_and_irq(_i2c_irq_id[bus_num], &pal_info) != PAL_SUCCESS ) {
                OS_FREE(pal_info);
                return false;
            }
            phyad = pal_info->base_addr0;
            _i2c_state.virt_addr_offset_bus[bus_num] =  (uint32_t) OS_MAP_IO_TO_MEM_NOCACHE(phyad,_I2C_ONE_BUS_ADDR_RANGE);
          }
        OS_FREE(pal_info);
#endif
       /* Check to see if virtual address page was allocated */
        for ( bus_num=0;bus_num< _i2c_bus_count;bus_num++) {
          if (_i2c_state.virt_addr_offset_bus[bus_num] == 0x00000000) {
          return _I2C_FAILURE;
        }
       } 
      break;

    }

   irq_base = (uint32_t)OS_MAP_IO_TO_MEM_NOCACHE(GEN3_IRQ_BASE, GEN3_IRQ_SIZE);

   /* Check to see if virtual address page was allocated */
   if (irq_base == 0x00000000) {
      return _I2C_FAILURE;
   }
   
   _i2c_state.is_opened = true;

   /* Default all units to no interrupt handler and fast mode and reset them */
   for (bus_num = 0; bus_num < _i2c_bus_count; bus_num++) {
      if (_i2c_state.interrupt_handle[bus_num] != NULL) {
#if 1 /* EPC */
         os_release_interrupt(_i2c_state.interrupt_handle[bus_num]);
#endif
         _i2c_state.interrupt_handle[bus_num] = NULL;
      }
      if (_i2c_set_mode(bus_num, _I2C_MODE_FAST) != _I2C_SUCCESS) {
         goto exception;
      }
      if (_i2c_reset(bus_num) != _I2C_SUCCESS) {
         goto exception;
      }
   }
   return _I2C_SUCCESS;
exception:
   _i2c_close();
   return _I2C_FAILURE;
}

/*------------------------------------------------------------------------------
 * _i2c_close
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_close(void)
{
   uint8_t bus_num;

   if (!_i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   if (_i2c_state.num_instances > 0) {
      _i2c_state.num_instances--;
   }

   if (_i2c_state.num_instances == 0) {
       switch (soc_name )
      {
      	case SOC_NAME_CE3100:
      	case SOC_NAME_CE4100:
      	case SOC_NAME_CE4200:
          OS_UNMAP_IO_FROM_MEM((void *) _i2c_state.virt_addr_offset, _I2C_ADDR_RANGE);
          _i2c_state.virt_addr_offset = 0x00000000;
         break;
         
        case SOC_NAME_CE5300:
          for ( bus_num=0;bus_num < _i2c_bus_count;bus_num++) {
            OS_UNMAP_IO_FROM_MEM((void *) _i2c_state.virt_addr_offset_bus[bus_num], 
            _I2C_ONE_BUS_ADDR_RANGE);
           _i2c_state.virt_addr_offset_bus[bus_num] = 0x00000000;
         }  
        break;

      }
       
      OS_UNMAP_IO_FROM_MEM((void *)irq_base, GEN3_IRQ_SIZE);
      _i2c_state.is_opened = false;
      irq_base = 0x0;

      /* Unregister interrupt handlers */
      for (bus_num = 0; bus_num < _i2c_bus_count; bus_num++) {
		 if (_i2c_state.interrupt_handle[bus_num] != NULL) {
#if 1 /* EPC */
	 		 os_release_interrupt(_i2c_state.interrupt_handle[bus_num]);
#endif
	 		 _i2c_state.interrupt_handle[bus_num] = NULL;
		}
   	    _i2c_write_register(bus_num, _I2C_REG_ICR, _I2C_ICR_DEFAULT_MODE);
      }
      return _I2C_SUCCESS;
   } else {
      return _I2C_DEVICE_BUSY;
   }
}

/*------------------------------------------------------------------------------
 * _i2c_set_mode
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_set_mode(uint8_t bus_num, _i2c_mode_t mode)
{
   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }

   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   _i2c_state.mode[bus_num] = mode;
   return _I2C_SUCCESS;
}

/*------------------------------------------------------------------------------
 * _i2c_reset
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_reset(uint8_t bus_num)
{
   uint32_t i, reg_value, poll_count = _I2C_POLL_COUNT;

   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }

   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   /* Set and clear reset bit */
   if (_i2c_write_register(bus_num, _I2C_REG_ICR, _I2C_ICR_DEFAULT_MODE |
      _I2C_ICR_UNIT_RESET) != _I2C_SUCCESS) {
      goto exception;
   }
   if (_i2c_write_register(bus_num, _I2C_REG_ICR, _I2C_ICR_DEFAULT_MODE | _I2C_ICR_UNIT_ENABLE | _I2C_ICR_SCL_ENABLE) !=
      _I2C_SUCCESS) {
      goto exception;
   }

   /* Check if i2c bus is idle after reset */
#if _I2C_XDB
       switch (soc_name )
      {
      	case SOC_NAME_CE3100:
      	case SOC_NAME_CE4100:
      	case SOC_NAME_CE4200:
         _I2C_XDB_PRINT("set value @reg_val = *(int *)0x%08X\n",
            _I2C_BASE_ADDR + _i2c_addr_offset[bus_num] + (uint32_t) _I2C_REG_ISR);
         _I2C_XDB_PRINT("while (@reg_val & 0x%08X) != 0x%08X then\n",
            _I2C_ISR_UNIT_BUSY, _I2C_ISR_UNIT_BUSY);
         _I2C_XDB_PRINT("set value @reg_val = *(int *)0x%08X\n",
            _I2C_BASE_ADDR + _i2c_addr_offset[bus_num] + (uint32_t) _I2C_REG_ISR);
         _I2C_XDB_PRINT("end\n");
         break;
         
        case SOC_NAME_CE5300:
         _I2C_XDB_PRINT("set value @reg_val = *(int *)0x%08X\n",
            _i2c_addr[bus_num] + (uint32_t) _I2C_REG_ISR);
         _I2C_XDB_PRINT("while (@reg_val & 0x%08X) != 0x%08X then\n",
            _I2C_ISR_UNIT_BUSY, _I2C_ISR_UNIT_BUSY);
         _I2C_XDB_PRINT("set value @reg_val = *(int *)0x%08X\n",
           _i2c_addr[bus_num] + (uint32_t) _I2C_REG_ISR);
         _I2C_XDB_PRINT("end\n"); 
        break;

      }

#endif
   for (i = 0; i < poll_count; i++) {
      if (_i2c_read_register(bus_num, _I2C_REG_ISR, &reg_value) != 
         _I2C_SUCCESS) {
         goto exception;
      }
      if (! (reg_value & _I2C_ISR_BUS_BUSY)) {
         break;
      }
   }
   if (reg_value & _I2C_ISR_BUS_BUSY) {
      return _I2C_FAILURE;
   }

   return _I2C_SUCCESS;

exception:
   return _I2C_FAILURE;
}

/*------------------------------------------------------------------------------
 * _i2c_read_byte_without_dummy
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_read_byte_without_dummy(uint8_t bus_num, uint32_t control_flags, uint8_t *p_data_byte, uint32_t interrupt_flags,
 uint32_t wait_condition)
{
   uint32_t reg_value, other_flags;

   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }

   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   if ((control_flags & ~(_I2C_SEND_NACK | _I2C_SEND_STOP)) != 0x00000000) {
      return _I2C_INVALID_PARAM;
   }

   /* Enable unit for transfer and set appropriate operating mode */
   control_flags |= (_I2C_ICR_UNIT_ENABLE | _I2C_ICR_SCL_ENABLE |
      _I2C_ICR_TRANSFER_BYTE);
   if (_i2c_state.mode[bus_num] == _I2C_MODE_FAST) {
      control_flags |= _I2C_ICR_FAST_MODE;
   }
   
   /* Keep original settings of flags */
   if (_i2c_read_register(bus_num, _I2C_REG_ICR, &other_flags) != 
      _I2C_SUCCESS) {
      goto exception;
   }
   other_flags &= ~(_I2C_SEND_START | _I2C_SEND_NACK | _I2C_SEND_STOP |
      _I2C_ICR_UNIT_ENABLE | _I2C_ICR_SCL_ENABLE |
      _I2C_ICR_TRANSFER_BYTE | _I2C_ICR_FAST_MODE);

   if (_i2c_write_register(bus_num, _I2C_REG_ICR, control_flags | 
      other_flags) != _I2C_SUCCESS) {
      goto exception;
   }

   /* Wait for interrupt*/
   if (idl_i2c_wait_for_interrupts(bus_num, interrupt_flags,
   wait_condition) != IDL_SUCCESS) {
      goto exception;
   }

   /* Read in one byte */
   if (_i2c_read_register(bus_num, _I2C_REG_IDBR, &reg_value) != _I2C_SUCCESS) {
      goto exception;
   }

   *p_data_byte = (uint8_t) (reg_value & 0x000000ff);
   
   return _I2C_SUCCESS;

exception:
   return _I2C_FAILURE;
}

/*------------------------------------------------------------------------------
 * _i2c_read_byte
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_read_byte(uint8_t bus_num, uint32_t control_flags, uint8_t *p_data_byte)
{
   uint32_t reg_value, other_flags;

   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }

   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   if ((control_flags & ~(_I2C_SEND_NACK | _I2C_SEND_STOP)) != 0x00000000) {
      return _I2C_INVALID_PARAM;
   }

   /* Enable unit for transfer and set appropriate operating mode */
   control_flags |= (_I2C_ICR_UNIT_ENABLE | _I2C_ICR_SCL_ENABLE |
      _I2C_ICR_TRANSFER_BYTE);
   if (_i2c_state.mode[bus_num] == _I2C_MODE_FAST) {
      control_flags |= _I2C_ICR_FAST_MODE;
   }

   /* Read in one byte */
   if (_i2c_read_register(bus_num, _I2C_REG_IDBR, &reg_value) != _I2C_SUCCESS) {
      goto exception;
   }
   *p_data_byte = (uint8_t) (reg_value & 0x000000ff);
   
   /* Keep original settings of flags */
   if (_i2c_read_register(bus_num, _I2C_REG_ICR, &other_flags) != 
      _I2C_SUCCESS) {
      goto exception;
   }
   other_flags &= ~(_I2C_SEND_START | _I2C_SEND_NACK | _I2C_SEND_STOP |
      _I2C_ICR_UNIT_ENABLE | _I2C_ICR_SCL_ENABLE |
      _I2C_ICR_TRANSFER_BYTE | _I2C_ICR_FAST_MODE);

   if (_i2c_write_register(bus_num, _I2C_REG_ICR, control_flags | 
      other_flags) != _I2C_SUCCESS) {
      goto exception;
   }

   return _I2C_SUCCESS;

exception:
   return _I2C_FAILURE;
}

/*------------------------------------------------------------------------------
 * _i2c_write_byte
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_write_byte(uint8_t bus_num, uint32_t control_flags, uint8_t data_byte)
{
   uint32_t other_flags;

   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }

   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   if ((control_flags & ~(_I2C_SEND_START | _I2C_SEND_NACK | _I2C_SEND_STOP)) 
      != 0x00000000) {
      return _I2C_INVALID_PARAM;
   }

   /* Enable unit for transfer and set appropriate operating mode */
   control_flags |= (_I2C_ICR_UNIT_ENABLE | _I2C_ICR_SCL_ENABLE |
      _I2C_ICR_TRANSFER_BYTE);
   if (_i2c_state.mode[bus_num] == _I2C_MODE_FAST) {
      control_flags |= _I2C_ICR_FAST_MODE;
   }

   /* Write out one byte */
   if (_i2c_write_register(bus_num, _I2C_REG_IDBR, data_byte) != _I2C_SUCCESS) {
      goto exception;
   }

   /* Keep original settings of flags */
   if (_i2c_read_register(bus_num, _I2C_REG_ICR, &other_flags) != 
      _I2C_SUCCESS) {
      goto exception;
   }
   other_flags &= ~(_I2C_SEND_START | _I2C_SEND_NACK | _I2C_SEND_STOP |
      _I2C_ICR_UNIT_ENABLE | _I2C_ICR_SCL_ENABLE |
      _I2C_ICR_TRANSFER_BYTE | _I2C_ICR_FAST_MODE);

   if (_i2c_write_register(bus_num, _I2C_REG_ICR, control_flags |
      other_flags) != _I2C_SUCCESS) {
      goto exception;
   }

   return _I2C_SUCCESS;

exception:
   return _I2C_FAILURE;
}

/*------------------------------------------------------------------------------
 * _i2c_read_register
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_read_register(uint8_t bus_num, _i2c_register_t reg, uint32_t *p_reg_value)
{
   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }

   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }
   
  switch (soc_name )
  {
  	case SOC_NAME_CE3100:
  	case SOC_NAME_CE4100:
  	case SOC_NAME_CE4200:
     *p_reg_value = *((volatile uint32_t *) (_i2c_state.virt_addr_offset + 
          _i2c_addr_offset[bus_num] + (uint32_t) reg));
     
#if _I2C_XDB
         _I2C_XDB_PRINT("set value @reg_val = *(int *)0x%08X\n",
         _I2C_BASE_ADDR + _i2c_addr_offset[bus_num] + (uint32_t) reg);
#endif

#if _I2C_DEBUG
          _I2C_DEBUG_PRINT("*(0x%08x) -> 0x%08x\n", (_i2c_state.virt_addr_offset + 
          _i2c_addr_offset[bus_num] + (uint32_t) reg), *p_reg_value);
#endif
     break;
     
    case SOC_NAME_CE5300:
       *p_reg_value = *((volatile uint32_t *) (_i2c_state.virt_addr_offset_bus[bus_num]+ 
            (uint32_t) reg));
       
#if _I2C_XDB
       _I2C_XDB_PRINT("set value @reg_val = *(int *)0x%08X\n",
         _i2c_addr[bus_num] + (uint32_t) reg); 
#endif

#if _I2C_DEBUG
       _I2C_DEBUG_PRINT("*(0x%08x) -> 0x%08x\n", (_i2c_state.virt_addr_offset_bus[bus_num] + 
          (uint32_t) reg), *p_reg_value);
#endif

    break;

  }
   return _I2C_SUCCESS;
}

/*------------------------------------------------------------------------------
 * _i2c_write_register
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_write_register(uint8_t bus_num, _i2c_register_t reg, uint32_t reg_value)
{
   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }

   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

  switch (soc_name )
  {
  	case SOC_NAME_CE3100:
  	case SOC_NAME_CE4100:
  	case SOC_NAME_CE4200:
   *((volatile uint32_t *) (_i2c_state.virt_addr_offset + 
      _i2c_addr_offset[bus_num] + (uint32_t) reg)) = reg_value;

#if _I2C_XDB
   _I2C_XDB_PRINT("set value /size=long 0x%08X = 0x%08X\n", 
      (_I2C_BASE_ADDR + _i2c_addr_offset[bus_num] + (uint32_t) reg), 
      reg_value);
#endif
#if _I2C_DEBUG
   _I2C_DEBUG_PRINT("*(0x%08x) <- 0x%08x\n", (_i2c_state.virt_addr_offset + 
      _i2c_addr_offset[bus_num] + (uint32_t) reg), reg_value);
#endif
     break;

     case SOC_NAME_CE5300:
      *((volatile uint32_t *) (_i2c_state.virt_addr_offset_bus[bus_num] + 
       (uint32_t) reg)) = reg_value;

#if _I2C_XDB
   _I2C_XDB_PRINT("set value /size=long 0x%08X = 0x%08X\n", 
      (_i2c_addr[bus_num] + (uint32_t) reg), 
      reg_value);
#endif
#if _I2C_DEBUG
   _I2C_DEBUG_PRINT("*(0x%08x) <- 0x%08x\n", (_i2c_state.virt_addr_offset_bus[bus_num] + 
       (uint32_t) reg), reg_value);
#endif
     break;
    }
   return _I2C_SUCCESS;
}

/*------------------------------------------------------------------------------
 * _i2c_read_address
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_read_address(uint32_t address, uint32_t *p_address_value)
{
   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   *p_address_value = *((volatile uint32_t *) (address));

   return _I2C_SUCCESS;
}

/*------------------------------------------------------------------------------
 * _i2c_write_address
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_write_address(uint32_t address, uint32_t address_value)
{
   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   *((volatile uint32_t *) (address)) = address_value;

   return _I2C_SUCCESS;
}

/*------------------------------------------------------------------------------
 * _i2c_set_interrupt_mask
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_set_interrupt_mask(uint8_t bus_num, uint32_t interrupt_mask)
{
   uint32_t reg_value = 0x00000000;
   
   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }
   
   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   if ((interrupt_mask & ~(_I2C_BUS_ERROR | _I2C_RECEIVE_FULL | 
      _I2C_TRANSMIT_EMPTY | _I2C_ARBITRATION_LOSS)) != 0x00000000) {
      return _I2C_INVALID_PARAM;
   }
   if (_i2c_read_register(bus_num, _I2C_REG_ICR, &reg_value) != _I2C_SUCCESS) {
      goto exception;
   }
   reg_value &= (~(_I2C_ICR_BUS_ERROR | _I2C_ICR_RECEIVE_FULL | _I2C_ICR_TRANSMIT_EMPTY | _I2C_ICR_ARBITRATION_LOSS));
  
   /* Construct and write out bit pattern for interrupt controller register */
   if (interrupt_mask & _I2C_BUS_ERROR) {
      reg_value |= _I2C_ICR_BUS_ERROR;
   }
   if (interrupt_mask & _I2C_RECEIVE_FULL) {
      reg_value |= _I2C_ICR_RECEIVE_FULL;
   }
   if (interrupt_mask & _I2C_TRANSMIT_EMPTY) {
      reg_value |= _I2C_ICR_TRANSMIT_EMPTY;
   }
   if (interrupt_mask & _I2C_ARBITRATION_LOSS) {
      reg_value |= _I2C_ICR_ARBITRATION_LOSS;
   }
   if (_i2c_write_register(bus_num, _I2C_REG_ICR, reg_value) != _I2C_SUCCESS) {
      goto exception;
   }


   return _I2C_SUCCESS;

exception:
   return _I2C_FAILURE;
}

/*------------------------------------------------------------------------------
 * _i2c_get_interrupt_mask
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_get_interrupt_mask(uint8_t bus_num, uint32_t *p_interrupt_mask)
{
   uint32_t reg_value;
   
   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }
   
   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   if (_i2c_read_register(bus_num, _I2C_REG_ICR, &reg_value) != _I2C_SUCCESS) {
      return _I2C_FAILURE;
   }

   /* Convert to expected (albeit likely the same) interrupt mask */
   *p_interrupt_mask = _I2C_NO_INTERRUPT;
   if (reg_value & _I2C_ICR_BUS_ERROR) {
      *p_interrupt_mask |= _I2C_BUS_ERROR;
   }
   if (reg_value & _I2C_ICR_RECEIVE_FULL) {
      *p_interrupt_mask |= _I2C_RECEIVE_FULL;
   }
   if (reg_value & _I2C_ICR_TRANSMIT_EMPTY) {
      *p_interrupt_mask |= _I2C_TRANSMIT_EMPTY;
   }
   if (reg_value & _I2C_ICR_ARBITRATION_LOSS) {
      *p_interrupt_mask |= _I2C_ARBITRATION_LOSS;
   }

   return _I2C_SUCCESS;
}


/*------------------------------------------------------------------------------
 * _i2c_read_interrupts_status
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_read_interrupts_status(uint8_t bus_num, uint32_t *interrupt_value){

   if (_i2c_read_register(bus_num, _I2C_REG_ISR, interrupt_value) !=
      _I2C_SUCCESS) {
      return _I2C_FAILURE;
   }
   return _I2C_SUCCESS;

}

/*------------------------------------------------------------------------------
 * _i2c_clear_interrupts
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_clear_interrupts(uint8_t bus_num, uint32_t interrupt_flags){
   uint32_t interrupt_value;
   if ((interrupt_flags & ~(_I2C_ISR_BUS_ERROR | _I2C_ISR_ARBITRATION_LOSS | _I2C_ISR_RECEIVE_FULL | _I2C_ISR_TRANSMIT_EMPTY)) != 0x0000){
      return _I2C_INVALID_PARAM;
   }
   if (_i2c_read_register(bus_num, _I2C_REG_ISR, &interrupt_value) != _I2C_SUCCESS) {
      return _I2C_FAILURE;
   }
   interrupt_value &= (~(_I2C_ISR_BUS_ERROR | _I2C_ISR_ARBITRATION_LOSS | _I2C_ISR_RECEIVE_FULL | _I2C_ISR_TRANSMIT_EMPTY));
   if (_i2c_write_register(bus_num, _I2C_REG_ISR, interrupt_value | interrupt_flags) != _I2C_SUCCESS) {
      return _I2C_FAILURE;
   }
   return _I2C_SUCCESS;
}


/*------------------------------------------------------------------------------
 * _i2c_get_pending_interrupts
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_get_pending_interrupts(uint8_t bus_num, uint32_t *p_interrupt_flags)
{
   uint32_t i, original_flags, interrupt_flags, poll_count = _I2C_POLL_COUNT;

   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }
   
   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   /* Read and clear interrupts */
   if (_i2c_read_register(bus_num, _I2C_REG_ISR, &original_flags) != 
      _I2C_SUCCESS) {
      goto exception;
   }
#if _I2C_XDB
   _I2C_XDB_PRINT("set value @original_flags = @reg_val\n");
#endif
   if (_i2c_write_register(bus_num, _I2C_REG_ISR, original_flags) !=
      _I2C_SUCCESS) {
      goto exception;
   }
   
   /* Wait until interrupts actually get cleared */
#if _I2C_XDB
   _I2C_XDB_PRINT("set value @interrupt_flags = *(int *)0x%08X\n",
      _I2C_BASE_ADDR + _i2c_addr_offset[bus_num] + (uint32_t) _I2C_REG_ISR);
   _I2C_XDB_PRINT(
      "while (@interrupt_flags & 0x%08X & @original_flags) != 0 then\n",
      _I2C_ARBITRATION_LOSS | _I2C_TRANSMIT_EMPTY | _I2C_RECEIVE_FULL | 
      _I2C_BUS_ERROR, _I2C_ARBITRATION_LOSS | _I2C_TRANSMIT_EMPTY |
         _I2C_RECEIVE_FULL | _I2C_BUS_ERROR);
   _I2C_XDB_PRINT("set value @interrupt_flags = *(int *)0x%08X\n",
      _I2C_BASE_ADDR + _i2c_addr_offset[bus_num] + (uint32_t) _I2C_REG_ISR);
   _I2C_XDB_PRINT("end\n");
#endif
   for (i = 0; i < poll_count; i++) {
      if (_i2c_read_register(bus_num, _I2C_REG_ISR, &interrupt_flags) != 
         _I2C_SUCCESS) {
         goto exception;
      }
      if (! ((interrupt_flags & (_I2C_ARBITRATION_LOSS | _I2C_TRANSMIT_EMPTY |
         _I2C_RECEIVE_FULL | _I2C_BUS_ERROR)) & original_flags)) {
         break;
      }
   }
   if ((interrupt_flags & (_I2C_ARBITRATION_LOSS | _I2C_TRANSMIT_EMPTY |
        _I2C_RECEIVE_FULL | _I2C_BUS_ERROR)) & original_flags) {
      goto exception;
   }


   /* Convert to expected (albeit likely the same) interrupt flags */
   *p_interrupt_flags = _I2C_NO_INTERRUPT;
   if (original_flags & _I2C_ISR_BUS_ERROR) {
      *p_interrupt_flags |= _I2C_BUS_ERROR;
   }
   if (original_flags & _I2C_ISR_RECEIVE_FULL) {
      *p_interrupt_flags |= _I2C_RECEIVE_FULL;
   }
   if (original_flags & _I2C_ISR_TRANSMIT_EMPTY) {
      *p_interrupt_flags |= _I2C_TRANSMIT_EMPTY;
   }
   if (original_flags & _I2C_ISR_ARBITRATION_LOSS) {
      *p_interrupt_flags |= _I2C_ARBITRATION_LOSS;
   }

   return _I2C_SUCCESS;

exception:
   return _I2C_FAILURE;
}

/*------------------------------------------------------------------------------
 * _i2c_register_interrupt_handler
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_register_interrupt_handler(uint8_t bus_num, 
   os_interrupt_handler_t *p_interrupt_handler, void *p_interrupt_data)
{
#if 1 /* EPC */
   uint32_t irq = 4; //eliminate warning: 'irq' may be used uninitialized in this function
   char irq_str[20];
   char* interrupt_handler_name[_I2C_MAX_BUS_COUNT]= {"IDL I2C0", "IDL I2C1", "IDL I2C2","IDL_I2C3"} ;
#endif

   struct pci_dev *i2c_dev = pci_get_device(0x8086, 0x2E68, NULL);
   if (i2c_dev) {
      pci_enable_device(i2c_dev);
      pci_intx(i2c_dev, 1);
      irq = i2c_dev->irq;
      printk(KERN_INFO "I2C IRQ Line is %d\n", irq);
      pci_dev_put(i2c_dev);
   }

   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }
   
   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   /* Release original interrupt handle */
   if (_i2c_state.interrupt_handle[bus_num] != NULL) {
#if 1 /* EPC */
      os_release_interrupt(_i2c_state.interrupt_handle[bus_num]);
#endif
      _i2c_state.interrupt_handle[bus_num] = NULL;
   }

#if 1 /* EPC */
   /* Currently, can only register one interrupt handler for i2c */
   sprintf(irq_str, "IDL I2C %d", bus_num);
   if ((_i2c_state.interrupt_handle[bus_num] = os_acquire_interrupt(irq, 
      _i2c_irq_id[bus_num], interrupt_handler_name[bus_num] , p_interrupt_handler, 
      p_interrupt_data)) != NULL) {
      return _I2C_SUCCESS;
   }
#else
   return _I2C_SUCCESS;
#endif

   return _I2C_FAILURE;
}

/*------------------------------------------------------------------------------
 * _i2c_release_interrupt_handler
 *------------------------------------------------------------------------------
 */

_i2c_result_t
_i2c_release_interrupt_handler(uint8_t bus_num)
{
   if (bus_num >= _i2c_bus_count) {
      return _I2C_INVALID_PARAM;
   }
   
   if (! _i2c_state.is_opened) {
      return _I2C_NOT_INITIALIZED;
   }

   /* Release original interrupt handle */
   if (_i2c_state.interrupt_handle[bus_num] != NULL) {
#if 1 /* EPC */
      os_release_interrupt(_i2c_state.interrupt_handle[bus_num]);
#endif
      _i2c_state.interrupt_handle[bus_num] = NULL;
   }

   return _I2C_SUCCESS;
}

#ifdef __cplusplus
}
#endif
