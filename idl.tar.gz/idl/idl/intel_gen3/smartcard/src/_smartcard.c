/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

/*----------------------------------------------------------------------
 * File Name:       _smartcard.c
 * $Revision: 0.1 $
 *----------------------------------------------------------------------
 *
 */

#include "osal_memmap.h"
#include "osal_io.h"
#include "osal_memory.h"
#include "_smartcard.h"
#include <pal_interrupt.h>

 /**
 * Forward references
 */
static uint32_t _scard_infc_get_base_addr(uint8_t scard_id);

static uint32_t gscard_infc_addr[] = {0x0, 0x0};
//static uint32_t gscard_phys_base_addr[] = {_BASE_REG_PA_USIM_0, _BASE_REG_PA_USIM_1};
static _scard_infc_reg_t *gpscard_infc_port[] = {NULL, NULL};

// the delay time (ms) during reset, default to 40 ms;
static uint32_t reset_delay= 40;
/*
 * This routine will return the physical base address of Smart card
 * interface 
 * @retval Base address if smartcard interface is supported other wise 0x0 is 
 * returned.
 */
static uint32_t _scard_infc_get_base_addr(uint8_t slot)
{
        uint32_t base_addr;
        uint32_t phyad;
 
        if (gscard_infc_addr[slot] != 0)
        {
                /* base_addr already mapped */
                base_addr = gscard_infc_addr[slot];
        }
        else
        {
#ifdef HARDCODE_BAR
                base_addr = (uint32_t) OS_MAP_IO_TO_MEM_NOCACHE(gscard_phys_base_addr[slot], 0xff);
#else
        //get the base address from pal
        pal_dev_id_t scard_dev_id;
	pal_info_t *pal_info = (pal_info_t *)OS_ALLOC(sizeof(pal_info_t));
        if (pal_info == NULL)
        {
             // OS_PRINT("OS_ALLOC FAILURE : could not alloc memory to pal_info \n");
              return false;
        }

        if(slot == 0)
	{
        scard_dev_id = SCARD_0;
	}
        else
	{ 
        scard_dev_id = SCARD_1;
        }
        if ( pal_get_base_and_irq(scard_dev_id, &pal_info) != PAL_SUCCESS ) {
               OS_FREE(pal_info);
               return false;
        }
        phyad = pal_info->base_addr0;
        base_addr = (uint32_t)OS_MAP_IO_TO_MEM_NOCACHE(phyad,0xff);
        OS_FREE(pal_info);
#endif
        }

        return (base_addr);
}

/*
 * This function initializes the smartcard interface. This is the first function that should
 * be called, it reset all the smartcard interface register to HW reset values.
 */
int _scard_infc_init(uint8_t slot)
{
        if (slot >= sizeof(gscard_infc_addr)/sizeof(gscard_infc_addr[0])) {
                _OS_DEBUG("SLOT value is incorrect=%d", slot);
                return (-1);
        }
        gscard_infc_addr[slot]  = _scard_infc_get_base_addr(slot);
        gpscard_infc_port[slot] = (_scard_infc_reg_t *)(gscard_infc_addr[slot]);

        gpscard_infc_port[slot]->egtr = 0x00000005;
        gpscard_infc_port[slot]->bgtr = 0x00000005;
#if 0
        gpscard_infc_port[slot]->clkr = 0x00000006;
        gpscard_infc_port[slot]->flr  = 0x00000005;
        gpscard_infc_port[slot]->dlr  = 0x00000004;
#endif
        _scard_infc_set_tx_trigger_level(slot, 0);
        _scard_infc_set_rx_trigger_level(slot, 0);

        return (0);
}

/*
 * This function frees any memory associated with the smartcard interface. This 
 * functions should be called last
 */
int _scard_infc_deinit(uint8_t slot)
{
      if (slot >= sizeof(gscard_infc_addr)/sizeof(gscard_infc_addr[0])) { 
                _OS_DEBUG("SLOT value is incorrect=%d", slot); 
                return (-1); 
        } 
        /* clear all pending interrupts */
        if (_scard_infc_clear_interrupt(slot, SC_EVENT_MASK) < 0) {
                return IDL_FAILURE;
        }

        if (gpscard_infc_port[slot] != NULL)
        {
                OS_UNMAP_IO_FROM_MEM(gpscard_infc_port[slot], sizeof(gpscard_infc_port[slot]));
                gpscard_infc_port[slot] = NULL;
                gscard_infc_addr[slot]  = 0x0;
        }

        return (0);
}

/*
 * This routine will perform cold/warm reset to the card connected to 
 * smartcard interface and activate it
 */
int _scard_infc_reset(uint8_t slot, sc_reset_t type, sc_vcc_t vcc)
{
        int ret = 0;
		uint32_t dummy;

        switch (type) {
                case SC_RESET_TYPE_COLD:

                        /* set CCR.RST_CARD_N to logic 0 */
                        gpscard_infc_port[slot]->ccr &= 0xfffffffe;

                        os_sleep(1);
                        /* 
                         * turn on the VCC voltage by writing to the CCR.VCC bits.on first 
                         * activation, set the lowest voltage level.(set the CCR.VCC bits 
                         * to "10").
                         */
                        ret = _scard_infc_set_card_vcc(slot, vcc);
						if ( ret < 0) 
								return ret; 
 
                        /* enable the i/o line to return to Vhigh by setting the CCR.TXD_FORCE bit to 0 */
                        gpscard_infc_port[slot]->ccr &= 0xffffffef;

                        /* activate the card clock by setting the stop bit, CLKR.STOP_UCLK to 0 */
                        gpscard_infc_port[slot]->clkr &= 0xffffdfff;

                        /*
                         * verify that CCR.RST_CARD_N was asserted for at least 400 UCLK cycles. note that
                         * when Fcard is set to th lowest frequency allowed by the standard, 400 cycles
                         * take 0.4ms
                         */
                        os_sleep(1);
                        /*
                         * deassert CCR.RST_CARD_N by setting it to 1. the card will Answer To Reset(ATR)
                         * within 400-40000 card clock cycles 
                         */
                        gpscard_infc_port[slot]->ccr |= 0x00000001;

                        os_sleep(reset_delay);

                        break;
                case SC_RESET_TYPE_WARM:
                        /* set CCR.RST_CARD_N to logic 0 */
                        gpscard_infc_port[slot]->ccr &= 0xfffffffe;
                        
                        /*
                         * verify that CCR.RST_CARD_N was asserted for at least 400 UCLK cycles. note that
                         * when Fcard is set to th lowest frequency allowed by the standard, 400 cycles
                         * take 0.4ms
                         */
                        os_sleep(1);

                        /*
                         * deassert CCR.RST_CARD_N by setting it to 1. the card will Answer To Reset(ATR)
                         * within 400-40000 card clock cycles 
                         */
                        gpscard_infc_port[slot]->ccr |= 0x00000001;

                        os_sleep(reset_delay);
                        /* Card Deactivation.Perform the following in sequence to deactivate the USIM card */
                        
                        break;
                default: 
                        ret = (-1);
                        break;
        }
		dummy = gpscard_infc_port[slot]->lsr;
        return (ret);
}

/*
 * This routine will deactivate the card
 * @param id - 0,1 ( smartcard id)
 * @retval IDL_SUCCESS if card is deactivated 
 * is returned
 */
int _scard_infc_card_deactivate(uint8_t slot)
{
        if ( slot >= sizeof(gpscard_infc_port)/sizeof(gpscard_infc_port[0]) ) {	
                _OS_DEBUG("SLOT value is incorrect=%d", slot);
                return (-1);
        }
        /* set CCR.RST_CARD_N to logic 0 */
        gpscard_infc_port[slot]->ccr &= 0xfffffffe;
                          
        /*
         * stop the clock on Vlow by setting CLKR.STOP_LEVEL bit to 0, and setting the
         * CLKR.STOP_UCLK bit to 1
         */
        gpscard_infc_port[slot]->clkr &= 0xffff7fff;
        gpscard_infc_port[slot]->clkr |= 0x00002000;
        
        /* force the i/o line to ground level by setting 1 to the CCR.TXT_FORCE bit */
        gpscard_infc_port[slot]->ccr |= 0x00000010;
        
        /*
         * turn on the VCC voltage to ground level by setting CCR.VCC bits to "00" at least 
         * after the i/o line is forced low. the i/o line can be checked in the Line Status
         * Register(LSR).
         */
        gpscard_infc_port[slot]->ccr &= 0xfffffff9;
        
        return (0);
}

/*
 * This routine will get the current number of bytes in receive buffer 
 */
int _scard_infc_get_rx_length(uint8_t slot)
{
         return (gpscard_infc_port[slot]->fsr & 0x01ff);
}

/*
 * This routine will get the current number of bytes in transmit buffer 
 */
int _scard_infc_get_tx_length(uint8_t slot)
{
        return ( (gpscard_infc_port[slot]->fsr & 0x01ff0000) >> 16);
}

/*
 * This routine will reset and flush the TX FIFO entries
 */
int _scard_infc_reset_tx_fifo(uint8_t slot)
{
	
    if (slot >= sizeof(gpscard_infc_port)/sizeof(gpscard_infc_port[0])) {
                _OS_DEBUG("SLOT value is incorrect=%d", slot);
                return (-1);
}	    
    gpscard_infc_port[slot]->fcr |= 0x20000000;
        return (0);
}

/*
 * This routine will reset and flush the RX FIFO entries
 */
int _scard_infc_reset_rx_fifo(uint8_t slot)
{
    if (slot >= sizeof(gpscard_infc_port)/sizeof(gpscard_infc_port[0])) {
                _OS_DEBUG("SLOT value is incorrect=%d", slot);
                return (-1);
}	    
        gpscard_infc_port[slot]->fcr |= 0x10000000;
 
        return (0);
}

/*
 * This routine will set the RX trigger level
 */
int _scard_infc_set_rx_trigger_level(uint8_t slot, uint16_t rx_tl)
{
        if (rx_tl > 260) {
                return (-1);
        }
        else if (slot >= sizeof(gpscard_infc_port)/sizeof(gpscard_infc_port[0])) {
                _OS_DEBUG("SLOT value is incorrect=%d", slot);
                return (-1);
        }
        else {
                gpscard_infc_port[slot]->fcr &= 0xffffff00;
                gpscard_infc_port[slot]->fcr |= rx_tl;
        }

        return (0);
}

/*
 * This routine will set the TX trigger level
 */
int _scard_infc_set_tx_trigger_level(uint8_t slot, uint16_t tx_tl)
{
        if (tx_tl > 260) {
                return (-1);
        }
        else {
                gpscard_infc_port[slot]->fcr &= 0xff00ffff;
                gpscard_infc_port[slot]->fcr |= (tx_tl << 16);
        }

        return (0);
}

/*
 * This routine will detect the card at smart card interface.
 */
int _scard_infc_get_slot_info(uint8_t slot, sc_slot_info_t *info)
{
        /* get protocol */
        if (gpscard_infc_port[slot]->lcr & 0x00000018) {
                info->protocol = SC_T1;
        }
        else {
                info->protocol = SC_T0;
        }

        /* get status */
        if (gpscard_infc_port[slot]->ccr & _SCARD_INFC_CCR_SCARD_INSERTED) {
                /* card is inserted, we now have to check if it is powered up */
                if ( ((gpscard_infc_port[slot]->ccr & 0x00000007) >> 1) > 0) {
                        info->status = SC_CARD_POWERED_UP;
                }
                else {
                        info->status = SC_CARD_INSERTED_NOT_POWERED_UP;
                }             
        }
        else {
                info->status = SC_CARD_NO_CARD_INSERTED;
        }

        return (0);
}

/*
 * This routine will set the protocols for the transmitter/receiver
 * transmitter and receiver are programmed with same protocol type
 */
int _scard_infc_set_protocol(uint8_t slot, uint8_t protocol)
{
        int ret = 0;

        switch (protocol) {
                case SC_T0:
                        gpscard_infc_port[slot]->lcr &= 0xffffffe7;
                        break;
                case SC_T1:
                        gpscard_infc_port[slot]->lcr |= 0x00000018;
                        break;
                default:
                        ret = (-1);
                        break;
        }

        return (ret);
}

/*
 * This routine will enable the interrupts for smart card interface
 */
int _scard_infc_enable_interrupt(uint8_t slot, uint32_t mask)
{
        int ier = 0;

        if ( mask & (~SC_EVENT_MASK) ) {	
                return (-1);
        }
       
		ier = gpscard_infc_port[slot]->ier;
		ier |= (mask & SC_EVENT_MASK); 
        gpscard_infc_port[slot]->ier = ier; 

        return (0);
}

/*
 * This routine will disable the interrupts for smart card interface
 */
int _scard_infc_disable_interrupt(uint8_t slot, uint32_t mask)
{
        int ier = 0;

        if ( mask & (~SC_EVENT_MASK) ) {	
                return (-1);
        }
        else if ( slot >= sizeof(gpscard_infc_port)/sizeof(gpscard_infc_port[0]) ) {	
                _OS_DEBUG("SLOT value is incorrect=%d", slot);
                return (-1);
        }
        
		ier = gpscard_infc_port[slot]->ier;
		ier &= (~(mask & SC_EVENT_MASK)); 
        gpscard_infc_port[slot]->ier = ier; 
        
        return (0);
}

/*
 * This routine will clear the interrupt for smart card interface by clearing
 * the status bits
 */
int _scard_infc_clear_interrupt(uint8_t slot, uint32_t mask)
{
        if ( (mask & (~SC_EVENT_MASK)) ) {
                return (-1);
        }

        gpscard_infc_port[slot]->iir |= mask;

        return (0);
}

int _scard_get_interrupt_status(uint8_t slot, uint32_t *status)
{
        *status = (gpscard_infc_port[slot]->iir & SC_EVENT_MASK);
        
        return (0);
}

/*
 * This routine will read a byte from smartcard interface RX FIFO and activate it
 */
int _scard_infc_read(uint8_t slot, uint8_t *s, uint32_t nbytes, uint32_t *actual_bytes_read) 
{
        uint32_t i = 0;
        uint32_t lsr = 0;
        uint32_t fsr = 0;
        uint32_t len = 0;
		int32_t  counter = 10;	
        uint32_t bytes_to_read = 0;
		int ret = 0;

        *actual_bytes_read = 0;

		do{

			lsr = gpscard_infc_port[slot]->lsr;
			fsr = gpscard_infc_port[slot]->fsr;
			if (lsr & (1<<3))
			{
				ret = -EFRAME; /*Frame error*/
				break;
			}  
			if (lsr & (1<<1))
			{
				ret = -EPARITY; /*parity error*/
				break;
			}  
			if (lsr & (1<<0))
			{
				ret = -EOVRN; /*over run error*/
				break;
			} 

			if (!( (lsr & 0x4000) || !(fsr & 0x1FF) || !(lsr & 0x0010) ))
			{
				break;
			}
			counter--;
			set_current_state(TASK_UNINTERRUPTIBLE);
			schedule_timeout(HZ/100);

		}while (counter);
		
		if (0 == counter) ret = -ETIME; /*timeout*/
		if (ret < 0) 
		{	
		  printk("error is coming ret is %d\n",ret);
	//	  _scard_dump_registers(slot);
		  return ret;
		}
        len = _scard_infc_get_rx_length(slot);

        bytes_to_read = (len > nbytes) ? nbytes : len;

        while (i < bytes_to_read) {
                s[i++] = gpscard_infc_port[slot]->rbr;

        }

        *actual_bytes_read = i;

        return (0);
}

/*
 * This routine will read a byte from smartcard interface RX FIFO
 * and activate it
 */
int _scard_infc_write(uint8_t slot, uint8_t *s, uint32_t nbytes, uint32_t *actual_bytes_written) 
{ 
        uint32_t i = 0;
        uint32_t val;
        uint32_t lsr = 0;
        uint32_t fsr = 0;
		int32_t	counter = 10;
		int ret = 0;
        

        while (i < nbytes) {
                /* 
                 * if it is the last byte to be writen, then mark bit TX_ENABLE in the bit 31
                 */
#if 1
                if (i == nbytes - 1) { /* last byte */
                        val = (_SCARD_INFC_THR_TX_ENABLE | s[i]);

                }
                else {
                        val = s[i];
                }
#else
                val = (_SCARD_INFC_THR_TX_ENABLE | s[i]);
#endif  
                /* Write a character byte to the FIFO. */
                gpscard_infc_port[slot]->thr = val;
                i++;
        }

        *actual_bytes_written = i;

		do{
			lsr = gpscard_infc_port[slot]->lsr;
			fsr = gpscard_infc_port[slot]->fsr;
			if (lsr & (1<<2))
			{
				gpscard_infc_port[slot]->fsr = (fsr | (1 << 6));
				udelay(10);
				ret = -ET0;
				break;
			
			}  
			if (!( (lsr & 0x2000) || (fsr & 0x1FF0000) ))
			{
				break;
			}  
		
			counter--;
			set_current_state(TASK_UNINTERRUPTIBLE);
			schedule_timeout(HZ/100);

		}while (counter);
		if (0 == counter) ret = -ETIME;

        return ret;
}

/*
 * This routine is called after the card is removed from the interface
 * This routine will complete smooth shut down at interface
 * @param id - 0,1 ( smartcard id)
 * @retval IDL_SUCCESS if card is deactivated 
 * is returned
 */
int _scard_infc_card_removal(uint8_t slot)
{
#if 1
        /* clear the FIFOs */
        _scard_infc_reset_tx_fifo(slot);
        _scard_infc_reset_rx_fifo(slot);

        /* shut down the power supply */
        if (_scard_infc_set_card_vcc(slot, SC_VCC_SEL_0) < 0) {
                return (-1);
        }
#else                
        /* stop the clocks */
        _scard_infc_stop_sclk(slot);

        /* set the clock rate to default value */
        _scard_infc_set_clk_divisor(slot, IDL_SCARD_INFC_CLK_DIV_DEF);
#endif
        return (0);
}

/*
 * This routine configure the clock frequency for smartcard interface
 * @param id - 0,1 ( smartcard id)
 * @param c_div - 0-0xFF 
 * @retval true if etu values are set correctly
 */
int _scard_infc_set_clk_divisor(uint8_t slot, uint32_t c_div)
{
	int i=0;
        if ( c_div > 0xff ) {
                _OS_DEBUG("Clock divisior value is incorrect=0x%X[0-0x00FF]",c_div);
                return (-1);
        }
        else if (slot >= sizeof(gpscard_infc_port)/sizeof(gpscard_infc_port[0])) {
                _OS_DEBUG("SLOT value is incorrect=%d", slot);
                return (-1);
        } 
	//Any write to the CLKR when CLKR.RQST = '1' will be ignored
	while((i++<10) && (gpscard_infc_port[slot]->clkr &0x100));

	if(10 <= i)
	{
		_OS_DEBUG("Request occurring, do not update CLKR\n");
		return (-1);
	} 
		gpscard_infc_port[slot]->clkr = (gpscard_infc_port[slot]->clkr & 0xffffff00) | (uint8_t) c_div;
       
        os_sleep(1);
 
        return (0);
}

int _scard_infc_stop_sclk(uint8_t slot)
{
        gpscard_infc_port[slot]->clkr |= 0x00002000;
        
        return (0);
}

int _scard_infc_start_sclk(uint8_t slot)
{
        gpscard_infc_port[slot]->clkr &= 0xffffdfff;
        
        return (0);
}

int _scard_infc_set_card_vcc(uint8_t slot, sc_vcc_t vcc)
{
        if ( slot >= sizeof(gpscard_infc_port)/sizeof(gpscard_infc_port[0]) ) {	
                _OS_DEBUG("SLOT value is incorrect=%d", slot);
                return (-1);
        }
        gpscard_infc_port[slot]->ccr &= 0xfffffff9;
        gpscard_infc_port[slot]->ccr |= (vcc << 1);

		if( ((gpscard_infc_port[slot]->ccr & (~0xfffffff9)) >> 1) != vcc) 
				return -1;
        
        return (0);
}

int _scard_infc_set_egtr(uint8_t slot, uint32_t egtm)
{
        if ( egtm > 0xff ) {
                _OS_DEBUG("EGTR value is incorrect=0x%X[0-0xFF]", egtm);
                return (-1);
        }    

        gpscard_infc_port[slot]->egtr = (uint8_t) egtm;

        return (0);
}

int _scard_infc_set_bgtr(uint8_t slot, uint32_t bgt)
{
        if ( bgt > 0xff ) {
                _OS_DEBUG("BGTR value is incorrect=0x%X[0-0xFF]", bgt);
                return (-1);
        }    

        gpscard_infc_port[slot]->bgtr = (uint8_t) bgt;

        return IDL_SUCCESS;
}

/*
 * This routine configure the GPIO for smartcard interface
 * @param id - 0,1 ( smartcard id)
 * @retval true if gpio are programmed corretly
 */
int _scard_infc_set_gpio(uint8_t scard_id)
{
        /* need to add code to configure GPIO if they are not configured by default */
        return (0);
}

/*
 * This routine configure the etu for smartcard interface
 * @param id - 0,1 ( smartcard id)
 * @param c_div - 0-0xFF 
 * @param D - 0-0xFFFF
 * @param F - 0-0xFF
 * @retval true if etu values are set correctly
 */
int _scard_infc_set_etu(uint8_t slot, uint32_t c_div, uint32_t divisor, uint32_t factor)
{
        int ret = -1;

        /* configure divisor latch reg */
        if (_scard_infc_set_dlr(slot, divisor) < 0) {
                return (ret);
        }

        /* configure factor latch reg */
        if (_scard_infc_set_flr(slot, factor) < 0) {
                return (ret);
        }

        if (_scard_infc_set_clk_divisor(slot, c_div) < 0) {
                return (ret);
        }

        return (0);    
}

/*
 * This routine configure the baud factor for smartcard interface
 * @param id - 0,1 ( smartcard id)
 * @param F - 0-0xFF
 * @retval IDL_SUCCESS if baud factor values are set correctly
 */
int _scard_infc_set_flr(uint8_t slot, uint32_t factor)
{
        if (factor > 0xff) {
                _OS_DEBUG("Baud factor value is incorrect=0x%X[0-0x00FF]", factor);
                return (-1);
        }
        else if (slot >= sizeof(gpscard_infc_port)/sizeof(gpscard_infc_port[0])) {
                _OS_DEBUG("SLOT value is incorrect=%d", slot);
 
                return (-1);
	}
        gpscard_infc_port[slot]->flr = (uint8_t) factor ;
       
        return (0);
}
/*
 * This routine configure the baud divisor for smartcard interface
 * @param id - 0,1 ( smartcard id)
 * @param F - 0-0xFFFF
 * @retval IDL_SUCCESS if baud divisor values are set correctly
 */
int _scard_infc_set_dlr(uint8_t slot, uint32_t divisor)
{
        if (divisor > 0xffff) {
                _OS_DEBUG("Baud divisor value is incorrect=0x%X[0-0xFFFF]", divisor);
                return (-1);
        }    
    if (slot >1) {
                _OS_DEBUG("slot value is incorrect=%d", slot);
                return (-1);
        }    


        gpscard_infc_port[slot]->dlr = (uint16_t) divisor;
 
        return (0);
}

/*
 * This routine configure the character waiting time for smartcard interface
 * @param id - 0,1 ( smartcard id)
 * @param D - 0-0xFFFF
 * @retval IDL_SUCCESS if character waiting time values are set correctly
 */
int _scard_infc_set_cwt(uint8_t slot, uint32_t cwt)
{
        if (cwt > 0xffff) {
                _OS_DEBUG("CWT value is incorrect=0x%X[0-0xFFFF]", cwt);
                return (-1);
        }    

        gpscard_infc_port[slot]->cwtr = (uint16_t) cwt;

        return (0);
}

/*
 * This routine configure the block waiting time for smartcard interface
 * @param id - 0,1 ( smartcard id)
 * @param data - 0-0xFFFF
 * @retval IDL_SUCCESS if block waiting time values are set correctly
 */
int _scard_infc_set_bwt(uint8_t slot, uint32_t bwt)
{
        if (bwt > 0xffff) {
                _OS_DEBUG("BWT value is incorrect=0x%X[0-0xFFFF]", bwt);
                return (-1);
        }    

        gpscard_infc_port[slot]->bwtr = (uint16_t) bwt;

        return (0);
}

/*
 * This routine configure the time out register for smartcard interface
 * @param id - 0,1 ( smartcard id)
 * @param data - 0-0xFFFF
 * @retval IDL_SUCCESS if block waiting time values are set correctly
 */
int _scard_infc_set_tor(uint8_t slot, uint32_t tor)
{
        if (tor > 0xffff) {
                _OS_DEBUG("BWT value is incorrect=0x%X[0-0xFFFF]", tor);
                return (-1);
        }    

        gpscard_infc_port[slot]->tor = (uint16_t) tor;

        return (0);
}

/*
 * This routine configure the io mode for smartcard interface
 * @param id - 0,1 ( smartcard id)
 * @param data - 0-0x1
 * @retval IDL_SUCCESS if block waiting time values are set correctly
 */
int _scard_infc_set_iomode(uint8_t slot, uint32_t iomode)
{
        if (iomode > 0x1) {
                _OS_DEBUG("BWT value is incorrect=0x%X[0-0x1]", iomode);
                return (-1);
        }    
		
		if (iomode == DIRECT_CONVENTION)
		{
			gpscard_infc_port[slot]->lcr &= ((uint16_t)(0xFFFC));
			gpscard_infc_port[slot]->lcr |= ((uint16_t)(1<<0x2));
		}
		else
		{
			gpscard_infc_port[slot]->lcr &= ((uint16_t)(~(1<<0x2)));
			gpscard_infc_port[slot]->lcr |= ((uint16_t)(0x0003));
		}

        return (0);
}

/*
 * This routine will clear the interrupt for smart card interface by clearing
 * the status bits
 */
int _scard_infc_adjust_reset_delay(uint8_t slot, uint32_t delay)
{
		if ( delay > 500) {
				return (-1);
		}

        reset_delay = delay; 

        return (0);
}

void _scard_dump_registers(uint8_t slot)
{
        OS_PRINT( "---------------BEGIN(SCARD_%d)-----------------\n", slot);
        OS_PRINT( "ier  = 0x%08x\n", gpscard_infc_port[slot]->ier);
        OS_PRINT( "iir  = 0x%08x\n", gpscard_infc_port[slot]->iir);
        OS_PRINT( "fcr  = 0x%08x\n", gpscard_infc_port[slot]->fcr);
        OS_PRINT( "fsr  = 0x%08x\n", gpscard_infc_port[slot]->fsr);
        OS_PRINT( "ecr  = 0x%08x\n", gpscard_infc_port[slot]->ecr);
        OS_PRINT( "lcr  = 0x%08x\n", gpscard_infc_port[slot]->lcr);
        OS_PRINT( "ccr  = 0x%08x\n", gpscard_infc_port[slot]->ccr);
        OS_PRINT( "lsr  = 0x%08x\n", gpscard_infc_port[slot]->lsr);
        OS_PRINT( "egtr = 0x%08x\n", gpscard_infc_port[slot]->egtr);
        OS_PRINT( "bgtr = 0x%08x\n", gpscard_infc_port[slot]->bgtr);
        OS_PRINT( "tor  = 0x%08x\n", gpscard_infc_port[slot]->tor);
        OS_PRINT( "clkr = 0x%08x\n", gpscard_infc_port[slot]->clkr);
        OS_PRINT( "dlr  = 0x%08x\n", gpscard_infc_port[slot]->dlr);
        OS_PRINT( "flr  = 0x%08x\n", gpscard_infc_port[slot]->flr);
        OS_PRINT( "cwtr = 0x%08x\n", gpscard_infc_port[slot]->cwtr);
        OS_PRINT( "bwtr = 0x%08x\n", gpscard_infc_port[slot]->bwtr);
        OS_PRINT( "-----------------END(SCARD_%d)-----------------\n", slot);
}

static _scard_infc_reg_t scard_reg[SC_MAX_SLOTS_SUPPORTED];
/*suspend one smartcard register into scard_reg[slot] structure*/
int _scard_infc_suspend(uint8_t slot)
{
   _pscard_infc_reg_t p;
   if (slot >= SC_MAX_SLOTS_SUPPORTED) return -EINVAL;
   p = (_pscard_infc_reg_t )_scard_infc_get_base_addr(slot);
   scard_reg[slot].rbr = p->rbr;
   scard_reg[slot].thr = p->thr;
   scard_reg[slot].ier = p->ier;
   scard_reg[slot].iir = p->iir;
   scard_reg[slot].fcr = p->fcr;
   scard_reg[slot].fsr = p->fsr;
   scard_reg[slot].ecr = p->ecr;
   scard_reg[slot].lcr = p->lcr;
   scard_reg[slot].ccr = p->ccr;
   scard_reg[slot].lsr = p->lsr;
   scard_reg[slot].egtr = p->egtr;
   scard_reg[slot].bgtr = p->bgtr;
   scard_reg[slot].tor = p->tor;
   scard_reg[slot].clkr = p->clkr;
   scard_reg[slot].dlr = p->dlr;
   scard_reg[slot].flr = p->flr;
   scard_reg[slot].cwtr = p->cwtr;
   scard_reg[slot].bwtr = p->bwtr;
   return 0;
 }
 
 /*resume one smartcard register from scard_reg[slot] structure*/
int _scard_infc_resume(uint8_t slot)
{
   _pscard_infc_reg_t p;
   if (slot >= SC_MAX_SLOTS_SUPPORTED) return -EINVAL;
   p = (_pscard_infc_reg_t )_scard_infc_get_base_addr(slot);
   p->ier = (scard_reg[slot].ier & 0x707F);
   p->fcr = (scard_reg[slot].fcr & ((1 << 31) | 0x1FF | (0x1FF << 16) ));
   p->ecr = (scard_reg[slot].ecr & (0x3 | (0x3 << 3) | (1 << 7)));
   p->lcr = (scard_reg[slot].lcr & 0x1f);
 //    p->ccr = scard_reg[slot].ccr;
   p->egtr = (scard_reg[slot].egtr & 0xFF);
   p->bgtr = (scard_reg[slot].bgtr & 0xFF);
   p->tor = (scard_reg[slot].tor & 0xFF);
   p->clkr = (scard_reg[slot].clkr & 0x60FF);
   p->dlr = (scard_reg[slot].dlr & 0xFFFF);
   p->flr = (scard_reg[slot].flr & 0xFF);
   p->cwtr = (scard_reg[slot].cwtr & 0xFFFF);
   p->bwtr = (scard_reg[slot].bwtr & 0xFFFF);
   _scard_infc_reset_tx_fifo(slot);
   _scard_infc_reset_rx_fifo(slot);
   return 0;
}

