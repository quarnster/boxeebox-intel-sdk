/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

#ifndef SPI_H
#define SPI_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef IDL_DRIVER
#include "stdint.h"
#include "stdbool.h"
#endif

#include "osal_type.h"
#include "pal.h"
#include "osal_interrupt.h"
#include "osal_memmap.h"
#include "idl.h"
#include "idl_spi.h"

/*define HARDCODE_BAR, will use the hardcode base address, otherwise, will get base address from
pal */
//#define HARDCODE_BAR

// This file contains all of the hardware-specific definitions internal to the SPI interface.
#ifndef NULL
#define NULL ((void *)0)
#endif

/* Number of SPI ports supported in this implementation. */
#define NUM_SPI_PORTS 1

/* SPI Base address */
#define SPI_PHYSICAL_BASE_ADDRESS 0xDFFE0A00

/* SPI Interrupt Request Number */
//#define SPI_IRQ_NUMBER   27//need to change

#define SPI_TX_FIFO_SIZE 4
#define SPI_RX_FIFO_SIZE 4

/* SPI Regiter offsets */
#define SPI_SSCR0_OFFSET 0x00
#define SPI_SSCR1_OFFSET 0x04
#define SPI_SSSR_OFFSET  0x08
#define SPI_SSDR_OFFSET  0x10

/* Size of the SPI device register space. */
#define SPI_REGISTER_SPACE_SIZE 0x100

/* SPI Control Register 0 (SSCR0) bit fields */

// Data size select.
#define SPI_CONTROL_DSS_SHIFT        0
#define SPI_CONTROL_DSS_MASK         (0xF << SPI_CONTROL_DSS_SHIFT)
#define SPI_DATA_SIZE_MIN            4
#define SPI_DATA_SIZE_MAX            16

// Frame format.
#define SPI_CONTROL_FRF_SHIFT        4
#define SPI_CONTROL_FRF_MASK         (0x3 << SPI_CONTROL_FRF_SHIFT)
#define SPI_CONTROL_FRF_MOT_SPI      (0 << SPI_CONTROL_FRF_SHIFT )
#define SPI_CONTROL_FRF_TI_SSP       (1 << SPI_CONTROL_FRF_SHIFT )
#define SPI_CONTROL_FRF_NS_MICROWIRE (2 << SPI_CONTROL_FRF_SHIFT )

// Serial port enable.
#define SPI_CONTROL_SSE_SHIFT        7
#define SPI_CONTROL_SSE_MASK         (0x1 << SPI_CONTROL_SSE_SHIFT)
#define SPI_CONTROL_SSE_ENABLE       (1 << SPI_CONTROL_SSE_SHIFT)
#define SPI_CONTROL_SSE_DISABLE      (0 << SPI_CONTROL_SSE_SHIFT)

// Serial clock rate.
#define SPI_CONTROL_SCR_SHIFT        8
#define SPI_CONTROL_SCR_MASK         (0xFF << SPI_CONTROL_SCR_SHIFT)
#define SPI_MAX_BIT_RATE             1843200
#define SPI_MIN_BIT_RATE             7200
#define SPI_SCR_MAX                  0
#define SPI_SCR_MIN                  255


/* SPI Control Register 1 (SSCR1) bit fields */

// Receive FIFO interupt enable.
#define SPI_CONTROL_RIE_SHIFT        0
#define SPI_CONTROL_RIE_MASK         (0x1 << SPI_CONTROL_RIE_SHIFT)
#define SPI_CONTROL_RIE_ENABLE       (1 << SPI_CONTROL_RIE_SHIFT)
#define SPI_CONTROL_RIE_DISABLE      (0 << SPI_CONTROL_RIE_SHIFT)

// Transmit FIFO interupt enable.
#define SPI_CONTROL_TIE_SHIFT        1
#define SPI_CONTROL_TIE_MASK         (0x1 << SPI_CONTROL_TIE_SHIFT)
#define SPI_CONTROL_TIE_ENABLE       (1 << SPI_CONTROL_TIE_SHIFT)
#define SPI_CONTROL_TIE_DISABLE      (0 << SPI_CONTROL_TIE_SHIFT)

// Loop-back mode.
#define SPI_CONTROL_LBM_SHIFT        2
#define SPI_CONTROL_LBM_MASK         (0x1 << SPI_CONTROL_LBM_SHIFT)
#define SPI_CONTROL_LBM_ENABLE       (1 << SPI_CONTROL_LBM_SHIFT)
#define SPI_CONTROL_LBM_DISABLE      (0 << SPI_CONTROL_LBM_SHIFT)

// Polarity.
#define SPI_CONTROL_SPO_SHIFT        3
#define SPI_CONTROL_SPO_MASK         (0x1 << SPI_CONTROL_SPO_SHIFT)
#define SPI_CONTROL_SPO_HIGH         (1 << SPI_CONTROL_SPO_SHIFT)
#define SPI_CONTROL_SPO_LOW          (0 << SPI_CONTROL_SPO_SHIFT)

// Phase.
#define SPI_CONTROL_SPH_SHIFT        4
#define SPI_CONTROL_SPH_MASK         (0x1 << SPI_CONTROL_SPH_SHIFT)
#define SPI_CONTROL_SPH_ONE          (0 << SPI_CONTROL_SPH_SHIFT)
#define SPI_CONTROL_SPH_HALF         (1 << SPI_CONTROL_SPH_SHIFT)

// Transmit FIFO threshold
#define SPI_CONTROL_TFT_SHIFT        6
#define SPI_CONTROL_TFT_MASK         (0x3 << SPI_CONTROL_TFT_SHIFT)
#define SPI_TX_THRESHOLD_MIN         1
#define SPI_TX_THRESHOLD_MAX         (SPI_TX_FIFO_SIZE)

// Receive FIFO threshold.
#define SPI_CONTROL_RFT_SHIFT        10
#define SPI_CONTROL_RFT_MASK         (0x3 << SPI_CONTROL_RFT_SHIFT)
#define SPI_RX_THRESHOLD_MIN         1
#define SPI_RX_THRESHOLD_MAX         (SPI_RX_FIFO_SIZE)

// FIFO Write/Read special function.
#define SPI_CONTROL_EFWR_SHIFT        14
#define SPI_CONTROL_EFWR_MASK         (0x1 << SPI_CONTROL_EFWR_SHIFT)
#define SPI_CONTROL_EFWR_ENABLE       (1 << SPI_CONTROL_EFWR_SHIFT)
#define SPI_CONTROL_EFWR_DISABLE      (0 << SPI_CONTROL_EFWR_SHIFT)

// FIFO select for Write/Read special function.
#define SPI_CONTROL_STRF_SHIFT        15
#define SPI_CONTROL_STRF_MASK         (0x1 << SPI_CONTROL_STRF_SHIFT)
#define SPI_CONTROL_STRF_RECEIVE      (1 << SPI_CONTROL_STRF_SHIFT)
#define SPI_CONTROL_STRF_TRANSMIT     (0 << SPI_CONTROL_STRF_SHIFT)


/* SPI Status Register (SSSR) bit fields */

// Alternate frame output.
#define SPI_STATUS_ALT_FRM_SHIFT     0
#define SPI_STATUS_ALT_FRM_MASK      (0x3 << SPI_STATUS_ALT_FRM_SHIFT)
#define SPI_STATUS_ALT_FRM_MIN       0
#define SPI_STATUS_ALT_FRM_MAX       3

// Transmit FIFO not full.
#define SPI_STATUS_TNF_SHIFT         2
#define SPI_STATUS_TNF_MASK          (0x1 << SPI_STATUS_TNF_SHIFT)
#define SPI_STATUS_TNF_TRUE          (1 << SPI_STATUS_TNF_SHIFT)
#define SPI_STATUS_TNF_FALSE         (0 << SPI_STATUS_TNF_SHIFT)

// Receive FIFO not empty.
#define SPI_STATUS_RNE_SHIFT         3
#define SPI_STATUS_RNE_MASK          (0x1 << SPI_STATUS_RNE_SHIFT)
#define SPI_STATUS_RNE_TRUE          (1 << SPI_STATUS_RNE_SHIFT)
#define SPI_STATUS_RNE_FALSE         (0 << SPI_STATUS_RNE_SHIFT)

// Serial port busy.
#define SPI_STATUS_BSY_SHIFT         4
#define SPI_STATUS_BSY_MASK          (0x1 << SPI_STATUS_BSY_SHIFT)
#define SPI_STATUS_BSY_TRUE          (1 << SPI_STATUS_BSY_SHIFT )
#define SPI_STATUS_BSY_FALSE         (0 << SPI_STATUS_BSY_SHIFT )

// Transmit FIFO service request.
#define SPI_STATUS_TFS_SHIFT         5
#define SPI_STATUS_TFS_MASK          (0x1 << SPI_STATUS_TFS_SHIFT)
#define SPI_STATUS_TFS_TRUE          (1 << SPI_STATUS_TFS_SHIFT)
#define SPI_STATUS_TFS_FALSE         (0 << SPI_STATUS_TFS_SHIFT)

// Receive FIFO service request.
#define SPI_STATUS_RFS_SHIFT         6
#define SPI_STATUS_RFS_MASK          (0x1 << SPI_STATUS_RFS_SHIFT)
#define SPI_STATUS_RFS_TRUE          (1 << SPI_STATUS_RFS_SHIFT)
#define SPI_STATUS_RFS_FALSE         (0 << SPI_STATUS_RFS_SHIFT)

// Receive FIFO overrun.
#define SPI_STATUS_ROR_SHIFT         7
#define SPI_STATUS_ROR_MASK          (0x1 << SPI_STATUS_ROR_SHIFT)
#define SPI_STATUS_ROR_TRUE          (1 << SPI_STATUS_ROR_SHIFT)
#define SPI_STATUS_ROR_FALSE         (0 << SPI_STATUS_ROR_SHIFT)

// Transmit FIFO level.
#define SPI_STATUS_TFL_SHIFT         8
#define SPI_STATUS_TFL_MASK          (0xF << SPI_STATUS_TFL_SHIFT)
#define SPI_STATUS_TFL_MIN           0
#define SPI_STATUS_TFL_MAX           15

// Receive FIFO level.
#define SPI_STATUS_RFL_SHIFT         12
#define SPI_STATUS_RFL_MASK          (0xF << SPI_STATUS_RFL_SHIFT)
#define SPI_STATUS_RFL_MIN           0
#define SPI_STATUS_RFL_MAX           15


#define spi_get_tx_fifo_size(port_num) ((uint32_t)SPI_TX_FIFO_SIZE)
#define spi_get_rx_fifo_size(port_num) ((uint32_t)SPI_RX_FIFO_SIZE)


#define READ_REG32(address)              (*((volatile uint32_t *)(address)))
#define WRITE_REG32(address,data)        (*((volatile uint32_t *)(address)) = (data))
#define MODIFY_REG32(address,data,mask)  (*((volatile uint32_t *)(address)) = (*((volatile uint32_t *)(address)) & ~(mask)) | ((data) & (mask)) )


bool spi_is_valid_port_num( uint32_t port_num );

bool spi_is_initialized( uint32_t port_num );

bool spi_init_port( uint32_t port_num );

bool spi_deinit_port( uint32_t port_num );

bool spi_set_bit_rate( uint32_t port_num, uint32_t bit_rate );

bool spi_set_clock_polarity( uint32_t port_num, uint32_t polarity );

bool spi_set_data_size( uint32_t port_num, uint32_t data_size );

bool spi_set_frame_format( uint32_t port_num, uint32_t frame_format );

bool spi_set_phase_type( uint32_t port_num, uint32_t phase_type );

bool spi_set_chip_select( uint32_t port_num, uint32_t chip_select );

bool spi_set_rx_threshold( uint32_t port_num, uint32_t threshold );

bool spi_set_tx_threshold( uint32_t port_num, uint32_t threshold );

uint32_t spi_get_rx_fifo_level( uint32_t port_num );

uint32_t spi_get_tx_fifo_level( uint32_t port_num );

spi_event_t spi_get_event_status( uint32_t port_num );

spi_event_t spi_get_enabled_events( uint32_t port_num );

bool spi_enable_events(uint32_t port_num, spi_event_t events );

bool spi_disable_events(uint32_t port_num, spi_event_t events );

bool spi_read_data( uint32_t port_num, uint32_t *data );

bool spi_write_data( uint32_t port_num, uint32_t data );

bool spi_acquire_interrupt( uint32_t port_num, void *event_handler, void *port_status );

bool spi_release_interrupt( uint32_t port_num );


#ifdef __cplusplus
}
#endif



#endif
