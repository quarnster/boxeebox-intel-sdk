/*
#
#  This file is provided under a dual BSD/GPLv2 license.  When using or
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  intel.com
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  95052
#  USA
#  (408) 765-8080
#
#
#  BSD LICENSE
#
#  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions
#  are met:
#
#    * Redistributions of source code must retain the above copyright
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright
#      notice, this list of conditions and the following disclaimer in
#      the documentation and/or other materials provided with the
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its
#      contributors may be used to endorse or promote products derived
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
#*/

#include "_spi.h"
#include "pal_interrupt.h"
#include "osal_interrupt.h"
#include "osal_memory.h"

/*
 * _spi.c contains the implementation-dependent portions of the SPI interface.
 * 
 * This file implements the SPI interface for intel_gen3.
 *
 */


typedef struct {
	uint32_t device_key;
	uint32_t phys;
	uint32_t virt;
	os_interrupt_t interrupt_handler;
	spi_event_t enabled_events;
} port_info;

extern uint32_t spi_irq;

static port_info spi_port_info[NUM_SPI_PORTS] = {
	{ SPI, SPI_PHYSICAL_BASE_ADDRESS, 0, (os_interrupt_t)0, SPI_EVENT_RX_OVERRUN }
};
//static port_info spi_port_info[NUM_SPI_PORTS];


bool spi_is_valid_port_num( uint32_t port_num )
{
	return ( port_num < NUM_SPI_PORTS );
}


bool spi_is_initialized( uint32_t port_num )
{
	return ( spi_port_info[port_num].virt != 0 );
}

/* Initialize the port.  Does not check if the port is already initialized. */
bool spi_init_port( uint32_t port_num )
{
	bool return_value = false;

#ifdef HARDCODE_BAR
	/* Get a virtual pointer to the physcial hardware unit. */
	spi_port_info[port_num].virt = (uint32_t) OS_MAP_IO_TO_MEM_NOCACHE( spi_port_info[port_num].phys, SPI_REGISTER_SPACE_SIZE );
#else
	/* Get a virtual pointer to and the IRQ number of the physcial hardware unit. */
	pal_info_t *pal_info = (pal_info_t *)OS_ALLOC(sizeof(pal_info_t));
        if (pal_info == NULL)
        {
             // printk("OS_ALLOC FAILURE : could not alloc memory to pal_info \n");
              return false;
        }
        //PAL change the Device ID definition, so USE SPI to replace SPI_0,                               
        if ( pal_get_base_and_irq(SPI, &pal_info) != PAL_SUCCESS ) {
               OS_FREE(pal_info);
               return false;
        }
        spi_port_info[port_num].phys = pal_info->base_addr0;
        spi_irq = pal_info->irq_num; /* this belongs here, need to remove call to pci_get_device() in idl_spi_drv.c */
        spi_port_info[port_num].virt = (uint32_t) OS_MAP_IO_TO_MEM_NOCACHE( spi_port_info[port_num].phys, SPI_REGISTER_SPACE_SIZE );
         OS_FREE(pal_info);
#endif

	if ( spi_port_info[port_num].virt != 0 ) {
		/* Enable the port. */
		MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR0_OFFSET, SPI_CONTROL_SSE_ENABLE, SPI_CONTROL_SSE_MASK );

		/* Clear any Receive FIFO Overrun condition. */
		MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSSR_OFFSET, SPI_STATUS_ROR_TRUE, SPI_STATUS_ROR_MASK );

		return_value = true;
	}
	return ( return_value );
}


/* De-initialized the port */
bool spi_deinit_port( uint32_t port_num )
{

	/* Disable the port. */
	MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR0_OFFSET, SPI_CONTROL_SSE_DISABLE, SPI_CONTROL_SSE_MASK );

	/* Release a virtual pointer to the physcial hardware unit. */
	OS_UNMAP_IO_FROM_MEM( (void *)(spi_port_info[port_num].virt), SPI_REGISTER_SPACE_SIZE);

	spi_port_info[port_num].virt = 0;

	return (true);
}


/* Set the bit rate (i.e. clock rate) */
bool spi_set_bit_rate( uint32_t port_num, uint32_t bit_rate )
{
	/* 
	 * Forumula for caluclating the SCR value from the bit rate:
	 *    SCR = ((1.8432MHz / BitRate) - 1)
     *
	 * Therefore, valid bitrates are :
	 *  1843200 /   1 = 1843200
	 *  1843200 /   2 =  921600
	 *  1843200 /   3 =  614400
	 *  1843200 /   4 =  460800
	 *  1843200 /   5 =  368640
	 *  1843200 /   6 =  307200
	 *  1843200 /   7 =  263314
	 *  1843200 /   8 =  230400
	 *  1843200 /   9 =  204800
	 *  1843200 /  10 =  184320
	 *  1843200 /  11 =  167563
	 *  ...
	 *  1843200 / 254 =    7256
     * 1843200 / 255 =    7228
	 *  1843200 / 256 =    7200
	 */

	bool return_value = false;
	uint32_t scr;

	if ( (bit_rate >= SPI_MIN_BIT_RATE) && (bit_rate <= SPI_MAX_BIT_RATE) ) {

		scr = (SPI_MAX_BIT_RATE / bit_rate) - 1;

		/* If the specified bit rate is supported, then set it. */
		if ( (SPI_MAX_BIT_RATE / (scr + 1)) == bit_rate ) {
		  MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR0_OFFSET, scr << SPI_CONTROL_SCR_SHIFT, SPI_CONTROL_SCR_MASK );
			return_value = true;
		}
	}

	return ( return_value );
}


/* Set the data size (each data element can be 4 through 16 bits wides). */
bool spi_set_data_size( uint32_t port_num, uint32_t data_size )
{
 	bool return_value = false;
	uint32_t dss;

	// If the specified data size is supported, then set it.
	if ( (data_size >= SPI_DATA_SIZE_MIN) &&
		 (data_size <= SPI_DATA_SIZE_MAX) ) {
		dss = (data_size - 1) << SPI_CONTROL_DSS_SHIFT;
		MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR0_OFFSET, dss << SPI_CONTROL_DSS_SHIFT, SPI_CONTROL_DSS_MASK );
		return_value = true;
	}

	return ( return_value );
}

/* Set the frame format (Motorola SPI, Texas Instruments SSP, National Semiconductor Microwire) */
bool spi_set_frame_format( uint32_t port_num, uint32_t frame_format )
{
	bool return_value = false;

	if (frame_format == MOTOROLA_SPI) {
		MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR0_OFFSET, SPI_CONTROL_FRF_MOT_SPI, SPI_CONTROL_FRF_MASK );
		return_value = true;
	}

	return ( return_value );
}


bool spi_set_phase_type( uint32_t port_num, uint32_t phase_type )
{
	bool return_value = false;

	switch (phase_type) {
		case PHASE_ONE_HALF:
			MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR1_OFFSET, SPI_CONTROL_SPH_ONE, SPI_CONTROL_SPH_MASK );
			return_value = true;
			break;
		case PHASE_HALF_ONE:
			MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR1_OFFSET, SPI_CONTROL_SPH_HALF, SPI_CONTROL_SPH_MASK );
			return_value = true;
			break;
	}

	return ( return_value );
}


bool spi_set_clock_polarity( uint32_t port_num, uint32_t polarity )
{
	bool return_value = false;

	switch (polarity) {
		case INACTIVE_LOW:
			MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR1_OFFSET, SPI_CONTROL_SPO_LOW, SPI_CONTROL_SPO_MASK );
			return_value = true;
			break;
		case INACTIVE_HIGH:
			MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR1_OFFSET, SPI_CONTROL_SPO_HIGH, SPI_CONTROL_SPO_MASK );
			return_value = true;
			break;
	}

	return ( return_value );
}


bool spi_set_chip_select( uint32_t port_num, uint32_t chip_select )
{
	bool return_value = false;

	if ( chip_select <= SPI_STATUS_ALT_FRM_MAX ) {
		MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSSR_OFFSET, chip_select << SPI_STATUS_ALT_FRM_SHIFT , SPI_STATUS_ALT_FRM_MASK );
		return_value = true;
	}

	return ( return_value );
}


bool spi_set_rx_threshold( uint32_t port_num, uint32_t threshold )
{
	bool return_value = false;

	/* If the specified data size is supported, then set it. */
	if( (threshold >= SPI_RX_THRESHOLD_MIN) &&
                 (threshold <= SPI_RX_THRESHOLD_MAX) ) {
		MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR1_OFFSET, (threshold-1) << SPI_CONTROL_RFT_SHIFT, SPI_CONTROL_RFT_MASK );
		return_value = true;
	}

	return ( return_value );
}


bool spi_set_tx_threshold( uint32_t port_num, uint32_t threshold )
{
	bool return_value = false;

	/* If the specified threshold is supported, then set it. */
	if ( (threshold >= SPI_TX_THRESHOLD_MIN) &&
		 (threshold <= SPI_TX_THRESHOLD_MAX) ) {
		MODIFY_REG32( spi_port_info[port_num].virt + SPI_SSCR1_OFFSET, (threshold-1) << SPI_CONTROL_TFT_SHIFT, SPI_CONTROL_TFT_MASK );
		return_value = true;
	}

	return ( return_value );
}


uint32_t spi_get_rx_fifo_level( uint32_t port_num )
{
	
	uint32_t status;
	uint32_t level;

	status = READ_REG32(spi_port_info[port_num].virt + SPI_SSSR_OFFSET);
	level = (status & SPI_STATUS_RFL_MASK) >> SPI_STATUS_RFL_SHIFT;
	/* 
	 * The RFL bit field is somewhat awkward.  The receive
	 * FIFO level can be determined by the following table.
	 * 
	 * RFL  RNE  Level
	 * ===  ===  =====
	 *  3    0     0
	 *  0    1     1
	 *  1    1     2
	 *  2    1     3
	 *  3    1     4
	 *
	 */
	level = (level + 1) & 0x3;
	if (level == 0) {
		if ( (status & SPI_STATUS_RNE_MASK) == SPI_STATUS_RNE_TRUE ) {
			level = spi_get_rx_fifo_size(port_num);
		}
	}

	return ( level );

}


uint32_t spi_get_tx_fifo_level( uint32_t port_num )
{
	uint32_t status;
	uint32_t level;

	status = READ_REG32(spi_port_info[port_num].virt + SPI_SSSR_OFFSET);
	level = (status & SPI_STATUS_TFL_MASK) >> SPI_STATUS_TFL_SHIFT;

	/* 
	 * If the TFL reads 0, we have to check the TNF bit 
	 * to determine whether the FIFO is full or empty.
	 */
	if (level == 0) {
		if ( (status & SPI_STATUS_TNF_MASK) == SPI_STATUS_TNF_FALSE ) {
			level = spi_get_tx_fifo_size(port_num);
		}
	}

	return ( level );
}


spi_event_t spi_get_event_status( uint32_t port_num )
{
	uint32_t status;
	spi_event_t return_value = SPI_EVENT_NONE;

	status = READ_REG32(spi_port_info[port_num].virt + SPI_SSSR_OFFSET);
	if ( (status & SPI_STATUS_RFS_MASK) == SPI_STATUS_RFS_TRUE ) {
		return_value |= SPI_EVENT_RX_THRESHOLD;
	}
	if ( (status & SPI_STATUS_TFS_MASK) == SPI_STATUS_TFS_TRUE ) {
		return_value |= SPI_EVENT_TX_THRESHOLD;
	}
	if ( (status & SPI_STATUS_ROR_MASK) == SPI_STATUS_ROR_TRUE ) {
		return_value |= SPI_EVENT_RX_OVERRUN;
		MODIFY_REG32(spi_port_info[port_num].virt + SPI_SSSR_OFFSET, SPI_STATUS_ROR_TRUE, SPI_STATUS_ROR_MASK);
	}

	return (return_value);
}


bool spi_enable_events( uint32_t port_num, spi_event_t events )
{
	bool return_value = false;
	
	uint32_t event_bits = 0;

	if ( (events & ~SPI_EVENT_ALL) == 0 ) {

		if ( (events & SPI_EVENT_RX_THRESHOLD) != 0) {
			event_bits |= SPI_CONTROL_RIE_ENABLE ;
		}
		if ( (events & SPI_EVENT_TX_THRESHOLD) != 0) {
			event_bits |= SPI_CONTROL_TIE_ENABLE ;
		}
		/*
		 * The Receive FIFO Overrun interrupt is always enabled in intel_gen3.
         * Therefore, all attempts to enable it will always succeed.
		 *
		 * if ( (events & SPI_EVENT_RX_OVERRUN) != 0) {
		 *	event_bits |= SPI_CONTROL_ROR_ENABLE ;
		 * }
		 */

		spi_port_info[port_num].enabled_events |= events;
		MODIFY_REG32(spi_port_info[port_num].virt + SPI_SSCR1_OFFSET, event_bits, event_bits);
		return_value = true;
	}

	return ( return_value );
}


bool spi_disable_events( uint32_t port_num, spi_event_t events )
{
	bool return_value = false;
	
	uint32_t event_bits = 0;

	if ( (events & ~SPI_EVENT_ALL) == 0 ) {
		if ( (events & SPI_EVENT_RX_THRESHOLD) != 0) {
			event_bits |= SPI_CONTROL_RIE_ENABLE ;
		}
		if ( (events & SPI_EVENT_TX_THRESHOLD) != 0) {
			event_bits |= SPI_CONTROL_TIE_ENABLE ;
		}
		if ( (events & SPI_EVENT_RX_OVERRUN) != 0) {
			/* The Receive FIFO Overrun interrupt cannot be disabled in intel_gen3 but we can at least clear the event. */
			events &= ~SPI_EVENT_RX_OVERRUN;
			MODIFY_REG32(spi_port_info[port_num].virt + SPI_SSSR_OFFSET, SPI_STATUS_ROR_TRUE, SPI_STATUS_ROR_MASK);
			/* event_bits |= SPI_CONTROL_ROR_ENABLE; */
		}

		spi_port_info[port_num].enabled_events &= ~events;
		MODIFY_REG32(spi_port_info[port_num].virt + SPI_SSCR1_OFFSET, ~event_bits, event_bits);
		return_value = true;
	}

	return ( return_value );
}


spi_event_t spi_get_enabled_events( uint32_t port_num )
{
	return ( spi_port_info[port_num].enabled_events );
}


bool spi_read_data( uint32_t port_num, uint32_t *data )
{
	uint32_t status;
	bool return_value = false;

	/* If there is data in the receive FIFO, then read the data. */
	status = READ_REG32(spi_port_info[port_num].virt + SPI_SSSR_OFFSET);
	if ( (status & SPI_STATUS_RNE_MASK) == SPI_STATUS_RNE_TRUE ) {
		*data = READ_REG32(spi_port_info[port_num].virt + SPI_SSDR_OFFSET);
		return_value = true;
	}

	return ( return_value );
}


bool spi_write_data( uint32_t port_num, uint32_t data )
{
	uint32_t status;
	bool return_value = false;

	/* If there is room in the transmit FIFO, then write the data. */
	status = READ_REG32(spi_port_info[port_num].virt + SPI_SSSR_OFFSET);
	if ( (status & SPI_STATUS_TNF_MASK) == SPI_STATUS_TNF_TRUE ) {
		WRITE_REG32(spi_port_info[port_num].virt + SPI_SSDR_OFFSET, data);
		return_value = true;
	}

	return ( return_value );
}


bool spi_acquire_interrupt( uint32_t port_num, void *event_handler, void *handler_data )
{
	spi_port_info[port_num].interrupt_handler =	os_acquire_interrupt( spi_irq, 
                                                                      spi_port_info[port_num].device_key, 
                                                                      "SPI", 
                                                                      event_handler, 
                                                                      handler_data );
	return ( true );
}


bool spi_release_interrupt( uint32_t port_num )
{
	os_release_interrupt( spi_port_info[port_num].interrupt_handler );
	return ( true );
}


