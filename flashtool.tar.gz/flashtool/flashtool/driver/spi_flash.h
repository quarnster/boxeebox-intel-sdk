/*
 * GPL LICENSE SUMMARY
 * Copyright (c) 2011, Intel Corporation and its suppliers.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */


#define INTEL_VENORID 0x8086
#define CE4200_DEVID 0x0709

#define SPI_F_CSR0_MBAR 0xDFFE0100
#define SPI_F_CSR0_LENGTH 0x100 //256B
#define SPI_F_WIN_MBAR 0xD8000000
#define SPI_F_WIN_LENGTH 0x4000000 //64MB
#define SPI_F_CSR1_MBAR 0xDFFE0000
#define SPI_F_CSR1_LENGTH 0x100 //256B

// Parameters of flash M25P32
#define SECTOR_NUMBER       64
#define PAGENUM_PER_SECTOR (SECTOR_SIZE/SPI_PAGE_SIZE)
#define SECTOR_SIZE         0x10000 // sector size is 64KB for M25P32
#define SPI_PAGE_SIZE           0x100   // Page size is 256 bytes for M25P32
#define FLASH_SIZE          (SECTOR_SIZE * SECTOR_NUMBER)  // 4MB for M25P32
#define PAGE_BASE_MASK      (SPI_PAGE_SIZE - 1)
#define SECTOR_BASE_MASK    (SECTOR_SIZE - 1)
#define WRITE_BUFFER_SIZE SECTOR_SIZE

// Register offset
#define MODE_CONTL_REG       0x00
#define ADDR_SPLIT_REG       0x04
#define CURRENT_ADDR_REG     0x08
#define DATA_COMMAND_REG     0x0C
#define INTERFACE_CONFIG_REG 0x10

// Command supported by SPI NOR Flash
#define RDID_COMMAND 0x9F
#define WREN_COMMAND 0x06
#define WRDI_COMMAND 0x04
#define RDSR_COMMAND 0x05
#define WRSR_COMMAND 0x01
#define READ_COMMAND 0x03
#define FAST_READ_COMMAND 0x0B
#define PAGE_PROG_COMMAND 0x02
#define SECT_ERSE_COMMAND 0xD8
#define BULK_ERSE_COMMAND 0xC7
#define DEEP_PWDN_COMMAND 0xB9
#define RES_COMMAND       0xAB

// Bits in status register
#define WIP_BIT    0x01
#define WEL_BIT    0x02
#define BP0_BIT    0x04
#define BP1_BIT    0x08
#define BP2_BIT    0x10
#define SRWD_bit   0x80

#define INTEL_SPI_PERROR(fmt, args...) printk("[ERROR] %s: " fmt, __FUNCTION__ , ## args)

//#define SPI_DEBUG 1//For debug usage
#ifdef SPI_DEBUG
#   define SPI_PRINT(fmt, args...) printk("%s: " fmt, __FUNCTION__ , ## args)
#   define SPI_TRACE printk("Line %d.%s: ->",__LINE__,__FUNCTION__);
#else
#   define SPI_PRINT(fmt, args...)
#endif



#include "common.h"

typedef intel_ce_flash_info_t spi_flash_info_t;
typedef intel_ce_flash_cmd_t spi_flash_cmd_t;

struct flash_dev{
	int memory_map_count;
	int flash_id;
	struct mutex rw_sem;
	struct cdev cdev;
	spi_flash_info_t flash_info;
	memory_map_item_t memory_map[MAX_MEMORY_MAP];
	
};


#define INTEL_SPI_FLASH_ERASE INTEL_CE_FLASH_ERASE
#define INTEL_SPI_FLASH_RESET INTEL_CE_FLASH_RESET
#define INTEL_SPI_FLASH_READINFO INTEL_CE_FLASH_READINFO
#define INTEL_SPI_FLASH_WRITE_BLOCK INTEL_CE_FLASH_WRITE_BLOCK
#define INTEL_SPI_FLASH_READ_BLOCK INTEL_CE_FLASH_READ_BLOCK
#define INTEL_SPI_FLASH_GET_MAP INTEL_CE_FLASH_GET_MAP
#define INTEL_SPI_FLASH_READ_BYTES INTEL_CE_FLASH_READ_BYTES
#define INTEL_SPI_FLASH_READ_SECRET_BYTES INTEL_CE_FLASH_READ_SECRET_BYTES
#define INTEL_SPI_FLASH_WRITE_SECRET_BYTES INTEL_CE_FLASH_WRITE_SECRET_BYTES

