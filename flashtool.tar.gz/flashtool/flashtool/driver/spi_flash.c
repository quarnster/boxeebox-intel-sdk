/*
 * GPL LICENSE SUMMARY
 * Copyright (c) 2011, Intel Corporation and its suppliers.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */
#include <linux/version.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/pci.h>
#include <linux/pci_ids.h>
#include <linux/interrupt.h>
#include <linux/spinlock.h>
#include <linux/miscdevice.h>
#include <linux/mm.h>
#include <linux/vmalloc.h>
#include <linux/delay.h>
#include <linux/wait.h>
#include <linux/types.h>
#include <linux/cdev.h>

#include <asm/uaccess.h>
//#include <asm/hardware.h>

#define READ_FROM_MAP_WINDOW 1	//SPI Flash is mapped into a 64 MB memory mapped window that can be read directly by the host processor or any other agent.

#include "spi_flash.h"
#ifdef LINUX
char *version_string = "#@# intel-spi-flash.ko " VER;
#endif

#define DEVICE_NAME "spi_flash"

#define DOWN_SPI_SEM(sem)  do{\
		if (mutex_lock_interruptible(&sem))\
		{\
			return -ERESTARTSYS;\
		}\
	}while(0)

#define UP_SPI_SEM(sem) do{\
		mutex_unlock(&sem);\
	}while(0)


static struct flash_dev *spi_flash_dev;
int spi_flash_major = 0;
int spi_flash_minor = 0;

#define SPI_SECRET_BLK_NUM 2	//we reserved 2 blocks as secret area
#define SPI_SECRET_START spi_flash_dev->memory_map[spi_flash_dev->memory_map_count- SPI_SECRET_BLK_NUM].start
#define SPI_SECRET_END spi_flash_dev->memory_map[spi_flash_dev->memory_map_count - 1].end

static u8 * sector_buffer;
static u8 * tmp_buffer;
	
volatile static u32 INTEL_SPI_FLASH_CS0_BASE_VIRT = 0;
volatile static u32 INTEL_SPI_FLASH_CS1_BASE_VIRT = 0;
volatile static u32 INTEL_SPI_FLASH_MBAR_BASE_VIRT = 0;

volatile static u32 SPI_WIN_MBAR = 0;

/****************************************************************************************
 * 
 * SPI Flash Bus API
 *
 ***************************************************************************************/
static void spi_turn_off_chip_sel(void ) {
    *((volatile u32 *)(INTEL_SPI_FLASH_CS0_BASE_VIRT + DATA_COMMAND_REG)) = 0;
}

static u8 spi_read_byte(void ) {
    
    u8 readData;
    *((volatile u32 *)(INTEL_SPI_FLASH_CS0_BASE_VIRT + DATA_COMMAND_REG)) = 0x05000000;
    readData = (u8)(*((volatile u32 *)(INTEL_SPI_FLASH_CS0_BASE_VIRT + DATA_COMMAND_REG)));

//    SPI_PRINT("spi_read_byte: 0x%02X\n", readData);
    return readData;
}

static void spi_write_byte(u8 data) {
     
    u32 writeData = (u8)data;
    u32 dummyData;
    *((volatile u32 *)(INTEL_SPI_FLASH_CS0_BASE_VIRT + DATA_COMMAND_REG)) = 0x05000000 | (writeData << 16);
     
    writeData = 0x05000000 | (writeData << 16);
  

    // Dummy read
    dummyData = *((volatile u32 *)(INTEL_SPI_FLASH_CS0_BASE_VIRT + DATA_COMMAND_REG));
//	  SPI_PRINT("spi_write_byte: 0x%08X\n", writeData);

}

static void spi_write_address(u32 address) {
     
    u32 dummyData, sendAddress;
	
    *((volatile u32 *)(INTEL_SPI_FLASH_CS0_BASE_VIRT + DATA_COMMAND_REG)) = 0x07000000 | (address & 0x00FFFFFF);

    sendAddress = 0x07000000 | (address & 0x00FFFFFF);
 //   SPI_PRINT("spi_write_address: 0x%08X\n", sendAddress);
     
    // Dummy read
    dummyData = *((volatile u32 *)(INTEL_SPI_FLASH_CS0_BASE_VIRT + DATA_COMMAND_REG));
}

/****************************************************************************************
 * 
 * Main SPI Flash API
 *
 ***************************************************************************************/

static u32 spi_read_id(u32 *idNum) {
	
    u8 *idStr = (u8 *)idNum;
    // Trun off chip select
    spi_turn_off_chip_sel();
    
    // Send RDID command
    spi_write_byte(RDID_COMMAND);
    
    // Read ID string
    *idStr = spi_read_byte();
    *(idStr + 1) = spi_read_byte();
    *(idStr + 2) = spi_read_byte();
    
    // Trun off chip select
    spi_turn_off_chip_sel();
	return *idNum;

}

static u8 spi_read_stats_reg(void) {

    u8 status;


    
    // Trun off chip select
    spi_turn_off_chip_sel();
    
    // Send RDSR command
    spi_write_byte(RDSR_COMMAND);
    
    // Read ID string
    status = spi_read_byte();
   
    // Trun off chip select
    spi_turn_off_chip_sel();
   
    return status;   

}

static void spi_write_enable(void) {
    // Trun off chip select
    spi_turn_off_chip_sel();
    
    // Send WREN command
    spi_write_byte(WREN_COMMAND);
    
    // Check the status register for Write Enable Latch bit, it should be 0x02 
    while (WEL_BIT != (spi_read_stats_reg() & WEL_BIT)) {
				yield();
    }

    // Trun off chip select
    spi_turn_off_chip_sel();
}

static void spi_write_disable(void) {

    // Trun off chip select
    spi_turn_off_chip_sel();
    
    // Send WRDI command
    spi_write_byte(WRDI_COMMAND);
    
    // Check the status register for Write Enable Latch bit, it should be 0x00 
    while (0 != (spi_read_stats_reg() & WEL_BIT)) {
				yield();
    }

    // Trun off chip select
    spi_turn_off_chip_sel();
}
//buffer -- target address in RAM
//address --source address of SPI NOR
static u32 spi_read_data(u8 * buffer, u32 address, u32 length) {
    u32 i;

    
    // Trun off chip select
    spi_turn_off_chip_sel();
    
    // Send WRDI command
    spi_write_byte(READ_COMMAND);
    
    // Send address want to read
    spi_write_address(address);
    
    // Read data one by one
    for (i = 0; i < length; i++) {
        *((volatile u8 *)buffer + i) = spi_read_byte();
        if (0 == i % SPI_PAGE_SIZE)
            printk("$");
    }
    printk("\n");
    
    // Trun off chip select
    spi_turn_off_chip_sel();    
	return 0;
}

/****************************************************************************************
 * 
 * Page Program: Write data into a specific page, write data beyond end of current page
 *               are written from the start address of the same page. So this function 
 *               can write maximal 256 bytes in a page.  
 * 
 * Input:        
 		buffer -- source address in RAM
 		address -- target address in SPI NOR
 * Output:       Size the bytes that are written into current page.
 ***************************************************************************************/
static u32 spi_page_write(u32 buffer, u32 address, u32 length) {
    u32 i;
    u32 maxWriteLength;
    u32 writeSize;
    
    maxWriteLength = SPI_PAGE_SIZE - (address & PAGE_BASE_MASK);
    
    if (length > maxWriteLength) {
        writeSize = maxWriteLength;
    } else {
        writeSize = length;
    }


    
    // Trun off chip select
    spi_turn_off_chip_sel();
    
    // Write enable
    spi_write_enable();
    
    // Send PAGE_PROG command
    spi_write_byte(PAGE_PROG_COMMAND);
    
    // Send address want to read
    spi_write_address(address);
    
    // Write data one by one
    for (i = 0; i < writeSize; i++) {
        spi_write_byte(*((volatile u8 *)buffer + i));
    }
    
    // Trun off chip select
    spi_turn_off_chip_sel();
    
    return writeSize;      
}
/****************************************************************************************
 * Sector Erase: Erase a sector and set all data to 0xFF in chosen setor. Any address 
 *               inside the sector will erase the chosen sector.
 *
 * Input       : Address in the chosen sector       
 ***************************************************************************************/

static void spi_sector_erase(u32 address) {
    // Trun off chip select
    spi_turn_off_chip_sel();
    
    // Write enable
    spi_write_enable();
    
    // Send SECT_ERSE command
    spi_write_byte(SECT_ERSE_COMMAND);
    
    // Send address want to erase
    spi_write_address(address);
    // Check WIP bit in status register
    while ( 0 != (spi_read_stats_reg() & WIP_BIT)) 
		yield();
    // Trun off chip select
    spi_turn_off_chip_sel();
 
}

/****************************************************************************************
 * Chip Erase: Erase the chip with Bulk Erase command 
 *
 ***************************************************************************************/
static void spi_chip_erase(void) {
    
    // Trun off chip select
    spi_turn_off_chip_sel();
    
    // Write enable
    spi_write_enable();
    
    // Send BULK_ERSE command
    spi_write_byte(BULK_ERSE_COMMAND);
       
    // Check WIP bit in status register
    while ( 0 != (spi_read_stats_reg() & WIP_BIT)) {
				yield();
    }
    
    // Trun off chip select
    spi_turn_off_chip_sel();
 
}
/****************************************************************************************
 * Sector Write: Write one sector 
 *
 ***************************************************************************************/
static u32 spi_sector_write(u32 src, u32 blockno) {    
    int i = 0;
    u32 dst = 0;
    if (blockno > MAX_MEMORY_MAP)
	    return -EINVAL;
    dst = spi_flash_dev->memory_map[blockno].start;

    // Write the main body of data from srcAddr
    for (i = 0; i < PAGENUM_PER_SECTOR; i ++) {
        spi_page_write(src + SPI_PAGE_SIZE * i, dst + SPI_PAGE_SIZE * i, SPI_PAGE_SIZE);
        printk("Programming at block %d page %d ......\n",blockno, i);
    }
 	return 0;
}
/*****************************************************************************
			Linux Device Driver interface
*****************************************************************************/
static int _erase_one_block(int offset)
{
	spi_sector_erase(offset);
	return 0;
}
int spi_flash_erase(int offset, int flags, int eflags)
{
	int ret = -EIO;
	if(eflags == 1)
	{
		if(offset >= SPI_SECRET_START)
			return -EINVAL; 
	}
	ret = _erase_one_block(offset);

	return ret;
}
static int spi_flash_readinfo(spi_flash_info_t * pInfo)
{
	int ret = 0;
	struct flash_dev *pdev = spi_flash_dev;
	if(!pInfo)
		return -EINVAL;
	if (copy_to_user((char *)(pInfo), (char *)(&pdev->flash_info), sizeof(spi_flash_info_t)))
		return -EFAULT;
	return ret;
}
static int spi_flash_reset(void)
{
	return 0;
}

//Read from NOR flash to user buffer 
static int spi_flash_read_bytes(spi_flash_cmd_t * pCmd)
{
	int ret = 0;
	unsigned long volatile flashBase = 0;
	
	if(!pCmd)
		return -EINVAL;
	if(!(pCmd->buf))
		return -EINVAL;
	if(pCmd->offset < 0 || pCmd->offset > SPI_SECRET_START || (pCmd->offset + pCmd->length) > SPI_SECRET_START)
	{
		INTEL_SPI_PERROR("read out of flash range: offset=0x%x, size=0x%x\n",
			pCmd->offset, pCmd->length);
		return -EINVAL;
	}

	flashBase += (pCmd->offset);
#if READ_FROM_MAP_WINDOW
	flashBase += INTEL_SPI_FLASH_MBAR_BASE_VIRT;
	printk("Read from 0x%x to 0x%x\n",flashBase,(pCmd->buf));
	
	if (copy_to_user((char *)(pCmd->buf), (char *)(flashBase), pCmd->length))		
	{
		INTEL_SPI_PERROR("copy_to_user error line %d\n",__LINE__);	
		return -EFAULT;
	}
#else	
	if (!(tmp_buffer = (u8 *)kzalloc(pCmd->length, GFP_KERNEL)))
	{
		printk("Error: Can not alloc buffer for read \n");
		return -EIO;
	}
	ret=spi_read_data(tmp_buffer,flashBase,pCmd->length);
	
	if (copy_to_user((void *)(pCmd->buf), (void *)(tmp_buffer), pCmd->length))
		return -EFAULT;
	kfree(tmp_buffer);
#endif
	return ret;

}
static int spi_flash_read_secret_bytes_internal(spi_flash_cmd_t * pCmd, int flag)
{
	int ret = 0;
	int start = SPI_SECRET_START;
	int end = SPI_SECRET_END;

	unsigned long volatile flashBase = 0 + start;

	if(!pCmd)
		return -EINVAL;
	if(!(pCmd->buf))
		return -EINVAL;
	if((pCmd->offset < 0) || (pCmd->offset >= (end-start+1)) || ((pCmd->offset + pCmd->length) > (end-start +1)))   
	{
		INTEL_SPI_PERROR("read out of flash range: offset=0x%x, size=0x%x\n",
			pCmd->offset, pCmd->length);
		return -EINVAL;
	}

	flashBase += (pCmd->offset);
#if READ_FROM_MAP_WINDOW
		flashBase += INTEL_SPI_FLASH_MBAR_BASE_VIRT;
        SPI_PRINT("flashBase=0x%lx\n", flashBase);

		if(flag == 1)
		{
			if (copy_to_user((char *)(pCmd->buf), (char *)(flashBase), pCmd->length))
				{
					INTEL_SPI_PERROR("copy_to_user error!\n");
					return -EINVAL;
				}
			}
		else
			memcpy((char *)(pCmd->buf), (char *)(flashBase), pCmd->length);
#else
	if(flag == 1)
	{	
		if (!(tmp_buffer = (u8 *)kzalloc(pCmd->length, GFP_KERNEL)))
		{
			printk("Error: Can not alloc buffer for read \n");
			return -EIO;
		}
		ret=spi_read_data(tmp_buffer,flashBase,pCmd->length);
		if (copy_to_user((void *)(pCmd->buf), tmp_buffer, pCmd->length))
			return -EFAULT;
		kfree(tmp_buffer);
	}
	else
		ret=spi_read_data((char *)(pCmd->buf), flashBase, pCmd->length);
#endif
	return ret;
}
int spi_flash_read_secret_bytes(spi_flash_cmd_t * pCmd)
{
	return spi_flash_read_secret_bytes_internal(pCmd,0);
}
EXPORT_SYMBOL(spi_flash_read_secret_bytes);

static int spi_flash_read_block(spi_flash_cmd_t * pCmd, int flags)
{
	int ret = 0;
	int count;
	unsigned long volatile flashBase = 0;
	int temp_count;
	struct flash_dev *pdev = spi_flash_dev;
	if(flags == 1)
		temp_count = pdev->memory_map_count - 1;
	else
		temp_count = pdev->memory_map_count;
	
	if(!pCmd)
		return -EINVAL;
	if(!(pCmd->buf))
		return -EINVAL;
	if((pCmd->blockno) >= temp_count || (pCmd->blockno) < 0)
	{
		INTEL_SPI_PERROR("invalid block number: %d\n", pCmd->blockno);
		return -EINVAL;
	}

	flashBase += pdev->memory_map[pCmd->blockno].start;
	count = (pdev->memory_map[pCmd->blockno].end) - (pdev->memory_map[pCmd->blockno].start) + 1;
		
#if	READ_FROM_MAP_WINDOW
	flashBase += INTEL_SPI_FLASH_MBAR_BASE_VIRT;
	SPI_PRINT("flashBase=0x%lx\n", flashBase);

	if(flags == 1)
		if (copy_to_user((char *)(pCmd->buf), (char *)(flashBase), count))
			{
				INTEL_SPI_PERROR("copy_to_user error\n");
				return -EFAULT;
			}		
		else
			memcpy((char *)(pCmd->buf), (char *)(flashBase), count);

#else

	if(flags == 1)
		{
			memset(sector_buffer,0,count);
			spi_read_data(sector_buffer,flashBase,count);
			if (copy_to_user((char *)(pCmd->buf), sector_buffer, count))
				return -EFAULT;
		}
	else
		ret= spi_read_data((char *)(pCmd->buf), flashBase, count);
#endif
	return ret;
}
static int spi_flash_write_block(spi_flash_cmd_t * pCmd, int flags)
{
	int count, ret = 0;
	u16 * src;
	int temp_count;
	struct flash_dev *pdev = spi_flash_dev;
	
	if(flags == 1)
		temp_count = pdev->memory_map_count - 1;
	else
		temp_count = pdev->memory_map_count;

	if(!(pCmd->buf))
		return -EINVAL;
	if((pCmd->blockno) < 0 || (pCmd->blockno) >= temp_count)
	{
		INTEL_SPI_PERROR("invalid block number: %d\n", pCmd->blockno);
		return -EINVAL;
	}
	//SPI_PRINT("pBuf=0x%p, blockno=0x%x, start 0x%x, end 0x%x\n", pCmd->buf, pCmd->blockno,(pdev->memory_map[pCmd->blockno].start),(pdev->memory_map[pCmd->blockno].end));
	//SPI_PRINT("program block...\n");


	src = (u16 *)pCmd->buf;
	count = (pdev->memory_map[pCmd->blockno].end) - (pdev->memory_map[pCmd->blockno].start) + 1;
	SPI_PRINT("pBuf=0x%p, blockno=0x%x, start 0x%x, end 0x%x, count 0x%x\n", pCmd->buf, pCmd->blockno,(pdev->memory_map[pCmd->blockno].start),(pdev->memory_map[pCmd->blockno].end),count);
	SPI_PRINT("program block...\n");

	if(flags == 1)//From user space
	{
		memset(sector_buffer, 0, count);
		if (copy_from_user(sector_buffer,(void *)src, count))
			return -EFAULT;
		ret = spi_sector_write((u32)sector_buffer, pCmd->blockno);
	}
	else
		ret = spi_sector_write((u32)src, pCmd->blockno);
    printk("\n");
	return ret;

}
static int spi_flash_write_secret_bytes_internal(spi_flash_cmd_t * pCmd, int flags)
{
	int ret = 0;
	spi_flash_cmd_t rwcmd;
	struct flash_dev *pdev = spi_flash_dev;
	u8 *temp_buf;
	u8 *p;
	int start = SPI_SECRET_START;
	int end = SPI_SECRET_END;
	int i = 0;

	if(!pCmd)
		return -EINVAL;
	if(!(pCmd->buf))
		return -EINVAL;
	if((pCmd->offset < 0) || (pCmd->offset >= (end-start+1)) || ((pCmd->offset + pCmd->length) > (end-start +1)))   
	{
		INTEL_SPI_PERROR("write out of flash range: offset=0x%x, size=0x%x\n",
			pCmd->offset, pCmd->length);
		return -EINVAL;
	}
	temp_buf = kzalloc(SPI_SECRET_BLK_NUM * pdev->flash_info.blocksize, GFP_KERNEL);
	if(!temp_buf)
	{
		return -ENOMEM;
	}
	
	rwcmd.buf = temp_buf;
	for (i = (pdev->memory_map_count - SPI_SECRET_BLK_NUM); i< pdev->memory_map_count; i++)
	{
	rwcmd.blockno = i;
	ret=spi_flash_read_block(&rwcmd, 0);
	if(ret < 0)
	{
		printk("error reading block\n");
		goto ioreturn;
	}
	rwcmd.buf += (pdev->memory_map[rwcmd.blockno].end) - (pdev->memory_map[rwcmd.blockno].start) + 1;
	}
	p = temp_buf + pCmd->offset;
	if(flags == 1)
	{
		if (copy_from_user(p, pCmd->buf, pCmd->length))
		{
			ret = -EFAULT;
			goto ioreturn;
		}
	}
	else
		memcpy(p, pCmd->buf, pCmd->length);

	rwcmd.buf = temp_buf;
	for (i = (pdev->memory_map_count - SPI_SECRET_BLK_NUM); i< pdev->memory_map_count; i++)
	{
	rwcmd.blockno = i;

	ret = spi_flash_erase(pdev->memory_map[rwcmd.blockno].start,0,0);
	if(ret < 0)
	{
		printk("erase error\n");
		goto ioreturn;
	}

	ret = spi_flash_write_block(&rwcmd, 0);
	if(ret < 0)
	{
		printk("write error\n");
		goto ioreturn;
	}
	rwcmd.buf += (pdev->memory_map[rwcmd.blockno].end) - (pdev->memory_map[rwcmd.blockno].start) + 1;
	}
ioreturn:
	kfree(temp_buf);
	return ret;

}
int spi_flash_write_secret_bytes(spi_flash_cmd_t * pCmd, int flags)
{
	return spi_flash_write_secret_bytes_internal(pCmd, 0);
}

EXPORT_SYMBOL(spi_flash_write_secret_bytes);

static int spi_flash_get_map(memory_map_t * pMap)
{
	if(!pMap)
		return -EINVAL;
	
	if (copy_to_user(pMap->map, spi_flash_dev->memory_map, sizeof(memory_map_item_t) * MAX_MEMORY_MAP))
			return -EFAULT;
	pMap->memory_map_size = spi_flash_dev->memory_map_count;
	
	return 0;
}
static int spi_flash_open(struct inode *inode, struct file * file)
{	return 0;
}

static int spi_flash_close(struct inode *inode, struct file * file)
{	
	return 0;
}

static long spi_flash_ioctl(struct file * file,
		   unsigned int cmd, unsigned long arg)
{
	int status = -EINVAL;
	spi_flash_cmd_t rwcmd;
        SPI_PRINT("cmd=%d arg=0x%08lx\n", cmd, arg);
	DOWN_SPI_SEM(spi_flash_dev->rw_sem);
	switch(cmd)
	{
		case INTEL_SPI_FLASH_ERASE:
			status = spi_flash_erase(arg, file->f_flags, 1);
			break;
		case INTEL_SPI_FLASH_READINFO:
			status = spi_flash_readinfo((spi_flash_info_t *)arg);
			break;
		case INTEL_SPI_FLASH_RESET:
			status = spi_flash_reset();
			break;
		case INTEL_SPI_FLASH_READ_BLOCK:
			if(0 == copy_from_user(&rwcmd, (void *)arg, sizeof(rwcmd)))
			{
				status = spi_flash_read_block(&rwcmd, 1);
			}
			break;
		case INTEL_SPI_FLASH_READ_BYTES:
			if(0 == copy_from_user(&rwcmd, (void *)arg, sizeof(rwcmd)))
			{
				status = spi_flash_read_bytes(&rwcmd);
			}
			break;
		case INTEL_SPI_FLASH_READ_SECRET_BYTES:
			if(0 == copy_from_user(&rwcmd, (void *)arg, sizeof(rwcmd)))
			{
				status = spi_flash_read_secret_bytes_internal(&rwcmd,1);
			}
			break;
		case INTEL_SPI_FLASH_WRITE_SECRET_BYTES:
			if(0 == copy_from_user(&rwcmd, (void *)arg, sizeof(rwcmd)))
			{
				status = spi_flash_write_secret_bytes_internal(&rwcmd, 1);
			}
			break;

		case INTEL_SPI_FLASH_WRITE_BLOCK:
			if(0 == copy_from_user(&rwcmd, (void *)arg, sizeof(rwcmd)))
				status = spi_flash_write_block(&rwcmd, 1);
			break;
		case INTEL_SPI_FLASH_GET_MAP:
			status = spi_flash_get_map((memory_map_t *)arg);
			break;
		default:
			break;
	}
	UP_SPI_SEM(spi_flash_dev->rw_sem);
	return status;
}
static struct file_operations spi_flash_fops = {
	.owner = THIS_MODULE,
	.open = spi_flash_open,
	.release = spi_flash_close,
	.unlocked_ioctl = spi_flash_ioctl
};
//Probe whether there's SPI NOR flash exist
static int spi_flash_probe(struct flash_dev *dev)
{
	if (!(spi_read_id(&dev->flash_id)))
	{
		INTEL_SPI_PERROR("No SPI NOR FLASH Exist\n");
		return -ENODEV;
	}
	dev->flash_info.blocksize = SECTOR_SIZE;
	dev->flash_info.size_in_bytes = FLASH_SIZE;
	dev->flash_info.blocksize2 = 0;
	dev->flash_info.parameter = 0;
	return 0;
}

static int _build_memory_map(struct flash_dev *dev)
{
	int i,last,j=0;
	int sector_size = 0;
	memory_map_item_t *pMap = &dev->memory_map[0];
	spi_flash_info_t *pInfo = &dev->flash_info;
		
	if(!pMap || !pInfo)
		return 1;
	
	sector_size = pInfo->blocksize;
	
	last = 0;
	for (j = 0; j < SECTOR_NUMBER; j++)
	{
		pMap[j].start = last;
		pMap[j].end = pMap[j].start + sector_size- 1;
		last = pMap[j].end + 1; 
	}
	dev->memory_map_count = j - 1;
	
#ifdef SPI_DEBUG
	for(i = 0; i < 4; i++)
	{
		printk("%02d: start=0x%08x, end=0x%08x\n", i, pMap[i].start, pMap[i].end);
	}
	for(i = j - 4; i < j; i++)
	{
		printk("%02d: start=0x%08x, end=0x%08x\n", i, pMap[i].start, pMap[i].end);
	}
#endif
	return 0;
}
static void _setup_cdev(struct flash_dev *dev)
{         
	int err, devno = MKDEV(spi_flash_major, spi_flash_minor);
	
    cdev_init(&dev->cdev, &spi_flash_fops);
    dev->cdev.owner = THIS_MODULE;
    dev->cdev.ops = &spi_flash_fops;
	
    err = cdev_add (&dev->cdev, devno, 1);
    /* Fail gracefully if need be */
    if (err)
           printk(KERN_NOTICE "Error %d adding dev%d", err,devno);
}
static void _cleanup_cdev(void)
{

	dev_t devno = MKDEV(spi_flash_major, spi_flash_minor);
	cdev_del(&spi_flash_dev->cdev);
	unregister_chrdev_region(devno, 1);
	if (spi_flash_dev)
		kfree(spi_flash_dev);
}

static int __init spi_flash_init(void)
{
	int i, rev = 0;

	dev_t dev = 0;
 	if (spi_flash_major)
	{
		dev = MKDEV(spi_flash_major,spi_flash_minor);
		i = register_chrdev_region(dev,0,DEVICE_NAME);
	}
	else
	{
		i = alloc_chrdev_region(&dev,spi_flash_minor,1,DEVICE_NAME);
		spi_flash_major = MAJOR(dev);
	}
	SPI_PRINT("Chr dev register success major: %d\n",spi_flash_major);
	if (i < 0 )
	{
		INTEL_SPI_PERROR("CAN't get major %d\n",spi_flash_major);
		rev = -EIO;
		goto out;
	}
    spi_flash_dev = kzalloc(sizeof(struct flash_dev), GFP_KERNEL);
    if (!spi_flash_dev) {
        rev = -ENOMEM;
        goto cdev_fail;  /* Make this more graceful */
    }
	mutex_init(&spi_flash_dev->rw_sem);
	_setup_cdev(spi_flash_dev);

	INTEL_SPI_FLASH_CS0_BASE_VIRT = (volatile unsigned long)ioremap_nocache(SPI_F_CSR0_MBAR,SPI_F_CSR0_LENGTH);
	INTEL_SPI_FLASH_CS1_BASE_VIRT = (volatile unsigned long)ioremap_nocache(SPI_F_CSR1_MBAR,SPI_F_CSR1_LENGTH);
	INTEL_SPI_FLASH_MBAR_BASE_VIRT = (volatile unsigned long)ioremap_nocache(SPI_F_WIN_MBAR,SPI_F_WIN_LENGTH);

    SPI_PRINT("INTEL_SPI_FLASH_CS0_BASE_VIRT = 0x%08X\n", INTEL_SPI_FLASH_CS0_BASE_VIRT);
    SPI_PRINT("INTEL_SPI_FLASH_CS1_BASE_VIRT = 0x%08X\n", INTEL_SPI_FLASH_CS1_BASE_VIRT);
    SPI_PRINT("INTEL_SPI_FLASH_MBAR_BASE_VIRT = 0x%08X\n", INTEL_SPI_FLASH_MBAR_BASE_VIRT);
  //  SPI_PRINT("SPI_WIN_MBAR = 0x%08X\n", SPI_WIN_MBAR);

    *((volatile u32 *)(INTEL_SPI_FLASH_CS0_BASE_VIRT + MODE_CONTL_REG)) = 0x44450031; // SLE clock divider = 1, 33.3MHZ

	
	if(0 != (i = spi_flash_probe(spi_flash_dev)))
	{
		if (i == -ENODEV)
		{
			printk(KERN_ERR "flashtool::No valid SPI NOR flash device detected, skipping attempt to install NOR flash driver\n");
			goto nodev_out;
		}
		else
		{
			printk(KERN_ERR "flashtool::Error probing flash device; Failed to install SPI flash driver\n");
			goto map_out;
			}
	}
#if 0	
	if(spi_flash_readinfo(&spi_flash_dev->flash_info))
	{
		printk("flashtool::Error getting device info! Failed to install NOR flash driver\n");
		goto map_out;
	}
#endif

	printk("flashtool::spi_flash driver initialized\n");
	printk("Device size in bytes: 0x%x\n", spi_flash_dev->flash_info.size_in_bytes);
	printk("Block size: 0x%x \n", spi_flash_dev->flash_info.blocksize);

	if(spi_flash_dev->flash_info.size_in_bytes > 64*1024*1024)
	{
		printk("Only supports flash up to 64M bytes now\n");
		goto map_out;
	}

	if(_build_memory_map(spi_flash_dev))
	{
		printk("Error building memory map\n");
		goto map_out;
	}

	if (!(sector_buffer = (u8 *)kzalloc(SECTOR_SIZE, GFP_KERNEL)))
	{
		printk("Error: Can not alloc buffer for SECTOR buffer \n");
		goto map_out;
	}
	SPI_PRINT("sector_buffer=0x%x\n",sector_buffer);
		
out:
	 return rev;
nodev_out:
 	iounmap((void *)INTEL_SPI_FLASH_CS0_BASE_VIRT);
 	iounmap((void *)INTEL_SPI_FLASH_CS1_BASE_VIRT);
	iounmap((void *)INTEL_SPI_FLASH_MBAR_BASE_VIRT);
	
	_cleanup_cdev();
	rev = -ENODEV;
	goto out;
map_out:
 	iounmap((void *)INTEL_SPI_FLASH_CS0_BASE_VIRT);
 	iounmap((void *)INTEL_SPI_FLASH_CS1_BASE_VIRT);	
	iounmap((void *)INTEL_SPI_FLASH_MBAR_BASE_VIRT);
cdev_fail:
	_cleanup_cdev();
	rev = -EIO;
	goto out;
}
static void __exit spi_flash_exit(void)
{
	kfree(sector_buffer);
	if (tmp_buffer)
		kfree(tmp_buffer);
	_cleanup_cdev();
	printk(KERN_INFO "spi_flash driver removed\n");
}

module_init(spi_flash_init);
module_exit(spi_flash_exit);

MODULE_DESCRIPTION("Intel(R) SPI Flash Device Driver");
MODULE_AUTHOR("Intel Corporation, (C) 2010 All Rights Reserved");
MODULE_LICENSE("GPL");

