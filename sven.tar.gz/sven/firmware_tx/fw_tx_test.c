/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include <sven_devh.h>

#ifndef SVEN_FW_GLOBALS_H
#include "sven_fw_globals.h"
#endif

#include <auto_eas/gen3_dfx.h>

/* gcc -m32 -g -Wall -I../../i686-linux-elf/include/ -I../../i686-linux-elf/include/linux_user/ sven_fw_io.c sven_fw_regio.c sven_fw_core.c fw_tx_test.c -o fw_tx_test -L ../../i686-linux-elf/lib/ -lsven -lpal -losal -lplatform_config -lpthread */

#include <stdio.h>

/* ================================================================= */
/* ================================================================= */
void sven_fw_attach(
   struct SVENHandle       *svenh,
   struct SVEN_FW_Globals  *fw_globals );

void sven_fw_write_event(
   struct SVENHandle       *svenh,
   struct SVENEvent        *ev );
/* ================================================================= */
/* ================================================================= */

struct SVEN_FW_Globals  g_sven_fw;
struct SVENHandle       g_svenh;

int main( int argc, char *argv[] )
{
   int                      err = 0;
   os_devhandle_t          *devh;

   /* Create a fake sven handle */
   if ( NULL != (devh = devhandle_factory(NULL)) )
   {
      if ( devhandle_connect_name( devh, "DFX" ) )
      {
         int                      i,n;
         unsigned char           *regs;
         struct SVENHandle       *svenh;
         struct SVEN_FW_Globals  *fw_globals;

         struct SVENEvent         ev;

         svenh = &g_svenh;
         fw_globals = &g_sven_fw;

         /* Initialize Globals */
      #ifdef INITIALIZE_FW_SVEN_TX_WITH_PHYS_ADDR
         fw_globals->en                = devh->devh_svenh.hdr->buffers[0].svc_physaddr;
         fw_globals->eventbuf_size     = devh->devh_svenh.hdr->buffers[0].svc_size;
         regs                          = (unsigned char *) devh->devh_regs_phys_addr;
      #else
         fw_globals->en                = devh->devh_svenh.en;
         fw_globals->eventbuf_size     = devh->devh_svenh.hdr->buffers[0].svc_size;
         regs                          = (unsigned char *) devh->devh_regs_ptr;
      #endif

         fw_globals->sven_dfx_hot      = (volatile unsigned int *)(regs + ROFF_DFX_DBG_SCRATCH);
         fw_globals->sven_dfx_time     = (volatile unsigned int *)(regs + ROFF_DFX_DBG_TIMESTAMP);
         fw_globals->sven_dfx_inc_tx   = (volatile unsigned int *)(regs + ROFF_DFX_DBG_COUNT_INC);
         fw_globals->sven_dfx_cur_tx   = (volatile unsigned int *)(regs + ROFF_DFX_DBG_COUNT_GET);

         sven_fw_attach( svenh, fw_globals );

         n = 0x26;

         for( i = 0; i < n; i++ )
         {
            ev.se_et.et_module   = -1;
            ev.se_et.et_unit     = -1;
            ev.se_et.et_type     = SVEN_event_type_module_specific;
            ev.se_et.et_subtype  = SVEN_EV_RegIo32_Read;
            ev.u.se_uint[0]      = 0xabad0000 | i;
            ev.u.se_uint[1]      = 0xf00d0000 | i;
            ev.u.se_uint[2]      = 0xcafe0000 | i;
            ev.u.se_uint[3]      = 0xbabe0000 | i;
            ev.u.se_uint[4]      = 0xfeed0000 | i;
            ev.u.se_uint[5]      = 0xbaca0000 | i;

            sven_fw_write_event( svenh, &ev );
         }
      }
      else
      {
         printf("ERR: Cannot devhandle_connect_name( devh, \"DFX\" )\n");
      }

      devh_Delete(devh);
   }
   else
   {
      printf("ERR: Cannot devhandle_factory()\n");
   }

   return(err);
}
