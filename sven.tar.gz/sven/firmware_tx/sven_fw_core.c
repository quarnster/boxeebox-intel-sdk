/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef SVEN_FW_H
#include "sven_fw.h"
#endif

/* ------------------------------------------------------------------------------------ */
/* ------------------------------------------------------------------------------------ */
   
/* get current timestamp */
unsigned int sven_fw_get_timestamp(
   struct SVENHandle    *svenh )
{
   return( sven_fw_read_external_register( svenh, svenh->ptime ) );
}

void sven_fw_attach(
   struct SVENHandle             *svenh,
   const struct SVEN_FW_Globals  *fw_globals )
{
   int                     siz;

   siz = fw_globals->eventbuf_size;

   svenh->buffnum          = 0;
   svenh->hdr              = (void *)0;
   svenh->en               = fw_globals->en;
   svenh->event_pos_mask   = (siz >> SVEN_EVENT_SIZE_BITS) - 1;

   /* Set up DFX Pointers */
   svenh->pcur             = fw_globals->sven_dfx_cur_tx;
   svenh->pinc             = fw_globals->sven_dfx_inc_tx;
   svenh->phot             = fw_globals->sven_dfx_hot;
   svenh->ptime            = fw_globals->sven_dfx_time;

   /* calculate event position LSB based on the buffer size
   * this will be used for sanity checking while logging apps
   * or other event stream readers are trying to keep up
   * with the data being written.  Used cheifly by.
   * _sven_write_new_event() to set the event_tag.et_gencount
   */
   svenh->event_pos_lsb = 0;
   while ( (siz >> SVEN_EVENT_SIZE_BITS) > 1)
   {
      svenh->event_pos_lsb++;
      siz >>= 1;
   }
}

static __inline int _sven_fw_is_tx_enabled(
   struct SVENHandle       *svenh )
{
   int                     hot_bits;
   int                     event_flags;

   /* if any of these bits are set FW WILL NOT transmit SVEN Events */

   /* TODO: WARNING: Pat believes the logic of the "hot" register in the DFX Assist unit
    * is reversed, tna that a "production fused part" will actually have a read-only 
    * 0xffffffff value for hot, in which case this logic needs reversed
    */
    event_flags = ( SVENHeader_DISABLE_MODULE |
                    SVENHeader_DISABLE_FW |
                    SVENHeader_DISABLE_ANY );

    hot_bits = sven_fw_read_external_register( svenh, svenh->phot );
    
    if ( event_flags & hot_bits)
    {
      return(0);
    }

    return(1);
}

int sven_fw_is_tx_enabled(
   struct SVENHandle       *svenh )
{
   return(_sven_fw_is_tx_enabled(svenh));
}

/** Write an Event into the Nexus:
 * NOTE: your event "timestamp" and "tag" will be overwritten.
 */
void sven_fw_write_event(
   struct SVENHandle       *svenh,
   struct SVENEvent        *ev )
{
   struct SVENEvent        *to;
   unsigned int             epos;

   /* Gat on hot enable */
    if ( ! sven_fw_is_tx_enabled(svenh) )
        return;

   /* Reserve an event "slot" by reading an external register */
#ifndef SELF_TEST
   epos = sven_fw_read_external_register( svenh, svenh->pinc );
#else
   epos = (*svenh->pinc)++;
#endif
   
   /* Event to write TO */
   to = &svenh->en[ epos & svenh->event_pos_mask ];

   /* MUST Overwrite et_gencount to maintain proper synchronization with downstream clients */
   ev->se_et.et_gencount = epos >> svenh->event_pos_lsb;

   /* Grab a hardware timestamp just before TX */
   ev->se_timestamp = sven_fw_read_external_register( svenh, svenh->ptime );
   
   sven_fw_copy_event_to_host_mem( svenh, to, ev );
}

#ifdef SELF_TEST

/* gcc -g -Wall -I../../i686-linux-elf/include/ -DSELF_TEST sven_fw_io.c sven_fw_core.c -o sven_fw */

#include <stdio.h>

#define SVEN_SELF_TEST_EVENT_SIZE   16

struct SVEN_FW_Globals  g_sven_fw;
struct SVENHandle       g_svenh;
struct SVENEvent        g_sven_ev[ SVEN_SELF_TEST_EVENT_SIZE ];

unsigned int            fake_dfx_time;
unsigned int            fake_dfx_inc;
unsigned int            fake_dfx_cur;
unsigned int            fake_dfx_hot;


static void dump_mem( const void *buf, unsigned int size )
{
   unsigned int         off;

   for ( off = 0; off < size; off += 4 )
   {
      if ( 0 == (off & 0x1f) )
      {
         printf("\n0x%08x: ", off );
      }
      printf("%08x ", ((unsigned int *)buf)[ off >> 2 ] );
   }
   printf("\n");
}


int main( int argc, char *argv[] )
{
   int                      err = 0;
   int                      i,n;
   struct SVENHandle       *svenh;
   struct SVEN_FW_Globals  *fw_globals;
   struct SVENEvent         ev;

   /* Create a fake sven handle */
   svenh = &g_svenh;
   fw_globals = &g_sven_fw;

   /* Initialize Globals */
   fw_globals->en                = g_sven_ev;
   fw_globals->eventbuf_size     = sizeof(g_sven_ev);
   fw_globals->sven_dfx_time     = &fake_dfx_time;
   fw_globals->sven_dfx_inc_tx   = &fake_dfx_inc;
   fw_globals->sven_dfx_cur_tx   = &fake_dfx_cur;
   fw_globals->sven_dfx_hot      = &fake_dfx_hot;
   
   sven_fw_attach( svenh, fw_globals );

   n = 0x26;

   for( i = 0; i < n; i++ )
   {
      ev.se_et.et_module   = -1;
      ev.se_et.et_unit     = -1;
      ev.se_et.et_type     = SVEN_event_type_register_io;
      ev.se_et.et_subtype  = SVEN_EV_RegIo32_Read;
      ev.u.se_uint[0]      = 0xabad0000 | i;
      ev.u.se_uint[1]      = 0xf00d0000 | i;
      ev.u.se_uint[2]      = 0xcafe0000 | i;
      ev.u.se_uint[3]      = 0xbabe0000 | i;
      ev.u.se_uint[4]      = 0xfeed0000 | i;
      ev.u.se_uint[5]      = 0xbaca0000 | i;

      sven_fw_write_event( svenh, &ev );
   }

   dump_mem( g_sven_ev, sizeof(g_sven_ev) );

   return(err);
}

#endif
