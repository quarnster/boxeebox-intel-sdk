/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef SVEN_H
#include "sven.h"
#endif

#ifndef __KERNEL__
    #include <stdarg.h>
    #include <string.h>
    #include <sys/mman.h>
    #include <fcntl.h>
    #include <stdlib.h>
    #include <unistd.h>
    #include <stdio.h>

    #ifdef TGT_SVOS
    #define _SVEN_SVOS_ 1
    #endif

    #ifdef _SVEN_SVOS_
    #include <sv/svlib.h>
    #endif

    #include <sys/ipc.h>
    #include <sys/shm.h>
#else
extern int g_sven_num_bufs;    /* kernel mode driver only */
#endif
    
/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */
extern int sven_init_dfx_support( 
   struct _SVENHeader    *hdr );
/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */

#define SVEN_SHARED_BLOCK_TOTAL_SIZE    ((4*1024)+(256*1024))

/**
 * @brief         Initialize a sven header pool for first use.
 *
 * @param         hdr                   : struct _SVENHeader to initialize
 * @param         sven_mempool_size     : TOTAL pool size (HEADER_SIZE + CIRCBUF_SIZE)
 * @param         sven_header_physaddr  : Physical address of header.
 * @param         sven_circbuf_physaddr : Physical address of circular buffer, or zero
 *                                        if the circular buffer is physically contiguous
 *                                        with the header (on silicon they are different)
 *
 * @note
 *  Do not call this function unless you _know_ you are the
 *  first entrant into the pool.  sven_open_header() automatically
 *  performs the correct checking and may or may not call this
 *  routine on the header.
 * 
 * @note In @b Virtual @b memory, the header and circbuffers @b are @b contiguous
 * @code
 *  +-----+---------------------+----------+----------+
 *  | hdr | circbuffer 0        | circ 1   | circ 2   |
 *  +-----+---------------------+----------+----------+
 * @endcode
 * 
 * @note In @b Physical @b memory, the header and circbuffers @b are @b not contiguous
 * @code
 *  +-----+
 *  | hdr | - single PAGE_SIZE
 *  +-----+
 *    circbuffer must be some power_of_two kbytes
 *  +---------------------+----------+----------+
 *  | circbuffer 0        | circ 1   | circ 2   |
 *  +---------------------+----------+----------+
 * @endcode
 *
 */
void sven_header_initialize(
	struct _SVENHeader		*hdr,
    int                      sven_mempool_size,
    unsigned int             sven_header_physaddr,
    unsigned int             sven_circbuf_physaddr )
{
   int             circbuffer_size;
   int             os_page_size = (4*1024);	/* TODO: add page size */

   circbuffer_size = sven_mempool_size - os_page_size;

   /* clear out LSBs to make this a clean power of two */
   while ( circbuffer_size & (circbuffer_size-1) )
      circbuffer_size &= ~(circbuffer_size-1);

   hdr->svh_version            = SVENHeader_VERSION_2;
   hdr->svh_disable_mask_deprecated = 0;
   hdr->svh_debug_flags        = 0;
   hdr->svh_hdr_physaddr       = sven_header_physaddr;
   hdr->svh_hdr_size           = (4*1024);

   if ( sven_circbuf_physaddr )
   {
      /* Circular buffer has different physical address
      * (doesn't immediately follow the header in phys mem)
      */
      hdr->svh_buff_physaddr  = sven_circbuf_physaddr;
   }
   else
   {
      hdr->svh_buff_physaddr  = hdr->svh_hdr_physaddr + hdr->svh_hdr_size;
   }

   hdr->svh_buff_size          = sven_mempool_size - hdr->svh_hdr_size;

#if ( SVEN_CIRCBUFFER_ID_CPU_KERNEL != SVEN_CIRCBUFFER_ID_CPU_USER )
  #ifdef __KERNEL__
    if ( 4 == g_sven_num_bufs )
    {
        /* ARM Build has Kernel and User memory spills
        *  +-----+
        *  | hdr | - single PAGE_SIZE
        *  +-----+
        *    circbuffer is some power_of_two kbytes
        *  +----------+---------+----------+-----------+
        *  | circ 0   | circ 1  | circ 2   | circ 3    |
        *  +----------+---------+----------+-----------+
        *
        */
        /* initialise first buffer with 1/4 the memory pool */
        hdr->buffers[0].svc_physaddr = hdr->svh_buff_physaddr;
        hdr->buffers[0].svc_size = circbuffer_size >> 2;
        hdr->buffers[0].svc_pos = 0;
        hdr->buffers[0].svc_id = 0;
        
        /* initialise second buffer with 1/4 the memory pool */
        hdr->buffers[1].svc_physaddr = 
                hdr->buffers[0].svc_physaddr +
                hdr->buffers[0].svc_size;
        hdr->buffers[1].svc_size = circbuffer_size >> 2;
        hdr->buffers[1].svc_pos = 0;
        hdr->buffers[1].svc_id = 1;
        
        /* initialise third buffer with 1/4 the memory pool */
        hdr->buffers[2].svc_physaddr = 
                hdr->buffers[1].svc_physaddr +
                hdr->buffers[1].svc_size;
        hdr->buffers[2].svc_size = circbuffer_size >> 2;
        hdr->buffers[2].svc_pos = 0;
        hdr->buffers[2].svc_id = 2;
        
        /* initialise fourth buffer with 1/4 the memory pool */
        hdr->buffers[3].svc_physaddr = 
                hdr->buffers[2].svc_physaddr +
                hdr->buffers[2].svc_size;
        hdr->buffers[3].svc_size = circbuffer_size >> 2;
        hdr->buffers[3].svc_pos = 0;
        hdr->buffers[3].svc_id = 3;
        
        /* Number of circular buffers described */
        hdr->svh_circbuffer_count   = 4;
    }
    else
  #endif
    {
        /* ARM Memory Split without firmware positions
        *  +-----+
        *  | hdr | - single PAGE_SIZE
        *  +-----+
        *    circbuffer is some power_of_two kbytes
        *  +---------------------+---------------------+
        *  | circbuffer kernel   | circbuf user-mode   |
        *  +---------------------+---------------------+
        *
        */
        /* initialise first buffer with 1/4 the memory pool */
        hdr->buffers[0].svc_physaddr = hdr->svh_buff_physaddr;
        hdr->buffers[0].svc_size = circbuffer_size >>1;
        hdr->buffers[0].svc_pos = 0;
        hdr->buffers[0].svc_id = 0;
    
        /* initialise second buffer with 1/4 the memory pool */
        hdr->buffers[1].svc_physaddr = 
                hdr->buffers[0].svc_physaddr +
                hdr->buffers[0].svc_size;
        hdr->buffers[1].svc_size = circbuffer_size >>1;
        hdr->buffers[1].svc_pos = 0;
        hdr->buffers[1].svc_id = 1;
        
        /* Number of circular buffers described */
        hdr->svh_circbuffer_count   = 2;
    }
#else
    /* i386, all others have a SINGLE Memory Pool
     *  +-----+
     *  | hdr | - single PAGE_SIZE
     *  +-----+
     *    circbuffer is some power_of_two kbytes
     *  +-------------------------------------------+
     *  | circbuffer 0                              |
     *  +-------------------------------------------+
     *
     */
    /* initialise first buffer with half the memory pool */
    hdr->buffers[0].svc_physaddr = hdr->svh_buff_physaddr;
    hdr->buffers[0].svc_size = circbuffer_size;
    hdr->buffers[0].svc_pos = 0;
    hdr->buffers[0].svc_id = 0;

    /* Number of circular buffers described */
    hdr->svh_circbuffer_count   = 1;
#endif
}

#ifndef __KERNEL__
static struct _SVENHeader	*g_sven_hdr;
static void                *g_sven_circbuf;

#include "platform_config.h"
#include "platform_config_paths.h"
#include "osal_memmap.h"

static struct _SVENHeader * sven_connect_platform_config()
{
   if ( (void *)0 == g_sven_hdr )
   {
      int fd;
      unsigned int	sven_hdr_pa = 0;
      unsigned int	sven_hdr_size = 0;
      unsigned int	sven_circbuf_pa = 0;
      unsigned int	sven_circbuf_size = 0;

      /* open the sven driver to ensure it has initialized the area */
      fd = open("/proc/sven", O_RDWR);
      if(fd < 0)
      {
         //perror("cannot open /proc/sven");
         return NULL;
      }

      config_get_int( 0, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".sven_hdr.base", (int *) &sven_hdr_pa );
      config_get_int( 0, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".sven_hdr.size", (int *) &sven_hdr_size );
      config_get_int( 0, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".sven_buf.base", (int *) &sven_circbuf_pa );
      config_get_int( 0, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".sven_buf.size", (int *) &sven_circbuf_size );

      //printf("SVEN_PLATFORM_CONFIG: %s\n", CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".sven_hdr" );
      //printf("SVEN_PLATFORM_CONFIG: %s\n", CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".sven_buf" );
      //printf("SVEN_PLATFORM_CONFIG: %08x %08x %08x %08x\n", sven_hdr_pa, sven_hdr_size, sven_circbuf_pa, sven_circbuf_size );
		
      if ( (0 != sven_hdr_pa) && (0 != sven_circbuf_pa) )
      {
         #if defined(__i386__) || defined(__x86_64__)
         g_sven_circbuf = OS_MAP_IO_TO_MEM_NOCACHE( sven_circbuf_pa, sven_circbuf_size );
         #else
         g_sven_circbuf = OS_MAP_IO_TO_MEM_NOCACHE( sven_circbuf_pa, sven_circbuf_size );
         #endif

         if ( (void *)0 != g_sven_circbuf )
         {
            /* MAP the regions into memory, HEADER (first 4k MUST BE NON_CACHABLE) */
            #if defined(__i386__) || defined(__x86_64__)
            g_sven_hdr = (struct _SVENHeader *) OS_MAP_IO_TO_MEM_NOCACHE(
            sven_hdr_pa, sven_hdr_size );
            #else
            g_sven_hdr = (struct _SVENHeader *) OS_MAP_IO_TO_MEM_NOCACHE(
            sven_hdr_pa, sven_hdr_size );
            #endif

            if ( (void *)0 != g_sven_hdr )
            {
            }
         }
      }

      close(fd);
   }
   return ( g_sven_hdr );
}

static struct _SVENHeader * sven_connect_to_smd_kernel_driver()
{
    if ( (void *)0 == g_sven_hdr )
    {
	    int fd;
	    unsigned long length = 0;
	    struct _SVENHeader *hdr = NULL;

	    fd = open("/proc/sven", O_RDWR);
	    if(fd < 0)
		    return NULL;
	    //first, just map the header so we can determine to proper size
	    hdr = mmap(NULL, getpagesize() , PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	    if(hdr == MAP_FAILED){
		    printf("cannot map /proc/sven");
		    close(fd);
		    return NULL;
	    }
	    length = hdr->svh_hdr_size + hdr->svh_buff_size;
	    // we know the full size, so map the whole thing 
	    munmap(hdr, getpagesize());

	    hdr = mmap(NULL, length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	    if(hdr == MAP_FAILED){
		    printf("cannot map full /proc/sven event log");
		    close(fd);
		    return NULL;
	    }

//        printf("SVENHeader:PSD kernel driver loaded\n");
        g_sven_hdr = hdr;
        g_sven_circbuf = (char *)hdr + hdr->svh_hdr_size;
    }

	return ( g_sven_hdr );
}

struct _SVENHeader * sven_connect_to_kernel_driver()
{
   if ( (void *)0 == g_sven_hdr )
   {
	   int fd;
	   unsigned long length = 0;
	   struct _SVENHeader *hdr = NULL;

	   fd = open("/proc/svenlog", O_RDWR);
	   if(fd < 0)
		   return NULL;
	   //first, just map the header so we can determine to proper size
	   hdr = mmap(NULL, getpagesize() , PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	   if(hdr == MAP_FAILED){
		   perror("cannot map /proc/svenlog");
		   close(fd);
		   return NULL;
	   }
	   length = hdr->svh_hdr_size + hdr->svh_buff_size;
	   // we know the full size, so map the whole thing 
	   munmap(hdr, getpagesize());

	   hdr = mmap(NULL, length, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
	   if(hdr == MAP_FAILED){
		   perror("cannot map full /proc/svenlog event log");
		   close(fd);
		   return NULL;
	   }

      g_sven_hdr = hdr;
      g_sven_circbuf = (char *)hdr + hdr->svh_hdr_size;
   }

	return g_sven_hdr;
}

#ifdef _SVEN_SVOS_
/** Physical address to map to to share SVEN Memory */
struct SVEN_SVOS_Location
{
    uint64_t    sven_hdr_PhysAddr;
};
#define SVEN_SVOS_LOCATION_SIZE (4*1024)

static struct SVEN_SVOS_Location  *g_sven_svos_shm_loc;
static int                         g_sven_svos_shm_id = -1;

struct SVEN_SVOS_Location *sven_svos_find_location()
{
    struct SVEN_SVOS_Location  *loc = NULL;

    if ( -1 == g_sven_svos_shm_id )
    {
        g_sven_svos_shm_id = shmget( ftok("/tmp/sven2.loc",'v' ),
            SVEN_SVOS_LOCATION_SIZE,
            IPC_CREAT | 0777 );

        if ( g_sven_svos_shm_id < 0 )
            g_sven_svos_shm_id = -2;    /* do not try again */
    }

    if ( g_sven_svos_shm_id >= 0 )
    {
        if ( NULL == (loc = g_sven_svos_shm_loc) )
        {
            loc = (struct SVEN_SVOS_Location *) shmat( g_sven_svos_shm_id, 0, 0 );
            if ( loc != (struct SVEN_SVOS_Location *)-1 )
            {
                struct shmid_ds ds;

                if ( ! shmctl( g_sven_svos_shm_id, IPC_STAT, &ds ) )
                {
                    if ( 1 == ds.shm_nattch )   /* We're the only one connected? */
                    {
                        loc->sven_hdr_PhysAddr = SVanyPhysicalAddress;
                    }
                }

                g_sven_svos_shm_loc = loc;
            }
            else
            {
                g_sven_svos_shm_loc = NULL;
            }
        }
    }

    return( g_sven_svos_shm_loc );
}

static struct _SVENHeader  *g_sven_svos_hdr;
static int      g_sven_svos_MemAttr;	/* Attributes allocated */
static int		g_sven_svos_MemSize;	/* page aligned number of bytes allocated */
static void	   *g_sven_svos_MemTarget;	/* SV Handle thing */
static void	   *g_sven_svos_ptr;		/* Virtual Address */
static uint64_t g_sven_svos_PhyAddr;	/* Physical address of buffer (from DUT) */

void sven_disconnect_svos_targetmemory()
{
    releaseMemoryTarget( g_sven_svos_MemTarget );
}

struct _SVENHeader * sven_connect_svos_targetmemory(
    struct SVEN_SVOS_Location       *loc )
{
	struct _SVENHeader *hdr = NULL;

    if ( NULL == (hdr = g_sven_svos_hdr) )
    {
        svErrorStatus				 svResult;

		//g_sven_svos_MemAttr = SVuncachableMemory | ( SVreadMapping | SVwriteMapping | SVexecMapping ) | SVsharedMapping ;//memory attribute
		g_sven_svos_MemAttr = ( SVreadMapping | SVwriteMapping | SVexecMapping ) | SVsharedMapping ;//memory attribute
		g_sven_svos_ptr     = SVanyVirtualAddress;

        if ( loc && loc->sven_hdr_PhysAddr )
    		g_sven_svos_PhyAddr = loc->sven_hdr_PhysAddr;
        else
	    	g_sven_svos_PhyAddr = SVanyPhysicalAddress;

		g_sven_svos_MemSize = SVEN_SHARED_BLOCK_TOTAL_SIZE;

		svResult = getMemoryTarget(
            g_sven_svos_MemAttr,
            &g_sven_svos_MemTarget,
            &g_sven_svos_MemSize,
            &g_sven_svos_ptr,
            &g_sven_svos_PhyAddr );

		if ( SVLIB_SUCCESS == svResult )
		{
            g_sven_svos_hdr = hdr = (struct _SVENHeader *) g_sven_svos_ptr;

            if ( SVENHeader_VERSION_2 != hdr->svh_version )
            {
                if ( loc )
                {
                    loc->sven_hdr_PhysAddr = g_sven_svos_PhyAddr;
                }

                /* Initialize the header, physically contiguous */
                sven_header_initialize( hdr,
                    g_sven_svos_MemSize,
                    g_sven_svos_PhyAddr, 0 );
            } else if(loc && !loc->sven_hdr_PhysAddr) {
                loc->sven_hdr_PhysAddr = g_sven_svos_PhyAddr;
            }

            g_sven_circbuf = (char *)hdr + hdr->svh_hdr_size;
        }
    }

	return hdr;
}
#endif

static struct _SVENHeader  *g_sven_shm_hdr;
static int                  g_sven_shm_id = -1;

struct _SVENHeader * sven_connect_to_shared_mem()
{
    struct _SVENHeader  *hdr = NULL;

    if ( -1 == g_sven_shm_id )
    {
        g_sven_shm_id = shmget( ftok("/tmp/sven2.mem",'v' ),
            SVEN_SHARED_BLOCK_TOTAL_SIZE,
            IPC_CREAT | 0777 );

        if ( g_sven_shm_id < 0 )
            g_sven_shm_id = -2;    /* do not try again */
    }

    if ( g_sven_shm_id >= 0 )
    {
        if ( NULL == (hdr = g_sven_shm_hdr) )
        {
            hdr = (struct _SVENHeader *) shmat( g_sven_shm_id, 0, 0 );
            if ( hdr != (struct _SVENHeader *)-1 )
            {
                g_sven_shm_hdr = hdr;

                if ( SVENHeader_VERSION_2 != hdr->svh_version )
                {
                    sven_header_initialize( hdr, SVEN_SHARED_BLOCK_TOTAL_SIZE, 0, 0 );
                }

                g_sven_circbuf = (char *)hdr + hdr->svh_hdr_size;
            }
            else
            {
                hdr = NULL;
            }
        }
    }

    return( hdr );
}

/**
 * @brief        Gain access to the System-Visible-Event-Nexus Event Buffer area
 *
 * @returns     (struct _SVENHeader *) or NULL if unsuccessful
 *
 */
void *sven_get_event_buf()
{
    return( g_sven_circbuf );
}

/**
 * @brief        Gain access to the System-Visible-Event-Nexus
 *
 * @returns     (struct _SVENHeader *) or NULL if unsuccessful
 *
 */
struct _SVENHeader *sven_open_header()
{
    struct _SVENHeader  *hdr;

    if ( NULL == (hdr = g_sven_hdr) )
    {
   #ifdef _SVEN_SVOS_
       struct SVEN_SVOS_Location   *svenloc;

       svenloc = sven_svos_find_location();

       if ( NULL != (hdr = sven_connect_svos_targetmemory(svenloc)) )
       {
   //printf("SVENHeader:SVOS Target Memory\n");
       }
       else if ( NULL != (hdr = sven_connect_to_kernel_driver()) )
       {
   //printf("SVENHeader:kernel driver loaded (SVOS)\n");
       }
       else if ( NULL != (hdr = sven_connect_to_shared_mem()) )
       {
   //printf("SVENHeader:Shared Memory Created (SVOS)\n");
       }
       else if ( NULL != (hdr = (struct _SVENHeader *) malloc(SVEN_SHARED_BLOCK_TOTAL_SIZE)) )
       {
           /* Initialize the header, physically contiguous */
           sven_header_initialize( hdr,
               SVEN_SHARED_BLOCK_TOTAL_SIZE,
               0, 0 );

           g_sven_circbuf = (char *)hdr + hdr->svh_hdr_size;
   printf("SVENHeader:malloc (SVOS)\n");
       }
   #else
   //printf("SVEN_INIT SVEN_INIT SVEN_INIT SVEN_INIT SVEN_INIT SVEN_INIT SVEN_INIT SVEN_INIT \n");    
       if ( NULL != (hdr = sven_connect_to_kernel_driver()) )
       {
   printf("SVENHeader @ sven_connect_to_kernel_driver\n");
       }
       else if ( NULL != (hdr = sven_connect_to_smd_kernel_driver()) )
       {
   //printf("SVENHeader @ sven_connect_to_smd_kernel_driver\n");
       }
       else if ( NULL != (hdr = sven_connect_platform_config()) )
       {
   printf("SVENHeader @ sven_connect_platform_config\n");
       }
       #ifndef __CYGWIN__
       else if ( NULL != (hdr = sven_connect_to_shared_mem()) )
       {
   printf("SVENHeader @ sven_connect_to_shared_mem\n");
       }
       #endif
       else if ( NULL != (hdr = (struct _SVENHeader *) malloc(SVEN_SHARED_BLOCK_TOTAL_SIZE)) )
       {
           /* Initialize the header, physically contiguous */
           sven_header_initialize( hdr,
               SVEN_SHARED_BLOCK_TOTAL_SIZE,
               0, 0 );

           g_sven_circbuf = (char *)hdr + hdr->svh_hdr_size;
   printf("SVENHeader @ malloc()\n");
       }
   #endif
      if ( NULL != hdr )
      {
         g_sven_hdr = hdr;
         sven_init_dfx_support(g_sven_hdr);
      }
   }

   return( hdr );
}

extern void sven_devh_usermode_lib_init( void );
extern void sven_devh_usermode_lib_deinit( void );

/* Shared code library initialization hacks */
__attribute__((constructor)) static void sven_usermode_lib_init(void)
{
   sven_devh_usermode_lib_init();
}

 __attribute__((destructor)) static void sven_usermode_lib_deinit(void)
{
   /* DO NOT CALL DEINIT: All memory will be freed for this process when it is torn down */
   sven_devh_usermode_lib_deinit();
}

#endif /* ! __KERNEL__ */
