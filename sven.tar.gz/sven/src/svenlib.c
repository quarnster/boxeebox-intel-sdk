/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef SVEN_H
#include "sven.h"
#endif


#ifdef __KERNEL__
   #include <stdarg.h>
   #include <linux/kernel.h> /* printk() */
#else /* !__KERNEL__ */
   #include <string.h>
   #include <stdarg.h>
   #include <sys/mman.h>
   #include <fcntl.h>
   #include <stdlib.h>
   #include <unistd.h>
   #include <stdio.h>
#endif /* !__KERNEL__ */

/* private function from sven_dfx.c */
extern void sven_handle_dfx_init(
   struct SVENHandle    *svenh,
   struct _SVENHeader   *hdr );

#if defined(__XSCALE__)
/* there is nothing as nice as a simple "rdtsc" for xscale userspace, so
   we get to use the OST timer register.  To get access to it requires mapping it into userspace */
#define OST_PAGE_ADDRESS (0xfffe0000)
#define OST_TIMESTAMP_OFFSET (0x180)

char * ost_map = 0;

static int map_ost_addr()
{
	int fd;
	fd = open("/dev/mem", O_RDONLY);
	if(fd < 0)
		return -1;
        ost_map = mmap(NULL, getpagesize() , PROT_READ, MAP_SHARED, fd, OST_PAGE_ADDRESS);
	close(fd);
        if(ost_map == MAP_FAILED){
                perror("cannot map OST register for timestamps");
                return -1;
        }
	return 0;
}

unsigned int sventimestamp()
{
	int fd;
	if(!ost_map){
		map_ost_addr();
	}
	if(ost_map == MAP_FAILED){
		return 0;
	}
	return *(volatile unsigned int *)(ost_map + OST_TIMESTAMP_OFFSET);
}

#endif

/* get current timestamp */
unsigned int sven_get_timestamp(void)
{
   return( sventimestamp() );
}

void sven_attach_handle_to_queue(
   struct SVENHandle    *svenh,
   struct _SVENHeader   *hdr,
   int                   queue_number )
{
	unsigned int     siz = hdr->buffers[queue_number].svc_size;
    int              i;
    char            *buf;

	svenh->buffnum          = queue_number;
	svenh->hdr              = hdr;
	svenh->event_pos_mask   = (hdr->buffers[svenh->buffnum].svc_size >> SVEN_EVENT_SIZE_BITS) - 1;

#ifdef _SVEN_FIRMWARE_
    /* Get a pointer to my event queue */
    buf = (char *) hdr;
    /* Note: This pointer manipulation trick prevents us from having to
     * use an ifdef when compiling for firmware.  While the host
     * computer sees the header and the buffer as "virtually" contiguous,
     * the header is not physically contiguous to the event buffer area.
     * so we "jump" by adding the difference between the physical memory
     * addresses.
     */
    buf += (hdr->svh_buff_physaddr - hdr->svh_hdr_physaddr);    /* jump to buffer */
#else
    // buf = (char *) hdr + hdr->svh_hdr_size;
    buf = sven_get_event_buf();
#endif
    /* roll forward to the new buffer */
    for ( i = 0; i < queue_number; i++ )
    {
        buf += hdr->buffers[i].svc_size;
    }
   	svenh->en = (struct SVENEvent *) buf;
    
    /* calculate event position LSB based on the buffer size
     * this will be used for sanity checking while logging apps
     * or other event stream readers are trying to keep up
     * with the data being written.  Used cheifly by.
     * _sven_write_new_event() to set the event_tag.et_gencount
     */
	svenh->event_pos_lsb = 0;
	while ( (siz >> SVEN_EVENT_SIZE_BITS) > 1)
	{
		svenh->event_pos_lsb++;
		siz >>= 1;
	}

   sven_handle_dfx_init(svenh,hdr);
}

#ifndef _SVEN_FIRMWARE_
/** @deprecated: Please use sven_attach_handle_to_queue() */
void sven_init_writer_handle(
	struct SVENHandle		*svenh,
	struct _SVENHeader		*hdr)
{
    sven_attach_handle_to_queue( svenh, hdr, 0 );
}

void sven_write_event(
	struct SVENHandle		*svenh,
	const struct SVENEvent	*ev )
{
    if ( NULL != svenh ) _sven_write_new_event( svenh, ev );
}

int sven_get_write_position(
	struct SVENHandle		*svenh )
{
	return( _sven_get_write_position(svenh) );
}

int sven_read_next_event(
	struct SVENHandle		*svenh,
	struct SVENEvent		*ev,
	int						*preader_pos )
{
	return( _sven_read_next_event(svenh,ev,preader_pos) );
}
#endif

void sven_WriteDebugString(
	struct SVENHandle		*svenh,
    int                      module,
    int                      unit,
    int                      debugstr_subtype,
    const char              *str )
{
    struct SVENEvent    ev;
    int                 i;

    /* Initialize the header */
    _sven_initialize_event_top( &ev,
        module, unit,
        SVEN_event_type_debug_string,
        debugstr_subtype );

    if ( NULL != str )
    {
        /* `strncpy' copies not more than LENGTH characters from the
        * the string pointed to by SRC (including the terminating null
        * character) to the array pointed to by DST.  If the string
        * pointed to by SRC is shorter than LENGTH characters, null
        * characters are appended to the destination array until a
        * total of LENGTH characters have been written.
        */
        for ( i = 0; i < SVEN_EVENT_PAYLOAD_NUM_CHARS; i++ )
        {
            if ( '\0' == (ev.u.se_dbg_str[i] = str[i]) )
                break;
        }
        while ( i < SVEN_EVENT_PAYLOAD_NUM_CHARS )
        {
            ev.u.se_dbg_str[i] = '\0';  i++;
        }
        /* force null term */
        ev.u.se_dbg_str[SVEN_EVENT_PAYLOAD_NUM_CHARS-1] = '\0';
   }
   else
   {
        for ( i = 0; i < SVEN_EVENT_PAYLOAD_NUM_CHARS; i++ )
        {
            ev.u.se_dbg_str[i] = '\0';
        }
        ev.u.se_dbg_str[0] = 'N';
        ev.u.se_dbg_str[1] = 'U';
        ev.u.se_dbg_str[2] = 'L';
        ev.u.se_dbg_str[3] = 'L';
   }
        
    _sven_write_new_event( svenh, &ev );
}

#ifndef _SVEN_FIRMWARE_
/**
 * sven_WriteDebugStringEnd() Ensures last "N" chars of debugstring are copied.
 *   Event Type will ALWAYS == SVEN_event_type_debug_string.
 *   Only 24 characters will fit inside a SVEN DebugString event.
 *   This function is usually called from SVEN_AUTO_TRACE().
 *
 * @param svenh            : SVEN Handle structure
 * @param module           : enum SVEN_Module (e.g. SVEN_module_VR_VCAP)
 * @param unit             : unit within the module (e.g. 0, 1, 2 .. )
 * @param subtype          : enum SVEN_DEBUGSTR_t (e.g. SVEN_DEBUGSTR_FunctionEntered)
 * @param str              : string to copy rightmost chars from
 */
void sven_WriteDebugStringEnd(
	struct SVENHandle		*svenh,
    int                      module,
    int                      unit,
    int                      subtype,
    const char              *str )
{
    struct SVENEvent    ev;
    const char         *cp;
    int                 len,i;

    /* Initialize the header */
    _sven_initialize_event_top( &ev,
        module, unit,
        SVEN_event_type_debug_string,
        subtype );

    if ( NULL != str )
    {
        /* basically strlen(str) */
        len = 0; while ( '\0' != str[len] ) { len++; }
    
        /* seek to the end if we have to */
        cp = str;
        if ( len >= SVEN_EVENT_PAYLOAD_NUM_CHARS )
        {
            cp += (len - SVEN_EVENT_PAYLOAD_NUM_CHARS + 1);
        }
    
        /* Copy the string */
        for ( i = 0; i < SVEN_EVENT_PAYLOAD_NUM_CHARS; i++ )
        {
            if ( '\0' == (ev.u.se_dbg_str[i] = cp[i]) )
                break;
        }
        while ( i < SVEN_EVENT_PAYLOAD_NUM_CHARS )
        {
            ev.u.se_dbg_str[i] = '\0';  i++;
        }
        /* force null term */
        ev.u.se_dbg_str[SVEN_EVENT_PAYLOAD_NUM_CHARS-1] = '\0';
    }
   else
   {
        for ( i = 0; i < SVEN_EVENT_PAYLOAD_NUM_CHARS; i++ )
        {
            ev.u.se_dbg_str[i] = '\0';
        }
        ev.u.se_dbg_str[0] = 'N';
        ev.u.se_dbg_str[1] = 'U';
        ev.u.se_dbg_str[2] = 'L';
        ev.u.se_dbg_str[3] = 'L';
   }
    
    _sven_write_new_event( svenh, &ev );
}
#endif /* ! _SVEN_FIRMWARE_ */

#ifndef _SVEN_FIRMWARE_
void sven_WriteEvent_ulongs(
	struct SVENHandle		*svenh,
    int                      module,
    int                      unit,
    int                      event_type,
    int                      event_subtype,
    int                      event_num_ulongs,
    unsigned long           *pulongs )
{
    int                 i;
    struct SVENEvent    ev;

    /* Initialize the header */
    _sven_initialize_event_top( &ev, module, unit, event_type, event_subtype );
    
    if ( (event_num_ulongs > SVEN_EVENT_PAYLOAD_NUM_ULONGS) ||
         (event_num_ulongs < 0) )
    {
        event_num_ulongs = SVEN_EVENT_PAYLOAD_NUM_ULONGS;

        sven_WriteDebugString( svenh, module, unit,
            SVEN_DEBUGSTR_InvalidParam, "sven_WriteEvent_ulong" );
    }

    for ( i = 0; i < event_num_ulongs; i++ )
    {
        ev.u.se_ulong[i] = pulongs[i];
    }

    /* Complete with zeroes */
    while ( i < SVEN_EVENT_PAYLOAD_NUM_ULONGS )
    {
        ev.u.se_ulong[i++] = 0;
    }

    _sven_write_new_event( svenh, &ev );
}
    
void sven_WriteEventVA_ulong(
	struct SVENHandle		*svenh,
    int                      module,
    int                      unit,
    int                      event_type,
    int                      event_subtype,
    int                      event_num_ulongs,
    ... )
{
    int                 i;
    va_list             ap;
    struct SVENEvent    ev;

    /* Initialize the header */
    _sven_initialize_event_top( &ev, module, unit, event_type, event_subtype );
    
    va_start( ap, event_num_ulongs );

    if ( (event_num_ulongs > SVEN_EVENT_PAYLOAD_NUM_ULONGS) ||
         (event_num_ulongs < 0) )
    {
        event_num_ulongs = SVEN_EVENT_PAYLOAD_NUM_ULONGS;

        sven_WriteDebugString( svenh, module, unit,
            SVEN_DEBUGSTR_InvalidParam, "sven_WriteEventVA_ulong" );
    }

    for ( i = 0; i < event_num_ulongs; i++ )
    {
        ev.u.se_ulong[i] = va_arg(ap, unsigned long );
    }
    va_end( ap );

    /* Complete with zeroes */
    while ( i < SVEN_EVENT_PAYLOAD_NUM_ULONGS )
    {
        ev.u.se_ulong[i++] = 0;
    }

    _sven_write_new_event( svenh, &ev );
}
#endif
