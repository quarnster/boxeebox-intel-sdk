/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2005-2011 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef SVEN_H
#include "sven.h"
#endif

#ifndef SVEN_RBD_LOOKUP
#include "rbd_lookup.h"
#endif

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef NULL
#define NULL ((void *)0)
#endif

#include "svenreverse.h"

/* ------------------------------------------------------- */
extern const struct ModuleReverseDefs *svenreverse_GetModuleTables(
	enum SVEN_Module			module );
/* ------------------------------------------------------- */

const struct EventTypeReverse*  svenreverse_EVENT_TABLES_BY_NAME(
    const char                  *event_name );

/*const struct EventSubtypeReverse* svenreverse_sub_event_table(
	struct EventTypeReverse *event, const char *sub_event_name);*/

/** Generic "reverse engineering" handle for decoding SVEN Events.
 *	Internal structure for svenreverse.c
 */
struct SVENReverser
{
	struct _SVENHeader			*hdr;	/* struct in Shared Memory */
};

/* Internal Structures */
/* ------------------------------------------------------- */
/** "reverse engineering" _subtype_ for decoding SVEN Events.
 *	Internal structure for svenreverse.c
 */

/** "reverse engineering" _type_ for decoding SVEN Events.
 *	Internal structure for svenreverse.c
 */



/* Internal Tables */
/* ------------------------------------------------------- */


static const struct EventSubtypeReverse g_event_trigger_reverse[] =
{
	{ NULL, SVEN_EV_trigger_invalid, "invalid"	, NULL },
	{ NULL, SVEN_EV_trigger_alarm, "alarm"	, NULL },
	{ NULL, 0, NULL, NULL } /* End-Of-Table */
};

static const struct EventSubtypeReverse g_event_debugstring_reverse[] =
{
	{ NULL, SVEN_DEBUGSTR_invalid,         "invalid" , NULL },
	{ NULL, SVEN_DEBUGSTR_Generic,         "log"	, NULL },
	{ NULL, SVEN_DEBUGSTR_FunctionEntered, "FuncEnter" , NULL },
	{ NULL, SVEN_DEBUGSTR_FunctionExited,  "FuncExit" , NULL },
	{ NULL, SVEN_DEBUGSTR_AutoTrace,       "AutoTrace" , NULL },
	{ NULL, SVEN_DEBUGSTR_InvalidParam,    "FuncInvalidParam" , NULL },
	{ NULL, SVEN_DEBUGSTR_Checkpoint,      "Checkpoint" , NULL },
	{ NULL, SVEN_DEBUGSTR_Assert,          "AssertFail" , NULL },
	{ NULL, SVEN_DEBUGSTR_Warning,         "Warning" , NULL },
	{ NULL, SVEN_DEBUGSTR_FatalError,      "FatalError" , NULL },
	{ NULL, SVEN_DEBUGSTR_PresTiming,      "PresTiming" , NULL },
	{ NULL, 0, NULL, NULL } /* End-Of-Table */
};

static const struct EventSubtypeReverse g_event_register_io_reverse[] =
{
	{ NULL, SVEN_EV_RegIo_invalid, "invalid" , NULL },
	{ NULL, SVEN_EV_RegIo32_Read, "Read32" , NULL },
	{ NULL, SVEN_EV_RegIo32_Write, "Write32" , NULL },
	{ NULL, SVEN_EV_RegIo32_OrBits, "OrBits32" , NULL },
	{ NULL, SVEN_EV_RegIo32_AndBits, "AndBits32" , NULL },
	{ NULL, SVEN_EV_RegIo32_SetMasked, "SetMasked32" , NULL },
	{ NULL, SVEN_EV_RegIo16_Read, "Read16" , NULL },
	{ NULL, SVEN_EV_RegIo16_Write, "Write16" , NULL },
	{ NULL, SVEN_EV_RegIo16_OrBits, "OrBits16" , NULL },
	{ NULL, SVEN_EV_RegIo16_AndBits, "AndBits16" , NULL },
	{ NULL, SVEN_EV_RegIo16_SetMasked, "SetMasked16" , NULL },
	{ NULL, SVEN_EV_RegIo8_Read, "Read8" , NULL },
	{ NULL, SVEN_EV_RegIo8_Write, "Write8" , NULL },
	{ NULL, SVEN_EV_RegIo8_OrBits, "OrBits8" , NULL },
	{ NULL, SVEN_EV_RegIo8_AndBits, "AndBits8" , NULL },
	{ NULL, SVEN_EV_RegIo8_SetMasked, "SetMasked8" , NULL },
	{ NULL, SVEN_EV_RegIo64_Read, "Read64" , NULL },
	{ NULL, SVEN_EV_RegIo64_Write, "Write64" , NULL },
	{ NULL, SVEN_EV_RegIo64_OrBits, "OrBits64" , NULL },
	{ NULL, SVEN_EV_RegIo64_AndBits, "AndBits64" , NULL },
	{ NULL, SVEN_EV_RegIo64_SetMasked, "SetMasked64" , NULL },
	{ NULL, 0, NULL, NULL } /* End-Of-Table */
};
static const struct EventSubtypeReverse g_event_port_io_reverse[] =
{
	{ NULL, SVEN_EV_PortIo_invalid, "invalid" , NULL },
	{ NULL, SVEN_EV_PortIo32_Read,  "Read32" , NULL },
	{ NULL, SVEN_EV_PortIo32_Write, "Write32" , NULL },
	{ NULL, SVEN_EV_PortIo32_OrBits, "OrBits32" , NULL },
	{ NULL, SVEN_EV_PortIo32_AndBits, "AndBits32" , NULL },
	{ NULL, SVEN_EV_PortIo32_SetMasked, "SetMasked32" , NULL },
	{ NULL, SVEN_EV_PortIo16_Read, "Read16" , NULL },
	{ NULL, SVEN_EV_PortIo16_Write, "Write16" , NULL },
	{ NULL, SVEN_EV_PortIo16_OrBits, "OrBits16" , NULL },
	{ NULL, SVEN_EV_PortIo16_AndBits, "AndBits16" , NULL },
	{ NULL, SVEN_EV_PortIo16_SetMasked, "SetMasked16" , NULL },
	{ NULL, SVEN_EV_PortIo8_Read, "Read8" , NULL },
	{ NULL, SVEN_EV_PortIo8_Write, "Write8" , NULL },
	{ NULL, SVEN_EV_PortIo8_OrBits, "OrBits8" , NULL },
	{ NULL, SVEN_EV_PortIo8_AndBits, "AndBits8" , NULL },
	{ NULL, SVEN_EV_PortIo8_SetMasked, "SetMasked8" , NULL },
	{ NULL, 0, NULL, NULL } /* End-Of-Table */
};
static const struct EventSubtypeReverse g_event_module_isr_reverse[] =
{
	{ NULL, SVEN_EV_UnitIsr_invalid, "invalid" , NULL },
	{ NULL,	SVEN_EV_UnitIsr_Enter, "Enter" , NULL },
	{ NULL,	SVEN_EV_UnitIsr_Exit, "Exit" , NULL },
	{ NULL, 0, NULL, NULL } /* End-Of-Table */
};
static const struct EventSubtypeReverse g_event_os_isr_reverse[] =
{
	{ NULL, SVEN_EV_OSIsr_invalid, "invalid" , NULL },
	{ NULL,	SVEN_EV_OSIsr_Enter, "Enter" , NULL },
	{ NULL,	SVEN_EV_OSIsr_Exit, "Exit" , NULL },
	{ NULL, 0, NULL, NULL } /* End-Of-Table */
};
static const struct EventSubtypeReverse g_event_os_thread_reverse[] =
{
	{ NULL,	SVEN_EV_OS_Thread_invalid, "invalid" , NULL },
	{ NULL,	SVEN_EV_OS_Thread_Run, "Run" , NULL },
	{ NULL,	SVEN_EV_OS_Thread_Wait, "Wait" , NULL },
	{ NULL,	SVEN_EV_OS_Thread_Create, "Create" , NULL },
	{ NULL,	SVEN_EV_OS_Thread_Delete, "Delete" , NULL },
	{ NULL,	SVEN_EV_OS_Thread_Suspend, "Suspend" , NULL },
	{ NULL, 0, NULL, NULL } /* End-Of-Table */
};
static const struct EventSubtypeReverse g_event_smd_core_reverse[] =
{
	{ NULL,	SVEN_EV_SMDCore_invalid,        "invalid" , NULL },

    { NULL, SVEN_EV_SMDCore_Port_Alloc,     "Port_Alloc" , NULL },
    { NULL, SVEN_EV_SMDCore_Port_Free,      "Port_Free" , NULL },
    { NULL, SVEN_EV_SMDCore_Port_Connect,   "Port_Connect" , NULL },
    { NULL, SVEN_EV_SMDCore_Port_Disconnect,"Port_Disconnect" , NULL },
    { NULL, SVEN_EV_SMDCore_Port_SetName,   "Port_SetName" , NULL },

    { NULL, SVEN_EV_SMDCore_Queue_Alloc,    "Queue_Alloc" , NULL },
    { NULL, SVEN_EV_SMDCore_Queue_Free,     "Queue_Free" , NULL },
    { NULL, SVEN_EV_SMDCore_Queue_SetConfig,"Queue_SetConfig" , NULL },
    { NULL, SVEN_EV_SMDCore_Queue_Write,    "Queue_Write" , NULL },
    { NULL, SVEN_EV_SMDCore_Queue_Read,     "Queue_Read" , NULL },
    { NULL, SVEN_EV_SMDCore_Queue_Flush,    "Queue_Flush" , NULL },
    { NULL, SVEN_EV_SMDCore_Queue_WriteFail,"Queue_WriteFail" , NULL },
    { NULL, SVEN_EV_SMDCore_Queue_ReadFail, "Queue_ReadFail" , NULL },
    { NULL, SVEN_EV_SMDCore_Queue_Push,     "Queue_Push" , NULL },
    { NULL, SVEN_EV_SMDCore_Queue_Pull,     "Queue_Pull" , NULL },
    { NULL, SVEN_EV_SMDCore_Queue_SetName,  "Queue_SetName" , NULL },

    { NULL, SVEN_EV_SMDCore_Buf_Alloc,      "Buf_Alloc" , NULL },
    { NULL, SVEN_EV_SMDCore_Buf_Free,       "Buf_Free" , NULL },
    { NULL, SVEN_EV_SMDCore_Buf_AddRef,     "Buf_AddRef" , NULL },
    { NULL, SVEN_EV_SMDCore_Buf_DeRef,      "Buf_DeRef" , NULL },
    { NULL, SVEN_EV_SMDCore_Buf_Release,    "Buf_Release" , NULL },
    { NULL, SVEN_EV_SMDCore_Buf_fb_count,   "Buf_FB_count" , NULL },
    { NULL, SVEN_EV_SMDCore_Buf_Desc_Err,   "Buf_Desc_Err" , "Get buf descriptor error, buf %d, 0x%X" },
    { NULL, SVEN_EV_SMDCore_Buf_Unavail,    "Buf_Unavail", "type: %d size: %d"},

    { NULL, SVEN_EV_SMDCore_Clock_Alloc,    "Clock_Alloc" , NULL },
    { NULL, SVEN_EV_SMDCore_Clock_Free,     "Clock_Free" , NULL },
    { NULL, SVEN_EV_SMDCore_Clock_Status,   "Clock_Status" , NULL },
    { NULL, SVEN_EV_SMDCore_Clock_Get,      "Clock_Get" , NULL },
    { NULL, SVEN_EV_SMDCore_Clock_Set,      "Clock_Set" , NULL },
    { NULL, SVEN_EV_SMDCore_Clock_Adjust,   "Clock_Adjust" , NULL },
    { NULL, SVEN_EV_SMDCore_Clock_Set,      "Clock_LastTrigTime" , NULL },
    { NULL, SVEN_EV_SMDCore_Clock_AlarmStats,"Clock_AlarmStats" , NULL },
    { NULL, SVEN_EV_SMDCore_Clock_SetFreq   ,"Clock_SetFreq" , NULL },

    { NULL, SVEN_EV_SMDCore_SoftPLL_PCR_Arrive,    "PCR_Arrive" , "pcr:%08x stc:%08x dt:%5d %2d state:%d g:%08x" },
    { NULL, SVEN_EV_SMDCore_SoftPLL_NudgeClock,    "NudgeClock" , "pcr:%08x stc:%08x dt:%5d dtc:%08x ippm:%d ppm %d" },
    { NULL, SVEN_EV_SMDCore_SoftPLL_Discontinuity, "Discontinu" , "pcr:%08x stc:%08x dt:%5d %2d state:%d %08x" },
    { NULL, SVEN_EV_SMDCore_SoftPLL_ScanBuffer,    "ScanBuffer" , "state:%d siz:%d pid:%d ts:%d %d %d" },
    { NULL, SVEN_EV_SMDCore_SoftPLL_DriftStatus,   "DriftStats" , "pcr:%08x stc:%08x dt:%5d dtc:%08x state:%d g:%08x" },
    { NULL, SVEN_EV_SMDCore_SoftPLL_UnTrackable,   "UnTrackable" , "PCR-STC :%d %d %d %d %d %d" },
    { NULL, SVEN_EV_SMDCore_SoftPLL_RegEvent,      "RegEvent",     "handle :%d event :%d type :%d %d %d %d" },
    { NULL, SVEN_EV_SMDCore_SoftPLL_GetSyncInfo,   "GetSyncInfo" , "handle :%d last_adj :%d clock :%d algo :%d %d %d" },
    { NULL, SVEN_EV_SMDCore_SoftPLL_TriggerEvent,  "TriggerEvent" , "vent :%d event_type :%d %d %d %d %d" },


    { NULL, SVEN_EV_SMDCore_ClockMux_STC,    "STC_MUX" , "unit:%d mux:%d %08x %08x %08x %08x" },
    { NULL, SVEN_EV_SMDCore_ClockMux_Aud,    "AUD_MUX" , "unit:%d mux:%d %08x %08x %08x %08x" },

    { NULL, SVEN_EV_SMDCore_Circbuf_Alloc,   "Circbuf_Alloc" , NULL },
    { NULL, SVEN_EV_SMDCore_Circbuf_Free,    "Circbuf_Free" , NULL },
    { NULL, SVEN_EV_SMDCore_Circbuf_Write,   "Circbuf_Write" , NULL },
    { NULL, SVEN_EV_SMDCore_Circbuf_Read,    "Circbuf_Read" , NULL },
    { NULL, SVEN_EV_SMDCore_Circbuf_SetName, "Circbuf_SetName" , NULL },

    { NULL, SVEN_EV_SMDCore_Viz_Port_Associate,     "Viz_Port" , NULL },
    { NULL, SVEN_EV_SMDCore_Viz_Queue_Associate,    "Viz_Queue" , NULL },
    { NULL, SVEN_EV_SMDCore_Viz_Circbuf_Associate,  "Viz_Circbuf" , NULL },

    { NULL, SVEN_EV_SMDCore_Gst_Transition,  "Gst_Transition", "%c%c%c%c tran:%d %d"},
    { NULL, SVEN_EV_SMDCore_Gst_ParentCall,  "Gst_ParentCall", "%c%c%c%c tran:%d %d"},
    { NULL, SVEN_EV_SMDCore_Gst_ParentRet,   "Gst_ParentRet",  "%c%c%c%c tran:%d res:%d"},
    { NULL, SVEN_EV_SMDCore_Gst_EventEnter,  "Gst_EventEnter", "%c%c%c%c evt:%d %d"},
    { NULL, SVEN_EV_SMDCore_Gst_EventExit,   "Gst_EventExit",  "%c%c%c%c evt:%d %d"},
    { NULL, SVEN_EV_SMDCore_Gst_LoopSleep,   "Gst_LoopSleep",  "%c%c%c%c %d %d"},
    { NULL, SVEN_EV_SMDCore_Gst_LoopEnter,   "Gst_LoopEnter",  "%c%c%c%c %d %d"},
    { NULL, SVEN_EV_SMDCore_Gst_ChainMode,   "Gst_ChainMode",  "%c%c%c%c mode:%d %d"},
    { NULL, SVEN_EV_SMDCore_Gst_ClockId,   	"Gst_ClockId",    "%c%c%c%c clk:%d %d"},
    { NULL, SVEN_EV_SMDCore_Gst_BufDrop,   	"Gst_BufDrop",    "%c%c%c%c rsn:%d info:%d"},
    { NULL, SVEN_EV_SMDCore_Gst_BufWrAtmpt,  "Gst_BufWrAtmpt", "%c%c%c%c id:%d port:%d"},
    { NULL, SVEN_EV_SMDCore_Gst_BufWrite,   	"Gst_BufWrite",   "%c%c%c%c id:%d port:%d"},
    { NULL, SVEN_EV_SMDCore_Gst_BufRcv,   	"Gst_BufRcv",     "%c%c%c%c ts:0x%x%x"},

    { NULL, 0, NULL, NULL } /* End-Of-Table */
};

static const struct EventSubtypeReverse g_event_performance_reverse[] =
{
	{ NULL,	SVEN_EV_performance_invalid,     "invalid",     NULL },
	{ NULL,	SVEN_EV_performance_start,       "start",       "context: %d workload: 0x%08x units: %d time: %d (0x%08x 0x%08x)" },
	{ NULL,	SVEN_EV_performance_stop,        "stop",        "context: %d workload: 0x%08x units: %d time: %d (0x%08x 0x%08x)" },
	{ NULL,	SVEN_EV_performance_measurement, "measurement", "context: %d workload: 0x%08x units: %d time: %d (0x%08x 0x%08x)" },
	{ NULL, 0, NULL, NULL } /* End-Of-Table */
};

static const struct EventSubtypeReverse g_event_api_reverse[] =
{
	{ NULL,	SVEN_EV_API_INVALID,          "invalid",     NULL },
	{ NULL,	SVEN_EV_API_FunctionCalled,   "call",    "calling api" },
	{ NULL,	SVEN_EV_API_FunctionReturned, "ret",     "api returned" },
	{ NULL, 0, NULL, NULL } /* End-Of-Table */
};

static const struct EventTypeReverse	g_event_type_reverse[] =
{
	{ NULL, SVEN_event_type_invalid, "invalid",
            NULL
	},
	{ NULL, SVEN_event_type_trigger, "trigger",
			g_event_trigger_reverse
	},
	{ NULL, SVEN_event_type_debug_string, "debug_str",
            g_event_debugstring_reverse
	},
	{ NULL, SVEN_event_type_register_io, "register_io",
			g_event_register_io_reverse
	},
	{ NULL, SVEN_event_type_port_io, "port_io",
			g_event_port_io_reverse
	},
	{ NULL, SVEN_event_type_module_isr, "module_isr",
			g_event_module_isr_reverse
	},
	{ NULL, SVEN_event_type_os_isr, "os_isr",
			g_event_os_isr_reverse
	},
	{ NULL, SVEN_event_type_os_thread, "os_thread",
			g_event_os_thread_reverse
	},
	{ NULL, SVEN_event_type_smd, "smd",
			g_event_smd_core_reverse
	},
	{ NULL, SVEN_event_type_module_specific, "module_event",
            NULL
	},
	{NULL, SVEN_event_type_PMU, "pmu_event",
	NULL
	},
	{NULL, SVEN_event_type_performance, "performance",
          g_event_performance_reverse
	},
	{NULL, SVEN_event_type_API, "api",
          g_event_api_reverse
	},
	{ NULL, 0, NULL, NULL }	/* End-Of-Table */
};



const struct EventTypeReverse g_sven_event_invalid =
{
	NULL,
	SVEN_event_type_invalid,
	"invalid",
        NULL
};

const struct EventTypeReverse g_sven_event_trigger =
{
	NULL,
	SVEN_event_type_trigger,
	"trigger",
        g_event_trigger_reverse
};

const struct EventTypeReverse g_sven_event_debug_str =
{
	NULL,
	SVEN_event_type_debug_string,
	"debug_str",
        g_event_debugstring_reverse
};

const struct EventTypeReverse g_sven_event_register_io =
{
	NULL,
	SVEN_event_type_register_io,
	"register_io",
        g_event_register_io_reverse
};

const struct EventTypeReverse g_sven_event_port_io =
{
	NULL,
	SVEN_event_type_port_io,
	"port_io",
        g_event_port_io_reverse
};

const struct EventTypeReverse g_sven_event_module_isr =
{
	NULL,
	SVEN_event_type_module_isr,
	"module_isr",
        g_event_module_isr_reverse
};

const struct EventTypeReverse g_sven_event_os_isr =
{
	NULL,
	SVEN_event_type_os_isr,
	"os_isr",
        g_event_os_isr_reverse
};

const struct EventTypeReverse g_sven_event_os_thread =
{
	NULL,
	SVEN_event_type_os_thread,
	"os_thread",
        g_event_os_thread_reverse
};

const struct EventTypeReverse g_sven_event_smd_core =
{
	NULL,
	SVEN_event_type_smd,
	"smd",
        g_event_smd_core_reverse
};

const struct EventTypeReverse g_sven_event_module_event=
{
	NULL,
	SVEN_event_type_module_specific,
	"module_event",
        NULL
};
const struct EventTypeReverse g_sven_event_api_event=
{
	NULL,
	SVEN_event_type_API,
	"api",
   g_event_api_reverse
};

static const struct EventTypeReverse *g_events[SVEN_event_type_MAX] = {
    &g_sven_event_invalid,       /* SVEN_event_type_invalid,		*/
    &g_sven_event_trigger,       /* SVEN_event_type_trigger,		*/
    &g_sven_event_debug_str,     /* SVEN_event_type_debug_string,	*/
    &g_sven_event_register_io,   /* SVEN_event_type_register_io,	*/
    &g_sven_event_port_io,       /* SVEN_event_type_port_io,		*/
    &g_sven_event_module_isr,    /* SVEN_event_type_module_isr,     */
    &g_sven_event_os_isr,        /* SVEN_event_type_os_isr,         */
    &g_sven_event_os_thread,     /* SVEN_event_type_os_thread,      */
    &g_sven_event_smd_core,      /* SVEN_event_type_smd,   */
    &g_sven_event_module_event,  /* SVEN_event_type_module_specific */
    NULL,                        /* SVEN_event_type_PMU,            */
    NULL,                        /* SVEN_event_type_performance */
    &g_sven_event_api_event,     /* SVEN_event_type_API */
};

/* ========================================================================== */
/* ========================================================================== */

static const struct RegisterBankDescriptor **g_reverse_sorted_rbd;
static int g_reverse_num_rbds;

void sven_reverse_set_physaddr_lookup(
    const struct RegisterBankDescriptor **rbd_lookup,
    int                                   num_rbds )
{
    g_reverse_sorted_rbd = rbd_lookup;
    g_reverse_num_rbds = num_rbds;
}

static const struct RegisterBankDescriptor *sven_reverse_physaddr_lookup(
    unsigned int                    phys_addr )
{
    const struct RegisterBankDescriptor *rbd = NULL;
    int n,lo,hi;

    if ( NULL == g_reverse_sorted_rbd ) return(rbd);    /* WARNING: EARLY RETURN */
    if ( 0 == g_reverse_num_rbds )      return(rbd);    /* WARNING: EARLY RETURN */

    lo = 0; hi = g_reverse_num_rbds - 1;
    n = (lo + hi) >> 1;

    /* binary search */
    while ( lo != hi )
    {
        if ( phys_addr < g_reverse_sorted_rbd[n]->rbd_phys_addr )
        {
//printf("h:%2d l:%2d n:%2d :: %08x < %08x\n", hi, lo, n, (int) phys_addr, (int) g_reverse_sorted_rbd[n]->rbd_phys_addr );
            hi = n - 1;
            n = (lo + hi) >> 1;
//            n = (lo + hi + 1) >> 1;
        }
        else if ( phys_addr >=
            (g_reverse_sorted_rbd[n]->rbd_phys_addr +
             g_reverse_sorted_rbd[n]->rbd_size ) )
        {
//printf("h:%2d l:%2d n:%2d :: %08x >= %08x\n", hi, lo, n, (int) phys_addr, (int) (g_reverse_sorted_rbd[n]->rbd_phys_addr + g_reverse_sorted_rbd[n]->rbd_size) );
            lo = n + 1;
            n = (lo + hi) >> 1;
//            n = (lo + hi + 1) >> 1;
        }
        else
        {
            rbd = g_reverse_sorted_rbd[n];
            break;
        }

        if ( hi == lo )
        {
            if ( (phys_addr >= g_reverse_sorted_rbd[n]->rbd_phys_addr) &&
                 (phys_addr < (g_reverse_sorted_rbd[n]->rbd_phys_addr + g_reverse_sorted_rbd[n]->rbd_size)) )
            {
//printf("**h:%2d l:%2d n:%2d :: %08x >= %08x\n", hi, lo, n, (int) phys_addr, (int) (g_reverse_sorted_rbd[n]->rbd_phys_addr + g_reverse_sorted_rbd[n]->rbd_size) );
                rbd = g_reverse_sorted_rbd[n];
            }
            break;
        }
        else if ( hi < lo ) break;
    }

    return(rbd);
}

////////////////////////////////////////////////////////////////////////////////
///	 Reverse-engineers a Register Read/Write SVENEvent to a register-change text string
///     Will break-out register bit definitions if they are defined in the table.
///
/// @param   str  : string to print into
/// @param   ev : SVENEvent containing the Register IO value
/// @param   mrd : ModuleReverseDefs (unit definitions)
/// @param   prev_value : previous value of the register
///
/// @returns number of characters written
///
////////////////////////////////////////////////////////////////////////////////
int sven_reverse_get_register_changes(
	char 				 		    *str,			/* String to build into */
	const struct SVENEvent		    *ev,			/* Register-IO SVENEvent to decode */
	const struct ModuleReverseDefs  *mrd,           /* ModuleReverseDefs */
	unsigned int				     prev_value )	/* previous value of register */
{
	const struct EAS_Register	*reg;			/* register table description pointer */
	const struct EAS_Register	*prev_reg;		/* register table description pointer */
	char						*cp;			/* current character pointer */
	unsigned int 				 event_regoff;	/* calculated device register offset */
	unsigned int				 changed_bits;	/* bits that have changed */

	cp				= str;								/* current string pointer */
	changed_bits	= prev_value ^ ev->u.se_reg.value;	/* calc all bits that have changed */

    if ( mrd && mrd->mrd_size )
    {
    	event_regoff	= ev->u.se_reg.phys_addr & (mrd->mrd_size - 1);
    }
    else
    {
    	event_regoff	= ev->u.se_reg.phys_addr & 0xFFFF;  /* 64k */
    }

    /* This is how we decode offsets from register array */
    reg = mrd->mrd_regdefs;
    prev_reg = reg;

	/* register search loop */
	while ( NULL != reg->reg_name )
	{
		if( reg->reg_offset == (int) event_regoff )
		{
			const struct EAS_RegBits	*regbits; /// Make variables as local as possible */

            if ( ! (SVEN_REGIO_LOG_FLAG_PREV_UNKNOWN & ev->u.se_reg.log_flags) )
            {
			    /* append the register name */
			    cp += sprintf( cp, "Reg:%s %08x->%08x ", reg->reg_name, prev_value, ev->u.se_reg.value );
            }
            else
            {
			    /* append the register name */
			    cp += sprintf( cp, "Reg:%s unknown ->%08x ", reg->reg_name, ev->u.se_reg.value );
            }

			/* Is there a bits breakout for this register? */
			if ( NULL != (regbits = reg->reg_bits) )
			{
				while ( NULL != regbits->regbits_name )
				{
					unsigned int 		mask;

					/* Calculate the mask for this set of bits */
					mask = ((1<<regbits->regbits_width)-1) << regbits->regbits_lsb_pos;

					/* are any of the changed bits in this mask? */
					if ( changed_bits & mask )
					{
						/* append */
						cp += sprintf( cp, "[%s %X->%X] ",
							regbits->regbits_name,
							(prev_value & mask) >> regbits->regbits_lsb_pos,
							(ev->u.se_reg.value & mask) >> regbits->regbits_lsb_pos );
					}

					regbits++;	/* next bits descriptor */
				}
			}


			break;	/* we found the offset */
		}
        else
        {
            /* is the event offset greater than our offset? */
            if ( event_regoff > (unsigned int) reg->reg_offset )
            {
                /* is this offset greater than our previous one? */
                if ( reg->reg_offset > prev_reg->reg_offset )
                {
                    prev_reg = reg;
                }
            }
        }

		reg++;	/* next register descriptor */
	}

	if ( cp == str )	/* no chars written? register not found, print default info */
	{
		// cp += sprintf(cp, "Reg @%08lx: %08x->%08x", ev->u.se_reg.phys_addr, prev_value, ev->u.se_reg.value );
    	cp += sprintf( cp, "Reg:%x (%s+0x%x) %08x->%08x ",
            event_regoff,
            prev_reg->reg_name,
            (int) event_regoff - prev_reg->reg_offset,
            prev_value,
            ev->u.se_reg.value );

	}

	/* return string length */
	return( cp - str );
}

////////////////////////////////////////////////////////////////////////////////
///
/// @brief		Reverse-engineers OS interrupt events.
///
/// @param   str  : string to print into
/// @param   ev : SVENEvent containing the interrupt event.
///
/// @returns number of characters written
///
////////////////////////////////////////////////////////////////////////////////
static int sven_reverse_os_isr(char *str, const struct SVENEvent *ev)
{
	return sprintf(str, "cpu:%d irq:%d", ev->u.se_int.cpu, ev->u.se_int.line);
}

////////////////////////////////////////////////////////////////////////////////
///
/// @brief		Reverse-engineers OS thread events.
///
/// @param   str  : string to print into
/// @param   ev : SVENEvent containing the thread event.
///
/// @returns number of characters written
///
////////////////////////////////////////////////////////////////////////////////
static int sven_reverse_os_thread(char *str, const struct SVENEvent *ev)
{
	if(ev->se_et.et_subtype == SVEN_EV_OS_Thread_Run)
		return sprintf(str, "cpu:%d pid:%d prevpid:%d", ev->u.se_thread.cpu, ev->u.se_thread.pid, ev->u.se_thread.prevpid);

	return 0;
}

////////////////////////////////////////////////////////////////////////////////
///
/// @brief		Dumps the payload ULONGS
///
/// @param   str  : string to print into
/// @param   ev : SVENEvent containing the interrupt event.
///
/// @returns number of characters written
///
////////////////////////////////////////////////////////////////////////////////
static int sven_reverse_dump_payload(char *str, const struct SVENEvent *ev)
{
    char        *cp = str;
    int          i;

    for ( i = 0; i < SVEN_EVENT_PAYLOAD_NUM_UINTS; i++ )
    {
        cp += sprintf( cp, " %08x", ev->u.se_uint[i] );
    }

    return( cp - str );
}

////////////////////////////////////////////////////////////////////////////////
///
/// @brief		Decodes a "module_name.register_name.bits_name" string from a
//              known location.
///
/// @param   regname  : string to print into
/// @param   pmrd     : ModuleReverseDefs to find.
/// @param   preg     : EAS_Register to find.
/// @param   pbits    : EAS_RegBits to find.
/// @param   poffset  : offset
///
/// @returns zero on failure, N on success
///
////////////////////////////////////////////////////////////////////////////////
int sven_reverse_Lookup(
	const char			               *regname,
    const struct ModuleReverseDefs    **pmrd,
    const struct EAS_Register         **preg,
    const struct EAS_RegBits          **pbits,
    unsigned int                       *poffset )
{
    const struct ModuleReverseDefs    *mrd = NULL;
    const struct EAS_Register         *reg = NULL;
    const struct EAS_RegBits          *bits = NULL;
    int                                lookup_succeeded = 0;
    int                                tok_beg,tok_end;

    if ( pmrd )     mrd = *pmrd;
    if ( preg )     reg = *preg;
    if ( pbits )    bits = *pbits;
    if ( poffset )  *poffset = 0;

    tok_beg = tok_end = 0;

    /* Skip leading spaces */
    while (' ' == regname[tok_end]) tok_end++; /*seek the end of first white space */
    tok_beg = tok_end;

    do
    {
        /* Dot separator or EOS */
        if ( ('.' != regname[tok_end]) && ('\0' != regname[tok_end]) )
        {
            tok_end++;
        }
        else
        {
            if ( NULL == mrd )
            {
                int                              module;

                for ( module = 0; module < SVEN_module_MAX; module++ )
                {
                    if ( NULL != (mrd = svenreverse_GetModuleTables( module )) )
                    {
                        if ( !strncasecmp( &regname[tok_beg], mrd->mrd_name, (tok_end-tok_beg)) )
                        {
                            lookup_succeeded++;
                            break;
                        }
                    }
                }

                if ( SVEN_module_MAX == module )
                {
                    /* We got all the way to the end and didn't find anything */
                    //printf( "Lookup:Module \"%s\" not found\n", &regname[tok_beg] );
                    mrd = NULL;

                    if ( NULL != g_reverse_sorted_rbd )
                    {
                        int                                  i;

                        for ( i = 0; i < g_reverse_num_rbds; i++ )
                        {
                            const struct RegisterBankDescriptor *rbd;

                            rbd = g_reverse_sorted_rbd[i];

                            if ( !strncasecmp( &regname[tok_beg], rbd->rbd_name, (tok_end-tok_beg)) )
                            {
                                if ( NULL != (mrd = svenreverse_GetModuleTables( rbd->rbd_module )) )
                                {
                                    lookup_succeeded++;
                                }
                                break;
                            }
                        }
                    }

                    if ( (NULL == mrd) && (NULL != poffset) )
                    {
                        *poffset = strtoul( &regname[tok_beg], NULL, 0 );
                    }

                    lookup_succeeded++;
                    break;
                }
            }
            else if ( NULL == reg )
            {
                /* Search for register in this MRD with this token's name */
                if ( NULL != (reg = mrd->mrd_regdefs) )
                {
                    while ( reg->reg_name )
                    {
                        if ( !strncasecmp( &regname[tok_beg], reg->reg_name, (tok_end-tok_beg)) )
                        {
                            lookup_succeeded++;
                            break;
                        }

                        reg++;
                    }

                    if ( NULL == reg->reg_name )
                    {
                        /* We got all the way to the end and didn't find anything */
                        //printf( "Lookup:Reg \"%s\" not found\n", &regname[tok_beg] );
                        if ( NULL != poffset )
                            *poffset = strtoul( &regname[tok_beg], NULL, 0 );

                        #if 0   /* search for register name with same offset */
                        /* search for register with the same offset */
                        reg = mrd->mrd_regdefs;
                        while ( reg->reg_name )
                        {
                            if ( reg->reg_offset == *poffset )
                            {
                                break;
                            }
                            reg++;
                        }
                        #endif

                        lookup_succeeded++;

                        if ( NULL == reg->reg_name )    /* got to the end? */
                        {
                            reg = NULL;
                            break;
                        }
                    }
                }
                else
                {
                    if ( NULL != poffset )
                        *poffset = strtoul( &regname[tok_beg], NULL, 0 );
                    lookup_succeeded++;
                    break;
                }
            }
            else if ( NULL == bits )
            {
                /* Search for registerbits in this REG with this token's name */
                if ( NULL != (bits = reg->reg_bits) )
                {
                    while ( bits->regbits_name )
                    {
                        if ( !strncasecmp( &regname[tok_beg], bits->regbits_name, (tok_end-tok_beg)) )
                        {
                            lookup_succeeded++;
                            break;
                        }

                        bits++;
                    }

                    if ( NULL == bits->regbits_name )
                    {
                        /* We got all the way to the end and didn't find anything */
                        //printf( "Lookup:Bits \"%s\" not found\n", &regname[tok_beg] );
                        bits = NULL;
                        if ( NULL != poffset )
                            *poffset = strtoul( &regname[tok_beg], NULL, 0 );
                        lookup_succeeded++;
                        break;
                    }
                }
                else
                {
                    if ( NULL != poffset )
                        *poffset = strtoul( &regname[tok_beg], NULL, 0 );
                    lookup_succeeded++;
                    break;
                }
            }
            else
            {
                break;
            }


            /* tok_end points to '.' or '\0' */
            if ( '\0' == regname[tok_end] )
            {
                break;
            }

            tok_end++; /* Skip past the dot '.' */
            tok_beg = tok_end;
        }
    } while ( 1 );


    if ( pmrd )     *pmrd = mrd;
    if ( preg )     *preg = reg;
    if ( pbits )    *pbits = bits;

    return( lookup_succeeded );
}

////////////////////////////////////////////////////////////////////////////////
///
/// @brief		Reverse-engineers a SVENEvent into a text string.
///
/// @param   str  : string to print into
/// @param   rev : struct SVENReverser
/// @param   ev : SVENEvent containing the Register IO value
///
/// @returns number of characters written
///
////////////////////////////////////////////////////////////////////////////////
int sven_reverse_GetEventTextString(
	char					*str,
	struct SVENReverser		*rev,
	const struct SVENEvent	*ev )
{
	char							 *cp = str;
	const struct EventTypeReverse    *er = g_event_type_reverse;
	const struct EventSubtypeReverse *esr = NULL;
	const struct ModuleReverseDefs	 *mrd;
	const struct ModuleReverseDefs	 *pa_mrd = NULL;

   (void)rev;  /* unused parameter */

    if ( NULL != (mrd = svenreverse_GetModuleTables(ev->se_et.et_module)) )
    {
	    /* Module and Unit */
	    cp += sprintf(cp,"M:%-11s U:%02x ",            // -11s = left align 11 wide field.  Makes the output prettier.  11 = size of ("GEN3_AUD_IO")
		    mrd->mrd_name,
		    (int) ev->se_et.et_unit );
    }
    else
    {
	    /* Module and Unit */
	    cp += sprintf(cp,"M:%02x U:%02x ",
		    (int) ev->se_et.et_module,
		    (int) ev->se_et.et_unit );
    }

	if ( SVEN_event_type_register_io == ev->se_et.et_type )
	{
        const struct RegisterBankDescriptor *rbd;

        if ( NULL != (rbd = sven_reverse_physaddr_lookup(ev->u.se_reg.phys_addr)) )
        {
            /* Search RegIo module for Physical Address */
            pa_mrd = svenreverse_GetModuleTables(rbd->rbd_module);
        }
    }

	while ( er->er_name )
	{
		if ( er->er_type == ev->se_et.et_type )
		{
			cp += sprintf(cp,"T:%s ", er->er_name );
			/* There is a subtype breakout??? */
			if ( er->er_subtypes )
			{
				esr = er->er_subtypes;
				while ( esr->er_name )
				{
					if ( esr->er_subtype == ev->se_et.et_subtype )
					{
						cp += sprintf(cp,"S:%-12s ", esr->er_name );
						break;	/* break on subtype */
					}
					esr++;
				}

                if ( NULL == esr->er_name )
                {
                    esr = NULL;
    				cp += sprintf(cp,"S:%d ", ev->se_et.et_subtype );
                }
			}
			else if ( SVEN_event_type_register_io == ev->se_et.et_type )
			{
                /* Look up the previous register value??? */
			}
			else if ( SVEN_event_type_module_specific == ev->se_et.et_type )
			{
                const char      *event_fmt_string = NULL;

				/* Search Module-Specific Events */
				if ( NULL != mrd )
				{
					const struct SVEN_Module_EventSpecific	*mes;

					if ( NULL != (mes = mrd->mrd_event_specific) )
					{
						/* Search through module-specific event subtypes */
						while ( mes->mes_name )
						{
							/* Here's our subtype */
							if ( mes->mes_subtype == ev->se_et.et_subtype )
							{
                                int         i;

								/* Add Module Specific subtype text string */
								cp += sprintf(cp," %s", mes->mes_name );

                                /* Search for % in the comment to indicate it's a format string */
                                i = 0;
                                while ( '\0' != mes->mes_comment[i] )
                                {
                                    if ( '%' == mes->mes_comment[i] )
                                    {
                                        event_fmt_string = mes->mes_comment;
                                        break;
                                    }
                                    i++;
                                }

								break;
							}
							mes++;
						}
					}

					/* No event subtype found */
					if ( (NULL == mes) || (NULL == mes->mes_name) )
					{
						cp += sprintf(cp,"MS: %s (%d)", mrd->mrd_name, ev->se_et.et_subtype );
					}
				}
				else
				{
					/* Just dump whole thingo */
					cp += sprintf(cp,"ModSpec: (%d,%d)", ev->se_et.et_module, ev->se_et.et_subtype );
				}

                if ( NULL != event_fmt_string )
                {
                #if ( 6 == SVEN_EVENT_PAYLOAD_NUM_UINTS )
                    cp += sprintf(cp, event_fmt_string,
                        ev->u.se_uint[0],
                        ev->u.se_uint[1],
                        ev->u.se_uint[2],
                        ev->u.se_uint[3],
                        ev->u.se_uint[4],
                        ev->u.se_uint[5] );
                #else
                    _TODO_FIX_SVEN_REVERSE_MODULE_SPECIFIC_DUMP;
                #endif
                }
                else
                {
                    cp += sven_reverse_dump_payload( cp, ev );
                }
			}

			else if (SVEN_event_type_PMU == ev->se_et.et_type)
			{
				cp += sprintf(cp, "t%d,c0%d,c1%d", (int)ev->u.se_pmu.timer,(int)ev->u.se_pmu.counter_0,(int)ev->u.se_pmu.counter_1);
			}
			else
			{
			}

			break;
		}
		er++;
	}

	if ( SVEN_event_type_register_io == ev->se_et.et_type )
	{
        /* Physical Address MRD */
        if ( NULL != pa_mrd )
        {
            if ( mrd != pa_mrd )
        		cp += sprintf( cp, "{%s}:", pa_mrd->mrd_name ); /* warning, different module */

            if ( NULL != pa_mrd->mrd_regdefs )
            {
            	cp += sven_reverse_get_register_changes( cp, ev, pa_mrd, ev->u.se_reg.log_prev );
            }
        }
        else if ( (NULL != mrd) && (NULL != mrd->mrd_regdefs) )
        {
            cp += sven_reverse_get_register_changes( cp, ev, mrd, ev->u.se_reg.log_prev );
        }
        else
        {
    		cp += sprintf( cp, "Addr:0x%08x %08x -> %08x", (int) ev->u.se_reg.phys_addr, ev->u.se_reg.log_prev, ev->u.se_reg.value );
        }
	}
	else if ( SVEN_event_type_debug_string == ev->se_et.et_type )
	{
		/* Debug String */
		cp += sprintf(cp,"\"%s\"", ev->u.se_dbg_str );
	}
	else if ( SVEN_event_type_smd == ev->se_et.et_type )
	{
        if ( (NULL != esr) && (NULL != esr->er_fmt_string) )
        {
            #if ( 6 == SVEN_EVENT_PAYLOAD_NUM_UINTS )
                cp += sprintf(cp, esr->er_fmt_string,
                    ev->u.se_uint[0],
                    ev->u.se_uint[1],
                    ev->u.se_uint[2],
                    ev->u.se_uint[3],
                    ev->u.se_uint[4],
                    ev->u.se_uint[5] );
            #else
                _TODO_FIX_SVEN_REVERSE_MODULE_SPECIFIC_DUMP;
            #endif
        }
        else
        {
    		cp += sven_reverse_dump_payload( cp, ev );
        }
	}
	else if ( SVEN_event_type_os_isr == ev->se_et.et_type )
	{
		cp += sven_reverse_os_isr(cp, ev);
 	}
    else if ( SVEN_event_type_os_thread == ev->se_et.et_type )
    {
        cp += sven_reverse_os_thread(cp, ev);
    }


	/* Event Type Not Listed */
	if ( er->er_type != ev->se_et.et_type )
	{
		cp += sprintf(cp,"T:%02x S:%02x",
			(int) ev->se_et.et_type,
			(int) ev->se_et.et_subtype );

		cp += sven_reverse_dump_payload( cp, ev );
	}

	/* return string length */
	return( cp - str );
}

void svenreverse_Delete(
	struct SVENReverser		*rev )
{
    free( rev );
}
////////////////////////////////////////////////////////////////////////////////
///
/// @brief		Create a generic SVENReverse handle
///
/// @param   hdr  : SVEN Root Shared Memory structure
///
/// @returns struct SVENReverser * or NULL
///
////////////////////////////////////////////////////////////////////////////////
struct SVENReverser *svenreverse_Create(
	struct _SVENHeader		*hdr )
{
	struct SVENReverser		*rev;

	if ( NULL != (rev = (struct SVENReverser *) calloc(1,sizeof(*rev))) )
	{
		/* Grab reverser */
		rev->hdr = hdr;
	}

	return( rev );
}

////////////////////////////////////////////////////////////////////////////
///
/// @brief :  Gets the SVEN EVENT Type based on the command passed
///
/// @param  event_name: Name of the event to be decoded
///
/// @return: struct EventTypeReverse
///
///////////////////////////////////////////////////////////////////////////
const struct EventTypeReverse* svenreverse_EVENT_TABLES_BY_NAME(
    const char                  *event_name )
{
    int 					event;

    for ( event = 0; event < SVEN_event_type_MAX; event++ )
    {
        if ( (NULL != g_events[event]) && !strcasecmp( g_events[event]->er_name, event_name ) )
        {
            return( g_events[event] );
        }
    }

    return NULL;
}

const struct EventTypeReverse* svenreverse_EVENT_TABLES_BY_NUM(
    int                          event_num )
{
    if ( (event_num >= 0) && (event_num < SVEN_event_type_MAX) )
    {
        return( g_events[event_num] );
    }
    return(NULL);
}

/*const struct EventSubtypeReverse* svenreverse_sub_event_table(
	struct EventTypeReverse *event, const char *sub_event_name)
{
	int sub_event;
	int j = 0;
	struct EventTypeReverse *tempevent;
	struct EventSubtypeReverse *sub_type;
	tempevent = calloc(1, sizeof(struct EventTypeReverse));
	sub_type   = calloc(1, sizeof(struct EventSubtypeReverse));
	memcpy(tempevent, event, sizeof(struct EventTypeReverse));
	memcpy(sub_type, event->er_subtypes, sizeof(struct EventSubtypeReverse));
	while(sub_type[j].er_subtype)
		{
			if(sub_type[j] && !strcasecmp(sub_type[j].er_name, sub_event_name))
				return &sub_type[j];
			j++;
		}
	return NULL;

}
*/
#if 0
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Example of Defs Using Extensions */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
struct TestApp_0_Params
{
    struct EAS_Extension    ext;
    int                     min_value;
    int                     max_value;
};

struct HardwareConfig_Params
{
    struct EAS_Extension    ext;
    int                     interval;
    int                     mangulation_value;
};

static struct HardwareConfig_Params  g_csr_ExtUnit_CONFIG_WatchDog_HWParams = {
    { NULL,
		"HWConfig-Params", 0 },   /* Extension parameters, Links */
    .interval = 214,
    .mangulation_value = 42
};

static struct TestApp_0_Params  g_csr_ExtUnit_CONFIG_WatchDog_T0Params = {
    { &g_csr_ExtUnit_CONFIG_WatchDog_HWParams.ext,	/* backwards link */
		"TestApp0-Params", 0 },   /* Extension parameters, Links */
    .min_value = 0,
    .max_value = 5
};

static const struct EAS_RegBits g_csr_ExtUnit_CONFIG_ww50_05[] =
{
    { "RESERVED_32_8",			8,	24},    /* reserved bits [32..8] in this register */
	{ "WATCHDOG_CFG",			4,	4, NULL, &g_csr_ExtUnit_CONFIG_WatchDog_T0Params.ext},		/* WATCHDOG config  */
	{ "STREAM_3_ENABLE",		3,	1}, 	/* Stream 3 enable  */
	{ "STREAM_2_ENABLE",		2,	1}, 	/* Stream 2 enable  */
	{ "STREAM_1_ENABLE",		1,	1}, 	/* Stream 1 enable  */
	{ "STREAM_0_ENABLE",		0,	1}, 	/* Stream 0 enable  */
	{ NULL }    /* NULL terminator */
};

static const struct EAS_Register g_csr_ExtUnit_ww50_05[] =
{
	{ "CONFIG",     0x00, g_csr_ExtUnit_CONFIG_ww50_05, "Config Register" },
	{ "INT_STATUS", 0x04, NULL, "Interrupt Status Register" },
	{ NULL }    /* NULL terminator */
};

const struct EAS_Unit_CSR_Version g_csr_ExtUnit_versions[] =
{
	{ "WW5005",     g_csr_ExtUnit_ww50_05 },
	{ NULL }    /* NULL terminator */
};
#endif
