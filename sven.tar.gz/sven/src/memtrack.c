/*
  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright (c) 2006-2008. Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright (c) 2006-2008. Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
/** memtracker library hack-and-whack-a-mole
 */

#ifdef MEMTRACK_LIB

#define __USE_GNU

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <ctype.h>
#include <dlfcn.h>
#include <execinfo.h>
#include <pthread.h>

#ifndef PTHREAD_MUTEX_RECURSIVE_MP
#include <sched.h>
#include <sys/types.h>
#include <sys/unistd.h>

//_syscall0(pid_t,gettid)
// pid_t gettid(void);
#endif

/* this should be defined in dlfcn.h */
#ifndef RTLD_NEXT
#define RTLD_NEXT ((void *)-1L)
#endif

/* To build :
* remove spaces from below path
* /nfs/ch/proj/cevsvmv/cev001/c anmore/c m-linux/bin/gcc -m32 -g -fno-omit-frame-pointer -Wall -shared -fPIC -fpic -DMEMTRACK_LIB memtrack.c -o memtrack.so -ldl -lpthread
* arm-linux-gcc -Wall -g -shared -fPIC -fpic -DMEMTRACK_LIB memtrack.c -o memtrack.so -ldl -lpthread
*/

/* -------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------- */
#define TRACKER_HASH_M  0x9E3779B9

/* pointer to hash */
#define TRACKER_BUF_KEY(buf) (((int)(buf))*TRACKER_HASH_M)

#define TRACKER_BACKTRACE_DEPTH     40

struct AllocInfo
{
    struct AllocInfo    *ai_next;   /* MUST BE FIRST */
    int                  ai_key;
    int                  ai_sequence;
    int                  ai_status;
    size_t               ai_bufsize;
    void                *ai_buf;
    int                  ai_backtrace_depth;
    void                *ai_backtrace[TRACKER_BACKTRACE_DEPTH];
};

#define TRACKER_ALLOC_TRACES_PER_BLOCK  127

struct TrackerBlock
{
    struct TrackerBlock     *tb_next;   /* MUST BE FIRST */
    volatile int             tb_next_ai;
    struct AllocInfo         tb_ai[TRACKER_ALLOC_TRACES_PER_BLOCK];
};

#define TRACKER_HASH_SIZE   (1<<10)
#define TRACKER_HASH_MASK   (TRACKER_HASH_SIZE - 1)
struct MemTracker
{
    struct TrackerBlock     *mt_first_tb;
    int                      mt_backtrace_recursion;
    int                      mt_sequence;
    struct AllocInfo        *mt_recent_frees;
    struct AllocInfo        *mt_hash[TRACKER_HASH_SIZE];
};

/* -------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------- */

static pthread_mutex_t      recmutex = PTHREAD_MUTEX_INITIALIZER;

#ifndef PTHREAD_MUTEX_RECURSIVE_MP
//static pthread_mutexattr_t  recmutex_attr; NOT WORKING
static int                  recmutex_count;
pthread_t                   recmutex_owner;
#endif

//static pthread_mutex_t recmutex = PTHREAD_RECURSIVE_MUTEX_INITIALIZER_NP;

static struct TrackerBlock  g_first_tb;
static struct MemTracker    g_mt = {
    .mt_first_tb = &g_first_tb
};

static void *(*old_malloc)(size_t size);
static void *(*old_calloc)( size_t nmemb, size_t size );
static void *(*old_realloc)(void *ptr, size_t size);
static int (*old_posix_memalign)(void **memptr, size_t alignment, size_t size);
static void *(*old_valloc)(size_t size);
static void *(*old_memalign)(size_t boundary, size_t size);
static void (*old_free)(void *ptr);
static FILE *(*old_fopen)(const char *path, const char *mode);

#define CALLOC_STEAL_HACK_SIZE  (4*1024)
static int  calloc_hack_next_buf;
static char calloc_hack_region[CALLOC_STEAL_HACK_SIZE];

static void steal_malloc_free(void) __attribute__((constructor));

static void steal_malloc_free(void)
{
    old_calloc = dlsym( RTLD_NEXT, "calloc" );
    old_malloc = dlsym( RTLD_NEXT, "malloc" );
    old_realloc = dlsym( RTLD_NEXT, "realloc" );

    old_valloc = dlsym( RTLD_NEXT, "valloc" );
    old_memalign = dlsym( RTLD_NEXT, "memalign" );
    old_posix_memalign = dlsym( RTLD_NEXT, "posix_memalign" );

    old_free = dlsym( RTLD_NEXT, "free" );
    old_fopen = dlsym( RTLD_NEXT, "fopen" );

#ifndef PTHREAD_MUTEX_RECURSIVE_MP
    //pthread_mutexattr_init( &recmutex_attr );
    //pthread_mutexattr_settype( &recmutex_attr, PTHREAD_MUTEX_RECURSIVE_MP );
    //pthread_mutex_init( &recmutex, &recmutex_attr );
#endif
}

/* -------------------------------------------------- */

static inline void memtracker_block(
    struct MemTracker   *mt )
{
#ifdef PTHREAD_MUTEX_RECURSIVE_MP
    pthread_mutex_lock( &recmutex );
#else
    char        gotit = 0;
    pthread_t   my_thread_id;

    my_thread_id = pthread_self();

    while ( 1 )
    {
        pthread_mutex_lock( &recmutex );
        if ( ! recmutex_count )
        {
            recmutex_count++;
            recmutex_owner = my_thread_id;
            gotit = 1;
        }
        else if ( pthread_equal(recmutex_owner,my_thread_id)  )
        {
            recmutex_count++;
            gotit = 1;
        }
        pthread_mutex_unlock( &recmutex );
        if ( gotit )
        {
            break;
        }
        else
        {
            sched_yield();
        }
    }
#endif
}

static inline void memtracker_unblock(
    struct MemTracker   *mt )
{
#ifdef PTHREAD_MUTEX_RECURSIVE_MP
    pthread_mutex_unlock( &recmutex );
#else
    recmutex_count--;
#endif
}

static void memtracker_record_malloc(
    struct MemTracker   *mt,
    void                *buf,
    size_t               size )
{
    struct AllocInfo    *ai = NULL;

    memtracker_block( mt );
    {
        struct TrackerBlock *tb;

        tb = (struct TrackerBlock *)mt->mt_first_tb;

        if ( NULL != mt->mt_recent_frees )
        {
            /* Unlink from "recently freed" list */
            ai = mt->mt_recent_frees;
            mt->mt_recent_frees = ai->ai_next;
        }
        else if ( tb->tb_next_ai < TRACKER_ALLOC_TRACES_PER_BLOCK )
        {
            ai = &tb->tb_ai[tb->tb_next_ai];
            tb->tb_next_ai++;
        }
        else if ( NULL != (tb = (*old_malloc)(sizeof(*tb))) )
        {
            /* insert at header of tracker blocks */
            tb->tb_next = mt->mt_first_tb;
            mt->mt_first_tb = tb;

            ai = &tb->tb_ai[0];
            tb->tb_next_ai = 1;
        }
        
        if ( NULL != ai )
        {
            struct AllocInfo    **pai;
            
            ai->ai_buf = buf;
            ai->ai_bufsize = size;
            ai->ai_key = TRACKER_BUF_KEY(buf);
            ai->ai_sequence = mt->mt_sequence++;
            ai->ai_status = 0;
            ai->ai_backtrace_depth = 0;
            
#if 1
            if ( ! mt->mt_backtrace_recursion++ )
            {
                void    *ltrace[TRACKER_BACKTRACE_DEPTH+2];
                int     depth;

                depth = (*backtrace)( ltrace, TRACKER_BACKTRACE_DEPTH+2 );
                if ( depth > 2 )
                {
                    ai->ai_backtrace_depth = depth - 2;
                    memcpy( ai->ai_backtrace, &ltrace[2], ai->ai_backtrace_depth * sizeof(void *) );
                }
            }
            mt->mt_backtrace_recursion--;
#endif
        
            /* Add this to the hashtable */
            pai = &mt->mt_hash[ ai->ai_key & TRACKER_HASH_MASK ];
            ai->ai_next = *pai;
            *pai = ai;
        }
    }
    memtracker_unblock( mt );
    
    if ( NULL == ai )
    {
        printf("memtracker: FATAL ERROR\n");
        exit(0);
    }
}

static void memtracker_record_free(
    struct MemTracker   *mt,
    void                *buf )
{

    memtracker_block( mt );
    {
        struct AllocInfo    *ai = NULL;
        struct AllocInfo    **pai,*nai;
        int                  key;

        key = TRACKER_BUF_KEY(buf);

        /* Scan this hash-chain */
        pai = &mt->mt_hash[ key & TRACKER_HASH_MASK ];
        while ( NULL != (nai = *pai) )
        {
            if ( nai->ai_buf == buf )
            {
                ai = nai;

                *pai = ai->ai_next; /* UNLINK from Hash Chain */

                break;
            }

            pai = &nai->ai_next;    /* next */
        }

        if ( NULL != ai )
        {
            ai->ai_status = 1;  /* mark as freed */

            /* Link to head of "recent memory frees" (for re-use) */
            ai->ai_next = mt->mt_recent_frees;
            mt->mt_recent_frees = ai;
        }
    }
    memtracker_unblock( mt );
}

static void memtracker_report(
    struct MemTracker   *mt,
    int                  verbosity )
{
    //memtracker_block( mt );
    {
        struct TrackerBlock *tb;
        int                  block = 0;
        int                  total_unfreed_bufs;
        int                  total_unfreed_bytes;
        int                  largest_unfreed_bytes;

        total_unfreed_bufs = 0;
        total_unfreed_bytes = 0;
        largest_unfreed_bytes = 0;
        
        tb = (struct TrackerBlock *)mt->mt_first_tb;
        printf("memtracker: Report: Seq:%d\n", mt->mt_sequence );

        while ( NULL != tb )
        {
            int                  i,n_ais;

            printf("Block %4d: next:%p N:%d\n", block++, tb->tb_next, tb->tb_next_ai );

            n_ais = tb->tb_next_ai;
            
            for ( i = 0; i < n_ais; i++ )
            {
                struct AllocInfo    *ai;

                ai = &tb->tb_ai[i];

                if ( !ai->ai_status )   /* still active */
                {
                    total_unfreed_bufs++;
                    total_unfreed_bytes += ai->ai_bufsize;
                    if ( largest_unfreed_bytes < ai->ai_bufsize )
                        largest_unfreed_bytes = ai->ai_bufsize;

                    if ( verbosity > 0 )
                    {
                        int                  bt;
                        char                **syms;

                        #if 0
                        printf("AI:%3d seq:%5d buf:%p size:%x bt:%d s:%d [", i, ai->ai_sequence, ai->ai_buf, ai->ai_bufsize, ai->ai_backtrace_depth, ai->ai_status );

                        for ( bt = 0; bt < ai->ai_backtrace_depth; bt++ )
                        {
                            printf("%p ", ai->ai_backtrace[bt] );
                        }

                        printf("]\n");
                        #else
                        printf("AI:%3d seq:%5d buf:%p size:%x bt:%d s:%d\n", i, ai->ai_sequence, ai->ai_buf, ai->ai_bufsize, ai->ai_backtrace_depth, ai->ai_status );
                        #endif

                        //if ( verbosity > 1 )
                        {
                            int         j;

                            printf("buf-000: ");

                            for ( j = 0; j < 16; j++ )
                            {
                                if ( j < ai->ai_bufsize )
                                    printf("%02x ", ((unsigned char *)ai->ai_buf)[j] );
                                else
                                    printf("   ");
                                    
                            }

                            printf("-- ");

                            for ( j = 0; j < 16; j++ )
                            {
                                char            ch;

                                if ( j < ai->ai_bufsize )
                                {
                                    ch = ((char *)ai->ai_buf)[j];
                                    if ( ! isprint(ch) )
                                        ch = '.';
                                }
                                else
                                {
                                    ch = ' ';
                                }
                                printf("%c", ch );
                            }

                            printf("\n");
                        }

                        //memtracker_unblock( mt );
                        mt->mt_backtrace_recursion++;
                        syms = backtrace_symbols( ai->ai_backtrace, ai->ai_backtrace_depth );
                        mt->mt_backtrace_recursion--;
                        //memtracker_block( mt );

                        if ( NULL != syms )
                        {
                            for ( bt = 0; bt < ai->ai_backtrace_depth; bt++ )
                            {
                                printf("  %s\n", syms[bt] );
                            }

                            free(syms);
                        }
                    }
                }
            }
            
            tb = tb->tb_next;
        }

        printf("memtracker: Summary: %d unfreed buffers containing %d bytes, largest buf %d\n",
            total_unfreed_bufs, total_unfreed_bytes, largest_unfreed_bytes );

    }
    //memtracker_unblock( mt );
}

/* -------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------- */

static int g_memtracker_enabled;

void *malloc( size_t size )
{
    void        *ptr;

    if ( NULL == old_fopen ) steal_malloc_free();

    ptr = (*old_malloc)(size);

    if ( (NULL != ptr) && g_memtracker_enabled )
    {
        memtracker_record_malloc( &g_mt, ptr, size );
    }

    return( ptr );
}

void *calloc( size_t nmemb, size_t size )
{
    void        *ptr = NULL;
    size_t       bufsiz;

    bufsiz = nmemb * size;
    bufsiz = (bufsiz + 0xf) & ~0xf; /* align the size */

    if ( NULL == old_calloc )
    {
        if ( (calloc_hack_next_buf + bufsiz) <= CALLOC_STEAL_HACK_SIZE )
        {
            ptr = &calloc_hack_region[calloc_hack_next_buf];
            calloc_hack_next_buf += bufsiz;
        }
        else
        {
            fprintf( stderr, "ERR: memtracker calloc(%d,%d) hack region empty %d:%d\n", nmemb, size, calloc_hack_next_buf, CALLOC_STEAL_HACK_SIZE );
        }
    }
    else
    {
        ptr = (*old_calloc)( nmemb, size );
    }

    if ( (NULL != ptr) && g_memtracker_enabled )
    {
        memtracker_record_malloc( &g_mt, ptr, (nmemb * size) );
    }

    return( ptr );
}

int posix_memalign(void **memptr, size_t alignment, size_t size)
{
    int             retval;

    if ( NULL == old_fopen ) steal_malloc_free();

    retval = (*old_posix_memalign)(memptr,alignment,size);
    
    if ( (NULL != *memptr) && g_memtracker_enabled )
    {
        memtracker_record_malloc( &g_mt, *memptr, size );
    }

    return(retval);
}

void *valloc(size_t size)
{
    void        *ptr;

    if ( NULL == old_fopen ) steal_malloc_free();

    ptr = (*old_valloc)(size);

    if ( (NULL != ptr) && g_memtracker_enabled )
    {
        memtracker_record_malloc( &g_mt, ptr, size );
    }

    return( ptr );
}

void *memalign(size_t boundary, size_t size)
{
    void        *ptr;

    if ( NULL == old_fopen ) steal_malloc_free();

    ptr = (*old_memalign)(boundary,size);

    if ( (NULL != ptr) && g_memtracker_enabled )
    {
        memtracker_record_malloc( &g_mt, ptr, size );
    }

    return( ptr );
}

void *realloc(void *ptr, size_t size)
{
    void        *new_ptr;

    if ( NULL == old_fopen ) steal_malloc_free();

    new_ptr = (*old_realloc)(ptr,size);

    if ( (NULL != new_ptr) && g_memtracker_enabled )
    {
        if ( new_ptr != ptr )
        {
            memtracker_record_free( &g_mt, ptr );
            memtracker_record_malloc( &g_mt, new_ptr, size );
        }
    }

    return(new_ptr);
}

void free( void *ptr )
{
    if ( NULL == old_fopen ) steal_malloc_free();
    
    if ( g_memtracker_enabled )
    {
        memtracker_record_free( &g_mt, ptr );
    }

    /* Not within the calloc stealing region */
    if ( (((char *)ptr - calloc_hack_region) < 0) ||
         (((char *)ptr - calloc_hack_region) >= CALLOC_STEAL_HACK_SIZE) )
    {
        (*old_free)(ptr);
    }
}

static void memtracker_flush(
    struct MemTracker   *mt )
{
   struct AllocInfo    *ai = NULL;

   memtracker_block( mt );
   {
      struct TrackerBlock *tb;

      while ( NULL != (tb = (struct TrackerBlock *)mt->mt_first_tb) )
      {
         mt->mt_first_tb = tb->tb_next;

         if ( tb != &g_first_tb )
            (*old_free)(tb);
      }

      /* now clear the whole structure */
      memset( mt, 0, sizeof(*mt) );
      memset( &g_first_tb, 0, sizeof(g_first_tb) );
      mt->mt_first_tb = &g_first_tb;
   }
   memtracker_unblock( mt );
}

static void memtracker_enable(void)
{
	if ( !g_memtracker_enabled )
	{
			/* COPY file /proc/self/maps to memtracker.maps */
			FILE        *map_in,*map_out;
			map_in = (*old_fopen)("/proc/self/maps","r");
			if ( NULL != map_in )
			{
				map_out = (*old_fopen)("memtracker.maps","w+");
				if ( NULL != map_out )
				{
					size_t      i;
					char        copy_buf[128];

					printf("memtracker: copying /proc/self/maps to memtracker.maps\n");
					
					while ( (i = fread(copy_buf,1,128,map_in)) > 0 )
					{
							if ( i != fwrite(copy_buf,1,i,map_out) )
							{
								/* error, write not the same size as the read */
								printf("memtracker: ERROR: while copying\n");
								break;
							}
					}

					fclose(map_out);
				} else printf("could not fopen(\"memtracker.maps\",\"w+\")\n");
				
				fclose(map_in);
			} else printf("could not fopen(\"/proc/self/maps\",\"r\")\n");

			printf("memtracker enabled\n");
	}
	g_memtracker_enabled = 1;
}

FILE *fopen(const char *path, const char *mode)
{
    FILE    *fp;
    
    if ( NULL == old_fopen ) steal_malloc_free();

    fp = (*old_fopen)(path,mode);

    if ( (NULL != path) )
    {
        if ( !strcmp( path, "memtracker/enable" ) )
        {
		  		memtracker_enable();
        }
        else if ( !strcmp( path, "memtracker/disable" ) )
        {
            if ( g_memtracker_enabled ) printf("memtracker disabled\n");
            g_memtracker_enabled = 0;
        }
        else if ( !strcmp( path, "memtracker/flush" ) )
        {
            memtracker_flush( &g_mt );
        }
        else if ( !strcmp( path, "memtracker/summary" ) )
        {
            memtracker_report( &g_mt, 0 );
        }
        else if ( !strcmp( path, "memtracker/report" ) )
        {
            memtracker_report( &g_mt, 1 );
        }
    }
    
    return(fp);
}
/* -------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------- */
/* Shared code library initialization hacks */
__attribute__((constructor)) static void memtracker_lib_init(void)
{
	//memtracker_enable(); /* causes a segfault if enabled */
}

 __attribute__((destructor)) static void memtracker_lib_deinit(void)
{
   /* DO NOT CALL DEINIT: All memory will be freed for this process when it is torn down */
   //memtracker_report( &g_mt, 1 );
}


#else

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

static void *function_two()
{
   void *p;
   p = malloc(42);
   strcpy(p,"function_two_mem");
   return( p );
}

static void *function_one()
{
   return(function_two());
}

/** send_memtracker_command
 * The memtracker library is controlled through an override of the fopen()
 * function.  It looks for filenames, "memtracker/__command__" and will respond
 * In case memtracker is not loaded, or those files _actually_ exist we make sure
 * we close the file if the fopen() actually succeeds. */\
static void send_memtracker_command( const char *cmd )
{
   FILE        *fp;
   if ( NULL != (fp = fopen( cmd, "r" )) )
   {
      fclose(fp);
   }
}

/* To build :
* gcc -Wall memtrack.c -o memtracker_test
* bash>LD_PRELOAD="./memtrack.so" ./memtracker_test
*/
int main ( int argc, char *argv[] )
{
    int             err = 0;
    void            *foo;
    
    foo = malloc( 0x1234 );

    free(foo);

    send_memtracker_command("memtracker/enable");

    foo = malloc( rand() % 1024 ); 
    function_one();
    
    foo = malloc( rand() % 1024 ); printf("foo = %p\n", foo );
    foo = malloc( rand() % 1024 ); printf("foo = %p free\n", foo );  free(foo);
    foo = malloc( rand() % 1024 ); printf("foo = %p\n", foo );
    foo = malloc( rand() % 1024 ); printf("foo = %p\n", foo );

    send_memtracker_command("memtracker/summary");
    send_memtracker_command("memtracker/report");
    printf("------------- flush -------------\n");
    send_memtracker_command("memtracker/flush");
    send_memtracker_command("memtracker/report");

    foo = malloc( rand() % 1024 ); printf("foo = %p free\n", foo );  free(foo);
    foo = malloc( rand() % 1024 ); printf("foo = %p\n", foo );
    foo = malloc( rand() % 1024 ); printf("foo = %p\n", foo );

    send_memtracker_command("memtracker/report");
    send_memtracker_command("memtracker/summary");
    send_memtracker_command("memtracker/report");
    
    return(err);
}
#endif
