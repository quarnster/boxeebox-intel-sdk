/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include <string.h>
#include <stdlib.h>

/**
 * @brief         Print structure elements with a special formatting string
 *
 * @param         str         : Character string buffer to write into
 * @param         fmt         : Special struct-printing Format String
 *                          example: "reg_offset @8%08x value @12%08x"
 * @param         ptr         : Pointer to struct
 *
 * @returns number of characters written to str
 *
 * @code
 * @endcode
 *
 */
#define 							max_tokens 	20

struct 	token_vals
{
	char*					token_name;
	unsigned int 				offset;
	unsigned int 				output_size;
	char 					output_type;
	char*					sizestr;
	char*					offsetstr;
};


int struct_sprintf(
   					 char            *str,
    					 const char      *fmt,
    					 const void      *struct_ptr )
{
	struct token_vals 							*tokens[max_tokens];
	int 										commandlength;
	char 									copyCommand[1024];
	char 									copyagain[1024];
	int 										offset_tokens[20];
	char 									*endptr;
	int 										i, j , token = 0;
	int 										offset_num = 0;
	int 										num_tokens = 0;
	int 										index = 0;
	int 										beginArg = 0;
	int 										done = 0;
	int 										tempToken;

	printf("I am in struct_printf What the F*** is going on\n");


	
	for (i =0; i <max_tokens; i++)
	{
			tokens[i] = (struct token_vals *)calloc(1, sizeof(struct token_vals));
			if (NULL != (tokens[i]->token_name = (char *)calloc(1, 128 * sizeof(char))))
				{
				}
			else break;
			if(NULL != (tokens[i]->sizestr = (char *)calloc(1, 32 * sizeof(char))))
				{
				}
			else break;
			if(NULL != (tokens[i]->offsetstr = (char *)calloc(1, 32 * sizeof(char))))
			{
			}
		else break;
	}

	if((commandlength = strlen(fmt)) >= 1024)
		printf("Command string cannot be more than 1024 characters\n");
	else
		strcpy(copyCommand, fmt);
		strcpy(copyagain, copyCommand);
		copyCommand[commandlength] = '\0';
		copyagain[commandlength] = '\0';
	while((!done) && (index <= commandlength))	
		 {
		 if(':' == copyagain[index] || '\0' == copyagain[index] || ' ' ==copyagain[index] || '%' == copyagain[index])
		 {
			if (copyagain[index] == '\0')
			{
			done = 1;
			break;
			}
			if (':'== copyagain[index])
			{
				copyCommand[index] = '\0';
				strcpy(tokens[token]->token_name, copyCommand + beginArg);
			}
			if(':' == copyagain[index] && '@' == copyagain[index + 1])
			{
				int temp =0;
				temp = index;
				while ( !(copyagain[temp] == '%'))
					temp++;
				if (2 == (index -temp))
				{
				offset_tokens[offset_num] = copyagain[index + 2] - 48;
				tokens[token]->offset = copyagain[index + 2] -48;
				}
				else
				{	
					copyCommand[temp] = '\0';
					strcpy(tokens[token]->offsetstr,copyCommand + index + 2);
					tokens[token]->offset =	strtoul(tokens[token]->offsetstr, &endptr, 0);
				}
			
				offset_num += 1;
			}
			if ('%' == copyagain[index])
			{
				int temp = 0;
				temp = index;
				
				while ( !((copyagain[temp] == 'x')|| (copyagain[temp] == 'd') || (copyagain[temp] == 'c') || (copyagain[temp] == 's')))
					temp++;
				
				if ( 1 == (temp -index))
					tokens[token]->output_size = copyagain[index + 2] -48;
				else
				{
					copyCommand[temp] = '\0';
					strcpy(tokens[token]->sizestr, copyCommand + index + 1);
					tokens[token]->output_size =	strtoul(tokens[token]->sizestr, &endptr, 16);
				}
					tokens[token]->output_type = copyagain[temp];
			}
			if (' ' == copyagain[index])
			{			
				tempToken = num_tokens + 1;
				token += 1;
			}
			num_tokens += 1;
			index++;		
			beginArg = index;		

		}
		else
		{
		index++;
		}
		} 
	
	
		for ( j =0; j <= token; j++)
		{
//			printf("Stored Values are %s : %d : %d : %c", tokens[j]->token_name, tokens[j]->output_size, tokens[j]->offset, tokens[j]->output_type);
			sprintf(str, "%s  %s:", str , tokens[j]->token_name);
			switch (tokens[j]->output_type)
				{
				case ('x'):
					if (tokens[j]->output_size == 4)
						{
						sprintf(str, "%s""%4x",str, *(unsigned short *)((char *)struct_ptr + tokens[j]->offset));
						break;
						}
					if(tokens[j]->output_size == 8)
						{
						sprintf(str, "%s%8x",str, *(unsigned int * )((char *)struct_ptr + tokens[j]->offset));
						break;
						}
					if(tokens[j]->output_size == 16)
						{
						sprintf(str, "%s%16x", str,*(unsigned long long * )((char *)struct_ptr + tokens[j]->offset));
						break;
						}
					else break;
				case ('X'):
					if (tokens[j]->output_size == 4)
						{
						sprintf(str, "%s""%4x",str, *(unsigned short *)((char *)struct_ptr + tokens[j]->offset));
						break;
						}
					if(tokens[j]->output_size == 8)
						{
						sprintf(str, "%s%8x",str, *(unsigned int * )((char *)struct_ptr + tokens[j]->offset));
						break;
						}
					if(tokens[j]->output_size == 16)
						{
						sprintf(str, "%s%16x", str,*(unsigned long long * )((char *)struct_ptr + tokens[j]->offset));
						break;
						}
					else break;
				case ('d'):
						sprintf(str, "%s%d",str, *(int *)((char *)struct_ptr + tokens[j]->offset));
						break;
				case ('D'):
						sprintf(str, "%s%d",str, *(int *)((char *)struct_ptr + tokens[j]->offset));
						break;
				case ('c'):
						sprintf(str, "%s%c",str, *((char *)struct_ptr + tokens[j]->offset));
						break;
				case ('C'):
						sprintf(str, "%s%c",str, *((char *)struct_ptr + tokens[j]->offset));
						break;
				
				default:
						sprintf(str, "Unspecified format Assuning unsigned int%s%x",str, *(unsigned int *)((char *)struct_ptr + tokens[j]->offset));
						break;
				}
		}

	/*Free UP all the Tokens Now*/
		for (i = 0 ; i < max_tokens; i++)
			free(tokens[i]);
		
	return(0);
}

	



#ifdef EXAMPLE_USAGE

struct MyStruct
{
    char						foo;
    unsigned int        		   	bar;
    unsigned short        			alpha;
    char        					beta;
};

int main ( int argc, char *argv[] )
{
    struct MyStruct ms;
    char            outstr[512];

    ms.foo      = 'y';
    ms.bar      = 0x89abcdef;
    ms.alpha    = 0xa1a2;
    ms.beta     = 'x';

    /* reference
     * http://www.cplusplus.com/ref/cstdio/sprintf.html
     */
    
    /*  example: "bar:@4%08x"
     *
     *  @4   - at offset 4 (bytes) into struct ptr, sprintf
     *  %08x - the unsigned int
     *
     */

    struct_sprintf( outstr, "foo:@0%c bar:@4%08x alpha:@8%04x beta:@10%c", &ms );

    printf("%s\n", outstr );
    
    /** output should read
     *
     *  foo:01234567 bar:0x89abcdef alpha:a1a2 beta:b1b2
     *
     */
    
    return(0);
}

#endif
