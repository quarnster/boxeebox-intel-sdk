/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include "sven.h"
#include "sven_devh.h"
#include "osal_memory.h"
#include "pal.h"
#include "sven_fw_globals.h"

#ifndef SVEN_RBD_LOOKUP
#include "rbd_lookup.h"
#endif

#include <auto_eas/gen3_dfx.h>

#ifdef __KERNEL__
   #include <linux/kernel.h> /* printk() */
#endif

/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */

extern const struct RegisterBankDescriptor *pal_get_rbd_table(
   int                  *rbd_size );

#define NEXT_RBD( rbd, rbd_size )   ((const struct RegisterBankDescriptor *) ((const char *)rbd + rbd_size ))

/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */
static volatile unsigned int *g_sven_dfx_regs;
static volatile unsigned int  g_sven_dfx_regs_pa;

#ifdef __KERNEL__
       volatile unsigned int *g_sven_dfx_hot;
#else
static volatile unsigned int *g_sven_dfx_hot;
#endif
       volatile unsigned int *g_sven_dfx_time;     /* actual global */
static volatile unsigned int *g_sven_dfx_inc_tx;
static volatile unsigned int *g_sven_dfx_cur_tx;

static struct SVEN_FW_Globals g_sven_fw_globals;

#if defined(__i386__) || defined(__x86_64__)
   #define TIMESTAMP_FREQ_IN_KHZ   781
#else
   #define TIMESTAMP_FREQ_IN_KHZ   1500
#endif
unsigned int g_sven_timestamp_frequency = TIMESTAMP_FREQ_IN_KHZ * 1000;

/* This is the XSI Bus Frequency (in MHz) - 1
   TODO:
   Ideally the clock registers (elsewhere on the chip) are interrogated for XSI speed.
   This will work for now, but still need to find the recipe for getting the real XSI speed
*/
#define SVEN_DFX_TIMESTAMP_1MHZ_PRESCALE_GEN3  265
#define SVEN_DFX_TIMESTAMP_1MHZ_PRESCALE_GEN4  399

/** This setting ensure the "hot" flags are stored in DRAM instead of 
 * the DFX unit.  Performance analysis shows host overhead is substantially
 * reduced when the "hot" flag is in cacheable memory.
 */
#define SVEN_HOT_ENABLE_IN_DRAM 1

/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */
/* Timestamp frequency in ticks per second */
unsigned int sven_get_timestamp_frequency(void)
{
   return( g_sven_timestamp_frequency );
}

int sven_init_fw_globals(
   struct SVEN_FW_Globals  *fw_globals )
{
   int         err = -1;

   if ( ((void *)0 != g_sven_dfx_hot) &&
        ((void *)0 != fw_globals) )
   {
      *fw_globals = g_sven_fw_globals;
       err = 0;
   }

   return(err);
}

void sven_handle_dfx_init(
   struct SVENHandle    *svenh,
   struct _SVENHeader   *hdr )
{
   /* Extern DFX Stuff */
   svenh->phot             = g_sven_dfx_hot;
   svenh->ptime            = g_sven_dfx_time;

   if ( NULL != g_sven_dfx_time )
   {
      /* Some drivers user private headers, sven_open_header() is quick */
      if ( sven_open_header() == hdr )
      {
         svenh->pinc          = g_sven_dfx_inc_tx;
         svenh->pcur          = g_sven_dfx_cur_tx;
      }
      else
      {
         svenh->pinc          = &hdr->buffers[svenh->buffnum].svc_pos;
         svenh->pcur          = &hdr->buffers[svenh->buffnum].svc_pos;
      }
   }
   else
   {
      svenh->pinc          = &hdr->buffers[svenh->buffnum].svc_pos;
      svenh->pcur          = &hdr->buffers[svenh->buffnum].svc_pos;
   }
}


int sven_init_dfx_support(
   struct _SVENHeader    *hdr )
{
   pal_result_t                         pal_result;
   pal_soc_info_t                       pal_soc_info;
   const struct RegisterBankDescriptor *rbd;
   int                                  dfx_detected = 0;
   int                                  rbd_size;
   unsigned int                         timestamp_1mhz_prescale = SVEN_DFX_TIMESTAMP_1MHZ_PRESCALE_GEN3;

   /* SETUP Default Registers */
   g_sven_dfx_hot    = (volatile unsigned int *) &hdr->svh_disable_mask_deprecated;
   g_sven_dfx_time   = (volatile unsigned int *) NULL;
   g_sven_dfx_inc_tx = (volatile unsigned int *) &hdr->buffers[0].svc_pos;
   g_sven_dfx_cur_tx = (volatile unsigned int *) &hdr->buffers[0].svc_pos;

   rbd = pal_get_rbd_table( &rbd_size );

    /* Determine if we are on gen3 or 4.  Used to adjust timestamp_freq */
   pal_result = pal_get_soc_info(&pal_soc_info);

   if ( pal_result == PAL_SUCCESS )
   {
      if ( SOC_GENERATION_3 == pal_soc_info.generation )
      {
      }
      else if ( SOC_GENERATION_4 == pal_soc_info.generation )
      {
         timestamp_1mhz_prescale = SVEN_DFX_TIMESTAMP_1MHZ_PRESCALE_GEN4;
      }
      else /* GEN5 */
      {
         timestamp_1mhz_prescale = SVEN_DFX_TIMESTAMP_1MHZ_PRESCALE_GEN4;
         //assert(pal_soc_info.generation == SOC_GENERATION_3);
      }
   }

   /* Scan list of device handles we're aware of */
   while ( NULL != rbd->rbd_name )
   {
      if ( SVEN_module_GEN3_DFX == rbd->rbd_module )
      {
         if ( (0 != rbd->rbd_phys_addr) &&
              (0 != rbd->rbd_size) )
         {
            unsigned char        *regs;

         	if ( NULL != (regs = OS_MAP_IO_TO_MEM_NOCACHE(
                  rbd->rbd_phys_addr, rbd->rbd_size )) )
            {
               g_sven_dfx_regs = (volatile unsigned int *) regs;

               hdr->svh_dfx_physaddr = rbd->rbd_phys_addr;
               hdr->svh_dfx_size = rbd->rbd_size;

               /* HOT Enable, DRAM or DFX Register? */

             #ifdef SVEN_HOT_ENABLE_IN_DRAM

               // leave pointer to "hot" flag in the sven header (DRAM) to eliminate
               // performance difference between reading from DRAM vs DFX Register

             #else /* ! SVEN_HOT_ENABLE_IN_DRAM, use DFX Reg */

               g_sven_dfx_hot    = (volatile unsigned int *)(regs + ROFF_DFX_DBG_SCRATCH);

             #endif

               g_sven_dfx_time   = (volatile unsigned int *)(regs + ROFF_DFX_DBG_TIMESTAMP);
               g_sven_dfx_inc_tx = (volatile unsigned int *)(regs + ROFF_DFX_DBG_COUNT_INC);
               g_sven_dfx_cur_tx = (volatile unsigned int *)(regs + ROFF_DFX_DBG_COUNT_GET);

               /* Set Timestamp Prescale Value */
               *((volatile unsigned int *) ((char *)regs + ROFF_DFX_DBG_PRESCALE))
                  = timestamp_1mhz_prescale;

               /* Only update TX Pos in kernel driver */
               #ifdef __KERNEL__
               *((volatile unsigned int *) ((char *)regs + ROFF_DFX_DBG_COUNT_SET))
                  = hdr->buffers[0].svc_pos;
               #endif

               /* timestamp frequency is in microseconds */
               g_sven_timestamp_frequency = 1000000;

               #ifdef __KERNEL__
                  printk(KERN_INFO "%s():%4i: SVEN DFX Enabled @%08lx:%08lx wpos:%d\n",
                     __func__, __LINE__,
                     (unsigned long) hdr->svh_dfx_physaddr,
                     (unsigned long) hdr->svh_dfx_size,
                     hdr->buffers[0].svc_pos );
               #endif

               dfx_detected = 1;
               break;
            }
         }

         break;
      }
      rbd = NEXT_RBD(rbd,rbd_size);
   }

   /* Initialize SVEN FW Globals */
   /* This is always the LAST Circbuffer "hdr->svh_circbuffer_count" */

   g_sven_fw_globals.en             = (struct SVENEvent *)hdr->buffers[hdr->svh_circbuffer_count - 1].svc_physaddr;
   g_sven_fw_globals.eventbuf_size  = hdr->buffers[hdr->svh_circbuffer_count - 1].svc_size;

   if ( 0 != dfx_detected )
   {
      /* when we've got a DFX Unit present, point to the HW Registers */
      #ifdef SVEN_HOT_ENABLE_IN_DRAM

      g_sven_fw_globals.sven_dfx_hot = (volatile unsigned int *)((int) hdr->svh_hdr_physaddr +
         ((char *)&hdr->svh_disable_mask_deprecated - (char *)hdr));

      #else /* ! SVEN_HOT_ENABLE_IN_DRAM */

      g_sven_fw_globals.sven_dfx_hot      = (volatile unsigned int *)(hdr->svh_dfx_physaddr + ROFF_DFX_DBG_SCRATCH);

      #endif

      g_sven_fw_globals.sven_dfx_time     = (volatile unsigned int *)(hdr->svh_dfx_physaddr + ROFF_DFX_DBG_TIMESTAMP);
      g_sven_fw_globals.sven_dfx_inc_tx   = (volatile unsigned int *)(hdr->svh_dfx_physaddr + ROFF_DFX_DBG_COUNT_INC);
      g_sven_fw_globals.sven_dfx_cur_tx   = (volatile unsigned int *)(hdr->svh_dfx_physaddr + ROFF_DFX_DBG_COUNT_GET);
   }
   else
   {
      /* Otherwise, use phys addrs within the header (but INC will never work) */
      g_sven_fw_globals.sven_dfx_hot = (volatile unsigned int *)((int) hdr->svh_hdr_physaddr +
         ((char *)&hdr->svh_disable_mask_deprecated - (char *)hdr));

      g_sven_fw_globals.sven_dfx_time = (volatile unsigned int *)((int) hdr->svh_hdr_physaddr +
         ((char *)hdr->pad - (char *)hdr));

      g_sven_fw_globals.sven_dfx_inc_tx = (volatile unsigned int *)((int) hdr->svh_hdr_physaddr +
         ((char *)&hdr->buffers[hdr->svh_circbuffer_count - 1].svc_pos - (char *)hdr));

      g_sven_fw_globals.sven_dfx_cur_tx = (volatile unsigned int *)((int) hdr->svh_hdr_physaddr +
         ((char *)&hdr->buffers[hdr->svh_circbuffer_count - 1].svc_pos - (char *)hdr));
   }

   return(dfx_detected);
}
