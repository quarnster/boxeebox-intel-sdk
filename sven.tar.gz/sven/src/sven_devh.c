/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include <stdio.h>        // for sprintf()
#include <sven.h>
#include <sven_protos.h>

#ifndef _CSR_DEFS_H
#include <csr_defs.h>
#endif

#include "osal_memory.h"
#include "osal_pci.h"
#include "osal_sched.h"       // Defines OS_SLEEP macro, useful for debug.

#ifndef SVEN_RBD_LOOKUP
#include "rbd_lookup.h"
#endif

#define SVEN_CONNECT_DEBUG_MESSAGES

#define _DEVIO_CONFIG_TARGET_TSTDRV   1

#include <sven_devh.h>

#ifndef _SVEN_DEVH_INLINE_H
#include <sven_devh_inline.h>
#endif

//#include "private_osal_devio.h"

#ifndef UNUSED_PARAMETER
#define UNUSED_PARAMETER(x)   (void)(x)
#endif

/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */
extern int sven_init_dfx_support( 
   struct _SVENHeader    *hdr );
/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */

static void    null_devh_close(      os_devhandle_t *devh );

/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */

static uint32_t linuser_ReadReg32(    os_devhandle_t *devh, uint32_t reg_offset );
static void     linuser_WriteReg32(   os_devhandle_t *devh, uint32_t reg_offset, uint32_t value );
static uint16_t linuser_ReadReg16(    os_devhandle_t *devh, uint32_t reg_offset );
static void     linuser_WriteReg16(   os_devhandle_t *devh, uint32_t reg_offset, uint16_t value );
static uint8_t  linuser_ReadReg8(     os_devhandle_t *devh, uint32_t reg_offset );
static void     linuser_WriteReg8(    os_devhandle_t *devh, uint32_t reg_offset, uint8_t value );
static uint64_t linuser_ReadReg64(    os_devhandle_t *devh, uint32_t reg_offset );
static void     linuser_WriteReg64(   os_devhandle_t *devh, uint32_t reg_offset, uint64_t value );

static os_devh_ops_t g_linuser_dev_ops = {
sizeof(g_linuser_dev_ops),
null_devh_close,
devh_default_InjectRead,
devh_default_InjectWrite,
linuser_ReadReg32,
linuser_WriteReg32,
linuser_ReadReg16,
linuser_WriteReg16,
linuser_ReadReg8,
linuser_WriteReg8,
linuser_ReadReg64,
linuser_WriteReg64
};

/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */
static uint32_t null_ReadReg32(    os_devhandle_t *devh, uint32_t reg_offset );
static void     null_WriteReg32(   os_devhandle_t *devh, uint32_t reg_offset, uint32_t value );
static uint16_t null_ReadReg16(    os_devhandle_t *devh, uint32_t reg_offset );
static void     null_WriteReg16(   os_devhandle_t *devh, uint32_t reg_offset, uint16_t value );
static uint8_t  null_ReadReg8(     os_devhandle_t *devh, uint32_t reg_offset );
static void     null_WriteReg8(    os_devhandle_t *devh, uint32_t reg_offset, uint8_t value );
static uint64_t null_ReadReg64(    os_devhandle_t *devh, uint32_t reg_offset );
static void     null_WriteReg64(   os_devhandle_t *devh, uint32_t reg_offset, uint64_t value );

static os_devh_ops_t g_null_dev_ops = {
sizeof(g_null_dev_ops),
null_devh_close,
devh_default_InjectRead,
devh_default_InjectWrite,
null_ReadReg32,
null_WriteReg32,
null_ReadReg16,
null_WriteReg16,
null_ReadReg8,
null_WriteReg8,
null_ReadReg64,
null_WriteReg64
};

/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */
#if _DEVIO_CONFIG_TARGET_TSTDRV
static int tstdrv_plx_InjectRead(       os_devhandle_t *devh, const char *param_name, void *pvalue, int len );
static int tstdrv_plx_InjectWrite(      os_devhandle_t *devh, const char *param_name, const void *pvalue, int len );
static uint32_t tstdrv_plx_ReadReg32(   os_devhandle_t *devh, uint32_t reg_offset );
static void     tstdrv_plx_WriteReg32(  os_devhandle_t *devh, uint32_t reg_offset, uint32_t value );

/** Performs printfs to DUT */
static os_devh_ops_t g_tstdrv_plx_dev_ops = {
sizeof(g_tstdrv_plx_dev_ops),
null_devh_close,
tstdrv_plx_InjectRead,
tstdrv_plx_InjectWrite, // file load/save done here
tstdrv_plx_ReadReg32,
tstdrv_plx_WriteReg32,
null_ReadReg16,  /* unimpl */
null_WriteReg16, /* unimpl */
null_ReadReg8,   /* unimpl */
null_WriteReg8,  /* unimpl */
null_ReadReg64,  /* unimpl */
null_WriteReg64  /* unimpl */
};
#endif

#if 0
static uint32_t tstdrv_itp_ReadReg32(    os_devhandle_t *devh, uint32_t reg_offset );
static void     tstdrv_itp_WriteReg32(   os_devhandle_t *devh, uint32_t reg_offset, uint32_t value );
static uint16_t tstdrv_itp_ReadReg16(    os_devhandle_t *devh, uint32_t reg_offset );
static void     tstdrv_itp_WriteReg16(   os_devhandle_t *devh, uint32_t reg_offset, uint16_t value );
static uint8_t  tstdrv_itp_ReadReg8(     os_devhandle_t *devh, uint32_t reg_offset );
static void     tstdrv_itp_WriteReg8(    os_devhandle_t *devh, uint32_t reg_offset, uint8_t value );
static uint64_t tstdrv_itp_ReadReg64(    os_devhandle_t *devh, uint32_t reg_offset );
static void     tstdrv_itp_WriteReg64(   os_devhandle_t *devh, uint32_t reg_offset, uint64_t value );

/** Used For connection from DUT to Host Via TSTDRV to ITP */
static os_devh_ops_t g_tstdrv_itp_dev_ops = {
sizeof(g_tstdrv_itp_dev_ops),
tstdrv_itp_devh_close,
devh_default_InjectRead,
tstdrv_itp_InjectWrite,   /* for sending other ITP commands */
tstdrv_itp_ReadReg32,
tstdrv_itp_WriteReg32,
tstdrv_itp_ReadReg16,
tstdrv_itp_WriteReg16,
tstdrv_itp_ReadReg8,
tstdrv_itp_WriteReg8,
tstdrv_itp_ReadReg64,
tstdrv_itp_WriteReg64
};

/** Used For connection from DUT to Host Via TSTDRV to ITP */
static os_devh_ops_t g_tstdrv_ikos_dev_ops = {
sizeof(g_tstdrv_ikos_dev_ops),
tstdrv_ikos_devh_close,
tstdrv_ikos_InjectRead,
tstdrv_ikos_InjectWrite,
null_ReadReg32,  /* unimpl */
null_WriteReg32, /* unimpl */
null_ReadReg16,  /* unimpl */
null_WriteReg16, /* unimpl */
null_ReadReg8,   /* unimpl */
null_WriteReg8,  /* unimpl */
null_ReadReg64,  /* unimpl */
null_WriteReg64  /* unimpl */
};

static int32_t tcp_itp_ReadReg32(    os_devhandle_t *devh, int reg_offset );
static void    tcp_itp_WriteReg32(   os_devhandle_t *devh, int reg_offset, int32_t value );
static int16_t tcp_itp_ReadReg16(    os_devhandle_t *devh, int reg_offset );
static void    tcp_itp_WriteReg16(   os_devhandle_t *devh, int reg_offset, int16_t value );
static int8_t  tcp_itp_ReadReg8(     os_devhandle_t *devh, int reg_offset );
static void    tcp_itp_WriteReg8(    os_devhandle_t *devh, int reg_offset, int8_t value );
static int64_t tcp_itp_ReadReg64(    os_devhandle_t *devh, int reg_offset );
static void    tcp_itp_WriteReg64(   os_devhandle_t *devh, int reg_offset, int64_t value );

/** Used For connection from Any Machine to DUT ITP Host via TCP Telnet */
static os_devh_ops_t g_tcp_itp_dev_ops = {
sizeof(g_tcp_itp_dev_ops),
tcp_itp_devh_close,
devh_default_InjectRead,
devh_default_InjectWrite,
tcp_itp_ReadReg32,
tcp_itp_WriteReg32,
tcp_itp_ReadReg16,
tcp_itp_WriteReg16,
tcp_itp_ReadReg8,
tcp_itp_WriteReg8,
tcp_itp_ReadReg64,
tcp_itp_WriteReg64
};
#endif


/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */
static os_devhandle_t    g_null_devh_struct;
static os_devhandle_t   *g_null_devh;

static void sven_devh_usermode_lib_set_sven_header(
        struct _SVENHeader    *hdr )
{
   if ( NULL == g_null_devh->devh_svenh.hdr )
   {
      sven_init_dfx_support(hdr);

      sven_attach_handle_to_queue(
         &g_null_devh->devh_svenh, hdr,
         SVEN_CIRCBUFFER_ID_CPU_USER );
    }
}

void sven_devh_usermode_lib_init( void )
{
   g_null_devh = &g_null_devh_struct;
   g_null_devh->devh_ops = &g_null_dev_ops;
   g_null_devh->devh_sven_module = SVEN_module_invalid;
   g_null_devh->devh_sven_unit = 0;
}

void sven_devh_usermode_lib_deinit( void )
{
}

/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */

/** null close function */
static void null_devh_close(      os_devhandle_t *devh )
{
   UNUSED_PARAMETER(devh);
}


static uint32_t linuser_ReadReg32(  os_devhandle_t *devh, uint32_t reg_offset )
{
    return( *(uint32_t *)((char *)devh->devh_regs_ptr + reg_offset) );
}
static void linuser_WriteReg32( os_devhandle_t *devh, uint32_t reg_offset, uint32_t value )
{
    *(volatile uint32_t *)((char *)devh->devh_regs_ptr + reg_offset) = value;
}
static uint16_t linuser_ReadReg16(  os_devhandle_t *devh, uint32_t reg_offset )
{
    return( *(uint16_t *)((char *)devh->devh_regs_ptr + reg_offset) );
}
static void    linuser_WriteReg16( os_devhandle_t *devh, uint32_t reg_offset, uint16_t value )
{
    *(volatile uint16_t *)((char *)devh->devh_regs_ptr + reg_offset) = value;
}
static uint8_t  linuser_ReadReg8(   os_devhandle_t *devh, uint32_t reg_offset )
{
    return( *(uint8_t *)((char *)devh->devh_regs_ptr + reg_offset) );
}
static void    linuser_WriteReg8(  os_devhandle_t *devh, uint32_t reg_offset, uint8_t value )
{
    *(volatile uint8_t *)((char *)devh->devh_regs_ptr + reg_offset) = value;
}
static uint64_t linuser_ReadReg64(  os_devhandle_t *devh, uint32_t reg_offset )
{
    return( *(uint64_t *)((char *)devh->devh_regs_ptr + reg_offset) );
}
static void    linuser_WriteReg64( os_devhandle_t *devh, uint32_t reg_offset, uint64_t value )
{
    *(volatile uint64_t *)((char *)devh->devh_regs_ptr + reg_offset) = value;
}


/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
static uint32_t null_ReadReg32(  os_devhandle_t *devh, uint32_t reg_offset )
{
   UNUSED_PARAMETER(devh);
   UNUSED_PARAMETER(reg_offset);
    return( 0 );
}
static void    null_WriteReg32(  os_devhandle_t *devh, uint32_t reg_offset, uint32_t value )
{
   UNUSED_PARAMETER(devh);
   UNUSED_PARAMETER(reg_offset);
   UNUSED_PARAMETER(value);
}
static uint16_t null_ReadReg16(  os_devhandle_t *devh, uint32_t reg_offset )
{
   UNUSED_PARAMETER(devh);
   UNUSED_PARAMETER(reg_offset);
    return( 0 );
}
static void    null_WriteReg16(  os_devhandle_t *devh, uint32_t reg_offset, uint16_t value )
{
   UNUSED_PARAMETER(devh);
   UNUSED_PARAMETER(reg_offset);
   UNUSED_PARAMETER(value);
}
static uint8_t  null_ReadReg8(   os_devhandle_t *devh, uint32_t reg_offset )
{
   UNUSED_PARAMETER(devh);
   UNUSED_PARAMETER(reg_offset);
    return( 0 );
}
static void    null_WriteReg8(   os_devhandle_t *devh, uint32_t reg_offset, uint8_t value )
{
   UNUSED_PARAMETER(devh);
   UNUSED_PARAMETER(reg_offset);
   UNUSED_PARAMETER(value);
}
static uint64_t null_ReadReg64(  os_devhandle_t *devh, uint32_t reg_offset )
{
   UNUSED_PARAMETER(devh);
   UNUSED_PARAMETER(reg_offset);
    return( 0 );
}
static void    null_WriteReg64( os_devhandle_t *devh, uint32_t reg_offset, uint64_t value )
{
   UNUSED_PARAMETER(devh);
   UNUSED_PARAMETER(reg_offset);
   UNUSED_PARAMETER(value);
}

#if _DEVIO_CONFIG_TARGET_TSTDRV
struct TSTDRV_FileIOCommand
{
    /* File Load is Inject( dev, "TBE.FILE_TO_MEM", &tfio, sizeof(tfio) );
     * File Save is Inject( dev, "TBE.MEM_TO_FILE", &tfio, sizeof(tfio) );
     */
    unsigned int        phys_addr;
    unsigned int        size_in_bytes;
    char                filename[1];
};

static int tstdrv_plx_InjectRead(       os_devhandle_t *devh, const char *param_name, void *pvalue, int len )
{
   UNUSED_PARAMETER(devh);
   UNUSED_PARAMETER(param_name);
   UNUSED_PARAMETER(pvalue);
   UNUSED_PARAMETER(len);
    return( 0 );
}

static int tstdrv_plx_InjectWrite(      os_devhandle_t  *devh, const char *param_name, const void *pvalue, int len )
{
    int             retval = 0;

   UNUSED_PARAMETER(len);

DEVH_FUNC_ENTERED(devh);

    if ( !strcasecmp( param_name, "TBE.FILE_TO_MEM" ) )
    {
        const struct TSTDRV_FileIOCommand *tfio = (const struct TSTDRV_FileIOCommand *) pvalue;
        int                                ack = 0;      /* TSTDRV ack status */

DEVH_AUTO_TRACE(devh);

    printf("\nPLX:%s:Fileload %s 0x%08x 0x%08x\n",
            (char *)devh->devh_os_data, /* "AVO", "AVI", "SYSCTRL" */
            tfio->filename,
            tfio->phys_addr,
            tfio->size_in_bytes );

        // wait for ack status
        scanf("%d", &ack);

DEVH_AUTO_TRACE(devh);

        // Don't modify above return code setting unless ack is an error status
        if ( ack )
        {
DEVH_AUTO_TRACE(devh);
            DEVH_WARN( devh, "PLX FileLoad ACK Fail" );
        }
        else
        {
DEVH_AUTO_TRACE(devh);
            retval = tfio->size_in_bytes;
        }
    }
    else if ( !strcasecmp( param_name, "TBE.MEM_TO_FILE" ) )
    {
        const struct TSTDRV_FileIOCommand *tfio = (const struct TSTDRV_FileIOCommand *) pvalue;
        int                                ack = 0;      /* TSTDRV ack status */

        printf("\nPLX:%s:Filesave %s 0x%08x 0x%08x\n",
            (char *)devh->devh_os_data, /* "AVO", "AVI", "SYSCTRL" */
            tfio->filename,
            tfio->phys_addr,
            tfio->size_in_bytes );

        // wait for ack status
        scanf("%d", &ack);

        if ( ack )
        {
            DEVH_WARN( devh, "PLX FileSave ACK Fail" );
        }
        else
        {
            retval = tfio->size_in_bytes;
        }
    }
    else
    {
    DEVH_WARN(devh, "UnknownInject" );
    DEVH_WARN(devh, param_name );
    }

DEVH_FUNC_EXIT(devh);

    return( retval );
}
static uint32_t tstdrv_plx_ReadReg32(    os_devhandle_t *devh, uint32_t reg_offset )
{
//TSTDRV.pl       ## If we detect an PLX:Read address
//TSTDRV.pl       if ($line =~ /^PLX:Read AVI 0x([0-9a-f]*)/i)
    int32_t         value;
    int             ack = 0;     /* TSTDRV ack status */

DEVH_FUNC_ENTERED(devh);

    // Send TSTDRV Read address message
    printf("\nPLX:%s:Read 0x%08lx\n",
        (char *)devh->devh_os_data, /* "AVO", "AVI", "SYSCTRL" */
        devh->devh_regs_phys_addr + reg_offset );

    // recv TSTDRV stdin data value
    scanf("%x", &value);

    // wait for ack status
    scanf("%d", &ack);

    // Don't modify above return code setting unless ack is an error status
    if ( ack )
    {
        DEVH_WARN( devh, "PLX Read ACK Fail" );
    }

DEVH_FUNC_EXIT(devh);
    return(value);
}

static void    tstdrv_plx_WriteReg32(   os_devhandle_t *devh, uint32_t reg_offset, uint32_t value )
{
    int             ack = 0;     /* TSTDRV ack status */

DEVH_FUNC_ENTERED(devh);

//TSTDRV.pl       ## If we detect an PLX:Write address data
//TSTDRV.pl       if ($line =~ /^PLX:Write AVI 0x([0-9a-f]*) 0x([0-9a-f]*)/i)

    // Send TSTDRV Write address message
    printf("\nPLX:%s:write 0x%08lx 0x%08x\n",
        (char *)devh->devh_os_data, /* "AVO", "AVI", "SYSCTRL" */
        devh->devh_regs_phys_addr + reg_offset,
        value );

    // wait for ack status
    scanf("%d", &ack);

    // Don't modify above return code setting unless ack is an error status
    if ( ack )
    {
        DEVH_WARN( devh, "PLX Write ACK Fail" );
    }

DEVH_FUNC_EXIT(devh);
}
#endif
/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */

/**
 * @brief         Read a parameter (scriptable) from the device handle
 *
 *  This function is used to read named parameters from a device
 *  handle, for example, new registers, configuration information, etc.
 *  This is kind of a catch-all method to allow experimentation and
 *  high-level scripting response to the device handle.
 *
 * @param         devh        : device handle (associated with a PCI device)
 * @param         param_name  : Parameter name to inject.
 * @param         pvalue      : buffer to read into.
 * @param         len         : number of bytes to read
 *
 *  Note that each unique "param_name" has an expected value type, which
 *  the writer and responder must agree upon ahead of time.  "Inject" only
 *  passes the value pointer and does not enforce data types.
 *
 * @returns       Number of bytes read, or number of bytes required if ( NULL == pvalue )
 *
 */
int devh_default_InjectRead(
    os_devhandle_t  *devh,
    const char      *param_name,
    void            *pvalue,
    int              len )
{
    const struct ModuleReverseDefs    *mrd;
    char temp_str[256];

    devh = (NULL != devh) ? devh :  g_null_devh;
   UNUSED_PARAMETER(len);

    DEVH_FUNC_ENTERED(devh);
    sprintf(temp_str, "param_name=%s", param_name);
    DEVH_DEBUG(devh, temp_str);

    // If string starts with REG.
    if (0 == strncasecmp("REG.", param_name, 4))
    {
        // get a ptr to what is after REG.
        const char* param_reg_name = param_name + 4;

  //      sprintf(temp_str, "REG.=%s", param_reg_name);
  //      DEVH_DEBUG(devh, temp_str);

        if ( NULL != (mrd = svenreverse_GetModuleTables( devh->devh_sven_module )) )
        {
            const struct EAS_Register   *reg;

            reg = mrd->mrd_regdefs;

            while ( reg->reg_name )
            {
                if ( !strncasecmp( reg->reg_name, param_reg_name, strlen(reg->reg_name) ) )
                {
                    *(int32_t *)pvalue = devh_ReadReg32( devh, reg->reg_offset );
                    DEVH_FUNC_EXIT(devh);
                    return(4);
                }
                reg++;
            }
        }
    }

    DEVH_FUNC_EXIT(devh);
    return(0);
}

/**
 * @brief         Write a parameter (scriptable) into the device handle
 *
 *  This function is used to write named parameters to a device
 *  handle, for example, new registers, configuration information, etc.
 *  This is kind of a catch-all method to allow experimentation and
 *  high-level scripting response to the device handle.
 *
 * @param         devh        : device handle (associated with a PCI device)
 * @param         param_name  : Parameter name to inject.
 * @param         pvalue      : buffer to read from.
 * @param         len         : number of bytes to write
 *
 *  Note that each unique "param_name" has an expected value type, which
 *  the writer and responder must agree upon ahead of time.  "Inject" only
 *  passes the value pointer and does not enforce data types.
 *
 * @returns       Number of bytes written.
 */
int devh_default_InjectWrite(
    os_devhandle_t  *devh,
    const char      *param_name,
    const void      *pvalue,
    int              len )
{
    const struct ModuleReverseDefs    *mrd;
    char temp_str[256];

   UNUSED_PARAMETER(len);

    devh = (NULL != devh) ? devh :  g_null_devh;

    DEVH_FUNC_ENTERED(devh);
    sprintf(temp_str, "param_name=%s", param_name);
    DEVH_DEBUG(devh, temp_str);

    // If string starts with REG.
    if (0 == strncasecmp("REG.", param_name, 4))
    {
        // get a ptr to what is after REG.
        const char* param_reg_name = param_name + 4;

        if ( NULL != (mrd = svenreverse_GetModuleTables( devh->devh_sven_module )) )
        {
            const struct EAS_Register   *reg;

            reg = mrd->mrd_regdefs;

            while ( reg->reg_name )
            {
                if ( !strncasecmp( reg->reg_name, param_reg_name, strlen(reg->reg_name) ) )
                {
                    devh_WriteReg32( devh, reg->reg_offset, *(const int32_t *) pvalue );
                    DEVH_FUNC_EXIT(devh);
                    return(4);
                }
                reg++;
            }
        }
    }
    DEVH_FUNC_EXIT(devh);
    return(0);
}

/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */


struct OpenRegisterBank
{
    struct OpenRegisterBank         *next;
    struct RegisterBankDescriptor   *orb_rbd;
    int                              orb_lock;
    void                            *orb_va;
    unsigned long                    orb_pa;
    unsigned long                    orb_size;
};

/* --------------------------------------------------------------- */
/* --------------------------------------------------------------- */
static int devhandle_connect_sven(
    os_devhandle_t                 *devh,
    const struct RegisterBankDescriptor  *rbd )
{
    int  retval = 0;

    if ( NULL == devh->devh_svenh.hdr )
    {
        struct _SVENHeader    *hdr;

        if ( NULL != (hdr = sven_open_header()) )
        {
            /* ensure global (NULL) handle is initialized */
            sven_devh_usermode_lib_set_sven_header(hdr);

            sven_attach_handle_to_queue(
                    &devh->devh_svenh, hdr,
                    SVEN_CIRCBUFFER_ID_CPU_USER );

            retval = 1;
        }
    }
   else
   {
      retval = 1;
   }

    if ( devh->devh_svenh.hdr )
    {
        /* any follow-up? */
        if ( NULL != rbd )
        {
               //char debug_str1[64], debug_str2[64];
               //DEVH_DEBUG( devh, "SVEN:RBD_present" );
               //sprintf(debug_str1,"rbd: %X.", rbd);
               //DEVH_DEBUG( devh, debug_str1 );
               //sprintf(debug_str2,"rbd->rbd_module %X.", rbd->rbd_module);
               //DEVH_DEBUG( devh, debug_str2 );
               //fprintf(stderr,"%s  %s.\n", debug_str1, debug_str2);
            /* Find the sVEN Module Reverse Tables */
            devh->devh_mrd = svenreverse_GetModuleTables( rbd->rbd_module );

            if ( devh->devh_mrd )
            {
               #ifdef SVEN_CONNECT_DEBUG_MESSAGES
                  DEVH_DEBUG( devh, "SVEN:MRD_present" );
               #endif
            }
            else  DEVH_DEBUG( devh, "SVEN:MRD_ABSENT" );

            devh->devh_sven_module = rbd->rbd_module;
        }
        else
        {
           #ifdef SVEN_CONNECT_DEBUG_MESSAGES
            DEVH_DEBUG( devh, "SVEN:RBD_ABSENT" );
           #endif
        }
    }

    return(retval);
}


/* --------------------------------------------------------------- */
/* --------------------------------------------------------------- */

static struct OpenRegisterBank *g_first_orb;

static struct OpenRegisterBank *find_orb_phys_addr(
    unsigned long                   pa,
    unsigned long                   size )
{
    struct OpenRegisterBank     *orb;

    orb = g_first_orb;
    while ( orb )
    {
        if ( orb->orb_pa == pa )
        {
            if ( orb->orb_size == size )
            {
                orb->orb_lock++;

                return(orb);
            }
        }

        /* next in global list */
        orb = orb->next;
    }

    if ( NULL != (orb = (struct OpenRegisterBank *)OS_ALLOC(sizeof(*orb))) )
    {
        OS_MEMSET( orb, 0, sizeof(*orb) );

        orb->orb_pa = pa;
        orb->orb_size = size;
        orb->orb_lock++;

        /* MAP the memory */
        if ( NULL != (orb->orb_va = OS_MAP_IO_TO_MEM_NOCACHE( pa, size )) )
        {
printf("[map( 0x%08lx, 0x%08lx ) = 0x%08lx]\n", pa, size, (unsigned long) orb->orb_va );
        }

        /* Link into the head of the list */
        orb->next = g_first_orb;
        g_first_orb = orb;
    }

    return(orb);
}


/* --------------------------------------------------------------- */
/* --------------------------------------------------------------- */
extern const struct RegisterBankDescriptor *pal_get_rbd_table(
   int                  *rbd_size );
#define NEXT_RBD( rbd, rbd_size )   ((const struct RegisterBankDescriptor *) ((const char *)rbd + rbd_size ))
        
int devhandle_connect_pci_bus_dev_fun_bar(
    os_devhandle_t          *devh,
    int                      pci_bus,
    int                      pci_dev,
    int                      pci_fun,
    int                      pci_bar )
{
    int                              retval = 0;
    const struct RegisterBankDescriptor *rbd;
    int                                  rbd_size;
    os_pci_dev_t                     pcidev;
   devhandle_connect_sven(devh,NULL);
   #ifdef SVEN_CONNECT_DEBUG_MESSAGES
      DEVH_FUNC_ENTERED(devh);
   #endif

    rbd = pal_get_rbd_table( &rbd_size );

   /* Scan list of device handles we're aware of */
   while ( NULL != rbd->rbd_name )
   {
        if ( (rbd->rbd_pci_bus == pci_bus) &&
             (rbd->rbd_pci_dev == pci_dev) &&
             (rbd->rbd_pci_fun == pci_fun) &&
             (rbd->rbd_pci_bar == pci_bar) )
        {
            break;
        }
        rbd = NEXT_RBD(rbd,rbd_size);
    }
    if ( NULL == rbd->rbd_name ) rbd = NULL;    /* no match found */


    if ( OSAL_SUCCESS == OS_PCI_DEVICE_FROM_ADDRESS(&pcidev,pci_bus,pci_dev,pci_fun) )
    {
        unsigned int        bar_pa;

        if ( OSAL_SUCCESS == OS_PCI_READ_CONFIG_32( pcidev,
                0x10+(pci_bar<<2),
                &bar_pa ) )
        {
            devh->devh_regs_phys_addr = (unsigned long) bar_pa;

            if ( NULL != rbd )
                devh->devh_regs_size = rbd->rbd_size;
            else
               devh->devh_regs_size = (16 * 1024);

            if ( (0 != devh->devh_regs_phys_addr) &&
                 (0 != devh->devh_regs_size) )
            {
                struct OpenRegisterBank     *orb;

                if ( NULL != (orb = find_orb_phys_addr(bar_pa,devh->devh_regs_size)) )
                {
                    devh->devh_regs_ptr = orb->orb_va;

                    if ( devhandle_connect_sven(devh,rbd) )
                    {
                        retval = 1;
                    }
                }
            }
        }

        OS_PCI_FREE_DEVICE(pcidev);
    }


    #ifdef SVEN_CONNECT_DEBUG_MESSAGES
        DEVH_FUNC_EXIT(devh);
    #endif

    return(retval);
}

int devhandle_connect_physical_address(
    os_devhandle_t          *devh,
    int64_t                  phys_addr,
    int                      regs_size )
{
   int                              retval = 0;
   const struct RegisterBankDescriptor *rbd;
   int                                  rbd_size;
   //char debug_str1[64], debug_str2[64], debug_str3[64];

   devhandle_connect_sven(devh,NULL);
   DEVH_FUNC_ENTERED(devh);

   //sprintf(debug_str1,"devh %8X",devh);
   //DEVH_DEBUG(devh,debug_str1);
   //sprintf(debug_str2,"phys_addr %8X",phys_addr);
   //DEVH_DEBUG(devh,debug_str2);
   //sprintf(debug_str3,"regs_size %8X",regs_size);
   //DEVH_DEBUG(devh,debug_str3);
   //fprintf(stderr,"%s  %s  %s\n", debug_str1, debug_str2, debug_str3 );

   rbd = pal_get_rbd_table( &rbd_size );

   /* Scan list of device handles we're aware of */
   while ( NULL != rbd->rbd_name )
   {
      if ( rbd->rbd_phys_addr == (unsigned long) phys_addr )
      {
         devh_SVEN_WriteModuleEvent( devh, 0,
            rbd->rbd_module,
            rbd->rbd_phys_addr,
            rbd->rbd_size, 
            rbd->rbd_pci_did, 
            rbd->rbd_pci_bar,
            (rbd->rbd_pci_bus << 16) | (rbd->rbd_pci_dev << 8) | rbd->rbd_pci_fun );
         break;
      }
      rbd = NEXT_RBD(rbd,rbd_size);
   }

   //sprintf(debug_str1,"%8X %s", rbd->rbd_phys_addr, rbd->rbd_name );
   //DEVH_DEBUG(devh,debug_str1);
   //fprintf(stderr,"%s\n",debug_str1);

   if ( NULL == rbd->rbd_name ) rbd = NULL;    /* no match found */


   {
      struct OpenRegisterBank     *orb;

      if ( NULL != (orb = find_orb_phys_addr( phys_addr, regs_size)) )
      {
         /* Get Base Address */
         devh->devh_regs_ptr = orb->orb_va;
         devh->devh_regs_phys_addr = phys_addr;
         devh->devh_regs_size = regs_size;

         if ( devhandle_connect_sven(devh,rbd) )
         {
            retval = 1;
         }
      }
      else
      {
         DEVH_WARN( devh, "Can't map phys_addr" );
      }
   }

   DEVH_FUNC_EXIT(devh);
   return(retval);
}

int devhandle_connect_name(
    os_devhandle_t          *devh,
    const char              *devname )
{
    int                              retval = 0;
    const char                      *post_underscore_name;
    const struct RegisterBankDescriptor   *rbd;
    int                                  rbd_size;

    devhandle_connect_sven(devh,NULL);
    #ifdef SVEN_CONNECT_DEBUG_MESSAGES
       DEVH_FUNC_ENTERED(devh);
    #endif

    post_underscore_name = devname;
    for ( retval = 0; ('\0' != devname[retval]); retval++ )
    {
        if ( '_' == devname[retval] )
        {
            post_underscore_name = &devname[retval+1];
            break;
        }
    }
    retval = 0;
    
    /* Scan list of device handles we're aware of */
    rbd = pal_get_rbd_table( &rbd_size );
    while ( NULL != rbd->rbd_name )
    {
        if ( !strcasecmp( devname, rbd->rbd_name ) ||
             !strcasecmp( post_underscore_name, rbd->rbd_name ) )
        {
//printf("rbd:\"%s\"\"%s\"\n", devname, rbd->rbd_name );
            #ifdef SVEN_CONNECT_DEBUG_MESSAGES
               DEVH_DEBUG( devh, rbd->rbd_name  );
               DEVH_DEBUG( devh, "devh:connect found" );
            #endif
            break;
        }

        rbd = NEXT_RBD(rbd,rbd_size);
    }

    /* LOOK THROUGH SVEN MODULES */
    if ( NULL == rbd->rbd_name )    /* We got all the way to the end, no luck */
    {
        /* Try to find the name via SVENModule */
        enum SVEN_Module     module;
        int                  found_match = 0;

        for ( module = 0; module < SVEN_module_MAX; module++ )
        {
            const struct ModuleReverseDefs  *mrd;

            if ( (NULL != (mrd = svenreverse_GetModuleTables(module))) &&
                 (NULL != mrd->mrd_name) )
            {
                int                          i;
                const char                  *post_underscore_mrd_name;

                post_underscore_mrd_name = mrd->mrd_name;
                for ( i = 0; ('\0' != mrd->mrd_name[i]); i++ )
                {
                    if ( '_' == mrd->mrd_name[i] )
                    {
                        post_underscore_mrd_name = &mrd->mrd_name[i+1];
                        break;
                    }
                }

                /* We have a matching name from SVENReverse */
                if ( !strcasecmp( devname, mrd->mrd_name ) ||
                     !strcasecmp( devname, post_underscore_mrd_name ) ||
                     !strcasecmp( post_underscore_name, mrd->mrd_name ) ||
                     !strcasecmp( post_underscore_name, post_underscore_mrd_name ) )
                {
                    #ifdef SVEN_CONNECT_DEBUG_MESSAGES
                       DEVH_DEBUG( devh, mrd->mrd_name  );
                       DEVH_DEBUG( devh, "devh:connect found" );
                    #endif

                    /* Scan list of device handles we're aware of */
                    rbd = pal_get_rbd_table( &rbd_size );
                    while ( NULL != rbd->rbd_name )
                    {
                        if ( rbd->rbd_module == module )
                        {
//printf( "mod:\"%s\" \"%s\":\"%s\" \"%s\"\n", devname, post_underscore_name, mrd->mrd_name, post_underscore_mrd_name  );
                            found_match = 1;
                            break;
                        }

                        rbd = NEXT_RBD(rbd,rbd_size);
                    }

                    if ( found_match ) break;
                }
            }
        }

        if ( !found_match ) rbd = NULL;
    }

//DEVH_ASSERT( devh, rbd );

    if ( NULL != rbd )
    {
        /* Physical address already specified? */
        if ( 0 != rbd->rbd_phys_addr )
        {
            #ifdef SVEN_CONNECT_DEBUG_MESSAGES
            DEVH_DEBUG( devh, "devh:phys_addr" );
            #endif

            retval = devhandle_connect_physical_address( devh,
                       rbd->rbd_phys_addr,
                       rbd->rbd_size );
        }
        else /* else scan the PCI bus */
        {
            #ifdef SVEN_CONNECT_DEBUG_MESSAGES
               DEVH_DEBUG( devh, "devh:pci_bdfb" );
            #endif
            /* Open by BDF */
            if ( 0 != (retval = devhandle_connect_pci_bus_dev_fun_bar( devh,
                rbd->rbd_pci_bus,
                rbd->rbd_pci_dev,
                rbd->rbd_pci_fun,
                rbd->rbd_pci_bar)) )
            {
                devh->devh_regs_size = rbd->rbd_size;
            }
        }
    }
//DEVH_ASSERT( devh, retval );

    #ifdef SVEN_CONNECT_DEBUG_MESSAGES
      DEVH_FUNC_EXIT(devh);
    #endif
    return(retval);
}

/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */

/**
 * @brief         connect the devh using device name and simulate memory
 *
 * @param[out]    devh         : device handle (associated with a PCI device)
 * @param[in]     devname      : Name of device to connect
 * @param[in,out] ptrsimbuffer : Ptr to sim memory, if NULL function will allocate
 * @param[in,out] buffersize   : Size of ptrsimbuffer, if 0, size will be returned
 *
 * @returns       0 if success, non zero for error
 */
int devhandle_connect_sim_name(
    os_devhandle_t          *devh,
    const char              *devname,
    void *                   ptrsimbuffer,
    unsigned long            buffersize )
{
    int                              retval = 0;
    const struct RegisterBankDescriptor   *rbd;
    int                                  rbd_size;
    rbd = pal_get_rbd_table( &rbd_size );

    devhandle_connect_sven(devh,NULL);
    DEVH_FUNC_ENTERED(devh);

    /* Scan list of device handles we're aware of */
    while ( NULL != rbd->rbd_name )
    {
        if ( !strcasecmp( devname, rbd->rbd_name ) )
        {
            devh_SVEN_WriteDebugString( devh, SVEN_DEBUGSTR_Generic, rbd->rbd_name  );
            devh_SVEN_WriteDebugString( devh, SVEN_DEBUGSTR_Generic, "devh:connect found" );
            break;
        }

        rbd = NEXT_RBD(rbd,rbd_size);
    }
    if ( NULL == rbd->rbd_name )
    {
        rbd = NULL;    /* no match found */
        retval = OSAL_NOT_FOUND;
    }

    if ( NULL != rbd )
    {
        if(NULL != ptrsimbuffer)
        {
            devh_SVEN_WriteDebugString( devh, SVEN_DEBUGSTR_Generic, "devh:sim" );
            devh->devh_regs_ptr  = ptrsimbuffer;
            devh->devh_regs_size = buffersize;
        }
        else
        {
            retval = OSAL_NOT_IMPLEMENTED;

            /// @todo devhandle_connect_sim_name - allocate memory when ptrsimbuffer is NULL
            if(buffersize == 0)
            {
                // Allocate based on table
                buffersize = 0;  // TODO return size allocated.
            }
            else
            {
                // TODO: Allocate based on buffersize
            }
        }
    }

    DEVH_FUNC_EXIT(devh);
    return(retval);
}

/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */

/**
 * @brief         Read a 32 bit register at an offset from the device handle
 *
 * @param         devh        : device handle (associated with a PCI device)
 * @param         reg_offset  : byte offset from the device BASE address.
 *
 * @returns       register value
 */
uint32_t devh_ReadReg32(
    os_devhandle_t  *devh,
    uint32_t         reg_offset )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    return( devh_ReadReg32_inline( devh, reg_offset ) );
}

/**
 * @brief         Read a 32 bit register at an offset from the device handle
 *                  polling mode, will only write event if the value read.
 *                  is different from "prev_value"
 *
 * @param         devh        : device handle (associated with a PCI device)
 * @param         reg_offset  : byte offset from the device BASE address.
 * @param         prev_value  : byte offset from the device BASE address.
 *
 * @returns       register value
 */
uint32_t devh_ReadReg32_polling_mode(
    os_devhandle_t  *devh,
    uint32_t         reg_offset,
    uint32_t         prev_value )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    return( devh_ReadReg32_pollingmode_inline( devh, reg_offset, prev_value ) );
}

/**
 * @brief         Write a 32 bit register at an offset from the device handle
 *
 * @param         devh        : device handle (associated with a PCI device)
 * @param         reg_offset  : byte offset from the device BASE address.
 * @param         value       : value to write.
 */
void devh_WriteReg32(
    os_devhandle_t  *devh,
    uint32_t         reg_offset,
    uint32_t         value )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    devh_WriteReg32_inline( devh, reg_offset, value );
}

/**
 * @brief         OR a 32 bit register at an offset from the device handle
 *
 * @param         devh        : device handle (associated with a PCI device)
 * @param         reg_offset  : byte offset from the device BASE address.
 * @param         or_value    : value to OR into the register
 */
void devh_OrBitsReg32(
    os_devhandle_t  *devh,
    uint32_t         reg_offset,
    uint32_t         or_value )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    devh_OrBitsReg32_inline( devh, reg_offset, or_value );
}

/**
 * @brief         AND a 32 bit register at an offset from the device handle
 *
 * @param         devh        : device handle (associated with a PCI device)
 * @param         reg_offset  : byte offset from the device BASE address.
 * @param         and_value   : value to AND into the register
 */
void devh_AndBitsReg32(
    os_devhandle_t  *devh,
    uint32_t         reg_offset,
    uint32_t         and_value )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    devh_AndBitsReg32_inline( devh, reg_offset, and_value );
}

/**
 * @brief         AND then OR a 32 bit register at an offset from the device handle
 *
 * @param         devh        : device handle (associated with a PCI device)
 * @param         reg_offset  : byte offset from the device BASE address.
 * @param         and_value   : value to AND into the register (performed FIRST)
 * @param         or_value    : value to OR into the register (performed SECOND)
 */
void devh_SetMaskedReg32(
    os_devhandle_t  *devh,
    uint32_t         reg_offset,
    uint32_t         and_value,
    uint32_t         or_value )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    devh_SetMaskedReg32_inline( devh, reg_offset, and_value, or_value );
}

/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */

/**
 * @brief         Read a 64 bit register at an offset from the device handle
 *
 * @param         devh        : device handle (associated with a MMR device)
 * @param         reg_offset  : byte offset from the device BASE address.
 *
 * @returns       register value
 */
uint64_t devh_ReadReg64(
    os_devhandle_t  *devh,
    uint64_t         reg_offset )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    return( devh_ReadReg64_inline( devh, reg_offset ) );
}

/**
 * @brief         Read a 64 bit register at an offset from the device handle
 *                  polling mode, will only write event if the value read.
 *                  is different from "prev_value"
 *
 * @param         devh        : device handle (associated with a MMR device)
 * @param         reg_offset  : byte offset from the device BASE address.
 * @param         prev_value  : byte offset from the device BASE address.
 *
 * @returns       register value
 */
uint64_t devh_ReadReg64_polling_mode(
    os_devhandle_t  *devh,
    uint64_t         reg_offset,
    uint64_t         prev_value )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    return( devh_ReadReg64_pollingmode_inline( devh, reg_offset, prev_value ) );
}

/**
 * @brief         Write a 64 bit register at an offset from the device handle
 *
 * @param         devh        : device handle (associated with a MMR device)
 * @param         reg_offset  : byte offset from the device BASE address.
 * @param         value       : value to write.
 */
void devh_WriteReg64(
    os_devhandle_t  *devh,
    uint64_t         reg_offset,
    uint64_t         value )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    devh_WriteReg64_inline( devh, reg_offset, value );
}

/**
 * @brief         OR a 64 bit register at an offset from the device handle
 *
 * @param         devh        : device handle (associated with a MMR device)
 * @param         reg_offset  : byte offset from the device BASE address.
 * @param         or_value    : value to OR into the register
 */
void devh_OrBitsReg64(
    os_devhandle_t  *devh,
    uint64_t         reg_offset,
    uint64_t         or_value )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    devh_OrBitsReg64_inline( devh, reg_offset, or_value );
}

/**
 * @brief         AND a 64 bit register at an offset from the device handle
 *
 * @param         devh        : device handle (associated with a MMR device)
 * @param         reg_offset  : byte offset from the device BASE address.
 * @param         and_value   : value to AND into the register
 */
void devh_AndBitsReg64(
    os_devhandle_t  *devh,
    uint64_t         reg_offset,
    uint64_t         and_value )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    devh_AndBitsReg64_inline( devh, reg_offset, and_value );
}

/**
 * @brief         AND then OR a 64 bit register at an offset from the device handle
 *
 * @param         devh        : device handle (associated with a MMR device)
 * @param         reg_offset  : byte offset from the device BASE address.
 * @param         and_value   : value to AND into the register (performed FIRST)
 * @param         or_value    : value to OR into the register (performed SECOND)
 */
void devh_SetMaskedReg64(
    os_devhandle_t  *devh,
    uint64_t         reg_offset,
    uint64_t         and_value,
    uint64_t         or_value )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    devh_SetMaskedReg64_inline( devh, reg_offset, and_value, or_value );
}

/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */
/**
 * @brief         Write a parameter (scriptable) into the device handle
 *
 *  This function is used to inject undocumentented parameters to a device
 *  handle, for example, new registers, configuration information, etc.
 *  This is kind of a catch-all method to allow experimentation and
 *  high-level scripting response to the device handle.
 *
 * @param         devh        : device handle (associated with a PCI device)
 * @param         param_name  : Parameter name to inject.
 * @param         pvalue      : buffer to read from.
 * @param         len         : number of bytes to write
 *
 *  Note that each unique "param_name" has an expected value type, which
 *  the writer and responder must agree upon ahead of time.  "Inject" only
 *  passes the value pointer and does not enforce data types.
 *
 * @returns       Number of bytes written.
 */
int devh_InjectWrite(
    os_devhandle_t  *devh,
    const char      *param_name,
    const void      *pvalue,
    int              len )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    return( (*devh->devh_ops->InjectWrite)(devh, param_name, pvalue, len) );
}

/**
 * @brief         Read a parameter (scriptable) from the device handle
 *
 *  This function is used to read undocumentented parameters from a device
 *  handle, for example, new registers, configuration information, etc.
 *  This is kind of a catch-all method to allow experimentation and
 *  high-level scripting response to the device handle.
 *
 * @param         devh        : device handle (associated with a PCI device)
 * @param         param_name  : Parameter name to inject.
 * @param         pvalue      : buffer to read into.
 * @param         len         : number of bytes to read.
 *
 *  Note that each unique "param_name" has an expected value type, which
 *  the writer and responder must agree upon ahead of time.  "Inject" only
 *  passes the value pointer and does not enforce data types.
 *
 * @returns       Number of bytes read, or number of bytes required if ( NULL == pvalue )
 *
 */
int devh_InjectRead(
    os_devhandle_t  *devh,
    const char      *param_name,
    void            *pvalue,
    int              len )
{
    devh = (NULL != devh) ? devh :  g_null_devh;
    return( (*devh->devh_ops->InjectRead)(devh, param_name, pvalue, len) );
}

/** Get SVEN Handle for device
 */
struct SVENHandle *devh_SVEN_GetHandle(
    os_devhandle_t            *devh )
{
#ifndef SVEN_DEVH_DISABLE_SVEN
    return( &devh->devh_svenh );
#else
    return( NULL );
#endif
}


/**
 * Set the device handle's SVEN Module and Unit IDs.
 * all future events written will contain the dev handle's
 *
 * @param devh             : device handle (associated with a PCI device)
 * @param sven_module      : enum SVEN_Module (sven_unit.h>
 * @param sven_unit        : unit number, beginning with zero
 *
 */
void devh_SVEN_SetModuleUnit(
    os_devhandle_t          *devh,
    int                      sven_module,
    int                      sven_unit )
{
#ifndef SVEN_DEVH_DISABLE_SVEN
    devh->devh_sven_module = sven_module;
    devh->devh_sven_unit = sven_unit;
#endif
}

/**
 * Set the device handle's dynamic disable mask.
 * this allows for run-time control of which categories of events
 * get recorded.
 *
 * @param devh             : device handle (associated with a PCI device)
 * @param dyn_disable_mask : Mask bits (see SVENHeader_DISABLE_Xxx in sven.h)
 *
 */
void devh_SVEN_SetDynamicDisable(
    os_devhandle_t          *devh,
    unsigned int             dyn_disable_mask )
{
#ifndef SVEN_DEVH_DISABLE_SVEN
    devh->devh_sven_ddis = dyn_disable_mask;
#endif
}

/**
 * @brief         Write a Module-Specific Debug Event to SVEN Nexus.
 *
 *  This is used to throw out a module-specific event to the debug stream
 *
 * @param         devh                  : device handle (associated with a MMR device)
 * @param         module_event_subtype  : Module-Specific event type
 * @param         payload0              : Module-Specific event payload 0
 * @param         payload1              : Module-Specific event payload 1
 * @param         payload2              : Module-Specific event payload 2
 * @param         payload3              : Module-Specific event payload 3
 * @param         payload4              : Module-Specific event payload 4
 * @param         payload5              : Module-Specific event payload 5
 */
void devh_SVEN_WriteModuleEvent(
    os_devhandle_t  *devh,
    int              module_event_subtype,
    unsigned int     payload0,
    unsigned int     payload1,
    unsigned int     payload2,
    unsigned int     payload3,
    unsigned int     payload4,
    unsigned int     payload5 )
{
#ifndef SVEN_DEVH_DISABLE_SVEN
    struct SVENEvent        ev;

    devh = (NULL != devh) ? devh :  g_null_devh;

    if ( ! devh_IsEventHotEnabled(devh,SVENHeader_DISABLE_MODULE) )
        return;

    _sven_initialize_event_top( &ev,
        devh->devh_sven_module,
        devh->devh_sven_unit,
        SVEN_event_type_module_specific,
        module_event_subtype );

    ev.u.se_uint[0]        = payload0;
    ev.u.se_uint[1]        = payload1;
    ev.u.se_uint[2]        = payload2;
    ev.u.se_uint[3]        = payload3;
    ev.u.se_uint[4]        = payload4;
    ev.u.se_uint[5]        = payload5;

    sven_write_event( &devh->devh_svenh, &ev );
#endif
}

/**
 * Write a new SVEN Event
 *
 * @param devh             : device handle (associated with a PCI device)
 * @param ev               : SVEN Event to write
 *
 */
void devh_SVEN_WriteEvent(
    os_devhandle_t          *devh,
    const struct SVENEvent  *ev )
{
#ifndef SVEN_DEVH_DISABLE_SVEN
    devh = (NULL != devh) ? devh :  g_null_devh;

    if ( ! devh_IsEventHotEnabled(devh,0) )
        return;

    sven_write_event( &devh->devh_svenh, ev );
#endif
}

/**
 *
 * Write a short SVEN Debug string, truncating ending characters if necessary.
 *   Event Type will ALWAYS == SVEN_event_type_debug_string.
 *   Only 24 characters will fit inside a SVEN DebugString event.
 *
 * @param devh             : device handle (associated with a PCI device)
 * @param subtype          : enum SVEN_DEBUGSTR_t (e.g. SVEN_DEBUGSTR_FunctionEntered)
 * @param str              : Debug String to write (not to exceed 24 characters)
 *
 */
void devh_SVEN_WriteDebugString(
    os_devhandle_t          *devh,
    int                      subtype,
    const char              *str )
{
#ifndef SVEN_DEVH_DISABLE_SVEN
    devh = (NULL != devh) ? devh :  g_null_devh;

    if ( ! devh_IsEventHotEnabled(devh,SVENHeader_DISABLE_STRINGS) )
        return;

    sven_WriteDebugString(
        &devh->devh_svenh,
        devh->devh_sven_module,
        devh->devh_sven_unit,
        subtype,
        str );
#endif
}

/**
 *
 * Write a short SVEN Debug string, truncating leftmost characters if necessary.
 *   Event Type will ALWAYS == SVEN_event_type_debug_string.
 *   Only 24 characters will fit inside a SVEN DebugString event.
 *
 * @param devh             : device handle (associated with a PCI device)
 * @param subtype          : enum SVEN_DEBUGSTR_t (e.g. SVEN_DEBUGSTR_FunctionEntered)
 * @param str              : Debug String to write (not to exceed 24 characters)
 *
 */
void devh_SVEN_WriteDebugStringEnd(
    os_devhandle_t          *devh,
    int                      subtype,
    const char              *str )
{
#ifndef SVEN_DEVH_DISABLE_SVEN
    #if SVEN_DEVH_CHECK_MODULE_DISABLE
    unsigned int     disable_flags;

    disable_flags = SVENHeader_DISABLE_STRINGS;

    if ( (SVEN_DEBUGSTR_FunctionEntered == subtype) ||
         (SVEN_DEBUGSTR_FunctionExited == subtype) ||
         (SVEN_DEBUGSTR_AutoTrace == subtype) )
    {
       disable_flags |= SVENHeader_DISABLE_FUNCTION;
    }

    devh = (NULL != devh) ? devh :  g_null_devh;

    if ( ! devh_IsEventHotEnabled(devh,disable_flags) )
        return;
    #else
    devh = (NULL != devh) ? devh :  g_null_devh;
    #endif
    sven_WriteDebugStringEnd(
        &devh->devh_svenh,
        devh->devh_sven_module,
        devh->devh_sven_unit,
        subtype,
        str );
#endif
}

/* ---------------------------------------------------------------------- */
/* ---------------------------------------------------------------------- */

/**
 * @brief         Create a DevHandle
 *
 * @param         desc     : "Creation assist" description, or use NULL.  desc
 *                           will be used to arrange for different connection
 *                           methods to the device, Examples:
 *                              "NULL"         - NULL-implementation (no register IO)
 *                              "TSTDRV"       - TSTDRV Output
 *                              "ITP:vrlab007" - Use ITP protocol to DUT
 *                              "HCI:host03"   - Use HCI protocol to DUT host
 *                              "PLX:1"        - Addresses off PLX device localbus
 *
 * @returns       FALSE on failure, TRUE on success
 */
os_devhandle_t *devhandle_factory( const char *desc )
{
    os_devhandle_t *devh;

    if ( NULL != (devh = (os_devhandle_t *)OS_ALLOC(sizeof(*devh))) )
    {
      OS_MEMSET(devh,0,sizeof(*devh));

        if ( NULL == desc )
        {
            devh->devh_ops = &g_linuser_dev_ops;
        }
        else if ( ! strcasecmp( desc, "NULL" ) )
        {
            devh->devh_ops = &g_null_dev_ops;
        }
        else if ( ! strncasecmp( desc, "TSTDRV:", 7 ) )
        {
            /* FORMAT is "TSTDRV:AVO" */
            devh->devh_ops = &g_tstdrv_plx_dev_ops;
            devh->devh_os_data = (void *)&desc[7];  /* "AVO", "SYSCTRL", "AVI", ... */
            //*((const char **)&devh->devh_os_data) = &desc[7];  /* "AVO", "SYSCTRL", "AVI", ... */
        }
        else if ( ! strcasecmp( desc, "TSTDRV" ) )
        {
            devh->devh_ops = &g_tstdrv_plx_dev_ops;
            devh->devh_os_data = "AVI";
        }
        else
        {
            devh->devh_ops = &g_linuser_dev_ops;
        }

      /* Preliminary connect */
      devhandle_connect_sven( devh, NULL );

      if ( NULL != (devh->devh_lock = os_create_lock()) )
      {
      }
    }

    return(devh);
}

/**
 * @brief         Gain Exclusive access to a device handle.
 *
 * @param         devh        : device handle (associated with a MMR device)
 */
void devh_Block(
    os_devhandle_t          *devh )
{
   if ( os_lock( devh->devh_lock ) )
   {
#ifndef SVEN_DEVH_DISABLE_SVEN
        SVEN_FATAL_ERROR(
            &devh->devh_svenh,
            devh->devh_sven_module,
            devh->devh_sven_unit,
            "devh_Block() Failed" );
#endif
   }
}

/**
 * @brief         Release Exclusive access to a device handle.
 *
 * @param         devh        : device handle (associated with a MMR device)
 */
void devh_Unblock(
    os_devhandle_t          *devh )
{
   if ( os_unlock( devh->devh_lock ) )
   {
#ifndef SVEN_DEVH_DISABLE_SVEN
        SVEN_FATAL_ERROR(
            &devh->devh_svenh,
            devh->devh_sven_module,
            devh->devh_sven_unit,
            "devh_Unblock() Failed" );
#endif
   }
}

/**
 * @brief         Delete a DevHandle.  Closing associated resources.
 *
 * @param         devh        : device handle (associated with a MMR device)
 */
void devh_Delete(
    os_devhandle_t          *devh )
{
   (*devh->devh_ops->Close)(devh);

   if ( NULL != devh->devh_lock )
   {
      os_destroy_lock( devh->devh_lock );
      devh->devh_lock = NULL;
   }

    OS_FREE(devh);
}


#ifndef SVEN_DEVH_DISABLE_SVEN
void dump_devh_os_devhandle_t ( os_devhandle_t  *devh )
{
   //typedef struct os_devhandle {
   //    struct os_devh_ops         *devh_ops;             /* Device Operations */
   //    int                         devh_last_error;      /* Last hard error encountered during IO */

   //    os_lock_t                   devh_lock;            /* for app/driver writer mutual exclusion */

   //    void                       *devh_os_data;         /* OS-Specific Register Access info */
   //    void                       *devh_regs_ptr;        /* Register Pointers in memory, if available */
   //    unsigned long               devh_regs_phys_addr;  /* TODO: should be prepped for 64 bits */
   //    unsigned long               devh_regs_size;       /* size of register base */

   //    #ifndef SVEN_DEVH_DISABLE_SVEN
   //    const struct ModuleReverseDefs *devh_mrd;         /* "Reverse" definitions */
   //    struct SVENHandle           devh_svenh;           /* SVEN Handle for recording IOs */
   //    int                         devh_sven_module;     /* e.g. SVEN_module_VR_VCAP */
   //    int                         devh_sven_unit;       /* e.g. 0, 1, 2, .... */
   //    int                         devh_sven_ddis;       /* "dynamic disable" bits */
   //    #else
   //    unsigned long               devh_pad[8];
   //    #endif

   //    unsigned long               devh_reserved[4];     /* reserved, must be NULL */
   //} os_devhandle_t;
   printf("\nDump devh.  devh loc %8X\n", (unsigned int)devh );
   printf(  "Device Operations    %8X\n", (unsigned int)devh->devh_ops );
   printf(  "devh_last_error      %8X\n", (unsigned int)devh->devh_last_error );
   printf(  "devh_lock            %8X\n", (unsigned int)devh->devh_lock );
   printf(  "devh_os_data         %8X\n", (unsigned int)devh->devh_os_data );
   printf(  "devh_regs_ptr        %8X\n", (unsigned int)devh->devh_regs_ptr );
   printf(  "devh_regs_phys_addr  %8X\n", (unsigned int)devh->devh_regs_phys_addr );
   printf(  "devh_regs_size       %8X\n", (unsigned int)devh->devh_regs_size );
   printf(  "devh_mrd             %8X\n", (unsigned int)devh->devh_mrd );
   //printf("devh_svenh           %8X\n",               devh->devh_svenh );
   printf(  "devh_sven_module     %8X\n", (unsigned int)devh->devh_sven_module );
   printf(  "devh_sven_unit       %8X\n\n",(unsigned int)devh->devh_sven_unit );
   fflush(NULL);
} // dump_devh_os_devhandle_t
#endif
