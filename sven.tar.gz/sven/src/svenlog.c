/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef SVEN_H
#include "sven.h"
#endif

#include "sven_protos.h"

#include <stdio.h>
#include <stdlib.h>

#define xstringify(s) stringify(s)
#define stringify(s) #s
#ifdef COMP_VER
char *libsven_version_string = "#@# libsven " xstringify(COMP_VER) " " __DATE__ " " __TIME__;
#else
char *libsven_version_string = "#@# libsven <COMP_VER undefined> Eng Rel";
#endif


#define SVENLOG_MAX_QUEUES          8
#define SVENLOG_TIMESORTS_POOLS     1

#ifndef UNUSED_PARAMETER
#define UNUSED_PARAMETER(x)   (void)(x)
#endif

/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */

/** Internal SVENEvent filter structure for svenlog.c
 */
struct SVENEventFilter
{
	struct SVENEventFilter	*ef_next;
	int						 ef_offset;
	unsigned int			 ef_and_mask;
	unsigned int			 ef_eq_mask;
};

/** Internal user-defined filter for svenlog.c */
struct SVENUserFilter
{
	struct SVENUserFilter	*uf_next;

    int                     (*uf_filter)(
                                struct SVENEvent    *ev,
                                void                *userdata0,
                                void                *useredata1 );

    void                    *uf_userdata0;
    void                    *uf_userdata1;
};


struct SVENTemplateFilter
{
    struct SVENUserFilter    tf_uf;     /* embedded user filter MUST_BE_FIRST */
    int                      tf_hit_retval;
    struct SVENEvent         tf_and_ev; /* significant bits in the template */
    struct SVENEvent         tf_eq_ev;  /* value to compare to */
};

/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */

/** Internal register state recorder for svenlog.c */
struct SVENRegisterState
{
    struct SVENRegisterState    *rs_next;
    unsigned long                rs_phys_addr;
    unsigned int                 rs_curr_written;   /* always maintained */
    unsigned int                 rs_curr_read;      /* always maintained */
    unsigned int                 rs_last_written;   /* only update while !paused */
    unsigned int                 rs_last_read;      /* only update while !paused */
};

#define REG_STATES_PER_PUDDLE   255
/** Internal register state recorder for svenlog.c */
struct SVENRegisterPuddle
{
    struct SVENRegisterPuddle   *srp_next;
    int                          srp_next_rs;
    int                          srp_reserved0;
    int                          srp_reserved1;
    struct SVENRegisterState     srp_rs[REG_STATES_PER_PUDDLE];
};

struct SVENRegisterTracker
{
    /* Cached Register States */
    struct SVENRegisterPuddle   *srt_first_srp;

#define REG_STATES_HASH_SIZE   256
#define REG_STATES_HASH_MASK   (REG_STATES_HASH_SIZE-1)

    struct SVENRegisterState    *srt_regstate[REG_STATES_HASH_SIZE];
};

/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */

/** Internal SVENLog structure for svenlog.c
 */
struct SVENLog
{
   /* Our connection "glue" to the system shared memory pool */
   struct SVENHandle		     svenh[SVENLOG_MAX_QUEUES];
   /* Fast Tracking, always on */
   int                       svenlog_rt_reader_pos[SVENLOG_MAX_QUEUES];
#ifdef SVENLOG_TIMESORTS_POOLS
   struct SVENEvent          svenlog_next_ev[SVENLOG_MAX_QUEUES];
#endif


   int                       svenlog_attached_queues;
   int                       svenlog_trigger_fire_request;
   int                       svenlog_trigger_countdown;
   int                       svenlog_trigger_countdown_default;

   /* Local, filtered, circular buffer of events */
   struct SVENEvent		    *svenlog_local_events;
   unsigned int			     svenlog_local_events_mask;
   unsigned int			     svenlog_local_writer_pos;
   unsigned int			     svenlog_pause_requested;
   int						     svenlog_filter_default;

   unsigned int			     svenlog_local_reader_pos;  /* local reader position */

   struct SVENEventFilter    *svenlog_black_list;	/* Always Ignored */

   struct SVENEventFilter    *svenlog_white_list;	/* Always recorded */

   struct SVENUserFilter     *svenlog_user_list;     /* user filter list */


   /* ---------------------------------------------- */
   struct SVENRegisterTracker   svenlog_srt;           /* register tracker */
};

/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */

static __inline void svenlog_Block(
	struct SVENLog	*svenlog )
{
   UNUSED_PARAMETER(svenlog);
	/* Multi-threaded protection here */
}
static __inline void svenlog_Unblock(
	struct SVENLog	*svenlog )
{
   UNUSED_PARAMETER(svenlog);
	/* Multi-threaded protection here */
}
static __inline void svenregistertracker_Block(
    struct SVENRegisterTracker  *srt )
{
   UNUSED_PARAMETER(srt);
	/* Multi-threaded protection here */
}
static __inline void svenregistertracker_Unblock(
    struct SVENRegisterTracker  *srt )
{
   UNUSED_PARAMETER(srt);
	/* Multi-threaded protection here */
}

static __inline unsigned int svenregistertracker_CalcHash(
    unsigned long       reg_phys_addr )
{
    return(
        ((reg_phys_addr >>  0) & 0xff) +
        ((reg_phys_addr >>  8) & 0xff) +
        ((reg_phys_addr >> 16) & 0xff) +
        ((reg_phys_addr >> 24) & 0xff) );
}

/* ----------------------------------------------------------------- */
/* Current-state information */
/* ----------------------------------------------------------------- */

static struct SVENRegisterState *srt_find_regio_state(
    struct SVENRegisterTracker  *srt,
    unsigned long                reg_phys_addr,
    int                         *pnew )
{
    struct SVENRegisterState    *rs;
    unsigned int                 hash;
    
    /* compute hash value for physical address */
    hash = svenregistertracker_CalcHash( reg_phys_addr );

    svenregistertracker_Block( srt );
    {
        /* go to first item in the hash table */
        rs = srt->srt_regstate[ hash & REG_STATES_HASH_MASK ];

        while ( rs )
        {
            if ( rs->rs_phys_addr == reg_phys_addr )
            {
                /* found it */
                *pnew = 0;  /* indicate old value */
                break;
            }

            rs = rs->rs_next;
        }

        if ( NULL == rs )
        {
            struct SVENRegisterPuddle   *srp;

            /* See if we have space to store another register by physical address */
            if ( (NULL == (srp = srt->srt_first_srp)) ||
                 (srp->srp_next_rs >= REG_STATES_PER_PUDDLE) )
            {
                if ( NULL != (srp = (struct SVENRegisterPuddle *)calloc(1,sizeof(*srp))) )
                {
                    /* insert at head of list */
                    srp->srp_next = srt->srt_first_srp;
                    srt->srt_first_srp = srp;
                }
            }

            /* Now we've got a puddle to grab from */
            if ( NULL != (srp = srt->srt_first_srp) )
            {
                /* new one created */
                rs = &srp->srp_rs[ srp->srp_next_rs++ ];

                *pnew = 1;  /* indicate new recording */
                
                /* Set the physical address */
                rs->rs_phys_addr = reg_phys_addr;

                /* insert RegisterState at head of hash table */
                rs->rs_next = srt->srt_regstate[ hash & REG_STATES_HASH_MASK ];
                srt->srt_regstate[ hash & REG_STATES_HASH_MASK ] = rs;
            }
        }
    }
    svenregistertracker_Unblock( srt );
    
    return( rs );
}

    
/**
 * @brief         INTERNAL to svenlog. Examine a RegIO or PortIO event and keep
 *                track of the register values.
 *
 * @param         svenlog     : struct SVENLog
 * @param         ev          : SVENEvent to examine
 */
static void svenlog_maintain_regio_state(
	struct SVENLog		*svenlog,
	struct SVENEvent	*ev )
{
    struct SVENRegisterState    *rs;
    int                          is_new_state;

    if ( NULL != (rs = srt_find_regio_state(
            &svenlog->svenlog_srt,
            ev->u.se_reg.phys_addr,
            &is_new_state )) )
    {
        if ( is_new_state )  /* We just started tracking this */
        {
            ev->u.se_reg.log_flags |= SVEN_REGIO_LOG_FLAG_PREV_UNKNOWN;
        }

        switch ( ev->se_et.et_subtype )
        {
            case SVEN_EV_RegIo32_Read:
            case SVEN_EV_RegIo16_Read:
            case SVEN_EV_RegIo8_Read:
            case SVEN_EV_RegIo64_Read:
            {
                /* Store the previous value in the event */
                ev->u.se_reg.log_prev = rs->rs_curr_read;

                rs->rs_curr_read = ev->u.se_reg.value;
                if ( is_new_state )
                    rs->rs_curr_written = rs->rs_curr_read;
                if ( ! svenlog->svenlog_pause_requested )
                    rs->rs_last_read = ev->u.se_reg.value;
            }
            break;

            case SVEN_EV_RegIo32_Write:
            case SVEN_EV_RegIo16_Write:
            case SVEN_EV_RegIo8_Write:
            case SVEN_EV_RegIo64_Write:
            {
                /* Store the previous value in the event */
                ev->u.se_reg.log_prev = rs->rs_curr_written;

                rs->rs_curr_written = ev->u.se_reg.value;
                if ( is_new_state )
                    rs->rs_curr_read = rs->rs_curr_written;
                if ( ! svenlog->svenlog_pause_requested )
                    rs->rs_last_written = ev->u.se_reg.value;
            }
            break;

            case SVEN_EV_RegIo32_OrBits:
            {
                /* Store the previous value in the event */
                ev->u.se_reg.log_prev = rs->rs_curr_written;

                rs->rs_curr_written |= ev->u.se_reg.value;
                if ( is_new_state )
                    rs->rs_curr_read = rs->rs_curr_written;
                if ( ! svenlog->svenlog_pause_requested )
                    rs->rs_last_written |= ev->u.se_reg.value;
            }
            break;
            
            case SVEN_EV_RegIo32_AndBits:
            {
                /* Store the previous value in the event */
                ev->u.se_reg.log_prev = rs->rs_curr_written;

                rs->rs_curr_written &= ev->u.se_reg.value;
                if ( is_new_state )
                    rs->rs_curr_read = rs->rs_curr_written;
                if ( ! svenlog->svenlog_pause_requested )
                    rs->rs_last_written = ev->u.se_reg.value;
            }
            break;

            case SVEN_EV_RegIo32_SetMasked:
            {
                /* Store the previous value in the event */
                ev->u.se_reg.log_prev = rs->rs_curr_written;

                rs->rs_curr_written = ev->u.se_reg.value;
                if ( is_new_state )
                    rs->rs_curr_read = rs->rs_curr_written;
                if ( ! svenlog->svenlog_pause_requested )
                    rs->rs_last_written = ev->u.se_reg.value;
            }
            break;

            default:
            {
                //printf("ERR: maintain_regio_state() RegIO Subtype not handled\n");
            }
            break;
        }
    }
}

/* ----------------------------------------------------------------- */
/* ----------------------------------------------------------------- */

/**
 * @brief         Delete a SVENLog
 *
 * @param         svenlog     : SVENLog to delete
 */
void svenlog_Delete(
	struct SVENLog	*svenlog )
{
	struct SVENEventFilter	*ef,*next_ef;

	/* Traverse WHITE list, force-record */
	for ( ef = svenlog->svenlog_white_list; ef; ef = next_ef )
	{
		next_ef = ef->ef_next;
		free(ef);
	}
	for ( ef = svenlog->svenlog_black_list; ef; ef = next_ef )
	{
		next_ef = ef->ef_next;
		free(ef);
	}

	if ( svenlog->svenlog_local_events )
	{
		free( svenlog->svenlog_local_events );
		svenlog->svenlog_local_events = NULL;
	}

	free(svenlog);
}

/**
 * @brief         Run new event through black, white, then user filters
 *                if the event should _not_ be recorded into the local
 *                event capture buffer.
 *
 * @param         svenlog     : struct SVENLog
 * @param         ev          : SVENEvent to check
 *
 * @returns       0 if event should be captured, any other value if it should not
 */
static int svenlog_filter_event(
	struct SVENLog		*svenlog,
	struct SVENEvent	*ev )
{
	struct SVENEventFilter	*ef;
    int                      whitelist_hit = 0;
    int                      blacklist_hit = 0;
    int                      userfilt_hit = 0;

	svenlog_Block( svenlog );
	{
	    /* Traverse WHITE list, FORCE-RECORD */
	    for ( ef = svenlog->svenlog_white_list; ef; ef = ef->ef_next )
	    {
		    if ( ef->ef_eq_mask == (ef->ef_and_mask &
			    *((unsigned int *)((char *)ev + ef->ef_offset)) ) )
		    {
                whitelist_hit = 1;
                break;
		    }
	    }

	    /* Traverse BLACK list, FORCE-IGNORE */
        if ( ! whitelist_hit )
        {
	        for ( ef = svenlog->svenlog_black_list; ef; ef = ef->ef_next )
	        {
		        //if ( ef->ef_eq_mask == (ef->ef_and_mask & ((int *)ev)[ef->ef_offset]) )
		        if ( ef->ef_eq_mask == (ef->ef_and_mask & 
			        *((unsigned int *)((char *)ev + ef->ef_offset)) ) )
		        {
                    blacklist_hit = 1;
                    break;
		        }
	        }
        }

        /* Traverse user filter list */
        if ( ! blacklist_hit )
        {
            struct SVENUserFilter   *uf,*next_uf;

	        for ( uf = svenlog->svenlog_user_list; uf; uf = next_uf )
            {
                /* get next_uf now in case this filter removes
                 * itself during the callback
                 */
                next_uf = uf->uf_next;

                if ( 0 != (userfilt_hit = (*uf->uf_filter)
                        ( ev, uf->uf_userdata0, uf->uf_userdata1 ) ) )
                {
                    break;
                }
            }
        }
    }
    svenlog_Unblock(svenlog);

    if ( whitelist_hit || (userfilt_hit > 0) )
    {
        return(0);	/* force-record */
    }
    else if ( blacklist_hit || (userfilt_hit < 0) )
    {
        return(1);	/* force-ignore */
    }

	return( svenlog->svenlog_filter_default );
}
	
/**
 * @brief         Set the default filter behavior for events that
 *                are not force-accepted or force-rejected by filters
 *
 * @param         svenlog        : struct SVENLog
 * @param         filter_default : 0 to record all, 1 to reject all
 */
void svenlog_set_filter_default(
	struct SVENLog		*svenlog,
	int					 filter_default )
{
	svenlog->svenlog_filter_default = filter_default;
}

/**
 * @brief         Set the number of events to record after the trigger fires
 *
 * @param         svenlog     : struct SVENLog
 */
void svenlog_SetTriggerDelay(
	struct SVENLog		*svenlog,
	unsigned int         svenlog_trigger_delay )
{
    svenlog->svenlog_trigger_countdown_default = svenlog_trigger_delay;
}

/**
 * @brief         Has Capture been paused by external events?
 *
 * @param         svenlog     : struct SVENLog
 *
 * @returns       0 if trigger has not yet fired, 1 if trigger has fired.
 */
int svenlog_IsCapturePaused(
    struct SVENLog		*svenlog )
{
    return( svenlog->svenlog_pause_requested );
}


/**
 * @brief         Pause capture of all Realtime events into local queue
 *
 * @param         svenlog     : struct SVENLog
 */
void svenlog_Pause(
	struct SVENLog	*svenlog )
{
	/* Indicate to observer thread we don't want any new events recorded */
	svenlog->svenlog_pause_requested = 1;
}

/**
 */
static int priv_svenlog_read_next_event(
	struct SVENHandle		*svenh,
	struct SVENEvent		*ev,
	int						*preader_pos )
{
    int                  wpos;
    int                  rpos;

    rpos = *preader_pos;
    wpos = _sven_get_write_position(svenh);

	/* have not caught up? */
	if ( rpos != wpos )
	{
		struct SVENEvent    *from;

		from = _sven_get_event_ptr( svenh, rpos );

        /* Has got to be a better way of doing this */

        /** TODO: We may want to do "lap detection" here to see if
         * the reader has been asleep to long.  Probably the better
         * approach is to do that kind of detection at a higher level
         */
        /* Make sure the generation counter in the tag is what we're
         * expecting to see for our reader position.
         */
        if ( from->se_et.et_gencount == ((rpos >> svenh->event_pos_lsb) & 0x3) )
        {
		    /* Copy the structure out */
		    *ev = *from;

		    /* Advance the reader position */
		    *preader_pos = ++rpos;

		    return(1);	/* event grabbed */
        }
        else if ( (wpos - rpos) > 8 )
        {
		    /* Copy the structure out */
		    *ev = *from;

		    /* Advance the reader position */
		    *preader_pos = ++rpos;

		    return(1);	/* event grabbed */
        }
	}

	return(0);
}

/**
 * @brief         For Debug of "field recorded events", Binary files captured off-site
 *
 * @param         svenlog           : struct SVENLog
 * @param         ev                : SVENEvent to load
 * @param         ignore_filters    : if 1: do not pass event through any active filters
 *
 * @returns       number of new events read.  Note it is possible
 *                that all events were rejected by filtering, and
 *                there would be no new events in the local buffer.
 */
int svenlog_InsertEvent_Locally(
	struct SVENLog		*svenlog,
	struct SVENEvent	*ev,
    int                  ignore_filters )
{
    int         retval = 0;

    if ( ignore_filters )
    {
		svenlog->svenlog_local_events[
			(svenlog->svenlog_local_writer_pos &
			 svenlog->svenlog_local_events_mask) ] = *ev;

		/* increment, svenlog_local_events_mask is used to prevent overflow */
		svenlog->svenlog_local_writer_pos++;

        retval = 1;
    }
    else
    {
        if ( (SVEN_event_type_register_io == ev->se_et.et_type ) ||
             (SVEN_event_type_port_io == ev->se_et.et_type ) )
        {
            svenlog_maintain_regio_state( svenlog, ev );
        }

		if ( ! svenlog_filter_event( svenlog, ev ) )
		{
			svenlog->svenlog_local_events[
				(svenlog->svenlog_local_writer_pos &
				 svenlog->svenlog_local_events_mask) ] = *ev;

			/* increment, svenlog_local_events_mask is used to prevent overflow */
			svenlog->svenlog_local_writer_pos++;

            retval = 1;
		}
	}
    

    return(retval);
}

/**
 * @brief         Read all available RT events into local queue.  This
 *                function is usually periodically called on a dedicated
 *                high-priority thread.
 *
 * @param         svenlog     : struct SVENLog
 *
 * @returns       number of new events read.  Note it is possible
 *                that all events were rejected by filtering, and
 *                there would be no new events in the local buffer.
 */
#ifdef SVENLOG_TIMESORTS_POOLS
int svenlog_CaptureRealTimeEvents_Locally(
	struct SVENLog		*svenlog )
{
	int			        num_events_grabbed = 0;
    int                 qnum;
    int                 pools_with_events_mask;
    int                 minq = 0;
    struct SVENEvent   *ev = NULL;

//#define DEBUG_SVENLOG_TIMESORTS_POOLS
#define SVENLOG_TIMESORT_CONTINUOUSLY_CHECK_POOLS_WHILE_EXECUTING

#ifdef DEBUG_SVENLOG_TIMESORTS_POOLS
    struct SVENEvent    dbg_ev;

    memset( &dbg_ev, 0, sizeof(dbg_ev) );

    dbg_ev.se_timestamp     = sventimestamp();
    dbg_ev.se_et.et_module  = SVEN_module_CPU;
    dbg_ev.se_et.et_type    = SVEN_event_type_module_specific;
    dbg_ev.se_et.et_subtype = 0x80;
    dbg_ev.u.se_uint[0]++;
#endif

#ifdef BOOTSTRAP_DEBUG_ONLY_ENSURE_SVENLOG_GETTING_CALLED
    static int  times_this_func_executed;

    if ( 0xff == (++times_this_func_executed & 0xFF) )
    {
        // Can Only WRITE to USER-MODE event log
        sven_WriteDebugString( &svenlog->svenh[SVEN_CIRCBUFFER_ID_CPU_USER],
            0, 0, SVEN_DEBUGSTR_Generic, "svenlog tick (x256)" );
    }
#endif

    /* Figure out which pools have events waiting to be copied into local memory */
    /* ------------------------------------------------------------------------- */
    pools_with_events_mask = 0;
    /* Initialize the events available in the attached queues */
    for ( qnum = 0; qnum < svenlog->svenlog_attached_queues; qnum++ )
    {
        struct SVENHandle   *svenh;
        int                  de;    /* Delta-events */

        /* LOG LAP Detection!!! */
        svenh = &svenlog->svenh[qnum];

        de = _sven_get_write_position(svenh) - svenlog->svenlog_rt_reader_pos[qnum];
        if ( (unsigned) de > svenh->event_pos_mask )
        {
            /* Zoom to WRITER_POS - (3/4 of pool) */
            svenlog->svenlog_rt_reader_pos[qnum] =
                _sven_get_write_position(svenh) -
                (((svenh->event_pos_mask + 1) >> 1) +
                 ((svenh->event_pos_mask + 1) >> 2) );

            // Can Only WRITE to USER-MODE event log
            sven_WriteDebugString( &svenlog->svenh[SVEN_CIRCBUFFER_ID_CPU_USER],
                0, 0, SVEN_DEBUGSTR_Warning, "svenlog lapped" );
        }


	    if ( priv_svenlog_read_next_event( svenh,
            &svenlog->svenlog_next_ev[qnum],
            &svenlog->svenlog_rt_reader_pos[qnum] ) )
        {
            if ( 0 == pools_with_events_mask )
            {
                minq = qnum;
                ev = &svenlog->svenlog_next_ev[minq];
            }
            else
            {
                if ( (signed int)(svenlog->svenlog_next_ev[qnum].se_timestamp - 
                                  ev->se_timestamp) < 0 )
                {
                    minq = qnum;
                    ev = &svenlog->svenlog_next_ev[minq];
                }
            }

            pools_with_events_mask |= (1<<qnum);
        }
        else
        {
            /* No events in this circular buffer are ready */
        }
    }

    #ifdef DEBUG_SVENLOG_TIMESORTS_POOLS
    if ( pools_with_events_mask != 0 )
    {
        dbg_ev.u.se_uint[0] = minq | (pools_with_events_mask << 8);
        dbg_ev.u.se_uint[1] = ev->se_timestamp;
    }
    #endif

    while ( pools_with_events_mask != 0 )
    {
        struct SVENHandle   *svenh;


		num_events_grabbed++;

        /* write this event into local memory */
        /* ----------------------------------------------------------------------- */
        svenh = &svenlog->svenh[minq];

        /* Reuse event "GENCOUNT" for source queue number so we can correlate
         * timebases from the different queues.
         */
        ev->se_et.et_gencount = minq;
        if ( (SVEN_event_type_register_io == ev->se_et.et_type ) ||
             (SVEN_event_type_port_io == ev->se_et.et_type ) )
        {
            svenlog_maintain_regio_state( svenlog, ev );
        }

		/* Record the event */
		if ( ! svenlog->svenlog_pause_requested )
		{
			if ( ! svenlog_filter_event( svenlog, ev ) )
			{
				svenlog->svenlog_local_events[
					(svenlog->svenlog_local_writer_pos &
					 svenlog->svenlog_local_events_mask) ] = *ev;

				/* increment, svenlog_local_events_mask is used to prevent overflow */
				svenlog->svenlog_local_writer_pos++;
			}
		}

        /* Grab another event from this input queue */
        /* ----------------------------------------------------------------------- */

        /* is yet another event ready for this queue? */
        if ( priv_svenlog_read_next_event( svenh,
            &svenlog->svenlog_next_ev[minq],
            &svenlog->svenlog_rt_reader_pos[minq] ) )
        {
            /* bit will be used */
        }
        else
        {
            /* remove the bit from consideration now */
            pools_with_events_mask &= ~(1<<minq);
        }

        /* Search for smallest timestamp again */
        /* ----------------------------------------------------------------------- */
        ev = NULL;
        for ( qnum = 0; qnum < svenlog->svenlog_attached_queues; qnum++ )
        {
#ifdef SVENLOG_TIMESORT_CONTINUOUSLY_CHECK_POOLS_WHILE_EXECUTING
				/* check previously empty queues for new events arriving while executing this function */
            if ( ! ((1<<qnum) & pools_with_events_mask) )
				{
					if ( priv_svenlog_read_next_event( &svenlog->svenh[qnum],
							&svenlog->svenlog_next_ev[qnum],
							&svenlog->svenlog_rt_reader_pos[qnum] ) )
					{
							pools_with_events_mask |= (1<<qnum);
				        #ifdef DEBUG_SVENLOG_TIMESORTS_POOLS
            				dbg_ev.u.se_uint[5]++;
        					#endif
					}
				}
#endif
            /* there are events here */
            if ( (1<<qnum) & pools_with_events_mask )
            {
                if ( NULL == ev )
                {
                    minq = qnum;
                    ev = &svenlog->svenlog_next_ev[minq];
                }
                else
                {
                    if ( (signed int)(svenlog->svenlog_next_ev[qnum].se_timestamp - 
                                      ev->se_timestamp) < 0 )
                    {
                        minq = qnum;
                        ev = &svenlog->svenlog_next_ev[minq];
                    }
                }
            }
        }

        #ifdef DEBUG_SVENLOG_TIMESORTS_POOLS
        if ( pools_with_events_mask != 0 )
        {
            dbg_ev.u.se_uint[2] = minq | (pools_with_events_mask << 8);
            dbg_ev.u.se_uint[3] = ev->se_timestamp;
            dbg_ev.u.se_uint[4]++;
        }
        #endif

        /* Perform Trigger Fire Mechanisms */
        if ( svenlog->svenlog_trigger_fire_request )
        {
            /* have we counted down the number of events */
            if ( --svenlog->svenlog_trigger_countdown <= 0 )
            {
                /* Pause Capturing */
                svenlog_Pause( svenlog );

                /* Repeal the trigger request */
                svenlog->svenlog_trigger_fire_request = 0;
            }
        }
    }

    #ifdef DEBUG_SVENLOG_TIMESORTS_POOLS
	svenlog->svenlog_local_events[
		(svenlog->svenlog_local_writer_pos &
		 svenlog->svenlog_local_events_mask) ] = dbg_ev;

	/* increment, svenlog_local_events_mask is used to prevent overflow */
	svenlog->svenlog_local_writer_pos++;
    #endif

	return( num_events_grabbed );
}
#else /* ! SVENLOG_TIMESORTS_POOLS */
int svenlog_CaptureRealTimeEvents_Locally(
	struct SVENLog		*svenlog )
{
	int			num_events_grabbed = 0;
    int         qnum;

#if BOOTSTRAP_DEBUG_ONLY_ENSURE_SVENLOG_GETTING_CALLED
    static int  times_this_func_executed;

    if ( 0xff == (++times_this_func_executed & 0xFF) )
    {
        // Can Only WRITE to USER-MODE event log
        sven_WriteDebugString( &svenlog->svenh[SVEN_CIRCBUFFER_ID_CPU_USER],
            0, 0, SVEN_DEBUGSTR_Generic, "svenlog tick (x256)" );
    }
#endif
    
    /* Scan through all attached queues */
    for ( qnum = 0; qnum < svenlog->svenlog_attached_queues; qnum++ )
    {
        struct SVENHandle   *svenh;
        int                  de;    /* Delta-events */
	    struct SVENEvent	 ev;

        /* LOG LAP Detection!!! */
        svenh = &svenlog->svenh[qnum];
        de = _sven_get_write_position(svenh) - svenlog->svenlog_rt_reader_pos[qnum];
        if ( (unsigned int) de > svenh->event_pos_mask )
        {
            /* Zoom to WRITER_POS - (3/4 of pool) */
            svenlog->svenlog_rt_reader_pos[qnum] =
                _sven_get_write_position(svenh) -
                (((svenh->event_pos_mask + 1) >> 1) +
                 ((svenh->event_pos_mask + 1) >> 2) );

            // Can Only WRITE to USER-MODE event log
            sven_WriteDebugString( &svenlog->svenh[SVEN_CIRCBUFFER_ID_CPU_USER],
                0, 0, SVEN_DEBUGSTR_Warning, "svenlog lapped" );
        }
        
	    while ( priv_svenlog_read_next_event( svenh, &ev, &svenlog->svenlog_rt_reader_pos[qnum] ) )
	    {
		    num_events_grabbed++;

            /* Reuse event "GENCOUNT" for source queue number so we can correlate
             * timebases from the different queues.
             */
            ev.se_et.et_gencount = qnum;

            if ( (SVEN_event_type_register_io == ev.se_et.et_type ) ||
                 (SVEN_event_type_port_io == ev.se_et.et_type ) )
            {
                svenlog_maintain_regio_state( svenlog, &ev );
            }

		    /* Record the event */
		    if ( ! svenlog->svenlog_pause_requested )
		    {
			    if ( ! svenlog_filter_event( svenlog, &ev ) )
			    {
				    svenlog->svenlog_local_events[
					    (svenlog->svenlog_local_writer_pos &
					     svenlog->svenlog_local_events_mask) ] = ev;

				    /* increment, svenlog_local_events_mask is used to prevent overflow */
				    svenlog->svenlog_local_writer_pos++;
			    }
		    }
	    }
    }

    /* Perform Trigger Fire Mechanisms */
    if ( svenlog->svenlog_trigger_fire_request )
    {
        /* have we counted down the number of events */
        if ( --svenlog->svenlog_trigger_countdown <= 0 )
        {
            /* Pause Capturing */
            svenlog_Pause( svenlog );

            /* Repeal the trigger request */
            svenlog->svenlog_trigger_fire_request = 0;
        }
    }
    
	return( num_events_grabbed );
}
#endif /* !SVENLOG_TIMESORTS_POOLS */

/**
 * @brief         Resume capture of all Realtime events into local queue.
 *                Note this will update the internal "read" pointer with
 *                the "last written" pointer in the RT Queue, so it is
 *                likely events will have been lost between Paus and Run.
 *
 * @param         svenlog     : struct SVENLog
 */
void svenlog_Run(
	struct SVENLog	*svenlog )
{
	if ( svenlog->svenlog_pause_requested )
	{
        int         qnum;

        /* Scan through all attached queues */
        for ( qnum = 0; qnum < svenlog->svenlog_attached_queues; qnum++ )
        {
		    /* Catch up with latest reader position */
		    svenlog->svenlog_rt_reader_pos[qnum] = _sven_get_write_position( &svenlog->svenh[qnum] );
        }

		/* Un-pause the reading thread */
		svenlog->svenlog_pause_requested = 0;
	}
}

/**
 * @brief         Recover all events from the event queues (typically after reset)
 *
 * @param         svenlog     : struct SVENLog
 */
void svenlog_Recover(
	struct SVENLog	*svenlog )
{
	struct _SVENHeader	*hdr;
    unsigned int         qnum;

    hdr = svenlog->svenh[0].hdr;

    for ( qnum = 0; (qnum < hdr->svh_circbuffer_count) && (qnum < SVENLOG_MAX_QUEUES); qnum++ )
    {
        unsigned int            wpos;

        wpos = _sven_get_write_position( &svenlog->svenh[qnum] );

		/* We've wrapped around more than once */
        if ( wpos > svenlog->svenh[qnum].event_pos_mask )
        {
            /* Start at wraparound */
            svenlog->svenlog_rt_reader_pos[qnum] = wpos - svenlog->svenh[qnum].event_pos_mask;
        }
        else
        {
            /* Start at zero */
            svenlog->svenlog_rt_reader_pos[qnum] = 0;
        }
    }
}

/**
 * @brief         Remove a rudimentary filter from an internal filter queue.
 *
 * @param         svenlog     : struct SVENLog
 * @param         search_ef   : filter to remove.
 * @param         pfirst_ef   : pointer to first filter in internal queue.
 *
 * @returns       1 if filter found, 0 if filter not found
 */
static __inline int svenlog_remove_bwlist_entry(
	struct SVENLog		*svenlog,
	struct SVENEventFilter*search_ef,
	struct SVENEventFilter**pfirst_ef )
{
	int			found_it = 0;

	svenlog_Block( svenlog );
	{
		struct SVENEventFilter	*ef;

		while ( NULL != (ef = *pfirst_ef) )
		{
			if ( ef == search_ef )
			{
				/* unlink from list */
				*pfirst_ef = ef->ef_next;
				found_it = 1;
				break;
			}

			/* Go to next item */
			pfirst_ef = &ef->ef_next;
		}
	}
	svenlog_Unblock( svenlog );

    /* release the filter's memory */
    if ( found_it )
    {
        free(search_ef);
    }
    
	return( found_it );
}

/**
 * @brief         Add a rudimentary filter into an internal filter queue.
 *
 * @param         svenlog        : struct SVENLog
 * @param         event_offset   : byte offset within single SVENEvent
 * @param         event_and_mask : mask of bits to compare to equ_mask
 * @param         event_equ_mask : "positive" result of AND operation
 * @param         pfirst_ef      : pointer to first filter in internal queue.
 *
 * @returns       pointer to struct SVENEventFilter added
 */
static __inline struct SVENEventFilter *svenlog_add_bwlist_entry(
	struct SVENLog		*svenlog,
	int					 event_offset,
	unsigned int		 event_and_mask,
	unsigned int		 event_equ_mask,
	struct SVENEventFilter**pfirst_ef )
{
	struct SVENEventFilter	*ef;

	if ( NULL != (ef = (struct SVENEventFilter *)calloc(1,sizeof(*ef))) )
	{
		ef->ef_and_mask = event_and_mask;
		ef->ef_eq_mask = event_equ_mask;
		ef->ef_offset = event_offset;

		/* Insert at head */
		svenlog_Block( svenlog );
		{
			ef->ef_next = *pfirst_ef;
			*pfirst_ef = ef;
		}
		svenlog_Unblock( svenlog );
	}

	return(ef);
}

/**
 * @brief         Add a rudimentary filter into the White (always record) list.
 *
 * @param         svenlog        : struct SVENLog
 * @param         event_offset   : byte offset within single SVENEvent
 * @param         event_and_mask : mask of bits to compare to equ_mask
 * @param         event_equ_mask : "positive" result of AND operation
 *
 * @returns       pointer to struct SVENEventFilter added
 */
struct SVENEventFilter *svenlog_add_whitelist_filter(
	struct SVENLog		*svenlog,
	int					 event_offset,
	unsigned int		 event_and_mask,
	unsigned int		 event_equ_mask )
{
	return( svenlog_add_bwlist_entry( svenlog,
		event_offset,
		event_and_mask,
		event_equ_mask,
		&svenlog->svenlog_white_list ) );
}

/**
 * @brief         Add a rudimentary filter into the Black (always reject) list.
 *
 * @param         svenlog        : struct SVENLog
 * @param         event_offset   : byte offset within single SVENEvent
 * @param         event_and_mask : mask of bits to compare to equ_mask
 * @param         event_equ_mask : "positive" result of AND operation
 *
 * @returns       pointer to struct SVENEventFilter added
 */
struct SVENEventFilter *svenlog_add_blacklist_filter(
	struct SVENLog		*svenlog,
	int					 event_offset,
	unsigned int		 event_and_mask,
	unsigned int		 event_equ_mask )
{
	return( svenlog_add_bwlist_entry( svenlog,
		event_offset,
		event_and_mask,
		event_equ_mask,
		&svenlog->svenlog_black_list ) );
}

/**
 * @brief         Remove a whitelist filter from internal filter queue.
 *
 * @param         svenlog     : struct SVENLog
 * @param         ef          : filter created by svenlog_add_whiteklist_filter()
 *
 * @returns       1 if filter found, 0 if filter not found
 */
int svenlog_remove_whitelist_filter(
	struct SVENLog		*svenlog,
	struct SVENEventFilter *ef )
{
	return( svenlog_remove_bwlist_entry( svenlog, ef,
		&svenlog->svenlog_white_list ) );
}

/**
 * @brief         Remove a blacklist filter from internal filter queue.
 *
 * @param         svenlog     : struct SVENLog
 * @param         ef          : filter created by svenlog_add_blacklist_filter()
 *
 * @returns       1 if filter found, 0 if filter not found
 */
int svenlog_remove_blacklist_filter(
	struct SVENLog		*svenlog,
	struct SVENEventFilter *ef )
{
	return( svenlog_remove_bwlist_entry( svenlog, ef,
		&svenlog->svenlog_black_list ) );
}

/**
 * @brief         Add a user programmable filter to the logger.
 *
 * @param         svenlog        : struct SVENLog
 * @param         filter         : filter function to call
 * @param         userdata0      : userdata0 to pass to the filter
 * @param         userdata1      : userdata1 to pass to the filter
 *
 * @returns       pointer to struct SVENUserFilter added
 *
 *  Note the filter function gets passed these two userdata pointers
 *  and an event to "sniff".  The return value of this callback indicates
 *  how the event should be handled.  Note your filter is expected to
 *  cooperate with all other added filters in the system.
 *
 *      Your filter callback return values:
 *
 *      retval > 0      - record the event immediately
 *      retval == 0     - indifferent, pass to next user filter.
 *      retval < 0      - reject (don't record) the event immediately
 *
 *
 *  User-filters are called in the order they were added, after
 *  the black and white list filters have run.  Events that are
 *  accepted by the whitelist are seen by the user filters in sequence,
 *  until one of them rejects it by returning (retval < 0).
 *
 */
struct SVENUserFilter *svenlog_add_user_filter(
	struct SVENLog		*svenlog,
    int                (*filter)(
                          struct SVENEvent    *ev,
                          void                *userdata0,
                          void                *userdata1 ),
    void                *userdata0,
    void                *userdata1 )
{
	struct SVENUserFilter	*uf;

	if ( NULL != (uf = (struct SVENUserFilter *)calloc(1,sizeof(*uf))) )
	{
        uf->uf_filter = filter;
        uf->uf_userdata0 = userdata0;
        uf->uf_userdata1 = userdata1;

		/* Insert at head */
		svenlog_Block( svenlog );
		{
			uf->uf_next = svenlog->svenlog_user_list;
			svenlog->svenlog_user_list = uf;
		}
		svenlog_Unblock( svenlog );
	}

	return(uf);
}

/**
 * @brief         Remove a user filter from the logger
 *
 * @param         svenlog        : struct SVENLog
 * @param         filter         : filter created by svenlog_add_user_filter()
 *
 * @returns       pointer to struct SVENUserFilter added
 */
int svenlog_remove_user_filter(
	struct SVENLog		*svenlog,
    struct SVENUserFilter   *filter )
{
	int			found_it = 0;

	svenlog_Block( svenlog );
	{
        struct SVENUserFilter   **puf;
        struct SVENUserFilter    *uf;

        puf = &svenlog->svenlog_user_list;
        
		while ( NULL != (uf = *puf) )
		{
			if ( uf == filter )
			{
				/* unlink from list */
				*puf = uf->uf_next;
				found_it = 1;
				break;
			}

			/* Go to next item */
			puf = &uf->uf_next;
		}
	}
	svenlog_Unblock( svenlog );

    /* release the filter's memory */
    if ( found_it )
    {
        free( filter );
    }
    
	return( found_it );
}


/**
 * @brief         Get a view of the event buffer in increasing time order
 *
 *    Get a view of the internal SVENLog Buffer in increasing time order.
 *
 *    SVENLog captures events in a circular fashion.  This function gives
 *    the application a view into the events before and after the "split"
 *    created when capturing events.
 *
 *    Warning: behavior is unpredictable if the svenlog is not "paused"
 *
 * @param         svenlog              : struct SVENLog *
 * @param         pev0                 : pointer to first block of sven events
 * @param         nev0                 : number of SVEN Events in the first block
 * @param         pev1                 : pointer to second block of sven events
 * @param         nev1                 : number of SVEN Events in the second block
 *
 * @returns       0 for success, error otherwise
 */
int svenlog_view_event_buffer(
	struct SVENLog    *svenlog,
   struct SVENEvent  **pev0,
   int               *nev0,
   struct SVENEvent  **pev1,
   int               *nev1 )
{
   int         wpos;

   /* snapshot the current writer position */
   wpos = (svenlog->svenlog_local_writer_pos & svenlog->svenlog_local_events_mask);

   /* first block of events */
   *pev0 = &svenlog->svenlog_local_events[wpos];
   *nev0 = (svenlog->svenlog_local_events_mask + 1) - wpos;

   /* second block */
   *pev1 = &svenlog->svenlog_local_events[0];
   *nev1 = wpos;
   
   return(0);
}
   

/**
 * @brief         Create and initialize a new SVENLog handle
 *
 * @param         hdr                   : struct _SVENHeader
 * @param         local_eventbuf_size   : how much memory to allocate for local event storage
 *
 * @returns       (struct SVENLog *) or NULL
 */
struct SVENLog *svenlog_Create(
	struct _SVENHeader		*hdr,
	unsigned int			 local_eventbuf_size )
{
	struct SVENLog	*svenlog;

	if ( NULL != (svenlog = (struct SVENLog *)calloc(1,sizeof(*svenlog))) )
	{
		char		    ok = 0;
        unsigned int    qnum;

        svenlog->svenlog_trigger_countdown_default = 16;

        for ( qnum = 0; (qnum < hdr->svh_circbuffer_count) && (qnum < SVENLOG_MAX_QUEUES); qnum++ )
        {
            /* attach to this queue */
            sven_attach_handle_to_queue( &svenlog->svenh[qnum], hdr, qnum );

		      /* Catch up with latest reader position */
		      svenlog->svenlog_rt_reader_pos[qnum] = _sven_get_write_position( &svenlog->svenh[qnum] );

            svenlog->svenlog_attached_queues++;
        }
        
		/* Local event storage */
		if ( NULL != (svenlog->svenlog_local_events = malloc(local_eventbuf_size)) )
		{
			/* convert this from a byte size to a power of two MASK */
			local_eventbuf_size >>= SVEN_EVENT_SIZE_BITS;

			/* WHile NOT a power of two */
			while ( local_eventbuf_size & (local_eventbuf_size-1) )
			{
				local_eventbuf_size &= (local_eventbuf_size-1);
			}

			/* Create a working "local events" buffer */
			svenlog->svenlog_local_events_mask = (local_eventbuf_size - 1);


			/* More init...... */
			ok = 1;
		}

		if ( !ok )
		{
			svenlog_Delete(svenlog);
			svenlog = 0;
		}
	}
	
	return(svenlog);
}


/* ============================================================================= */
/* ============================================================================= */
/* ============================================================================= */
/* ============================================================================= */

/**
 * @brief         Read the next event out of the "local capture" queue.
 *
 * @param         svenlog     : struct SVENLog
 * @param         ev          : SVENEvent to check
 *
 * @returns       0 if event ready, 1 otherwise
 */
int svenlog_ReadNextLocalEvent(
	struct SVENLog		*svenlog,
	struct SVENEvent	*ev )
{
    /* if reader has not caught up */
    if ( svenlog->svenlog_local_reader_pos !=
         svenlog->svenlog_local_writer_pos )
    {
	    *ev = svenlog->svenlog_local_events[
    		    (svenlog->svenlog_local_reader_pos &
	    	     svenlog->svenlog_local_events_mask) ];

		/* increment, svenlog_local_events_mask is used to prevent overflow */
	    svenlog->svenlog_local_reader_pos++;

        return(1);
    }

    return(0);
}

/**
 * @brief         Place the local event reader one full buffer behind the writer.
 *
 * @param         svenlog     : struct SVENLog
 * @param         num_events  : how many events to rewind (0 if all available)
 *
 *     This function should only be called while local capture is Paused.
 *
 */
void svenlog_RewindLocalEventReader( 
	struct SVENLog		*svenlog,
    int                  num_events )
{
    unsigned int        new_reader_pos;

    if ( num_events < 0 )   num_events = -num_events;

    /* only in first iteration of record */
    if ( svenlog->svenlog_local_writer_pos <=
         svenlog->svenlog_local_events_mask )
    {
        if ( num_events )
        {
            if ( svenlog->svenlog_local_writer_pos > (unsigned int) num_events )
            {
                new_reader_pos = svenlog->svenlog_local_writer_pos - num_events;
            }
            else
            {
                new_reader_pos = 0;
            }
        }
        else
        {
            new_reader_pos = 0;
        }
    }
    else
    {
        if ( num_events )
        {
            if ( (unsigned int) num_events > svenlog->svenlog_local_events_mask )
                num_events = svenlog->svenlog_local_events_mask;

            new_reader_pos = svenlog->svenlog_local_writer_pos - num_events;
        }
        else
        {
            /* Zoom a full buffer backwards */
            new_reader_pos =
                 svenlog->svenlog_local_writer_pos -
                 svenlog->svenlog_local_events_mask;
        }
    }

#if 0
printf("SL: siz:0x%x lwp:0x%x lrp:0x%x n-lrp:0x%x\n",
    svenlog->svenlog_local_events_mask,
    svenlog->svenlog_local_writer_pos,
    svenlog->svenlog_local_reader_pos,
    new_reader_pos );
#endif

    svenlog->svenlog_local_reader_pos = new_reader_pos;

}

/**
 * @brief         Write a text string describing the event
 *
 * @param         svenlog     : struct SVENLog
 * @param         ev          : SVENEvent to check
 * @param         str         : Text String for the event
 *
 * @returns       number of characters written to string
 */
int svenlog_GetEventTextString(
	struct SVENLog		*svenlog,
	struct SVENEvent	*ev,
    char                *str )
{
   UNUSED_PARAMETER(svenlog);
    return( sven_reverse_GetEventTextString( str, NULL, ev ) );
}

static int sven_template_filter_callback(
    struct SVENEvent    *ev,
    void                *userdata0,
    void                *userdata1 )
{
//	struct SVENLog              *svenlog = (struct SVENLog *)userdata0;
    struct SVENTemplateFilter   *tf = (struct SVENTemplateFilter *)userdata1;
   UNUSED_PARAMETER(userdata0);

/*
        tst_ev = xx02xxxx
        and_ev = 00ff0000
        t & a  = 00020000
        equ_ev = 00020000
        r ^ equ= 00000000 -- hit

        tst_ev = xx03xxxx
        and_ev = 00ff0000
        t & a  = 00030000
        equ_ev = 00020000
        r ^ equ= 00010000 -- miss

 */
#if ( 6 == SVEN_EVENT_PAYLOAD_NUM_UINTS )
    if ( (((int *)&tf->tf_eq_ev)[0] ^ (((int *)ev)[0] & ((int *)&tf->tf_and_ev)[0])) ||
         (((int *)&tf->tf_eq_ev)[1] ^ (((int *)ev)[1] & ((int *)&tf->tf_and_ev)[1])) ||
         (((int *)&tf->tf_eq_ev)[2] ^ (((int *)ev)[2] & ((int *)&tf->tf_and_ev)[2])) ||
         (((int *)&tf->tf_eq_ev)[3] ^ (((int *)ev)[3] & ((int *)&tf->tf_and_ev)[3])) ||
         (((int *)&tf->tf_eq_ev)[4] ^ (((int *)ev)[4] & ((int *)&tf->tf_and_ev)[4])) ||
         (((int *)&tf->tf_eq_ev)[5] ^ (((int *)ev)[5] & ((int *)&tf->tf_and_ev)[5])) ||
         (((int *)&tf->tf_eq_ev)[6] ^ (((int *)ev)[6] & ((int *)&tf->tf_and_ev)[6])) ||
         (((int *)&tf->tf_eq_ev)[7] ^ (((int *)ev)[7] & ((int *)&tf->tf_and_ev)[7])) )
    {
        return( 0 );
    }
    else
    {
        return( tf->tf_hit_retval );
    }
#else
    #pragma error _TODO_FIX_TEMPLATE_FILTER_COMPARE_FUNCTION_;
    return(0);
#endif
}

static int sven_template_trigger_callback(
    struct SVENEvent    *ev,
    void                *userdata0,
    void                *userdata1 )
{
	struct SVENLog              *svenlog = (struct SVENLog *)userdata0;
    struct SVENTemplateFilter   *tf = (struct SVENTemplateFilter *)userdata1;

#if ( 6 == SVEN_EVENT_PAYLOAD_NUM_UINTS )
    if ( (((int *)&tf->tf_eq_ev)[0] ^ (((int *)ev)[0] & ((int *)&tf->tf_and_ev)[0])) ||
         (((int *)&tf->tf_eq_ev)[1] ^ (((int *)ev)[1] & ((int *)&tf->tf_and_ev)[1])) ||
         (((int *)&tf->tf_eq_ev)[2] ^ (((int *)ev)[2] & ((int *)&tf->tf_and_ev)[2])) ||
         (((int *)&tf->tf_eq_ev)[3] ^ (((int *)ev)[3] & ((int *)&tf->tf_and_ev)[3])) ||
         (((int *)&tf->tf_eq_ev)[4] ^ (((int *)ev)[4] & ((int *)&tf->tf_and_ev)[4])) ||
         (((int *)&tf->tf_eq_ev)[5] ^ (((int *)ev)[5] & ((int *)&tf->tf_and_ev)[5])) ||
         (((int *)&tf->tf_eq_ev)[6] ^ (((int *)ev)[6] & ((int *)&tf->tf_and_ev)[6])) ||
         (((int *)&tf->tf_eq_ev)[7] ^ (((int *)ev)[7] & ((int *)&tf->tf_and_ev)[7])) )
    {
    }
    else
    {
        svenlog_SetTrigger( svenlog );
    }
#else
    #pragma error _TODO_FIX_TEMPLATE_TRIGGER_COMPARE_FUNCTION_;
#endif
    return(0);
}

/**
 * @brief         Add a "template based" filter to the logger.
 *
 * @param         svenlog        : struct SVENLog
 * @param         mask_ev         : Mask of "significant" events
 * @param         eq_ev          : Value (once masked) the event should equal
 * @param         hit_returnval  : Value to return to the filter if template "hit"
 *
 * @returns       pointer to struct SVENUserFilter added
 *
 *  Note the filter function gets passed these two userdata pointers
 *  and an event to "sniff".  The return value of this callback indicates
 *  how the event should be handled.  Note your filter is expected to
 *  cooperate with all other added filters in the system.
 *
 *      Your filter callback return values:
 *
 *      retval > 0      - record the event immediately
 *      retval == 0     - indifferent, pass to next user filter.
 *      retval < 0      - reject (don't record) the event immediately
 *
 *
 *  User-filters are called in the order they were added, after
 *  the black and white list filters have run.  Events that are
 *  accepted by the whitelist are seen by the user filters in sequence,
 *  until one of them rejects it by returning (retval < 0).
 *
 */
struct SVENUserFilter *svenlog_add_template_filter(
	struct SVENLog		      *svenlog,
    const struct SVENEvent    *mask_ev,
    const struct SVENEvent    *eq_ev,
    int                        hit_returnval )
{
    struct SVENTemplateFilter   *tf;
    
	if ( NULL != (tf = (struct SVENTemplateFilter *)calloc(1,sizeof(*tf))) )
	{
        tf->tf_uf.uf_filter = sven_template_filter_callback;
        tf->tf_uf.uf_userdata0 = svenlog;
        tf->tf_uf.uf_userdata1 = tf;
        tf->tf_and_ev = *mask_ev;
        tf->tf_eq_ev = *eq_ev;
        tf->tf_hit_retval = hit_returnval;

		/* Insert at head */
		svenlog_Block( svenlog );
		{
			tf->tf_uf.uf_next = svenlog->svenlog_user_list;
			svenlog->svenlog_user_list = &tf->tf_uf;
		}
		svenlog_Unblock( svenlog );
	}

	return( &tf->tf_uf );
}

/**
 * @brief         Add a "template-based" Trigger to the logger.
 *
 * @param         svenlog        : struct SVENLog
 * @param         mask_ev         : Mask of "significant" events
 * @param         eq_ev          : Value (once masked) the event should equal
 * @param         hit_returnval  : Value to return to the filter if template "hit"
 *
 * @returns       pointer to struct SVENUserFilter added
 *
 *  Note the filter function gets passed these two userdata pointers
 *  and an event to "sniff".  The return value of this callback indicates
 *  how the event should be handled.  Note your filter is expected to
 *  cooperate with all other added filters in the system.
 *
 *      Your filter callback return values:
 *
 *      retval > 0      - record the event immediately
 *      retval == 0     - indifferent, pass to next user filter.
 *      retval < 0      - reject (don't record) the event immediately
 *
 *
 *  User-filters are called in the order they were added, after
 *  the black and white list filters have run.  Events that are
 *  accepted by the whitelist are seen by the user filters in sequence,
 *  until one of them rejects it by returning (retval < 0).
 *
 */
struct SVENUserFilter *svenlog_add_template_trigger(
	struct SVENLog		      *svenlog,
    const struct SVENEvent    *mask_ev,
    const struct SVENEvent    *eq_ev )
{
    struct SVENTemplateFilter   *tf;
    
	if ( NULL != (tf = (struct SVENTemplateFilter *)calloc(1,sizeof(*tf))) )
	{
        tf->tf_uf.uf_filter = sven_template_trigger_callback;
        tf->tf_uf.uf_userdata0 = svenlog;
        tf->tf_uf.uf_userdata1 = tf;
        tf->tf_and_ev = *mask_ev;
        tf->tf_eq_ev = *eq_ev;

		/* Insert at head */
		svenlog_Block( svenlog );
		{
			tf->tf_uf.uf_next = svenlog->svenlog_user_list;
			svenlog->svenlog_user_list = &tf->tf_uf;
		}
		svenlog_Unblock( svenlog );
	}

	return( &tf->tf_uf );
}

/**
 * @brief         Fire all svenlog trigger mechanisms.
 *
 * @param         svenlog        : struct SVENLog
 *
 */
void svenlog_SetTrigger( 
	struct SVENLog		      *svenlog )
{
    if ( ! svenlog->svenlog_trigger_fire_request )
    {
        /* Set event countdown */
        svenlog->svenlog_trigger_countdown = svenlog->svenlog_trigger_countdown_default;
        svenlog->svenlog_trigger_fire_request = 1;

        printf("SVENLog:Trigger Fired, capturing an additional %d events\n", svenlog->svenlog_trigger_countdown );
    }
}


#define SVENLOG_LOCAL_EVENTBUF_SIZE (1 * 1024 * 1024)

//#define ENABLE_SVENLOG_WHILE_WRITE_EVENT_VERY_DANGEROUS

#ifdef ENABLE_SVENLOG_WHILE_WRITE_EVENT_VERY_DANGEROUS
int Output_SVEN_log_locally = 0;
struct SVENLog * SVEN_log = NULL;
#endif

////////////////////////////////////////////////////////////////////////////////
/// @brief        Makes sven log come out locally.
////////////////////////////////////////////////////////////////////////////////
void Set_Output_SVEN_log_locally(int logLocal)
{
#ifdef ENABLE_SVENLOG_WHILE_WRITE_EVENT_VERY_DANGEROUS
   static struct _SVENHeader * SVEN_hdr = NULL;

   Output_SVEN_log_locally = logLocal;
      // If not suppose to output or already initialized then return.
   if ( !Output_SVEN_log_locally || SVEN_hdr != NULL ) return;

      // Set up the parameters needed by:
      //    int svenlog_GetEventTextString(struct SVENLog		*svenlog,
      //                                   struct SVENEvent	*ev, char  *str )

   if ( NULL == (SVEN_hdr = sven_open_header()) )
   {
      fprintf(stderr,"Error Set_Output_SVEN_log_locally: sven_open_header().\n");
   }
   else if ( NULL == (SVEN_log = svenlog_Create( SVEN_hdr, SVENLOG_LOCAL_EVENTBUF_SIZE )) )
   {
      fprintf(stderr,"Error Set_Output_SVEN_log_locally: svenlog_Create().\n");
   }
#else
   UNUSED_PARAMETER(logLocal);
#endif /* ENABLE_SVENLOG_WHILE_WRITE_EVENT_VERY_DANGEROUS */
   
} // Set_Output_SVEN_log_locally()
