#
#  This file is provided under a dual BSD/GPLv2 license.  When using or 
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright (c) 2006-2008. Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify 
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but 
#  WITHOUT ANY WARRANTY; without even the implied warranty of 
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License 
#  along with this program; if not, write to the Free Software 
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution 
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  97052
#
#  BSD LICENSE 
#
#  Copyright (c) 2006-2008. Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without 
#  modification, are permitted provided that the following conditions 
#  are met:
#
#    * Redistributions of source code must retain the above copyright 
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright 
#      notice, this list of conditions and the following disclaimer in 
#      the documentation and/or other materials provided with the 
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its 
#      contributors may be used to endorse or promote products derived 
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

RET_VAL=0

print_usage()
{
   echo "Usage: $0 (<options to pass to HOMIE.sh>)"
   echo "       $0 --sysinfo                      : Print system info "
   echo "       $0 --help | -h                    : Print usage info "
   echo ""
   echo "This script will start csven health mode, if a AV freeze (delay of 3 seconds) is"
   echo "detected, the csven health trigger will fire and record the sven events leading up"
   echo "to the event, and then attempt to call ./HOMIE.sh (or /bin/HOMIE.sh)"
   echo ""
   echo "This should be run in a separate terminal when the player is still running."
   echo "This is best used to debug issues like a/v freeze, system hang etc..."
   echo ""
   echo "It is recommended that the date and time are set prior to running the script using"
   echo "date [MMDDhhmm[[CC]YY][.ss]]"
   echo "and the hwclock is updated to keep the settings if the platform is reset"
   echo "Example:"
   echo "date 083118002009"
   echo "hwclock --systohc"
   echo ""
   echo "Now lets ask HOMIE.sh about how it is used..."
if [ -f /bin/HOMIE.sh ]; then
  /bin/HOMIE.sh
else
  if [ -f ./HOMIE.sh ]; then
    ./HOMIE.sh
  else
     echo "(/bin/)HOMIE.sh not found. will not be used"
  fi
fi   
}

echo ""
echo "===================================================================================="
echo "AV Health sven log capturer script version 0.05"
echo ""
while [ $# -gt 0 ]
do
   case "$1" in
      -h)
             print_usage
             exit 1;;
      --help)
             print_usage
             exit 1;;
      --sysinfo)
             /scripts/sysinfo.sh
             exit 1;;
       *)  break;;	# terminate while loop
   esac
   shift
done

# print the date / time
date

echo ""
#==============
echo start csven, using the events we need.  Capture the raw output to a file and parse it later...

echo "hot disable all
#hot enable smd
hot enable mod
filter accept all

health
triggerdelay 1
health aud 3000
health vid 3000
health enable
SysTime
triggerwait
SysTime
echo health trigger fired we have a AV issue...
echo save the csven raw data.
save csven_AV_health_data.bin 
quit" | time nice csven -l 2 


echo ""
echo "Please include the file csven_AV_health_data.bin containing csven raw data along with the output below..."
echo ""

if [ -f /bin/HOMIE.sh ]; then
  /bin/HOMIE.sh $@
else
  if [ -f ./HOMIE.sh ]; then
    ./HOMIE.sh $@
  else
    echo "(/bin/)HOMIE.sh not found. tail of dmesg output:"
    echo "======================================="
    dmesg | tail
    echo "======================================="
  fi
fi

print_sysinfo

# create the text version and the tar gzip the binary and text files for transport
rm -f csven_AV_health_data.tar.gz
echo ""
echo "Extracting the text data from the csven raw data - takes about 30 seconds. Please be patient, thank you."
echo "echo disable drivers writing into the nexus while we dump the text from the raw
hot disable all
echo filter out some noise
filter reject module GEN3_MFD event module_event subtype ADDREF
filter reject module GEN3_MFD event module_event subtype BH_INPUT_QUEUE
filter reject module GEN3_MFD event module_event subtype ENQUEUE_ES_BUFFER
filter reject module GEN3_MFD event module_event subtype SPA
filter reject module GEN3_DPE event module_event subtype BH_ISR_ENTER
load csven_AV_health_data.bin
filter accept all
echo using time tminus  - to output csven time in a count down mode
time tminus
SysTime
echo REMEMBER - health trigger fired after 3 seconds of no AV... scroll down to time  t-:3000.000 to be near the trigger event.
dump 32000
echo REMEMBER - health trigger fired after 3 seconds of no AV... scroll back to time  t-:3000.000 to be near the trigger event.
quit" | csven -l 2 > csven_AV_health_data.txt

echo "tar/gzip the csven txt and bin data to csven_AV_health_data.tar.gz"
tar czf csven_AV_health_data.tar.gz csven_AV_health_data.txt csven_AV_health_data.bin bin/csven lib/libsven_modules.so
echo "listing the contents: tar -tzf csven_AV_health_data.tar.gz:"
tar -tzf csven_AV_health_data.tar.gz
if [ -f ./csven_AV_health_data.tar.gz ]; then
     rm -f csven_AV_health_data.bin
     rm -f csven_AV_health_data.txt
fi
echo "Note: to extract the contents: tar -xzf csven_AV_health_data.tar.gz"

echo ""
echo "Please include the file csven_AV_health_data.tar.gz containing csven data along with the output above..."
echo ""
exit 0

