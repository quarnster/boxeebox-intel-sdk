#
#  This file is provided under a dual BSD/GPLv2 license.  When using or 
#  redistributing this file, you may do so under either license.
#
#  GPL LICENSE SUMMARY
#
#  Copyright (c) 2006-2011. Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify 
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but 
#  WITHOUT ANY WARRANTY; without even the implied warranty of 
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License 
#  along with this program; if not, write to the Free Software 
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution 
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#  Intel Corporation
#  2200 Mission College Blvd.
#  Santa Clara, CA  97052
#
#  BSD LICENSE 
#
#  Copyright (c) 2006-2011. Intel Corporation. All rights reserved.
#  All rights reserved.
#
#  Redistribution and use in source and binary forms, with or without 
#  modification, are permitted provided that the following conditions 
#  are met:
#
#    * Redistributions of source code must retain the above copyright 
#      notice, this list of conditions and the following disclaimer.
#    * Redistributions in binary form must reproduce the above copyright 
#      notice, this list of conditions and the following disclaimer in 
#      the documentation and/or other materials provided with the 
#      distribution.
#    * Neither the name of Intel Corporation nor the names of its 
#      contributors may be used to endorse or promote products derived 
#      from this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

RET_VAL=0

print_usage()
{
   echo "Usage: $0"
   echo ""
   echo "The csven api trace requires a special build of csven.  Please rebuild"
   echo "csven binary first before running this script."
   echo ""
   echo "To enable sven smd api reverse lookup rebuild csven with define"
   echo "-DSMD_API_REVERSE after all smd drivers have been built."
   echo ""
   echo "csven utility is found in SDK component sven-x.x.x.x/tools/csven"
   echo "In the tools/csven/Makefile search for and uncomment the line"
   echo "CFLAGS += -DSMD_API_REVERSE"
   echo " then make -C sven-x.x.x.x/tools"
   echo ""
   echo " The following SDK environment variables may need to be defined first, examples:"
   echo " export SDK_INSTALL_ROOT=/usr/local/ce31xx/sdk/IntelCE-13.88175"
   echo " export BUILD_DEST=\$SDK_INSTALL_ROOT/build_i686/staging_dir/"
   echo " export TARGET_DEST=\$SDK_INSTALL_ROOT/binaries/IntelCE/"
   echo " export FSROOT=\$SDK_INSTALL_ROOT/project_build_i686/IntelCE/root/"
   echo " export SRC_ROOT=\$SDK_INSTALL_ROOT/project_build_i686/IntelCE/"
   echo ""
}

echo ""
echo "===================================================================================="
echo "csven api trace script 0.01 - for CE3100/4100/5100"
echo ""
while [ $# -gt 0 ]
do
   case "$1" in
      -h)
             print_usage
             exit 1;;
      --help)
             print_usage
             exit 1;;
       *)  break;;	# terminate while loop
   esac
   shift
done

echo ""
echo "Collect some system information as well"
echo ""
chmod +x /scripts/sysinfo.sh
/scripts/sysinfo.sh 

echo ""
#==============
echo start csven, api trace.

echo "echo
echo Ensure you have rebuilt csven binary with the  -DSMD_API_REVERSE define
hot disable all
hot enable api
echo
echo   NOTE: monitor cmd starts a thread to print the events to the console,
echo         you can press Ctrl+c to break out of this script.
echo
echo   NOTE: if the log looks like:
echo         dt:   0.011 mt:   0.011 M:SW_SMD_CORE U:0a T:api S:call
echo         dt:   0.004 mt:   0.004 M:SW_SMD_CORE U:0a T:api S:ret
echo         Then the csven binary has not been rebuilt with the -DSMD_API_REVERSE define 
echo
monitor
quit" | time nice csven 

echo ""
exit 0

