/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include <linux/kernel.h> /* printk() */
#include <linux/module.h>
#include <linux/version.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(2,6,10))
#include <asm/page.h>
#include <linux/kthread.h>
#endif
#include <linux/slab.h>   /* kmalloc() */
#include <linux/fs.h>     /* everything... */
#include <linux/errno.h>  /* error codes */
#include <linux/types.h>  /* size_t */
#include <linux/proc_fs.h>
#include <linux/fcntl.h>
#include <linux/cdev.h>
#include <linux/tty.h>
#include <linux/list.h>
#include <asm/atomic.h>
#include <linux/sched.h>
#include <asm/irq.h>
#include <asm/io.h>
#include <asm/ioctl.h>
#include <linux/spinlock.h>
#include <linux/mm.h>

#ifndef MOD_INC_USE_COUNT
#define MOD_INC_USE_COUNT
#define MOD_DEC_USE_COUNT
#endif

#include "sven.h"
#include "sven_devh.h"
#include "osal_memory.h"

/* These are predefined macros that specify different parameters
 * for our driver */
MODULE_AUTHOR("Intel Corporation, (C) 2007-2008 - All Rights Reserved");
MODULE_DESCRIPTION("System Visible Event Nexus (SVEN)");
MODULE_SUPPORTED_DEVICE("Intel Media Processors");

/* Notifies the kernel that our driver is not GPL. */
MODULE_LICENSE("Dual BSD/GPL");

//! Insmod parameter to enable/disable debug output, debug - 1 (off)
int sven_debug = 0;
module_param(sven_debug, int, 0);

/* Defined in sven_dfx.c */
extern volatile unsigned int *g_sven_dfx_hot;

#define xstringify(s) stringify(s)
#define stringify(s) #s
#ifdef COMP_VER
//MODULE_VERSION(COMP_VER);
char *version_string = "#@# sven-linux " xstringify(COMP_VER) " " __DATE__ " " __TIME__;
#else
//MODULE_VERSION("$LastChangedRevision: 7002 $ $HeadURL: http://subversion.co.intel.com/svn/ESS/branches/trials2006_dev/media_drivers/sven/sven_driver.c $");
char *version_string = "#@# sven-linux <COMP_VER undefined> Eng Rel";
#endif


/* ----------------------------------------------------------------------------------- */
/* ----------------------------------------------------------------------------------- */
#include "platform_config.h"
#include "platform_config_paths.h"
/* ----------------------------------------------------------------------------------- */
/* ----------------------------------------------------------------------------------- */

extern void sven_attach_handle_to_queue(
	struct SVENHandle		*svenh,
	struct _SVENHeader		*hdr,
    int                      queue_number );

extern void sven_header_initialize(
	struct _SVENHeader		*hdr,
    int                      sven_mempool_size,
    unsigned int             sven_header_physaddr,
    unsigned int             sven_circbuf_physaddr );

extern int sven_init_dfx_support( struct _SVENHeader *hdr );
extern void sven_devh_kernel_init( struct _SVENHeader *hdr );

#define _TEMP_SVEN_HEADER_PA    0x0FE00000
#define _TEMP_SVEN_CIRCBUF_PA   0x0987e000

#define _TEMP_SVEN_HEADER_SIZE  0x00001000
#define _TEMP_SVEN_CIRCBUF_SIZE 0x00100000

static struct SVENHandle     g_svenh;
static struct _SVENHeader	 *g_sven_hdr;
static unsigned long         g_sven_hdr_pa = _TEMP_SVEN_HEADER_PA;;
static unsigned long         g_sven_hdr_size = _TEMP_SVEN_HEADER_SIZE;
static void                 *g_sven_circbuf;
static unsigned long         g_sven_circbuf_pa = _TEMP_SVEN_CIRCBUF_PA;
static unsigned long         g_sven_circbuf_size = _TEMP_SVEN_CIRCBUF_SIZE;

#if 0
static void                 *g_dfx_regs;
static unsigned long         g_dfx_regs_pa = 0;
static unsigned long         g_dfx_regs_size = 0;
#endif

static int                   g_sven_debug = 0;
int                          g_sven_num_bufs= 2;
static unsigned int          g_sven_disable_mask = SVENHeader_DISABLE_REGIO | SVENHeader_DISABLE_FUNCTION;

/* ----------------------------------------------------------------------------------- */
/* ----------------------------------------------------------------------------------- */
struct _SVENHeader *sven_open_header()
{
    if ( (void *)0 == g_sven_hdr )
    {
        config_get_int( 0, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".sven_hdr.base", (int *) &g_sven_hdr_pa );
        config_get_int( 0, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".sven_hdr.size", (int *) &g_sven_hdr_size );
        config_get_int( 0, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".sven_buf.base", (int *) &g_sven_circbuf_pa );
        config_get_int( 0, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".sven_buf.size", (int *) &g_sven_circbuf_size );

        if ( (0 != g_sven_hdr_pa) && (0 != g_sven_circbuf_pa) )
        {
            /* MAP the regions into memory  */
            g_sven_circbuf = OS_MAP_IO_TO_MEM_CACHE( g_sven_circbuf_pa, g_sven_circbuf_size );

            if ( (void *)0 != g_sven_circbuf )
            {
                /* MAP the regions into memory */
                g_sven_hdr = (struct _SVENHeader *) OS_MAP_IO_TO_MEM_CACHE( g_sven_hdr_pa, g_sven_hdr_size );

                if ( (void *)0 != g_sven_hdr )
                {
                    const char        *header_action = "Connected";

                    /* validate sanity of SVEN Header in memory */
                    if ( (SVENHeader_VERSION_2 != g_sven_hdr->svh_version) ||
                         (g_sven_hdr->svh_circbuffer_count > 5) ||
                         (g_sven_hdr->svh_circbuffer_count == 0) ||
                         (g_sven_hdr->svh_hdr_physaddr != g_sven_hdr_pa) ||
                         (g_sven_hdr->svh_hdr_size != g_sven_hdr_size) ||
                         (g_sven_hdr->svh_buff_physaddr!= g_sven_circbuf_pa) ||
                         (g_sven_hdr->svh_buff_size != g_sven_circbuf_size ) )
                    {
                        if (g_sven_debug > 0) printk(KERN_INFO "SVEN Header init\n");
                        memset( g_sven_hdr, 0, g_sven_hdr_size );

                        /* Completely initialized */
                        sven_header_initialize( g_sven_hdr,
                            (g_sven_hdr_size + g_sven_circbuf_size),
                            g_sven_hdr_pa,
                            g_sven_circbuf_pa );

                        header_action = "Initialized";
                    }


                    printk(KERN_INFO "%s():%4i: SVEN Header %s %08lx@%08lx:%08lx, circbuf %08lx@%08lx:%08lx dis:%08x\n",
                        __func__, __LINE__, header_action,
                        (unsigned long) g_sven_hdr,
                        g_sven_hdr_pa,
                        g_sven_hdr_size,
                        (unsigned long) g_sven_circbuf,
                        g_sven_circbuf_pa,
                        g_sven_circbuf_size,
                        g_sven_disable_mask );

                    sven_init_dfx_support( g_sven_hdr );

                    /* Set HOT Disable */
                    *g_sven_dfx_hot = g_sven_disable_mask;

                    sven_devh_kernel_init( g_sven_hdr );
               }
                else
                {
                    printk(KERN_INFO "%s:%4i: failed to map sven_hdr @%08lx size %08lx\n", __FILE__, __LINE__, g_sven_hdr_pa, g_sven_hdr_size);
                }
            }
            else
            {
                printk(KERN_INFO "%s:%4i: failed to map sven_circbuf @%08lx size %08lx\n", __FILE__, __LINE__, g_sven_circbuf_pa, g_sven_circbuf_size );
            }
        }
        else
        {
            printk(KERN_INFO "%s:%4i: failed to get phys_addrs for sven\n", __FILE__, __LINE__);
        }
    }

	return(g_sven_hdr);
}

void *sven_get_event_buf()
{
    return( g_sven_circbuf );
}

static int ksven_mmap(struct file * filp, struct vm_area_struct *vma)
{
   unsigned long length = vma->vm_end - vma->vm_start;
   pgprot_t ro_page_prot; /* read-only page prot */
   int err = 0;

   if (g_sven_debug > 0) printk("ksven_mmap(%08lx:%08lx:%08lx:%08lx)\n", vma->vm_start, length, vma->vm_flags, *((long *)&vma->vm_page_prot) );

   if (!vma)
      return -ENXIO;

   if (vma->vm_pgoff)
      return -EINVAL;		/* want no offset */

   if (length > (g_sven_hdr_size + g_sven_circbuf_size))
      return -ENOMEM;		/* cannot map more than reserved buffer */

   vma->vm_flags |= VM_RESERVED | VM_IO;

   // Set up read-only access to SVEH Header
   ro_page_prot = vma->vm_page_prot;
   /* remove write flag for header, this makes this copy-on-write */
   pgprot_val(ro_page_prot) &= ~(_PAGE_RW);

   err = remap_pfn_range(vma, vma->vm_start, g_sven_hdr_pa >> PAGE_SHIFT,
   g_sven_hdr_size, ro_page_prot);

   if(!err && (length > PAGE_SIZE)){
      err = remap_pfn_range(vma, vma->vm_start + g_sven_hdr_size,
      g_sven_circbuf_pa >> PAGE_SHIFT,
      length - g_sven_hdr_size,
      vma->vm_page_prot);
   }
   return err;
}

static int ksven_read_proc(char *page, char **start, off_t off,
            int count, int *eof, void *data)
{
   if(off)
      return 0;

   *eof = 1;
   return ( sprintf( page, "0x%08lx 0x%08lx 0x%08lx 0x%08lx\n",
        g_sven_hdr_pa,
        g_sven_hdr_size,
        g_sven_circbuf_pa,
        g_sven_circbuf_size ) );
}

static int ksven_open(struct inode *inode, struct file *file)
{
if (g_sven_debug > 0) printk("ksven_open\n" );
   MOD_INC_USE_COUNT;
   return 0;
}

static int ksven_release(struct inode *inode, struct file *file)
{
if (g_sven_debug > 0) printk("ksven_release\n" );
   MOD_DEC_USE_COUNT;
   return 0;
}

/* WARNING this initialization gets overwriten in init_module() */
static struct file_operations ksven_proc_ops = {
   open:       ksven_open,
   mmap:       ksven_mmap,
   release:    ksven_release,
};

/**
This function is called at module initialization time
@param[in] none
@retval 0: On Success
@retval xxx: On failure
*/
static int __init sven_init_module(void)
{
    struct proc_dir_entry *proc;
    config_ref_t           sven_id;

    printk("ESS SVEN init:" __DATE__ " " __TIME__ "\n");

    if ( CONFIG_SUCCESS == config_node_find( 0, CONFIG_PATH_DRIVER_SVEN, &sven_id ) )
    {
        config_get_int( sven_id, "dismask", &g_sven_disable_mask );
        config_get_int( sven_id, "debug_level", &g_sven_debug );
        config_get_int( sven_id, "num_bufs", &g_sven_num_bufs );
    }

    if ( (void *)0 != sven_open_header() )
    {
        sven_attach_handle_to_queue( &g_svenh, g_sven_hdr, SVEN_CIRCBUFFER_ID_CPU_KERNEL );
    }

   proc = create_proc_entry("sven", S_IRUSR | S_IWUSR, NULL);
   if(proc){
      memcpy(&ksven_proc_ops, proc->proc_fops, sizeof(ksven_proc_ops));
      ksven_proc_ops.open = ksven_open;
      ksven_proc_ops.mmap = ksven_mmap;
      ksven_proc_ops.release = ksven_release;
      proc->proc_fops = &ksven_proc_ops;
      proc->read_proc = ksven_read_proc;
   }
    else
    {
        printk("create proc_entry failed\n");
        return -EIO;
    }

    //printk("osal_debug = %d\n", osal_debug);
    return 0;
}

/**
This function is called at module unload
@param[in] none
@retval none
*/
static void __exit sven_cleanup_module(void)
{
    remove_proc_entry("sven", NULL);
}

/* Keep this function here to prevent table-loading bloat */
const struct ModuleReverseDefs *svenreverse_GetModuleTables(
	enum SVEN_Module			module )
{
	return( (void *)0 );
}


module_init(sven_init_module);
module_exit(sven_cleanup_module);

EXPORT_SYMBOL(g_sven_dfx_time);              /* hardware timer */
EXPORT_SYMBOL(sven_get_timestamp);           /* function */
EXPORT_SYMBOL(sven_get_timestamp_frequency); /* get freq in tick per second */

EXPORT_SYMBOL(sven_open_header);
EXPORT_SYMBOL(sven_init_fw_globals);
EXPORT_SYMBOL(sven_attach_handle_to_queue);
EXPORT_SYMBOL(sven_write_event);
EXPORT_SYMBOL(sven_get_write_position);
EXPORT_SYMBOL(sven_read_next_event);
EXPORT_SYMBOL(sven_WriteDebugString);
EXPORT_SYMBOL(sven_WriteDebugStringEnd);
EXPORT_SYMBOL(sven_WriteEvent_ulongs);
EXPORT_SYMBOL(sven_WriteEventVA_ulong);
EXPORT_SYMBOL(svenreverse_GetModuleTables);/* Exposing this can link in lots of symbols */

EXPORT_SYMBOL(devhandle_factory);
EXPORT_SYMBOL(devhandle_connect_pci_bus_dev_fun_bar);
EXPORT_SYMBOL(devhandle_connect_physical_address);
EXPORT_SYMBOL(devhandle_connect_name);
EXPORT_SYMBOL(devh_Block);
EXPORT_SYMBOL(devh_Unblock);
EXPORT_SYMBOL(devh_Delete);
EXPORT_SYMBOL(devh_ReadReg32);
EXPORT_SYMBOL(devh_ReadReg32_polling_mode);
EXPORT_SYMBOL(devh_WriteReg32);
EXPORT_SYMBOL(devh_OrBitsReg32);
EXPORT_SYMBOL(devh_AndBitsReg32);
EXPORT_SYMBOL(devh_SetMaskedReg32);
EXPORT_SYMBOL(devh_ReadReg64);
EXPORT_SYMBOL(devh_ReadReg64_polling_mode);
EXPORT_SYMBOL(devh_WriteReg64);
EXPORT_SYMBOL(devh_OrBitsReg64);
EXPORT_SYMBOL(devh_AndBitsReg64);
EXPORT_SYMBOL(devh_SetMaskedReg64);
EXPORT_SYMBOL(devh_InjectRead);
EXPORT_SYMBOL(devh_InjectWrite);
EXPORT_SYMBOL(devh_default_InjectRead);
EXPORT_SYMBOL(devh_default_InjectWrite);
EXPORT_SYMBOL(devh_SVEN_GetHandle);
EXPORT_SYMBOL(devh_SVEN_SetModuleUnit);
EXPORT_SYMBOL(devh_SVEN_WriteEvent);
EXPORT_SYMBOL(devh_SVEN_WriteModuleEvent);
EXPORT_SYMBOL(devh_SVEN_WriteDebugString);
EXPORT_SYMBOL(devh_SVEN_WriteDebugStringEnd);
EXPORT_SYMBOL(devh_SVEN_SetDynamicDisable);
