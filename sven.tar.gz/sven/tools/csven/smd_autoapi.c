/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef SVEN_MODULE_H
#include <sven_module.h>
#endif

#ifndef _CSR_DEFS_H
#include <csr_defs.h>
#endif

#ifdef SMD_API_REVERSE

#include "audio_autoapi_reverse.c"
#include "clock_autoapi_reverse.c"
#include "clock_recovery_autoapi_reverse.c"
#include "core_autoapi_reverse.c"
#include "demux_v3_autoapi_reverse.c"
#include "viddec_autoapi_reverse.c"
#include "vidpproc_autoapi_reverse.c"
#include "vidrend_autoapi_reverse.c"

/* This enum is derived completely from smd_api_gen.py in
 *       <trunk>/smd/tools/autoapi/src
 *  which reads
 *  api_name_to_id = { 'test'           : 0,
 *                     'demux_v2'       : 1,
 *                     'demux_v3'       : 1,
 *                     'audio'          : 2,
 *                     'mfd'            : 3,
 *                     'viddec'         : 3,
 *                     'viddec_v2'      : 3,
 *                     'dpe'            : 4,
 *                     'vidpproc'       : 4,
 *                     'vidrend'        : 5,
 *                     'core'           : 6,
 *                     'clock'          : 7,
 *                     'dfx'            : 8,
 *                     'clock_recovery' : 9,
 *                     'mrt'            : 10,
 *                     'tsout'          : 11,
 *                     'bufmon'         : 12,
 *                   'viddec_fw_parser' : 13,
 *                  'viddec_fw_decoder' : 14,
 *                   'videnc_fw'        : 15,
 *                   'avcap_shim'       : 16,
 *                   'remux'            : 17,
 *                   'vidsink'          : 18,
 *   }
 *
 */
enum AUTO_API_Module /* WARNING: VALIDATE against module list in smd_api_gen.py */
{
   AUTO_API_module_invalid,                  /* 0, NO ZEROES ALLOWED */
   AUTO_API_module_smd_API_demux,            /* 1 */
   AUTO_API_module_smd_API_audio,            /* 2 */
   AUTO_API_module_smd_API_viddec,           /* 3, also mfd */
   AUTO_API_module_smd_API_vidpproc,         /* 4, also dpe */
   AUTO_API_module_smd_API_vidrend,          /* 5 */
   AUTO_API_module_smd_API_core,             /* 6 */
   AUTO_API_module_smd_API_clock,            /* 7 */
   AUTO_API_module_smd_API_dfx,              /* 8 */
   AUTO_API_module_smd_API_clock_recovery,   /* 9 */
   AUTO_API_module_smd_API_mrt,              /* 10 */
   AUTO_API_module_smd_API_tsout,            /* 11 */
   AUTO_API_module_smd_API_bufmon,           /* 12 */
   AUTO_API_module_smd_API_viddec_fw_parser, /* 13 */
   AUTO_API_module_smd_API_viddec_fw_decoder,/* 14 */
   AUTO_API_module_smd_API_videnc_fw,        /* 15 */
   AUTO_API_module_smd_API_avcap_shim,       /* 16 */
   AUTO_API_module_smd_API_remux,            /* 17 */
   AUTO_API_module_smd_API_vidsink,          /* 18 */

   AUTO_API_module_MAX                    /* MAX Placeholder */
};

static const struct SVEN_Module_EventSpecific *g_autoapi_reverse[AUTO_API_module_MAX+1] =
{
/*  0 */   NULL,
/*  1 */   g_smd_API_demux_v3_specific_events,  
/*  2 */   g_smd_API_audio_specific_events,  
/*  3 */   g_smd_API_viddec_specific_events,  
/*  4 */   g_smd_API_vidpproc_specific_events,  
/*  5 */   g_smd_API_vidrend_specific_events,  
/*  6 */   g_smd_API_core_specific_events,  
/*  7 */   g_smd_API_clock_specific_events,  
/*  8 */   NULL, /* dfx */
/*  9 */   g_smd_API_clock_recovery_specific_events,  
/* 10 */   NULL,  /* mrt */
/* 11 */   NULL,  /* tsout */
/* 12 */   NULL,  /* bufmon */
/* 13 */   NULL,  /* viddec_fw_parser */
/* 14 */   NULL,  /* viddec_fw_parser */
/* 15 */   NULL,  /* videnc_fw */
/* 16 */   NULL,  /* avcap_shim */
/* 16 */   NULL,  /* remux */
/* 18 */   NULL,  /* vidsink */


   NULL  /* unnecessary termination */
};

const struct SVEN_Module_EventSpecific *autoapi_lookup_function(
   unsigned api_group_id,
   unsigned msg_type )
{
   if ( api_group_id < AUTO_API_module_MAX )
   {
      const struct SVEN_Module_EventSpecific *rev;

      if ( NULL != (rev = g_autoapi_reverse[api_group_id]) )
      {
         while ( NULL != rev->mes_name )
         {
            if ( rev->mes_subtype == msg_type )
            {
               return(rev);
            }
            rev++;
         }
      }
   }

   return(NULL);
}
#endif /* SMD_API_REVERSE */

