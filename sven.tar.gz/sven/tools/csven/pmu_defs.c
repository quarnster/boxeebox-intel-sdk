/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "pmu_defs.h"
#include "struct_sprintf.c"
struct GEN2_PMU_units 	p_units[PMU_UNITS_MAX] =
{
{"MCU", 						0x1},
{"VCMH1",					0x2},
{"VCMH2",					0x3},
{"XAB",						0x4},
{"AUDIO",					0x5},
{ NULL,						0x0}
};

unsigned int get_pmu_unit_hex(char *unitname)
{
	int 								unit = 0;
	while (NULL != p_units[unit].unit_name)
	{
		if(!strcasecmp(p_units[unit].unit_name, unitname))
			{
				printf("Returning %8x/n", p_units[unit].unit_number);
				return p_units[unit].unit_number;
			}
		else
			unit++;
	}
	return 0;
}

static inline unsigned int _readpmu_register(os_devhandle_t *devh, unsigned int offset)
{
	int err = 0;
	if(NULL != devh)
		{
			err = (unsigned int)(devh_ReadReg32( devh, offset));
		}
		else
			printf("/nRead Failed/n");
		
	return err;
}

static inline unsigned int _writepmu_register(os_devhandle_t *devh, unsigned int offset, unsigned int value)
{
	int err = 0;
	
	devh_WriteReg32( devh, offset, value);
	err = (unsigned int)(devh_ReadReg32( devh, offset));
	return err;
}


int gen2_pmu_worker(void *pmu_t )
{
	os_devhandle_t							*devh;
	struct SVENEvent 							ev;
	static int 									count = 0;
	unsigned int 								tempeventsel;
	struct 	gen2_pmu_t						*pmu_val;
	int 										err = 0;
	FILE*									fp;


	pmu_val = malloc(sizeof(struct gen2_pmu_t));
	memcpy(pmu_val, pmu_t, sizeof(struct gen2_pmu_t));


	
/*	_sven_initialize_event_top( &ev,
	SVEN_module_GEN2_PMU,
	 (int) pmu_val->unit_id,
        SVEN_event_type_PMU,
        0 );*/


	printf("Suceeded to reach Before the file Open");

	fp = (FILE *)fopen("monitor.txt","w+");
	if (fp == NULL)
		{
			printf("\n The file opening failed");
			return 0;
		}
	fprintf(fp, "PMU Count 0\t PMU Count 1\t PMU Timer\t");	
	printf("pmu_t->unit %8x, pmu->event %8xpmu->subevent%8x", pmu_val->unit_id, pmu_val->event_id, pmu_val->sub_event_id);
	if(NULL != (devh = devhandle_factory(NULL)))
		{
			if( devhandle_connect_name (devh, "PMU"))
			{
					err =1;
			}
			else
				{
				DEVH_FATAL_ERROR(devh, "could not connect to UNIT");
				devh_Delete(devh);
				devh = NULL;
				err = 0; 
				return 0;
				}
		}
	
	while (count != pmu_val->num_times)
	{
	if (count == 0)
		{
		//	tempeventsel = subevent | event | unit ;
   		tempeventsel = pmu_val->sub_event_id| pmu_val->event_id| pmu_val->unit_id;
		devh_WriteReg32( devh, 4, tempeventsel);
		//Set Max thersholds to the PMU Event thresholds /*To Do* Might have to change this and make it dynamic
		devh_WriteReg32( devh, 10, -1);
		devh_WriteReg32( devh, 14, -1);
		devh_WriteReg32( devh, 18, -1);
		
		//The First Value wrritten in the queue is all zeros
			fprintf(fp, "   %8x\t		%8x\t  		%8x\n", _readpmu_register(devh, 0x0020), _readpmu_register(devh, 0x0024), _readpmu_register(devh, 0x001c)) ;
		   
			switch (pmu_val->monitor_type)
				{
				case DURATION:
					devh_WriteReg32( devh, 0, 119);
				break;
				case EDGE:
					devh_WriteReg32( devh, 0,  375);
				break;
				}
		}
		else if (count < pmu_val->num_times)
		{

		//	printf("I am in the monitoring loop\n");
			devh_WriteReg32( devh, 0,  0); //Stop Read and Restart Functionality
			//Use Fprintf untll you get the SVEN Events to work
			fprintf(fp, "   %8x\t		%8x\t  		%8x\n", _readpmu_register(devh, 0x0020), _readpmu_register(devh, 0x0024), _readpmu_register(devh, 0x001c)) ;
			switch (pmu_val->monitor_type)
				{
				case DURATION:
					devh_WriteReg32( devh, 0, 119);
				break;
				case EDGE:
					devh_WriteReg32( devh, 0,  375);
				break;
				}
			devh_WriteReg32( devh, 0,  375);	
		}
	else 
		{
		   	devh_WriteReg32( devh, 0,  0);
			fprintf(fp, "   %8x\t		%8x\t  		%8x\t", _readpmu_register(devh, 0x0020), _readpmu_register(devh, 0x0024), _readpmu_register(devh, 0x001c)) ;
		}
		count++;
 	//	 _sven_write_new_event(&devh->devh_svenh, &ev );

 	//	sleep(100);
	
		}
	
	fclose(fp);
	return 0;

}








