/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

///
/// @brief      SVEN Debug Console Application
///
/// History:    Created 11/2005
//  Note:       See Doxygen Manual http://www.doxygen.org/commands.html for
//              Special Commands used by doxygen tool to create documentation.
////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>
#include <unistd.h>
#include <sven_devh.h>
#include <time.h>
#include "pmu_defs.h"
#include "osal_thread.h"
#include "osal_type.h"
#include "osal_sema.h"
#include "osal_memory.h"
#include "os/osal_thread.h"

#ifndef SVEN_H
#include <sven.h>
#endif

#ifndef SVENREVERSE_H
#include <svenreverse.h>
#endif

#ifndef SVEN_RBD_LOOKUP
#include "rbd_lookup.h"
#endif

#ifndef SVEN_PROTOS_H
#include <sven_protos.h>
#endif

#include "sven_fw_globals.h"
#include "omarlib.h"

#ifdef SVEN_VIZ_UDP
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <fcntl.h>
#endif

#define DISABLE_READLINE 1
#ifndef DISABLE_READLINE
#include <readline/readline.h>
#endif

#include <auto_eas/sw_vidrend.h>
#include <auto_eas/gen3_aud_io.h>

//#include <auto_eas/cm_aud_io.h>

#define xstringify(s) stringify(s)
#define stringify(s) #s
#ifdef COMP_VER
char *csven_version_string = "#@# csven " xstringify(COMP_VER) " " __DATE__ " " __TIME__;
#else
char *csven_version_string = "#@# csven <COMP_VER undefined> Eng Rel";
#endif

#ifndef UNUSED_PARAMETER
#define UNUSED_PARAMETER(x)   (void)(x)
#endif

#define SVENLOG_LOCAL_EVENTBUF_SIZE (4 * 1024 * 1024)

// Update this version anytime the format of the SVENEvent structure (or any
// or any structures it is dependent on) changes.
#define CSVEN_SAVE_VERSION          (1)

static int g_ctrl_c_pressed;
static int sven_ts_in_khz;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

/* == Structures ============================================================ */

////////////////////////////////////////////////////////////////////////////////
/// @struct  Token for Command Parser
////////////////////////////////////////////////////////////////////////////////
struct CommandToken
{
    char*                token_str;         /* will be NULL terminated The string is 128 characters max */
    unsigned int         token_int_value;   /* parsed integer value */
    unsigned int         token_buf_size;    /* must be >= strlen(token) */
};

////////////////////////////////////////////////////////////////////////////////
/// @struct  Command Parser
////////////////////////////////////////////////////////////////////////////////
struct CommandParser
{
    int                  num_tokens;
    int                  max_tokens;
    int                  default_token_length;
    struct CommandToken* token;
};

////////////////////////////////////////////////////////////////////////////////
/// @struct  SVEN SMD Health Monitoring Hooks
////////////////////////////////////////////////////////////////////////////////
#define SMD_HEALTH_VID_TIMESTAMPS        4
#define SMD_HEALTH_AUD_TIMESTAMPS        8
struct SMDHealthMonitor
{
    unsigned int    trigger_enabled;

    unsigned int    vid_threshhold;
    unsigned int    aud_threshhold;

    unsigned int    vid_timestamps[SMD_HEALTH_VID_TIMESTAMPS];
    unsigned int    aud_timestamps[SMD_HEALTH_AUD_TIMESTAMPS];
};

////////////////////////////////////////////////////////////////////////////////
/// @struct  SVEN SMD Core Monitoring Pre-declaration
////////////////////////////////////////////////////////////////////////////////
struct SMDMon_Port;
struct SMDMon_Queue;
struct SMDMon_Buf;
struct SMDMon_Circbuf;
struct SMDMon_Buf_Stats
{
    struct SMDMon_Buf_Stats *next;      // Not used.
    int  buf_size;           // Used to detect hash collision
    int  in_use;
    int  num_curr_in_use;
    int  max_used;
    int  min_used;
    int  num_use_events;     // Used to compute average usage
    int  total_buf_usage;    // Used to compute average usage
};

#define SMDMON_BUF_HASH_SIZE    (1<<6)
#define SMDMON_BUF_HASH_MASK    (SMDMON_BUF_HASH_SIZE - 1)

#ifdef SVEN_VIZ_UDP
#define NUM_VIZ_TUPLES_PER_UDP  30
struct VIZ_Tuple
{
    int         virtid;
    int         depth;
    int         level;
};
#endif

////////////////////////////////////////////////////////////////////////////////
/// @struct  SVEN SMD Core Monitoring Hooks
////////////////////////////////////////////////////////////////////////////////
struct SMDCoreMonitor
{
    int                   core_msgs;
    int                   unknown_msgs;
    int                   core_allocs;
    int                   core_frees;
    int                   collecting_extended_buf_stats;

#ifdef SVEN_VIZ_UDP
    struct hostent       *viz_hostInfo;
    int                   viz_socket;
    int                   viz_socket_opened;
    unsigned short int    viz_serverPort;
    struct sockaddr_in    viz_serverAddress;
    int                   viz_update_count;
    struct VIZ_Tuple      viz_tuple[NUM_VIZ_TUPLES_PER_UDP];
#endif

    struct SMDMon_Port      *first_port;
    struct SMDMon_Queue     *first_queue;
    struct SMDMon_Circbuf   *first_circbuf;

    struct SMDMon_Buf       *free_bufs;
    struct SMDMon_Buf       *buft[SMDMON_BUF_HASH_SIZE];
    struct SMDMon_Buf_Stats stats_buft[SMDMON_BUF_HASH_SIZE];
};

////////////////////////////////////////////////////////////////////////////////
/// @struct  SVEN Event TX Hogs Monitoring Hooks
////////////////////////////////////////////////////////////////////////////////
struct SVENHogsMonitor
{
   int                   module_event_count[1024]; /* module is 10 bits */
   int                   smd_unit_event_count[16]; /* unit is 4 bits */
};


////////////////////////////////////////////////////////////////////////////////
/// @struct  SVEN Application Data
////////////////////////////////////////////////////////////////////////////////
struct SVENApp
{
    struct SVENHandle   *svenh;   /* event writing handle, always points to esvenh */
    struct CommandParser cparse;

    os_devhandle_t      *devh;    /* for generic DEVHANDLE testing, unconnected to any device */

    struct SVENLog      *svenlog; /* logger */
    int                  time_display_mode;
    unsigned int         time_last_event_time;
    #define TDISPLAY_NORMAL     0
    #define TDISPLAY_DELTA      1
    #define TDISPLAY_TMINUS     2
    unsigned int         last_module_time[SVEN_module_MAX];

#ifdef SVEN_CONSOLE_LINUX_ONLY
    pthread_attr_t       svenlog_pthread_attr;
    pthread_t            svenlog_pthread;
#else
    int                  svenlog_thread_create_attempted;
    os_thread_t          svenlog_thread;
#endif

    /* Waveform Source Capture */
    struct WaveformSource *omar;

    int                  svenlog_thread_quit_request;

    struct SVENReverser *srev;    /* reverser */
    struct _SVENHeader  *hdr;     /* sven header */
    FILE                *fin;     /* Input source of commands */
    int                  interactive_mode;
    int                  quit_requested;

    /* Embedded SMD Core Monitoring structure */
    struct SMDCoreMonitor   smd_mon;

    /* Embedded SMD Health Monitoring structure */
    struct SMDHealthMonitor smd_health;

    /* private stuff below here */
    struct SVENHandle    esvenh; /* embedded writing handle, do not touch */

    struct SVENHogsMonitor hogs;

};

#ifdef SVEN_CMD_BITFIELD_TEST
int sven_cmd_bitfield_test( struct SVENApp* app, const char* command )
{
    int            bits;

    UNUSED_PARAMETER(command);

    /* Whole register */
    DEVH_WRITE_BITFIELD( app->devh, BITFIELD_AUDIO_ISRX, 3 );

    /* multi- bit BITFIELD */
    DEVH_WRITE_BITFIELD( app->devh, BITFIELD_AUDIO_ISRX_RSVD_5_2, 2 );

    /* single bit BITFIELD, set */
    DEVH_WRITE_BITFIELD( app->devh, BITFIELD_AUDIO_ISRX_IPCX, 1 );

    /* single bit BITFIELD, clear */
    DEVH_WRITE_BITFIELD( app->devh, BITFIELD_AUDIO_ISRX_IPCX, 0 );

    bits = 0;

    /* Whole register */
    bits  += DEVH_READ_BITFIELD( app->devh, BITFIELD_AUDIO_ISRX );

    /* multi- bit BITFIELD */
    bits  += DEVH_READ_BITFIELD( app->devh, BITFIELD_AUDIO_ISRX_RSVD_5_2 );

    /* single bit BITFIELD, set */
    bits  += DEVH_READ_BITFIELD( app->devh, BITFIELD_AUDIO_ISRX_IPCX );

    return(bits);
}
#endif //def SVEN_CMD_BITFIELD_TEST

////////////////////////////////////////////////////////////////////////////////
/// @struct  Structure to hold sven lexicon and associated funtions
///
/// see global instance of sven lexicon later in souce: g_svenapp_commands
////////////////////////////////////////////////////////////////////////////////
struct app_command_dispatcher
{
    const char*     cmdname;
    const char*     arghelp;
    int           (*dispatch)( struct SVENApp *app, const char *command );
};


/* == Defintions ==========================================================*/

static int sven_smd_core_filter(
    struct SVENEvent    *ev,
    void                *userdata0,
    void                *userdata1 );
static int sven_smd_health_filter(
    struct SVENEvent    *ev,
    void                *userdata0,
    void                *userdata1 );
static int sven_cmd_help( struct SVENApp* app, const char* command );
static int sven_cmd_source( struct SVENApp* app, const char* command );
static int sven_cmd_list_modules( struct SVENApp* app, const char* command );
int svenapp_source_main(  struct SVENApp* app, bool from_src_cmd_flag );
int svenapp_dispatch_command(struct SVENApp* app, const char* command );

static int sven_cmd_health(
    struct SVENApp*  app,
    const  char*     command );

//------------------------------------------------------------------------------
// Signal handler
//------------------------------------------------------------------------------
void signal_handler(int sig)
{
   printf("\n");
   fflush(stdout);
   fflush(stderr);
   //reset and raise default signal
   signal(sig , SIG_DFL);
   raise(sig);
}
/* ========================================================================== */
/* ========================================================================== */
extern const struct RegisterBankDescriptor *pal_get_rbd_table(
   int                  *rbd_size );

static void build_reverse_rbd_table( void )
{
    const struct RegisterBankDescriptor *osal_rbd_table;
    int                                  rbd_size;

    if ( NULL != (osal_rbd_table = pal_get_rbd_table( &rbd_size )) )
    {
        const struct RegisterBankDescriptor *rbd,**rbd_table;
        int                                  num_rbds;

        /* Find out how many there are first */
        num_rbds = 0;
        rbd = osal_rbd_table;
        while ( rbd->rbd_name )
        {
            num_rbds++;
            /* move to the next one in the entry */
            rbd = (const struct RegisterBankDescriptor *) ((const char *)rbd + rbd_size );
        }

        if ( NULL != (rbd_table = OS_ALLOC( sizeof(void *) * num_rbds )) )
        {
            int       num_in_table;

            /* Perform insertion sort (by physical address)
             * from OSAL table to SVEN Reverse table.
             *
             * once the table is sorted by ascending physical address
             *  give it to sven_reverse_set_physaddr_lookup()
             *
             * Then, inside sven_reverse_GetEventTextString(), the physical
             * addresses will be searched for "undocumented" physical addresses
             *
             */
            num_in_table = 0;
            rbd = osal_rbd_table;
            while ( rbd->rbd_name )
            {
                int         i;

                for ( i = 0; i < num_in_table; i++ )
                {
                    if ( rbd->rbd_phys_addr < rbd_table[i]->rbd_phys_addr )
                    {
                        break;
                    }
                }
                /* Insert */
                if ( i < num_in_table )
                {
                    int             j;
                    for ( j = num_in_table; j > i; j-- )
                    {
                        rbd_table[j] = rbd_table[j-1];
                    }
                }

                /* put this here now */
                rbd_table[i] = rbd;
                num_in_table++;

                /* move to the next one in the entry */
                rbd = (const struct RegisterBankDescriptor *) ((const char *)rbd + rbd_size );
            }

            #if 0
            {
                int         i;

                printf("RBD_TABLE: %d %d\n", num_rbds, num_in_table );

                for ( i = 0; i < num_in_table; i++ )
                {
                    printf("%2d: %08x %08x \"%s\"\n",
                        i,
                        (int) rbd_table[i]->rbd_phys_addr,
                        (int) rbd_table[i]->rbd_size,
                        rbd_table[i]->rbd_name );
                }
            }
            #endif

            /* Hand this off to the reverser for physaddr lookups */
            sven_reverse_set_physaddr_lookup( rbd_table, num_rbds );
        }
    }
}

#ifdef SMD_API_REVERSE
static int autoapi_reverse_smd_event(
   const struct SVENEvent  *ev,
   char                    *revstr )
{
   extern const struct SVEN_Module_EventSpecific *autoapi_lookup_function(unsigned api_group_id,unsigned msg_type );
   const struct SVEN_Module_EventSpecific *api;
   char *cp = revstr;
   unsigned api_group_id;
   unsigned msg_type;
   api_group_id = (ev->u.se_uint[0] >> 16) & 0xffff;
   msg_type = (ev->u.se_uint[0] >> 0) & 0xffff;
   if ( NULL != (api = autoapi_lookup_function( api_group_id, msg_type )) )
   {
      cp += sprintf(cp,"API: ");

      if ( SVEN_EV_API_FunctionCalled == ev->se_et.et_subtype )
      {
         cp += sprintf(cp,"call %s( ", api->mes_name );
         cp += sprintf(cp, api->mes_comment, ev->u.se_uint[1], ev->u.se_uint[2], ev->u.se_uint[3], ev->u.se_uint[4], ev->u.se_uint[5] );
         cp += sprintf(cp," );" );
      }
      else if ( SVEN_EV_API_FunctionReturned == ev->se_et.et_subtype )
      {
         cp += sprintf(cp,"retn %s() = %d ", api->mes_name, ev->u.se_uint[1] );
      }
      else
      {
         cp += sprintf(cp,"unknown subtype %d [ %08x %08x %08x %08x %08x ]",
               (int) ev->se_et.et_subtype,
               ev->u.se_uint[1],
               ev->u.se_uint[2],
               ev->u.se_uint[3],
               ev->u.se_uint[4],
               ev->u.se_uint[5] );
      }
   }
   else
   {
      cp += sprintf( revstr, "unknown api subtype %d: group %d func %d [ %08x %08x %08x %08x %08x ]",
         ev->se_et.et_subtype, api_group_id, msg_type,
         ev->u.se_uint[1], ev->u.se_uint[2], ev->u.se_uint[3], ev->u.se_uint[4], ev->u.se_uint[5] );
   }

   return( cp - revstr );
}
#endif

/* ==================PMU Helper Function========================*/
//////////////////////////////////////////////////////////////////////////
///
/// @brief Helper functions for the PMU..Keep it here for now Ask Pat for a better location
///
/// @param[in]  unit
/// @param[in]  event
/// @param[in]  sub_event
/// @returns sucess or failure
///////////////////////////////////////////////////////////////////////////


extern const struct EventTypeReverse* svenreverse_EVENT_TABLES_BY_NAME(
       const char*                    event_name );

extern const struct EventTypeReverse* svenreverse_EVENT_TABLES_BY_NUM(
       int                            event_num );

/* == Functions - Implementations ============================================*/

////////////////////////////////////////////////////////////////////////////////
///
/// @brief        Command Parser Initialization
///
///               Initializes Command tokens
///
/// @param[in]    cparse            ptr
/// @param[in]    num_tokens        how many
/// @param[in]    max_token_length  max length
///
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int cparse_init(
    struct CommandParser*    cparse,
    unsigned int             num_tokens,
    unsigned int             max_token_length )
{
    /* initializes several tokens */
    int             retval = 0;
    unsigned int    i;

    if ( NULL != (cparse->token = (struct CommandToken *)
        calloc( num_tokens, sizeof(struct CommandToken)) ) )
    {
        cparse->max_tokens = num_tokens;
        cparse->default_token_length = max_token_length;

        for (i = 0; i < num_tokens; i++ )   /* guess */
        {
            cparse->token[i].token_buf_size    = max_token_length;

            if ( NULL != (cparse->token[i].token_str =
                calloc(128, sizeof(char)) ) )
            {
            }
            else break;
        }

        if ( i == num_tokens )  /* no errors encountered */
        {
            retval = 1;
        }
    }

    return(retval);
}

////////////////////////////////////////////////////////////////////////////////
///
/// @brief        Command Parser
///
/// @param[in]    cparse   ptr
/// @param[in]    command  ptr command
///
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int cparse_parse_command(
    struct CommandParser* cparse,
    const  char*          command )
{
    unsigned int        done = 0;
    int                 tok_beg = 0;
    int                 tok_end = 0;

    cparse->num_tokens = 0;
    while (' ' == command[tok_end])
        tok_end++; /*seek the end of first white space */
    tok_beg = tok_end;

    do
    {
        if ( (' ' != command[tok_end]) && ('\0' != command[tok_end]) && ('\t' != command[tok_end]) )
        {
            tok_end++;
        }
        else
        {
            if ( cparse->token[cparse->num_tokens].token_buf_size <= (unsigned int)(tok_end - tok_beg) )
            {
                char            *new_tok;
                int              tok_bufsize;

                /* How big does this token need to grow */
                tok_bufsize = cparse->token[cparse->num_tokens].token_buf_size;
                while ( tok_bufsize <= (tok_end - tok_beg) )
                    tok_bufsize <<= 1;

                if ( NULL != (new_tok = calloc(tok_bufsize,1) ) )
                {
                    free( cparse->token[cparse->num_tokens].token_str );
                    cparse->token[cparse->num_tokens].token_str = new_tok;
                    cparse->token[cparse->num_tokens].token_buf_size = tok_bufsize;
                }
                else
                {
                    printf("SVEN ERR: Cannot Grow command parser token");
                    exit(0);
                }
            }
            strncpy( cparse->token[cparse->num_tokens].token_str, &command[tok_beg], (tok_end - tok_beg) );
            cparse->token[cparse->num_tokens].token_str[(tok_end - tok_beg)] = '\0';
            cparse->token[cparse->num_tokens].token_int_value = strtoul(
                cparse->token[cparse->num_tokens].token_str, NULL, 0);

            tok_beg = tok_end;
            cparse->num_tokens++;

            /* Grow the token array? */
            if ( cparse->num_tokens >= cparse->max_tokens )
            {
                struct CommandToken* new_tokens;

                if ( NULL != (new_tokens = calloc( sizeof(*new_tokens), cparse->max_tokens<<1)) )
                {
                    int         i;
                    for ( i = 0; i < cparse->max_tokens; i++ )
                    {
                        new_tokens[i].token_str = cparse->token[i].token_str;
                        new_tokens[i].token_buf_size = cparse->token[i].token_buf_size;
                        new_tokens[i].token_int_value = cparse->token[i].token_int_value;
                    }
                    while ( i < (cparse->max_tokens<<1) )
                    {
                        if ( NULL != (new_tokens[i].token_str = malloc( cparse->default_token_length )) )
                        {
                            new_tokens[i].token_buf_size = cparse->default_token_length;
                            new_tokens[i].token_int_value = 0;
                        }
                        else
                        {
                            printf("SVEN ERR: Cannot Grow command parser token table");
                            exit(0);
                        }

                        i++;
                    }
                    free( cparse->token );
                    cparse->token = new_tokens;
                    cparse->max_tokens<<= 1;
                }
                else
                {
                    printf("SVEN ERR: Cannot Grow command parser token table");
                    exit(0);
                }
            }

            /* skip to beginning of next token */
            while (command[tok_beg] && ((' ' == command[tok_beg]) || ('.' == command[tok_beg]) || ('\t' == command[tok_beg])))
                tok_beg++;

            tok_end = tok_beg;    /* for next iteration through the parser loop */
            if (command[tok_end] == '\0')
                done = 1;
        }

    } while(!done);

    return(cparse->num_tokens);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        De-allocation stuff
/// @param[in]    app   ptr
////////////////////////////////////////////////////////////////////////////////
void svenapp_Delete( struct SVENApp*  app )
{
    if ( NULL != app->srev )
    {
    }

    if ( NULL != app->svenlog )
    {
        svenlog_Delete( app->svenlog );
    }

    if ( NULL != app->hdr )
    {
    }

    free(app);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Print the header data and circular buffers info
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_print_header(
    struct SVENApp*  app,
    const  char*     command )
{
   struct _SVENHeader *hdr;
   unsigned int        i;

   UNUSED_PARAMETER(command);

   hdr = app->hdr;

   if ( NULL != g_sven_dfx_time )
   {
      printf( "SVEN-Header: ver:     '%c%c%c%c' disab: %08x debugfl: %08x\n"
         "           : hdr_pa:%08x hdr_sz:%08x\n"
         "           : buf_pa:%08x buf_sz:%08x tx_pos:%08x\n"
         "           : dfx_pa:%08x dfx_sz:%08x\n",
         (char)((hdr->svh_version>>24)&0xff),
         (char)((hdr->svh_version>>16)&0xff),
         (char)((hdr->svh_version>>8)&0xff),
         (char)((hdr->svh_version>>0)&0xff),
         *app->esvenh.phot,
         hdr->svh_debug_flags,
         hdr->svh_hdr_physaddr,
         hdr->svh_hdr_size,
         hdr->svh_buff_physaddr,
         hdr->svh_buff_size,
         *app->esvenh.pcur,
         hdr->svh_dfx_physaddr,
         hdr->svh_dfx_size );
   }
   else
   {
      printf( "SVEN-Header: ver:     '%c%c%c%c' disab: %08x debugfl: %08x\n"
         "           : hdr_pa:%08x hdr_sz:%08x\n"
         "           : buf_pa:%08x buf_sz:%08x cb_count:%08x\n",
         (char)((hdr->svh_version>>24)&0xff),
         (char)((hdr->svh_version>>16)&0xff),
         (char)((hdr->svh_version>>8)&0xff),
         (char)((hdr->svh_version>>0)&0xff),
         *app->esvenh.phot,
         hdr->svh_debug_flags,
         hdr->svh_hdr_physaddr,
         hdr->svh_hdr_size,
         hdr->svh_buff_physaddr,
         hdr->svh_buff_size,
         hdr->svh_circbuffer_count );

      /* Dump circular buffers */
      for ( i = 0; i < hdr->svh_circbuffer_count; i++ )
      {
         printf( "SVEN-CBuf-%d: cb_pa: %08x cb_siz:%08x cb_pos:  %08x cb_id: %08x\n",
            i,
            hdr->buffers[i].svc_physaddr,
            hdr->buffers[i].svc_size,
            hdr->buffers[i].svc_pos,
            hdr->buffers[i].svc_id );
      }
   }

   return(0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Initialization
/// @param[in]    spec     ptr
/// @returns      ptr to SVENApp structure on success, NULL on failure
////////////////////////////////////////////////////////////////////////////////
struct SVENApp* svenapp_Create(
        const char*   spec,
        int           log_size_megabytes )
{
    struct SVENApp  *app;

    UNUSED_PARAMETER(spec);

    /* Some sanity clamping */
    if ( (log_size_megabytes <= 0) || (log_size_megabytes >= 1024) )
        log_size_megabytes = 1;

    log_size_megabytes *= (1024*1024);  /* convert this to bytes */

    if ( NULL != (app = (struct SVENApp *)calloc(1,sizeof(*app))) )
    {
        char        ok = 0;

        /* point-to-self */
        app->svenh = &app->esvenh;

        if ( NULL != (app->hdr = sven_open_header()) )
        {
            sven_ts_in_khz = sven_get_timestamp_frequency() / 1000;

            /* Connect our handle, user-mode */
            sven_attach_handle_to_queue( app->svenh, app->hdr, SVEN_CIRCBUFFER_ID_CPU_USER );

            if ( NULL != (app->svenlog = svenlog_Create( app->hdr, log_size_megabytes )) )
            {
                struct SVENUserFilter   *uf;

                if ( NULL != (uf = svenlog_add_user_filter( app->svenlog, sven_smd_core_filter, app, &app->smd_mon )) )
                {
                    /* Set health trigger threshholds when enabled to one second */
                    app->smd_health.vid_threshhold = sven_get_timestamp_frequency();
                    app->smd_health.aud_threshhold = sven_get_timestamp_frequency();

                    if ( NULL != (uf = svenlog_add_user_filter( app->svenlog, sven_smd_health_filter, app, &app->smd_health )) )
                    {
                        if ( NULL != (app->srev = svenreverse_Create( app->hdr )) )
                        {
                            if ( cparse_init( &app->cparse, 8, 64 ) )
                            {
                                if ( NULL != (app->devh = devhandle_factory(NULL)) )
                                {
                                    ok = 1;
                                }
                            }
                        }
                    }
                }
            }
        }


        if ( !ok )
        {
            svenapp_Delete(app);
            app = NULL;
        }
    }

    return( app );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Test the command parser
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_testparser(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;
    int                 tokens_parsed;
    int                 i;

    /* how these are used */
    tokens_parsed = cparse_parse_command( &app->cparse, command );

    printf("parsed %d:", tokens_parsed );

    for ( i = 0; i < tokens_parsed; i++ )
    {
        printf( "[%d:\"%s\" %08x] ", i,
            app->cparse.token[i].token_str,
            app->cparse.token[i].token_int_value );
    }

    printf("\n");

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Recover all events from the shared memory pool
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_recover(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;

    UNUSED_PARAMETER(command);

    svenlog_Recover( app->svenlog );

    return( err );
}

#if 0
static int sven_cmd_user_filter_example(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;
    int                 tokens_parsed;
    int                 i;
    int                 filter_accept_reject;
    struct SVENEvent    mask_ev,eq_ev;

    memset( &mask_ev,0,sizeof(mask_ev) );
    memset( &eq_ev,0,sizeof(eq_ev) );

    /* to trigger on module */
    mask_ev.se_et.et_module = -1;
    eq_ev.se_et.et_module = SVEN_module_GEN2_HDMI;

    mask_ev.se_et.et_type = -1;
    eq_ev.se_et.et_type = SVEN_event_type_register_io;

    mask_ev.se_et.et_subtype = -1;
    eq_ev.se_et.et_subtype = SVEN_EV_RegIo32_Write;

    /* how these are used */
    tokens_parsed = cparse_parse_command( &app->cparse, command );

    filter_accept_reject = 0;   /* useless value */

    if ( user_wants_recorded )
        filter_accept_reject = 1;
    else if ( user_doesnt_want_recorded )
        filter_accept_reject = -1;

    /* Add this to the svenlog recorder filter list */
    svenlog_add_template_filter( app->svenlog,
        &mask_ev, &eq_ev, filter_accept_reject );

    return( err );
}
#endif

////////////////////////////////////////////////////////////////////////////////
/// @brief        read the (binary) SVEN log data from a file
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// @brief        read the (binary) SVEN log data from a file
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_load(
    struct SVENApp* app,
    const  char*    command )
{
    int                 err = 0;
    int                 tokens_parsed;

    /* how these are used */
    tokens_parsed = cparse_parse_command( &app->cparse, command );

    if ( tokens_parsed > 1 )
    {
        FILE                *fi;
        const char          *filename;
        int                  ignore_filters = 0;

        filename = app->cparse.token[1].token_str;

        if ( tokens_parsed > 2 )
        {
            ignore_filters = app->cparse.token[1].token_int_value;
        }

        if ( NULL != (fi = fopen( filename, "rb" )) )
        {
            struct SVENEvent       ev;
            struct SVENEventTag_v0 et_old;
            uint32_t               *et_data;
            int                    was_paused;
            int                    num_events_read;
            int                    num_events_passed_filter;
            bool                   use_old_ev_format = false;

            printf("reading events from file \"%s\"\n", filename );

            was_paused = svenlog_IsCapturePaused( app->svenlog );

            svenlog_Pause( app->svenlog );
            sleep(1);

            num_events_read = 0;
            num_events_passed_filter = 0;

            // Read the first event from the file.
            if ( sizeof(ev) == fread( &ev, 1, sizeof(ev), fi ) )
            {
                et_data = (uint32_t *)&ev.se_et;

                // If the first event tag is not all 1's, this data is saved
                // using the old event format.
                if (*et_data != 0xFFFFFFFF)
                {
                    printf("Detected version 0 SVENEvent format ... adapting...\n");
                    use_old_ev_format = true;

                    // Copy the event tag to an old format struct
                    *((uint32_t *)&et_old) = *et_data;

                    // Copy the old format struct elements to the new tag
                    // struct format
                    ev.se_et.et_subtype  = et_old.et_subtype;
                    ev.se_et.et_type     = et_old.et_type;
                    ev.se_et.et_unit     = et_old.et_unit;
                    ev.se_et.et_module   = et_old.et_module;
                    ev.se_et.et_gencount = et_old.et_gencount;

                    num_events_read++;

                    if ( svenlog_InsertEvent_Locally( app->svenlog, &ev,
                                                      ignore_filters ) )
                    {
                        num_events_passed_filter++;
                    }
                }
                else
                {
                    printf("Detected version %d SVENEvent format ... adapting...\n", (int)ev.u.se_ulong[0]);
                }

                while ( sizeof(ev) == fread( &ev, 1, sizeof(ev), fi ) )
                {
                    // If the file we are reading was saved using the old
                    // event tag format, convert the event tag data to the
                    // new format.
                    if (use_old_ev_format)
                    {
                        *((uint32_t *)&et_old) = *((uint32_t *)&ev.se_et);
                        ev.se_et.et_subtype  = et_old.et_subtype;
                        ev.se_et.et_type     = et_old.et_type;
                        ev.se_et.et_unit     = et_old.et_unit;
                        ev.se_et.et_module   = et_old.et_module;
                        ev.se_et.et_gencount = et_old.et_gencount;
                    }

                    num_events_read++;

                    if ( svenlog_InsertEvent_Locally( app->svenlog, &ev, ignore_filters ) )
                    {
                        num_events_passed_filter++;
                    }

                    #if 0
                    if ( 0xF == (num_events_read & 0xF) )
                    {
                        printf(".");
                    }
                    if ( 0x3FF == (num_events_read & 0x3FF) )
                    {
                        printf("\n");
                    }
                    #endif
                }
            }

            fclose(fi);
            printf("read %d of %d events from file \"%s\" %s\n", num_events_passed_filter, num_events_read, filename, ignore_filters ? "ignore filters" : "filtered" );
            printf("Event Capture is now paused, you must type run to capture again\n" );
        }
        else
        {
            printf("ERR: failed to open file \"%s\"\n", filename );
            err = 1;
        }
    }
    else
    {
        printf("ERR: usage load <filename>\n");
        err = 1;
    }

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        save the (binary) SVEN log data to a file
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_save(
    struct SVENApp* app,
    const  char*    command )
{
    int                 err = 0;
    int                 tokens_parsed;

    /* how these are used */
    tokens_parsed = cparse_parse_command( &app->cparse, command );

    if ( tokens_parsed > 1 )
    {
        FILE                *fo;
        const char          *filename;

        filename = app->cparse.token[1].token_str;

        if ( NULL != (fo = fopen( filename, "wb+" )) )
        {
            struct SVENEvent    ev;
            int                 was_paused;
            int                 num_events_written;

            was_paused = svenlog_IsCapturePaused( app->svenlog );

            svenlog_Pause( app->svenlog );

            /* look to see all events */
            svenlog_RewindLocalEventReader( app->svenlog, 0 );

            num_events_written = 0;

            printf("saving to file \"%s\" using SVENEvent format version %d\n",
                   filename, CSVEN_SAVE_VERSION );

            // Write a bogus event with an event tag with all bits set to
            // indicate this is a version 1 event log.
            memset( &ev, 0, sizeof(struct SVENEvent) );
            *((uint32_t *)&ev.se_et) = 0xFFFFFFFF;
            ev.u.se_ulong[0]         = CSVEN_SAVE_VERSION;

            if (sizeof(ev) != fwrite( &ev, 1, sizeof(ev), fo ) )
            {
                printf("ERR: Write to \"%s\" failed\n", filename );
                err = 1;
            }

            while ( ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) ) &&
                    ( err == 0 ) )
            {
                if ( sizeof(ev) != fwrite( &ev, 1, sizeof(ev), fo ) )
                {
                    printf("ERR: Write to \"%s\" failed\n", filename );
                    err = 1;
                    break;
                }
                else
                {
                    num_events_written++;
                }
            }

            /* let it start running again */
            if ( !was_paused ) svenlog_Run( app->svenlog );

            fclose(fo);
            printf("wrote %d events to file \"%s\"\n", num_events_written, filename );
        }
        else
        {
            printf("ERR: failed to open \"%s\" for save\n", filename );
            err = 1;
        }
    }
    else
    {
        printf("ERR: usage save <filename>\n");
        err = 1;
    }

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        dump the SVEN log data
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_dump(
    struct SVENApp* app,
    const  char*    command )
{
    int                 err = 0;
    int                 num_events_to_capture;
    int                 captured;
    struct SVENEvent    ev;
    static char         revstr[4096];

    /* break out the tokens from the command string */
    cparse_parse_command( &app->cparse, command );

    num_events_to_capture = 40; /* SWAG: standard linux console height */
    if ( app->cparse.num_tokens > 1 )   /* events to capture available here? */
        num_events_to_capture = app->cparse.token[1].token_int_value;
    if ( num_events_to_capture <= 0 )
        num_events_to_capture = 40;

    captured = 0;

    /* Seek backwards */
    svenlog_RewindLocalEventReader( app->svenlog, 1 );
    if ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
    {
        app->time_last_event_time = ev.se_timestamp;
    }

    /* reset last module times */
    for (err = 0; err < SVEN_module_MAX; err++ )
    {
        app->last_module_time[err] = app->time_last_event_time;
    }
    err = 0;    /* reset this */

    svenlog_RewindLocalEventReader( app->svenlog, num_events_to_capture );

    while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
    {
     #ifdef SMD_API_REVERSE
        if ( SVEN_event_type_API == ev.se_et.et_type )
        {
           autoapi_reverse_smd_event( &ev, revstr );
        }
        else
        {
           svenlog_GetEventTextString( app->svenlog, &ev, revstr );
        }
     #else
        svenlog_GetEventTextString( app->svenlog, &ev, revstr );
     #endif

        switch ( app->time_display_mode )
        {
            case 0: /* TEMPORARY */
            case TDISPLAY_DELTA:
            {
                int             delta,ms,us;

                delta = ev.se_timestamp - app->time_last_event_time;
                ms = delta / sven_ts_in_khz;     /* number of milliseconds */
                delta = delta % sven_ts_in_khz;  /* remaining clocks */

                us = delta / ((sven_ts_in_khz + 999)/1000);      /* microseconds */
                delta = delta % ((sven_ts_in_khz + 999)/1000);   /* remaining clocks */

                /* use "delta" to push back previous timestamp by un-accounted-for clocks */
                app->time_last_event_time = ev.se_timestamp - delta;

                if ( (ev.se_et.et_module >= 0) && (ev.se_et.et_module < SVEN_module_MAX) )
                {
                    int             mms,mus;

                    delta = ev.se_timestamp - app->last_module_time[ev.se_et.et_module];
                    mms = delta / sven_ts_in_khz;     /* number of milliseconds */
                    delta = delta % sven_ts_in_khz;  /* remaining clocks */

                    mus = delta / ((sven_ts_in_khz + 999)/1000);      /* microseconds */
                    delta = delta % ((sven_ts_in_khz + 999)/1000);   /* remaining clocks */

                    printf( " dt:%4d.%03d mt:%4d.%03d %s\n", ms, us, mms, mus, revstr );

                    /* Save last module timestamp */
                    /* use "delta" to push back previous timestamp by un-accounted-for clocks */
                    app->last_module_time[ev.se_et.et_module] = ev.se_timestamp - delta;
                }
                else
                {
                    printf( " dt:%4d.%03d %s\n", ms, us, revstr );
                }
            }
            break;
            case TDISPLAY_TMINUS:
            {
                int             delta,ms,us;

                delta = ev.se_timestamp - app->time_last_event_time;
                delta = -delta; /* convert to t-minus */
                ms = delta / sven_ts_in_khz;     /* number of milliseconds */
                delta = delta % sven_ts_in_khz;  /* remaining clocks */

                us = delta / ((sven_ts_in_khz + 999)/1000);      /* microseconds */

                printf( " t-:%4d.%03d %s\n", ms, us, revstr );
            }
            break;
            default:
            printf( " t:%08x %s\n", ev.se_timestamp, revstr );
            break;
        }

        if ( ++captured >= num_events_to_capture )
            break;
    }

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Search SVEN Log data for any events with payload specified
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_search(
    struct SVENApp* app,
    const  char*    command )
{
    int                 err = 0;
    unsigned int        payload_lo, payload_hi;
    struct SVENEvent    ev;
    static char         revstr[4096];

    /* break out the tokens from the command string */
    cparse_parse_command( &app->cparse, command );

    if ( app->cparse.num_tokens <= 1 )
    {
      printf("usage: search value_low [value_high]\n");
      return(0);
    }
    else
    {
      payload_lo = app->cparse.token[1].token_int_value;
      payload_hi = payload_lo + 1;

      if ( app->cparse.num_tokens > 2 )
      {
         payload_hi = app->cparse.token[2].token_int_value;
      }
    }
    /* Get timestamp of last event recorded */
    svenlog_RewindLocalEventReader( app->svenlog, 1 );
    if ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
    {
        app->time_last_event_time = ev.se_timestamp;
    }

    /* reset last module times */
    for (err = 0; err < SVEN_module_MAX; err++ )
    {
        app->last_module_time[err] = app->time_last_event_time;
    }
    err = 0;    /* reset this */

   /* go all the way to the beginning */
    svenlog_RewindLocalEventReader( app->svenlog, 0 );

    while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
    {
        int    i;
        int    is_match;

        is_match = 0;

        /* is any payload item in range? */
        for ( i = 0; i < SVEN_EVENT_PAYLOAD_NUM_UINTS; i++ )
        {
            /* is this payload in range? */
            if ( (ev.u.se_uint[i] >= payload_lo) && (ev.u.se_uint[i] < payload_hi) )
            {
               is_match = 1;
               break;
            }
        }

        if ( is_match )
        {
        #ifdef SMD_API_REVERSE
           if ( SVEN_event_type_API == ev.se_et.et_type )
           {
              autoapi_reverse_smd_event( &ev, revstr );
           }
           else
           {
              svenlog_GetEventTextString( app->svenlog, &ev, revstr );
           }
        #else
           svenlog_GetEventTextString( app->svenlog, &ev, revstr );
        #endif

            // case TDISPLAY_TMINUS: always display in tminus format
            {
                int             delta,ms,us;

                delta = ev.se_timestamp - app->time_last_event_time;
                delta = -delta; /* convert to t-minus */
                ms = delta / sven_ts_in_khz;     /* number of milliseconds */
                delta = delta % sven_ts_in_khz;  /* remaining clocks */

                us = delta / ((sven_ts_in_khz + 999)/1000);      /* microseconds */

                printf( " t-:%4d.%03d %s\n", ms, us, revstr );
            }
        }
    }

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        dump the SVEN log data in hex
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_hexdump(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;
    int                 num_events_to_capture;
    int                 captured;
    struct SVENEvent    ev;

    /* break out the tokens from the command string */
    cparse_parse_command( &app->cparse, command );

    num_events_to_capture = 40; /* SWAG: standard linux console height */
    if ( app->cparse.num_tokens > 1 )   /* events to capture available here? */
        num_events_to_capture = app->cparse.token[1].token_int_value;
    if ( num_events_to_capture <= 0 )
        num_events_to_capture = 40;


    captured = 0;

    /* Seek last thirty */
    svenlog_RewindLocalEventReader( app->svenlog, num_events_to_capture );

    while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
    {
        int             i;

        for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
            printf("%08x ", ((unsigned int *)&ev)[i] );
        }

        printf("\n");

        if ( ++captured >= num_events_to_capture )
            break;
    }

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        write data to the log
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_logwrite(
    struct SVENApp*  app,
    const  char*     command )
{
    struct SVENHandle   *svenh = app->svenh;

    UNUSED_PARAMETER(command);

    SVEN_FUNC_ENTER(svenh,0,0);
    SVEN_AUTO_TRACE(svenh,0,0);

    sven_WriteDebugString( svenh,
        0,    /* module from "sven_module.h" */
        0,    /* unit */
        SVEN_DEBUGSTR_Generic,
        NULL );

    sven_WriteDebugString( svenh,
        SVEN_module_GEN2_HDMI,    /* module from "sven_module.h" */
        0,                      /* unit */
        SVEN_DEBUGSTR_Generic,
        "Hey There" );

    SVEN_AUTO_TRACE(svenh,0,0);

    sven_WriteDebugString( svenh,
        SVEN_module_GEN2_HDMI,    /* module from "sven_module.h" */
        0,                      /* unit */
        SVEN_DEBUGSTR_FunctionEntered,
        __FUNCTION__ );

    SVEN_AUTO_TRACE(svenh,0,0);

    sven_WriteDebugString( svenh,
        SVEN_module_GEN2_HDMI,    /* module from "sven_module.h" */
        0,                      /* unit */
        SVEN_DEBUGSTR_Checkpoint,
        "about to perform regio test" );

    SVEN_AUTO_TRACE(svenh,0,0);

    /* Send out a fake register read */
    sven_WriteEventVA_ulong( svenh,
        SVEN_module_GEN2_HDMI, 0,         /* module, unit */
        SVEN_event_type_register_io,    /* event type */
        SVEN_EV_RegIo32_Read,           /* event subtype */
        2, /* two parameters in event */
        0x08,       /* physical address + offset */
        (1<<20) | (1<<17) | (1<<1) | (1<<0)  /* value written */
        );

    SVEN_AUTO_TRACE(svenh,0,0);

    /* Send out a fake register read */
    sven_WriteEventVA_ulong( svenh,
        SVEN_module_GEN2_VCAP, 0,         /* module, unit */
        SVEN_event_type_register_io,    /* event type */
        SVEN_EV_RegIo32_Read,           /* event subtype */
        2, /* two parameters in event */
        0x154,       /* physical address + offset */
        0x11223344  /* value written */
        );

    SVEN_AUTO_TRACE(svenh,0,0);

    sven_WriteDebugString( svenh,
        SVEN_module_GEN2_HDMI,    /* module from "sven_module.h" */
        0,                      /* unit */
        SVEN_DEBUGSTR_Checkpoint,
        "regio event test complete" );

    sven_WriteDebugStringEnd( svenh, 0, 0,
        SVEN_DEBUGSTR_Generic,
        "Really long string ends here." );

    SVEN_FUNC_EXIT(svenh,0,0);

    DEVH_ASSERT( app->devh, 0 );
    DEVH_ASSERT( app->devh, 1 );
    DEVH_ASSERT( app->devh, NULL != app->devh );
    DEVH_ASSERT( app->devh, NULL == app->devh );

    return( 0 );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        reset command
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_reset( struct SVENApp* app, const char* command )
{
    struct _SVENHeader *hdr;
    unsigned int        i;

    UNUSED_PARAMETER(command);

    hdr = app->hdr;

    hdr->svh_version = 0x00000000;

    /* Dump circular buffers */
    for ( i = 0; i < hdr->svh_circbuffer_count; i++ )
    {
        /* reset this */
        hdr->buffers[i].svc_pos = 0;
    }

    return( 0 );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        quit command - exit the app
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_quit(
    struct SVENApp*  app,
    const  char*     command )
{
    UNUSED_PARAMETER(command);
    app->quit_requested = 1;
    return(0);
}
////////////////////////////////////////////////////////////////////////////////
/// @brief        sleep command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_sleep( struct SVENApp* app, const char* command )
{
    int                 num_tokens = 0;
    int                 seconds_to_sleep;

    num_tokens = cparse_parse_command( &app->cparse, command );
    seconds_to_sleep = 1;

    if ( num_tokens > 1 )
    {
        seconds_to_sleep = app->cparse.token[1].token_int_value;
    }

    printf("sleeping for %d seconds\n", seconds_to_sleep );
    while ( seconds_to_sleep-- )
    {
        sleep(1);
    }

    return(0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        pause command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_pause( struct SVENApp* app, const char* command )
{
    UNUSED_PARAMETER(command);
    svenlog_Pause( app->svenlog );
    return(0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        run command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_run( struct SVENApp* app, const char* command )
{
    UNUSED_PARAMETER(command);
    svenlog_Run( app->svenlog );
    return(0);
}


////////////////////////////////////////////////////////////////////////////////
/// @brief        Creates a thread process
/// @param[in]    arg      ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static void *svenapp_svenlog_threadproc( void* arg )
{
    struct SVENApp *app;
    //    int             err = 0;

    app = (struct SVENApp *) arg;

#ifdef SVEN_CONSOLE_LINUX_ONLY
    {
        int policy, pmin, pmax, pmean;
        struct sched_param param;

        memset(&param,0,sizeof(param));
        policy = SCHED_RR;
        pmin = sched_get_priority_min(policy);
        pmax = sched_get_priority_max(policy);
        pmean = (pmin + pmax) / 2;

        pthread_setschedparam( app->svenlog_pthread, policy, &param);
    }


    //! Cancel type set to ASYNC. Default is DEFERRED, this means the thread can be cancelled at anytime,
    //! not at a cancellation point.
    pthread_setcanceltype( PTHREAD_CANCEL_ASYNCHRONOUS,NULL );//! \todo abort if this fn returns an error
#endif

    while ( ! app->svenlog_thread_quit_request )
    {
        svenlog_CaptureRealTimeEvents_Locally( app->svenlog );

        usleep( 8 * 1000 ); /* 8 milliseconds */
    }

    return(NULL);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        go command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_go( struct SVENApp* app, const char* command )
{
    int             err = 0;

    UNUSED_PARAMETER(command);

#ifdef SVEN_CONSOLE_LINUX_ONLY
    if ( !app->svenlog_pthread )
    {
        pthread_attr_init( &app->svenlog_pthread_attr );

        //NPTL (2.6 kernel thread library) requires us to set this.
        pthread_attr_setinheritsched(
            &app->svenlog_pthread_attr,
            PTHREAD_EXPLICIT_SCHED);

        if ( ! (err = pthread_create(
            &app->svenlog_pthread,
            &app->svenlog_pthread_attr,
            svenapp_svenlog_threadproc,
            app ) ) )
        {
            printf("svenlog_thread_created\n");
        }
    }
#else
    if ( ! app->svenlog_thread_create_attempted++ )
    {
        if ( ! (err = os_thread_create( &app->svenlog_thread,
                                        svenapp_svenlog_threadproc,
                                        app,
                                        0,
                                        0,
                                        NULL ) ) )
        {
            printf("svenlog_thread_created\n");
        }
    }
#endif
    else
    {
        printf("svenlog thread already running\n");
    }

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        print command string
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_echo(
    struct SVENApp*  app,
    const  char*     command )
{
    const char * echo_str = &command[4];  // chop off the word echo, leave the space
    UNUSED_PARAMETER(app);
    return printf( "%s\n", echo_str);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        print system time string
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_systime(
    struct SVENApp*  app,
    const  char*     command )
{
    time_t         systemtime  = time(NULL);
    struct tm *time_struct     = localtime(&systemtime);
    UNUSED_PARAMETER(app);
    UNUSED_PARAMETER(command);
    return printf("SysTime: %s",  (time_struct != NULL)?asctime(time_struct):"N/A\n");
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        triggerwait start thread and wait for trigger.
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_triggerwait(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;
    int                 num_tokens;
    int                 trigger_time,trigger_timeout_seconds = 0;

    printf("Starting thread and waiting for trigger event\n");

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 1 )
    {
        trigger_timeout_seconds = app->cparse.token[1].token_int_value;

        /* calculate how many 10 ms intervals (see below usleep)  */
        trigger_timeout_seconds *= 100;
    }
    
    /* Launch the thread */
    sven_cmd_go( app, command );

    trigger_time = 0;
    while ( 1 )
    {
        if ( svenlog_IsCapturePaused( app->svenlog ) )
        {
            printf("Trigger Has Completed, exiting back to console\n");
            break;
        }
        usleep(10000);  // 10mSec

        if ( trigger_timeout_seconds )
        {
           if ( ++trigger_time >= trigger_timeout_seconds )
           {
              printf("Trigger Timeout\n");
              break;
           }
        }
    }

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        monitor and print all incoming messages to terminal and file.
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_monitor(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;
    struct SVENEvent    ev;
    static char         revstr[1024];

    /* Launch the thread */
    sven_cmd_go( app, command );

    /* get a beginning timestamp */
    svenlog_RewindLocalEventReader( app->svenlog, 1 );
    if ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
    {
        app->time_last_event_time = ev.se_timestamp;
    }
    svenlog_RewindLocalEventReader( app->svenlog, 0 );

    /* reset last module times */
    for (err = 0; err < SVEN_module_MAX; err++ )
    {
        app->last_module_time[err] = app->time_last_event_time;
    }
    err = 0;    /* reset this */

    while ( 1 )
    {
        int     any_events_read;

        any_events_read = 0;

        while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
        {
            any_events_read = 1;

            if ( ev.se_et.et_module || ev.se_et.et_type )
            {
            #ifdef SMD_API_REVERSE
                if ( SVEN_event_type_API == ev.se_et.et_type )
                {
                   autoapi_reverse_smd_event( &ev, revstr );
                }
                else
                {
                   svenlog_GetEventTextString( app->svenlog, &ev, revstr );
                }
            #else
                svenlog_GetEventTextString( app->svenlog, &ev, revstr );
            #endif

                switch ( app->time_display_mode )
                {
                    case 0: /* TEMPORARY */
                    case 3:
                    case TDISPLAY_DELTA:
                    {
                        int             delta,ms,us;

                        delta = ev.se_timestamp - app->time_last_event_time;
                        ms = delta / sven_ts_in_khz;     /* number of milliseconds */
                        delta = delta % sven_ts_in_khz;  /* remaining clocks */

                        us = delta / ((sven_ts_in_khz + 999)/1000);      /* microseconds */
                        delta = delta % ((sven_ts_in_khz + 999)/1000);   /* remaining clocks */

                        if ( (ev.se_et.et_module >= 0) && (ev.se_et.et_module < SVEN_module_MAX) )
                        {
                            int             mms,mus;

                            delta = ev.se_timestamp - app->last_module_time[ev.se_et.et_module];
                            mms = delta / sven_ts_in_khz;     /* number of milliseconds */
                            delta = delta % sven_ts_in_khz;  /* remaining clocks */

                            mus = delta / ((sven_ts_in_khz + 999)/1000);      /* microseconds */
                            delta = delta % ((sven_ts_in_khz + 999)/1000);   /* remaining clocks */

                            printf( " dt:%4d.%03d mt:%4d.%03d %s\n", ms, us, mms, mus, revstr );

                            /* Save last module timestamp */
                            /* use "delta" to push back previous timestamp by un-accounted-for clocks */
                            app->last_module_time[ev.se_et.et_module] = ev.se_timestamp - delta;
                        }
                        else
                        {
                            if ( 3 == app->time_display_mode ) printf( " t:%08x dt:%4d.%03d %s\n", ev.se_timestamp, ms, us, revstr );
                            else                               printf( " dt:%4d.%03d %s\n", ms, us, revstr );
                        }

                        /* use "delta" to push back previous timestamp by un-accounted-for clocks */
                        app->time_last_event_time = ev.se_timestamp - delta;
                    }
                    break;
                    case TDISPLAY_TMINUS:
                    {
                        int             delta,ms,us;

                        delta = ev.se_timestamp - app->time_last_event_time;
                        delta = -delta; /* convert to t-minus */
                        ms = delta / sven_ts_in_khz;     /* number of milliseconds */
                        delta = delta % sven_ts_in_khz;  /* remaining clocks */

                        us = delta / ((sven_ts_in_khz + 999)/1000);      /* microseconds */

                        printf( " t-:%4d.%03d %s\n", ms, us, revstr );
                    }
                    break;
                    default:
                        printf( " t:%08x %s\n", ev.se_timestamp, revstr );
                    break;
                }
            }
        }

        if ( svenlog_IsCapturePaused( app->svenlog ) )
        {
            printf("Trigger Has Completed, exiting monitor back to console\n");
            break;
        }
        if ( 0 != any_events_read )
        {
           fflush(stdout);
        }
        usleep(4000);
        if ( g_ctrl_c_pressed )
        {
           printf("USER-BREAK\n");
           g_ctrl_c_pressed = 0;
           break;
        }
    }

    return( err );
}


////////////////////////////////////////////////////////////////////////////////
/// @brief        monitor and print all incoming messages.
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_stream(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;
    int                 tokens_parsed;
    const char          *filename;

    /* how these are used */
    tokens_parsed = cparse_parse_command( &app->cparse, command );

    if ( tokens_parsed > 1 )
    {
        FILE                *fo;

        filename = app->cparse.token[1].token_str;

        if ( NULL != (fo = fopen( filename, "wb+" )) )
        {
            struct SVENEvent    ev;

            /* Launch the thread */
            sven_cmd_go( app, command );

            /* get a beginning timestamp */
            svenlog_RewindLocalEventReader( app->svenlog, 1 );
            if ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
            {
                app->time_last_event_time = ev.se_timestamp;
            }
            svenlog_RewindLocalEventReader( app->svenlog, 0 );

            /* reset last module times */
            for (err = 0; err < SVEN_module_MAX; err++ )
            {
                app->last_module_time[err] = app->time_last_event_time;
            }
            err = 0;    /* reset this */

            while ( 1 )
            {
                while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
                {
                    if ( sizeof(ev) != fwrite( &ev, 1, sizeof(ev), fo ) )
                    {
                        printf("ERR: Write to \"%s\" failed\n", filename );
                        err = 1;
                        break;
                    }
                }

                if ( svenlog_IsCapturePaused( app->svenlog ) )
                {
                    printf("Trigger Has Completed, exiting monitor back to console\n");
                    break;
                }
                usleep(4000);
            }

            fclose(fo);
        }
        else
        {
            printf("Could not open file \"%s\"\n", filename );
        }
   }
   else
   {
       printf("usage: stream <filename>\n" );
   }

    return( err );
}


////////////////////////////////////////////////////////////////////////////////
/// @brief        decode command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_decode( struct SVENApp* app, const char* command )
{
    int                 num_tokens = 0;
    unsigned int        err = 0;

    /* Usage:  decode UNIT offset value [prev_value] */

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 3 )
    {
        const struct ModuleReverseDefs *mrd;
        const struct EAS_Register      *reg;
        const struct EAS_RegBits       *bits;
        unsigned int                    offset;

        mrd = NULL;
        reg = NULL;
        bits = NULL;

        if ( sven_reverse_Lookup( app->cparse.token[1].token_str, &mrd, &reg, &bits, &offset ) )
        {
            struct SVENEvent    ev;
            char                revstr[1024];

            _sven_initialize_event( &ev,
                (NULL != mrd) ? mrd->mrd_module : offset, 0,
                SVEN_event_type_register_io,
                SVEN_EV_RegIo32_Read );

            ev.u.se_reg.phys_addr   = app->cparse.token[2].token_int_value;
            ev.u.se_reg.value       = app->cparse.token[3].token_int_value;
            ev.u.se_reg.mask        = 0;
            if ( num_tokens > 4 )
                ev.u.se_reg.log_prev  = app->cparse.token[4].token_int_value;
            else
                ev.u.se_reg.log_prev  = 0x00000000;

            sven_reverse_GetEventTextString( revstr, NULL, &ev );

            printf("%s\n", revstr );
        }
    }
    else
    {
    }

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        peek command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_peek( struct SVENApp* app, const char* command )
{
    int                 num_tokens = 0;
    unsigned int        err = 0;

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 1 )
    {
        const struct ModuleReverseDefs *mrd;
        const struct EAS_Register      *reg;
        const struct EAS_RegBits       *bits;
        unsigned int                    offset;
        int                             lookups;
        int                             physaddr_specified;
        int                             page_size;

        mrd = NULL;
        reg = NULL;
        bits = NULL;
        physaddr_specified = 0;
        page_size = getpagesize();

        if ( (lookups = sven_reverse_Lookup( app->cparse.token[1].token_str, &mrd, &reg, &bits, &offset )) )
        {
            os_devhandle_t     *devh;

            if( NULL != (devh = devhandle_factory(NULL)) )
            {
                if ( NULL != mrd )
                {
                    const char  *devname;

                    /** Many units are named "GEN2_HDMI", "GEN1_VCAP", etc
                     * we need to skip past the underscore to open the
                     * unit by name properly
                     */
                    devname = mrd->mrd_name;
                    while ( '\0' != *devname )
                    {
                        if ( '_' == *devname )
                        {
                            devname++;  /* Skip past it */
                            break;
                        }
                        devname++;
                    }

                    if( '\0' == *devname ) /* got all the way to the end */
                    {
                        devname = mrd->mrd_name;    /* use whole string */
                    }

                    if ( ! devhandle_connect_name( devh, devname ) )
                    {
                        printf("Failed to connect to devname \"%s\"\n", devname );

                        devh_Delete(devh);
                        devh = NULL;
                    }
                }
                else if ( offset )
                {
                    physaddr_specified = 1;

                    /* Just grab a 4k page */
                    if ( ! devhandle_connect_physical_address( devh, (offset & ~(page_size-1)), page_size ) )
                    {
                        printf("Failed to connect to physaddr %08x\n", (offset & ~(page_size-1)) );

                        devh_Delete(devh);
                        devh = NULL;
                    }
                }
                else /* try opening the name anyway */
                {
                    char            devname[32];
                    int             i = 0;

                    while ( ('\0' != app->cparse.token[1].token_str[i]) &&
                            ('.' != app->cparse.token[1].token_str[i]) )
                    {
                        devname[i] = app->cparse.token[1].token_str[i];
                        i++;
                    }
                    devname[i] = '\0';

                    if ( ! devhandle_connect_name( devh, devname ) )
                    {
                        printf("Failed to connect to devname \"%s\"\n", devname );

                        devh_Delete(devh);
                        devh = NULL;
                    }
                }
            } else printf("devhandle_factory() failed\n");

            if ( NULL != devh )
            {
                unsigned int            value = 0;

                if ( NULL != mrd )  /* real module name specified */
                {
                    if ( NULL != reg )  /* real register name specified */
                    {
                        value = devh_ReadReg32( devh, reg->reg_offset );

                        printf("REG:%08x = %08x \"%s\" - \"%s\"\n",
                            reg->reg_offset, value,
                            reg->reg_name,
                            (NULL != reg->reg_comment) ? reg->reg_comment : "" );
                    }
                    else if ( lookups > 1 ) /* offset from MRD specified */
                    {
                        if ( num_tokens > 2 )
                        {
                            unsigned int         i;

                            for ( i = 0; i < app->cparse.token[2].token_int_value; i++ )
                            {
                                value = devh_ReadReg32( devh, (offset & ~0x3) + (i<<2) );

                                printf(" %08x", value );

                                if ( 0x7 == (i & 0x7) )
                                    printf("\n");
                            }
                            if ( 0x0 != (i & 0x7) )
                                printf("\n");
                        }
                        else
                        {
                            /* "offset" is offset from base */
                            value = devh_ReadReg32( devh, (offset & ~0x3) );
                            printf("REG:%08x = %08x\n", (offset & ~0x3), value );
                        }
                    }
                    else if ( NULL != (reg = mrd->mrd_regdefs) )
                    {
                        // PRINT ALL REGISTERS FOR THIS MODULE
                        while ( reg->reg_name )
                        {
                            value = devh_ReadReg32( devh, reg->reg_offset );

                            printf("REG:%08x = %08x \"%s\" - \"%s\" \n",
                                reg->reg_offset, value,
                                reg->reg_name,
                                (NULL != reg->reg_comment) ? reg->reg_comment : "" );

                            reg++;
                        }
                    }
                    else
                    {
                        /* NO Register specified, and no register breakout */
                    }
                }
                else
                {
                    if ( num_tokens > 2 )
                    {
                        int         i,first,last;
                        int         n;

                        /* now make it offset within the page */
                        first = (offset & ~0x3) - devh->devh_regs_phys_addr;
                        last = first + app->cparse.token[2].token_int_value;
                        if ( last > page_size ) last = page_size;

                        for ( i = first, n = 0; i < last; i += 4, n++ )
                        {
                            if ( 0x0 == (n & 0x7) )
                                printf("0x%08lx: ", devh->devh_regs_phys_addr + i );

                            value = devh_ReadReg32( devh, i );

                            //printf(" %08x", value );
                            printf(" %02x %02x %02x %02x ",
                                (value >> 0) & 0xFF,
                                (value >> 8) & 0xFF,
                                (value >> 16) & 0xFF,
                                (value >> 24) & 0xFF );

                            if ( 0x7 == (n & 0x7) )
                                printf("\n" );
                        }
                        if ( 0x0 != (n & 0x7) )
                            printf("\n");
                    }
                    else
                    {
                        if ( physaddr_specified )
                        {
                            /* "offset" was PHYSICAL ADDRESS, we mapped a PAGE, read from the page */
                            value = devh_ReadReg32( devh, (offset & 0xffc) );
                            printf("PHYS_ADDR:%08x = %08x\n", offset, value );
                        }
                        else /* Device without "reverse" info was opened, dump the device */
                        {
                            int         i,max;

                            if ( num_tokens > 2 )
                            {
                                max = app->cparse.token[2].token_int_value << 2;
                            }
                            else
                            {
                                max = devh->devh_regs_size;
                                if ( max > 512 )
                                    max = 512; /* artificial clamp */
                            }

                            for ( i = (offset & 0xffc); i < max; i += 4 )
                            {
                                value = devh_ReadReg32( devh, i );

                                //printf(" %08x", value );
                                printf(" %02x %02x %02x %02x ",
                                    (value >> 0) & 0xFF,
                                    (value >> 8) & 0xFF,
                                    (value >> 16) & 0xFF,
                                    (value >> 24) & 0xFF );

                                if ( (0x7<<2) == (i & (0x7<<2)) )
                                    printf("\n");
                            }
                            if ( 0x0 != (i & (0x7<<2)) )
                                printf("\n");
                        }
                    }
                }

                if ( NULL != bits )
                {
                    printf(" BITS [%d..%d] = %x ; \"%s\" - \"%s\"\n",
                        bits->regbits_lsb_pos + bits->regbits_width - 1,
                        bits->regbits_lsb_pos,
                        (value >> bits->regbits_lsb_pos) &
                            ((1 << bits->regbits_width)-1),
                        bits->regbits_name,
                        (NULL != bits->regbits_comment) ? bits->regbits_comment : "" );
                }
                else if ( (NULL != reg) && (NULL != (bits = reg->reg_bits)) )
                {
                    // PRINT ALL BITS for this Register
                #if 0
                    while ( bits->regbits_name )
                    {
                        printf( "[%s=%X] ", bits->regbits_name,
                            (value >> bits->regbits_lsb_pos) &
                                ((1 << bits->regbits_width)-1) );

                        bits++;
                    }
                    printf("\n");
                #else
                    while ( bits->regbits_name )
                    {
                        printf( " /* mask 0x%08x bits[%2d..%2d] */ %s = 0x%X \n",
                            ((1 << bits->regbits_width)-1) << bits->regbits_lsb_pos,
                            bits->regbits_lsb_pos + bits->regbits_width - 1,
                            bits->regbits_lsb_pos,
                            bits->regbits_name,
                             (value >> bits->regbits_lsb_pos) &
                                ((1 << bits->regbits_width)-1) );

                        bits++;
                    }
                #endif
                }

                devh_Delete(devh);
                devh = NULL;
            }

        } else printf("\nPeek of \"%s\" not found\n", app->cparse.token[1].token_str );
    }
    else
    {
    }

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        poke command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_poke( struct SVENApp* app, const char* command )
{
    int                 num_tokens = 0;
    unsigned int        err = 0;

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 2 )
    {
        const struct ModuleReverseDefs *mrd;
        const struct EAS_Register      *reg;
        const struct EAS_RegBits       *bits;
        unsigned int                    offset;
        int                             lookups;

        mrd = NULL;
        reg = NULL;
        bits = NULL;

        if ( (lookups = sven_reverse_Lookup( app->cparse.token[1].token_str, &mrd, &reg, &bits, &offset )) )
        {
            os_devhandle_t     *devh;

            if( NULL != (devh = devhandle_factory(NULL)) )
            {
                if ( NULL != mrd )
                {
                    const char  *devname;

                    /** Many units are named "GEN2_HDMI", "GEN1_VCAP", etc
                     * we need to skip past the underscore to open the
                     * unit by name properly
                     */
                    devname = mrd->mrd_name;
                    while ( '\0' != *devname )
                    {
                        if ( '_' == *devname )
                        {
                            devname++;  /* Skip past it */
                            break;
                        }
                        devname++;
                    }

                    if( '\0' == *devname ) /* got all the way to the end */
                    {
                        devname = mrd->mrd_name;    /* use whole string */
                    }

                    if ( ! devhandle_connect_name( devh, devname ) )
                    {
                        printf("Failed to connect to devname \"%s\"\n", devname );

                        devh_Delete(devh);
                        devh = NULL;
                    }
                }
                else
                {
                    /* Just grab a 4k page */
                    if ( ! devhandle_connect_physical_address( devh, (offset & ~0xfff), 0x1000 ) )
                    {
                        printf("Failed to connect to physaddr %08x\n", (offset & ~0xfff) );

                        devh_Delete(devh);
                        devh = NULL;
                    }
                }
            } else printf("devhandle_factory() failed\n");

            if ( NULL != devh )
            {
                unsigned int            value = 0;

                value = app->cparse.token[2].token_int_value;

                if ( NULL != mrd )  /* real module name specified */
                {
                    if ( NULL != reg )  /* real register name specified */
                    {
                        if ( NULL == bits )
                        {
                            devh_WriteReg32( devh, reg->reg_offset, value );

                            printf("REG:%08x = %08x \"%s\"\n",
                                reg->reg_offset, value, reg->reg_name );
                        }
                        else
                        {
                            unsigned int            old_value;
                            unsigned int            new_value;
                            unsigned int            mask;

                            old_value = devh_ReadReg32( devh, reg->reg_offset );

                            /* Caclulate mask for these bits */
                            mask = ((1 << bits->regbits_width)-1) << bits->regbits_lsb_pos;

                            /* Remove bitmask from previous value */
                            new_value = old_value & ~mask;

                            new_value |= (mask & (value << bits->regbits_lsb_pos));

                            devh_WriteReg32( devh, reg->reg_offset, new_value );

                            printf( "REG:%08x = %08x->%08x \"%s\"\n",
                                reg->reg_offset, old_value, new_value, reg->reg_name );
                        }
                    }
                    else if ( lookups > 1 ) /* offset from MRD specified */
                    {
                        /* "offset" is offset from base */
                        devh_WriteReg32( devh, (offset & ~0x3), value );

                        printf("REG:%08x = %08x\n", (offset & ~0x3), value );
                    }
                }
                else
                {
                    /* "offset" was PHYSICAL ADDRESS, we mapped a PAGE, read from the page */
                    devh_WriteReg32( devh, (offset & 0xffc), value );

                    printf("PHYS_ADDR:%08x = %08x\n", (offset & ~0x3), value );
                }

                devh_Delete(devh);
                devh = NULL;
            }

        } else printf("\nPeek of \"%s\" not found\n", app->cparse.token[1].token_str );
    }
    else
    {
    }

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        parse memory load/save parameters
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_parse_memory_pitch_command(
    struct SVENApp      *app,
    int                 *plength,
    int                 *pwidth,
    int                 *ppitch,
    int                 *plines,
    int                 *pappend,
    int                  start_token )
{
    int                  err = 0;
    int                  i,num_tokens;

    *plength = 0;
    *ppitch = 0;
    *pwidth = 0;
    *plines = 0;
    *pappend = 0;

    /* How many tokens are there */
    num_tokens = app->cparse.num_tokens;
    i = start_token;

    /** Memory Load/Save are build to handle scanlines
     *
     *  e.g.  "GEN2_HDMI UNIT 0 EVENT register_io SUBTYPE Write32"
     *
     *  TUPLE TABLE
     *
     *  LENGTH          number of bytes to write
     *
     *  LINEPITCH       number of bytes between scanlines
     *  LINEWIDTH       number of bytes per scanline
     *  LINES           number of scanlines to write
     *
     *  APPEND          0 or 1  append to file
     *
     *
     */
    for ( i = start_token; i < (num_tokens-1); i += 2 )
    {
        if ( !strcasecmp(app->cparse.token[i].token_str, "LENGTH") )
        {
            *plength = app->cparse.token[i+1].token_int_value;
        }
        else if ( !strcasecmp(app->cparse.token[i].token_str, "LINEPITCH") )
        {
            *ppitch = app->cparse.token[i+1].token_int_value;
        }
        else if ( !strcasecmp(app->cparse.token[i].token_str, "LINEWIDTH") )
        {
            *pwidth = app->cparse.token[i+1].token_int_value;
        }
        else if ( !strcasecmp(app->cparse.token[i].token_str, "LINES") )
        {
            *plines = app->cparse.token[i+1].token_int_value;
        }
        else if ( !strcasecmp(app->cparse.token[i].token_str, "APPEND") )
        {
            *pappend = app->cparse.token[i+1].token_int_value;
        }
        else
        {
            printf("Usage: %s <filename> <physical_address> <tuple list> where tuples are:\n"
                    " *  LENGTH          number of bytes to write\n"
                    " *\n"
                    " *  LINEPITCH       number of bytes between scanlines\n"
                    " *  LINEWIDTH       number of bytes per scanline\n"
                    " *  LINES           number of scanlines to write\n"
                    " *\n"
                    " *  APPEND          0 or 1  append to file\n"
                    " *  LENGTH          0,1,2, (number of bytes to write)\n"
                    " *\n"
                    " *  LINEPITCH       number of bytes between scanlines\n"
                    " *  LINEWIDTH       number of bytes per scanline\n"
                    " *  LINES           number of scanlines to write\n"
                    " *\n"
                    " *  APPEND          0 or 1  append to file\n",
                app->cparse.token[0].token_str );

            err = 1;
        }
    }

    return( err );
}


static int sven_cmd_mem_read_write( struct SVENApp* app, const char* command, int write_to_file )
{
    int                     err = 1;

    cparse_parse_command( &app->cparse, command );

    if ( app->cparse.num_tokens > 3 )
    {
        int                  length;
        int                  width;
        int                  pitch;
        int                  lines;
        int                  append;

        if ( 0 == (err = sven_parse_memory_pitch_command(
                app, &length, &width, &pitch, &lines, &append, 3 )) )
        {
            FILE                *fp;

            const char          *filename;
            const char          *fopen_mode;
            unsigned int         buf_phys_address;

            filename = app->cparse.token[1].token_str;
            buf_phys_address = app->cparse.token[2].token_int_value;

            if ( write_to_file )
            {
                if ( append )   fopen_mode = "ab";
                else            fopen_mode = "wb";
            }
            else
            {
                fopen_mode = "rb";
            }

            if ( NULL != (fp = fopen( filename, fopen_mode )) )
            {
                os_devhandle_t      *devh;

                if( NULL != (devh = devhandle_factory(NULL)) )
                {
                    unsigned int         buf_total_size;

                    if ( 0 != length )
                    {
                        buf_total_size = length;
                        width = length;
                        lines = 1;
                    }
                    else if ( 0 != lines )
                    {
                        if ( 0 != pitch )
                        {
                            buf_total_size = pitch * lines;
                        }
                        else
                        {
                            buf_total_size = width * lines;
                        }
                    }
                    else
                    {   /* Default to a page at physical address */
                        buf_total_size = length = 4096;
                        width = length;
                        lines = 1;
                    }

                    if ( devhandle_connect_physical_address( devh, buf_phys_address, buf_total_size ) )
                    {
                        char                *buf;
                        int                  line;

                        buf = (char *)devh->devh_regs_ptr;

                        /* Write or Read the data */
                        for ( line = 0; line < lines; line++ )
                        {
                            size_t      io_len;

                            if ( write_to_file )
                                io_len = fwrite( buf, 1, width, fp );
                            else
                                io_len = fread( buf, 1, width, fp );

                            if ( io_len != (size_t) width )
                            {
                                printf("Err: File IO\n");
                                break;
                            }

                            buf += pitch;
                        }
                    }
                    else
                    {
                        printf("Failed to connect to physaddr %08x\n", buf_phys_address );
                    }

                    devh_Delete(devh);
                    devh = NULL;
                }

                fclose(fp);
            }
            else
            {
                printf("ERR: Could not fopen( \"%s\", \"%s\")\n", filename, fopen_mode );
                err = 1;
            }
        }
    }

    if ( err )
    {
        printf("Usage: %s <filename> <physical_address> <tuple list> where tuples are:\n"
                " *  LENGTH          number of bytes to write\n"
                " *\n"
                " *  LINEPITCH       number of bytes between scanlines\n"
                " *  LINEWIDTH       number of bytes per scanline\n"
                " *  LINES           number of scanlines to write\n"
                " *\n"
                " *  APPEND          0 or 1  append to file\n",
            app->cparse.token[0].token_str );
    }

    return (err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        memload and memsave commands
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_memload( struct SVENApp* app, const char* command )
{
    return( sven_cmd_mem_read_write( app, command, 0 ) );
}

static int sven_cmd_memsave( struct SVENApp* app, const char* command )
{
    return( sven_cmd_mem_read_write( app, command, 1 ) );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        parse the template filter
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_parse_template_filter_command(
    struct SVENApp      *app,
    struct SVENEvent    *ev,
    struct SVENEvent    *mask,
    int                  start_token )
{
    int                              i,num_tokens;
    const struct ModuleReverseDefs  *module;
    const struct EventTypeReverse   *event;
    const struct EventSubtypeReverse*subevent;
    const struct EAS_Register       *reg;
    const struct EAS_RegBits        *bits;
    int                              err = 0;

    /* Pre-init */
    module = NULL;
    event = NULL;
    subevent = NULL;
    reg = NULL;
    bits = NULL;

    /* How many tokens are there */
    num_tokens = app->cparse.num_tokens;
    i = start_token;

    /** Event Descriptions are parsed as TUPLES
     *
     *  e.g.  "MODULE GEN2_HDMI UNIT 0 EVENT register_io SUBTYPE Write32"
     *
     *  TUPLE TABLE
     *
     *  MODULE          GEN2_MCH, GEN2_GPU, GEN2_MPG2VD, etc or "N"
     *  UNIT            0,1,2,....
     *  EVENT           trigger, debug_str, register_io, port_io, module_event
     *  SUBTYPE         (e.g. for register_io), Read32, Write32, SetMasked32, ...
     *
     *
     *
     */
    for ( i = start_token; i < (num_tokens-1); i += 2 )
    {
        if ( !strcasecmp(app->cparse.token[i].token_str, "MODULE") )
        {
            if( NULL != (module = svenreverse_GetModuleTables_ByName(app->cparse.token[i+1].token_str)) )
            {
                ev->se_et.et_module = module->mrd_module;
                mask->se_et.et_module = -1;
            }
            else if ( '?' == app->cparse.token[i+1].token_str[0] )
            {
                sven_cmd_list_modules( app, "" );
                err |= (1<<0);
            }
            else
            {
                ev->se_et.et_module = app->cparse.token[i+1].token_int_value;
                mask->se_et.et_module = -1;
            }
        }
        else if ( !strcasecmp(app->cparse.token[i].token_str, "UNIT") )
        {
            ev->se_et.et_unit = app->cparse.token[i+1].token_int_value;
            mask->se_et.et_unit = -1;
        }
        else if( !strcasecmp(app->cparse.token[i].token_str, "EVENT") )
        {
            if ( NULL != (event = svenreverse_EVENT_TABLES_BY_NAME(app->cparse.token[i+1].token_str)) )
            {
                ev->se_et.et_type =  event->er_type;
                mask->se_et.et_type= -1;
            }
            else if ( '?' == app->cparse.token[i+1].token_str[0] )
            {
                int                 k;

                printf("event types [");

                for ( k = 0; k < SVEN_event_type_MAX; k++ )
                {
                    const struct EventTypeReverse   *etr;

                    if ( NULL != (etr = svenreverse_EVENT_TABLES_BY_NUM(k)) )
                    {
                        printf("%s ", etr->er_name );
                    }
                }

                printf("]\n");

                err |= (1<<1);
            }
            else
            {
                ev->se_et.et_type = app->cparse.token[i+1].token_int_value;
                mask->se_et.et_type = -1;
            }
        }
        else if ( !strcasecmp(app->cparse.token[i].token_str, "SUBTYPE" ) )
        {
            if ( NULL != event )
            {
                if ( SVEN_event_type_module_specific == event->er_type )
                {
                    if ( NULL != module )
                    {
                        const struct SVEN_Module_EventSpecific  *me;
                        int                                      print_subtypes = 0;

                        if ( '?' == app->cparse.token[i+1].token_str[0] )
                            print_subtypes = 1;

                        if ( NULL != (me = module->mrd_event_specific) )
                        {
                            while ( NULL != me->mes_name )
                            {
                                if ( !strcasecmp(
                                    app->cparse.token[i+1].token_str,
                                    me->mes_name) )
                                {
                                    break;
                                }

                                me++;
                            }

                            if ( NULL != me->mes_name )
                            {
                                ev->se_et.et_subtype = me->mes_subtype;
                                mask->se_et.et_subtype = -1;
                            }
                            else
                            {
                                /* non-zero string specified */
                                if ( 0 != app->cparse.token[i+1].token_int_value )
                                {
                                    ev->se_et.et_subtype = app->cparse.token[i+1].token_int_value;
                                    mask->se_et.et_subtype = -1;
                                }
                                else
                                {
                                    printf("\tsubtype not found: %s\n", app->cparse.token[i+1].token_str);
                                    print_subtypes = 1;
                                }
                            }

                            if ( print_subtypes )
                            {
                                int cnt=0;
                                err |= (1<<2);

                                printf("subtypes: [");
                                me = module->mrd_event_specific;
                                while ( NULL != me->mes_name )
                                {
                                    printf("%-30s ", me->mes_name );
                                    me++;
                                    if ( 0 == (cnt++%4) )
                                       printf("\n");
                                }
                                printf("]\n");
                            }
                        }
                        else
                        {
                            /* non-zero string specified */
                            if ( 0 != app->cparse.token[i+1].token_int_value )
                            {
                                ev->se_et.et_subtype = app->cparse.token[i+1].token_int_value;
                                mask->se_et.et_subtype = -1;
                            }
                            else
                            {
                                printf("ERR: Must Specify Module first\n");
                                err |= (1<<4);
                            }
                        }
                    }
                    else
                    {
                        printf("ERR: Must Specify Module first\n");
                        err |= (1<<4);
                    }
                }
                else if ( NULL != event->er_subtypes )
                {
                    const struct EventSubtypeReverse    *se;
                    int                                  print_subtypes = 0;

                    se = event->er_subtypes;

                    if ( '?' == app->cparse.token[i+1].token_str[0] )
                        print_subtypes = 1;

                    while ( NULL != se->er_name )
                    {
                        if ( !strcasecmp(
                            app->cparse.token[i+1].token_str,
                            se->er_name) )
                        {
                            ev->se_et.et_subtype = se->er_subtype;
                            mask->se_et.et_subtype = -1;

                            subevent = se;  /* Keep this pointer */
                            break;
                        }

                        se++; /* next in table */
                    }

                    /* None found */
                    if ( NULL == se->er_name )
                    {
                        /* Name not found, assume hardcoded */
                        if ( app->cparse.token[i+1].token_int_value ||
                             ('0' == app->cparse.token[i+1].token_str[0]) )
                        {
                            ev->se_et.et_subtype = app->cparse.token[i+1].token_int_value;
                            mask->se_et.et_subtype = -1;
                        }
                        else
                        {
                            print_subtypes = 1;
                        }
                    }

                    if ( print_subtypes )
                    {
                        err |= (1<<2);
                        se = event->er_subtypes;

                        printf("subtypes: [");
                        while ( NULL != se->er_name )
                        {
                            printf("%s ", se->er_name );
                            se++; /* next in table */
                        }
                        printf("]\n");
                    }
                }
                else
                {
                    ev->se_et.et_subtype = app->cparse.token[i+1].token_int_value;
                    mask->se_et.et_subtype = -1;
                }
            }
            else
            {
                printf("ERR: Must Specify Event Type first\n");
                err |= (1<<4);
            }
        }
        else if ( !strcasecmp(app->cparse.token[i].token_str, "REGISTER") )
        {
            unsigned int                    offset;

            if ( sven_reverse_Lookup( app->cparse.token[i+1].token_str, &module, &reg, &bits, &offset ) )
            {
                if ( NULL != module )
                {
                    /* Force Register IO Lookup */
                    ev->se_et.et_type = SVEN_event_type_register_io;
                    mask->se_et.et_type = -1;

                    if ( NULL != reg )
                    {
                        /* Create a phys addr mask */
                        ev->u.se_reg.phys_addr      = reg->reg_offset;
                        mask->u.se_reg.phys_addr    = (module->mrd_size - 1);  /* size mask */

                        if ( NULL != bits )
                        {
                            ev->u.se_reg.value      = (0 << bits->regbits_lsb_pos);    /* TODO: parse non-zero bitfield values */
                            mask->u.se_reg.value    = ((1 << bits->regbits_width) - 1) << bits->regbits_lsb_pos;
                        }
                    }
                    else
                    {
                        printf( "Lookup:REG Not Found, offset=%08x\n", offset );

                        /* Create a phys addr mask */
                        ev->u.se_reg.phys_addr      = offset;
                        mask->u.se_reg.phys_addr    = (module->mrd_size - 1);  /* size mask */
                    }
                }
                else printf( "Lookup:MRD Not Found, offset=%08x\n", offset );
            }
            else
            {
                printf("ERR: Must Specify Module first\n");
                err |= (1<<4);
            }
        }
        else if ( !strcasecmp(app->cparse.token[i].token_str, "REGVAL") )
        {
            if ( SVEN_event_type_register_io == ev->se_et.et_type )
            {
                if ( (NULL != module) && (NULL != reg) )
                {
                    if ( NULL == bits ) /* compare the whole register value */
                    {
                        ev->u.se_reg.value      = app->cparse.token[i+1].token_int_value;
                        mask->u.se_reg.value    = 0xffffffff;
                    }
                    else                /* compare just the bitfield */
                    {
                        ev->u.se_reg.value      = (app->cparse.token[i+1].token_int_value << bits->regbits_lsb_pos);
                        mask->u.se_reg.value    = ((1 << bits->regbits_width) - 1) << bits->regbits_lsb_pos;
                    }
                }
                else
                {
                    printf("ERR: Must Specify Module and Register before REGVAL\n");
                    err |= (1<<4);
                }
            }
        }
        else
        {
            printf("Unknown tuple type \"%s\"\n", app->cparse.token[i].token_str );
            err |= (1<<5);
        }
    }

#if ( 6 == SVEN_EVENT_PAYLOAD_NUM_UINTS )
    if ( (0 == ((int *)mask)[0]) &&
         (0 == ((int *)mask)[1]) &&
         (0 == ((int *)mask)[2]) &&
         (0 == ((int *)mask)[3]) &&
         (0 == ((int *)mask)[4]) &&
         (0 == ((int *)mask)[5]) &&
         (0 == ((int *)mask)[6]) &&
         (0 == ((int *)mask)[7]) )
    {
        err = 1;
    }
#else
    _TODO_FIX_TEMPLATE_PARSER_FUNCTION_;
#endif

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        trigger delay command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_triggerdelay( struct SVENApp* app, const char* command )
{
    int                     err = 0;

    cparse_parse_command( &app->cparse, command );

    if ( app->cparse.num_tokens > 1 )
    {
        if ( app->cparse.token[1].token_int_value )
        {
            svenlog_SetTriggerDelay( app->svenlog, app->cparse.token[1].token_int_value );
            printf("new trigger delay = %d events\n", app->cparse.token[1].token_int_value );
        }
        else
        {
            printf("cannot set trigger delay of zero\n");
        }
    }
    else
    {
        printf("Usage: triggerdelay <number of events>\n");
    }

    return (err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        trigger command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_trigger( struct SVENApp* app, const char* command )
{
    int                     err = 0;
    struct SVENEvent        ev, mask;

    /*Blanks for Now Will Fill in as we go along*/
    memset( &ev, 0, sizeof(ev) );
    memset( &mask, 0, sizeof(mask) );

    cparse_parse_command( &app->cparse, command );

    if ( app->cparse.num_tokens > 1 )
    {
        if ( ! sven_parse_template_filter_command( app, &ev, &mask, 1 ) )
        {
            #if 1
            int                     i;
            printf("Adding Trigger:\n" );
            printf(" EV: " );
            for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
                printf("%08x ", ((unsigned int *)&ev)[i] );
            }
            printf("\n");
            printf(" MSK:" );
            for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
                printf("%08x ", ((unsigned int *)&mask)[i] );
            }
            printf("\n");
            #endif

            svenlog_add_template_trigger(app->svenlog, &mask, &ev );
        }
    }
    else
    {
        printf("Usage: trigger <event specification>\n");
    }

    return (err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        list modules command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_list_modules( struct SVENApp* app, const char* command )
{
    int                 module;

    UNUSED_PARAMETER(app);
    UNUSED_PARAMETER(command);

    for ( module = 0; module < SVEN_module_MAX; module++ )
    {
        const struct ModuleReverseDefs  *mrd;

        if ( NULL != (mrd = svenreverse_GetModuleTables(module)) )
        {
            if ( NULL != mrd->mrd_name )
            {
                printf( "Module %2d: %-12s - \"%s\"\n",
                    mrd->mrd_module, mrd->mrd_name,
                    (NULL == mrd->mrd_comment) ? "(no comment)" : mrd->mrd_comment );
            }
        }
    }
    return(0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        filter command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_filter( struct SVENApp* app, const char* command )
{
    int                     err = 0;
    int                     filter_mode = 0;       /* -1 = accept, +1 = reject */

    cparse_parse_command( &app->cparse, command );

    /* e.g. "filter accept ..... " */
    if ( app->cparse.num_tokens > 2 )
    {
        struct SVENEvent        ev, mask;

        if( !strcasecmp(app->cparse.token[1].token_str, "REJECT") )
        {
            if( ! strcasecmp(app->cparse.token[2].token_str, "ALL") )
            {
                svenlog_set_filter_default( app->svenlog, -1 );
                printf("SVENLog default rejects all events\n" );
                return(err); /* EXIT NOW */
            }
            filter_mode = -1;
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "ACCEPT") )
        {
            if( ! strcasecmp(app->cparse.token[2].token_str, "ALL") )
            {
                svenlog_set_filter_default( app->svenlog, 0 );
                printf("SVENLog default accepts all events\n" );
                return(err); /* EXIT NOW */
            }
            filter_mode = 1;
        }

        /*Blanks for Now Will Fill in as we go along*/
        memset( &ev, 0, sizeof(ev) );
        memset( &mask, 0, sizeof(mask) );

        if ( ! sven_parse_template_filter_command( app, &ev, &mask, 2 ) )
        {
            #if 1
            int                     i;
            printf("Adding Filter:\n" );
            printf(" EV: " );
            for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
                printf("%08x ", ((unsigned int *)&ev)[i] );
            }
            printf("\n");
            printf(" MSK:" );
            for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
                printf("%08x ", ((unsigned int *)&mask)[i] );
            }
            printf("\n");
            #endif

            svenlog_add_template_filter( app->svenlog, &mask, &ev, filter_mode );
        }
    }

    if ( 0 == filter_mode )
    {
        printf("ERR: usage filter [accept|reject] <event specification>\n");
    }

    return (err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        hot enable/disable of sven event writers through the shared
///               dword *g_sven_dfx_hot.
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_hot( struct SVENApp* app, const char* command )
{
    int                     err = 0;
    int                     print_usage = 1;

    cparse_parse_command( &app->cparse, command );

    /* e.g. "filter accept ..... " */
    if ( app->cparse.num_tokens > 2 )
    {
        int                     mask_is_disable = 1;
        unsigned int            new_mask = 0;

        print_usage = 0;

        /* read first parameter */
        if( !strncasecmp(app->cparse.token[1].token_str, "DIS", 3 ) )
        {
            mask_is_disable = 1;
        }
        else if( !strncasecmp(app->cparse.token[1].token_str, "EN", 2 ) )
        {
            mask_is_disable = 0;
        }
        else
        {
            print_usage = 1;
        }

        if( ! strcasecmp(app->cparse.token[2].token_str, "ALL") )
        {
            new_mask = 0xffffffff;
        }
        else if( ! strncasecmp(app->cparse.token[2].token_str, "STR", 3 ) )
        {
            new_mask = SVENHeader_DISABLE_STRINGS;
        }
        else if( ! strncasecmp(app->cparse.token[2].token_str, "SMD", 3 ) )
        {
            new_mask = SVENHeader_DISABLE_SMD;
        }
        else if( ! strncasecmp(app->cparse.token[2].token_str, "MOD", 3 ) )
        {
            new_mask = SVENHeader_DISABLE_MODULE;
        }
        else if( ! strncasecmp(app->cparse.token[2].token_str, "REG", 3 ) )
        {
            new_mask = SVENHeader_DISABLE_REGIO;
        }
        else if( ! strncasecmp(app->cparse.token[2].token_str, "FUN", 3 ) )
        {
            new_mask = SVENHeader_DISABLE_FUNCTION;
        }
        else if( ! strncasecmp(app->cparse.token[2].token_str, "TRA", 3 ) )
        {
            new_mask = SVENHeader_DISABLE_FUNCTION; /* trace */
        }
        else if( ! strncasecmp(app->cparse.token[2].token_str, "PERF", 4 ) )
        {
            new_mask = SVENHeader_DISABLE_PERFORMANCE;
        }
        else if( ! strncasecmp(app->cparse.token[2].token_str, "API", 3 ) )
        {
            new_mask = SVENHeader_DISABLE_API;
        }
        else if( ! strncasecmp(app->cparse.token[2].token_str, "FW", 2 ) )
        {
            new_mask = SVENHeader_DISABLE_FW;
        }
        else if( ! strncasecmp(app->cparse.token[2].token_str, "ANY", 3 ) )
        {
            new_mask = SVENHeader_DISABLE_ANY;
        }
        else if( app->cparse.token[2].token_int_value )
        {
            new_mask = app->cparse.token[2].token_int_value;
        }
        else
        {
            print_usage = 1;
        }

        if ( ! print_usage )
        {
            struct _SVENHeader *hdr;
            unsigned int        written_mask;
            unsigned int        old_mask;

            hdr = app->hdr;

            old_mask = *app->esvenh.phot;

            if ( mask_is_disable )
            {
                written_mask = (old_mask | new_mask);
                *app->esvenh.phot = written_mask;
            }
            else
            {
                written_mask = (old_mask & ~(new_mask|SVENHeader_DISABLE_ANY));
                *app->esvenh.phot = written_mask;
            }
            printf(" hdr disable: 0x%08x -> 0x%08x\n", old_mask, written_mask );
        }
    }

    if ( print_usage )
    {
        printf("ERR: usage hot [enable|disable] [all|strings|regio|func|smd|mod|perf|api|fw]\n");
    }

    return (err);
}

#if 0
////////////////////////////////////////////////////////////////////////////////
/// @brief        pmu command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_pmu( struct SVENApp* app, const char* command )
{

    /*Blanks for Now Will Fill in as we go along*/
    struct gen2_pmu_t                *pmu_t;
    os_thread_t                     pmu_thread;
//  pthread_t                       pmu_thread;
    char                        str[128] = "";
    int                             num_tokens = 0;
    int                             unit_number;
    if (NULL != (pmu_t = malloc(sizeof(gen2_pmu_t))))
        {
        pmu_t       =               memset(pmu_t, 0, sizeof(gen2_pmu_t));
        }
    else
        return 1;

    num_tokens = cparse_parse_command( &app->cparse, command );
    printf("\n Sample Commads for PMU #pmu DUT <filename> or #pmu DUT UNIT EVENT SUBEVENT ITERATIONS MONITOR_TYPE INTERVAL");
    printf("\nDUT=  VR/GEN2, UNIT = UNIT_NAME, EVENT = HEX_VALUE SUBEVENT =HEX_VALUE ITERATIONS = INT VALUE MONITOR_TYPE = DURATION_EDGE INTERVAL = INT VALUE\n");
    printf("\n pmu gen2 mcu 0x4 0x0 1000 DURATION 30\n");
    printf("\n pmu VR vrconfig <num_times> <duration>");
    if (!((num_tokens == 5) || (num_tokens == 8)))
        printf("\n Command-Line Entered is incorrect\n");
    else
        {

            if (num_tokens == 5)
            {
                if (!(strcasecmp(app->cparse.token[1].token_str, "VR")))
                    {
                        sprintf(str, "source %s", app->cparse.token[2].token_str);
                        sven_cmd_source(app, str);
                        return 0;
                    }
            }
            if (num_tokens == 8)
            {

                if(!strcasecmp(app->cparse.token[1].token_str, "GEN2"))
                {
                    unit_number = get_pmu_unit_hex(app->cparse.token[2].token_str);
                    pmu_t->unit_id = unit_number;
                    pmu_t->event_id = app->cparse.token[3].token_int_value;
                    pmu_t->sub_event_id = app->cparse.token[4].token_int_value;
                    pmu_t->num_times = app->cparse.token[5].token_int_value;
                    if (!strcasecmp(app->cparse.token[6].token_str, "EDGE"))
                        pmu_t->monitor_type = EDGE;
                    else
                        pmu_t->monitor_type = DURATION; //Default is Duration

                    pmu_t->interval = app->cparse.token[7].token_int_value;
                    gen2_pmu_worker((void *)pmu_t);

                    if (pmu_t != NULL)
                        printf("PMU pointer %8x", pmu_t);
                }
//              pthread_create(&pmu_thread, NULL, (void *)&gen2_pmu_worker, (void *) (pmu_t));
//              os_thread_create(&pmu_thread, (void *)&gen2_pmu_worker,NULL,0,0,NULL );
            }
        }
        free(pmu_t);
    return 0;
}

/////////////////////////////////////////////////////////////////////////////////
/// @brief gpio command
/// @returns Error Value or Zero on sucess
/////////////////////////////////////////////////////////////////////////////////

 static int  sven_cmd_gpio(struct SVENApp *app, const char* command)
 {
    os_devhandle_t          *devh;
       int                       num_tokens =0;
    unsigned int                 err = 0;
    unsigned int                position = 0x1;
        num_tokens = cparse_parse_command( &app->cparse, command );
        if (num_tokens != 4)
        {
        printf("Sample GPIO Command\n");
        printf("gpio vr 4 1\n");
        printf("Sets gpio pin 4 high\n");
            }
    else
        {
        position = 1 << position;
        if(NULL != (devh = devhandle_factory(NULL)))
            {
                if( devhandle_connect_name (devh, "GPIO"))
                    {
                    devh_WriteReg32( devh, 0x4, position);
                    devh_WriteReg32(devh, 0x0, position);
                    usleep(100);
                    }
                else
                    {
                    DEVH_FATAL_ERROR(devh, "could not connect to UNIT");
                    devh_Delete(devh);
                    devh = NULL;
                    }
            }

        }
    return (0);
 }
#endif

////////////////////////////////////////////////////////////////////////////////
/// @brief        Select time Display mode
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_time( struct SVENApp* app, const char* command )
{
    int         num_tokens;
    int         print_help = 0;

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 1 )
    {
        if ( !strcasecmp( "default", app->cparse.token[1].token_str ) )
        {
            app->time_display_mode = 0;
        }
        else if ( !strcasecmp( "delta", app->cparse.token[1].token_str ) )
        {
            app->time_display_mode = 1;
        }
        else if ( !strcasecmp( "tminus", app->cparse.token[1].token_str ) )
        {
            app->time_display_mode = 2;
        }
        else if ( !strcasecmp( "help", app->cparse.token[1].token_str ) )
        {
            print_help = 1;
        }
        else
        {
            app->time_display_mode = app->cparse.token[1].token_int_value;;
        }

        printf("time display mode is now %d\n", app->time_display_mode );
    }
    else
    {
        print_help = 1;
    }

    if ( print_help )
    {
        const char      *c;

        c = app->cparse.token[0].token_str;

        printf( "Usage %s [default|delta|tminus|<num>]\n", c );
        printf( "      %s default - display regular timestamps\n"
                "      %s delta   - display time since previous timestamp, in microseconds\n"
                "      %s tminus  - display time in t-minus trigger time\n"
                "      %s <num>   - set other time mode by number\n",c,c,c,c );
    }


    return (0);
}

#include <sys/time.h>
#include <auto_eas/gen3_dfx.h>

////////////////////////////////////////////////////////////////////////////////
/// @brief        Demo peek/poke code for dttc demo
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_timestamp( struct SVENApp* app, const char* command )
{
   os_devhandle_t          *devh;

   UNUSED_PARAMETER(app);
   UNUSED_PARAMETER(command);

   if ( NULL != (devh = devhandle_factory(NULL)) )
   {
      if ( devhandle_connect_name( devh, "DFX" ) )
      {
         #define TIMESTAMP_CHECK 30
         #define get_dfx_timestamp( devh )   (((volatile unsigned int *)(devh)->devh_regs_ptr)[ROFF_DFX_DBG_TIMESTAMP>>2])
         int               i;
         unsigned int      t[TIMESTAMP_CHECK];
         unsigned int      rt[TIMESTAMP_CHECK];
         struct timeval    tv[TIMESTAMP_CHECK];


         for ( i = 0; i < TIMESTAMP_CHECK; i++ )
         {
            t[i] = sventimestamp();
            rt[i] = get_dfx_timestamp(devh);
            gettimeofday( &tv[i], NULL );
            printf("time: %2d sven %08d dfx %08d tvu %08d\n", i, t[i], rt[i], (int) tv[i].tv_usec );
            sleep(1);
         }

         for ( i = 1; i < TIMESTAMP_CHECK; i++ )
         {
            tv[i].tv_usec += (tv[i].tv_sec - tv[0].tv_sec) * 1000000;

            /* Calculate to end */
            tv[i].tv_usec -= tv[0].tv_usec;
            t[i] -= t[0];
            rt[i] -= rt[0];
         }

         printf("=================================================\n" );

         t[0] = 0;
         rt[0] = 0;
         tv[0].tv_usec = 0;

         for ( i = 0; i < TIMESTAMP_CHECK; i++ )
         {
            printf("time: %2d sven %08d dfx %08d tvu %08d\n", i, t[i], rt[i], (int) tv[i].tv_usec );
         }

         i = TIMESTAMP_CHECK - 1;
         printf("SVEN Timestamp Frequency (kHz):  %d  0x%08x\n",
            (int) ( ((long long)t[i] * 1000) / tv[i].tv_usec),
            (int) ( ((long long)t[i] * 1000) / tv[i].tv_usec) );
         printf(" XSI Timestamp Frequency (kHz):  %d  0x%08x\n",
            (int) ( ((long long)rt[i] * 1000) / tv[i].tv_usec),
            (int) ( ((long long)rt[i] * 1000) / tv[i].tv_usec) );
      }

      devh_Delete(devh);
   }

   return (0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Demo peek/poke code for dttc demo
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_dttc_example( struct SVENApp* app, const char* command )
{
    os_devhandle_t          *devh;

    UNUSED_PARAMETER(app);
    UNUSED_PARAMETER(command);

    if ( NULL != (devh = devhandle_factory(NULL)) )
    {
        if ( devhandle_connect_name( devh, "MCH" ) )
        {
            DEVH_AUTO_TRACE( devh ); // SVEN: Inserts time, filename, line# Event

            devh_WriteReg32( devh, 0xE40, 0xCCCCCCCC ); // SVEN Write MCH.NOA5 Register
            devh_WriteReg32( devh, 0xE44, 0x55555555 ); // SVEN Write MCH.NOA6 Register
            devh_WriteReg32( devh, 0xE48, 0x00035735 ); // SVEN Write MCH.NOA7 Register
            devh_WriteReg32( devh, 0xE50, 0x00000000 ); // SVEN Write MCH.CW Selection Register
            devh_WriteReg32( devh, 0xE50, 0x00026D93 ); // SVEN Write MCH.CW Selection Register
        }
        else
        {
            DEVH_AUTO_TRACE( devh ); // SVEN: Inserts time, filename, line# Event
            DEVH_FATAL_ERROR( devh, "Cannot Open MCH" ); // Debug string, fatal
        }

        devh_Delete(devh);
    }

    return (0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        CMU
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_get_xsi_speed( struct SVENApp* app, const char* command )
{
    os_devhandle_t          *devh;

    UNUSED_PARAMETER(app);
    UNUSED_PARAMETER(command);

    if ( NULL != (devh = devhandle_factory(NULL)) )
    {
        if ( devhandle_connect_pci_bus_dev_fun_bar( devh, 0,0,2,0 ) )
        {
            uint32_t          val;

/*
HPLL VCO         MEM_SPEED[1:0]  DDR Speed   mcclk frequency   mdclk frequency
frequency, MHz   strap           Grade       MHz               MHz
1600             00              DDR2-400    200               400
1600             01              DDR2-533    266.67            533.33
2000             10              DDR2-667    333.33            666.67
1600             11              DDR2-800    400               800
*/

            val = devh_ReadReg32( devh, 0x15<<2 );
            val = (val >> 5) & 0x3;
            switch ( val )
            {
               case 0:
               case 1:
               case 3:
               {
                  printf("xsi speed is 266 MHz\n");
               }
               break;

               case 2:
               {
                  printf("xsi speed is 250 MHz\n");
               }
               break;
            }

        }
        else
        {
            printf("err: cannot open PCI bus %d dev %d fun %d bar %d\n", 0,0,2,0 );
        }

        devh_Delete(devh);
    }
    else
    {
        printf("err: cannot devhandle_factory()\n" );
    }

    return (0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Demo NULL devh code
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_NULL_devh( struct SVENApp* app, const char* command )
{
    UNUSED_PARAMETER(app);
    UNUSED_PARAMETER(command);

    DEVH_AUTO_TRACE( NULL ); // SVEN: Inserts time, filename, line# Event
    devh_WriteReg32( NULL, 0xE40, 0xCCCCCCCC ); // SVEN Write MCH.NOA5 Register
    DEVH_AUTO_TRACE( NULL ); // SVEN: Inserts time, filename, line# Event
    DEVH_FATAL_ERROR( NULL, "Cannot Open MCH" ); // Debug string, fatal
    DEVH_ASSERT( NULL, 0 );
    DEVH_ASSERT( NULL, 1 );
    return (0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Chipwatcher doorstep select command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_omar( struct SVENApp* app, const char* command )
{
    int         num_tokens;
    int         err = 0;

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 1 )
    {
        if( !strcasecmp(app->cparse.token[1].token_str, "OPEN"))
        {
            if ( NULL != app->omar )
            {
                wavesource_Delete(app->omar);
                app->omar = NULL;
            }

            if ( NULL != (app->omar = wavesource_Create(0,0,0)) )
            {
               wavesource_ParseConfig( app->omar, NULL, 0 );
            }
            else
            {
                printf("ERR: wavesource_Create(0,0,0) failed\n");
                err = 1;
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "CLOSE"))
        {
            if ( NULL != app->omar )
            {
                wavesource_Delete(app->omar);
                app->omar = NULL;
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "INTERVAL"))
        {
            if ( (NULL != app->omar) && (num_tokens > 2) )
            {
                wavesource_SetCaptureInterval( app->omar, app->cparse.token[2].token_int_value );
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "PARAM"))
        {
            if ( (NULL != app->omar) && (num_tokens > 3) )
            {
                wavesource_SetProperty( app->omar,
                    app->cparse.token[2].token_str,
                    app->cparse.token[3].token_int_value );
            }
            else
            {
                printf("usage: OMAR PARAM <param_name> <param_value>\n" );
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "SIGNAME"))
        {
            if ( (NULL != app->omar) && (num_tokens > 3) )
            {
                //wavesource_SetSignalName( app->omar,
                //    app->cparse.token[2].token_int_value,
                //    app->cparse.token[3].token_str );
                printf("ERR: \"%s\"not implemented\n", app->cparse.token[1].token_str );
            }
            else
            {
                printf("usage: OMAR SIGNAME <signal_number> <signal_name>\n" );
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "ENABLE"))
        {
            if ( (NULL != app->omar) && (num_tokens > 2) )
            {
                int             min,max;

                if( !strcasecmp(app->cparse.token[2].token_str, "ALL") )
                {
                    min = 0; max = 255;
                }
                else
                {
                    min = max = app->cparse.token[2].token_int_value;
                    if ( num_tokens > 3 )
                    {
                        max = app->cparse.token[3].token_int_value;
                    }
                }
                if ( min < 0 )          min = 0;
                else if ( min > 255 )   min = 255;

                if ( max < 0 )          max = 0;
                else if ( max > 255 )   max = 255;

                printf("ERR: \"%s\"not implemented\n", app->cparse.token[1].token_str );
                //while ( min <= max )
                //{
                //    wavesource_EnableSignalCapture( app->omar, min );
                //    min++;
                //}
            }
            else
            {
                printf("usage: OMAR ENABLE {ALL | <signal_number> [max_signal_number]}\n" );
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "DISABLE"))
        {
            if ( (NULL != app->omar) && (num_tokens > 2) )
            {
                int             min,max;

                if( !strcasecmp(app->cparse.token[2].token_str, "ALL") )
                {
                    min = 0; max = 255;
                }
                else
                {
                    min = max = app->cparse.token[2].token_int_value;
                    if ( num_tokens > 3 )
                    {
                        max = app->cparse.token[3].token_int_value;
                    }
                }
                if ( min < 0 )          min = 0;
                else if ( min > 255 )   min = 255;

                if ( max < 0 )          max = 0;
                else if ( max > 255 )   max = 255;

                printf("ERR: \"%s\"not implemented\n", app->cparse.token[1].token_str );
                //while ( min <= max )
                //{
                //    wavesource_DisableSignalCapture( app->omar, min );
                //    min++;
                //}
            }
            else
            {
                printf("usage: OMAR DISABLE {ALL | <signal_number> [max_signal_number]}\n" );
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "PEEK"))
        {
            if ( NULL != app->omar )
            {
                //printf("OMAR: CapturePointer=0x%08x\n", wavesource_GetCurrentCapturePointer(app->omar) );
                printf("ERR: \"%s\"not implemented\n", app->cparse.token[1].token_str );
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "START"))
        {
            if ( NULL != app->omar )
            {
                wavesource_StartCapture( app->omar );
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "STOP"))
        {
            if ( NULL != app->omar )
            {
                wavesource_StopCapture( app->omar );
                printf("OMAR: capture stopped\n");
                //wavesource_AnalyzeCapture( app->omar );
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "SAVE"))
        {
            if ( (NULL != app->omar) && (num_tokens > 2) )
            {
                //wavesource_SaveCapture( app->omar, app->cparse.token[2].token_str );
                printf("ERR: \"%s\"not implemented\n", app->cparse.token[1].token_str );
            }
            else
            {
                printf("ERR: Save must specify filename\n");
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "INSPECT"))
        {
            if ( NULL != app->omar )
            {
                int         start,stop;

                start = 0;

                if ( num_tokens > 2 )
                    start = app->cparse.token[2].token_int_value;

                stop = start + 1;

                if ( num_tokens > 3 )
                    stop = app->cparse.token[3].token_int_value;

                //wavesource_Inspect( app->omar, start, stop );
                printf("ERR: \"%s\"not implemented\n", app->cparse.token[1].token_str );
            }
            else
            {
                printf("ERR: Save must specify filename\n");
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "FLUSH"))
        {
            if ( NULL != app->omar )
            {
                int         start,stop;

                start = 0;

                if ( num_tokens > 2 )
                    start = app->cparse.token[2].token_int_value;

                stop = start + 1;

                if ( num_tokens > 3 )
                    stop = app->cparse.token[3].token_int_value;

                //wavesource_Flush( app->omar, start, stop );
                printf("ERR: \"%s\"not implemented\n", app->cparse.token[1].token_str );
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "HELP"))
        {
            printf("  OMAR OPEN [mmr_addr] [capture_addr] [capture_size]\n" );
            printf("  OMAR CLOSE\n" );
            printf("  OMAR INTERVAL <interval-in-xsi-clocks>\n" );
            printf("  OMAR SIGNAME <signal_number> <signal_name>\n" );
            printf("  OMAR ENABLE {ALL | <signal_number> [max_signal_number]}\n" );
            printf("  OMAR DISABLE {ALL | <signal_number> [max_signal_number]}\n" );
            printf("  OMAR INSPECT [start] [stop]\n" );
            printf("  OMAR FLUSH [start] [stop]\n" );
            printf("  OMAR PEEK\n" );
            printf("  OMAR START\n" );
            printf("  OMAR STOP\n" );
            printf("  OMAR SAVE <filename.vcd>\n" );
        }
        else
        {
            printf("ERR: Unknown OMAR Command \"%s\"\n", app->cparse.token[1].token_str );
        }
    }
    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Chipwatcher doorstep select command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_cw( struct SVENApp* app, const char* command )
{
    int         num_tokens;

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( 1 != num_tokens  )
    {
        os_devhandle_t          *devh;

        if ( NULL != (devh = devhandle_factory(NULL)) )
        {
            if ( devhandle_connect_name( devh, "MCH" ) )
            {
                int                 d0,d1,m0,m1;

                devh_WriteReg32( devh, 0xE30, 0x00000000 ); // NOA1 Register
                devh_WriteReg32( devh, 0xE34, 0x00000000 ); // NOA2 Register
                devh_WriteReg32( devh, 0xE38, 0x00000000 ); // NOA3 Register
                devh_WriteReg32( devh, 0xE3C, 0x00000000 ); // NOA4 Register
                devh_WriteReg32( devh, 0xE40, 0xCCCCCCCC ); // NOA5 Register
                devh_WriteReg32( devh, 0xE44, 0x55555555 ); // NOA6 Register
                devh_WriteReg32( devh, 0xE48, 0x00035735 ); // NOA7 Register
                devh_WriteReg32( devh, 0xE50, 0x00046952 ); // CW Selection Register
                devh_WriteReg32( devh, 0xE54, 0x00000000 ); // CW Deskew0 Register
                devh_WriteReg32( devh, 0xE58, 0x00000000 ); // CW Deskew1 Register
                devh_WriteReg32( devh, 0xE5C, 0x00000000 ); // CW Deskew2 Register

                /* Turn on pattern generation */
                if ( ((unsigned int)-1) == app->cparse.token[1].token_int_value )
                {
                    devh_WriteReg32( devh, 0xE48, 0x01035735 ); // NOA7 Register
                    printf("Select Pattern on CW Bus\n");
                }
                else if ( 5 == num_tokens )
                {
                    unsigned int        sel;

                    d0 = app->cparse.token[1].token_int_value;
                    m0 = app->cparse.token[2].token_int_value;
                    d1 = app->cparse.token[3].token_int_value;
                    m1 = app->cparse.token[4].token_int_value;

                    sel = 0;
                    sel |= (0 << 21);           // DSU_GROUP_DATA_INPUT_BYPASS_TIMING_CHARACTERIZATION
                    sel |= (0 << 20);           // DSU_GROUP_DATA_INPUT_BYPASS_TIMING_CHARACTERIZATION
                    sel |= ((0x7 & m1) << 17);  // DSU_8X1_2nd_mux_Select
                    sel |= ((0x7 & m0) << 14);  // DSU_8X1_1st_mux_Select
                    sel |= ((0x7F & d1) << 7);  // 2nd_Chipwatcher_DSU_Select
                    sel |= ((0x7F & d0) << 0);  // 1st_Chipwatcher_DSU_Select

                    devh_WriteReg32( devh, 0xE50, sel ); // CW Selection Register

                    printf("CW Showing %d.%d %d.%d\n",d0,m0,d1,m1);
                }
                else if ( 3 == num_tokens )
                {
                    unsigned int        sel;

                    d0 = app->cparse.token[1].token_int_value;
                    m0 = app->cparse.token[2].token_int_value;
                    d1 = d0;
                    m1 = m0;

                    sel = 0;
                    sel |= (0 << 21);           // DSU_GROUP_DATA_INPUT_BYPASS_TIMING_CHARACTERIZATION
                    sel |= (0 << 20);           // DSU_GROUP_DATA_INPUT_BYPASS_TIMING_CHARACTERIZATION
                    sel |= ((0x7 & m1) << 17);  // DSU_8X1_2nd_mux_Select
                    sel |= ((0x7 & m0) << 14);  // DSU_8X1_1st_mux_Select
                    sel |= ((0x7F & d1) << 7);  // 2nd_Chipwatcher_DSU_Select
                    sel |= ((0x7F & d0) << 0);  // 1st_Chipwatcher_DSU_Select

                    devh_WriteReg32( devh, 0xE50, sel ); // CW Selection Register

                    printf("CW Showing %d.%d %d.%d\n",d0,m0,d1,m1);
                }
                else
                {
                    printf("ERR: could not parse cw select command\n");
                }
            }
            else
            {
                printf("ERR: Could not create devhandle\n");
            }

            devh_Delete(devh);
        }
    }
    else
    {
        printf("ERR: Usage %s doorstep mux doorstep mux\n", app->cparse.token[0].token_str );
    }
    return (0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Lookup a register string
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_lookup( struct SVENApp* app, const char* command )
{
    int                             num_tokens;

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 1 )
    {
        const struct ModuleReverseDefs *mrd;
        const struct EAS_Register      *reg;
        const struct EAS_RegBits       *bits;
        unsigned int                    offset;

        mrd = NULL;
        reg = NULL;
        bits = NULL;

        if ( sven_reverse_Lookup(
            app->cparse.token[1].token_str,
            &mrd, &reg, &bits, &offset ) )
        {
            if ( NULL != mrd )
            {
                printf("MRD:%d \"%s\" siz:%08x\n",
                    (int) mrd->mrd_module,
                    mrd->mrd_name,
                    (int) mrd->mrd_size );

                if ( NULL != reg )
                {
                    printf("REG:%08x \"%s\" - \"%s\" \n",
                        reg->reg_offset,
                        reg->reg_name,
                        (NULL != reg->reg_comment) ? reg->reg_comment : "" );

                    if ( NULL != bits )
                    {
                        printf("BITS [%d..%d] \"%s\" - \"%s\" \n",
                            bits->regbits_lsb_pos + bits->regbits_width,
                            bits->regbits_lsb_pos,
                            bits->regbits_name,
                            (NULL != bits->regbits_comment) ? bits->regbits_comment : "" );
                    }
                    else printf( "Lookup:BITS Not Found, offset=%08x\n", offset );
                }
                else printf( "Lookup:REG Not Found, offset=%08x\n", offset );
            }
            else printf( "Lookup:MRD Not Found, offset=%08x\n", offset );
        }
        else printf( "Lookup failed\n" );
    }

    return(num_tokens);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        source command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_source( struct SVENApp* app, const char* command )
{
    FILE        *old_fin;
    const char  *fn;
    int          err = 0;
    /* Save */
    old_fin = app->fin;
    fn = command;

    while ( *fn && (' ' != *fn) )  fn++;    /* Seek space */
    while ( *fn && (' ' == *fn) )  fn++;    /* Seend end of white space */

    if ( NULL != (app->fin = fopen( fn, "r" )) )
    {
        int         ibak;

        ibak = app->interactive_mode;
        app->interactive_mode = 0;

        svenapp_source_main(app, true);

        app->interactive_mode = ibak;
        app->quit_requested = 0;
    }
    else
    {
        printf("Could not Source File \"%s\"\n", fn );
    }

    /* Restore */
    app->fin = old_fin;

    return( err );
}


/* ===========================================================================*/
/* Streaming Media Driver Monitoring functions */
/* ===========================================================================*/

struct SMDMon_Buf
{
    struct SMDMon_Buf   *next;      /* for hash lookup */
    int                  buf_id;    /* for hash lookup */
    int                  buf_id_is_free;

    struct SMDMon_Queue *queue;     /* associated queue */

    int                  addref_count;
    int                  deref_count;
    int                  release_count;

    struct SVENEvent     ev_alloc;  /* LAST Alloc event */
    struct SVENEvent     ev_free;
    struct SVENEvent     ev_addref;
    struct SVENEvent     ev_deref;
    struct SVENEvent     ev_release;
};

struct SMDMon_Queue
{
    struct SMDMon_Queue *next;
    int                  queue_id;
    int                  queue_id_is_free;

    int                  queue_type;
    int                  queue_free_count;   /* # times this queue has been freed */
    int                  queue_max_bufs;
    int                  queue_max_bytes;
    int                  queue_current_num_buffers;  /* Curernt number of buffers in the queue.  0 = empty. */
    int                  queue_high_watermark;
    int                  queue_low_watermark;

    struct SMDMon_Port   *port;     /* associated port */

    struct SVENEvent     ev_name;   /* SVEN_EV_SMDCore_Queue_SetName */
    char                 queue_name_null_pad[4];  /* null-terminate the queue name */
    struct SVENEvent     ev_viz;  /* SVEN_EV_SMDCore_Viz_Queue_Associate */

    int                  queue_bytes_written;
    int                  queue_bufs_written;
    int                  queue_writes;
    int                  queue_write_fails;
    struct SVENEvent     ev_write;      /* last write */

    int                  queue_bytes_read;
    int                  queue_bufs_read;
    int                  queue_reads;
    int                  queue_read_fails;
    struct SVENEvent     ev_read;       /* last read */

    int                  queue_bytes_flushed;
    int                  queue_bufs_flushed;
    int                  queue_flushes;
    struct SVENEvent     ev_flush;       /* last flush */
};

struct SMDMon_Circbuf
{
    struct SMDMon_Circbuf *next;
    int                  circbuf_id;
    int                  circbuf_id_is_free;

    int                  circbuf_type;
    int                  circbuf_free_count;   /* # times this queue has been freed */
    int                  circbuf_max_bufs;
    int                  circbuf_max_bytes;
    int                  circbuf_high_watermark;
    int                  circbuf_low_watermark;

    struct SMDMon_Port   *port;     /* associated port */

    struct SVENEvent     ev_name;   /* SVEN_EV_SMDCore_Circbuf_SetName */
    char                 circbuf_name_null_pad[4];  /* null-terminate the queue name */
    struct SVENEvent     ev_viz;  /* SVEN_EV_SMDCore_Viz_Circbuf_Associate */

    int                  circbuf_bytes_written;
    int                  circbuf_bufs_written;
    int                  circbuf_writes;
    int                  circbuf_write_fails;
    struct SVENEvent     ev_write;      /* last write */

    int                  circbuf_bytes_read;
    int                  circbuf_bufs_read;
    int                  circbuf_reads;
    int                  circbuf_read_fails;
    struct SVENEvent     ev_read;       /* last read */

    int                  circbuf_bytes_flushed;
    int                  circbuf_bufs_flushed;
    int                  circbuf_flushes;
    struct SVENEvent     ev_flush;       /* last flush */
};

struct SMDMon_Port
{
    struct SMDMon_Port  *next;
    int                  port_id;
    int                  port_id_is_free;   /*  */

    int                  port_free_count;   /* # times this port has been freed */

    struct SVENEvent     ev_name;   /* SVEN_EV_SMDCore_Port_SetName */
    char                 port_name_null_pad[4];  /* null-terminate the port name */
    struct SVENEvent     ev_viz;   /* SVEN_EV_SMDCore_Viz_Port_Associate */

    /* Connections */
    struct SMDMon_Port  *out_port;          /* port I'm sending to */
    struct SMDMon_Port  *in_port;           /* port sending to me */

    struct SMDMon_Queue *queue;     /* associated queue */
};

static struct SMDMon_Port *smd_monitor_find_port(
    struct SMDCoreMonitor   *cm,
    int                      port_id )
{
    struct SMDMon_Port  *port;

    port = cm->first_port;
    while ( NULL != port )
    {
        if ( port_id == port->port_id )
        {
            break;
        }
        port = port->next;
    }

    if ( NULL == port )
    {
        if ( NULL != (port = calloc(1,sizeof(*port)) ) )
        {
            port->port_id = port_id;
            port->port_id_is_free = 1;
            sprintf( port->ev_name.u.smd.setname.name, "PORT-%d", port->port_id );

            /* link it in */
            port->next = cm->first_port;
            cm->first_port = port;
        }
    }

    return(port);
}

static struct SMDMon_Queue *smd_monitor_find_queue(
    struct SMDCoreMonitor   *cm,
    int                      queue_id )
{
    struct SMDMon_Queue  *queue;

    queue = cm->first_queue;
    while ( NULL != queue )
    {
        if ( queue_id == queue->queue_id )
        {
            break;
        }
        queue = queue->next;
    }

    if ( NULL == queue )
    {
        if ( NULL != (queue = calloc(1,sizeof(*queue)) ) )
        {
            queue->queue_id = queue_id;
            queue->queue_id_is_free = 1;
            sprintf( queue->ev_name.u.smd.setname.name, "QUEUE-%d", queue->queue_id );

            /* link it in */
            queue->next = cm->first_queue;
            cm->first_queue = queue;
        }
    }

    return(queue);
}

static struct SMDMon_Circbuf *smd_monitor_find_circbuf(
    struct SMDCoreMonitor   *cm,
    int                      circbuf_id )
{
    struct SMDMon_Circbuf  *circbuf;

    circbuf = cm->first_circbuf;
    while ( NULL != circbuf )
    {
        if ( circbuf_id == circbuf->circbuf_id )
        {
            break;
        }
        circbuf = circbuf->next;
    }

    if ( NULL == circbuf )
    {
        if ( NULL != (circbuf = calloc(1,sizeof(*circbuf)) ) )
        {
            circbuf->circbuf_id = circbuf_id;
            circbuf->circbuf_id_is_free = 1;
            sprintf( circbuf->ev_name.u.smd.setname.name, "CIRCBUF-%d", circbuf->circbuf_id );

            /* link it in */
            circbuf->next = cm->first_circbuf;
            cm->first_circbuf = circbuf;
        }
    }

    return(circbuf);
}

static struct SMDMon_Buf *smd_monitor_find_buf(
    struct SMDCoreMonitor   *cm,
    int                      buf_id,
    struct SMDMon_Buf       **pprev_result )
{
    struct SMDMon_Buf    *buf;
    struct SMDMon_Buf   **pprev;

    pprev = &cm->buft[ buf_id & SMDMON_BUF_HASH_MASK ];
    while ( NULL != (buf = (struct SMDMon_Buf *) &((*pprev)->next)) )
    {
        if ( buf_id == buf->buf_id )
        {
            break;
        }
        pprev = &buf->next;
    }

    if ( NULL != pprev_result )
       *pprev_result = (struct SMDMon_Buf   *) pprev;

    //if ( NULL == buf )
    //    printf(" U %d ", __LINE__ );

    return(buf);
}

static struct SMDMon_Buf *smd_monitor_add_buf(
    struct SMDCoreMonitor   *cm,
    int                      buf_id )
{
   struct SMDMon_Buf   *buf;
   int ret = 0;

   buf = smd_monitor_find_buf( cm, buf_id, NULL);

   if ( NULL == buf )
   {
      /* Remove buffer from HT and add to free list */
      ret = pthread_mutex_lock ( &mutex );
      {
         if ( NULL != cm->free_bufs )
         {
           buf = cm->free_bufs;                  /* Take a buffer from free buffers list */
           cm->free_bufs = cm->free_bufs->next;  /* Update free buffers list */
         }
         else
         {
            buf= calloc(1,sizeof(*buf));         /* Free buffers list is empty. Allocate */
         }
      }
      ret = pthread_mutex_unlock( &mutex );

      if ( NULL != buf )
      {
         buf->buf_id = buf_id;

         /* link it in */
         buf->next = cm->buft[ buf_id & SMDMON_BUF_HASH_MASK ];
         cm->buft[ buf_id & SMDMON_BUF_HASH_MASK ] = buf;
      }
   }

   return(buf);
}


static void smd_monitor_init_stats_buf(
    struct SMDMon_Buf_Stats *stats_buf,
    int    init_extended_data_only )
{
    //printf(" init %d ", init_extended_data_only );

    if ( !init_extended_data_only )
    {
       stats_buf->max_used = -1;            // max_used easier to calculate.  Therefore not controlled by buf command switching the collecting of stats.
       stats_buf->num_curr_in_use = 0;
    }
    stats_buf->min_used = 0x7FFFFFFF;       // This is the extended data.
    stats_buf->num_use_events  = 0;
    stats_buf->total_buf_usage = 0;
}

static struct SMDMon_Buf_Stats *smd_monitor_find_stats_buf(
    struct SMDCoreMonitor   *cm,
    int                      buf_size,
    int                      initialize)
{
    static int last_buf_size_init_err=0;
    static int message_printed = 0;
    struct SMDMon_Buf_Stats *stats_buf;
    int array_index;
    int i;

    //if ( 0x2000 == buf_size )
    //    printf(" find %#x %d ", buf_size, initialize);

    array_index = ffs(buf_size) & SMDMON_BUF_HASH_MASK;
    for ( i=0; i<SMDMON_BUF_HASH_SIZE; i++ )
    {
        stats_buf = &cm->stats_buft[ array_index++ & SMDMON_BUF_HASH_MASK];
        if ( stats_buf->in_use )
        {
           if ( stats_buf->buf_size == buf_size )
           {
               return stats_buf;
           }
           // else there is a collision
        }
        else
        {
            if ( initialize )
            {
                smd_monitor_init_stats_buf(stats_buf,0);
                stats_buf->buf_size = buf_size;
                stats_buf->in_use   = 1;
                return stats_buf;
            }
            //if ( buf_size != last_buf_size_init_err )
            //    printf("\t%s buf size %#x not found and no init\n", __func__, buf_size);
            last_buf_size_init_err = buf_size;
            return NULL;
        }
    }

    if ( ! message_printed )
    {
       printf("Error, buf stats hash buf is full.  Need to increase size.\n");
       message_printed = 1;
    }
    return NULL;  // This case is reached when all of the stats bufs are in use.  Need to increase the size.
}




#ifdef SVEN_VIZ_UDP
static void smd_viz_update_circbuf(
    struct SMDCoreMonitor   *cm,
    int                      virtid,
    int                      depth,
    int                      level )
{
    if ( cm->viz_socket_opened )
    {
        cm->viz_tuple[ cm->viz_update_count ].virtid = virtid;
        cm->viz_tuple[ cm->viz_update_count ].depth = depth;
        cm->viz_tuple[ cm->viz_update_count ].level = level;
        if ( ++cm->viz_update_count >= NUM_VIZ_TUPLES_PER_UDP )
        {
            sendto( cm->viz_socket,
                cm->viz_tuple,
                sizeof(cm->viz_tuple),
                0,
                (struct sockaddr *) &cm->viz_serverAddress,
                sizeof(cm->viz_serverAddress) );

            /* Prepare to send the next */
            cm->viz_update_count = 0;
        }
    }
}
#else
static void smd_viz_update_circbuf(
    struct SMDCoreMonitor   *cm,
    int                      virtid,
    int                      depth,
    int                      level )
{
    UNUSED_PARAMETER(cm);
    UNUSED_PARAMETER(virtid);
    UNUSED_PARAMETER(depth);
    UNUSED_PARAMETER(level);
}
#endif

static int sven_smd_core_filter(
    struct SVENEvent    *ev,
    void                *userdata0,
    void                *userdata1 )
{
    static int dealloc_prev_buf_id = -1;

    UNUSED_PARAMETER(userdata0);

    /* Is this an SMD event? */
    if ( SVEN_event_type_smd == ev->se_et.et_type )
    {
        //struct SVENApp          *app = (struct SVENApp *)userdata0;
        struct SMDCoreMonitor   *cm = (struct SMDCoreMonitor *)userdata1;

        ++cm->core_msgs;

        switch( (int) ev->se_et.et_subtype )
        {
            case SVEN_EV_SMDCore_Port_Alloc:
            {
                struct SMDMon_Port  *port;

                if ( NULL != (port = smd_monitor_find_port( cm,
                                ev->u.smd.port_alloc.port_id ) ) )
                {
                    struct SMDMon_Queue *queue;

                    if ( ! port->port_id_is_free )
                    {
                        /* ALREADY ALLOCATED !?!?!?!? */
                        /* WARN: Port ID created twice */
                    }
                    port->port_id_is_free = 0;

                    if ( NULL != (queue = smd_monitor_find_queue(cm,
                                    ev->u.smd.port_alloc.queue_id)) )
                    {
                        /* DEBUG? */


                        /* Connect them */
                        port->queue = queue;
                        queue->port = port;
                    }
                }
            }
            break;
            case SVEN_EV_SMDCore_Port_SetName:
            {
                struct SMDMon_Port  *port;

                if ( NULL != (port = smd_monitor_find_port( cm,
                                ev->u.smd.setname.id ) ) )
                {
                    port->ev_name = *ev;
                }
            }
            break;
            case SVEN_EV_SMDCore_Viz_Port_Associate:
            {
                struct SMDMon_Port  *port;

                if ( NULL != (port = smd_monitor_find_port( cm,
                                ev->u.smd.viz.id ) ) )
                {
                    port->ev_viz = *ev;
                }
            }
            break;
            case SVEN_EV_SMDCore_Port_Free:
            {
                struct SMDMon_Port  *port;

                if ( NULL != (port = smd_monitor_find_port( cm,
                                ev->u.smd.port_free.port_id ) ) )
                {
                    port->port_free_count++;

                    if ( port->port_id_is_free )
                    {
                        /* ALREADY FREE!?!?!?!? */
                        /* WARN: Port Freed twice */
                    }
                    port->port_id_is_free = 1;

                    /* Disconnect cross-link */
                    if ( NULL != port->queue )
                    {
                        port->queue->port = NULL;
                    }

                    port->queue = NULL;
                }
            }
            break;
            case SVEN_EV_SMDCore_Port_Connect:
            {
                struct SMDMon_Port  *port;

                if ( NULL != (port = smd_monitor_find_port( cm,
                                ev->u.smd.port_connect.port_id ) ) )
                {
                    struct SMDMon_Port  *other_port;

                    if ( NULL != (other_port = smd_monitor_find_port( cm,
                                    ev->u.smd.port_connect.other_port_id ) ) )
                    {
                        /* Establish the connection */
                        port->out_port = other_port;
                        other_port->in_port = port;
                    }
                }
            }
            break;
            case SVEN_EV_SMDCore_Port_Disconnect:
            {
                struct SMDMon_Port  *port;

                if ( NULL != (port = smd_monitor_find_port( cm,
                                ev->u.smd.port_connect.port_id ) ) )
                {
                    struct SMDMon_Port  *other_port;

                    if ( NULL != (other_port = smd_monitor_find_port( cm,
                                    ev->u.smd.port_connect.other_port_id ) ) )
                    {
                        /* Some stats??? */


                        /* Break the connection */
                        other_port->in_port = NULL;
                    }

                    /* Break the connection */
                    port->out_port = NULL;
                }
            }
            break;

            /* -------------------------------------------------------- */

            case SVEN_EV_SMDCore_Queue_Alloc:
            {
                struct SMDMon_Queue *queue;

                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.queue.queue_id)) )
                {
                    if ( ! queue->queue_id_is_free )
                    {
                        /* ALREADY ALLOCATED !?!?!?!? */
                        /* WARN: Queue ID created twice */
                    }
                    queue->queue_id_is_free = 0;
                    queue->queue_type = ev->u.smd.queue.queue_type;
                    queue->queue_max_bufs = ev->u.smd.queue.max_depth;
                }
            }
            break;
            case SVEN_EV_SMDCore_Queue_SetName:
            {
                struct SMDMon_Queue *queue;

                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.setname.id)) )
                {
                    queue->ev_name = *ev;
                }
            }
            break;
            case SVEN_EV_SMDCore_Viz_Queue_Associate:
            {
                struct SMDMon_Queue *queue;

                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.viz.id)) )
                {
                    queue->ev_viz = *ev;
                }
            }
            break;
            case SVEN_EV_SMDCore_Queue_Free:
            {
                struct SMDMon_Queue *queue;
                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.queue.queue_id)) )
                {
                    if ( queue->queue_id_is_free )
                    {
                        /* ALREADY FREE!?!?!?!? */
                        /* WARN: Port Freed twice */
                    }
                    queue->queue_id_is_free = 1;
                    queue->queue_current_num_buffers = 0;
                }
            }
            break;
            case SVEN_EV_SMDCore_Queue_SetConfig:
            {
                struct SMDMon_Queue *queue;

                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.queue_config.queue_id )) )
                {
                    queue->queue_max_bufs       = ev->u.smd.queue_config.max_buffers;
                    queue->queue_max_bytes      = ev->u.smd.queue_config.max_bytes;
                    queue->queue_high_watermark = ev->u.smd.queue_config.high_watermark;
                    queue->queue_low_watermark  = ev->u.smd.queue_config.low_watermark;
                }
            }
            break;
            case SVEN_EV_SMDCore_Queue_Write:
            {
                struct SMDMon_Queue *queue;

                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.queue_io.queue_id )) )
                {
                    queue->queue_writes++;
                    queue->queue_current_num_buffers = ev->u.smd.queue_io.tot_buffers_in_q;
                    queue->queue_bufs_written       += ev->u.smd.queue_io.xact_buffers;
                    queue->queue_bytes_written      += ev->u.smd.queue_io.xact_bytes;
                    queue->ev_write = *ev;

                    smd_viz_update_circbuf( cm,
                        queue->ev_viz.u.smd.viz.viz_id,
                        queue->queue_max_bufs,
                        ev->u.se_uint[1] );
                }
            }
            break;
            case SVEN_EV_SMDCore_Queue_Read:
            {
                struct SMDMon_Queue *queue;

                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.queue_io.queue_id )) )
                {
                    queue->queue_reads++;
                    queue->queue_current_num_buffers = ev->u.smd.queue_io.tot_buffers_in_q;
                    queue->queue_bufs_read          += ev->u.smd.queue_io.xact_buffers;
                    queue->queue_bytes_read         += ev->u.smd.queue_io.xact_bytes;
                    queue->ev_read = *ev;

                    smd_viz_update_circbuf( cm,
                        queue->ev_viz.u.smd.viz.viz_id,
                        queue->queue_max_bufs,
                        ev->u.se_uint[1] );
                }
            }
            break;
            case SVEN_EV_SMDCore_Queue_Flush:
            {
                struct SMDMon_Queue *queue;
                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.queue_io.queue_id )) )
                {
                    queue->queue_current_num_buffers = 0;
                    queue->queue_flushes++;
                    queue->queue_bufs_flushed  += ev->u.smd.queue_io.xact_buffers;
                    queue->queue_bytes_flushed += ev->u.smd.queue_io.xact_bytes;
                    queue->ev_flush = *ev;
                }
            }
            break;
            case SVEN_EV_SMDCore_Queue_WriteFail:
            {
                struct SMDMon_Queue *queue;

                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.queue_io.queue_id )) )
                {
                    queue->queue_write_fails++;
                }
            }
            break;
            case SVEN_EV_SMDCore_Queue_ReadFail:
            {
                struct SMDMon_Queue *queue;

                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.queue_io.queue_id )) )
                {
                    queue->queue_read_fails++;
                }
            }
            break;
            case SVEN_EV_SMDCore_Queue_Push:
            {
                struct SMDMon_Queue *queue;

                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.queue_io.queue_id )) )
                {
                }
            }
            break;
            case SVEN_EV_SMDCore_Queue_Pull:
            {
                struct SMDMon_Queue *queue;

                if ( NULL != (queue = smd_monitor_find_queue(cm,
                                ev->u.smd.queue_io.queue_id )) )
                {
                }
            }
            break;
            /* -------------------------------------------------------- */
            case SVEN_EV_SMDCore_Circbuf_Alloc:
            {
                struct SMDMon_Circbuf *circbuf;

                if ( NULL != (circbuf = smd_monitor_find_circbuf(cm,
                                ev->u.smd.queue.queue_id)) )
                {
                    if ( ! circbuf->circbuf_id_is_free )
                    {
                        /* ALREADY ALLOCATED !?!?!?!? */
                        /* WARN: Circbuf ID created twice */
                    }
                    circbuf->circbuf_id_is_free = 0;
                    circbuf->circbuf_type = ev->u.smd.queue.queue_type;
                    circbuf->circbuf_max_bufs = ev->u.smd.queue.max_depth;
                }
            }
            break;
            case SVEN_EV_SMDCore_Circbuf_SetName:
            {
                struct SMDMon_Circbuf *circbuf;

                if ( NULL != (circbuf = smd_monitor_find_circbuf(cm,
                                ev->u.smd.setname.id)) )
                {
                    circbuf->ev_name = *ev;
                }
            }
            break;
            case SVEN_EV_SMDCore_Viz_Circbuf_Associate:
            {
                struct SMDMon_Circbuf *circbuf;

                if ( NULL != (circbuf = smd_monitor_find_circbuf(cm,
                                ev->u.smd.viz.id)) )
                {
                    circbuf->ev_viz = *ev;
                }
            }
            break;
            case SVEN_EV_SMDCore_Circbuf_Free:
            {
                struct SMDMon_Circbuf *circbuf;

                if ( NULL != (circbuf = smd_monitor_find_circbuf(cm,
                                ev->u.smd.queue.queue_id)) )
                {
                    if ( circbuf->circbuf_id_is_free )
                    {
                        /* ALREADY FREE!?!?!?!? */
                        /* WARN: Port Freed twice */
                    }
                    circbuf->circbuf_id_is_free = 1;
                }
            }
            break;
            case SVEN_EV_SMDCore_Circbuf_Write:
            {
                struct SMDMon_Circbuf *circbuf;

                if ( NULL != (circbuf = smd_monitor_find_circbuf(cm,
                                ev->u.smd.queue_io.queue_id )) )
                {
                    circbuf->circbuf_writes++;
                    circbuf->circbuf_bufs_written += ev->u.smd.queue_io.xact_buffers;
                    circbuf->circbuf_bytes_written += ev->u.smd.queue_io.xact_bytes;
                    circbuf->ev_write = *ev;

                    smd_viz_update_circbuf( cm,
                        // circbuf->ev_viz.u.smd.viz.viz_id,
                        ev->u.se_uint[0],
                        ev->u.se_uint[1],
                        ev->u.se_uint[2] );
                }
            }
            break;
            case SVEN_EV_SMDCore_Circbuf_Read:
            {
                struct SMDMon_Circbuf *circbuf;

                if ( NULL != (circbuf = smd_monitor_find_circbuf(cm,
                                ev->u.smd.queue_io.queue_id )) )
                {
                    circbuf->circbuf_reads++;
                    circbuf->circbuf_bufs_read += ev->u.smd.queue_io.xact_buffers;
                    circbuf->circbuf_bytes_read += ev->u.smd.queue_io.xact_bytes;
                    circbuf->ev_read = *ev;

                    smd_viz_update_circbuf( cm,
                        // circbuf->ev_viz.u.smd.viz.viz_id,
                        ev->u.se_uint[0],
                        ev->u.se_uint[1],
                        ev->u.se_uint[2] );
                }
            }
            break;


            /* -------------------------------------------------------- */
            /*                    Buffer tracking                                                    */
            /* -------------------------------------------------------- */

            case SVEN_EV_SMDCore_Buf_Alloc:
            {
                struct SMDMon_Buf       *buf;
                struct SMDMon_Buf_Stats *stats_buf;

                dealloc_prev_buf_id = -1;

                cm->core_allocs++;

                if ( NULL != (buf = smd_monitor_add_buf(cm,
                                ev->u.smd.buf_alloc.buf_id )) )
                {
                    if ( ! buf->buf_id_is_free )
                    {
                        /* ALREADY ALLOCATED !?!?!?!? */
                        /* WARN: Buffer ID created twice */
                    }
                    buf->addref_count++;
                    buf->buf_id_is_free = 0;

                    buf->ev_alloc = *ev;    /* copy the alloc event */
                        // Collect buffer use statistics
                    stats_buf = smd_monitor_find_stats_buf(cm, ev->u.smd.buf_alloc.buf_size, 1);
                    if ( stats_buf == NULL )
                    {
                       static int message_printed = 0;
                       /*
                        Below code maybe helpful if trying to debug why garbage buf events are being received.
                       // Lets dump the buf stats buffer out of curiosity, then exit.
                       int i;
                       printf("Unable to find a buffer with size %d.\n", ev->u.smd.buf_alloc.buf_size );
                       for ( i=0; i<SMDMON_BUF_HASH_SIZE; i++ )
                       {
                           stats_buf = &cm->stats_buft[i];
                           if ( stats_buf->in_use )
                           {
                              printf("%2d size %10d 0x%8X, num_curr_in_use %3d, max %3d, min %d, num_use_events %d, total_buf_usage %d\n",
                                 i,
                                 stats_buf->buf_size, stats_buf->buf_size,
                                 stats_buf->num_curr_in_use,
                                 stats_buf->max_used,
                                 stats_buf->min_used,
                                 stats_buf->num_use_events,     // Used to compute average usage
                                 stats_buf->total_buf_usage);    // Used to compute average usage);
                           }
                           else
                           {
                              printf("\n%d not in use.  Shouldn't happen!!!\n\n", i );
                           }
                       }
                       printf("Invoke the debugger by causing a segfault.\n");
                       stats_buf = (struct SMDMon_Buf_Stats *)0;
                       stats_buf->num_curr_in_use += 1;     // Invoke the debugger by causing a segfault.
                       */
                       if ( ! message_printed )
                       {
                          printf("Garbage buf stats being received.  Buf stats will not work.\n");
                          message_printed = 1;
                       }
                    }
                    else
                    {
                       stats_buf->num_curr_in_use += 1;

                       if( stats_buf->max_used < stats_buf->num_curr_in_use )
                           stats_buf->max_used = stats_buf->num_curr_in_use;
                       if( cm->collecting_extended_buf_stats )
                       {
                              // below statistics used to compute average
                              // Average usage = total_buf_usage / num_use_events
                          stats_buf->num_use_events  += 1;
                          stats_buf->total_buf_usage += stats_buf->num_curr_in_use;
                       }
                    }
                }
            }
            break;
            case SVEN_EV_SMDCore_Buf_AddRef:
            {
                struct SMDMon_Buf   *buf;

                if ( NULL != (buf = smd_monitor_find_buf(cm,
                                ev->u.smd.buf.buf_id, NULL )) )
                {
                    buf->addref_count++;
                    buf->ev_addref = *ev;
                }
            }
            break;
            case SVEN_EV_SMDCore_Buf_DeRef:
            {
                struct SMDMon_Buf   *buf;

                if ( NULL != (buf = smd_monitor_find_buf(cm,
                                ev->u.smd.buf.buf_id, NULL )) )
                {
                    buf->deref_count++;
                    buf->ev_deref = *ev;
                }
            }
            break;

            case SVEN_EV_SMDCore_Buf_Free:
            case SVEN_EV_SMDCore_Buf_Release:
            {
                int ret = 0;
                struct SMDMon_Buf_Stats *stats_buf;
                struct SMDMon_Buf       *buf, *prev;

                cm->core_frees++;

                if ( NULL != (buf = smd_monitor_find_buf(cm,
                                ev->u.smd.buf.buf_id,
                                &prev )) )
                {
                    buf->release_count++;
                    buf->ev_release = *ev;
                    if ( buf->buf_id_is_free )
                    {
                        /* ALREADY ALLOCATED !?!?!?!? */
                        /* WARN: Buffer ID freed twice */
                       buf->addref_count = 0;
                       buf->deref_count = 0;
                    }
                    buf->buf_id_is_free = 1;

                    /* Remove buffer from HT and add to free list */
                    ret = pthread_mutex_lock ( &mutex );
                    {
                        prev->next = buf->next;       /* link over */
                        buf->next  = cm->free_bufs;   /* insert buf at head of free list */
                        cm->free_bufs= buf;
                    }
                    ret = pthread_mutex_unlock( &mutex );
                }
                if ( NULL != (stats_buf = smd_monitor_find_stats_buf(cm,
                                ev->u.smd.buf.buf_size, 0)) )
                {
                        // Check if we just deallocated this buffer.
                    if ( dealloc_prev_buf_id != ev->u.smd.buf.buf_id )
                        stats_buf->num_curr_in_use -= 1;
                    dealloc_prev_buf_id = ev->u.smd.buf.buf_id;
                    if ( stats_buf->num_curr_in_use < 0 )
                        stats_buf->num_curr_in_use = 0;
                    if( cm->collecting_extended_buf_stats )
                    {
                       if( stats_buf->min_used > stats_buf->num_curr_in_use )
                           stats_buf->min_used = stats_buf->num_curr_in_use;
                           // below statistics used to compute average
                           // Average usage = total_buf_usage / num_use_events
                       stats_buf->num_use_events  += 1;
                       stats_buf->total_buf_usage += stats_buf->num_curr_in_use;
                    }
                }
            }
            break;

            default:
            {
                cm->unknown_msgs++;
            }
            break;
        };
    }

    return( 0 );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        SMD Core SVEN Functions.
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static void sven_send_smd_core_event(
    os_devhandle_t          *devh,
    int                      smd_core_unit,
    enum SVEN_EV_SMDCore_t   subtype,
    int                      payload0,
    int                      payload1,
    int                      payload2,
    int                      payload3,
    int                      payload4,
    int                      payload5 )
{
    /* If we're not disabled */
    if ( (NULL != devh) &&
         (0 == (*devh->devh_svenh.phot &
                (SVENHeader_DISABLE_ANY | SVENHeader_DISABLE_SMD))) )
    {
        struct SVENEvent        ev;

        /* Initialize the tag */
        ev.se_et.et_module = SVEN_module_SMD_CORE;
        ev.se_et.et_unit = smd_core_unit;
        ev.se_et.et_type = SVEN_event_type_smd;
        ev.se_et.et_subtype = subtype;

        ev.u.se_uint[0] = payload0;
        ev.u.se_uint[1] = payload1;
        ev.u.se_uint[2] = payload2;
        ev.u.se_uint[3] = payload3;
        ev.u.se_uint[4] = payload4;
        ev.u.se_uint[5] = payload5;

        devh_SVEN_WriteEvent( devh, &ev );
    }
}

static char *get_string(
    int num )
{
   static char buf[32] = {0};
   int  i       = 30;

   for ( ; num && i; --i, num /= 10 )
      buf[i] = "0123456789"[num % 10];

   return &buf[i+1];
}

static char *trim_string(
   char *str )
{
   static char buf[22] = {0};
   int open_brace  = 0;
   int close_brace = strlen(str) - 1;

   while ( str[open_brace] != '(' && open_brace < close_brace )
      open_brace++;

   while ( str[close_brace] != ')' && close_brace > open_brace )
      close_brace--;

   if ( open_brace < close_brace )
   {
      strncpy( buf, &str[open_brace], close_brace-open_brace+1 );
      buf[close_brace-open_brace+1] = '\0';
      return buf;
   }

   return str;
}

static char *get_thread_name(
   int thread_id )
{
   FILE *fp;
   char fname[20];
   char tname[22] = "DEFUNCT";

   // Generate file name
   strcpy( fname, "/proc/" );
   strcat( fname, get_string(thread_id) );
   strcat( fname, "/stat");

   // Open file and read thread name
   fp = fopen( fname, "r" );
   if ( NULL != fp )
   {
      fgets( tname, 22, fp );
      fclose( fp );
   }

   return trim_string( tname );
}

static int sven_cmd_smd(
    struct SVENApp*  app,
    const  char*     command )
{
    int         num_tokens;
    int         err = 0;

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 1 )
    {
        struct SMDCoreMonitor   *cm = &app->smd_mon;

        if( !strcasecmp(app->cparse.token[1].token_str, "TEST"))
        {
            int         q0_id,q0_max_bufs,q0_max_bytes;
            int         port0_id;
            int         q1_id,q1_max_bufs,q1_max_bytes;
            int         port1_id;
            int         buf_id;

            q0_id = 0xa0;
            port0_id = 0xa1;
            q1_id = 0xb0;
            port1_id = 0xb1;
            buf_id = 0xc0;
            q0_max_bufs = q1_max_bufs = 3;
            q0_max_bytes = q1_max_bytes = (4*1024);;

            /* Queue0, Port0 */
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Queue_Alloc,
                q0_id,0,0,0,0,0 );
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Port_Alloc,
                port0_id,q0_id,0,0,0,0 );
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Queue_SetConfig,
                q0_id,q0_max_bufs,q0_max_bytes,0,0,0 );

            /* Queue1, Port1 */
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Queue_Alloc,
                q1_id,0,0,0,0,0 );
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Port_Alloc,
                port1_id,q1_id,0,0,0,0 );
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Queue_SetConfig,
                q1_id,q1_max_bufs,q1_max_bytes,0,0,0 );


            /* fake port connection */
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Port_Connect,
                q0_id,q1_id,0,0,0,0 );

            // buf_id;         /* buffer ID */
            // buf_size;       /* buffer size */
            // buf_phys_addr;  /* buffer PhysAddr */
            // buf_va;         /* buffer Virtual Address */
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Buf_Alloc,
                buf_id,0,0,0,0,0 );

            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Buf_AddRef,
                buf_id,0,0,0,0,0 );

            //SVEN_EV_SMDCore_Queue_Write,
            //SVEN_EV_SMDCore_Queue_Read,
            //SVEN_EV_SMDCore_Queue_Flush,
            //SVEN_EV_SMDCore_Queue_WriteFail,
            //SVEN_EV_SMDCore_Queue_ReadFail,
            //SVEN_EV_SMDCore_Queue_Push,
            //SVEN_EV_SMDCore_Queue_Pull,
            // queue_id;       ID used by this queue
            // tot_buffers;    total buffers in queue
            // tot_bytes;      total bytes in queue
            // xact_buffers;   this transaction buffers
            // xact_bytes;     this transaction bytes
            // buf_id;         Associated Buffer ID (if relevant)
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Queue_Write,
                q0_id, 0,0, 1,1024, buf_id );

            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Queue_Read,
                q1_id, 0,0, 1,1024, buf_id );

            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Buf_DeRef,
                buf_id,0,0,0,0,0 );

            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Buf_Release,
                buf_id,0,0,0,0,0 );

            /* Flush on teardown */
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Queue_Flush,
                q0_id,0,0,0,0,0 );

            /* Port disconnect */
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Port_Disconnect,
                q0_id,q1_id,0,0,0,0 );

            /* pretend to delete the buffer */
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Buf_Free,
                buf_id,0,0,0,0,0 );

            /* Free queue/port 0 */
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Queue_Free,
                q0_id,0,0,0,0,0 );
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Port_Free,
                port0_id,0,0,0,0,0 );

            /* Free queue/port 1 */
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Queue_Free,
                q1_id,0,0,0,0,0 );
            sven_send_smd_core_event( app->devh, 0,
                SVEN_EV_SMDCore_Port_Free,
                port1_id,0,0,0,0,0 );
        }
#ifdef SVEN_VIZ_UDP
        else if( !strcasecmp(app->cparse.token[1].token_str, "udp"))
        {
            if ( num_tokens > 3 )
            {
                struct SMDCoreMonitor   *cm = &app->smd_mon;

                if ( NULL != (cm->viz_hostInfo = gethostbyname(app->cparse.token[2].token_str)) )
                {
                    if ( cm->viz_socket_opened )
                    {
                        close( cm->viz_socket );
                        cm->viz_socket_opened = 0;
                    }

                    if ( (cm->viz_socket = socket(AF_INET, SOCK_DGRAM, 0)) >= 0 )
                    {
                        cm->viz_serverAddress.sin_family = cm->viz_hostInfo->h_addrtype;

                        memcpy((char *) &cm->viz_serverAddress.sin_addr.s_addr,
                            cm->viz_hostInfo->h_addr_list[0],
                            cm->viz_hostInfo->h_length);

                        cm->viz_serverAddress.sin_port = htons(app->cparse.token[3].token_int_value);


                        cm->viz_socket_opened = 1;
                    }
                    else printf("could not create socket\n" );
                }
                else printf("could not gethostbyname(%s)\n", app->cparse.token[2].token_str );
            }
            else
            {
                printf("usage: %s %s <host_ip> <host_port>\n",
                    app->cparse.token[0].token_str,
                    app->cparse.token[1].token_str );
            }
        }
#endif
        else if( !strcasecmp(app->cparse.token[1].token_str, "port"))
        {
            struct SMDMon_Port  *port;

            port = cm->first_port;
            while ( NULL != port )
            {
                printf("port:%3d \"%20s\" count:%2d queue:%3d in:%3d out:%3d\n",
                    port->port_id,
                    port->ev_name.u.smd.setname.name,
                    port->port_free_count,
                    (NULL != port->queue) ? port->queue->queue_id : -1,
                    (NULL != port->in_port) ? port->in_port->port_id : -1,
                    (NULL != port->out_port) ? port->out_port->port_id : -1 );

                if ( NULL != port->queue )
                {
                    struct SMDMon_Queue  *queue = port->queue;

                    printf("   q:%3d t:%d \"%20s\" count:%2d max:%2d maxbytes %x cur(%2d, %08x) :: writes(%5d,%08x) reads(%5d,%08x) flush(%5d,%08x)\n",
                        queue->queue_id,
                        queue->queue_type,
                        queue->ev_name.u.smd.setname.name,
                        queue->queue_free_count,
                        queue->queue_max_bufs,
                        queue->queue_max_bytes,
                        queue->ev_write.u.smd.queue_io.tot_buffers_in_q,
                        queue->ev_write.u.smd.queue_io.tot_bytes,
                        queue->queue_bufs_written,
                        queue->queue_bytes_written,
                        queue->queue_bufs_read,
                        queue->queue_bytes_read,
                        queue->queue_bufs_flushed,
                        queue->queue_bytes_flushed );
                }


                port = port->next;
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "q"))
        {
            struct SMDMon_Queue  *queue;

            queue = cm->first_queue;
            while ( NULL != queue )
            {
                if ( 0 != queue->queue_bufs_written && 0 == queue->queue_id_is_free )
                {
                   char empty_full_str[8];
                   if ( queue->queue_max_bufs == queue->queue_current_num_buffers )
                     strcpy(empty_full_str,"full ");
                   else if ( 0 == queue->queue_current_num_buffers )
                     strcpy(empty_full_str,"empty");
                   else
                     strcpy(empty_full_str,"     ");
                   printf(" q:%3d \"%20s\"  %s  bufs::max:%3d cur in q:%3d  writes:%5d  reads:%5d\n",
                        queue->queue_id,
                        queue->ev_name.u.smd.setname.name,
                        empty_full_str,
                        queue->queue_max_bufs,
                        queue->queue_current_num_buffers,
                        queue->queue_bufs_written,
                        queue->queue_bufs_read );
                 }
                queue = queue->next;
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "que"))
        {
            struct SMDMon_Queue  *queue;

            queue = cm->first_queue;
            while ( NULL != queue )
            {
                printf("   q:%3d t:%d \"%20s\" count:%2d max:%2d maxbytes %x cur(%2d, %08x) :: writes(%5d,%08x) reads(%5d,%08x) flush(%5d,%08x)\n",
                    queue->queue_id,
                    queue->queue_type,
                    queue->ev_name.u.smd.setname.name,
                    queue->queue_free_count,
                    queue->queue_max_bufs,
                    queue->queue_max_bytes,
                    queue->queue_current_num_buffers,
                    queue->ev_write.u.smd.queue_io.tot_bytes,
                    queue->queue_bufs_written,
                    queue->queue_bytes_written,
                    queue->queue_bufs_read,
                    queue->queue_bytes_read,
                    queue->queue_bufs_flushed,
                    queue->queue_bytes_flushed );

                queue = queue->next;
            }
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "buf"))
        {
           int index = 0, buffers_allocated = 0, buffers_aged_count = 0,  ret = 0;
           uint32_t buffers_size = 0;

           printf("RECEIVED %d SMD_Core Messages [allocs %d frees %d]\n", cm->core_msgs, cm->core_allocs, cm->core_frees );

           ret = pthread_mutex_lock ( &mutex );
           {
               for ( index = 0; index < SMDMON_BUF_HASH_SIZE ; index++ )
               {
                  struct SMDMon_Buf   *buf;

                  buf = cm->buft[index];

                  while ( NULL != buf )
                  {
                     if ( !buf->buf_id_is_free )
                     {
                        int age = -1;

                        age = (sven_get_timestamp() - buf->ev_alloc.se_timestamp)/1000000; /* Buffer age in seconds */

                        if ( (buf->addref_count != buf->deref_count) && (age > 1) )
                        {

                           // Print buffer information
                           printf("buff:%#10x phy_add:%#10x size:%#8x addref:%4d deref:%4d relcount:%4d thread_id:%5d thread:%18s age:%3d\n",
                                 buf->buf_id,
                                 buf->ev_alloc.u.smd.buf_alloc.buf_phys_addr,
                                 buf->ev_alloc.u.smd.buf_alloc.buf_size,
                                 buf->addref_count,
                                 buf->deref_count,
                                 buf->release_count,
                                 buf->ev_alloc.u.smd.buf_alloc.thread_id,
                                 get_thread_name(buf->ev_alloc.u.smd.buf_alloc.thread_id),
                                 age );
                           buffers_aged_count++;
                        }

                        buffers_allocated++;
                        buffers_size += buf->ev_alloc.u.smd.buf_alloc.buf_size;
                     }

                     buf = buf->next;
                  } // end of while
               } // end of for
            }
            ret = pthread_mutex_unlock( &mutex );

            /* Print Summary */
            printf("\n");
            printf("Buffers currently allocated            = %d\n", buffers_allocated);
            printf("Buffers in memory for more than a sec  = %d\n", buffers_aged_count);
            printf("Total size of all allocated buffers    = %u\n", buffers_size);

           ret = pthread_mutex_lock ( &mutex );
           {
               for ( index = 0; index < SMDMON_BUF_HASH_SIZE ; index++ )
               {
                  struct SMDMon_Buf_Stats *buf_stats;

                  buf_stats = &cm->stats_buft[index];

                  if ( buf_stats->in_use )
                  {
                     // Print buf stats information
                     printf("buff size:%#8x  num curr in use:%4d  max used:%4d  ",
                           buf_stats->buf_size,
                           buf_stats->num_curr_in_use,
                           buf_stats->max_used );
                     //if ( cm->collecting_extended_buf_stats || cm->did_collect_extended_buf_stats ) {
                     if ( cm->collecting_extended_buf_stats ) {
                        if ( buf_stats->num_use_events != 0 )
                        {
                           int average_usage = buf_stats->total_buf_usage / buf_stats->num_use_events;
                           int min_used = buf_stats->min_used;
                           if ( min_used == 0x7fffffff ) min_used = 0;     // Occurs when there were no buf free events, for example during module load time.
                           printf("min used:%3d  average used:%4d  num use events:%6d  total buf usage:%8d",
                              min_used,
                              average_usage,
                              buf_stats->num_use_events,
                              buf_stats->total_buf_usage );
                        }
                     } else {
                        smd_monitor_init_stats_buf(buf_stats,1);
                     }
                     printf("\n");
                  }
               } // end of for
               if ( cm->collecting_extended_buf_stats )
               {
                  printf("Collecting extended buf statistics turned off.\n");
               } else {
                  printf("Collecting extended buf statistics turned on.\n");
               }
               cm->collecting_extended_buf_stats = !cm->collecting_extended_buf_stats;
            }
            ret = pthread_mutex_unlock( &mutex );

        }
    }

    return( err );
}

/* ===========================================================================*/

static int sven_smd_health_filter(
    struct SVENEvent    *ev,
    void                *userdata0,
    void                *userdata1 )
{
    struct SVENApp            *app = (struct SVENApp *)userdata0;;
    struct SMDHealthMonitor   *hm = (struct SMDHealthMonitor *)userdata1;
    int                        i;
    int                        fire_trigger = 0;

    /* collect hogs info for this module */
    app->hogs.module_event_count[ ev->se_et.et_module ]++;
    if ( SVEN_module_SMD_CORE == ev->se_et.et_module )
    {
        app->hogs.smd_unit_event_count[ev->se_et.et_unit ]++;
    }

    if ( 0 != hm->trigger_enabled )
    {
        /* We've crossed the threshhold for delay between events */
        if ( 0 != hm->vid_timestamps[1] )
        {
            if ( (signed int)(ev->se_timestamp - hm->vid_timestamps[0]) >
                 (signed int)hm->vid_threshhold )
            {
                printf("\nHealth Video trigger activated\n");
                fire_trigger = 1;
            }
        }
        /* We've crossed the threshhold for delay between events */
        if ( 0 != hm->aud_timestamps[1] )
        {
            if ( (signed int)(ev->se_timestamp - hm->aud_timestamps[0]) >
                 (signed int)hm->aud_threshhold )
            {
                printf("\nHealth Audio trigger activated\n");
                fire_trigger = 1;
            }
        }

        if ( fire_trigger )
        {
            struct SVENApp          *app = (struct SVENApp *)userdata0;

            sven_cmd_health(app, "health stats\0");
            hm->trigger_enabled = 0;

            svenlog_SetTrigger( app->svenlog );
        }
    }

    if ( SVEN_module_VIDREND == ev->se_et.et_module )
    {
        if ((SVEN_event_type_module_specific == ev->se_et.et_type) &&
            (SVEN_MODULE_EVENT_VIDREND_VID_PRESENT == ev->se_et.et_subtype) )
        {
            for ( i = (SMD_HEALTH_VID_TIMESTAMPS-1); i > 0; i-- )
            {
                hm->vid_timestamps[i] = hm->vid_timestamps[i-1];
            }
            hm->vid_timestamps[0] = ev->se_timestamp;
        }
    }
    else if ( SVEN_module_GEN3_AUD_IO == ev->se_et.et_module )
    {
        if ((SVEN_event_type_module_specific == ev->se_et.et_type) &&
            (SVEN_MODULE_EVENT_AUD_IO_ATC_INPUT_DEQUEUE == ev->se_et.et_subtype) )
        {
            for ( i = (SMD_HEALTH_AUD_TIMESTAMPS-1); i > 0; i-- )
            {
                hm->aud_timestamps[i] = hm->aud_timestamps[i-1];
            }
            hm->aud_timestamps[0] = ev->se_timestamp;
        }
    }

    return(0);
}

static int sven_cmd_health(
    struct SVENApp*  app,
    const  char*     command )
{
    int         num_tokens;
    int         err = 0;
    int         print_usage = 1;

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 1 )
    {
        print_usage = 0;

        if( !strncasecmp(app->cparse.token[1].token_str, "stat", 4))
        {
            int             i;

            printf("vid: ");
            /* Clear timestamp arrays to prevent false triggering  */
            for ( i = 0; i < (SMD_HEALTH_VID_TIMESTAMPS-1); i++ )
            {
                int             dt;
                dt = (int) (app->smd_health.vid_timestamps[i]-app->smd_health.vid_timestamps[i+1]);
                printf( "%5d ", (dt * 1000) / sven_ts_in_khz );
                //printf("%08x ", app->smd_health.vid_timestamps[i] );
            }
            printf("aud: ");
            /* Clear timestamp arrays to prevent false triggering  */
            for ( i = 0; i < (SMD_HEALTH_AUD_TIMESTAMPS-1); i++ )
            {
                int             dt;
                dt = (int) (app->smd_health.aud_timestamps[i]-app->smd_health.aud_timestamps[i+1]);
                printf( "%5d ", (dt * 1000) / sven_ts_in_khz );
                //printf("%08x ", app->smd_health.aud_timestamps[i] );
            }
            printf("\n");
        }
        else if( !strncasecmp(app->cparse.token[1].token_str, "vid", 3))
        {
            if ( num_tokens > 2 )
            {
                int         clocks;

                clocks = (app->cparse.token[2].token_int_value * sven_ts_in_khz);

                app->smd_health.vid_threshhold = clocks;

                printf("\nNew Video Health timeout %d clocks\n", app->smd_health.vid_threshhold );
            }
        }
        else if( !strncasecmp(app->cparse.token[1].token_str, "aud", 3))
        {
            if ( num_tokens > 2 )
            {
                int         clocks;

                clocks = (app->cparse.token[2].token_int_value * sven_ts_in_khz);

                app->smd_health.aud_threshhold = clocks;

                printf("\nNew Aud Health timeout %d clocks\n", app->smd_health.aud_threshhold );
            }
        }
        else if( !strncasecmp(app->cparse.token[1].token_str, "en", 2))
        {
            int             i;

            /* Clear timestamp arrays to prevent false triggering  */
            for ( i = 0; i < SMD_HEALTH_VID_TIMESTAMPS; i++ )
            {
                app->smd_health.vid_timestamps[i] = 0;
            }
            for ( i = 0; i < SMD_HEALTH_AUD_TIMESTAMPS; i++ )
            {
                app->smd_health.aud_timestamps[i] = 0;
            }

            app->smd_health.trigger_enabled = 1;
        }
        else if( !strncasecmp(app->cparse.token[1].token_str, "dis", 3))
        {
            app->smd_health.trigger_enabled = 0;
        }
        else
        {
            print_usage = 1;
        }
    }

    if ( print_usage )
    {
        printf("\n");
        printf("usage: health [enable|disable|stats] - enable/disable SMD Health trigger\n");
        printf("     : health vid <milliseconds> - Set VIDREND_VID_PRESENT timeout in milliseconds\n");
        printf("     : health aud <milliseconds> - Set ATC_INPUT_DEQUEUE timeout in milliseconds\n");
    }

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        validate logic
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_dfx( struct SVENApp* app, const char* command )
{
   int                err = 0;
   struct SVENHandle *svenh = app->svenh;

   UNUSED_PARAMETER(command);

   if ( svenh->pcur != svenh->pinc )
   {
      int               i,j,t;
      struct SVENEvent  ev;

      printf("DFX Enabled\n");

      t = *svenh->pcur;

      printf("test dfx_regs POS: %08x (%08x)..", t, svenh->hdr->buffers[svenh->buffnum].svc_pos );
      for ( i = 0; i < (1<<20); i++ )
      {
         j = *svenh->pinc;

         if ( j != (t + i + 1) )
         {
            printf("ERR in svenh->pinc\n");
            err = 1;
            break;
         }

         if ( j != (int) *svenh->pcur )
         {
            printf("ERR in svenh->pcur\n");
            err = 1;
            break;
         }
      }

      if ( i == (1<<20) )
      {
         printf("PASS\n");
      }
      t += i;  /* continuing next test */

      printf("test  inlines POS: %08x (%08x)..", t, svenh->hdr->buffers[svenh->buffnum].svc_pos );
      for ( i = 0; i < (1<<20); i++ )
      {
         j = _sven_reserve_event_slot(svenh);

         if ( j != (t + i + 1) )
         {
            printf("ERR in _sven_reserve_event_slot()\n");
            err = 1;
            break;
         }

         if ( j != (_sven_get_write_position(svenh)-1) )
         {
            printf("ERR in _sven_get_write_position()\n");
            err = 1;
            break;
         }
      }

      if ( i == (1<<20) )
      {
         printf("PASS\n");
      }
      t += i;  /* continuing next test */
      //j = t;
      j = t = _sven_get_write_position(svenh);

      memset(&ev,0xff,sizeof(ev));

      printf("test   events POS: %08x (%08x)..", t, svenh->hdr->buffers[svenh->buffnum].svc_pos );
      for ( i = 0; i < (1<<20); i++ )
      {
         struct SVENEvent  rev;

         ev.u.se_ulong[0] = i;
         ev.u.se_ulong[1] = t+i;
         ev.u.se_ulong[2] -= 0x0001;
         ev.u.se_ulong[3] -= 0x0010;
         ev.u.se_ulong[4] -= 0x0100;
         ev.u.se_ulong[5] -= 0x1000;

         _sven_write_new_event( svenh, &ev );

         if ( ! _sven_read_next_event( svenh, &rev, &j ) )
         {
            printf("ERR in _sven_read_next_event()\n");
            err = 1;
            break;
         }
         else
         {
            /* write_new_event overwrites these */
            ev.se_et.et_gencount = rev.se_et.et_gencount;
            ev.se_timestamp = rev.se_timestamp;

            if ( memcmp( &ev, &rev, sizeof(rev)) )
            {
               printf("ERR TX,RX events not equal()\n");
               err = 1;
               break;
            }
         }
      }
      if ( i == (1<<20) )
      {
         printf("PASS\n");
      }
   }
   else
   {
      printf("DFX Not Enabled\n");
   }

   return( err );
}

/* ===========================================================================*/
/* ===========================================================================*/

#define VALIDATE_MODULE     0x1ff
#define VALIDATE_UNIT       0x3

struct ValStats
{
    int             filter_events_caught;
    int             read_events_caught;
};

static int sven_validation_filter(
    struct SVENEvent    *ev,
    void                *userdata0,
    void                *userdata1 )
{
//    struct SVENApp      *app = (struct SVENApp *)userdata0;
    struct ValStats     *vs = (struct ValStats *)userdata1;

    UNUSED_PARAMETER(userdata0);

    if ( (VALIDATE_MODULE == ev->se_et.et_module) &&
         (VALIDATE_UNIT == ev->se_et.et_unit) )
    {
        vs->filter_events_caught++;
    }

    return( 0 );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        validate logic
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_validate( struct SVENApp* app, const char* command )
{
    int                      err = 0;
    struct SVENUserFilter   *uf;
    struct ValStats          vs;

    UNUSED_PARAMETER(command);

    sven_cmd_go( app, "thread" );   /* force thread launch */

    memset( &vs ,0, sizeof(vs) );   /* clear the stats */

    if ( NULL != (uf = svenlog_add_user_filter( app->svenlog, sven_validation_filter, app, &vs )) )
    {
        int                 qnum,nqueues;
        struct SVENHandle   txh[4];
        struct SVENEvent    ev;

        memset( txh,0,sizeof(txh));

        nqueues = app->svenh->hdr->svh_circbuffer_count;

        if ( nqueues > 4 )
        {
            printf("ERR: Number of SVEN Event Queues is > 4 (%d)\n", nqueues );
            nqueues = 4;
            err = 1;
        }

        for ( qnum = 0; qnum < nqueues; qnum++ )
        {
            sven_attach_handle_to_queue( &txh[qnum], app->svenh->hdr, qnum );
        }

        while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
        {
            /* drain the log */
        }

        memset( &ev,0,sizeof(ev) );
        ev.se_et.et_module = VALIDATE_MODULE;
        ev.se_et.et_unit = VALIDATE_UNIT;

        for ( qnum = 0; qnum < nqueues; qnum++ )
        {
            int                 i,nevents;
            int                 timeout;

            /* fill the queue 3/4 full */
            nevents = txh[qnum].event_pos_mask + 1;
            nevents = (nevents>>2) + (nevents>>1);  /* 1/2 + 1/4 of size */

            vs.filter_events_caught = 0;    /* Reset the #events caught by the filter */

            printf("generating %d events on q %d....", nevents, qnum );
            for ( i = 0; i < nevents; i++ )
            {
                ev.u.se_uint[0] = qnum;
                ev.u.se_uint[1] = i;
                ev.u.se_uint[2] = nevents;
                ev.u.se_uint[3] = 0xcccccccc;
                ev.u.se_uint[4] = 0xcccccccc;
                ev.u.se_uint[5] = 0xcccccccc;
                sven_write_event( &txh[qnum], &ev );
            }

            timeout = 0;

            while ( vs.filter_events_caught < nevents )
            {
                printf("%d: arrival at filter...", timeout );
                sleep(1);
                if ( ++timeout > 5 )
                {
                    printf("\nERR: not all events arrived at filter (expected %d, got %d)\n",
                        nevents, vs.filter_events_caught  );
                    err = 2;
                    break;
                }
            }
            if ( vs.filter_events_caught == nevents )   printf("OK ");

            printf( "arrival at local buffer..." );
            i = 0;
            while ( i < nevents )
            {
                if ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
                {
                    if ( (VALIDATE_MODULE == ev.se_et.et_module) &&
                         (VALIDATE_UNIT == ev.se_et.et_unit) )
                    {
                        i++;
                    }
                }
                else
                {
                    printf("\nERR: Not all local events available, failed at %d of %d\n", i, nevents );
                    err = 2;
                    break;
                }
            }
            if ( !err && (i == nevents) )
            {
                /* VALIDATE PASS */
                printf("PASS\n");
            }
        }

        /* OVER-FILL the last queue */
        if ( (qnum = nqueues-1) > 0 )
        {
            int                 i,nevents;
            int                 timeout;

            /* fill the queue 3/4 full */
            nevents = txh[qnum].event_pos_mask + 1;
            nevents = nevents + (nevents>>2);       /* OVERFILL by 1/4 !!!!!*/

            vs.filter_events_caught = 0;    /* Reset the #events caught by the filter */

            printf("OVERFILL %d events on q %d, size\n", nevents, qnum );
            for ( i = 0; i < nevents; i++ )
            {
                ev.u.se_uint[0] = qnum;
                ev.u.se_uint[1] = i;
                ev.u.se_uint[2] = nevents;
                ev.u.se_uint[3] = 0xaaaaaaaa;
                ev.u.se_uint[4] = 0xaaaaaaaa;
                ev.u.se_uint[5] = 0xaaaaaaaa;
                sven_write_event( &txh[qnum], &ev );
            }

            timeout = 0;
            while ( vs.filter_events_caught < nevents )
            {
                printf("%d: check for arrival at filter\n", timeout );
                sleep(1);
                if ( ++timeout > 1 )
                {
                    printf("ERR: not all events arrived at filter (expected %d, got %d)\n",
                        nevents, vs.filter_events_caught  );
                    /* NOT AN ERROR bcause we "lapped" the SVENLOG Reader */
                    break;
                }
            }
            printf("OVERFILLED and caught %d events\n", vs.filter_events_caught );

            printf( "check for arrival at local buffer..." );
            i = 0;
            while ( i < vs.filter_events_caught )
            {
                if ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
                {
                    if ( (VALIDATE_MODULE == ev.se_et.et_module) &&
                         (VALIDATE_UNIT == ev.se_et.et_unit) )
                    {
                        i++;
                    }
                }
                else
                {
                    printf("\nERR: Not all local events available, failed at %d of %d\n", i, nevents );
                    err = 2;
                    break;
                }
            }
            if ( !err && (i == vs.filter_events_caught) )
            {
                /* VALIDATE PASS */
                printf("PASS\n");
            }
        }

        svenlog_remove_user_filter( app->svenlog, uf );
    } else err = 1;

    return( err );
}

enum sven_overhead_test
{
   SVEN_OVERHEAD_WRITE_EVENT,
   SVEN_OVERHEAD_DEVH_DEBUG,
   SVEN_OVERHEAD_DIRECT_READ,
   SVEN_OVERHEAD_DIRECT_WRITE,
   SVEN_OVERHEAD_DEVH_READ,
   SVEN_OVERHEAD_DEVH_WRITE,
   SVEN_OVERHEAD_DEVH_READ_POLL
};

static void sven_perform_overhead_loop(
   os_devhandle_t     *devh,
   struct SVENHandle  *svenh,
   const char         *test_name,
   enum sven_overhead_test test_type,
   int                 nevents,
   int                 niterations,
   unsigned int        roff )
{
   int                 t,i,q=0;
   struct timeval      tv[2];
   struct timeval      lowest_tv,highest_tv;
   struct SVENEvent    ev;

   memset( &lowest_tv,0,sizeof(lowest_tv) );
   memset( &highest_tv,0,sizeof(highest_tv) );

   memset( &ev,0,sizeof(ev) );
   ev.se_et.et_module = VALIDATE_MODULE;
   ev.se_et.et_unit = VALIDATE_UNIT;
   ev.u.se_uint[0] = 0xabadfeed;
   ev.u.se_uint[1] = 0;
   ev.u.se_uint[2] = nevents;
   ev.u.se_uint[3] = 0xcccccccc;
   ev.u.se_uint[4] = 0xcccccccc;
   ev.u.se_uint[5] = 0xcccccccc;

   for ( t = 0; t < niterations; t++ )
   {
      gettimeofday( &tv[0], NULL );

      switch( test_type )
      {
         case  SVEN_OVERHEAD_WRITE_EVENT:
         {
            for ( i = 0; i < nevents; i++ )
            {
                ev.u.se_uint[1] = i;
                sven_write_event( svenh, &ev );
            }
         }
         break;
         case  SVEN_OVERHEAD_DEVH_DEBUG:
         {
            for ( i = 0; i < nevents; i++ )
            {
               DEVH_DEBUG( devh, "SVEN Overhead" );
            }
         }
         break;
         case  SVEN_OVERHEAD_DIRECT_READ:
         {
            for ( i = 0; i < nevents; i++ )
            {
               q += *((volatile unsigned int *)((char *)devh->devh_regs_ptr + roff));
            }
         }
         break;
         case  SVEN_OVERHEAD_DIRECT_WRITE:
         {
            for ( i = 0; i < nevents; i++ )
            {
               *((volatile unsigned int *)((char *)devh->devh_regs_ptr + roff)) = q;
            }
         }
         break;
         case  SVEN_OVERHEAD_DEVH_READ:
         {
            for ( i = 0; i < nevents; i++ )
            {
               devh_ReadReg32( devh, roff );
            }
         }
         break;
         case  SVEN_OVERHEAD_DEVH_WRITE:
         {
            for ( i = 0; i < nevents; i++ )
            {
               devh_WriteReg32( devh, roff, q );
            }
         }
         break;
         case  SVEN_OVERHEAD_DEVH_READ_POLL:
         {
            for ( i = 0; i < nevents; i++ )
            {
               q = devh_ReadReg32_polling_mode( devh, roff, q );
            }
         }
         break;
      }

      gettimeofday( &tv[1], NULL );
      tv[1].tv_usec += (tv[1].tv_sec - tv[0].tv_sec) * 1000000;

      /* Grab the BEST time */
      if ( (0 == t) || (tv[1].tv_usec < lowest_tv.tv_usec) )
      {
         lowest_tv.tv_usec = tv[1].tv_usec;
      }
      /* Grab the Worst time */
      if ( (0 == t) || (tv[1].tv_usec > highest_tv.tv_usec) )
      {
         highest_tv.tv_usec = tv[1].tv_usec;
      }
   }

   printf("%-44s %5d.%03d us each\n",
      test_name,
      (int) (lowest_tv.tv_usec / nevents),
      (int) (((lowest_tv.tv_usec * 1000) / nevents) % 1000) );

}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Measure SVEN Performance Characteristics
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_overhead( struct SVENApp* app, const char* command )
{
   int                 err = 0;
   os_devhandle_t     *devh=NULL;
   int                 nevents,niterations;
   struct SVENHandle   txh;
   int                 tokens_parsed;

    /* how these are used */
    tokens_parsed = cparse_parse_command( &app->cparse, command );

    nevents = 500000;   /* one half million */
    niterations = 10;

    if ( tokens_parsed > 1 )
    {
        nevents = app->cparse.token[1].token_int_value;
    }
    if ( tokens_parsed > 2 )
    {
        niterations = app->cparse.token[2].token_int_value;
    }


   memset( &txh, 0, sizeof(txh) );

   sven_attach_handle_to_queue( &txh, app->svenh->hdr, 0 );

   printf("generating %d (0x%x) SVENEvents\n", nevents, nevents );

/*
   SVEN_OVERHEAD_WRITE_EVENT,
   SVEN_OVERHEAD_DEVH_DEBUG,
   SVEN_OVERHEAD_DIRECT_READ,
   SVEN_OVERHEAD_DIRECT_WRITE,
   SVEN_OVERHEAD_DEVH_READ,
   SVEN_OVERHEAD_DEVH_WRITE,
   SVEN_OVERHEAD_DEVH_READ_POLL
*/

   sven_perform_overhead_loop( devh, &txh, "sven_write_event()", SVEN_OVERHEAD_WRITE_EVENT, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );

   if( NULL != (devh = devhandle_factory(NULL)) )
   {
      unsigned int      hot;

      devh_SVEN_SetModuleUnit( devh, VALIDATE_MODULE, VALIDATE_UNIT );

      hot = *app->esvenh.phot;   /* save current "hot" value */

      if ( devhandle_connect_name( devh, "GEN3_DFX" ) )
      {
         unsigned int      size;

         size = devh_ReadReg32( devh, ROFF_DFX_OMAR_CAP_SIZE );   /* save */

         *app->esvenh.phot = -1; /* disable all */
         sven_perform_overhead_loop( devh, &txh, "DIRECT READ", SVEN_OVERHEAD_DIRECT_READ, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );
         sven_perform_overhead_loop( devh, &txh, "HOT-DISABLED devh_ReadReg32()", SVEN_OVERHEAD_DEVH_READ, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );
         *app->esvenh.phot = 0; /* enable all */
         sven_perform_overhead_loop( devh, &txh, "HOT-ENABLED  devh_ReadReg32()", SVEN_OVERHEAD_DEVH_READ, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );

         *app->esvenh.phot = -1; /* disable all */
         sven_perform_overhead_loop( devh, &txh, "DIRECT WRITE", SVEN_OVERHEAD_DIRECT_WRITE, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );
         sven_perform_overhead_loop( devh, &txh, "HOT-DISABLED devh_WriteReg32()", SVEN_OVERHEAD_DEVH_WRITE, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );
         *app->esvenh.phot = 0; /* enable all */
         sven_perform_overhead_loop( devh, &txh, "HOT-ENABLED  devh_WriteReg32()", SVEN_OVERHEAD_DEVH_WRITE, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );

         #if 0
         *app->esvenh.phot = 0; /* enable all */
         sven_perform_overhead_loop( devh, &txh, "HOT-ENABLED  DEVH_DEBUG()", SVEN_OVERHEAD_DEVH_DEBUG, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );
         sven_perform_overhead_loop( devh, &txh, "HOT-ENABLED  devh_ReadReg32_polling_mode()", SVEN_OVERHEAD_DEVH_READ_POLL, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );
         *app->esvenh.phot = -1; /* disable all */
         sven_perform_overhead_loop( devh, &txh, "HOT-DISABLED DEVH_DEBUG()", SVEN_OVERHEAD_DEVH_DEBUG, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );
         sven_perform_overhead_loop( devh, &txh, "HOT-DISABLED devh_ReadReg32_polling_mode()", SVEN_OVERHEAD_DEVH_READ_POLL, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );
         #endif

         devh_WriteReg32( devh, ROFF_DFX_OMAR_CAP_SIZE, size );   /* restore */
      }
      else
      {
         *app->esvenh.phot = 0; /* enable all */
         sven_perform_overhead_loop( devh, &txh, "HOT-ENABLED  DEVH_DEBUG()", SVEN_OVERHEAD_DEVH_DEBUG, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );

         *app->esvenh.phot = -1; /* disable all */
         sven_perform_overhead_loop( devh, &txh, "HOT-DISABLED DEVH_DEBUG()", SVEN_OVERHEAD_DEVH_DEBUG, nevents, niterations, ROFF_DFX_OMAR_CAP_SIZE );
      }

      *app->esvenh.phot = hot;   /* restore previous "hot" */

      devh_Delete(devh);
   }
   return( err );
}
////////////////////////////////////////////////////////////////////////////////
/// @brief        Measure SVEN Performance Characteristics
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_hogs( struct SVENApp* app, const char* command )
{
   int                 err = 0;
   int                 tokens_parsed;
   int                 i;

   /* how these are used */
   tokens_parsed = cparse_parse_command( &app->cparse, command );

   for ( i = 0; i < 1024; i++ )
   {
      if ( 0 != app->hogs.module_event_count[i] )
      {
         char        modname[64];

         sprintf( modname,"mod-%d", i );

         if ( i < SVEN_module_MAX )
         {
           const struct ModuleReverseDefs  *mrd;

           if ( NULL != (mrd = svenreverse_GetModuleTables(i)) )
           {
               if ( NULL != mrd->mrd_name )
               {
                  strcpy( modname, mrd->mrd_name );
               }
           }
         }

         printf("Module: %16s events %d\n", modname, app->hogs.module_event_count[i] );

         if ( SVEN_module_SMD_CORE == i )
         {
            int         j;

            for( j = 0; j < 16; j++ )
            {
               if ( 0 != app->hogs.smd_unit_event_count[j] )
               {
                  printf(" unit: %d events %d\n", j, app->hogs.smd_unit_event_count[j] );
                  app->hogs.smd_unit_event_count[j] = 0;
               }
            }
         }
         app->hogs.module_event_count[i] = 0;
      }
   }

   return(err);
}



////////////////////////////////////////////////////////////////////////////////
/// @brief        Measure SVEN Performance Characteristics
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_fw_globals( struct SVENApp* app, const char* command )
{
   int                           err = 0;
   struct SVEN_FW_Globals        fw_globals;

   (void) app;
   (void) command;

   err = sven_init_fw_globals( &fw_globals );

   if ( 0 == err )
   {
      printf( "SVEN_FW_Globals: cb %08x  cb_size %08x  hot %08x  time %08x  inc %08x  cur %08x\n",
         (unsigned int) fw_globals.en,
         (unsigned int) fw_globals.eventbuf_size,
         (unsigned int) fw_globals.sven_dfx_hot,
         (unsigned int) fw_globals.sven_dfx_time,
         (unsigned int) fw_globals.sven_dfx_inc_tx,
         (unsigned int) fw_globals.sven_dfx_cur_tx );
   }
   else
   {
      printf("ERR: sven_init_fw_globals() returns %d\n", err );
   }

   return(err);
}

/* ===========================================================================*/

////////////////////////////////////////////////////////////////////////////////
/// Static Global Structure holds sven lexicon comands and ptrs to functions
////////////////////////////////////////////////////////////////////////////////
static struct app_command_dispatcher g_svenapp_commands[] =
{
    { "q"   ,           "Quit SVEN console",
        sven_cmd_quit },
    { "quit",           "Quit SVEN console",
        sven_cmd_quit },
    { "help",           "print help with commands",
        sven_cmd_help },
    { "sleep",          "sleep for N seconds",
        sven_cmd_sleep },
    { "pause",          "pause capture",
        sven_cmd_pause },
    { "run",            "restart capture",
        sven_cmd_run },
    { "monitor",        "Monitor (print) all events coming into the nexus",
        sven_cmd_monitor },
    { "hdr",            "print SVEN shared memory header info",
        sven_cmd_print_header },
    { "dump",           "dump (up to) last 50 events",
        sven_cmd_dump },
    { "hexdump",        "dump (in hex) last 50 events",
        sven_cmd_hexdump },
    { "search",         "Search Events for any payload between <min> and <max>",
        sven_cmd_search },
    { "lookup",            "lookup a module, register, bitfield",
        sven_cmd_lookup },
    { "modules",           "List Supported Modules",
        sven_cmd_list_modules },
    { "logwrite",       "demonstrate log write",
        sven_cmd_logwrite },
    { "reset",          "reset shared memory areas (DANGEROUS)",
        sven_cmd_reset },
    { "recover",         "Recover All events from shared memory areas (usually after reset)",
        sven_cmd_recover },
    { "source",          "Execute additional commands in file",
        sven_cmd_source },
    { "thread",         "launch svenlog monitor thread",
        sven_cmd_go },
    { "decode",           "Decode MODULE reg_offset reg_value [prev_value] to text",
        sven_cmd_decode },
    { "peek",           "read a named register",
        sven_cmd_peek },
    { "poke",           "write a named register",
        sven_cmd_poke },
    { "hot",           "Hot Enable/Disable of event writers",
        sven_cmd_hot},
//    { "gpio",           "write a named register",
//        sven_cmd_gpio },
    { "source",           "source a file with the SVEN commands",
        sven_cmd_source},
    { "trigger",           "triggers on a specific event",
        sven_cmd_trigger},
    { "triggerdelay",      "Set the number of events to record after a trigger fires",
        sven_cmd_triggerdelay},
    { "filter",           "Filters SVENLog based on a Mask provided",
        sven_cmd_filter},
//    { "pmu",        "Configures the PMU based on the Script file provided",
//        sven_cmd_pmu},
    { "cw",         "Configures the CW based on the Script file provided",
        sven_cmd_cw},
    { "save",         "Save the (binary) SVENLOG to a file",
        sven_cmd_save},
    { "load",         "Load the (binary) SVENLOG from a file",
        sven_cmd_load},
    { "memsave",      "Save memory to a binary file",
        sven_cmd_memsave},
    { "memload",      "Load memory from a binary file",
        sven_cmd_memload},
    { "omar",           "OMAR Command",
        sven_cmd_omar },
    { "time",         "Select time display mode",
        sven_cmd_time },
    { "smd",          "Streaming Media Driver control",
        sven_cmd_smd },
    { "health",       "Health Trigger",
        sven_cmd_health },
    { "hogs",         "Find SVEN Event Transmission hogs",
        sven_cmd_hogs},
    { "null",         "NULL Devhandle Test",
        sven_cmd_NULL_devh},
    { "dfx",         "tests DFX support",
        sven_cmd_dfx},
    { "overhead",         "Measures Overhead",
        sven_cmd_overhead},
    { "stream",         "Save the SVENLOG to a file",
        sven_cmd_stream},
    { "timestamp",    "Timestamp Test",
        sven_cmd_timestamp},
    { "self_test",     "Validate Log Writing Code",
        sven_cmd_validate},
    { "dttc",         "DTTC Example code",
        sven_cmd_dttc_example},
    { "xsi",         "Get XSI Clock Speed",
        sven_cmd_get_xsi_speed},
    { "testparser",         "See how the debug console parses the command line",
        sven_cmd_testparser},
    { "fw_globals",         "display fw globals",
        sven_cmd_fw_globals},
    { "systime", "print the current system time",
        sven_cmd_systime},
    { "echo", "print a string",
        sven_cmd_echo},
    { "triggerwait", "Wait for a trigger event [optional timeout in seconds]",
        sven_cmd_triggerwait},
    {NULL, NULL, NULL}    /* NULL Terminator */
};


////////////////////////////////////////////////////////////////////////////////
/// @brief        Function to convert sven lexicon into function calls
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
int svenapp_dispatch_command(
    struct SVENApp*  app,
    const  char*     command )
{
    struct app_command_dispatcher  *cd = g_svenapp_commands;
    int         index = 0;
    char        temp_command[1024];

    /* search for first token */
    index = 0;
    while ( command[index] && (' ' != command[index]) )
    {
        temp_command[index] = command[index];
        index++;
    }
    temp_command[index] = '\0';

    while ( NULL != cd->cmdname )
    {
        if ( !strcasecmp( cd->cmdname, temp_command ) )
        {
            return( (*cd->dispatch)( app, command ) );
        }
        cd++;
    }

    if ( index > 0 )    /* something besides just enter */
    {
        printf("Unknown command: \"%s\"\n", temp_command );
    }

    return( 0 );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Main loop
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
int svenapp_source_main(
    struct SVENApp*  app, bool from_src_cmd_flag )
{
    /* accept 2k commands */
    static char     g_command[2048];
    int             err = 0;

    if ( app->interactive_mode ) printf("sven> ");



    while ( 1 )
    {
        int         nchars;
        int         len;
        char        *linebuf;

        linebuf = g_command;
        nchars = -1;
#ifdef DISABLE_READLINE
        if ( NULL != fgets( g_command, sizeof(g_command), app->fin ) )
          nchars = strlen(g_command);
#else
        if ( stdin == app->fin )
        {
           linebuf = readline( "sven> " );
        }
        else
        {
           if ( NULL != fgets( g_command, sizeof(g_command), app->fin ) )
             nchars = strlen(g_command);
        }
#endif

        if ( nchars <= 0 )
        {
           //printf(" app->interactive_mode %d\n", app->interactive_mode );
           if ( from_src_cmd_flag ) break;  // Exit loop and function.
           usleep(100*1000);                // Sleep for 100 ms.
           continue;
        }

        /* eliminate from comment character to end of string before parsing */
        len = 0;
        while ( linebuf[len]  )
        {
            if ( '#' == linebuf[len] )
            {
                linebuf[len] = '\0';
                break;
            }
            len++;
        }

        /* newline characters were causing problems in the parser
        * turn them to null terminators
        */
//        len = strlen(g_command);

        if ( (len > 0) &&
            ( ('\n' == linebuf[len-1]) ||
            ('\r' == linebuf[len-1]) ) )
        {
            g_command[len-1] = '\0';
        }
        if ( (len > 1) &&
            ( ('\n' == linebuf[len-2]) ||
            ('\r' == linebuf[len-2]) ) )
        {
            linebuf[len-2] = '\0';
        }

        if ( !app->interactive_mode ) {
            // don't double echo
            if(0 != strncmp("echo", g_command, 4)) {
                printf("SVEN: %s\n", linebuf );
            }
        }
        err = svenapp_dispatch_command( app, linebuf );


        if ( linebuf != g_command )
          free(linebuf);

        if ( app->quit_requested )
        {
            break;
        }

        if ( app->interactive_mode ) printf("sven> ");
        fflush(stdout);
    }
    fflush(stdout);
    return( err );
}


////////////////////////////////////////////////////////////////////////////////
/// @brief        Help Command - Displays Help
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_help( struct SVENApp* app, const char* command )
{
    struct app_command_dispatcher  *cd = g_svenapp_commands;

    UNUSED_PARAMETER(app);
    UNUSED_PARAMETER(command);

    while ( NULL != cd->cmdname )
    {
        printf("%15s - %s\n", cd->cmdname, cd->arghelp );

        cd++;
    }
    return( 0 );
}

#ifdef NOT_WORKING_FROM_USER_MODE
#if defined(__XSCALE__) || defined(__LINUX_ARM_ARCH__)
// TODO:  Temporary function to dynamicly determine gen2 A Step vs. B step
#define GEN2_A2_CPUID 0x69056840
#define GEN2_B0_CPUID 0x69056844
inline static uint32_t get_cpu_id(void)
{
   uint32_t cpuid;
   asm volatile ( "mrc p15, 0, %0, c0, c0, 0\n\t": "=r" (cpuid) :);
   return cpuid ;
}
#endif
#else
#define get_cpu_id() 0
#endif

////////////////////////////////////////////////////////////////////////////////
/// @brief        Main entry into sven app
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
int main(
    int     argc,
    char*   argv[] )
{
    int         err = 0;
    int         log_size_megabytes;

    struct SVENApp*  app;

    /* Adds CTRL-C support to flush buffers prior to exit */
    signal(SIGINT , signal_handler);
    signal(SIGQUIT , signal_handler);
    signal(SIGTERM , signal_handler);

    build_reverse_rbd_table();

    /* LAST TWO Parameters may be "-l <log_MB>" */
    log_size_megabytes = 1;
    if ( (argc > 2) && !strcmp( argv[argc-2], "-l") )
    {
        log_size_megabytes = atol(argv[argc-1]);
        printf("log size is %d MB\n", log_size_megabytes );
        argc -= 2;  /* erase these two arguments */
    }

    if ( NULL != (app = svenapp_Create( NULL, log_size_megabytes )) )
    {
        /* default input filhandle is stdin */
        app->fin = stdin;

        // Shut's off NULL EVENTS, for debugging */
        //svenlog_add_blacklist_filter( app->svenlog, 4, 0xffffffff, 0x00000000 );

        /* sven source filename */
        if ( (argc > 2) && !strcasecmp( "source", argv[1] ) )
        {
            /* sven command script becomes input file  */
            if ( NULL != (app->fin = fopen( argv[2], "r" )) )
            {
                printf("Sourcing script \"%s\"\n", argv[2] );
                err = svenapp_source_main( app, true );
            }
            else
            {
                printf("Could not open \"%s\"\n", argv[2] );
            }
        }
        else if ( (argc > 1) )  /* sven command..... */
        {
            int             i;
            char            *cp;
            static char      app_command[2048];

            /* SVEN Command takes pre-tokenized command string, rebuild
            * the long command string before sending to dispatch_command
            */
            cp = app_command;
            for ( i = 1; i < argc; i++ )
            {
                cp += sprintf( cp, "%s ", argv[i] );
            }

            svenapp_dispatch_command( app, app_command );
        }
        else /* just plain old sven */
        {
            printf( "SVEN Interactive: Built " __DATE__ "\n"
                "Copyright 2006-2010 Intel Corporation All Rights Reserved\n"
                "type help for a list of commands or quit\n" );

            #if defined(__XSCALE__) || defined(__LINUX_ARM_ARCH__)
            printf("CPUID: 0x%08x ", get_cpu_id() );
            #endif

            printf("(ev): %d (long):%d (int):%d (short):%d (char):%d\n", (int)sizeof(struct SVENEvent), (int)sizeof(long), (int)sizeof(int), (int)sizeof(short), (int)sizeof(char) );

            sven_cmd_print_header( app, "hdr" );

            /* inform we are in interactive mode */
            app->interactive_mode = 1;
            err = svenapp_source_main( app, false );
        }

        svenapp_Delete( app );
    }
    else
    {
        printf("err: svenapp create failed\n");
        err = 2;
    }

    return( err );
}
