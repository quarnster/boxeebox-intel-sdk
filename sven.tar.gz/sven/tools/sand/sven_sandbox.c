/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

////////////////////////////////////////////////////////////////////////////////
///
/// @brief      SVEN Debug Console Application
///
/// History:    Created 11/2005
//  Note:       See Doxygen Manual http://www.doxygen.org/commands.html for
//              Special Commands used by doxygen tool to create documentation.
////////////////////////////////////////////////////////////////////////////////
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#ifndef SVEN_H
#include <sven.h>
#endif

#ifndef SVENREVERSE_H
#include <svenreverse.h>
#endif

#ifndef SVEN_PROTOS_H
#include <sven_protos.h>
#endif

#define OLO_TIMESTAMP_FREQ_IN_KHZ   62500

/* quick compile:
 *
 * gcc -Wall -m32 -I ./ -I ../../../i686-linux-elf/include -g ../../src/svenlib.c ../../src/svenreverse.c ../../src/svenlog.c sven_sandbox.c ../../../i686-linux-elf/lib/libsven_modules.a -lpthread -o sand
 *
 */
#define SVENLOG_LOCAL_EVENTBUF_SIZE (8 * 1024 * 1024)

/* == PRIVATE Functions Replace sven_init.c ================================== */
#ifdef __KERNEL__
       volatile unsigned int *g_sven_dfx_hot;
#else
static volatile unsigned int *g_sven_dfx_hot;
#endif
       volatile unsigned int *g_sven_dfx_time;     /* actual global */
static volatile unsigned int *g_sven_dfx_inc_tx;
static volatile unsigned int *g_sven_dfx_cur_tx;

static struct _SVENHeader	*g_sven_hdr;
static void                *g_sven_circbuf;

#if defined(__i386__) || defined(__x86_64__)
   // #define TIMESTAMP_FREQ_IN_KHZ 781   /* measured using GEN3 cpu */
   #define TIMESTAMP_FREQ_IN_KHZ   1000      /* using DFX unit timestamp */
#else
   #define TIMESTAMP_FREQ_IN_KHZ   1500
#endif
unsigned int g_sven_timestamp_frequency = TIMESTAMP_FREQ_IN_KHZ * 1000;

/* This is the XSI Bus Frequency (in MHz) - 1 */
#define SVEN_DFX_TIMESTAMP_1MHZ_PRESCALE  265

#define SVEN_SHARED_BLOCK_TOTAL_SIZE    ((4*1024)+(256*1024))

/* Timestamp frequency in ticks per second */
unsigned int sven_get_timestamp_frequency(void)
{
   return( g_sven_timestamp_frequency );
}

void sven_handle_dfx_init(
   struct SVENHandle    *svenh,
   struct _SVENHeader   *hdr )
{
   /* Extern DFX Stuff */
   svenh->phot          = g_sven_dfx_hot;
   svenh->ptime         = g_sven_dfx_time;
   svenh->pinc          = &hdr->buffers[svenh->buffnum].svc_pos;
   svenh->pcur          = &hdr->buffers[svenh->buffnum].svc_pos;
}

int sven_init_dfx_support( 
   struct _SVENHeader    *hdr )
{
   /* SETUP Default Registers */
   g_sven_dfx_hot    = (volatile unsigned int *) &hdr->svh_disable_mask_deprecated;
   g_sven_dfx_time   = (volatile unsigned int *) NULL;
   g_sven_dfx_inc_tx = (volatile unsigned int *) &hdr->buffers[0].svc_pos;
   g_sven_dfx_cur_tx = (volatile unsigned int *) &hdr->buffers[0].svc_pos;

   return(0);
}

void sven_header_initialize(
	struct _SVENHeader		*hdr,
    int                      sven_mempool_size,
    unsigned int             sven_header_physaddr,
    unsigned int             sven_circbuf_physaddr )
{
   int             circbuffer_size;
   int             os_page_size = (4*1024);	/* TODO: add page size */

   circbuffer_size = sven_mempool_size - os_page_size;

   /* clear out LSBs to make this a clean power of two */
   while ( circbuffer_size & (circbuffer_size-1) )
      circbuffer_size &= ~(circbuffer_size-1);

   hdr->svh_version            = SVENHeader_VERSION_2;
   hdr->svh_disable_mask_deprecated = 0;
   hdr->svh_debug_flags        = 0;
   hdr->svh_hdr_physaddr       = sven_header_physaddr;
   hdr->svh_hdr_size           = (4*1024);

   if ( sven_circbuf_physaddr )
   {
      /* Circular buffer has different physical address
      * (doesn't immediately follow the header in phys mem)
      */
      hdr->svh_buff_physaddr  = sven_circbuf_physaddr;
   }
   else
   {
      hdr->svh_buff_physaddr  = hdr->svh_hdr_physaddr + hdr->svh_hdr_size;
   }

   hdr->svh_buff_size          = sven_mempool_size - hdr->svh_hdr_size;

    /* i386, all others have a SINGLE Memory Pool
     *  +-----+
     *  | hdr | - single PAGE_SIZE
     *  +-----+
     *    circbuffer is some power_of_two kbytes
     *  +-------------------------------------------+
     *  | circbuffer 0                              |
     *  +-------------------------------------------+
     *
     */
    /* initialise first buffer with half the memory pool */
    hdr->buffers[0].svc_physaddr = hdr->svh_buff_physaddr;
    hdr->buffers[0].svc_size = circbuffer_size;
    hdr->buffers[0].svc_pos = 0;
    hdr->buffers[0].svc_id = 0;

    /* Number of circular buffers described */
    hdr->svh_circbuffer_count   = 1;
}

/**
 * @brief        Gain access to the System-Visible-Event-Nexus Event Buffer area
 *
 * @returns     (struct _SVENHeader *) or NULL if unsuccessful
 *
 */
void *sven_get_event_buf()
{
    return( g_sven_circbuf );
}

/**
 * @brief        Gain access to the System-Visible-Event-Nexus
 *
 * @returns     (struct _SVENHeader *) or NULL if unsuccessful
 *
 */
struct _SVENHeader *sven_open_header()
{
    struct _SVENHeader  *hdr;

    if ( NULL == (hdr = g_sven_hdr) )
    {
       if ( NULL != (hdr = (struct _SVENHeader *) malloc(SVEN_SHARED_BLOCK_TOTAL_SIZE)) )
       {
           /* Initialize the header, physically contiguous */
           sven_header_initialize( hdr,
               SVEN_SHARED_BLOCK_TOTAL_SIZE,
               0, 0 );

           g_sven_circbuf = (char *)hdr + hdr->svh_hdr_size;
      }
      if ( NULL != hdr )
      {
         g_sven_hdr = hdr;
         sven_init_dfx_support(g_sven_hdr);
      }
   }

   return( hdr );
}

/* == Structures ============================================================ */

////////////////////////////////////////////////////////////////////////////////
/// @struct  Token for Command Parser
////////////////////////////////////////////////////////////////////////////////
struct CommandToken
{
    char*                token_str;         /* will be NULL terminated The string is 128 characters max */
    unsigned int         token_int_value;   /* parsed integer value */
    unsigned int         token_buf_size;    /* must be >= strlen(token) */
};

////////////////////////////////////////////////////////////////////////////////
/// @struct  Command Parser
////////////////////////////////////////////////////////////////////////////////
struct CommandParser
{
    int                  num_tokens;
    int                  max_tokens;
    int                  default_token_length;
    struct CommandToken* token;
};

////////////////////////////////////////////////////////////////////////////////
/// @struct  SVEN Application Data
////////////////////////////////////////////////////////////////////////////////
struct SVENApp
{
    struct SVENHandle   *svenh;   /* event writing handle, always points to esvenh */
    struct CommandParser cparse;

    struct SVENLog      *svenlog; /* logger */
    pthread_attr_t       svenlog_pthread_attr;
    pthread_t            svenlog_pthread;
    pthread_mutex_t      svenlog_pthread_mtx;
    pthread_cond_t       svenlog_pthread_cvr;
    int                  svenlog_pthread_quit_request;

    struct SVENReverser *srev;    /* reverser */
    struct _SVENHeader  *hdr;     /* sven header */
    FILE                *fin;     /* Input source of commands */
    int                  interactive_mode;
    int                  quit_requested;

    int                  time_display_mode;
    unsigned int         time_last_event_time;
    #define TDISPLAY_NORMAL     0
    #define TDISPLAY_DELTA      1
    #define TDISPLAY_TMINUS     2

    unsigned int         last_module_time[SVEN_module_MAX];

    /* private stuff below here */
    struct SVENHandle    esvenh; /* embedded writing handle, do not touch */
};

////////////////////////////////////////////////////////////////////////////////
/// @struct  Structure to hold sven lexicon and associated funtions
///
/// see global instance of sven lexicon later in souce: g_svenapp_commands
////////////////////////////////////////////////////////////////////////////////
struct app_command_dispatcher
{
    const char*     cmdname;
    const char*     arghelp;
    int           (*dispatch)( struct SVENApp *app, const char *command );
};


/* == Defintions ==========================================================*/

static int sven_cmd_help( struct SVENApp* app, const char* command );
static int sven_cmd_source( struct SVENApp* app, const char* command );
static int sven_cmd_list_modules( struct SVENApp* app, const char* command );
int svenapp_source_main(  struct SVENApp* app );
int svenapp_dispatch_command(struct SVENApp* app, const char* command );



/* ==================PMU Helper Function========================*/
//////////////////////////////////////////////////////////////////////////
///
/// @brief Helper functions for the PMU..Keep it here for now Ask Pat for a better location
///
/// @param[in] 	unit
/// @param[in] 	event
/// @param[in] 	sub_event
/// @returns sucess or failure
///////////////////////////////////////////////////////////////////////////



extern const struct EventTypeReverse* svenreverse_EVENT_TABLES_BY_NAME(
       const char*                    event_name );

extern const struct EventTypeReverse* svenreverse_EVENT_TABLES_BY_NUM(
       int                            event_num );

/* == Functions - Implementations ============================================*/

////////////////////////////////////////////////////////////////////////////////
///
/// @brief        Command Parser Initialization
///
///               Initializes Command tokens
///
/// @param[in]    cparse            ptr
/// @param[in]    num_tokens        how many
/// @param[in]    max_token_length  max length
///
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int cparse_init(
    struct CommandParser*    cparse,
    unsigned int             num_tokens,
    unsigned int             max_token_length )
{
    /* initializes several tokens */
    int             retval = 0;
    int             i;

    if ( NULL != (cparse->token = (struct CommandToken *)
        calloc( num_tokens, sizeof(struct CommandToken)) ) )
    {
        cparse->max_tokens = num_tokens;
        cparse->default_token_length = max_token_length;

        for (i = 0; i < num_tokens; i++ )   /* guess */
        {
            cparse->token[i].token_buf_size    = max_token_length;

            if ( NULL != (cparse->token[i].token_str =
                calloc(128, sizeof(char)) ) )
            {
            }
            else break;
        }

        if ( i == num_tokens )  /* no errors encountered */
        {
            retval = 1;
        }
    }

    return(retval);
}

////////////////////////////////////////////////////////////////////////////////
///
/// @brief        Command Parser
///
/// @param[in]    cparse   ptr
/// @param[in]    command  ptr command
///
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int cparse_parse_command(
    struct CommandParser* cparse,
    const  char*          command )
{
    unsigned int        done = 0;
    int                 tok_beg = 0;
    int                 tok_end = 0;

    cparse->num_tokens = 0;
    while (' ' == command[tok_end])
        tok_end++; /*seek the end of first white space */
    tok_beg = tok_end;

    do
    {
        if ( (' ' != command[tok_end]) && ('\0' != command[tok_end]) )
        {
            tok_end++;
        }
        else
        {
            if ( cparse->token[cparse->num_tokens].token_buf_size <= (tok_end - tok_beg) )
            {
                char            *new_tok;
                int              tok_bufsize;

                /* How big does this token need to grow */
                tok_bufsize = cparse->token[cparse->num_tokens].token_buf_size;
                while ( tok_bufsize <= (tok_end - tok_beg) )
                    tok_bufsize <<= 1;

                if ( NULL != (new_tok = calloc(tok_bufsize,1) ) )
                {
                    free( cparse->token[cparse->num_tokens].token_str );
                    cparse->token[cparse->num_tokens].token_str = new_tok;
                    cparse->token[cparse->num_tokens].token_buf_size = tok_bufsize;
                }
                else
                {
                    printf("SVEN ERR: Cannot Grow command parser token");
                    exit(0);
                }
            }
            strncpy( cparse->token[cparse->num_tokens].token_str, &command[tok_beg], (tok_end - tok_beg) );
            cparse->token[cparse->num_tokens].token_str[(tok_end - tok_beg)] = '\0';
            cparse->token[cparse->num_tokens].token_int_value = strtoul(
                cparse->token[cparse->num_tokens].token_str, NULL, 0);

            tok_beg = tok_end;
            cparse->num_tokens++;

            /* Grow the token array? */
            if ( cparse->num_tokens >= cparse->max_tokens )
            {
                struct CommandToken* new_tokens;

                if ( NULL != (new_tokens = calloc( sizeof(*new_tokens), cparse->max_tokens<<1)) )
                {
                    int         i;
                    for ( i = 0; i < cparse->max_tokens; i++ )
                    {
                        new_tokens[i].token_str = cparse->token[i].token_str;
                        new_tokens[i].token_buf_size = cparse->token[i].token_buf_size;
                        new_tokens[i].token_int_value = cparse->token[i].token_int_value;
                    }
                    while ( i < (cparse->max_tokens<<1) )
                    {
                        if ( NULL != (new_tokens[i].token_str = malloc( cparse->default_token_length )) )
                        {
                            new_tokens[i].token_buf_size = cparse->default_token_length;
                            new_tokens[i].token_int_value = 0;
                        }
                        else
                        {
                            printf("SVEN ERR: Cannot Grow command parser token table");
                            exit(0);
                        }

                        i++;
                    }
                    free( cparse->token );
                    cparse->token = new_tokens;
                    cparse->max_tokens<<= 1;
                }
                else
                {
                    printf("SVEN ERR: Cannot Grow command parser token table");
                    exit(0);
                }
            }
            
            /* skip to beginning of next token */
            while (command[tok_beg] && ((' ' == command[tok_beg]) || ('.') == command[tok_beg]))
                tok_beg++;

            tok_end = tok_beg;    /* for next iteration through the parser loop */
            if (command[tok_end] == '\0')
                done = 1;
        }

    } while(!done);

    return(cparse->num_tokens);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        De-allocation stuff
/// @param[in]    app   ptr
////////////////////////////////////////////////////////////////////////////////
void svenapp_Delete( struct SVENApp*  app )
{
    if ( NULL != app->srev )
    {
    }

    if ( NULL != app->svenlog )
    {
        svenlog_Delete( app->svenlog );
    }

    if ( NULL != app->hdr )
    {
    }

    free(app);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Print the header data and circular buffers info
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_print_header(
    struct SVENApp*  app,
    const  char*     command )
{
    struct _SVENHeader *hdr;
    int                 i;

    hdr = app->hdr;

    printf( "SVEN-Header: ver:     '%c%c%c%c' disab: %08x debugfl: %08x\n"
        "           : hdr_pa:%08x hdr_sz:%08x\n"
        "           : buf_pa:%08x buf_sz:%08x cb_count:%08x\n",
        (char)((hdr->svh_version>>24)&0xff),
        (char)((hdr->svh_version>>16)&0xff),
        (char)((hdr->svh_version>>8)&0xff),
        (char)((hdr->svh_version>>0)&0xff),
        hdr->svh_disable_mask_deprecated,
        hdr->svh_debug_flags,
        hdr->svh_hdr_physaddr,
        hdr->svh_hdr_size,
        hdr->svh_buff_physaddr,
        hdr->svh_buff_size,
        hdr->svh_circbuffer_count );

    /* Dump circular buffers */
    for ( i = 0; i < hdr->svh_circbuffer_count; i++ )
    {
        printf( "SVEN-CBuf-%d: cb_pa: %08x cb_siz:%08x cb_pos:  %08x cb_id: %08x\n",
            i,
            hdr->buffers[i].svc_physaddr,
            hdr->buffers[i].svc_size,
            hdr->buffers[i].svc_pos,
            hdr->buffers[i].svc_id );
    }

    return(0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Initialization
/// @param[in]    spec     ptr
/// @returns      ptr to SVENApp structure on success, NULL on failure
////////////////////////////////////////////////////////////////////////////////
struct SVENApp* svenapp_Create(
        const char*   spec )
{
    struct SVENApp  *app;

    if ( NULL != (app = (struct SVENApp *)calloc(1,sizeof(*app))) )
    {
        char        ok = 0;

        /* point-to-self */
        app->svenh = &app->esvenh;

        pthread_mutex_init(&app->svenlog_pthread_mtx,NULL);

        pthread_cond_init(&app->svenlog_pthread_cvr,NULL);

        if ( NULL != (app->hdr = sven_open_header()) )
        {
            /* Connect our handle, user-mode */
            sven_attach_handle_to_queue( app->svenh, app->hdr, SVEN_CIRCBUFFER_ID_CPU_USER );

            if ( NULL != (app->svenlog = svenlog_Create( app->hdr, SVENLOG_LOCAL_EVENTBUF_SIZE )) )
            {
                if ( NULL != (app->srev = svenreverse_Create( app->hdr )) )
                {
                    if ( cparse_init( &app->cparse, 8, 64 ) )
                    {
                        ok = 1;
                    }
                }
            }
        }


        if ( !ok )
        {
            svenapp_Delete(app);
            app = NULL;
        }
    }

    return( app );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Test the command parser
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_testparser(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;
    int                 tokens_parsed;
    int                 i;

    /* how these are used */
    tokens_parsed = cparse_parse_command( &app->cparse, command );

    printf("parsed %d:", tokens_parsed );

    for ( i = 0; i < tokens_parsed; i++ )
    {
        printf( "[%d:\"%s\" %08x] ", i,
            app->cparse.token[i].token_str,
            app->cparse.token[i].token_int_value );
    }

    printf("\n");
    
    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        read the (binary) SVEN log data from a file
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_load(
    struct SVENApp* app,
    const  char*    command )
{
    int                 err = 0;
    int                 tokens_parsed;

    /* how these are used */
    tokens_parsed = cparse_parse_command( &app->cparse, command );

    if ( tokens_parsed > 1 )
    {
        FILE                *fi;
        const char          *filename;
        int                  ignore_filters = 0;

        filename = app->cparse.token[1].token_str;

        if ( tokens_parsed > 2 )
            ignore_filters = app->cparse.token[1].token_int_value;

        if ( NULL != (fi = fopen( filename, "rb" )) )
        {
            struct SVENEvent    ev;
            int                 was_paused;
            int                 num_events_read;
            int                 num_events_passed_filter;

            printf("reading events from file \"%s\"\n", filename );

            was_paused = svenlog_IsCapturePaused( app->svenlog );

            svenlog_Pause( app->svenlog );
            sleep(1);

            num_events_read = 0;
            num_events_passed_filter = 0;
            while ( sizeof(ev) == fread( &ev, 1, sizeof(ev), fi ) )
            {
                num_events_read++;

                if ( svenlog_InsertEvent_Locally( app->svenlog, &ev, ignore_filters ) )
                {
                    num_events_passed_filter++;
                }

                #if 0
                if ( 0xF == (num_events_read & 0xF) )
                {
                    printf(".");
                }
                if ( 0x3FF == (num_events_read & 0x3FF) )
                {
                    printf("\n");
                }
                #endif
            }

            fclose(fi);
            printf("read %d of %d events from file \"%s\"\n", num_events_passed_filter, num_events_read, filename );
            printf("Event Capture is now paused, you must type run to capture again\n" );
        }
        else
        {
            printf("ERR: failed to open file \"%s\"\n", filename );
            err = 1;
        }
    }
    else
    {
        printf("ERR: usage load <filename>\n");
        err = 1;
    }
    
    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        save the (binary) SVEN log data to a file
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_save(
    struct SVENApp* app,
    const  char*    command )
{
    int                 err = 0;
    int                 tokens_parsed;

    /* how these are used */
    tokens_parsed = cparse_parse_command( &app->cparse, command );

    if ( tokens_parsed > 1 )
    {
        FILE                *fo;
        const char          *filename;

        filename = app->cparse.token[1].token_str;

        if ( NULL != (fo = fopen( filename, "wb+" )) )
        {
            struct SVENEvent    ev;
            int                 was_paused;
            int                 num_events_written;

            was_paused = svenlog_IsCapturePaused( app->svenlog );

            svenlog_Pause( app->svenlog );

            /* look to see all events */
            svenlog_RewindLocalEventReader( app->svenlog, 0 );

            num_events_written = 0;

            printf("saving to file \"%s\"\n", filename );

            while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
            {
                if ( sizeof(ev) != fwrite( &ev, 1, sizeof(ev), fo ) )
                {
                    printf("ERR: Write to \"%s\" failed\n", filename );
                    err = 1;
                    break;
                }
                else
                {
                    num_events_written++;
                }
            }

            /* let it start running again */
            if ( !was_paused ) svenlog_Run( app->svenlog );

            fclose(fo);
            printf("wrote %d events to file \"%s\"\n", num_events_written, filename );
        }
        else
        {
            printf("ERR: failed to open \"%s\" for save\n", filename );
            err = 1;
        }
    }
    else
    {
        printf("ERR: usage save <filename>\n");
        err = 1;
    }
    
    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        dump the SVEN log data
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_dump(
    struct SVENApp* app,
    const  char*    command )
{
    int                 err = 0;
    int                 num_events_to_capture;
    int                 captured;
    struct SVENEvent    ev;
    static char         revstr[4096];

    /* break out the tokens from the command string */
    cparse_parse_command( &app->cparse, command );

    num_events_to_capture = 40; /* SWAG: standard linux console height */
    if ( app->cparse.num_tokens > 1 )   /* events to capture available here? */
        num_events_to_capture = app->cparse.token[1].token_int_value;
    if ( num_events_to_capture <= 0 )
        num_events_to_capture = 40;
    
    captured = 0;

    /* Seek backwards */
    svenlog_RewindLocalEventReader( app->svenlog, 1 );
    if ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
    {
        app->time_last_event_time = ev.se_timestamp;
    }

    /* reset last module times */
    for (err = 0; err < SVEN_module_MAX; err++ )
    {
        app->last_module_time[err] = app->time_last_event_time;
    }
    err = 0;    /* reset this */


    svenlog_RewindLocalEventReader( app->svenlog, num_events_to_capture );

    while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
    {
        svenlog_GetEventTextString( app->svenlog, &ev, revstr );

        switch ( app->time_display_mode )
        {
            case 0: /* TEMPORARY */
            case TDISPLAY_DELTA:
            {
                int             delta,ms,us;

                delta = ev.se_timestamp - app->time_last_event_time;
                ms = delta / OLO_TIMESTAMP_FREQ_IN_KHZ;     /* number of milliseconds */
                delta = delta % OLO_TIMESTAMP_FREQ_IN_KHZ;  /* remaining clocks */

                us = delta / ((OLO_TIMESTAMP_FREQ_IN_KHZ + 999)/1000);      /* microseconds */
                delta = delta % ((OLO_TIMESTAMP_FREQ_IN_KHZ + 999)/1000);   /* remaining clocks */

                /* use "delta" to push back previous timestamp by un-accounted-for clocks */
                app->time_last_event_time = ev.se_timestamp - delta;

                if ( (ev.se_et.et_module >= 0) && (ev.se_et.et_module < SVEN_module_MAX) )
                {
                    int             mms,mus;

                    delta = ev.se_timestamp - app->last_module_time[ev.se_et.et_module];
                    mms = delta / OLO_TIMESTAMP_FREQ_IN_KHZ;     /* number of milliseconds */
                    delta = delta % OLO_TIMESTAMP_FREQ_IN_KHZ;  /* remaining clocks */

                    mus = delta / ((OLO_TIMESTAMP_FREQ_IN_KHZ + 999)/1000);      /* microseconds */
                    delta = delta % ((OLO_TIMESTAMP_FREQ_IN_KHZ + 999)/1000);   /* remaining clocks */

                    printf( " dt:%4d.%03d mt:%4d.%03d %s\n", ms, us, mms, mus, revstr );

                    /* Save last module timestamp */
                    /* use "delta" to push back previous timestamp by un-accounted-for clocks */
                    app->last_module_time[ev.se_et.et_module] = ev.se_timestamp - delta;
                }
                else
                {
                    printf( " dt:%4d.%03d %s\n", ms, us, revstr );
                }
            }
            break;
            case TDISPLAY_TMINUS:
            {
                int             delta,ms,us;

                delta = ev.se_timestamp - app->time_last_event_time;
                delta = -delta; /* convert to t-minus */
                ms = delta / OLO_TIMESTAMP_FREQ_IN_KHZ;     /* number of milliseconds */
                delta = delta % OLO_TIMESTAMP_FREQ_IN_KHZ;  /* remaining clocks */

                us = delta / ((OLO_TIMESTAMP_FREQ_IN_KHZ + 999)/1000);      /* microseconds */

                printf( " t-:%4d.%03d %s\n", ms, us, revstr );
            }
            break;
            default:
            printf( " t:%08x %s\n", ev.se_timestamp, revstr );
            break;
        }

        if ( ++captured >= num_events_to_capture )
            break;
    }

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        dump the SVEN log data
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_all(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;
    struct SVENEvent    ev;
    static char         revstr[1024];


    /* Seek last thirty */
    svenlog_RewindLocalEventReader( app->svenlog, 0 );

    while ( 1 )
    {
        while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
        {
            if ( ev.se_et.et_module || ev.se_et.et_type )
            {
                svenlog_GetEventTextString( app->svenlog, &ev, revstr );
                printf( " t:%08x %s\n", ev.se_timestamp, revstr );
            }
        }

        usleep(4000);
    }

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        dump the SVEN log data in hex
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_hexdump(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;
    int                 num_events_to_capture;
    int                 captured;
    struct SVENEvent    ev;

    /* break out the tokens from the command string */
    cparse_parse_command( &app->cparse, command );

    num_events_to_capture = 40; /* SWAG: standard linux console height */
    if ( app->cparse.num_tokens > 1 )   /* events to capture available here? */
        num_events_to_capture = app->cparse.token[1].token_int_value;
    if ( num_events_to_capture <= 0 )
        num_events_to_capture = 40;
    

    captured = 0;

    /* Seek last thirty */
    svenlog_RewindLocalEventReader( app->svenlog, num_events_to_capture );

    while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
    {
        int             i;

        for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
            printf("%08x ", ((unsigned int *)&ev)[i] );
        }

        printf("\n");

        if ( ++captured >= num_events_to_capture )
            break;
    }

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        write data to the log
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_logwrite(
    struct SVENApp*  app,
    const  char*     command )
{
    struct SVENHandle   *svenh = app->svenh;

    SVEN_FUNC_ENTER(svenh,0,0);
    SVEN_AUTO_TRACE(svenh,0,0);

    sven_WriteDebugString( svenh,
        SVEN_module_GEN2_HDMI,    /* module from "sven_unit.h" */
        0,                      /* unit */
        SVEN_DEBUGSTR_Generic,
        "Hey There" );

    SVEN_AUTO_TRACE(svenh,0,0);

    sven_WriteDebugString( svenh,
        SVEN_module_GEN2_HDMI,    /* module from "sven_unit.h" */
        0,                      /* unit */
        SVEN_DEBUGSTR_FunctionEntered,
        __FUNCTION__ );

    SVEN_AUTO_TRACE(svenh,0,0);

    sven_WriteDebugString( svenh,
        SVEN_module_GEN2_HDMI,    /* module from "sven_unit.h" */
        0,                      /* unit */
        SVEN_DEBUGSTR_Checkpoint,
        "about to perform regio test" );

    SVEN_AUTO_TRACE(svenh,0,0);

    /* Send out a fake register read */
    sven_WriteEventVA_ulong( svenh,
        SVEN_module_GEN2_HDMI, 0,         /* module, unit */
        SVEN_event_type_register_io,    /* event type */
        SVEN_EV_RegIo32_Read,           /* event subtype */
        2, /* two parameters in event */
        0x08,       /* physical address + offset */
        (1<<20) | (1<<17) | (1<<1) | (1<<0)  /* value written */
        );

    SVEN_AUTO_TRACE(svenh,0,0);

    /* Send out a fake register read */
    sven_WriteEventVA_ulong( svenh,
        SVEN_module_GEN2_VCAP, 0,         /* module, unit */
        SVEN_event_type_register_io,    /* event type */
        SVEN_EV_RegIo32_Read,           /* event subtype */
        2, /* two parameters in event */
        0x154,       /* physical address + offset */
        0x11223344  /* value written */
        );

    SVEN_AUTO_TRACE(svenh,0,0);

    sven_WriteDebugString( svenh,
        SVEN_module_GEN2_HDMI,    /* module from "sven_unit.h" */
        0,                      /* unit */
        SVEN_DEBUGSTR_Checkpoint,
        "regio event test complete" );

    sven_WriteDebugStringEnd( svenh, 0, 0,
        SVEN_DEBUGSTR_Generic,
        "Really long string ends here." );

    SVEN_FUNC_EXIT(svenh,0,0);

    return( 0 );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        write data to the log
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_log_tracking_test(
    struct SVENApp*  app,
    const  char*     command )
{
    struct SVENHandle   *svenh = app->svenh;

    SVEN_FUNC_ENTER(svenh,0,0);

    /* Send out a fake register read */
    sven_WriteEventVA_ulong( svenh,
        SVEN_module_GEN2_HDMI, 0,         /* module, unit */
        SVEN_event_type_register_io,    /* event type */
        SVEN_EV_RegIo32_Read,           /* event subtype */
        2,                              /* two parameters in event */
        0x08,                                /* FAKE: ROFF_HGSR */
        (1<<20) | (1<<17) | (1<<1) | (1<<0)  /* FAKE: value Read */
        );

    /* Send out a fake register read */
    sven_WriteEventVA_ulong( svenh,
        SVEN_module_GEN2_HDMI, 0,         /* module, unit */
        SVEN_event_type_register_io,    /* event type */
        SVEN_EV_RegIo32_Read,           /* event subtype */
        2,                              /* two parameters in event */
        0x08,                           /* FAKE: ROFF_HGSR */
        (1<<1) | (1<<0)                 /* FAKE: value Read */
        );

    /* Send out a fake register read */
    sven_WriteEventVA_ulong( svenh,
        SVEN_module_GEN2_HDMI, 0,         /* module, unit */
        SVEN_event_type_register_io,    /* event type */
        SVEN_EV_RegIo32_Write,          /* event subtype */
        2,                              /* two parameters in event */
        0x00,                           /* FAKE: ROFF_HGCR */
        (1<<25) | (2<<15) | (1<<2)      /* FAKE: value Written */
        );

    /* Send out a fake register read */
    sven_WriteEventVA_ulong( svenh,
        SVEN_module_GEN2_HDMI, 0,         /* module, unit */
        SVEN_event_type_register_io,    /* event type */
        SVEN_EV_RegIo32_Write,          /* event subtype */
        2,                              /* two parameters in event */
        0x00,                           /* FAKE: ROFF_HGCR */
        (1<<25) | (2<<15) | (1<<2) | (1<<1) | (1<<0)  /* FAKE: value Written */
        );

    SVEN_FUNC_EXIT(svenh,0,0);

    return( 0 );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        reset command
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_reset( struct SVENApp* app, const char* command )
{
    struct _SVENHeader *hdr;
    int                 i;
    hdr = app->hdr;

    /* Dump circular buffers */
    for ( i = 0; i < hdr->svh_circbuffer_count; i++ )
    {
        /* reset this */
        hdr->buffers[i].svc_pos = 0;
    }

    return( 0 );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        inject command (tbd)
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_inject( 
    struct SVENApp*  app, 
    const  char*     command )
{
    int                 err = 0;

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        quit command - exit the app
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_quit( 
    struct SVENApp*  app, 
    const  char*     command )
{
    app->quit_requested = 1;
    return(0);
}
////////////////////////////////////////////////////////////////////////////////
/// @brief        sleep command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_sleep( struct SVENApp* app, const char* command )
{
    sleep(1);
    return(0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        pause command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_pause( struct SVENApp* app, const char* command )
{
    svenlog_Pause( app->svenlog );
    return(0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        run command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_run( struct SVENApp* app, const char* command )
{
    svenlog_Run( app->svenlog );
    return(0);
}


////////////////////////////////////////////////////////////////////////////////
/// @brief        Creates a thread process
/// @param[in]    arg      ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static void *svenapp_svenlog_threadproc( void* arg )
{
    struct SVENApp *app;
    //    int             err = 0;

    {
        int policy, pmin, pmax, pmean;
        struct sched_param param;

        app = (struct SVENApp *) arg;

        memset(&param,0,sizeof(param));
        policy = SCHED_RR;
        pmin = sched_get_priority_min(policy);
        pmax = sched_get_priority_max(policy);
        pmean = (pmin + pmax) / 2;

        pthread_setschedparam( app->svenlog_pthread, policy, &param);
    }


    //! Cancel type set to ASYNC. Default is DEFERRED, this means the thread can be cancelled at anytime,
    //! not at a cancellation point.
    pthread_setcanceltype( PTHREAD_CANCEL_ASYNCHRONOUS,NULL );//! \todo abort if this fn returns an error

    while ( ! app->svenlog_pthread_quit_request )
    {
        svenlog_CaptureRealTimeEvents_Locally( app->svenlog );

        usleep( 8 * 1000 ); /* 8 milliseconds */
    }

    return(NULL);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        go command 
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_go( struct SVENApp* app, const char* command )
{
    int             err = 0;

    if ( !app->svenlog_pthread )
    {
        pthread_attr_init( &app->svenlog_pthread_attr );

        //NPTL (2.6 kernel thread library) requires us to set this.
        pthread_attr_setinheritsched(
            &app->svenlog_pthread_attr,
            PTHREAD_EXPLICIT_SCHED);

        if ( ! (err = pthread_create(
            &app->svenlog_pthread,
            &app->svenlog_pthread_attr,
            svenapp_svenlog_threadproc,
            app ) ) )
        {
            printf("svenlog_thread_created\n");
        }
    }
    else
    {
        printf("svenlog thread already running\n");
    }

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        monitor and print all incoming messages.
/// @param[in]    app      ptr
/// @param[in]    command  ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_monitor(
    struct SVENApp*  app,
    const  char*     command )
{
    int                 err = 0;
    struct SVENEvent    ev;
    static char         revstr[1024];

    /* Launch the thread */
    sven_cmd_go( app, command );
    
    /* Seek last thirty */
    svenlog_RewindLocalEventReader( app->svenlog, 0 );

    while ( 1 )
    {
        while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
        {
            if ( ev.se_et.et_module || ev.se_et.et_type )
            {
                svenlog_GetEventTextString( app->svenlog, &ev, revstr );
                printf( " t:%08x %s\n", ev.se_timestamp, revstr );
            }
        }

        usleep(4000);
    }

    return( err );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Lookup a register string
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_lookup( struct SVENApp* app, const char* command )
{
    int                             num_tokens;

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 1 )
    {
        const struct ModuleReverseDefs *mrd;
        const struct EAS_Register      *reg;
        const struct EAS_RegBits       *bits;
        unsigned int                    offset;

        mrd = NULL;
        reg = NULL;
        bits = NULL;

        if ( sven_reverse_Lookup(
            app->cparse.token[1].token_str,
            &mrd, &reg, &bits, &offset ) )
        {
            if ( NULL != mrd )
            {
                printf("MRD:%d \"%s\" siz:%08x\n",
                    (int) mrd->mrd_module,
                    mrd->mrd_name,
                    (int) mrd->mrd_size );

                if ( NULL != reg )
                {
                    printf("REG:%08x \"%s\" - \"%s\" \n",
                        reg->reg_offset,
                        reg->reg_name,
                        (NULL != reg->reg_comment) ? reg->reg_comment : "" );

                    if ( NULL != bits )
                    {
                        printf("BITS [%d..%d] \"%s\" - \"%s\" \n",
                            bits->regbits_lsb_pos + bits->regbits_width,
                            bits->regbits_lsb_pos,
                            bits->regbits_name,
                            (NULL != bits->regbits_comment) ? bits->regbits_comment : "" );
                    }
                    else printf( "Lookup:BITS Not Found, offset=%08x\n", offset );
                }
                else printf( "Lookup:REG Not Found, offset=%08x\n", offset );
            }
            else printf( "Lookup:MRD Not Found, offset=%08x\n", offset );
        }
        else printf( "Lookup failed\n" );
    }
    
    return(num_tokens);
}


////////////////////////////////////////////////////////////////////////////////
/// @brief        parse the template filter
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_parse_template_filter_command(
    struct SVENApp      *app,
    struct SVENEvent    *ev,
    struct SVENEvent    *mask,
    int                  start_token )
{
    int                              i,num_tokens;
    const struct ModuleReverseDefs  *module;
    const struct EventTypeReverse   *event;
    const struct EventSubtypeReverse*subevent;
    int                              err = 0;

    /* Pre-init */
    module = NULL;
    event = NULL;
    subevent = NULL;
    
    /* How many tokens are there */
    num_tokens = app->cparse.num_tokens;
    i = start_token;

    /** Event Descriptions are parsed as TUPLES
     *
     *  e.g.  "MODULE VR_HDMI UNIT 0 EVENT register_io SUBTYPE Write32"
     *
     *  TUPLE TABLE
     *
     *  MODULE          VR_MCH, VR_GPU, VR_MPG2VD, etc or "N"
     *  UNIT            0,1,2,....
     *  EVENT           trigger, debug_str, register_io, port_io, module_event
     *  SUBTYPE         (e.g. for register_io), Read32, Write32, SetMasked32, ...
     *
     *
     *
     */
    for ( i = start_token; i < (num_tokens-1); i += 2 )
    {
        if ( !strcasecmp(app->cparse.token[i].token_str, "MODULE") )
        {
            if( NULL != (module = svenreverse_GetModuleTables_ByName(app->cparse.token[i+1].token_str)) )
            {
                ev->se_et.et_module = module->mrd_module;
                mask->se_et.et_module = -1;
            }
            else if ( '?' == app->cparse.token[i+1].token_str[0] )
            {
                sven_cmd_list_modules( app, "" );
                err |= (1<<0);
            }
            else
            {
                ev->se_et.et_module = app->cparse.token[i+1].token_int_value;
                mask->se_et.et_module = -1;
            }
        }
        else if ( !strcasecmp(app->cparse.token[i].token_str, "UNIT") )
        {
            ev->se_et.et_unit = app->cparse.token[i+1].token_int_value;
            mask->se_et.et_unit = -1;
        }
        else if( !strcasecmp(app->cparse.token[i].token_str, "EVENT") )
        {
            if ( NULL != (event = svenreverse_EVENT_TABLES_BY_NAME(app->cparse.token[i+1].token_str)) )
            {
                ev->se_et.et_type =  event->er_type;
                mask->se_et.et_type= -1;
            }
            else if ( '?' == app->cparse.token[i+1].token_str[0] )
            {
                int                 k;

                printf("event types [");

                for ( k = 0; k < SVEN_event_type_MAX; k++ )
                {
                    const struct EventTypeReverse   *etr;

                    if ( NULL != (etr = svenreverse_EVENT_TABLES_BY_NUM(k)) )
                    {
                        printf("%s ", etr->er_name );
                    }
                }

                printf("]\n");

                err |= (1<<1);
            }
            else
            {
                ev->se_et.et_type = app->cparse.token[i+1].token_int_value;
                mask->se_et.et_type = -1;
            }
        }
        else if ( !strcasecmp(app->cparse.token[i].token_str, "SUBTYPE" ) )
        {
            if ( NULL != event )
            {
                if ( SVEN_event_type_module_specific == event->er_type )
                {
                    if ( NULL != module )
                    {
                        const struct SVEN_Module_EventSpecific  *me;
                        int                                      print_subtypes = 0;

                        if ( '?' == app->cparse.token[i+1].token_str[0] )
                            print_subtypes = 1;

                        if ( NULL != (me = module->mrd_event_specific) )
                        {
                            while ( NULL != me->mes_name )
                            {
                                if ( !strcasecmp(
                                    app->cparse.token[i+1].token_str,
                                    me->mes_name) )
                                {
                                    break;
                                }

                                me++;
                            }

                            if ( NULL != me->mes_name )
                            {
                                ev->se_et.et_subtype = me->mes_subtype;
                                mask->se_et.et_subtype = -1;
                            }
                            else
                            {
                                /* non-zero string specified */
                                if ( 0 != app->cparse.token[i+1].token_int_value )
                                {
                                    ev->se_et.et_subtype = app->cparse.token[i+1].token_int_value;
                                    mask->se_et.et_subtype = -1;
                                }
                                else
                                {
                                    print_subtypes = 1;
                                }
                            }

                            if ( print_subtypes )
                            {
                                err |= (1<<2);

                                printf("subtypes: [");
                                me = module->mrd_event_specific;
                                while ( NULL != me->mes_name )
                                {
                                    printf("%s ", me->mes_name );
                                    me++;
                                }
                                printf("]\n");
                            }
                        }
                        else
                        {
                            /* non-zero string specified */
                            if ( 0 != app->cparse.token[i+1].token_int_value )
                            {
                                ev->se_et.et_subtype = app->cparse.token[i+1].token_int_value;
                                mask->se_et.et_subtype = -1;
                            }
                            else
                            {
                                printf("ERR: Must Specify Module first\n");
                                err |= (1<<4);
                            }
                        }
                    }
                    else
                    {
                        printf("ERR: Must Specify Module first\n");
                        err |= (1<<4);
                    }
                }
                else if ( NULL != event->er_subtypes )
                {
                    const struct EventSubtypeReverse    *se;
                    int                                  print_subtypes = 0;

                    se = event->er_subtypes;
                    
                    if ( '?' == app->cparse.token[i+1].token_str[0] )
                        print_subtypes = 1;
                    
                    while ( NULL != se->er_name )
                    {
                        if ( !strcasecmp(
                            app->cparse.token[i+1].token_str,
                            se->er_name) )
                        {
                            ev->se_et.et_subtype = se->er_subtype;
                            mask->se_et.et_subtype = -1;

                            subevent = se;  /* Keep this pointer */
                            break;
                        }

                        se++; /* next in table */
                    }
                    
                    /* None found */
                    if ( NULL == se->er_name )
                    {
                        /* Name not found, assume hardcoded */
                        if ( app->cparse.token[i+1].token_int_value ||
                             ('0' == app->cparse.token[i+1].token_str[0]) )
                        {
                            ev->se_et.et_subtype = app->cparse.token[i+1].token_int_value;
                            mask->se_et.et_subtype = -1;
                        }
                        else
                        {
                            print_subtypes = 1;
                        }
                    }
                
                    if ( print_subtypes )
                    {
                        err |= (1<<2);
                        se = event->er_subtypes;
                        
                        printf("subtypes: [");
                        while ( NULL != se->er_name )
                        {
                            printf("%s ", se->er_name );
                            se++; /* next in table */
                        }
                        printf("]\n");
                    }
                }
                else
                {
                    ev->se_et.et_subtype = app->cparse.token[i+1].token_int_value;
                    mask->se_et.et_subtype = -1;
                }
            }
            else
            {
                printf("ERR: Must Specify Event Type first\n");
                err |= (1<<4);
            }
        }
        else
        {
            printf("Unknown tuple type \"%s\"\n", app->cparse.token[i].token_str );
            err |= (1<<5);
        }
    }

#if ( 6 == SVEN_EVENT_PAYLOAD_NUM_UINTS )
    if ( (0 == ((int *)mask)[0]) &&
         (0 == ((int *)mask)[1]) &&
         (0 == ((int *)mask)[2]) &&
         (0 == ((int *)mask)[3]) &&
         (0 == ((int *)mask)[4]) &&
         (0 == ((int *)mask)[5]) &&
         (0 == ((int *)mask)[6]) &&
         (0 == ((int *)mask)[7]) )
    {
        err = 1;
    }
#else
    _TODO_FIX_TEMPLATE_PARSER_FUNCTION_;
#endif

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        trigger command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
/// @brief        trigger command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_trigger( struct SVENApp* app, const char* command )
{
    int                     err = 0;
    struct SVENEvent        ev, mask;

    /*Blanks for Now Will Fill in as we go along*/
    memset( &ev, 0, sizeof(ev) );
    memset( &mask, 0, sizeof(mask) );

    cparse_parse_command( &app->cparse, command );

    if ( app->cparse.num_tokens > 1 )
    {
        if ( ! sven_parse_template_filter_command( app, &ev, &mask, 1 ) )
        {
            #if 1
            int                     i;
            printf("Adding Trigger:\n" );
            printf(" EV: " );
            for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
                printf("%08x ", ((unsigned int *)&ev)[i] );
            }
            printf("\n");
            printf(" MSK:" );
            for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
                printf("%08x ", ((unsigned int *)&mask)[i] );
            }
            printf("\n");
            #endif

            svenlog_add_template_trigger(app->svenlog, &mask, &ev );
        }
    }
    else
    {
        printf("Usage: trigger <event specification>\n");
    }

    return (err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        filter command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_list_modules( struct SVENApp* app, const char* command )
{
    int                 module;

    for ( module = 0; module < SVEN_module_MAX; module++ )
    {
        const struct ModuleReverseDefs  *mrd;

        if ( NULL != (mrd = svenreverse_GetModuleTables(module)) )
        {
            if ( NULL != mrd->mrd_name )
            {
                printf( "Module %2d: %-12s - \"%s\"\n",
                    mrd->mrd_module, mrd->mrd_name,
                    (NULL == mrd->mrd_comment) ? "(no comment)" : mrd->mrd_comment );
            }
        }
    }
    return(0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Select time Display mode
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_time( struct SVENApp* app, const char* command )
{
    int         num_tokens;
    int         print_help = 0;

    num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 1 )
    {
        if ( !strcasecmp( "default", app->cparse.token[1].token_str ) )
        {
            app->time_display_mode = 0;
        }
        else if ( !strcasecmp( "delta", app->cparse.token[1].token_str ) )
        {
            app->time_display_mode = 1;
        }
        else if ( !strcasecmp( "tminus", app->cparse.token[1].token_str ) )
        {
            app->time_display_mode = 2;
        }
        else if ( !strcasecmp( "help", app->cparse.token[1].token_str ) )
        {
            print_help = 1;
        }
        else
        {
            app->time_display_mode = app->cparse.token[1].token_int_value;;
        }

        printf("time display mode is now %d\n", app->time_display_mode );
    }
    else
    {
        print_help = 1;
    }

    if ( print_help )
    {
        const char      *c;

        c = app->cparse.token[0].token_str;

        printf( "Usage %s [default|delta|tminus|<num>]\n", c );
        printf( "      %s default - display regular timestamps\n"
                "      %s delta   - display time since previous timestamp, in microseconds\n"
                "      %s tminus  - display time in t-minus trigger time\n"
                "      %s <num>   - set other time mode by number\n",c,c,c,c );
    }


    return (0);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        peek command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_decode( struct SVENApp* app, const char* command )
{
	int                 num_tokens = 0;
	unsigned int        err = 0;

    /* Usage:  decode UNIT offset value [prev_value] */
    
	num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 3 )
    {
        const struct ModuleReverseDefs *mrd;
        const struct EAS_Register      *reg;
        const struct EAS_RegBits       *bits;
        unsigned int                    offset;

        mrd = NULL;
        reg = NULL;
        bits = NULL;

        if ( sven_reverse_Lookup( app->cparse.token[1].token_str, &mrd, &reg, &bits, &offset ) )
        {
            struct SVENEvent    ev;
            char                revstr[1024];

            _sven_initialize_event( &ev,
                (NULL != mrd) ? mrd->mrd_module : offset, 0,
                SVEN_event_type_register_io,
                SVEN_EV_RegIo32_Read );

            ev.u.se_reg.phys_addr   = app->cparse.token[2].token_int_value;
            ev.u.se_reg.value       = app->cparse.token[3].token_int_value;
            ev.u.se_reg.mask        = 0;
            if ( num_tokens > 4 )
                ev.u.se_reg.log_prev  = app->cparse.token[4].token_int_value;
            else
                ev.u.se_reg.log_prev  = 0x00000000;

            sven_reverse_GetEventTextString( revstr, NULL, &ev );

            printf("%s\n", revstr );
        }
    }
    else
    {
    }    

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        peek command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_peek( struct SVENApp* app, const char* command )
{
	int                 num_tokens = 0;
	unsigned int        err = 0;

	num_tokens = cparse_parse_command( &app->cparse, command );

    if ( num_tokens > 1 )
    {
        const struct ModuleReverseDefs *mrd;
        const struct EAS_Register      *reg;
        const struct EAS_RegBits       *bits;
        unsigned int                    offset;

        mrd = NULL;
        reg = NULL;
        bits = NULL;

        if ( sven_reverse_Lookup( app->cparse.token[1].token_str, &mrd, &reg, &bits, &offset ) )
        {
            if ( NULL != mrd )
            {
                printf("MRD:%d \"%s\" siz:%08x\n",
                    (int) mrd->mrd_module,
                    mrd->mrd_name,
                    (int) mrd->mrd_size );

                if ( NULL != reg )
                {
                    unsigned int            value;

                    //value = devh_ReadReg32( devh, reg->reg_offset );
                    value = 0x12345678;

                    printf("REG:%08x = %08x \"%s\" - \"%s\"\n",
                        reg->reg_offset, value,
                        reg->reg_name,
                        (NULL != reg->reg_comment) ? reg->reg_comment : "" );

                    if ( NULL != bits )
                    {
                        printf(" BITS [%d..%d] = %x ; \"%s\" - \"%s\"\n",
                            bits->regbits_lsb_pos + bits->regbits_width - 1,
                            bits->regbits_lsb_pos,
                            (value >> bits->regbits_lsb_pos) &
                                ((1 << bits->regbits_width)-1),
                            bits->regbits_name,
                            (NULL != bits->regbits_comment) ? bits->regbits_comment : "" );
                    }
                    else if ( NULL != (bits = reg->reg_bits) )
                    {
                        // PRINT ALL BITS for this Register
                    #if 0
                        while ( bits->regbits_name )
                        {
						    printf( "[%s=%X] ", bits->regbits_name,
                                (value >> bits->regbits_lsb_pos) & 
                                    ((1 << bits->regbits_width)-1) );

                            bits++;
                        }
                        printf("\n");
                    #else
                        while ( bits->regbits_name )
                        {
						    printf( " /* mask 0x%08x bits[%2d..%2d] */ %s = 0x%X \n",
                                ((1 << bits->regbits_width)-1) << bits->regbits_lsb_pos,
                                bits->regbits_lsb_pos + bits->regbits_width - 1,
                                bits->regbits_lsb_pos,
                                bits->regbits_name,
                                 (value >> bits->regbits_lsb_pos) & 
                                    ((1 << bits->regbits_width)-1) );

                            bits++;
                        }
                    #endif
                    }
                }
                else if ( NULL != (reg = mrd->mrd_regdefs) )
                {
                    // PRINT ALL REGISTERS FOR THIS MODULE
                    while ( reg->reg_name )
                    {
                        unsigned int            value;

                        //value = devh_ReadReg32( devh, reg->reg_offset );
                        value = 0x12345678;

                        printf("REG:%08x = %08x \"%s\" - \"%s\" \n",
                            reg->reg_offset, value,
                            reg->reg_name,
                            (NULL != reg->reg_comment) ? reg->reg_comment : "" );

                        reg++;
                    }
                }
            } else printf( "Lookup:MRD Not Found\n" );
        } else printf("\nPeek of \"%s\" not found\n", app->cparse.token[1].token_str );
    }
    else
    {
    }    

    return(err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        filter command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_filter( struct SVENApp* app, const char* command )
{
    int                     err = 0;
    int                     filter_mode = 0;       /* -1 = accept, +1 = reject */

    cparse_parse_command( &app->cparse, command );

    /* e.g. "filter accept ..... " */
    if ( app->cparse.num_tokens > 2 )
    {
        struct SVENEvent        ev, mask;

        if( !strcasecmp(app->cparse.token[1].token_str, "REJECT") )
        {
            if( ! strcasecmp(app->cparse.token[2].token_str, "ALL") )
            {
                svenlog_set_filter_default( app->svenlog, -1 );
                printf("SVENLog default rejects all events\n" );
                return(err); /* EXIT NOW */
            }
            filter_mode = -1;
        }
        else if( !strcasecmp(app->cparse.token[1].token_str, "ACCEPT") )
        {
            if( ! strcasecmp(app->cparse.token[2].token_str, "ALL") )
            {
                svenlog_set_filter_default( app->svenlog, 0 );
                printf("SVENLog default accepts all events\n" );
                return(err); /* EXIT NOW */
            }
            filter_mode = 1;
        }

        /*Blanks for Now Will Fill in as we go along*/
        memset( &ev, 0, sizeof(ev) );
        memset( &mask, 0, sizeof(mask) );

        if ( ! sven_parse_template_filter_command( app, &ev, &mask, 2 ) )
        {
            #if 1
            int                     i;
            printf("Adding Filter:\n" );
            printf(" EV: " );
            for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
                printf("%08x ", ((unsigned int *)&ev)[i] );
            }
            printf("\n");
            printf(" MSK:" );
            for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
                printf("%08x ", ((unsigned int *)&mask)[i] );
            }
            printf("\n");
            #endif

            svenlog_add_template_filter( app->svenlog, &mask, &ev, filter_mode );
        }
    }

    if ( 0 == filter_mode )
    {
        printf("ERR: usage filter [accept|reject] <event specification>\n");
    }

    return (err);
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        source command
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_source( struct SVENApp* app, const char* command )
{
    FILE        *old_fin;
    const char  *fn;
    int          err = 0;
    /* Save */
    old_fin = app->fin;
    fn = command;

    printf("passed to source%s", command);
    while ( *fn && (' ' != *fn) )  fn++;    /* Seek space */
    while ( *fn && (' ' == *fn) )  fn++;    /* Seend end of white space */

    if ( NULL != (app->fin = fopen( fn, "r" )) )
    {

        svenapp_source_main(app);
        app->quit_requested = 0;
    }
    else
    {
        printf("Could not Source File \"%s\"\n", fn );
    }

    /* Restore */
    app->fin = old_fin;

    return( err );
}

/* ===========================================================================*/
/* ===========================================================================*/

#define VALIDATE_MODULE     0x1ff
#define VALIDATE_UNIT       0x3

struct ValStats
{
    int             filter_events_caught;
    int             read_events_caught;
};

static int sven_validation_filter(
    struct SVENEvent    *ev,
    void                *userdata0,
    void                *userdata1 )
{
//    struct SVENApp      *app = (struct SVENApp *)userdata0;
    struct ValStats     *vs = (struct ValStats *)userdata1;

    if ( (VALIDATE_MODULE == ev->se_et.et_module) &&
         (VALIDATE_UNIT == ev->se_et.et_unit) )
    {
        vs->filter_events_caught++;
    }

    return( 0 );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        validate logic
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_validate( struct SVENApp* app, const char* command )
{
    int                      err = 0;
    struct SVENUserFilter   *uf;
    struct ValStats          vs;

    sven_cmd_go( app, "thread" );   /* force thread launch */

    memset( &vs ,0, sizeof(vs) );   /* clear the stats */

    if ( NULL != (uf = svenlog_add_user_filter( app->svenlog, sven_validation_filter, app, &vs )) )
    {
        int                 qnum,nqueues;
        struct SVENHandle   txh[4];
        struct SVENEvent    ev;

        memset( txh,0,sizeof(txh));

        nqueues = app->svenh->hdr->svh_circbuffer_count;

        if ( nqueues > 4 )
        {
            printf("ERR: Number of SVEN Event Queues is > 4 (%d)\n", nqueues );
            nqueues = 4;
            err = 1;
        }

        for ( qnum = 0; qnum < nqueues; qnum++ )
        {
            sven_attach_handle_to_queue( &txh[qnum], app->svenh->hdr, qnum );
        }
        
        while ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
        {
            /* drain the log */
        }

        memset( &ev,0,sizeof(ev) );
        ev.se_et.et_module = VALIDATE_MODULE;
        ev.se_et.et_unit = VALIDATE_UNIT;

        for ( qnum = 0; qnum < nqueues; qnum++ )
        {
            int                 i,nevents;
            int                 timeout;

            /* fill the queue 3/4 full */
            nevents = txh[qnum].event_pos_mask + 1;
            nevents = (nevents>>2) + (nevents>>1);  /* 1/2 + 1/4 of size */

            vs.filter_events_caught = 0;    /* Reset the #events caught by the filter */

            printf("generating %d events on q %d....", nevents, qnum );
            for ( i = 0; i < nevents; i++ )
            {
                ev.u.se_uint[0] = qnum;
                ev.u.se_uint[1] = i;
                ev.u.se_uint[2] = nevents;
                sven_write_event( &txh[qnum], &ev );
            }

            timeout = 0;

            while ( vs.filter_events_caught < nevents )
            {
                printf("%d: arrival at filter...", timeout );
                sleep(1);
                if ( ++timeout > 5 )
                {
                    printf("\nERR: not all events arrived at filter (expected %d, got %d)\n",
                        nevents, vs.filter_events_caught  );
                    err = 2;
                    break;
                }
            }
            if ( vs.filter_events_caught == nevents )   printf("OK ");

            printf( "arrival at local buffer..." );
            i = 0;
            while ( i < nevents )
            {
                if ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
                {
                    if ( (VALIDATE_MODULE == ev.se_et.et_module) &&
                         (VALIDATE_UNIT == ev.se_et.et_unit) )
                    {
                        i++;
                    }
                }
                else
                {
                    printf("\nERR: Not all local events available, failed at %d of %d\n", i, nevents );
                    err = 2;
                    break;
                }
            }
            if ( !err && (i == nevents) )
            {
                /* VALIDATE PASS */
                printf("PASS\n");
            }
        }

        /* OVER-FILL one of the smaller queues */
        qnum = 1;
        {
            int                 i,nevents;
            int                 timeout;

            /* fill the queue 3/4 full */
            nevents = txh[qnum].event_pos_mask + 1;
            nevents = nevents + (nevents>>2);       /* OVERFILL by 1/4 !!!!!*/

            vs.filter_events_caught = 0;    /* Reset the #events caught by the filter */

            printf("OVERFILL %d events on q %d, size\n", nevents, qnum );
            for ( i = 0; i < nevents; i++ )
            {
                ev.u.se_uint[0] = qnum;
                ev.u.se_uint[1] = i;
                ev.u.se_uint[2] = nevents;
                sven_write_event( &txh[qnum], &ev );
            }

            timeout = 0;
            while ( vs.filter_events_caught < nevents )
            {
                printf("%d: check for arrival at filter\n", timeout );
                sleep(1);
                if ( ++timeout > 1 )
                {
                    printf("ERR: not all events arrived at filter (expected %d, got %d)\n",
                        nevents, vs.filter_events_caught  );
                    /* NOT AN ERROR bcause we "lapped" the SVENLOG Reader */
                    break;
                }
            }
            printf("OVERFILLED and caught %d events\n", vs.filter_events_caught );

            printf( "check for arrival at local buffer..." );
            i = 0;
            while ( i < vs.filter_events_caught )
            {
                if ( svenlog_ReadNextLocalEvent( app->svenlog, &ev ) )
                {
                    if ( (VALIDATE_MODULE == ev.se_et.et_module) &&
                         (VALIDATE_UNIT == ev.se_et.et_unit) )
                    {
                        i++;
                    }
                }
                else
                {
                    printf("\nERR: Not all local events available, failed at %d of %d\n", i, nevents );
                    err = 2;
                    break;
                }
            }
            if ( !err && (i == vs.filter_events_caught) )
            {
                /* VALIDATE PASS */
                printf("PASS\n");
            }
        }
        
        svenlog_remove_user_filter( app->svenlog, uf );
    } else err = 1;
    
    return( err );
}

/* ===========================================================================*/
/* ===========================================================================*/

////////////////////////////////////////////////////////////////////////////////
/// Static Global Structure holds sven lexicon comands and ptrs to functions
////////////////////////////////////////////////////////////////////////////////
static struct app_command_dispatcher g_svenapp_commands[] =
{
    { "quit",           "Quit SVEN console",
        sven_cmd_quit },
    { "help",           "print help with commands",
        sven_cmd_help },
    { "sleep",          "sleep for N seconds",
        sven_cmd_sleep },
    { "pause",          "pause capture",
        sven_cmd_pause },
    { "run",            "restart capture",
        sven_cmd_run },
    { "all",            "restart capture",
        sven_cmd_all },
    { "monitor",        "Monitor (print) all events coming into the nexus",
        sven_cmd_monitor },
    { "hdr",            "print SVEN shared memory header info",
        sven_cmd_print_header },
    { "dump",           "dump (up to) last 50 events",
        sven_cmd_dump },
    { "hexdump",        "dump (in hex) last 50 events",
        sven_cmd_hexdump },
    { "logwrite",       "demonstrate log write",
        sven_cmd_logwrite },
    { "regiotest",       "Write Register IO Tracking Test Log entries",
        sven_cmd_log_tracking_test },
    { "reset",          "reset shared memory areas (DANGEROUS)",
        sven_cmd_reset },
    { "inject",         "Inject Parameters",
        sven_cmd_inject },
    { "modules",           "List Supported Modules",
        sven_cmd_list_modules },
    { "decode",           "Decode MODULE reg_offset reg_value [prev_value] to text",
        sven_cmd_decode },
    { "peek",         "Peek at HW Register Values",
        sven_cmd_peek },
    { "source",         "Execute additional commands in file",
        sven_cmd_source },
    { "thread",         "launch svenlog monitor thread",
        sven_cmd_go },
    { "lookup",            "lookup a module, register, bitfield",
        sven_cmd_lookup },
    { "trigger",           "triggers on a specific event",
        sven_cmd_trigger},
    { "time",         "Select time display mode",
        sven_cmd_time },
    { "testparser",         "See how the debug console parses the command line",
        sven_cmd_testparser},
    { "filter",           "Filters SVENLog based on a Mask provided",
        sven_cmd_filter},
    { "validate",     "Validate Log Writing Code",
        sven_cmd_validate},
    { "save",         "Save the (binary) SVENLOG to a file",
        sven_cmd_save},
    { "load",         "Load the (binary) SVENLOG from a file",
        sven_cmd_load},
    {NULL, NULL, NULL}    /* NULL Terminator */
};


////////////////////////////////////////////////////////////////////////////////
/// @brief        Function to convert sven lexicon into function calls
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
int svenapp_dispatch_command(
    struct SVENApp*  app,
    const  char*     command )
{
    struct app_command_dispatcher  *cd = g_svenapp_commands;
    int         index = 0;
    char        temp_command[1024];

    while ( command[index] && (' ' != command[index]) )
    {
        temp_command[index] = command[index];
        index++;
    }
    temp_command[index] = '\0';

    while ( NULL != cd->cmdname )
    {
        if ( !strcasecmp( cd->cmdname, temp_command ) )
        {
            return( (*cd->dispatch)( app, command ) );
        }
        cd++;
    }

    if ( index > 0 )    /* something besides just enter */
    {
        printf("Unknown command: \"%s\"\n", temp_command );
    }

    return( 0 );
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Main loop
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
int svenapp_source_main(
    struct SVENApp*  app )
{
    /* accept 2k commands */
    static char     g_command[2048];
    int             err = 0;

    if ( app->interactive_mode ) printf("sven> ");

    while ( fgets( g_command, sizeof(g_command), app->fin ) )
    {
        int         len;
        /* newline characters were causing problems in the parser
        * turn them to null terminators
        */
        len = strlen(g_command);

        if ( (len > 0) &&
            ( ('\n' == g_command[len-1]) ||
            ('\r' == g_command[len-1]) ) )
        {
            g_command[len-1] = '\0';
        }
        if ( (len > 1) &&
            ( ('\n' == g_command[len-2]) ||
            ('\r' == g_command[len-2]) ) )
        {
            g_command[len-2] = '\0';
        }

        err = svenapp_dispatch_command( app, g_command );

        if ( app->quit_requested )
        {
            break;
        }

        if ( app->interactive_mode ) printf("sven> ");
    }
    return( err );
}


////////////////////////////////////////////////////////////////////////////////
/// @brief        Help Command - Displays Help
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static int sven_cmd_help( struct SVENApp* app, const char* command )
{
    struct app_command_dispatcher  *cd = g_svenapp_commands;

    while ( NULL != cd->cmdname )
    {
        printf("%15s - %s\n", cd->cmdname, cd->arghelp );

        cd++;
    }
    return( 0 );
}


////////////////////////////////////////////////////////////////////////////////
/// @brief        Main entry into sven app
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
int main(
    int     argc,
    char*   argv[] )
{
    int         err = 0;

    struct SVENApp*  app;

    if ( NULL != (app = svenapp_Create( NULL )) )
    {
        /* default input filhandle is stdin */
        app->fin = stdin;

        // Shut's off NULL EVENTS, for debugging */
        //svenlog_add_blacklist_filter( app->svenlog, 4, 0xffffffff, 0x00000000 );

        /* sven source filename */
        if ( (argc > 2) && !strcasecmp( "source", argv[1] ) )
        {
            /* sven command script becomes input file  */
            if ( NULL != (app->fin = fopen( argv[2], "r" )) )
            {
                err = svenapp_source_main( app );
            }
            else
            {
                printf("Could not open \"%s\"\n", argv[2] );
            }
        }
        else if ( argc > 1 )  /* sven command..... */
        {
            int             i;
            char            *cp;
            static char      app_command[4096];

            /* SVEN Command takes pre-tokenized command string, rebuild
            * the long command string before sending to dispatch_command
            */
            cp = app_command;
            for ( i = 1; i < argc; i++ )
            {
                cp += sprintf( cp, "%s ", argv[i] );
            }

            svenapp_dispatch_command( app, app_command );
        }
        else /* just plain old sven */
        {
            printf( "SVEN Sandbox: Built " __DATE__ "\n"
                "Copyright 2006 Intel Corporation All Rights Reserved\n"
                "type help for a list of commands or quit\n" );

            printf("(long):%d (int):%d (short):%d (char):%d\n", (int)sizeof(long), (int)sizeof(int), (int)sizeof(short), (int)sizeof(char) );

            sven_cmd_print_header( app, "hdr" );

            /* inform we are in interactive mode */
            app->interactive_mode = 1;
            err = svenapp_source_main( app );
        }

        svenapp_Delete( app );
    }
    else 
    {
        printf("err: svenapp create failed\n");
        err = 2;
    }

    return( err );
}
