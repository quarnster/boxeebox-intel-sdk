/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
//#include <rfb/rfb.h>
#define MAX_CHAR_BUFFER_LENGTH 100
#define TRUE 1
#define FALSE 0
#define Bool unsigned char

#include "omarlib.h"
#include "htuple.h"

#include <ctype.h>

#define PARSER_MAX_LEN   (1024*4)

/* Add "spreadsheet parser" code, which calls wavesource_hw_SetSignalName()
 */
     void SetHWSignalNames(struct WaveformSource   *pWs,char* SignalListFileName,char delimiter)
    {
        FILE* fp;

   static char str[PARSER_MAX_LEN   ];
   static char temp[PARSER_MAX_LEN   ];
   static char signame[PARSER_MAX_LEN   ];

             char * ptr=NULL,*oldptr=NULL;
             Bool bSetSignalName=FALSE;
             int count=0,omarid=0,bitpos=0;

             fp=fopen(SignalListFileName,"rt");
             if(!fp)
               {
                   fprintf(stderr,"\nError reading file: %s\n",strerror(errno));
               }
               else
               {
                    while(!feof(fp))
                   {
                       fgets( str,PARSER_MAX_LEN,fp);

                       ptr=strchr(str,(delimiter));
                       oldptr=ptr;
                       while (ptr!=NULL)
                       {
                           ptr=strchr(ptr+1,(delimiter));
                           if(ptr==(oldptr+1))
                           {
                              count++;
                           }
                           else
                           {
                               if(NULL==ptr)
                               {
                                    count++;
                                    strncpy(temp,oldptr+1,PARSER_MAX_LEN);

                               }
                               else
                               {
                                    strncpy(temp,oldptr+1,ptr-oldptr-1);
                                    temp[ptr-oldptr-1]='\0';
                                    count++;
                               }

                           }    /* if(ptr!=(oldptr+1)) */


                           switch(count)
                              {
                                   case 5:
                                        strcpy(signame,temp);
                                        break;
                                   case 8:
                                        if(isdigit(temp[0]))
                                        {
                                        omarid=atoi(temp);
                                        }
                                        break;
                                   case 9:
                                        if(isdigit(temp[0]))
                                        {
                                            bSetSignalName=TRUE;
                                            bitpos=atoi(temp);
                                        }
                                        else
                                        {
                                            omarid=0;
                                        }
                                        break;
                                   default:
                                           break;

                              } /* switch(count) */
                           oldptr=ptr;
                           temp[0]='\0';
                       } /* while (ptr!=NULL) */

                    if(bSetSignalName)
                    {
                        wavesource_Set_HW_SignalName(pWs,(omarid<<4)+bitpos,signame);
                        bSetSignalName=FALSE;
                    }

                       count=0;bitpos=0;

                   }    /* while(!feof(fp)) */

                   wavesource_DetectBuses( pWs ); //TODO FIX THIS

               fclose(fp);
             }  /* NULL!=fp */

    }   /* SetSignalNames() */


    /*****************************************************************
        Function that loads the htuple configuration file
    ******************************************************************/

void LoadConfigFile(const char *filename)
{
   FILE *fp;

   if ( NULL != (fp = fopen(filename, "r")) )
   {
      char            *txt;
      long             txtlen;

      fseek( fp, 0, SEEK_END );
      txtlen = ftell(fp);
      rewind(fp);

      if ( NULL != (txt = malloc(txtlen+1)) )
      {
         if ( txtlen == (long) fread( txt, 1, txtlen, fp ) )
         {
            /* unnecessary null term */ txt[txtlen] = '\0';
            htuple_parse_config_string( 0, txt, txtlen );
         }
         free(txt);
      }   /* if ( NULL != (txt = malloc(txtlen+1)) ) */

      fclose(fp);
   } /* if ( NULL != (fp = fopen(filename, "r")) ) */

}   /* LoadConfigFile() */

    /*****************************************************************
        Function that returns the configuration file parameters
    ******************************************************************/
#if 0
     void HandleConfigFile()
    {
        unsigned int testdir_id=0;
        int                  err = 0;

       if ( 0 != (testdir_id = htuple_find_child(0,g_testdir_location,strlen(g_testdir_location))) )
        {
             unsigned int         child;
            if ( 0 != (child = htuple_first_child( testdir_id )) )
            {
                do
                {
                    const char          *test;

                    if ( 0 == (err = htuple_get_str_value( child, "type", 4, &test)) )
                    {
                        printf("\"%s\" ", test );

                        if ( ! strcmp( test,"omar") )
                        {
                            int Block;
                            int Pin;
                            char* label;

                            htuple_get_int_value(child,"block",5,&Block);
                            printf("Block %d ",Block);
                            htuple_get_int_value(child,"pin",3,&Pin);
                            printf("Pin %d ",Pin);
                            htuple_get_str_value(child,"label",5,&label);
                            printf("%s \n",label);
                       //   wavesource_Set_SignalName(pWs,(Block<<4)+Pin,label);

                        }
                        else if ( ! strcmp(test,"sven") )
                        {

                        char *module;
                        int unit;
                        char *EventType,*EventSubType;
                    #if 0
                            module        "VIDREND"                unit         0                event_type    "module_specific"                event_sub    "VSYNC_ISR"
                    #else
                        htuple_get_str_value(child,"module",6,&module);
                        htuple_get_int_value(child,"unit",4,&unit);
                        htuple_get_str_value(child,"event_type",10,&EventType);
                        htuple_get_str_value(child,"event_sub",9,&EventSubType);
                        printf("Module :%s Unit: %d Event Type: %s Event Subtype: %s\n",module,unit,EventType,EventSubType);

                    #endif
                        }

                        else
                        {
                            printf("Unknown Test \"%s\"\n", test );
                        }

                        printf("---------------------------------------------\n");
                    }
                    else
                    {
                        printf( " err %d: no \"test\" entry at id %d\n", err, child );
                       // verbose_printf( child, 3 ); /* recursive "pretty printer" */
                        break;
                    }

                    child = htuple_next_sibling(child);
                } while ( 0 != child );
            }
        }
        else printf("ERR: Could not find tests directory, \"%s\"\n", g_testdir_location );

    }   /* HandleConfigFile() */
#endif
