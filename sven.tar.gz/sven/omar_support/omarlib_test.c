/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2008 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef OMARLIB_H
#include "omarlib.h"
#endif

#ifndef SVEN_FILE_H
#include "sven_file.h"
#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>


//#include "ismd_core.h"

static const char *wave_shape_string_threechar[WSSV_MAX] = {
    "___",  //    WSSV_0,
    "---",  //    WSSV_1,
    "_--",  //    WSSV_0_to_1,
    "-__",  //    WSSV_1_to_0,
    "_-_",  //    WSSV_hi_pulse,
    "-_-",  //    WSSV_lo_pulse,
    "===",  //    WSSV_fast_pulse,
    "|__",  //    WSSV_tick,
    "???",  //    WSSV_ind,
    "===",  //    WSSV_hi_and_lo
    "=x=",  //    WSSV_cross
};
static const char *wave_shape_string_terse[WSSV_MAX] = {
    "__",  //    WSSV_0,
    "--",  //    WSSV_1,
    "_-",  //    WSSV_0_to_1,
    "-_",  //    WSSV_1_to_0,
    "^_",  //    WSSV_hi_pulse,
    "V-",  //    WSSV_lo_pulse,
    "==",  //    WSSV_fast_pulse,
    "|_",  //    WSSV_tick,
    "??",  //    WSSV_ind,
    "==",  //    WSSV_hi_and_lo
    "=x",  //    WSSV_cross
};
static const char *wave_shape_string[WSSV_MAX] = {
    "__ ",  //    WSSV_0,
    "-- ",  //    WSSV_1,
    "_- ",  //    WSSV_0_to_1,
    "-_ ",  //    WSSV_1_to_0,
    "^_ ",  //    WSSV_hi_pulse,
    "V- ",  //    WSSV_lo_pulse,
    "== ",  //    WSSV_fast_pulse,
    "|_ ",  //    WSSV_tick,
    "?? ",  //    WSSV_ind,
    "== ",  //    WSSV_hi_and_lo
    "=x ",  //    WSSV_cross
};

static void test_load_config_file( struct WaveformSource *ws, const char *filename )
{
    FILE        *fp;

    if ( NULL != (fp = fopen(filename, "r")) )
    {
        char            *txt;
        long             txtlen;

        fseek( fp, 0, SEEK_END );
        txtlen = ftell(fp);
        rewind(fp);
        if ( NULL != (txt = malloc(txtlen+1)) )
        {
            if ( txtlen == (long) fread( txt, 1, txtlen, fp ) )
            {
                /* unnecessary null term */ txt[txtlen] = '\0';

                wavesource_ParseConfig( ws, txt, txtlen );
            }

            free(txt);
        }

        fclose(fp);
    }
}

static int wavesource_scoreboard( struct WaveformSource *ws, int argc, char *argv[] )
{
}

/* signal */
#include <signal.h>
volatile int g_CtrlC_Flag = 0;
static void crtl_c_sig_handle( int signo )
{
    if ( SIGINT == signo )
    {
        /* Ignore all other Ctrl C signals */
        signal( SIGINT, SIG_IGN );
        g_CtrlC_Flag = signo;
    }
}


#ifndef SMD_INTERACTION
int main( int argc, char *argv[] )
{
   struct WaveformSource   *ws;
   const char              *omar_filename = "omar.bin";
   unsigned int             enable0 = 0;
   unsigned int             enable1 = 0;
   unsigned int             good_e0,good_e1;
   int                      capture_once = 0;
   int                      err = 0;

   if ( argc > 1 ) omar_filename = argv[1];
   if ( argc > 2 ) enable0 = strtoul(argv[2],NULL,0);
   if ( argc > 3 ) enable1 = strtoul(argv[3],NULL,0);

   good_e0 = good_e1 = 0;
   
   if ( enable0 | enable1 )
      capture_once = 1;

   if ( NULL != (ws = wavesource_Create(0,0,0)) )
   {
      int            enable_bit;
      long long      interval;

      wavesource_ParseConfig( ws, NULL, 0 );

      wavesource_GetHiResClockFreq( ws, &interval );
      interval /= 1000000; /* 1kHz */
      wavesource_SetCaptureInterval( ws, (unsigned int) interval );

      for ( enable_bit = 0; enable_bit < 64; enable_bit++ )
      {
         unsigned int      e0,e1;
         int               timeout;

         if ( capture_once )
         {
            e0 = enable0;
            e1 = enable1;
         }
         else
         {
            if ( enable_bit < 32 )
            {
               e0 = good_e0 | enable0 | (1<<enable_bit);
               e1 = good_e1 | enable1;
            }
            else
            {
               e0 = good_e0 | enable0;
               e1 = good_e1 | enable1 | (1<<(enable_bit-32));
            }
         }

         wavesource_SetProperty( ws, "enable.0", e0 );
         wavesource_SetProperty( ws, "enable.1", e1 );

         wavesource_StartCapture( ws );
         {
            int             pos,hdr;
            int             hpos;

            pos = 0;
            wavesource_GetProperty( ws, "capture.hdr", &hdr );
            wavesource_GetProperty( ws, "capture.pos", &pos );
            hpos = pos;
            printf("%2d: enable: 0x%08x-%08x hdr: %08x pos %08x :: \"%s\"\n", enable_bit, e1, e0, hdr, hpos, wavesource_GetGroupName(ws,enable_bit) );

            timeout = 10;
            while ( (hpos - pos) < 1024  )   /* capture at least one kbyte */
            {
               usleep(10000);
               wavesource_GetProperty( ws, "capture.hdr", &hdr );
               wavesource_GetProperty( ws, "capture.pos", &hpos );
               printf("%2d: enable: 0x%08x-%08x hdr: %08x pos %08x :: \"%s\"\n", enable_bit, e1, e0, hdr, hpos, wavesource_GetGroupName(ws,enable_bit) );

               if ( (hpos - pos) > 1024  )   /* capture at least one kbyte */
               {
                  good_e0 |= e0;
                  good_e1 |= e1;
               }

               if ( ! --timeout )   break;
            }
         }
         wavesource_StopCapture( ws );
         
         if ( capture_once )
         {
            /* command line specified specific masks to attempt */
            break;
         }
      }

      wavesource_Delete(ws);
   }

   printf("DONE: enable_1: 0x%08x enable_0: 0x%08x\n", good_e1, good_e0 );


   return(err);   
}

#else /* SMD INTERACTION */

/* gcc -g -m32 omarlib_cm.c omarlib_test.c -o test
 * gcc -g -m32 omarlib_test.c -L i686-linux-elf/ -L ../../i686-linux-elf/lib -lhtuple -losal -lpal -lsven -lomarwave -lismd_core -lpthread 
 * gcc -g -m32 -I ../../i686-linux-elf/include/ -I ../../i686-linux-elf/include/linux_user/ omarlib_test.c -L i686-linux-elf/ -L ../../i686-linux-elf/lib -lhtuple -losal -lpal -lsven -lomarwave -lismd_core -lpthread -o omarlib_test
 * gcc -g -m32 -I ../../i686-linux-elf/include/ -I ../../i686-linux-elf/include/linux_user/ omarlib_test.c -L i686-linux-elf/ -L ../../i686-linux-elf/lib -lhtuple -losal -lpal -lsven -lomarwave -lismd_core -lpthread -o omarlib_test
*/
int main( int argc, char *argv[] )
{
    int                          err = 0;
    ismd_result_t                res;
    struct WaveformSource       *ws;
    const char                  *omar_filename = "omar.bin";
    unsigned int                 zoom_is_out,zoom,num_shapes,capture_interval;
    ismd_buffer_handle_t         omar_bufh = 0;
    ismd_buffer_descriptor_t     omar_buf;
    ismd_physical_address_t      targ_offset;

    omar_buf.phys.base = 0x80000000;        /* host-visible physical address */
    targ_offset = 0x80000000;
    capture_interval = (2*2*2*2*3*3*5*5);    /* 3600 */


    #define OMAR_BUFSIZE    (1024*1024)

    
   return( verify_silicon( argc, argv ) );

    printf(
        "=================================================================\n"
        "=================================================================\n"
        "=================================================================\n"
        "=================================================================\n" );


#define OMAR_SLE_HACK
//#define OMAR_TEST_TRACES

#ifndef OMAR_TEST_TRACES
    /* Random seed (fake data uses rand() ) */
    if ( argc > 1 ) omar_filename = argv[1];
    if ( argc > 2 ) omar_buf.phys.base = strtol( argv[2], NULL, 0 );
    if ( argc > 3 ) targ_offset = strtol( argv[3], NULL, 0 );
    if ( argc > 4 ) capture_interval = strtol( argv[4], NULL, 0 );

    #ifdef OMAR_SLE_HACK
    omar_buf.virt.base = OS_MAP_IO_TO_MEM_NOCACHE(    /* Get view */
                omar_buf.phys.base,
                OMAR_BUFSIZE );
    if ( NULL == omar_buf.virt.base )
    {
        printf("failure: OS_MAP_IO_TO_MEM_NOCACHE(0x%08x,0x%08x);\n", omar_buf.phys.base, OMAR_BUFSIZE );
        //return(1);
    }
    omar_buf.phys.base -= targ_offset; /* convert OMAR-visible physical address */
                
    #else
    if ( 0 != (res = ismd_buffer_manager_init())) {
        printf("failure: ismd_buffer_manager_init(); err %08x\n", res );
        //return(1);
    }
    if ( 0 != (res = ismd_buffer_alloc(OMAR_BUFSIZE, &omar_bufh))) {
        printf("failure: ismd_buffer_alloc(%08x); err %08x\n", OMAR_BUFSIZE, res );
        //return(1);
    }
    if ( 0 != (res = ismd_buffer_read_desc(omar_bufh, &omar_buf))) {
        printf("failure: ismd_buffer_read_desc(%08x); err %08x\n", (int) omar_bufh, res );
        //return(1);
    }
    #endif
    
    printf("omar_buf %p phys.base = 0x%08x size = 0x%08x\n", omar_buf.virt.base, omar_buf.phys.base, OMAR_BUFSIZE );
#endif
    zoom_is_out = 1;
    zoom = 1;
    num_shapes = 40;

    /* Random seed (fake data uses rand() ) */
    if ( argc > 1 ) zoom_is_out = strtol( argv[1], NULL, 0 );
    if ( argc > 2 ) zoom = strtol( argv[2], NULL, 0 );
    if ( argc > 3 ) num_shapes = strtol( argv[3], NULL, 0 );
   
    if ( NULL != (ws = wavesource_Create( 0, 0, 0 ) ) )
    {
        unsigned int             sig,num_samps,num_sigs;

    #ifdef OMAR_TEST_TRACES
        int             sigs_displayed = 0;
        
        unsigned int    hw_interval;
        unsigned int    shape_interval;
        long long       duration,hclk;

        #define DEMO_TRACE_SHAPE_SIZE        1024
        static char     shapes[DEMO_TRACE_SHAPE_SIZE];

        wavesource_PrepareFakeData( ws );

        test_load_config_file( ws, "traces.hcfg" );
        wavesource_LoadTraces( ws, "sven-omar-gui.waveform.traces" );

        num_sigs  = wavesource_GetNumTraces( ws );

        wavesource_GetHiResClockFreq( ws, &hclk );
        duration  = wavesource_GetDuration( ws );
        hw_interval = wavesource_GetCaptureInterval( ws );

        if ( zoom_is_out )
        {
            shape_interval = hw_interval * zoom;
        }
        else
        {
            //while ( 0 != (hw_interval % zoom) ) /* WARNING: TODO: CHOOSE_GOOD_HW_INTERVALS */
            //    zoom++;

            shape_interval = hw_interval / zoom;
        }

        /* clamp "duration" to correct number of shapes */
        //num_shapes = duration / shape_interval;
        if ( num_shapes > DEMO_TRACE_SHAPE_SIZE )
            num_shapes = DEMO_TRACE_SHAPE_SIZE;

        /* update duration with the number of shapes we want */
        duration = num_shapes * shape_interval;
        
        printf("NumSignals() = %4d num_shapes = %d, hw_interval = %d, shape_interval = %d, duration %ld\n",
            num_sigs,
            num_shapes,
            hw_interval,
            shape_interval,
            duration );

        for ( sig = 0; sig < num_sigs; sig++ )
        {

            int                                     t;
            #define COMPARE_TO_REFERENCE

            if ( ++sigs_displayed >= 16 )
            {
                //printf("==== not displaying sig %d to %d ====\n", sig, num_sigs );
                //break;
            }

            #ifdef COMPARE_TO_REFERENCE
            printf("%4d %20s\n", sig, wavesource_GetTraceName( ws, sig ) );
            wavesource_GetShapes( ws, sig,
                (long long) 0,
                (long long) hw_interval * num_shapes,
                shapes,
                num_shapes );

            for ( t = 0; t < num_shapes; t++ )
            {
                enum WaveSourceSampleShape  shape;

                shape = shapes[t];

                printf("%s", (shape < WSSV_MAX) ? wave_shape_string[shape] : "xx " );

                //if ( t > 60 )  break;
            }
            printf("\n");
            #endif

            #ifndef COMPARE_TO_REFERENCE
            printf("%4d %20s: ", sig, wavesource_GetTraceName( ws, sig ) );
            #endif

            wavesource_GetShapes( ws, sig,
                (long long) 0,
                duration,
                shapes,
                num_shapes );

            for ( t = 0; t < num_shapes; t++ )
            {
                enum WaveSourceSampleShape  shape;

                shape = shapes[t];

                printf("%s", (shape < WSSV_MAX) ? wave_shape_string[shape] : "xx " );

                //if ( t > 60 )  break;
            }

            printf("\n");

            //if ( 0xf == (sig & 0xf) )
            //    printf("\n");
        }
    
    #elif 1
        FILE                    *fp;

        wavesource_ParseConfig( ws, NULL, 0 );

        wavesource_SetProperty( ws, "circbuf.pa", omar_buf.phys.base );
        wavesource_SetProperty( ws, "circbuf.virt", (int) omar_buf.virt.base );
        wavesource_SetProperty( ws, "circbuf.size", OMAR_BUFSIZE );

        wavesource_SetProperty( ws, "enable.0", 0x1fbe019f );   /* TODO: SLE Enabled units only */
        wavesource_SetProperty( ws, "enable.1", 0xc6f0ff00 );   /* TODO: SLE Enabled units only */

        wavesource_SetProperty( ws, "swap.hilo", 0x00000000 );
        wavesource_SetProperty( ws, "swap.block", 0x00000000 );
        wavesource_SetProperty( ws, "swap.mux", 0x00000000 );

        wavesource_SetCaptureInterval( ws, capture_interval );   /* good to use lots of primes */

        {   int       i;
            for ( i = 0; i < (OMAR_BUFSIZE>>2); i++ )
            {
                ((int *)omar_buf.virt.base)[i] = 0xffffffff;
            }
        }

        signal( SIGINT, crtl_c_sig_handle );
        siginterrupt( SIGINT, 0 );

        wavesource_StartCapture( ws );
        {
            int             hpos;

            hpos = 0;

            while ( hpos < ((OMAR_BUFSIZE>>1)+(OMAR_BUFSIZE>>2)) )
            {
                if ( wavesource_HW_CheckNewsamplesAvailable( ws, hpos ) )
                {
                    int         next_pos;

                    next_pos = hpos;
                    wavesource_HW_GetCurrentCapturePos( ws, &next_pos );

                    if ( hpos != next_pos )
                        printf("[hpos: %d nextpos: %d]\n", hpos, next_pos );

                    while ( hpos != next_pos )
                    {
                        hpos += 1;
                    }
                }
                sleep(1);
                if ( g_CtrlC_Flag )
                {
                    printf("CRTL-C\n");
                    wavesource_HW_DebugCaptureBuffer( ws, 0, 96 );
                    break;
                }
            }
            printf("done\n");
        }
        wavesource_StopCapture( ws );

    #elif 0
        FILE                    *fp;

        wavesource_ParseConfig( ws, NULL, 0 );

        wavesource_SetProperty( ws, "circbuf.pa", omar_buf.phys.base );
        wavesource_SetProperty( ws, "circbuf.virt", (int) omar_buf.virt.base );
        wavesource_SetProperty( ws, "circbuf.size", OMAR_BUFSIZE );

        wavesource_SetProperty( ws, "enable.0", 0x1fbe019f );   /* TODO: SLE Enabled units only */
        wavesource_SetProperty( ws, "enable.1", 0xc6f0ff00 );   /* TODO: SLE Enabled units only */

//        wavesource_SetProperty( ws, "enable.0", 0xffffffff );
//        wavesource_SetProperty( ws, "enable.1", 0xffffffff );
        wavesource_SetProperty( ws, "swap.hilo", 0x00000000 );
        wavesource_SetProperty( ws, "swap.block", 0x00000000 );
        wavesource_SetProperty( ws, "swap.mux", 0x00000000 );


        printf("starting capture\n");
        
        wavesource_SetCaptureInterval( ws, capture_interval );   /* good to use lots of primes */

        wavesource_StartCapture( ws );
        {
            unsigned int             cpos;
            unsigned int             pos,hdr;
            unsigned int             end_pos;

            /* stop after capturing 3/4 of buffer */
            end_pos = omar_buf.phys.base + ((OMAR_BUFSIZE>>1)+(OMAR_BUFSIZE>>2));
                        
            do
            {
                sleep(1);
                wavesource_GetProperty( ws, "capture.pos", &pos );
                wavesource_GetProperty( ws, "capture.hdr", &hdr );
                printf("pos:%08x hdr:%08x waiting...\n", pos, hdr );
            } while ( pos < end_pos );
            printf("done\n");
        }
        wavesource_StopCapture( ws );

        printf("stopped capture\n");
        #if 0
        printf("Saving to file \"%s\"...", omar_filename );
        if ( NULL != (fp = fopen(omar_filename, "wb")) )
        {
            size_t      len;
            if ( OMAR_BUFSIZE != (len = fwrite( omar_buf.virt.base, 1, OMAR_BUFSIZE, fp )) )
            {
                printf("ERR: fwrite() returns %d\n", len );
            }
            fclose(fp);
        } else printf("ERR: Cannot open file \"%s\"...", omar_filename );
        #else
        printf("please run:\ncsven memsave %s 0x%08x length 0x%08x\n",omar_filename,
                omar_buf.phys.base + targ_offset, OMAR_BUFSIZE );
        #endif
        printf("\n");
     #else
        int             sigs_displayed = 0;

        wavesource_PrepareFakeData( ws );

        num_sigs  = wavesource_GetNumSignals( ws );
        num_samps = wavesource_GetNumSamples( ws );

        printf("NumSignals() = %4d NumSamples() = %d\n", num_sigs, num_samps );

        for ( sig = 0; sig < num_sigs; sig++ )
        {
            unsigned int        t,dt;
            unsigned int        dt_pow;

            dt_pow = 5;
            dt = (1<<dt_pow);

            if ( ++sigs_displayed >= 16 )
            {
                //printf("==== not displaying sig %d to %d ====\n", sig, num_sigs );
                //break;
            }

            printf("%4d %20s: ", sig, wavesource_GetSignalName( ws, sig ) );

            for ( t = 0; t < num_samps; t += dt)
            {
                enum WaveSourceSampleShape  shape;

                shape = wavesource_GetSampleShape( ws, sig, (t<<dt_pow), (t<<dt_pow)+dt );

                printf("%s", (shape < WSSV_MAX) ? wave_shape_string_terse[shape] : "xx" );

                //if ( t > 60 )  break;
            }

            printf("\n");

            if ( 0xf == (sig & 0xf) )
                printf("\n");
        }
     #endif

        wavesource_Delete( ws );
    }

    #ifdef OMAR_SLE_HACK
    #else
    ismd_buffer_free( omar_bufh );
    #endif
    
    return(err);
}
#endif /* SMD INTERACTION */
