/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#ifndef OMARLIB_H
#include "omarlib.h"
#endif

#include <osal.h>
#include <pal.h>
#include <sven_devh.h>
#include <svenreverse.h>
#include <sven_protos.h>
#include <osal_memory.h>
#include <auto_eas/gen3_dfx.h>


#ifndef UNUSED_PARAMETER
#define UNUSED_PARAMETER(x)   (void)(x)
#endif

#define GEN3_OMAR_HW_COUNTDOWN_FREQ      (266 * 1000 * 1000) /* XSI Clk:   266 MHz */
#define GEN4_OMAR_HW_COUNTDOWN_FREQ      (400 * 1000 * 1000) /* XSI Clk:   400 MHz */

#define OMAR_HW_MAX_SAMPLED_BLOCKS  64
#define OMAR_HW_SAMPLES_PER_BLOCK   16
#define OMAR_HW_MAX_SAMPLED_SIGNALS (OMAR_HW_MAX_SAMPLED_BLOCKS * OMAR_HW_SAMPLES_PER_BLOCK)
#define OMAR_HW_ENABLES_NUM_DWORDS  (OMAR_HW_MAX_SAMPLED_BLOCKS >> 5)
#define OMAR_HW_MAX_BURSTS_PER_SAMPLE   2

/* This macro combination can be used to find the next power of 2
 * for any input 64 bit value. This works by setting all the bits to the right
 * of the most significant bit to 1s and then incrementing the entire
 * result by 1 so that the resultant number is a power of 2 .
 * For example . If the input value is 2689 , the result at the end of each step
 * is as follows
 *  1. (x-1)         =  2688
 *  2. (x | x >> 1)  =  4032
 *  3. (x | x >> 2)  =  4080
 *  4. (x | x >> 4)  =  4095
 *  5. (x | x >> 8)  =  4095
 *  6. (x | x >> 16) =  4095
 *  7.  x + 1        =  4096
 */
#define B2(x)  ( (x)   | ( (x) >> 1) )
#define B4(x)  ( B2(x) | ( B2(x) >> 2) )
#define B8(x)  ( B4(x) | ( B4(x) >> 4) )
#define B16(x) ( B8(x) | ( B8(x) >> 8) )
#define B32(x) (B16(x) | (B16(x) >>16) )
#define NEXTPOWEROF2(x) (B32(x-1) + 1)

#define OMAR_HW_CHIP_BLOCKS         68
#define OMAR_HW_CHIP_MAX_SIGNALS    (OMAR_HW_CHIP_BLOCKS * OMAR_HW_SAMPLES_PER_BLOCK)

/* WARNING: Arbitrary limit of 32 groups */
#define OMAR_HW_MAX_GROUPS          32
#define OMAR_HW_MAX_BLOCKS          67

#define xstringify(s) stringify(s)
#define stringify(s) #s
#ifdef COMP_VER
char *libomarwave_version_string = "#@# libomarwave " xstringify(COMP_VER) " " __DATE__ " " __TIME__;
#else
char *libomarwave_version_string = "#@# libomarwave <COMP_VER undefined> Eng Rel";
#endif

union OMARBurstHeader
{
    unsigned int        hdr;
    struct
    {
        unsigned int    hdr_sample      : 24;    /* [23..0] */
        unsigned int    hdr_r0          : 1;     /* [24] */
        unsigned int    hdr_burst       : 4;     /* [28..25] */
        unsigned int    hdr_r1          : 1;     /* [29] */
        unsigned int    hdr_wrap        : 2;     /* [31..30] */
    };
};

#define OMAR_BURST_HEADER_SAMPLE_MASK  0x00FFFFFF
#define OMAR_BURST_HEADER_BURST_MASK   0x1e000000
#define OMAR_BURST_HEADER_WRAP_MASK    0xC0000000


struct OMARBurst
{
    union OMARBurstHeader   hdr;
    unsigned int            data[OMAR_HW_SAMPLES_PER_BLOCK*3];
};

/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */

struct WaveformData
{
    void            *wd_sample_buffer;
    unsigned int     wd_buffer_size;
    unsigned int     wd_bytes_per_sample;       /* Samples contain N Bursts */
    unsigned int     wd_bursts_per_sample;      /* Samples contain N Bursts */
    unsigned int     wd_max_signal_num;         /* calculated */
    unsigned int     wd_bursts_per_buffer;
    unsigned int     wd_samples_per_buffer;
    unsigned int     wd_bursts_captured;
    int              wd_starting_burst;        /* found by scanning circbuf */
    int              wd_first_sample_timestamp;
    int              wd_starting_burst_timestamp;

    unsigned int     wd_interval_countdown;    /* XSI Clocks */
    int              wd_sample_skip_tolerance; /* sample skip tolerance */
    unsigned int     wd_enable[OMAR_HW_ENABLES_NUM_DWORDS];
    unsigned int     wd_hilo_swap;
    unsigned int     wd_block_swap;
    unsigned int     wd_mux_select;

    unsigned int     wd_cur_burst;    /* currently read sample */

    /* All Capturable Signals */
    char            *wd_sig_name[OMAR_HW_CHIP_MAX_SIGNALS];

    /* Group and OMAR Block Names */
    char            *wd_group_name[OMAR_HW_MAX_GROUPS];
    char            *wd_block_name[OMAR_HW_MAX_BLOCKS];

    /* Enabled Signals */
    char            **wd_enabled_signame[OMAR_HW_MAX_SAMPLED_SIGNALS];
};

/* -------------------------------------------------------------------------- */

static struct OMARBus* wavesource_AddOMARBus(
    struct WaveformSource   *ws );

/* -------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------- */

/*****************************************************************
    Waveformdata APIs
******************************************************************/
static void waveformdata_Close(
    struct WaveformData     *wd )
{
    int         i;

    for ( i = (OMAR_HW_CHIP_MAX_SIGNALS-1); i >= 0; i-- )
    {
        if ( NULL != wd->wd_sig_name[i] )
        {
            free( wd->wd_sig_name[i] );
        }
    }
}   /* waveformdata_Close() */

#if 0
static int waveformdata_Set_SignalName(
    struct WaveformData     *wd,
    int                      sig_num,
    const char              *signame,
    int                      signame_len )
{
    int          err = 0;

    if ( (sig_num >= 0) && (sig_num < OMAR_HW_CHIP_MAX_SIGNALS) )
    {
        char        *new_name;

        if ( NULL != (new_name = malloc(signame_len+1)) )
        {
            strncpy( new_name, signame, signame_len );
            new_name[signame_len] = '\0';

            if ( NULL != wd->wd_enabled_signame[sig_num] )
            {
                free( wd->wd_enabled_signame[sig_num] );
            }

            wd->wd_enabled_signame[sig_num] = new_name;
        }
        else
        {
            err = 1;
        }
    }
    else
    {
        err = 1;
    }

    return(err);
}
#endif
static int waveformdata_Set_HW_BusName(
        char            ** ppBusName,
        int               sig_num,
        const char    *signame,
        int               LowestPin,
        int               HighestPin,
        int               signame_len
  )
{
    int          err = 0;
    char ch[4]={'\0'};
   int len;

    if ( (sig_num >= 0) && (sig_num < OMAR_HW_CHIP_MAX_SIGNALS) )
    {
        char        *new_name=NULL;
        len=signame_len;
        sprintf(ch,"%d",LowestPin);
        len+= strlen(ch);
        sprintf(ch,"%d",HighestPin);
        len+= strlen(ch);
        len+=2; /* For : and ] */

        if ( (NULL != (new_name = malloc(len+1))) && (NULL!=signame ) )
        {
            strncpy( new_name, signame, signame_len );
            new_name[signame_len]='\0';
            strcat(new_name,ch);
            strcat(new_name,":");
            sprintf(ch,"%d",LowestPin);
            strcat(new_name,ch);
            strcat(new_name,"]");

            new_name[len] = '\0';

            if ( NULL != *ppBusName )
            {
                free( *ppBusName);
            }

            *ppBusName = new_name;
        }
        else
        {
            err = 1;
        }
    }
    else
    {
        err = 1;
    }

    return(err);
}   /* waveformdata_Set_HW_BusName()  */

static int waveformdata_Set_HW_SignalName(
    struct WaveformData     *wd,
    int                      sig_num,
    const char              *signame,
    int                      signame_len )
{
    int          err = 0;

    if ( (sig_num >= 0) && (sig_num < OMAR_HW_CHIP_MAX_SIGNALS) )
    {
        char        *new_name;

        if ( NULL != (new_name = malloc(signame_len+1)) )
        {
            strncpy( new_name, signame, signame_len );
            new_name[signame_len] = '\0';

            if ( NULL != wd->wd_sig_name[sig_num] )
            {
                free( wd->wd_sig_name[sig_num] );
            }

            wd->wd_sig_name[sig_num] = new_name;
        }
        else
        {
            err = 1;
        }
    }
    else
    {
        err = 1;
    }

    return(err);
} /* waveformdata_Set_HW_SignalName() */

static int waveformdata_SetGroupName(
    struct WaveformData     *wd,
    int                      group_num,
    const char              *groupname,
    int                      groupname_len )
{
    int          err = 0;


    if ( (group_num >= 0) && (group_num < OMAR_HW_MAX_GROUPS) )
    {
        char        *new_name;

        if ( NULL != (new_name = malloc(groupname_len+1)) )
        {
            strncpy( new_name, groupname, groupname_len );
            new_name[groupname_len] = '\0';

            if ( NULL != wd->wd_group_name[group_num] )
            {
                free( wd->wd_group_name[group_num] );
            }

            wd->wd_group_name[group_num] = new_name;
        }
        else
        {
            err = 1;
        }
    }
    else
    {
        err = 1;
    }

    return(err);
} /* waveformdata_SetGroupName() */

static int waveformdata_SetBlockName(
    struct WaveformData     *wd,
    int                      block_num,
    const char              *blockname,
    int                      blockname_len )
{
    int          err = 0;


    if ( (block_num >= 0) && (block_num < OMAR_HW_MAX_BLOCKS) )
    {
        char        *new_name;

        if ( NULL != (new_name = malloc(blockname_len+1)) )
        {
            strncpy( new_name, blockname, blockname_len );
            new_name[blockname_len] = '\0';

            if ( NULL != wd->wd_block_name[block_num] )
            {
                free( wd->wd_block_name[block_num] );
            }

            wd->wd_block_name[block_num] = new_name;
        }
        else
        {
            err = 1;
        }
    }
    else
    {
        err = 1;
    }

    return(err);
}   /* waveformdata_SetBlockName() */

static int waveformdata_MakeFakeSignalNames(
    struct WaveformData     *wd )
{
    int         err = 0;
    int         i;

    for ( i = 0; i < OMAR_HW_MAX_SAMPLED_SIGNALS; i++ )
    {
        char        name[32];

        sprintf( name, "DFX_SIG_0x%03x", i );

        if ( 0 != (err = waveformdata_Set_HW_SignalName(wd,i,name,strlen(name))) )
        {
            err = 1;
            break;
        }
    }

    return(err);

}   /* waveformdata_MakeFakeSignalNames() */

static int waveformdata_Init(
    struct WaveformData     *wd )
{
    int         retval = 0;

    wd->wd_sample_skip_tolerance = 0x5;
    wd->wd_interval_countdown = GEN4_OMAR_HW_COUNTDOWN_FREQ / 1000; /* one kHz Capture */

    {   int i;

        /* All block capture enabled */
        wd->wd_hilo_swap = 0;
        wd->wd_block_swap = 0;
        for ( i = 0; i < OMAR_HW_ENABLES_NUM_DWORDS; i++ )
            wd->wd_enable[i] = 0xffffffff;
    }

    if ( ! waveformdata_MakeFakeSignalNames( wd ) )
    {
        retval = 1;
    }

    if ( !retval )
    {
        waveformdata_Close(wd);
    }

    return(retval);

}   /* waveformdata_Init() */

static int waveformdata_RethinkNewEnables(
    struct WaveformData     *wd )
{
    int             i,signum,blocks_captured,next_loc;

    signum = 0;
    blocks_captured = 0;
    next_loc = 0;

    for ( i = 0; i < OMAR_HW_ENABLES_NUM_DWORDS; i++ )
    {
        int         bit;

        for ( bit = 0; bit < 32; bit++ )
        {
            if ( 1 || (wd->wd_enable[i] & (1<<bit)) )
            {
                int             n;

                for ( n = 0; n < OMAR_HW_SAMPLES_PER_BLOCK; n++ )
                {
                    /* Set the captured name-ptr-ptr */
                    wd->wd_enabled_signame[next_loc] = &wd->wd_sig_name[signum + n];
                    next_loc++;
                }

                blocks_captured++;
            }

            signum += OMAR_HW_SAMPLES_PER_BLOCK;
        }
    }

    /* calculate the number of bursts per sample */
    wd->wd_bursts_per_sample = (blocks_captured + 31) >> 5;
    wd->wd_max_signal_num = wd->wd_bursts_per_sample * OMAR_HW_SAMPLES_PER_BLOCK * 32;
    wd->wd_bytes_per_sample = wd->wd_bursts_per_sample * sizeof(struct OMARBurst);

    /* Calculate Number of bursts per buffer */
    wd->wd_bursts_per_buffer = wd->wd_buffer_size / sizeof(struct OMARBurst);
    wd->wd_samples_per_buffer = wd->wd_buffer_size / wd->wd_bytes_per_sample;

    return( next_loc );

}

/* How many different signals were captured */
#if 0
static int waveformdata_GetNumberOfTraces(
    struct WaveformData     *wd )
{
    return( wd->wd_max_signal_num);
}
#endif


static int waveformdata_GetNumOfHWSignalsCaptured(
    struct WaveformData     *wd )
{
    return( wd->wd_bursts_per_sample *
            32 * /* Number of blocks captured */
            OMAR_HW_SAMPLES_PER_BLOCK );
}

#if 0
/* What is the "name" of captured signal <sig_num> */
static const char * waveformdata_GetCapturedSignalName(
    struct WaveformData     *wd,
    unsigned int             sig_num )
{
    if ( sig_num < wd->wd_max_signal_num )
        return( *wd->wd_sig_name[sig_num] );
    else
        return( NULL );
}
#endif
/* What is the "name" of captured signal <sig_num> */
static const char * waveformdata_GetHWSignalName(
    struct WaveformData     *wd,
    unsigned int             sig_num )
{
    if ( sig_num < wd->wd_max_signal_num )
        {
        //return( *wd->wd_sig_name[sig_num] );
        return( wd->wd_sig_name[sig_num] );
        }
    else
        return( NULL );
}

#ifdef UNUSED_FUNCTION
/* WARNING: Rough estimate of number of samples per second */
static int waveformdata_GetCapturedSampleRate(
    struct WaveformData     *wd )
{
    if ( wd->wd_interval_countdown )
        return( OMAR_HW_COUNTDOWN_FREQ / wd->wd_interval_countdown );
    else
        return( 10000 );
}
#endif

#ifdef UNUSED_FUNCTION
/* how many sample captured in this data format */
static unsigned long waveformdata_GetNumberOfSamplesCaptured(
    struct WaveformData     *wd )
{
    /** TODO: This must account for "missing" samples */
    return( wd->wd_samples_per_buffer );
}
#endif

#ifdef UNUSED_FUNCTION
/* Read the next sample into my local buffer */
static struct OMARBurst *waveformdata_SeekNextBurst(
    struct WaveformData     *wd )
{
    char            *src;

    /* Go to the beginning of the buffer */
    src = (char *) wd->wd_sample_buffer;

    /* zoom to sample */
    src += wd->wd_cur_burst * sizeof(struct OMARBurst);

    /* Increment with wrap-around */
    if ( ++wd->wd_cur_burst >= wd->wd_bursts_per_buffer )
    {
        wd->wd_cur_burst = 0;
    }

    return( (struct OMARBurst *) src );
}
#endif

/* Seek to sample, give pointers to previous and current */
static int waveformdata_SeekSample(
    struct WaveformData     *wd,
    int                      sample_num,
    struct OMARBurst        **pprev,
    struct OMARBurst        **pcur )
{
    int                      err = 0;

    /* Add detected starting position */
    sample_num += wd->wd_starting_burst;
    /* clamp with wrap-around */
    sample_num %= wd->wd_bursts_per_buffer;

    /* pointer to current sample */
//    (*pcur) = (struct OMARBurst *) &((char *)wd->wd_sample_buffer)[sample_num * wd->wd_bytes_per_sample];
    (*pcur) = (struct OMARBurst *) &((char *)wd->wd_sample_buffer)[sample_num * sizeof(struct OMARBurst)];

    /* back up one sample (with wraparound) */
    if ( (sample_num -= wd->wd_bursts_per_sample) < 0 )
        sample_num = wd->wd_bursts_per_buffer - 1;

    /* pointer to current sample */
//    (*pprev) = (struct OMARBurst *) &((char *)wd->wd_sample_buffer)[sample_num * wd->wd_bytes_per_sample];
    (*pprev) = (struct OMARBurst *) &((char *)wd->wd_sample_buffer)[sample_num * sizeof(struct OMARBurst)];

    return( err );
}

static struct OMARBurst *waveformdata_SeekBurst(
    struct WaveformData     *wd,
    int                      burst_num )
{
    struct OMARBurst        *cur;

    /* Add detected starting position */
    burst_num += wd->wd_starting_burst;
    /* clamp with wrap-around */
    burst_num %= wd->wd_bursts_per_buffer;

    /* pointer to current sample */
    cur = (struct OMARBurst *) &((char *)wd->wd_sample_buffer)[burst_num * sizeof(struct OMARBurst)];

    return( cur );
}

#ifdef DEBUG_SAMPLE_HEADERS
static void waveformdata_PrintSampleHeaders(
    struct WaveformData     *wd )
{
    struct OMARBurst    *burst;
    unsigned int         i;

    burst = (struct OMARBurst *)wd->wd_sample_buffer;

    for ( i = 0; i < wd->wd_bursts_per_buffer; i++ )
    {
        printf("%d-%d ", (int) burst[i].hdr.hdr_wrap, (int) burst[i].hdr.hdr_burst );
        if ( 0x1f == (i & 0x1f) )
            printf("\n");
    }
    printf("\n");
}
#endif /* DEBUG_SAMPLE_HEADERS */

#ifdef UNUSED_FUNCTION
static void wavesource_GetOmarSampleTimestamp(
    struct WaveformData *wd,
    int sample, int *sample_timestamp)
{
   struct OMARBurst *burst;
   burst = (struct OMARBurst *) wd->wd_sample_buffer;
   *sample_timestamp = burst[sample].hdr.hdr_sample;
}
#endif

static int waveformdata_FindCaptureSeam(
    struct WaveformData     *wd,
    int                     *pburst )
{
    int                  found_it = 0;
    unsigned int         i = 0;
    int                  s0,s1;
    struct OMARBurst    *burst;

    #ifdef DEBUG_SAMPLE_HEADERS
    waveformdata_PrintSampleHeaders(wd);
    #endif

    burst = (struct OMARBurst *)wd->wd_sample_buffer;

    s0 = burst[0].hdr.hdr_sample;
    s1 = burst[wd->wd_bursts_per_buffer-1].hdr.hdr_sample;

    //printf("t0 = %06x tn = %06x\n", s0, s1 );

    /* Is the timestamp at the end of the buffer
     * just before the timestamp at the beginning of the buffer?
     */
    if ( ((s0 - s1) >= 0) &&
         ((s0 - s1) <= wd->wd_sample_skip_tolerance) )
    {
        int                  wrap = 0;
        /* Wrap count of first item in the buffer */
        wrap = burst[0].hdr.hdr_wrap;
        /* convert to expected previous wrap */
        wrap = (wrap-1) & 0x3;

        for ( i = 0; i < wd->wd_bursts_per_buffer; i++ )
        {
            if ( burst[i].hdr.hdr_wrap == wrap )
            {
                if ( 0 == burst[i].hdr.hdr_burst )
                {
                    printf("waveformdata_FindCaptureSeam( %d ) = %d\n", wd->wd_bursts_per_buffer, i );
                    found_it = 1;
                    break;
                }
            }
            else if ( burst[i].hdr.hdr_wrap != burst[0].hdr.hdr_wrap ) /* rip */
            {
                found_it = 0;   /* wrap has rips in it, can be caused by multiple short captures */
                break;
            }
            else
            {
                /* wrap is the same, just continue */
            }
        }
    }
    else
    {
        /* buffer does not appear to wrap at the end */
    }

    if ( found_it )
    {
        *pburst = i;
    }
    else
    {
        *pburst = 0;
    }
    return(found_it);
}

static int waveformdata_FindBurstCount(
    struct WaveformData *wd,
    unsigned int *burst_count)
{
   int err = 0;
   unsigned int i = 0;
   int s0;
   struct OMARBurst *burst;
   unsigned int curr = 0;

   curr = wd->wd_starting_burst;
   burst = (struct OMARBurst *) wd->wd_sample_buffer;
   s0 = burst[curr].hdr.hdr_sample;

   /* Increment by 2 as the next burst might also have the same timestamp */
   curr += 2;

   for (i = 1; i < wd->wd_bursts_per_buffer; i++)
   {
      if ((burst[curr].hdr.hdr_sample) > s0)
      {
         curr++;

         /* For wrap around */
         curr %= wd->wd_bursts_per_buffer;
      }
      else
      {
         *burst_count = i + 2;
         break;
      }

   }
   return (err);
}

static int waveformdata_PrepareFakeData(
    struct WaveformData     *wd,
    int                      flags )
{
    int             err = 0;
    unsigned int    i;
    unsigned int    num_samples;

//    odh->odh_interval_countdown = rand() % OMAR_HW_COUNTDOWN_FREQ;

    /* MUNGE the enable flags */
    if ( 0 == (0x1 & flags) )
    {
        for ( i = 0; i < OMAR_HW_ENABLES_NUM_DWORDS; i++ )
        {
            wd->wd_enable[i] = rand();

            /* thin it (to roughly 6% enabled) */
            if ( 0 == (0x2 & flags) )
            {
                wd->wd_enable[i] &= ~rand();
                wd->wd_enable[i] &= ~rand();
                //odh->odh_enable[i] &= ~rand();
            }
        }
    }
    else
    {
        for ( i = 0; i < OMAR_HW_ENABLES_NUM_DWORDS; i++ )
        {
            wd->wd_enable[i] = 0xFFFFFFFF;
        }
    }

    /* Calculate new sizes, etc */
    waveformdata_RethinkNewEnables(wd);

    /* get non-zero number of samples */
    //while ( 0 == (num_samples = (0x3F & rand())) )
    while ( 0 == (num_samples = (0x3FF & rand())) )
        ;

    /* How big does the buffer need to be */
    wd->wd_buffer_size = num_samples * wd->wd_bytes_per_sample;

    /* Add some random padding (must be less than one extra sample) */
    wd->wd_buffer_size += rand() % wd->wd_bytes_per_sample;

    /* Free Previous */
    if ( NULL != wd->wd_sample_buffer )
    {
        free ( wd->wd_sample_buffer );
    }

    /* Calculate new sizes, etc */
    waveformdata_RethinkNewEnables(wd);

    /* Create a fake wrapping point */
    wd->wd_starting_burst = rand() % wd->wd_bursts_per_buffer;

    /* Allocate a new sample buffer */
    if ( NULL != (wd->wd_sample_buffer = malloc(wd->wd_buffer_size)) )
    {
        unsigned int         timestamp,pass;

        memset( wd->wd_sample_buffer, 0xff, wd->wd_buffer_size );

        timestamp = rand() & 0x00FFFFFF;    /* 24 bits */
        pass = rand();                      /* 2 bit pass number */

        for ( i = 0; i < (num_samples * wd->wd_bursts_per_sample); i += wd->wd_bursts_per_sample )
        {
            unsigned int     burst;

            for ( burst = 0; burst < wd->wd_bursts_per_sample; burst++ )
            {
                struct OMARBurst    *cur;
                int                  d;

                cur = waveformdata_SeekBurst( wd, i+burst );

                cur->hdr.hdr = 0;
                cur->hdr.hdr_wrap = pass;
                cur->hdr.hdr_burst = burst;
                cur->hdr.hdr_sample = timestamp;

                for ( d = 0; d < (OMAR_HW_SAMPLES_PER_BLOCK*3) ; d++ )
                {
                    cur->data[d] = rand() & rand() & rand();
                }
            }

            timestamp++;
        }

        /* make it look like a wrap-around */
        {
            unsigned int         start;
            struct OMARBurst    *cur;

            start = wd->wd_starting_burst;
            wd->wd_starting_burst = 0;
            pass++;

            for ( i = 0; i < start; i++ )
            {
                cur = waveformdata_SeekBurst( wd, i );
                cur->hdr.hdr_wrap = pass;
            }

            /* Restore the starting position or make the app look for it??? */
            //wd->wd_starting_burst = start;
        }
    }
    else
    {
        err = 1;
    }

    return(err);
}

/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */
/* ------------------------------------------------------------------ */


const struct EventTypeReverse* svenreverse_EVENT_TABLES_BY_NAME(
    const char                  *event_name );
const struct EventTypeReverse* svenreverse_EVENT_TABLES_BY_NUM(
    int                          event_num );


/* ------------------------------------------------------------- */
#include "htuple.h"
#include "platform_config.h"
#include "platform_config_paths.h"
#include "sven_file.h"

struct WaveClock
{
    /** for example, OMAR Capture is XSI / 1000, SVEN Timestamps are XSI / 125 */
    unsigned int             clock_divide_value;
};

struct SVENFilter
{
    struct SVENEvent     eq_ev;     /* EQ block for SVEN Filter */
    struct SVENEvent     and_ev;    /* AND block for SVEN Filter */
};

enum WaveTraceType
{
    TRACE_TYPE_OMAR_WIRE,
    TRACE_TYPE_OMAR_BUS,
    TRACE_TYPE_SVEN_FILTER,
    TRACE_TYPE_BUF_LEVEL,
    TRACE_TYPE_GROUP,
    TRACE_TYPE_HEALTH,
    TRACE_TYPE_MAX
};

struct WaveTrace
{
    struct WaveTraceInfo    pub;    /* embedded public data */

    htuple_t                trace_node_id;      /* description in configuration file */

    enum WaveTraceType      ttype;

    int                     is_expandable;
    int                     is_expanded;
    unsigned int            parent_trace;       /* Wires point to their BUS */

    /* Private Data */
    struct WaveClock        *clk;   /* how to evaluate the time of this trace */

    union
    {
        struct
        {
            unsigned int     block_id;          /* block 0 to 67 */
            unsigned int     pin_id;            /* pin on the capture block [15..0] */
            unsigned int     capture_id;        /* Signal number as captured  (after HW MUXING) */
        }omar_wire;
        struct
        {
            unsigned int     block_id;          /* block 0 to 67 */
            unsigned int     pin_id;            /* least-significant pin on the block*/
            unsigned int     capture_id;        /* Signal number as captured  (after HW MUXING) */
            unsigned int     pin_width;         /* how many wires in the trace */
        }omar_bus;
        struct
        {
            struct SVENFilter   filt;           /* Event filter thing */
        }sven;
        struct
        {
            unsigned int    total_size;         /* Total traces in the group including any group traces */
        }group;
        struct
        {
            unsigned int     port;              /* SMD port_id */
            unsigned int     queue;             /* SMD queue_id */
            unsigned int     max_bufs;          /* what buffer level is 100% */
            unsigned int     max_bytes;         /* what buffer level is 100% */
            unsigned int     peak_bufs;         /* measured: what buffer level WAS 100% */
            unsigned int     peak_bytes;        /* measured: what buffer level WAS 100% */
        }smd;
        struct
        {
            unsigned int     foo;               /* some health indicator */
        }health;
    };
};


/** Process for chipwatcher file parsing
 *
 *  1.  Populate all Detected OMAR Signal names as scanning file
 *              wavesource_SetSignalName()
 *
 *  2.  Scan all (68*16) HW signal names, looking for "bus name sequences"
 *      e.g. "tsd_wpc[4]" "tsd_wpc[3]" "tsd_wpc[2]"
 *      for each detected:
 *              wavesource_AddOMARBus( ..... )
 *
 *
 *  When viewing OMAR_ONLY mode
 *
 *      separate routine populates ws_traces[] with collapsed detected busses and wires
 *
 *      struct WaveTrace *wt = wavesource_AddTrace(...);
 *          wt->pub.label              = "TBD";
 *          wt->pub.depth              = 0;
 *          wt->pub.level_style        = 0;
 *          wt->ttype                  = TRACE_TYPE_OMAR_WIRE;
 *          wt->is_expandable          = 0;
 *          wt->is_expanded            = 0;
 *          wt->parent_trace           = parent_sig;
 *          wt->clk                    = parent->clk;
 *          wt->omar_wire.block_id     = omar_wire_id / WIRES_PER_BLOCK;
 *          wt->omar_wire.pin_id       = omar_wire_id % WIRES_PER_BLOCK;
 *          wt->omar_wire.capture_id   = omar_wire_id;
 *          wt->pub.label              = ws->wd.wd_sig_name[omar_wire_id];
 */

struct OMARBus
{
    char            *label;             /* e.g. "tsd_wpc[4:2]" */
    unsigned int     block_id;          /* block 0 to 67 */
    unsigned int     pin_id;            /* least-significant pin on the block*/
    unsigned int     capture_id;        /* Signal number as captured  (after HW MUXING) */
    unsigned int     pin_width;         /* how many wires in the trace */
};

/** Private to this implementation */
struct WaveformSource
{
   struct WaveformData      wd;

#ifndef SELF_TEST
   os_devhandle_t          *ws_devh;
#endif

   /* OMAR CAPTURE INFORMATION */
   /* ------------------------------------------------------------------------ */
   int                      ws_hw_capture_enabled;

   unsigned int             ws_capture_clock_frequency;    /* header word before capture started */

   unsigned int             ws_capture_start_word;         /* header word before capture started */
   unsigned int             ws_capture_stop_word;          /* header word after capture stopped */
   unsigned int             ws_capture_start_timestamp;    /* SVEN Timestamp Register when OMAR started */
   unsigned int             ws_capture_stop_timestamp;     /* SVEN Timestamp Register when OMAR started */
   unsigned int             ws_capture_start_prescale;     /* SVEN Timestamp Register when OMAR started */
   unsigned int             ws_capture_first_detected;

   int                      ws_hardware_not_present;
   void                    *ws_capture_buf_ptr;
   unsigned long            ws_capture_buf_pa;
   unsigned long            ws_capture_buf_size;

   int                      ws_capture_buf_mapped;

   unsigned int             ws_hilo_swap;
   unsigned int             ws_block_swap;
   unsigned int             ws_mux_select;
   unsigned int             ws_capture_period;
   unsigned int             ws_enable[OMAR_HW_ENABLES_NUM_DWORDS];
   unsigned int             ws_omar_offset;

   /* OMAR Signal Name bus detection logic */
   /* ------------------------------------------------------------------------ */
   struct OMARBus          *ws_omar_busses;
   unsigned int             ws_num_omar_busses;   /* how many V traces */
   unsigned int             ws_max_omar_busses;   /* how many V allocated */


   /* SVEN Trace information */
   /* ------------------------------------------------------------------------ */
   struct _SVENHeader      *ws_svenhdr;
   struct SVENLog          *ws_svenlog;
   unsigned long            ws_svenlog_size; /* size in bytes of local sven log */
   struct SVENReverser     *ws_svenreverse;
   os_thread_t              ws_svenlog_thread;
   int                      ws_svenlog_thread_created;
   int                      ws_svenlog_thread_quit_request;
   unsigned int             ws_svenlog_start_timestamp;
   unsigned int             ws_svenlog_time_wraps;
   unsigned int             ws_svenlog_stop_timestamp;
   struct SVENEvent         ws_reference_event;
   int                      ws_reference_event_active;
   int                      ws_svenlog_load_enabled;
   unsigned int             ws_firstsven_timestamp;
   unsigned int             ws_lastsven_timestamp;

   /* Capture Configuration  */
   /* ------------------------------------------------------------------------ */
   htuple_t                 config_file_id;  /* gsven.hcfg htuple tree */
   htuple_t                 omar_config_id;  /* omar.hcfg htuple tree */

   /* Hybrid-view structs */
   /* ------------------------------------------------------------------------ */
   struct WaveTrace         *ws_traces;        /* "Trace view" (vertical array of traces) */
   unsigned int              ws_num_traces;    /* how many V traces */
   unsigned int              ws_max_traces;    /* how many V allocated */

   /* Hybrid-view structs */
   /* ------------------------------------------------------------------------ */
   union {
      struct {
         struct _SVENFileHeader       ws_file_hdr;      /* file hdr contains one trace */
         struct SVENFile_TraceHeader  ws_file_trace[2]; /* more than this if necessary */
      };
      unsigned char                   ws_file_hdr_buf[512];
   };

};
typedef struct BusParams
{
    int StartingSignalNumber;
    int NumOfLinesInBus;
    int BusName;

} BusParams, *pBusParams;

#define MAX_STRING_LENGTH 100

static void omar_htuple_verbose_printf( htuple_t id, unsigned int level )
{
    const char          *name;
    unsigned int         child,i;
    struct htuple_Value  val;

    for ( i = 0; i < level; i++ )
        printf("  ");

    htuple_node_name( id, &name );
    htuple_node_get_value( id, &val );

    if ( HTUPLE_TYPE_STRING == val.type )
    {
        printf("\"%s\" = \"%s\" /* id %d type %d */\n", name, val.str, id, val.type );
    }
    else
    {
        printf("\"%s\" = 0x%x /* id %d type %d */\n", name, val.intval, id, val.type );
    }

    if ( 0 != (child = htuple_first_child( id )) )
    {
        for ( i = 0; i < level; i++ )
            printf("  ");
        printf("{\n");

        level++;

        do
        {
            omar_htuple_verbose_printf( child, level );

            child = htuple_next_sibling(child);
        } while ( 0 != child );

        level--;

        for ( i = 0; i < level; i++ )
            printf("  ");
        printf("}\n");
    }
}


static int ExtractBusLineNumber(const char* pName)
{
    const char *pBegin=NULL,*pEnd=NULL;
    char temp[MAX_STRING_LENGTH];

    pBegin=strchr(pName,'[');
    pBegin++;
    pEnd=strchr(pName,']');
    pEnd--;
    strncpy(temp,pBegin,(pEnd-pBegin+1));
    temp[(pEnd-pBegin+1)]='\0';

    return atoi(temp);

}   /* ExtractBusLineNumber() */

void wavesource_DetectBuses(struct WaveformSource   *ws)
{
    int i,j=0,NumOfSignals,len,UpperLimit;
    const char *pTempChar=NULL,*pName=NULL;
     char *pBuffer=NULL;
    int temp,bit1,bit2;
    int bTemp=FALSE;
    struct OMARBus* pBus=NULL;

NumOfSignals=wavesource_GetNum_HW_Signals( ws);

for(i=0;i<NumOfSignals;i++)
{
        pName=wavesource_Get_HW_SignalName(ws, i);
        if(NULL==pName)
        {
            continue;
        }
        len=strlen(pName);

        if(']'==pName[len-1])
        {
            /* Potential bus. Must analyse further */

            /*
                Find out number of lines in this bus.
                Assume that they are adjacent lines
            */

            /* Find the position of  [ The generic name occurs before this */

            pTempChar=strchr ( pName, '[' );

            if(NULL!=pTempChar)
            {
                temp=pTempChar-pName+1;
                pTempChar=pName;
            }
            else
            {
                continue;
            }

            /* Look only within this OMAR block. Block size is 16 bits */
            UpperLimit=(( i>>4)<<4)+16;

            i++;
            bit1=ExtractBusLineNumber(pName);
            bit2=0;
            while((i<UpperLimit)&&(i<NumOfSignals))
            {
                /* Read the next signal's name */
                pName=wavesource_Get_HW_SignalName(ws, i);
                if(NULL==pName)
                {
                    break;
                }

                if(!strncmp(pTempChar,pName,temp))
                {
                    /* It is a bus */
                    if(!bTemp)
                    {
                        /* Writing the first line in the bus */
                        j++;
                        if ( NULL != (pBus = wavesource_AddOMARBus(ws)) )
                        {
                            pBus->capture_id=i-1;
                            pBus->pin_width=1;
                            bTemp=TRUE;
                             pBuffer=(char*)malloc(sizeof(char)*(strlen(pTempChar)+2));
                            if(NULL!=pBuffer)
                            {
                                strcpy(pBuffer," ");
                                strcat(pBuffer,pTempChar);
                            wavesource_Set_HW_SignalName(ws,i-1,pBuffer);
                        //    wavesource_Set_HW_SignalName(ws,i,pTempChar);
                                free(pBuffer);
                                pBuffer=NULL;
                            }
                        }
                    }   /* if(!bTemp) */

                   bit2=ExtractBusLineNumber(pName);
                   pBus->pin_width++;
                   pBuffer=(char*)malloc(sizeof(char)*(strlen(pName)+2));
                     if(NULL!=pBuffer)
                    {
                        strcpy(pBuffer," ");
                        strcat(pBuffer,pName);
                       wavesource_Set_HW_SignalName(ws,i,pBuffer);
                  //    wavesource_Set_HW_SignalName(ws,i,pTempChar);
                        free(pBuffer);
                        pBuffer=NULL;
                    }
                    i++;
                }
                else
                {
                    break;
                }
            }   /* while((i<UpperLimit)&&(i<pAppInst->WaveformParam.NumOfSignals)) */
            if(bTemp)
            {
                /* A bus was previously detected */
                bTemp=FALSE;

                if(bit1>bit2)
                {
                    temp=bit2;
                    bit2=bit1;
                    bit1=temp;
                }


                /* Now we must arrive at the length of the constructed bus name */
                pName=wavesource_Get_HW_SignalName(ws,i-1);
                pTempChar=strchr ( pName, '[' );
                len=pTempChar-pName;

                /* Allocate memory,create string and then make the bus
                datastructure point to this. */
                waveformdata_Set_HW_BusName(
                &(pBus->label),
                   pBus->capture_id,
                    &pName[1],bit1,bit2,
                    len );


             }   /* if(bTemp) */
            i--;

        }   /* if(']'==pName[len-1]) */


    }   /* for(i=0;i<NumOfSignals;i++) */

}   /* wavesource_DetectBuses() */

static void wavesource_ReleaseCaptureBuffer(
    struct WaveformSource   *ws )
{
    if ( NULL != ws->wd.wd_sample_buffer )
    {
        if ( ws->ws_capture_buf_mapped )
        {
#ifndef SELF_TEST
            OS_UNMAP_IO_FROM_MEM( ws->wd.wd_sample_buffer, ws->ws_capture_buf_size );
#endif
            ws->wd.wd_sample_buffer = NULL;
            ws->ws_capture_buf_mapped = 0;
        }
        else
        {
            /* assume malloc */
            free( ws->wd.wd_sample_buffer );
            ws->wd.wd_sample_buffer = NULL;
        }
    }
}

/** Delete a WaveSource */
void wavesource_Delete(
    struct WaveformSource   *ws )
{
    if ( 0 != ws->ws_svenlog_thread_created )
    {
       ws->ws_svenlog_thread_quit_request = 1;
       os_thread_wait( &ws->ws_svenlog_thread, 1 );   /* wait for completion */
    }

    if ( NULL != ws->ws_svenlog )
    {
        svenlog_Delete( ws->ws_svenlog );
        ws->ws_svenlog = NULL;
    }

    if ( NULL != ws->ws_svenreverse )
    {
        svenreverse_Delete( ws->ws_svenreverse );
        ws->ws_svenreverse = NULL;
    }
    if ( NULL != ws->ws_svenhdr )
    {
        ws->ws_svenhdr = NULL;
    }

    wavesource_ReleaseCaptureBuffer( ws );

    if ( NULL != ws->ws_traces )
    {
        free( ws->ws_traces );
        ws->ws_traces = NULL;
    }
    if ( NULL != ws->ws_omar_busses)
     {
         free( ws->ws_omar_busses );
         ws->ws_omar_busses = NULL;
     }

#ifndef SELF_TEST
    if ( NULL != ws->ws_devh )
    {
        devh_Delete( ws->ws_devh );
        ws->ws_devh = NULL;
    }

    OS_FREE(ws);
#endif
}

////////////////////////////////////////////////////////////////////////////////
/// @brief        Creates a thread process
/// @param[in]    arg      ptr
/// @returns      Error value or 0 on success
////////////////////////////////////////////////////////////////////////////////
static void *wavesource_svenlog_threadproc( void* arg )
{
   struct WaveformSource  *ws;
   int                     t0,t1;

   ws = (struct WaveformSource *) arg;

   t0 = (int) sven_get_timestamp();
   
   while ( ! ws->ws_svenlog_thread_quit_request )
   {
      svenlog_CaptureRealTimeEvents_Locally( ws->ws_svenlog );

      t1 = (int) sven_get_timestamp();

      /* we've crossed from negative to positive
       * this will happen about once an hour for a 1usec timestamp
       */
      if ( (t0 < 0) && (t1 >= 0) )
      {
         if ( svenlog_IsCapturePaused( ws->ws_svenlog ) )
         {
            ws->ws_svenlog_time_wraps++;
         }
      }
      t0 = t1;

      usleep( 8 * 1000 ); /* 8 milliseconds */
   }

   return(NULL);
}

/** Create a WaveSource */
struct WaveformSource *wavesource_Create(
    int                      unit,
    unsigned long            bar_pa,
    unsigned long            bar_size )
{
    struct WaveformSource     *ws;

#ifdef SELF_TEST
    if ( NULL != (ws = calloc(1,sizeof(*ws))) )
#else
    if ( NULL != (ws = OS_ALLOC(sizeof(*ws))) )
#endif
    {
        pal_result_t       pal_result;
        pal_soc_info_t     pal_soc_info;
        char        ok = 0;
        int         i;

        memset(ws,0,sizeof(*ws));

        /* Enable All */
        for ( i = 0; i < OMAR_HW_ENABLES_NUM_DWORDS; i++ )
        {
            ws->ws_enable[i] = 0xffffffff;
        }

        waveformdata_Init( &ws->wd );

        ws->ws_svenlog_size = (2 * 1024 * 1024);
        ws->ws_capture_clock_frequency = GEN4_OMAR_HW_COUNTDOWN_FREQ;

        /* Determine if we are on gen3 or 4.  Used to adjust timestamp_freq */
        pal_result = pal_get_soc_info(&pal_soc_info);
        if ( pal_result == PAL_SUCCESS )
        {
           if ( SOC_GENERATION_3 == pal_soc_info.generation )
           {
              ws->ws_capture_clock_frequency = GEN3_OMAR_HW_COUNTDOWN_FREQ;
           }
        }
        
        
#ifndef SELF_TEST
        if ( NULL != (ws->ws_devh = devhandle_factory(NULL)) )
        {
            if ( bar_pa )   /* Physical address already specified */
            {
                if ( ! bar_size )
                    bar_size = 0x00010000;

                if ( devhandle_connect_physical_address( ws->ws_devh, bar_pa, bar_size ) )
                {
                    ok = 1;
                    /* Set the Device Handle Type */
                    devh_SVEN_SetModuleUnit( ws->ws_devh, SVEN_module_GEN3_DFX, unit );
                }
            }
            else
            {
                if ( devhandle_connect_name( ws->ws_devh, "DFX" ) )
                {
                    int                  omar_pa,omar_size;
                    void                *mapped_buf;

                    ok = 1;

                    omar_pa = omar_size = 0;
#if 1
                    if ( (0 == config_get_int( ROOT_NODE,
                            CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".omar_buf.base",
                            &omar_pa )) &&
                         (0 == config_get_int( ROOT_NODE,
                            CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".omar_buf.size",
                            &omar_size )) )
                    {
                    }
                    else
                    {
                        printf("ERR: Could not find OMAR capture buffer in platform config\n");
                    }
#endif

                    if ( (0 == omar_pa) || (0 == omar_size) )
                    {
                        omar_pa = 0x0;              /* Phys addr 0 on SLE */
                        omar_size = (256 * 1024);  /* One megabyte */
                    }

                    mapped_buf = OS_MAP_IO_TO_MEM_NOCACHE( omar_pa, omar_size );

                    if ( NULL != mapped_buf )
                    {
                        ws->ws_capture_buf_pa = omar_pa;

                        #ifndef ALL_OMAR_ENABLES_WORK
                        /* Through experimentation, these are the units to never turn on on gen3 A0*/
                        ws->ws_enable[0] &= 0xfeffffff; /* TVENC_1 */
                        ws->ws_enable[1] &= 0xfffffffe; /* PCIe-0 */
                        //ws->ws_enable[0] &= 0xfe7dff9f;
                        //ws->ws_enable[1] &= 0xc7fffffe;
                        #endif
                        
                        ws->ws_capture_period = (ws->ws_capture_clock_frequency / 10);   /* 10 Hz */
                        ws->wd.wd_sample_buffer = ws->ws_capture_buf_ptr = mapped_buf;
                        ws->ws_capture_buf_size = omar_size;
                        ws->ws_capture_buf_mapped = 1;

                        printf("OMAR: Capture pa: %08lx siz: %08lx @ virt: %p\n",
                            ws->ws_capture_buf_pa,
                            ws->ws_capture_buf_size,
                            ws->ws_capture_buf_ptr );

                        /* Copy the enable bits to the data analyzer section */
                        memcpy( ws->wd.wd_enable, ws->ws_enable, sizeof( ws->wd.wd_enable ) );

                        /* Copy our "temporary" params between Start/Stop capture */
                        ws->wd.wd_interval_countdown    = ws->ws_capture_period;
                        ws->wd.wd_buffer_size           = ws->ws_capture_buf_size;
                        ws->wd.wd_hilo_swap             = ws->ws_hilo_swap;
                        ws->wd.wd_block_swap            = ws->ws_block_swap;
                        ws->wd.wd_mux_select            = ws->ws_mux_select;
                        ws->wd.wd_starting_burst        = 0;

                        /* Have OMAR Calculate various byte offsets, sizes, names, etc */
                        waveformdata_RethinkNewEnables( &ws->wd );


                        printf("OMAR: burst/buf %d burst/samp %d Byte/samp %d\n",
                            ws->wd.wd_bursts_per_buffer,
                            ws->wd.wd_bursts_per_sample,
                            ws->wd.wd_bytes_per_sample );
                    }
                } else printf("Could not find DFX Unit\n");
            }

            if ( !ok )
            {
                /* Just randomize */
                devh_SVEN_SetModuleUnit( ws->ws_devh, SVEN_module_GEN3_DFX, unit );
                ws->ws_hardware_not_present = 1;
                ok = 1;
            }

            if ( ok )
            {
                ok = 0;
                ws->wd.wd_interval_countdown = (2*2*3*3*5*7); /* to prevent DIV0 */
                if ( ! waveformdata_MakeFakeSignalNames( &ws->wd ) )
                {
                    ok = 1;
                }
            }

        }
#else
        ws->wd.wd_interval_countdown = (2*2*3*3*5*7); /* to prevent DIV0 */
        if ( ! waveformdata_MakeFakeSignalNames( &ws->wd ) )
        {
            ok = 1;
        }
#endif

        /* Connect sven stuff */
        if ( ok )
        {
            ok = 0;
            if ( NULL != (ws->ws_svenhdr = sven_open_header()) )
            {
                if ( NULL != (ws->ws_svenreverse = svenreverse_Create( ws->ws_svenhdr )) )
                {
                    if ( NULL != (ws->ws_svenlog = svenlog_Create(ws->ws_svenhdr, ws->ws_svenlog_size )) )
                    {
                       svenlog_Pause( ws->ws_svenlog );

                       /* Create SVENLog Thread */
                       if ( ! os_thread_create(&ws->ws_svenlog_thread,
                                               wavesource_svenlog_threadproc,
                                               ws,
                                               0,
                                               0,
                                               NULL)  )
                       {
                           ws->ws_svenlog_thread_created = 1;
                           ok = 1;
                       }
                    }
                }
            }
        }


        if ( !ok )
        {
            wavesource_Delete( ws );
            ws = NULL;
        }
    }
    return( ws );
}

/*******************************************************************
    Function that the returns the size of "svenlog.bin" file
********************************************************************/
unsigned long wavesource_Get_SvenlogFileSize(
      const char              *filename )
{
   unsigned long                 size = 0;
   FILE                          *fp;
   if ( NULL != (fp = fopen( filename, "rb" )) )
   {
      /* Seek to end of file */
      fseek(fp, 0, SEEK_END);

      /* Get current file pointer */
      size = ftell(fp);

      fclose(fp);
   }
   return size;
}

/*****************************************************************
    Function that modifies the size of the local svenlog
*****************************************************************/
void wavesource_Resize_Local_Svenlog(
      struct WaveformSource   *ws,
      unsigned long            size )
{
   int                            ok = 0;
   unsigned long                  svenlog_size;

   svenlog_size = ws->ws_svenlog_size;

   if (size > (2 * 1024 * 1024))
   {
      size /= (1024 * 1024);

      /* The buffer size has to be a power of 2 . This works for all cases.
       * WARNING - If input is 0 then the size returned will also be 0 . But
       * care is taken to ensure that minimum svenlog size will always be 2  MB */
      size = NEXTPOWEROF2(size);

      svenlog_size = size * 1024 * 1024;
   }
   else
   {
      /* Default svenlog size */
      svenlog_size = 2 * 1024 * 1024;
   }

   if (svenlog_size != ws->ws_svenlog_size)
   {
      ws->ws_svenlog_size = svenlog_size;

      if ( ! svenlog_IsCapturePaused( ws->ws_svenlog ) )
      {
         /* pause sven recording */
         svenlog_Pause( ws->ws_svenlog );
      }

      if ( NULL != ws->ws_svenlog )
      {
         svenlog_Delete( ws->ws_svenlog );
         ws->ws_svenlog = NULL;
      }

      if ( NULL != (ws->ws_svenlog = svenlog_Create(ws->ws_svenhdr, ws->ws_svenlog_size )) )
      {
         ok = 1;
      }
   }
}
/*****************************************************************
    Function that finds the length of the longest string (signal name) in Waveform
    view.
******************************************************************/

void wavesource_FindMaxStringLength(struct WaveformSource   *ws,unsigned int* pMaxLength )
{
unsigned int i,len;

    for(i=0;i<ws->ws_num_traces;i++)
        {
            len = strlen (wavesource_GetTraceName( ws,i));
            if ( len> (*pMaxLength) )
            {
            *pMaxLength=len;
            }
        }
}


/** How many different "traces" were captured (vertical) */
int wavesource_GetNumTraces(
    struct WaveformSource   *ws )
{
    return( ws->ws_num_traces);
}
/** How many different "traces" were captured (vertical) */
int wavesource_GetNum_HW_Signals(
    struct WaveformSource   *ws )
{
    return( waveformdata_GetNumOfHWSignalsCaptured( &ws->wd ) );
}

int wavesource_HW_CheckNewsamplesAvailable(
    struct WaveformSource   *ws,
    int                      pos )
{
    struct WaveformData *wd;
    struct OMARBurst    *burst;
    int                  samp,next_samp;
    int                  burst_pos;
    int                  hw_pos_has_changed = 0;

    if ( ws->ws_hardware_not_present )
    {
        return(1);
    }

    wd = &ws->wd;
    burst = (struct OMARBurst *)wd->wd_sample_buffer;
    burst_pos = (pos * wd->wd_bursts_per_sample) % ws->wd.wd_bursts_per_buffer;
    samp = burst[burst_pos].hdr.hdr_sample; /* sample at first */

//    printf("[%d %p = %d %d %x]", burst_pos, &burst[burst_pos], burst[burst_pos].hdr.hdr_wrap, burst[burst_pos].hdr.hdr_burst, burst[burst_pos].hdr.hdr_sample );

    if ( ! ws->ws_capture_first_detected )
    {
        int         start_samp;

        next_samp = samp;
        start_samp = (ws->ws_capture_start_word & BMSK_DFX_OMAR_HEADER_WORD_HDR_SAMP) >>
                        BLSB_DFX_OMAR_HEADER_WORD_HDR_SAMP;

        if ( ((samp - start_samp) >= 0) &&
             ((samp - start_samp) <= wd->wd_sample_skip_tolerance) )
        {
            ws->ws_capture_first_detected = 1;
            hw_pos_has_changed = 1;

//            printf("first %08x -> %08x\n", start_samp, samp );
        }
        else
        {
//            printf("waiting-for-first-sample.. %08x %08x\n", start_samp, samp );
        }
    }
    else
    {
        /* next candidate burst */
        burst_pos += ws->wd.wd_bursts_per_sample;
        burst_pos %= ws->wd.wd_bursts_per_buffer;

        /* read the sample number digitized here */
        next_samp = burst[burst_pos].hdr.hdr_sample;

        /* is next sample difference small (will always == 1 unless capture interval is too fast) */
        if ( ((next_samp - samp) > 0) &&
             ((next_samp - samp) <= wd->wd_sample_skip_tolerance) )
        {
            hw_pos_has_changed = 1;
//            printf("[%d %p = %d %d %x]", burst_pos, &burst[burst_pos], burst[burst_pos].hdr.hdr_wrap, burst[burst_pos].hdr.hdr_burst, burst[burst_pos].hdr.hdr_sample );
        }
        else
        {
//            printf("(%d %p = %d %d %x)", burst_pos, &burst[burst_pos], burst[burst_pos].hdr.hdr_wrap, burst[burst_pos].hdr.hdr_burst, burst[burst_pos].hdr.hdr_sample );
        }
    }

    if ( ! ws->ws_hardware_not_present )
    {
        //unsigned int         hwsamp,hwpos;

        /* Hardware time */
        //hwsamp = DEVH_READ_BITFIELD( ws->ws_devh, BITFIELD_DFX_OMAR_HEADER_WORD_HDR_SAMP );
        //hwpos = devh_ReadReg32( ws->ws_devh, ROFF_DFX_OMAR_CAP_CUR_PTR );

//        printf("NewsamplesAvailable(%x) = %x [%x %x] [%08x %08x]\n", pos, hw_pos_has_changed, samp, next_samp, hwsamp, hwpos  );
    }

    return(hw_pos_has_changed);
}

int wavesource_HW_GetCurrentCapturePos(
    struct WaveformSource   *ws,
    int                     *ppos )
{
    struct WaveformData *wd;
    struct OMARBurst    *burst;
    int                  samp;
    int                  next_samp;
    int                  burst_pos;
    int                  number_of_samples = 0;
    unsigned int         first_hdr,last_hdr,next_hdr;

    if ( ws->ws_hardware_not_present )
    {
        *ppos += 1;
        return( *ppos );
    }

    // TODO:  Track capturing hardware, following "seam" in capture buffer

    wd = &ws->wd;
    burst = (struct OMARBurst *)wd->wd_sample_buffer;
    burst_pos = (*ppos * wd->wd_bursts_per_sample) % ws->wd.wd_bursts_per_buffer;
    first_hdr = burst[burst_pos].hdr.hdr;
    last_hdr = first_hdr;
    samp = first_hdr & OMAR_BURST_HEADER_SAMPLE_MASK;

    //printf("[%d = %d %d %x]", burst_pos, burst[burst_pos].hdr.hdr_wrap, burst[burst_pos].hdr.hdr_burst, burst[burst_pos].hdr.hdr_sample );

    while ( 1 )
    {
        /* read the sample number digitized here */
        burst_pos += ws->wd.wd_bursts_per_sample;
        burst_pos %= ws->wd.wd_bursts_per_buffer;
        next_hdr = burst[burst_pos].hdr.hdr;
        next_samp = next_hdr & OMAR_BURST_HEADER_SAMPLE_MASK;

        /* is next sample difference small (will always == 1 unless capture interval is too fast) */
        if ( ((next_samp - samp) > 0) &&
             ((next_samp - samp) <= wd->wd_sample_skip_tolerance) )
        {
            number_of_samples++;

            //printf("[%d = %d %d %x]", burst_pos, burst[burst_pos].hdr.hdr_wrap, burst[burst_pos].hdr.hdr_burst, burst[burst_pos].hdr.hdr_sample );
        }
        else
        {
            //printf("(%d = %d %d %x)", burst_pos, burst[burst_pos].hdr.hdr_wrap, burst[burst_pos].hdr.hdr_burst, burst[burst_pos].hdr.hdr_sample );
            break;
        }

        samp = next_samp;
        last_hdr = next_hdr;
    }

    // WARNING: do NOT update waveformdata seam position
   devh_SVEN_WriteModuleEvent( ws->ws_devh, 128,
      *ppos,
      (burst_pos >> 1) | ((burst_pos & 1) << 31),
      (wd->wd_bursts_per_sample << 16) | number_of_samples,
      last_hdr - first_hdr,
      first_hdr,
      last_hdr );

    if ( number_of_samples )
        *ppos += number_of_samples;

//        *ppos = (burst_pos-1) / ws->wd.wd_bursts_per_sample;


    return(number_of_samples);
}

void wavesource_HW_DebugCaptureBuffer(
    struct WaveformSource   *ws,
    int                      pos,
    int                      siz )
{
    struct WaveformData *wd;
    struct OMARBurst    *burst;

    // TODO:  Track capturing hardware, following "seam" in capture buffer

    wd = &ws->wd;
    burst = (struct OMARBurst *)wd->wd_sample_buffer;

    while ( siz-- )
    {
        printf("[%d %d %6x]", burst[pos].hdr.hdr_wrap, burst[pos].hdr.hdr_burst, burst[pos].hdr.hdr_sample );
        pos++;

        if ( 0 == (pos & 0x1) )
            printf("\n");
    }
    printf("\n");
}

void wavesource_GetHiResClockFreq(
    struct WaveformSource   *ws,
    long long               *phclk )
{
   UNUSED_PARAMETER(ws);

   *phclk = ws->ws_capture_clock_frequency;
}

/** What is the name of signal N */
const char *wavesource_GetTraceName(
    struct WaveformSource   *ws,
    int                     sig )
{
    if((unsigned int)sig < ws->ws_num_traces)
    {
        return ws->ws_traces[sig].pub.label;
    }

    return NULL;
}

/** What is the name of signal N */
const char *wavesource_Get_HW_SignalName(
    struct WaveformSource   *ws,
    int                     sig )
{
    return( waveformdata_GetHWSignalName( &ws->wd, sig ) );
}

/** What is the name of the group this signal is in */
int wavesource_GetSignalGroup(
    struct WaveformSource   *ws,
    int                      sig )
{
   UNUSED_PARAMETER(ws);
    return(sig / OMAR_HW_SAMPLES_PER_BLOCK);
}

/** What is the name of signal N */
const char *wavesource_GetGroupName(
    struct WaveformSource   *ws,
    int                     group )
{
    const char        *retval = "---";

    if ( (group >= 0) && (group < OMAR_HW_MAX_BLOCKS) )
    {
        if ( NULL == (retval = ws->wd.wd_block_name[group]) )
        {
            retval = "grp";
        }
    }

    return(retval);
}

/** How long is the trace, in high resolution clocks */
long long wavesource_GetDuration(
    struct WaveformSource   *ws )
{
   long long               t1;
   unsigned int omar_clk_div , sven_clk_div;
   long long sven_interval , omar_interval;

   omar_clk_div = ws->wd.wd_interval_countdown;
   sven_clk_div = ws->ws_capture_clock_frequency / sven_get_timestamp_frequency();
   sven_interval = ((ws->ws_lastsven_timestamp-ws->ws_firstsven_timestamp));
   omar_interval = ((ws->wd.wd_bursts_captured /2) * (omar_clk_div/sven_clk_div));

   if (1 != ws->ws_svenlog_load_enabled)
   {
      if((omar_interval > sven_interval) || (ws->wd.wd_bursts_captured < (ws->wd.wd_samples_per_buffer << 1)))
      {
         t1 = (long long)(ws->wd.wd_bursts_captured/2)*(long long)omar_clk_div;
      }
      else
      {
         t1  = (long long)(ws->ws_omar_offset  * ws->wd.wd_samples_per_buffer) * (long long)omar_clk_div;
      }
   }
   else
   {
      t1 = (long long)(ws->ws_capture_stop_timestamp  - ws->ws_capture_start_timestamp)*(long long)sven_clk_div;
   }
   return t1;
}

/* OMAR Burst Memory Object DWORDS
    Number of DWORDS    Contents
    1                   "Burst Object" Header

    16                  OMAR Signals "Current Value"
0   16                  OMAR Signals LSB "Counter Value"
    16                  OMAR Signals MSB "Counter Value"

    16                  OMAR Signals "Current Value"
1   16                  OMAR Signals LSB "Counter Value"
    16                  OMAR Signals MSB "Counter Value"

    16                  OMAR Signals "Current Value"
2   16                  OMAR Signals LSB "Counter Value"
    16                  OMAR Signals MSB "Counter Value"
*/

/* Create Bitfield:
 *  +-----+-----+-----+-----+
 *  | pv  | cv  |  n_edges  |
 *  +-----+-----+-----+-----+
 */
static const enum WaveSourceSampleShape omar_shape_lookup[16] = {
/* 0 0 00 = ____ */             WSSV_0,             /* ___ */
/* 0 0 01 = _XX_ PARADOX */     WSSV_hi_pulse,      /* _-_ */
/* 0 0 10 = _--_ */             WSSV_hi_pulse,      /* _-_ */
/* 0 0 11 = _XX_ SATURATION */  WSSV_fast_lo,       /* ==_ */
/* 0 1 00 = _XX- PARADOX */     WSSV_0_to_1,        /* _-- */
/* 0 1 01 = ___- */             WSSV_0_to_1,        /* _-- */
/* 0 1 10 = _==- PARADOX */     WSSV_fast_hi,       /* ==- */
/* 0 1 11 = _XX- SATURATION */  WSSV_fast_hi,       /* ==- */
/* 1 0 00 = ---_ PARADOX */     WSSV_1_to_0,        /* -__ */
/* 1 0 01 = ---_ */             WSSV_1_to_0,        /* -__ */
/* 1 0 10 = _XX_ PARADOX */     WSSV_fast_lo,       /* ==_ */
/* 1 0 11 = -XX_ SATURATION  */ WSSV_fast_lo,       /* ==_ */
/* 1 1 00 = ---- */             WSSV_1,             /* --- */
/* 1 1 01 = -XX- PARADOX*/      WSSV_lo_pulse,      /* -_- */
/* 1 1 10 = _XX- */             WSSV_fast_hi,       /* ==- */
/* 1 1 11 = -XX- SATURATION */  WSSV_fast_hi        /* ==- */
};

enum WaveSourceSampleShape wavesource_GetOmarShape(
    struct WaveformSource *ws,
    unsigned int sig, int t0, int t1)
{
   struct OMARBurst *prev, *cur;
   unsigned int packet_offset;
   unsigned int wavebits;
   unsigned int sigmask;
   unsigned int omar_clk_div , sven_clk_div;
   long long sven_interval , omar_interval;
   int flag = 0;

   omar_clk_div = ws->wd.wd_interval_countdown;
   sven_clk_div = ws->ws_capture_clock_frequency / sven_get_timestamp_frequency();

   sven_interval = (ws->ws_lastsven_timestamp-ws->ws_firstsven_timestamp);
   omar_interval = ((ws->wd.wd_bursts_captured /2) * (omar_clk_div/sven_clk_div));

   /* Display omar shapes outside of our window as a flat */
   if((omar_interval > sven_interval) || (ws->wd.wd_bursts_captured < (ws->wd.wd_samples_per_buffer << 1)))
   {
      if (t0 > (int)(ws->wd.wd_bursts_captured / 2))
         flag = 1;
   }
   else
   {
      if ((t0 < (int)((ws->ws_omar_offset-1) * ws->wd.wd_samples_per_buffer)) || (t0 > (int)(ws->ws_omar_offset  * ws->wd.wd_samples_per_buffer)))
         flag = 1;
   }


   if (2 == ws->wd.wd_bursts_per_sample)
   {
      t0 <<= 1;
      t1 <<= 1;
      /* Go to the "odd" bursts */
      if (sig >= (32 * OMAR_HW_SAMPLES_PER_BLOCK))
      {
         t0++;
         t1++;
         sig -= (32 * OMAR_HW_SAMPLES_PER_BLOCK);
      }
   }

   /* Which DWORD in the OMARBurst contains this signal */
   packet_offset = sig & (OMAR_HW_SAMPLES_PER_BLOCK - 1);
   packet_offset *= 3;
   /* Divide, with unsigned should be shift */
   sigmask = 1 << (sig / OMAR_HW_SAMPLES_PER_BLOCK);

   if ((t1 - t0) <= (int) ws->wd.wd_bursts_per_sample)
   {
      waveformdata_SeekSample(&ws->wd, t1, &prev, &cur);

      /* Build wavebits */
      wavebits = (prev->data[packet_offset + 0] & sigmask) ? 0x8 : 0x0;
      wavebits |= (cur->data[packet_offset + 0] & sigmask) ? 0x4 : 0x0;
      wavebits |= (cur->data[packet_offset + 1] & sigmask) ? 0x1 : 0x0;
      wavebits |= (cur->data[packet_offset + 2] & sigmask) ? 0x2 : 0x0;
   }
   else
   {
      unsigned int transitions = 0;

      waveformdata_SeekSample(&ws->wd, t0, &prev, &cur);

      /* Build wavebits */
      wavebits = (prev->data[packet_offset + 0] & sigmask) ? 0x8 : 0x0;

      transitions += (cur->data[packet_offset + 1] & sigmask) ? 0x1 : 0x0;
      transitions += (cur->data[packet_offset + 2] & sigmask) ? 0x2 : 0x0;
      t0 += ws->wd.wd_bursts_per_sample; /* next sample */

      while (t0 != t1)
      {
         cur = waveformdata_SeekBurst(&ws->wd, t0);

         transitions += (cur->data[packet_offset + 1] & sigmask) ? 0x1 : 0x0;
         transitions += (cur->data[packet_offset + 2] & sigmask) ? 0x2 : 0x0;

         t0 += ws->wd.wd_bursts_per_sample; /* next sample */

         if (transitions > 2)
            break;
      }

      /* Exit state */
      cur = waveformdata_SeekBurst(&ws->wd, t1);

      wavebits |= (cur->data[packet_offset + 0] & sigmask) ? 0x4 : 0x0;

      transitions += (cur->data[packet_offset + 1] & sigmask) ? 0x1 : 0x0;
      transitions += (cur->data[packet_offset + 2] & sigmask) ? 0x2 : 0x0;

      wavebits |= (transitions > 2) ? 0x3 : transitions;
   }
   if ((1 == flag) || (1 == ws->ws_svenlog_load_enabled))
      wavebits = 0;

   return (omar_shape_lookup[wavebits]);
}
/** Get the value of the waveform at time T */
enum WaveSourceSampleShape wavesource_GetSampleShape(
    struct WaveformSource   *ws,
    unsigned int             sig,
    int                      t0,
    int                      t1 )
{
    struct OMARBurst            *prev,*cur;
    unsigned int                 packet_offset;
    unsigned int                 wavebits;
    unsigned int                 sigmask;

    /** TODO: Search forward "sample counter" >= (t1) in captured data to account
     * for missing samples in case OMAR Sample interval is too high.
     */

#ifndef SELF_TEST
    DEVH_ASSERT( ws->ws_devh, (t1-t0) > 0 );
    DEVH_ASSERT( ws->ws_devh, (unsigned int)(t1-t0) < ws->wd.wd_bursts_per_buffer );
#endif

    if ( 2 == ws->wd.wd_bursts_per_sample )
    {
        t0 <<= 1;
        t1 <<= 1;
        /* Go to the "odd" bursts */
        if ( sig >= (32 * OMAR_HW_SAMPLES_PER_BLOCK) )
        {
            t0++;
            t1++;
            sig -= (32 * OMAR_HW_SAMPLES_PER_BLOCK);
        }
    }

//#define TIMELINE_VIEW_DEBUG
#ifdef TIMELINE_VIEW_DEBUG
    /* insert a counter at block 0 */
    if ( sig < OMAR_HW_SAMPLES_PER_BLOCK )
    {
        /* convert time to wave shape */
        if ( 0 != (t1 & (1 << (sig & (OMAR_HW_SAMPLES_PER_BLOCK-1)))) )
        {
            return ( WSSV_1 );
        }
        else
        {
            return ( WSSV_0 );
        }
    }
#endif

    /* Which DWORD in the OMARBurst contains this signal */
    packet_offset = sig & (OMAR_HW_SAMPLES_PER_BLOCK - 1);
    packet_offset *= 3;
    /* Divide, with unsigned should be shift */
    sigmask = 1 << (sig / OMAR_HW_SAMPLES_PER_BLOCK);

#ifdef DEBUG_WAVESOURCE_SHAPE
    if ( (0 == t0) && (0 == t1) )
    {
        printf("%3d %08x ", packet_offset, sigmask );
    }
#endif

/* OMAR Burst Memory Object DWORDS
sig Number of DWORDS    Contents
-   1                   "Burst Object" Header

    16                  OMAR Signals "Current Value"
0   16                  OMAR Signals LSB "Counter Value"
    16                  OMAR Signals MSB "Counter Value"

    16                  OMAR Signals "Current Value"
1   16                  OMAR Signals LSB "Counter Value"
    16                  OMAR Signals MSB "Counter Value"

    16                  OMAR Signals "Current Value"
2   16                  OMAR Signals LSB "Counter Value"
    16                  OMAR Signals MSB "Counter Value"

    16                  OMAR Signals "Current Value"
3   16                  OMAR Signals LSB "Counter Value"
    16                  OMAR Signals MSB "Counter Value"
*/

    /* Create Bitfield:
     *  +-----+-----+-----+-----+
     *  | pv  | cv  |  n_edges  |
     *  +-----+-----+-----+-----+
     */
    if ( (t1-t0) <= (int) ws->wd.wd_bursts_per_sample )
    {
        waveformdata_SeekSample( &ws->wd, t1, &prev, &cur );

        /* Build wavebits */
        wavebits = (prev->data[ packet_offset + 0 ] & sigmask) ? 0x8 : 0x0;
        wavebits |= (cur->data[ packet_offset + 0 ] & sigmask) ? 0x4 : 0x0;
        wavebits |= (cur->data[ packet_offset + 1 ] & sigmask) ? 0x1 : 0x0;
        wavebits |= (cur->data[ packet_offset + 2 ] & sigmask) ? 0x2 : 0x0;
    }
    else
    {
        unsigned int            transitions = 0;

        waveformdata_SeekSample( &ws->wd, t0, &prev, &cur );

        /* Build wavebits */
        wavebits = (prev->data[ packet_offset + 0 ] & sigmask) ? 0x8 : 0x0;

        transitions += (cur->data[ packet_offset + 1 ] & sigmask) ? 0x1 : 0x0;
        transitions += (cur->data[ packet_offset + 2 ] & sigmask) ? 0x2 : 0x0;
        t0 += ws->wd.wd_bursts_per_sample;  /* next sample */

        while ( t0 != t1 )
        {
            cur = waveformdata_SeekBurst( &ws->wd, t0 );

            transitions += (cur->data[ packet_offset + 1 ] & sigmask) ? 0x1 : 0x0;
            transitions += (cur->data[ packet_offset + 2 ] & sigmask) ? 0x2 : 0x0;

            t0 += ws->wd.wd_bursts_per_sample;  /* next sample */

            if ( transitions > 2 ) break;
        }

        /* Exit state */
        cur = waveformdata_SeekBurst( &ws->wd, t1 );

        wavebits |= (cur->data[ packet_offset + 0 ] & sigmask) ? 0x4 : 0x0;

        transitions += (cur->data[ packet_offset + 1 ] & sigmask) ? 0x1 : 0x0;
        transitions += (cur->data[ packet_offset + 2 ] & sigmask) ? 0x2 : 0x0;

        wavebits |= (transitions > 2) ? 0x3 : transitions;
    }


    return( omar_shape_lookup[wavebits] );
}

unsigned int wavesource_GetBusValue(
    struct WaveformSource   *ws,
    unsigned int             sig,
    unsigned int             sig_width,
    int                      t0 )
{
    struct OMARBurst        *prev,*cur;
    unsigned int             sigmask;
    unsigned int             packet_offset;
    unsigned int             sig_bits;
    unsigned int             value = 0;

    if ( 2 == ws->wd.wd_bursts_per_sample )
    {
        t0 <<= 1;
        /* Go to the "odd" bursts */
        if ( sig >= (32 * OMAR_HW_SAMPLES_PER_BLOCK) )
        {
            t0++;
            sig -= (32 * OMAR_HW_SAMPLES_PER_BLOCK);
        }
    }

    /* Which DWORD in the OMARBurst contains this signal */
    packet_offset = sig & (OMAR_HW_SAMPLES_PER_BLOCK - 1);
    packet_offset *= 3;
    /* Divide, with unsigned should be shift */
    sigmask = 1 << (sig / OMAR_HW_SAMPLES_PER_BLOCK);
    sig_bits = sig_width;

    waveformdata_SeekSample( &ws->wd, t0, &prev, &cur );

    while ( sig_bits )
    {
        /* OMAR Burst Memory Object DWORDS
        sig Number of DWORDS    Contents
        -   1                   "Burst Object" Header

            16                  OMAR Signals "Current Value"
        0   16                  OMAR Signals LSB "Counter Value"
            16                  OMAR Signals MSB "Counter Value"

            16                  OMAR Signals "Current Value"
        1   16                  OMAR Signals LSB "Counter Value"
            16                  OMAR Signals MSB "Counter Value"

            16                  OMAR Signals "Current Value"
        2   16                  OMAR Signals LSB "Counter Value"
            16                  OMAR Signals MSB "Counter Value"

            16                  OMAR Signals "Current Value"
        3   16                  OMAR Signals LSB "Counter Value"
            16                  OMAR Signals MSB "Counter Value"
        */
        /* if this bit is set */
        if ( prev->data[ packet_offset + 0 ] & sigmask )
        {
            value |= 0x10000;   /* OR with 2^16 */
        }
        value >>= 1;  /* BUG: should shift down */

        sig++;
        sig_bits--;
        packet_offset += 3; /* move to next bit in block */
    }

    /* shift MSB down */
    value >>= 16 - sig_width;

    return(value);
}

/** Get the value of the waveform at time T */
enum WaveSourceSampleShape wavesource_GetBusShape(
    struct WaveformSource   *ws,
    unsigned int             sig,
    unsigned int             sig_width,
    int                      t0,
    int                      t1,
    unsigned int            *exit_value )
{
    enum WaveSourceSampleShape  retval = WSSV_hi_and_lo;
    unsigned int                busval0,busval1;

    if ( (t1-t0) <= (int) ws->wd.wd_bursts_per_sample )
    {
        busval0 = wavesource_GetBusValue( ws, sig, sig_width, t0 );

        if ( 0x00000000 == busval0 )
            retval = WSSV_0;
        else if ( (unsigned int)((1<<sig_width)-1) == busval0 )
            retval = WSSV_1;

        *exit_value = busval0;
    }
    else
    {
        busval0 = busval1 = wavesource_GetBusValue( ws, sig, sig_width, t0 );
        t0 += ws->wd.wd_bursts_per_sample;  /* next sample */

        while ( t0 != t1 )
        {
            busval1 = wavesource_GetBusValue( ws, sig, sig_width, t0 );

            t0 += ws->wd.wd_bursts_per_sample;  /* next sample */

            if ( busval1 ^ busval0 )
            {
                retval = WSSV_cross;
            }
        }

        *exit_value = busval1;
    }

    return( retval );
}


static int svenfilter_is_match(
    struct SVENFilter   *filter,
    struct SVENEvent    *ev )
{
#if ( 6 == SVEN_EVENT_PAYLOAD_NUM_UINTS )
    if ( (((int *)&filter->eq_ev)[0] ^ (((int *)ev)[0] & ((int *)&filter->and_ev)[0])) ||
         (((int *)&filter->eq_ev)[1] ^ (((int *)ev)[1] & ((int *)&filter->and_ev)[1])) ||
         (((int *)&filter->eq_ev)[2] ^ (((int *)ev)[2] & ((int *)&filter->and_ev)[2])) ||
         (((int *)&filter->eq_ev)[3] ^ (((int *)ev)[3] & ((int *)&filter->and_ev)[3])) ||
         (((int *)&filter->eq_ev)[4] ^ (((int *)ev)[4] & ((int *)&filter->and_ev)[4])) ||
         (((int *)&filter->eq_ev)[5] ^ (((int *)ev)[5] & ((int *)&filter->and_ev)[5])) ||
         (((int *)&filter->eq_ev)[6] ^ (((int *)ev)[6] & ((int *)&filter->and_ev)[6])) ||
         (((int *)&filter->eq_ev)[7] ^ (((int *)ev)[7] & ((int *)&filter->and_ev)[7])) )
    {
        return( 0 );
    }
    else
    {
        return( 1 );
    }
#else
    _TODO_FIX_TEMPLATE_FILTER_COMPARE_FUNCTION_;
    return(0);
#endif
}

static struct SVENEvent* svenlog_search_for_time(
    struct SVENFilter          *sven_filter,
    struct SVENEvent           *ev,
    unsigned int                event_interval,
    unsigned int                event_offset,
    int                         index_of_last_event)
{
   int low , high;
   int sven_t,i;
   int startidx=0, endidx=0;

   low = 0;
   high = index_of_last_event;

   /* Binary search on the input block of events */
   while (low <= high)
   {
      int middle = low + (high - low) / 2;

      /* Note that we are using a signed integer here . Necessary for the search */
      sven_t = ev[middle].se_timestamp - event_offset;

      if (sven_t > (int)event_interval)
         high = middle - 1;
      else if (sven_t < 0)
         low = middle + 1;
      else
      {
         /* Trace forward to find the events which lie with in the window */
         for (i = middle; i <= index_of_last_event; i++)
         {
            sven_t = ev[i].se_timestamp - event_offset;
            if ((unsigned int)sven_t <= event_interval)
               endidx = i;
            else
               break;
         }

         /* Trace back to find the events which lie with in the window */
         for (i = middle; i >= 0; i--)
         {
            sven_t = ev[i].se_timestamp - event_offset;
            if ((unsigned int)sven_t <= event_interval)
               startidx = i;
            else
               break;
         }

         /* Find the event which matches the trace type */
         for (i = startidx; i <= endidx; i++)
         {
            if (svenfilter_is_match(sven_filter, &ev[i]))
            {
               /* WARNING : Early return */
               return (&ev[i]);
            }
         }
         break;
      }
   }
   return (NULL);
}

static char gDescription[4096];

/** Get a text description  of the waveform at time T, primarily used by sven */
int wavesource_GetDescription(
    struct WaveformSource   *ws,
    char**                   ppDescription,
    unsigned int             trace_num,
    long long                t0,
    long long                t1 )
{

   *ppDescription = gDescription;
   gDescription[0] = '\0';

   if (trace_num < ws->ws_num_traces)
   {
      struct WaveTrace *wt;

      /* convert to (local to the trace) time scale */
      wt = &ws->ws_traces[trace_num];

      switch (wt->ttype)
      {
      case TRACE_TYPE_SVEN_FILTER:
      {
         struct SVENEvent *ev0, *ev1 , *ref_event;
         int nev0, nev1;
         unsigned int sven_t0, sven_dt;
         unsigned int sven_clk_div, omar_clk_div;
         unsigned int offset = 0, event_offset=0;
         long long sven_interval, omar_interval;
         int capture_start = 0;


         omar_clk_div = ws->wd.wd_interval_countdown;
         sven_clk_div = ws->ws_capture_clock_frequency / sven_get_timestamp_frequency();
         sven_interval = (ws->ws_lastsven_timestamp - ws->ws_firstsven_timestamp);
         omar_interval = ((ws->wd.wd_bursts_captured / 2) * (omar_clk_div / sven_clk_div));

         if (1 != ws->ws_svenlog_load_enabled)
         {

            if ((sven_interval < omar_interval) && (ws->wd.wd_bursts_captured
                  >= (ws->wd.wd_samples_per_buffer << 1)))
            {
               /* Take into account the time elapsed before the first capture has occurred in case of a wrap around */
               capture_start = (ws->ws_capture_stop_timestamp  - ws->ws_capture_start_timestamp - ((ws->wd.wd_samples_per_buffer + 1) * omar_clk_div  / sven_clk_div));

            }
            if ((omar_interval < sven_interval) && (ws->wd.wd_bursts_captured
                  >= (ws->wd.wd_samples_per_buffer << 1)))
            {
               /* Take into account the time elapsed before the first capture has occurred in case of a wrap around */
               capture_start = (ws->ws_capture_stop_timestamp  - ws->ws_capture_start_timestamp - sven_interval);

               /* Determine the omar waveform offset as a multiple of the total sven interval. Offset cannot be even */
               ws->ws_omar_offset  = ((sven_interval % omar_interval) == 0) ? (sven_interval / omar_interval): ((sven_interval / omar_interval) + 1);
               ws->ws_omar_offset  = ((ws->ws_omar_offset % 2) == 0) ? (ws->ws_omar_offset + 1) : ws->ws_omar_offset;

               /* Determine the sven waveform offset from zero . */
               offset = ((ws->ws_omar_offset * (ws->wd.wd_samples_per_buffer + 1) * omar_clk_div / sven_clk_div)) - sven_interval;
            }
         }

         /* calculate t0, t1 in sven time */
         sven_t0 = ws->ws_capture_start_timestamp + capture_start + (t0 / sven_clk_div);
         sven_dt = (unsigned int) ((t1 - t0) / sven_clk_div);
         event_offset = (sven_t0 - offset);

         sprintf(gDescription, "t0:%d sven_t0:%d sven_dt:%d sven_clk_div:%d\n",
               (int) (t0 / sven_clk_div), sven_t0, sven_dt, sven_clk_div);

         /* Get the "split" view of captured SVEN Events */
         svenlog_view_event_buffer(ws->ws_svenlog, &ev0, &nev0, &ev1, &nev1);

         /* Binary search on the first block of events */
         ref_event = svenlog_search_for_time( &wt->sven.filt ,&ev0[0], sven_dt, event_offset, nev0-1);

         if ( NULL != ref_event)
         {
            svenlog_GetEventTextString(ws->ws_svenlog, ref_event,
                  gDescription);
            return (1); /* WARNING: Early Return */
         }

         /* Binary search on the next block of events */
         ref_event = svenlog_search_for_time( &wt->sven.filt, &ev1[0], sven_dt, event_offset, nev1-1);

         if ( NULL != ref_event)
         {
            svenlog_GetEventTextString(ws->ws_svenlog, ref_event,
                  gDescription);
            return (1); /* WARNING: Early Return */
         }

         break;
      }
      default:
      {
         sprintf(gDescription, "Trace Number:%d Time T0:%lld T1:%lld dt:%lld",
               trace_num, t0, t1, t1 - t0);
      }
         break;
      }
   }

   return 1;

} /* wavesource_GetDescription() */

int wavesource_SelectReferenceEventAtTime(
    struct WaveformSource   *ws,
    unsigned int             trace_num,
    long long                t0,
    long long                t1 )
{
   int ok = 0;
   int first_sample, starting_burst;
   int capture_start = 0;
   first_sample = ws->wd.wd_first_sample_timestamp;
   starting_burst = ws->wd.wd_starting_burst_timestamp;

   if (trace_num < ws->ws_num_traces)
   {
      struct WaveTrace *wt;

      /* convert to (local to the trace) time scale */
      wt = &ws->ws_traces[trace_num];

      switch (wt->ttype)
      {
      case TRACE_TYPE_SVEN_FILTER:
      {
         struct SVENEvent *ev0 , *ev1;
         unsigned int sven_t0, sven_dt;
         unsigned int sven_clk_div;
         unsigned int omar_clk_div;
         long long sven_interval , omar_interval;
         unsigned int offset = 0;
         int nev0, nev1,i;

         omar_clk_div = ws->wd.wd_interval_countdown;
         sven_clk_div = ws->ws_capture_clock_frequency
               / sven_get_timestamp_frequency();

         sven_interval = ((ws->ws_lastsven_timestamp - ws->ws_firstsven_timestamp) * sven_clk_div);
         omar_interval = ((ws->wd.wd_bursts_captured  * omar_clk_div)/2);

         if (1 != ws->ws_svenlog_load_enabled)
         {

            if (( sven_interval < omar_interval) &&  (ws->wd.wd_bursts_captured >= (ws->wd.wd_samples_per_buffer << 1)))
            {
               /* Take into account the time elapsed before the first capture has occurred in case of a wrap around */
               capture_start = (ws->ws_capture_stop_timestamp - ws->ws_capture_start_timestamp - ((ws->wd.wd_samples_per_buffer + 1)  * omar_clk_div / sven_clk_div));

            }
            if (( omar_interval < sven_interval) && (ws->wd.wd_bursts_captured >= (ws->wd.wd_samples_per_buffer << 1)))
            {
               /* Take into account the time elapsed before the first capture has occurred in case of a wrap around */
               capture_start = (ws->ws_capture_stop_timestamp - ws->ws_capture_start_timestamp - sven_interval);

               /* Determine the omar waveform offset as a multiple of the total sven interval. Offset cannot be even */
               ws->ws_omar_offset = ((sven_interval % omar_interval) == 0) ? (sven_interval / omar_interval) : ((sven_interval / omar_interval)+1);
               ws->ws_omar_offset = ((ws->ws_omar_offset %2) == 0) ? (ws->ws_omar_offset + 1) : ws->ws_omar_offset;

               /* Determine the sven waveform offset from zero . */
               offset = ((ws->ws_omar_offset * (ws->wd.wd_samples_per_buffer + 1) * omar_clk_div / sven_clk_div)) -  sven_interval ;
            }
         }

         /* calculate t0, t1 in sven time */
         sven_t0 = ws->ws_capture_start_timestamp + capture_start + (t0 / sven_clk_div);
         sven_dt = (unsigned int) ((t1 - t0) / sven_clk_div);

         /* Get the "split" view of captured SVEN Events */
         svenlog_view_event_buffer( ws->ws_svenlog, &ev0, &nev0, &ev1, &nev1 );

         for ( i = 0; i < nev0; i++ )
         {
            if (svenfilter_is_match(&wt->sven.filt, &ev0[i]))
            {

               unsigned int sven_t;

               sven_t = ev0[i].se_timestamp - sven_t0 + offset; /* subtract from start of capture */

               /** Is the Event timestamp within our window? */
               /** Note we're using UNSIGNED integer to check for the window
                * intersection, which can be done with  single compare
                */
               if (sven_t <= sven_dt)
               {
                  ws->ws_reference_event = ev0[i];
                  ws->ws_reference_event_active = 1;
                  ok = 1;
                  break;
               }
            }
         }

         for ( i = 0; i < nev1; i++ )
         {
            if (svenfilter_is_match(&wt->sven.filt, &ev1[i]))
            {

               unsigned int sven_t;

               sven_t = ev1[i].se_timestamp - sven_t0 + offset; /* subtract from start of capture */

               /** Is the Event timestamp within our window? */
               /** Note we're using UNSIGNED integer to check for the window
                * intersection, which can be done with  single compare
                */
               if (sven_t <= sven_dt)
               {
                  ws->ws_reference_event = ev1[i];
                  ws->ws_reference_event_active = 1;
                  ok = 1;
                  break;
               }
            }
         }
      }

      default:
         break;
      }
   }

   if (!ok)
   {
      /* set ref event to all zeroes so no matching occurs */
      memset(&ws->ws_reference_event, 0, sizeof(ws->ws_reference_event));
      ws->ws_reference_event_active = 0;
   }

   return ok;
}

/* "Live-Wavesource" control APIs */
int wavesource_StartCapture(
    struct WaveformSource   *ws )
{
    int         err = 0;
#ifndef SELF_TEST
    if ( 0 == ws->ws_hardware_not_present )
    {
        int         i;

        /* Turn OFF the hardware */
        devh_AndBitsReg32( ws->ws_devh, ROFF_DFX_OMAR_CONTROL, ~BMSK_DFX_OMAR_CONTROL_ENABLE );
        ws->ws_hw_capture_enabled = 0;

        devh_WriteReg32( ws->ws_devh, ROFF_DFX_OMAR_CAP_BASE_ADDR, ws->ws_capture_buf_pa );
        devh_WriteReg32( ws->ws_devh, ROFF_DFX_OMAR_CAP_SIZE, ws->ws_capture_buf_size );
        devh_WriteReg32( ws->ws_devh, ROFF_DFX_OMAR_INTERVAL_COUNT, ws->ws_capture_period );

        /* Set Block Swaps */
        devh_WriteReg32( ws->ws_devh, ROFF_DFX_OMAR_HILO_SWAP, ws->ws_hilo_swap );
        devh_WriteReg32( ws->ws_devh, ROFF_DFX_OMAR_BLOCK_SWAP, ws->ws_block_swap );
        devh_WriteReg32( ws->ws_devh, ROFF_DFX_OMAR_BLOCK_MUX_SELECT, ws->ws_mux_select );

        for ( i = 0; i < OMAR_HW_ENABLES_NUM_DWORDS; i++ )
        {
            devh_WriteReg32( ws->ws_devh,
                ROFF_DFX_OMAR_UNIT_ENABLE_0 + (i<<2),
                ws->ws_enable[i] );
        }

        /* Grab starting conditions */
        ws->ws_capture_start_word = devh_ReadReg32( ws->ws_devh, ROFF_DFX_OMAR_HEADER_WORD );
        ws->ws_capture_start_timestamp = devh_ReadReg32( ws->ws_devh, ROFF_DFX_DBG_TIMESTAMP );
        ws->ws_capture_start_prescale = devh_ReadReg32( ws->ws_devh, ROFF_DFX_DBG_PRESCALE );

        ws->ws_capture_first_detected = 0;
        ws->ws_hw_capture_enabled = 1;
        /* Turn on the hardware */
        devh_OrBitsReg32( ws->ws_devh, ROFF_DFX_OMAR_CONTROL, BMSK_DFX_OMAR_CONTROL_ENABLE );

        ws->ws_svenlog_start_timestamp = ws->ws_capture_start_timestamp;
        svenlog_Run( ws->ws_svenlog ); /* allow sven recording */
        /* --------------------------------------------------------------------------- */

        /* Hardware capture now turned on, prepare the DATA Handle */

        /* --------------------------------------------------------------------------- */

        /* Copy the enable bits to the data analyzer section */
        memcpy( ws->wd.wd_enable, ws->ws_enable, sizeof( ws->wd.wd_enable ) );

        /* Copy our "temporary" params between Start/Stop capture */
        ws->wd.wd_interval_countdown    = ws->ws_capture_period;
        ws->wd.wd_buffer_size           = ws->ws_capture_buf_size;
        ws->wd.wd_hilo_swap             = ws->ws_hilo_swap;
        ws->wd.wd_block_swap            = ws->ws_block_swap;
        ws->wd.wd_mux_select            = ws->ws_mux_select;
        ws->wd.wd_starting_burst        = 0;
        ws->ws_svenlog_load_enabled = 0;
        ws->ws_firstsven_timestamp = 0;
        ws->ws_lastsven_timestamp = 0;
        /* Clear highlighted event */
        ws->ws_reference_event_active = 0;

        /* Have OMAR Calculate various byte offsets, sizes, names, etc */
        waveformdata_RethinkNewEnables( &ws->wd );

//printf("OMAR Capture Started: sw: %08x ts: %08x tp: %08x\n",ws->ws_capture_start_word, ws->ws_capture_start_timestamp, ws->ws_capture_start_prescale );
    }
#endif /* SELF_TEST */


    return(err);
}

int wavesource_StopCapture(
    struct WaveformSource   *ws )
{
   struct SVENEvent               ev;

   /* HALT Now */
   if ( ! svenlog_IsCapturePaused( ws->ws_svenlog ) )
   {
      svenlog_Pause( ws->ws_svenlog ); /* allow sven recording */
   }

#ifndef SELF_TEST
   /* Turn OFF the hardware */
   if ( 0 == ws->ws_hardware_not_present )
   {
      if ( ws->ws_hw_capture_enabled )
      {
         devh_AndBitsReg32( ws->ws_devh, ROFF_DFX_OMAR_CONTROL, ~BMSK_DFX_OMAR_CONTROL_ENABLE );
         ws->ws_capture_stop_word = devh_ReadReg32( ws->ws_devh, ROFF_DFX_OMAR_HEADER_WORD );
         ws->ws_capture_stop_timestamp = devh_ReadReg32( ws->ws_devh, ROFF_DFX_DBG_TIMESTAMP );
         ws->ws_hw_capture_enabled = 0;
      }
   }
#endif

   wavesource_GetDuration(ws);
   /* Calculate Time Represented for waveform view */

   svenlog_RewindLocalEventReader( ws->ws_svenlog, 0 );
   if ( svenlog_ReadNextLocalEvent( ws->ws_svenlog, &ev ) )
   {
      int         t0,t1;

      ws->ws_svenlog_time_wraps = 0;

      t0 = (int) ev.se_timestamp;
      while ( svenlog_ReadNextLocalEvent( ws->ws_svenlog, &ev ) )
      {
         t1 = (int) ev.se_timestamp;
         ws->ws_svenlog_stop_timestamp = ev.se_timestamp;

         if (( ev.se_timestamp >= ws->ws_capture_start_timestamp) && (ev.se_timestamp <= ws->ws_capture_stop_timestamp))
         {
            /* Initialize the first and last timestamps */
            if ((ws->ws_firstsven_timestamp == 0) || (ws->ws_lastsven_timestamp == 0))
            {
               ws->ws_firstsven_timestamp = ws->ws_lastsven_timestamp = ev.se_timestamp;
            }
            else
            {
               if (ev.se_timestamp < ws->ws_firstsven_timestamp)
               {
                  ws->ws_firstsven_timestamp = ev.se_timestamp;
               }
               if (ev.se_timestamp > ws->ws_lastsven_timestamp )
               {
                  ws->ws_lastsven_timestamp  = ev.se_timestamp;
               }
            }

         }
         /* Zero Crossing */
         if ( (t0 < 0) && (t1 > 0) )
         {
            ws->ws_svenlog_time_wraps++;
         }
         t0 = t1;
      }
      ws->ws_svenlog_stop_timestamp = ws->ws_lastsven_timestamp;
   }
   waveformdata_FindCaptureSeam( &ws->wd, &ws->wd.wd_starting_burst );
   waveformdata_FindBurstCount( &ws->wd, &ws->wd.wd_bursts_captured );

#ifdef SELF_TEST

   uint64_t sven_interval , omar_interval;
   unsigned int          last_sample;
   unsigned int sven_clk_div , omar_clk_div;
   int                     capture_start;
   unsigned int sven_t0;

   if( ws->wd.wd_bursts_captured < (ws->wd.wd_samples_per_buffer<<1))
   {
      last_sample = ws->wd.wd_bursts_captured;
   }
   else
      last_sample = ((ws->wd.wd_starting_burst - 1) < 0) ? (ws->wd.wd_samples_per_buffer<<1) : (ws->wd.wd_starting_burst - 1);

   capture_start = 0;
   omar_clk_div = ws->wd.wd_interval_countdown;
   sven_clk_div = ws->ws_capture_clock_frequency / sven_get_timestamp_frequency();
   printf("\n Bursts captured = %d", ws->wd.wd_bursts_captured);
   printf("\n last sample = %d , starting burst = %d", last_sample, ws->wd.wd_starting_burst);
   printf("\n sven_clk_div = %d", sven_clk_div);
   printf("\n omar_clk_div = %d", omar_clk_div);
   printf("\n omar starting burst time stamp = %d",ws->wd.wd_starting_burst_timestamp );
//   printf("\n omar_first sample timestamp = %d" , ws->wd.wd_first_sample_timestamp);
   printf("\n sven last sample timestamp  = %d, sven first sample timestamp = %d",ws->ws_lastsven_timestamp,ws->ws_firstsven_timestamp);
   printf("\n capture start timestamp = %d , capture stop timestmap = %d" , ws->ws_capture_start_timestamp,ws->ws_capture_stop_timestamp);

  // printf("\n capture start = %d", capture_start);
   //printf("\n sven_t0 = %d",(ws->ws_capture_start_timestamp + capture_start));
   sven_interval = (ws->ws_lastsven_timestamp-ws->ws_firstsven_timestamp) ;
   omar_interval = ((ws->wd.wd_bursts_captured /2) * (omar_clk_div / sven_clk_div ));
   printf("\n sven_interval = %lld , omar_interval = %lld ",sven_interval,omar_interval);
   printf("\n time sven = %lld time omar = %lld ", (uint64_t)(sven_interval/1000),  (uint64_t)(omar_interval/1000));
   printf("\n");
#endif

   return(0);
}

/** Calibrates to connected devices
 */
int wavesource_SelfCalibrate(
    struct WaveformSource   *ws )
{
    int         err = 0;
#ifndef SELF_TEST
    if ( 0 == ws->ws_hardware_not_present )
    {
        unsigned int    good_e0,good_e1;
        int             enable_bit,capture_was_enabled;
        unsigned int    previous_interval;

        previous_interval = ws->ws_capture_period;

        if ( 0 != (capture_was_enabled = ws->ws_hw_capture_enabled) )
        {
            wavesource_StopCapture( ws );
        }

        good_e0 = good_e1 = 0;

        ws->ws_capture_period = ws->ws_capture_clock_frequency / 1000;  /* 1 millis */

        for ( enable_bit = 0; enable_bit < 64; enable_bit++ )
        {
            unsigned int      e0,e1;
            int               timeout;

            if ( enable_bit < 32 )
            {
                e0 = good_e0 | (1<<enable_bit);
                e1 = good_e1;
            }
            else
            {
                e0 = good_e0;
                e1 = good_e1| (1<<(enable_bit-32));
            }

            wavesource_SetProperty( ws, "enable.0", e0 );
            wavesource_SetProperty( ws, "enable.1", e1 );

            wavesource_StartCapture( ws );
            {
                int             pos,hdr;
                int             hpos;

                pos = 0;
                wavesource_GetProperty( ws, "capture.hdr", &hdr );
                wavesource_GetProperty( ws, "capture.pos", &pos );
                hpos = pos;
                //printf("%2d: enable: 0x%08x-%08x hdr: %08x pos %08x :: \"%s\"\n", enable_bit, e1, e0, hdr, hpos, wavesource_GetGroupName(ws,enable_bit) );

                timeout = 10;
                while ( (hpos - pos) < 1024  )   /* capture at least one kbyte */
                {
                    usleep(4000);
                    wavesource_GetProperty( ws, "capture.hdr", &hdr );
                    wavesource_GetProperty( ws, "capture.pos", &hpos );
                    //printf("%2d: enable: 0x%08x-%08x hdr: %08x pos %08x :: \"%s\"\n", enable_bit, e1, e0, hdr, hpos, wavesource_GetGroupName(ws,enable_bit) );

                    if ( (hpos - pos) > 1024  )   /* capture at least one kbyte */
                    {
                        good_e0 |= e0;
                        good_e1 |= e1;
                    }

                    if ( ! --timeout )   break;
                }
            }
            wavesource_StopCapture( ws );
        }

        ws->ws_capture_period = previous_interval;
        wavesource_SetProperty( ws, "enable.0", good_e0 );
        wavesource_SetProperty( ws, "enable.1", good_e1 );
        if ( capture_was_enabled )
        {
            wavesource_StartCapture( ws );
        }

        printf("DONE: enable_0: 0x%08x enable_1: 0x%08x :: ", good_e0, good_e1 );

        {
         int   i;
         for ( i = 0; i < 64; i++ )
         {
            if ( i < 32 )
            {
               if ( ! (good_e0 & (1<<i)) )
               {
                  if ( NULL != ws->wd.wd_block_name[i] )
                     printf("!%s ", ws->wd.wd_block_name[i] );
                  else
                     printf("!block_%d ", i );
               }
            }
            else
            {
               if ( ! (good_e1 & (1<<(i-32))) )
               {
                  if ( NULL != ws->wd.wd_block_name[i] )
                     printf("!%s ", ws->wd.wd_block_name[i] );
                  else
                     printf("!block_%d ", i );
               }
            }
         }
         printf("\n");
        }
    }
#endif
    return(err);
}

/** How often to capture new signals */
int wavesource_SetCaptureInterval(
    struct WaveformSource   *ws,
    unsigned int             hclks )
{
   printf("wavesource_SetCaptureInterval() %d -> %d\n", ws->ws_capture_period, hclks );

   ws->ws_capture_period = hclks;

   return(0);
}

/** How often to capture new signals */
unsigned int wavesource_GetCaptureInterval(
    struct WaveformSource   *ws )
{
     return(ws->wd.wd_interval_countdown);   /* Must get interval of data captured */
}

/** Get a wavesource property */
int wavesource_GetProperty(
    struct WaveformSource   *ws,
    const char              *property_name,
    int                     *property_value )
{
    int         err = 1;

    if ( ! strcasecmp( property_name, "capture.pos" ) )
    {
        if ( 0 == ws->ws_hardware_not_present )
        {
            *property_value = devh_ReadReg32( ws->ws_devh, ROFF_DFX_OMAR_CAP_CUR_PTR );
            err = 0;
        }
    }
    else if ( ! strcasecmp( property_name, "capture.hdr" ) )
    {
        if ( 0 == ws->ws_hardware_not_present )
        {
            *property_value = devh_ReadReg32( ws->ws_devh, ROFF_DFX_OMAR_HEADER_WORD );
            err = 0;
        }
    }

    return(err);
}

int wavesource_SetProperty(
    struct WaveformSource   *ws,
    const char              *property,
    int                      value )
{
    int         err = 1;

    if ( ! strcasecmp( property, "circbuf.pa" ) )
    {
        ws->ws_capture_buf_pa = value;
    }
    else if ( ! strcasecmp( property, "circbuf.virt" ) )
    {
        ws->wd.wd_sample_buffer = ws->ws_capture_buf_ptr = (void *)value;
    }
    else if ( ! strcasecmp( property, "circbuf.size" ) )
    {
        //if ( value && ws->ws_capture_buf_pa )
        //    wavesource_ReleaseCaptureBuffer( ws );

        ws->ws_capture_buf_size = value;
//printf("OMAR: Capture pa: %08x siz: %08x @ virt: %p\n", ws->ws_capture_buf_pa, ws->ws_capture_buf_size, ws->ws_capture_buf_ptr );
    }
    else if ( ! strcasecmp( property, "enable.0" ) )
    {
        ws->ws_enable[0] = value;
    }
    else if ( ! strcasecmp( property, "enable.1" ) )
    {
        ws->ws_enable[1] = value;
    }
    else if ( ! strcasecmp( property, "swap.hilo" ) )
    {
        ws->ws_hilo_swap = value;
    }
    else if ( ! strcasecmp( property, "swap.block" ) )
    {
        ws->ws_block_swap = value;
    }
    else if ( ! strcasecmp( property, "swap.mux" ) )
    {
        ws->ws_mux_select = value;
    }
    else
    {
        err = 0;
    }

    return(err);
}

int wavesource_PrepareFakeData(
    struct WaveformSource   *ws )
{
    int                      retval = 0;

    if ( ws->ws_hardware_not_present )
    {
        struct WaveformData     *wd;
        const char              *omar_filename = "omar_cap.bin";
        FILE                    *fp;
        #define OMAR_BUFSIZE    (512*1024)

        wd = &ws->wd;

        wavesource_ParseConfig( ws, NULL, 0 );

        /* How big does the buffer need to be */
        ws->ws_capture_buf_size = wd->wd_buffer_size = OMAR_BUFSIZE;
        ws->ws_capture_period   = ws->wd.wd_interval_countdown = (2*2*2*2*3*5*5);

        /* Free Previous */
        if ( NULL != wd->wd_sample_buffer )
        {
            free ( wd->wd_sample_buffer );
        }

        if ( NULL != (fp = fopen(omar_filename, "rb")) )
        {
            fseek( fp, 0, SEEK_END );

            ws->ws_capture_buf_size = wd->wd_buffer_size = ftell(fp);

            rewind(fp);

            if ( NULL != (wd->wd_sample_buffer = malloc(wd->wd_buffer_size)) )
            {
                printf("FAKE: Loading file \"%s\" size %d KB...", omar_filename, (wd->wd_buffer_size>>10)  );

                wavesource_SetProperty( ws, "enable.0", 0x1fbe019f );   /* TODO: SLE Enabled units only */
                wavesource_SetProperty( ws, "enable.1", 0xc6f0ff00 );   /* TODO: SLE Enabled units only */
                wavesource_SetProperty( ws, "swap.hilo", 0x00000000 );
                wavesource_SetProperty( ws, "swap.block", 0x00000000 );
                wavesource_SetProperty( ws, "swap.mux", 0x00000000 );

                /* Calculate new sizes, etc */
                waveformdata_RethinkNewEnables(wd);

                wavesource_StartCapture( ws );

                if ( wd->wd_buffer_size == fread( wd->wd_sample_buffer, 1, wd->wd_buffer_size, fp ) )
                {
                }
            }

            fclose(fp);
        }
        else
        {
            printf("ERR: Cannot open file \"%s\"...", omar_filename );
            retval = waveformdata_PrepareFakeData( &ws->wd, 1 );
        }

        printf("\n");
        wavesource_StopCapture( ws );
    }
    return(retval);
}

/** Rename a signal, signame passed into this is not required to be permanent */
int wavesource_Set_HW_SignalName(
    struct WaveformSource   *ws,
    int                      sig,
    const char              *signame )
{
    return( waveformdata_Set_HW_SignalName( &ws->wd, sig, signame, strlen(signame) ) );
}
#if 0
int wavesource_Set_HW_SignalName(
    struct WaveformSource   *ws,
    int                      sig,
    const char              *signame )
{
    return( waveformdata_Set_HW_SignalName( &ws->wd, sig, signame, strlen(signame) ) );
}
#endif

/** Eliminate traces
 */
int wavesource_FlushTraces(
    struct WaveformSource   *ws )
{
   /* Clear the traces by setting num_traces to zero  */
    ws->ws_num_traces = 0;
    return(0);
}

/**
 * Add a trace to the wavesource
 */
static struct WaveTrace *wavesource_AddTrace(
    struct WaveformSource   *ws )
{
    struct WaveTrace    *wt = NULL;

    if ( NULL == ws->ws_traces )    /* no trace array allocated yet */
    {
        #define WAVESOURCE_STARTING_NUM_TRACES  16
        if ( NULL != (ws->ws_traces = malloc(sizeof(struct WaveTrace) * WAVESOURCE_STARTING_NUM_TRACES)) )
        {
            ws->ws_max_traces = WAVESOURCE_STARTING_NUM_TRACES;

            ws->ws_num_traces = 1;
            wt = &ws->ws_traces[0];  /* first entry in the array */
        }
    }
    else if ( ws->ws_num_traces < ws->ws_max_traces )   /* trace can fit */
    {
        wt = &ws->ws_traces[ ws->ws_num_traces++ ];  /* return this pointer */
    }
    else    /* must grow array, double the size */
    {
        struct WaveTrace    *new_wt;

        if ( NULL != (new_wt = malloc((ws->ws_max_traces<<1)*sizeof(struct WaveTrace))) )
        {
            unsigned int         i;

            /* Copy existing array items */
            for ( i = 0; i < ws->ws_max_traces; i++ )
            {
                new_wt[i] = ws->ws_traces[i];
            }

            free(ws->ws_traces);
            ws->ws_traces = new_wt;
            ws->ws_max_traces <<= 1;

            wt = &ws->ws_traces[ ws->ws_num_traces++ ];  /* return this pointer */
        }
    }

    if ( NULL != wt )
    {
        memset(wt,0,sizeof(*wt));
    }

    return(wt);
}
static struct OMARBus* wavesource_AddOMARBus(
    struct WaveformSource   *ws )
{
    struct OMARBus    *ob = NULL;

    if ( NULL == ws->ws_omar_busses)    /* no trace array allocated yet */
    {
        #define WAVESOURCE_STARTING_NUM_BUSES 16
        if ( NULL != (ws->ws_omar_busses = malloc(sizeof(struct OMARBus) * WAVESOURCE_STARTING_NUM_BUSES)) )
        {
            ws->ws_max_omar_busses= WAVESOURCE_STARTING_NUM_BUSES;

            ws->ws_num_omar_busses= 1;
            ob = &ws->ws_omar_busses[0];  /* first entry in the array */
        }
    }
    else if ( ws->ws_num_omar_busses < ws->ws_max_omar_busses )   /* trace can fit */
    {
        ob = &ws->ws_omar_busses[ ws->ws_num_omar_busses++ ];  /* return this pointer */
    }
    else    /* must grow array, double the size */
    {
        struct OMARBus    *new_ob;

        if ( NULL != (new_ob= malloc((ws->ws_max_omar_busses<<1)*sizeof(struct OMARBus))) )
        {
            unsigned int         i;

            /* Copy existing array items */
            for ( i = 0; i < ws->ws_max_omar_busses; i++ )
            {
                new_ob[i] = ws->ws_omar_busses[i];
            }

            free(ws->ws_omar_busses);
            ws->ws_omar_busses = new_ob;
            ws->ws_max_omar_busses <<= 1;

            ob = &ws->ws_omar_busses[ ws->ws_num_omar_busses++ ];  /* return this pointer */
        }
    }

    if ( NULL != ob )
    {
        memset(ob,0,sizeof(*ob));
    }

    return(ob);
}

void wavesource_HW_PopulateTrace(
    struct WaveformSource   *ws )
{
    unsigned int        sig;
    unsigned int        bus,next_buspin;

    sig = bus = 0;

    if ( ws->ws_num_omar_busses > 0 )
    {
        next_buspin = ws->ws_omar_busses[bus].capture_id;
    }
    else
    {
        next_buspin = OMAR_HW_MAX_SAMPLED_SIGNALS + 1;
    }

    /* populate with all collapsed busses */

    while ( sig < OMAR_HW_MAX_SAMPLED_SIGNALS )
    {
        struct WaveTrace    *wt;

        if ( NULL != (wt = wavesource_AddTrace(ws)) )
        {
            /* Label should be a concatenation of bus name and pin no. */
            wt->pub.depth              = 0;
            wt->pub.level_style        = 0;
            wt->is_expanded            = 0;
            wt->parent_trace           = 0;
            wt->clk                    = NULL /* omar_hw_clk */;

            /* Grab the config defined label for this OMAR trace */
            /* TODO: OMAR BUSSES ARE EXPANDED FROM LSB TO MSB, REVERSE THIS???? */

            if ( sig >= next_buspin )
            {
                /* Add only the bus */
                wt->ttype                  = TRACE_TYPE_OMAR_BUS;
                wt->is_expandable          = 1;
                wt->omar_bus.block_id      = sig / OMAR_HW_SAMPLES_PER_BLOCK;
                wt->omar_bus.pin_id        = sig % OMAR_HW_SAMPLES_PER_BLOCK;
                wt->omar_bus.capture_id    = sig;
                wt->omar_bus.pin_width     = ws->ws_omar_busses[bus].pin_width;
                wt->pub.label              = ws->ws_omar_busses[bus].label;

                /* move out of this bus */
                sig += ws->ws_omar_busses[bus].pin_width;


                if ( ++bus < ws->ws_num_omar_busses )
                {
                    next_buspin = ws->ws_omar_busses[bus].capture_id;
                }
                else
                {
                    next_buspin = OMAR_HW_CHIP_MAX_SIGNALS + 1; /* past the end of the loop */
                }

            }
            else
            {
                wt->ttype                  = TRACE_TYPE_OMAR_WIRE;
                wt->is_expandable          = 0;
                wt->omar_wire.block_id     = sig / OMAR_HW_SAMPLES_PER_BLOCK;
                wt->omar_wire.pin_id       = sig % OMAR_HW_SAMPLES_PER_BLOCK;
                wt->omar_wire.capture_id   = sig;
                wt->pub.label              = ws->wd.wd_sig_name[wt->omar_wire.capture_id];

                sig++;
            }
        }
        else
        {
            /* MEMORY ERROR */
        }
    }
}

/* look up this function in sven.c to parse key,value pairs */
static int trace_parse_sven_filter_template(
    struct SVENEvent    *ev,
    struct SVENEvent    *mask,
    htuple_t             trace_id )
{
    int                              err = 0;
    int                              child;
    const struct ModuleReverseDefs  *module;
    const struct EventTypeReverse   *event;
    const struct EventSubtypeReverse*subevent;
    const struct EAS_Register       *reg;
    const struct EAS_RegBits        *bits;

    /* Pre-init */
    module = NULL;
    event = NULL;
    subevent = NULL;
    reg = NULL;
    bits = NULL;

    if ( 0 != (child = htuple_first_child( trace_id )) )
    {
        do
        {
            const char          *name;
            struct htuple_Value  val;

            htuple_node_name( child, &name );
            htuple_node_get_value( child, &val );

            if ( ! strcasecmp( name, "MODULE" ) )
            {
                if ( HTUPLE_TYPE_STRING == val.type )
                {
                    if( NULL != (module = svenreverse_GetModuleTables_ByName(val.str)) )
                    {
                        ev->se_et.et_module = module->mrd_module;
                        mask->se_et.et_module = -1;
                    }
                    else
                    {
                        /* ERROR: Module with Name Not found */
                    }
                }
                else
                {
                    ev->se_et.et_module = val.intval;
                    mask->se_et.et_module = -1;
                }
            }
            else if ( ! strcasecmp( name, "UNIT" ) )
            {
                if ( HTUPLE_TYPE_STRING == val.type )
                {
                    /* ERROR: no way to find unit by name, these are always ordinal */
                }
                else
                {
                    ev->se_et.et_unit = val.intval;
                    mask->se_et.et_unit = -1;
                }
            }
            else if( !strcasecmp(name, "EVENT_TYPE") ||
                     !strcasecmp(name, "EVENT") )
            {
                if ( HTUPLE_TYPE_STRING == val.type )
                {
                    if ( NULL != (event = svenreverse_EVENT_TABLES_BY_NAME(val.str)) )
                    {
                        ev->se_et.et_type =  event->er_type;
                        mask->se_et.et_type= -1;
                    }
                }
                else
                {
                    ev->se_et.et_type = val.intval;
                    mask->se_et.et_type = -1;
                }
            }
            else if ( !strcasecmp(name, "EVENT_SUBTYPE" ) ||
                      !strcasecmp(name, "SUBTYPE" ) )
            {
                if ( HTUPLE_TYPE_STRING == val.type )
                {
                    if ( NULL != event )
                    {
                        if ( SVEN_event_type_module_specific == event->er_type )
                        {
                            if ( NULL != module )
                            {
                                const struct SVEN_Module_EventSpecific  *me;

                                if ( NULL != (me = module->mrd_event_specific) )
                                {
                                    while ( NULL != me->mes_name )
                                    {
                                        if ( !strcasecmp(
                                            val.str,
                                            me->mes_name) )
                                        {
                                            break;
                                        }

                                        me++;
                                    }

                                    if ( NULL != me->mes_name )
                                    {
                                        ev->se_et.et_subtype = me->mes_subtype;
                                        mask->se_et.et_subtype = -1;
                                    }
                                    else
                                    {
                                        /* ERROR: Event Subtype not found  */
                                    }
                                }
                                else
                                {
                                    /* ERROR: No subtypes specified for this event  */
                                }
                            }
                            else
                            {
                                printf("ERR: Must Specify Module first\n");
                                err |= (1<<4);
                            }
                        }
                        else if ( NULL != event->er_subtypes )
                        {
                            const struct EventSubtypeReverse    *se;

                            se = event->er_subtypes;

                            while ( NULL != se->er_name )
                            {
                                if ( !strcasecmp(
                                    val.str,
                                    se->er_name) )
                                {
                                    ev->se_et.et_subtype = se->er_subtype;
                                    mask->se_et.et_subtype = -1;

                                    subevent = se;  /* Keep this pointer */
                                    break;
                                }

                                se++; /* next in table */
                            }

                            /* None found */
                            if ( NULL == se->er_name )
                            {
                                /* ERROR: No subtypes specified for this event  */
                            }
                        }
                        else
                        {
                            /* ERROR: No module specified */
                        }
                    }
                }
                else
                {
                    ev->se_et.et_subtype = val.intval;
                    mask->se_et.et_subtype = -1;
                }
            }
            else
            {
                /* Filter Specification unknown, or an unknown (to us) token */
            }

            child = htuple_next_sibling(child);
        } while ( 0 != child );
    }
   #if 0
   {
      int                     i;
      printf("Adding SVEN Filter:\n" );
      printf(" EV: " );
      for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
         printf("%08x ", ((unsigned int *)ev)[i] );
      }
      printf("\n");
      printf(" MSK:" );
      for(i = 0; i < (SVEN_EVENT_PAYLOAD_NUM_UINTS  + 2); i++){
         printf("%08x ", ((unsigned int *)mask)[i] );
      }
      printf("\n");
   }
   #endif

    return(err);
}

static int wavesource_GetGroupTraceCount(
      struct WaveformSource   *ws,
      unsigned int            wavetrace_num,
      htuple_t                trace_id )
{
   struct WaveTrace        *wt;
   const char              *trace_type;
   htuple_t                 tid, child;
   int                      total_size = 0;

   if ( wavetrace_num < ws->ws_num_traces )
   {
      if ( 0 != (tid = htuple_find_child( trace_id, "trace", strlen("trace"))) )
      {
         if ( 0 != (child = htuple_first_child(tid)) )
         {
            do
            {
               wavetrace_num ++;

               /* convert to (local to the trace) time scale */
               wt = &ws->ws_traces[wavetrace_num];

               if ( ! htuple_get_str_value(child,"type", strlen("type"), &trace_type) )
               {
                  total_size ++;

                  if ( (! strcmp( "group", trace_type )) && (1 == wt->is_expanded ))
                  {
                     total_size += wavesource_GetGroupTraceCount(ws,wavetrace_num,wt->trace_node_id);
                  }
               }
               child = htuple_next_sibling(child);

            } while ( 0 != child );
         }
      }
   }
   return total_size;
}

static int wavesource_BuildTrace(
    struct WaveformSource   *ws,
    struct WaveTrace        *wt,
    htuple_t                 node_id )
{
    int                      err = 0;
    const char              *trace_type;

    if ( ! htuple_get_str_value(node_id,"type", strlen("type"), &trace_type) )
    {
       enum WaveTraceType      ttype;

        /** Trace Keywords, values
         *
         *    type           value: must be "omar" or "sven"
         *    label          value: text to appear on left of wave trace
         *    style          value: 0 = line, 1 = delta, 3 = bar, 4 = thermo
         *
         *    if ( type == "omar" )
         *    {
         *        block      value: integer, omar capture block ID
         *        pin        value: integer, pin on the omar capture block
         *    }
         *    else if ( type == "sven" )
         *    {   -- we're defining a SVEN "Event Filter"
         *        module     value: string, SVEN Module name
         *        unit       value: int, Event unit number
         *        event_type value: string, SVEN Major Event Type
         *        event_sub  value: string, SVEN Minor Event Type
         *    }
         *
         */
        #if 0
        /* Hardware: Vertical Sync */
        {    type        "omar"
            block        0x13    /* VDC-2 */
            pin            14    /* V-SYNC */
            label        "VDC:VSync"
        }
        /* Video Renderer ISR */
        {    type        "sven"
            module        "VIDREND"
            unit         0
            event_type    "module_specific"
            event_sub    "VSYNC_ISR"
        }
        #endif
        if ( ! strcmp( "omar", trace_type ) )
        {
            ttype = TRACE_TYPE_OMAR_WIRE;
        }
        else if ( ! strcmp( "omar_bus", trace_type ) )
        {
            ttype = TRACE_TYPE_OMAR_BUS;
        }
        else if ( ! strcmp( "sven", trace_type ) )
        {
            ttype = TRACE_TYPE_SVEN_FILTER;
        }
        else if ( ! strcmp( "smd_q", trace_type ) )
        {
            ttype = TRACE_TYPE_BUF_LEVEL;
        }
        else if ( ! strcmp( "group", trace_type ) )
        {
           ttype = TRACE_TYPE_GROUP;
        }
        else
        {
            err = 1;
            printf("ERR: unknown trace type \"%s\"\n", trace_type );
        }
        if ( !err )
        {
            if ( NULL == wt)
            {
               wt = wavesource_AddTrace(ws);
            }
            if ( NULL != wt)
            {
                wt->ttype = ttype;              /* save the trace type */
                wt->trace_node_id = node_id;    /* and the containing htuple node id */

                htuple_get_str_value( node_id, "label", strlen("label"), (const char **) &wt->pub.label );
                htuple_get_int_value( node_id, "style", strlen("style"), (unsigned int *) &wt->pub.level_style );

                if ( TRACE_TYPE_OMAR_WIRE == ttype )      /* omar wire */
                {
                    htuple_get_int_value( node_id, "block", strlen("block"), (unsigned int *) &wt->omar_wire.block_id );
                    htuple_get_int_value( node_id, "pin", strlen("pin"), (unsigned int *) &wt->omar_wire.pin_id );

                    DEVH_ASSERT( ws->ws_devh, wt->omar_wire.block_id < OMAR_HW_CHIP_BLOCKS );
                    DEVH_ASSERT( ws->ws_devh, wt->omar_wire.pin_id < OMAR_HW_SAMPLES_PER_BLOCK );

                    wt->omar_wire.capture_id =
                        (wt->omar_wire.block_id * OMAR_HW_SAMPLES_PER_BLOCK) +
                        wt->omar_wire.pin_id;

                    if ( NULL == wt->pub.label )
                    {
                        wt->pub.label = ws->wd.wd_sig_name[wt->omar_wire.capture_id];
                    }
                }
                else if ( TRACE_TYPE_OMAR_BUS == ttype ) /* omar bus */
                {
                    htuple_get_int_value( node_id, "block", strlen("block"), &wt->omar_bus.block_id );
                    htuple_get_int_value( node_id, "pin", strlen("pin"), &wt->omar_bus.pin_id );
                    htuple_get_int_value( node_id, "width", strlen("width"), &wt->omar_bus.pin_width );

                    DEVH_ASSERT( ws->ws_devh, wt->omar_wire.block_id < OMAR_HW_CHIP_BLOCKS );
                    DEVH_ASSERT( ws->ws_devh, wt->omar_wire.pin_id < OMAR_HW_SAMPLES_PER_BLOCK );

                    wt->omar_bus.capture_id =
                        (wt->omar_bus.block_id * OMAR_HW_SAMPLES_PER_BLOCK) +
                        wt->omar_bus.pin_id;

                    wt->is_expandable = 1;

                    if ( NULL == wt->pub.label )
                    {
                        unsigned int i=0;

                        /* start with a block name */
                        wt->pub.label = wavesource_GetGroupName( ws, wt->omar_bus.block_id );

                        ////////////////////////////////////////////////////////////////////
                        /* Find the matching bus */
                        if(ws->ws_num_omar_busses >0)
                        {
                            while(i<ws->ws_num_omar_busses)
                            {
                                if(ws->ws_omar_busses[i].capture_id==wt->omar_bus.capture_id)
                                {
                                    wt->pub.label = ws->ws_omar_busses[i].label;
                                    break;
                                }
                                i++;
                            }
                        }
                    }
                }
                else if ( TRACE_TYPE_SVEN_FILTER == ttype ) /* sven filter */
                {
                   if ( NULL == wt->pub.label )
                   {
                      wt->pub.label = "sven";
                   }

                   /* Build the sven filter */
                   trace_parse_sven_filter_template(
                         &wt->sven.filt.eq_ev,
                         &wt->sven.filt.and_ev,
                         node_id );
                }
                else if ( TRACE_TYPE_BUF_LEVEL == ttype )
                {
                    htuple_get_int_value( node_id, "port", strlen("port"), &wt->smd.port );
                    htuple_get_int_value( node_id, "queue", strlen("queue"), &wt->smd.queue );
                    htuple_get_int_value( node_id, "max_bufs", strlen("max_bufs"), &wt->smd.max_bufs );
                    htuple_get_int_value( node_id, "max_bytes", strlen("max_bytes"), &wt->smd.max_bytes );
                }
                else if ( TRACE_TYPE_GROUP == ttype ) /* Group type Sven and OMAR */
                {
                    if ( NULL == wt->pub.label )
                    {
                        wt->pub.label = "group";
                    }

                    wt->is_expandable = 1;

                }
            }
            else
            {
                err = 1;
                printf("ERR: Cannot add new trace, out-of-memory\n");
            }
        }
    }
    else
    {
        err = 1;
        printf("ERR: No trace type specified\n");
    }

   if ( 0 != err )
   {
      printf("error loading trace at node %d\n", node_id );
      omar_htuple_verbose_printf( node_id, 1 );
   }
   else
   {
      // omar_htuple_verbose_printf( node_id, 1 );
   }

    return(err);
}

/* Typically called with "sven-omar-gui.waveform.traces" after config file is loaded */
int wavesource_AddTraces(
    struct WaveformSource   *ws,
    htuple_t                 trace_id )
{
   int             err = 0;
   int             num_traces_loaded = 0;

   while ( 0 != trace_id )
   {
      /* Build a trace based on this description */
       wavesource_BuildTrace( ws, NULL, trace_id );
       num_traces_loaded++;

       trace_id = htuple_next_sibling(trace_id);
   }

   printf("OMAR: Loaded %d traces\n", num_traces_loaded );

   return(err);
}

int wavesource_LoadTraces(
    struct WaveformSource   *ws,
    const char              *trace_config_path )
{
    int             err = 0;
    htuple_t        node_id;

    if ( NULL == trace_config_path )
    {
        trace_config_path = "omarlib.default_trace";
    }

    /* Traverse through trace */
    if ( 0 != (node_id = htuple_find_child(0,trace_config_path,strlen(trace_config_path))) )
    {
       htuple_t        child;

       if ( 0 != (child = htuple_first_child(node_id)) )
       {
          wavesource_FlushTraces( ws );

          err = wavesource_AddTraces( ws, child );
       }
    }
    else
    {
        printf("can't find \"%s\"\n", trace_config_path );
        err = 1;
    }

    return(err);
}

int wavesource_LoadConfigFile(
    struct WaveformSource   *ws,
    const char              *config_filename,
    const char              *trace_config_path )
{
   int       err = 0;
   FILE     *fp;

   if ( NULL != (fp = fopen(config_filename, "r")) )
   {
      char            *txt;
      long             txtlen;

      fseek( fp, 0, SEEK_END );
      txtlen = ftell(fp);
      rewind(fp);

      if ( NULL != (txt = malloc(txtlen+1)) )
      {
         if ( txtlen == (long) fread( txt, 1, txtlen, fp ) )
         {
            htuple_t        private_id;

            if ( 0 == (err = htuple_create_private_tree( &private_id )) )
            {
               htuple_t        node_id;
               htuple_t        config_file_id = ws->config_file_id;

               /* unnecessary null term */ txt[txtlen] = '\0';
               htuple_parse_config_string( private_id, txt, txtlen );

               /* Store the htuple id  */
               ws->config_file_id = private_id;

               /* Traverse through trace */
               if ( 0 != (node_id = htuple_find_child(private_id,trace_config_path,strlen(trace_config_path))) )
               {
                  /* go to first entry (not empty) */
                  if ( 0 != (node_id = htuple_first_child(node_id)) )
                  {
                     wavesource_FlushTraces( ws );
                     err = wavesource_AddTraces( ws, node_id );
                  }
                  else
                  {
                     err = 1;
                     printf("ERR: Empty traces at \"%s\"\n",trace_config_path );
                  }
               }
               else
               {
                  err = 1;
                  printf("ERR: unabled to open traces at \"%s\"\n",trace_config_path );
               }

               if ( err )
               {
                  htuple_delete_private_tree( private_id );
                  ws->config_file_id = config_file_id;
               }
               else
               {
                  /* Push out the old one */
                  if ( 0 != config_file_id )
                  {
                     htuple_delete_private_tree( config_file_id );
                  }
               }
            }
            else
            {
               err = 1;
               printf("ERR: htuple_create_private_tree() failed\n" );
            }
         }
         else
         {
            err = 1;
            printf("ERR: fread(%ld) failed\n", txtlen );
         }
         free(txt);
      }
      else
      {
         err = 1;
         printf("ERR: malloc(%ld) failed\n", txtlen );
      }

      fclose(fp);
   }
   else
   {
      err = 1;
      printf("ERR: unabled to open config file \"%s\"\n",config_filename );
   }

   return(err);
}

int wavesource_LoadSvenlog(
	    struct WaveformSource   *ws,
	    const char              *svenlog_filename
	)
{
	 int       err = 0;
	 FILE     *fi;
     int ignore_filters;
     //int         i;

     ws->ws_svenlog_load_enabled = 1;
     /* Turn OFF the hardware */
     if ( 0 == ws->ws_hardware_not_present )
     {
        if ( ws->ws_hw_capture_enabled )
        {
           devh_AndBitsReg32( ws->ws_devh, ROFF_DFX_OMAR_CONTROL, ~BMSK_DFX_OMAR_CONTROL_ENABLE );
           ws->ws_hw_capture_enabled = 0;
        }
     }

     /* HALT sven capture if enabled */
     if ( ! svenlog_IsCapturePaused( ws->ws_svenlog ) )
     {
        svenlog_Pause( ws->ws_svenlog ); /* pause sven recording */
     }


     if ( NULL != (fi = fopen( svenlog_filename, "rb" )) )
	 {
		 struct SVENEvent       ev;
         struct SVENEventTag_v0 et_old;
         uint32_t               *et_data;
	     int                    num_events_read;
	     int                    num_events_passed_filter;
	     bool                   use_old_ev_format = false;


	      printf("reading events from file \"%s\"\n", svenlog_filename );
         num_events_read = 0;
         num_events_passed_filter = 0;
         ignore_filters = 0;

         // Read the first event from the file.
         if ( sizeof(ev) == fread( &ev, 1, sizeof(ev), fi ) )
         {

        	 et_data = (uint32_t *)&ev.se_et;

        	 // If the first event tag is not all 1's, this data is saved
             // using the old event format.
             if (*et_data != 0xFFFFFFFF)
             {
                 printf("Detected version 0 SVENEvent format ... adapting...\n");
                 use_old_ev_format = true;

                 // Copy the event tag to an old format struct
                 *((uint32_t *)&et_old) = *et_data;

                 // Copy the old format struct elements to the new tag
                 // struct format
                 ev.se_et.et_subtype  = et_old.et_subtype;
                 ev.se_et.et_type     = et_old.et_type;
                 ev.se_et.et_unit     = et_old.et_unit;
                 ev.se_et.et_module   = et_old.et_module;
                 ev.se_et.et_gencount = et_old.et_gencount;

                 num_events_read++;

                 if ( svenlog_InsertEvent_Locally( ws->ws_svenlog, &ev,ignore_filters ) )
                 {
                	 num_events_passed_filter++;
                 }
             }
             else
             {
                 printf("Detected version %d SVENEvent format ... adapting...\n", (int)ev.u.se_ulong[0]);
             }

             while ( sizeof(ev) == fread( &ev, 1, sizeof(ev), fi ) )
             {
                 // If the file we are reading was saved using the old
                 // event tag format, convert the event tag data to the
                 // new format.
                 if (use_old_ev_format)
                 {
                     *((uint32_t *)&et_old) = *((uint32_t *)&ev.se_et);
                     ev.se_et.et_subtype  = et_old.et_subtype;
                     ev.se_et.et_type     = et_old.et_type;
                     ev.se_et.et_unit     = et_old.et_unit;
                     ev.se_et.et_module   = et_old.et_module;
                     ev.se_et.et_gencount = et_old.et_gencount;
                 }

                 num_events_read++;

                 if ( svenlog_InsertEvent_Locally( ws->ws_svenlog, &ev, ignore_filters ) )
                 {
                     num_events_passed_filter++;
                 }
             }

             svenlog_RewindLocalEventReader(ws->ws_svenlog,num_events_passed_filter);

             svenlog_ReadNextLocalEvent(ws->ws_svenlog, &ev);
             ws->ws_capture_start_timestamp = ws->ws_capture_stop_timestamp = ev.se_timestamp;

             while (svenlog_ReadNextLocalEvent(ws->ws_svenlog, &ev))
             {
                if (  ev.se_timestamp > ws->ws_capture_stop_timestamp)
                   ws->ws_capture_stop_timestamp = ev.se_timestamp;
             }
         }

         fclose(fi);
         printf("read %d of %d events from file \"%s\" %s\n", num_events_passed_filter, num_events_read, svenlog_filename, ignore_filters ? "ignore filters" : "filtered" );

         ws->wd.wd_interval_countdown = ws->ws_capture_clock_frequency / 100; /* one kHz Capture */

	 }
     else
     {
         printf("ERR: failed to open file \"%s\"\n", svenlog_filename );
         err = 1;
     }


	 return (err);
}


/** This string created so we can parse a signals names area as a file
 * loaded at runtime in the same format.
 */
static const char omar_config[] =
"omarlib\n"
"{\n"
"   info\n"
"   {\n"
"      filename \"" __FILE__ "\"\n"
"      date \"" __DATE__ "\"\n"
"      time \"" __TIME__ "\"\n"
"   }\n"
"   group\n"
"   {\n"
"       TLU         0\n"
"       AUD_IO      1\n"
"       AUD_DSP     2\n"
"       MFD0        3\n"
"       MFD1        4\n"
"       MFD_CTRL    5\n"
"       VDC         6\n"
"       HDMI_Tx     7\n"
"       TV_ENC      8\n"
"       TSPrefilter 9\n"
"       USB         10\n"
"       Gb-Mac      11\n"
"       PCIe        12\n"
"       SGx         13\n"
"       CRU         14\n"
"       SEC         15\n"
"       TSDemux     16\n"
"       PUB_TOP     17\n"
"       SATA        18\n"
"       IT_TOP      19\n"
"       DPE         20\n"
"       ICH7_Legacy 21\n"
"       MSPOD       22\n"
"   }\n"
"   block\n"
"   {\n"
"       TLU             0\n"
"       AUD_IO-0        1\n"
"       AUD_IO-1        2\n"
"       AUD_IO-2        3\n"
"       AUD_IO-3        4\n"
"       AUD_IO-4        5\n"
"       AUD_IO-5        6\n"
"       AUD_DSP-0       7\n"
"       AUD_DSP-1       8\n"
"       MFD0-0          9\n"
"       MFD1-0          10\n"
"       MFD_CTRL-0      11\n"
"       MFD_CTRL-1      12\n"
"       MFD_CTRL-2      13\n"
"       MFD_CTRL-3      14\n"
"       MFD_CTRL-4      15\n"
"       MFD_CTRL-5      16\n"
"       VDC-0           17\n"
"       VDC-1           18\n"
"       VDC-2           19\n"
"       VDC-3           20\n"
"       VDC-4           21\n"
"       HDMI_Tx-0       22\n"
"       TV_ENC-0        23\n"
"       TV_ENC-1        24\n"
"       TSPrefilter-0   25\n"
"       TSPrefilter-1   26\n"
"       TSPrefilter-2   27\n"
"       TSPrefilter-3   28\n"
"       USB-0           29\n"
"       Gb-Mac-0        30\n"
"       Gb-Mac-1        31\n"
"       PCIe-0          32\n"
"       PCIe-1          33\n"
"       SGx-0           34\n"
"       SGx-1           35\n"
"       CRU-0           36\n"
"       CRU-1           37\n"
"       CRU-2           38\n"
"       CRU-3           39\n"
"       SEC-0           40\n"
"       SEC-1           41\n"
"       SEC-2           42\n"
"       SEC-3           43\n"
"       SEC-4           44\n"
"       SEC-5           45\n"
"       SEC-6           46\n"
"       SEC-7           47\n"
"       TSDemux-0       48\n"
"       TSDemux-1       49\n"
"       TSDemux-2       50\n"
"       TSDemux-3       51\n"
"       PUB_TOP-0       52\n"
"       PUB_TOP-1       53\n"
"       PUB_TOP-2       54\n"
"       PUB_TOP-3       55\n"
"       SATA-0          56\n"
"       IT_TOP-0        57\n"
"       IT_TOP-1        58\n"
"       DPE-0           59\n"
"       DPE-1           60\n"
"       DPE-2           61\n"
"       ICH7_Legacy-0   62\n"
"       ICH7_Legacy-1   63\n"
"       MSPOD-0         64\n"
"       reserved-0      65\n"
"       reserved-1      66\n"
"       reserved-2      67\n"
"   }\n"
"   default_trace\n"
"   {\n"
"         { label \"sven-all\"         type \"sven\"        }\n"
"         { label \"INT\"              type \"omar\"       block 63 pin 13 }\n"
"         { label \"INT_UART\"         type \"omar\"       block 57 pin 14 }\n"
"         { label \"INT_SATA\"         type \"omar\"       block 58 pin 7 }\n"
"         { label \"INT_GIGE\"         type \"omar\"       block 58 pin 5 }\n"
"         { label \"smd\"              type \"sven\"       module \"sw_smd_core\" }\n"
"         { label \" QueueWrite\"      type \"sven\"       module \"sw_smd_core\" event \"smd\" subtype \"Queue_Write\" }\n"
"         { label \" QueueRead\"       type \"sven\"       module \"sw_smd_core\" event \"smd\" subtype \"Queue_Read\" }\n"
"         { label \" QueuePush\"       type \"sven\"       module \"sw_smd_core\" event \"smd\" subtype \"Queue_Push\" }\n"
"         { label \" QueuePull\"       type \"sven\"       module \"sw_smd_core\" event \"smd\" subtype \"Queue_Pull\" }\n"
"         { label \"INT_DEMUX\"        type \"omar\"       block 57 pin 5 }\n"
"         { label \"demux\"            type \"sven\"       module \"gen3_demux\" }\n"
"         { label \" trap\"            type \"omar\"       block 51 pin 8 }\n"
"         { label \" host_doorb\"      type \"omar_bus\"   block 50 pin 0 width 4 }\n"
"         { label \"cru\"              type \"sven\"       module \"gen3_cru\" }\n"
"         { label \" 0_stc_match\"     type \"omar\"       block 36 pin 2 }\n"
"         { label \" 0_sw_ts\"         type \"omar\"       block 36 pin 1 }\n"
"         { label \" 0_pts[15]\"       type \"omar\"       block 36 pin 6 }\n"
"         { label \" 0_pts[6]\"        type \"omar\"       block 36 pin 7 }\n"
"         { label \"INT_MFD\"          type \"omar\"       block 57 pin 2 }\n"
"         { label \"viddec\"           type \"sven\"       module \"gen3_mfd\" }\n"
"         { label \" es_in_SW\"        type \"sven\"       module \"gen3_mfd\" event \"module_event\" subtype \"ENQUEUE_ES_BUFFER\" }\n"
"         { label \" frame_out_SW\"    type \"sven\"       module \"gen3_mfd\" event \"module_event\" subtype \"DISPLAY_ORDER_FRAME\" }\n"
"         { label \" frame_rel_SW\"    type \"sven\"       module \"gen3_mfd\" event \"module_event\" subtype \"RELEASE_FRAME_BUFFER\" }\n"
"         { label \" frame_done\"      type \"omar\"       block 15 pin 0 }\n"
"         { label \" slice_start\"     type \"omar\"       block 15 pin 8 }\n"
"         { label \" slice_done\"      type \"omar\"       block 15 pin 7 }\n"
"         { label \" mpg2vd_pes\"      type \"omar\"       block 16 pin 0 }\n"
"         { label \" mpg2vd_int\"      type \"omar\"       block 16 pin 1 }\n"
"         { label \"INT_DPE\"          type \"omar\"       block 57 pin 10 }\n"
"         { label \"vidpproc\"         type \"sven\"       module \"gen3_dpe\" }\n"
"         { label \" frame_in_SW\"     type \"sven\"       module \"gen3_dpe\" event \"module_event\" subtype \"READ_INPUT_BUFFER\" }\n"
"         { label \" frame_out_SW\"    type \"sven\"       module \"gen3_dpe\" event \"module_event\" subtype \"WRITE_OUTPUT_BUFFER\" }\n"
"         { label \" cp_drbl_event\"   type \"omar\"       block 59 pin 14 }\n"
"         { label \" cp_stride_done\"  type \"omar\"       block 59 pin 13 }\n"
"         { label \"INT_VDC\"          type \"omar\"       block 57 pin 9 }\n"
"         { label \"vidmsb_g\"         type \"omar\"       block 17 pin 11 }\n"
"         { label \"field_t0\"         type \"omar\"       block 17 pin 0 }\n"
"         { label \"vblank_t0\"        type \"omar\"       block 17 pin 6 }\n"
"         { label \"vidrend\"          type \"sven\"       module \"sw_vidrend\" }\n"
"         { label \" flip\"            type \"sven\"       module \"sw_vidrend\" event \"module_event\" subtype \"flip\" }\n"
"         { label \" drop\"            type \"sven\"       module \"sw_vidrend\" event \"module_event\" subtype \"drop\" }\n"
"         { label \" module\"          type \"sven\"       module \"sw_vidrend\" event \"module_event\" }\n"
"         { label \"INT_AUD\"          type \"omar\"       block 57 pin 8 }\n"
"         { label \"audio\"            type \"sven\"       module \"gen3_aud_io\" }\n"
"         { label \" mmr_write\"       type \"omar\"       block 3 pin 10 }\n"
"         { label \" mmr_read\"        type \"omar\"       block 3 pin 11 }\n"
"         { label \"INT_DSP_0\"        type \"omar\"       block 57 pin 6 }\n"
"         { label \"dsp0\"             type \"sven\"       module \"gen3_aud_dsp0\" }\n"
"         { label \"INT_DSP_1\"        type \"omar\"       block 57 pin 7 }\n"
"         { label \"dsp1\"             type \"sven\"       module \"gen3_aud_dsp1\" }\n"
"       omar_00 { type \"omar_bus\" width 16 label \"TLU\"              block 0 }\n"
"       omar_01 { type \"omar_bus\" width 16 label \"AUD_IO\"           block 1 }\n"
"       omar_02 { type \"omar_bus\" width 16 label \"AUD_IO-1\"         block 2 }\n"
"       omar_03 { type \"omar_bus\" width 16 label \"AUD_IO-2\"         block 3 }\n"
"       omar_04 { type \"omar_bus\" width 16 label \"AUD_IO-3\"         block 4 }\n"
"       omar_05 { type \"omar_bus\" width 16 label \"AUD_IO-4\"         block 5 }\n"
"       omar_06 { type \"omar_bus\" width 16 label \"AUD_IO-5\"         block 6 }\n"
"       omar_07 { type \"omar_bus\" width 16 label \"AUD_DSP-0\"        block 7 }\n"
"       omar_08 { type \"omar_bus\" width 16 label \"AUD_DSP-1\"        block 8 }\n"
"       omar_09 { type \"omar_bus\" width 16 label \"MFD0-0\"           block 9 }\n"
"       omar_10 { type \"omar_bus\" width 16 label \"MFD1-0\"           block 10 }\n"
"       omar_11 { type \"omar_bus\" width 16 label \"MFD_CTRL-0\"       block 11 }\n"
"       omar_12 { type \"omar_bus\" width 16 label \"MFD_CTRL-1\"       block 12 }\n"
"       omar_13 { type \"omar_bus\" width 16 label \"MFD_CTRL-2\"       block 13 }\n"
"       omar_14 { type \"omar_bus\" width 16 label \"MFD_CTRL-3\"       block 14 }\n"
"       omar_15 { type \"omar_bus\" width 16 label \"MFD_CTRL-4\"       block 15 }\n"
"       omar_16 { type \"omar_bus\" width 16 label \"MFD_CTRL-5\"       block 16 }\n"
"       omar_17 { type \"omar_bus\" width 16 label \"VDC-0\"            block 17 }\n"
"       omar_18 { type \"omar_bus\" width 16 label \"VDC-1\"            block 18 }\n"
"       omar_19 { type \"omar_bus\" width 16 label \"VDC-2\"            block 19 }\n"
"       omar_20 { type \"omar_bus\" width 16 label \"VDC-3\"            block 20 }\n"
"       omar_21 { type \"omar_bus\" width 16 label \"VDC-4\"            block 21 }\n"
"       omar_22 { type \"omar_bus\" width 16 label \"HDMI_Tx-0\"        block 22 }\n"
"       omar_23 { type \"omar_bus\" width 16 label \"TV_ENC-0\"         block 23 }\n"
"       omar_24 { type \"omar_bus\" width 16 label \"TV_ENC-1\"         block 24 }\n"
"       omar_25 { type \"omar_bus\" width 16 label \"TSPrefilter-0\"    block 25 }\n"
"       omar_26 { type \"omar_bus\" width 16 label \"TSPrefilter-1\"    block 26 }\n"
"       omar_27 { type \"omar_bus\" width 16 label \"TSPrefilter-2\"    block 27 }\n"
"       omar_28 { type \"omar_bus\" width 16 label \"TSPrefilter-3\"    block 28 }\n"
"       omar_29 { type \"omar_bus\" width 16 label \"USB-0\"            block 29 }\n"
"       omar_30 { type \"omar_bus\" width 16 label \"Gb-Mac-0\"         block 30 }\n"
"       omar_31 { type \"omar_bus\" width 16 label \"Gb-Mac-1\"         block 31 }\n"
"       omar_32 { type \"omar_bus\" width 16 label \"PCIe-0\"           block 32 }\n"
"       omar_33 { type \"omar_bus\" width 16 label \"PCIe-1\"           block 33 }\n"
"       omar_34 { type \"omar_bus\" width 16 label \"SGx-0\"            block 34 }\n"
"       omar_35 { type \"omar_bus\" width 16 label \"SGx-1\"            block 35 }\n"
"       omar_36 { type \"omar_bus\" width 16 label \"CRU-0\"            block 36 }\n"
"       omar_37 { type \"omar_bus\" width 16 label \"CRU-1\"            block 37 }\n"
"       omar_38 { type \"omar_bus\" width 16 label \"CRU-2\"            block 38 }\n"
"       omar_39 { type \"omar_bus\" width 16 label \"CRU-3\"            block 39 }\n"
"       omar_40 { type \"omar_bus\" width 16 label \"SEC-0\"            block 40 }\n"
"       omar_41 { type \"omar_bus\" width 16 label \"SEC-1\"            block 41 }\n"
"       omar_42 { type \"omar_bus\" width 16 label \"SEC-2\"            block 42 }\n"
"       omar_43 { type \"omar_bus\" width 16 label \"SEC-3\"            block 43 }\n"
"       omar_44 { type \"omar_bus\" width 16 label \"SEC-4\"            block 44 }\n"
"       omar_45 { type \"omar_bus\" width 16 label \"SEC-5\"            block 45 }\n"
"       omar_46 { type \"omar_bus\" width 16 label \"SEC-6\"            block 46 }\n"
"       omar_47 { type \"omar_bus\" width 16 label \"SEC-7\"            block 47 }\n"
"       omar_48 { type \"omar_bus\" width 16 label \"TSDemux-0\"        block 48 }\n"
"       omar_49 { type \"omar_bus\" width 16 label \"TSDemux-1\"        block 49 }\n"
"       omar_50 { type \"omar_bus\" width 16 label \"TSDemux-2\"        block 50 }\n"
"       omar_51 { type \"omar_bus\" width 16 label \"TSDemux-3\"        block 51 }\n"
"       omar_52 { type \"omar_bus\" width 16 label \"PUB_TOP-0\"        block 52 }\n"
"       omar_53 { type \"omar_bus\" width 16 label \"PUB_TOP-1\"        block 53 }\n"
"       omar_54 { type \"omar_bus\" width 16 label \"PUB_TOP-2\"        block 54 }\n"
"       omar_55 { type \"omar_bus\" width 16 label \"PUB_TOP-3\"        block 55 }\n"
"       omar_56 { type \"omar_bus\" width 16 label \"SATA-0\"           block 56 }\n"
"       omar_57 { type \"omar_bus\" width 16 label \"IT_TOP-0\"         block 57 }\n"
"       omar_58 { type \"omar_bus\" width 16 label \"IT_TOP-1\"         block 58 }\n"
"       omar_59 { type \"omar_bus\" width 16 label \"DPE-0\"            block 59 }\n"
"       omar_60 { type \"omar_bus\" width 16 label \"DPE-1\"            block 60 }\n"
"       omar_61 { type \"omar_bus\" width 16 label \"DPE-2\"            block 61 }\n"
"       omar_62 { type \"omar_bus\" width 16 label \"ICH7_Legacy-0\"    block 62 }\n"
"       omar_63 { type \"omar_bus\" width 16 label \"ICH7_Legacy-1\"    block 63 }\n"
"   }\n"
"}\n"
;

static const char omar_config_gen4[] =
"omarlib\n"
"{\n"
"   info\n"
"   {\n"
"      filename \"" __FILE__ "\"\n"
"      date \"" __DATE__ "\"\n"
"      time \"" __TIME__ "\"\n"
"      soc_generation  4\n"
"   }\n"
"   group\n"
"   {\n"
"       TLU         0\n"
"       AUD_IO      1\n"
"       AUD_DSP     2\n"
"       MFD0        3\n"
"       MFD1        4\n"
"       MFD_CTRL    5\n"
"       VDC         6\n"
"       HDMI_Tx     7\n"
"       TV_ENC      8\n"
"       TSPrefilter 9\n"
"       USB         10\n"
"       Gb-Mac      11\n"
"       PCIe        12\n"
"       SGx         13\n"
"       CRU         14\n"
"       SEC         15\n"
"       TSDemux     16\n"
"       PUB_TOP     17\n"
"       SATA        18\n"
"       IT_TOP      19\n"
"       DPE         20\n"
"       ICH7_Legacy 21\n"
"       MSPOD       22\n"
"   }\n"
"   block\n"
"   {\n"
"       TLU             0\n"
"       MFD-0           1\n"
"       MFD-1           2\n"
"       MFD-2           3\n"
"       MFD-3           4\n"
"       MFD-4           5\n"
"       MFD-5           6\n"
"       MFD-6           7\n"
"       HDVCAP-0        8\n"
"       VDC-0           9\n"
"       VDC-1           10\n"
"       VDC-2           11\n"
"       VDC-3           12\n"
"       VDC-4           13\n"
"       TV_ENC-0        14\n"
"       TV_ENC-1        15\n"
"       HDMI_Tx-0       16\n"
"       PUB_TOP-0       17\n"
"       PUB_TOP-1       18\n"
"       PUB_TOP-2       19\n"
"       PUB_TOP-3       20\n"
"       SGx-0           21\n"
"       SGx-1           22\n"
"       DPE-0           23\n"
"       DPE-1           24\n"
"       DPE-2           25\n"
"       AUD_IO-0        26\n"
"       AUD_IO-1        27\n"
"       AUD_IO-2        28\n"
"       AUD_IO-3        29\n"
"       AUD_IO-4        30\n"
"       AUD_IO-5        31\n"
"       TSPrefilter-0   32\n"
"       TSPrefilter-1   33\n"
"       TSPrefilter-2   34\n"
"       TSPrefilter-3   35\n"
"       TSDemux-0       36\n"
"       TSDemux-1       37\n"
"       TSDemux-2       38\n"
"       TSDemux-3       39\n"
"       SEC-0           40\n"
"       SEC-1           41\n"
"       SEC-2           42\n"
"       SEC-3           43\n"
"       SEC-4           44\n"
"       SEC-5           45\n"
"       SEC-6           46\n"
"       SEC-7           47\n"
"       ICH7_Legacy-0   48\n"
"       ICH7_Legacy-1   49\n"
"       IT_TOP-0        50\n"
"       IT_TOP-1        51\n"
"       Gb-Mac-0        52\n"
"       Gb-Mac-1        53\n"
"       CRU-0           54\n"
"       CRU-1           55\n"
"       CRU-2           56\n"
"       CRU-3           57\n"
"       SATA-0          58\n"
"       USB-0           59\n"
"       AUD_DSP-0       60\n"
"       AUD_DSP-1       61\n"
"       GV-0            62\n"
"       GV-1            63\n"
"   }\n"
"   default_trace\n"
"   {\n"
"       omar_00 { type \"omar_bus\" width 16 label \"TLU\"            block 0 }\n"
"       omar_01 { type \"omar_bus\" width 16 label \"MFD-0\"          block 1 }\n"
"       omar_02 { type \"omar_bus\" width 16 label \"MFD-1\"          block 2 }\n"
"       omar_03 { type \"omar_bus\" width 16 label \"MFD-2\"          block 3 }\n"
"       omar_04 { type \"omar_bus\" width 16 label \"MFD-3\"          block 4 }\n"
"       omar_05 { type \"omar_bus\" width 16 label \"MFD-4\"          block 5 }\n"
"       omar_06 { type \"omar_bus\" width 16 label \"MFD-5\"          block 6 }\n"
"       omar_07 { type \"omar_bus\" width 16 label \"MFD-6\"          block 7 }\n"
"       omar_08 { type \"omar_bus\" width 16 label \"HDVCAP-0\"       block 8 }\n"
"       omar_09 { type \"omar_bus\" width 16 label \"VDC-0\"          block 9 }\n"
"       omar_10 { type \"omar_bus\" width 16 label \"VDC-1\"          block 10 }\n"
"       omar_11 { type \"omar_bus\" width 16 label \"VDC-2\"          block 11 }\n"
"       omar_12 { type \"omar_bus\" width 16 label \"VDC-3\"          block 12 }\n"
"       omar_13 { type \"omar_bus\" width 16 label \"VDC-4\"          block 13 }\n"
"       omar_14 { type \"omar_bus\" width 16 label \"TV_ENC-0\"       block 14 }\n"
"       omar_15 { type \"omar_bus\" width 16 label \"TV_ENC-1\"       block 15 }\n"
"       omar_16 { type \"omar_bus\" width 16 label \"HDMI_Tx-0\"      block 16 }\n"
"       omar_17 { type \"omar_bus\" width 16 label \"PUB_TOP-0\"      block 17 }\n"
"       omar_18 { type \"omar_bus\" width 16 label \"PUB_TOP-1\"      block 18 }\n"
"       omar_19 { type \"omar_bus\" width 16 label \"PUB_TOP-2\"      block 19 }\n"
"       omar_20 { type \"omar_bus\" width 16 label \"PUB_TOP-3\"      block 20 }\n"
"       omar_21 { type \"omar_bus\" width 16 label \"SGx-0\"          block 21 }\n"
"       omar_22 { type \"omar_bus\" width 16 label \"SGx-1\"          block 22 }\n"
"       omar_23 { type \"omar_bus\" width 16 label \"DPE-0\"          block 23 }\n"
"       omar_24 { type \"omar_bus\" width 16 label \"DPE-1\"          block 24 }\n"
"       omar_25 { type \"omar_bus\" width 16 label \"DPE-2\"          block 25 }\n"
"       omar_26 { type \"omar_bus\" width 16 label \"AUD_IO-0\"       block 26 }\n"
"       omar_27 { type \"omar_bus\" width 16 label \"AUD_IO-1\"       block 27 }\n"
"       omar_28 { type \"omar_bus\" width 16 label \"AUD_IO-2\"       block 28 }\n"
"       omar_29 { type \"omar_bus\" width 16 label \"AUD_IO-3\"       block 29 }\n"
"       omar_30 { type \"omar_bus\" width 16 label \"AUD_IO-4\"       block 30 }\n"
"       omar_31 { type \"omar_bus\" width 16 label \"AUD_IO-5\"       block 31 }\n"
"       omar_32 { type \"omar_bus\" width 16 label \"TSPrefilter-0\"  block 32 }\n"
"       omar_33 { type \"omar_bus\" width 16 label \"TSPrefilter-1\"  block 33 }\n"
"       omar_34 { type \"omar_bus\" width 16 label \"TSPrefilter-2\"  block 34 }\n"
"       omar_35 { type \"omar_bus\" width 16 label \"TSPrefilter-3\"  block 35 }\n"
"       omar_36 { type \"omar_bus\" width 16 label \"TSDemux-0\"      block 36 }\n"
"       omar_37 { type \"omar_bus\" width 16 label \"TSDemux-1\"      block 37 }\n"
"       omar_38 { type \"omar_bus\" width 16 label \"TSDemux-2\"      block 38 }\n"
"       omar_39 { type \"omar_bus\" width 16 label \"TSDemux-3\"      block 39 }\n"
"       omar_40 { type \"omar_bus\" width 16 label \"SEC-0\"          block 40 }\n"
"       omar_41 { type \"omar_bus\" width 16 label \"SEC-1\"          block 41 }\n"
"       omar_42 { type \"omar_bus\" width 16 label \"SEC-2\"          block 42 }\n"
"       omar_43 { type \"omar_bus\" width 16 label \"SEC-3\"          block 43 }\n"
"       omar_44 { type \"omar_bus\" width 16 label \"SEC-4\"          block 44 }\n"
"       omar_45 { type \"omar_bus\" width 16 label \"SEC-5\"          block 45 }\n"
"       omar_46 { type \"omar_bus\" width 16 label \"SEC-6\"          block 46 }\n"
"       omar_47 { type \"omar_bus\" width 16 label \"SEC-7\"          block 47 }\n"
"       omar_48 { type \"omar_bus\" width 16 label \"ICH7_Legacy-0\"  block 48 }\n"
"       omar_49 { type \"omar_bus\" width 16 label \"ICH7_Legacy-1\"  block 49 }\n"
"       omar_50 { type \"omar_bus\" width 16 label \"IT_TOP-0\"       block 50 }\n"
"       omar_51 { type \"omar_bus\" width 16 label \"IT_TOP-1\"       block 51 }\n"
"       omar_52 { type \"omar_bus\" width 16 label \"Gb-Mac-0\"       block 52 }\n"
"       omar_53 { type \"omar_bus\" width 16 label \"Gb-Mac-1\"       block 53 }\n"
"       omar_54 { type \"omar_bus\" width 16 label \"CRU-0\"          block 54 }\n"
"       omar_55 { type \"omar_bus\" width 16 label \"CRU-1\"          block 55 }\n"
"       omar_56 { type \"omar_bus\" width 16 label \"CRU-2\"          block 56 }\n"
"       omar_57 { type \"omar_bus\" width 16 label \"CRU-3\"          block 57 }\n"
"       omar_58 { type \"omar_bus\" width 16 label \"SATA-0\"         block 58 }\n"
"       omar_59 { type \"omar_bus\" width 16 label \"USB-0\"          block 59 }\n"
"       omar_60 { type \"omar_bus\" width 16 label \"AUD_DSP-0\"      block 60 }\n"
"       omar_61 { type \"omar_bus\" width 16 label \"AUD_DSP-1\"      block 61 }\n"
"       omar_62 { type \"omar_bus\" width 16 label \"GV-0\"           block 62 }\n"
"       omar_63 { type \"omar_bus\" width 16 label \"GV-1\"           block 63 }\n"
"   }\n"
"}\n"
;

static const char *g_omar_group_dirname = "omarlib.group";
static const char *g_omar_block_dirname = "omarlib.block";
static char       *g_omar_config_filename;

/** Parse a text "config file" in memory
 */
int wavesource_ParseConfig(
    struct WaveformSource   *ws,
    const char              *cfg,
    int                      cfg_size )
{
    int             err = 0;
    htuple_t        node_id;

    //printf("wavesource_ParseConfig( %p, %d )\n", cfg, cfg_size );

    if ( NULL == cfg )
    {
        static int g_null_cfg_parsed_already = 0;

        if ( ! g_null_cfg_parsed_already )
        {
            g_null_cfg_parsed_already = 1;
            //***********************************************************************
            // Determine platform and set appropriate vars
            //***********************************************************************
            pal_result_t                         pal_result;
            pal_soc_info_t                       pal_soc_info;

            err = 1;
            pal_result = pal_get_soc_info(&pal_soc_info);

            if ( pal_result == PAL_SUCCESS )
            {
               if ( pal_soc_info.generation == SOC_GENERATION_3 )
               {
                  cfg = omar_config;
                  cfg_size = sizeof(omar_config);
                  ws->ws_capture_clock_frequency = GEN3_OMAR_HW_COUNTDOWN_FREQ;
                  g_omar_config_filename = "omar_gen3.hcfg";
               }
               else
               {
                  cfg = omar_config_gen4;
                  cfg_size = sizeof(omar_config_gen4);
                  ws->ws_capture_clock_frequency = GEN4_OMAR_HW_COUNTDOWN_FREQ;
                  g_omar_config_filename = "omar_gen4.hcfg";
                  // assume GEN4 for all SOC >= GEN4
                  //assert(pal_soc_info.generation == SOC_GENERATION_3);
               }
            }
            //printf("============================================================\n");
            //printf(omar_config);
            //printf("============================================================\n");
        }
        else
        {
            cfg = " ";
            cfg_size = 1;
        }
    }

    htuple_parse_config_string( 0, cfg, cfg_size );

    /* Traverse through configuration "nodes omar.group" */
    if ( 0 != (node_id = htuple_find_child(0,g_omar_group_dirname,strlen(g_omar_group_dirname))) )
    {
        htuple_t        child;

        if ( 0 != (child = htuple_first_child(node_id)) )
        {
            do
            {
                const char      *groupname = NULL;
                int              groupnum = 0;

                htuple_node_name( child, &groupname );
                htuple_node_int_value( child, (unsigned int *) &groupnum );

                if ( NULL != groupname )
                {
                    waveformdata_SetGroupName( &ws->wd, groupnum, groupname, strlen(groupname) );
                }

                child = htuple_next_sibling(child);
            } while ( 0 != child );
        }
    } else printf("can't find \"%s\"\n", g_omar_group_dirname );

    /* Traverse through configuration "nodes omar.block" */
    if ( 0 != (node_id = htuple_find_child(0,g_omar_block_dirname,strlen(g_omar_block_dirname))) )
    {
        htuple_t        child;

        if ( 0 != (child = htuple_first_child(node_id)) )
        {
            do
            {
                const char      *blockname = NULL;
                int              blocknum = 0;

                htuple_node_name( child, &blockname );
                htuple_node_int_value( child, (unsigned int *) &blocknum );

                if ( NULL != blockname )
                {
                    waveformdata_SetBlockName( &ws->wd, blocknum, blockname, strlen(blockname) );
                }

                child = htuple_next_sibling(child);
            } while ( 0 != child );
        }
    } else printf("can't find \"%s\"\n", g_omar_block_dirname );

    return(err);
}

static unsigned int sven_event_payload_match(
	 struct SVENEvent	*ev,
	 struct SVENEvent	*ref )
{
   unsigned int   payload_match = 0;
   int            ri,ei;
   unsigned int   n;

#define REF_EVENT_CHECK_SHIFTED_VALUES

   /* ri = "reference i" (event to find matches for) */
   for ( ri = 0; ri < SVEN_EVENT_PAYLOAD_NUM_UINTS; ri++ )
   {
      n = ref->u.se_uint[ri];

      /* avoid matching common numbers (all powers of two and zero) */
      if  (0 != ( n & (n-1)))
      {
      #ifdef REF_EVENT_CHECK_SHIFTED_VALUES
         unsigned int   nl,nr;

         nl = n << 1;
         nr = n >> 1;
      #endif
         /* see if payload entry N has any matches in candidate event */
         for ( ei = 0; ei < SVEN_EVENT_PAYLOAD_NUM_UINTS; ei++ )
         {
            #ifdef REF_EVENT_CHECK_SHIFTED_VALUES
            if ( (ev->u.se_uint[ei] == n) ||
                 (ev->u.se_uint[ei] == nl) ||
                 (ev->u.se_uint[ei] == nr) )
            {
               /* indicate match for this payload item */
               payload_match |= (1 << ri);
               break;
            }
            #else /* REF_EVENT_CHECK_SHIFTED_VALUES */
            /* matching payload entry (like phys_addr, buff_id */
            if ( ref->u.se_uint[ri] == ev->u.se_uint[ei] )
            {
               /* indicate match for this payload item */
               payload_match |= (1 << ri);
               break;
            }
            #endif /* REF_EVENT_CHECK_SHIFTED_VALUES */
         }
      }
   }

   return( payload_match );
}

/** Get the value of the waveform at time T */
int wavesource_GetShapes(
    struct WaveformSource   *ws,
    unsigned int             sig,
    long long                t0,    /* signed because values typically negative */
    long long                t1,
    unsigned char           *shapes,
    int                      shapes_len )
{
    unsigned long long       shape_clk_div;
    unsigned int             omar_clk_div;
    unsigned int             sven_clk_div;
    unsigned int             shapes_per_omar_sample,omar_shape_phase;
    unsigned int             omar_samples_per_shape;

    /* Fills our array, shapes[i], with (enum WaveSourceSampleShape) */
    DEVH_ASSERT( ws->ws_devh, sig < ws->ws_num_traces );
    DEVH_ASSERT( ws->ws_devh, NULL != shapes );
    DEVH_ASSERT( ws->ws_devh, t0 <= t1 );
    DEVH_ASSERT( ws->ws_devh, 0 != shapes_len );

    /* How many HCLKs per shape .  Should be of type UINT_64 as we can reach
     large values for 10KHz capture frequency */

    shape_clk_div = (t1-t0) / shapes_len;

#if 0
    if ( 0 == sig )
    {
        fprintf( stderr, "t1 %d t0 %d (t1-t0) %d, shapes_len %d ",
            (int) t1,
            (int) t0,
            (int) (t1-t0),
            shapes_len );
    }
#endif

    /* There must be exactly (N * shapes_len) amount of time */
    DEVH_ASSERT( ws->ws_devh, (0 == ((t1-t0) % shape_clk_div)) );

    shapes_per_omar_sample = omar_samples_per_shape = 0;
    omar_clk_div = ws->wd.wd_interval_countdown;
    sven_clk_div = ws->ws_capture_clock_frequency / sven_get_timestamp_frequency();
    /**
     * omar_clk_div = 1200
     * shape_clk_div = 600
     *    should be two shapes per omar sample
     *
     */
    /* is OMAR capture frequency HIGHER than SHAPE frequency? */
    if ( omar_clk_div < shape_clk_div  )
    {
        /* MUST BE INTEGER MULTIPLE */
        DEVH_ASSERT( ws->ws_devh, (0 == (shape_clk_div % omar_clk_div)) );

        /* ---------------------------------- */
        /* Each shape contains N omar samples */
        /* ---------------------------------- */
        omar_samples_per_shape  = shape_clk_div / omar_clk_div;
        omar_shape_phase = 0; /* remove an "unintialized" warning */
    }
    else
    {
        /* MUST BE INTEGER MULTIPLE */
        DEVH_ASSERT( ws->ws_devh, (0 == (omar_clk_div % shape_clk_div)) );

        /* ---------------------------------- */
        /* Each OMAR sample contains N shapes */
        /* ---------------------------------- */
        shapes_per_omar_sample = omar_clk_div / shape_clk_div;
        omar_shape_phase = (t0 / shape_clk_div) % shapes_per_omar_sample;
    }

   if ( sig < ws->ws_num_traces )
   {
      struct WaveTrace    *wt;

      /* convert to (local to the trace) time scale */

      wt = &ws->ws_traces[sig];

        switch( wt->ttype )
        {
            case TRACE_TYPE_OMAR_WIRE:
            {
               int         i ;

               if ( shapes_per_omar_sample )   /* shapes_per_omar_sample >= 2 */
               {
                  int omar_t0;
                  enum WaveSourceSampleShape shape;

                  omar_t0 = t0 / omar_clk_div;
                  shape = wavesource_GetOmarShape(ws, wt->omar_wire.capture_id, omar_t0,
                        omar_t0 + 1);

                  /* Get sample shape, render it according to phase */
                  for (i = 0; i < shapes_len; i++)
                  {
                     switch (shape)
                     {
                     case WSSV_0_to_1: /* _-- */
                     {
                        if (omar_shape_phase < (shapes_per_omar_sample >> 1))
                           shapes[i] = WSSV_0;
                        else if (omar_shape_phase == (shapes_per_omar_sample >> 1))
                           shapes[i] = WSSV_0_to_1;
                        else
                           shapes[i] = WSSV_1;
                     }
                        break;

                     case WSSV_1_to_0: /* -__ */
                     {
                        if (omar_shape_phase < (shapes_per_omar_sample >> 1))
                           shapes[i] = WSSV_1;
                        else if (omar_shape_phase == (shapes_per_omar_sample >> 1))
                           shapes[i] = WSSV_1_to_0;
                        else
                           shapes[i] = WSSV_0;
                     }
                        break;

                     case WSSV_hi_pulse: /* _-_ */
                     {
                        if (2 == shapes_per_omar_sample)
                        {
                           /* 2 samples:  _- -_ */
                           if (0 == omar_shape_phase)
                              shapes[i] = WSSV_0_to_1;
                           else
                              shapes[i] = WSSV_1_to_0;
                        }
                        else if (3 == shapes_per_omar_sample)
                        {
                           /* 3 samples:  __ _- -_ */
                           if (0 == omar_shape_phase)
                              shapes[i] = WSSV_0;
                           else if (1 == omar_shape_phase)
                              shapes[i] = WSSV_0_to_1;
                           else
                              shapes[i] = WSSV_1_to_0;
                        }
                        else /* 4 or greater shapes */
                        {
                           /* 4 samples:  __ _- -- -_ */
                           if (omar_shape_phase < (shapes_per_omar_sample >> 1))
                              shapes[i] = WSSV_0;
                           else if (omar_shape_phase == (shapes_per_omar_sample >> 1))
                              shapes[i] = WSSV_0_to_1;
                           else if (omar_shape_phase == (shapes_per_omar_sample - 1))
                              shapes[i] = WSSV_1_to_0;
                           else
                              shapes[i] = WSSV_1;
                        }
                     }
                        break;

                     case WSSV_lo_pulse: /* -_- */
                     {
                        if (2 == shapes_per_omar_sample)
                        {
                           /* 2 samples:  -_ _- */
                           if (0 == omar_shape_phase)
                              shapes[i] = WSSV_1_to_0;
                           else
                              shapes[i] = WSSV_0_to_1;
                        }
                        else if (3 == shapes_per_omar_sample)
                        {
                           /* 3 samples:  -- -_ _- */
                           if (0 == omar_shape_phase)
                              shapes[i] = WSSV_1;
                           else if (1 == omar_shape_phase)
                              shapes[i] = WSSV_1_to_0;
                           else
                              shapes[i] = WSSV_0_to_1;
                        }
                        else /* 4 or greater shapes */
                        {
                           /* 4 samples:  -- -_ __ _- */
                           if (omar_shape_phase < (shapes_per_omar_sample >> 1))
                              shapes[i] = WSSV_1;
                           else if (omar_shape_phase == (shapes_per_omar_sample >> 1))
                              shapes[i] = WSSV_1_to_0;
                           else if (omar_shape_phase == (shapes_per_omar_sample - 1))
                              shapes[i] = WSSV_0_to_1;
                           else
                              shapes[i] = WSSV_0;
                        }
                     }
                        break;

                     case WSSV_tick: /* |__ */
                     {
                        if (0 == omar_shape_phase)
                           shapes[i] = WSSV_tick;
                        else
                           shapes[i] = WSSV_0;
                     }
                        break;

                     case WSSV_0: /* ___ */
                     case WSSV_1: /* --- */
                     case WSSV_fast_pulse: /* ### */
                     case WSSV_ind: /* ??? */
                     case WSSV_hi_and_lo: /* === */
                     case WSSV_cross: /* =x= */
                     case WSSV_fast_lo: /* ##_ */
                     case WSSV_fast_hi: /* ##- */
                     default:
                        shapes[i] = shape;
                        break;
                     }

                     if (++omar_shape_phase >= shapes_per_omar_sample)
                     {
                        omar_shape_phase = 0;
                        omar_t0++;
                        shape = wavesource_GetOmarShape(ws, wt->omar_wire.capture_id,
                              omar_t0, omar_t0 + 1);
                     }
                  }
               }
               else /* one or more omar samples per shape */
               {
                  int omar_t0;
                  omar_t0 = t0 / omar_clk_div;
                  /* Get multiple OMAR samples per shape */
                  for (i = 0; i < shapes_len; i++)
                  {
                     shapes[i] = wavesource_GetOmarShape(ws, wt->omar_wire.capture_id,
                           omar_t0, omar_t0 + omar_samples_per_shape);

                     omar_t0 += omar_samples_per_shape;
                  }
               }
            }
            break;
            case TRACE_TYPE_OMAR_BUS:
            {
                int             i;
                unsigned int    bus_val;

                #if 0
                if ( 0 == wt->omar_bus.capture_id )
                {
                    fprintf( stderr, "TRACE_0: HCLK[ %d..%d ] SPS: %d SHAPE:%d[%d..%d] OMAR:%d[%d..%d]\n",
                        (int) t0,
                        (int) t1,
                        shapes_per_omar_sample,
                        shape_clk_div,
                        (int) (t0 / shape_clk_div),
                        (int) (t1 / shape_clk_div),
                        omar_clk_div,
                        (int) t0 / omar_clk_div,
                        (int) t1 / omar_clk_div );
                }
                #endif

                if ( shapes_per_omar_sample )   /* shapes_per_omar_sample >= 2 */
                {
                    int                         omar_t0;
                    enum WaveSourceSampleShape  shape;

                    omar_t0 = t0 / omar_clk_div;
                    shape = wavesource_GetBusShape( ws,
                            wt->omar_bus.capture_id,
                            wt->omar_bus.pin_width,
                            omar_t0, omar_t0+1,
                            &bus_val );

                    t0 /= shape_clk_div;      // which shape to start
                    t1 /= shape_clk_div;      // which shape to start


                    /* Get sample shape, render it according to phase */
                    for ( i = 0; i < shapes_len; i++ )
                    {
                        if ( (WSSV_cross == shape) &&
                             (omar_shape_phase != (shapes_per_omar_sample>>1)) )
                        {
                            shapes[i] = WSSV_hi_and_lo;
                        }
                        else
                        {
                            shapes[i] = shape;
                        }

                        if ( ++omar_shape_phase >= shapes_per_omar_sample )
                        {
                            omar_shape_phase = 0;
                            omar_t0++;
                            shape = wavesource_GetBusShape( ws,
                                    wt->omar_bus.capture_id,
                                    wt->omar_bus.pin_width,
                                    omar_t0, omar_t0+1,
                                    &bus_val );

                        }
                    }
                }
                else    /* one or more omar samples per shape */
                {
                    t0 /= omar_clk_div;      // which captured sample to start

                    /* Get multiple OMAR samples per shape */
                    for ( i = 0; i < shapes_len; i++ )
                    {
                        unsigned int    this_bus_val;

                        shapes[i] = wavesource_GetBusShape( ws,
                                wt->omar_bus.capture_id,
                                wt->omar_bus.pin_width,
                                t0,
                                t0 + omar_samples_per_shape,
                                &this_bus_val );

                        if ( (0 != i) && (bus_val != this_bus_val) )
                        {
                            shapes[i] = WSSV_cross;
                        }
                        bus_val = this_bus_val;

                        t0 += omar_samples_per_shape;
                    }
                }
            }
            break;
            case TRACE_TYPE_SVEN_FILTER:
            {
               struct SVENEvent        *ev0, *ev1;
               unsigned int            sven_t0 , offset = 0;
               unsigned int            sven_dt;
               unsigned int            payload_match = 0;
               long long               sven_interval , omar_interval;
               int                     nev0, nev1;
               int                     i;
               int                     capture_start = 0;
               unsigned int            sven_t;

               /* flood fill with zeroes */
               for ( i = 0; i < shapes_len; i++ )
               {
                  shapes[i] = WSSV_0;
               }
               sven_interval = (ws->ws_lastsven_timestamp - ws->ws_firstsven_timestamp);
               omar_interval = ((long long)(ws->wd.wd_bursts_captured /2) * (long long)omar_clk_div/sven_clk_div);

               /* Get the "split" view of captured SVEN Events */
               svenlog_view_event_buffer( ws->ws_svenlog, &ev0, &nev0, &ev1, &nev1 );

               sven_dt = ((t1 - t0) / sven_clk_div);

               if (1 != ws->ws_svenlog_load_enabled)
               {

                  if (( sven_interval < omar_interval) &&  (ws->wd.wd_bursts_captured >= (ws->wd.wd_samples_per_buffer << 1)))
                  {
                     /* Take into account the time elapsed before the first capture has occurred in case of a wrap around */
                     capture_start = (ws->ws_capture_stop_timestamp - ws->ws_capture_start_timestamp - ((ws->wd.wd_samples_per_buffer + 1)  * omar_clk_div / sven_clk_div));

                  }
                  if (( omar_interval < sven_interval) && (ws->wd.wd_bursts_captured >= (ws->wd.wd_samples_per_buffer << 1)))
                  {
                     /* Take into account the time elapsed before the first capture has occurred in case of a wrap around */
                     capture_start = (ws->ws_capture_stop_timestamp - ws->ws_capture_start_timestamp - sven_interval);

                     /* Determine the omar waveform offset as a multiple of the total sven interval. Offset cannot be even */
                     ws->ws_omar_offset = ((sven_interval % omar_interval) == 0) ? (sven_interval / omar_interval) : ((sven_interval / omar_interval)+1);
                     ws->ws_omar_offset = ((ws->ws_omar_offset %2) == 0) ? (ws->ws_omar_offset + 1) : ws->ws_omar_offset;

                     /* Determine the sven waveform offset from zero . */
                     offset = ((ws->ws_omar_offset * (ws->wd.wd_samples_per_buffer + 1) * omar_clk_div / sven_clk_div)) -  sven_interval ;
                  }
               }

               /* calculate t0 in sven time */
               sven_t0 = ws->ws_capture_start_timestamp + capture_start + (t0/sven_clk_div) ;

               for ( i = 0; i < nev0; i++ )
               {
                  sven_t = ev0[i].se_timestamp - sven_t0 + offset;

                  /** Is the Event timestamp within our window? */
                  /** Note we're using UNSIGNED integer to check for the window
                   * intersection, which can be done with a single compare
                   * (using signed math forces two compares)
                   */
                  if ( sven_t < sven_dt )
                  {
                     if ( svenfilter_is_match( &wt->sven.filt, &ev0[i] ))
                     {
                        unsigned long         t;

                        t = ((long long)sven_t *(long long)sven_clk_div) / shape_clk_div;

                        /* Check if an event is selected */
                        if ( 0 != ws->ws_reference_event_active )
                        {
                           payload_match = sven_event_payload_match(
                                      &ev0[i],
                                      &ws->ws_reference_event );
                        }

                        if ( WSSV_0 == shapes[t] )
                        {
                           shapes[t] = WSSV_tick;

                           if ( 0 != payload_match )
                           {
                              shapes[t] = WSSV_payloadmatch_0 | payload_match;
                           }
                        }
                        else /* event has been "touched" */
                        {
                           if ( (shapes[t] >= WSSV_payloadmatch_0) &&
                               (shapes[t] <= WSSV_payloadmatch_63) )
                           {
                              /* shape is already matching, or more bits or 0 */
                              shapes[t] |= payload_match;
                           }
                           else if ( 0 != payload_match )
                           {
                              shapes[t] = WSSV_payloadmatch_0 | payload_match;
                           }
                           else
                           {
                              shapes[t] = WSSV_tock;
                           }
                        }
                     }
                  }
               }
               for ( i = 0; i < nev1; i++ )
               {

                  sven_t = ev1[i].se_timestamp - sven_t0 + offset;

                  /** Is the Event timestamp within our window? */
                  /** Note we're using UNSIGNED integer to check for the window
                   * intersection, which can be done with a single compare
                   * (using signed math forces two compares)
                   */
                  if ( sven_t < sven_dt )
                  {
                     if ( svenfilter_is_match( &wt->sven.filt, &ev1[i] ))
                     {
                        unsigned long         t;

                        t = ((long long)sven_t *(long long)sven_clk_div) / shape_clk_div;

                        if ( 0 != ws->ws_reference_event_active )
                        {
                            payload_match = sven_event_payload_match(
                              &ev1[i],
                              &ws->ws_reference_event );
                        }
                        if ( WSSV_0 == shapes[t] )
                        {
                           shapes[t] = WSSV_tick;

                           if ( 0 != payload_match )
                           {
                              shapes[t] = WSSV_payloadmatch_0 | payload_match;
                           }
                        }
                        else /* event has been "touched" */
                        {
                           if ( (shapes[t] >= WSSV_payloadmatch_0) &&
                               (shapes[t] <= WSSV_payloadmatch_63) )
                           {
                              /* shape is already matching, or more bits or 0 */
                              shapes[t] |= payload_match;
                           }
                           else if ( 0 != payload_match )
                           {
                              shapes[t] = WSSV_payloadmatch_0 | payload_match;
                           }
                           else
                           {
                              shapes[t] = WSSV_tock;
                           }
                        }
                     }
                  }
               }
            }
            break;
            case TRACE_TYPE_BUF_LEVEL:
            {
               struct SVENEvent     *ev0, *ev1, *ev;
               unsigned int          sven_t0,sven_dt, sven_t1;
               int                   nev0, nev1, nev;
               int                   i,n;
               unsigned int          last_q_sven_time;
               unsigned int          last_q_bufs;
               unsigned int          last_q_bytes;
               unsigned int          capture_start = 0;
               unsigned int          sven_interval,omar_interval;
               unsigned int          offset = 0;

               sven_interval = (ws->ws_lastsven_timestamp - ws->ws_firstsven_timestamp);
               omar_interval = ((ws->wd.wd_bursts_captured /2) * (omar_clk_div/sven_clk_div));

               /* Get the "split" view of captured SVEN Events */
               svenlog_view_event_buffer( ws->ws_svenlog, &ev0, &nev0, &ev1, &nev1 );

               if (1 != ws->ws_svenlog_load_enabled)
               {

                  if (( sven_interval < omar_interval) &&  (ws->wd.wd_bursts_captured >= (ws->wd.wd_samples_per_buffer << 1)))
                  {
                     /* Take into account the time elapsed before the first capture has occurred in case of a wrap around */
                     capture_start = (ws->ws_capture_stop_timestamp - ws->ws_capture_start_timestamp - ((ws->wd.wd_samples_per_buffer + 1)  * omar_clk_div / sven_clk_div));

                  }
                  if (( omar_interval < sven_interval) && (ws->wd.wd_bursts_captured >= (ws->wd.wd_samples_per_buffer << 1)))
                  {
                     /* Take into account the time elapsed before the first capture has occurred in case of a wrap around */
                     capture_start = (ws->ws_capture_stop_timestamp - ws->ws_capture_start_timestamp - sven_interval);

                     /* Determine the omar waveform offset as a multiple of the total sven interval. Offset cannot be even */
                     ws->ws_omar_offset = ((sven_interval % omar_interval) == 0) ? (sven_interval / omar_interval) : ((sven_interval / omar_interval)+1);
                     ws->ws_omar_offset = ((ws->ws_omar_offset %2) == 0) ? (ws->ws_omar_offset + 1) : ws->ws_omar_offset;

                     /* Determine the sven waveform offset from zero . */
                     offset = ((ws->ws_omar_offset * (ws->wd.wd_samples_per_buffer + 1) * omar_clk_div / sven_clk_div)) -  sven_interval ;
                  }
               }

               /* calculate t0, t1 in sven time */
               sven_t0 = ws->ws_capture_start_timestamp + capture_start + (t0/sven_clk_div) ;
               sven_dt = (unsigned int) ((t1-t0) / sven_clk_div);
               sven_t1 = ws->ws_capture_stop_timestamp - sven_t0 + offset;

               /* flood fill with LEVEL zero */
               for ( i = 0; i < shapes_len; i++ )
               {
                  shapes[i] = WSSV_level64_0;
               }

               last_q_sven_time = ev0[0].se_timestamp;
               last_q_bufs      = last_q_bytes = 0;

               for ( n = 0; n < 2; n++ )
               {
                  if ( 0 == n )
                  {
                     ev = ev0;   /* first block */
                     nev = nev0; /* first block */
                  }
                  else
                  {
                     ev = ev1;   /* second block */
                     nev = nev1; /* second block */
                  }

                  for ( i = 0; i < nev; i++ )
                  {
                     if ( (SVEN_event_type_smd == ev[i].se_et.et_type) &&
                          (wt->smd.queue == ev[i].u.se_uint[0]) &&   /* logically incorrect optimization, checking payload */
                          ( (SVEN_EV_SMDCore_Queue_Write == ev[i].se_et.et_subtype) ||
                            (SVEN_EV_SMDCore_Queue_Read == ev[i].se_et.et_subtype) ||
                            (SVEN_EV_SMDCore_Queue_Push == ev[i].se_et.et_subtype) ||
                            (SVEN_EV_SMDCore_Queue_Pull == ev[i].se_et.et_subtype) ||
                            (SVEN_EV_SMDCore_Queue_Flush == ev[i].se_et.et_subtype) ) )
                     {
                        /* buffer level (see trunk/smd/core/core/ismd_queue_manager.c)
                         *  queue num:
                         *       payload[0]     SVEN_EV_SMDCore_Queue_Write
                         *       payload[0]     SVEN_EV_SMDCore_Queue_Read
                         *       payload[0]     SVEN_EV_SMDCore_Queue_Flush
                         *       payload[0]     SVEN_EV_SMDCore_Queue_Push
                         *       payload[0]     SVEN_EV_SMDCore_Queue_Pull
                         *  bufs:
                         *       payload[1]     SVEN_EV_SMDCore_Queue_Write
                         *       payload[1]     SVEN_EV_SMDCore_Queue_Read
                         *       payload[1]     SVEN_EV_SMDCore_Queue_Flush
                         *       payload[1]     SVEN_EV_SMDCore_Queue_Push
                         *       payload[1]     SVEN_EV_SMDCore_Queue_Pull
                         *  bytes:
                         *       payload[2]     SVEN_EV_SMDCore_Queue_Write
                         *       payload[2]     SVEN_EV_SMDCore_Queue_Read
                         *       payload[2]     SVEN_EV_SMDCore_Queue_Flush
                         *       payload[2]     SVEN_EV_SMDCore_Queue_Push
                         *       payload[2]     SVEN_EV_SMDCore_Queue_Pull
                         */
                        unsigned int          q_bytes;
                        unsigned int          q_bufs;
                        unsigned int          sven_t;
                        unsigned int          cur_level = 0;

                        q_bufs  = ev[i].u.se_uint[1];
                        q_bytes = ev[i].u.se_uint[2];

                        sven_t = ev[i].se_timestamp - sven_t0 + offset; /* subtract from start of capture */

                        if ( wt->smd.peak_bytes < q_bytes )
                           wt->smd.peak_bytes = q_bytes;
                        if ( wt->smd.peak_bufs < q_bufs )
                           wt->smd.peak_bufs = q_bufs;

                        if ( 0 != wt->smd.peak_bytes )
                        {
                           cur_level = (q_bytes * 64) / wt->smd.peak_bytes;
                        }
                        else if ( 0 != wt->smd.peak_bufs )
                        {
                           cur_level = (q_bufs * 64) / wt->smd.peak_bufs;
                        }

                        if ( cur_level >= 63 )
                           cur_level = 63;


                        /** Is the Event timestamp within our window? */
                        /** Note we're using UNSIGNED integer to check for the window
                         * intersection, which can be done with a single compare
                         * (using signed math forces two compares)
                         */
                        if ( sven_t < sven_dt )
                        {
                           int         t;
                           int shapes_end;

                           t = ((long long)sven_t * (long long)sven_clk_div) / shape_clk_div;

                           shapes_end = ((long long)sven_t1 * (long long)sven_clk_div) / shape_clk_div;
                           /* fill from t to end of the shape buffer */
                           /* this is more than a little wasteful, CPU wise */
                           /* TODO: rewrite this to only overwrite shapes */
                           while (( t <= shapes_len ) && (t <= shapes_end))
                           {
                              shapes[t++] = WSSV_level64_0 + cur_level;
                           }
                        }

                        last_q_sven_time  = ev[i].se_timestamp;
                        last_q_bufs       = q_bufs;
                        last_q_bytes      = q_bytes;
                     } /* is an SMD Queue event for this buffer */
                  }
               }
            }
            break;
            case TRACE_TYPE_GROUP:
            {
               int         i;
               if ( 1 == wt->is_expanded )
               {
                  for ( i = 0; i < shapes_len; i++ )
                  {
                     shapes[i] = 0;
                  }
               }
               else
               {
                  for ( i = 0; i < shapes_len; i++ )
                  {
                     shapes[i] = WSSV_cross;
                  }
               }
            }
            break;
            default:
            {   int         i;
                for ( i = 0; i < shapes_len; i++ )
                {
                    shapes[i] = WSSV_ind;
                }
            }
            break;
        }
    }
    else
    {   int         i;
        for ( i = 0; i < shapes_len; i++ )
        {
            shapes[i] = WSSV_ind;
        }
    }

    return(0);
}

/** returns Error */
int wavesource_GetTraceInfo(
    struct WaveformSource   *ws,
    unsigned int             sig,
    struct WaveTraceInfo    *wti )
{
    /* Fills our array, shapes[i], with (enum WaveSourceSampleShape) */
    DEVH_ASSERT( ws->ws_devh, sig < ws->ws_num_traces );

    if((unsigned int)sig < ws->ws_num_traces)
    {
        *wti = ws->ws_traces[sig].pub;
        return 1;
    }

    return 0;
}

/** returns Error */
WavesourceExpandState wavesource_Expandability(
    struct WaveformSource   *ws,
    unsigned int             sig )
{

    WavesourceExpandState rval=Trace_NotExpandable;

    DEVH_ASSERT( ws->ws_devh, sig < ws->ws_num_traces );

    if ( sig < ws->ws_num_traces )
    {
        struct WaveTrace    *wt;

        wt = &ws->ws_traces[sig];

        if(!wt->is_expandable)
            {

                rval=Trace_NotExpandable;
            }
        else if ( (wt->is_expandable) && (!wt->is_expanded ))
            {

                rval=Trace_Expandable;
            }
        else if ( (wt->is_expandable) && (wt->is_expanded) )
            {

                rval=Trace_Collapsible;
            }
    }
    return rval;
}

#if 0
/** returns Error */
int wavesource_IsCollapsible(
    struct WaveformSource   *ws,
    unsigned int             sig )
{
    /* Fills our array, shapes[i], with (enum WaveSourceSampleShape) */
    DEVH_ASSERT( ws->ws_devh, sig < ws->ws_num_traces );

    if ( sig < ws->ws_num_traces )
    {
        struct WaveTrace    *wt;

        wt = &ws->ws_traces[sig];

        return;
    }

    return(0);
}
#endif
static int wavesource_NumChildren(
    struct WaveformSource   *ws,
    struct WaveTrace        *wt )
{
   UNUSED_PARAMETER(ws);
    if ( TRACE_TYPE_OMAR_BUS == wt->ttype )
    {
        return( wt->omar_bus.pin_width );
    }
    else if (TRACE_TYPE_GROUP == wt->ttype)
    {
       return (wt->group.total_size);
    }

    /* TODO */
    return(0);
}

static int wavesource_InitChildTraces(
    struct WaveformSource   *ws,
    struct WaveTrace        *parent,
    unsigned int             parent_sig,
    struct WaveTrace        *child )
{
   if ( TRACE_TYPE_OMAR_BUS == parent->ttype )
   {
      unsigned int        i;
      /* TODO */
      for ( i = 0; i < parent->omar_bus.pin_width; i++ )
      {
         /* MUST CLEAR STRUCTURE */
         memset( &child[i], 0, sizeof(*child) );
         /* Label should be a concatenation of bus name and pin no. */
         /////////////////////////////////////////////////////////////

         child[i].pub.depth              = parent->pub.depth+1;
         child[i].pub.level_style        = parent->pub.level_style;
         child[i].ttype                  = TRACE_TYPE_OMAR_WIRE;
         child[i].is_expandable          = 0;
         child[i].is_expanded            = 0;
         child[i].parent_trace           = parent_sig;
         child[i].clk                    = parent->clk;
         child[i].omar_wire.block_id     = parent->omar_bus.block_id;
         child[i].omar_wire.pin_id       = parent->omar_bus.pin_id + i;
         child[i].omar_wire.capture_id   = parent->omar_bus.capture_id + i;
         /* Grab the config defined label for this OMAR trace */
         child[i].pub.label              = ws->wd.wd_sig_name[child[i].omar_wire.capture_id];
         /* TODO: OMAR BUSSES ARE EXPANDED FROM LSB TO MSB, REVERSE THIS???? */
      }
   }
   else if ( TRACE_TYPE_GROUP == parent->ttype )
   {
      unsigned int    i = 0;
      htuple_t        tid;
      htuple_t        wid;
      const char     *trace_type;

      /* Traverse through trace */
      if ( 0 != (tid = htuple_find_child( parent->trace_node_id, "trace", strlen("trace"))) )
      {
         if ( 0 != (wid = htuple_first_child(tid)) )
         {
            do
            {
               if ( ! htuple_get_str_value(wid,"type", strlen("type"), &trace_type) )
               {
                  /* MUST CLEAR STRUCTURE */
                  memset( &child[i], 0, sizeof(*child) );

                  /* Build a trace based on this description */
                  wavesource_BuildTrace( ws , &child[i], wid );

                  wid = htuple_next_sibling(wid);

                  i++;
               }

            } while (0 != wid);

         }
      }
   }

   return(0);
}

static void wavesource_UpdateGroupTraceCount(
      struct WaveformSource   *ws,
      struct WaveTrace        *wt,
      unsigned int             sig)
{
   UNUSED_PARAMETER(ws);
   if (TRACE_TYPE_GROUP == wt->ttype)
   {
      wt->group.total_size = wavesource_GetGroupTraceCount(ws,sig,wt->trace_node_id);
   }
}
/** returns Error
 * THIS WILL REBUILD INTERNALLY, YOU MUST CALL
 * wavesource_GetNumTraces() and re-render
 */
int wavesource_ExpandSignal(
    struct WaveformSource   *ws,
    unsigned int             sig )
{
    int         err = 1;

    /* Fills our array, shapes[i], with (enum WaveSourceSampleShape) */
    DEVH_ASSERT( ws->ws_devh, sig < ws->ws_num_traces );

    if ( sig < ws->ws_num_traces )
    {
        struct WaveTrace    *wt;

        wt = &ws->ws_traces[sig];

        if ( wt->is_expandable && !wt->is_expanded )
        {
            unsigned int    num_children;

            wavesource_UpdateGroupTraceCount(ws, wt, sig);
            num_children = wavesource_NumChildren( ws, wt );

            /* Ensure Vertical "trace array" can hold expanded */
            if ( (ws->ws_num_traces + num_children) > ws->ws_max_traces )
            {
                struct WaveTrace    *new_traces;

                /* Trace Array must be realloced */

                /* if new array alloc fails, set num_children to 0 */
                if ( NULL != (new_traces = malloc( (ws->ws_max_traces<<1) * sizeof(*wt))) )
                {

                    wt->is_expanded = 1;
                    /* Copy up-to and including sig */
                    memcpy(
                        &new_traces[0],
                        &ws->ws_traces[0],
                        ((sig+1) * sizeof(*wt)) );

                    wavesource_InitChildTraces( ws, wt, sig,
                        &new_traces[sig+1] );


                    memcpy(
                        &new_traces[sig+1+num_children],
                        &ws->ws_traces[sig+1],
                        ((ws->ws_num_traces - (sig+1)) * sizeof(*wt)) );


                    free( ws->ws_traces );
                    ws->ws_traces = new_traces;
                    ws->ws_max_traces <<= 1;
                    ws->ws_num_traces += num_children;

                    err = 0;
                }
            }
            else
            {
                /* Copy */
                memmove(
                    &ws->ws_traces[sig+1+num_children],
                    &ws->ws_traces[sig+1],
                    ((ws->ws_num_traces - (sig+1)) * sizeof(*wt)) );

                wavesource_InitChildTraces( ws, wt, sig,
                    &ws->ws_traces[sig+1] );

                wt->is_expanded = 1;

                ws->ws_num_traces += num_children;

                err = 0;
            }
        }
    }

    return(err);
}

/** returns Error
 * THIS WILL REBUILD INTERNALLY, YOU MUST CALL
 * wavesource_GetNumTraces() and re-render
 */
int wavesource_CollapseSignal(
    struct WaveformSource   *ws,
    unsigned int             sig )
{
    int         err = 1;
    /* Fills our array, shapes[i], with (enum WaveSourceSampleShape) */
    DEVH_ASSERT( ws->ws_devh, sig < ws->ws_num_traces );

    if ( sig < ws->ws_num_traces )
    {
        struct WaveTrace    *wt;

        wt = &ws->ws_traces[sig];

        if ( wt->is_expandable && wt->is_expanded )
        {
            unsigned int         childsig;
            unsigned int    num_children;

            /* Rebuild Trace Array */

            /* array[sig] stays the same
             * array[sig+ num_sig_children] deleted
             */
            childsig = sig + 1;

            wavesource_UpdateGroupTraceCount(ws, wt, sig);
            num_children = wavesource_NumChildren( ws, wt );


#if 0
            while ( ws->ws_traces[childsig].parent_trace == sig )
            {
                childsig++;
            }
#else
            childsig+=num_children;
#endif
            /* Copy wave traces down */
            memmove(
                &ws->ws_traces[sig+1],
                &ws->ws_traces[childsig],
                (ws->ws_num_traces - childsig) *
                    sizeof(struct WaveTrace) );

            wt->is_expanded = 0;

            /* indicate child signals are gone */
            ws->ws_num_traces -= ((childsig-1) - sig);

            err = 0;
        }
    }
    return(err);
}

/* Black box recording file format */

#include <sven_file.h>

/** returns Error
 */
int wavesource_LoadBlackBoxRecording(
    struct WaveformSource   *ws,
    const char              *filename )
{
   struct _SVENFileHeader        *hdr = &ws->ws_file_hdr;
   struct SVENFile_TraceHeader   *trace = &hdr->svenfile_trace[0];
   FILE                          *fp;
   int                            err = 0;
   off_t                          foff;

   ws->ws_svenlog_load_enabled = 0;

   /* Clear highlighted event */
   ws->ws_reference_event_active = 0;

   /* It is not necessary to check if capture enabled . Check is provided inside stop capture */
   wavesource_StopCapture( ws );

   if ( NULL != (fp = fopen( filename, "rb" )) )
   {
      size_t         wsize,siz;

      wsize = sizeof(ws->ws_file_hdr_buf);
      if ( wsize == (siz = fread( ws->ws_file_hdr_buf, 1, wsize, fp )))
      {
         if ( SVENFileHeader_VERSION_1 == hdr->svenfile_version )
         {
            unsigned int   i;

            foff = trace[0].file_offset;

            for ( i = 0; i < hdr->svenfile_num_traces; i++ )
            {
               if ( BLACKBOX_RECORDING_TRACE_SVEN == trace[i].trace_type )
               {
                  ws->ws_capture_start_timestamp = trace[i].capture_start;
                  ws->ws_capture_stop_timestamp = trace[i].capture_stop;
                  ws->ws_firstsven_timestamp = trace[i].start_marker;
                  ws->ws_lastsven_timestamp = trace[i].stop_marker;
                  if ( ! fseeko( fp, foff, SEEK_SET  ) )
                  {
                     struct SVENEvent     ev;
                     unsigned int         bytes_read = 0;

                     while ( sizeof(ev) == fread( &ev, 1, sizeof(ev), fp ) )
                     {
                        /* insert the event */
                        svenlog_InsertEvent_Locally( ws->ws_svenlog, &ev, 1 );

                        bytes_read += sizeof(ev);
                        if ( bytes_read >= trace[i].file_size )
                        {
                           break;
                        }
                     }
                  }
               }
               else if ( BLACKBOX_RECORDING_TRACE_OMAR == trace[i].trace_type )
               {
                  ws->wd.wd_interval_countdown = trace[i].timestamp_divider;
                  ws->wd.wd_starting_burst     = trace[i].start_marker;
                  ws->wd.wd_bursts_captured    = trace[i].stop_marker;
                  /* Read */
                  if ( trace[i].file_size == fread(
                     ws->wd.wd_sample_buffer, 1, trace[i].file_size, fp ) )
                  {
                  }
                  else
                  {
                     printf("ERR: Failed read from file \"%s\"\n", filename );
                     err++;
                  }
               }
            }
         }
      }
      fclose(fp);
   }
   else
   {
      printf("ERR: Failed to open file \"%s\" for reading\n", filename );
      err++;
   }

   return(err);
}

/** returns Error
 */
int wavesource_SaveBlackBoxRecording(
    struct WaveformSource   *ws,
    const char              *filename )
{
   struct _SVENFileHeader        *hdr = &ws->ws_file_hdr;
   struct SVENFile_TraceHeader   *trace = &hdr->svenfile_trace[0];
   FILE                          *fp;
   int                            err = 0;
   off_t                          foff;

   if ( ws->ws_hw_capture_enabled )
   {
      wavesource_StopCapture( ws );
   }

   /* clear entire header, no chuff */
   memset( ws->ws_file_hdr_buf, 0, sizeof(ws->ws_file_hdr_buf) );

   hdr->svenfile_version      = SVENFileHeader_VERSION_1;
   hdr->svenfile_hdr_size     = sizeof(ws->ws_file_hdr_buf);
   hdr->svenfile_num_traces   = 1;

   foff = hdr->svenfile_hdr_size;   // update file offset

   trace->trace_type          = BLACKBOX_RECORDING_TRACE_SVEN;
   
   trace->hclk_frequency      = ws->ws_capture_clock_frequency;
   trace->timestamp_divider   = ws->ws_capture_clock_frequency / sven_get_timestamp_frequency();

   trace->file_offset         = foff;
   trace->file_size           = ws->ws_svenlog_size;
   trace->capture_start       = ws->ws_capture_start_timestamp ;
   trace->capture_stop        = ws->ws_capture_stop_timestamp ;
   trace->start_marker        = ws->ws_firstsven_timestamp;
   trace->stop_marker         = ws->ws_lastsven_timestamp;

   foff += trace->file_size;

#ifndef SELF_TEST
   if ( 0 == ws->ws_hardware_not_present )
   {
      trace++;
      hdr->svenfile_num_traces++;

      trace->trace_type          = BLACKBOX_RECORDING_TRACE_OMAR;
      trace->hclk_frequency      = ws->ws_capture_clock_frequency;
      trace->timestamp_divider   = ws->wd.wd_interval_countdown;
      trace->file_offset         = foff;
      trace->file_size           = ws->wd.wd_buffer_size;
      trace->capture_start       = (ws->ws_capture_start_word & BMSK_DFX_OMAR_HEADER_WORD_HDR_SAMP);  /* MUST BE IN HCLKS */
      trace->capture_stop        = (ws->ws_capture_stop_word & BMSK_DFX_OMAR_HEADER_WORD_HDR_SAMP);  /* MUST BE IN HCLKS */
      trace->start_marker        = ws->wd.wd_starting_burst;
      trace->stop_marker         = ws->wd.wd_bursts_captured;
      foff += trace->file_size;
   }
#endif

   if ( NULL != (fp = fopen( filename, "wb" )) )
   {
      size_t         wsize,siz;

      wsize = sizeof(ws->ws_file_hdr_buf);
      if ( wsize == (siz = fwrite( ws->ws_file_hdr_buf, 1, wsize, fp )))
      {
         struct SVENEvent     *ev0, *ev1;
         int                   nev0, nev1;

         trace = &hdr->svenfile_trace[0];

         /* Write SVEN events */
         svenlog_view_event_buffer( ws->ws_svenlog, &ev0, &nev0, &ev1, &nev1 );

         if ( (unsigned) nev0 == fwrite( ev0, sizeof(struct SVENEvent), nev0, fp ) )
         {
            if ( 0 != nev1 )
            {
               if ( (unsigned) nev1 == fwrite( ev1, sizeof(struct SVENEvent), nev1, fp ) )
               {
               }
               else
               {
                  printf("ERR: writing SVENEvents to \"%s\"\n", filename );
                  err++;
               }
            }
         }
         else
         {
            printf("ERR: writing SVENEvents to \"%s\"\n", filename );
            err++;
         }


#ifndef SELF_TEST
         if ( (0 == err) && ( 0 == ws->ws_hardware_not_present ) )
         {
            /* Write the entire OMAR Capture buffer */
            if ( ws->wd.wd_buffer_size == fwrite( 
                  ws->wd.wd_sample_buffer,
                  1, ws->wd.wd_buffer_size, fp ) )
            {
            }
            else
            {
               printf("ERR: OMAR Capture Buffer to \"%s\"\n", filename );
               err++;
            }
         }
#endif

      }
      else
      {
         printf("ERR: only wrote %d of %d byte file header to \"%s\"\n", siz, wsize, filename );
         err++;
      }


      fclose(fp);
   }
   else
   {
      printf("ERR: Failed to open file \"%s\" for writing\n", filename );
      err++;
   }

   return(err);
}

/* Find the block id from the block name */
static void omar_htuple_getblockid(
      htuple_t          private_id,
      const char       *blockname,
      unsigned int     *block_id)
{
   htuple_t       node_id;
   const char    *busname;
   bool           block_found = false;

   if ( 0 != (node_id = htuple_find_child(private_id,"omar.bus",strlen("omar.bus"))) )
   {
      if ( 0 != (node_id = htuple_first_child(node_id)) )
      {
         do
         {
            htuple_node_name( node_id, &busname );

            if ( ! strcmp( busname, blockname ))
            {
               htuple_node_int_value( node_id, (unsigned int *) block_id );
               block_found = true;
               break;
            }
            node_id = htuple_next_sibling(node_id);

         } while ( 0 != node_id );
      }
   }

   if (!block_found)
   {
      printf("ERR: Omar block find failed \n");
   }
}

static const char license_text[] =
"/*\n\n"
"  This file is provided under a dual BSD/GPLv2 license.  When using or\n"
"  redistributing this file, you may do so under either license.\n\n"
"  GPL LICENSE SUMMARY\n\n"
"  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.\n\n"
"  This program is free software; you can redistribute it and/or modify\n"
"  it under the terms of version 2 of the GNU General Public License as\n"
"  published by the Free Software Foundation.\n\n"
"  This program is distributed in the hope that it will be useful, but\n"
"  WITHOUT ANY WARRANTY; without even the implied warranty of\n"
"  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU\n"
"  General Public License for more details.\n\n"
"  You should have received a copy of the GNU General Public License\n"
"  along with this program; if not, write to the Free Software\n"
"  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.\n"
"  The full GNU General Public License is included in this distribution\n"
"  in the file called LICENSE.GPL.\n\n"
"  Contact Information:\n"
"    Intel Corporation\n"
"    2200 Mission College Blvd.\n"
"    Santa Clara, CA  97052\n\n"
"  BSD LICENSE\n\n"
"  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.\n"
"  All rights reserved.\n\n"
"  Redistribution and use in source and binary forms, with or without\n"
"  modification, are permitted provided that the following conditions\n"
"  are met:\n\n"
"    * Redistributions of source code must retain the above copyright\n"
"      notice, this list of conditions and the following disclaimer.\n"
"    * Redistributions in binary form must reproduce the above copyright\n"
"      notice, this list of conditions and the following disclaimer in\n"
"      the documentation and/or other materials provided with the\n"
"      distribution.\n"
"    * Neither the name of Intel Corporation nor the names of its\n"
"      contributors may be used to endorse or promote products derived\n"
"      from this software without specific prior written permission.\n\n"
"  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS\n"
"  AS IS AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT\n"
"  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR\n"
"  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT\n"
"  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,\n"
"  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT\n"
"  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,\n"
"  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY\n"
"  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT\n"
"  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE\n"
"  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n\n"
"*/\n"
;

void wavesource_DumpOmarConfig(
      struct WaveformSource   *ws )
{
   FILE                  *fp;
   htuple_t               child, node_id;

   if ( NULL != (fp = fopen(g_omar_config_filename, "wb" )) )
   {

      struct WaveformData       *wd ;

      wd = &(ws->wd);

      fprintf(fp,"%s",license_text);
      fprintf(fp,"omar\n{\n\tbus\n\t{\n");

      if ( 0 != (node_id = htuple_find_child(0,g_omar_block_dirname,strlen(g_omar_block_dirname))) )
      {
         if ( 0 != (child = htuple_first_child(node_id)) )
         {
            do
            {
               const char      *blockname = NULL;
               int              blocknum = 0;

               htuple_node_name( child, &blockname );
               htuple_node_int_value( child, (unsigned int *) &blocknum );

               if ( NULL != blockname )
               {
                  fprintf(fp,"\t\t\"%s\" = %d",wd->wd_block_name[blocknum],blocknum);
                  fprintf(fp,"\n");
               }

               child = htuple_next_sibling(child);
            } while ( 0 != child );
            fprintf(fp,"\t}\n");
         }
      }
      if ( 0 != (node_id = htuple_find_child(0,"omarlib.default_trace",strlen("omarlib.default_trace"))) )
      {
         unsigned int           capture_id;
         unsigned int           block_id, pin_id, pin_width;
         const char            *trace_type;

         fprintf(fp,"\twire\n\t{\n");

         if ( 0 != (child = htuple_first_child(node_id)) )
         {
            do
            {
               if ( ! htuple_get_str_value(child,"type", strlen("type"), &trace_type) )
               {
                  if ( ! strcmp( "omar_bus", trace_type ) ) /* omar bus */
                  {
                     htuple_get_int_value( child, "block", strlen("block"), &block_id );
                     htuple_get_int_value( child, "width", strlen("width"), &pin_width );

                     for(pin_id=0 ; pin_id < pin_width; pin_id ++)
                     {
                        capture_id = (block_id * OMAR_HW_SAMPLES_PER_BLOCK) + pin_id;

                        /* Remove the space at the start of the signal name */
                        if(' ' == wd->wd_sig_name[capture_id][0])
                        {
                           strncpy (wd->wd_sig_name[capture_id],&wd->wd_sig_name[capture_id][1],\
                                 strlen(wd->wd_sig_name[capture_id]));
                        }
                        fprintf(fp,"\t\t{ block = \"%s\" wire = %d label = \"%s\" }\n",\
                              wd->wd_block_name[block_id],pin_id,wd->wd_sig_name[capture_id]);
                     }
                  }
               }

               child = htuple_next_sibling(child);

            } while ( 0 != child );

         }
         fprintf(fp,"\t}\n");

         fprintf(fp,"}");
      }
   }

   fclose(fp);
}

void wavesource_ParseOmarConfig(
      struct WaveformSource   *ws )
{
   int       err = 0;
   FILE     *fp;

   if ( NULL != (fp = fopen(g_omar_config_filename, "r")) )
   {
      char            *txt;
      long             txtlen;

      fseek( fp, 0, SEEK_END );
      txtlen = ftell(fp);
      rewind(fp);

      if ( NULL != (txt = malloc(txtlen+1)) )
      {
         if ( txtlen == (long) fread( txt, 1, txtlen, fp ) )
         {
            htuple_t                   private_id;
            htuple_t                   node_id;
            struct WaveformData       *wd ;

            wd = &(ws->wd);

            if ( 0 == (err = htuple_create_private_tree( &private_id )) )
            {
               /* null term */
               txt[txtlen] = '\0';
               htuple_parse_config_string( private_id, txt, txtlen );

               /* Traverse through trace */
               if ( 0 != (node_id = htuple_find_child(private_id,"omar.wire",strlen("omar.wire"))) )
               {
                  unsigned int           block_id, pin_id;
                  const char            *blockname, *signalname;
                  unsigned int           capture_id;

                  /* go to first entry (not empty) */
                  if ( 0 != (node_id = htuple_first_child(node_id)) )
                  {
                     do
                     {
                        htuple_get_str_value( node_id, "block", strlen("block"), (const char **) &blockname );
                        htuple_get_int_value( node_id, "wire", strlen("wire"), &pin_id );
                        htuple_get_str_value( node_id, "label", strlen("label"), (const char **) &signalname );

                        /* Find the block id from the block name */
                        omar_htuple_getblockid(private_id,blockname,&block_id);

                        capture_id = (block_id * OMAR_HW_SAMPLES_PER_BLOCK) + pin_id;

                        /* store the signal name */
                        wd->wd_sig_name[capture_id] = (char *)signalname;

                        node_id = htuple_next_sibling(node_id);

                     } while (0 != node_id);

                  }
                  else
                  {
                     err = 1;
                     printf("ERR: Nothing found at omar.wire\n");
                  }
               }
               else
               {
                  err = 1;
                  printf("ERR: unable to find node id for omar config file");
               }

               if ( err )
               {
                  htuple_delete_private_tree( private_id );
               }
               else
               {
                  /* Store the htuple id  */
                  ws->omar_config_id = private_id;
                  printf("Successfully parsed omar config file \"%s\"\n",g_omar_config_filename );
               }
            }
            else
            {
               printf("ERR: htuple_create_private_tree() failed\n" );
            }
         }
         else
         {
            printf("ERR: fread(%ld) failed\n", txtlen );
         }
         free(txt);
      }
      else
      {
         printf("ERR: malloc(%ld) failed\n", txtlen );
      }

      fclose(fp);
   }
   else
   {
      printf("ERR: unable to open omar config file \"%s\"\n",g_omar_config_filename );
   }

}
