/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2010-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2010-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* NO Registers for the mvc remux as it is entirely a software component */
static const struct EAS_Register g_csr_CES[] =
{
   { NULL,0,NULL,"",NULL }   /* NULL Terminated */
};
#endif /* INTERNAL_BUILD */

/*   Use the below structure for creating trackable high level events.
 * Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_CES_specific_events[] =
{
   /* CES FW events 0x00..0x33 */

   /* CES instance opened */
   { "OPEN",                   1, "   ID: %d, ret:0x%08X %08X %08X %08X %08X", NULL },

   /* CES instance closed */
   { "CLOSE",                  2, "   ID: %d", NULL },
   { "GV_SYNC_ST",             3, "   func_id=%4d serv=%4d %4d 0x%08X 0x%08X 0x%08X", NULL },
   { "GV_SYNC_END",            4, "   func_id=%4d serv=%4d %4d 0x%08X 0x%08X 0x%08X", NULL },
   /* Videnc FW events 0x34..0x66 */

   /* Videnc fw read workload */
   { "VIDENC_READ_WKLD",                   0x34, "   Stream: %d, Success: %d, WKLD ID: %x, WKLD Phys: %x, WKLD Length: %x, WKLD Flags: %x", NULL },

   /* Videnc fw write workload */
   { "VIDENC_WRITE_WKLD",                  0x35, "   Stream: %d, Success: %d, WKLD ID: %x, WKLD Phys: %x, WKLD Length: %x, WKLD Flags: %x", NULL },

   /* videnc fw state change - DBG mode only */
   { "VIDENC_DBG_H264_STATE_CHANGE",       0x36, "   New State: %d, Prev State iterations: %d", NULL },
    
   /* Videnc fw read es descriptor - DBG mode only*/
   { "VIDENC_DBG_READ_ES",                 0x37, "   Stream: %d, Success: %d, ES ID: %x, ES Phys: %x, ES Length: %x, ES Flags: %x", NULL },

   /* Mux FW events 0x67..0x99 */
   /*Opened new mux fw instance*/
   {"MUX_FW_OPEN_NEW_INSTANCE",        0x67, "ID: 0x%X Type: 0x%X Status: 0x%X", NULL },
   /*Flush*/
   {"MUX_FW_FLUSH",                    0x68, "Instance: 0x%X Status: 0x%X", NULL },
   /*Closed an instance*/
   {"MUX_FW_CLOSE_INSTANCE",           0x69, "Instance: 0x%X Status: 0x%X", NULL },
   
   /*Read a workload from input queue*/
   {"MUX_FW_READ_WKLD",                0x80, "Instance: 0x%X Type: 0x%X Flags: 0x%X", NULL },
   /*Read an empty output buffer from input queue*/
   {"MUX_FW_CONSUMED_EMPTY_OUTBUFF",   0x81, "Instance: 0x%X Flags: 0x%X Size: 0x%X", NULL },
   /*Outputted a workload*/
   {"MUX_FW_WROTE_WKLD",               0x82, "Instance: 0x%X Type: 0x%X Flags: 0x%X", NULL },
   /*Outputted an output buffer*/
   {"MUX_FW_WROTE_OUTPUT_BUFFER",      0x83, "Instance: 0x%X Flags: 0x%X Size: 0x%X Level: 0x%X", NULL },

   /*An assumption is broken, use identifier to find assertion generating code*/
   {"MUX_FW_DBG_ASSERT",               0x90, "Instance: 0x%X Assertion identifier: 0x%X", NULL },

   /* Viddec Parser FW events 0x9A..0xCC */
   { "TRACE",                    0x9A, " %d %d 0x%08X 0x%08X 0x%08X 0x%08X", NULL },
   { "FW_PAR_OPEN",              0x9B, " strm_id=%08d codec=%08d  in_es_q=%08d in_wk_q=%08d out_wk_q=%08d dumm=0x%08X", NULL },
   { "FW_PAR_CLOSE",             0x9C, " strm_id=%08d result=%08d dumm=%08d dumm=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { "FW_PAR_SET_STATE",         0x9D, " strm_id=%08d state =%08d prev=%08d dumm=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { "FW_PAR_FLUSH",             0x9E, " strm_id=%08d result=%08d dumm=%08d dumm=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { "FW_PAR_WKLD_ST",           0x9F, " strm_id=%08d wl_cur=%08X wl_ne=%08X dumm=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { "FW_PAR_WKLD_DN",           0xA0, " wl_phys=%08X dumm=%08d dumm=%08d dumm=%08d dumm=0x%08X dumm=0x%08X", NULL },

   /* Viddec Decoder FW events 0xCD..0xFF */
   { "FW_DEC_OPEN",              0xCD, " strm_id=%08d codec=%08d  in_q=%08d outq=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { "FW_DEC_CLOSE",             0xCE, " strm_id=%08d result=%08d dumm=%08d dumm=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { "FW_DEC_SET_STATE",         0xCF, " strm_id=%08d state =%08d dumm=%08d dumm=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { "FW_DEC_FLUSH",             0xD0, " strm_id=%08d type  =%08d dumm=%08d dumm=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { "FW_DEC_WKLD_ST_BEG",       0xD1, " wkld_ph=%08X codec =%08d outq=%08d dumm=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { "FW_DEC_WKLD_ST_END",       0xD2, " wkld_ph=%08X codec =%08d outq=%08d stat=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { "FW_DEC_WKLD_DONE",         0xD3, " wkld_ph=%08X state =%08d outq=%08d dumm=%08d dumm=0x%08X dumm=0x%08X", NULL },
   { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_CES_sven_module =
{
   "SW_CES",                  /*  */
   SVEN_module_CES,           /* Find your module in <sven_module.h> */
   0,                         /* Size of MMRs */
#ifdef SVEN_INTERNAL_BUILD
   g_csr_CES,                 /*  */
#else
   NULL,                      /* What is the latest HW version to use? */
#endif
   "CES: Common Embedded Services",/* Get a better text string */
   g_CES_specific_events,     /* Define important events specific to my module */
   NULL                       /* extension list */
};
