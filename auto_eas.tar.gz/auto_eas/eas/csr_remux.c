/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2009-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2009-2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* NO Registers for the mvc remux as it is entirely a software component */
static const struct EAS_Register g_csr_REMUX[] =
{
   { NULL,0,NULL,"",NULL }   /* NULL Terminated */
};
#endif /* INTERNAL_BUILD */

/*   Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_REMUX_specific_events[] =
{

   /* Remux instance opened */
   { "OPEN",                   1, " ID: %d, Out Port ID: %d, Port Depth: %d", NULL },

   /* Remux instance closed */
   { "CLOSE",                  2, " ID:%d", NULL },

   /* Input View added */
   { "VIEW_ADDED",             3, " ID:%d, View ID:%d, In Port:%d", NULL },

   /* Input view removed */
   { "VIEW_REMOVED",           4, " ID:%d View ID:%d", NULL },

   /* Port flushed */
   { "PORT_FLUSHED",           5, " ID:%d, View ID:%d, In Port:%d", NULL },

   /* Port flush error */
   { "PORT_FLUSH_ERROR",       6, " ID:%d, View ID:%d, In Port:%d, err:%d", NULL },

   /* Read input port */
   { "IN_DEQUEUE",             7, " ID:%d, View ID:%d, In Port:%d, DTS/2:%d, Buffer:%d, Curr Depth:%d", NULL },

   /* Write output port */
   { "OUT_ENQUEUE",            8, " ID:%d, View ID:%d, Out Port:%d, DTS/2:%d, Buffer:%d, Curr Depth:%d", NULL },

   /* Output port full */
   { "OUT_PORT_FULL",          9, " ID %d, Out Port: %d", NULL },

   /* Input port empty */
   { "IN_PORT_EMPTY",          10, " ID:%d, View ID:%d, In port:%d ", NULL },

   /* Input port full */
   { "IN_PORT_FULL",           11, " ID:%d, View ID:%d, In port:%d ", NULL },

   /* Remux state change */
   { "STATE_CHANGE",           12, " ID:%d, Old State:~ %d, New Sate:%d", NULL },

   /* Start of mvc frame at input */
   { "INPUT_FRAME_START",      13, " ID:%d, View ID:%d, DTS/2:%d, Buffer:%d", NULL },

   /* End of mvc frame at input */
   { "INPUT_FRAME_END",        14, " ID:%d, View ID:%d, DTS/2:%d, Buffer:%d", NULL },

   /* Input buffer dropped */
   { "DROPPED",                15, " ID:%d, View ID:%d, Dep DTS/2:%d, Base DTS/2:%d, Buffer:%d", NULL },

   /* EOS recieved */
   { "EOS",                    16, " ID:%d, View ID:%d, Buffer:%d", NULL },

   /* Late Frame */
   { "LATE_FRAME",             17, " ID:%d, View ID:%d, Dep DTS/2:%d, Base DTS/2:%d, Buffer:%d", NULL },

   /* Dependent view DTS matched the base view DTS */
   { "DTS_MATCH",              18, " ID:%d, View ID:%d, Dep DTS/2:%d, Base DTS/2:%d, Buffer:%d", NULL },

   /* State of remux when it goes from STOP to PAUSE or immediately after the
      stream is flushed */
   { "INPUT_STREAM_RESET",     19, " ID:%d", NULL },

   /* API_LOCK_EVENT was strobed by user API */
   { "STROBE_API_LOCK_EVENT",  20, " ID:%d, API:%d", NULL },

   /* API_UNLOCK_EVENT was strobed */
   { "STROBE_API_UNLOCK_EVENT",21, " ID:%d, API:%d", NULL },

   /* API_LOCK_EVENT was acknowledged */
   { "ACK_API_LOCK_EVENT",     22, " ID:%d, API : %d", NULL },

   /* API_UNLOCK_EVENT was acknowledged */
   { "ACK_API_UNLOCK_EVENT",   23, " ID:%d, API : %d", NULL },

   /* THREAD_EXIT_EVENT strobed */
   { "STROBE_THREAD_EXIT_EVENT",24, " ID:%d, API : %d", NULL },

   /* ACK_THREAD_EXIT_EVENT acknowledged*/
   { "ACK_THREAD_EXIT_EVENT",  25, " ID:%d, API : %d", NULL },

   /* Context lock acquired */
   { "CONTEXT_LOCK_ACQUIRED",  26, " ID:%d, API : %d", NULL },

   /* Context lock released */
   { "CONTEXT_LOCK_RELEASED",  27, " ID:%d, API : %d", NULL },

   /* Peek port success */
   { "PEEK_PORT",              28, " ID:%d, View ID:%d, In Port:%d, Buffer:%d, Position:%d", NULL },

   /* Input tag is present on the buffer being processed currently */
   { "TAG_PRESENT",            29, " ID:%d, View ID:%d, Buffer:%d", NULL },

   /* Input tag is present on the buffer being processed currently and it is
   dropped (by buffer alias operation) */
   { "TAG_DROPPED",            30, " ID:%d, View ID:%d, Buffer:%d", NULL },

   /* Frame currently being processed on a dependent input view is a future frame */
   { "FUTURE_FRAME",           31, " ID:%d, View ID:%d, Dep DTS/2:%d, Base DTS/2:%d, Buffer:%d", NULL },

   /* Input drop policy set on remux instance */
   { "INPUT_DROP_POLICY_SET",        32, " ID:%d, Policy:%d", NULL },

   { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_REMUX_sven_module =
{
   "SW_REMUX",                /*  */
   SVEN_module_REMUX,         /* Find your module in <sven_module.h> */
   0,                          /* Size of MMRs */
#ifdef SVEN_INTERNAL_BUILD
   g_csr_REMUX,               /*  */
#else
   NULL,                       /* What is the latest HW version to use? */
#endif
   "REMUX: REMUX",/* Get a better text string */
   g_REMUX_specific_events,   /* Define important events specific to my module */
   NULL                        /* extension list */
};
