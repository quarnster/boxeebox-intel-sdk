/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

/*	Use the below structure for creating trackable high level events versus 
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_SMD_CORE_specific_events[] =
{
#if 0
    // THESE Definitions have been HOISTED to sven_event_type.h
    // SVEN_EV_SMDCore_Xxx_Yyy
    // No defines will be generated for these values, do not use them.
    { "PORT_ALLOC",       0x01,    "Port Allocate", NULL },        /* will contain queue id */
    { "PORT_FREE",        0x02,    "Port Free", NULL },            /* */
    { "PORT_CONNECT",     0x03,    "Port Connect", NULL },         /* producer/consumer port_id */
    { "PORT_DISCONNECT",  0x04,    "Port Disconnect", NULL },      /* producer/consumer port_id */
    { "QUEUE_ALLOC",      0x11,    "Queue Allocate", NULL },       /* will contain queue ID */
    { "QUEUE_FREE",       0x12,    "Queue Free", NULL },           /* QID */
    { "QUEUE_SET_CONFIG", 0x13,    "Queue Set Config", NULL },     /* max_buffers, max_bytes, callback.... */
    { "QUEUE_WRITE",      0x14,    "Queue Write", NULL },
    { "QUEUE_READ",       0x15,    "Queue Read", NULL },
    { "QUEUE_FLUSH",      0x16,    "Queue Flush", NULL },
    { "QUEUE_WRITE_FAIL", 0x17,    "Queue Write Fail", NULL },
    { "QUEUE_READ_FAIL",  0x18,    "Queue Read Fail", NULL },
    { "QUEUE_PUSH",       0x19,    "Queue Direct Push", NULL },    /* will not be generated yet */
    { "QUEUE_PULL",       0x1a,    "Queue Direct Pull", NULL },    /* will not be generated yet */
    { "BUF_ALLOC",        0x21,    "Buffer Allocate", NULL },      /* buffer size, phys_addr, virtual_addr (kern) */
    { "BUF_FREE",         0x22,    "Buffer Free", NULL },
    { "BUF_ADDREF",       0x23,    "Buffer Inc Refcount", NULL },
    { "BUF_DEREF",        0x24,    "Buffer Dec Refcount", NULL },
    { "BUF_RELEASE",      0x25,    "Buffer Release", NULL }, /* ref count goes to NULL, returned to  */
#endif
	{ NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_SMD_CORE_sven_module =
{
    "SW_SMD_CORE",                   /* */
    SVEN_module_SMD_CORE,            /* Find your module in <sven_module.h> */
    0,                               /* Size of MMRs */
    NULL,                            /* No registers defined */
    "SMD_CORE: Media Driver Core",   /* text description*/
    g_SMD_CORE_specific_events,      /* Define important events specific to my module */
	NULL                             /* extension list */
};

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

/*	Use the below structure for creating trackable high level events versus 
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_GST_PLUGIN_specific_events[] =
{
	{ NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GST_PLUGIN_sven_module =
{
    "SW_GST_PLUGIN",                 /* */
    SVEN_module_GST_PLUGIN,          /* Find your module in <sven_module.h> */
    0,                               /* Size of MMRs */
    NULL,                            /* No registers defined */
    "GST_PLUGIN: GStreamer Plugins", /* text description*/
    g_GST_PLUGIN_specific_events,    /* Define important events specific to my module */
	NULL                             /* extension list */
};
