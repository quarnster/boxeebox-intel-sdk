/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
#define OLO

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Simplest Possible example of EAS definition */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

/* Declare the bit-breakout for the register defined in the EAS_Register defs below.
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MyModule_versions.
 */

// Refere to "Section 4.1.2 BSR_AVI_CONTROL" (Page 51, Vermillion Range AVI FPGA LLD)
#ifdef GEN2 //if it is Gen2 HS
static const struct EAS_RegBits g_csr_AVI_CONTROLX[] =
{
    { "RSVD_31_18",  31,18, "",NULL },   /* 17 - Enable the AVO Altera Flash programming interface */
    { "AVO_FLASH_EN",  17,1, "",NULL },   /* 17 - Enable the AVO Altera Flash programming interface */
    { "AVI_FLASH_EN",  16,1, "",NULL },   /* 16 - Enable the AVI Altera Flash programming interface */
    { "LED3_RED", 15,1,"",NULL },             /* 15 - General purpose Red LED */
    { "LED3_YEL", 14,1,"",NULL },             /* 14 - General purpose Yellow LED */
    { "LED3_GRN1", 13,1,"",NULL },             /* 13 - General purpose Green LED */
    { "LED3_GRN0", 12,1,"",NULL },             /* 12 - General purpose Green LED */
    { "SPD_SCL_PIN_STAT",11,1,"",NULL },  /* 11 - DIMM SPD I2C Clock Pin Status */
    { "SPD_SDA_PIN_STAT",10,1,"",NULL },  /* 10 - DIMM SPD I2C Data Pin Status */
    { "SPD_SCL_PIN_CTRL",9,1,"",NULL },   /* 9 - DIMM SPD I2C Clock Pin Control */
    { "SPD_SDA_PIN_CTRL",8,1,"",NULL },   /* 8 - DIMM SPD I2C Data Pin Control */
    { "RSVD_7",         7,1, "",NULL },   /* 7  - RSVD */
    { "I2S_RESET_N",    6,1, "",NULL },   /* 6  - Reset the I2S TBE */
    { "TS_RESET_N",    5,1, "",NULL },    /* 5 - Reset the TS TBE */
    { "BT656_RESET_N",4,1, "",NULL },     /* 4 - Reset the BT656 TBE */
    { "RSVD_3",         3,1, "",NULL },   /* 3  - RSVD */
    { "I2S_INTF_EN",    2,1, "",NULL },   /* 2  - Enable the interface portion of the I2S TBE */
    { "TS_INTF_EN",     1,1, "",NULL },   /* 1  - Enable the interface portion of the TS TBE */
    { "BT656_INTF_EN", 0,1, "",NULL },    /* 0  - Enable the interface portion of the BT656 TBE */
    { NULL,             0,0, "",NULL }    /* NULL Terminated */
};

#else  //If it is Fair Oaks for VR
static const struct EAS_RegBits g_csr_AVI_CONTROLX[] =
{
    { "RSVD_31_18",    18,14,"",NULL },   /* 31 : 18 - RSVD */
    { "AVO_FLASH_EN",  17,1, "",NULL },   /* 17 - Enable the AVO Altera Flash programming interface */
    { "AVI_FLASH_EN",  16,1, "",NULL },   /* 16 - Enable the AVI Altera Flash programming interface */
    { "RSVD_15",       15,1, "",NULL },   /* 15 - RSVD */
    { "SPDIF_RESET_N", 14,1, "",NULL },   /* 14 - Reset the SPDIF TBE */
    { "HDMI_RESET_N",  13,1, "",NULL },   /* 13 - Reset the HDMI TBE */
    { "TS_RESET_N",    12,1, "",NULL },   /* 12 - Reset the TS TBE */
    { "RGB_RESET_N",   11,1, "",NULL },   /* 11 - Reset the RGB TBE */
    { "BT1120_RESET_N",10,1, "",NULL },   /* 10 - Reset the BT1120 TBE */
    { "VCAP_RESET_N",   9,1, "",NULL },   /* 9  - Reset the VCAP TBE */
    { "I2S_RESET_N",    8,1, "",NULL },   /* 8  - Reset the I2S TBE */
    { "RSVD_7",         7,1, "",NULL },   /* 7  - RSVD */
    { "SPDIF_INTF_EN",  6,1, "",NULL },   /* 6  - Enable the interface portion of the SPDIF TBE */
    { "HDMI_INTF_EN",   5,1, "",NULL },   /* 5  - Enable the interface portion of the HDMI TBE */
    { "TS_INTF_EN",     4,1, "",NULL },   /* 4  - Enable the interface portion of the RGB TBE */
    { "RGB_INTF_EN",    3,1, "",NULL },   /* 3  - Enable the interface portion of the RGB TBE */
    { "BT1120_INTF_EN", 2,1, "",NULL },   /* 2  - Enable the interface portion of the BT1120 TBE */
    { "VCAP_INTF_EN",   1,1, "",NULL },   /* 1  - Enable the interface portion of the VCAP TBE */
    { "I2S_INTF_EN",    0,1, "",NULL },   /* 0  - Enable the interface portion of the I2S TBE */
    { NULL,             0,0, "",NULL }    /* NULL Terminated */
};
#endif

//BSR_AVI_I2S_CONTROL
static const struct EAS_RegBits g_csr_AVI_I2S_CONTROLX[] =
{
    { "RSVD_31_21",   21,11,"",NULL },  /* 31 : 21 - RSVD */
    { "BURST_SIZE",   16,5,"",NULL },   /* 20 : 16 - burst size of the memory agent to the AHB-Lite bus */
    { "LOOP",         8,8,"",NULL },    /* 15 : 8 - Defines number of loops in Loop Mode */
    { "RSVD_7_6",     6,2,"",NULL },    /* 7 : 6 - RSVD */
    { "CLR_UFLOW",    5,1,"",NULL },    /* 5 - When you set this bit to 1, it clears the packet_fifo_uflow and packet_buffer_uflow flags in the STATUS register */
    { "MEM_AGENT_EN", 4,1,"",NULL },    /* 4 - Enable Memory Agent */
    { "MODE",         2,2,"",NULL },    /* 3 : 2 - Mode : Loop or Streaming Mode */
    { "MSB_JUSTIFIED",1,1,"",NULL },    /* 1 - Sets the timing of I2S interface */
    { "RSVD_0",       0,1,"",NULL },    /* 0 - RSVD */
    { NULL,           0,0,"",NULL }     /* NULL Terminated */
};

//BSR_AVI_I2S_STATUS
static const struct EAS_RegBits g_csr_AVI_I2S_STATUSX[] =
{
    { "LOOP_DONE",31,1,"",NULL },       /* 31  - Looping completed */
    { "TX_FIFO_UFLOW",30,1,"",NULL },   /* 30  - TX FIFO underflow */
    { "I2S_BUFFER_UFLOW",29,1,"",NULL },/* 29 - I2S Buffer underflow */
    { "RSVD_28_17",17,12,"",NULL },     /* 28 : 17 - Reserved */
    { "TX_FIFO_EMPTY",16,1,"",NULL },   /* 16 - Read only status of the TX FIFO */
    { "TX_COUNT",0,16,"",NULL },        /* 15 : 0 - Number of 20-bit word retrieved from the TX_FIFO and presumably transmitted to SPDIF Tx data pin */
    { NULL,0,0,"",NULL }                /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_BSR_AVI_TS_CONTROL[] =
{
    { "RSVD_31_27",27,5,"",NULL },      /* */
    { "Burst_Size",24,3,"",NULL },      /* */
    { "TS_CLK_Edge",23,1,"",NULL },     /* */
    { "ERR_Polarity",22,1,"",NULL },    /* */
    { "SYNC_Polarity",21,1,"",NULL },   /* */
    { "DAV_Polarity",20,1,"",NULL },    /* */
    { "CLR_uFlow",19,1,"",NULL },       /* */
    { "RSVD_18_17",17,2,"",NULL },      /* */
    { "Inject_Error",16,1,"",NULL },    /* */
    { "Loop",8,8,"",NULL },             /* */
    { "Calendaring",7,1,"",NULL },      /* */
    { "Timestamp",6,1,"",NULL },        /* */
    { "Serial_Parallel",5,1,"",NULL },  /* */
    { "MEM_Agent_EN",4,1,"",NULL },     /* */
    { "Mode",2,2,"",NULL },             /* */
    { "RSVD_1_0",0,2,"",NULL },         /* */

    CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_BSR_AVI_TS_STATUS[] =
{
    { "RSVD_31_7",7,25,"",NULL },       /* */
    { "PACKET_FIFO_Empty",6,1,"",NULL },/* */
    { "PACKET_FIFO_Full",5,1,"",NULL }, /* */
    { "MEM_Agent_Loop_Done",4,1,"",NULL }, /* */
    { "MEM_Agent_Underrun",3,1,"",NULL },  /* */
    { "Address_Error",2,1,"",NULL },    /* */
    { "RSVD_1_0",0,2,"",NULL },         /* */

    CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_BSR_AVI_TS_PACKET_FORMAT[] =
{
    { "RSVD_31_24",24,8,"",NULL },      /* */
    { "Packet_Size",16,8,"",NULL },     /* */
    { "RSVD_15_8",8,8,"",NULL },        /* */
    { "Num_Valid_Bytes",0,8,"",NULL },  /* */

    CSR_BB_NULL_TERM()
};

static const struct EAS_Register g_csr_AVI[] =
{
    { "CONTROL",                   0x000008,g_csr_AVI_CONTROLX ,"AVI Configuration Control Register.",NULL },

    { "I2S_CONTROL",               0x010000,g_csr_AVI_I2S_CONTROLX ,"I2S AVI Configuration Control Register.",NULL },
    { "I2S_STATUS",                0x010004,g_csr_AVI_I2S_STATUSX ,"I2S AVI Configuration Status Register.",NULL },
    { "I2S_BUF_START_ADDR",        0x010018,NULL ,"I2S AVI Buffer Start Address",NULL },
    { "I2S_BUF_END_ADDR",          0x01001c,NULL ,"I2S AVI Buffer End Address",NULL },
    { "I2S_BUF_RD_PTR",            0x010020,NULL ,"I2S AVI Buffer Read Pointer",NULL },
    { "I2S_BUF_WR_PTR",            0x010024,NULL ,"I2S AVI Buffer Write Pointer",NULL },

    CSR_REG_W_BB("BSR_AVI_TS_CONTROL",         0x0000,g_csr_BSR_AVI_TS_CONTROL,         "Pre-Filter Control register")
    CSR_REG_W_BB("BSR_AVI_TS_STATUS",          0x0004,g_csr_BSR_AVI_TS_STATUS,          "Pre-Filter Status register")
    CSR_REG(     "BSR_AVI_TS_PACKET_COUNT",    0x0008,                                  "Pre-Filter Number of Packets Sent (Read only)")
    CSR_REG(     "BSR_AVI_TS_CALENDAR",        0x000C,                                  "Pre-Filter Packet Source if Calendaring is enabled")
    CSR_REG_W_BB("BSR_AVI_TS_PACKET_FORMAT",   0x0010,g_csr_BSR_AVI_TS_PACKET_FORMAT,   "Pre-Filter Packet Size and Formatting info")
    CSR_REG(     "BSR_AVI_TS_BUF_START_ADDR",  0x0014,                                  "Pre-Filter TS buffer Start Address")
    CSR_REG(     "BSR_AVI_TS_BUF_END_ADDR",    0x0018,                                  "Pre-Filter TS buffer End Address")
    CSR_REG(     "BSR_AVI_TS_READ_PTR",        0x001C,                                  "Pre-Filter Read Pointer (aligned to frame boundary)")
    CSR_REG(     "BSR_AVI_TS_WRITE_PTR",       0x0020,                                  "Pre-Filter Write Pointer (should always be 16-byte aligned 0x010, 0x020...)")

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

static const struct SVEN_Module_EventSpecific g_tbe_avi_specific_events[] =
{
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_TBE_AVI_sven_module =
{
    "TBE_AVI",              /*  */
    SVEN_module_TBE_AVI,    /*  */
    0x02000000,             /* BAR SIZE */
#ifdef SVEN_INTERNAL_BUILD
    g_csr_AVI,              /* What is the latest HW version to use? */
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "TBE: AVI Multi-Stream Stimulus Card (mirrored FPGAs)",        /* text string */
    g_tbe_avi_specific_events,  /* TODO-Later: Define important events specific to my module */
    NULL /* extension list */
};
