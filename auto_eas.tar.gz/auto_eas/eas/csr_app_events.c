/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* NO Registers for the bufmon as it is entirely a software component */
static const struct EAS_Register g_csr_APP_EVENTS[] =
{
   { NULL,0,NULL,"",NULL }   /* NULL Terminated */
};
#endif /* INTERNAL_BUILD */

/*   Use the below structure for creating trackable high level events versus 
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_APP_EVENTS_specific_events[] =
{
   
   { "CC_CMD", 1, "Channel change command", NULL },  /* keypress for channel change entered */
     
   { "CC_TEARDOWN_START", 2, "Channel change start", NULL },  /* keypress for channel change entered */
   
   { "CC_TEARDOWN_END", 3, "Channel change end",NULL },  /* teardown (or flush) complete */

   { "STREAM_START", 4,  " Stream start", NULL }, /* Data started moving through the pipeline */

   { "STREAM_STOP", 5, " Stream end",NULL }, /* Data stopped moving through the pipeline */ 

   { "TRICK_PLAY_START", 6," Trick play start", NULL }, /* Pipeline entered into trick play */

   { "TRICK_PLAY_COMPLETE", 7, " Trick play complete", NULL }, /* Pipeline exited from trick play*/

   { "STOP", 8, "Pipeline stop", NULL }, /* Pipeline entered stop state */

   { "PLAY", 9, "Pipeline play", NULL }, /* Pipeline entered play state */       

   { "PAUSE", 10, "Pipeline pause", NULL },  /* Pipeline entered pause state */  

   { "INIT_COMPLETE", 11, "Pipeline init complete",  NULL },  /* Application init complete (memory alloc etc) */      

   { "EXIT_BEGIN", 12, "Pipeline exit begin", NULL },  /* Application exiting started */       
   
   { "EXIT_COMPLETE", 13, "Pipeline exit complete", NULL },  /* Application exiting finished */       

   { "CC_BUFFERING_START", 14, "Channel change buffering start",  NULL }, /* App has started buffering */ 
   
   { "CC_BUFFERING_END", 15, "Channel change buffering end",  NULL }, /* App has completed buffering */ 

   { "CC_BUILDUP1_START", 16, "Channel change buildup start", NULL },  /* App has started 1st part of building up 
                                              after channel change */

   { "CC_BUILDUP1_END", 17, "Channel change buildup end", NULL },  /* App has finished 1st part of building up 
                                              after channel change */
   
   { "CC_BUILDUP2_START", 18, "Channel change buildup start", NULL },  /* App has started 2nd part of building up                                              
                                              after channel change */

   { "CC_BUILDUP2_END", 19, "Channel change buildup end", NULL },  /* App has finished 2nd part of building up 
                                             after channel change */
         
   { "CC_CONFIG_START", 20, "Channel change config start", NULL },  /* App has started pipeline config */

   { "CC_CONFIG_END", 21, "Channel change config end", NULL },  /* App has finished pipeline config */
   
   { "CC_PAT_START", 22, "Channel change PAT start", NULL },  /* keypress for channel change entered */

   { "CC_PAT_END", 23, "Channel change PAT end", NULL },  /* teardown (or flush) complete */
   
   { "CC_PMT_START", 24, "Channel change PMT start", NULL },  /* keypress for channel change entered */

   { "CC_PMT_END", 25, "Channel change PMT end",NULL },  /* teardown (or flush) complete */

   
   { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_APP_EVENTS_sven_module =
{
   "SW_APP",                /*  */
   SVEN_module_APP_EVENTS,         /* Find your module in <sven_module.h> */
   0,                          /* Size of MMRs */
#ifdef SVEN_INTERNAL_BUILD
   g_csr_APP_EVENTS,               /*  */
#else
   NULL,                       /* What is the latest HW version to use? */
#endif
   "APP_EVENTS: Application events", /* Get a better text string */
   g_APP_EVENTS_specific_events,   /* Define important events specific to my module */
   NULL                        /* extension list */
};
