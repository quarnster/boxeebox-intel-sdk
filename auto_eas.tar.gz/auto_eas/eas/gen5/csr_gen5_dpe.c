/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_unit.h"
#endif
#ifdef SVEN_INTERNAL_BUILD


// Define individual offsets for various sub-units of DPE
//For WW16b & earlier CE5300 models, use these offsets.  Else, use the next offsets.
/*
#define DPE_MADI_BASE_OFFSET 0x0000  //New for CE5300
#define DPE_420_422_BASE_OFFSET	0x0180

#define DPE_DRTA_NP1_Y_BASE_OFFSET 0x0200
#define DPE_DRTA_NP1_UV_BASE_OFFSET 0x0280
#define DPE_SHARPNESS_BASE_OFFSET 0x0300  //New for CE5300
#define DPE_SNRF_BASE_OFFSET 0x0400  //New for CE5300
#define DPE_DI_BASE_OFFSET 0x1400
#define DPE_DRTA_N_YUV_BASE_OFFSET 0x1500
#define DPE_DRTA_NM1_YUV_BASE_OFFSET 0x1580
#define DPE_DRTA_NM1_MH_BASE_OFFSET 0x1600

#define DPE_DWTA_NP1_YUV_BASE_OFFSET 0x1680
#define DPE_DWTA_N_MH_BASE_OFFSET 0x1700
#define DPE_SCC_BASE_OFFSET 0x1780  //New for CE5300
#define DPE_HSC_BASE_OFFSET 0x2000
#define DPE_VSC_BASE_OFFSET 0x3000
#define DPE_DWTA_N_YUV_BASE_OFFSET 0x4100

//Added by RR
#define DPE_INCSC_BASE_OFFSET 0x4180  //New for CE5300
#define DPE_JLCC_BASE_OFFSET 0x4D00  //New for CE5300

#define DPE_DMA_BASE_OFFSET 0x6000
#define DPE_CP_BASE_OFFSET 0x7000
*/


//NOTE:  New Base offsets defined for CE5300 A0 - WW18model onwards

#define DPE_MADI_BASE_OFFSET 0x0000  //New for CE5300
#define DPE_420_422_BASE_OFFSET	0x0180

#define DPE_DRTA_NP1_Y_BASE_OFFSET 0x0200
#define DPE_DRTA_NP1_UV_BASE_OFFSET 0x0280
#define DPE_DETECTION_HIST_UV_BASE_OFFSET 0x0300  //New for CE5300
#define DPE_DI_BASE_OFFSET 0x1400
#define DPE_DRTA_N_YUV_BASE_OFFSET 0x1500
#define DPE_DRTA_NM1_YUV_BASE_OFFSET 0x1580
#define DPE_DRTA_NM1_MH_BASE_OFFSET 0x1600

#define DPE_DWTA_NP1_YUV_BASE_OFFSET 0x1680
#define DPE_DWTA_N_MH_BASE_OFFSET 0x1700
//#define DPE_SCC_BASE_OFFSET 0x1780  //New for CE5300
#define DPE_SCC_LUT_BASE_OFFSET 0x5980  //RR changed according to new EAS - Sep28th 
//#define DPE_SCC_LUT_BASE_OFFSET 0x1800  //RR changed according to new EAS - Sep28th 
#define DPE_SCC_BASE_OFFSET 0x1800  //RR changed according to new EAS - August 7th
#define DPE_HSC_BASE_OFFSET 0x2000
#define DPE_VSC_BASE_OFFSET 0x3000
#define DPE_SHARPNESS_BASE_OFFSET 0x4000  //New for CE5300
#define DPE_DWTA_N_YUV_BASE_OFFSET 0x4100

//Added by RR
#define DPE_SHRP_BASE_OFFSET 0x4000  //New for CE5300
#define DPE_INCSC_BASE_OFFSET 0x4180  //New for CE5300
#define DPE_JLCC_BASE_OFFSET 0x4C80  //New for CE5300

#define DPE_DMA_BASE_OFFSET 0x6000
#define DPE_SNRF_BASE_OFFSET 0x6400  //New for CE5300
#define DPE_DETECTION_YUV_BASE_OFFSET 0x6500  //New for CE5300
#define DPE_CP_BASE_OFFSET 0x7000


//------------------------------------DRTA_______________________________

static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NP1_Y_DMA_READ_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NP1_Y_DMA_READ_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NP1_Y_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "drta_en",		 0,	 1),     /*enable drta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};



static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NP1_Y_DMA_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NP1_UV_DMA_READ_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NP1_UV_DMA_READ_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NP1_UV_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "drta_en",		 0,	 1),     /*enable drta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NP1_UV_DMA_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NM1_YUV_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "drta_en",		 0,	 1),     /*enable drta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NM1_YUV_DMA_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};




static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_N_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_N_YUV_DMA_READ_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_N_YUV_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "drta_en",		 0,	 1),     /*enable drta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_N_YUV_DMA_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};



static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NM1_MH_DMA_READ_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NM1_MH_DMA_READ_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NM1_MH_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "drta_en",		 0,	 1),     /*enable drta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DRTA_NM1_MH_DMA_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

//-----------------------------------DWTA--------------------------------------------

static const struct EAS_RegBits g_csr_gen5_DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_WIDTH [] =
{
    CSR_BB( "out_stride_w",		 7,	 9),     /*stride width*/
   	CSR_BB( "in_stride_off",		 0,	 6),     /*input stride offset*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DWTA_NP1_YUV_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "dwta_en",		 0,	 1),     /*enable dwta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DWTA_N_MH_DMA_WRITE_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DWTA_N_MH_DMA_WRITE_STRIDE_WIDTH [] =
{
    CSR_BB( "out_stride_w",		 7,	 9),     /*stride width*/
   	CSR_BB( "in_stride_off",		 0,	 6),     /*input stride offset*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DWTA_N_MH_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "dwta_en",		 0,	 1),     /*enable dwta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_WIDTH [] =
{
    CSR_BB( "out_stride_w",		 7,	 9),     /*stride width*/
   	CSR_BB( "in_stride_off",		 0,	 6),     /*input stride offset*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DWTA_N_YUV_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "dwta_en",		 0,	 1),     /*enable dwta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


//-------------------------------------------------------DPE_420_422---------------------------------------------------


static const struct EAS_RegBits g_csr_gen5_DPE_420_422_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_420_422_Y_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_420_422_cbcr_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_420_422_Converter_Control [] =
{
    CSR_BB( "PI",		 3,	 1),     /*Raw picture type 0: progressive/1: interlaced*/
    CSR_BB( "TOP",		 2,	 1),	/* 0: bottom field, 1: top field */
    CSR_BB( "BYP",		 1,	 1),     /*1: bypass 420 to 422 converter; used when passing 422 format*/
    CSR_BB( "UNIT_EN",	 0,	 1),	/* Unit Enable (0: C422 off, 1: C422 on) */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

//----------------------------------------------------------------------CP-----------


static const struct EAS_RegBits g_csr_gen5_DPE_CP_CONTROL_REGISTER [] =
{
    CSR_BB( "STC3_Enable",		19,	 1),     /*System Time Counter 3 Enable*/
   	CSR_BB( "STC3_Clk_Sel",		17,	 2),     /*2-bit clock select:0: Clk_90,1: dds0_clk,2: dds1_clk */
  	CSR_BB( "STC2_Enable",		16,	 1),     /*System Time Counter 2 Enable*/
	CSR_BB( "STC2_Clk_Sel",		14,	 2),     /*2-bit clock select:0: Clk_90,1: dds0_clk,2: dds1_clk */
	CSR_BB( "STC1_Enable",		13,	 1),     /*System Time Counter 1 Enable*/
	CSR_BB( "STC1_Clk_Sel",		11,	 2),     /*2-bit clock select:0: Clk_90,1: dds0_clk,2: dds1_clk */
	CSR_BB( "STC0_Enable",		10,	 1),     /*System Time Counter 0 Enable*/
   	CSR_BB( "STC0_Clk_Sel",		 8,	 2),     /*2-bit clock select:0: Clk_90,1: dds0_clk,2: dds1_clk */
  	CSR_BB( "Watchdog_Timer_enable",		 7,	 1),     /*If set it will enable counting of 32-bit free running down counter*/
	CSR_BB( "ATR",				 5,	 2),     /*ATR: added to RISC external memory access address */
	CSR_BB( "PIP",				 2,	 1),     /*PIP: Mode for PIP or Main */
	CSR_BB( "DPE_Reset_l",       1,	 1),     /*DPE Pipeline reset: active low*/
	CSR_BB( "CP_Reset_l",		 0,	 1),     /*RISC Control Processor Reset: active low*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_CP_ICACHE_BASE_ADDRESS [] =
{
    CSR_BB( "Base_address",		14,	 18),     /*Instruction code base system address*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_WATCHDOG_TIMER [] =
{
    CSR_BB( "Timer",		0,	 20),     /*20-bit down-counting watchdog timer*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CACHELINE_INVALIDATE0 [] =
{
    CSR_BB( "Cacheline_Invalidate_mask",		0,	 32),     /*32-bit mask for cache line invalidate*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CACHELINE_INVALIDATE1 [] =
{
    CSR_BB( "Cacheline_Invalidate_mask",		0,	 32),     /*32-bit mask for cache line invalidate*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CACHELINE_INVALIDATE2 [] =
{
    CSR_BB( "Cacheline_Invalidate_mask",		0,	 32),     /*32-bit mask for cache line invalidate*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_DMA_SYSTEM_ADDRESS [] =
{
    CSR_BB( "System_address",		0,	 32),     /*32-bit System Address. Address must be DWORD aligned*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_DMA_LOCAL_ADDRESS [] =
{
    CSR_BB( "Local_address",		0,	 16),     /*16-bit local address. Address must be DWORD aligned*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_DMA_CONTROL_STATUS [] =
{
    CSR_BB( "DMA_START",		22,	 1),     /*Setting this bit initiates the DMA. The bit self clears*/
   	CSR_BB( "DMA_DONE",		21,	 1),     /*Set, on completion of DMA. Used with DMA interrupt */
  	CSR_BB( "DMA_BUSY",		20,	 1),     /*If set, indicates DMA unit is busy*/
	CSR_BB( "DMA_BURST",		18,	 2),     /*Sets the max burst size to use on SAP bus*/
	CSR_BB( "BYTE_SWAP",		17,	 1),     /*If set, the data will byte swapped within a word during the transfer*/
	CSR_BB( "DMA_Direction",	16,	 1),     /*If set, the data transfer is from Local to System side.*/
	CSR_BB( "DMA_Size",		 0,	16),     /*16-bit DMA transfer count in bytes*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HOST_DOORBELL [] =
{
   	CSR_BB( "Doorbell_command",		0,	 32),     /*32-bit software defined doorbell message*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_DOORBELL [] =
{
    CSR_BB( "Doorbell_command",		0,	 32),     /*32-bit software defined doorbell message*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HOST_IPC_STATUS [] =
{
    CSR_BB( "DONE",		1,	 1),     /*If set, Indicates that mailbox is ready for next message*/
	CSR_BB( "READY",		0,	 1),     /*If set, Indicates that doorbell register is ready for next message*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_IPC_STATUS [] =
{
    CSR_BB( "DONE",		1,	 1),     /*If set, Indicates that mailbox is ready for next message*/
	CSR_BB( "READY",		0,	 1),     /*If set, Indicates that doorbell register is ready for next message*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_SYSTEM_TIME_COUNTER0 [] =
{
    CSR_BB( "STC",		0,	 32),     /*32-bit System Time Counter Value*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_SYSTEM_TIME_COUNTER1 [] =
{
    CSR_BB( "STC",		0,	 32),     /*32-bit System Time Counter Value*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_SYSTEM_TIME_COUNTER2 [] =
{
    CSR_BB( "STC",		0,	 32),     /*32-bit System Time Counter Value*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_SYSTEM_TIME_COUNTER3 [] =
{
    CSR_BB( "STC",		0,	 32),     /*32-bit System Time Counter Value*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HOST_INTERRUPT_ENABLE [] =
{
    CSR_BB( "Vsparc_illegal_event",	6,	 1),     /*Vsparc illigal event. Please refer to External event CSR for details*/
   	CSR_BB( "Watchdog_timer",		5,	 1),     /*Watchdog timer event interrupt enable and status register*/
  	CSR_BB( "Ext_Event",			4,	 1),     /*External event interrupt enable and status register.*/
	CSR_BB( "DPE_Event",			3,	 2),     /*DPE event interrupt enable and status register.*/
	CSR_BB( "CP_DMA_done",		2,	 1),     /*CP DMA event interrupt enable and status register.*/
	CSR_BB( "HOST_Doorbell_Event",	1,	 1),     /*Host Doorbell event interrupt enable and status register*/
	CSR_BB( "CP_Doorbell_Event",		0,	 1),     /*CP Doorbell event interrupt enable and status register*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_INTERRUPT_ENABLE [] =
{
    CSR_BB( "Vsparc_illegal_event",	6,	 1),     /*Vsparc illigal event. Please refer to External event CSR for details*/
   	CSR_BB( "Watchdog_timer",		5,	 1),     /*Watchdog timer event interrupt enable and status register*/
  	CSR_BB( "Ext_Event",			4,	 1),     /*External event interrupt enable and status register.*/
	CSR_BB( "DPE_Event",			3,	 2),     /*DPE event interrupt enable and status register.*/
	CSR_BB( "CP_DMA_done",		2,	 1),     /*CP DMA event interrupt enable and status register.*/
	CSR_BB( "HOST_Doorbell_Event",	1,	 1),     /*Host Doorbell event interrupt enable and status register*/
	CSR_BB( "CP_Doorbell_Event",		0,	 1),     /*CP Doorbell event interrupt enable and status register*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_CP_INTERRUPT_STATUS_REGISTER [] =
{
    CSR_BB( "Vsparc_illegal_event",	6,	 1),     /*Vsparc illigal event. Please refer to External event CSR for details*/
   	CSR_BB( "Watchdog_timer",		5,	 1),     /*Watchdog timer event interrupt enable and status register*/
  	CSR_BB( "Ext_Event",			4,	 1),     /*External event interrupt enable and status register.*/
	CSR_BB( "DPE_Event",			3,	 2),     /*DPE event interrupt enable and status register.*/
	CSR_BB( "CP_DMA_done",		2,	 1),     /*CP DMA event interrupt enable and status register.*/
	CSR_BB( "HOST_Doorbell_Event",	1,	 1),     /*Host Doorbell event interrupt enable and status register*/
	CSR_BB( "CP_Doorbell_Event",		0,	 1),     /*CP Doorbell event interrupt enable and status register*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

//TODO:  Update these registers with the correct bits from updated EAS from Tanuja

static const struct EAS_RegBits g_csr_gen5_DPE_DPE_EVENT_ENABLE_REGISTER [] =
{
    CSR_BB( "NP1_Y_R_DMA_DONE",		23,	 1),     /*DPE Read NP1 (Y) stride_done*/
   	CSR_BB( "NP1_UV_R_DMA_DONE",		22,	 1),     /*DPE Read NP1 (UV) stride_don*/
  	CSR_BB( "NP1_YUV_W_DMA_DONE",		21,	 1),     /*DPE Write NP1 (Y) stride_done*/
	CSR_BB( "NM1_YUV_R_DMA_DONE",		20,	 1),     /*DPE Read N-1 (Y) stride_done*/
	CSR_BB( "NM1_MH_R_DMA_DONE",		19,	 1),     /*DPE Read  MH stride_done*/
	CSR_BB( "N_YUV_R_DMA_DONE",		18,	 1),     /*DPE Read N YUV stride_done*/
	CSR_BB( "N_Y_W_DMA_DONE",		17,	 1),     /*DPE Final Write N (Y) stride_done */
	CSR_BB( "N_UV_W_DMA_DONE",		16,	 1),     /*DPE Final Write N (UV) stride_done*/
   	CSR_BB( "N_MH_W_DMA_DONE",		15,	 1),     /*DPE_MH DMA stride_done*/
  	CSR_BB( "NP1_Y_R_DRTA_DONE",		14,	 1),     /*DPE_NP1_Y_DRTA stride_done*/
	CSR_BB( "NP1_UV_R_DRTA_DONE",		13,	 1),     /*DPE_NP1_UV_DRTA stride_done */
	CSR_BB( "NM1_YUV_R_DRTA_DONE",	12,	 1),     /*DPE_NM1_YUV_DRTA stride_done */
	CSR_BB( "NM1_MH_R_DRTA_DONE",		11,	 1),     /*DPE_MH_R_DRTA stride_done */
	CSR_BB( "N_YUV_R_DRTA_DONE",		 10,	 1),     /*DPE_N_YUV_R_DRTA stride_done */
	CSR_BB( "NP1_YUV_W_DWTA_DONE",	 9,	 1),     /*DPE_NP1_YUV_W_DWTA stride_done */
   	CSR_BB( "N_YUV_W_DWTA_DONE",		 8,	 1),     /*DPE_N_YUV_W_DWTA stride_done*/
  	CSR_BB( "N_MH_W_DWTA_DONE",		 7,	 1),     /*DPE_MH_W_DWTA stride_done*/
	CSR_BB( "VS_DONE",			 6,	 1),     /*Vertical Scaler stride_done*/
	CSR_BB( "HS_DONE",		 	 5,	 1),     /*Horizontal scaler stride_done*/
	CSR_BB( "DI_DONE",	 		 4,	 1),     /*Deinterlacer stride_done*/
       CSR_BB( "FGT_UV_DONE",		 3,	 1),     /*Film Grain stride_done*/
	CSR_BB( "FGT_Y_DONE",		 2,	 1),     /*Film Grain stride_done*/
	CSR_BB( "422_DONE",	 		 1,	 1),     /*422 stride_done*/
	CSR_BB( "RNR_DONE",			 0,	 1),     /*Ringing noise Removal stride _done*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

//TODO:  Update these registers with the correct bits from updated EAS from Tanuja

static const struct EAS_RegBits g_csr_gen5_DPE_DPE_EVENT_STATUS_REGISTER [] =
{

    	CSR_BB( "NP1_Y_R_DMA_DONE",		23,	 1),     /*DPE Read NP1 (Y) stride_done*/
   	CSR_BB( "NP1_UV_R_DMA_DONE",		22,	 1),     /*DPE Read NP1 (UV) stride_don*/
  	CSR_BB( "NP1_YUV_W_DMA_DONE",		21,	 1),     /*DPE Write NP1 (Y) stride_done*/
	CSR_BB( "NM1_YUV_R_DMA_DONE",		20,	 1),     /*DPE Read N-1 (Y) stride_done*/
	CSR_BB( "NM1_MH_R_DMA_DONE",		19,	 1),     /*DPE Read  MH stride_done*/
	CSR_BB( "N_YUV_R_DMA_DONE",		18,	 1),     /*DPE Read N YUV stride_done*/
	CSR_BB( "N_Y_W_DMA_DONE",		17,	 1),     /*DPE Final Write N (Y) stride_done */
	CSR_BB( "N_UV_W_DMA_DONE",		16,	 1),     /*DPE Final Write N (UV) stride_done*/
   	CSR_BB( "N_MH_W_DMA_DONE",		15,	 1),     /*DPE_MH DMA stride_done*/
  	CSR_BB( "NP1_Y_R_DRTA_DONE",		14,	 1),     /*DPE_NP1_Y_DRTA stride_done*/
	CSR_BB( "NP1_UV_R_DRTA_DONE",		13,	 1),     /*DPE_NP1_UV_DRTA stride_done */
	CSR_BB( "NM1_YUV_R_DRTA_DONE",	12,	 1),     /*DPE_NM1_YUV_DRTA stride_done */
	CSR_BB( "NM1_MH_R_DRTA_DONE",		11,	 1),     /*DPE_MH_R_DRTA stride_done */
	CSR_BB( "N_YUV_R_DRTA_DONE",		 10,	 1),     /*DPE_N_YUV_R_DRTA stride_done */
	CSR_BB( "NP1_YUV_W_DWTA_DONE",	 9,	 1),     /*DPE_NP1_YUV_W_DWTA stride_done */
   	CSR_BB( "N_YUV_W_DWTA_DONE",		 8,	 1),     /*DPE_N_YUV_W_DWTA stride_done*/
  	CSR_BB( "N_MH_W_DWTA_DONE",		 7,	 1),     /*DPE_MH_W_DWTA stride_done*/
	CSR_BB( "VS_DONE",			 6,	 1),     /*Vertical Scaler stride_done*/
	CSR_BB( "HS_DONE",		 	 5,	 1),     /*Horizontal scaler stride_done*/
	CSR_BB( "DI_DONE",	 		 4,	 1),     /*Deinterlacer stride_done*/
    	CSR_BB( "FGT_UV_DONE",		 3,	 1),     /*Film Grain stride_done*/
	CSR_BB( "FGT_Y_DONE",		 2,	 1),     /*Film Grain stride_done*/
	CSR_BB( "422_DONE",	 		 1,	 1),     /*422 stride_done*/
	CSR_BB( "RNR_DONE",			 0,	 1),     /*Ringing noise Removal stride _done*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_EXT_EVENT_ENABLE_REGISTER [] =
{

    CSR_BB( "VSparc_Illegal_Access",		31,	 1),     /*This bit gets set anytime VSPARC does an illgal data fetch.*/
   	CSR_BB( "Mfd_int",				17,	 1),     /**/
	CSR_BB( "Gfx_int",				16,	 1),     /* */
	CSR_BB( "Demux_int",				15,	 1),     /**/
   	CSR_BB( "Prefilter_int",			14,	 1),     /**/
  	CSR_BB( "Comp_int",				13,	 1),     /**/
	CSR_BB( "Audio_int",				12,	 1),     /**/
	CSR_BB( "VDC_Video1_OVRkeepout_p0_5",	 6,	 6),     /*These bit is only in the EXT_EVENT_STATUS_REGISTER When this Bit is set by VDC Video Plane 2 */
	CSR_BB( "VDC_Flip_p0_5",			 0,	 6),     /*Status bit set on receiving the video flip signal from VDC video plane 1*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_EXT_EVENT_STATUS_REGISTER [] =
{

    CSR_BB( "VSparc_Illegal_Access",		31,	 1),     /*This bit gets set anytime VSPARC does an illgal data fetch.*/
   	CSR_BB( "Mfd_int",				17,	 1),     /**/
	CSR_BB( "Gfx_int",				16,	 1),     /* */
	CSR_BB( "Demux_int",				15,	 1),     /**/
   	CSR_BB( "Prefilter_int",			14,	 1),     /**/
  	CSR_BB( "Comp_int",				13,	 1),     /**/
	CSR_BB( "Audio_int",				12,	 1),     /**/
	CSR_BB( "VDC_Video1_OVRkeepout_p0_5",	 6,	 6),     /*These bit is only in the EXT_EVENT_STATUS_REGISTER When this Bit is set by VDC Video Plane 2 */
	CSR_BB( "VDC_Flip_p0_5",			 0,	 6),     /*Status bit set on receiving the video flip signal from VDC video plane 1*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

//TODO:  Remove RNR for CE5300 A0

//-------------------------------- RNR ------------------Deringing-------------------

//static const struct EAS_RegBits g_csr_gen5_DPE_Deringing_Stride_Height_Register [] =
//{
//    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
//    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

//    CSR_BB_NULL_TERM()    /* NULL terminator */
//};

//static const struct EAS_RegBits g_csr_gen5_DPE_Deringing_Stride_Width_Register [] =
//{
//    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
//   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
//  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
//	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
//	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
//	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
//   	CSR_BB_NULL_TERM()    /* NULL terminator */
//};

//static const struct EAS_RegBits g_csr_gen5_DPE_Deringing_Control_Register [] =
//{
//    CSR_BB( "rnr_bypass",		 1,	 1),     /*Bypass Deringing*/
//    CSR_BB( "rnr_en",		 	 0,	 1),	/* Enable Deringing*/
//    CSR_BB_NULL_TERM()    /* NULL terminator */
//};

//static const struct EAS_RegBits g_csr_gen5_DPE_Deringing_Threshold_Register [] =
//{
//    CSR_BB( "rnr_disthigh_threshold",			 20,	 10),     /*This threshold is the high threshold*/
//    CSR_BB( "rnr_average_threshold",		 	 10,	 10),	/*This threshold is used in comparing averaged value versus original pixel value*/
//    CSR_BB( "rnr_distlow_threshold",		 	  0,	 10),	/* This threshold is the low threshold*/
//    CSR_BB_NULL_TERM()    /* NULL terminator */
//};

//TODO:  Update with correct bits & also add FFT

//-------------------------------- SNRF ------------------Static-------------------

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_Y_Stride_Height_Register[] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_Y_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_UV_Stride_Height_Register [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_UV_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_Y_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "Y_next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "Y_next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_UV_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "UV_next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "UV_next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_CONTROL [] =
{
    	CSR_BB( "Disable_impluse_noise_check",			 3,	 1),     /*When set the  impulse noise check will be disabled.  It is ON by default. */
   	CSR_BB( "En_3x3_Y_filter",		 2,	 1),     /*When set use 3x3 for all arithmetic operations. */
	CSR_BB( "Chroma_Bypass",		 1,	 1),     /*When set the Chroma path will be bypassed and UV will remain unchanged. */
	CSR_BB( "Luma_bypass",		 0,	 1),     /*When set the Luma path will be bypassed and Y will remain unchanged. */
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_IN_FILTER_Y_0_REGISTER []=
{
	CSR_BB( "In_filter_y0_coeff",	0,	12),	/*luma In coeff is used to generate the 5X5 filtered window ( for 3x3 low pass filter)*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_IN_FILTER_Y_1_REGISTER []=
{
	CSR_BB( "In_filter_y1_coeff",	0,	12),	/*luma In coeff is used to generate the 5X5 filtered window ( for 3x3 low pass filter)*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_IN_FILTER_Y_2_REGISTER []=
{
	CSR_BB( "In_filter_y2_coeff",	0,	12),	/*luma In coeff is used to generate the 5X5 filtered window ( for 3x3 low pass filter)*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_IN_FILTER_Y_3_REGISTER []=
{
	CSR_BB( "In_filter_y3_coeff",	0,	12),	/*luma In coeff is used to generate the 5X5 filtered window ( for 3x3 low pass filter)*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_IN_FILTER_Y_4_REGISTER []=
{
	CSR_BB( "In_filter_y4_coeff",	0,	12),	/*luma In coeff is used to generate the 5X5 filtered window ( for 3x3 low pass filter)*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_IN_FILTER_Y_5_REGISTER []=
{
	CSR_BB( "In_filter_y5_coeff",	0,	12),	/*luma In coeff is used to generate the 5X5 filtered window ( for 3x3 low pass filter)*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_IN_FILTER_Y_6_REGISTER []=
{
	CSR_BB( "In_filter_y6_coeff",	0,	12),	/*luma In coeff is used to generate the 5X5 filtered window ( for 3x3 low pass filter)*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_IN_FILTER_Y_7_REGISTER []=
{
	CSR_BB( "In_filter_y7_coeff",	0,	12),	/*luma In coeff is used to generate the 5X5 filtered window ( for 3x3 low pass filter)*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_IN_FILTER_Y_8_REGISTER []=
{
	CSR_BB( "In_filter_y8_coeff",	0,	12),	/*luma In coeff is used to generate the 5X5 filtered window ( for 3x3 low pass filter)*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_0_REGISTER []=
{
	CSR_BB( "Out_filter_y0_coeff",	0,	12),	/*luma OUT coeff is used to generate the filtered center pixel which replaces the masked pixel in final stage (for 3x3 center filter*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_1_REGISTER []=
{
	CSR_BB( "Out_filter_y1_coeff",	0,	12),	/*luma OUT coeff is used to generate the filtered center pixel which replaces the masked pixel in final stage (for 3x3 center filter*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_2_REGISTER []=
{
	CSR_BB( "Out_filter_y2_coeff",	0,	12),	/*luma OUT coeff is used to generate the filtered center pixel which replaces the masked pixel in final stage (for 3x3 center filter*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_3_REGISTER []=
{
	CSR_BB( "Out_filter_y3_coeff",	0,	12),	/*luma OUT coeff is used to generate the filtered center pixel which replaces the masked pixel in final stage (for 3x3 center filter*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_4_REGISTER []=
{
	CSR_BB( "Out_filter_y4_coeff",	0,	12),	/*luma OUT coeff is used to generate the filtered center pixel which replaces the masked pixel in final stage (for 3x3 center filter*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_5_REGISTER []=
{
	CSR_BB( "Out_filter_y5_coeff",	0,	12),	/*luma OUT coeff is used to generate the filtered center pixel which replaces the masked pixel in final stage (for 3x3 center filter*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_6_REGISTER []=
{
	CSR_BB( "Out_filter_y6_coeff",	0,	12),	/*luma OUT coeff is used to generate the filtered center pixel which replaces the masked pixel in final stage (for 3x3 center filter*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_7_REGISTER []=
{
	CSR_BB( "Out_filter_y7_coeff",	0,	12),	/*luma OUT coeff is used to generate the filtered center pixel which replaces the masked pixel in final stage (for 3x3 center filter*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_8_REGISTER []=
{
	CSR_BB( "Out_filter_y8_coeff",	0,	12),	/*luma OUT coeff is used to generate the filtered center pixel which replaces the masked pixel in final stage (for 3x3 center filter*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_0_REGISTER []=
{
	CSR_BB( "Out_filter_uv0_coeff",	0,	12),	/*Chroma OUT coeff is used to generate the 3x3 filtered window(for 3x3 low pass filter)*/	
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_1_REGISTER []=
{
	CSR_BB( "Out_filter_uv1_coeff",	0,	12),	/*Chroma OUT coeff is used to generate the 3x3 filtered window(for 3x3 low pass filter)*/	
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_2_REGISTER []=
{
	CSR_BB( "Out_filter_uv2_coeff",	0,	12),	/*Chroma OUT coeff is used to generate the 3x3 filtered window(for 3x3 low pass filter)*/	
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_3_REGISTER []=
{
	CSR_BB( "Out_filter_uv3_coeff",	0,	12),	/*Chroma OUT coeff is used to generate the 3x3 filtered window(for 3x3 low pass filter)*/	
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_4_REGISTER []=
{
	CSR_BB( "Out_filter_uv4_coeff",	0,	12),	/*Chroma OUT coeff is used to generate the 3x3 filtered window(for 3x3 low pass filter)*/	
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_5_REGISTER []=
{
	CSR_BB( "Out_filter_uv5_coeff",	0,	12),	/*Chroma OUT coeff is used to generate the 3x3 filtered window(for 3x3 low pass filter)*/	
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_6_REGISTER []=
{
	CSR_BB( "Out_filter_uv6_coeff",	0,	12),	/*Chroma OUT coeff is used to generate the 3x3 filtered window(for 3x3 low pass filter)*/	
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_7_REGISTER []=
{
	CSR_BB( "Out_filter_uv7_coeff",	0,	12),	/*Chroma OUT coeff is used to generate the 3x3 filtered window(for 3x3 low pass filter)*/	
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_8_REGISTER []=
{
	CSR_BB( "Out_filter_uv8_coeff",	0,	12),	/*Chroma OUT coeff is used to generate the 3x3 filtered window(for 3x3 low pass filter)*/	
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_MAX_Distance_Threshold_REGISTER []=
{
	CSR_BB( "Max_distance_threshold_UV",	16,	8),	/**/
	CSR_BB( "Max_distance_threshold_Y",	0,	8),	/**/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_MIN_Distance_Threshold_REGISTER []=
{
	CSR_BB( "Min_distance_threshold_UV",	16,	8),	/**/
	CSR_BB( "Min_distance_threshold_Y",	0,	8),	/**/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_Impulse_Noise_Threshold_REGISTER []=
{
	CSR_BB("Impulse_noise_threshold_UV",	16,	8),
	CSR_BB("Impulse_Noise_Threshold_Y",	0,	8),
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_Output_Average_Threshold_REGISTER []=
{
	CSR_BB("Output_average_threshold_UV",	16,	10),
	CSR_BB("Output_average_Threshold_Y",	0,	10),
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_HIST_APL_CNTRL_REGISTER []=
{
	CSR_BB( "max_enable",	3,	1),	/*determine max value and increment appropraiate FFT bin*/
	CSR_BB( "enable_hist_win",	2,	1),	/*enables pixel window for hist algo*/
	CSR_BB( "enable_fft_win",	1,	1),	/*enables pixel window for fft algo*/
	CSR_BB( "enable_apl_win",	0,	1),	/*enables pixel window for apt*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_HIST_Y_START_COORD_REGISTER []=
{
	CSR_BB( "Fft_hist_win_start_y",	16,	16),	/*value b/w 0 and 1080*/
	CSR_BB( "Fft_hist_win_start_x",	0,	16),	/*value b/w 0 and 1920*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_HIST_Y_END_COORD_REGISTER []=
{
	CSR_BB( "Fft_hist_win_end_y",	16,	16),	/*value b/w 0 and 1080*/
	CSR_BB( "Fft_hist_win_end_x",	0,	16),	/*value b/w 0 and 1920*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_HIST_CbCr_START_COORD_REGISTER []=
{
	CSR_BB( "Fft_hist_win_start_y",	16,	16),	/*value b/w 0 and 1080*/
	CSR_BB( "Fft_hist_win_start_x",	0,	16),	/*value b/w 0 and 1920*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_HIST_CbCr_END_COORD_REGISTER []=
{
	CSR_BB( "Fft_hist_win_start_y",	16,	16),	/*value b/w 0 and 1080*/
	CSR_BB( "Fft_hist_win_start_x",	0,	16),	/*value b/w 0 and 1920*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_APL_Y_START_COORD_REGISTER []=
{
	CSR_BB( "apl_win_start_y",	16,	16),	/*value b/w 0 and 1080*/
	CSR_BB( "apl_win_start_x",	0,	16),	/*value b/w 0 and 1920*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_APL_Y_END_COORD_REGISTER []=
{
	CSR_BB( "apl_win_end_y",	16,	16),	/*value b/w 0 and 1080*/
	CSR_BB( "apl_win_end_x",	0,	16),	/*value b/w 0 and 1920*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_APL_CbCr_START_COORD_REGISTER []=
{
	CSR_BB( "apl_win_start_y",	16,	16),	/*value b/w 0 and 1080*/
	CSR_BB( "apl_win_start_x",	0,	16),	/*value b/w 0 and 1920*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_APL_CbCr_END_COORD_REGISTER []=
{
	CSR_BB( "apl_win_start_y",	16,	16),	/*value b/w 0 and 1080*/
	CSR_BB( "apl_win_start_x",	0,	16),	/*value b/w 0 and 1920*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_STRIDE_WIDTH_REGISTER_Y []=
{
	CSR_BB( "next_rd_offset_x",	27,	5),	/*required for producer consumer model. This is a function of the next unit's IN_stride_off and its read window*/
	CSR_BB("Pix_coord_x",	16,	11),	/*X pixel coordinate of the first pixel IN the stride*/
	CSR_BB( "In_stride_w",	7,	9),	/*input stride width*/
	CSR_BB( "RM",	6,	1),	/*current stride is right most stride, need to apply boundary condition*/
	CSR_BB( "LM",	5,	1),	/*current stride is left most stride, need to apply boundary conditions*/
	CSR_BB( "IN_stride_off",	0,	5),	/*input stride offset*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_STRIDE_WIDTH_REGISTER_CbCr []=
{
	CSR_BB( "next_rd_offset_x",	27,	5),	/*required for producer consumer model. This is a function of the next unit's IN_stride_off and its read window*/
	CSR_BB("Pix_coord_x",	16,	11),	/*X pixel coordinate of the first pixel IN the stride*/
	CSR_BB( "In_stride_w",	7,	9),	/*input stride width*/
	CSR_BB( "RM",	6,	1),	/*current stride is right most stride, need to apply boundary condition*/
	CSR_BB( "LM",	5,	1),	/*current stride is left most stride, need to apply boundary conditions*/
	CSR_BB( "IN_stride_off",	0,	5),	/*input stride offset*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_COEF_0_A []=
{
	CSR_BB( "Coef_01",	16,	10),	/*filter coeff forpixels 2 and 4(1.1.8 value)*/
	CSR_BB( "Coef_00",	0,	10),	/*filter coeff for pixel 3(1.1.8 value)*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_COEF_0_B []=
{
	CSR_BB( "Coef_03",	16,	10),	/*filter coeff forpixels 0 and 6(1.1.8 value)*/
	CSR_BB( "Coef_02",	0,	10),	/*filter coeff for pixel 1 and 5(1.1.8 value)*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_COEF_1_A []=
{
	CSR_BB( "Coef_11",	16,	10),	/*filter coeff forpixels 2 and 4(1.1.8 value)*/
	CSR_BB( "Coef_10",	0,	10),	/*filter coeff for pixel 3(1.1.8 value)*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_COEF_1_B []=
{
	CSR_BB( "Coef_13",	16,	10),	/*filter coeff forpixels 0 and 6(1.1.8 value)*/
	CSR_BB( "Coef_12",	0,	10),	/*filter coeff for pixel 1 and 5(1.1.8 value)*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_COEF_2_A []=
{
	CSR_BB( "Coef_21",	16,	10),	/*filter coeff forpixels 2 and 4(1.1.8 value)*/
	CSR_BB( "Coef_20",	0,	10),	/*filter coeff for pixel 3(1.1.8 value)*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_COEF_2_B []=
{
	CSR_BB( "Coef_23",	16,	10),	/*filter coeff forpixels 0 and 6(1.1.8 value)*/
	CSR_BB( "Coef_22",	0,	10),	/*filter coeff for pixel 1 and 5(1.1.8 value)*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_COEF_3_A []=
{
	CSR_BB( "Coef_31",	16,	10),	/*filter coeff forpixels 2 and 4(1.1.8 value)*/
	CSR_BB( "Coef_30",	0,	10),	/*filter coeff for pixel 3(1.1.8 value)*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_COEF_3_B []=
{
	CSR_BB( "Coef_33",	16,	10),	/*filter coeff forpixels 0 and 6(1.1.8 value)*/
	CSR_BB( "Coef_32",	0,	10),	/*filter coeff for pixel 1 and 5(1.1.8 value)*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_COEF_4_A []=
{
	CSR_BB( "Coef_41",	16,	10),	/*filter coeff forpixels 2 and 4(1.1.8 value)*/
	CSR_BB( "Coef_40",	0,	10),	/*filter coeff for pixel 3(1.1.8 value)*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_COEF_4_B []=
{
	CSR_BB( "Coef_43",	16,	10),	/*filter coeff forpixels 0 and 6(1.1.8 value)*/
	CSR_BB( "Coef_42",	0,	10),	/*filter coeff for pixel 1 and 5(1.1.8 value)*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_TH []=
{
	CSR_BB( "TH_3",	24,	8),	/*Threshold 3*/
	CSR_BB( "TH_2",	16,	8),	/*Threshold 2*/
	CSR_BB( "TH_1",	 8,	8),	/*Threshold 1*/
	CSR_BB( "TH_0",	 0,	8),	/*Threshold 0*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_PIX_CUM_VALUE_Y []=
{
	CSR_BB( "pix_cum_value",	0,	32),	/*32 bit counter that accumulates pixel values in a frame*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_PIX_CUM_VALUE_Cb []=
{
	CSR_BB( "pix_cum_value",	0,	32),	/*32 bit counter that accumulates pixel values in a frame*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_PIX_CUM_VALUE_Cr []=
{
	CSR_BB( "pix_cum_value",	0,	32),	/*32 bit counter that accumulates pixel values in a frame*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

//static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_FFT_BIN_00_03_10_13_20_23_30_33_40_43 []=
//{
//	CSR_BB( "counter_00",	0,	32),	/*32 bit counter*/
//	CSR_BB_NULL_TERM()	/*NULL terminator */
//};

//static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_HIST_Y_BIN_0_127 []=
//{
//	CSR_BB( "Hist_y_bin",	0,	32),	/*32 bit counter: this has to be initialized to zero before Start of Frame*/
//	CSR_BB_NULL_TERM()	/*NULL terminator */
//};

//static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_HIST_Cb_BIN_0_127 []=
//{
//	CSR_BB( "Hist_Cb_bin",	0,	32),	/*32 bit counter: this has to be initialized to zero before Start of Frame*/
//	CSR_BB_NULL_TERM()	/*NULL terminator */
//};

//static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_HIST_Cr_BIN_0_127 []=
//{
//	CSR_BB( "Hist_Cr_bin",	0,	32),	/*32 bit counter: this has to be initialized to zero before Start of Frame*/
//	CSR_BB_NULL_TERM()	/*NULL terminator */
//};

//static const struct EAS_RegBits g_csr_gen5_DPE_SNRF_HIST_CbCr_BIN_0_1023 []=
//{
//	CSR_BB( "Hist_CbCr_bin",	0,	32),	/*32 bit counter: this has to be initialized to zero before Start of Frame*/
//	CSR_BB_NULL_TERM()	/*NULL terminator */
//};


//TODO:  Add FFT


///---------------------------------------------DI--------




static const struct EAS_RegBits g_csr_gen5_DPE_DI_Stride_Height_Register [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Field_Nplus1_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Field_N_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Field_Nless1_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Field_MH_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Field_FMD_Stride_Width_Register [] =
{
    CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Field_N_Next_Block_Parameters_Register [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels)*/
	CSR_BB( "next_wr_y",			 0,	 5),     /*Vertical block size for following unit in pipe (in pixels). */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Control_Register [] =
{
    CSR_BB( "Black_spatial",		31,	 1),     /*1: Use black pixel to replace SDI output, 0: Use SDI output as is for intenal use only*/
  	CSR_BB( "SDI_stride_mode",		30,	 1),     /*For internal C-model configuration only, treat as reserved bit for external use*/
	CSR_BB( "Mh_disable",			29,	 1),     /*For internal use only, treat as reserved bit for external use*/
	CSR_BB( "Const_md",			28,	 1),     /*For internal use only, treat as reserved bit for external use*/
	CSR_BB( "Const_md_value",		27,	 1),     /*For internal use only, treat as reserved bit for external use*/
	CSR_BB( "Chkn_mdaf",	              26,   1),     /* Chicken bit for post motion detection motion history adjustment */
	CSR_BB( "Chkn_mdaf_conservative_chk",		25,	 1),     /* Chicken bit (conservative) for motion_history */
	CSR_BB( "Chkn_weight_fix",		24,	 1),     /* Chicken bit for motion_history weight */
	CSR_BB( "Chkn_mdaf_check_md",		23,	 1),     /* Chicken bit to overrule MD decision */
	CSR_BB( "enable_1x2_MH_write",		14,	 1),     /* Enable writing MH for every row */
	CSR_BB( "MADI_select",		13,	 1),     /* Select the interpolated Pixel out from MADI */
	CSR_BB( "Motion_histogram_win_en",		12,	 1),     /* Motion Histogram window/fexible area enable */
       CSR_BB( "Swap23_mode",      10,  1),     /*1: To support UV upsample in VSC, swap line2 and line3 in every four outpu lines, 0: disable swap line2 and line3*/
	CSR_BB( "FilmMode_1_0",		 8,	 2),     /*11: reserved*/
   	CSR_BB( "CONST_HISTORY",		 7,	 1),     /*Enable constant history, the history data will not be write to or read from external DRAM*/
  	CSR_BB( "Software_Frame_Start",	 6,	 1),     /*1: Software is done programming registers for current frame and it is OK for DI to overwrite frame-based status*/
	CSR_BB( "BYPASS_SPATIAL_NRF",		 5,	 1),     /*1: Bypass the spatial NRF */
	CSR_BB( "BYPASSNRF",		 	 4,	 1),     /*1: Bypass NRF*/
	CSR_BB( "TOP_FIELD",	 		 3,	 1),     /*0:bottom field/1:top field. Must set to 1 for progressive frames*/
	CSR_BB( "SPATIAL",			 2,	 1),     /*1: Motion detection turned off. DI uses field N only for deinterlacing (Pspatial)*/
	CSR_BB( "Progressive",	 	 1,	 1),     /*1: The video input to DI has progressive content 0: The video input to DI has interlaced content*/
	CSR_BB( "Bypass",			 0,	 1),     /*1: pass-through mode (DISABLE must be 0). BYPASS is different from DISABLE*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_SDI_SAD_Wt_0_3_Register [] =
{
    CSR_BB( "SDI_SAD_Wt_3",		24, 8), 
    CSR_BB( "SDI_SAD_Wt_2",		16, 8),
    CSR_BB( "SDI_SAD_Wt_1",		8,   8), 
    CSR_BB( "SDI_SAD_Wt_0",		0,   8), 
	
    CSR_BB_NULL_TERM()    
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_SDI_SAD_Wt_4_5_Register [] =
{
    CSR_BB( "SDI_directional_mean_flag",		16, 1), 
    CSR_BB( "SDI_SAD_Wt_5",				8, 8),
    CSR_BB( "SDI_SAD_Wt_4",				0, 8), 
	
    CSR_BB_NULL_TERM()    
};


static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_SAD_Threshold_Parameter_Register [] =
{
    CSR_BB( "SAD_WEIGHT_PRE2",       28, 3),     /*The weight used for pre motion-detection SAD motion history adjustment when SAD score >= SAD history input and chkn_weight_fix=1*/
    CSR_BB( "SAD_WEIGHT_PRE1",       24, 3),     /*The weight used for pre motion-detection SAD motion history adjustment when SAD score < SAD history input and chkn_weight_fix=1*/
    CSR_BB( "MAX_NOISE_LEVEL",		16,	 8),     /*Max Noise Level . Threshold. U.7.0.   The range of possible values is [0..255]*/
    CSR_BB( "SAD_WEIGHT_POST",       12, 3),     /*The weight used for post motion-detection SAD motion history adjustment*/
	CSR_BB( "SAD_START_VALUE",		 0,	10),     /*SAD Start Value. U.10.0. The range of possible values is [0..1023]*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_MAD_History_Parameter_Register [] =
{
    CSR_BB( "MAD_HISTORY_VALUE",		16,	 6),     /*MAD history constant value, U.8.0. The range of possible values is [0..63]*/
	CSR_BB( "MAD_CAP",			 8,	 8),     /*MAD Cap. U.8.0.The mad_cap >= mad_min.   The range of possible values is [0..255]*/
	CSR_BB( "MAD_MIN",		 	 0,	 8),     /*MAD minimum value. U.8.0. The range of possible values is [0..255]*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_SAD_History_Parameter_Register [] =
{
    CSR_BB( "SAD_HISTORY_VALUE",		0,	 10),     /*SAD history constant value. The range of possible values is [0..1023]*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_Noise_Range_Register [] =
{
    CSR_BB( "NOISE_RNG2_MAX",		24,	 8),     /*MMaximum value of the range of noise for noise pixel accumulation*/
	CSR_BB( "NOISE_RNG2_MIN",		16,	 8),     /*Minimum value of the range of noise for noise pixel  accumulation*/
	CSR_BB( "NOISE_RNG1_MAX",		 8,	 8),     /*Maximum value of the range of noise for noise level accumulation*/
	CSR_BB( "NOISE_RNG1_MIN",		 0,	 8),     /*Minimum value of the range of noise for noise level accumulation*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_Noise_Level_Register [] =
{
    CSR_BB( "Noiselvl",		0,	 30),     /*The count is reset to zero at the beginning of frame by sw_frame_done */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_Noise_Pixel_Count_Register [] =
{
    CSR_BB( "Noisepixcnt",		0,	 22),     /*The count is reset to zero at the beginning of frame by sw_frame_done */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_Noise_Pixel_Count2_Register [] =
{
    CSR_BB( "Noisepixcnt2",		0,	 22),     /*Nnoise pixel count for zero-motion MAD threshold adjustment.   */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_Static_Noise_Level_Register [] =
{
    CSR_BB( "Noiselvl",		0,	 30),     /*The count is reset to zero at the beginning of frame by sw_frame_done */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_Static_Noise_Pixel_Count_Register [] =
{
    CSR_BB( "Noisepixcnt",		0,	 22),     /*The count is reset to zero at the beginning of frame by sw_frame_done */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_Static_Noise_Pixel_Count2_Register [] =
{
    CSR_BB( "Noisepixcnt2",		0,	 22),     /*Noise pixel count for zero-motion MAD threshold adjustment.   */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_Motion_Detect_Threshold_Register [] =
{
    CSR_BB( "MAD_WEIGHT_PRE",       28, 3),     /*The weight used for pre motion-detection MAD motion history adjustment*/
    CSR_BB( "MAD_WEIGHT_POST",       24, 3),     /*The weight used for post motion-detection MAD motion history adjustment*/
    CSR_BB( "thdm",		16,	 6),     /*Initial value of zero-motion MAD threshold for next  input picture*/
	CSR_BB( "Ln",			 0,	12),     /*Ln history for zero-motion SAD threshold adjustment*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_NRF_Index_Shift_Register [] =
{
    CSR_BB( "SWSHIFT",		 2,	2),     /*Number of bits to shift to right for spatial weight index, possible values are 0, 1, 2*/
	CSR_BB( "TWSHIFT",		 0,	2),     /*Number of bits to shift to right for spatial weight index, possible values are 0, 1, 2*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_FMD_TC_prev_count_Registers [] =
{
    CSR_BB( "TCP_COUNTER",		 	0,	20),     /*The tearing counter gives number of artifacts detected for given current field when weaved with next field*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_FMD_TC_next_count_Registers [] =
{
    CSR_BB( "TCN_COUNTER",		 	0,	20),     /*The tearing counter gives number of artifacts detected for given current field when weaved with next field*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_FMD_FDC_Registers [] =
{
    CSR_BB( "FD_COUNTER",		 	0,	20),     /*Gives the number of pixels between previous field and next field*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_FMD_Th_Registers [] =
{
    CSR_BB( "DIFF_TH",		 	      16, 8),
    CSR_BB( "DIFF_TC_TH",		 	 8,  8),
    CSR_BB( "TC_TH",		                 0,	8),
   
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_New_MD_Th_Register [] =
{
    CSR_BB( "NMD_MAD_TH",		 	20,	6),
    CSR_BB( "NMD_SAD_TH2",		 	10,	10),
    CSR_BB( "NMD_SAD_TH1",		 	0,	10),
   
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_MD_SAD_WT_0_7_Register [] =
{
    CSR_BB( "MH_SAD_Wt_7",		 	28,	4),
    CSR_BB( "MH_SAD_Wt_6",		 	24,	4),
    CSR_BB( "MH_SAD_Wt_5",		 	20,	4),
    CSR_BB( "MH_SAD_Wt_4",		 	16,	4),
    CSR_BB( "MH_SAD_Wt_3",		 	12,	4),
    CSR_BB( "MH_SAD_Wt_2",		 	8,	4),
    CSR_BB( "MH_SAD_Wt_1",		 	4,	4),
    CSR_BB( "MH_SAD_Wt_0",		 	0,	4),
   
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_MD_SAD_WT_8_14_Register [] =
{
    CSR_BB( "MH_MAD_Wt_8",		 	28,	4),
    CSR_BB( "MH_SAD_Wt_14",		 	24,	4),
    CSR_BB( "MH_SAD_Wt_13",		 	20,	4),
    CSR_BB( "MH_SAD_Wt_12",		 	16,	4),
    CSR_BB( "MH_SAD_Wt_11",		 	12,	4),
    CSR_BB( "MH_SAD_Wt_10",		 	8,	4),
    CSR_BB( "MH_SAD_Wt_9",		 	4,	4),
    CSR_BB( "MH_SAD_Wt_8",		 	0,	4),
   
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DI_MD_MAD_WT_0_7_Register [] =
{
    CSR_BB( "MH_MAD_Wt_7",		 	28,	4),
    CSR_BB( "MH_MAD_Wt_6",		 	24,	4),
    CSR_BB( "MH_MAD_Wt_5",		 	20,	4),
    CSR_BB( "MH_MAD_Wt_4",		 	16,	4),
    CSR_BB( "MH_MAD_Wt_3",		 	12,	4),
    CSR_BB( "MH_MAD_Wt_2",		 	8,	4),
    CSR_BB( "MH_MAD_Wt_1",		 	4,	4),
    CSR_BB( "MH_MAD_Wt_0",		 	0,	4),
   
	CSR_BB_NULL_TERM()    /* NULL terminator */
};


//-------------------------------------------------------DPE_TNRF_MADI-------------------------------------------------

static const struct EAS_RegBits g_csr_gen5_DPE_TNRF_SHIFT_Blend_Weight [] =
{
    CSR_BB( "YU_YV_BLEND",		8,	 8),     /* Weight for Blending Y and UV, U8.0. */
    CSR_BB( "UVSHIFT",		 2,	2),	/* Number of bits to shift for UV  */
    CSR_BB( "YSHIFT",		 0,	2),	/* Number of bits to shift for Y  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_TNRF_Y_LUT_0_3 [] =
{
    CSR_BB( "TNRF_Y_LUT_3",		24,	 8),
    CSR_BB( "TNRF_Y_LUT_2",		16,	 8),
    CSR_BB( "TNRF_Y_LUT_1",		8,	 8),
    CSR_BB( "TNRF_Y_LUT_0",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_TNRF_Y_LUT_4_7 [] =
{
    CSR_BB( "TNRF_Y_LUT_7",		24,	 8),
    CSR_BB( "TNRF_Y_LUT_6",		16,	 8),
    CSR_BB( "TNRF_Y_LUT_5",		8,	 8),
    CSR_BB( "TNRF_Y_LUT_4",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_TNRF_Y_LUT_8_11 [] =
{
    CSR_BB( "TNRF_Y_LUT_11",		24,	 8),
    CSR_BB( "TNRF_Y_LUT_10",		16,	 8),
    CSR_BB( "TNRF_Y_LUT_9",		8,	 8),
    CSR_BB( "TNRF_Y_LUT_8",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_TNRF_Y_LUT_12_15 [] =
{
    CSR_BB( "TNRF_Y_LUT_15",		24,	 8),
    CSR_BB( "TNRF_Y_LUT_14",		16,	 8),
    CSR_BB( "TNRF_Y_LUT_13",		8,	 8),
    CSR_BB( "TNRF_Y_LUT_12",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_TNRF_UV_LUT_0_3 [] =
{
    CSR_BB( "TNRF_UV_LUT_3",		24,	 8),
    CSR_BB( "TNRF_UV_LUT_2",		16,	 8),
    CSR_BB( "TNRF_UV_LUT_1",		8,	 8),
    CSR_BB( "TNRF_UV_LUT_0",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_TNRF_UV_LUT_4_7 [] =
{
    CSR_BB( "TNRF_UV_LUT_7",		24,	 8),
    CSR_BB( "TNRF_UV_LUT_6",		16,	 8),
    CSR_BB( "TNRF_UV_LUT_5",		8,	 8),
    CSR_BB( "TNRF_UV_LUT_4",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_TNRF_UV_LUT_8_11 [] =
{
    CSR_BB( "TNRF_UV_LUT_11",		24,	 8),
    CSR_BB( "TNRF_UV_LUT_10",		16,	 8),
    CSR_BB( "TNRF_UV_LUT_9",		8,	 8),
    CSR_BB( "TNRF_UV_LUT_8",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_TNRF_UV_LUT_12_15 [] =
{
    CSR_BB( "TNRF_UV_LUT_15",		24,	 8),
    CSR_BB( "TNRF_UV_LUT_14",		16,	 8),
    CSR_BB( "TNRF_UV_LUT_13",		8,	 8),
    CSR_BB( "TNRF_UV_LUT_12",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_TNRF_Var_Sc_Factor [] =
{
    CSR_BB( "Coring_TH",		24,	 8),
    CSR_BB( "FirstSec_Diff_Scale_Factor",		16,	 8),
    CSR_BB( "Sec_Diff_Scale_Factor",		8,	 8),
    CSR_BB( "First_Diff_Scale_Factor",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_Noise_Estimation_Th [] =
{
    CSR_BB( "VarNoise_Th",		10,	 12),
    CSR_BB( "VarNoise_Const",		0,	 10),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_Noise_Estimation_Var_Noise_Count [] =
{
    CSR_BB( "VarNoise_Count",		0,	 32),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_Noise_Estimation_Var_Noise_Level [] =
{
    CSR_BB( "VarNoise_Level",		0,	 32),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_MADI_LumaGain_Blend_LUT_0_3 [] =
{
    CSR_BB( "LumaGain_Blend_LUT3",		24,	 8),
    CSR_BB( "LumaGain_Blend_LUT2",		16,	 8),
    CSR_BB( "LumaGain_Blend_LUT1",		8,	 8),
    CSR_BB( "LumaGain_Blend_LUT0",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_LumaGain_Blend_LUT_4_7 [] =
{
    CSR_BB( "LumaGain_Blend_LUT7",		24,	 8),
    CSR_BB( "LumaGain_Blend_LUT6",		16,	 8),
    CSR_BB( "LumaGain_Blend_LUT5",		8,	 8),
    CSR_BB( "LumaGain_Blend_LUT4",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_LumaGain_LPF_LUT_0_3 [] =
{
    CSR_BB( "LumaGain_LPF_LUT3",		24,	 8),
    CSR_BB( "LumaGain_LPF_LUT2",		16,	 8),
    CSR_BB( "LumaGain_LPF_LUT1",		8,	 8),
    CSR_BB( "LumaGain_LPF_LUT0",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_LumaGain_LPF_LUT_4_7 [] =
{
    CSR_BB( "LumaGain_LPF_LUT7",		24,	 8),
    CSR_BB( "LumaGain_LPF_LUT6",		16,	 8),
    CSR_BB( "LumaGain_LPF_LUT5",		8,	 8),
    CSR_BB( "LumaGain_LPF_LUT4",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_MADI_Coring_Th [] =
{
    CSR_BB( "MAD_Coring_TH",		8,	 6),
    CSR_BB( "SAD_Coring_TH",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_Freq_Ana_SAD_Th [] =
{
    CSR_BB( "Freq_Max_Gain",		16,	 8),
    CSR_BB( "Freq_SAD_Th2",		8,	 8),
    CSR_BB( "Freq_SAD_Th1",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_Freq_Ana_Filter1_Th [] =
{
    CSR_BB( "Freq_Filt1_InvDiff_Th1Th2",		20,	 10),
    CSR_BB( "Freq_Filt1_Th2",		10,	 10),
    CSR_BB( "Freq_Filt1_Th1",		0,	 10),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_Freq_Ana_Filter3_Th [] =
{
    CSR_BB( "Freq_Filt3_InvDiff_Th1Th2",		20,	 10),
    CSR_BB( "Freq_Filt3_Th2",		10,	 10),
    CSR_BB( "Freq_Filt3_Th1",		0,	 10),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_MADI_SAD_MAD_TM_WTS [] =
{
    CSR_BB( "TM_WT_LPF",			20,	 4),
    CSR_BB( "TM_WT_BLEND",		16,	 4),
    CSR_BB( "MAD_WT_LPF",			12,	 4),
    CSR_BB( "MAD_WT_BLEND",		8,	 4),
    CSR_BB( "SAD_WT_LPF",			4,	 4),
    CSR_BB( "SAD_WT_BLEND",		0,	 4),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_MADI_FWT_Blend_LUT_0_3 [] =
{
    CSR_BB( "FWT_Blend_LUT3",		24,	 8),
    CSR_BB( "FWT_Blend_LUT2",		16,	 8),
    CSR_BB( "FWT_Blend_LUT1",		8,	 8),
    CSR_BB( "FWT_Blend_LUT0",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_FWT_Blend_LUT_4_7 [] =
{
    CSR_BB( "FWT_Blend_LUT7",		24,	 8),
    CSR_BB( "FWT_Blend_LUT6",		16,	 8),
    CSR_BB( "FWT_Blend_LUT5",		8,	 8),
    CSR_BB( "FWT_Blend_LUT4",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_FWT_LPF_LUT_0_3 [] =
{
    CSR_BB( "FWT_LPF_LUT3",		24,	 8),
    CSR_BB( "FWT_LPF_LUT2",		16,	 8),
    CSR_BB( "FWT_LPF_LUT1",		8,	 8),
    CSR_BB( "FWT_LPF_LUT0",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_FWT_LPF_LUT_4_7 [] =
{
    CSR_BB( "FWT_LPF_LUT7",		24,	 8),
    CSR_BB( "FWT_LPF_LUT6",		16,	 8),
    CSR_BB( "FWT_LPF_LUT5",		8,	 8),
    CSR_BB( "FWT_LPF_LUT4",		0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_MADI_Post_TM_Th [] =
{
    CSR_BB( "Post_TM_WT",				24,	 4),
    CSR_BB( "Post_TM_Max_Th",			16,	 8),
    CSR_BB( "Post_TM_InvDiff_Th1Th2",	8,	 8),
    CSR_BB( "Post_TM_Th1",				0,	 8),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_Control [] =
{
    CSR_BB( "Bypass_fWT_LPFLUT",			8,	 1),
    CSR_BB( "Bypass_fWT_BlendLUT",			7,	 1),
    CSR_BB( "Bypass_MDCheck_LPFWt",		6,	 1),
    CSR_BB( "Bypass_MDCheck_BlendWt",		5,	 1),
    CSR_BB( "Post_TM_Method",				4,	 1),
    CSR_BB( "Bypass_Ratio_Check_LPF",		3,	 1),
    CSR_BB( "Bypass_Ratio_Check_Blend",		2,	 1),
    CSR_BB( "TM_Max_Avg_Flag",				1,	 1),
    CSR_BB( "TM_Method_Flag",				0,	 1),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_MADI_Chicken_Bit [] =
{
    CSR_BB( "Last_Indicator_fix_en",				0,	 1),

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

//---------------------------------------FGT_-----------------------------------------------------




static const struct EAS_RegBits g_csr_gen5_DPE_FGT_Y_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_Y_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_UV_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_FGT_UV_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_Y_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_UV_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_CONTROL [] =
{
    CSR_BB( "fgt_bypass",			 7,	 1),     /*1: Disable FGT */
   	CSR_BB( "fgt_y_bypass",		 6,	 1),     /*This bit  is the inversion of comp_model_present_flag[0]*/
  	CSR_BB( "fgt_U_bypass",		 5,	 1),     /*This bit  is the inversion of comp_model_present_flag[1]*/
	CSR_BB( "fgt_V_bypass",		 4,	 1),     /*This bit  is the inversion of comp_model_present_flag[2]*/
	CSR_BB( "sw_pic_cfg_done",		 3,	 1),     /*1: Software is done with setting up the FGT to process next picture. */
	CSR_BB( "log2_scale_factor",		 0,	 3),     /*This is used to uniform;ly scale down all color components of all noise pixels. */
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_FGT_PRNG_Y_STRIDE_PARAMS [] =
{
    CSR_BB( "nnext_stride_strt_off",		 	12,	  9),     /*Offset to the leftmost pixel location of next stride */
    CSR_BB( "next_row_strt_off",			 0,	 12),	/*Offset from the leftmost pixel of the current stride row to the leftmost pixel of next stride row which is equivalent to the picture width*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_PRNG_UV_STRIDE_PARAMS [] =
{
    CSR_BB( "nnext_stride_strt_off",		 	12,	  9),     /*Offset to the leftmost pixel location of next stride */
    CSR_BB( "next_row_strt_off",			 0,	 12),	/*Offset from the leftmost pixel of the current stride row to the leftmost pixel of next stride row which is equivalent to the picture width*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_Y_PRNG_SEED [] =
{
    CSR_BB( "PRNG_Y_Seed",		 	0,	  32),     /*32-bit seed to start processing Y components of pixels in the stride*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_U_PRNG_SEED [] =
{
    CSR_BB( "PRNG_U_Seed",		 	0,	  32),     /*32-bit seed to start processing Y components of pixels in the stride*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_gen5_DPE_FGT_V_PRNG_SEED [] =
{
    CSR_BB( "PRNG_V_Seed",		 	0,	  32),     /*32-bit seed to start processing Y components of pixels in the stride*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_Y_NP_Parameter_Table [] =
{
    CSR_BB( "bypass_fgt",				12,	 1),     /*1: Skip */
    CSR_BB( "comp_model_value",			 4,	 8),	/*Valid range[0, 255], */
    CSR_BB( "np_cache_offset",			 0,	 4),	/*The offset of the corresponding 64X64 noise pattern in local sram cache*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_U_NP_Parameter_Table [] =
{
    CSR_BB( "bypass_fgt",				12,	 1),     /*1: Skip */
    CSR_BB( "comp_model_value",			 4,	 8),	/*Valid range[0, 255], */
    CSR_BB( "np_cache_offset",			 0,	 4),	/*The offset of the corresponding 64X64 noise pattern in local sram cache*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_FGT_V_NP_Parameter_Table [] =
{
    CSR_BB( "bypass_fgt",				12,	 1),     /*1: Skip */
    CSR_BB( "comp_model_value",			 4,	 8),	/*Valid range[0, 255], */
    CSR_BB( "np_cache_offset",			 0,	 4),	/*The offset of the corresponding 64X64 noise pattern in local sram cache*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};



//----------------------------------------DMA-----------------------------

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_Mode_Register [] =
{
    CSR_BB( "N_ARGB_W_enable",                  15,      1),     /*1: Enable DPE_ARGB_W */
    CSR_BB( "N_444_W_enable",                  14,      1),     /*1: Enable DPE_444_W */
    CSR_BB( "Dpe_dma_en",		 	11,	 1),     /*1: Enable DPE_DMA */
    CSR_BB( "N_YUV_W_en",		 	10,	 1),     /*1: Enable N_YUV_W DMA thread */
	CSR_BB( "FG_R_enable",		 9,	 1),     /*1: Enable DMA thread FG_R*/
	CSR_BB( "N_MH_W_enable",		 8,	 1),     /*1: Enable DMA thread N_MH_W*/
   	CSR_BB( "N_UV_W_enable",		 7,	 1),     /*1: Enable DMA thread N_UV_WM*/
  	CSR_BB( "N_Y_W_enable",	 	 6,	 1),     /*1: Enable DMA thread N_Y_W*/
	CSR_BB( "NP1_YUV_W_enable",		 5,	 1),     /*1: Enable DMA thread NP1_YUV_W */
	CSR_BB( "N_YUV_R_enable",		 4,	 1),     /*1: Enable DMA thread N_YUV_R*/
	CSR_BB( "NM1_MH_R_enable",	 	 3,	 1),     /*1: Enable DMA thread NM1_MH_R*/
	CSR_BB( "NM1_YUV_R_enable",		 2,	 1),     /*1: Enable DMA thread NM1_YUV_R*/
	CSR_BB( "NP1_UV_R_enable",	 	 1,	 1),     /*1: Enable DMA thread NP1_UV_R*/
	CSR_BB( "NP1_Y_R_enable",		 0,	 1),     /*1: Enable DMA thread NP1_Y_R*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_SAP_MEM_Parameters_Register [] =
{
    CSR_BB( "lsb_pad",		 	31,	  1),     /*Applicable only if pix_wsel=0. */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_Y_Picture_Parameter_Register [] =
{
	CSR_BB( "top_disable",		 31,	  1),     /*Disable reading of top field*/
	CSR_BB( "bottom_disable",	 	 30,	  1),     /*Disable reading of bottom field*/
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_UV_Picture_Parameter_Register [] =
{
	CSR_BB( "top_disable",		 31,	  1),     /*Disable reading of top field*/
	CSR_BB( "bottom_disable",	 	 30,	  1),     /*Disable reading of bottom field*/
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_Y_Top_Field_Starting_Address_Register [] =
{
    CSR_BB( "top_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_UV_Top_Field_Starting_Address_Register [] =
{
    CSR_BB( "top_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_Y_Bottom_Field_Starting_Address_Register [] =
{
    CSR_BB( "Bottom_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_UV_Bottom_Field_Starting_Address_Register [] =
{
    CSR_BB( "Bottom_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NM1_YUV_R_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NM1_MH_R_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_YUV_R_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_YUV_W_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_Y_W_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_UV_W_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_MH_W_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NM1_YUV_R_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NM1_MH_R_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_YUV_R_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_YUV_W_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_Y_W_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_UV_W_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_MH_W_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_Y_R_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_UV_R_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NM1_YUV_R_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NM1_MH_R_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_YUV_R_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_NP1_YUV_W_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_Y_W_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_UV_W_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_DMA_N_MH_W_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};


//--------------------------------------- Vsc-------------------------------




static const struct EAS_RegBits g_csr_gen5_DPE_VSC_STRIDE_HEIGHT [] =
{
    CSR_BB( "out_stride_h",             16,      11),   /* Out stride height in terms of pixel */
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_VSC_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_VSC_PREV_BLOCK_PARAMS [] =
{
    CSR_BB( "next_wr_offset_y",		 8,	 5),     /*Vertical write offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_VSC_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_VSC_IN_FIFO_PARAMS1 [] =
{
    CSR_BB( "In_fifo_startaddr",		12,	 18),     /*Physical address for first location of in_FIFO (in pixels)*/
    CSR_BB( "In_fifo_width",			 0,	  9),	/*Width of in_FIFO (in pixels)*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_VSC_IN_FIFO_PARAMS2 [] =
{
    CSR_BB( "In_fifo_size",			 8,	 15),     /*Size of in_fifo (in pixels)*/
    CSR_BB( "In_fifo_height",			 0,	  6),	/*Height of in_fifo (in pixels)*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_VSC_OUT_FIFO_PARAMS1 [] =
{
    CSR_BB( "Out_fifo_startaddr",		12,	 18),     /*Physical address for first location of out_FIFO (in pixels)*/
    CSR_BB( "Out_fifo_width",			 0,	  9),	/*Width of out_FIFO (in pixels)*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_VSC_OUT_FIFO_PARAMS2 [] =
{
    CSR_BB( "Out_fifo_size",			8,	15),     /*Size of out_fifo (in pixels)*/
    CSR_BB( "Out_fifo_height",			 0,	  6),	/*Height of out_fifo (in pixels)*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_VSC_CONTROL [] =
{
    CSR_BB( "dering_en",     4,  1),    /* Enable derining feature in VSC */
    CSR_BB( "pic_done",		 3,	 1),     /*1: Reset internal counters and states to be ready for next picture. After reset, VSC automatically clears this bit.*/
   	CSR_BB( "bank_sel",		 2,	 1),     /*1: Select coefficient memory 1 for polyphase filter coefficients*/
  	CSR_BB( "bypass",		 1,	 1),     /*Vertical Scaler Unit bypass*/
	CSR_BB( "en",			 0,	 1),     /*Vertical Scaler Unit Enable*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_VSC_SCALE_FACTOR [] =
{
    CSR_BB( "ISF",			0,	21),     /*Contains the value of 1/Scale factor*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_VSC_PHASE_CONFIG [] =
{
    CSR_BB( "SIP",			 8,	20),     /*Scaled Initial Phase. This needs to be  programmed to (Initial phase/TNP). */
    CSR_BB( "TNP",			 0,	 8),	/*Total number of phases used in the filter bank. */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


//---------------------------HSC---------------------------------------


static const struct EAS_RegBits g_csr_gen5_DPE_HSC_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_STRIDE_SCALING_PARAMS1 [] =
{
    CSR_BB( "In_stride_w",		20,	 9),     /*Typically, most units have a out_stride_w, which reflects how many pixels the algorithm will output.  */
    CSR_BB( "SIP",			 0,	17),	/* Scaled initial phase for the first output pixel in the stride */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_STRIDE_SCALING_PARAMS2 [] =
{
    CSR_BB( "SISF",		0,	 21),     /*The start value of 1/scale factor for the stride.  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_PREV_BLOCK_PARAMS[] =
{
    CSR_BB( "prev_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_CONTROL [] =
{
    CSR_BB( "dering_en",     4,  1),    /* Enable derining feature in HSC */
    CSR_BB( "bank_sel",		 2,	 1),     /*Selects the coefficient memory(0/1) that will be used by the HSC*/
  	CSR_BB( "en",			 0,	 1),     /*Horizontal Scaler Unit Enable*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_PHASE_CONFIG [] =
{
    CSR_BB( "SIP",			 8,	16),     /*Scaled Initial Phase. This needs to be  programmed to (Initial phase/TNP). */
    CSR_BB( "TNP",			 0,	 8),	/*Total number of phases used in the filter bank. */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_REGION1_START_VALUE [] =
{
    CSR_BB( "SISF",			0,	21),     /*Contains the value of 1/Scale factor*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_REGION1_SCALE_INCR [] =
{
    CSR_BB( "PC",				20,	11),     /*Pixel count for this region. The starting scale factor for the first pixel is SISF*/
    CSR_BB( "ISF_INCR",			 0,	17),	/*Per pixel increment of the inverse scale factor.*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_REGION2_START_VALUE [] =
{
    CSR_BB( "SISF",			0,	21),     /*Contains the value of 1/Scale factor*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_REGION2_SCALE_INCR [] =
{
    CSR_BB( "PC",				20,	11),     /*Pixel count for this region. The starting scale factor for the first pixel is SISF*/
    CSR_BB( "ISF_INCR",			 0,	17),	/*Per pixel increment of the inverse scale factor.*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_REGION3_START_VALUE [] =
{
    CSR_BB( "SISF",			0,	21),     /*Contains the value of 1/Scale factor*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_HSC_REGION3_SCALE_INCR [] =
{
    CSR_BB( "PC",				20,	11),     /*Pixel count for this region. The starting scale factor for the first pixel is SISF*/
    CSR_BB( "ISF_INCR",			 0,	17),	/*Per pixel increment of the inverse scale factor.*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

//-----------RR JLCCE Added for GEN 5-----------------------------------


//----------------------------INCSC-----------------------------------//


static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",              12,      4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",          0,     11),    /* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",         27,      5),     /*Required for the producer consumer model*/
    CSR_BB( "pix_coord_x",          16,      11),     /* X pixel coordinate of the first pixel in the stride.*/
    CSR_BB( "out_stride_w",          7,      9),     /*Output stride width*/
    CSR_BB( "RM",                            6,      1),     /*Indicates whether this stride is the right most stride*/
    CSR_BB( "LM",                            5,      1),     /*Indicates whether this stride is a left most stride*/
    CSR_BB( "in_stride_off",                 0,      5),     /*Input stride offset*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_CONTROL_REGISTER [] =
{
    CSR_BB( "xvYCC_en",         16,      1),    /*xvYCC mode*/
    CSR_BB( "dc_gain_bypass",   15,      1),    /*dc_gain_bypass mode*/
    CSR_BB( "rgb2lms_select",   3,      1),     /*RGB2LMS prog select*/
    CSR_BB( "skin_bypass",      2,      1),     /*Skin_bypass*/
    CSR_BB( "yuv2rgb_bypass",   1,      1),     /*yuv2rgb bypass*/
    CSR_BB( "rgb2ipt_bypass",   0,      1),     /*rgb2ipt_bypass*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_422_to_444_Coeff0_REGISTER []=
{
	CSR_BB( "C422_444_coeff0",	0,	9),	/*Coeff0 for 422 to 444 block*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_422_to_444_Coeff1_REGISTER []=
{
	CSR_BB( "C422_444_coeff1",	0,	9),	/*Coeff1 for 422 to 444 block*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_I_RANGE_COMP_REGISTER []=
{
	CSR_BB( "I_offset",	16,	13),	/*2's complement signed input offsets.12*/
	CSR_BB( "I_Gain",	0,	13),	/*unsigned input gain u1.12 format*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_YUV_to_RGB_Coeff_REGISTER []=
{
	CSR_BB( "Yuv2rgb_coeff",	0,	13),	/*Coeff for yuv2rgb block*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_RGB2LMS_C01_CSC_Coefficient01_REGISTER []=
{
	CSR_BB( "C1",	16,	15),	/*2's complement signed coefficient 1 (s2.12 format)*/
	CSR_BB( "C0",	0,	15),	/*2's complement signed coefficient 0 (s2.12 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_RGB2LMS_C23_CSC_Coefficient23_REGISTER []=
{
	CSR_BB( "C3",	16,	15),	/*2's complement signed coefficient 1 (s2.12 format)*/
	CSR_BB( "C2",	0,	15),	/*2's complement signed coefficient 0 (s2.12 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */

};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_RGB2LMS_C45_CSC_Coefficient45_REGISTER []=
{
	CSR_BB( "C5",	16,	15),	/*2's complement signed coefficient 1 (s2.12 format)*/
	CSR_BB( "C4",	0,	15),	/*2's complement signed coefficient 0 (s2.12 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */

};


static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_RGB2LMS_C67_RGB2LMS_Coefficient67_REGISTER []=
{
	CSR_BB( "C7",	16,	15),	/*2's complement signed coefficient 1 (s2.12 format)*/
	CSR_BB( "C6",	0,	15),	/*2's complement signed coefficient 0 (s2.12 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */

};


static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_RGB2LMS_C8_RGB2LMS_Coefficient8_REGISTER []=
{
	CSR_BB( "C8",	0,	15),	/*2's complement signed coefficient 0 (s2.12 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */

};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_YGOFF_REGISTER []=
{
	CSR_BB( "YG_OOFF",	16,	15),	/*2's complement signed output offset for Y/G*/
	CSR_BB( "YG_IOFF",	0,	13),	/*2's complement signed input offset for Y/G*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_CbBOFF_REGISTER []=
{
	CSR_BB( "CB_OOFF",	16,	15),	/*2's complement signed output offset for Cb/B*/
	CSR_BB( "CB_IOFF",	0,	13),	/*2's complement signed input offset for Cb/B*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_CrROFF_REGISTER []=
{
	CSR_BB( "CR_OOFF",	16,	15),	/*2's complement signed output offset for Cr/R*/
	CSR_BB( "CR_IOFF",	0,	13),	/*2's complement signed input offset for Cr/R*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_Coefficient01_REGISTER []=
{
	CSR_BB( "C1",	16,	15),	/*2's complement signed coefficient 1(s2.12 format)*/
	CSR_BB( "C0",	0,	15),	/*2's complement signed coefficient 0 (s2.12 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_Coefficient23_REGISTER []=
{
	CSR_BB( "C3",	16,	15),	/*2's complement signed coefficient 1(s2.12 format)*/
	CSR_BB( "C2",	0,	15),	/*2's complement signed coefficient 0 (s2.12 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_Coefficient45_REGISTER []=
{
	CSR_BB( "C5",	16,	15),	/*2's complement signed coefficient 1(s2.12 format)*/
	CSR_BB( "C4",	0,	15),	/*2's complement signed coefficient 0 (s2.12 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_Coefficient67_REGISTER []=
{
	CSR_BB( "C7",	16,	15),	/*2's complement signed coefficient 1(s2.12 format)*/
	CSR_BB( "C6",	0,	15),	/*2's complement signed coefficient 0 (s2.12 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_Coefficient8_REGISTER []=
{
	CSR_BB( "C8",	0,	15),	/*2's complement signed coefficient 0 (s2.12 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_YGICLAMP_REGISTER []=
{
	CSR_BB( "YG_IMAX",	16,	12),	/*Unsigned Y/G input maximum value*/ 
	CSR_BB( "YG_IMIN",	0,	12),	/*Unsigned Y/G input minimum value*/ 
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_CbBICLAMP_REGISTER []=
{
	CSR_BB( "CB_IMAX",	16,	12),	/*Unsigned Cb/B input maximum value*/ 
	CSR_BB( "CB_IMIN",	0,	12),	/*Unsigned Cb/B input minimum value*/ 
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_CrRICLAMP_REGISTER []=
{
	CSR_BB( "CR_IMAX",	16,	12),	/*Unsigned Cr/R input maximum value*/ 
	CSR_BB( "CR_IMIN",	0,	12),	/*Unsigned Cr/R input minimum value*/ 
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_YGOCLAMP_REGISTER []=
{
	CSR_BB( "YG_OMAX",	16,	15),	/*2's complement signed YG output maximum value*/ 
	CSR_BB( "YG_OMIN",	0,	15),	/*2's complement signed YG output minimum value*/ 
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_CbBOCLAMP_REGISTER []=
{
	CSR_BB( "CB_OMAX",	16,	15),	/*2's complement signed Cb/B output maximum value*/ 
	CSR_BB( "CB_OMIN",	0,	15),	/*2's complement signed Cb/B output minimum value*/ 
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_XVYCC_CSC_CrROCLAMP_REGISTER []=
{
	CSR_BB( "CR_OMAX",	16,	15),	/*2's complement signed Cr/R output maximum value*/ 
	CSR_BB( "CR_OMIN",	0,	15),	/*2's complement signed Cr/R output minimum value*/ 
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_RGB_LUT_REGISTER []=
{
	CSR_BB( "RGB_lut_value",	0,	24),	/*RGB lut value*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_LMS_LUT_REGISTER []=
{
	CSR_BB( "LMS_lut_value",	0,	24),	/*LMS lut value*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_LMTA_TL_0_5_REGISTER []=
{
	CSR_BB( "LA_0",		16,	12),	/*unsigned input limit*/
	CSR_BB( "TA_0",		0,	10),	/*unsigned input threshold*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_LMTA_SLOPE_0_4_REGISTER []=
{
	CSR_BB( "Sign_of_slope",	15,	1),	/*sign of slope*/
	CSR_BB( "Shift",	8,	4),	/*shift of slope*/
	CSR_BB( "Slope",	0,	5),	/*5 bit slope*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_LMTB_TL_0_5_REGISTER []=
{
	CSR_BB( "LB_0",		16,	10),	/*unsigned input limit*/
	CSR_BB( "TB_0",		0,	10),	/*unsigned input threshold*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_LMTB_SLOPE_0_4_REGISTER []=
{
	CSR_BB( "Sign_of_slope",	15,	1),	/*sign of slope*/
	CSR_BB( "Shift",	8,	4),	/*shift of slope*/
	CSR_BB( "Slope",	0,	5),	/*5 bit slope*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_xyz_coeff_a1_a3_REGISTER []=
{
	CSR_BB( "coeff_a1",	0,	13),	/*s2.10 input coeff*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_xyz_coeff_b1_b3_REGISTER []=
{
	CSR_BB( "coeff_b1",	0,	13),	/*s2.10 input coeff*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_xyz_coeff_c1_c3_REGISTER []=
{
	CSR_BB( "coeff_c1",	0,	13),	/*s2.10 input coeff*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_xyz_offset_d1_d3_REGISTER []=
{
	CSR_BB( "offset_d1",	0,	11),	/*signed input offset s2.10*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_Select_REGISTER []=
{
	CSR_BB( "Ycr_select_min",	10,	2),	/*Select min in YC ratio*/
	CSR_BB( "Lmtb_select_2",	8,	2),	/*Select 2 in Lmtb*/
	CSR_BB( "Lmtb_select_1",	6,	2),	/*Select 1 in Lmtb*/
	CSR_BB( "Lmta_select_3",	4,	2),	/*Select 3 in Lmta*/
	CSR_BB( "Lmta_select_2",	2,	2),	/*Select 2 in Lmta*/
	CSR_BB( "Lmta_select_1",	0,	2),	/*Select 1 in Lmta*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_blend_k_REGISTER []=
{
	CSR_BB( "blend_k",	0,	8),	/*unsigned input blend factor u.8*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_Y_Gain_REGISTER []=
{
	CSR_BB( "Y_gain",	0,	10),		/*U1.9 gain*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_Y_Offset_REGISTER []=
{
	CSR_BB( "YOutoffset",	16,	11),	/*Signed output offset s.10 format*/
	CSR_BB( "YInoffset",	0,	11),	/*Signed input offset s.10 format*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_Y_LIMIT_REGISTER []=
{
	CSR_BB( "YMaxlim",	16,	10),	/*Unsigned input max value*/
	CSR_BB( "YMinlin",	0,	10),	/*Unsigned input min value*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_ENGINEERING_REGISTER_1 []=
{
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_ENGINEERING_REGISTER_2 []=
{
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_INCSC_DC_LUT_REGISTER []=
{
	CSR_BB( "Y_out",	0,	10),	/*LUT value*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};


//---------------------JLCC----------------------------------------------//
static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",              12,      4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",          0,     11),    /* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",         27,      5),     /*Required for the producer consumer model*/
    CSR_BB( "pix_coord_x",          16,      11),     /* X pixel coordinate of the first pixel in the stride.*/
    CSR_BB( "out_stride_w",          7,      9),     /*Output stride width*/
    CSR_BB( "RM",                            6,      1),     /*Indicates whether this stride is the right most stride*/
    CSR_BB( "LM",                            5,      1),     /*Indicates whether this stride is a left most stride*/
    CSR_BB( "in_stride_off",                 0,      5),     /*Input stride offset*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_CDF_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",         27,      5),     /*Required for the producer consumer model*/
    CSR_BB( "pix_coord_x",          16,      11),     /* X pixel coordinate of the first pixel in the stride.*/
    CSR_BB( "out_stride_w",          7,      9),     /*Output stride width*/
    CSR_BB( "RM",                            6,      1),     /*Indicates whether this stride is the right most stride*/
    CSR_BB( "LM",                            5,      1),     /*Indicates whether this stride is a left most stride*/
    CSR_BB( "in_stride_off",                 0,      5),     /*Input stride offset*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_CONTROL_REGISTER [] =
{
    CSR_BB( "SEL_DCE_LCE",   18,      1),    /*SEL_DCE_LCE*/
    CSR_BB( "DCE_TYPE_SEL",   17,      1),    /*DCE_TYPE_SEL*/
    CSR_BB( "xvYCC_en",   16,      1),    /*xvYCC_en*/
    CSR_BB( "DCE_bypass",   13,      1),    /*DCE_bypass*/
    CSR_BB( "dither_bypass",   12,      1),    /*dither_bypass*/
    CSR_BB( "bluestretch_bypass",   11,      1),    /*bluestretch_bypass*/
    CSR_BB( "blue_bypass",   10,      1),    /*blue_bypass*/
    CSR_BB( "green_bypass",   9,      1),    /*green_bypass*/
    CSR_BB( "skin_bypass",   8,      1),    /*skin_bypass*/
    CSR_BB( "SGB_bypass",   7,      1),    /*SGB_bypass*/
    CSR_BB( "skin_count_bypass",   6,      1),    /*skin_count_bypass*/
    CSR_BB( "RGB_to_YUV_bypass",   5,      1),    /*RGB_to_YUV bypass*/
    CSR_BB( "IPT_to_RGB_bypass",   4,      1),    /*IPT to RGB_bypass */
    CSR_BB( "saturation_bypass",   3,      1),     /*Saturation bypass*/
    CSR_BB( "global_lightness_bypass",      2,      1),     /*Global lightness bypass*/
    CSR_BB( "local_contrast_bypass",   1,      1),     /*Local contrast bypass*/
    CSR_BB( "jlcc_bypass",   0,      1),     /*JLCC in passthrough mode*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_I_RANGE_EXP_REGISTER []= 
{
	CSR_BB ("I_offset",	16,	13),	/*2's complement signed input offset s.12*/
	CSR_BB ("I_gain",	0,	14),	/*unsigned input gain u2.12 format*/
        CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_I_RANGE_MAXMIN_Offset_REGISTER []=
{
	CSR_BB ("I_max",	16,	14),	/*signed I max s1.12*/
	CSR_BB ("I_min",	0,	14),	/*signed I min s1.12 */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_YGOFF_CSC_YG_Offset_REGISTER []=
{
	CSR_BB ("YG_OOFF",	16,	16),	/*2's complement signed output offset for Y/G*/
	CSR_BB ("YG_IOFF",	0,	16),	/*2's complement signed input offset for Y/G */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_CBOFF_CSC_CbB_Offset_REGISTER []=
{
	CSR_BB ("CB_OOFF",	16,	16),	/*2's complement signed output offset for Cb/B */
	CSR_BB ("CB_IOFF",	0,	16),	/*2's complement signed input offset for Cb/B*/
	CSR_BB_NULL_TERM()	 /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_CROFF_CSC_CrR_Offset_REGISTER []=
{
	CSR_BB ("CR_OOFF",	16,	16),	/*2'S complement signed output offset for Cr/R*/
	CSR_BB ("CR_IOFF",	0,	16),	/*2's complement signed input offset for Cr/R*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_C01_CSC_Coefficient01_REGISTER []=
{
	CSR_BB ("C5",	16,	16),	/*2's complement signed coefficient 1(s2.13 format) */
	CSR_BB ("C4",	0,	16),	/*2's complement signed coefficient 0 (s2.13 format)*/
	CSR_BB_NULL_TERM()	/*NULL terminator*/
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_C23_CSC_Coefficient23_REGISTER []=
{
	CSR_BB ("C3",	16,	16),	/*2's complement signed coefficient 1(s2.13 format)*/
	CSR_BB ("C2",	0,	16),	/*2's complement signed coefficient 0(s2.13 format)*/
	CSR_BB_NULL_TERM()	/*NULL terminator*/
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_C45_CSC_Coefficient45_REGISTER []=
{
	CSR_BB ("C5",	16,	16),	/*2's complement signed coefficient 1 (s2.13 format)*/
	CSR_BB ("C4",	0,	16),	/*2's complement signed coefficient 0 (s2.13 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_C67_CSC_Coefficient67_REGISTER []=
{
	CSR_BB ("C7",	16,	16),	/*2's complement signed coefficient 1 (s2.13 format)*/
	CSR_BB ("C6",	0,	16),	/*2's complement signed coefficient 0 (s2.13 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_C8_CSC_Coefficient8_REGISTER []=
{
	CSR_BB ("C8",	0,	16),	/*2's complement signed coefficient 0 (s2.13 format)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_YGICLAMP_CSC_YG_Input_CLAMPING_REGISTER []=
{
	CSR_BB ("YG_IMAX",	16,	16),	/*Unsigned Y/G input maximun value */
	CSR_BB ("YG_IMIN",	0,	16),	/*unsigned Y/G input minimum value*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_CBICLAMP_CSC_CbB_Input_CLAMPING_REGISTER []=
{
	CSR_BB ("CB_IMAX",	16,	16),	/*unsigned Cb/B input maximum value */
	CSR_BB ("CB_IMIN",	0,	16),	/*unsigned Cb/B input minimum value */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_CRICLAMP_CSC_CrR_Input_CLAMPING_REGISTER []=
{
	CSR_BB ("CR_IMAX",	16,	16),	/*unsigned Cr/R input maximum value */
	CSR_BB ("CR_IMIN",	0,	16),	/*unsigned Cr/R input minimum value */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_YGOCLAMP_CSC_YG_Output_CLAMPING_REGISTER []=
{
	CSR_BB ("YG_OMAX",	16,	16),	/*2's complement signed YG output maximum value*/
	CSR_BB ("YG_OMIN",	0,	16),	/*2's complement signed YG output minimum value*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_CBOCLAMP_CSC_CbB_Output_CLAMPING_REGISTER []=
{
	CSR_BB ("CB_OMAX",	16,	16),	/*2's complement signed Cb/B output maximum value*/
	CSR_BB ("CB_OMIN",	0,	16),	/*2's complement signed Cb/B output minimum value*/
	CSR_BB_NULL_TERM()	/*NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_RGB2YUV_CROCLAMP_CSC_CrR_Output_CLAMPING_REGISTER []=
{
	CSR_BB ("CR_OMAX",	16,	16),	/*2's complement signed Cr/R output maximum value*/
	CSR_BB ("CR_OMIN",	0,	16),	/*2's complement signed Cr/R output minimum value*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_OUT_CSC_RGB_LUT_REGISTER []=
{
	CSR_BB ("RGB_lut_value",	0,	24),	/*RGB_lut_value*/
	CSR_BB_NULL_TERM()	/* NULL_terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_OUT_CSC_LMS_LUT_REGISTER []=
{
	CSR_BB ("LMS_lut_value",	0,	24),	/*LMS_lut_value*/
	CSR_BB_NULL_TERM()	/*NULL_terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_Local_Contrast_LUT_REGISTER []=
{
	CSR_BB ("LC_lut_value",		0,	14),	/*LC_lut_value*/
	CSR_BB_NULL_TERM()	/* NULL_terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SINLUT_REGISTER []=
{
	CSR_BB ("SIN_lut_value",	0,	14),	/*SIN_lut_value*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_CHROMA_LUT_REGISTER []=
{
	CSR_BB ("Chroma_lut_value",	0,	18),	/*Chroma_lut_value*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SQRT_LUT_REGISTER []=
{
	CSR_BB ("Sqrt_lut_value",	0,	18),	/*chroma_lut_value*/
	CSR_BB_NULL_TERM()		/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_GL_GAIN_REGISTER []=
{
	CSR_BB ("GL_gain",	0,	18),	/*jlcc global lightness gain*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SAT_GAIN_REGISTER []=
{
	CSR_BB ("SAT_gain",	0,	18),	/* JLCC global saturation gain */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_CDF_Counters_REGISTER []=
{
	CSR_BB ("CDF0_to_CDF31",	0,	32),	/*CDF COUNTERS*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_GL_Low_threshold_REGISTER []=
{
	CSR_BB ("GL_TH0",	0,	14),	/*Low threshold */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_GL_High_threshold_REGISTER []=
{
	CSR_BB ("GL_TH1",	0,	14),	/*Low Threshold */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_Global_Saturation_Low_threshold_REGISTER []=
{
	CSR_BB ("GS_TH0",	0,	14),	/*Low Threshold*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_Global_Saturation_High_threshold_REGISTER []=
{
	CSR_BB ("GS_TH1",	0,	14),	/*Low Threhold*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_Sin_Lut_Lower_Bound_REGISTER []=
{
	CSR_BB ("Sin_lut_lower_bound",	0,	14),	/*High Threshold*/
	CSR_BB_NULL_TERM()	/*NULL terminator*/
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SGB_SKIN_SLOPE_CSR1_REGISTER []=
{
	CSR_BB ("CSR_skin_slope",	14,	18),	/*Normal value =3482*/
	CSR_BB ("CSR1_skin",	0,	14),	/* (knob_factor_skin)*(skin_slope_inv)*(skin_sat_factor),Normal value=(4818)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SGB_SKIN_SLOPE_INV_CSR2_REGISTER []=
{
	CSR_BB ("CSR_skin_slope_inv",	14,	18),	/*Normal value=4818*/
	CSR_BB ("CSR2_skin",	0,	14),	/*(skin_knob_factor)*(skin_slope)*(skin_sat_factor),Normal value=(3482)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SGB_SKIN_SAT_CSR3_REGISTER []=
{
	CSR_BB ("CSR_skin_sat_factor",	14,	18),	/*skin saturation factor*/
	CSR_BB ("CSR3_skin",	0,	14),	/*Skin_knob_factor*skin_sat_factor, Normal value=(4096)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SGB_GREEN_SLOPE_CSR1_REGISTER []=
{
	CSR_BB ("CSR_green_slope",	14,	18),	/*Normal value=(-4792)*/
	CSR_BB ("CSR1_green",	0,	14),	/*(knob_factor_green)*(green_slope_inv)*(green_sat_factor), Normal value=(-3501)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SGB_GREEN_SLOPE_INV_CSR2_REGISTER []=
{
	CSR_BB ("CSR_green_slope_inv",	14,	18),	/*Normal value=(-3501)*/
	CSR_BB ("CSR2_green",	0,	14),	/*(green_knob_factor)*(green_slope)*(green_sat_factor), Normal value=(-4792)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SGB_GREEN_SAT_CSR3_REGISTER []=
{
	CSR_BB ("CSR_green_sat_factor",	14,	18),	/* Green saturation factor*/
	CSR_BB ("CSR3_green",	0,	14),	/*Green_knob_factor*Green_sat_factor,Normal value=(4096)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */	
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SGB_BLUE_SLOPE_CSR1_REGISTER []=
{
	CSR_BB ("CSR_blue_slope",	14,	18),	/*Normal value=(12288)*/
	CSR_BB ("CSR1_blue",	0,	14),	/*(knob_factor_blue)*(blue_slope_inv)P(blue_sat_factor),Normal value=(1365)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SGB_BLUE_SLOPE_INV_CSR2_REGISTER []=
{
	CSR_BB ("CSR_blue_slope_inv",	14,	18),	/*Normal value =(1365)*/
	CSR_BB ("CSR2_blue",	0,	14),	/*(blue_knob_factor)*(blue_slope)*(blue_sat_factor),Normal value=(-12288)*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_SGB_BLUE_SAT_CSR3_REGISTER []=
{
	CSR_BB ("CSR_blue_sat_factor",	14,	18),	/*Blue saturation factor*/
	CSR_BB ("CSR3_blue",	0,	14),	/*Blue_knob_factor*blue_sat_factor, Normal value =4096()*/
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_CSR_product1_REGISTER []=
{
	CSR_BB ("CSR_product2",		16,	12),	/* m_bluestretch_factor*FixPt_B(300), normal value=75 format s.11 */
	CSR_BB ("CSR_product1",		0,	12),	/* m_bluesttretch_factor*FixPt_B(100), normal value =25 format s.11 */
	CSR_BB_NULL_TERM()	/* NULL terminator */
	
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_CSR_Smooth1_REGISTER []=
{
	CSR_BB ("CSR_Smooth1",		0,	14),	/* (1.0-Double(1.0 - m_skin_sat_factor)/6.0, Normal value =(4027) */	
	CSR_BB_NULL_TERM()	/* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_CSR_Smooth2_REGISTER []=
{
	CSR_BB ("CSR_Smooth2",		0,	14),	/* (1.0-Double(1.0 - m_skin_sat_factor)/5.0, Normal value =(4014) */	
	CSR_BB_NULL_TERM()	/* NULL terminator */
};
 

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_CSR_Smooth3_REGISTER []=
{
	CSR_BB ("CSR_Smooth3",		0,	14),	/* (1.0-Double(1.0 - m_skin_sat_factor)/4.0, Normal value =(3993) */	
	CSR_BB_NULL_TERM()	/* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_CSR_Smooth4_REGISTER []=
{
	CSR_BB ("CSR_Smooth4",		0,	14),	/* (1.0-Double(1.0 - m_skin_sat_factor)/3.0, Normal value =(3959) */	
	CSR_BB_NULL_TERM()	/* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_CSR_Smooth5_REGISTER []=
{
	CSR_BB ("CSR_Smooth5",		0,	14),	/* (1.0-Double(1.0 - m_skin_sat_factor)/2.0, Normal value =(3891) */	
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_DITHER_SEED_REGISTER []=
{
	CSR_BB ("Dither_rs2",	13,	14),	/* Dither random seed 2 */
	CSR_BB ("Dither_rs1",	0,	13),	/* Dither random seed 1 */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_DITHER_PARAMS_REGISTER []=
{
	CSR_BB ("CSR_Dither_bits",	18,	2),	/* 00=1 dither_bit, 01= dither bit 10=3 dither bit 11=4 dither bit */
	CSR_BB ("CSR_delta_th_bits",	10,	4),	/* can be 5,6,7,8 */
	CSR_BB ("CSR_dither_high_threshold", 0,	10),
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_LMTC_TL_0_5_REGISTER []=
{
	CSR_BB ("LC_0",		16,	12),	/* unsigned input limit */
	CSR_BB ("TC_0",		0,	10),	/* unsigned input threshold */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_LMTC_SLOPE_0_4_REGISTER []=
{
	CSR_BB ("Sign_of_slope",	15,	1),	/* Sign of slope */
	CSR_BB ("Shift",	8,	4),	/* Shift of slope */
	CSR_BB ("Slope",	0,	5),	/* 5 bit slope */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_LMTD_TL_0_5_REGISTER []=
{
	CSR_BB ("LD_0",		16,	12),	/* unsigned input limit */
	CSR_BB ("TD_0",		0,	10),	/* unsigned input threshold */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_LMTD_SLOPE_0_4_REGISTER []=
{
	CSR_BB ("Sign_of_slope",	15,	1),	/* Sign of slope */
	CSR_BB ("Shift",	8,	4),	/* Shift of slope */
	CSR_BB ("Slope",	0,	5),	/* 5 bit slope */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_YCR_Select_Gain_REGISTER []=
{
	CSR_BB ("Ycr_select_gain",	0,	1),	/* Select gain in YC ratio 0:Selects Gain_YC1  1:Selects Gain_YC2 */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_DCE_UNA_UNB_REGISTER []=
{
	CSR_BB ("UN_B",		4,	3),	/* DCE UN_B value */
	CSR_BB ("UN_A",		0,	3),	/* DCE UN_A value */
	CSR_BB_NULL_TERM()	/* NULL terminator */
 };

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_DCE_COL_GA_REGISTER []=
{
	CSR_BB ("DCE_COL_GA_DOWN",	8,	8),	/* Color Gain down value */
	CSR_BB ("DCE_COL_GA_UP",	0,	8),	/* Color Gain up value */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_DC_LUT_REGISTER []=
{
	CSR_BB ("Y_out",	0,	10),	/* LUT output */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_JLCC_DC_GAIN_MAP_REGISTER []=
{
	CSR_BB ("Gain_map",	0,	12),	/* u2.10 Gain map value */
	CSR_BB_NULL_TERM()	/* NULL terminator */
};

/*----------------------------SCC-------------------------------------------------------*/

static const struct EAS_RegBits g_csr_gen5_DPE_SCC_CONTROL_REGISTER []=
{
        CSR_BB ("IHS_to_IPT_bypass",    2,      1),     /*1:Bypass 0:Normal Mode*/
        CSR_BB ("IPT_to_IHS_bypass",    1,      1),     /*1:Bypass 0:Normal Mode*/
        CSR_BB ("SCC_all_stage_bypass", 0,      1),     /*1:Bypass 0:Normal Mode*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_xvYcc_Offset_REGISTER []=
{
        CSR_BB ("xvYcc_offset",    0,    13),   /*2's complement signed input offste s.12*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_xvYcc_I_RANGE_COMP_REGISTER []=
{
        CSR_BB ("I_offset",      16,      13),  /*2's complement signed input offset s.12*/
        CSR_BB ("I_Gain",       0,      13),    /*unsigned input gain u1.12 format*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ATanLUT_REGISTER []=
{
        CSR_BB ("ArcTan",     0,      9 ),       /*U0.9 ArcTan LUT value*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SinLUT_REGISTER []=
{
        CSR_BB ("Sin",          0,      11),    /* U0.11 Sin LUT Value */
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SqrtLUT_REGISTER []=
{
        CSR_BB ("Sqrt",         0,      12),    /* U1.11 Sqrt LUT Value*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
 
};

static const struct EAS_RegBits g_csr_gen5_DPE_SCC_CosLUT_REGISTER []=
{
        CSR_BB ("Cos",          0,      11),    /* U0.11 Sin LUT Value*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
//--------------------------------SCC Stage N------------------------------------------//
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_STAGE_CONTROL_REGISTER []=
{
        CSR_BB ("Hue_stage_bypass",     3,      1),     /*1:Bypass 0:Normal mode*/
        CSR_BB ("Sat_stage_bypass",     2,      1),     /*1:Bypass 0:Normal mode*/
        CSR_BB ("Intensity_stage_bypass",       1,      1),     /*1:Bypass 0:Normal mode*/
        CSR_BB ("SCC_stage_bypass",     0,      1),     /*1:Bypass 0:Normal mode*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HThresh_AB_ST_N_REGISTER []=
{
        CSR_BB ("HTH_B_ST_N",   16,     12),    /*Hue threshold unsigned 1.11*/
        CSR_BB ("HTH_A_ST_N",   0,      12),    /*Hue threshold unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HThresh_CD_ST_N_REGISTER []=
{
        CSR_BB ("HTH_D_ST_N",   16,     12),    /*Hue threshold unsigned 1.11*/
        CSR_BB ("HTH_C_ST_N",   0,      12),    /*Hue threshold nsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HThresh_E_ST_N_REGISTER []=
{
        CSR_BB ("HTH_E_ST_N",   0,      12),    /*Hue threshold unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HGain_AB_ST_N_REGISTER []=
{
        CSR_BB ("HGN_B_ST_N",   16,     12),    /*Hue gain signed 1.11*/
        CSR_BB ("HGN_A_ST_N",   0,      12),    /*Hue gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HGain_CD_ST_N_REGISTER []=
{
        CSR_BB ("HGN_D_ST_N",   16,     12),    /*Hue gain signed 1.11*/
        CSR_BB ("HGN_C_ST_N",   0,      12),    /*Hue gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HGain_E_ST_N_REGISTER []=
{
        CSR_BB ("HGN_E_ST_N",   0,      12),    /*Hue gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HSlope_AB_BC_ST_N_REGISTER []=
{
        CSR_BB ("HSL_SGN_BC_ST_N",      31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_BC_ST_N",      24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_BC_ST_N",          16,     8),     /*8 BIT SLOPE*/
        CSR_BB ("HSL_SGN_AB_ST_N",      15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_AB_ST_N",      8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_AB_ST_N",          0,      8),     /*8 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HSlope_CD_DE_ST_N_REGISTER []=
{
        CSR_BB ("HSL_SGN_DE_ST_N",      31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_DE_ST_N",      24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_DE_ST_N",          16,     8),     /*8 BIT SLOPE*/
        CSR_BB ("HSL_SGN_CD_ST_N",      15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_CD_ST_N",      8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_CD_ST_N",          0,      8),     /*8 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SGain_AB_ST_N_REGISTER []=
{
        CSR_BB ("SGN_B_ST_N",   16,     12),    /*Saturation gain signed 1.11*/
        CSR_BB ("SGN_A_ST_N",   0,      12),    /*Saturation gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SGain_CD_ST_N_REGISTER []=
{
        CSR_BB ("SGN_D_ST_N",   16,     12),    /*Saturation gain signed 1.11*/
        CSR_BB ("SGN_C_ST_N",   0,      12),    /*Saturation gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SGain_E_ST_N_REGISTER []=
{
        CSR_BB ("SGN_E_ST_N",   0,      12),    /*Saturation gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_AB_BC_ST_N_REGISTER []=
{
        CSR_BB ("SSL_SGN_BC_ST_N",      31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_BC_ST_N",      24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_BC_ST_N",          16,     8),     /*8 BIT SLOPE*/
        CSR_BB ("SSL_SGN_AB_ST_N",      15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_AB_ST_N",      8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_AB_ST_N",          0,      8),     /*8 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_CD_DE_ST_N_REGISTER []=
{
        CSR_BB ("SSL_SGN_DE_ST_N",      31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_DE_ST_N",      24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_DE_ST_N",          16,     8),     /*8 BIT SLOPE*/
        CSR_BB ("SSL_SGN_CD_ST_N",      15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_CD_ST_N",      8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_CD_ST_N",          0,      8),     /*8 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IGain_AB_ST_N_REGISTER []=
{
        CSR_BB ("IGN_B_ST_N",           16,     12),    /*Intensity Gain signed 1.11*/
        CSR_BB ("IGN_A_ST_N",           0,      12),    /*Intensity Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IGain_CD_ST_N_REGISTER []=
{
        CSR_BB ("IGN_D_ST_N",           16,     12),    /*Intensity Gain signed 1.11*/
        CSR_BB ("IGN_C_ST_N",           0,      12),    /*Intensity Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IGain_E_ST_N_REGISTER []=
{
        CSR_BB ("IGN_E_ST_N",           0,      12),    /*Intensity Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_AB_BC_ST_N_REGISTER []=
{
        CSR_BB ("ISL_SGN_BC_ST_N",      31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_BC_ST_N",      24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_BC_ST_N",          16,     8),     /*8 BIT SLOPE*/
        CSR_BB ("ISL_SGN_AB_ST_N",      15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_AB_ST_N",      8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_AB_ST_N",          0,      8),     /*8 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_CD_DE_ST_N_REGISTER []=
{
        CSR_BB ("ISL_SGN_DE_ST_N",      31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_DE_ST_N",      24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_DE_ST_N",          16,     8),     /*8 BIT SLOPE*/
        CSR_BB ("ISL_SGN_CD_ST_N",      15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_CD_ST_N",      8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_CD_ST_N",          0,      8),     /*8 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Hue_lim_AB_ST_N_REGISTER []=
{
        CSR_BB ("STH_HLIM_B_ST_N",      16,     12),    /*Saturation thresh for Hue limiter unsigned 1.11*/
        CSR_BB ("STH_HLIM_A_ST_N",      0,      12),    /*Saturation thresh for Hue limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Hue_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("STH_HLIM_D_ST_N",      16,     12),    /*Saturation thresh for Hue limiter unsigned 1.11*/
        CSR_BB ("STH_HLIM_C_ST_N",      0,      12),    /*Saturation thresh for Hue limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Hue_lim_AB_BC_ST_N_REGISTER []=
{
        CSR_BB ("S_SGN_HLIM_BC_ST_N",   31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SFT_HLIM_BC_ST_N",   24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_HLIM_BC_ST_N",           16,     6),     /*6 BIT SLOPE*/
        CSR_BB ("S_SGN_HLIM_AB_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SFT_HLIM_AB_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_HLIM_AB_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Hue_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("S_SGN_HLIM_CD_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SFT_HLIM_CD_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_HLIM_CD_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_Hue_lim_ABCD_ST_N_REGISTER []=
{
        CSR_BB ("S_HLIM_D_ST_N",        24,     4),     /*Sat limD for hue unsigned 0.4*/
        CSR_BB ("S_HLIM_C_ST_N",        16,     4),     /*Sat limC for hue unsigned 0.4*/
        CSR_BB ("S_HLIM_B_ST_N",         8,     4),     /*Sat limB for hue unsigned 0.4*/
        CSR_BB ("S_HLIM_A_ST_N",         0,     4),     /*Sat limA for hue unsigned 0.4*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Hue_lim_AB_ST_N_REGISTER []=
{
        CSR_BB ("ITH_HLIM_B_ST_N",      16,     12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB ("ITH_HLIM_A_ST_N",      0,      12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Hue_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("ITH_HLIM_D_ST_N",      16,     12),    /*Instensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB ("ITH_HLIM_C_ST_N",      0,      12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Hue_lim_AB_BC_ST_N_REGISTER []=
{
        CSR_BB ("I_SGN_HLIM_BC_ST_N",   31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SFT_HLIM_BC_ST_N",   24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_HLIM_BC_ST_N",           16,     6),     /*6 BIT SLOPE*/
        CSR_BB ("I_SGN_HLIM_AB_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SFT_HLIM_AB_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_HLIM_AB_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Hue_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("I_SGN_HLIM_CD_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SFT_HLIM_CD_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_HLIM_CD_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_Hue_lim_ABCD_ST_N_REGISTER []=
{
        CSR_BB ("I_HLIM_D_ST_N",        24,     4),     /*Sat limD for hue unsigned 0.4*/
        CSR_BB ("I_HLIM_C_ST_N",        16,     4),     /*Sat limC for hue unsigned 0.4*/
        CSR_BB ("I_HLIM_B_ST_N",         8,     4),     /*Sat limB for hue unsigned 0.4*/
        CSR_BB ("I_HLIM_A_ST_N",         0,     4),     /*Sat limA for hue unsigned 0.4*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Sat_lim_AB_ST_N_REGISTER []=
{
        CSR_BB ("STH_SLIM_B_ST_N",      16,     12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("STH_SLIM_A_ST_N",      0,      12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Sat_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("STH_SLIM_D_ST_N",      16,     12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("STH_SLIM_C_ST_N",      0,      12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Sat_lim_AB_BC_ST_N_REGISTER []=
{
        CSR_BB ("S_SGN_SLIM_BC_ST_N",   31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SFT_SLIM_BC_ST_N",   24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_SLIM_BC_ST_N",           16,     6),     /*6 BIT SLOPE*/
        CSR_BB ("S_SGN_SLIM_AB_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SFT_SLIM_AB_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_SLIM_AB_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Sat_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("S_SGN_SLIM_CD_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SFT_SLIM_CD_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_SLIM_CD_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_Sat_lim_ABCD_ST_N_REGISTER []=
{
        CSR_BB ("S_SLIM_D_ST_N",        24,     4),     /*Sat limD for Sat unsigned 0.4*/
        CSR_BB ("S_SLIM_C_ST_N",        16,     4),     /*Sat limC for Sat unsigned 0.4*/
        CSR_BB ("S_SLIM_B_ST_N",         8,     4),     /*Sat limB for Sat unsigned 0.4*/
        CSR_BB ("S_SLIM_A_ST_N",         0,     4),     /*Sat limA for Sat unsigned 0.4*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Sat_lim_AB_ST_N_REGISTER []=
{
        CSR_BB ("ITH_SLIM_B_ST_N",      16,     12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("ITH_SLIM_A_ST_N",      0,      12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Sat_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("ITH_SLIM_D_ST_N",      16,     12),    /*Instensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("ITH_SLIM_C_ST_N",      0,      12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Sat_lim_AB_BC_ST_N_REGISTER []=
{
        CSR_BB ("I_SGN_SLIM_BC_ST_N",   31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SFT_SLIM_BC_ST_N",   24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_SLIM_BC_ST_N",           16,     6),     /*6 BIT SLOPE*/
        CSR_BB ("I_SGN_SLIM_AB_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SFT_SLIM_AB_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_SLIM_AB_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Sat_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("I_SGN_SLIM_CD_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SFT_SLIM_CD_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_SLIM_CD_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_Sat_lim_ABCD_ST_N_REGISTER []=
{
        CSR_BB ("I_SLIM_D_ST_N",        24,     4),     /*Sat limD for sat unsigned 0.4*/
        CSR_BB ("I_SLIM_C_ST_N",        16,     4),     /*Sat limC for sat unsigned 0.4*/
        CSR_BB ("I_SLIM_B_ST_N",         8,     4),     /*Sat limB for sat unsigned 0.4*/
        CSR_BB ("I_SLIM_A_ST_N",         0,     4),     /*Sat limA for sat unsigned 0.4*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_INT_lim_AB_ST_N_REGISTER []=
{
        CSR_BB ("STH_ILIM_B_ST_N",      16,     12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB ("STH_ILIM_A_ST_N",      0,      12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_INT_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("STH_ILIM_D_ST_N",      16,     12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB ("STH_ILIM_C_ST_N",      0,      12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_INT_lim_AB_BC_ST_N_REGISTER []=
{
        CSR_BB ("S_SGN_ILIM_BC_ST_N",   31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SFT_ILIM_BC_ST_N",   24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_ILIM_BC_ST_N",           16,     6),     /*6 BIT SLOPE*/
        CSR_BB ("S_SGN_ILIM_AB_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SFT_ILIM_AB_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_ILIM_AB_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_INT_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("S_SGN_ILIM_CD_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SFT_ILIM_CD_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_ILIM_CD_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_INT_lim_ABCD_ST_N_REGISTER []=
{
        CSR_BB ("S_ILIM_D_ST_N",        24,     4),     /*Sat limD for INT unsigned 0.4*/
        CSR_BB ("S_ILIM_C_ST_N",        16,     4),     /*Sat limC for INT unsigned 0.4*/
        CSR_BB ("S_ILIM_B_ST_N",         8,     4),     /*Sat limB for INT unsigned 0.4*/
        CSR_BB ("S_ILIM_A_ST_N",         0,     4),     /*Sat limA for INT unsigned 0.4*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_INT_lim_AB_ST_N_REGISTER []=
{
        CSR_BB ("ITH_ILIM_B_ST_N",      16,     12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB ("ITH_ILIM_A_ST_N",      0,      12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_INT_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("ITH_ILIM_D_ST_N",      16,     12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB ("ITH_ILIM_C_ST_N",      0,      12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_INT_lim_AB_BC_ST_N_REGISTER []=
{
        CSR_BB ("I_SGN_ILIM_BC_ST_N",   31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SFT_ILIM_BC_ST_N",   24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_ILIM_BC_ST_N",           16,     6),     /*6 BIT SLOPE*/
        CSR_BB ("I_SGN_ILIM_AB_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SFT_ILIM_AB_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_ILIM_AB_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_INT_lim_CD_ST_N_REGISTER []=
{
        CSR_BB ("I_SGN_ILIM_CD_ST_N",   15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SFT_ILIM_CD_ST_N",   8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_ILIM_CD_ST_N",           0,      6),     /* 6 BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_INT_lim_ABCD_ST_N_REGISTER []=
{
        CSR_BB ("I_ILIM_D_ST_N",        24,     4),     /*Sat limD for INT unsigned 0.4*/
        CSR_BB ("I_ILIM_C_ST_N",        16,     4),     /*Sat limC for INT unsigned 0.4*/
        CSR_BB ("I_ILIM_B_ST_N",         8,     4),     /*Sat limB for INT unsigned 0.4*/
        CSR_BB ("I_ILIM_A_ST_N",         0,     4),     /*Sat limA for INT unsigned 0.4*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
//------------------------Blue stretch (scc stage 8)---------------------------------
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_Blue_Stretch_CONTROL_REGISTER []=
{
        CSR_BB ("HUE_ZERO_SAT",         20,     11),    /*Hue for Zero Sat*/
        CSR_BB ("BS_Hue_bypass",        3,      1),     /*1:Bypass 0:Normal mode*/
        CSR_BB ("BS_Sat_bypass",        2,      1),     /*1:Bypass 0:Normal mode*/
        CSR_BB ("BS_Intensity_bypass",  1,      1),     /*1:Bypass 0:Normal mode*/
        CSR_BB ("Blue_Stretch_stage_bypass",    0,      1),     /*1:Bypass 0:Normal mode*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HThresh_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("HTH_B_ST8_BS",         16,     11),    /*Hue threshold unsigned 1.11*/
        CSR_BB ("HTH_A_ST8_BS",         0,      11),    /*Hue threshold unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HThresh_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("HTH_D_ST8_BS",         16,     12),    /*Hue threshold unsigned 1.11*/
        CSR_BB ("HTH_C_ST8_BS",         0,      12),    /*Hue threshold unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HThresh_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("HTH_F_ST8_BS",         16,     12),    /*Hue threshold unsigned 1.11*/
        CSR_BB ("HTH_E_ST8_BS",         0,      12),    /*Hue threshold unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HThresh_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("HTH_H_ST8_BS",         16,     12),    /*Hue threshold unsigned 1.11*/
        CSR_BB ("HTH_G_ST8_BS",         0,      12),    /*Hue threshold unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HGain_0A_ST8_BS_REGISTER []=
{
        CSR_BB ("HGN_A_ST8_BS",         16,     12),    /*Hue Gain signed 1.11*/
        CSR_BB ("HGN_0_ST8_BS",          0,     12),    /*Hue Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HGain_BC_ST8_BS_REGISTER []=
{
        CSR_BB ("HGN_C_ST8_BS",         16,     12),    /*Hue Gain signed 1.11*/
        CSR_BB ("HGN_B_ST8_BS",          0,     12),    /*Hue Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HGain_DE_ST8_BS_REGISTER []=
{
        CSR_BB ("HGN_E_ST8_BS",         16,     12),    /*Hue Gain signed 1.11*/
        CSR_BB ("HGN_D_ST8_BS",          0,     12),    /*Hue Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HGain_FG_ST8_BS_REGISTER []=
{
        CSR_BB ("HGN_G_ST8_BS",         16,     12),    /*Hue Gain signed 1.11*/
        CSR_BB ("HGN_F_ST8_BS",          0,     12),    /*Hue Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HGain_H_ST8_BS_REGISTER []=
{
        CSR_BB ("HGN_H_ST8_BS",          0,     12),    /*Hue Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HSlope_0A_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("HSL_SGN_AB_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_AB_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_AB_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("HSL_SGN_0A_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_0A_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_0A_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HSlope_BC_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("HSL_SGN_CD_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_CD_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_CD_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("HSL_SGN_BC_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_BC_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_BC_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HSlope_DE_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("HSL_SGN_EF_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_EF_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_EF_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("HSL_SGN_DE_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_DE_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_DE_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HSlope_FG_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("HSL_SGN_GH_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_GH_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_GH_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("HSL_SGN_FG_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_FG_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_FG_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_HSlope_H1_ST8_BS_REGISTER []=
{
        CSR_BB ("HSL_SGN_H1_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("HSL_SFT_H1_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("HSL_H1_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SDelta_0A_ST8_BS_REGISTER []=
{
        CSR_BB ("SDELTA_A_ST8_BS",      16,     12),    /*Saturation Delta signed S.11*/
        CSR_BB ("SDELTA_0_ST8_BS",       0,     12),    /*Saturation Delta signed S.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SDelta_BC_ST8_BS_REGISTER []=
{
        CSR_BB ("SDELTA_C_ST8_BS",      16,     12),    /*Saturation Delta signed S.11*/
        CSR_BB ("SDELTA_B_ST8_BS",       0,     12),    /*Saturation Delta signed S.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SDelta_DE_ST8_BS_REGISTER []=
{
        CSR_BB ("SDELTA_E_ST8_BS",      16,     12),    /*Saturation Delta signed S.11*/
        CSR_BB ("SDELTA_D_ST8_BS",       0,     12),    /*Saturation Delta signed S.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SDelta_FG_ST8_BS_REGISTER []=
{
        CSR_BB ("SDELTA_G_ST8_BS",      16,     12),    /*Saturation Delta signed S.11*/
        CSR_BB ("SDELTA_F_ST8_BS",       0,     12),    /*Saturation Delta signed S.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SDelta_H_ST8_BS_REGISTER []=
{
        CSR_BB ("SDELTA_H_ST8_BS",       0,     12),    /*Saturation Delta signed S.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SDelta_Slope_0A_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("SSL_SGN_AB_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_AB_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_AB_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("SSL_SGN_0A_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_0A_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_0A_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SDelta_Slope_BC_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("SSL_SGN_CD_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_CD_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_CD_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("SSL_SGN_BC_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_BC_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_BC_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SDelta_Slope_DE_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("SSL_SGN_EF_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_EF_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_EF_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("SSL_SGN_DE_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_DE_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_DE_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SDelta_Slope_FG_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("SSL_SGN_GH_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_GH_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_GH_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("SSL_SGN_FG_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_FG_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_FG_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SDelta_Slope_H1_ST8_BS_REGISTER []=
{
        CSR_BB ("SSL_SGN_H1_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("SSL_SFT_H1_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("SSL_H1_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IGain_0A_ST8_BS_REGISTER []=
{
        CSR_BB ("IGN_A_ST8_BS",         16,     12),    /*Intensity Gain signed 1.11*/
        CSR_BB ("IGN_0_ST8_BS",         0,      12),    /*Intensity Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IGain_BC_ST8_BS_REGISTER []=
{
        CSR_BB ("IGN_C_ST8_BS",         16,     12),    /*Intensity Gain signed 1.11*/
        CSR_BB ("IGN_B_ST8_BS",         0,      12),    /*Intensity Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IGain_DE_ST8_BS_REGISTER []=
{
        CSR_BB ("IGN_E_ST8_BS",         16,     12),    /*Intensity Gain signed 1.11*/
        CSR_BB ("IGN_D_ST8_BS",         0,      12),    /*Intensity Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IGain_FG_ST8_BS_REGISTER []=
{
        CSR_BB ("IGN_G_ST8_BS",         16,     12),    /*Intensity Gain signed 1.11*/
        CSR_BB ("IGN_F_ST8_BS",         0,      12),    /*Intensity Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IGain_H_ST8_BS_REGISTER []=
{
        CSR_BB ("IGN_H_ST8_BS",         0,      12),    /*Intensity Gain signed 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_0A_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("ISL_SGN_AB_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_AB_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_AB_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("ISL_SGN_0A_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_0A_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_0A_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_BC_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("ISL_SGN_CD_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_CD_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_CD_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("ISL_SGN_BC_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_BC_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_BC_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_DE_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("ISL_SGN_EF_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_EF_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_EF_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("ISL_SGN_DE_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_DE_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_DE_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_FG_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("ISL_SGN_GH_ST1",       31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_GH_ST1",       24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_GH_ST1",           16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("ISL_SGN_FG_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_FG_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_FG_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_H1_ST8_BS_REGISTER []=
{
        CSR_BB ("ISL_SGN_H1_ST1",       15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("ISL_SFT_H1_ST1",       8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("ISL_H1_ST1",           0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Hue_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_HLIM_B_ST8_BS",    16,     12),    /*Saturation thresh for hue limiter unsigned 1.11 */
        CSR_BB ("STH_HLIM_A_ST8_BS",     0,     12),    /*Saturation thresh for hue limiter unsigned 1.11 */
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_c_Hue_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_HLIM_D_ST8_BS",    16,     12),    /*Saturation thresh for hue limiter unsigned 1.11 */
        CSR_BB ("STH_HLIM_C_ST8_BS",     0,     12),    /*Saturation thresh for hue limiter unsigned 1.11 */
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Hue_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_HLIM_F_ST8_BS",    16,     12),    /*Saturation thresh for hue limiter unsigned 1.11 */
        CSR_BB ("STH_HLIM_E_ST8_BS",     0,     12),    /*Saturation thresh for hue limiter unsigned 1.11 */
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Hue_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_HLIM_H_ST8_BS",    16,     12),    /*Saturation thresh for hue limiter unsigned 1.11 */
        CSR_BB ("STH_HLIM_G_ST8_BS",     0,     12),    /*Saturation thresh for hue limiter unsigned 1.11 */
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Hue_lim_AB_BC_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_HLIM_BC_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_HLIM_BC_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_HLIM_BC_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("S_SLP_SGN_HLIM_AB_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_HLIM_AB_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_HLIM_AB_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Hue_lim_CD_DE_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_HLIM_DE_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_HLIM_DE_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_HLIM_DE_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("S_SLP_SGN_HLIM_CD_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_HLIM_CD_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_HLIM_CD_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Hue_lim_EF_FG_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_HLIM_FG_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_HLIM_FG_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_HLIM_FG_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("S_SLP_SGN_HLIM_EF_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_HLIM_EF_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_HLIM_EF_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Hue_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_HLIM_GH_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_HLIM_GH_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_HLIM_GH_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_Hue_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("S_HLIM_B_ST8_BS",      16,     8),     /*Sat limB for hue unsigned 0.8 */
        CSR_BB ("S_HLIM_A_ST8_BS",       0,     8),     /*Sat limA for hue unsigned 0.8 */
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_Hue_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("S_HLIM_D_ST8_BS",      16,     8),     /*Sat limD for hue unsigned 0.8 */
        CSR_BB ("S_HLIM_C_ST8_BS",       0,     8),     /*Sat limC for hue unsigned 0.8 */
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_Hue_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("S_HLIM_F_ST8_BS",      16,     8),     /*Sat limF for hue unsigned 0.8 */
        CSR_BB ("S_HLIM_E_ST8_BS",       0,     8),     /*Sat limE for hue unsigned 0.8 */
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_Hue_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("S_HLIM_H_ST8_BS",      16,     8),     /*Sat limH for hue unsigned 0.8 */
        CSR_BB ("S_HLIM_G_ST8_BS",       0,     8),     /*Sat limG for hue unsigned 0.8 */
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Hue_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_HLIM_B_ST8_BS",    16,     12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB ("ITH_HLIM_A_ST8_BS",     0,     12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Hue_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_HLIM_D_ST8_BS",    16,     12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB ("ITH_HLIM_C_ST8_BS",     0,     12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Hue_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_HLIM_F_ST8_BS",    16,     12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB ("ITH_HLIM_E_ST8_BS",     0,     12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Hue_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_HLIM_H_ST8_BS",    16,     12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB ("ITH_HLIM_G_ST8_BS",     0,     12),    /*Intensity thresh for Hue limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Hue_lim_AB_BC_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_HLIM_BC_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_HLIM_BC_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_HLIM_BC_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("I_SLP_SGN_HLIM_AB_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_HLIM_AB_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_HLIM_AB_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Hue_lim_CD_DE_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_HLIM_DE_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_HLIM_DE_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_HLIM_DE_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("I_SLP_SGN_HLIM_CD_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_HLIM_CD_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_HLIM_CD_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Hue_lim_EF_FG_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_HLIM_FG_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_HLIM_FG_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_HLIM_FG_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("I_SLP_SGN_HLIM_EF_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_HLIM_EF_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_HLIM_EF_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Hue_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_HLIM_GH_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_HLIM_GH_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_HLIM_GH_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_Hue_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("I_HLIM_B_ST8_BS",      16,     8),     /*Sat limC for hue unsigned 0.8*/
        CSR_BB ("I_HLIM_A_ST8_BS",       0,     8),     /*Sat limC for hue unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_Hue_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("I_HLIM_D_ST8_BS",      16,     8),     /*Sat limC for hue unsigned 0.8*/
        CSR_BB ("I_HLIM_C_ST8_BS",       0,     8),     /*Sat limC for hue unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_Hue_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("I_HLIM_F_ST8_BS",      16,     8),     /*Sat limC for hue unsigned 0.8*/
        CSR_BB ("I_HLIM_E_ST8_BS",       0,     8),     /*Sat limC for hue unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_Hue_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("I_HLIM_H_ST8_BS",      16,     8),     /*Sat limC for hue unsigned 0.8*/
        CSR_BB ("I_HLIM_G_ST8_BS",       0,     8),     /*Sat limC for hue unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Sat_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_SLIM_B_ST8_BS",    16,     12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("STH_SLIM_A_ST8_BS",     0,     12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Sat_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_SLIM_D_ST8_BS",    16,     12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("STH_SLIM_C_ST8_BS",     0,     12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Sat_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_SLIM_F_ST8_BS",    16,     12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("STH_SLIM_E_ST8_BS",     0,     12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_Sat_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_SLIM_H_ST8_BS",    16,     12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("STH_SLIM_G_ST8_BS",     0,     12),    /*Saturation thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Sat_lim_AB_BC_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_SLIM_BC_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_SLIM_BC_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_SLIM_BC_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("S_SLP_SGN_SLIM_AB_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_SLIM_AB_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_SLIM_AB_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Sat_lim_CD_DE_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_SLIM_DE_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_SLIM_DE_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_SLIM_DE_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("S_SLP_SGN_SLIM_CD_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_SLIM_CD_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_SLIM_CD_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Sat_lim_EF_FG_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_SLIM_FG_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_SLIM_FG_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_SLIM_FG_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("S_SLP_SGN_SLIM_EF_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_SLIM_EF_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_SLIM_EF_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_Sat_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_SLIM_GH_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_SLIM_GH_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_SLIM_GH_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_Sat_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLIM_B_ST8_BS",      16,     8),     /*Sat limC for sat unsigned 0.8*/
        CSR_BB ("S_SLIM_A_ST8_BS",       0,     8),     /*Sat limA for sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_Sat_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLIM_D_ST8_BS",      16,     8),     /*Sat limC for sat unsigned 0.8*/
        CSR_BB ("S_SLIM_C_ST8_BS",       0,     8),     /*Sat limA for sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_Sat_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLIM_F_ST8_BS",      16,     8),     /*Sat limC for sat unsigned 0.8*/
        CSR_BB ("S_SLIM_E_ST8_BS",       0,     8),     /*Sat limA for sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_Sat_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLIM_H_ST8_BS",      16,     8),     /*Sat limC for sat unsigned 0.8*/
        CSR_BB ("S_SLIM_G_ST8_BS",       0,     8),     /*Sat limA for sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Sat_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_SLIM_B_ST8_BS",    16,     12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("ITH_SLIM_A_ST8_BS",     0,     12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Sat_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_SLIM_D_ST8_BS",    16,     12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("ITH_SLIM_C_ST8_BS",     0,     12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Sat_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_SLIM_F_ST8_BS",    16,     12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("ITH_SLIM_E_ST8_BS",     0,     12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_Sat_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_SLIM_H_ST8_BS",    16,     12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB ("ITH_SLIM_G_ST8_BS",     0,     12),    /*Intensity thresh for Sat limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Sat_lim_AB_BC_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_SLIM_BC_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_SLIM_BC_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_SLIM_BC_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("I_SLP_SGN_SLIM_AB_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_SLIM_AB_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_SLIM_AB_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Sat_lim_CD_DE_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_SLIM_DE_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_SLIM_DE_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_SLIM_DE_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("I_SLP_SGN_SLIM_CD_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_SLIM_CD_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_SLIM_CD_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Sat_lim_EF_FG_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_SLIM_FG_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_SLIM_FG_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_SLIM_FG_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("I_SLP_SGN_SLIM_EF_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_SLIM_EF_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_SLIM_EF_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_Sat_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_SLIM_GH_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_SLIM_GH_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_SLIM_GH_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_Sat_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLIM_B_ST8_BS",      16,      8),    /*SatlimC for Sat unsigned 0.8*/
        CSR_BB ("I_SLIM_A_ST8_BS",       0,      8),    /*SatlimA for Sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_Sat_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLIM_D_ST8_BS",      16,      0),    /*SatlimC for Sat unsigned 0.8*/
        CSR_BB ("I_SLIM_C_ST8_BS",       0,      8),    /*SatlimA for Sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_Sat_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLIM_F_ST8_BS",      16,      8),    /*SatlimC for Sat unsigned 0.8*/
        CSR_BB ("I_SLIM_E_ST8_BS",       0,      8),    /*SatlimA for Sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_Sat_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLIM_H_ST8_BS",      16,      8),    /*SatlimC for Sat unsigned 0.8*/
        CSR_BB ("I_SLIM_G_ST8_BS",       0,      8),    /*SatlimA for Sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_INT_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_ILIM_B_ST8_BS",    16,     12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB ("STH_ILIM_A_ST8_BS",     0,     12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_INT_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_ILIM_D_ST8_BS",    16,     12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB ("STH_ILIM_C_ST8_BS",     0,     12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_INT_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_ILIM_F_ST8_BS",    16,     12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB ("STH_ILIM_E_ST8_BS",     0,     12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SThresh_INT_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("STH_ILIM_H_ST8_BS",    16,     12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB ("STH_ILIM_G_ST8_BS",     0,     12),    /*Saturation thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_INT_lim_AB_BC_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_ILIM_BC_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_ILIM_BC_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_ILIM_BC_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("S_SLP_SGN_ILIM_AB_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_ILIM_AB_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_ILIM_AB_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_INT_lim_CD_DE_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_ILIM_DE_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_ILIM_DE_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_ILIM_DE_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("S_SLP_SGN_ILIM_CD_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_ILIM_CD_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_ILIM_CD_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_INT_lim_EF_FG_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_ILIM_FG_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_ILIM_FG_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_ILIM_FG_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("S_SLP_SGN_ILIM_EF_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_ILIM_EF_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_ILIM_EF_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_SSlope_INT_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("S_SLP_SGN_ILIM_GH_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("S_SLP_SFT_ILIM_GH_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("S_SLP_ILIM_GH_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_INT_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("S_ILIM_B_ST8_BS",      16,      8),    /*SatlimC for Sat unsigned 0.8*/
        CSR_BB ("S_ILIM_A_ST8_BS",       0,      8),    /*SatlimA for Sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_INT_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("S_ILIM_D_ST8_BS",      16,      8),    /*SatlimC for Sat unsigned 0.8*/
        CSR_BB ("S_ILIM_C_ST8_BS",       0,      8),    /*SatlimA for Sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_INT_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("S_ILIM_F_ST8_BS",      16,      8),    /*SatlimC for Sat unsigned 0.8*/
        CSR_BB ("S_ILIM_E_ST8_BS",       0,      8),    /*SatlimA for Sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_S_INT_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("S_ILIM_H_ST8_BS",      16,      8),    /*SatlimC for Sat unsigned 0.8*/
        CSR_BB ("S_ILIM_G_ST8_BS",       0,      8),    /*SatlimA for Sat unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_INT_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_ILIM_B_ST8_BS",    16,     12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB ("ITH_ILIM_A_ST8_BS",     0,     12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_INT_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_ILIM_D_ST8_BS",    16,     12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB ("ITH_ILIM_C_ST8_BS",     0,     12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_INT_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_ILIM_F_ST8_BS",    16,     12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB ("ITH_ILIM_E_ST8_BS",     0,     12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_IThresh_INT_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("ITH_ILIM_H_ST8_BS",    16,     12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB ("ITH_ILIM_G_ST8_BS",     0,     12),    /*Intensity  thresh for INT limiter unsigned 1.11*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_INT_lim_AB_BC_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_ILIM_BC_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_ILIM_BC_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_ILIM_BC_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("I_SLP_SGN_ILIM_AB_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_ILIM_AB_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_ILIM_AB_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_INT_lim_CD_DE_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_ILIM_DE_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_ILIM_DE_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_ILIM_DE_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("I_SLP_SGN_ILIM_CD_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_ILIM_CD_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_ILIM_CD_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_INT_lim_EF_FG_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_ILIM_FG_ST8_BS",     31,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_ILIM_FG_ST8_BS",     24,     4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_ILIM_FG_ST8_BS",         16,     8),     /* 8 BIT SLOPE*/
        CSR_BB ("I_SLP_SGN_ILIM_EF_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_ILIM_EF_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_ILIM_EF_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_ISlope_INT_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("I_SLP_SGN_ILIM_GH_ST8_BS",     15,     1),     /*SIGN OF SLOPE*/
        CSR_BB ("I_SLP_SFT_ILIM_GH_ST8_BS",     8,      4),     /*SHIFT OF SLOPE*/
        CSR_BB ("I_SLP_ILIM_GH_ST8_BS",         0,      8),     /* 8  BIT SLOPE*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_INT_lim_AB_ST8_BS_REGISTER []=
{
        CSR_BB ("I_ILIM_B_ST8_BS",      16,      8),    /*SatlimC for INT unsigned 0.8*/
        CSR_BB ("I_ILIM_A_ST8_BS",       0,      8),    /*SatlimA for INT unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_INT_lim_CD_ST8_BS_REGISTER []=
{
        CSR_BB ("I_ILIM_D_ST8_BS",      16,      8),    /*SatlimC for INT unsigned 0.8*/
        CSR_BB ("I_ILIM_C_ST8_BS",       0,      8),    /*SatlimA for INT unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
 
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_INT_lim_EF_ST8_BS_REGISTER []=
{
        CSR_BB ("I_ILIM_F_ST8_BS",      16,      8),    /*SatlimC for INT unsigned 0.8*/
        CSR_BB ("I_ILIM_E_ST8_BS",       0,      8),    /*SatlimA for INT unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};
static const struct EAS_RegBits g_csr_gen5_DPE_SCC_I_INT_lim_GH_ST8_BS_REGISTER []=
{
        CSR_BB ("I_ILIM_H_ST8_BS",      16,      8),    /*SatlimC for INT unsigned 0.8*/
        CSR_BB ("I_ILIM_G_ST8_BS",       0,      8),    /*SatlimA for INT unsigned 0.8*/
        CSR_BB_NULL_TERM()      /*NULL terminator*/
};


//-------------------SHARPNESS-----------------------------------------------------------


static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_N_Y_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",              12,      4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",          0,     11),    /* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_N_Y_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",         27,      5),     /*Required for the producer consumer model*/
    CSR_BB( "pix_coord_x",          16,      11),     /* X pixel coordinate of the first pixel in the stride.*/
    CSR_BB( "out_stride_w",          7,      9),     /*Output stride width*/
    CSR_BB( "RM",                            6,      1),     /*Indicates whether this stride is the right most stride*/
    CSR_BB( "LM",                            5,      1),     /*Indicates whether this stride is a left most stride*/
    CSR_BB( "in_stride_off",                 0,      5),     /*Input stride offset*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_CONTROL_REGISTER [] =
{
    CSR_BB( "sharpness_bypass",   0,      1),     /*sharpness_bypass*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};
  
static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_H0_COEFF_01_REGISTER [] =
{
    CSR_BB( "H0Coeff1",   16,      13),     /*H0 Coeff[1]*/
    CSR_BB( "H0Coeff0",   0,      13),     /*H0 Coeff[0]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_H0_COEFF_23_REGISTER [] =
{
    CSR_BB( "H0Coeff3",   16,      13),     /*H0 Coeff[3]*/
    CSR_BB( "H0Coeff2",   0,      13),     /*H0 Coeff[2]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_H0_COEFF_45_REGISTER [] =
{
    CSR_BB( "H0Coeff5",   16,      13),     /*H0 Coeff[5]*/
    CSR_BB( "H0Coeff4",   0,      13),     /*H0 Coeff[4]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_H1_COEFF_01_REGISTER [] =
{
    CSR_BB( "H1Coeff1",   16,      13),     /*H1 Coeff[1]*/
    CSR_BB( "H1Coeff0",   0,      13),     /*H1 Coeff[0]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_H1_COEFF_23_REGISTER [] =
{
    CSR_BB( "H1Coeff3",   16,      13),     /*H1 Coeff[3]*/
    CSR_BB( "H1Coeff2",   0,      13),     /*H1 Coeff[2]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_H1_COEFF_45_REGISTER [] =
{
    CSR_BB( "H1Coeff5",   16,      13),     /*H1 Coeff[5]*/
    CSR_BB( "H1Coeff4",   0,      13),     /*H1 Coeff[4]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_V0_COEFF_01_REGISTER [] =
{
    CSR_BB( "V0Coeff1",   16,      13),     /*V0 Coeff[1]*/
    CSR_BB( "V0Coeff0",   0,      13),     /*V0 Coeff[0]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_V0_COEFF_23_REGISTER [] =
{
    CSR_BB( "V0Coeff3",   16,      13),     /*V0 Coeff[3]*/
    CSR_BB( "V0Coeff2",   0,      13),     /*V0 Coeff[2]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_V0_COEFF_4_REGISTER [] =
{
    CSR_BB( "V0Coeff4",   0,      13),     /*V0 Coeff[4]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_V1_COEFF_01_REGISTER [] =
{
    CSR_BB( "V1Coeff1",   16,      13),     /*V1 Coeff[1]*/
    CSR_BB( "V1Coeff0",   0,      13),     /*V1 Coeff[0]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_V1_COEFF_23_REGISTER [] =
{
    CSR_BB( "V1Coeff3",   16,      13),     /*V1 Coeff[3]*/
    CSR_BB( "V1Coeff2",   0,      13),     /*V1 Coeff[2]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_V1_COEFF_4_REGISTER [] =
{
    CSR_BB( "V1Coeff4",   0,      13),     /*V1 Coeff[4]*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_H0_H1_GAIN_REGISTER [] =
{
    CSR_BB( "H1Gain",   16,      13),     /*H1 Gain*/
    CSR_BB( "H0Gain",   0,      13),     /*H0 Gain*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_V0_V1_GAIN_REGISTER [] =
{
    CSR_BB( "V1Gain",   16,      13),     /*V1 Gain*/
    CSR_BB( "V0Gain",   0,      13),     /*V0 Gain*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_H0_H1_CLIP_REGISTER [] =
{
    CSR_BB( "H1Clip",   16,      13),     /*H1 Clip*/
    CSR_BB( "H0Clip",   0,      13),     /*H0 Clip*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_V0_V1_CLIP_REGISTER [] =
{
    CSR_BB( "V1Clip",   16,      13),     /*V1 Clip*/
    CSR_BB( "V0Clip",   0,      13),     /*V0 Clip*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_H0_H1_CORE_REGISTER [] =
{
    CSR_BB( "H1Core",   16,      13),     /*H1 Core*/
    CSR_BB( "H0Core",   0,      13),     /*H0 Core*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen5_DPE_SHRP_V0_V1_CORE_REGISTER [] =
{
    CSR_BB( "V1Core",   16,      13),     /*V1 Core*/
    CSR_BB( "V0Core",   0,      13),     /*V0 Core*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};



//------------------------------------------------end of bit breakout -------------------------------


static const struct EAS_Register g_csr_gen5_GEN5_DPE [] =
{

/* DPE 420 422 */

	CSR_REG_W_BB("DPE_420_422_STRIDE_HEIGHT",		DPE_420_422_BASE_OFFSET + 0x00, g_csr_gen5_DPE_420_422_STRIDE_HEIGHT,"Stride height and no of strides - fixed for all strides in one picture")

   	CSR_REG_W_BB("DPE_420_422_Y_STRIDE_WIDTH",		DPE_420_422_BASE_OFFSET + 0x04, g_csr_gen5_DPE_420_422_Y_STRIDE_WIDTH,"N Component Y stride width")

   	CSR_REG_W_BB("DPE_420_422_cbcr_STRIDE_WIDTH",	DPE_420_422_BASE_OFFSET + 0x08,g_csr_gen5_DPE_420_422_cbcr_STRIDE_WIDTH, "N Component cbcr stride width")

   	CSR_REG_W_BB("DPE_420_422_Converter_Control",	DPE_420_422_BASE_OFFSET + 0x60,g_csr_gen5_DPE_420_422_Converter_Control, "control register")

/*DPE CP*/
	CSR_REG_W_BB("CP_CONTROL_REGISTER",			DPE_CP_BASE_OFFSET + 0x00,g_csr_gen5_DPE_CP_CONTROL_REGISTER, "Controls the reset and configuration of Control Plane")

	CSR_REG_W_BB("CP_ICACHE_BASE_ADDRESS",		DPE_CP_BASE_OFFSET + 0x04,g_csr_gen5_DPE_CP_ICACHE_BASE_ADDRESS, "Instruction Code base system address")

	CSR_REG_W_BB("CP_WATCHDOG_TIMER",			DPE_CP_BASE_OFFSET + 0x08,g_csr_gen5_DPE_CP_WATCHDOG_TIMER, "A free running watchdog timer")

	CSR_REG_W_BB("CACHELINE_INVALIDATE0",		DPE_CP_BASE_OFFSET + 0x10,g_csr_gen5_DPE_CACHELINE_INVALIDATE0, "32-bit lower Icache line invalidate mask")

	CSR_REG_W_BB("CACHELINE_INVALIDATE1",		DPE_CP_BASE_OFFSET + 0x14,g_csr_gen5_DPE_CACHELINE_INVALIDATE1, "32-bit lower Icache line invalidate mask")

	CSR_REG_W_BB("CACHELINE_INVALIDATE2",		DPE_CP_BASE_OFFSET + 0x18,g_csr_gen5_DPE_CACHELINE_INVALIDATE2, "32-bit lower Icache line invalidate mask")

	CSR_REG_W_BB("CP_DMA_SYSTEM_ADDRESS",		DPE_CP_BASE_OFFSET + 0x20,g_csr_gen5_DPE_CP_DMA_SYSTEM_ADDRESS, "32-bit system address for DMA")

	CSR_REG_W_BB("CP_DMA_LOCAL_ADDRESS",		DPE_CP_BASE_OFFSET + 0x24,g_csr_gen5_DPE_CP_DMA_LOCAL_ADDRESS, "16-bit local address for DMA")

	CSR_REG_W_BB("CP_DMA_CONTROL_STATUS",		DPE_CP_BASE_OFFSET + 0x28,g_csr_gen5_DPE_CP_DMA_CONTROL_STATUS, "DMA control and status register")

	CSR_REG_W_BB("HOST_DOORBELL",			DPE_CP_BASE_OFFSET + 0x30,g_csr_gen5_DPE_HOST_DOORBELL, "Host Processor doorbell register")

	CSR_REG_W_BB("HOST_IPC_STATUS",			DPE_CP_BASE_OFFSET + 0x34,g_csr_gen5_DPE_HOST_IPC_STATUS, "Host Processor doorbell and mailbox status register")

	CSR_REG_W_BB("CP_DOORBELL",				DPE_CP_BASE_OFFSET + 0x38,g_csr_gen5_DPE_CP_DOORBELL, "Control Processor doorbell register")

	CSR_REG_W_BB("CP_IPC_STATUS",			DPE_CP_BASE_OFFSET + 0x3C,g_csr_gen5_DPE_CP_IPC_STATUS, "Control Processor doorbell and mailbox status register")

	CSR_REG_W_BB("CP_SYSTEM_TIME_COUNTER0",		DPE_CP_BASE_OFFSET + 0x40,g_csr_gen5_DPE_CP_SYSTEM_TIME_COUNTER0, "System time stamp counter0 for video stream")

	CSR_REG_W_BB("CP_SYSTEM_TIME_COUNTER1",		DPE_CP_BASE_OFFSET + 0x44,g_csr_gen5_DPE_CP_SYSTEM_TIME_COUNTER1, "System time stamp counter1 for video stream")

	CSR_REG_W_BB("CP_SYSTEM_TIME_COUNTER2",		DPE_CP_BASE_OFFSET + 0x48,g_csr_gen5_DPE_CP_SYSTEM_TIME_COUNTER2, "System time stamp counter2 for video stream")

	CSR_REG_W_BB("CP_SYSTEM_TIME_COUNTER3",		DPE_CP_BASE_OFFSET + 0x4C,g_csr_gen5_DPE_CP_SYSTEM_TIME_COUNTER3, "System time stamp counter3 for video stream")

	CSR_REG_W_BB("HOST_INTERRUPT_ENABLE",		DPE_CP_BASE_OFFSET + 0x50,g_csr_gen5_DPE_HOST_INTERRUPT_ENABLE, "Interrupt enable register for Host Processor")

	CSR_REG_W_BB("CP_INTERRUPT_ENABLE",			DPE_CP_BASE_OFFSET + 0x54,g_csr_gen5_DPE_CP_INTERRUPT_ENABLE,"Interrupt enable register for Control Processor")

	CSR_REG_W_BB("CP_INTERRUPT_STATUS_REGISTER",	DPE_CP_BASE_OFFSET + 0x58,g_csr_gen5_DPE_CP_INTERRUPT_STATUS_REGISTER, "Current Interrupt Status ")

	CSR_REG_W_BB("DPE_EVENT_ENABLE_REGISTER",		DPE_CP_BASE_OFFSET + 0x60,g_csr_gen5_DPE_DPE_EVENT_ENABLE_REGISTER, "DPE event interrupt enable register")

	CSR_REG_W_BB("DPE_EVENT_STATUS_REGISTER",		DPE_CP_BASE_OFFSET + 0x64,g_csr_gen5_DPE_DPE_EVENT_STATUS_REGISTER, "DPE event status register")

	CSR_REG_W_BB("EXT_EVENT_ENABLE_REGISTER",		DPE_CP_BASE_OFFSET + 0x70,g_csr_gen5_DPE_EXT_EVENT_ENABLE_REGISTER, "External event interrupt enable register")

	CSR_REG_W_BB("EXT_EVENT_STATUS_REGISTER", 		DPE_CP_BASE_OFFSET + 0x74,g_csr_gen5_DPE_EXT_EVENT_STATUS_REGISTER, "External event status register")
/*DPE DI*/

	CSR_REG_W_BB("DI_Stride_Height_Register",				DPE_DI_BASE_OFFSET + 0x00,g_csr_gen5_DPE_DI_Stride_Height_Register, "is used to set up the stride height and number of strides per frame")

	CSR_REG_W_BB("DI_Field_Nplus1_Stride_Width_Register",			DPE_DI_BASE_OFFSET + 0x04,g_csr_gen5_DPE_DI_Field_Nplus1_Stride_Width_Register, "set up the per stride input stride width, stride offset and output stride width for Field N+1")

	CSR_REG_W_BB("DI_Field_N_Stride_Width_Register",			DPE_DI_BASE_OFFSET + 0x08,g_csr_gen5_DPE_DI_Field_N_Stride_Width_Register, "set up the per stride input stride width, stride offset and output stride width for Field N")

	CSR_REG_W_BB("DI_Field_Nless1_Stride_Width_Register",			DPE_DI_BASE_OFFSET + 0x0c,g_csr_gen5_DPE_DI_Field_Nless1_Stride_Width_Register, "set up the per stride input stride width, stride offset and output stride width for Field 1")

	CSR_REG_W_BB("DI_Field_MH_Stride_Width_Register",			DPE_DI_BASE_OFFSET + 0x10,g_csr_gen5_DPE_DI_Field_MH_Stride_Width_Register, "sset up the per stride input stride width, stride offset and output stride width for motion history")

	CSR_REG_W_BB("DI_Field_FMD_Stride_Width_Register",			DPE_DI_BASE_OFFSET + 0x14,g_csr_gen5_DPE_DI_Field_FMD_Stride_Width_Register, "set up the per stride input stride width, stride offset and output stride width for film mode detection")

	CSR_REG_W_BB("DI_Field_N_Next_Block_Parameters_Register",		DPE_DI_BASE_OFFSET + 0x18,g_csr_gen5_DPE_DI_Field_N_Next_Block_Parameters_Register, "used to set up the next block parameters")

	CSR_REG_W_BB("DI_Control_Register",					DPE_DI_BASE_OFFSET + 0x20,g_csr_gen5_DPE_DI_Control_Register, "control register")

	CSR_REG_W_BB("DI_Status_Register",					DPE_DI_BASE_OFFSET + 0x24, NULL , "status register")

	CSR_REG_W_BB("DI_SDI_SAD_Wt_0_3_Register",			DPE_DI_BASE_OFFSET + 0x28, g_csr_gen5_DPE_DI_SDI_SAD_Wt_0_3_Register , "DI_SDI_SAD_Wt_0_3_Register")

	CSR_REG_W_BB("DI_SDI_SAD_Wt_4_5_Register",			DPE_DI_BASE_OFFSET + 0x2c, g_csr_gen5_DPE_DI_SDI_SAD_Wt_4_5_Register , "DI_SDI_SAD_Wt_4_5_Register")

	CSR_REG_W_BB("DI_Motion_Detect_SAD_Threshold_Parameter_Register",	DPE_DI_BASE_OFFSET + 0x30,g_csr_gen5_DPE_DI_Motion_Detect_SAD_Threshold_Parameter_Register, "DI_Motion_Detect_SAD_Threshold_Parameter_Register")

	CSR_REG_W_BB("DI_Motion_Detect_MAD_History_Parameter_Register",	DPE_DI_BASE_OFFSET + 0x34,g_csr_gen5_DPE_DI_Motion_Detect_MAD_History_Parameter_Register, "DI_Motion_Detect_MAD_Hsitory_Parameter_Register")

	CSR_REG_W_BB("DI_Motion_Detect_SAD_History_Parameter_Register",	DPE_DI_BASE_OFFSET + 0x38,g_csr_gen5_DPE_DI_Motion_Detect_SAD_History_Parameter_Register, "DI_Motion_Detect_SAD_Hsitory_Parameter_Register")

	CSR_REG_W_BB("DI_Motion_Detect_Noise_Range_Register",		DPE_DI_BASE_OFFSET + 0x3c,g_csr_gen5_DPE_DI_Motion_Detect_Noise_Range_Register, "DI_Motion_Detect Noise Range Register")

	CSR_REG_W_BB("DI_Motion_Detect_Noise_Level_Register",		DPE_DI_BASE_OFFSET + 0x40,g_csr_gen5_DPE_DI_Motion_Detect_Noise_Level_Register, "DI_Motion_Detect Noise level Register")

	CSR_REG_W_BB("DI_Motion_Detect_Noise_Pixel_Count_Register",		DPE_DI_BASE_OFFSET + 0x44,g_csr_gen5_DPE_DI_Motion_Detect_Noise_Pixel_Count_Register, "DI_Motion_Detect Noise pixel count Register")

	CSR_REG_W_BB("DI_Motion_Detect_Noise_Pixel_Count2_Register",	DPE_DI_BASE_OFFSET + 0x48,g_csr_gen5_DPE_DI_Motion_Detect_Noise_Pixel_Count2_Register, "DI_Motion_Detect Noise pixel count2 Register")

	CSR_REG_W_BB("DI_Motion_Detect_Threshold_Register",			DPE_DI_BASE_OFFSET + 0x4c,g_csr_gen5_DPE_DI_Motion_Detect_Threshold_Register, "DI_Motion_Detect threshold Register")

	CSR_REG_W_BB("DI_NRF_Index_Shift_Registers",			DPE_DI_BASE_OFFSET + 0x50,g_csr_gen5_DPE_DI_NRF_Index_Shift_Register, "DI_NRF_Index_Shift_Registers")

	CSR_REG_W_BB("DI_Motion_Detect_Static_Noise_Level_Register",		DPE_DI_BASE_OFFSET + 0x5c,g_csr_gen5_DPE_DI_Motion_Detect_Static_Noise_Level_Register, "DI_Motion_Detect Static Noise level Register")

	CSR_REG_W_BB("DI_Motion_Detect_Static_Noise_Pixel_Count_Register",		DPE_DI_BASE_OFFSET + 0x60,g_csr_gen5_DPE_DI_Motion_Detect_Static_Noise_Pixel_Count_Register, "DI_Motion_Detect Static Noise pixel count Register")

	CSR_REG_W_BB("DI_Motion_Detect_Static_Noise_Pixel_Count2_Register",	DPE_DI_BASE_OFFSET + 0x64,g_csr_gen5_DPE_DI_Motion_Detect_Static_Noise_Pixel_Count2_Register, "DI_Motion_Detect Static Noise pixel count2 Register")

	CSR_REG_W_BB("DI_FMD_TC_prev_count_Registers",			DPE_DI_BASE_OFFSET + 0x6c,g_csr_gen5_DPE_DI_FMD_TC_prev_count_Registers, "DI_FMD_TC_prev_count_Registers")

	CSR_REG_W_BB("DI_FMD_TC_next_count_Registers",			DPE_DI_BASE_OFFSET + 0x70,g_csr_gen5_DPE_DI_FMD_TC_next_count_Registers, "DI_FMD_TC_next_count_Registers")

	CSR_REG_W_BB("DI_FMD_FDC_Registers",				DPE_DI_BASE_OFFSET + 0x74,g_csr_gen5_DPE_DI_FMD_FDC_Registers, "DI_FMD_FDC_Registers")

	CSR_REG_W_BB("DI_FMD_Th_Registers",				DPE_DI_BASE_OFFSET + 0x78,g_csr_gen5_DPE_DI_FMD_Th_Registers, "DI_FMD_Th_Registers")

	CSR_REG_W_BB("DI_New_MD_Th_Register",				DPE_DI_BASE_OFFSET + 0xec,g_csr_gen5_DPE_DI_New_MD_Th_Register, "DI_New_MD_Th_Register")

	CSR_REG_W_BB("DI_MD_SAD_WT_0_7_Register",				DPE_DI_BASE_OFFSET + 0xf0,g_csr_gen5_DPE_DI_MD_SAD_WT_0_7_Register, "DI_MD_SAD_WT_0_7_Register")

	CSR_REG_W_BB("DI_MD_SAD_WT_8_14_Register",				DPE_DI_BASE_OFFSET + 0xf4,g_csr_gen5_DPE_DI_MD_SAD_WT_8_14_Register, "DI_MD_SAD_WT_8_14_Register")

	CSR_REG_W_BB("DI_MD_MAD_WT_0_7_Register",				DPE_DI_BASE_OFFSET + 0xf8,g_csr_gen5_DPE_DI_MD_MAD_WT_0_7_Register, "DI_MD_MAD_WT_0_7_Register")

/* DPE TNRF */
	CSR_REG_W_BB("DI_TNRF_SHIFT_Blend_Weight_Register",		DPE_MADI_BASE_OFFSET + 0x00,g_csr_gen5_DPE_TNRF_SHIFT_Blend_Weight, "DI_TNRF_SHIFT_Blend_Weight_Register")

	CSR_REG_W_BB("DI_TNRF_Y_LUT_0_3_Register",		DPE_MADI_BASE_OFFSET + 0x04,g_csr_gen5_DPE_TNRF_Y_LUT_0_3, "DI_TNRF_Y_LUT_0_3_Register")

	CSR_REG_W_BB("DI_TNRF_Y_LUT_4_7_Register",		DPE_MADI_BASE_OFFSET + 0x08,g_csr_gen5_DPE_TNRF_Y_LUT_4_7, "DI_TNRF_Y_LUT_4_7_Register")

	CSR_REG_W_BB("DI_TNRF_Y_LUT_8_11_Register",		DPE_MADI_BASE_OFFSET + 0x0c,g_csr_gen5_DPE_TNRF_Y_LUT_8_11, "DI_TNRF_Y_LUT_8_11_Register")

	CSR_REG_W_BB("DI_TNRF_Y_LUT_12_15_Register",		DPE_MADI_BASE_OFFSET + 0x10,g_csr_gen5_DPE_TNRF_Y_LUT_12_15, "DI_TNRF_Y_LUT_12_15_Register")

	CSR_REG_W_BB("DI_TNRF_UV_LUT_0_3_Register",		DPE_MADI_BASE_OFFSET + 0x14,g_csr_gen5_DPE_TNRF_UV_LUT_0_3, "DI_TNRF_UV_LUT_0_3_Register")

	CSR_REG_W_BB("DI_TNRF_UV_LUT_4_7_Register",		DPE_MADI_BASE_OFFSET + 0x18,g_csr_gen5_DPE_TNRF_UV_LUT_4_7, "DI_TNRF_UV_LUT_4_7_Register")

	CSR_REG_W_BB("DI_TNRF_UV_LUT_8_11_Register",		DPE_MADI_BASE_OFFSET + 0x1c,g_csr_gen5_DPE_TNRF_UV_LUT_8_11, "DI_TNRF_UV_LUT_8_11_Register")

	CSR_REG_W_BB("DI_TNRF_UV_LUT_12_15_Register",		DPE_MADI_BASE_OFFSET + 0x20,g_csr_gen5_DPE_TNRF_UV_LUT_12_15, "DI_TNRF_UV_LUT_12_15_Register")

	CSR_REG_W_BB("DI_TNRF_Var_Sc_Factor_Register",		DPE_MADI_BASE_OFFSET + 0x24,g_csr_gen5_DPE_TNRF_Var_Sc_Factor, "DI_TNRF_Var_Sc_Factor_Register")

	CSR_REG_W_BB("DI_Noise_Estimation_Th_Register",		DPE_MADI_BASE_OFFSET + 0x30,g_csr_gen5_DPE_Noise_Estimation_Th, "DI_Noise_Estimation_Th_Register")

	CSR_REG_W_BB("DI_Noise_Estimation_Var_Noise_Count_Register",	DPE_MADI_BASE_OFFSET + 0x34,g_csr_gen5_DPE_Noise_Estimation_Var_Noise_Count, "DI_Noise_Estimation_Var_Noise_Count_Register")

	CSR_REG_W_BB("DI_Noise_Estimation_Var_Noise_Level_Register",	DPE_MADI_BASE_OFFSET + 0x38,g_csr_gen5_DPE_Noise_Estimation_Var_Noise_Level, "DI_Noise_Estimation_Var_Noise_Level_Register")


/* DPE MADI */

	CSR_REG_W_BB("DI_MADI_LumaGain_Blend_LUT_0_3_Register",		DPE_MADI_BASE_OFFSET + 0x50,g_csr_gen5_DPE_MADI_LumaGain_Blend_LUT_0_3, "DI_MADI_LumaGain_Blend_LUT_0_3_Register")

	CSR_REG_W_BB("DI_MADI_LumaGain_Blend_LUT_4_7_Register",		DPE_MADI_BASE_OFFSET + 0x54,g_csr_gen5_DPE_MADI_LumaGain_Blend_LUT_4_7, "DI_MADI_LumaGain_Blend_LUT_4_7_Register")

	CSR_REG_W_BB("DI_MADI_LumaGain_LPF_LUT_0_3_Register",		DPE_MADI_BASE_OFFSET + 0x58,g_csr_gen5_DPE_MADI_LumaGain_LPF_LUT_0_3, "DI_MADI_LumaGain_LPF_LUT_0_3_Register")

	CSR_REG_W_BB("DI_MADI_LumaGain_LPF_LUT_4_7_Register",		DPE_MADI_BASE_OFFSET + 0x5c,g_csr_gen5_DPE_MADI_LumaGain_LPF_LUT_4_7, "DI_MADI_LumaGain_LPF_LUT_4_7_Register")

	CSR_REG_W_BB("DI_MADI_Coring_Th_Register",		DPE_MADI_BASE_OFFSET + 0x60,g_csr_gen5_DPE_MADI_Coring_Th, "DI_MADI_Coring_Th_Register")

	CSR_REG_W_BB("DI_MADI_Freq_Ana_SAD_Th_Register",		DPE_MADI_BASE_OFFSET + 0x64,g_csr_gen5_DPE_MADI_Freq_Ana_SAD_Th, "DI_MADI_Freq_Ana_SAD_Th_Register")

	CSR_REG_W_BB("DI_MADI_Freq_Ana_Filter1_Th_Register",		DPE_MADI_BASE_OFFSET + 0x68,g_csr_gen5_DPE_MADI_Freq_Ana_Filter1_Th, "DI_MADI_Freq_Ana_Filter1_Th_Register")

	CSR_REG_W_BB("DI_MADI_Freq_Ana_Filter3_Th_Register",		DPE_MADI_BASE_OFFSET + 0x6c,g_csr_gen5_DPE_MADI_Freq_Ana_Filter3_Th, "DI_MADI_Freq_Ana_Filter3_Th_Register")

	CSR_REG_W_BB("DI_MADI_SAD_MAD_TM_WTS_Register",		DPE_MADI_BASE_OFFSET + 0x70,g_csr_gen5_DPE_MADI_SAD_MAD_TM_WTS, "DI_MADI_SAD_MAD_TM_WTS_Register")

	CSR_REG_W_BB("DI_MADI_FWT_Blend_LUT_0_3_Register",		DPE_MADI_BASE_OFFSET + 0x74,g_csr_gen5_DPE_MADI_FWT_Blend_LUT_0_3, "DI_MADI_FWT_Blend_LUT_0_3_Register")

	CSR_REG_W_BB("DI_MADI_FWT_Blend_LUT_4_7_Register",		DPE_MADI_BASE_OFFSET + 0x78,g_csr_gen5_DPE_MADI_FWT_Blend_LUT_4_7, "DI_MADI_FWT_Blend_LUT_4_7_Register")

	CSR_REG_W_BB("DI_MADI_FWT_LPF_LUT_0_3_Register",		DPE_MADI_BASE_OFFSET + 0x7c,g_csr_gen5_DPE_MADI_FWT_LPF_LUT_0_3, "DI_MADI_FWT_LPF_LUT_0_3_Register")

	CSR_REG_W_BB("DI_MADI_FWT_LPF_LUT_4_7_Register",		DPE_MADI_BASE_OFFSET + 0x80,g_csr_gen5_DPE_MADI_FWT_LPF_LUT_4_7, "DI_MADI_FWT_LPF_LUT_4_7_Register")

	CSR_REG_W_BB("DI_MADI_Post_TM_Th_Register",		DPE_MADI_BASE_OFFSET + 0x84,g_csr_gen5_DPE_MADI_Post_TM_Th, "DI_MADI_Post_TM_Th_Register")

	CSR_REG_W_BB("DI_MADI_Control_Register",		DPE_MADI_BASE_OFFSET + 0x88,g_csr_gen5_DPE_MADI_Control, "DI_MADI_Control_Register")

	CSR_REG_W_BB("DI_MADI_Chicken_Bit_Register",		DPE_MADI_BASE_OFFSET + 0x100,g_csr_gen5_DPE_MADI_Chicken_Bit, "DI_MADI_Chicken_Bit_Register")
	
/* DPE Deringing */
/*
	CSR_REG_W_BB("Deringing_Stride_Height_Register",	DPE_RNR_BASE_OFFSET + 0x00,g_csr_gen5_DPE_Deringing_Stride_Height_Register, "set up the stride height and number of strides per frame")

	CSR_REG_W_BB("Deringing_Stride_Width_Register",		DPE_RNR_BASE_OFFSET + 0x04,g_csr_gen5_DPE_Deringing_Stride_Width_Register, "set up the input stride width, stride offset and output stride width for frame N")

	CSR_REG_W_BB("Deringing_Control_Register",			DPE_RNR_BASE_OFFSET + 0x40,g_csr_gen5_DPE_Deringing_Control_Register, "Deringing_Control_Register")

	CSR_REG_W_BB("Deringing_Threshold_Register",		DPE_RNR_BASE_OFFSET + 0x44,g_csr_gen5_DPE_Deringing_Threshold_Register, "Deringing_Threshold_Register")
*/

/* DPE SNRF */

	CSR_REG_W_BB("SNRF_Y_Stride_Height_Register",		DPE_SNRF_BASE_OFFSET + 0x00,g_csr_gen5_DPE_SNRF_Y_Stride_Height_Register, "DPE_SNRF_Y_stride_height")

	CSR_REG_W_BB("SNRF_Y_Stride_Width_Register",		DPE_SNRF_BASE_OFFSET + 0x04,g_csr_gen5_DPE_SNRF_Y_Stride_Width_Register , "DPE_SNRF_Y_stride_width")

	CSR_REG_W_BB("SNRF_UV_Stride_Height_Register",		DPE_SNRF_BASE_OFFSET + 0x08,g_csr_gen5_DPE_SNRF_UV_Stride_Height_Register , "DPE_SNRF_UV_stride_height")

	CSR_REG_W_BB("SNRF_UV_Stride_Width_Register",		DPE_SNRF_BASE_OFFSET + 0x0C,g_csr_gen5_DPE_SNRF_UV_Stride_Width_Register , "DPE_SNRF_UV_stride_width")

	CSR_REG_W_BB("SNRF_Y_NEXT_BLOCK_PARAMS",		DPE_SNRF_BASE_OFFSET + 0x10,g_csr_gen5_DPE_SNRF_Y_NEXT_BLOCK_PARAMS, "SNRF_Luma_Next_Field_Register")

	CSR_REG_W_BB("SNRF_UV_NEXT_BLOCK_PARAMS",	DPE_SNRF_BASE_OFFSET + 0x14,g_csr_gen5_DPE_SNRF_UV_NEXT_BLOCK_PARAMS, "SNRF_Chroma_Next_Field_Register")

	CSR_REG_W_BB("SNRF_Control_Register",				DPE_SNRF_BASE_OFFSET + 0x18,g_csr_gen5_DPE_SNRF_CONTROL , "SNRF_Control_Register")

	CSR_REG_W_BB("SNRF_In_filter_y0_Register",			DPE_SNRF_BASE_OFFSET + 0x20, g_csr_gen5_DPE_SNRF_IN_FILTER_Y_0_REGISTER, "SNRF_In_filter_y0_Register")
	
	CSR_REG_W_BB("SNRF_In_filter_y1_Register",			DPE_SNRF_BASE_OFFSET + 0x24, g_csr_gen5_DPE_SNRF_IN_FILTER_Y_1_REGISTER, "SNRF_In_filter_y1_Register")
	
	CSR_REG_W_BB("SNRF_In_filter_y2_Register",			DPE_SNRF_BASE_OFFSET + 0x28, g_csr_gen5_DPE_SNRF_IN_FILTER_Y_2_REGISTER, "SNRF_In_filter_y2_Register")
	
	CSR_REG_W_BB("SNRF_In_filter_y3_Register",			DPE_SNRF_BASE_OFFSET + 0x2c, g_csr_gen5_DPE_SNRF_IN_FILTER_Y_3_REGISTER, "SNRF_In_filter_y3_Register")
	
	CSR_REG_W_BB("SNRF_In_filter_y4_Register",			DPE_SNRF_BASE_OFFSET + 0x30, g_csr_gen5_DPE_SNRF_IN_FILTER_Y_4_REGISTER, "SNRF_In_filter_y4_Register")
	
	CSR_REG_W_BB("SNRF_In_filter_y5_Register",			DPE_SNRF_BASE_OFFSET + 0x34, g_csr_gen5_DPE_SNRF_IN_FILTER_Y_5_REGISTER, "SNRF_In_filter_y5_Register")
	
	CSR_REG_W_BB("SNRF_In_filter_y6_Register",			DPE_SNRF_BASE_OFFSET + 0x38, g_csr_gen5_DPE_SNRF_IN_FILTER_Y_6_REGISTER, "SNRF_In_filter_y6_Register")
	
	CSR_REG_W_BB("SNRF_In_filter_y7_Register",			DPE_SNRF_BASE_OFFSET + 0x3c, g_csr_gen5_DPE_SNRF_IN_FILTER_Y_7_REGISTER, "SNRF_In_filter_y7_Register")
	
	CSR_REG_W_BB("SNRF_In_filter_y8_Register",			DPE_SNRF_BASE_OFFSET + 0x40, g_csr_gen5_DPE_SNRF_IN_FILTER_Y_8_REGISTER, "SNRF_In_filter_y8_Register")

	CSR_REG_W_BB("SNRF_Out_filter_y0_Register",			DPE_SNRF_BASE_OFFSET + 0x44, g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_0_REGISTER, "SNRF_Out_filter_y0_Register")

	CSR_REG_W_BB("SNRF_Out_filter_y1_Register",			DPE_SNRF_BASE_OFFSET + 0x48, g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_1_REGISTER, "SNRF_Out_filter_y1_Register")

	CSR_REG_W_BB("SNRF_Out_filter_y2_Register",			DPE_SNRF_BASE_OFFSET + 0x4c, g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_2_REGISTER, "SNRF_Out_filter_y2_Register")

	CSR_REG_W_BB("SNRF_Out_filter_y3_Register",			DPE_SNRF_BASE_OFFSET + 0x50, g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_3_REGISTER, "SNRF_Out_filter_y3_Register")

	CSR_REG_W_BB("SNRF_Out_filter_y4_Register",			DPE_SNRF_BASE_OFFSET + 0x54, g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_4_REGISTER, "SNRF_Out_filter_y4_Register")

	CSR_REG_W_BB("SNRF_Out_filter_y5_Register",			DPE_SNRF_BASE_OFFSET + 0x58, g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_5_REGISTER, "SNRF_Out_filter_y5_Register")

	CSR_REG_W_BB("SNRF_Out_filter_y6_Register",			DPE_SNRF_BASE_OFFSET + 0x5c, g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_6_REGISTER, "SNRF_Out_filter_y6_Register")

	CSR_REG_W_BB("SNRF_Out_filter_y7_Register",			DPE_SNRF_BASE_OFFSET + 0x60, g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_7_REGISTER, "SNRF_Out_filter_y7_Register")

	CSR_REG_W_BB("SNRF_Out_filter_y8_Register",			DPE_SNRF_BASE_OFFSET + 0x64, g_csr_gen5_DPE_SNRF_OUT_FILTER_Y_8_REGISTER, "SNRF_Out_filter_y8_Register")

	CSR_REG_W_BB("SNRF_Out_filter_uv0_Register",			DPE_SNRF_BASE_OFFSET + 0x68, g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_0_REGISTER, "SNRF_Out_filter_UV0_Register")

	CSR_REG_W_BB("SNRF_Out_filter_uv1_Register",			DPE_SNRF_BASE_OFFSET + 0x6c, g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_1_REGISTER, "SNRF_Out_filter_UV1_Register")

	CSR_REG_W_BB("SNRF_Out_filter_uv2_Register",			DPE_SNRF_BASE_OFFSET + 0x70, g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_2_REGISTER, "SNRF_Out_filter_UV2_Register")

	CSR_REG_W_BB("SNRF_Out_filter_uv3_Register",			DPE_SNRF_BASE_OFFSET + 0x74, g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_3_REGISTER, "SNRF_Out_filter_UV3_Register")

	CSR_REG_W_BB("SNRF_Out_filter_uv4_Register",			DPE_SNRF_BASE_OFFSET + 0x78, g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_4_REGISTER, "SNRF_Out_filter_UV4_Register")

	CSR_REG_W_BB("SNRF_Out_filter_uv5_Register",			DPE_SNRF_BASE_OFFSET + 0x7c, g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_5_REGISTER, "SNRF_Out_filter_UV5_Register")

	CSR_REG_W_BB("SNRF_Out_filter_uv6_Register",			DPE_SNRF_BASE_OFFSET + 0x80, g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_6_REGISTER, "SNRF_Out_filter_UV6_Register")

	CSR_REG_W_BB("SNRF_Out_filter_uv7_Register",			DPE_SNRF_BASE_OFFSET + 0x84, g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_7_REGISTER, "SNRF_Out_filter_UV7_Register")

	CSR_REG_W_BB("SNRF_Out_filter_uv8_Register",			DPE_SNRF_BASE_OFFSET + 0x88, g_csr_gen5_DPE_SNRF_OUT_FILTER_UV_8_REGISTER, "SNRF_Out_filter_UV8_Register")

	CSR_REG_W_BB("SNRF_Max_distance_threshold_register",		DPE_SNRF_BASE_OFFSET + 0x8c, g_csr_gen5_DPE_SNRF_MAX_Distance_Threshold_REGISTER, "SNRF_Max_distance_threshold_register")

	CSR_REG_W_BB("SNRF_Min_distance_threshold_register",		DPE_SNRF_BASE_OFFSET + 0x90, g_csr_gen5_DPE_SNRF_MIN_Distance_Threshold_REGISTER, "SNRF_Min_distance_threshold_register")

	CSR_REG_W_BB("SNRF_Impulse_noise_threshold_register",	DPE_SNRF_BASE_OFFSET + 0x94, g_csr_gen5_DPE_SNRF_Impulse_Noise_Threshold_REGISTER, "SNRF_Impulse_noise_threshold_register")

	CSR_REG_W_BB("SNRF_Output_avg_threshold_register",	DPE_SNRF_BASE_OFFSET + 0x98, g_csr_gen5_DPE_SNRF_Output_Average_Threshold_REGISTER, "SNRF_Output_avg_threshold_register")

	CSR_REG_W_BB("SNRF_fft_hist_cntrl_register",		DPE_SNRF_BASE_OFFSET + 0x500,g_csr_gen5_DPE_SNRF_FFT_HIST_APL_CNTRL_REGISTER, "SNRF_fft_hist_cntrl_register") 

	CSR_REG_W_BB("SNRF_fft_hist_y_start_register",	DPE_SNRF_BASE_OFFSET + 0x504,g_csr_gen5_DPE_SNRF_FFT_HIST_Y_START_COORD_REGISTER, "SNRF_fft_hist_y_start_register") 

	CSR_REG_W_BB("SNRF_fft_hist_y_end_register",	        DPE_SNRF_BASE_OFFSET + 0x508,g_csr_gen5_DPE_SNRF_FFT_HIST_Y_END_COORD_REGISTER, "SNRF_fft_hist_y_end_register") 

	CSR_REG_W_BB("SNRF_fft_hist_CbCr_start_register",	DPE_SNRF_BASE_OFFSET + 0x50c,g_csr_gen5_DPE_SNRF_FFT_HIST_CbCr_START_COORD_REGISTER, "SNRF_fft_hist_CbCr_start_register") 

	CSR_REG_W_BB("SNRF_fft_hist_CbCr_end_register",      DPE_SNRF_BASE_OFFSET + 0x510,g_csr_gen5_DPE_SNRF_FFT_HIST_CbCr_END_COORD_REGISTER, "SNRF_fft_hist_CbCr_end_register") 

	CSR_REG_W_BB("SNRF_apl_y_start_register",	DPE_SNRF_BASE_OFFSET + 0x514,g_csr_gen5_DPE_SNRF_APL_Y_START_COORD_REGISTER, "SNRF_apl_y_start_register") 

	CSR_REG_W_BB("SNRF_apl_y_end_register",	DPE_SNRF_BASE_OFFSET + 0x518,g_csr_gen5_DPE_SNRF_APL_Y_END_COORD_REGISTER, "SNRF_apl_y_end_register") 

	CSR_REG_W_BB("SNRF_apl_CbCr_start_register",	DPE_SNRF_BASE_OFFSET + 0x51c,g_csr_gen5_DPE_SNRF_APL_CbCr_START_COORD_REGISTER, "SNRF_apl_CbCr_start_register") 

	CSR_REG_W_BB("SNRF_apl_CbCr_end_register",	DPE_SNRF_BASE_OFFSET + 0x520,g_csr_gen5_DPE_SNRF_APL_CbCr_END_COORD_REGISTER, "SNRF_apl_CbCr_end_register") 

	CSR_REG_W_BB("SNRF_stride_width_y",		DPE_SNRF_BASE_OFFSET + 0x524,g_csr_gen5_DPE_SNRF_STRIDE_WIDTH_REGISTER_Y, "SNRF_stride_width_y")

	CSR_REG_W_BB("SNRF_stride_width_CbCr",	DPE_SNRF_BASE_OFFSET + 0x528,g_csr_gen5_DPE_SNRF_STRIDE_WIDTH_REGISTER_CbCr, "SNRF_stride_width_CbCr")

	CSR_REG_W_BB("SNRF_fft_coeff_0_A",		DPE_SNRF_BASE_OFFSET + 0x52c,g_csr_gen5_DPE_SNRF_FFT_COEF_0_A, "SNRF_fft_coeff_0_A")

	CSR_REG_W_BB("SNRF_fft_coeff_0_B",		DPE_SNRF_BASE_OFFSET + 0x530,g_csr_gen5_DPE_SNRF_FFT_COEF_0_B, "SNRF_fft_coeff_0_B")

	CSR_REG_W_BB("SNRF_fft_coeff_1_A",		DPE_SNRF_BASE_OFFSET + 0x534,g_csr_gen5_DPE_SNRF_FFT_COEF_1_A, "SNRF_fft_coeff_1_A")

	CSR_REG_W_BB("SNRF_fft_coeff_1_B",		DPE_SNRF_BASE_OFFSET + 0x538,g_csr_gen5_DPE_SNRF_FFT_COEF_1_B, "SNRF_fft_coeff_1_B")

	CSR_REG_W_BB("SNRF_fft_coeff_2_A",		DPE_SNRF_BASE_OFFSET + 0x53c,g_csr_gen5_DPE_SNRF_FFT_COEF_2_A, "SNRF_fft_coeff_2_A")

	CSR_REG_W_BB("SNRF_fft_coeff_2_B",		DPE_SNRF_BASE_OFFSET + 0x540,g_csr_gen5_DPE_SNRF_FFT_COEF_2_B, "SNRF_fft_coeff_2_B")

	CSR_REG_W_BB("SNRF_fft_coeff_3_A",		DPE_SNRF_BASE_OFFSET + 0x544,g_csr_gen5_DPE_SNRF_FFT_COEF_3_A, "SNRF_fft_coeff_3_A")

	CSR_REG_W_BB("SNRF_fft_coeff_3_B",		DPE_SNRF_BASE_OFFSET + 0x548,g_csr_gen5_DPE_SNRF_FFT_COEF_3_B, "SNRF_fft_coeff_3_B")

	CSR_REG_W_BB("SNRF_fft_coeff_4_A",		DPE_SNRF_BASE_OFFSET + 0x54c,g_csr_gen5_DPE_SNRF_FFT_COEF_4_A, "SNRF_fft_coeff_4_A")

	CSR_REG_W_BB("SNRF_fft_coeff_4_B",		DPE_SNRF_BASE_OFFSET + 0x550,g_csr_gen5_DPE_SNRF_FFT_COEF_4_B, "SNRF_fft_coeff_4_B")

	CSR_REG_W_BB("SNRF_fft_th",  		DPE_SNRF_BASE_OFFSET + 0x554,g_csr_gen5_DPE_SNRF_FFT_TH, "SNRF_fft_th")

	CSR_REG_W_BB("SNRF_pix_cum_value_y",	        DPE_SNRF_BASE_OFFSET + 0x558,g_csr_gen5_DPE_SNRF_PIX_CUM_VALUE_Y, "SNRF_pix_cum_value_y")

	CSR_REG_W_BB("SNRF_pix_cum_value_Cb",	 DPE_SNRF_BASE_OFFSET + 0x55C,g_csr_gen5_DPE_SNRF_PIX_CUM_VALUE_Cb, "SNRF_pix_cum_value_Cb")

	CSR_REG_W_BB("SNRF_pix_cum_value_Cr",         DPE_SNRF_BASE_OFFSET + 0x560,g_csr_gen5_DPE_SNRF_PIX_CUM_VALUE_Cr, "SNRF_pix_cum_value_Cr")
































/* DPE FGT */

	CSR_REG_W_BB("FGT_Y_STRIDE_HEIGHT",		DPE_FGT_BASE_OFFSET + 0x00,g_csr_gen5_DPE_FGT_Y_STRIDE_HEIGHT,"DPE FGT Y stride height")

  	CSR_REG_W_BB("FGT_Y_STRIDE_WIDTH",		DPE_FGT_BASE_OFFSET + 0x04,g_csr_gen5_DPE_FGT_Y_STRIDE_WIDTH,"DPE FGT Y stride width")

        CSR_REG_W_BB("FGT_UV_STRIDE_HEIGHT",	DPE_FGT_BASE_OFFSET + 0x08,g_csr_gen5_DPE_FGT_UV_STRIDE_HEIGHT,"DPE FGT UV stride height")

        CSR_REG_W_BB("FGT_UV_STRIDE_WIDTH",		DPE_FGT_BASE_OFFSET + 0x0C,g_csr_gen5_DPE_FGT_UV_STRIDE_WIDTH,"DPE FGT UV stride width")

	CSR_REG_W_BB("FGT_Y_NEXT_BLOCK_PARAMS",	DPE_FGT_BASE_OFFSET + 0x10,g_csr_gen5_DPE_FGT_Y_NEXT_BLOCK_PARAMS,"Pixel Data Block Size and Offset parameters for next block in pipeline")

  	CSR_REG_W_BB("FGT_UV_NEXT_BLOCK_PARAMS",	DPE_FGT_BASE_OFFSET + 0x14,g_csr_gen5_DPE_FGT_UV_NEXT_BLOCK_PARAMS,"Pixel Data Block Size and Offset parameters for next block in pipeline")

 	CSR_REG_W_BB("FGT_CONTROL",			DPE_FGT_BASE_OFFSET + 0x20, g_csr_gen5_DPE_FGT_CONTROL,"General configuration that affects the entire FGT like bypass")

  	CSR_REG_W_BB("FGT_PRNG_Y_STRIDE_PARAMS",	DPE_FGT_BASE_OFFSET + 0x34,g_csr_gen5_DPE_FGT_PRNG_Y_STRIDE_PARAMS,"FGT Y configuration parameters for configuring PRNG to handle stride-based processing")

   CSR_REG_W_BB("FGT_PRNG_UV_STRIDE_PARAMS",	DPE_FGT_BASE_OFFSET + 0x38,g_csr_gen5_DPE_FGT_PRNG_UV_STRIDE_PARAMS,"FGT UV configuration parameters for configuring PRNG to handle stride-based processing")

  	CSR_REG_W_BB("FGT_Y_PRNG_SEED",		DPE_FGT_BASE_OFFSET + 0x28,g_csr_gen5_DPE_FGT_Y_PRNG_SEED,"FGT PRNG seed value of the current stride for Y component")

	CSR_REG_W_BB("FGT_U_PRNG_SEED",		DPE_FGT_BASE_OFFSET + 0x2C,g_csr_gen5_DPE_FGT_U_PRNG_SEED,"FGT PRNG seed value of the current stride for U component")

	CSR_REG_W_BB("FGT_V_PRNG_SEED",		DPE_FGT_BASE_OFFSET + 0x30,g_csr_gen5_DPE_FGT_V_PRNG_SEED,"FGT PRNG seed value of the current stride for V component")

	CSR_REG_W_BB("FGT_Y_NP_Parameter_Table",	DPE_FGT_BASE_OFFSET + 0x100,g_csr_gen5_DPE_FGT_Y_NP_Parameter_Table,"There are 256 registers that stores the noise-pattern parameters like the offset in NP cache and scaling factor for each possible value of 8X8 block")

	CSR_REG_W_BB("FGT_U_NP_Parameter_Table",	DPE_FGT_BASE_OFFSET + 0x500,g_csr_gen5_DPE_FGT_U_NP_Parameter_Table,"There are 256 registers that stores the noise-pattern parameters like the offset in NP cache and scaling factor for each possible value of 8X8 block")

	CSR_REG_W_BB("FGT_V_NP_Parameter_Table",	DPE_FGT_BASE_OFFSET + 0x900,g_csr_gen5_DPE_FGT_V_NP_Parameter_Table,"There are 256 registers that stores the noise-pattern parameters like the offset in NP cache and scaling factor for each possible value of 8X8 block")


/*DPE HSC Block*/

	CSR_REG_W_BB("HSC_STRIDE_HEIGHT",			DPE_HSC_BASE_OFFSET + 0x00,g_csr_gen5_DPE_HSC_STRIDE_HEIGHT, "Stride height configuration")

	CSR_REG_W_BB("HSC_STRIDE_WIDTH",			DPE_HSC_BASE_OFFSET + 0x04,g_csr_gen5_DPE_HSC_STRIDE_WIDTH, "Stride width configuration")

	CSR_REG_W_BB("HSC_STRIDE_SCALING_PARAMS1",		DPE_HSC_BASE_OFFSET + 0x08,g_csr_gen5_DPE_HSC_STRIDE_SCALING_PARAMS1, "Stride scaling params1 for the current stride")

	CSR_REG_W_BB("HSC_STRIDE_SCALING_PARAMS2",		DPE_HSC_BASE_OFFSET + 0x0C,g_csr_gen5_DPE_HSC_STRIDE_SCALING_PARAMS2, "Stride scaling params2 for the current stride")

	CSR_REG_W_BB("HSC_PREV_BLOCK_PARAMS",		DPE_HSC_BASE_OFFSET + 0x20,g_csr_gen5_DPE_HSC_PREV_BLOCK_PARAMS, "Pixel Data Block Size and Offset parameters for previous block in pipeline")

	CSR_REG_W_BB("HSC_NEXT_BLOCK_PARAMS",		DPE_HSC_BASE_OFFSET + 0x24,g_csr_gen5_DPE_HSC_NEXT_BLOCK_PARAMS, "Pixel Data Block Size and Offset parameters for next block in pipeline")

	CSR_REG_W_BB("HSC_CONTROL",				DPE_HSC_BASE_OFFSET + 0x40,g_csr_gen5_DPE_HSC_CONTROL, "Control/Configuration register for the unit")

	CSR_REG_W_BB("HSC_PHASE_CONFIG",			DPE_HSC_BASE_OFFSET + 0x44,g_csr_gen5_DPE_HSC_PHASE_CONFIG, "Total number of phases")

	CSR_REG_W_BB("HSC_REGION1_START_VALUE",		DPE_HSC_BASE_OFFSET + 0x48,g_csr_gen5_DPE_HSC_REGION1_START_VALUE, "Start parameter for region 1")

	CSR_REG_W_BB("HSC_REGION1_SCALE_INCR",		DPE_HSC_BASE_OFFSET + 0x4C,g_csr_gen5_DPE_HSC_REGION1_SCALE_INCR,"Inverse scale factor increment for region 1")

	CSR_REG_W_BB("HSC_REGION2_START_VALUE",		DPE_HSC_BASE_OFFSET + 0x50,g_csr_gen5_DPE_HSC_REGION2_START_VALUE, "Start parameter for region 2")

	CSR_REG_W_BB("HSC_REGION2_SCALE_INCR",		DPE_HSC_BASE_OFFSET + 0x54,g_csr_gen5_DPE_HSC_REGION2_SCALE_INCR, "Inverse scale factor increment for region 2")

	CSR_REG_W_BB("HSC_REGION3_START_VALUE",		DPE_HSC_BASE_OFFSET + 0x58,g_csr_gen5_DPE_HSC_REGION3_START_VALUE, "Start parameter for region 3")

	CSR_REG_W_BB("HSC_REGION3_SCALE_INCR",		DPE_HSC_BASE_OFFSET + 0x5C,g_csr_gen5_DPE_HSC_REGION3_SCALE_INCR, "Inverse scale factor increment for region 3")

	CSR_REG_W_BB("HSC_Y_POLY_COEFF_BANK0",		DPE_HSC_BASE_OFFSET + 0x0400, NULL, "Y polyphase coefficient memory Bank 0")

	CSR_REG_W_BB("HSC_Y_POLY_COEFF_BANK1",		DPE_HSC_BASE_OFFSET + 0x0800, NULL,"Y polyphase coefficient memory Bank 1")

	CSR_REG_W_BB("HSC_UV_POLY_COEFF_BANK0",		DPE_HSC_BASE_OFFSET + 0x0C00, NULL,"UV polyphase coefficient memory Bank 0")

	CSR_REG_W_BB("HSC_UV_POLY_COEFF_BANK1",		DPE_HSC_BASE_OFFSET + 0x0E00, NULL,"UV polyphase coefficient memory Bank 1")


/*DPE VSC Block*/

	CSR_REG_W_BB("VSC_STRIDE_HEIGHT",			DPE_VSC_BASE_OFFSET + 0x00,g_csr_gen5_DPE_VSC_STRIDE_HEIGHT, "Stride height configuration")

	CSR_REG_W_BB("VSC_STRIDE_WIDTH",			DPE_VSC_BASE_OFFSET + 0x04,g_csr_gen5_DPE_VSC_STRIDE_WIDTH, "Stride width configuration")

	CSR_REG_W_BB("VSC_PREV_BLOCK_PARAMS",		DPE_VSC_BASE_OFFSET + 0x20,g_csr_gen5_DPE_VSC_PREV_BLOCK_PARAMS, "Pixel Data Block Size and Offset parameters for previous block in pipeline")

	CSR_REG_W_BB("VSC_NEXT_BLOCK_PARAMS",		DPE_VSC_BASE_OFFSET + 0x24,g_csr_gen5_DPE_VSC_NEXT_BLOCK_PARAMS, "Pixel Data Block Size and Offset parameters for next block in pipeline")

	CSR_REG_W_BB("VSC_IN_FIFO_PARAMS1",			DPE_VSC_BASE_OFFSET + 0x28,g_csr_gen5_DPE_VSC_IN_FIFO_PARAMS1, "Shared Memory Input FIFO parameters")

	CSR_REG_W_BB("VSC_IN_FIFO_PARAMS2",			DPE_VSC_BASE_OFFSET + 0x2C,g_csr_gen5_DPE_VSC_IN_FIFO_PARAMS2, "Shared Memory Input FIFO parameters")

	CSR_REG_W_BB("VSC_OUT_FIFO_PARAMS1",		DPE_VSC_BASE_OFFSET + 0x30,g_csr_gen5_DPE_VSC_OUT_FIFO_PARAMS1, "Shared Memory Output FIFO parameters")

	CSR_REG_W_BB("VSC_OUT_FIFO_PARAMS2",		DPE_VSC_BASE_OFFSET + 0x34,g_csr_gen5_DPE_VSC_OUT_FIFO_PARAMS2, "Shared Memory Output FIFO parameters")

	CSR_REG_W_BB("VSC_CONTROL",				DPE_VSC_BASE_OFFSET + 0x40,g_csr_gen5_DPE_VSC_CONTROL, "Control/Configuration register for the unit")

	CSR_REG_W_BB("VSC_SCALE_FACTOR",			DPE_VSC_BASE_OFFSET + 0x44,g_csr_gen5_DPE_VSC_SCALE_FACTOR, "Inverse scale factor value")

	CSR_REG_W_BB("VSC_PHASE_CONFIG",			DPE_VSC_BASE_OFFSET + 0x48,g_csr_gen5_DPE_VSC_PHASE_CONFIG, "Phase configuration parameters including number of phases and initial phase")

	CSR_REG_W_BB("VSC_Y_POLY_COEFF_BANK0",		DPE_VSC_BASE_OFFSET + 0x0400, NULL, "Y polyphase coefficient memory Bank 0")

	CSR_REG_W_BB("VSC_Y_POLY_COEFF_BANK1",		DPE_VSC_BASE_OFFSET + 0x0800, NULL,"Y polyphase coefficient memory Bank 1")

	CSR_REG_W_BB("VSC_UV_POLY_COEFF_BANK0",		DPE_VSC_BASE_OFFSET + 0x0C00, NULL,"UV polyphase coefficient memory Bank 0")

	CSR_REG_W_BB("VSC_UV_POLY_COEFF_BANK1",		DPE_VSC_BASE_OFFSET + 0x0E00, NULL, "UV polyphase coefficient memory Bank 1")


/*DPE DMA Write transfer agent */

	CSR_REG_W_BB("DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_HEIGHT",		DPE_DWTA_NP1_YUV_BASE_OFFSET + 0x00, g_csr_gen5_DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_HEIGHT, "This register is used to set up the stride height and number of strides per frame")

 	CSR_REG_W_BB("DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_WIDTH",		DPE_DWTA_NP1_YUV_BASE_OFFSET + 0x04, g_csr_gen5_DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_WIDTH, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DWTA_NP1_YUV_DMA_CONTROL_REGISTER",		DPE_DWTA_NP1_YUV_BASE_OFFSET + 0x08, g_csr_gen5_DPE_DWTA_NP1_YUV_DMA_CONTROL_REGISTER, "This register is used to enable/disable DWTA")


	CSR_REG_W_BB("DPE_DWTA_N_MH_DMA_WRITE_STRIDE_HEIGHT",		DPE_DWTA_N_MH_BASE_OFFSET + 0x00, g_csr_gen5_DPE_DWTA_N_MH_DMA_WRITE_STRIDE_HEIGHT, "This register is used to set up the stride height and number of strides per frame")

 	CSR_REG_W_BB("DPE_DWTA_N_MH_DMA_WRITE_STRIDE_WIDTH",		DPE_DWTA_N_MH_BASE_OFFSET + 0x04, g_csr_gen5_DPE_DWTA_N_MH_DMA_WRITE_STRIDE_WIDTH, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DWTA_N_MH_DMA_CONTROL_REGISTER",			DPE_DWTA_N_MH_BASE_OFFSET + 0x08, g_csr_gen5_DPE_DWTA_N_MH_DMA_CONTROL_REGISTER, "This register is used to enable/disable DWTA")


	CSR_REG_W_BB("DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_HEIGHT",		DPE_DWTA_N_YUV_BASE_OFFSET + 0x00, g_csr_gen5_DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_HEIGHT, "This register is used to set up the stride height and number of strides per frame")

 	CSR_REG_W_BB("DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_WIDTH",		DPE_DWTA_N_YUV_BASE_OFFSET + 0x04, g_csr_gen5_DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_WIDTH, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DWTA_N_YUV_DMA_CONTROL_REGISTER",			DPE_DWTA_N_YUV_BASE_OFFSET + 0x08, g_csr_gen5_DPE_DWTA_N_YUV_DMA_CONTROL_REGISTER, "This register is used to enable/disable DWTA")

/*DPE DMA Read transfer agent */

	CSR_REG_W_BB("DPE_DRTA_NP1_Y_DMA_READ_STRIDE_HEIGHT_REGISTER",		DPE_DRTA_NP1_Y_BASE_OFFSET + 0x00, g_csr_gen5_DPE_DRTA_NP1_Y_DMA_READ_STRIDE_HEIGHT_REGISTER, "This register is used to set up the stride height and number of strides per frame. ")

	CSR_REG_W_BB("DPE_DRTA_NP1_Y_DMA_READ_STRIDE_WIDTH_REGISTER",		DPE_DRTA_NP1_Y_BASE_OFFSET + 0x04, g_csr_gen5_DPE_DRTA_NP1_Y_DMA_READ_STRIDE_WIDTH_REGISTER, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DRTA_NP1_Y_DMA_CONTROL_REGISTER",				DPE_DRTA_NP1_Y_BASE_OFFSET + 0x0c, g_csr_gen5_DPE_DRTA_NP1_Y_DMA_CONTROL_REGISTER, "This register is used to enable/disable DRTA")

	CSR_REG_W_BB("DPE_DRTA_NP1_Y_DMA_NEXT_BLOCK_PARAMS",			DPE_DRTA_NP1_Y_BASE_OFFSET + 0x08, g_csr_gen5_DPE_DRTA_NP1_Y_DMA_NEXT_BLOCK_PARAMS, "used to setup dma read data param")


	CSR_REG_W_BB("DPE_DRTA_NP1_UV_DMA_READ_STRIDE_HEIGHT_REGISTER",		DPE_DRTA_NP1_UV_BASE_OFFSET + 0x00, g_csr_gen5_DPE_DRTA_NP1_UV_DMA_READ_STRIDE_HEIGHT_REGISTER, "This register is used to set up the stride height and number of strides per frame. ")

	CSR_REG_W_BB("DPE_DRTA_NP1_UV_DMA_READ_STRIDE_WIDTH_REGISTER",		DPE_DRTA_NP1_UV_BASE_OFFSET + 0x04, g_csr_gen5_DPE_DRTA_NP1_UV_DMA_READ_STRIDE_WIDTH_REGISTER, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DRTA_NP1_UV_DMA_CONTROL_REGISTER",			DPE_DRTA_NP1_UV_BASE_OFFSET + 0x0c, g_csr_gen5_DPE_DRTA_NP1_UV_DMA_CONTROL_REGISTER, "This register is used to enable/disable DRTA")

	CSR_REG_W_BB("DPE_DRTA_NP1_UV_DMA_NEXT_BLOCK_PARAMS",			DPE_DRTA_NP1_UV_BASE_OFFSET + 0x08,g_csr_gen5_DPE_DRTA_NP1_UV_DMA_NEXT_BLOCK_PARAMS, "used to setup dma read data param")


	CSR_REG_W_BB("DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER",		DPE_DRTA_NM1_YUV_BASE_OFFSET + 0x00, g_csr_gen5_DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER, "This register is used to set up the stride height and number of strides per frame. ")

	CSR_REG_W_BB("DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_WIDTH_REGISTER",		DPE_DRTA_NM1_YUV_BASE_OFFSET + 0x04, g_csr_gen5_DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_WIDTH_REGISTER, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DRTA_NM1_YUV_DMA_CONTROL_REGISTER",			DPE_DRTA_NM1_YUV_BASE_OFFSET + 0x0c, g_csr_gen5_DPE_DRTA_NM1_YUV_DMA_CONTROL_REGISTER, "This register is used to enable/disable DRTA")

	CSR_REG_W_BB("DPE_DRTA_NM1_YUV_DMA_NEXT_BLOCK_PARAMS",			DPE_DRTA_NM1_YUV_BASE_OFFSET + 0x08,g_csr_gen5_DPE_DRTA_NM1_YUV_DMA_NEXT_BLOCK_PARAMS, "used to setup dma read data param")



	CSR_REG_W_BB("DPE_DRTA_N_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER",		DPE_DRTA_N_YUV_BASE_OFFSET + 0x00, g_csr_gen5_DPE_DRTA_N_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER, "This register is used to set up the stride height and number of strides per frame. ")

	CSR_REG_W_BB("DPE_DRTA_N_YUV_DMA_READ_STRIDE_WIDTH_REGISTER",		DPE_DRTA_N_YUV_BASE_OFFSET + 0x04, g_csr_gen5_DPE_DRTA_N_YUV_DMA_READ_STRIDE_WIDTH_REGISTER, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DRTA_N_YUV_DMA_CONTROL_REGISTER",				DPE_DRTA_N_YUV_BASE_OFFSET + 0x0c, g_csr_gen5_DPE_DRTA_N_YUV_DMA_CONTROL_REGISTER, "This register is used to enable/disable DRTA")

	CSR_REG_W_BB("DPE_DRTA_N_YUV_DMA_NEXT_BLOCK_PARAMS",			DPE_DRTA_N_YUV_BASE_OFFSET + 0x08,g_csr_gen5_DPE_DRTA_N_YUV_DMA_NEXT_BLOCK_PARAMS, "used to setup dma read data param")



	CSR_REG_W_BB("DPE_DRTA_NM1_MH_DMA_READ_STRIDE_HEIGHT_REGISTER",		DPE_DRTA_NM1_MH_BASE_OFFSET + 0x00, g_csr_gen5_DPE_DRTA_NM1_MH_DMA_READ_STRIDE_HEIGHT_REGISTER, "This register is used to set up the stride height and number of strides per frame. ")

	CSR_REG_W_BB("DPE_DRTA_NM1_MH_DMA_READ_STRIDE_WIDTH_REGISTER",		DPE_DRTA_NM1_MH_BASE_OFFSET + 0x04, g_csr_gen5_DPE_DRTA_NM1_MH_DMA_READ_STRIDE_WIDTH_REGISTER, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DRTA_NM1_MH_DMA_CONTROL_REGISTER",			DPE_DRTA_NM1_MH_BASE_OFFSET + 0x0c, g_csr_gen5_DPE_DRTA_NM1_MH_DMA_CONTROL_REGISTER, "This register is used to enable/disable DRTA")

	CSR_REG_W_BB("DPE_DRTA_NM1_MH_DMA_NEXT_BLOCK_PARAMS",			DPE_DRTA_NM1_MH_BASE_OFFSET + 0x08,g_csr_gen5_DPE_DRTA_NM1_MH_DMA_NEXT_BLOCK_PARAMS, "used to setup dma read data param")



/* DPE DMA */

 	CSR_REG_W_BB("DMA_Mode_Register",						DPE_DMA_BASE_OFFSET + 0x74, g_csr_gen5_DPE_DMA_Mode_Register, "DMA_Mode_Register")

	CSR_REG_W_BB("DMA_SAP_MEM_Parameters_Register",				DPE_DMA_BASE_OFFSET + 0x78, g_csr_gen5_DPE_DMA_SAP_MEM_Parameters_Register, "SAP_MEM_Parameters_Register")

	CSR_REG_W_BB("DMA_NP1_Y_Picture_Parameter_Register",			DPE_DMA_BASE_OFFSET + 0x00, g_csr_gen5_DPE_DMA_NP1_Y_Picture_Parameter_Register, "NP1_Y_Picture_Parameter_Register")

	CSR_REG_W_BB("DMA_NP1_UV_Picture_Parameter_Register",			DPE_DMA_BASE_OFFSET + 0x0c, g_csr_gen5_DPE_DMA_NP1_UV_Picture_Parameter_Register, "DMA_NP1_UV_Picture_Parameter_Register")

	CSR_REG_W_BB("DMA_NP1_Y_Top_Field_Starting_Address_Register",		DPE_DMA_BASE_OFFSET + 0x04, g_csr_gen5_DPE_DMA_NP1_Y_Top_Field_Starting_Address_Register, "DMA_NP1_Y_Top_Field_Starting_Address_Register")

	CSR_REG_W_BB("DMA_NP1_UV_Top_Field_Starting_Address_Register",		DPE_DMA_BASE_OFFSET + 0x10, g_csr_gen5_DPE_DMA_NP1_UV_Top_Field_Starting_Address_Register, "DMA_NP1_UV_Top_Field_Starting_Address_Register")

	CSR_REG_W_BB("DMA_NP1_Y_Bottom_Field_Starting_Address_Register",		DPE_DMA_BASE_OFFSET + 0x08, g_csr_gen5_DPE_DMA_NP1_Y_Bottom_Field_Starting_Address_Register, "DMA_NP1_Y_Bottom_Field_Starting_Address_Register")

	CSR_REG_W_BB("DMA_NP1_UV_Bottom_Field_Starting_Address_Register",		DPE_DMA_BASE_OFFSET + 0x14, g_csr_gen5_DPE_DMA_NP1_UV_Bottom_Field_Starting_Address_Register, "DMA_NP1_UV_Bottom_Field_Starting_Address_Register")

	CSR_REG_W_BB("DMA_NM1_YUV_R_Param_Register",				DPE_DMA_BASE_OFFSET + 0x18, g_csr_gen5_DPE_DMA_NM1_YUV_R_Param_Register, "DMA_NM1_YUV_R_Param_Register")

	CSR_REG_W_BB("DMA_NM1_MH_R_Param_Register",					DPE_DMA_BASE_OFFSET + 0x20, g_csr_gen5_DPE_DMA_NM1_MH_R_Param_Register, "DMA_NM1_MH_R_Param_Register")

	CSR_REG_W_BB("DMA_N_YUV_R_Param_Register",					DPE_DMA_BASE_OFFSET + 0x28, g_csr_gen5_DPE_DMA_N_YUV_R_Param_Register, "DMA_N_YUV_R_Param_Register")

	CSR_REG_W_BB("DMA_NP1_YUV_W_Param_Register",				DPE_DMA_BASE_OFFSET + 0x30, g_csr_gen5_DPE_DMA_NP1_YUV_W_Param_Register, "DMA_NP1_YUV_W_Param_Register")

	CSR_REG_W_BB("DMA_N_Y_W_Param_Register",					DPE_DMA_BASE_OFFSET + 0x38, g_csr_gen5_DPE_DMA_N_Y_W_Param_Register, "DMA_N_Y_W_Param_Register")

	CSR_REG_W_BB("DMA_N_UV_W_Param_Register",					DPE_DMA_BASE_OFFSET + 0x40, g_csr_gen5_DPE_DMA_N_UV_W_Param_Register, "DMA_N_UV_W_Param_Register")

	CSR_REG_W_BB("DMA_N_MH_W_Param_Register",					DPE_DMA_BASE_OFFSET + 0x48, g_csr_gen5_DPE_DMA_N_MH_W_Param_Register, "DMA_N_MH_W_Param_Register")

	CSR_REG_W_BB("DMA_NM1_YUV_R_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x1c, g_csr_gen5_DPE_DMA_NM1_YUV_R_Start_Addr_Register, "DMA_NM1_YUV_R_Start_Addr_Register")

	CSR_REG_W_BB("DMA_NM1_MH_R_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x24, g_csr_gen5_DPE_DMA_NM1_MH_R_Start_Addr_Register, "DMA_NM1_MH_R_Start_Addr_Register")

	CSR_REG_W_BB("DMA_N_YUV_R_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x2c, g_csr_gen5_DPE_DMA_N_YUV_R_Start_Addr_Register, "DMA_N_YUV_R_Start_Addr_Register")

	CSR_REG_W_BB("DMA_NP1_YUV_W_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x34, g_csr_gen5_DPE_DMA_NP1_YUV_W_Start_Addr_Register, "DMA_NP1_YUV_W_Start_Addr_Register")

	CSR_REG_W_BB("DMA_N_Y_W_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x3c, g_csr_gen5_DPE_DMA_N_Y_W_Start_Addr_Register, "DMA_N_Y_W_Start_Addr_Register")

	CSR_REG_W_BB("DMA_N_UV_W_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x44, g_csr_gen5_DPE_DMA_N_UV_W_Start_Addr_Register, "DMA_N_UV_W_Start_Addr_Register")

	CSR_REG_W_BB("DMA_N_MH_W_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x4c, g_csr_gen5_DPE_DMA_N_MH_W_Start_Addr_Register, "DMA_N_MH_W_Start_Addr_Register")

	CSR_REG_W_BB("DMA_NP1_Y_R_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x50, g_csr_gen5_DPE_DMA_NP1_Y_R_Stride_Param_Register, "DMA_NP1_Y_R_Stride_Param_Register")

	CSR_REG_W_BB("DMA_NP1_UV_R_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x54, g_csr_gen5_DPE_DMA_NP1_UV_R_Stride_Param_Register, "DMA_NP1_UV_R_Stride_Param_Register")

	CSR_REG_W_BB("DMA_NM1_YUV_R_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x58, g_csr_gen5_DPE_DMA_NM1_YUV_R_Stride_Param_Register, "DMA_NM1_YUV_R_Stride_Param_Register")

	CSR_REG_W_BB("DMA_NM1_MH_R_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x5c, g_csr_gen5_DPE_DMA_NM1_MH_R_Stride_Param_Register, "DMA_NM1_MH_R_Stride_Param_Register")

	CSR_REG_W_BB("DMA_N_YUV_R_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x60, g_csr_gen5_DPE_DMA_N_YUV_R_Stride_Param_Register, "DMA_N_YUV_R_Stride_Param_Register")

	CSR_REG_W_BB("DMA_NP1_YUV_W_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x64, g_csr_gen5_DPE_DMA_NP1_YUV_W_Stride_Param_Register, "DMA_NP1_YUV_W_Stride_Param_Register")

	CSR_REG_W_BB("DMA_N_Y_W_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x68, g_csr_gen5_DPE_DMA_N_Y_W_Stride_Param_Register, "DMA_N_Y_W_Stride_Param_Register")

	CSR_REG_W_BB("DMA_N_UV_W_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x6c, g_csr_gen5_DPE_DMA_N_UV_W_Stride_Param_Register, "DMA_N_UV_W_Stride_Param_Register")

	CSR_REG_W_BB("DMA_N_MH_W_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x70, g_csr_gen5_DPE_DMA_N_MH_W_Stride_Param_Register, "DMA_N_MH_W_Stride_Param_Register")

//RR ----------JLCC Registers-----------------
//----------------------INCSC----------------------------------//
	CSR_REG_W_BB("INCSC_Stride_Height_Register",	DPE_INCSC_BASE_OFFSET + 0x0, g_csr_gen5_DPE_INCSC_STRIDE_HEIGHT_REGISTER, "INCSC_Stride_Height_Register")

	CSR_REG_W_BB("INCSC_Stride_Width_Register",	DPE_INCSC_BASE_OFFSET + 0x4, g_csr_gen5_DPE_INCSC_STRIDE_WIDTH_REGISTER, "INCSC_Stride_Width_Register")

	CSR_REG_W_BB("INCSC_Control_Register",	DPE_INCSC_BASE_OFFSET + 0xC, g_csr_gen5_DPE_INCSC_CONTROL_REGISTER, "INCSC_Control_Register")

	CSR_REG_W_BB("INCSC_422_to_444_Coeff0_Register", DPE_INCSC_BASE_OFFSET + 0x10,	g_csr_gen5_DPE_INCSC_422_to_444_Coeff0_REGISTER, "INCSC_422_to_444_Coeff0_Register")
	
	CSR_REG_W_BB("INCSC_422_to_444_Coeff1_Register", DPE_INCSC_BASE_OFFSET + 0x14,	g_csr_gen5_DPE_INCSC_422_to_444_Coeff1_REGISTER, "INCSC_422_to_444_Coeff1_Register")	

	CSR_REG_W_BB("INCSC_xvYcc_I_Range_Comp_Register", DPE_INCSC_BASE_OFFSET + 0x18,	g_csr_gen5_DPE_INCSC_XVYCC_I_RANGE_COMP_REGISTER, "INCSC_xvYcc_I_Range_Comp_Register")	

	CSR_REG_W_BB("INCSC_YUV_to_RGB_Coeff_Register", DPE_INCSC_BASE_OFFSET + 0x20,	g_csr_gen5_DPE_INCSC_YUV_to_RGB_Coeff_REGISTER, "INCSC_YUV_to_RGB_Coeff_Register")	

	CSR_REG_W_BB("INCSC_RGB2LMS_Coefficient01_Register", DPE_INCSC_BASE_OFFSET + 0x20,	g_csr_gen5_DPE_INCSC_RGB2LMS_C01_CSC_Coefficient01_REGISTER, "INCSC_RGB2LMS_Coefficient01_Register") 

	CSR_REG_W_BB("INCSC_RGB2LMS_Coefficient23_Register", DPE_INCSC_BASE_OFFSET + 0x24,	g_csr_gen5_DPE_INCSC_RGB2LMS_C23_CSC_Coefficient23_REGISTER, "INCSC_RGB2LMS_Coefficient23_Register")	

	CSR_REG_W_BB("INCSC_RGB2LMS_Coefficient45_Register", DPE_INCSC_BASE_OFFSET + 0x28,	g_csr_gen5_DPE_INCSC_RGB2LMS_C45_CSC_Coefficient45_REGISTER, "INCSC_RGB2LMS_Coefficient45_Register")	

	CSR_REG_W_BB("INCSC_RGB2LMS_Coefficient67_Register", DPE_INCSC_BASE_OFFSET + 0x2C, g_csr_gen5_DPE_INCSC_RGB2LMS_C67_RGB2LMS_Coefficient67_REGISTER, "INCSC_RGB2LMS_Coefficient67_Register")	

	CSR_REG_W_BB("INCSC_RGB2LMS_Coefficient8_Register", DPE_INCSC_BASE_OFFSET + 0x30, g_csr_gen5_DPE_INCSC_RGB2LMS_C8_RGB2LMS_Coefficient8_REGISTER, "INCSC_RGB2LMS_Coefficient8_Register")	

	CSR_REG_W_BB("INCSC_Y_G_Offset_Register", DPE_INCSC_BASE_OFFSET + 0x54,	g_csr_gen5_DPE_INCSC_XVYCC_CSC_YGOFF_REGISTER, "INCSC_Y_G_Offset_Register")	

	CSR_REG_W_BB("INCSC_Cb_B_Offset_Register", DPE_INCSC_BASE_OFFSET + 0x58,	g_csr_gen5_DPE_INCSC_XVYCC_CSC_CbBOFF_REGISTER, "INCSC_Cb_B_Offset_Register")	

	CSR_REG_W_BB("INCSC_Cr_R_Offset_Register", DPE_INCSC_BASE_OFFSET + 0x5C,	g_csr_gen5_DPE_INCSC_XVYCC_CSC_CrROFF_REGISTER, "INCSC_Cr_R_Offset_Register")	

	CSR_REG_W_BB("INCSC_Coefficient01_Register", DPE_INCSC_BASE_OFFSET + 0x60, g_csr_gen5_DPE_INCSC_XVYCC_CSC_Coefficient01_REGISTER, "INCSC_Coefficient01_Register")	

	CSR_REG_W_BB("INCSC_Coefficient23_Register", DPE_INCSC_BASE_OFFSET + 0x64, g_csr_gen5_DPE_INCSC_XVYCC_CSC_Coefficient23_REGISTER, "INCSC_Coefficient23_Register")	

	CSR_REG_W_BB("INCSC_Coefficient45_Register", DPE_INCSC_BASE_OFFSET + 0x68, g_csr_gen5_DPE_INCSC_XVYCC_CSC_Coefficient45_REGISTER, "INCSC_Coefficient45_Register")	

	CSR_REG_W_BB("INCSC_Coefficient67_Register", DPE_INCSC_BASE_OFFSET + 0x6C, g_csr_gen5_DPE_INCSC_XVYCC_CSC_Coefficient67_REGISTER, "INCSC_Coefficient67_Register")	

	CSR_REG_W_BB("INCSC_Coefficient8_Register", DPE_INCSC_BASE_OFFSET + 0x70, g_csr_gen5_DPE_INCSC_XVYCC_CSC_Coefficient8_REGISTER, "INCSC_Coefficient8_Register")	
	
	CSR_REG_W_BB("INCSC_Y_G_Input_Clamping_Register", DPE_INCSC_BASE_OFFSET + 0x74,	g_csr_gen5_DPE_INCSC_XVYCC_CSC_YGICLAMP_REGISTER, "INCSC_Y_G_Input_Clamping_Register")	

	CSR_REG_W_BB("INCSC_Cb_B_Input_Clamping_Register", DPE_INCSC_BASE_OFFSET + 0x78,	g_csr_gen5_DPE_INCSC_XVYCC_CSC_CbBICLAMP_REGISTER, "INCSC_Cb_B_Input_Clamping_Register")	

	CSR_REG_W_BB("INCSC_Cr_R_Input_Clamping_Register", DPE_INCSC_BASE_OFFSET + 0x7C,	g_csr_gen5_DPE_INCSC_XVYCC_CSC_CrRICLAMP_REGISTER, "INCSC_Cr_R_Input_Clamping_Register")	

	CSR_REG_W_BB("INCSC_Y_G_Output_Clamping_Register", DPE_INCSC_BASE_OFFSET + 0x80,	g_csr_gen5_DPE_INCSC_XVYCC_CSC_YGOCLAMP_REGISTER, "INCSC_YG_Output_Clamping_Register")	

	CSR_REG_W_BB("INCSC_Cb_B_Output_Clamping_Register", DPE_INCSC_BASE_OFFSET + 0x84,	g_csr_gen5_DPE_INCSC_XVYCC_CSC_CbBOCLAMP_REGISTER, "INCSC_Cb_B_Output_Clamping_Register")	

	CSR_REG_W_BB("INCSC_Cr_R_Output_Clamping_Register", DPE_INCSC_BASE_OFFSET + 0x88,	g_csr_gen5_DPE_INCSC_XVYCC_CSC_CrROCLAMP_REGISTER, "INCSC_Cr_R_Output_Clamping_Register")	

	CSR_REG_W_BB("INCSC_RGB_LUT_Register", DPE_INCSC_BASE_OFFSET + 0x90,	g_csr_gen5_DPE_INCSC_RGB_LUT_REGISTER, "INCSC_RGB_LUT_Register")	

	CSR_REG_W_BB("INCSC_LMS_LUT_Register", DPE_INCSC_BASE_OFFSET + 0x490,	g_csr_gen5_DPE_INCSC_LMS_LUT_REGISTER, "INCSC_LMS_LUT_Register")	

	CSR_REG_W_BB("INCSC_LMTA_TL_0_Register", DPE_INCSC_BASE_OFFSET + 0x900,	g_csr_gen5_DPE_INCSC_LMTA_TL_0_5_REGISTER, "INCSC_LMTA_TL_0_Register")	
	CSR_REG_W_BB("INCSC_LMTA_TL_1_Register", DPE_INCSC_BASE_OFFSET + 0x904,	g_csr_gen5_DPE_INCSC_LMTA_TL_0_5_REGISTER, "INCSC_LMTA_TL_1_Register")	
	CSR_REG_W_BB("INCSC_LMTA_TL_2_Register", DPE_INCSC_BASE_OFFSET + 0x908,	g_csr_gen5_DPE_INCSC_LMTA_TL_0_5_REGISTER, "INCSC_LMTA_TL_2_Register")	
	CSR_REG_W_BB("INCSC_LMTA_TL_3_Register", DPE_INCSC_BASE_OFFSET + 0x90C,	g_csr_gen5_DPE_INCSC_LMTA_TL_0_5_REGISTER, "INCSC_LMTA_TL_3_Register")	
	CSR_REG_W_BB("INCSC_LMTA_TL_4_Register", DPE_INCSC_BASE_OFFSET + 0x910,	g_csr_gen5_DPE_INCSC_LMTA_TL_0_5_REGISTER, "INCSC_LMTA_TL_4_Register")	
	CSR_REG_W_BB("INCSC_LMTA_TL_5_Register", DPE_INCSC_BASE_OFFSET + 0x914,	g_csr_gen5_DPE_INCSC_LMTA_TL_0_5_REGISTER, "INCSC_LMTA_TL_5_Register")	
	
	CSR_REG_W_BB("INCSC_LMTA_Slope_0_Register", DPE_INCSC_BASE_OFFSET + 0x918,	g_csr_gen5_DPE_INCSC_LMTA_SLOPE_0_4_REGISTER, "INCSC_LMTA_Slope_0_Register")	
	CSR_REG_W_BB("INCSC_LMTA_Slope_1_Register", DPE_INCSC_BASE_OFFSET + 0x91C,	g_csr_gen5_DPE_INCSC_LMTA_SLOPE_0_4_REGISTER, "INCSC_LMTA_Slope_1_Register")	
	CSR_REG_W_BB("INCSC_LMTA_Slope_2_Register", DPE_INCSC_BASE_OFFSET + 0x920,	g_csr_gen5_DPE_INCSC_LMTA_SLOPE_0_4_REGISTER, "INCSC_LMTA_Slope_2_Register")	
	CSR_REG_W_BB("INCSC_LMTA_Slope_3_Register", DPE_INCSC_BASE_OFFSET + 0x924,	g_csr_gen5_DPE_INCSC_LMTA_SLOPE_0_4_REGISTER, "INCSC_LMTA_Slope_3_Register")	
	CSR_REG_W_BB("INCSC_LMTA_Slope_4_Register", DPE_INCSC_BASE_OFFSET + 0x928,	g_csr_gen5_DPE_INCSC_LMTA_SLOPE_0_4_REGISTER, "INCSC_LMTA_Slope_4_Register")	
	
	CSR_REG_W_BB("INCSC_LMTB_TL_0_Register", DPE_INCSC_BASE_OFFSET + 0x930,	g_csr_gen5_DPE_INCSC_LMTB_TL_0_5_REGISTER, "INCSC_LMTB_TL_0_Register")	
	CSR_REG_W_BB("INCSC_LMTB_TL_1_Register", DPE_INCSC_BASE_OFFSET + 0x934,	g_csr_gen5_DPE_INCSC_LMTB_TL_0_5_REGISTER, "INCSC_LMTB_TL_1_Register")	
	CSR_REG_W_BB("INCSC_LMTB_TL_2_Register", DPE_INCSC_BASE_OFFSET + 0x938,	g_csr_gen5_DPE_INCSC_LMTB_TL_0_5_REGISTER, "INCSC_LMTB_TL_2_Register")	
	CSR_REG_W_BB("INCSC_LMTB_TL_3_Register", DPE_INCSC_BASE_OFFSET + 0x93C,	g_csr_gen5_DPE_INCSC_LMTB_TL_0_5_REGISTER, "INCSC_LMTB_TL_3_Register")	
	CSR_REG_W_BB("INCSC_LMTB_TL_4_Register", DPE_INCSC_BASE_OFFSET + 0x940,	g_csr_gen5_DPE_INCSC_LMTB_TL_0_5_REGISTER, "INCSC_LMTB_TL_4_Register")	
	CSR_REG_W_BB("INCSC_LMTB_TL_5_Register", DPE_INCSC_BASE_OFFSET + 0x944,	g_csr_gen5_DPE_INCSC_LMTB_TL_0_5_REGISTER, "INCSC_LMTB_TL_5_Register")	
	
	CSR_REG_W_BB("INCSC_LMTB_Slope_0_Register", DPE_INCSC_BASE_OFFSET + 0x948,	g_csr_gen5_DPE_INCSC_LMTB_SLOPE_0_4_REGISTER, "INCSC_LMTB_Slope_0_Register")	
	CSR_REG_W_BB("INCSC_LMTB_Slope_1_Register", DPE_INCSC_BASE_OFFSET + 0x94C,	g_csr_gen5_DPE_INCSC_LMTB_SLOPE_0_4_REGISTER, "INCSC_LMTB_Slope_1_Register")	
	CSR_REG_W_BB("INCSC_LMTB_Slope_2_Register", DPE_INCSC_BASE_OFFSET + 0x950,	g_csr_gen5_DPE_INCSC_LMTB_SLOPE_0_4_REGISTER, "INCSC_LMTB_Slope_2_Register")	
	CSR_REG_W_BB("INCSC_LMTB_Slope_3_Register", DPE_INCSC_BASE_OFFSET + 0x954,	g_csr_gen5_DPE_INCSC_LMTB_SLOPE_0_4_REGISTER, "INCSC_LMTB_Slope_3_Register")	
	CSR_REG_W_BB("INCSC_LMTB_Slope_4_Register", DPE_INCSC_BASE_OFFSET + 0x958,	g_csr_gen5_DPE_INCSC_LMTB_SLOPE_0_4_REGISTER, "INCSC_LMTB_Slope_4_Register")	
	
	CSR_REG_W_BB("INCSC_xyz_coeff_a1_Register", DPE_INCSC_BASE_OFFSET + 0x960,	g_csr_gen5_DPE_INCSC_xyz_coeff_a1_a3_REGISTER, "INCSC_xyz_coeff_a1_Register")	

	CSR_REG_W_BB("INCSC_xyz_coeff_a2_Register", DPE_INCSC_BASE_OFFSET + 0x964,	g_csr_gen5_DPE_INCSC_xyz_coeff_a1_a3_REGISTER, "INCSC_xyz_coeff_a2_Register")	

	CSR_REG_W_BB("INCSC_xyz_coeff_a3_Register", DPE_INCSC_BASE_OFFSET + 0x968,	g_csr_gen5_DPE_INCSC_xyz_coeff_a1_a3_REGISTER, "INCSC_xyz_coeff_a3_Register")	
	
	CSR_REG_W_BB("INCSC_xyz_coeff_b1_Register", DPE_INCSC_BASE_OFFSET + 0x96c,	g_csr_gen5_DPE_INCSC_xyz_coeff_b1_b3_REGISTER, "INCSC_xyz_coeff_b1_Register")	
	CSR_REG_W_BB("INCSC_xyz_coeff_b2_Register", DPE_INCSC_BASE_OFFSET + 0x970,	g_csr_gen5_DPE_INCSC_xyz_coeff_b1_b3_REGISTER, "INCSC_xyz_coeff_b2_Register")	
	CSR_REG_W_BB("INCSC_xyz_coeff_b3_Register", DPE_INCSC_BASE_OFFSET + 0x974,	g_csr_gen5_DPE_INCSC_xyz_coeff_b1_b3_REGISTER, "INCSC_xyz_coeff_b3_Register")	
	
	CSR_REG_W_BB("INCSC_xyz_coeff_c1_Register", DPE_INCSC_BASE_OFFSET + 0x978,	g_csr_gen5_DPE_INCSC_xyz_coeff_c1_c3_REGISTER, "INCSC_xyz_coeff_c1_Register")	
	CSR_REG_W_BB("INCSC_xyz_coeff_c2_Register", DPE_INCSC_BASE_OFFSET + 0x97C,	g_csr_gen5_DPE_INCSC_xyz_coeff_c1_c3_REGISTER, "INCSC_xyz_coeff_c2_Register")	
	CSR_REG_W_BB("INCSC_xyz_coeff_c3_Register", DPE_INCSC_BASE_OFFSET + 0x980,	g_csr_gen5_DPE_INCSC_xyz_coeff_c1_c3_REGISTER, "INCSC_xyz_coeff_c3_Register")	

	CSR_REG_W_BB("INCSC_xyz_coeff_d1_Register", DPE_INCSC_BASE_OFFSET + 0x984,	g_csr_gen5_DPE_INCSC_xyz_offset_d1_d3_REGISTER, "INCSC_xyz_coeff_d1_Register")	
	CSR_REG_W_BB("INCSC_xyz_coeff_d2_Register", DPE_INCSC_BASE_OFFSET + 0x988,	g_csr_gen5_DPE_INCSC_xyz_offset_d1_d3_REGISTER, "INCSC_xyz_coeff_d2_Register")	
	CSR_REG_W_BB("INCSC_xyz_coeff_d3_Register", DPE_INCSC_BASE_OFFSET + 0x98C,	g_csr_gen5_DPE_INCSC_xyz_offset_d1_d3_REGISTER, "INCSC_xyz_coeff_d3_Register")	

	CSR_REG_W_BB("INCSC_Select_Register", DPE_INCSC_BASE_OFFSET + 0x990,	g_csr_gen5_DPE_INCSC_Select_REGISTER, "INCSC_Select_Register")	
	
	CSR_REG_W_BB("INCSC_blend_k_Register", DPE_INCSC_BASE_OFFSET + 0x994,	g_csr_gen5_DPE_INCSC_blend_k_REGISTER, "INCSC_blend_k_Register")	

	CSR_REG_W_BB("INCSC_Y_Gain_Register", DPE_INCSC_BASE_OFFSET + 0x998,	g_csr_gen5_DPE_INCSC_Y_Gain_REGISTER, "INCSC_Y_Gain_Register")	

	CSR_REG_W_BB("INCSC_Y_Offset_Register", DPE_INCSC_BASE_OFFSET + 0x99c, g_csr_gen5_DPE_INCSC_Y_Offset_REGISTER, "INCSC_Y_Offset_Register")	

	CSR_REG_W_BB("INCSC_Y_Limit_Register", DPE_INCSC_BASE_OFFSET + 0x9a0,	g_csr_gen5_DPE_INCSC_Y_LIMIT_REGISTER, "INCSC_Y_Limit_Register")	

	CSR_REG_W_BB("INCSC_DC_LUT_Eng1_Register", DPE_INCSC_BASE_OFFSET + 0x9f8, g_csr_gen5_DPE_INCSC_ENGINEERING_REGISTER_1, "INCSC_DC_LUT_Eng1_Register")

	CSR_REG_W_BB("INCSC_DC_LUT_Eng2_Register", DPE_INCSC_BASE_OFFSET + 0x9fC, g_csr_gen5_DPE_INCSC_ENGINEERING_REGISTER_2, "INCSC_DC_LUT_Eng2_Register")

	CSR_REG_W_BB("INCSC_DC_LUT_Register", DPE_INCSC_BASE_OFFSET + 0xa00,	g_csr_gen5_DPE_INCSC_DC_LUT_REGISTER, "INCSC_DC_LUT_Register")


//-------------------------JLCC----------------------------------------//

	CSR_REG_W_BB("JLCC_Stride_Height_Register",	DPE_JLCC_BASE_OFFSET + 0x0, g_csr_gen5_DPE_JLCC_STRIDE_HEIGHT_REGISTER, "JLCC_Stride_Height_Register")

	CSR_REG_W_BB("JLCC_Stride_Width_Register",	DPE_JLCC_BASE_OFFSET + 0x4, g_csr_gen5_DPE_JLCC_STRIDE_WIDTH_REGISTER, "JLCC_Stride_Width_Register")

	CSR_REG_W_BB("JLCC_CDF_Stride_Width_Register",	DPE_JLCC_BASE_OFFSET + 0x8, g_csr_gen5_DPE_JLCC_CDF_STRIDE_WIDTH_REGISTER, "JLCC_CDF_Stride_Width_Register")

	CSR_REG_W_BB("JLCC_Control_Register",	DPE_JLCC_BASE_OFFSET + 0x10, g_csr_gen5_DPE_JLCC_CONTROL_REGISTER, "JLCC_Control_Register")

	CSR_REG_W_BB("JLCC_I_RANGE_EXP_Register",	DPE_JLCC_BASE_OFFSET + 0x18, g_csr_gen5_DPE_JLCC_I_RANGE_EXP_REGISTER, "JLCC_I_RANGE_EXP_Register")

	CSR_REG_W_BB("JLCC_I_RANGE_MAXMIN_Register",  DPE_JLCC_BASE_OFFSET + 0x1c ,g_csr_gen5_DPE_JLCC_I_RANGE_MAXMIN_Offset_REGISTER, "JLCC_I_RANGE_MAXMIN_Register")
	
	CSR_REG_W_BB("JLCC_CSC_YG_OFFSET_Register",  DPE_JLCC_BASE_OFFSET + 0x20 ,g_csr_gen5_DPE_JLCC_RGB2YUV_YGOFF_CSC_YG_Offset_REGISTER, "JLCC_CSC_YG_OFFSET_Register")
	
	CSR_REG_W_BB("JLCC_CSC_CbB_OFFSET_Register",  DPE_JLCC_BASE_OFFSET + 0x24 ,g_csr_gen5_DPE_JLCC_RGB2YUV_CBOFF_CSC_CbB_Offset_REGISTER, "JLCC_CSC_CbB_OFFSET_Register")

	CSR_REG_W_BB("JLCC_CSC_CrR_OFFSET_Register", DPE_JLCC_BASE_OFFSET + 0x28 ,g_csr_gen5_DPE_JLCC_RGB2YUV_CROFF_CSC_CrR_Offset_REGISTER, "JLCC_CSC_CrR_OFFSET_Register")

	CSR_REG_W_BB("JLCC_CSC_Coefficient_01_Register", DPE_JLCC_BASE_OFFSET + 0x2c ,g_csr_gen5_DPE_JLCC_RGB2YUV_C01_CSC_Coefficient01_REGISTER, "JLCC_CSC_Coefficient_01_Register")

	CSR_REG_W_BB("JLCC_CSC_Coefficient_23_Register", DPE_JLCC_BASE_OFFSET + 0x30, g_csr_gen5_DPE_JLCC_RGB2YUV_C23_CSC_Coefficient23_REGISTER, "JLCC_CSC_Coefficient_23_Register")

	CSR_REG_W_BB("JLCC_CSC_Coefficient_45_Register", DPE_JLCC_BASE_OFFSET + 0x34, g_csr_gen5_DPE_JLCC_RGB2YUV_C45_CSC_Coefficient45_REGISTER, "JLCC_CSC_Coefficient_45_Register")

	CSR_REG_W_BB("JLCC_CSC_Coefficient_67_Register", DPE_JLCC_BASE_OFFSET +  0x38, g_csr_gen5_DPE_JLCC_RGB2YUV_C67_CSC_Coefficient67_REGISTER, "JLCC_CSC_Coefficient_67_Register")

	CSR_REG_W_BB("JLCC_CSC_Coefficient_8_Register", DPE_JLCC_BASE_OFFSET + 0x3c , g_csr_gen5_DPE_JLCC_RGB2YUV_C8_CSC_Coefficient8_REGISTER, "JLCC_CSC_Coefficient_8_Register")

	CSR_REG_W_BB("JLCC_CSC_YG_Input_Clamping_Register", DPE_JLCC_BASE_OFFSET + 0x40, g_csr_gen5_DPE_JLCC_RGB2YUV_YGICLAMP_CSC_YG_Input_CLAMPING_REGISTER, "JLCC_CSC_YG_Input_Clamping_Register")

	CSR_REG_W_BB("JLCC_CSC_CbB_Input_Clamping_Register", DPE_JLCC_BASE_OFFSET + 0x44, g_csr_gen5_DPE_JLCC_RGB2YUV_CBICLAMP_CSC_CbB_Input_CLAMPING_REGISTER, "JLCC_CSC_CbB_Input_Clamping_Register")

	CSR_REG_W_BB("JLCC_CSC_CrR_Input_Clamping_Register", DPE_JLCC_BASE_OFFSET + 0x48, g_csr_gen5_DPE_JLCC_RGB2YUV_CRICLAMP_CSC_CrR_Input_CLAMPING_REGISTER, "JLCC_CSC_CrR_Input_Clamping_Register")

	CSR_REG_W_BB("JLCC_CSC_YG_Output_Clamping_Register", DPE_JLCC_BASE_OFFSET + 0x4c, g_csr_gen5_DPE_JLCC_RGB2YUV_YGOCLAMP_CSC_YG_Output_CLAMPING_REGISTER, "JLCC_CSC_YG_Output_Clamping_Register")

	CSR_REG_W_BB("JLCC_CSC_CbB_Output_Clamping_Register", DPE_JLCC_BASE_OFFSET + 0x50, g_csr_gen5_DPE_JLCC_RGB2YUV_CBOCLAMP_CSC_CbB_Output_CLAMPING_REGISTER, "JLCC_CSC_CbB_Ouput_Clamping_Register")

	CSR_REG_W_BB("JLCC_CSC_CrR_Output_Clamping_Register", DPE_JLCC_BASE_OFFSET + 0x54, g_csr_gen5_DPE_JLCC_RGB2YUV_CROCLAMP_CSC_CrR_Output_CLAMPING_REGISTER, "JLCC_CSC_CrR_Output_Clamping_Register")

	CSR_REG_W_BB("JLCC_OUT_CSC_RGB_LUT_Register", DPE_JLCC_BASE_OFFSET + 0x90 , g_csr_gen5_DPE_JLCC_OUT_CSC_RGB_LUT_REGISTER, "JLCC_OUT_CSC_RGB_LUT_Register")

	CSR_REG_W_BB("JLCC_OUT_CSC_LMS_LUT_Register", DPE_JLCC_BASE_OFFSET + 0x490, g_csr_gen5_DPE_JLCC_OUT_CSC_LMS_LUT_REGISTER, "JLCC_OUT_CSC_LMS_LUT_Register")

	CSR_REG_W_BB("JLCC_Local_contrast_LUT_Register", DPE_JLCC_BASE_OFFSET + 0x890, g_csr_gen5_DPE_JLCC_Local_Contrast_LUT_REGISTER, "JLCC_Local_contrast_LUT_Register")

	CSR_REG_W_BB("JLCC_SIN_LUT_Register", DPE_JLCC_BASE_OFFSET + 0x914, g_csr_gen5_DPE_JLCC_SINLUT_REGISTER, "JLCC_SIN_LUT")

	CSR_REG_W_BB("JLCC_CHROMA_LUT_Register", DPE_JLCC_BASE_OFFSET + 0x998, g_csr_gen5_DPE_JLCC_CHROMA_LUT_REGISTER, "JLCC_CHROMA_LUT")

	CSR_REG_W_BB("JLCC_SQRT_LUT_Register", DPE_JLCC_BASE_OFFSET + 0xa18, g_csr_gen5_DPE_JLCC_SQRT_LUT_REGISTER, "JLCC_SQRT_LUT")
 
	CSR_REG_W_BB("JLCC_GL_GAIN", DPE_JLCC_BASE_OFFSET + 0xa98, g_csr_gen5_DPE_JLCC_GL_GAIN_REGISTER, "JLCC_GL_GAIN")

	CSR_REG_W_BB("JLCC_SAT_GAIN", DPE_JLCC_BASE_OFFSET + 0xa9c, g_csr_gen5_DPE_JLCC_SAT_GAIN_REGISTER, "JLCC_SAT_GAIN")

	CSR_REG_W_BB("JLCC_CDF_Counters", DPE_JLCC_BASE_OFFSET + 0xaa0, g_csr_gen5_DPE_JLCC_CDF_Counters_REGISTER, "JLCC_CDF_Counters")

	CSR_REG_W_BB("JLCC_GL_Low_threshold", DPE_JLCC_BASE_OFFSET + 0xb20, g_csr_gen5_DPE_JLCC_GL_Low_threshold_REGISTER, "JLCC_GL_Low_threshold")

	CSR_REG_W_BB("JLCC_GL_High_threshold", DPE_JLCC_BASE_OFFSET + 0xb24 ,g_csr_gen5_DPE_JLCC_GL_High_threshold_REGISTER, "JLCC_GL_High_threshold")

	CSR_REG_W_BB("JLCC_Global_saturation_low_threshold", DPE_JLCC_BASE_OFFSET + 0xb28, g_csr_gen5_DPE_JLCC_Global_Saturation_Low_threshold_REGISTER, "JLCC_Global_saturation_low_threshold")

	CSR_REG_W_BB("JLCC_Global_saturation_high_threshold", DPE_JLCC_BASE_OFFSET + 0xb2c, g_csr_gen5_DPE_JLCC_Global_Saturation_High_threshold_REGISTER, "JLCC_Global_saturation_high_threshold")

	CSR_REG_W_BB("JLCC_sin_lut_lower_bound", DPE_JLCC_BASE_OFFSET + 0xb30, g_csr_gen5_DPE_JLCC_Sin_Lut_Lower_Bound_REGISTER, "JLCC_sin_lut_lower_bound")

	CSR_REG_W_BB("JLCC_SGB_Skin_slope_CSR1", DPE_JLCC_BASE_OFFSET + 0xb34, g_csr_gen5_DPE_JLCC_SGB_SKIN_SLOPE_CSR1_REGISTER, "JLCC_SGB_Skin_slope_CSR1")

	CSR_REG_W_BB("JLCC_SGB_Skin_slope_inv_CSR2", DPE_JLCC_BASE_OFFSET + 0xb38, g_csr_gen5_DPE_JLCC_SGB_SKIN_SLOPE_INV_CSR2_REGISTER, "JLCC_SGB_Skin_slope_inv_CSR2")

	CSR_REG_W_BB("JLCC_SGB_Skin_sat_CSR3", DPE_JLCC_BASE_OFFSET + 0xb3c, g_csr_gen5_DPE_JLCC_SGB_SKIN_SAT_CSR3_REGISTER, "JLCC_SGB_Skin_sat_CSR3")

	CSR_REG_W_BB("JLCC_SGB_Green_slope_CSR1", DPE_JLCC_BASE_OFFSET + 0xb40, g_csr_gen5_DPE_JLCC_SGB_GREEN_SLOPE_CSR1_REGISTER, "JLCC_SGB_Green_slope_CSR1")

	CSR_REG_W_BB("JLCC_SGB_Green_slope_inv_CSR2", DPE_JLCC_BASE_OFFSET + 0xb44, g_csr_gen5_DPE_JLCC_SGB_GREEN_SLOPE_INV_CSR2_REGISTER, "JLCC_SGB_Green_slope_inv_CSR2")

	CSR_REG_W_BB("JLCC_SGB_Green_Sat_CSR3", DPE_JLCC_BASE_OFFSET + 0xb48, g_csr_gen5_DPE_JLCC_SGB_GREEN_SAT_CSR3_REGISTER, "JLCC_SGB_Green_sat_CSR3")

	CSR_REG_W_BB("JLCC_SGB_blue_slope_CSR1", DPE_JLCC_BASE_OFFSET + 0xb4c, g_csr_gen5_DPE_JLCC_SGB_BLUE_SLOPE_CSR1_REGISTER, "JLCC_SGB_blue_slope_CSR1")

	CSR_REG_W_BB("JLCC_SGB_blue_slope_inv_CSR2", DPE_JLCC_BASE_OFFSET + 0xb50, g_csr_gen5_DPE_JLCC_SGB_BLUE_SLOPE_INV_CSR2_REGISTER, "JLCC_SGB_blue_slope_inv_CSR2")

	CSR_REG_W_BB("JLCC_SGB_sat_CSR3", DPE_JLCC_BASE_OFFSET + 0xb54, g_csr_gen5_DPE_JLCC_SGB_BLUE_SAT_CSR3_REGISTER, "JLCC_SGB_sat_CSR3")

	CSR_REG_W_BB("JLCC_CSR_Product1", DPE_JLCC_BASE_OFFSET + 0xb58, g_csr_gen5_DPE_JLCC_CSR_product1_REGISTER, "JLCC_CSR_Product1")

	CSR_REG_W_BB("JLCC_CSR_Smooth1", DPE_JLCC_BASE_OFFSET + 0xb5c, g_csr_gen5_DPE_JLCC_CSR_Smooth1_REGISTER, "JLCC_CSR_Smooth1")

	CSR_REG_W_BB("JLCC_CSR_Smooth2", DPE_JLCC_BASE_OFFSET + 0xb60c, g_csr_gen5_DPE_JLCC_CSR_Smooth2_REGISTER, "JLCC_CSR_Smooth2")

	CSR_REG_W_BB("JLCC_CSR_Smooth3", DPE_JLCC_BASE_OFFSET + 0xb64, g_csr_gen5_DPE_JLCC_CSR_Smooth3_REGISTER, "JLCC_CSR_Smooth3")

	CSR_REG_W_BB("JLCC_CSR_Smooth4", DPE_JLCC_BASE_OFFSET + 0xb68, g_csr_gen5_DPE_JLCC_CSR_Smooth4_REGISTER, "JLCC_CSR_Smooth4")

	CSR_REG_W_BB("JLCC_CSR_Smooth5", DPE_JLCC_BASE_OFFSET + 0xb6c, g_csr_gen5_DPE_JLCC_CSR_Smooth5_REGISTER, "JLCC_CSR_Smooth5")

	CSR_REG_W_BB("JLCC_Dither_Seed", DPE_JLCC_BASE_OFFSET + 0xb70, g_csr_gen5_DPE_JLCC_DITHER_SEED_REGISTER, "JLCC_Dither_Seed")

	CSR_REG_W_BB("JLCC_Dither_Params", DPE_JLCC_BASE_OFFSET + 0xb74, g_csr_gen5_DPE_JLCC_DITHER_PARAMS_REGISTER, "JLCC_Dither_Params")

	CSR_REG_W_BB("JLCC_LMTC_TL_0", DPE_JLCC_BASE_OFFSET + 0xB80, g_csr_gen5_DPE_JLCC_LMTC_TL_0_5_REGISTER, "JLCC_LMTC_TL_0")
	CSR_REG_W_BB("JLCC_LMTC_TL_1", DPE_JLCC_BASE_OFFSET + 0xB84, g_csr_gen5_DPE_JLCC_LMTC_TL_0_5_REGISTER, "JLCC_LMTC_TL_1")
	CSR_REG_W_BB("JLCC_LMTC_TL_2", DPE_JLCC_BASE_OFFSET + 0xB88, g_csr_gen5_DPE_JLCC_LMTC_TL_0_5_REGISTER, "JLCC_LMTC_TL_2")
	CSR_REG_W_BB("JLCC_LMTC_TL_3", DPE_JLCC_BASE_OFFSET + 0xB8C, g_csr_gen5_DPE_JLCC_LMTC_TL_0_5_REGISTER, "JLCC_LMTC_TL_3")
	CSR_REG_W_BB("JLCC_LMTC_TL_4", DPE_JLCC_BASE_OFFSET + 0xB90, g_csr_gen5_DPE_JLCC_LMTC_TL_0_5_REGISTER, "JLCC_LMTC_TL_4")
	CSR_REG_W_BB("JLCC_LMTC_TL_5", DPE_JLCC_BASE_OFFSET + 0xB94, g_csr_gen5_DPE_JLCC_LMTC_TL_0_5_REGISTER, "JLCC_LMTC_TL_5")

	CSR_REG_W_BB("JLCC_LMTC_SLOPE_0", DPE_JLCC_BASE_OFFSET +0xB98 , g_csr_gen5_DPE_JLCC_LMTC_SLOPE_0_4_REGISTER, "JLCC_LMTC_SLOPE_0")
	CSR_REG_W_BB("JLCC_LMTC_SLOPE_1", DPE_JLCC_BASE_OFFSET +0xB9C , g_csr_gen5_DPE_JLCC_LMTC_SLOPE_0_4_REGISTER, "JLCC_LMTC_SLOPE_1")
	CSR_REG_W_BB("JLCC_LMTC_SLOPE_2", DPE_JLCC_BASE_OFFSET +0xBA0 , g_csr_gen5_DPE_JLCC_LMTC_SLOPE_0_4_REGISTER, "JLCC_LMTC_SLOPE_2")
	CSR_REG_W_BB("JLCC_LMTC_SLOPE_3", DPE_JLCC_BASE_OFFSET +0xBA4 , g_csr_gen5_DPE_JLCC_LMTC_SLOPE_0_4_REGISTER, "JLCC_LMTC_SLOPE_3")
	CSR_REG_W_BB("JLCC_LMTC_SLOPE_4", DPE_JLCC_BASE_OFFSET +0xBA8 , g_csr_gen5_DPE_JLCC_LMTC_SLOPE_0_4_REGISTER, "JLCC_LMTC_SLOPE_4")

	CSR_REG_W_BB("JLCC_LMTD_TL_0", DPE_JLCC_BASE_OFFSET +0xBB0 , g_csr_gen5_DPE_JLCC_LMTD_TL_0_5_REGISTER, "JLCC_LMTD_TL_0")
	CSR_REG_W_BB("JLCC_LMTD_TL_1", DPE_JLCC_BASE_OFFSET +0xBB4 , g_csr_gen5_DPE_JLCC_LMTD_TL_0_5_REGISTER, "JLCC_LMTD_TL_1")
	CSR_REG_W_BB("JLCC_LMTD_TL_2", DPE_JLCC_BASE_OFFSET +0xBB8 , g_csr_gen5_DPE_JLCC_LMTD_TL_0_5_REGISTER, "JLCC_LMTD_TL_2")
	CSR_REG_W_BB("JLCC_LMTD_TL_3", DPE_JLCC_BASE_OFFSET +0xBBC , g_csr_gen5_DPE_JLCC_LMTD_TL_0_5_REGISTER, "JLCC_LMTD_TL_3")
	CSR_REG_W_BB("JLCC_LMTD_TL_4", DPE_JLCC_BASE_OFFSET +0xBC0 , g_csr_gen5_DPE_JLCC_LMTD_TL_0_5_REGISTER, "JLCC_LMTD_TL_4")
	CSR_REG_W_BB("JLCC_LMTD_TL_5", DPE_JLCC_BASE_OFFSET +0xBC4 , g_csr_gen5_DPE_JLCC_LMTD_TL_0_5_REGISTER, "JLCC_LMTD_TL_5")

	CSR_REG_W_BB("JLCC_LMTD_SLOPE_0", DPE_JLCC_BASE_OFFSET + 0xBC8 , g_csr_gen5_DPE_JLCC_LMTD_SLOPE_0_4_REGISTER, "JLCC_LMTD_SLOPE_0")
	CSR_REG_W_BB("JLCC_LMTD_SLOPE_1", DPE_JLCC_BASE_OFFSET + 0xBCC , g_csr_gen5_DPE_JLCC_LMTD_SLOPE_0_4_REGISTER, "JLCC_LMTD_SLOPE_1")
	CSR_REG_W_BB("JLCC_LMTD_SLOPE_2", DPE_JLCC_BASE_OFFSET + 0xBD0 , g_csr_gen5_DPE_JLCC_LMTD_SLOPE_0_4_REGISTER, "JLCC_LMTD_SLOPE_2")
	CSR_REG_W_BB("JLCC_LMTD_SLOPE_3", DPE_JLCC_BASE_OFFSET + 0xBD4 , g_csr_gen5_DPE_JLCC_LMTD_SLOPE_0_4_REGISTER, "JLCC_LMTD_SLOPE_3")
	CSR_REG_W_BB("JLCC_LMTD_SLOPE_4", DPE_JLCC_BASE_OFFSET + 0xBD8 , g_csr_gen5_DPE_JLCC_LMTD_SLOPE_0_4_REGISTER, "JLCC_LMTD_SLOPE_4")

	CSR_REG_W_BB("JLCC_YCR_select_gain_register", DPE_JLCC_BASE_OFFSET + 0xBE0, g_csr_gen5_DPE_JLCC_YCR_Select_Gain_REGISTER, "JLCC_YCR_select_gain_register")

	CSR_REG_W_BB("JLCC_DCE_UNA_UNB", DPE_JLCC_BASE_OFFSET + 0xBE4, g_csr_gen5_DPE_JLCC_DCE_UNA_UNB_REGISTER, "JLCC_DCE_UNA_UNB")

	CSR_REG_W_BB("JLCC_DCE_COL_GA", DPE_JLCC_BASE_OFFSET + 0xBE8, g_csr_gen5_DPE_JLCC_DCE_COL_GA_REGISTER, "JLCC_DCE_COL_GA")

	CSR_REG_W_BB("JLCC_DC_LUT_Register", DPE_JLCC_BASE_OFFSET + 0xC00, g_csr_gen5_DPE_JLCC_DC_LUT_REGISTER, "JLCC_DC_LUT")

	CSR_REG_W_BB("JLCC_DC_GAIN_MAP_Register", DPE_JLCC_BASE_OFFSET + 0xC80, g_csr_gen5_DPE_JLCC_DC_GAIN_MAP_REGISTER, "JLCC_DC_GAIN_MAP")

//---------------------------------------------SCC---------------------------------------------------------------------------//
 
        CSR_REG_W_BB("SCC_Control_Register", DPE_SCC_LUT_BASE_OFFSET + 0x00, g_csr_gen5_DPE_SCC_CONTROL_REGISTER, "SCC_Control_Register")
 
        CSR_REG_W_BB("SCC_xvYcc_Offset_Register", DPE_SCC_LUT_BASE_OFFSET + 0x4, g_csr_gen5_DPE_SCC_xvYcc_Offset_REGISTER,  "SCC_xvYcc_Offset_Register")
 
        CSR_REG_W_BB("SCC_xvYcc_I_RANGE_COMP_Register", DPE_SCC_LUT_BASE_OFFSET + 0x8, g_csr_gen5_DPE_SCC_xvYcc_I_RANGE_COMP_REGISTER,      "SCC_xvYcc_I_RANGE_COMP_Register")
 
        CSR_REG_W_BB("SCC_ATanLUT_Register", DPE_SCC_LUT_BASE_OFFSET + 0x10, g_csr_gen5_DPE_SCC_ATanLUT_REGISTER,   "SCC_ATanLUT_Register")
 
        CSR_REG_W_BB("SCC_SinLUT_Register", DPE_SCC_LUT_BASE_OFFSET + 0x90, g_csr_gen5_DPE_SCC_SinLUT_REGISTER,     "SCC_SinLUT_Register")
 
        CSR_REG_W_BB("SCC_SqrtLUT_Register", DPE_SCC_LUT_BASE_OFFSET + 0x110, g_csr_gen5_DPE_SCC_SqrtLUT_REGISTER,  "SCC_SqrtLUT_Register")
 
        CSR_REG_W_BB("SCC_CosLUT_Register", DPE_SCC_LUT_BASE_OFFSET + 0x510, g_csr_gen5_DPE_SCC_CosLUT_REGISTER,    "SCC_CosLUT_Register")
 
//---------------------------------------SCC STAGE N-----------------------------------------------------------------------//
 
        CSR_REG_W_BB("SCC_Stage_Control_Register", DPE_SCC_BASE_OFFSET + 0x00, g_csr_gen5_DPE_SCC_STAGE_CONTROL_REGISTER,       "SCC_Stage_Control_Register")
 
        CSR_REG_W_BB("SCC_Hue_Threshold_AB_Register", DPE_SCC_BASE_OFFSET + 0x4, g_csr_gen5_DPE_SCC_HThresh_AB_ST_N_REGISTER,       "SCC_Hue_Threshold_AB_Register")
 
        CSR_REG_W_BB("SCC_Hue_Threshold_CD_Register", DPE_SCC_BASE_OFFSET + 0x8, g_csr_gen5_DPE_SCC_HThresh_CD_ST_N_REGISTER,       "SCC_Hue_Threshold_CD_Register")
 
        CSR_REG_W_BB("SCC_Hue_Threshold_E_Register", DPE_SCC_BASE_OFFSET + 0x0c, g_csr_gen5_DPE_SCC_HThresh_E_ST_N_REGISTER,        "SCC_Hue_Threshold_E_Register")
 
        CSR_REG_W_BB("SCC_Hue_Gain_AB_Register", DPE_SCC_BASE_OFFSET + 0x10, g_csr_gen5_DPE_SCC_HGain_AB_ST_N_REGISTER,     "SCC_Hue_Gain_AB_Register")
 
        CSR_REG_W_BB("SCC_Hue_Gain_CD_Register", DPE_SCC_BASE_OFFSET + 0x14, g_csr_gen5_DPE_SCC_HGain_CD_ST_N_REGISTER,     "SCC_Hue_Gain_CD_Register")
 
        CSR_REG_W_BB("SCC_Hue_Gain_E_Register", DPE_SCC_BASE_OFFSET + 0x18, g_csr_gen5_DPE_SCC_HGain_E_ST_N_REGISTER,       "SCC_Hue_Gain_E_Register")
 
        CSR_REG_W_BB("SCC_HSlope_AB_BC_N_Register", DPE_SCC_BASE_OFFSET + 0x20, g_csr_gen5_DPE_SCC_HSlope_AB_BC_ST_N_REGISTER,      "SCC_HSlope_AB_BC_N_Register")
 
        CSR_REG_W_BB("SCC_HSlope_CD_DE_N_Register", DPE_SCC_BASE_OFFSET + 0x24, g_csr_gen5_DPE_SCC_HSlope_CD_DE_ST_N_REGISTER,      "SCC_HSlope_CD_DE_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_Gain_AB_N_Register", DPE_SCC_BASE_OFFSET + 0x28, g_csr_gen5_DPE_SCC_SGain_AB_ST_N_REGISTER,    "SCC_Saturation_Gain_AB_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_Gain_CD_N_Register", DPE_SCC_BASE_OFFSET + 0x2c, g_csr_gen5_DPE_SCC_SGain_CD_ST_N_REGISTER,    "SCC_Saturation_Gain_CD_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_Gain_E_N_Register", DPE_SCC_BASE_OFFSET + 0x30, g_csr_gen5_DPE_SCC_SGain_E_ST_N_REGISTER,      "SCC_Saturation_Gain_E_N_Register")

	 CSR_REG_W_BB("SCC_Saturation_Slope_AB_BC_N_Register", DPE_SCC_BASE_OFFSET + 0x34, g_csr_gen5_DPE_SCC_SSlope_AB_BC_ST_N_REGISTER,    "SCC_Saturation_Slope_AB_BC_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_Slope_CD_DE_N_Register", DPE_SCC_BASE_OFFSET + 0x38, g_csr_gen5_DPE_SCC_SSlope_CD_DE_ST_N_REGISTER,    "SCC_Saturation_Slope_CD_DE_N_Register")
 
        CSR_REG_W_BB("SCC_Intensity_Gain_AB_Register", DPE_SCC_BASE_OFFSET + 0x3c, g_csr_gen5_DPE_SCC_IGain_AB_ST_N_REGISTER,       "SCC_Intensity_Gain_AB_Register")
 
        CSR_REG_W_BB("SCC_Intensity_Gain_CD_Register", DPE_SCC_BASE_OFFSET + 0x40, g_csr_gen5_DPE_SCC_IGain_CD_ST_N_REGISTER,       "SCC_Intensity_Gain_CD_Register")
 
        CSR_REG_W_BB("SCC_Intensity_Gain_E_Register", DPE_SCC_BASE_OFFSET + 0x44, g_csr_gen5_DPE_SCC_IGain_E_ST_N_REGISTER,         "SCC_Intensity_Gain_E_Register")
 
        CSR_REG_W_BB("SCC_Islope_AB_BC_Register", DPE_SCC_BASE_OFFSET + 0x48, g_csr_gen5_DPE_SCC_ISlope_AB_BC_ST_N_REGISTER,        "SCC_Islope_AB_BC_Register")
 
        CSR_REG_W_BB("SCC_Islope_CD_DE_Register", DPE_SCC_BASE_OFFSET + 0x4c, g_csr_gen5_DPE_SCC_ISlope_CD_DE_ST_N_REGISTER,        "SCC_Islope_CD_DE_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_AB_for_hue_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0x50, g_csr_gen5_DPE_SCC_SThresh_Hue_lim_AB_ST_N_REGISTER,        "SCC_Saturation_thresh_AB_for_hue_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_CD_for_hue_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0x54, g_csr_gen5_DPE_SCC_SThresh_Hue_lim_CD_ST_N_REGISTER,        "SCC_Saturation_thresh_CD_for_hue_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_hue_AB_BC_N_Register", DPE_SCC_BASE_OFFSET + 0x58, g_csr_gen5_DPE_SCC_SSlope_Hue_lim_AB_BC_ST_N_REGISTER,        "SCC_Saturation_slope_hue_AB_BC_N_Register")

        CSR_REG_W_BB("SCC_Saturation_slope_hue_CD_N_Register", DPE_SCC_BASE_OFFSET + 0x5C, g_csr_gen5_DPE_SCC_SSlope_Hue_lim_CD_ST_N_REGISTER,      "SCC_Saturation_slope_hue_CD_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_Hue_ABCD_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0x60, g_csr_gen5_DPE_SCC_S_Hue_lim_ABCD_ST_N_REGISTER,   "SCC_Saturation_limit_for_Hue_ABCD_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_AB_for_hue_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0x64, g_csr_gen5_DPE_SCC_IThresh_Hue_lim_AB_ST_N_REGISTER, "SCC_Intensity_thresh_AB_for_hue_limiter_N_Register")
 
 CSR_REG_W_BB("SCC_Intensity_thresh_CD_for_hue_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0x68, g_csr_gen5_DPE_SCC_IThresh_Hue_lim_CD_ST_N_REGISTER, "SCC_Intensity_thresh_CD_for_hue_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Islope_hue_AB_BC_Register", DPE_SCC_BASE_OFFSET + 0x6c, g_csr_gen5_DPE_SCC_ISlope_Hue_lim_AB_BC_ST_N_REGISTER,    "SCC_Islope_hue_AB_BC_Register")
 
        CSR_REG_W_BB("SCC_Islope_hue_CD_Register", DPE_SCC_BASE_OFFSET + 0x70, g_csr_gen5_DPE_SCC_ISlope_Hue_lim_CD_ST_N_REGISTER,  "SCC_Islope_hue_CD_Register")
 
        CSR_REG_W_BB("SCC_Intensity_limit_for_Hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0x74, g_csr_gen5_DPE_SCC_I_Hue_lim_ABCD_ST_N_REGISTER,   "SCC_Intensity_limit_for_Hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_AB_for_SAT_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0x78, g_csr_gen5_DPE_SCC_SThresh_Sat_lim_AB_ST_N_REGISTER,        "SCC_Saturation_thresh_AB_for_SAT_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_CD_for_SAT_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0x7C, g_csr_gen5_DPE_SCC_SThresh_Sat_lim_CD_ST_N_REGISTER,        "SCC_Saturation_thresh_CD_for_SAT_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_sat_slope_AB_BC_Register", DPE_SCC_BASE_OFFSET + 0x80, g_csr_gen5_DPE_SCC_SSlope_Sat_lim_AB_BC_ST_N_REGISTER,  "SCC_Saturation_sat_slope_AB_BC_Register")
 
        CSR_REG_W_BB("SCC_Saturation_sat_slope_CD_Register", DPE_SCC_BASE_OFFSET + 0x84, g_csr_gen5_DPE_SCC_SSlope_Sat_lim_CD_ST_N_REGISTER,        "SCC_Saturation_sat_slope_CD_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_SAT_limiter_ABCD_N_Register", DPE_SCC_BASE_OFFSET + 0x88, g_csr_gen5_DPE_SCC_S_Sat_lim_ABCD_ST_N_REGISTER,   "SCC_Saturation_limit_for_SAT_limiterABCD_N_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_AB_for_SAT_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0x90, g_csr_gen5_DPE_SCC_IThresh_Sat_lim_AB_ST_N_REGISTER, "SCC_Intensity_thresh_AB_for_SAT_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_CD_for_SAT_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0x94, g_csr_gen5_DPE_SCC_IThresh_Sat_lim_CD_ST_N_REGISTER, "SCC_Intensity_thresh_CD_for_SAT_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Islope_sat_AB_BC_N_Register", DPE_SCC_BASE_OFFSET + 0x98, g_csr_gen5_DPE_SCC_ISlope_Sat_lim_AB_BC_ST_N_REGISTER,  "SCC_Islope_sat_AB_BC_N_Register")
 
        CSR_REG_W_BB("SCC_Islope_sat_CD_N_Register", DPE_SCC_BASE_OFFSET + 0x9C, g_csr_gen5_DPE_SCC_ISlope_Sat_lim_CD_ST_N_REGISTER,        "SCC_Islope_sat_CD_N_Register")
 
	 CSR_REG_W_BB("SCC_Intensity_limit_for_SAT_limiter_Register", DPE_SCC_BASE_OFFSET + 0xA0, g_csr_gen5_DPE_SCC_I_Sat_lim_ABCD_ST_N_REGISTER,   "SCC_Intensity_limit_for_SAT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_AB_for_INT_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0xA4, g_csr_gen5_DPE_SCC_SThresh_INT_lim_AB_ST_N_REGISTER,        "SCC_Saturation_thresh_AB_for_INT_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_CD_for_INT_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0xA8, g_csr_gen5_DPE_SCC_SThresh_INT_lim_CD_ST_N_REGISTER,        "SCC_Saturation_thresh_CD_for_INT_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Sslope_INT_AB_BC_N_Register", DPE_SCC_BASE_OFFSET + 0xAC, g_csr_gen5_DPE_SCC_SSlope_INT_lim_AB_BC_ST_N_REGISTER,  "SCC_Sslope_INT_AB_BC_N_Register")
 
        CSR_REG_W_BB("SCC_Sslope_INT_CD_N_Register", DPE_SCC_BASE_OFFSET + 0xB0, g_csr_gen5_DPE_SCC_SSlope_INT_lim_CD_ST_N_REGISTER,        "SCC_Sslope_INT_CD_N_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_INT_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0xB4, g_csr_gen5_DPE_SCC_S_INT_lim_ABCD_ST_N_REGISTER,        "SCC_Saturation_limit_for_INT_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_AB_for_INT_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0xB8, g_csr_gen5_DPE_SCC_IThresh_INT_lim_AB_ST_N_REGISTER, "SCC_Intensity_thresh_AB_for_INT_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_CD_for_INT_limiter_N_Register", DPE_SCC_BASE_OFFSET + 0xBc, g_csr_gen5_DPE_SCC_IThresh_INT_lim_CD_ST_N_REGISTER, "SCC_Intensity_thresh_CD_for_INT_limiter_N_Register")
 
        CSR_REG_W_BB("SCC_Islope_INT_AB_BC_N_Register", DPE_SCC_BASE_OFFSET + 0xC0, g_csr_gen5_DPE_SCC_ISlope_INT_lim_AB_BC_ST_N_REGISTER,  "SCC_Islope_INT_AB_BC_N_Register")
 
        CSR_REG_W_BB("SCC_Islope_INT_CD_N_Register", DPE_SCC_BASE_OFFSET + 0xC4, g_csr_gen5_DPE_SCC_ISlope_INT_lim_CD_ST_N_REGISTER,        "SCC_Islope_INT_CD_N_Register")
 
        CSR_REG_W_BB("SCC_Intensity_limit_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0xC8, g_csr_gen5_DPE_SCC_I_INT_lim_ABCD_ST_N_REGISTER,   "SCC_Intensity_limit_for_INT_limiter_Register")
 
//------------------------------------------------------------SCC STAGE 8-------------------------------------------------//
 
	CSR_REG_W_BB("SCC_Blue_Stretch_Control_Register", DPE_SCC_BASE_OFFSET + 0x00, g_csr_gen5_DPE_SCC_Blue_Stretch_CONTROL_REGISTER, "SCC_Blue_Stretch_Control_Register")
 
        CSR_REG_W_BB("SCC_Hue_thresh_AB_Register", DPE_SCC_BASE_OFFSET + 0x4, g_csr_gen5_DPE_SCC_HThresh_AB_ST8_BS_REGISTER, "SCC_Hue_thresh_AB_Register")
 
        CSR_REG_W_BB("SCC_Hue_thresh_CD_Register", DPE_SCC_BASE_OFFSET + 0x8, g_csr_gen5_DPE_SCC_HThresh_CD_ST8_BS_REGISTER, "SCC_Hue_thresh_CD_Register")
 
        CSR_REG_W_BB("SCC_Hue_thresh_EF_Register", DPE_SCC_BASE_OFFSET + 0xC, g_csr_gen5_DPE_SCC_HThresh_EF_ST8_BS_REGISTER, "SCC_Hue_thresh_EF_Register")
 
        CSR_REG_W_BB("SCC_Hue_thresh_GH_Register", DPE_SCC_BASE_OFFSET + 0x10, g_csr_gen5_DPE_SCC_HThresh_GH_ST8_BS_REGISTER, "SCC_Hue_thresh_GH_Register")
 
        CSR_REG_W_BB("SCC_Hue_Gain_0A_Register", DPE_SCC_BASE_OFFSET + 0x14, g_csr_gen5_DPE_SCC_HGain_0A_ST8_BS_REGISTER, "SCC_Hue_Gain_0A_Register")
 
        CSR_REG_W_BB("SCC_Hue_Gain_BC_Register", DPE_SCC_BASE_OFFSET + 0x18, g_csr_gen5_DPE_SCC_HGain_BC_ST8_BS_REGISTER, "SCC_Hue_Gain_BC_Register")
 
        CSR_REG_W_BB("SCC_Hue_Gain_DE_Register", DPE_SCC_BASE_OFFSET + 0x1C, g_csr_gen5_DPE_SCC_HGain_DE_ST8_BS_REGISTER, "SCC_Hue_Gain_DE_Register")
 
        CSR_REG_W_BB("SCC_Hue_Gain_FG_Register", DPE_SCC_BASE_OFFSET + 0x20, g_csr_gen5_DPE_SCC_HGain_FG_ST8_BS_REGISTER, "SCC_Hue_Gain_FG_Register")
 
        CSR_REG_W_BB("SCC_Hue_Gain_H_Register", DPE_SCC_BASE_OFFSET + 0x24, g_csr_gen5_DPE_SCC_HGain_H_ST8_BS_REGISTER, "SCC_Hue_Gain_H_Register")
 
        CSR_REG_W_BB("SCC_Hslope_0A_AB_Register", DPE_SCC_BASE_OFFSET + 0x28, g_csr_gen5_DPE_SCC_HSlope_0A_AB_ST8_BS_REGISTER, "SCC_Hslope_0A_AB_Register")
 
        CSR_REG_W_BB("SCC_Hslope_BC_CD_Register", DPE_SCC_BASE_OFFSET + 0x2C, g_csr_gen5_DPE_SCC_HSlope_BC_CD_ST8_BS_REGISTER, "SCC_Hslope_BC_CD_Register")
 
        CSR_REG_W_BB("SCC_Hslope_DE_EF_Register", DPE_SCC_BASE_OFFSET + 0x30, g_csr_gen5_DPE_SCC_HSlope_DE_EF_ST8_BS_REGISTER, "SCC_Hslope_DE_EF_Register")
 
        CSR_REG_W_BB("SCC_Hslope_FG_GH_Register", DPE_SCC_BASE_OFFSET + 0x34, g_csr_gen5_DPE_SCC_HSlope_FG_GH_ST8_BS_REGISTER, "SCC_Hslope_FG_GH_Register")
 
        CSR_REG_W_BB("SCC_Hslope_H1_Register", DPE_SCC_BASE_OFFSET + 0x38, g_csr_gen5_DPE_SCC_HSlope_H1_ST8_BS_REGISTER, "SCC_Hslope_H1_Register")
 
        CSR_REG_W_BB("SCC_Saturation_delta_0A_Register", DPE_SCC_BASE_OFFSET + 0x3C, g_csr_gen5_DPE_SCC_SDelta_0A_ST8_BS_REGISTER, "SCC_Saturation_delta_0A_Register")
 
        CSR_REG_W_BB("SCC_Saturation_delta_BC_Register", DPE_SCC_BASE_OFFSET + 0x40, g_csr_gen5_DPE_SCC_SDelta_BC_ST8_BS_REGISTER, "SCC_Saturation_delta_BC_Register")
 
        CSR_REG_W_BB("SCC_Saturation_delta_DE_Register", DPE_SCC_BASE_OFFSET + 0x44, g_csr_gen5_DPE_SCC_SDelta_DE_ST8_BS_REGISTER, "SCC_Saturation_delta_DE_Register")
 
        CSR_REG_W_BB("SCC_Saturation_delta_FG_Register", DPE_SCC_BASE_OFFSET + 0x48, g_csr_gen5_DPE_SCC_SDelta_FG_ST8_BS_REGISTER, "SCC_Saturation_delta_FG_Register")
 
        CSR_REG_W_BB("SCC_Saturation_delta_H_Register", DPE_SCC_BASE_OFFSET + 0x4C, g_csr_gen5_DPE_SCC_SDelta_H_ST8_BS_REGISTER, "SCC_Saturation_delta_H_Register")
 
	CSR_REG_W_BB("SCC_SDelta_Saturation_slope_0A_AB_Register", DPE_SCC_BASE_OFFSET + 0x50, g_csr_gen5_DPE_SCC_SDelta_Slope_0A_AB_ST8_BS_REGISTER, "SCC_SDelta_Saturation_slope_0A_AB_Register")
 
        CSR_REG_W_BB("SCC_SDelta_Saturation_slope_BC_CD_Register", DPE_SCC_BASE_OFFSET + 0x54, g_csr_gen5_DPE_SCC_SDelta_Slope_BC_CD_ST8_BS_REGISTER, "SCC_SDelta_Saturation_slope_BC_CD_Register")
 
        CSR_REG_W_BB("SCC_SDelta_Saturation_slope_DE_EF_Register", DPE_SCC_BASE_OFFSET + 0x58, g_csr_gen5_DPE_SCC_SDelta_Slope_DE_EF_ST8_BS_REGISTER, "SCC_SDelta_Saturation_slope_DE_EF_Register")
 
        CSR_REG_W_BB("SCC_SDelta_Saturation_slope_FG_GH_Register", DPE_SCC_BASE_OFFSET + 0x5C, g_csr_gen5_DPE_SCC_SDelta_Slope_FG_GH_ST8_BS_REGISTER, "SCC_SDelta_Saturation_slope_FG_GH_Register")
 
        CSR_REG_W_BB("SCC_SDelta_Saturation_slope_H1_Register", DPE_SCC_BASE_OFFSET + 0x60, g_csr_gen5_DPE_SCC_SDelta_Slope_H1_ST8_BS_REGISTER, "SCC_SDelta_Saturation_slope_H1_Register")
 
        CSR_REG_W_BB("SCC_Intensity_Gain_0A_Register", DPE_SCC_BASE_OFFSET + 0x64, g_csr_gen5_DPE_SCC_IGain_0A_ST8_BS_REGISTER, "SCC_Intensity_Gain_0A_Register")
 
        CSR_REG_W_BB("SCC_Intensity_Gain_BC_Register", DPE_SCC_BASE_OFFSET + 0x68, g_csr_gen5_DPE_SCC_IGain_BC_ST8_BS_REGISTER, "SCC_Intensity_Gain_BC_Register")
 
        CSR_REG_W_BB("SCC_Intensity_Gain_DE_Register", DPE_SCC_BASE_OFFSET + 0x6C, g_csr_gen5_DPE_SCC_IGain_DE_ST8_BS_REGISTER, "SCC_Intensity_Gain_DE_Register")
 
        CSR_REG_W_BB("SCC_Intensity_Gain_FG_Register", DPE_SCC_BASE_OFFSET + 0x70, g_csr_gen5_DPE_SCC_IGain_FG_ST8_BS_REGISTER, "SCC_Intensity_Gain_FG_Register")
 
        CSR_REG_W_BB("SCC_Intensity_Gain_H_Register", DPE_SCC_BASE_OFFSET + 0x74, g_csr_gen5_DPE_SCC_IGain_H_ST8_BS_REGISTER, "SCC_Intensity_Gain_H_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_0A_AB_Register", DPE_SCC_BASE_OFFSET + 0x78, g_csr_gen5_DPE_SCC_ISlope_0A_AB_ST8_BS_REGISTER, "SCC_Saturation_slope_0A_AB_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_BC_CD_Register", DPE_SCC_BASE_OFFSET + 0x7C, g_csr_gen5_DPE_SCC_ISlope_BC_CD_ST8_BS_REGISTER, "SCC_Saturation_slope_BC_CD_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_DE_EF_Register", DPE_SCC_BASE_OFFSET + 0x80, g_csr_gen5_DPE_SCC_ISlope_DE_EF_ST8_BS_REGISTER, "SCC_Saturation_slope_DE_EF_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_FG_GH_Register", DPE_SCC_BASE_OFFSET + 0x84, g_csr_gen5_DPE_SCC_ISlope_FG_GH_ST8_BS_REGISTER, "SCC_Saturation_slope_FG_GH_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_H1_Register", DPE_SCC_BASE_OFFSET + 0x88, g_csr_gen5_DPE_SCC_ISlope_H1_ST8_BS_REGISTER, "SCC_Saturation_slope_H1_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_AB_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0x8C, g_csr_gen5_DPE_SCC_SThresh_Hue_lim_AB_ST8_BS_REGISTER, "SCC_Saturation_thresh_AB_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_aturation_thresh_CD_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0x90, g_csr_gen5_DPE_SCC_c_Hue_lim_CD_ST8_BS_REGISTER, "SCC_Saturation_thresh_CD_for_hue_limiter_Register")

	 CSR_REG_W_BB("SCC_Saturation_thresh_EF_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0x94, g_csr_gen5_DPE_SCC_SThresh_Hue_lim_EF_ST8_BS_REGISTER, "SCC_Saturation_thresh_EF_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_GH_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0x98, g_csr_gen5_DPE_SCC_SThresh_Hue_lim_GH_ST8_BS_REGISTER, "SCC_Saturation_thresh_GH_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_S_slope_AB_BC_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0x9C, g_csr_gen5_DPE_SCC_SSlope_Hue_lim_AB_BC_ST8_BS_REGISTER, "SCC_S_slope_AB_BC_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_S_slope_CD_DE_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xA0, g_csr_gen5_DPE_SCC_SSlope_Hue_lim_CD_DE_ST8_BS_REGISTER, "SCC_S_slope_CD_DE_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_S_slope_EF_FG_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xA4, g_csr_gen5_DPE_SCC_SSlope_Hue_lim_EF_FG_ST8_BS_REGISTER, "SCC_S_slope_EF_FG_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_S_slope_GH_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xA8, g_csr_gen5_DPE_SCC_SSlope_Hue_lim_GH_ST8_BS_REGISTER, "SCC_S_slope_GH_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_hue_limiter_AB_Register", DPE_SCC_BASE_OFFSET + 0xAC, g_csr_gen5_DPE_SCC_S_Hue_lim_AB_ST8_BS_REGISTER, "SCC_Saturation_limit_for_hue_limiter_AB_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_hue_limiter_CD_Register", DPE_SCC_BASE_OFFSET + 0xB0, g_csr_gen5_DPE_SCC_S_Hue_lim_CD_ST8_BS_REGISTER, "SCC_Saturation_limit_for_hue_limiter_CD_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_hue_limiter_EF_Register", DPE_SCC_BASE_OFFSET + 0xB4, g_csr_gen5_DPE_SCC_S_Hue_lim_EF_ST8_BS_REGISTER, "SCC_Saturation_limit_for_hue_limiter_EF_Register")
 
        CSR_REG_W_BB("SSC_Saturation_limit_for_hue_limiter_GH_Register", DPE_SCC_BASE_OFFSET + 0xB8, g_csr_gen5_DPE_SCC_S_Hue_lim_GH_ST8_BS_REGISTER, "SCC_Saturation_limit_for_hue_limiter_GH_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_AB_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xBC, g_csr_gen5_DPE_SCC_IThresh_Hue_lim_AB_ST8_BS_REGISTER, "SCC_Intensity_thresh_AB_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_CD_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xC0, g_csr_gen5_DPE_SCC_IThresh_Hue_lim_CD_ST8_BS_REGISTER, "SCC_Intensity_thresh_CD_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_EF_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xC4, g_csr_gen5_DPE_SCC_IThresh_Hue_lim_EF_ST8_BS_REGISTER, "SCC_Intensity_thresh_EF_for_hue_limiter_Register")

	 CSR_REG_W_BB("SCC_Intensity_thresh_GH_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xC8, g_csr_gen5_DPE_SCC_IThresh_Hue_lim_GH_ST8_BS_REGISTER, "SCC_Intensity_thresh_GH_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_AB_BC_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xCC, g_csr_gen5_DPE_SCC_ISlope_Hue_lim_AB_BC_ST8_BS_REGISTER, "SCC_Saturation_slope_AB_BC_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_CD_DE_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xD0, g_csr_gen5_DPE_SCC_ISlope_Hue_lim_CD_DE_ST8_BS_REGISTER, "SCC_Saturation_slope_CD_DE_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_ED_FG_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xD4, g_csr_gen5_DPE_SCC_ISlope_Hue_lim_EF_FG_ST8_BS_REGISTER, "SCC_Saturation_slope_EF_FG_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_GH_for_hue_limiter_Register", DPE_SCC_BASE_OFFSET + 0xD8, g_csr_gen5_DPE_SCC_ISlope_Hue_lim_GH_ST8_BS_REGISTER, "SCC_Saturation_slope_GH_for_hue_limiter_Register")
 
        CSR_REG_W_BB("SCC_I_limit_for_hue_limiter_AB_Register", DPE_SCC_BASE_OFFSET + 0xDC, g_csr_gen5_DPE_SCC_I_Hue_lim_AB_ST8_BS_REGISTER, "SCC_I_limit_for_hue_limiter_AB_Register")
 
        CSR_REG_W_BB("SCC_I_limit_for_hue_limiter_CD_Register", DPE_SCC_BASE_OFFSET + 0xE0, g_csr_gen5_DPE_SCC_I_Hue_lim_CD_ST8_BS_REGISTER, "SCC_I_limit_for_hue_limiter_CD_Register")
 
        CSR_REG_W_BB("SCC_I_limit_for_hue_limiter_EF_Register", DPE_SCC_BASE_OFFSET + 0xE4, g_csr_gen5_DPE_SCC_I_Hue_lim_EF_ST8_BS_REGISTER, "SCC_I_limit_for_hue_limiter_EF_Register")
 
        CSR_REG_W_BB("SCC_I_limit_for_hue_limiter_GH_Register", DPE_SCC_BASE_OFFSET + 0xE8, g_csr_gen5_DPE_SCC_I_Hue_lim_GH_ST8_BS_REGISTER, "SCC_I_limit_for_hue_limiter_GH_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_AB_for_Sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0xEC, g_csr_gen5_DPE_SCC_SThresh_Sat_lim_AB_ST8_BS_REGISTER, "SCC_Saturation_thresh_AB_for_Sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_CD_for_Sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0xF0, g_csr_gen5_DPE_SCC_SThresh_Sat_lim_CD_ST8_BS_REGISTER, "SCC_Saturation_thresh_CD_for_Sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_EF_for_Sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0xF4, g_csr_gen5_DPE_SCC_SThresh_Sat_lim_EF_ST8_BS_REGISTER, "SCC_Saturation_thresh_EF_for_Sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_GH_for_Sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0xF8, g_csr_gen5_DPE_SCC_SThresh_Sat_lim_GH_ST8_BS_REGISTER, "SCC_Saturation_thresh_GH_for_Sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_AB_BC_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0xFC, g_csr_gen5_DPE_SCC_SSlope_Sat_lim_AB_BC_ST8_BS_REGISTER, "SCC_Saturation_slope_AB_BC_for_sat_limiter_Register")

	CSR_REG_W_BB("SCC_Saturation_slope_CD_DE_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x100,g_csr_gen5_DPE_SCC_SSlope_Sat_lim_CD_DE_ST8_BS_REGISTER, "SCC_Saturation_slope_CD_DE_for_sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_EF_FG_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x104,g_csr_gen5_DPE_SCC_SSlope_Sat_lim_EF_FG_ST8_BS_REGISTER, "SCC_Saturation_slope_EF_FG_for_sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_GH_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x108,g_csr_gen5_DPE_SCC_SSlope_Sat_lim_GH_ST8_BS_REGISTER, "SCC_Saturation_slope_GH_for_sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_sat_limiter_AB_Register", DPE_SCC_BASE_OFFSET + 0x10C, g_csr_gen5_DPE_SCC_S_Sat_lim_AB_ST8_BS_REGISTER, "SCC_Saturation_limit_for_sat_limiter_AB_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_sat_limiter_CD_Register", DPE_SCC_BASE_OFFSET + 0x110, g_csr_gen5_DPE_SCC_S_Sat_lim_CD_ST8_BS_REGISTER, "SCC_Saturation_limit_for_sat_limiter_CD_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_sat_limiter_EF_Register", DPE_SCC_BASE_OFFSET + 0x114, g_csr_gen5_DPE_SCC_S_Sat_lim_EF_ST8_BS_REGISTER, "SCC_Saturation_limit_for_sat_limiter_EF_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_sat_limiter_GH_Register", DPE_SCC_BASE_OFFSET + 0x118, g_csr_gen5_DPE_SCC_S_Sat_lim_GH_ST8_BS_REGISTER, "SCC_Saturation_limit_for_sat_limiter_GH_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_AB_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x11C, g_csr_gen5_DPE_SCC_IThresh_Sat_lim_AB_ST8_BS_REGISTER, "SCC_Intensity_thresh_AB_for_sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_CD_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x120, g_csr_gen5_DPE_SCC_IThresh_Sat_lim_CD_ST8_BS_REGISTER, "SCC_Intensity_thresh_CD_for_sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_EF_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x124, g_csr_gen5_DPE_SCC_IThresh_Sat_lim_EF_ST8_BS_REGISTER, "SCC_Intensity_thresh_EF_for_sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_GH_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x128, g_csr_gen5_DPE_SCC_IThresh_Sat_lim_GH_ST8_BS_REGISTER, "SCC_Intensity_thresh_GH_for_sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_I_Slope_AB_BC_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x12C, g_csr_gen5_DPE_SCC_ISlope_Sat_lim_AB_BC_ST8_BS_REGISTER, "SCC_I_Slope_AB_BC_for_sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_I_Slope_CD_DE_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x130, g_csr_gen5_DPE_SCC_ISlope_Sat_lim_CD_DE_ST8_BS_REGISTER, "SCC_I_Slope_CD_DE_for_sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_I_Slope_EF_FG_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x134, g_csr_gen5_DPE_SCC_ISlope_Sat_lim_EF_FG_ST8_BS_REGISTER, "SCC_I_Slope_EF_FG_for_sat_limiter_Register")

	CSR_REG_W_BB("SCC_I_Slope_GH_for_sat_limiter_Register", DPE_SCC_BASE_OFFSET + 0x138, g_csr_gen5_DPE_SCC_ISlope_Sat_lim_GH_ST8_BS_REGISTER, "SCC_I_Slope_GH_for_sat_limiter_Register")
 
        CSR_REG_W_BB("SCC_I_Sat_limit_for_sat_limiter_AB_Register", DPE_SCC_BASE_OFFSET + 0x13C, g_csr_gen5_DPE_SCC_I_Sat_lim_AB_ST8_BS_REGISTER, "SCC_I_Sat_limit_for_sat_limiter_AB_Register")
 
        CSR_REG_W_BB("SCC_I_Sat_limit_for_sat_limiter_CD_Register", DPE_SCC_BASE_OFFSET + 0x140, g_csr_gen5_DPE_SCC_I_Sat_lim_CD_ST8_BS_REGISTER, "SCC_I_Sat_limit_for_sat_limiter_CD_Register")
 
        CSR_REG_W_BB("SCC_I_Sat_limit_for_sat_limiter_EF_Register", DPE_SCC_BASE_OFFSET + 0x144, g_csr_gen5_DPE_SCC_I_Sat_lim_EF_ST8_BS_REGISTER, "SCC_I_Sat_limit_for_sat_limiter_EF_Register")
 
        CSR_REG_W_BB("SCC_I_Sat_limit_for_sat_limiter_GH_Register", DPE_SCC_BASE_OFFSET + 0x148, g_csr_gen5_DPE_SCC_I_Sat_lim_GH_ST8_BS_REGISTER, "SCC_I_Sat_limit_for_sat_limiter_GH_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_AB_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x14C, g_csr_gen5_DPE_SCC_SThresh_INT_lim_AB_ST8_BS_REGISTER, "SCC_Saturation_thresh_AB_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_CD_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x150, g_csr_gen5_DPE_SCC_SThresh_INT_lim_CD_ST8_BS_REGISTER, "SCC_Saturation_thresh_CD_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_EF_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x154, g_csr_gen5_DPE_SCC_SThresh_INT_lim_EF_ST8_BS_REGISTER, "SCC_Saturation_thresh_EF_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_thresh_GH_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x158, g_csr_gen5_DPE_SCC_SThresh_INT_lim_GH_ST8_BS_REGISTER, "SCC_Saturation_thresh_GH_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_AB_BC_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x15C, g_csr_gen5_DPE_SCC_SSlope_INT_lim_AB_BC_ST8_BS_REGISTER, "SCC_Saturation_slope_AB_BC_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_CD_DE_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x160, g_csr_gen5_DPE_SCC_SSlope_INT_lim_CD_DE_ST8_BS_REGISTER, "SCC_Saturation_slope_CD_DE_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_EF_FG_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x164, g_csr_gen5_DPE_SCC_SSlope_INT_lim_EF_FG_ST8_BS_REGISTER, "SCC_Saturation_slope_EF_FG_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Saturation_slope_GH_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x168, g_csr_gen5_DPE_SCC_SSlope_INT_lim_GH_ST8_BS_REGISTER, "SCC_Saturation_slope_GH_for_INT_limiter_Register")
	
	 CSR_REG_W_BB("SCC_Saturation_lim_for_INT_limiter_AB_Register", DPE_SCC_BASE_OFFSET + 0x16C, g_csr_gen5_DPE_SCC_S_INT_lim_AB_ST8_BS_REGISTER, "SCC_Saturation_lim_for_INT_limiter_AB_Register")
 
        CSR_REG_W_BB("SCC_Saturation_lim_for_INT_limiter_CD_Register", DPE_SCC_BASE_OFFSET + 0x170, g_csr_gen5_DPE_SCC_S_INT_lim_CD_ST8_BS_REGISTER, "SCC_Saturation_lim_for_INT_limiter_CD_Register")
 
        CSR_REG_W_BB("SCC_Saturation_lim_for_INT_limiter_EF_Register", DPE_SCC_BASE_OFFSET + 0x174, g_csr_gen5_DPE_SCC_S_INT_lim_EF_ST8_BS_REGISTER, "SCC_Saturation_lim_for_INT_limiter_EF_Register")
 
        CSR_REG_W_BB("SCC_Saturation_lim_for_INT_limiter_GH_Register", DPE_SCC_BASE_OFFSET + 0x178, g_csr_gen5_DPE_SCC_S_INT_lim_GH_ST8_BS_REGISTER, "SCC_Saturation_lim_for_INT_limiter_GH_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_AB_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x17C, g_csr_gen5_DPE_SCC_IThresh_INT_lim_AB_ST8_BS_REGISTER, "SCC_Intensity_thresh_AB_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_CD_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x180, g_csr_gen5_DPE_SCC_IThresh_INT_lim_CD_ST8_BS_REGISTER, "SCC_Intensity_thresh_CD_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_EF_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x184, g_csr_gen5_DPE_SCC_IThresh_INT_lim_EF_ST8_BS_REGISTER, "SCC_Intensity_thresh_EF_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_Intensity_thresh_GH_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x188, g_csr_gen5_DPE_SCC_IThresh_INT_lim_GH_ST8_BS_REGISTER, "SCC_Intensity_thresh_GH_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_I_Slope_AB_BC_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x18C, g_csr_gen5_DPE_SCC_ISlope_INT_lim_AB_BC_ST8_BS_REGISTER, "SCC_I_Slope_AB_BC_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_I_Slope_CD_DE_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x190, g_csr_gen5_DPE_SCC_ISlope_INT_lim_CD_DE_ST8_BS_REGISTER, "SCC_I_Slope_CD_DE_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_I_Slope_EF_FG_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x194, g_csr_gen5_DPE_SCC_ISlope_INT_lim_EF_FG_ST8_BS_REGISTER, "SCC_I_Slope_EF_FG_for_INT_limiter_Register")
 
        CSR_REG_W_BB("SCC_I_Slope_GH_for_INT_limiter_Register", DPE_SCC_BASE_OFFSET + 0x198, g_csr_gen5_DPE_SCC_ISlope_INT_lim_GH_ST8_BS_REGISTER, "SCC_I_Slope_GH_for_INT_limiter_Register")

	 CSR_REG_W_BB("SCC_Saturation_limit_for_INT_limiter_AB_Register", DPE_SCC_BASE_OFFSET + 0x19C, g_csr_gen5_DPE_SCC_I_INT_lim_AB_ST8_BS_REGISTER, "SCC_Saturation_limit_for_INT_limiter_AB_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_INT_limiter_CD_Register", DPE_SCC_BASE_OFFSET + 0x1A0, g_csr_gen5_DPE_SCC_I_INT_lim_CD_ST8_BS_REGISTER, "SCC_Saturation_limit_for_INT_limiter_CD_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_INT_limiter_EF_Register", DPE_SCC_BASE_OFFSET + 0x1A4, g_csr_gen5_DPE_SCC_I_INT_lim_EF_ST8_BS_REGISTER, "SCC_Saturation_limit_for_INT_limiter_EF_Register")
 
        CSR_REG_W_BB("SCC_Saturation_limit_for_INT_limiter_GH_Register", DPE_SCC_BASE_OFFSET + 0x1A8, g_csr_gen5_DPE_SCC_I_INT_lim_GH_ST8_BS_REGISTER, "SCC_Saturation_limit_for_INT_limiter_GH_Register")
 
//-------------------------------------------SHARPNESS---------------------------------------------------------------------------------------//
                                                      
        CSR_REG_W_BB("SHRP_Stride_Height_Register",    DPE_SHRP_BASE_OFFSET + 0x0, g_csr_gen5_DPE_SHRP_N_Y_STRIDE_HEIGHT_REGISTER, "SHRP_Stride_Height_Register")

        CSR_REG_W_BB("SHRP_Stride_Width_Register",     DPE_SHRP_BASE_OFFSET + 0x4, g_csr_gen5_DPE_SHRP_N_Y_STRIDE_WIDTH_REGISTER, "SHRP_Stride_Width_Register")

        CSR_REG_W_BB("SHRP_Control_Register",  DPE_SHRP_BASE_OFFSET + 0x8, g_csr_gen5_DPE_SHRP_CONTROL_REGISTER, "SHRP_Control_Register")
        CSR_REG_W_BB("SHRP_H0_Coeff_01_Register",  DPE_SHRP_BASE_OFFSET + 0x10, g_csr_gen5_DPE_SHRP_H0_COEFF_01_REGISTER , "SHRP_H0_Coeff_01_Register")
        CSR_REG_W_BB("SHRP_H0_Coeff_23_Register",  DPE_SHRP_BASE_OFFSET + 0x14, g_csr_gen5_DPE_SHRP_H0_COEFF_23_REGISTER , "SHRP_H0_Coeff_23_Register")
        CSR_REG_W_BB("SHRP_H0_Coeff_45_Register",  DPE_SHRP_BASE_OFFSET + 0x18, g_csr_gen5_DPE_SHRP_H0_COEFF_45_REGISTER , "SHRP_H0_Coeff_45_Register")
        CSR_REG_W_BB("SHRP_H1_Coeff_01_Register",  DPE_SHRP_BASE_OFFSET + 0x1C, g_csr_gen5_DPE_SHRP_H1_COEFF_01_REGISTER , "SHRP_H1_Coeff_01_Register")
        CSR_REG_W_BB("SHRP_H1_Coeff_23_Register",  DPE_SHRP_BASE_OFFSET + 0x20, g_csr_gen5_DPE_SHRP_H1_COEFF_23_REGISTER , "SHRP_H1_Coeff_23_Register")
        CSR_REG_W_BB("SHRP_H1_Coeff_45_Register",  DPE_SHRP_BASE_OFFSET + 0x24, g_csr_gen5_DPE_SHRP_H1_COEFF_45_REGISTER , "SHRP_H1_Coeff_45_Register")
        CSR_REG_W_BB("SHRP_V0_Coeff_01_Register",  DPE_SHRP_BASE_OFFSET + 0x28, g_csr_gen5_DPE_SHRP_V0_COEFF_01_REGISTER , "SHRP_V0_Coeff_01_Register")
        CSR_REG_W_BB("SHRP_V0_Coeff_23_Register",  DPE_SHRP_BASE_OFFSET + 0x2C, g_csr_gen5_DPE_SHRP_V0_COEFF_23_REGISTER , "SHRP_V0_Coeff_23_Register")
        CSR_REG_W_BB("SHRP_V0_Coeff_4_Register",  DPE_SHRP_BASE_OFFSET + 0x30, g_csr_gen5_DPE_SHRP_V0_COEFF_4_REGISTER , "SHRP_V0_Coeff_4_Register")
        CSR_REG_W_BB("SHRP_V1_Coeff_01_Register",  DPE_SHRP_BASE_OFFSET + 0x34, g_csr_gen5_DPE_SHRP_V1_COEFF_01_REGISTER , "SHRP_V1_Coeff_01_Register")
        CSR_REG_W_BB("SHRP_V1_Coeff_23_Register",  DPE_SHRP_BASE_OFFSET + 0x38, g_csr_gen5_DPE_SHRP_V1_COEFF_23_REGISTER , "SHRP_V1_Coeff_23_Register")
        CSR_REG_W_BB("SHRP_V1_Coeff_4_Register",  DPE_SHRP_BASE_OFFSET + 0x3C, g_csr_gen5_DPE_SHRP_V1_COEFF_4_REGISTER , "SHRP_V1_Coeff_4_Register")
        CSR_REG_W_BB("SHRP_H0_H1_Gain_Register",  DPE_SHRP_BASE_OFFSET + 0x40, g_csr_gen5_DPE_SHRP_H0_H1_GAIN_REGISTER , "SHRP_H0_H1_GAIN_Register")
        CSR_REG_W_BB("SHRP_V0_V1_Gain_Register",  DPE_SHRP_BASE_OFFSET + 0x44, g_csr_gen5_DPE_SHRP_V0_V1_GAIN_REGISTER , "SHRP_V0_V1_GAIN_Register")
        CSR_REG_W_BB("SHRP_H0_H1_Clip_Register",  DPE_SHRP_BASE_OFFSET + 0x48, g_csr_gen5_DPE_SHRP_H0_H1_CLIP_REGISTER , "SHRP_H0_H1_Clip_Register")
        CSR_REG_W_BB("SHRP_V0_V1_Clip_Register",  DPE_SHRP_BASE_OFFSET + 0x4C, g_csr_gen5_DPE_SHRP_V0_V1_CLIP_REGISTER , "SHRP_V0_V1_Clip_Register")
        CSR_REG_W_BB("SHRP_H0_H1_Core_Register",  DPE_SHRP_BASE_OFFSET + 0x50, g_csr_gen5_DPE_SHRP_H0_H1_CORE_REGISTER , "SHRP_H0_H1_Core_Register")
        CSR_REG_W_BB("SHRP_V0_V1_Core_Register",  DPE_SHRP_BASE_OFFSET + 0x54, g_csr_gen5_DPE_SHRP_V0_V1_CORE_REGISTER , "SHRP_V0_V1_Core_Register")

//-----------------------------------------------------------------------------------------//
   CSR_NULL_TERM()    /* NULL terminator */
};

#endif /* !SVEN_INTERNAL_BUILD */


/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */

static const struct SVEN_Module_EventSpecific g_GEN5_DPE_specific_events[] =
{
    //not used
    { "MESSAGE_DPE_INIT", 1, "\tVPP get initialized!", NULL }, //hh add the event for init

	//used 1 time
    { "READ_INPUT_BUFFER", 2, "\tVPP Stream ID: %d, Buffer ID: 0x%x, U Addr: 0x%x, Y Addr: 0x%x, PTS/2: 0x%x, Polarity: %d", NULL }, //hh add the event for monitor input buffer

	//used 2 times
    { "WRITE_OUTPUT_BUFFER", 3, "\tVPP Stream ID: %d, Out Port: %d, In Buffer: 0x%x, Frames Out: %d, Out Buffer: 0x%x!, PTS/2 0x%x", NULL }, //hh add the event for monitor output buffer

	//used 1 time
    { "VPP_FW_START", 4, "\tVPP Core start FW!", NULL }, // add the event for fw start

	//used 1 time
    { "VPP_FW_RX", 5, "\tVPP Core received message from FW!", NULL }, //add the event for fw rx

	//used 1 time
    { "SPA", 6, "\tVPP fc:%d, iw:%d, ih:%d ow:%dk oh:%d, di:0x%x", NULL }, //add the event for calculate fw performance
                                                                //fc: time cycle for FW processing one frame
                                                                //ih: input height
                                                                //iw: input width
                                                                //oh: output height
                                                                //ow: output width
                                                                //di: stream id + deinterlace flag
                                                                // stream id [31-4]
                                                                // deinterlace flag [3-0]
                                                                // 0:di 1:i-bypass 2:p-bypass

	//used 1 time
    // { "FLUSH_START", 7, " VPP Flush start", NULL }, //add the event for flush start

	//used 1 time(s)
    { "FLUSH_STOP", 8, "\tVPP Flush stop", NULL }, //add the event for flush stop

	//used 1 time(s)
    { "FMD_DETECT", 9, "\tVPP Fmd detect", NULL }, //fmd detect

	//used 2 time(s)
    { "FMD_32", 10, "\tVPP Fmd 3:2 start", NULL }, //fmd 3:2 start

	//used 2 time(s)
    { "FMD_22", 11, "\tVPP Fmd 2:2 start", NULL }, //fmd 2:2 start

	//used 1 time(s)
    { "FMD_DUP", 12, "\tVPP Fmd dup", NULL }, //fmd duplicate

	//used 1 time(s)
    { "FMD_START", 13, "\tVPP Fmd start", NULL }, //fmd start

	//used 1 time(s)
    { "FMD_NEW", 14, "\tVPP Fmd start", NULL }, //fmd new frame

	//not used
    { "INTBUF_ALLOC", 15, "\tVPP int buf", NULL }, //intermediate buffer alloc

	//not used
    { "OUTBUF_ALLOC", 16, "\tVPP out buf", NULL }, //output buffer alloc

	//used 3 time(s)
    { "OUT_OF_MEMORY", 17, "\tVPP out of memory", NULL }, //out of memory event

	//used 1 time(s)
    { "LOOKAHEAD_READ_INPUT_BUF", 18, "\tVPP Read lookahead", NULL }, //out of memory event

	//used 1 time(s)
    { "BH_ISR_ENTER", 19, "\tVPP Bottom half ISR enter ", NULL }, //bottom half isr

	//used 1 time(s)
    { "CURRENT_INPUT_DEPTH", 20, "\tVPP Stream ID: 0x%06x Depth: %d, Status: 0x%x Mask: 0x%x, (prior depth: %d)", NULL }, //depth of the input port

	//used 1 time(s)
    { "METADATA_PAN_SCAN", 21, "\tVPP Stream ID: 0x%06x Field: %d, V Offset: %d, H Offset: %d, V Size: %d, H Size: %d", NULL }, //depth of the input port

	 { "CLIENT_ID_IN",      22, "\tStream ID: 0x%06x Port ID: %d id: %d", NULL},

	 { "CLIENT_ID_OUT",     23, "\tStream ID: 0x%06x Port ID: %d id: %d", NULL},

	 { "EOS_IN",            24, "\tStream ID: 0x%06x Port ID: %d", NULL},

	 { "EOS_OUT",           25, "\tStream ID: 0x%06x Port ID: %d", NULL},

	 { "BUFFER_DEREF_FAIL", 26, "\tBuffer ID: %d", NULL},

	 { "BUFFER_DEREF",      27, "\tBuffer ID: %d", NULL},

	 { "BUFFER_ADDREF_FAIL", 28, "\tBuffer ID: %d", NULL},

	 { "BUFFER_ADDREF",      29, "\tBuffer ID: %d", NULL},

	 { "INPUT_PORT_EVENT",   30, "\tStream ID: %d; Level %d", NULL},

	 { "OUTPUT_PORT_EVENT",  31, "\tStream ID: %d; Level %d", NULL},
         
         {"INTIAL_INPUT_BUFFER_READ_TIME", 32, "\tStream ID: 0x%06x; Buffer: %d; PTS/2: 0x%08x; Polarity: %d; Repeat Flag: %d; Content Rate: %d", NULL},

	 {"INTIAL_INPUT_BUFFER_READ_SIZE", 33, "\tStream ID: 0x%06x; Buffer: %d; Aspect Ratio: %d:%d; Size(WxH): %dx%d", NULL},

	 {"OUTPUT_BUFFER_WRITE", 34, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d", NULL},

	 {"OUTPUT_NON_FRAME_BUFFER", 35, "\tStream ID: 0x%06x; Buffer: %d", NULL},

	 {"QUEUE_WORK_ITEM", 36, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d; Flags 0x%08x", NULL},

	 {"SEND_FRAME_TO_FW_WORK", 37, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d; Flags 0x%08x", NULL},

	 {"INTIAL_INPUT_BUFFER_READ_TIME", 32, "\tStream ID: 0x%06x; Buffer: %d; PTS/2: 0x%08x; Polarity: %d; Repeat Flag: %d; Content Rate: %d", NULL},

	 {"INTIAL_INPUT_BUFFER_READ_SIZE", 33, "\tStream ID: 0x%06x; Buffer: %d; Aspect Ratio: %d:%d; Size(WxH): %dx%d", NULL},

	 {"OUTPUT_BUFFER_WRITE", 34, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d", NULL},

	 {"OUTPUT_NON_FRAME_BUFFER", 35, "\tStream ID: 0x%06x; Buffer: %d", NULL},

	 {"QUEUE_WORK_ITEM", 36, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d; Flags 0x%08x", NULL},

	 {"SEND_FRAME_TO_FW_WORK", 37, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d; Flags 0x%08x", NULL},

    {"FW_SOURCE_RECTANGE", 38, "\tStream ID: 0x%06x; Destination Buffer: %d; Start (%d, %d); End (%d, %d)", NULL},

    {"FW_DEST_RECTANGE", 39, "\tStream ID: 0x%06x; Destination Buffer: %d; Start (%d, %d); End (%d, %d)", NULL},

    {"GET_FRAME_FROM_FW_WORK", 40, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d; Flags 0x%08x", NULL},  

    {"READ_IN_BUFFER", 41, "\tStream ID: 0x%06x Port: %d, Buffer: %d, PTS/2: 0x%08x", NULL},

    {"INTIAL_INPUT_BUFFER_READ_COLOR", 42, "\tStream ID: 0x%06x; Buffer: %d; Color Space: %d; Gamma: %d; Pixel Format: %d", NULL},

    //50-59 reserved for FW Params
    {"FW_PARAMS_IN_RECT_POINTS", 50, "\tTop Left:(%d, %d) Bottom Right:(%d, %d)", NULL},
    {"FW_PARAMS_IN_RECT_SIZE", 51, "\tWidth: %d; Height: %d; Stride: %d", NULL},
    {"FW_PARAMS_OUT_RECT_POINTS", 52, "\tTop Left:(%d,%d); Bottom Right:(%d, %d)", NULL},
    {"FW_PARAMS_OUT_RECT_SIZE", 53, "\tWidth: %d; Height: %d; Stride: %d", NULL},
    {"FW_PARAMS_FLAGS", 54, "\tGeneral: 0x%08x; HSC/VSC: 0x%08x; App:0x%08x", NULL},
    {"FW_PARAMS_SETTINGS", 55, "\tNRF Level %d; FMD Mode: %d; MAD Threshold Delta: %d", NULL},
    {"FW_PARAMS_DI_WEIGHTS", 56, "\tMAD Post: %d; MAD Pre: %d; SAD Post: %d; SAD Pre 1: %d; SAD Pre 2: %d", NULL},
    {"FW_PARAMS_SHIFTS", 57, "\tHSC Y: %d; HSC UV: %d; VSC Y: %d; VSC UV1: %d", NULL},
    {"FW_PARAMS_BUFFERS", 58, "\tDI N-1: 0x%x; DI N: 0x%x; DI N+1: 0x%x; MH N-1: 0x%x; MH N: 0x%x", NULL},

	#include "../ismd_standard_events.c"
	// Each module can define it's own OPEN event (103), but it should always have the form:
	//{"OPEN",                103, "\tStream ID: 0x%06x In Port ID: %d, Out Port ID: %d <additional init parameters here>", NULL},
	{"OPEN",                103, "\tStream ID: 0x%06x In Port ID: %d, Out Port ID: %d", NULL},

    { NULL, 0, "", NULL }
};

static const struct ModuleReverseDefs g_GEN5_DPE_sven_module =
{
    "GEN5_DPE",
    SVEN_module_GEN5_DPE,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen5_GEN5_DPE,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: DPE Function (GEN5)",
    g_GEN5_DPE_specific_events,
    NULL                            /* extension list */
};
