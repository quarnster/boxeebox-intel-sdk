/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/****** Global registers ******/

static const struct EAS_RegBits g_csr_GEN5_TSI_OC_MODE_REGISTER[] =
{
     { "RESERVED_31_3", 3, 29 }, /* Reserved */
     { "OCCRCI",        2, 1  }, /* OpenCable Header Field CRC Init Value(OCCRCI) FFH-1, 00H 0 */
     { "OCCE",          1, 1  }, /* OpenCable CableCARD bypass 1: internal bypass - 0: normal operation */
     { "OCSSE",         0, 1  }, /* OpenCable Single-Stream Enable(OCSSE) SS-1, MS-0 */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_MAGIC_PACKET_REGISTER[] =
{
     { "EN",            31, 1  }, /* Enable */
     { "MAGIC_COUNT",   16, 15 }, /* Number of magic packets to generate wakeup */
     { "RESERVED_15",   15, 1  }, /* Rserved bit */
     { "MAGIC_PID",      0, 15 }, /* PID value of magic packet */
     {NULL}
};

static const struct EAS_RegBits g_csr_GEN5_TSI_CHIPWATCHER_SELECT_REGISTER[] =
{
     { "RESERVED_31_4",  4, 28 },  /* Reserved */
     { "CWSELECT3",      3, 1  },  /* 0: select prefilter 3 chipwatcher signals 1: select prefilter 7 chipwatcher signals */
     { "CWSELECT2",      2, 1  },  /* 0: select prefilter 2 chipwatcher signals 1: select prefilter 6 chipwatcher signals */
     { "CWSELECT1",      1, 1  },  /* 0: select prefilter 1 chipwatcher signals 1: select prefilter 5 chipwatcher signals */
     { "CWSELECT0",      0, 1  },  /* 0: select prefilter 0 chipwatcher signals 1: select prefilter 4 chipwatcher signals */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_CE_CONFIG_TX_REGISTER[] =
{
     { "RESERVED_31_11",11, 21 },  /* Reserved */
     { "DV_PTS",        10, 1  },  /* DV_PTS = Select what transmit timing control method is used for DV. Only valid in DV mode. 0: Use DV frame and packet interval counter for transmit timing control. 1: Use timestamp for transmit timing control  */
     { "TSHDR_FMT",      9, 1  },  /* Transport Stream Time Stamp Header Format : 0 : All 32 bits are used as time stamp 1 : The lower 30 bits are used as time stamp and the upper 2 bits are ignored when comparing with local transmit timebase counter */
     { "TX_MODE",        6, 3  },  /* Transmit CE interface mode: 000: Interface disabled 001: Mpeg TS mode 010: DirecTV mode 100: DV SD mode 101: DV HD mode */
     { "SYNC_LEN",       4, 2  },  /* CE TX Interface Packet SYNC (1394_OSYNC) mode : 00: Pulse marking the first bit of the first byte of the DIF packer; 01: Pulse marking the first byte of the DIF packer; 10: level covering the entire DIF packet from the first bit of the first byte to the last bit of the last byte. */
     { "ODAV_POL",       3, 1  },  /* CE TX Interface Data Valid output (1394_ODAV) polarity: 0: active high, 1: active low */
     { "OENABL_POL",     2, 1  },  /* CE TX Interface Packet Enable/Error output (1394_OENABLE) polarity: 0: active high, 1: active low */
     { "OSYNC_POL",      1, 1  },  /* CE TX Interface Packet SYNC output (1394_OSYNC) polarity. 0: active high, 1: active low */
     { "OCLK_EDGE",      0, 1  },  /* CE TX Interface Clock sampling edge: 0: rising edge, 1: falling edge */
     {NULL}
};

static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_PMM0_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};



static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_CFG_REGISTER[] =
{
     { "RESERVED_31_29", 29, 3  }, /* Reserved */
     { "OC_PKT_SIZE_SEL",28, 1  }, /* Open cable mode packet size select method (Only valid when OCEN is 1�b1): 0: Packet size is the actual number of bytes received from the prefilter NIM input. 1: Packet size is the programmed size from �Mode� (bits 2:1). This must be used if the stream originates from the open cable input. */
     { "CP",             27, 1  }, /* Clock Polarity-When set, will invert the incoming NIM clock. */
     { "DP",             26, 1  }, /* Data Valid Polarity - When set, will invert the incoming NIM Data Valid signal. */
     { "EP",             25, 1  }, /* Error Polarity - When set, will invert the incoming NIM Error signal. */
     { "SP",             24, 1  }, /* Sync Polarity - When set, will invert the incoming NIM Sync signal. */
     { "STREAM_ID",      16, 8  }, /* When Open Cable Streams are being demultiplexed, which ID is processed by the PID Parser. */
     { "OCHDR_EN",       15, 1  }, /* Open Cable Header Enable (Only valid when OCEN is 1�b1): 1: Add the 12B Open Cable Header 0: Do not add the 12B Open Cable Header */
     { "OCHDR_RM",       14, 1  }, /* Open Cable Header Removal (Only valid when OCEN is 1b1): 0: Remove the 12B Open Cable Header 1: Do not remove the 12B Open Cable Header */
     { "OC_CRC_MSK",     13, 1  }, /* Open Cable CRC Mask (Only valid when OCEN is 1b1) 1: Ignore CRC errors 0: Discard OC packets with CRC */
     { "OCEN",           12, 1  }, /* Open Cable Enable 1 - The stream will go out on MSPOD output and come back from MSPOD input. 0 - The stream will bypass CableCARD */
     { "CC",             10, 2  }, /* When inserting 30-bit time stamp header, CC is copied to the upper 2 bits of the 32-bit header. */
     { "TSHDR_FMT",       9, 1  }, /* Time Stamp Header Format: 0: Add the 32-bit time stamp header based on RX timebase counter. 1: The lower 30 bit s of the header is used for timestamping and the upper 2 bits are copied from CC field.*/
     { "TSHDR_EN",        8, 1  }, /* Time Stamp Header Enable: 1: Add the 4B Time Stamp Header based on RX timebase counter 0: Do not add the 4B Time Stamp Header OCHDR_RM should be 1 if affing the header */
     { "PGT",             7, 1  }, /* Packet too Large Mask: 1: Forward larger than exptected packets 0: Discard larger than expected packets NOTE: when enabled, if the packet size is greater than 252 bytes, only the first 252 bytes will be forwarded to memory due to internal FIFO size limit.*/
     { "PLT",             6, 1  }, /* Packet too Small Mask: 1: Forward smaller than exptected packets 0: Discard smaller than expected packets */
     { "DAV_MSK",         5, 1  }, /* Ignore DAV state 1: Ignore the state of DAV when counting packet bytes 0: Ignore bytes when DAV is inactive (also see bit 26) */
     { "ERR_MSK",         4, 1  }, /* Stream Error mask 1: Stream ERROR signal is ignored 0: Stream ERROR signal is used */
     { "ENDIAN",          3, 1  }, /* Endianess: When set, the bytes on a DWord basis (4B) will be reversed.  SW/FW must ensure swapping does not corrupt non-4B data. 1: Endianess swapped when sending data to the system bus 0: Endianess not swapped */
     { "MODE",            1, 2  }, /* Incoming Transport Stream mode 00: DVB (188 byte packet) 01: DirectTV (130 byte packet) 10: OCAP (200-byte) 11: use variable packet size register */
     { "EN",              0, 1  }, /* Prefilter Enable 1: Enabled 0: Disables parsing of incoming packets */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_STATUS_REGISTER[] =
{
     { "RESERVED_31_12",  12, 20  }, /* Reserved */
     { "NIM_ERR",         11, 1  }, /* NIM error event detected*/
     { "DAV_LOW",         10, 1  }, /* NIM DAV low detected*/
     { "OCF",              9, 1  }, /* OpenCable FIFO Full*/
     { "CRC",              8, 1  }, /* OpenCable Header CRC Error*/
     { "DIS",              7, 1  }, /* PCR Discontinuity Detected The TStream had the discontinuity bit set in the PCR header*/
     { "DET",              6, 1  }, /* PCR Detected The TStream contains PCR information*/
     { "PPF",              5, 1  }, /* Packet Discard The internal FIFO used to stage the valid TStreams before sending to DDR dropped a packet due to overflow.*/
     { "WDT",              4, 1  }, /* NIM Watch Dog Timer Expired*/
     { "FE",               3, 1  }, /* DDR Memory Buffer Empty*/
     { "FF",               2, 1  }, /* DDR Memory Buffer  Full*/
     { "PLT",              1, 1  }, /* TStream Packet was less than the correct packet size */
     { "PGT",              0, 1  }, /* TStream Packet was greater than the correct packet size */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_ENABLE_REGISTER[] =
{
     { "RESERVED_31_12",  12, 20  }, /* Reserved */
     { "NIM_ERR",         11, 1  }, /* NIM error event enable*/
     { "DAV_LOW",         10, 1  }, /* NIM DAV low event Enable*/
     { "OCF",              9, 1  }, /* OpenCable FIFO Full Enable*/
     { "CRC",              8, 1  }, /* OpenCable Header CRC Error Enable*/
     { "DIS",              7, 1  }, /* PCR Discontinuity Detected Enable The TStream had the discontinuity bit set in the PCR header*/
     { "DET",              6, 1  }, /* PCR Detected Enable The TStream contains PCR information*/
     { "PPF",              5, 1  }, /* Packet Discard Interrupt Enable The internal FIFO used to stage the valid TStreams before sending to DDR is discarding a packet*/
     { "WDT",              4, 1  }, /* NIM Watch Dog Timer Expired Enable*/
     { "FE",               3, 1  }, /* DDR Memory Buffer Empty Enable*/
     { "FF",               2, 1  }, /* DDR Memory Buffer  Full Enble*/
     { "PLT",              1, 1  }, /* TStream Packet was less than the correct packet size enable */
     { "PGT",              0, 1  }, /* TStream Packet was greater than the correct packet size enable */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_FERR_STATUS_REGISTER[] =
{
     { "RESERVED_31_29", 29, 3  }, /* Reserved */
     { "FERR_VAL",       24, 5  }, /* Index of error causing FERR This field represents the bit position in the Prefilter X Status Register (offset 0x104) which caused FERR to assert.*/
     { "RESERVED_23_22", 22, 2  }, /* Reserved */
     { "PID",             8, 14 }, /* PID captured when FERR is set*/
     { "RESERVED_7_0",    0, 8  }, /* Index of error causing FERR This field represents the bit position in the Prefilter X Status Register (offset 0x104) which caused FERR to assert.*/
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_PKT_SIZE_REGISTER[] =
{
     { "RESERVED_31_8",   8, 24 }, /* Reserved */
     { "SIZE",            0, 8  }, /* Number of bytes per packet.  Maximum allowable byte count is 248B.  Setting this field above this value will result in unpredictable behavior.  The Minimum size is 32B.  The prefilter can only contain 2 packets before discard occurs. */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_PID_REPLACE_REGISTER[] =
{
     { "EN",             31, 1  }, /* Enable */
     { "NEW_PID",        16, 15 }, /* PID value to replace with*/
     { "RESERVED_15",    15, 1  }, /* Reserved bit */
     { "OLD_PID",         0, 15 }, /* PID value to be replaced */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_NIM_WDOG_TIMER_REGISTER[] =
{
     { "ENABLE", 31, 1  }, /* Enables the Watch Dog Timer */
     { "WDT",    0, 31  }, /* Watch Dog Timer Counter value*/
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_PCR_CONFIG_REGISTER[] =
{
     { "RESERVED_31_2", 1, 31 }, /* Reserved */
     { "ENABLE",        0, 1  }, /* PCR Enable. This bit enables PCR detection / extraction from the TS stream. The PID that carries the PCR information must be programmed into PID Mask / Match 0 register. */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_PCR_REMOTE_A1_REGISTER[] =
{
     { "PCRR_MSBA1",   31, 1  }, /* PCR MSB. This bit contains the 33rd bit (MSB) of the DVB PCR.*/
     { "RESERVED_30_17", 17, 14 }, /* Reserved */
     { "PCRR_LOCK",      16, 1 },  // must be written as zero by software to
                                   // allow an update by hardware
     { "RESERVED_15_9",  9, 7 },   // reserved
     { "PCRR_LSBSA1",    0, 9 }, /* These 9 bits are the Modulo 300 counter for the DVB PCR */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_OC_HEADER_CONFIG_REGISTER[] =
{
     { "RESERVED_31_30",  30, 2  }, /* Reserved */
     { "OCHS",            28, 2  }, /* OpenCable Header Select (OCHS) ={3,2,1,0} 3: OpenCable Dynamic Header Selected 2: OpenCable Static Header-2 Selected 1: OpenCable Static Header-1 Selected 0: OpenCable Static Header-0 Selected */
     { "RESERVED_27_10", 10, 18  }, /* Reserved */
     { "OCLTS",            9, 1  }, /* OpenCable LTS Field Enable(OCLTS), 1: Enable, LTS is inserted based on header selection and pfX_cfg.TSHDR_FMT. 0: Disable, all zeros are written into LTS field.*/
     { "RESERVED_8",       8, 1  }, /* Reserved */
     { "OCLTSID",          0, 8  }, /* OpenCable LTSID(OCLTSID), used w/ Dynamically allocated Header Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1 and so on */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_OC_HEADER_0A_REGISTER[] =
{
     { "OCLTSID",     24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",   8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0", 0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_OC_HEADER_1A_REGISTER[] =
{
     { "OCLTSID",      24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",    8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0",  0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_GEN5_TSI_PF0_OC_HEADER_2A_REGISTER[] =
{
     { "OCLTSID",     24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",   8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0", 0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_gen5_tsi_INTERRUPT[] =
{
    {"GEN5_reserved3",          25, 7, "Reserved", NULL},
    {"GEN5_COMPARE_SYS",        24, 1, "The running value in System Time counter matched the desired compare setting", NULL },
    {"GEN5_reserved2",          18, 6, "Reserved", NULL},
    {"GEN5_CAPTURE_SYT2",       17, 1, "The valid timestamp was captured in System Time capture register 2 (for received packets on Ethernet)", NULL },
    {"GEN5_CAPTURE_SYT1",       16, 1, "The valid timestamp was captured in System Time capture register 1 (for transmitted packets on Ethernet)", NULL},
    {"GEN5_reserved1",          14, 2, "Reserved", NULL},
    {"GEN5_COMPARE_6",          13, 1, "The running value in STC counter of Channel 6 matched the desired compare setting", NULL },
    {"GEN5_COMPARE_5",          12, 1, "The running value in STC counter of Channel 5 matched the desired compare setting", NULL },
    {"GEN5_COMPARE_4",          11, 1, "The running value in STC counter of Channel 4 matched the desired compare setting", NULL },
    {"GEN5_COMPARE_3",          10, 1, "The running value in STC counter of Channel 3 matched the desired compare setting", NULL },
    {"GEN5_COMPARE_2",           9, 1, "The running value in STC counter of Channel 2 matched the desired compare setting", NULL },
    {"GEN5_COMPARE_1",           8, 1, "The running value in STC counter of Channel 1 matched the desired compare setting", NULL },
    {"GEN5_reserved0",           0, 8, "Reserved", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};




#define GEN5_TSI_GLOBAL     0x00000
#define GEN5_TSI_0_BASE     0x02000

/****** Local Register definitions *****/

static const struct EAS_Register g_csr_gen5_tsi[] =
{
      {"GEN5_OC_MODE",                 GEN5_TSI_GLOBAL + 0x00, g_csr_GEN5_TSI_OC_MODE_REGISTER, "OpenCABLE Mode Config Register" },
      {"GEN5_MAGIC_PACKET",            GEN5_TSI_GLOBAL + 0x04, g_csr_GEN5_TSI_MAGIC_PACKET_REGISTER, "MAGIC PACKET Register" },
      {"GEN5_CW_SELECT",               GEN5_TSI_GLOBAL + 0x08, g_csr_GEN5_TSI_CHIPWATCHER_SELECT_REGISTER, "Chipwatch Select Register" },
      {"GEN5_CE_CONFIG_TX",            GEN5_TSI_GLOBAL + 0x44, g_csr_GEN5_TSI_CE_CONFIG_TX_REGISTER, "CE Transmit Configuration Register" },
      {"GEN5_CE_TX_TS_CNT",            GEN5_TSI_GLOBAL + 0xC0, NULL, "CE Transmit Timestamp Counter" },

      // There are 32 PMM registers, all the same as PMM0
      {"GEN5_PFX_0_PMM0",              GEN5_TSI_0_BASE + 0x0, g_csr_GEN5_TSI_PF0_PMM0_REGISTER, "Mask/Match register" },

      {"GEN5_PFX_0_CFG",               GEN5_TSI_0_BASE + 0x100, g_csr_GEN5_TSI_PF0_CFG_REGISTER, "Prefilter Config register" },
      {"GEN5_PFX_0_STATUS",            GEN5_TSI_0_BASE + 0x104, g_csr_GEN5_TSI_PF0_STATUS_REGISTER, "Prefilter status register" },
      {"GEN5_PFX_0_ENABLE",            GEN5_TSI_0_BASE + 0x108, g_csr_GEN5_TSI_PF0_ENABLE_REGISTER, "Prefilter enable register" },
      {"GEN5_PFX_0_FERR_STATUS",       GEN5_TSI_0_BASE + 0x10c, g_csr_GEN5_TSI_PF0_FERR_STATUS_REGISTER, "Prefilter FERR status register" },
      {"GEN5_PFX_0_PKT_SIZE",          GEN5_TSI_0_BASE + 0x110, g_csr_GEN5_TSI_PF0_PKT_SIZE_REGISTER, "Prefilter Variable Packet Size" },
      {"GEN5_PFX_0_PID_REPLACE",       GEN5_TSI_0_BASE + 0x114, g_csr_GEN5_TSI_PF0_PID_REPLACE_REGISTER, "Prefilter X pid replace" },

      {"GEN5_PFX_0_DMA_BASE",          GEN5_TSI_0_BASE + 0x200, NULL, "Prefilter DMA Base" },
      {"GEN5_PFX_0_DMA_SIZE",          GEN5_TSI_0_BASE + 0x204, NULL, "Prefilter DMA Size" },
      {"GEN5_PFX_0_DMA_WR_PTR",        GEN5_TSI_0_BASE + 0x208, NULL, "Prefilter DMA Write Pointer" },
      {"GEN5_PFX_0_DMA_SHDW_WR_PTR_ADDR", GEN5_TSI_0_BASE + 0x20c, NULL, "Prefilter DMA Shadow Write Pointer Address" },
      {"GEN5_PFX_0_DMA_RD_PTR",        GEN5_TSI_0_BASE + 0x210, NULL, "Prefilter DMA Read Pointer" },
      {"GEN5_PFX_0_DMA_SHDW_WR_CTR",   GEN5_TSI_0_BASE + 0x214, NULL, "Prefilter DMA Shadow Write Counter" },
      {"GEN5_PFX_0_NIM_WDT",           GEN5_TSI_0_BASE + 0x218, g_csr_GEN5_TSI_PF0_NIM_WDOG_TIMER_REGISTER, "Prefilter NIM Watch Dog Timer" },

      {"GEN5_PFX_0_PCR_CFG",           GEN5_TSI_0_BASE + 0x300, g_csr_GEN5_TSI_PF0_PCR_CONFIG_REGISTER, "Prefilter PCR Config" },
      {"GEN5_PFX_0_PCR_REMOTE_A0",     GEN5_TSI_0_BASE + 0x31c, NULL, "Prefilter PCR Remote A0" },
      {"GEN5_PFX_0_PCR_REMOTE_A1",     GEN5_TSI_0_BASE + 0x320, g_csr_GEN5_TSI_PF0_PCR_REMOTE_A1_REGISTER, "Prefilter PCR Remote A1" },

      {"GEN5_PFX_0_OC_HEADER_CFG",     GEN5_TSI_0_BASE + 0x340, g_csr_GEN5_TSI_PF0_OC_HEADER_CONFIG_REGISTER, "Prefilter OC Header Config" },
      {"GEN5_PFX_0_OC_HEADER_0A",      GEN5_TSI_0_BASE + 0x344, g_csr_GEN5_TSI_PF0_OC_HEADER_0A_REGISTER,   "Prefilter OC Header-A0" },
      {"GEN5_PFX_0_OC_HEADER_0B",      GEN5_TSI_0_BASE + 0x348, NULL, "Prefilter OC Header-B0" },
      {"GEN5_PFX_0_OC_HEADER_1A",      GEN5_TSI_0_BASE + 0x34C, g_csr_GEN5_TSI_PF0_OC_HEADER_1A_REGISTER,   "Prefilter OC Header-A1" },
      {"GEN5_PFX_0_OC_HEADER_1B",      GEN5_TSI_0_BASE + 0x350, NULL, "Prefilter OC Header-B1" },
      {"GEN5_PFX_0_OC_HEADER_2A",      GEN5_TSI_0_BASE + 0x354, g_csr_GEN5_TSI_PF0_OC_HEADER_2A_REGISTER,   "Prefilter OC Header-A2" },
      {"GEN5_PFX_0_OC_HEADER_2B",      GEN5_TSI_0_BASE + 0x358, NULL, "Prefilter OC Header-B2" },

      {"GEN5_PFX_0_TIMESTAMP_CTR",     GEN5_TSI_0_BASE + 0x400, NULL, "Prefilter time stamp counter" },

      {NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct SVEN_Module_EventSpecific g_gen5_tsi_specific_events[] =
{
    { "BUFFER_FULL",     1,      " Context %d's output buffer is full!", NULL },
    { "PACKET_LOSS",     2,      " Context %d dropped a buffer!", NULL },
    { "OC_FIFO_FULL",    3,      " Context %d's OpenCable FIFO is full!", NULL },
    { "OC_CRC",          4,      " Context %d had an OpenCable header CRC error!", NULL },
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_gen5_tsi_sven_module =
{
    "GEN5_TSI",
    SVEN_module_GEN5_PREFILT,
    0x0000C000,                  /* CSR Space is 0x4000 in size.  Filters range from 0x4000 to 0xC000*/
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen5_tsi,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "TSI: Fifth Generation Prefilter Unit",
    g_gen5_tsi_specific_events,
    NULL /* extension list */
};
