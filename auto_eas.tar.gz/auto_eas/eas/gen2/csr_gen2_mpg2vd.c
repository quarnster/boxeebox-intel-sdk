/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
//
// NOTE: Struct of bits are defined in csr_vr_mpg2vd.c

/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MPG2VD_versions.
 */
static const struct EAS_Register g_csr_GEN1_MPG2VD[] =
{
    /* GLOBAL TOP LEVEL REGISTERS */
    CSR_REG("MDRC",        0x000, "Reset MPEG2 Decoder Data path")
    CSR_REG_W_BB("SED",    0x004, g_csr_MPG2VD_SED, "Stream Enable/Disable")
    CSR_REG_W_BB("SAS",    0x008, g_csr_MPG2VD_Streams, "Stream Active Status")
    CSR_REG_W_BB("SDEMC",  0x00c, g_csr_MPG2VD_SDEMC,   "Stream DMA Engine Master Control")
    CSR_REG_W_BB("IM0",    0x010, g_csr_MPG2VD_Interupts, "Interrupt Mask Stream 0")
    CSR_REG_W_BB("IM1",    0x014, g_csr_MPG2VD_Interupts, "Interrupt Mask Stream 1")
    CSR_REG_W_BB("IS",     0x018, g_csr_MPG2VD_Streams, "Interrupt Status")
    CSR_REG_W_BB("IS0",    0x01c, g_csr_MPG2VD_Interupts, "Interrupt Status Stream 0")
    CSR_REG_W_BB("IS1",    0x020, g_csr_MPG2VD_Interupts, "Interrupt Status Stream 0")
    CSR_REG("INTCR0",      0x024, "Interrupt Counter Stream 0")
    CSR_REG("INTCR1",      0x028, "Interrupt Counter Stream 1")
    CSR_REG_W_BB("PWRSED", 0x030, g_csr_MPG2VD_Streams, "Stream Enable(1)/Disable(0) for (VR) Power Savings ") // Not in Olo

    /* STREAM 0 - ELEMENTARY STREAM DECODER REGISTERS */
    CSR_REG_W_BB("S0CC",   0x100, g_csr_MPG2VD_CoreControl, "Decoder 0 Core Control")
    CSR_REG_W_BB("S0SM",   0x104, g_csr_MPG2VD_StallMask, "Decoder 0 Core Stall Mask")
    CSR_REG_W_BB("S0SS",   0x108, g_csr_MPG2VD_StallMask, "Decoder 0 Core Stall Status")
    CSR_REG_W_BB("S0SC",   0x10c, g_csr_MPG2VD_StallControl, "Decoder 0 Core Stall Control")
    CSR_REG("S0ASDBC",     0x110, "Decoder 0 Core Additional Stream Data Buffer Configuration")
    CSR_REG("S0ASDFP",     0x114, "Decoder 0 Core Additional Stream Data Front Pointer")
    CSR_REG("S0ASDBP",     0x118, "Decoder 0 Core Additional Stream Data Back Pointer")
    CSR_REG("S0ASDR",      0x11c, "Decoder 0 Core Additional Stream Data Read")
    CSR_REG("S0SI1",       0x120, "Decoder 0 Core Sequence Info 1")
    CSR_REG("S0SI2",       0x124, "Decoder 0 Core Sequence Info 2")
    CSR_REG("S0SI3",       0x128, "Decoder 0 Core Sequence Info 3")
    CSR_REG("S0SI4",       0x12c, "Decoder 0 Core Sequence Info 4")
    CSR_REG("S0PI1",       0x130, "Decoder 0 Core Picture Info 1")
    CSR_REG("S0PI2",       0x134, "Decoder 0 Core Picture Info 2")
    CSR_REG("S0PI3",       0x138, "Decoder 0 Core Picture Info 3")
    CSR_REG("S0PCE",       0x13c, "Decoder 0 Core Picture Coding Extension with Composite Display Flag Set")
    CSR_REG("S0SDE1",      0x140, "Decoder 0 Core Sequence Display Extension 1")
    CSR_REG("S0SDE2",      0x144, "Decoder 0 Core Sequence Display Extension 2")
    CSR_REG("S0GH",        0x148, "Decoder 0 Core GOP Header")

    /* STREAM 1 - ELEMENTARY STREAM DECODER REGISTERS */
    CSR_REG_W_BB("S1CC",   0x180, g_csr_MPG2VD_CoreControl, "Decoder 1 Core Control")
    CSR_REG_W_BB("S1SM",   0x184, g_csr_MPG2VD_StallMask, "Decoder 1 Core Stall Mask")
    CSR_REG_W_BB("S1SS",   0x188, g_csr_MPG2VD_StallMask, "Decoder 1 Core Stall Status")
    CSR_REG_W_BB("S1SC",   0x18c, g_csr_MPG2VD_StallControl, "Decoder 1 Core Stall Control")
    CSR_REG("S1ASDBC",     0x190, "Decoder 1 Core Additional Stream Data Configuration")
    CSR_REG("S1ASDFP",     0x194, "Decoder 1 Core Additional Stream Data Front Pointer")
    CSR_REG("S1ASDBP",     0x198, "Decoder 1 Core Additional Stream Data Back Pointer")
    CSR_REG("S1ASDR",      0x19c, "Decoder 1 Core Additional Stream Data Read")
    CSR_REG("S1SI1",       0x1a0, "Decoder 1 Core Sequence Info 1")
    CSR_REG("S1SI2",       0x1a4, "Decoder 1 Core Sequence Info 2")
    CSR_REG("S1SI3",       0x1a8, "Decoder 1 Core Sequence Info 3")
    CSR_REG("S1SI4",       0x1ac, "Decoder 1 Core Sequence Info 4")
    CSR_REG("S1PI1",       0x1b0, "Decoder 1 Core Picture Info 1")
    CSR_REG("S1PI2",       0x1b4, "Decoder 1 Core Picture Info 2")
    CSR_REG("S1PI3",       0x1b8, "Decoder 1 Core Picture Info 3")
    CSR_REG("S1PCE",       0x1bc, "Decoder 1 Core Picture Coding Extension with Composite Display Flag Set")
    CSR_REG("S1SDE1",      0x1c0, "Decoder 1 Core Sequence Display Extension 1")
    CSR_REG("S1SDE2",      0x1c4, "Decoder 1 Core Sequence Display Extension 2")
    CSR_REG("S1GH",        0x1c8, "Decoder 1 Core GOP Header")

    /* STREAM 0 - FRAME BUFFER MANAGER REGISTERS */
    CSR_REG("FBM0BE",      0x200, "FBM Master Buffer Enables")
    CSR_REG("FBM0PAP",     0x204, "FBM Buffer Pool Address Pointer")
    CSR_REG("FBM0YBA",     0x208, "FBM Y Buffer Address")
    CSR_REG("FBM0UVBA",    0x20c, "FBM UV Buffer Address")
    CSR_REG("FBM0PYBA",    0x210, "FBM PIP Y Buffer Address")
    CSR_REG("FBM0PUVBA",   0x214, "FBM PIP UV Buffer Address")
    CSR_REG_W_BB("FBM0BI", 0x218, g_csr_FBM_BufferInfo,   "FBM Buffer Info")
    CSR_REG_W_BB("FBM0BRI",0x21c, g_csr_FBM_BufferResInfo, "FBM Buffer Resolution Info")
    CSR_REG("FBM0GC",      0x220, "FBM General Control")
    CSR_REG("FBM0TDR",     0x224, "FBM Tracker Display Queue Release")
    CSR_REG_W_BB("FBM0DQS",0x228, g_csr_FBM_DisplayQueueStatus, "FBM Display Queue Status")
    CSR_REG("FBM0DQPO",    0x22c, "FBM Display Queue Entries")
    CSR_REG("FBM0PTSC",    0x230, "FBM PTS Control")
    CSR_REG("FBM0PTVM",    0x234, "FBM PTS Table (MSB)")
    CSR_REG("FBM0PTVL",    0x238, "FBM PTS Table (LSB)")
    CSR_REG("FBM0PTSOM",   0x23c, "FBM PTS Offset (MSB)")
    CSR_REG("FBM0PTSOL",   0x240, "FBM PTS Offset (LSB)")
    CSR_REG("FBM0PTSAM",   0x244, "FBM PTS Accum Init Value (MSB)")
    CSR_REG("FBM0PTSAL",   0x248, "FBM PTS Accum Init Value (LSB)")
    CSR_REG("FBM0PTSASM",  0x24c, "FBM PTS Accum Step Size (MSB)")
    CSR_REG("FBM0PTSASL",  0x250, "FBM PTS Accum Step Size (LSB)")
    CSR_REG("FBM0DYR",     0x254, "FBM Destination Y Buffer Register Address")
    CSR_REG("FBM0DUVR",    0x258, "FBM Destination UV Buffer Register Address")
    CSR_REG("FBM0DFMR",    0x25c, "FBM Destination flip mode Register Address")
    CSR_REG("FBM0NDB",     0x260, "FBM Next Display Buffer")
    CSR_REG("FBM0NDBR",    0x264, "FBM Next Display Buffer Resolution")
    CSR_REG("FBM0PSCO1",   0x268, "FBM Pan Scan Frame Center Offset 1")
    CSR_REG("FBM0PSCO2",   0x26c, "FBM Pan Scan Frame Center Offset 2")
    CSR_REG("FBM0PSCO3",   0x270, "FBM Pan Scan Frame Center Offset 3")
    CSR_REG("FBM0SQY",     0x274, "FBM Software Queue Y Address")
    CSR_REG("FBM0SQUV",    0x278, "FBM Software Queue UV Address")
    CSR_REG("FBM0SQPM",    0x27c, "FBM Software Queue PTS Value (MSB)")
    CSR_REG("FBM0SQPL",    0x280, "FBM Software Queue PTS value (LSB)")
    CSR_REG("FBM0FQCS",    0x284, "FBM Buffer Software Queue Control Status")
    CSR_REG("FBM0BDRI",    0x288, "FBM Buffer Display Resolution Info")
    CSR_REG("FBM0YVPRA",   0x28C, "FBM Destination Y Vertical Phase Register Address")
    CSR_REG("FBM0SQYVP",   0x290, "FBM Software Queue Y Vertical Phase")
    CSR_REG("FBM0DUVUPR",  0x294, "FBM Destination UV Vertical Phase Register")
    CSR_REG("FBM0SQUVVP",  0x298, "FBM Software Queue UV Vertical Phase")
    CSR_REG("FBM0DHPRA",   0x29C, "FBM Destination Horizontal Phase Register Address")
    CSR_REG("FBM0SQHP",    0x2A0, "FBM Software Queue Horizontal Phase")
    CSR_REG("FBM0DIPSR",   0x2A4, "FBM Destination Initial Phase Shift Register")
    CSR_REG("FBM0SQIPS",   0x2A8, "FBM Software Queue Initial Phase Shift")

    /* STREAM 1 - FBM REGISTERS */
    CSR_REG("FBM1BE",      0x300, "FBM Master Buffer Enables")
    CSR_REG("FBM1PAP",     0x304, "FBM Buffer Pool Address Pointer")
    CSR_REG("FBM1YBA",     0x308, "FBM Y Buffer Address")
    CSR_REG("FBM1UVBA",    0x30c, "FBM UV Buffer Address")
    CSR_REG("FBM1PYBA",    0x310, "FBM PIP Y Buffer Address ")
    CSR_REG("FBM1PUVBA",   0x314, "FBM PIP UV Buffer Address ")
    CSR_REG_W_BB("FBM1BI", 0x318, g_csr_FBM_BufferInfo, "FBM Buffer Info")
    CSR_REG_W_BB("FBM1BRI",0x31c, g_csr_FBM_BufferResInfo, "FBM Buffer Resolution Info")
    CSR_REG("FBM1GC",      0x320, "FBM General Control")
    CSR_REG("FBM1TDR",     0x324, "FBM Tracker Display Queue Release")
    CSR_REG("FBM1DQS",     0x328, "FBM Display Queue Status")
    CSR_REG("FBM1DQPO",    0x32c, "FBM Display Queue Entries")
    CSR_REG("FBM1PTSC",    0x330, "FBM PTS Control")
    CSR_REG("FBM1PTVM",    0x334, "FBM PTS Table (MSB)")
    CSR_REG("FBM1PTVL",    0x338, "FBM PTS Table (LSB)")
    CSR_REG("FBM1PTSOM",   0x33c, "FBM PTS Offset (MSB)")
    CSR_REG("FBM1PTSOL",   0x340, "FBM PTS Offset (LSB)")
    CSR_REG("FBM1PTSAM",   0x344, "FBM PTS Accum Init Value (MSB)")
    CSR_REG("FBM1PTSAL",   0x348, "FBM PTS Accum Init Value (LSB)")
    CSR_REG("FBM1PTSASM",  0x34c, "FBM PTS Accum Step Size (MSB)")
    CSR_REG("FBM1PTSASL",  0x350, "FBM PTS Accum Step Size (LSB)")
    CSR_REG("FBM1DYR",     0x354, "FBM Destination Y Buffer Register Address")
    CSR_REG("FBM1DUVR",    0x358, "FBM Destination UV Buffer Register Address")
    CSR_REG("FBM1DFMR",    0x35c, "FBM Destination flip mode Register Address")
    CSR_REG("FBM1NDB",     0x360, "FBM Next Display Buffer")
    CSR_REG("FBM1NDBR",    0x364, "FBM Next Display Buffer Resolution")
    CSR_REG("FBM1PSCO1",   0x368, "FBM Pan Scan Frame Center Offset 1")
    CSR_REG("FBM1PSCO2",   0x36c, "FBM Pan Scan Frame Center Offset 2")
    CSR_REG("FBM1PSCO3",   0x370, "FBM Pan Scan Frame Center Offset 3")
    CSR_REG("FBM1SQY",     0x374, "FBM Software Queue Y Address")
    CSR_REG("FBM1SQUV",    0x378, "FBM Software Queue UV Address")
    CSR_REG("FBM1SQPM",    0x37c, "FBM Software Queue PTS Value (MSB)")
    CSR_REG("FBM1SQPL",    0x380, "FBM Software Queue PTS value (LSB)")
    CSR_REG("FBM1FQCS",    0x384, "FBM Buffer Software Queue Control Status")
    CSR_REG("FBM1BDRI",    0x388, "FBM Buffer Display Resolution Info")
    CSR_REG("FBM1DYVPRA",  0x38C, "FBM Destination Y Vertical Phase Register Address")
    CSR_REG("FBM1SQYVP",   0x390, "FBM Software Queue Y Vertical Phase")
    CSR_REG("FBM1DUVVPR",  0x394, "FBM Destination UV Vertical Phase Register")
    CSR_REG("FBM1SQUVVP",  0x398, "FBM Software Queue UV Vertical Phase")
    CSR_REG("FBM1DHPRA",   0x39C, "FBM Destination Horizontal Phase Register Address")
    CSR_REG("FBM1SQHP",    0x3A0, "FBM Software Queue Horizontal Phase")
    CSR_REG("FBM1DIPSR",   0x3A4, "FBM Destination Initial Phase Shift Register")
    CSR_REG("FBM1SQIPS",   0x3A8, "FBM Software Queue Initial Phase Shift")

    /* STREAM 0 - PES PACKET PARSER REGISTERS */
    CSR_REG("PPTCR0",      0x400, "PES Packet Parser 0 Timer Control Register")
    CSR_REG_W_BB("PPCR0",  0x404, g_csr_MPG2VD_PPCR, "PES Packet Parser 0 Control Register")
    CSR_REG("PPSR0",       0x408, "PES Packet Parser 0 Status Register")
    CSR_REG("PPIDR0",      0x40c, "PES Packet Parser 0 Status ID Register")
    CSR_REG("PPDR10",      0x410, "PES Packet Parser 0 Data Register 1")
    CSR_REG("PPDR20",      0x414, "PES Packet Parser 0 Data Register 2")
    CSR_REG("PPDR30",      0x418, "PES Packet Parser 0 Data Register 3")
    CSR_REG("PPDR40",      0x41c, "PES Packet Parser 0 Data Register 4")
    CSR_REG("PPDR50",      0x420, "PES Packet Parser 0 Data Register 5")
    CSR_REG("PPDR60",      0x424, "PES Packet Parser 0 Data Register 6")
    CSR_REG("PPDR70",      0x428, "PES Packet Parser 0 Data Register 7")
    CSR_REG("PPEDR0",      0x42c, "PES Packet Parser 0 Extension Data Register")
    CSR_REG("PPSC10",      0x430, "PES Packet Parser 0 Programmable Start Codes 1")
    CSR_REG("PPSC20",      0x434, "PES Packet Parser 0 Programmable Start Codes 2")
    CSR_REG("PDOSM0",      0x438, "PES Packet Parser 0 Discontinuity Old STC (MSB)")
    CSR_REG("PDOSL0",      0x43c, "PES Packet Parser 0 Discontinuity Old STC (LSB)")
    CSR_REG("PDNSM0",      0x440, "PES Packet Parser 0 Discontinuity NEW STC (MSB)")
    CSR_REG("PDNSL0",      0x444, "PES Packet Parser 0 Discontinuity NEW STC (LSB)")

    /* STREAM 1 - PES PACKET PARSER REGISTERS */
    CSR_REG("PPTCR1",      0x480, "PES Packet Parser 1 Timer Control Register")
    CSR_REG_W_BB("PPCR1",  0x484, g_csr_MPG2VD_PPCR, "PES Packet Parser 1 Control Register")
    CSR_REG("PPSR1",       0x488, "PES Packet Parser 1 Status Register")
    CSR_REG("PPIDR1",      0x48c, "PES Packet Parser 1 Status ID Register")
    CSR_REG("PPDR11",      0x490, "PES Packet Parser 1 Data Register 1")
    CSR_REG("PPDR21",      0x494, "PES Packet Parser 1 Data Register 2")
    CSR_REG("PPDR31",      0x498, "PES Packet Parser 1 Data Register 3")
    CSR_REG("PPDR41",      0x49c, "PES Packet Parser 1 Data Register 4")
    CSR_REG("PPDR51",      0x4a0, "PES Packet Parser 1 Data Register 5")
    CSR_REG("PPDR61",      0x4a4, "PES Packet Parser 1 Data Register 6")
    CSR_REG("PPDR71",      0x4a8, "PES Packet Parser 1 Data Register 7")
    CSR_REG("PPEDR1",      0x4ac, "PES Packet Parser 1 Extension Data Register")
    CSR_REG("PPSC11",      0x4b0, "PES Packet Parser 1 Programmable Start Codes 1")
    CSR_REG("PPSC21",      0x4b4, "PES Packet Parser 1 Programmable Start Codes 2")
    CSR_REG("PDOSM1",      0x4b8, "PES Packet Parser 1 Discontinuity Old STC (MSB)")
    CSR_REG("PDOSL1",      0x4bc, "PES Packet Parser 1 Discontinuity Old STC (LSB)")
    CSR_REG("PDNSM1",      0x4c0, "PES Packet Parser 1 Discontinuity NEW STC (MSB)")
    CSR_REG("PDNSL1",      0x4c4, "PES Packet Parser 1 Discontinuity NEW STC (LSB)")

    /* STREAM 0 - DMA ENGINE REGISTERS */
    CSR_REG("SD0CBBA",     0x500, "Stream 0 DMA Circular/Linear Buffer Base Address")
    CSR_REG("SD0SBRP",     0x504, "Stream 0 DMA Source Block Register Address of Read Pointer")
    CSR_REG("SD0CBS",      0x508, "Stream 0 DMA Circular/Linear Buffer Size")
    CSR_REG("SD0PDV",      0x50c, "Stream 0 DMA Read/Write Pointer Watermark")
    CSR_REG("SD0WT",       0x510, "Stream 0 DMA Watchdog Timer")
    CSR_REG("SD0LRP",      0x514, "Stream 0 DMA Local Read Pointer")
    CSR_REG("SD0LWP",      0x518, "Stream 0 DMA Local Write Pointer")
    CSR_REG("SD0LINK",     0x51c, "Stream 0 DMA Link Address")
    CSR_REG("SD0LLSA",     0x520, "Stream 0 DMA Link List Source Address")
    CSR_REG("SD0LNDA",     0x524, "Stream 0 DMA Link List Next Descriptor Address")
    CSR_REG("SD0LDBC",     0x528, "Stream 0 DMA Link List Data Buffer Byte Count")
    CSR_REG("SD0LCBC",     0x52c, "Stream 0 DMA Link List Current Data Buffer Byte Count")
    CSR_REG("SD0LDC",      0x530, "Stream 0 DMA Link List Descriptor Control")

    /* STREAM 1 - DMA ENGINE REGISTERS */
    CSR_REG("SD1CBBA",     0x580, "Stream 1 DMA Circular/Linear Buffer Base Address")
    CSR_REG("SD1SBRP",     0x584, "Stream 1 DMA Source Block Register Address of Read Pointer")
    CSR_REG("SD1CBS",      0x588, "Stream 1 DMA Circular/Linear Buffer Size")
    CSR_REG("SD1PDV",      0x58c, "Stream 1 DMA Read/Write Pointer Watermark")
    CSR_REG("SD1WT",       0x590, "Stream 1 DMA Watchdog Timer")
    CSR_REG("SD1LRP",      0x594, "Stream 1 DMA Local Read Pointer")
    CSR_REG("SD1LWP",      0x598, "Stream 1 DMA Local Write Pointer")
    CSR_REG("SD1LINK",     0x59c, "Stream 1 DMA Link Address")
    CSR_REG("SD1LLSA",     0x5a0, "Stream 1 DMA Link List Source Address")
    CSR_REG("SD1LNDA",     0x5a4, "Stream 1 DMA Link List Next Descriptor Address")
    CSR_REG("SD1LDBC",     0x5a8, "Stream 1 DMA Link List Data Buffer Byte Count")
    CSR_REG("SD1LCBC",     0x5ac, "Stream 1 DMA Link List Current Data Buffer Byte Count")
    CSR_REG("SD1LDC",      0x5b0, "Stream 1 DMA Link List Descriptor Control")

    CSR_REG("SD0FWP",      0x700, "Stream 0 FIFO input")
    CSR_REG("SD1FWP",      0x704, "Stream 1 FIFO input")
    CSR_REG_W_BB("SDFSTAT",0x708, g_csr_MPG2VD_SDFSTAT, "FIFO Status")

    /* SYSTEM TIME COUNTER REGISTERS */
    CSR_REG("STC_AM0",     0x600, "STC_A (MSB)")
    CSR_REG("STC_AL0",     0x604, "STC_A (LSB)")
    CSR_REG("STC_BM0",     0x608, "STC_B (MSB)")
    CSR_REG("STC_BL0",     0x60c, "STC_B (LSB)")
    CSR_REG_W_BB("STC_CTRL0", 0x610, g_csr_MPG2VD_STC_CTRL, "STC Control")
    CSR_REG("STC_CNTM0",   0x614, "STC Count Value (MSB)")
    CSR_REG("STC_CNTL0",   0x618, "STC Count Value (LSB)")
    CSR_REG("STC_CNTTM0",  0x61c, "STC Count Timer (MSB)")
    CSR_REG("STC_CNTTL0",  0x620, "STC Count Timer (LSB)")
    CSR_REG("STC_VCNTM0",  0x624, "STC VDC Count (MSB)")
    CSR_REG("STC_VCNTL0",  0x628, "STC VDC Count (LSB)")

    CSR_REG("STC_AM1",     0x680, "STC_A (MSB)")
    CSR_REG("STC_AL1",     0x684, "STC_A (LSB)")
    CSR_REG("STC_BM1",     0x688, "STC_B (MSB)")
    CSR_REG("STC_BL1",     0x68c, "STC_B (LSB)")
    CSR_REG_W_BB("STC_CTRL1", 0x690, g_csr_MPG2VD_STC_CTRL, "STC Control")
    CSR_REG("STC_CNTM1",   0x694, "STC Count Value (MSB)")
    CSR_REG("STC_CNTL1",   0x698, "STC Count Value (LSB)")
    CSR_REG("STC_CNTTM1",  0x69c, "STC Count Timer (MSB)")
    CSR_REG("STC_CNTTL1",  0x6A0, "STC Count Timer (LSB)")
    CSR_REG("STC_VCNTM1",  0x6A4, "STC VDC Count (MSB)")
    CSR_REG("STC_VCNTL1",  0x6A8, "STC VDC Count (LSB)")

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_GEN1_MPG2VD_specific_events[] =
{
    { "INTERRUPT_OCCURED",  1,      "mpg2vd has an interrupt to service",   NULL },
    { "PUSH_FRAME",         2,      " %5d,y->%08x,FrmId:%d,TmpRef:%u,PTS33:%u, PTS_low:%u", NULL },
    { "CAN_DISPLAY",        3,      "mpg2vd has a frame ready for display", NULL },
    { "CIRC_BUF_WRITE",     4,      " rd:%08x,wt:%08x,off:%05x,cnt:%04x,tmp:%05x,amt:%05x", NULL },
    { "DISPLAY_QUEUE_RELEASE",  5,  "      y->%08x,FrmId:%d,TmpRef:%d", NULL },
    { "FRAMES_OUT_OF_ORDER",6,      " The Temporal Reference is less than the previous", NULL },
    { "DISCONT",            7,      " MPG2VD got discontinuity", NULL },
    { "PTS_FROM_TSD",       8,      "   prsnt:%d,PTS33:%u,PTSlow:%u,base:%x,size:%x,id:%d", NULL },
    { "PTS_VBV_INDEX",      9,      "  valid:%d,PTS33:%u,PTSlow:%u,Index:%03x,size:%x,pictype:%d", NULL },
    { "PTS_VBV_INDEX2",    10,      " valid:%d,PTS33:%u,PTSlow:%u,Index:%03x,FrmId:%x,pictype:%d", NULL },
    { "PTS_VBV_INDEX3",    11,      " valid:%d,PTS33:%u,PTSlow:%u,Index:%03x,FrmId:%x,pictype:%d", NULL },
    { "FLUSH_START",       12,      " Starting mpg2vd flush", NULL },
    { "FLUSH_STOP",        13,      "  mpg2vd flush finished", NULL },
    { "THROW_AWAY",        14,      " %5d,y->%08x,FrmId:%d,TmpRef:%u,PTS33:%u, PTS_low:%u", NULL },
    { "NEW_EVENT",         15,      " The next mpg2vd sven event(placeholder)", NULL },
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN1_MPG2VD_sven_module =
{
    "GEN1_MPG2VD",
    SVEN_module_GEN1_MPG2VD,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN1_MPG2VD,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: MPG2VD Function (GEN1)",
    g_GEN1_MPG2VD_specific_events,
    NULL                            /* extension list */
};

