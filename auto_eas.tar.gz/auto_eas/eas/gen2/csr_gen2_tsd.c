/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_unit.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Simplest Possible example of EAS definition */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

/* Declare the bit-breakout for the register defined in the EAS_Register defs below.
 * Keep this table (static) so it is not visible outside of this module. 
 * The only publicly visible pointer should be g_csr_GEN1_TSD_versions.
 */

static const struct EAS_RegBits g_csr_GEN1_TSD_CRYPTO_CONTROL[] =
{
    { "RESERVED_31_5",          5,  27,"",NULL},    /* reserved bits [32..5] in this register */
    { "Conformance_mode_select",     4,  1,"",NULL},/*0=DVB 2.0 ; 1= Conformance(DVB 1.2) */
    { "ACTIVE_KEY_TYPE",           0,  4,"",NULL}, /* 0 none;1 Single DES; 2 Double DES;3 Triple DES;4 DVB */
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN1_TSD_CRYPTO_STATUS[] =
{
    { "RESERVED_31_8",          5,  27,"",NULL},    /* reserved bits [31..8] in this register */
    { "Back_Door_Key_Busy",     4,  1,"",NULL},
    { "Invalid_Key",                3,  1,"",NULL},
    { "Output_Ready",               2,  1,"",NULL},
    { "Input_Ready",                1,  1,"",NULL},
    { "Busy",                       0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_GEN1_TSD_CRYPTO_IRQ[] =
{
    { "RESERVED_31_3",          5,  29,"",NULL},    /* reserved bits [31..8] in this register */
    { "Invalid_Key_IRQ",                2,  1,"",NULL},
    { "Output_Ready_IRQ",                1,  1,"",NULL},
    { "Input_Ready_IRQ",                 0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN1_TSD_CRYPTO_IRQ_MASK[] =
{
    { "RESERVED_31_3",          5,  29,"",NULL},    /* reserved bits [31..8] in this register */
    { "Invalid_Key_IRQ_MASK",                2,  1,"",NULL},
    { "Output_Ready_IRQ_MASK",                1,  1,"",NULL},
    { "Input_Ready_IRQ_MASK",                 0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN1_TSD_CRYPTO_ALG[] =
{
    { "RESERVED_31_5",          5,  27,"",NULL},    /* reserved bits [31..8] in this register */
    { "Default_Crypto_Algorithm",                 0,  5,"",NULL},
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN1_TSD_KEY_ADDR[] =
{
    { "RESERVED_31_3",          3,  29,"",NULL},    /* reserved bits [31..8] in this register */
    { "BackDoor_Key_Address",                 0,  3,"",NULL},
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN1_TSD_CRC_CONTROL[] =
{
    { "RESERVED_31_2",          2,  30,"",NULL},    /* reserved bits [32..4] in this register */
    { "BIT_DIRECTION",          1,  1,"",NULL},
    { "CRC_ENABLE",             0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN1_TSD_CRC_STATUS[] =
{
    { "RESERVED_31_1",          1,  31,"",NULL},    /* reserved bits [32..4] in this register */
    { "CRC_Error",              0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN1_TSD_PM_CONTROL[] =
{
    { "RESERVED_31_2",          2,  30,"",NULL},    /* reserved bits [32..4] in this register */
    { "MASK_MATCH_ENABLE",      1,  1,"",NULL},
    { "EXACT_MATCH_ENABLE",     0,  1,"",NULL},
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN1_TSD_PM_STATUS[] =
{
    { "RESERVED_31_2",          2,  30,"",NULL},    /* reserved bits [32..4] in this register */
    { "MASK_MATCH",      1,  1,"",NULL},
    { "EXACT_MATCH",     0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_GEN1_TSD_PM_IRQ[] =
{
    { "RESERVED_31_2",          2,  30,"",NULL},    /* reserved bits [32..4] in this register */
    { "MASK_MATCH_IRQ",      1,  1,"",NULL},
    { "EXACT_MATCH_IRQ",     0,  1,"",NULL},
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_GEN1_TSD_PM_IRQ_MASK[] =
{
    { "RESERVED_31_2",          2,  30,"",NULL},    /* reserved bits [32..4] in this register */
    { "MASK_MATCH_IRQ_Mask",      1,  1,"",NULL},
    { "EXACT_MATCH_IRQ_Mask",     0,  1,"",NULL},
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN1_TSD_PM_MASK_CLEAR[] =
{
    { "RESERVED_31_8",          8,  24,"",NULL},    /* reserved bits [32..8] in this register */
    { "Clears_MASK_47",      4,  4,"",NULL},
    { "Clears_MASK_03",     0,  4,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_GEN1_TSD_IO_CONTROL[] =
{
    { "RESERVED_31_4",          4,  28,"",NULL},    /* reserved bits [32..4] in this register */
    { "Send_Remaining",             3,  1,"",NULL},
    { "Send_Enable",                2,  1,"",NULL},
    { "Fetch_Enable",               1,  1,"",NULL},
    { "Input_Flush",                0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_GEN1_TSD_IO_OUTPUT_SND_THRES[] =
{
    { "RESERVED_31_4",          8,  24,"",NULL},    /* reserved bits [32..8] in this register */
    { "Threshold_Mask",           2,  6,"",NULL},
    { "Hardwired",                0,  2,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN1_TSD_IO_INPUT_FETCH_THRES[] =
{
    { "RESERVED_31_4",          8,  24,"",NULL},    /* reserved bits [32..8] in this register */
    { "Threshold_Mask",           2,  6,"",NULL},
    { "Hardwired",                0,  2,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_GEN1_TSD_IO_STATUS[] =
{
    { "RESERVED_31_4",          4,  28,"",NULL},    /* reserved bits [32..4] in this register */
    { "Send_Remaining_Busy",        3,  1,"",NULL},
    { "Out_FIFO_Emtpy",             2,  1,"",NULL},
    { "Shift_Busy",             1,  1,"",NULL},
    { "Input_Flush_Busy",       0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_Register g_csr_GEN1_TSD[] =
{
    /* Crypto Engine Unit registers */
    { "CRYPTO_CONTROL", 0x0000, g_csr_GEN1_TSD_CRYPTO_CONTROL, 	"Crypto Control Register",NULL },
    { "CRYPTO_STATUS",  0x0004, g_csr_GEN1_TSD_CRYPTO_STATUS, 	"Crypto Status Register",NULL },
	{ "CRYPTO_IRQ",  	0x0008, g_csr_GEN1_TSD_CRYPTO_IRQ, 		"Crypto IRQ Register", NULL, },
	{ "CRYPTO_IRQ_MASK",0x000C,g_csr_GEN1_TSD_CRYPTO_IRQ_MASK,	"Crypto IRQ_MASK Register", NULL, },
	{ "CRYPTO_IV_0", 	0x0010,		NULL,						"Least significant word", NULL, },
	{ "CRYPTO_IV_1", 	0x0014, 	NULL,						"Most significant word", NULL,},
	{ "CRYPTO_RESERVED0",0x0018, 	NULL,						"RESERVED",NULL, },
	{ "CRYPTO_KEY_0", 0x0024, NULL,"Least significant word of crypto key",NULL, },
	{ "CRYPTO_KEY_1", 0x0028, NULL,"Middle signifiacnt word",NULL, },
	{ "CRYPTO_KEY_2", 0x002C, NULL,"Middle signifiacnt word",NULL,},
	{ "CRYPTO_KEY_3", 0x0030, NULL,"Middle signifiacnt word",NULL, },
	{ "CRYPTO_KEY_4", 0x0034, NULL,"Middle signifiacnt word",NULL, },
	{ "CRYPTO_KEY_5", 0x0038, NULL,"Most signifiacnt word",NULL, },
	{ "CRYPTO_ALGORITHM", 0x003C, g_csr_GEN1_TSD_CRYPTO_ALG,"Algorithm",NULL, },
	{ "CRYPTO_DATAOUT_0", 0x0040, NULL, "LSB of the result of a crypto operation OUTPUT_READY status flag is asserted",NULL, },
	{ "CRYPTO_DATAOUT_1", 0x0044, NULL, "MSB of result of crypto operation_OUTPUT_READY FLAG ASSERTED",NULL,},
	{ "KEY_ADDR",		0x0048,g_csr_GEN1_TSD_KEY_ADDR, "Selects the current back-door crypto key", NULL, },
	{ "CRYPTO_RESERVED1", 0x0048, NULL, "Reserved", NULL, },


    /* Data Shift Register Unit registers */
    { "DSR_CONTROL", 0x0800,	NULL,	"Data Shift Control Register",NULL },
	{ "DSR_STATUS",  0x0804,	NULL, 	"Data Shift Register",NULL },
	{ "DSR_IRQ",  	0x0808,		NULL,	"Data Shift IRQ Register", NULL, },
	{ "DSR_IRQ_MASK",0x080C,	NULL,	"Data shiftIRQ_MASK Register", NULL, },
    { "DSR_DATA_03", 0x0810, NULL, "Data Shift Data_03 Register",NULL},
    { "DSR_DATA_47", 0x0814, NULL, "Data Shift Data_47 Register",NULL},
    { "DSR_DATA_8B", 0x0818, NULL, "Data Shift Data_8B Register",NULL},
    { "DSR_DATA_CF", 0x081C, NULL, "Data Shift Data_CF Register",NULL},
    { "DSR_RESERVED", 0x0820, NULL, "Reserved", NULL, },
    /* CRC Checker Unit registers */
    { "CRC_CONTROL",	0x1000,	g_csr_GEN1_TSD_CRC_CONTROL, "CRC check control register",NULL },
    { "CRC_STATUS",		0x1004,	g_csr_GEN1_TSD_CRC_STATUS,	"CRC check status register",NULL },
    { "CRC_IRQ",		0x1008,	NULL,			 		"CRC IRQ Register", NULL, },
	{ "CRC_IRQ_MASK",	0x100C,	NULL,	"CRCIRQ_MASK Register", NULL, },
    { "CRC_ACCUMULATOR",0x1010, NULL,	"CRC accumulator register",NULL },
 	{ "CRC_RESERVED",	0x101C, NULL,	"Reserved", NULL, },
    /* Pattern Matcher Unit registers */
    { "PM_CONTROL",	 0x1800,g_csr_GEN1_TSD_PM_CONTROL,	"Pattern Matcher Unit Control",NULL},
    { "PM_STATUS",	 0x1804,g_csr_GEN1_TSD_PM_STATUS, 	"Pattern Matcher Unit Status",NULL},
    { "PM_IRQ",		 0x1808,g_csr_GEN1_TSD_PM_IRQ, 	"Pattern Matcher IRQ Register", NULL, },
	{ "PM_IRQ_MASK",0x180C,	g_csr_GEN1_TSD_PM_IRQ_MASK,	"Pattern Matcher IRQ_MASK Register", NULL, },
    { "PM_MASK_03", 0x1810, 	NULL, 	"Pattern Matcher Unit Mask03",NULL},
    { "PM_MASK_47", 0x1814, 	NULL, 	"Pattern Matcher Unit Mask47",NULL},
    { "PM_RESERVED0", 0x1818, 	NULL,	"Reserved", NULL, },
    { "PM_MATCH_03",0x1820, 	NULL, 	"Pattern Matcher Unit Match03",NULL},
    { "PM_MATCH_47",0x1824, 	NULL, 	"Pattern Matcher Unit Match03",NULL},
	{ "PM_RESERVED",0x0828, 	NULL, 	"Reserved", NULL, },
	{ "PM_MASK_CLEAR",0x1830,g_csr_GEN1_TSD_PM_MASK_CLEAR,"Selectively clears bytes in the MATCH_* registers.", NULL, },
	{ "PM_RESERVED1", 0x1834,	NULL,	"RESERVED", NULL, },
    /* I/O Controller Unit registers */
    { "IO_CONTROL",	0x2000, g_csr_GEN1_TSD_IO_CONTROL, "I/O controller control Register",NULL },
    { "IO_STATUS",	0x2004, g_csr_GEN1_TSD_IO_STATUS, "I/O controller status Register",NULL },
    { "IO_IRQ",		0x2008, NULL, 	"I/O Controller IRQ Register", NULL, },
	{ "IO_IRQ_MASK",0x200C, NULL,	"I/O Controller IRQ_MASK Register", NULL, },
    { "IO_INPUT_START_ADDR",0x2010, NULL,	 "I/O controller input start address Register",NULL},
    { "IO_INPUT_CURR_ADDR",	0x2014, NULL,	 "I/O controller input current address Register",NULL },
    { "IO_INPUT_SIZE", 		0x2018, NULL,	 "I/O controller input size Register",NULL },
    { "IO_RESERVED0",		0x201C, NULL,	 "IO_RESERVED",NULL, },
	{ "IO_BYTES_SHIFTED_IN",0x2020, NULL,	"The value in this register is incremented by one each time a new byte is shifted into the DSR.", NULL, },
	{ "IO_INPUT_FIFO_LEVEL",0x2024,	NULL,	"The number of bytes currently available in the input FIFO for shifting into the DSR. ", NULL, },
    { "IO_OUTPUT_START_ADDR",	0x2028, NULL,	 "I/O controller output start address Register",NULL },
    { "IO_OUTPUT_CURR_ADDR",	0x202C, NULL,	 "I/O controller output current address Register",NULL },
    { "IO_OUTPUT_SIZE",			0x2030, NULL,	 "I/O controller output size Register",NULL },
    { "IO_OUTPUT_SEND_THRESHOLD",0x2038,g_csr_GEN1_TSD_IO_OUTPUT_SND_THRES,	 "Indicates a watermark for creating an xsi request to send out more stream data. ", NULL, },
	{ "IO_INPUT_FETCH_THRESHOLD",0x203C,g_csr_GEN1_TSD_IO_INPUT_FETCH_THRES,	"Indicates a watermark for creating an xsi request to read in more stream data. ", NULL, },
	{ "IO_RESERVED1",			0x2040, NULL,	"Reserved",								NULL, },
/* "Host Interface" Unit registers */
	{ "HOST_RESERVED0",	0x2800,	NULL,	"Host Interface Reserved",	NULL, },
	{ "HOST_RESERVED1",	0x2804,	NULL,	"Host Interface Reserved",	NULL, },
	{ "HOST_IRQ",		0x2808,	NULL,	"Contains the IPC Doorbell IRQs.  They are cleared by writing a 1.", NULL, },
	{ "HOST_IRQ_MASK",	0x280C,	NULL,	"indicates the correlated IRQ signal from the IRQ register is masked.", NULL, },
	{ "HOST_IPC_STATUS",0x2810,	NULL,	"Contains the Ready and Done IPC flags for each of the processors.", NULL, },
	{ "HOST_IPC_DOORBELL",	0x2814,	NULL,"Command mailbox for communicating with the host processor from the RISC controller.", NULL, },
	{ "RISC_IPC_DOORBELL",	0x2818,	NULL,"Command mailbox for communicating with the RISC controller from the host processor.", NULL, },
	{ "ICACHE_BASE_ADDRESS",0x281C,NULL,"Indicates the base address of the firmware image in the XSI memory space. ", NULL, },
	{ "ICACHE_INVALIDATE_0",0x2820,	NULL,"Each bit in this register corresponds to a cache line in the RISC instruction cache. ", NULL, },
	{ "ICACHE_INVALIDATE_1",0x2824,	NULL,"Each bit in this register corresponds to a cache line in the RISC instruction cache.", NULL, },
	{ "ICACHE_INVALIDATE_2",0x2828,	NULL,"Each bit in this register corresponds to a cache line in the RISC instruction cache.", NULL, },
	{ "ICACHE_INVALIDATE_3",0x282C,	NULL,"Each bit in this register corresponds to a cache line in the RISC instruction cache. ", NULL, },
	{ "HOST_RESERVED",		0x2830,	NULL,"Reserved	2", NULL, },
/*	"Host Coprocessor Control (debug mode) */
	{ "Coproc_Interface_Opcode",	0x3000,	NULL,"The opcode written to this register is passed on to the coprocessor via the coprocessor interface ", NULL, },
	{ "Coproc_Interface_Data",		0x3004,	NULL,"Data written to this register is passed on to the coprocessor via the coprocessor ", NULL, },
	{ "Coproc_Interface_Aux",		0x3008, NULL,"Auxillary Interface",	NULL },
    { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */



static const struct SVEN_Module_EventSpecific g_GEN1_TSD_specific_events[] =
{
    { "TSD_EVENTAME_0",     1,      "Software did read captured frames in time", NULL },
    { "IN_PORT_EMPTY",      2,      "Input port %d for stream %d is empty", NULL },
    { "UNDERRUN_DETECTED", 3, "Buffer underrun detected with PTS 0x%08X, New buffering offset 0x%08X, time: 0x%08X, base time: 0x%08X, minimum_buffering: 0x%08X, current_buffering: 0x%08X", NULL },
    { "IN_BUFFERS_FULL",    4,      "Buffer for stream %d input to fw is full", NULL },
    { "OUT_BUFFERS_EMPTY",  5,      "Buffers from fw for stream %d, filter %d are empty", NULL },
    { "OUT_PORT_FULL",      6,      "Output port %d for stream %d, filter %d is full", NULL },
    { "PORT_WRITE",         7,      "Wrote buff of size %d to port %d for stream %d, filter %d, PTS %x, FW PTS %x", NULL}, 

    { "FW_RCV_IPC_CMD_SET_INPUT_STREAM",           0x80, "", NULL },
    { "FW_RCV_IPC_CMD_CONTROL_INPUT_STREAM",       0x81, "", NULL },
    { "FW_RCV_IPC_CMD_SET_FILTER",                 0x82, "", NULL },
    { "FW_RCV_IPC_CMD_CTRL_CRYPTO_ON_FILTER",      0x83, "", NULL },
    { "FW_RCV_IPC_CMD_ADD_PID",                    0x84, "", NULL },
    { "FW_RCV_IPC_CMD_ADD_FILTER_TO_PID",          0x85, "", NULL },
    { "FW_RCV_IPC_CMD_CONTROL_PID",                0x86, "", NULL },
    { "FW_RCV_IPC_CMD_CONTROL_FILTER",             0x87, "", NULL },
    { "FW_RCV_IPC_CMD_DELETE_PID",                 0x88, "", NULL },
    { "FW_RCV_IPC_CMD_DELETE_FILTER_FROM_PID",     0x89, "", NULL },
    { "FW_RCV_IPC_CMD_SET_FILTER_WPA",             0x8a, "", NULL },
    { "FW_RCV_IPC_CMD_ADD_MM_FILTER",              0x8b, "", NULL },
    { "FW_RCV_IPC_CMD_SET_CRYPTO_PARAMS",          0x8c, "", NULL },
    { "FW_RCV_IPC_CMD_SET_CRYPTO_KEY",             0x8d, "", NULL },
    { "FW_RCV_IPC_CMD_SET_STR_CRYPTO_INFO",        0x8e, "", NULL },
    { "FW_RCV_IPC_CMD_RESET_INDEX_COUNT",          0x8f, "", NULL },
    { "FW_RCV_IPC_CMD_SET_DISCONT_PKT_STREAM_ID",  0x90, "", NULL },
    { "FW_RCV_IPC_CMD_SET_PCR_PID",                0x91, "", NULL },
    { "FW_RCV_IPC_CMD_RESET_FILTER",               0x92, "", NULL },
    { "FW_RCV_IPC_CMD_RESET_STREAM",               0x93, "", NULL },
    { "FW_RCV_IPC_CMD_SET_STREAM_LOW_WM",          0x94, "", NULL },
    { "FW_RCV_IPC_CMD_SET_FILTER_HIGH_WM",         0x95, "", NULL },
    { "FW_RCV_IPC_CMD_SET_FILTER_CF",              0x96, "", NULL },

    {"SET_REBASE_OFFSET", 8, " old_value: %x new_value: %x", NULL },
    {"GET_REBASE_OFFSET", 9, " rebase offset: %x", NULL },
    
    { NULL,0,NULL,NULL }
};

static const struct ModuleReverseDefs g_GEN1_TSD_sven_module =
{
    "GEN1_TSDEMUX",                           /* */
    SVEN_module_GEN1_TSDEMUX,             /*  */
    128*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN1_TSD,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "TSD: TransportStreamDemux (GEN1)",   /* */
    g_GEN1_TSD_specific_events,   /* TODO-Later: Define important events specific to my module */
    NULL /* extension list */
};
