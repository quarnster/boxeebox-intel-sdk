/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct EAS_RegBits g_csr_gen1plus_omar_CONTROL[] = 
{
    /* Copied from EAS */
    {"RESERVED",            1, 30, "", NULL },
    {"ENABLE",              0, 1, "", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen1plus_omar_HEADER_WORD[] = 
{
    /* Copied from EAS */
    {"HDR_PASS",            30, 2, "Circular Buffer loop count", NULL },
    {"RESERVED",            24, 6, "", NULL },
    {"HDR_SAMP",            0, 24, "Sample Counter", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Copied from OMAR EAS by Pat Brouillette */
static const struct EAS_Register g_csr_gen1plus_omar[] =
{
    { "CONTROL",               0x00, g_csr_gen1plus_omar_CONTROL, "Control Register", NULL },
    { "STATUS",                0x04, NULL, "Status", NULL },
    { "INTERVAL_COUNT",        0x08, NULL, "Sample Interval Countdown (XSI clocks)", NULL },
    { "HEADER_WORD",           0x0c, g_csr_gen1plus_omar_HEADER_WORD, "(RO) Header Word", NULL },
    { "CAP_BASE_ADDR",         0x10, NULL, "Capture Buffer Base Address", NULL },
    { "CAP_SIZE",              0x14, NULL, "Capture Buffer Size in bytes", NULL },
    { "CAP_CUR_PTR",           0x18, NULL, "(RO) Capture Current Pointer", NULL },
    { "RESERVED0",             0x1c, NULL, "reserved", NULL },
    { "SIG_ENABLE0",           0x20, NULL, "Capture Enable for signals (00-1f)", NULL },
    { "SIG_ENABLE1",           0x24, NULL, "Capture Enable for signals (20-3f)", NULL },
    { "SIG_ENABLE2",           0x28, NULL, "Capture Enable for signals (40-5f)", NULL },
    { "SIG_ENABLE3",           0x2c, NULL, "Capture Enable for signals (60-7f)", NULL },
    { "SIG_ENABLE4",           0x30, NULL, "Capture Enable for signals (80-9f)", NULL },
    { "SIG_ENABLE5",           0x34, NULL, "Capture Enable for signals (a0-bf)", NULL },
    { "SIG_ENABLE6",           0x38, NULL, "Capture Enable for signals (c0-df)", NULL },
    { "SIG_ENABLE7",           0x3c, NULL, "Capture Enable for signals (e0-ff)", NULL },
    { "SET_OR_INC_0",          0x80, NULL, "Set-on-Write, Increment-on-Read, counter 0", NULL },
    { "ADD_OR_DEC_0",          0x84, NULL, "Add-on-Write, Decrement-on-Read, counter 0", NULL },
    { NULL,0,NULL,"",NULL } /* NULL Terminated */
};

/* Copied from OMAR EAS 09aug2006 by Pat Brouillette */
static const struct EAS_Register g_csr_gen1plus_omar_cw[] =
{
    { "GLOBAL_CW",          0x0000,  NULL, "Global Chip Watch Control", NULL },
    { "RESERVED0",          0x0004,  NULL, "reserved0", NULL },
    { "RESERVED1",          0x0008,  NULL, "reserved1", NULL },
    { "RESERVED2",          0x000c,  NULL, "reserved2", NULL },
    { "SKEW9_0_CNTRL",      0x0010,  NULL, "Skew Control Register for Bus bits 9-0", NULL },
    { "SKEW19_10_CNTRL",    0x0014,  NULL, "Skew Control Register for Bus bits 19-10", NULL },
    { "SKEW29_20_CNTRL",    0x0018,  NULL, "Skew Control Register for Bus bits 29-20", NULL },
    { "SKEW33_30_CNTRL",    0x001C,  NULL, "Skew Control Register for Bus bits 33-30", NULL },
    { "DTUNIT_CW_OVERRIDE", 0x0020,  NULL, "DTUnit Chip Watch Selection", NULL },
    { "VCMH1_CW_OVERRIDE",  0x0024,  NULL, "VCMH1 Chip Watch Selection", NULL },
    { "VCMH0_CW_OVERRIDE",  0x0028,  NULL, "VCMH0 Chip Watch Selection", NULL },
    { "MCU_CW_OVERRIDE",    0x002C,  NULL, "MCU Chip Watch Selection", NULL },
    { "XSI_CW_OVERRIDE",    0x0030,  NULL, "XSI Chip Watch Selection", NULL },
    { "VCAP1_CW_OVERRIDE",  0x0034,  NULL, "VCAP1 Chip Watch Selection", NULL },
    { "VCAP2_CW_OVERRIDE",  0x0038,  NULL, "VCAP2 Chip Watch Selection", NULL },
    { "MPDG2VE_CW_OVERRIDE",0x003C,  NULL, "MPEG2VE Chip Watch Selection", NULL },
    { "H264VD_CW_OVERRIDE", 0x0040,  NULL, "H264 Chip Watch Selection", NULL },
    { "MPG2VD_CW_OVERRIDE", 0x0044,  NULL, "MPEG2VD Chip Watch Selection", NULL },
    { "SEC_CW_OVERRIDE",    0x0048,  NULL, "SEC Chip Watch Selection", NULL },
    { "TSD_CW_OVERRIDE",    0x004C,  NULL, "TSD Chip Watch Selection", NULL },
    { "PREFILTER1_CW_OVERRIDE",      0x0050,  NULL, "Prefilter1 Chip Watch Selection", NULL },
    { "PREFILTER2_CW_OVERRIDE",      0x0054,  NULL, "Prefilter2 Chip Watch Selection", NULL },
    { "PREFILTER3_CW_OVERRIDE",      0x0058,  NULL, "Prefilter3 Chip Watch Selection", NULL },
    { "PCI_CW_OVERRIDE",    0x005C,  NULL, "PCI Chip Watch Selection", NULL },
    { "VDC_CW_OVERRIDE",    0x0060,  NULL, "VDC Chip Watch Selection", NULL },
    { "GFX_CW_OVERRIDE",    0x0064,  NULL, "GFX Chip Watch Selection", NULL },
    { "SCK_CW_OVERRIDE",    0x0068,  NULL, "SCK Chip Watch Selection", NULL },
    { "PCK_CW_OVERRIDE",    0x006C,  NULL, "PCK Chip Watch Selection", NULL },
    { "RU_CW_OVERRIDE",     0x0070,  NULL, "RU Chip Watch Selection", NULL },
    { "USIM_CW_OVERRIDE",   0x0074,  NULL, "Smart Card Chip Watch Selection", NULL },
    { "UART_CW_OVERRIDE",   0x0078,  NULL, "UART Chip Watch Selection", NULL },
    { "EXP_CW_OVERRIDE",    0x007C,  NULL, "Expansion Bus Chip Watch Selection", NULL },
    { "SPI_CW_OVERRIDE",    0x0080,  NULL, "SPI Chip Watch Selection", NULL },
    { "I2C_CW_OVERRIDE",    0x0084,  NULL, "I2C Chip Watch Selection", NULL },
    { "ARBS_CW_OVERRIDE",   0x0088,  NULL, "Pub Arbiters Chip Watch Selection", NULL },
    { "AU_CW_OVERRIDE",     0x008C,  NULL, "Audio Bus Chip Watch Selection", NULL },
    { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct SVEN_Module_EventSpecific g_gen1plus_omar_specific_events[] =
{
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_omar_sven_module =
{
    "GEN1PLUS_OMAR",
    SVEN_module_GEN1PLUS_OMAR,
    256,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen1plus_omar,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "OMAR: On-chip Media Analysis Recorder (Gen1++)",
    g_gen1plus_omar_specific_events,
    NULL /* extension list */
};

static const struct SVEN_Module_EventSpecific g_gen1plus_omar_cw_specific_events[] =
{
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_omar_cw_sven_module =
{
    "GEN1PLUS_OMAR_CW",
    SVEN_module_GEN1PLUS_OMAR_CW,
    256,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen1plus_omar_cw,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "OMAR: On-chip Media Analysis Recorder, Chipwatcher Control",
    g_gen1plus_omar_cw_specific_events,
    NULL /* extension list */
};
