/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
static const struct EAS_RegBits g_csr_gen1plus_mcu_DBG_CTL[] = 
{
    /* Copied from EAS */
    {"RESERVED_0",            20, 12, "Reserved", NULL },
    {"CH_ENABLE",            16, 4, "MCU Channel Enable", NULL },
    {"RESERVED_1",            14, 2, "Reserved", NULL },
    {"PORT_ENABLE",            8, 6, "MCU Port Enable", NULL },
    {"RESERVED_2",            1, 7, "Reserved", NULL },
    {"MCU_DEBUG_MODE_EN",              0, 1, "MCU Debug Mode Enable", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen1plus_mcuport_DBG_CTL[] = 
{
    /* Copied from EAS */
    {"RESERVED_3",            30, 2, "Reserved", NULL },
    {"PORT_ISSUE_CNTR_THRESH",            24, 6, "Port Issye Counter Threshold", NULL },
    {"PORT_ISSUE_CNTR",            18, 6, "Port Issue Counter", NULL },
    {"PORT_ISSUE_CNTR_RST",            17, 1, "Port Issue Counter Reset", NULL },
    {"PORT_ISSUE_CNTR_EN",            16, 1, "Port Iissue Counter Enable", NULL },
    {"RESERVED_4",              0, 16, "Reserved", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen1plus_mcuport_watchaddrattr[] = 
{
    /* Copied from EAS */
    {"Tag",            27, 5, "Watch Address Tag", NULL },
    {"RESERVED_5",            26, 1, "Reserved", NULL },
    {"TYPE",            17, 9, "Watch Address type", NULL },
    {"BYTE_COUNT",            8, 9, "Watch address Byte Count", NULL },
    {"READ_WRITE_CMD",              0, 8, "Read/Write Command", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen1plus_mcu_int_CTL_STAT[] = 
{
    /* Copied from EAS */
    {"RESERVED_6",            22, 10, "Reserved", NULL },
    {"PORT5_INT_ST",              21, 1, "Port 5 Counter Match Intr Stat", NULL },
    {"PORT4_INT_ST",              20, 1, "Port 4 Counter Match Intr Stat", NULL },
    {"PORT3_INT_ST",              19, 1, "Port 3 Counter Match Intr Stat", NULL },
    {"PORT2_INT_ST",              18, 1, "Port 2 Counter Match Intr Stat", NULL },
    {"PORT1_INT_ST",              17, 1, "Port 1 Counter Match Intr Stat", NULL },
    {"PORT0_INT_ST",              16, 1, "Port 0 Counter Match Intr Stat", NULL },
    {"RESERVED_7",            6, 10, "Reserved", NULL },
    {"PORT5_INT_EN",              5, 1, "Port 5 Counter Match Intr En", NULL },
    {"PORT4_INT_EN",              4, 1, "Port 4 Counter Match Intr En", NULL },
    {"PORT3_INT_EN",              3, 1, "Port 3 Counter Match Intr En", NULL },
    {"PORT2_INT_EN",              2, 1, "Port 2 Counter Match Intr En", NULL },
    {"PORT1_INT_EN",              1, 1, "Port 1 Counter Match Intr En", NULL },
    {"PORT0_INT_EN",              0, 1, "Port 0 Counter Match Intr En", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_Register g_csr_gen1_mcu[] =
{
  { "DEBUG_CNTRL",                      0x00, g_csr_gen1plus_mcu_DBG_CTL, "DEBUG CONTROL", NULL }, 
  { "PORT0_CNTRL",                  0x04, g_csr_gen1plus_mcuport_DBG_CTL, "MCU PORT0 DEBUG CONTROL", NULL },
  { "PORT0_MATCH_ADDR",             0x08, NULL, "MCU PORT0 MATCH ADDR", NULL },
  { "PORT0_MATCH_ADDR_MASK",        0x0C, NULL, "MCU PORT0 MATCH ADDR MASK", NULL },
  { "PORT0_WATCH_ADDR",             0x10, NULL, "MCU PORT0 WATCH ADDR", NULL },
  { "PORT0_WATCH_ADDR_ATTR",        0x14, g_csr_gen1plus_mcuport_watchaddrattr, "MCU PORT0 WATCH ADDR ATTR", NULL },
  { "PORT1_CNTRL",                  0x18, g_csr_gen1plus_mcuport_DBG_CTL, "MCU PORT1 DEBUG CONTROL", NULL },
  { "PORT1_MATCH_ADDR",             0x1C, NULL, "MCU PORT1 MATCH ADDR", NULL },
  { "PORT1_MATCH_ADDR_MASK",        0x20, NULL, "MCU PORT1 MATCH ADDR MASK", NULL },
  { "PORT1_WATCH_ADDR",             0x24, NULL, "MCU PORT1 WATCH ADDR", NULL },
  { "PORT1_WATCH_ADDR_ATTR",        0x28, g_csr_gen1plus_mcuport_watchaddrattr, "MCU PORT1 WATCH ADDR ATTR", NULL },
  { "PORT2_CNTRL",                  0x2C, g_csr_gen1plus_mcuport_DBG_CTL, "MCU PORT2 DEBUG CONTROL", NULL },
  { "PORT2_MATCH_ADDR",             0x30, NULL, "MCU PORT2 MATCH ADDR", NULL },
  { "PORT2_MATCH_ADDR_MASK",        0x34, NULL, "MCU PORT2 MATCH ADDR MASK", NULL },
  { "PORT2_WATCH_ADDR",             0x38, NULL, "MCU PORT2 WATCH ADDR", NULL },
  { "PORT2_WATCH_ADDR_ATTR",        0x3C, g_csr_gen1plus_mcuport_watchaddrattr, "MCU PORT2 WATCH ADDR ATTR", NULL },
  { "PORT3_CNTRL",                  0x40, g_csr_gen1plus_mcuport_DBG_CTL, "MCU PORT3 DEBUG CONTROL", NULL },
  { "PORT3_MATCH_ADDR",             0x44, NULL, "MCU PORT3 MATCH ADDR", NULL },
  { "PORT3_MATCH_ADDR_MASK",        0x48, NULL, "MCU PORT3 MATCH ADDR MASK", NULL },
  { "PORT3_WATCH_ADDR",             0x4C, NULL, "MCU PORT3 WATCH ADDR", NULL },
  { "PORT3_WATCH_ADDR_ATTR",        0x50, g_csr_gen1plus_mcuport_watchaddrattr, "MCU PORT3 WATCH ADDR ATTR", NULL },
  { "PORT4_CNTRL",                  0x54, g_csr_gen1plus_mcuport_DBG_CTL, "MCU PORT4 DEBUG CONTROL", NULL },
  { "PORT4_MATCH_ADDR",             0x58, NULL, "MCU PORT4 MATCH ADDR", NULL },
  { "PORT4_MATCH_ADDR_MASK",        0x5C, NULL, "MCU PORT4 MATCH ADDR MASK", NULL },
  { "PORT4_WATCH_ADDR",             0x60, NULL, "MCU PORT4 WATCH ADDR", NULL },
  { "PORT4_WATCH_ADDR_ATTR",        0x64, g_csr_gen1plus_mcuport_watchaddrattr, "MCU PORT4 WATCH ADDR ATTR", NULL },
  { "PORT5_CNTRL",                  0x68, g_csr_gen1plus_mcuport_DBG_CTL, "MCU PORT5 DEBUG CONTROL", NULL },
  { "PORT5_MATCH_ADDR",             0x6C, NULL, "MCU PORT5 MATCH ADDR", NULL },
  { "PORT5_MATCH_ADDR_MASK",        0x70, NULL, "MCU PORT5 MATCH ADDR MASK", NULL },
  { "PORT5_WATCH_ADDR",             0x74, NULL, "MCU PORT5 WATCH ADDR", NULL },
  { "PORT5_WATCH_ADDR_ATTR",        0x78, g_csr_gen1plus_mcuport_watchaddrattr, "MCU PORT5 WATCH ADDR ATTR", NULL },
  { "INT_CNTRL_STAT",               0x7C, g_csr_gen1plus_mcu_int_CTL_STAT, "MCU INTERRUPT CONTROL STATUS", NULL },
  CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*	Use the below structure for creating trackable high level events versus 
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_gen1_mcu_specific_events[] =
{
  	{NULL, 0, "", NULL }   /* NULL Terminated */
};

static const struct ModuleReverseDefs g_gen1_mcu_sven_module =
{
	"GEN1_MCU",               
	SVEN_module_GEN1_MCU,         
    256,
#ifdef SVEN_INTERNAL_BUILD
	g_csr_gen1_mcu,              
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
	"MCU: MCU DEBUG (GEN1)",
	g_gen1_mcu_specific_events,   /* TODO-Later: Define important events specific to my module */
	NULL /* extension list */
};
