/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

#define GEN1_CSR_BASE 0x80000

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Simplest Possible example of EAS definition */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

/* Declare the bit-breakout for the register defined in the EAS_Register defs below.
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MyModule_versions.
 */
static const struct EAS_RegBits g_bit_breakout_AUDIO_CSR[] =
{
    { "XREMAP",16,16,"The address of the window into the Intel MSA address space for Intel XScale core accesses",NULL },   /* NULL Terminated */
    { "RSVD_15_8",8,8,"",NULL },   /* NULL Terminated */
    { "REMAP",4,4,"",NULL },   /* NULL Terminated */
    { "DSP_INIT",3,1,"",NULL },   /* NULL Terminated */
    { "DSP_RST",2,1,"",NULL },   /* NULL Terminated */
    { "SWRST",1,1,"Software Reset. When asserted, active low, drives reset to all dependent blocks, except DSP processor.",NULL },   /* NULL Terminated */
    { "CLKEN",0,1,"",NULL },   /* NULL Terminated */
    { NULL,0,0,"",NULL }   /* NULL Terminated */
};

static const struct EAS_RegBits g_bit_breakout_AUDIO_ISRX[] =
{
    { "RSVD_31_24",30,8,"",NULL },   /* 31:30 - Reserved */
    { "DMA3_DES",23,1,"",NULL },   /* 10 - DMA3 Destination  Interrupt pending to CPU */
    { "DMA3_SRC",22,1,"",NULL },    /* 9  - DMA3 Source Interrupt pending to CPU */
    { "DMA2_DES",21,1,"",NULL },    /* 8  - DMA2 Destination  Interrupt pending to CPU */
    { "DMA2_SRC",20,1,"",NULL },    /* 7  - DMA2 Source Interrupt pending to CPU */
    { "DMA1_DES",19,1,"",NULL },    /* 6  - DMA1 Destination  Interrupt pending to CPU */
    { "DMA1_SRC",18,1,"",NULL },    /* 5  - DMA1 Source Interrupt pending to CPU */
    { "DMA0_DES",17,1,"",NULL },    /* 4  - DMA0 Destination  Interrupt pending to CPU */
    { "DMA0_SRC",16,1,"",NULL },    /* 3  - DMA0 Source Interrupt pending to CPU */

    { "RSVD_15_11",15,5,"",NULL },

    { "IPCD",10,1,"",NULL },   /* 25 - IPCD Interrupt Request to IA CPU */
    { "IPCX", 9,1,"",NULL },   /* 24 - IPCX Interrupt Request to IA CPU */

    { "I2S3_TO_CPU",8,1,"1  Pending interrupt; 0  Not pending",NULL },
    { "I2S2_TO_CPU",7,1,"1  Pending interrupt; 0  Not pending",NULL },
    { "I2S1_TO_CPU",6,1,"1  Pending interrupt; 0  Not pending",NULL },
    { "RSVD_5_2",2,4,"",NULL },
    { "ETS1",1,1,"",NULL },        /* 1  - ETS1 Interrupt pending to CPU */
    { "ETS0",0,1,"",NULL },        /* 0  - ETS0 Interrupt pending to CPU */
    { NULL,0,0,"",NULL }          /* NULL Terminated */
};  // ISRX


static const struct EAS_RegBits g_bit_breakout_AUDIO_ISRD[] =
{
    { "DEBUG_BRK",31,1,"",NULL },
    { "RSVD_30_24",24,7,"",NULL },
    { "DMA3_DES",23,1,"",NULL },
    { "DMA3_SRC",22,1,"",NULL },
    { "DMA2_DES",21,1,"",NULL },
    { "DMA2_SRC",20,1,"",NULL },
    { "DMA1_DES",19,1,"",NULL },
    { "DMA1_SRC",18,1,"",NULL },
    { "DMA0_DES",17,1,"",NULL },
    { "DMA0_SRC",16,1,"",NULL },

    { "RSVD_15_11",15,5,"",NULL },

    { "IPCD",10,1,"",NULL },
    { "IPCX", 9,1,"Interrupt Request to MSA",NULL },

    { "I2S3_TO_DSP",8,1,"Interrupt pending to DSP",NULL },
    { "I2S2_TO_DSP",7,1,"Interrupt pending to DSP",NULL },
    { "I2S1_TO_DSP",6,1,"Interrupt pending to DSP",NULL },
    { "RSVD_5_2",2,4,"",NULL },
    { "ETS1",1,1,"",NULL },        /* 1  - ETS1 Interrupt pending to DSP */
    { "ETS0",0,1,"",NULL },        /* 0  - ETS0 Interrupt pending to DSP */
    { NULL,0,0,"",NULL }           /* NULL Terminated */
};


static const struct EAS_RegBits g_bit_breakout_AUDIO_IMRX[] =
{
    { "RSVD_31_24",24,8,"",NULL },   /* 31:30 - Reserved */
    { "DMA3_DES",23,1,"",NULL },
    { "DMA3_SRC",22,1,"",NULL },
    { "DMA2_DES",21,1,"",NULL },
    { "DMA2_SRC",20,1,"",NULL },
    { "DMA1_DES",19,1,"",NULL },
    { "DMA1_SRC",18,1,"",NULL },
    { "DMA0_DES",17,1,"",NULL },
    { "DMA0_SRC",16,1,"",NULL },

    { "RSVD_15_11",15,5,"",NULL },

    { "IPCD",10,1,"",NULL },
    { "IPCX", 9,1,"Interrupt Enable to XScale",NULL },

    { "I2S3_TO_DSP",8,1,"(audio capture) Interrupt Enable to XScale",NULL },
    { "I2S2_TO_DSP",7,1,"(stereo) interrupt Enable to XScale",NULL },
    { "I2S1_TO_DSP",6,1,"(6-channel) interrupt Enable to XScale",NULL },
    { "RSVD_5_2",2,4,"",NULL },
    { "ETS1",1,1,"",NULL },        /* 1  - ETS1 Interrupt pending to DSP */
    { "ETS0",0,1,"",NULL },        /* 0  - ETS0 Interrupt pending to DSP */
    { NULL,0,0,"",NULL }           /* NULL Terminated */
};


static const struct EAS_RegBits g_bit_breakout_AUDIO_IMRD[] =
{
    { "DEBUG_BRK",31,1,"",NULL },
    { "RSVD_30_24",24,7,"",NULL },
    { "DMA3_DES",23,1,"",NULL },
    { "DMA3_SRC",22,1,"",NULL },
    { "DMA2_DES",21,1,"",NULL },
    { "DMA2_SRC",20,1,"",NULL },
    { "DMA1_DES",19,1,"",NULL },
    { "DMA1_SRC",18,1,"",NULL },
    { "DMA0_DES",17,1,"",NULL },
    { "DMA0_SRC",16,1,"",NULL },

    { "RSVD_15_11",15,5,"",NULL },

    { "IPCD",10,1,"",NULL },
    { "IPCX", 9,1,"Interrupt Request to MSA",NULL },

    { "I2S3_TO_DSP",8,1,"Interrupt Enable to MSA",NULL },
    { "I2S2_TO_DSP",7,1,"Interrupt Enable to MSA",NULL },
    { "I2S1_TO_DSP",6,1,"Interrupt Enable to MSA",NULL },
    { "RSVD_5_2",2,4,"",NULL },
    { "ETS1",1,1,"",NULL },        /* 1  - ETS1 Interrupt pending to DSP */
    { "ETS0",0,1,"",NULL },        /* 0  - ETS0 Interrupt pending to DSP */
    { NULL,0,0,"",NULL }           /* NULL Terminated */
};

/* IPCX.Inter-process Communication Register for XScale */
static const struct EAS_RegBits g_bit_breakout_AUDIO_IPCX[] =
{
    { "BUSY",31,1,"",NULL },       /* 31 - Busy */
    { "DONE",30,1,"",NULL },       /* 30 - Done */
    { "RSVD_29_16",16,14,"",NULL },      /* 29 : 16 - reserved */
    { "CPU_MSA_MSG",0,16,"",NULL },/* 15 : 0 - CPU to Intel MSA Message */
    { NULL,0,0,"",NULL }          /* NULL Terminated */
};

/* IPCD.Inter-process Communication Register for DSP */
static const struct EAS_RegBits g_bit_breakout_AUDIO_IPCD[] =
{
    { "BUSY",31,1,"",NULL },       /* 31 - Busy */
    { "DONE",30,1,"",NULL },       /* 30 - Done */
    { "RSVD_29_16",16,14,"",NULL },      /* 29 : 16 - reserved */
    { "MSA_CPU_MSG",0,16,"",NULL },/* 15 : 0 - Intel MSA to CPU Message */
    { NULL,0,0,"",NULL }           /* NULL Terminated */
};

/* MSARVEC.Intel MSA Reset Vector  - No Break Up Needed */
/* ETS0.Interrupt Event Time Stamp Channel 0 -  No Break Up Needed */
/* ETS1.Interrupt Event Time Stamp Channel 1 -  No Break Up Needed */
/* ETS2.Interrupt Event Time Stamp Channel 2 -  No Break Up Needed */

/* SCR0 - Presentation Time Counter Control */
static const struct EAS_RegBits g_bit_breakout_AUDIO_SCR0[] =
{
    { "RSVD_31_6",3,25,"",NULL },
    { "STC_Counter_90_kHz_Prescaler_SEL",5,1,"",NULL },
    { "PREFILTER_CLOCK_SEL",3,2,"",NULL },
    { "PCR_SEL",1,2,"",NULL },
    { "Counter_Select",0,1,"",NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* SCR1 - Presentation Time Counter Control */
static const struct EAS_RegBits g_bit_breakout_AUDIO_SCR1[] =
{
    { "RSVD_31_6",3,25,"",NULL },
    { "STC_Counter_90_kHz_Prescaler_SEL",5,1,"",NULL },
    { "PREFILTER_CLOCK_SEL",3,2,"",NULL },
    { "PCR_SEL",1,2,"",NULL },
    { "Counter_Select",0,1,"",NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};



/* RXSACR0.Global Control Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_RXSACR0[] =
{
    { "RSVD_31_7",7,25,"",NULL },   /* 31 : 7 - Reserved */
    { "SEL_INPUTS",5,2,"",NULL },   /* 6 : 5 - Selects Inputs */
    { "SP_RW_FN_EN",4,1,"",NULL },  /* 4 - This bit enables a special purpose FIFO Write/Read function */
    { "RST_FIFO_REGS",3,1,"",NULL },/* 3 - Resets FIFOs logic and all registers, except this register (SACR0) */
    { "BITCLK_DIR",2,1,"",NULL },   /* 2 - This bit specifies input/output direction of BITCLK */
    { "RSVD_1_1",1,1,"",NULL },     /* 1 - Reserved */
    { "EN_RX",0,1,"",NULL },        /* 0 - Enable RX function */
    { NULL,0,0,"",NULL }           /* NULL Terminated */
};

/* RXSACR1.Serial Audio I2S/MSB-Justified Control Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_RXSACR1[] =
{
    { "RSVD_31_21",21,11,"",NULL },		/* 31 : 21 - Reserved */
    { "TS_FILTER_EN",20,1,"",NULL },		/* 20 - Timestamp Filter Enable */
    { "DMA_CONTEXT",17,3,"",NULL },		/* 19 : 17 - DMA Context Number */
    { "TS_FIFO_THLD",15,2,"",NULL },		/* 16 : 15 -  Time stamp fifo Threshold */
    { "RSVD_14_10",10,5,"",NULL },       /* 14 : 10 - Reserved */
    { "DATA_STORE_MODE",8,2,"",NULL },	/* 9 : 8  - Data Storage Mode */
    { "DATA_SAMP_SZ",7,1,"",NULL },		/* 7 - Data Sample Size */
    { "RSVD_6_0",0,7,"",NULL },			/* 6 : 0 - Reserved */
    { NULL,0,0,"",NULL }				/* NULL Terminated */
};

/* RXSASR0.Serial Audio I2S/MSB-Justified Interface and FIFO Status Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_RXSASR0[] =
{
    { "RSVD_31_11",11,21,"",NULL },			/* 31 : 11 - Reserved */
	{ "TS_FIFO_LVL",8,3,"",NULL },			/* 10 : 8 - Timestamp FIFO Level */
	{ "I2S_SHUTDN",7,1,"",NULL },			/* 7 - I2S Controller CLean Shutdown */
	{ "FIFO_OEVRRUN_INT",6,1,"",NULL },		/* 6 - FIFO Overrun */
    { "RSVD_5_5",5,1,"",NULL },				/* 5 - Reserved */
	{ "FIFO_SERVICE_REQ",4,1,"",NULL },		/* 4 - FIFO Service Request */
	{ "RSVD_3_3",3,1,"",NULL },				/* 3 - Reserved */
	{ "BUSY",2,1,"",NULL }	,				/* 2 - RX BUSY */
	{ "FIFO_EMPTY",1,1,"",NULL },			/* 1 - FIFO EMPTY */
	{ "RSVD_0_0",0,1,"",NULL },				/* 1 - Reserved */
	{ NULL,0,0,"",NULL }					/* NULL Terminated */
};

/* RXSAIMR.Serial Audio Interrupt Mask Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_RXSAIMR[] =
{
	{ "RSVD_31_16",16,16,"",NULL },   /* 31 : 16 - Reserved */
	{ "HDMI_CNTRL_FIFO_OVERRUN_INT_EN",15,1,"",NULL },	/* 15 - Enable HDMI control FIFO overrun error interrupt */
	{ "HDMI_CNTRL_FIFO_SERVICE_INT_EN",14,1,"",NULL },	/* 14 - Enable HDMI Control FIFO service interrupt */
	{ "HDMI_SYNC_ERR_INT_EN",13,1,"",NULL },				/* 13 - Enable HDMI Synch error interrupt */
	{ "HDMI_CLEAR_AVMUTE_INT_EN",12,1,"",NULL },			/* 12 - Enable HDMI Clear AVMUTE interrupt */
	{ "HDMI_SET_AVMUTE_INT_EN",11,1,"",NULL },			/* 11 - Enable HDMI Set AVMUTE interrupt */
	{ "I2S_FRAME_INT_EN",10,1,"",NULL },					/* 10 - Enable I2S Frame interrupt (valid for I2S and S/PDIF) */
	{ "SPDIF_SYNC_ERR_INT_EN",9,1,"",NULL },				/* 9 - Enable S/PDIF synch error interrupt (valid only in S/PDIF input mode) */
	{ "SPDIF_BLOCK_CMP_INT_EN",8,1,"",NULL },			/* 8 - Enable S/PDIF Block complete interrupt (Valid for HDMI and S/PDIF) */
	{ "TIME_STAMP_FIFO_SER_REQ_INT_EN",7,1,"",NULL },		/* 7 - Enable Timestamp FIFO Service Request Interrupt */
	{ "FIFO_OVERRUN_INT_EN",6,1,"",NULL },			/* 6 - Enable Receive FIFO Overrun condition based interrupt */
	{ "RSVD_5_5",5,1,"",NULL },							/* 5 - Reserved */
	{ "FIFO_SER_REQ_EN",4,1,"",NULL },				/* 4 - Enable Recieve FIFO Service Request based interrupt */
	{ "SPDIF_VAL_BIT_INT_EN",3,1,"",NULL },					/* 3 - Enable SPDIF Validity bit interrupt */
	{ "SPDIF_PAR_ERR_INT_EN",2,1,"",NULL },				/* 2 - Enable SPDIF Parity error interrupt */
	{ "RSVD_1_0",0,2,"",NULL },							/* 1 : 0 - Reserved */
	{ NULL,0,0,"",NULL }								/* NULL Terminated */
};

/* RXSAISR.Serial Audio Interrupt Status Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_RXSAISR[] =
{
	{ "RSVD_31_12",12,20,"",NULL },   /* 31 : 12 - Reserved */
	{ "HDMI_CNTRL_FIFO_OVERRUN_INT",11,1,"",NULL }, /* 11 - HDMI Control FIFO overrun error interrupt */
	{ "HDMI_CNTRL_FIFO_SERVICE_INT",10,1,"",NULL }, /* 10 - HDMI Control FIFO Service Request interrupt */
	{ "TIME_STAMP_FIFO_SER_REQ_INT",9,1,"",NULL },	/* 9 - Timestamp FIFO Service Request Interrupt */
	{ "CLEAR_FIFO_OVERRUN_INT",8,1,"",NULL },		/* 8 - Clear Receive FIFO overrun Interrupt */
	{ "HDMI_SYNC_ERR_INT",7,1,"",NULL },				/* 7 - HDMI Synch Error Interrupt */
	{ "HDMI_CLEAR_AVMUTE_INT",6,1,"",NULL },			/* 6 - HDMI Clear AV MUTE interrupt */
	{ "HDMI_SET_AVMUTE_INT",5,1,"",NULL },			/* 5 - HDMI Set AV MUTE interrupt */
	{ "I2S_FRAME_INT",4,1,"",NULL },					/* 4 - I2S/ S/PDIF Frame interrupt */
	{ "SPDIF_VAL_BIT_INT",3,1,"",NULL },				/* 3 - S/PDIF invalid bit interrupt */
	{ "SPDIF_PAR_ERR_INT",2,1,"",NULL },				/* 2 - S/PDIF Parity error interrupt */
	{ "SPDIF_BLOCK_CMP_INT",1,1,"",NULL },			/* 1 - S/PDIF Block Interrupt */
	{ "SPDIF_SYNC_ERR_INT",0,1,"",NULL },			/* 0 - S/PDIF input synch error interrupt */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* RXSADIV.Audio Clock Divider Control */
static const struct EAS_RegBits g_bit_breakout_AUDIO_RXSADIV[] =
{
	{ "RSVD_31_7",7,25,"",NULL },					/* 31 : 7 - Reserved */
	{ "AUDIO_CLK_DIV",0,7,"",NULL },					/* 6 : 0 - Audio CLock Divider */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* RXSARR.Serial Audio Receive Register - No Break Up Needed */

/* RXSAFTH.Serial Audio FIFO Threshold Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_RXSAFTH[] =
{
	{ "RSVD_31_16",16,16,"",NULL },					/* 31 : 16 - Reserved */
	{ "FIFO_THLD",0,16,"",NULL },					/* 15 : 0 - Upper FIFO Threshold of Receive Channel in words */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/*RXSADESC */
static const struct EAS_RegBits g_bit_breakout_AUDIO_RXSADESC[] =
{
	{ "FRAME_DESC",16,16,"",NULL },					/* 31 : 16 - 16-bit Frame Descriptor */
	{ "FRAME_SIZE",0,16,"",NULL },					/* 15 : 0 - Frame Size */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* RXSAFL.Serial Audio FIFO Level Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_RXSAFL[] =
{
	{ "RSVD_31_8",8,24,"",NULL },					/* 31 : 8 - Reserved */
	{ "RX_FIFO_LEVEL",0,8,"",NULL },					/* 7 : 0 - Upper FIFO level of Receive Channel in words */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* RXSATS.Audio Capture Block Timestamp - No Break Up Needed  */
/* RXSABAP.Audio Sample Block Buffer Pointer - No Break Up Needed */
/* RXSACUDR. S/PDIF Audio Capture User Data Registers - No Break Up Needed */
/* RXSACSR.Audio Capture Channel Status Registers - No Break Up Needed */
/* RXSAVR.Audio Capture Validity Status Registers  - No Break Up Needed */
/* RXSPDBP.Audio Capture SPDIF Block Address Pointer FIFO - No Break Up Needed */
/*************************************RX CHANNEL REGISTERS ENDED***************************************************/

/*************************************TX CHANNEL REGISTERS BEGIN***************************************************/
/* TXSACR0.Global Control Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_TXSACR0[] =
{
    { "SAMS",31,1,"",NULL },            /* 31 Serial Audio Mode Select */
    { "SPORT",30,1,"",NULL },           /* 30 - SPORT Audio Mode Select */
    { "RSVD_29_6",6,24,"",NULL },       /* 29 : 6 - Reserved */
    { "RX_STRF",5,1,"",NULL },          /* 5 - Select Transmit or Receive FIFO for STRF based special purpose function (0=tx,1=rx) */
    { "SP_RW_FN_EN",4,1,"",NULL } ,     /* 4 - This bit enables a special purpose FIFO Write/Read function */
    { "RST_FIFO_REGS",3,1,"",NULL },    /* 3 - Resets FIFOs logic and all registers, except this register (SACR0) */
    { "BITCLK_OUT",2,1,"",NULL },       /* 2 - Bitclk is output */
    { "BITCLK_INV",1,1,"",NULL },       /* 1 - Bitclock Polarity at pad */
    { "EN_TX",0,1,"",NULL },            /* 0 - Enable TX function */
    { NULL,0,0,"",NULL }                /* NULL Terminated */
};

/* TXSACR1.Serial Audio I2S/MSB-Justified Control Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_TXSACR1[] =
{
    { "SPDIF_VALIDITY",31,1,"",NULL },	/* 31 - SPDIF Validity Bit */
    { "RSVD_30_20",20,11,"",NULL },		/* 30 : 20 - Reserved */
    { "DMA_CONTEXT",18,2,"",NULL },		/* 19 : 19 - DMA Context Number */
    { "TS_FIFO_THLD",16,2,"",NULL },	/* 17 : 16 - Timestamp FIFO threshhold */
    { "PIN2_DIS",14,2,"",NULL },        /* 15 : 14 - Disable I2S Transmit Data Pin 2 */
    { "PIN1_DIS",12,2,"",NULL },        /* 13 : 13 - Disable I2S Transmit Data Pin 1 */
    { "PIN0_DIS",10,2,"",NULL },        /* 11 : 10 - Disable I2S Transmit Data Pin 0 */
    { "DATA_FMT",8,2,"",NULL },         /* 9 : 8  - Data Format Mode 00=5.1, 01=stereo, 10=left-mono, 11=right-mono */
    { "DATA_SAMP_SZ",7,1,"",NULL },		/* 7 - Data Sample Size 0=16b, 1=24b */
    { "LOOPBACK",5,2,"",NULL },			/* 6 : 5 - Enable I2S/MSB Interface Loop Back Function */
    { "SLIP_DIS",4,1,"",NULL },			/* 4 - Disable Time Slip (PVR) function of i2S or MSB-justified interface */
    { "REC_DIS",3,1,"",NULL },			/* 3 - Disable Recording function of i2S or MSB-justified interface */
    { "RSVD_2_1",1,2,"",NULL },			/* 2 : 1 - Reserved */
    { "ALT_MODE",0,1,"",NULL },			/* 0 - Specify Alternate Mode (I2S or MSB-Justified) Operation */
    { NULL,0,0,"",NULL }				/* NULL Terminated */
};

/* TXSASR0.Serial Audio I2S/MSB-Justified Interface and FIFO Status Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_TXSASR0[] =
{
    { "RSVD_31_11",11,21,"",NULL },			/* 31 : 11 - Reserved */
	{ "TS_FIFO_LVL",8,3,"",NULL },			/* 10 : 8 - Timestamp FIFO Level */
	{ "I2S_SHUTDN",7,1,"",NULL },			/* 7 - I2S Controller CLean Shutdown */
	{ "RX_FIFO_OVERRUN",6,1,"",NULL },		/* 6 - RX FIFO Overrun */
    { "TX_FIFO_UNDERRUN",5,1,"",NULL }, 	/* 5 - TX Fifo Underrun */
	{ "RX_FIFO_SERVICE_REQ",4,1,"",NULL },  /* 4 - RX FIFO Service Request */
	{ "TX_FIFO_SERVICE_REQ",3,1,"",NULL },	/* 3 - TX FIFO Service Request */
	{ "BUSY",2,1,"",NULL }	,				/* 2 - I2S BUSY */
	{ "RX_FIFO_NEMPTY",1,1,"",NULL },		/* 1 - RX FIFO is NOT EMPTY */
	{ "TX_FIFO_NFULL",0,1,"",NULL },		/* 0 - TX FIFO is NOT FULL */
	{ NULL,0,0,"",NULL }					/* NULL Terminated */
};

/* TXSAIMR.Serial Audio Interrupt Mask Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_TXSAIMR[] =
{
	{ "RSVD_31_16",16,16,"",NULL } ,  /* 31 : 16 - Reserved */
	{ "HDMI_CNTRL_FIFO_OVERRUN_INT_EN",15,1,"",NULL },	/* 15 - Enable HDMI control FIFO overrun error interrupt */
	{ "HDMI_CNTRL_FIFO_SERVICE_INT_EN",14,1,"",NULL },	/* 14 - Enable HDMI Control FIFO service interrupt */
	{ "HDMI_SYNC_ERR_INT_EN",13,1,"",NULL }	,			/* 13 - Enable HDMI Synch error interrupt */
	{ "HDMI_CLEAR_AVMUTE_INT_EN",12,1,"",NULL },			/* 12 - Enable HDMI Clear AVMUTE interrupt */
	{ "HDMI_SET_AVMUTE_INT_EN",11,1,"",NULL },			/* 11 - Enable HDMI Set AVMUTE interrupt */
	{ "I2S_FRAME_INT_EN",10,1,"",NULL },					/* 10 - Enable I2S Frame interrupt (valid for I2S and S/PDIF) */
	{ "SPDIF_SYNC_ERR_INT_EN",9,1,"",NULL }	,			/* 9 - Enable S/PDIF synch error interrupt (valid only in S/PDIF input mode) */
	{ "SPDIF_BLOCK_CMP_INT_EN",8,1,"",NULL },			/* 8 - Enable S/PDIF Block complete interrupt (Valid for HDMI and S/PDIF) */
	{ "TIME_STAMP_FIFO_SER_REQ_INT_EN",7,1,"",NULL },		/* 7 - Enable Timestamp FIFO Service Request Interrupt */
	{ "FIFO_OVERRUN_INT_EN",6,1,"",NULL },			/* 6 - Enable Receive FIFO Overrun condition based interrupt */
	{ "RSVD_5_5",5,1,"",NULL },							/* 5 - Reserved */
	{ "FIFO_SER_REQ_EN",4,1,"",NULL },				/* 4 - Enable Recieve FIFO Service Request based interrupt */
	{ "SPDIF_VAL_BIT_INT_EN",3,1,"",NULL }	,				/* 3 - Enable SPDIF Validity bit interrupt */
	{ "SPDIF_PAR_ERR_INT_EN",2,1,"",NULL },				/* 2 - Enable SPDIF Parity error interrupt */
	{ "RSVD_1_0",0,2,"",NULL },							/* 1 : 0 - Reserved */
	{ NULL,0,0,"",NULL }								/* NULL Terminated */
};

/* TXSAISR.Serial Audio Interrupt Status Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_TXSAISR[] =
{
	{ "RSVD_31_12",12,20,"",NULL },   /* 31 : 12 - Reserved */
	{ "HDMI_CNTRL_FIFO_OVERRUN_INT",11,1,"",NULL }, /* 11 - HDMI Control FIFO overrun error interrupt */
	{ "HDMI_CNTRL_FIFO_SERVICE_INT",10,1,"",NULL }, /* 10 - HDMI Control FIFO Service Request interrupt */
	{ "TIME_STAMP_FIFO_SER_REQ_INT",9,1,"",NULL },	/* 9 - Timestamp FIFO Service Request Interrupt */
	{ "CLEAR_FIFO_OVERRUN_INT",8,1,"",NULL },		/* 8 - Clear Receive FIFO overrun Interrupt */
	{ "HDMI_SYNC_ERR_INT",7,1,"",NULL },				/* 7 - HDMI Synch Error Interrupt */
	{ "HDMI_CLEAR_AVMUTE_INT",6,1,"",NULL }	,		/* 6 - HDMI Clear AV MUTE interrupt */
	{ "HDMI_SET_AVMUTE_INT",5,1,"",NULL },			/* 5 - HDMI Set AV MUTE interrupt */
	{ "I2S_FRAME_INT",4,1,"",NULL }	,				/* 4 - I2S/ S/PDIF Frame interrupt */
	{ "SPDIF_VAL_BIT_INT",3,1,"",NULL },				/* 3 - S/PDIF invalid bit interrupt */
	{ "SPDIF_PAR_ERR_INT",2,1,"",NULL },				/* 2 - S/PDIF Parity error interrupt */
	{ "SPDIF_BLOCK_CMP_INT",1,1,"",NULL },			/* 1 - S/PDIF Block Interrupt */
	{ "SPDIF_SYNC_ERR_INT",0,1,"",NULL },			/* 0 - S/PDIF input synch error interrupt */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TXSADIV.Audio Clock Divider Control */
static const struct EAS_RegBits g_bit_breakout_AUDIO_TXSADIV[] =
{
	{ "RSVD_31_7",7,25,"",NULL },					/* 31 : 7 - Reserved */
	{ "AUDIO_CLK_DIV",0,7,"",NULL }	,				/* 6 : 0 - Audio CLock Divider */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TXSATR.Serial Audio Transmit Register - - No Break Up Needed  */
/* TXSAFTH.Serial Audio FIFO Threshold Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_TXSAFTH[] =
{
	{ "RX_THLD",16,16,"",NULL },				    /* 31 : 16 - Reserved */
	{ "TX_THLD",0,16,"",NULL },				        /* 15 : 0 - Upper FIFO Threshold of Receive Channel in words */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TXSATR.Serial Audio Transmit Register - - No Break Up Needed  */
/* TXSAFTH.Serial Audio FIFO Threshold Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_TXSAFTHL[] =
{
	{ "RX_THLD",16,16,"",NULL },    				/* 31 : 16 - Reserved */
	{ "TX_THLD",0,16,"",NULL },	        			/* 15 : 0 - Lower FIFO Threshold of Receive Channel in words */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TXSAFL.Serial Audio FIFO Level Register */
static const struct EAS_RegBits g_bit_breakout_AUDIO_TXSAFL[] =
{
	{ "RX_LEVEL",16,16,"",NULL }	,				/* 31 : 16 - Reserved */
	{ "TX_LEVEL",0,16,"",NULL },					/* 15 : 0 - Upper FIFO Threshold of Receive Channel in words */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TX0SASUDxS/PDIF Output User Data Register Attributes - No Break Up Needed */
/*	TX0SASUDCUser Data Control Register Attributes */
static const struct EAS_RegBits g_bit_breakout_AUDIO_TXSASUDC[] =
{
	{ "RSVD_31_1",1,31,"",NULL },					/* 31 : 1 - Reserved */
	{ "LD_UD_REGISTERS",0,1,"",NULL },				/* 0 - Load the User Data registers (SASUD0  SASUD11)into buffer for insertion into S/PDIF data stream. This bit will be automatically reset to 0. */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TX0SASCSxS/PDIF Channel Status Register Attributes */
/* TX0SASCSC */

/*************************************TX CHANNEL REGISTERS ENDED***************************************************/

/**************************************DMA REGISTERS BEGIN*********************************************************/
/* CURR_DESCR - No Break Up Needed  */
/* DSTDMA_BOT - No Break Up Needed  */
/* DSTDMA_SIZE - No Break Up Needed  */
/* DSTDMA_START - No Break Up Needed  */
/* DSTDMA_STOP - No Break Up Needed  */
/* DSTDMA_TOP - No Break Up Needed  */
/* NEXT_DESCR - No Break Up Needed  */
/* SRCDMA_BOT - No Break Up Needed  */
/* SRCDMA_SIZE - No Break Up Needed  */
/* SRCDMA_START - No Break Up Needed  */
/* SRCDMA_STOP - No Break Up Needed  */
/* SRCDMA_TOP - No Break Up Needed  */

/* FLAGS MODE */
static const struct EAS_RegBits g_regbits_AUDIO_FLAGS_MODE[] =
{
      { "DMA_CONTEXT_ACTIVE",31,1,"",NULL },			/* 31 RO DMA context is active */
	  { "SRC_INT_EN",30,1,"",NULL },					/* 30 RW Source Interrupt Enable */
	  { "DST_INT_EN",29,1,"",NULL },					/* 29 RW Destination Interrupt Enable */
	  { "LINK_LIST_TERM",28,1,"",NULL },				/* 28 RW Do not fetch tje next descriptor when the current transfer has finished */
	  { "RD_SWAP_ENDIAN",27,1,"",NULL },				/* 27 RW Read Swap Endianism */
	  { "WR_SWAP_ENDIAN",26,1,"",NULL },				/* 26 RW Write Swap Endianism */
	  { "SRC_ENDIANISM",25,1,"",NULL },				/* 25 RW Source Endianism */
	  { "DST_ENDIANISM",24,1,"",NULL },				/* 24 RW Destination Endianism */
	  { "SUB_UNIT_SEL",20,4,"",NULL },				/* 23 : 20 RW Sub unit select */
	  { "XSI_DMA_GAP",61,4,"",NULL },				/* 19 :16 RW Between bursts (meaning the larger of the 2 burst sizes) the context is .locked. for <XDMA_GAP value> XSI bus clocks */
	  { "XSI_DMA_BURST_SZ",12,5,"",NULL }	,		/* 15 : 12 The DMA will transfer data to the Global Agent in bursts of this value */
	  { "DMA_BURST_SZ",8,4,"",NULL },				/* 11 : 8 The DMA will transfer data to the Local Agent in bursts of this value */
	  { "READ_EN",7,1,"",NULL },						/* 7 RW The DMA will read data from the global address space and write it into the local address space */
	  { "SRC_ADDR_MODE",5,2,"",NULL },				/* 6 : 5 Source addressing mode */
	  { "SRC_LINK_LIST",4,1,"",NULL },				/* 4 RW Source link list */
	  { "WRITE_EN",3,1,"",NULL },					/* 3 RW The DMA will read data from the local address space and write it into the global address space */
	  { "DST_ADDR_MODE",1,2,"",NULL },				/* 2 : 1 RW Destination Addressing Mode */
	  { "DST_LINK_LIST",0,1,"",NULL },				/* 0 RW Destination Link List Enable */
	  { NULL,0,0,"",NULL }							/* NULL Terminated */

};
/**************************************DMA REGISTERS END*********************************************************/


static const struct EAS_RegBits g_regbits_MSA_INT_STATUS[] =
{
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MyModule_versions.
 *      AU_AUX_BASE+0000h - AU_AUX_BASE+0FFFh   Audio Configuration and Control registers
 *      AU_AUX_BASE+1000h - AU_AUX_BASE+1FFF    DMA Contexts and Control Structures
 *      AU_AUX_BASE+2000h - AU_AUX_BASE+2FFF    I2S/SPDIF Output Channels
 *      AU_AUX_BASE+3000h - AU_AUX_BASE+3FFF    I2S Audio Capture Interfaces And HDMI audio support registers
 *      AU_AUX_BASE+4000h  AU_AUX_BASE+5FFFh   Audio Re-sampler Coefficient Memory
 *      AU_AUX_BASE+6000h  AU_AUX_BASE+6FFFh   Audio Re-sampler CSR
 */
static const struct EAS_Register g_register_AUDIO_Gen1[] =
{
   { "CSR",                  GEN1_CSR_BASE+ 0x000000,g_bit_breakout_AUDIO_CSR ,"Configuration and Status Register.",NULL },
   { "ISRX",                 GEN1_CSR_BASE+ 0x000004,g_bit_breakout_AUDIO_ISRX, "XScale Interrupt Status Register.",NULL },
   { "ISRD",                 GEN1_CSR_BASE+ 0x000008,g_bit_breakout_AUDIO_ISRD, "Intel MSA Interrupt Status Register.",NULL },
   { "IMRX",                 GEN1_CSR_BASE+ 0x00000C,g_bit_breakout_AUDIO_IMRX, "XScale Interrupt Mask Register.",NULL },
   { "IMRD",                 GEN1_CSR_BASE+ 0x000010,g_bit_breakout_AUDIO_IMRD, "Intel MSA Interrupt Mask Register.",NULL },
   { "IPCX",                 GEN1_CSR_BASE+ 0x000014,g_bit_breakout_AUDIO_IPCX, "Inter-process Communication register for XScale.",NULL },
   { "IPCD",                 GEN1_CSR_BASE+ 0x000018,g_bit_breakout_AUDIO_IPCD, "Inter-process Communication Intel MSA.",NULL },
   { "MSARVEC",              GEN1_CSR_BASE+ 0x00001C,NULL, "Intel MSA Reset Vector.",NULL },
   { "ETS0L",                GEN1_CSR_BASE+ 0x000020,NULL, "Interrupt Event Time Stamp register 0 LSB",NULL },
   { "ETS0M",                GEN1_CSR_BASE+ 0x000024,NULL, "Interrupt Event Time Stamp register 0 MSB",NULL },
   { "ETS1L",                GEN1_CSR_BASE+ 0x000028,NULL, "Interrupt Event Time Stamp register 1 LSB",NULL },
   { "ETS1M",                GEN1_CSR_BASE+ 0x00002C,NULL, "Interrupt Event Time Stamp register 1 MSB",NULL },

        // 30-3F RESERVED
	{ "AUDDEC_RESERVED1", GEN1_CSR_BASE+ 0x30,NULL, "Reserved", NULL },
	{ "AUDDEC_RESERVED2", GEN1_CSR_BASE+ 0x34,NULL, "Reserved", NULL },
	{ "AUDDEC_RESERVED3", GEN1_CSR_BASE+ 0x38,NULL, "Reserved", NULL },
	{ "AUDDEC_RESERVED4", GEN1_CSR_BASE+ 0x3C,NULL, "Reserved", NULL },

   { "SPL0",                 GEN1_CSR_BASE+ 0x000040,NULL, "Presentation Time Counter STC 0 LSB Preload Register",NULL },
   { "SPM0",                 GEN1_CSR_BASE+ 0x000044,NULL, "Presentation Time Counter STC 0 MSB Preload Register",NULL },
   { "SVL0",                 GEN1_CSR_BASE+ 0x000048,NULL, "Presentation Time Counter STC 0 LSB Current Value Register",NULL },
   { "SVM0",                 GEN1_CSR_BASE+ 0x00004C,NULL, "Presentation Time Counter STC 0 MSB Current Value Register",NULL },

   { "SPL1",                 GEN1_CSR_BASE+ 0x000050,NULL, "Presentation Time Counter STC 1 LSB Preload Register",NULL },
   { "SPM1",                 GEN1_CSR_BASE+ 0x000054,NULL, "Presentation Time Counter STC 1 MSB Preload Register",NULL },
   { "SVL1",                 GEN1_CSR_BASE+ 0x000058,NULL, "Presentation Time Counter STC 1 LSB Current Value Register",NULL },
   { "SVM1",                 GEN1_CSR_BASE+ 0x00005C,NULL, "Presentation Time Counter STC 1 MSB Current Value Register",NULL },

   { "SCR0",                 GEN1_CSR_BASE+ 0x000080,g_bit_breakout_AUDIO_SCR0, "Presentation Time Counter STC 0 Control Register",NULL },
   { "SCR1",                 GEN1_CSR_BASE+ 0x000084,g_bit_breakout_AUDIO_SCR1, "Presentation Time Counter STC 1 Control Register",NULL },

   { "ACPL",               GEN1_CSR_BASE+ 0x0000A0,NULL, "Audio Capture Timestamp LSB Preload Register",NULL },
   { "ACPM",               GEN1_CSR_BASE+ 0x0000A4,NULL, "Audio Capture Timestamp MSB Preload Register",NULL },
   { "ACVL",               GEN1_CSR_BASE+ 0x0000A8,NULL, "Audio Capture Timestamp LSB Current Value Register",NULL },
   { "ACVM",               GEN1_CSR_BASE+ 0x0000AC,NULL, "Audio Capture Timestamp MSB Current Value Register",NULL },

   /* DMA Control/Context Registers */
   { "DMA0_CURR_DESCR",      GEN1_CSR_BASE+ 0x001008,NULL ,"Current descriptor address pointer",NULL },
   { "DMA0_NEXT_DESCR",      GEN1_CSR_BASE+ 0x00100C,NULL, "Next descriptor address pointer.",NULL },
   { "DMA0_SRCDMA_START",    GEN1_CSR_BASE+ 0x001010,NULL, "Start address of the Source DMA buffer in the BI address space.",NULL },
   { "DMA0_DSTDMA_START",    GEN1_CSR_BASE+ 0x001014,NULL, "Start address of the Destination DMA buffer in the BI address space.",NULL },
   { "DMA0_SRCDMA_SIZE",     GEN1_CSR_BASE+ 0x001018,NULL, "Total size of the block of data (in bytes) to be read from the source location.",NULL },
   { "DMA0_FLAGS_MODE",      GEN1_CSR_BASE+ 0x00101C,g_regbits_AUDIO_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
   { "DMA0_SRCDMA_START_ALIAS",GEN1_CSR_BASE+ 0x001020,NULL,"This is the alias of Source DMA Start Register SRCDMA_START",NULL },
   { "DMA0_SRCDMA_BOT",      GEN1_CSR_BASE+ 0x001024,NULL, "Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA0_SRCDMA_TOP",      GEN1_CSR_BASE+ 0x001028,NULL, "Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA0_DSTDMA_BOT",      GEN1_CSR_BASE+ 0x00102C,NULL, "Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA0_DSTDMA_TOP",      GEN1_CSR_BASE+ 0x001030,NULL, "Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA0_DSTDMA_SIZE",     GEN1_CSR_BASE+ 0x001034,NULL, "Size of the block of data (in bytes) to be sent to the destination location.",NULL },
   { "DMA0_SRCDMA_STOP",     GEN1_CSR_BASE+ 0x001038,NULL, "Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
   { "DMA0_DSTDMA_STOP",     GEN1_CSR_BASE+ 0x00103C,NULL, "Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

   { "DMA1_CURR_DESCR",      GEN1_CSR_BASE+ 0x001048,NULL, " Current descriptor address pointer",NULL },
   { "DMA1_NEXT_DESCR",      GEN1_CSR_BASE+ 0x00104C,NULL, " Next descriptor address pointer.",NULL },
   { "DMA1_SRCDMA_START",    GEN1_CSR_BASE+ 0x001050,NULL, " Start address of the Source DMA buffer in the BI address space.",NULL },
   { "DMA1_DSTDMA_START",    GEN1_CSR_BASE+ 0x001054,NULL, " Start address of the Destination DMA buffer in the BI address space.",NULL },
   { "DMA1_SRCDMA_SIZE",     GEN1_CSR_BASE+ 0x001058,NULL, " Total size of the block of data (in bytes) to be read from the source location.",NULL },
   { "DMA1_FLAGS_MODE",      GEN1_CSR_BASE+ 0x00105C,g_regbits_AUDIO_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
   { "DMA1_SRCDMA_START_ALIAS",GEN1_CSR_BASE+ 0x001060,NULL," This is the alias of Source DMA Start Register SRCDMA_START",NULL },
   { "DMA1_SRCDMA_BOT",      GEN1_CSR_BASE+ 0x001064,NULL, " Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA1_SRCDMA_TOP",      GEN1_CSR_BASE+ 0x001068,NULL, " Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA1_DSTDMA_BOT",      GEN1_CSR_BASE+ 0x00106C,NULL, " Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA1_DSTDMA_TOP",      GEN1_CSR_BASE+ 0x001070,NULL, " Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA1_DSTDMA_SIZE",     GEN1_CSR_BASE+ 0x001074,NULL, " Size of the block of data (in bytes) to be sent to the destination location.",NULL },
   { "DMA1_SRCDMA_STOP",     GEN1_CSR_BASE+ 0x001078,NULL, " Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
   { "DMA1_DSTDMA_STOP",     GEN1_CSR_BASE+ 0x00107C,NULL, " Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

   { "DMA2_CURR_DESCR",      GEN1_CSR_BASE+ 0x001088,NULL, " Current descriptor address pointer",NULL },
   { "DMA2_NEXT_DESCR",      GEN1_CSR_BASE+ 0x00108C,NULL, " Next descriptor address pointer.",NULL },
   { "DMA2_SRCDMA_START",    GEN1_CSR_BASE+ 0x001090,NULL, " Start address of the Source DMA buffer in the BI address space.",NULL },
   { "DMA2_DSTDMA_START",    GEN1_CSR_BASE+ 0x001094,NULL, " Start address of the Destination DMA buffer in the BI address space.",NULL },
   { "DMA2_SRCDMA_SIZE",     GEN1_CSR_BASE+ 0x001098,NULL, " Total size of the block of data (in bytes) to be read from the source location.",NULL },
   { "DMA2_FLAGS_MODE",      GEN1_CSR_BASE+ 0x00109C,g_regbits_AUDIO_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
   { "DMA2_SRCDMA_START_ALIAS",GEN1_CSR_BASE+ 0x0010A0,NULL, " This is the alias of Source DMA Start Register SRCDMA_START",NULL },
   { "DMA2_SRCDMA_BOT",      GEN1_CSR_BASE+ 0x0010A4,NULL, " Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA2_SRCDMA_TOP",      GEN1_CSR_BASE+ 0x0010A8,NULL, " Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA2_DSTDMA_BOT",      GEN1_CSR_BASE+ 0x0010AC,NULL, " Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA2_DSTDMA_TOP",      GEN1_CSR_BASE+ 0x0010B0,NULL, " Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA2_DSTDMA_SIZE",     GEN1_CSR_BASE+ 0x0010B4,NULL, " Size of the block of data (in bytes) to be sent to the destination location.",NULL },
   { "DMA2_SRCDMA_STOP",     GEN1_CSR_BASE+ 0x0010B8,NULL, " Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
   { "DMA2_DSTDMA_STOP",     GEN1_CSR_BASE+ 0x0010BC,NULL, " Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

   { "DMA3_CURR_DESCR",      GEN1_CSR_BASE+ 0x0010C8,NULL, " Current descriptor address pointer",NULL },
   { "DMA3_NEXT_DESCR",      GEN1_CSR_BASE+ 0x0010CC,NULL, " Next descriptor address pointer.",NULL },
   { "DMA3_SRCDMA_START",    GEN1_CSR_BASE+ 0x0010D0,NULL, " Start address of the Source DMA buffer in the BI address space.",NULL },
   { "DMA3_DSTDMA_START",    GEN1_CSR_BASE+ 0x0010D4,NULL, " Start address of the Destination DMA buffer in the BI address space.",NULL },
   { "DMA3_SRCDMA_SIZE",     GEN1_CSR_BASE+ 0x0010D8,NULL, " Total size of the block of data (in bytes) to be read from the source location.",NULL },
   { "DMA3_FLAGS_MODE",      GEN1_CSR_BASE+ 0x0010DC,g_regbits_AUDIO_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
   { "DMA3_SRCDMA_START_ALIAS",GEN1_CSR_BASE+ 0x0010E0,NULL," This is the alias of Source DMA Start Register SRCDMA_START",NULL },
   { "DMA3_SRCDMA_BOT",      GEN1_CSR_BASE+ 0x0010E4,NULL, " Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA3_SRCDMA_TOP",      GEN1_CSR_BASE+ 0x0010E8,NULL, " Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA3_DSTDMA_BOT",      GEN1_CSR_BASE+ 0x0010EC,NULL, " Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA3_DSTDMA_TOP",      GEN1_CSR_BASE+ 0x0010F0,NULL, " Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
   { "DMA3_DSTDMA_SIZE",     GEN1_CSR_BASE+ 0x0010F4,NULL, " Size of the block of data (in bytes) to be sent to the destination location.",NULL },
   { "DMA3_SRCDMA_STOP",     GEN1_CSR_BASE+ 0x0010F8,NULL, " Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
   { "DMA3_DSTDMA_STOP",     GEN1_CSR_BASE+ 0x0010FC,NULL, " Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },


   /* I2S or S/PDIF or HDMI Support Registers */
   { "TX0SACR0",             GEN1_CSR_BASE+ 0x002000, g_bit_breakout_AUDIO_TXSACR0, "Global Control Register",NULL },
   { "TX0SACR1",             GEN1_CSR_BASE+ 0x002004, g_bit_breakout_AUDIO_TXSACR1, "Serial Audio I2S/MSB-Justified Control Register",NULL },
   { "TX0SASR0",             GEN1_CSR_BASE+ 0x002008, g_bit_breakout_AUDIO_TXSASR0, "Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL },
   { "TX0SAIMR",             GEN1_CSR_BASE+ 0x00200C, g_bit_breakout_AUDIO_TXSAIMR, "Serial Audio Interrupt Mask Register",NULL },
   { "TX0SAISR",             GEN1_CSR_BASE+ 0x002010, g_bit_breakout_AUDIO_TXSAISR, "Serial Audio Interrupt Status Register",NULL },
   { "TX0SADIV",             GEN1_CSR_BASE+ 0x002014, g_bit_breakout_AUDIO_TXSADIV, "Audio Clock Divider Register",NULL },
   { "TX0SATR",              GEN1_CSR_BASE+ 0x002018, NULL, "Serial Audio Transmit Register",NULL },
   { "TX0SARR",              GEN1_CSR_BASE+ 0x00201C, NULL, "Serial Audio Rx Register",NULL },
   { "TX0SAFTH",             GEN1_CSR_BASE+ 0x002020, g_bit_breakout_AUDIO_TXSAFTH, "Serial Audio FIFO Level Register",NULL },
   { "TX0SAFTHL",            GEN1_CSR_BASE+ 0x002024, g_bit_breakout_AUDIO_TXSAFTHL, "Serial Audio FIFO Level Register",NULL },
   { "TX0SAFL",              GEN1_CSR_BASE+ 0x002028, g_bit_breakout_AUDIO_TXSAFL, "Serial Audio FIFO Level Register",NULL },
   { "TX0SADESC",            GEN1_CSR_BASE+ 0x002030, NULL, "Audio Capture Descriptor Register",NULL },
   { "TX0SABAP",             GEN1_CSR_BASE+ 0x002034, NULL, "Audio Capture Buffer Address Pointer Register",NULL },
   { "TX0SATSL",             GEN1_CSR_BASE+ 0x002038, NULL, "Audio Capture Timestamp LSB",NULL },
   { "TX0SATSM",             GEN1_CSR_BASE+ 0x00203c, NULL, "Audio Capture Timestamp MSB",NULL },
   { "TX0SASUDX",            GEN1_CSR_BASE+ 0x002040, NULL, "S/PDIF transmit user data bits registers",NULL },
   { "TX0SASUDC",            GEN1_CSR_BASE+ 0x002070, g_bit_breakout_AUDIO_TXSASUDC, "S/PDIF transmit user data control Register",NULL },
   { "TX0SASCSC",            GEN1_CSR_BASE+ 0x00207C, NULL, "S/PDIF transmit Channel status ctrl Register",NULL },
   { "TX0SASCSX",            GEN1_CSR_BASE+ 0x002080, NULL, "S/PDIF transmit channel status Registers",NULL },

   { "TX1SACR0",             GEN1_CSR_BASE+ 0x002100, g_bit_breakout_AUDIO_TXSACR0, "Global Control Register",NULL },
   { "TX1SACR1",             GEN1_CSR_BASE+ 0x002104, g_bit_breakout_AUDIO_TXSACR1, "Serial Audio I2S/MSB-Justified Control Register",NULL },
   { "TX1SASR0",             GEN1_CSR_BASE+ 0x002108, g_bit_breakout_AUDIO_TXSASR0, "Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL },
   { "TX1SAIMR",             GEN1_CSR_BASE+ 0x00210C, g_bit_breakout_AUDIO_TXSAIMR, "Serial Audio Interrupt Mask Register",NULL },
   { "TX1SAISR",             GEN1_CSR_BASE+ 0x002110, g_bit_breakout_AUDIO_TXSAISR, "Serial Audio Interrupt Status Register",NULL },
   { "TX1SADIV",             GEN1_CSR_BASE+ 0x002114, g_bit_breakout_AUDIO_TXSADIV, "Audio Clock Divider Register",NULL },
   { "TX1SATR",              GEN1_CSR_BASE+ 0x002118, NULL, "Serial Audio Transmit Register",NULL },
   { "TX1SARR",              GEN1_CSR_BASE+ 0x00211C, NULL, "Serial Audio Rx Register",NULL },
   { "TX1SAFTH",             GEN1_CSR_BASE+ 0x002120, g_bit_breakout_AUDIO_TXSAFTH, "Serial Audio FIFO Level Register",NULL },
   { "TX1SAFTHL",            GEN1_CSR_BASE+ 0x002124, g_bit_breakout_AUDIO_TXSAFTHL, "Serial Audio FIFO Level Register",NULL },
   { "TX1SAFL",              GEN1_CSR_BASE+ 0x002128, g_bit_breakout_AUDIO_TXSAFL, "Serial Audio FIFO Level Register",NULL },
   { "TX1SADESC",            GEN1_CSR_BASE+ 0x002130, NULL, "Audio Capture Descriptor Register",NULL },
   { "TX1SABAP",             GEN1_CSR_BASE+ 0x002134, NULL, "Audio Capture Buffer Address Pointer Register",NULL },
   { "TX1SATSL",             GEN1_CSR_BASE+ 0x002138, NULL, "Audio Capture Timestamp LSB",NULL },
   { "TX1SATSM",             GEN1_CSR_BASE+ 0x00213c, NULL, "Audio Capture Timestamp MSB",NULL },
   { "TX1SASUDX",            GEN1_CSR_BASE+ 0x002140, NULL, "S/PDIF transmit user data bits registers",NULL },
   { "TX1SASUDC",            GEN1_CSR_BASE+ 0x002170, g_bit_breakout_AUDIO_TXSASUDC, "S/PDIF transmit user data control Register",NULL },
   { "TX1SASCSC",            GEN1_CSR_BASE+ 0x00217C, NULL, "S/PDIF transmit Channel status ctrl Register",NULL },
   { "TX1SASCSX",            GEN1_CSR_BASE+ 0x002180, NULL, "S/PDIF transmit channel status Registers",NULL },

#ifdef GEN1_PLUS_MAYBE_NOT_SURE_WHERE_THESE_CAME_FROM
   { "TX2SACR0",             GEN1_CSR_BASE+ 0x002200, g_bit_breakout_AUDIO_TXSACR0, "Global Control Register",NULL },
   { "TX2SACR1",             GEN1_CSR_BASE+ 0x002204, g_bit_breakout_AUDIO_TXSACR1, "Serial Audio I2S/MSB-Justified Control Register",NULL },
   { "TX2SASR0",             GEN1_CSR_BASE+ 0x002208, g_bit_breakout_AUDIO_TXSASR0, "Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL },
   { "TX2SAIMR",             GEN1_CSR_BASE+ 0x00220C, g_bit_breakout_AUDIO_TXSAIMR, "Serial Audio Interrupt Mask Register",NULL },
   { "TX2SAISR",             GEN1_CSR_BASE+ 0x002210, g_bit_breakout_AUDIO_TXSAISR, "Serial Audio Interrupt Status Register",NULL },
   { "TX2SADIV",             GEN1_CSR_BASE+ 0x002214, g_bit_breakout_AUDIO_TXSADIV, "Audio Clock Divider Register",NULL },
   { "TX2SATR",              GEN1_CSR_BASE+ 0x002218, NULL, "Serial Audio Transmit Register",NULL },
   { "TX2SARR",              GEN1_CSR_BASE+ 0x00221C, NULL, "Serial Audio Rx Register",NULL },
   { "TX2SAFTH",             GEN1_CSR_BASE+ 0x002220, g_bit_breakout_AUDIO_TXSAFTH, "Serial Audio FIFO Level Register",NULL },
   { "TX2SAFTHL",            GEN1_CSR_BASE+ 0x002224, g_bit_breakout_AUDIO_TXSAFTHL, "Serial Audio FIFO Level Register",NULL },
   { "TX2SAFL",              GEN1_CSR_BASE+ 0x002228, g_bit_breakout_AUDIO_TXSAFL, "Serial Audio FIFO Level Register",NULL },
   { "TX2SADESC",            GEN1_CSR_BASE+ 0x002230, NULL, "Audio Capture Descriptor Register",NULL },
   { "TX2SABAP",             GEN1_CSR_BASE+ 0x002234, NULL, "Audio Capture Buffer Address Pointer Register",NULL },
   { "TX2SATSL",             GEN1_CSR_BASE+ 0x002238, NULL, "Audio Capture Timestamp LSB",NULL },
   { "TX2SATSM",             GEN1_CSR_BASE+ 0x00223c, NULL, "Audio Capture Timestamp MSB",NULL },
   { "TX2SASUDX",            GEN1_CSR_BASE+ 0x002240, NULL, "S/PDIF transmit user data bits registers",NULL },
   { "TX2SASUDC",            GEN1_CSR_BASE+ 0x002270, g_bit_breakout_AUDIO_TXSASUDC, "S/PDIF transmit user data control Register",NULL },
   { "TX2SASCSC",            GEN1_CSR_BASE+ 0x00227C, NULL, "S/PDIF transmit Channel status ctrl Register",NULL },
   { "TX2SASCSX",            GEN1_CSR_BASE+ 0x002280, NULL, "S/PDIF transmit channel status Registers",NULL },
#endif /* GEN1_PLUS_MAYBE_NOT_SURE_WHERE_THESE_CAME_FROM */

   { "RX0SACR0",             GEN1_CSR_BASE+ 0x003000,g_bit_breakout_AUDIO_RXSACR0, "Global Control Register",NULL },
   { "RX0SACR1",             GEN1_CSR_BASE+ 0x003004,g_bit_breakout_AUDIO_RXSACR1, "Serial Audio I2S/MSB-Justified Control Register",NULL },
   { "RX0SASR0",             GEN1_CSR_BASE+ 0x003008,g_bit_breakout_AUDIO_RXSASR0, "Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL },
   { "RX0SAIMR",             GEN1_CSR_BASE+ 0x00300C,g_bit_breakout_AUDIO_RXSAIMR, "Serial Audio Interrupt Mask Register",NULL },
   { "RX0SAISR",             GEN1_CSR_BASE+ 0x003010,g_bit_breakout_AUDIO_RXSAISR, "Serial Audio Interrupt Status Register",NULL },
   { "RX0SADIV",             GEN1_CSR_BASE+ 0x003014, g_bit_breakout_AUDIO_RXSADIV,"Audio Clock Divider Register",NULL },
   { "RX0SARR",              GEN1_CSR_BASE+ 0x003018,NULL, "Serial Audio Receive Register",NULL },
   { "RX0SAFTH",             GEN1_CSR_BASE+ 0x00301C,g_bit_breakout_AUDIO_RXSAFTH, "Serial Audio FIFO Threshold Register",NULL },
   { "RX0SAFL",              GEN1_CSR_BASE+ 0x003020,g_bit_breakout_AUDIO_RXSAFL, "Serial Audio FIFO Level Register",NULL },
   { "RX0SADESC",            GEN1_CSR_BASE+ 0x003024,g_bit_breakout_AUDIO_RXSASR0, "Audio capture Block size Register",NULL },
   { "RX0SATS",              GEN1_CSR_BASE+ 0x003028,NULL, "Audio Capture block timestamp",NULL },
   { "RX0SABAP",             GEN1_CSR_BASE+ 0x00302C,NULL, "Audio Sample block buffer pointer",NULL },
   { "RX0SACUDR",            GEN1_CSR_BASE+ 0x003030,NULL, "Audio Capture User Data bit FIFO",NULL },
   { "RX0SACSR",             GEN1_CSR_BASE+ 0x003034,NULL, "Audio Capture Channel Status bit FIFO",NULL },
   { "RX0SAVR",              GEN1_CSR_BASE+ 0x003038,NULL, "Audio Capture Validity bit FIFO",NULL },
   { "RX0SPDBP",             GEN1_CSR_BASE+ 0x00303C,NULL, "Audio Capture SPDIF Block address Pointer FIFO",NULL },

#ifdef GEN1_PLUS_MAYBE_NOT_SURE_WHERE_THESE_CAME_FROM
   { "RX1SACR0",             GEN1_CSR_BASE+ 0x003100,g_bit_breakout_AUDIO_RXSACR0, "Global Control Register",NULL },
   { "RX1SACR1",             GEN1_CSR_BASE+ 0x003104,g_bit_breakout_AUDIO_RXSACR1,"Serial Audio I2S/MSB-Justified Control Register",NULL },
   { "RX1SASR0",             GEN1_CSR_BASE+ 0x003108,g_bit_breakout_AUDIO_RXSASR0, "Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL },
   { "RX1SAIMR",             GEN1_CSR_BASE+ 0x00310C,g_bit_breakout_AUDIO_RXSAIMR, "Serial Audio Interrupt Mask Register",NULL },
   { "RX1SAISR",             GEN1_CSR_BASE+ 0x003110,g_bit_breakout_AUDIO_RXSAISR, "Serial Audio Interrupt Status Register",NULL },
   { "RX1SADIV",             GEN1_CSR_BASE+ 0x003114,g_bit_breakout_AUDIO_RXSADIV, "Audio Clock Divider Register",NULL },
   { "RX1SARR",              GEN1_CSR_BASE+ 0x003118,NULL, "Serial Audio Receive Register",NULL },
   { "RX1SAFTH",             GEN1_CSR_BASE+ 0x00311C,g_bit_breakout_AUDIO_RXSAFTH, "Serial Audio FIFO Threshold Register",NULL },
   { "RX1SAFL",              GEN1_CSR_BASE+ 0x003120,g_bit_breakout_AUDIO_RXSAFL, "Serial Audio FIFO Level Register",NULL },
   { "RX1SADESC",            GEN1_CSR_BASE+ 0x003124,NULL, "Audio capture Block size Register",NULL },
   { "RX1SATS",              GEN1_CSR_BASE+ 0x003128,NULL, "Audio Capture block timestamp",NULL },
   { "RX1SABAP",             GEN1_CSR_BASE+ 0x00312C,NULL, "Audio Sample block buffer pointer",NULL },
   { "RX1SACUDR",            GEN1_CSR_BASE+ 0x003130,NULL, "Audio Capture User Data bit FIFO",NULL },
   { "RX1SACSR",             GEN1_CSR_BASE+ 0x003134,NULL, "Audio Capture Channel Status bit FIFO",NULL },
   { "RX1SAVR",              GEN1_CSR_BASE+ 0x003138,NULL, "Audio Capture Validity bit FIFO",NULL },
   { "RX1SPDBP",             GEN1_CSR_BASE+ 0x00313C,NULL, "Audio Capture SPDIF Block address Pointer FIFO",NULL },
#endif /* GEN1_PLUS_MAYBE_NOT_SURE_WHERE_THESE_CAME_FROM */

    CSR_NULL_TERM()

};

#ifdef OLD_AND_UNUSED
static const struct EAS_Register g_csr_GEN1_AUDIO[] =
{
    { "CSR_0",		0x0000,NULL, "Configuration and Status Register.",NULL },
    { "ISRX_0",		0x0004,NULL, "IA32 Interrupt Status Register.",NULL },
    { "ISRD_0",		0x0008,NULL, "Intel MSA Interrupt Status Register.",NULL },
    { "IMRX_0",		0x000C,NULL, "IA32 Interrupt Mask Register.",NULL },
    { "IMRD_0",		0x0010,NULL, "Intel MSA Interrupt Mask Register.",NULL },
    { "IPCX_0",		0x0014,NULL, "Inter-process Communication register for IA32 CPU.",NULL },
    { "IPCD_0",		0x0018,NULL, "Inter-process Communication Intel MSA.",NULL },
    { "MSARVEC_0",	0x001C,NULL, "Intel MSA Reset Vector.",NULL },
    { "ETS0L_0",	0x0020,NULL, "Interrupt Event Time Stamp register 0 LSB",NULL },
    { "ETS0M_0",	0x0024,NULL, "Interrupt Event Time Stamp register 0 MSB",NULL },
    { "ETS1L_0",	0x0028,NULL, "Interrupt Event Time Stamp register 1 LSB",NULL },
    { "ETS1M_0",	0x002C,NULL, "Interrupt Event Time Stamp register 2 MSB",NULL },
    { "RESERVED00", 0x0030,NULL, "Reserved for future use",NULL },
    { "SPL0_0",		0x0040,NULL, "Presentation Time Counter STC 0 LSB Preload register ",NULL },
    { "SPM0_0",		0x0044,NULL, "Presentation Time Counter STC 0 MSB Preload register ",NULL },
    { "SVL0_0",		0x0048,NULL, "Presentation Time Counter STC 0 LSB Curent Register",NULL },
	{ "SVM0_0",		0x004C,NULL, "Presentation Time Counter STC 0 MSB Current Register",NULL },
	{ "SPL1_0",		0x0050,NULL, "Presentation Time Counter STC 1 LSB Preload register ",NULL },
    { "SPM1_0",		0x0054,NULL, "Presentation Time Counter STC 1 MSB Preload register ",NULL },
    { "SVL1_0",		0x0058,NULL, "Presentation Time Counter STC 1 LSB Curent Register",NULL },
	{ "SVM1_0",		0x005C,NULL, "Presentation Time Counter STC 1 MSB Current Register",NULL },
	{ "RESERVED10",	0x0060,NULL, "Reserved for future use",NULL },
    { "SCR0_0",		0x0080,g_csr_AUDIO_SCR0, "Presentation time counter select register 0",NULL },
    { "SCR1_0",		0x0084,g_csr_AUDIO_SCR1, "Presentation time counter select register 1",NULL },
    { "ACPL_0",		0x00A0,NULL, "Audio Capture Timestamp  LSB Preload register ",NULL },
	{ "ACPM_0",		0x00A4,NULL, "Audio Capture Timestamp  MSB Preload register ",NULL },
	{ "AVPL_0",		0x00A8,NULL, "Audio Capture Timestamp  LSB Curent Register",NULL },
	{ "AVPL_0",		0x00AC,NULL, "Audio Capture Timestamp  MSB Current Register",NULL },
    { "CSR_1",		0x1000,NULL, "Configuration and Status Register.",NULL },
	{ "ISRX_1",		0x1004,NULL, "IA32 Interrupt Status Register.",NULL },
	{ "ISRD_1",		0x1008,NULL, "Intel MSA Interrupt Status Register.",NULL },
	{ "IMRX_1",		0x100C,NULL, "IA32 Interrupt Mask Register.",NULL },
	{ "IMRD_1",		0x1010,NULL, "Intel MSA Interrupt Mask Register.",NULL },
	{ "IPCX_1",		0x1014,NULL, "Inter-process Communication register for IA32 CPU.",NULL },
	{ "IPCD_1",		0x1018,NULL, "Inter-process Communication Intel MSA.",NULL },
	{ "MSARVEC_1",	0x101C,NULL, "Intel MSA Reset Vector.",NULL },
	{ "ETS0L_1",	0x1020,NULL, "Interrupt Event Time Stamp register 0 LSB",NULL },
	{ "ETS0M_1",	0x1024,NULL, "Interrupt Event Time Stamp register 0 MSB",NULL },
	{ "ETS1L_1",	0x1028,NULL, "Interrupt Event Time Stamp register 1 LSB",NULL },
	{ "ETS1M_1",	0x102C,NULL, "Interrupt Event Time Stamp register 2 MSB",NULL },
	{ "RESERVED01",	0x1030,NULL, "Reserved for future use",NULL },
	{ "SPL0_1",		0x1040,NULL, "Presentation Time Counter STC 0 LSB Preload register ",NULL },
	{ "SPM0_1",		0x1044,NULL, "Presentation Time Counter STC 0 MSB Preload register ",NULL },
	{ "SVL0_1",		0x1048,NULL, "Presentation Time Counter STC 0 LSB Curent Register",NULL },
	{ "SVM0_1",		0x104C,NULL, "Presentation Time Counter STC 0 MSB Current Register",NULL },
	{ "SPL1_1",		0x1050,NULL, "Presentation Time Counter STC 1 LSB Preload register ",NULL },
	{ "SPM1_1",		0x1054,NULL, "Presentation Time Counter STC 1 MSB Preload register ",NULL },
	{ "SVL1_1",		0x1058,NULL, "Presentation Time Counter STC 1 LSB Curent Register",NULL },
	{ "SVM1_1",		0x105C,NULL, "Presentation Time Counter STC 1 MSB Current Register",NULL },
	{ "RESERVED11",	0x1060,NULL, "Reserved for future use",NULL },
	{ "SCR0_1",		0x1080,g_csr_AUDIO_SCR0, "Presentation time counter select register 0",NULL },
	{ "SCR1_1",		0x1084,g_csr_AUDIO_SCR1, "Presentation time counter select register 1",NULL },
	{ "ACPL_1",		0x10A0,NULL, "Audio Capture Timestamp  LSB Preload register ",NULL },
	{ "ACPM_1",		0x10A4,NULL, "Audio Capture Timestamp  MSB Preload register ",NULL },
	{ "AVPL_1",		0x10A8,NULL, "Audio Capture Timestamp  LSB Curent Register",NULL },
	{ "AVPL_1",		0x10AC,NULL, "Audio Capture Timestamp  MSB Current Register",NULL },
    { "CSR_2",		0x2000,NULL, "Configuration and Status Register.",NULL },
	{ "ISRX_2",		0x2004,NULL, "IA32 Interrupt Status Register.",NULL },
	{ "ISRD_2",		0x2008,NULL, "Intel MSA Interrupt Status Register.",NULL },
	{ "IMRX_2",		0x200C,NULL, "IA32 Interrupt Mask Register.",NULL },
	{ "IMRD_2",		0x2010,NULL, "Intel MSA Interrupt Mask Register.",NULL },
	{ "IPCX_2",		0x2014,NULL, "Inter-process Communication register for IA32 CPU.",NULL },
	{ "IPCD_2",		0x2018,NULL, "Inter-process Communication Intel MSA.",NULL },
	{ "MSARVEC_2",	0x201C,NULL, "Intel MSA Reset Vector.",NULL },
	{ "ETS0L_2",	0x2020,NULL, "Interrupt Event Time Stamp register 0 LSB",NULL },
	{ "ETS0M_2",	0x2024,NULL, "Interrupt Event Time Stamp register 0 MSB",NULL },
	{ "ETS1L_2",	0x2028,NULL, "Interrupt Event Time Stamp register 1 LSB",NULL },
	{ "ETS1M_2",	0x202C,NULL, "Interrupt Event Time Stamp register 2 MSB",NULL },
	{ "RESERVED02",	0x2030,NULL, "Reserved for future use",NULL },
	{ "SPL0_2",		0x2040,NULL, "Presentation Time Counter STC 0 LSB Preload register ",NULL },
	{ "SPM0_2",		0x1044,NULL, "Presentation Time Counter STC 0 MSB Preload register ",NULL },
	{ "SVL0_2",		0x2048,NULL, "Presentation Time Counter STC 0 LSB Curent Register",NULL },
	{ "SVM0_2",		0x204C,NULL, "Presentation Time Counter STC 0 MSB Current Register",NULL },
	{ "SPL1_2",		0x2050,NULL, "Presentation Time Counter STC 1 LSB Preload register ",NULL },
	{ "SPM1_2",		0x2054,NULL, "Presentation Time Counter STC 1 MSB Preload register ",NULL },
	{ "SVL1_2",		0x2058,NULL, "Presentation Time Counter STC 1 LSB Curent Register",NULL },
	{ "SVM1_2",		0x205C,NULL, "Presentation Time Counter STC 1 MSB Current Register",NULL },
	{ "RESERVED12",	0x2060,NULL, "Reserved for future use",NULL },
	{ "SCR0_2",		0x2080,g_csr_AUDIO_SCR0, "Presentation time counter select register 0",NULL },
	{ "SCR1_2",		0x2084,g_csr_AUDIO_SCR1, "Presentation time counter select register 1",NULL },
	{ "ACPL_2",		0x20A0,NULL, "Audio Capture Timestamp  LSB Preload register ",NULL },
	{ "ACPM_2",		0x20A4,NULL, "Audio Capture Timestamp  MSB Preload register ",NULL },
	{ "AVPL_2",		0x20A8,NULL, "Audio Capture Timestamp  LSB Curent Register",NULL },
	{ "AVPL_2",		0x20AC,NULL, "Audio Capture Timestamp  MSB Current Register",NULL },
    { "CSR_3",		0x3000,NULL, "Configuration and Status Register.",NULL },
	{ "ISRX_3",		0x3004,NULL, "IA32 Interrupt Status Register.",NULL },
	{ "ISRD_3",		0x3008,NULL, "Intel MSA Interrupt Status Register.",NULL },
	{ "IMRX_3",		0x300C,NULL, "IA32 Interrupt Mask Register.",NULL },
	{ "IMRD_3",		0x3010,NULL, "Intel MSA Interrupt Mask Register.",NULL },
	{ "IPCX_3",		0x3014,NULL, "Inter-process Communication register for IA32 CPU.",NULL },
	{ "IPCD_3",		0x3018,NULL, "Inter-process Communication Intel MSA.",NULL },
	{ "MSARVEC_3",	0x301C,NULL, "Intel MSA Reset Vector.",NULL },
	{ "ETS0L_3",	0x3020,NULL, "Interrupt Event Time Stamp register 0 LSB",NULL },
	{ "ETS0M_3",	0x3024,NULL, "Interrupt Event Time Stamp register 0 MSB",NULL },
	{ "ETS1L_3",	0x3028,NULL, "Interrupt Event Time Stamp register 1 LSB",NULL },
	{ "ETS1M_3",	0x302C,NULL, "Interrupt Event Time Stamp register 2 MSB",NULL },
	{ "RESERVED03",	0x3030,NULL, "Reserved for future use",NULL },
	{ "SPL0_3",		0x3040,NULL, "Presentation Time Counter STC 0 LSB Preload register ",NULL },
	{ "SPM0_3",		0x3044,NULL, "Presentation Time Counter STC 0 MSB Preload register ",NULL },
	{ "SVL0_3",		0x3048,NULL, "Presentation Time Counter STC 0 LSB Curent Register",NULL },
	{ "SVM0_3",		0x304C,NULL, "Presentation Time Counter STC 0 MSB Current Register",NULL },
	{ "SPL1_3",		0x3050,NULL, "Presentation Time Counter STC 1 LSB Preload register ",NULL },
	{ "SPM1_3",		0x3054,NULL, "Presentation Time Counter STC 1 MSB Preload register ",NULL },
	{ "SVL1_3",		0x3058,NULL, "Presentation Time Counter STC 1 LSB Curent Register",NULL },
	{ "SVM1_3",		0x305C,NULL, "Presentation Time Counter STC 1 MSB Current Register",NULL },
	{ "RESERVED13",	0x3060,NULL, "Reserved for future use",NULL },
	{ "SCR0_3",		0x3080,g_csr_AUDIO_SCR0, "Presentation time counter select register 0",NULL },
	{ "SCR1_3",		0x3084,g_csr_AUDIO_SCR1, "Presentation time counter select register 1",NULL },
	{ "ACPL_3",		0x30A0,NULL, "Audio Capture Timestamp  LSB Preload register ",NULL },
	{ "ACPM_3",		0x30A4,NULL, "Audio Capture Timestamp  MSB Preload register ",NULL },
	{ "AVPL_3",		0x30A8,NULL, "Audio Capture Timestamp  LSB Curent Register",NULL },
	{ "AVPL_3",		0x30AC,NULL, "Audio Capture Timestamp  MSB Current Register",NULL },

    CSR_NULL_TERM()
};
#endif /* OLD_AND_UNUSED */
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_gen1_AUDIO_specific_events[] =
{
    { "DEC_FRAME_PUSH", 1, " PTS_low:%d, Size:%d", NULL },
    { "ES_SCRUB_FRAME_PUSH",      2,      " PTS_low:%d, Size:%d", NULL },
    { "RESAM_FRAME_PUSH", 3,      "avdl_auddec_start()", NULL },
    { "SET_TIMEBASE", 4,      " timebase:%d", NULL },  
    { "I2S_ENABLED", 5,      "", NULL },      
    { "ATC_WRITE", 6,      " offset:%d, size:%d, buf_size:%d location:%d rp:0x%x wp:0x%x", NULL }, 
    { "ALSA_WRITE", 7,      " offset:%d, size:%d, buf_size:%d location:%d rp:0x%x wp:0x%x", NULL }, 
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_gen1_AUDIO_sven_module =
{
    "GEN1_AUDIO",               /* Module Name */
    SVEN_module_GEN1_AUDIO,     /* Module ID> */
    1024*1024,                  /* Memory size of register space */
#ifdef SVEN_INTERNAL_BUILD
    g_register_AUDIO_Gen1,      /* What is the latest HW version to use? */
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "AUDIO: AUDIO (GEN1)",      /* TODO: Get a better text string */
    g_gen1_AUDIO_specific_events, /* TODO-Later: Define important events specific to my module */
    NULL /* extension list */
};
