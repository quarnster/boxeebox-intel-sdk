/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

static const struct EAS_RegBits g_csr_gen1plus_XAB_DBG_CTL[] = 
{
    /* Copied from EAS */
    {"RESERVED_3",                30, 2, "Reserved", NULL },
    {"PORT_ISSUE_CNTR_THRESH",    24, 6, "Port Issye Counter Threshold", NULL },
    {"PORT_ISSUE_CNTR",           18, 6, "Port Issue Counter", NULL },
    {"PORT_ISSUE_CNTR_RST",       17, 1, "Port Issue Counter Reset", NULL },
    {"PORT_ISSUE_CNTR_EN",        16, 1, "Port Iissue Counter Enable", NULL },
    {"RESERVED_1",                10, 6, "Reserved", NULL },
    {"SAP_PORT_DIS",              2, 8, "SAP Port DISABLE", NULL },
    {"XSI_ISSUE_DIS",             1, 1, "XSI ISSUE DISABLE", NULL },
    {"XAB_DEBUG_MODE_EN",         0, 1, "XAB Debug Mode Enable", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_gen1plus_xab_watchaddrattr[] = 
{
    /* Copied from EAS */
    {"Tag",            27, 5, "Watch Address Tag", NULL },
    {"RESERVED_5",            26, 1, "Reserved", NULL },
    {"TYPE",            17, 9, "Watch Address type", NULL },
    {"BYTE_COUNT",            8, 9, "Watch address Byte Count", NULL },
    {"READ_WRITE_CMD",              0, 8, "Read/Write Command", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen1plus_xab_int_CTL_STAT[] = 
{
    /* Copied from EAS */
    {"RESERVED_6",            5, 27, "Reserved", NULL },
    {"XAB_DBG_INT_ST",        4, 1, "XAB Counter Match Intr Stat", NULL },
    {"RESERVED_7",            1, 3, "Reserved", NULL },
    {"XAB_DBG_INT_EN",        0, 1, "XAB Debug Counter Match Intr En", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_Register g_csr_gen1_xab[] =
{
  { "XAB_DEBUG_CNTRL",            0x00, g_csr_gen1plus_XAB_DBG_CTL, "XAB DEBUG CONTROL", NULL },
  { "XAB_MATCH_ADDR",            0x04, NULL, "XAB MATCH ADDR", NULL },
  { "XAB_MATCH_ADDR_MASK",        0x08, NULL, "XAB MATCH ADDR MASK", NULL },
  { "PORT0_WATCH_ADDR",          0x0C, NULL, "XAB WATCH ADDR", NULL }, 
  { "PORT0_WATCH_ADDR_ATTR",     0x10, g_csr_gen1plus_xab_watchaddrattr, "XAB WATCH ADDR ATTR", NULL },
  { "INT_CNTRL_STAT",            0x14, g_csr_gen1plus_xab_int_CTL_STAT, "XAB INTERRUPT CONTROL STATUS", NULL },
  CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*	Use the below structure for creating trackable high level events versus 
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_gen1_xab_vid_specific_events[] =
{
  	{NULL, 0, "", NULL }   /* NULL Terminated */
};

static const struct ModuleReverseDefs g_gen1_xab_vid_sven_module =
{
	"GEN1_XAB_VID",               
	SVEN_module_GEN1_XAB_VID,         
    256,
#ifdef SVEN_INTERNAL_BUILD
	g_csr_gen1_xab,              
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
	"XAB VID: XAB VID DEBUG (Olo)",
	g_gen1_xab_vid_specific_events,
	NULL /* extension list */
};

static const struct SVEN_Module_EventSpecific g_gen1_xab_aper_specific_events[] =
{
  	{NULL, 0, "", NULL }   /* NULL Terminated */
};

static const struct ModuleReverseDefs g_gen1_xab_aper_sven_module =
{
	"GEN1_XAB_APER",               
	SVEN_module_GEN1_XAB_APER,         
    256,
#ifdef SVEN_INTERNAL_BUILD
	g_csr_gen1_xab,              
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
	"XAB APER: XAB APER DEBUG (Olo)",
	g_gen1_xab_aper_specific_events,
	NULL /* extension list */
};

static const struct SVEN_Module_EventSpecific g_gen1_xab_xport_specific_events[] =
{
  	{NULL, 0, "", NULL }   /* NULL Terminated */
};

static const struct ModuleReverseDefs g_gen1_xab_xport_sven_module =
{
	"GEN1_XAB_XPORT",               
	SVEN_module_GEN1_XAB_XPORT,         
    256,
#ifdef SVEN_INTERNAL_BUILD
	g_csr_gen1_xab,              
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
	"XAB XPORT: XAB XPORT DEBUG (GEN1)",
	g_gen1_xab_xport_specific_events,
	NULL /* extension list */
};
