/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

static const struct EAS_Register g_csr_GEN1_EXPBUS[] =
{
{ "EXP_TIMING_CS0", 0x00, NULL,	"Timing & Control Register for Chip Select 0", NULL  },
{ "EXP_TIMING_CS1", 0x04, NULL,	"Timing & Control Register for Chip Select 1",  NULL  },
{ "EXP_TIMING_CS2", 0x08, NULL,	"Timing & Control Register for Chip Select 2",  NULL  },
{ "EXP_TIMING_CS3", 0x0C, NULL,	"Timing & Control Register for Chip Select 3 ",  NULL  },
{ "EXP_TIMING_CS4", 0x10, NULL,	"Timing & Control Register for Chip Select 4 ",  NULL  },
{ "EXP_TIMING_CS5", 0x14, NULL,	"Timing & Control Register for Chip Select 5",  NULL },
{ "EXP_TIMING_CS6", 0x18, NULL,	"Timing & Control Register for Chip Select 6",  NULL },
{ "EXP_TIMING_CS7", 0x1C, NULL,	"Timing & Control Register for Chip Select 7",  NULL  },
{ "NAND_CMD", 		0x30, NULL,	"NAND Memory interface Command and Mode Register",  NULL  },
{ "NAND_ADDR", 	0x34,	  NULL, "NAND Memory interface Address and Action Register",  NULL },
};
#endif /* !SVEN_INTERNAL_BUILD */


static const struct SVEN_Module_EventSpecific g_GEN1_EXPBUS_specific_events[] =
{

/******EXAMPLES*******

    { "OUT_FIFO_FULL",      1,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    2,      "", NULL },

 ****END EXAMPLES*****/

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN1_EXPBUS_sven_module =
{
    "GEN1_EXPBUS",
    SVEN_module_GEN1_EXPBUS,
    256,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN1_EXPBUS,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "EXPBUS: EXPBUS Function (GEN1)",
    g_GEN1_EXPBUS_specific_events,           /* TODO-Later: Define important events specific to my module */
    NULL                            /* extension list */
};
