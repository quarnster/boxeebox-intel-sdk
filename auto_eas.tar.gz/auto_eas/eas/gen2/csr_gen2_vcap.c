/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
static const struct EAS_RegBits g_csr_gen1_vcap_CONTROL[] = {
    { "RESERVED",         		3, 29,"RESERVED", NULL },
    { "BT656_LLC_INVERT_CTL",   1, 1, "Video Capture Enable", NULL },
    { "VCAP_ENABLE",        	0, 1, "BT656_LLC clock invert control", NULL },
    CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen1_vcap_INT_STATUS[] = {
    { "RESERVED",               8, 24, "RESERVED", NULL },
    { "BT656_SYNC_ERROR",		7, 1, "BT656 Sync Error", NULL},
    { "PDMA_IS_STALLED",		6, 1, "Pixel DMA is stalled", NULL },
    { "C_ADDR_OUT_OF_RANGE",	5, 1, "Chroma address out of range", NULL },
    { "Y_ADDR_OUT_OF_RANGE",	4, 1, "Luma address out of range", NULL },
    { "BOTTOM_FIELD_DONE1",		3, 1, "Frame buffer 1 bottom field done", NULL },
    { "TOP_FIELD_DONE1",		2, 1, "Frame buffer 1 top field done", NULL },
    { "BOTTOM_FIELD_DONE0",		1, 1, "Frame buffer 0 bottom field done", NULL },
    { "TOP_FIELD_DONE0",		0, 1, "Frame buffer 0 top field done", NULL },
    CSR_BB_NULL_TERM()
};


static const struct EAS_RegBits g_csr_gen1_vcap_BT656_CONTROL[] = {
	{ "RESERVED",				8, 24, "RESERVED", NULL },
	{ "PGEN_MODE",				4, 4, "Video Test Pattern Generator Mode Select", NULL },
	{ "PGEN_EN",				3, 1, "Video Test Pattern Generator Enable", NULL },
	{ "BT656_IN_DISABLE",		2, 1, "BT.656 Input Disable", NULL },
	{ "SWAP_MODE",				0, 2, "BT.656 Decoder Luma/Chroma Swap Mode", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen1_vcap_VRT_START[] = {
	{ "RESERVED_0",			26, 6, "RESERVED", NULL },
	{ "BOTTOM_VRT_START",	16, 10, "The starting line number for the top field", NULL },
	{ "RESERVED_1", 			10, 6, "RESERVED", NULL },
	{ "TOP_VRT_START",		0, 10, "The starting line number for the bottom field", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen1_vcap_VRT_END[] = {
	{ "RESERVED_0",			26, 6, "RESERVED", NULL },
	{ "BOTTOM_VRT_END",		16, 10, "The ending line number for the top field", NULL },
	{ "RESERVED_1", 			10, 6, "RESERVED", NULL },
	{ "TOP_VRT_END",		0, 10, "The ending line number for the bottom field", NULL },
	CSR_BB_NULL_TERM()
};		

static const struct EAS_RegBits g_csr_gen1_vcap_PDMA_CTL[] = {
	{ "RESERVED",			7, 25, "RESERVED", NULL },
	{ "DMA_XFER_SIZE_SEL",	5, 2, "DMA Transfer Size Select", NULL },
	{ "PDMA_STALL",			4, 1, "Stall Pixel DMA", NULL },
	{ "CC_EN",				3, 1, "Capture closed caption line", NULL },
	{ "BIG_ENDIAN",			2, 1, "Big Endian", NULL },
	{ "PDMA_FIFO_AUTO_FLUSH_DIS", 1, 1, "Pixel DMA FIFO Auto Flush Disable", NULL },
	{ "PROGRESSIVE",		0, 1, "Progressive Scan Mode", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen1_vcap_CC_LINE[] = {
	{ "RESERVED_0",			26, 6, "RESERVED", NULL },
	{ "bottom_cc_line",     16, 10, "Close caption line number for the top field", NULL },
	{ "RESERVED_1", 			10, 6, "RESERVED", NULL },
	{ "top_cc_line",		0, 10, "Close caption line number for the bottom field", NULL },
	CSR_BB_NULL_TERM()
};
	

/*** REGISTER DEFINITIONS ***/
static const struct EAS_Register g_csr_gen1_vcap[] = {
/* Global Register Definitions */
	{ "GLOBAL_CTL",			0x00, g_csr_gen1_vcap_CONTROL, "VIDEO CAPTURE GLOBAL CONTROL", NULL },
	{ "INT_STATUS",			0x04, g_csr_gen1_vcap_INT_STATUS, "VIDEO CAPTURE INTERRUPT STATUS", NULL },
	{ "INT_MASK",			0x08, NULL, "VIDEO CAPTURE INTERRUPT MASK", NULL },

/* BT.656 Decoder Register Definitions */
	{ "BT656_CTL",			0x0C, g_csr_gen1_vcap_BT656_CONTROL, "VIDEO CAPTURE BT.656 DECODER CONTROL", NULL 
	},

/* 4:2:2-to-4:2:0 Filter Register Definitions */
	{ "FILTER_CTL",			0x10, NULL, "VIDEO CAPTURE 4:2:2-TO-4:2:0 FILTER CONTROL", NULL },
	{ "FILTER_VRT_START",	0x14, g_csr_gen1_vcap_VRT_START, "VIDEO CAPTURE 4:2:2-TO-4:2:0 FILTER VERTICAL LINE START", NULL },
	{ "FILTER_VRT_END",		0x18, g_csr_gen1_vcap_VRT_END, "VIDEO CAPTURE 4:2:2-TO-4:2:0 FILTER VERTICAL LINE END", NULL },

/* Pixel DMA Register Definitions */
	{ "PDMA_CTL",			0x1C, g_csr_gen1_vcap_PDMA_CTL,	"VIDEO CAPTURE PIXEL DMA CONTROL", NULL },
	{ "Y_ADDR0",			0x20, NULL,	"CAPTURE LUMA FRAME BUFFER 0 ADDRESS", NULL },
	{ "C_ADDR0",			0x24, NULL,	"CAPTURE CHROMA FRAME BUFFER 0 ADDRESS", NULL },
	{ "Y_PITCH0",			0x28, NULL,	"CAPTURE LUMA FRAME BUFFER 0 PITCH", NULL },
	{ "C_PITCH0",			0x2C, NULL,	"CAPTURE CHROMA FRAME BUFFER 0 PITCH", NULL },
	{ "Y_ADDR1",			0x30, NULL,	"CAPTURE LUMA FRAME BUFFER 1 ADDRESS", NULL },
	{ "C_ADDR1",			0x34, NULL,	"CHROMA FRAME BUFFER 1 ADDRESS", NULL },
	{ "Y_PITCH1",			0x38, NULL,	"LUMA FRAME BUFFER 1 PITCH", NULL },
	{ "C_PITCH1",			0x3C, NULL,	"CHROMA FRAME BUFFER 1 PITCH", NULL },
	{ "CC_ADDR0",			0x40, NULL,	"CLOSED CAPTION BUFFER 0 ADDRESS", NULL },
	{ "CC_ADDR1",			0x44, NULL,	"CLOSED CAPTION BUFFER 1 ADDRESS", NULL },
	{ "CC_LINE",			0x48, g_csr_gen1_vcap_CC_LINE,	"CLOSED CAPTION LINE NUMBER", NULL },
	{ "CROP_VRT_START",		0x4C, g_csr_gen1_vcap_VRT_START,	"VERTICAL CROP LINE START", NULL },
	{ "CROP_VRT_END",		0x50, g_csr_gen1_vcap_VRT_END,	"VERTICAL CROP LINE END", NULL },
	{ "CROP_HRZ_START",		0x54, NULL,	"HORIZONTAL CROP PIXEL START", NULL },
	{ "CROP_HRZ_END",		0x58, NULL,	"HORIZONTAL CROP PIXEL END", NULL },

/* Time Stamp Register Definitions */
	{ "TS_CTL",				0x5C, NULL,	"TIME STAMP CONTROL", NULL },
	{ "TS_PRELOAD_LSB",		0x60, NULL,	"TIME STAMP PRELOAD LSB", NULL },
	{ "TS_PRELOAD_MSB",		0x64, NULL,	"TIME STAMP PRELOAD MSB", NULL },
	{ "TS_LSB0",			0x68, NULL,	"TIMESTAMP LSB BUFFER 0", NULL },
	{ "TS_MSB0",			0x6C, NULL,	"TIMESTAMP MSB BUFFER 0", NULL },
	{ "TS_LSB1",			0x70, NULL,	"TIMESTAMP LSB BUFFER 1", NULL },
	{ "TS_MSB1",			0x74, NULL,	"TIMESTAMP MSB BUFFER 1", NULL },
	{ "TS_COUNTER_LSB",		0x78, NULL,	"TIMESTAMP COUNTER LSB", NULL },
	{ "TS_COUNTER_MSB",		0x7C, NULL,	"TIMESTAMP COUNTER MSB", NULL },

/* Scene Change Detection Register Definitions */
	{ "SCD_CTL",					0x80, NULL,	"SCD CONTROL", NULL },
	{ "SCD_AVG_MIN_MAX_TOP0",		0x84, NULL,	"SCENE CHANGE DETECTION AVG/MIN/MAX TOP FIELD BUFFER 0", NULL },
	{ "SCD_AVG_HRZ_GRAD_TOP0",		0x88, NULL,	"SCENE CHANGE DETECTION AVERAGE HORIZONTAL GRADIENT TOP FIELD BUFFER 0", NULL },
	{ "SCD_SUM_GRAD_TOP0",			0x8C, NULL,	"SCENE CHANGE DETECTION SUM OF HORIZONTAL GRADIENTS TOP FIELD BUFFER 0", NULL },
	{ "SCD_NUM_GRAD_TOP0",			0x90, NULL,	"SCENE CHANGE DETECTION NUMBER OF HORIZONTAL GRADIENTS TOP FIELD BUFFER 0", NULL },
	{ "SCD_AVG_MIN_MAX_BOTTOM0",	0x94, NULL,	"SCENE CHANGE DETECTION AVG/MIN/MAX BOTTOM FIELD BUFFER 0", NULL },
	{ "SCD_AVG_HRZ_GRAD_BOTTOM0",	0x98, NULL,	"SCENE CHANGE DETECTION AVERAGE HORIZONTAL GRADIENT BOTTOM FIELD BUFFER 0", NULL },
	{ "SCD_SUM_GRAD_BOTTOM0",		0x9C, NULL,	"SCENE CHANGE DETECTION SUM OF HORIZONTAL GRADIENTS BOTTOM FIELD BUFFER 0", NULL },
	{ "SCD_NUM_GRAD_BOTTOM0",		0xA0, NULL,	"SCENE CHANGE DETECTION NUMBER OF HORIZONTAL GRADIENTS BOTTOM FIELD BUFFER 0", NULL },
	{ "SCD_AVG_MIN_MAX_TOP1",		0xA4, NULL,	"SCENE CHANGE DETECTION AVG/MIN/MAX TOP FIELD BUFFER 1", NULL },
	{ "SCD_AVG_HRZ_GRAD_TOP1",		0xA8, NULL,	"SCENE CHANGE DETECTION AVERAGE HORIZONTAL GRADIENT TOP FIELD BUFFER 1", NULL },
	{ "SCD_SUM_GRAD_TOP1",			0xAC, NULL,	"SCENE CHANGE DETECTION SUM OF HORIZONTAL GRADIENTS TOP FIELD BUFFER 1", NULL },
	{ "SCD_NUM_GRAD_TOP1",			0xB0, NULL,	"SCENE CHANGE DETECTION NUMBER OF HORIZONTAL GRADIENTS TOP FIELD BUFFER 1", NULL },
	{ "SCD_AVG_MIN_MAX_BOTTOM1", 	0xB4, NULL,	"SCENE CHANGE DETECTION AVG/MIN/MAX BOTTOM FIELD BUFFER 1", NULL },
	{ "SCD_AVG_HRZ_GRAD_BOTTOM1",	0xB8, NULL,	"SCENE CHANGE DETECTION AVERAGE HORIZONTAL GRADIENT BOTTOM FIELD BUFFER 1", NULL },
	{ "SCD_SUM_GRAD_BOTTOM1",		0xBC, NULL,	"SCENE CHANGE DETECTION SUM OF HORIZONTAL GRADIENTS BOTTOM FIELD BUFFER 1", NULL },
	{ "SCD_NUM_GRAD_BOTTOM1",		0xC0, NULL,	"SCENE CHANGE DETECTION NUMBER OF HORIZONTAL GRADIENTS BOTTOM FIELD BUFFER 1", NULL },
	{ "SCD_THRESHOLD",				0xC4, NULL,	"SCENE CHANGE DETECTION HORIZONTAL GRADIENT THRESHOLD", NULL },

/* Test Register Definitions */
	{ "TEST0",				0xC8, NULL,	"TEST REGISTER 0", NULL },
	{ "TEST1",				0xCC, NULL,	"TEST REGISTER 1", NULL },
	{ "TEST2",				0xD0, NULL,	"TEST REGISTER 2", NULL },
	{ "TEST3",				0xD4, NULL,	"TEST REGISTER 3", NULL },

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

static const struct SVEN_Module_EventSpecific g_gen1_vcap_specific_events[] = {
	{NULL, 0, "", NULL }   /* NULL Terminated */
};

static const struct ModuleReverseDefs g_gen1_vcap_sven_module = {
    "GEN1_VCAP",
    SVEN_module_GEN1_VCAP,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen1_vcap,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "VCAP: Video Capture (GEN1)",
    g_gen1_vcap_specific_events,
    NULL /* extension list */
};

