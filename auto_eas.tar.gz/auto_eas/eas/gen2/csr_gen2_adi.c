/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
//
/// 
static const struct EAS_RegBits g_csr_ADI_STATUS[] =
{
    { "VCMH_WFIFO_EMPTY",              31, 1,"",NULL},
    { "RDATA_MGR_COL_LAST",            30,  1,"",NULL},
    { "RDATA_MGR_COL_0",               29,  1,"",NULL},
    { "RDATA_MGR_ROW_LAST",            28,  1,"",NULL},
    { "RDATA_MGR_ROW_0",               27,  1,"",NULL},
    { "RDATA_MGR_ROW_VEC",             19,  8,"",NULL},
    { "RDATA_MGR_COL_VEC",             11,  8,"",NULL},
    { "TOP_FIRST",                     10,  1,"",NULL},
    { "ENGINE_BUSY_NMINUS1",            9,  1,"",NULL},
    { "ENGINE_BUSY_NPLUS1",             8,  1,"",NULL},
    { "WBUFF_MGR_CSR_RD_PTR",           5,  3,"",NULL},
    { "WBUFF_MGR_CSR_FRAME_COUNT",      1,  4,"",NULL},
    { "ZERO",                           0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// 
static const struct EAS_RegBits g_csr_ADI_CONTROL[] =
{
    { "RESERVED_26_31",                26,  6,"",NULL},
    { "BACK_BUFFER_PREVENT",           25,  1,"A write of 1 to this bit prevents the back-buffer from moving to the front buffer in the ADI ",NULL},
    { "SWAP_ALLBYTES4RD_DATA",         24,  1,"MUST ALWAYS BE 1",NULL},
    { "EN_SOFT_FLIP",                  23,  1,"",NULL},
    { "DBG_RPT_FR",                    22,  1,"",NULL},
    { "USE_VDC_FLIPB",                 21,  1,"",NULL},
    { "USE_VDC_FLIPA",                 20,  1,"",NULL},
    { "SOFT_HALT_ADI_VDC_WR",          19,  1,"",NULL},
    { "SOFT_FLUSH",                    18,  1,"",NULL},
    { "SOFT_POP",                      17,  1,"",NULL},
    { "SOFT_PUSH",                     16,  1,"",NULL},
    { "DBG_SWAP_WITHIN8BYTES_LOWER",   15,  1,"SHOULD ALWAYS BE ZERO",NULL},
    { "DBG_SWAP_WITHIN8BYTES_UPPER",   14,  1,"SHOULD ALWAYS BE ZERO",NULL},
    { "DBG_SWAP_8BYTES_WITHIN16",      13,  1,"SHOULD ALWAYS BE ZERO",NULL},
    { "MOTION_THRESHHOLD",              3, 10,"Should always be programmed to ten (decimal)",NULL},
    { "RESERVED_2",                     2,  1,"",NULL},
    { "ENABLE",                         1,  1,"",NULL},
    { "RESERVED_0",                     0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// 
static const struct EAS_RegBits g_csr_ADI_INTEN[] =
{
    { "RESERVED_24_31",                24,  8,"",NULL},
    { "ADI_ADDR_VLD",                  23,  1,"RW", NULL },
    { "ARB_WR_CMD_TAKEN",              22,  1,"RW", NULL },
    { "RDATA_MGR_COL_LAST",            21,  1,"RW", NULL },
    { "RDATA_MGR_COL_0",               20,  1,"RW", NULL },
    { "RDATA_MGR_ROW_LAST",            19,  1,"RW", NULL },
    { "RDATA_MGR_ROW_0",               18,  1,"RW", NULL },
    { "VCMH_ADI_WFIFO_RD",             17,  1,"RW", NULL },
    { "VCMH_ADI_REQFIFO_RD",           16,  1,"RW", NULL },
    { "VCMH_ADI_REORDER_WEN",          15,  1,"RW", NULL },
    { "VCMH_ADI_REORDER_DONE",         14,  1,"RW", NULL },
    { "ARDY",                          13,  1,"RW", NULL },
    { "GO_PROCESS_FRAME_NPLUS1",       12,  1,"RW", NULL },
    { "ENGINE_BUSY_NMINUS1",           11,  1,"RW", NULL },
    { "CODEC_IF_UPDATE_FRONT_BUFF",    10,  1,"RW", NULL },
    { "OVRKEEPOUT1",                    9,  1,"RW", NULL },
    { "OVRKEEPOUT0",                    8,  1,"RW", NULL },
    { "FLIP_VIDB",                      7,  1,"RW", NULL },
    { "FLIP_VIDA",                      6,  1,"RW", NULL },
    { "CODEC_IF_KILL_FLIP2CODEC",       5,  1,"RW", NULL },
    { "WBUFF_MGR_CSR_WR_VDC",           4,  1,"RW", NULL },
    { "WBUFF_MGR_CSR_DI_DONE_N",        3,  1,"RW", NULL },
    { "WBUFF_MGR_CSR_DI_DONE_NPLUS1",   2,  1,"RW", NULL },
    { "WBUFF_MGR_CSR_DI_UNDERRUN",      1,  1,"RW", NULL },
    { "MASTER_ENABLE",                  0,  1,"GLOBAL OR MASTER ENABLE FOR ALL THE INTERRUPTS. THIS MUST BE PROGRAMMED TO 1 TO ENABLE ANY OF THE INTERRUPTS", NULL },
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// 
static const struct EAS_RegBits g_csr_ADI_INTSTAT[] =
{
    { "RESERVED_23_31",                23,  9,"",NULL},
    { "ADI_ADDR_VLD",                  22,  1,"RW", NULL },
    { "ARB_WR_CMD_TAKEN",              21,  1,"RW", NULL },
    { "RDATA_MGR_COL_LAST",            20,  1,"RW", NULL },
    { "RDATA_MGR_COL_0",               19,  1,"RW", NULL },
    { "RDATA_MGR_ROW_LAST",            18,  1,"RW", NULL },
    { "RDATA_MGR_ROW_0",               17,  1,"RW", NULL },
    { "VCMH_ADI_WFIFO_RD",             16,  1,"RW", NULL },
    { "VCMH_ADI_REQFIFO_RD",           15,  1,"RW", NULL },
    { "VCMH_ADI_REORDER_WEN",          14,  1,"RW", NULL },
    { "VCMH_ADI_REORDER_DONE",         13,  1,"RW", NULL },
    { "ARDY",                          12,  1,"RW", NULL },
    { "GO_PROCESS_FRAME_NPLUS1",       11,  1,"RW", NULL },
    { "ENGINE_BUSY_NMINUS1",           10,  1,"RW", NULL },
    { "CODEC_IF_UPDATE_FRONT_BUFF",     9,  1,"RW", NULL },
    { "OVRKEEPOUT1",                    8,  1,"RW", NULL },
    { "OVRKEEPOUT0",                    7,  1,"RW", NULL },
    { "FLIP_VIDB",                      6,  1,"RW", NULL },
    { "FLIP_VIDA",                      5,  1,"RW", NULL },
    { "CODEC_IF_KILL_FLIP2CODEC",       4,  1,"RW", NULL },
    { "WBUFF_MGR_CSR_WR_VDC",           3,  1,"RW", NULL },
    { "WBUFF_MGR_CSR_DI_DONE_N",        2,  1,"RW", NULL },
    { "WBUFF_MGR_CSR_DI_DONE_NPLUS1",   1,  1,"RW", NULL },
    { "WBUFF_MGR_CSR_DI_UNDERRUN",      0,  1,"RW", NULL },
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_CHAP_versions.
 */
static const struct EAS_Register g_csr_ADI[] =
{
    CSR_REG( "NMB_ROWS_CHROMA",     0x000,  "Number of MB rows of chroma vertically. Defines the chroma depth of the image in NV12 format in units of MB")
    CSR_REG( "NMB_ROWS_LUMA",       0x004,  "Number of MB rows of luma vertically. Defines the luma depth of the image in NV12 format in units of MB")
    CSR_REG( "NMB_PER_ROW",         0x008,  "Number of MB horizonatally. Defines the luma & chroma width of the image in NV12 format in units of MB")
    CSR_REG( "LUMA2CHROMA_OFF",     0x00C,  "DO_NOT_USE")
    CSR_REG_W_BB("STATUS",          0x010,  g_csr_ADI_STATUS, "Contains debug break status such as interrupts etc.")
    CSR_REG_W_BB("CONTROL",         0x014,  g_csr_ADI_CONTROL, "Control or configuration register to set up the ADI")
    CSR_REG_W_BB("INTEN",           0x018,  g_csr_ADI_INTEN, "Enable the different interrupts")
    CSR_REG( "INTSTAT",             0x01c,  "View the interrupt status")
    CSR_REG( "FBUF_ADDR0_Y",        0x020,  "DRAM Address of latest deinterlaced frame to be written to VDC. Luma address.")
    CSR_REG( "FBUF_ADDR1_U",        0x024,  "DRAM Address of latest deinterlaced frame to be written to VDC. Luma address.")
    CSR_REG( "VDC_OVL_Y",           0x028,  "This is the address of the VDC Overlay Buffer 0 Start Address Y Pointer Register")
    CSR_REG( "VDC_OVL_U",           0x02c,  "This is the address of the VDC Overlay Buffer 0 Start Address Y Pointer Register")
    CSR_REG( "VDC_OVL_V",           0x030,  "for future use to support other formats")
    CSR_REG( "ADI_FBUF1_Y",         0x034,  "ADI maintains 4 frame buffers and round robins around them. This is the dram address to which ADI writes luma of the 1st frame")
    CSR_REG( "ADI_FBUF1_U",         0x038,  "ADI maintains 4 frame buffers and round robins around them. This is the dram address to which ADI writes luma of the 1st frame")
    CSR_REG( "ADI_FBUF1_V",         0x03c,  "for future use to support other formats")
    CSR_REG( "ADI_FBUF2_Y",         0x040,  "ADI maintains 4 frame buffers and round robins around them. This is the dram address to which ADI writes luma of the 2nd frame")
    CSR_REG( "ADI_FBUF2_U",         0x044,  "ADI maintains 4 frame buffers and round robins around them. This is the dram address to which ADI writes luma of the 2nd frame")
    CSR_REG( "ADI_FBUF2_V",         0x048,  "for future use to support other formats")
    CSR_REG( "ADI_FBUF3_Y",         0x04c,  "ADI maintains 4 frame buffers and round robins around them. This is the dram address to which ADI writes luma of the 3rd frame")
    CSR_REG( "ADI_FBUF3_U",         0x050,  "ADI maintains 4 frame buffers and round robins around them. This is the dram address to which ADI writes luma of the 3rd frame")
    CSR_REG( "ADI_FBUF3_V",         0x054,  "for future use to support other formats")
    CSR_REG( "ADI_FBUF4_Y",         0x058,  "ADI maintains 4 frame buffers and round robins around them. This is the dram address to which ADI writes luma of the 4th frame")
    CSR_REG( "ADI_FBUF4_U",         0x05c,  "ADI maintains 4 frame buffers and round robins around them. This is the dram address to which ADI writes luma of the 4th frame")
    CSR_REG( "ADI_FBUF4_V",         0x060,  "for future use to support other formats")
    CSR_REG( "ADI_FRONT_Y",         0x064,  "This is a shift register implementation that moves the back buffer to the front every codec flip.")
    CSR_REG( "ADI_FRONT_U",         0x068,  "This is a shift register implementation that moves the back buffer to the front every codec flip.")
    CSR_REG( "ADI_FRONT_V",         0x06c,  "for future use to support other formats")
    CSR_REG( "SCRATCH0",            0x070,  "Scratch Register 0")
    CSR_REG( "SCRATCH1",            0x074,  "Scratch Register 1")
    CSR_REG( "SCRATCH2",            0x078,  "Scratch Register 2")
    CSR_REG( "OLY_FLIP_MODE",       0x090,  "Overlay Flip Mode")
    CSR_REG( "OLY_BUF0_Y",          0x094,  "Luma Back Buffer")
    CSR_REG( "OLY_BUF0_U",          0x098,  "Chroma Back Buffer")
    CSR_REG( "OLY_BUF0_V",          0x09c,  "For future Use")

    CSR_REG( "SW_DEBUG",            0x0E0,  "Overlay Flip Mode")
    CSR_REG( "VDC_TIMEOUT",         0x0E4,  "")

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_ADI_specific_events[] =
{

/******EXAMPLES*******

    { "OUT_FIFO_FULL",      1,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    2,      "", NULL },

 ****END EXAMPLES*****/

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN1_ADI_sven_module =
{
    "GEN1_ADI",                      /* Name of module */
    SVEN_module_GEN1_ADI,            /* module enum from sven_module.h */
    0x100,                          /* SIZE in bytes */
#ifdef SVEN_INTERNAL_BUILD
    g_csr_ADI,                      /* register definitions */
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "ADI: Advanced Deinterlacer (GEN1)",   /* Get a better text string */
    g_ADI_specific_events,          /* TODO-Later: Define important events specific to my module */
    NULL                            /* extension list */
};
