/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_GEN1_TSP_versions.
 */
static const struct EAS_Register g_csr_GEN1_H264VD[] =
{
    /* top register set */
    CSR_REG("H264VD_GLOBAL_CTRL",0x0000, "Global Control")
    CSR_REG("H264VD_DPB_DDR_BA",0x0004, "DPB DDR Base Address")
    CSR_REG("H264VD_DPB_FS_CTRL",0x0008, "DPB Frame Store Control")
    CSR_REG("H264VD_RSB_DDR_BA",0x000C, "RSB DDR Base Address")
    CSR_REG("H264VD_FAV_CTRL",0x0010, "Frame Association Value Control")
    CSR_REG("H264VD_FAV",0x0014, "Frame Association Value")
    CSR_REG("H264VD_PAV",0x0018, "PTS Association Value")
    CSR_REG("H264VD_DAV",0x001C, "Discontinuity Association Value")
    CSR_REG("H264VD_SIF_SMP_RS",0x0020, "SIF Semaphore Register (RS access)")
    CSR_REG("H264VD_SIF_MSK_RS",0x0024, "SIF Interrupt Mask Register (RS access)")
    CSR_REG("H264VD_SIF_HDAT",0x0028, "SIF Host Semaphore Data Register")
    CSR_REG("H264VD_SIF_SDDAT",0x002C, "SIF Slice Decoder Semaphore Data Register ")
    CSR_REG("H264VD_SIF_SMP_RC",0x0030, "SIF Semaphore Register (RC access)")
    CSR_REG("H264VD_SIF_MSK_RC",0x0034, "SIF Interrupt Mask Register (RC access)")
    CSR_REG("H264VD_FW_BA",0x0038, "Slice Controller Firmware Base Address ")
    CSR_REG("H264VD_PMOD",0x003C, "Slice Decoder Program Mode")
    CSR_REG("H264VD_SED",0x0040, "Stream Enable/Disable")
    CSR_REG("H264VD_SDEMC",0x0044, "Stream DMA Engine Master Control")
    CSR_REG("H264VD_INT_EN",0x0048, "Interrupt Enable")
    CSR_REG("H264VD_INT_STAT",0x004C, "Interrupt Status")
    CSR_REG("H264VD_INT_CNTR",0x0050, "Interrupt Counter")
    CSR_REG("H264VD_PTS_MSB",0x0054, "PTS MSB")
    CSR_REG("H264VD_PTS_LSB",0x0058, "PTS LSB")
    CSR_REG("RES1",0x005C, "")

    /* DMA Engine */
    CSR_REG("H264VD_DMA_CB_BASE",0x0100, "Stream DMA Circular/Linear Buffer Base Address")
    CSR_REG("H264VD_DMA_SB_RDPTR",0x0104, "Stream DMA Source Block Register Address of Read Pointer")
    CSR_REG("H264VD_DMA_CB_SIZE",0x0108, "Stream DMA Circular/Linear Buffer Size")
    CSR_REG("H264VD_DMA_WTRMARK",0x010C, "Stream DMA Read/Write Pointer Watermark")
    CSR_REG("H264VD_DMA_WDT",0x0110, "Stream DMA Watchdog Timer")
    CSR_REG("H264VD_DMA_CB_RDPTR",0x0114, "Stream DMA Local Read Pointer")
    CSR_REG("H264VD_DMA_CB_WRPTR",0x0118, "Stream DMA Local Write Pointer")
    CSR_REG("H264VD_DMA_SDLINK",0x011C, "Stream DMA Link Address")
    CSR_REG("H264VD_DMA_SDLLSA",0x0120, "Stream DMA Link List Source Address")
    CSR_REG("H264VD_DMA_SDLNDA",0x0124, "Stream DMA Link List Next Descriptor Address")
    CSR_REG("H264VD_DMA_SDLDBC",0x0128, "Stream DMA Link List Data Buffer Byte Count")
    CSR_REG("H264VD_DMA_SDLCBC",0x012C, "Stream DMA Link List Current Data Buffer Byte Count")
    CSR_REG("H264VD_DMA_SDLDC",0x0130, "Stream DMA Link List Descriptor Control")
    CSR_REG("RES2",0x0134, "")
    /* out of place in the register numbering */
    CSR_REG("H264VD_DMA_FIFO",0x0900, "Stream DMA FIFO Write Data")
    CSR_REG("H264VD_DMA_FIFO_STAT",0x0904, "Stream DMA FIFO Status")

    /* PES Packet Parser */
    CSR_REG("H264VD_PES_TMR_CTRL",0x0200, "PES Packet Parser Timer Control Register")
    CSR_REG("H264VD_PES_CTRL",0x0204, "PES Packet Parser Control Register")
    CSR_REG("H264VD_PES_STAT",0x0208, "PES Packet Parser Status Register")
    CSR_REG("H264VD_PES_STATID",0x020C, "PES Packet Parser Status ID Register")
    CSR_REG("H264VD_PES_DATAREG1",0x0210, "PES Packet Parser Data Register 1")
    CSR_REG("H264VD_PES_DATAREG2",0x0214, "PES Packet Parser Data Register 2")
    CSR_REG("H264VD_PES_DATAREG3",0x0218, "PES Packet Parser Data Register 3")
    CSR_REG("H264VD_PES_DATAREG4",0x021C, "PES Packet Parser Data Register 4")
    CSR_REG("H264VD_PES_DATAREG5",0x0220, "PES Packet Parser Data Register 5")
    CSR_REG("H264VD_PES_DATAREG6",0x0224, "PES Packet Parser Data Register 6")
    CSR_REG("H264VD_PES_DATAREG7",0x0228, "PES Packet Parser Data Register 7")
    CSR_REG("H264VD_PES_EXT_DATA",0x022C, "PES Packet Parser Extension Data Register")
    CSR_REG("H264VD_PES_SCR1",0x0230, "PES Packet Parser Programmable Start Codes 1")
    CSR_REG("H264VD_PES_SCR2",0x0234, "PES Packet Parser Programmable Start Codes 2")
    CSR_REG("H264VD_PES_DOSTCM",0x0238, "PES Packet Parser Discontinuity Old STC (MSB)")
    CSR_REG("H264VD_PES_DOSTCL",0x023C, "PES Packet Parser Discontinuity Old STC (LSB)")
    CSR_REG("H264VD_PES_DNSTCM",0x0240, "PES Packet Parser Discontinuity NEW STC (MSB)")
    CSR_REG("H264VD_PES_DNSTCL",0x0244, "PES Packet Parser Discontinuity NEW STC (LSB)")
    CSR_REG("RES3",0x0248, "")

    /* STC Registers */
    CSR_REG("H264VD_STC_AM",0x0300, "STC_A (MSB)")
    CSR_REG("H264VD_STC_AL",0x0304, "STC_A (LSB)")
    CSR_REG("H264VD_STC_BM",0x0308, "STC_B (MSB)")
    CSR_REG("H264VD_STC_BL",0x030C, "STC_B (LSB)")
    CSR_REG("H264VD_STC_CTRL",0x0310, "STC Control")
    CSR_REG("H264VD_STC_CNTM",0x0314, "STC Count Value (MSB)")
    CSR_REG("H264VD_STC_CNTL",0x0318, "STC Count Timeout (LSB)")
    CSR_REG("H264VD_STC_CNTTM",0x031C, "STC Count Timeout (MSB)")
    CSR_REG("H264VD_STC_CNTTL",0x0320, "STC Count Timeout (LSB)")
    CSR_REG("H264VD_STC_VCNTM",0x0324, "STC VDC Count (MSB)")
    CSR_REG("H264VD_STC_VCNTL",0x0328, "STC VDC Count (LSB)")
    CSR_REG("RES4",0x032C, "")

    /* Display Queue Manager Registers */
    CSR_REG("H264VD_DQM_PTS_CTRL",0x0400, "DQM PTS Control")
    CSR_REG("H264VD_DQM_PTS_OM",0x0404, "DQM PTS Post Accumulator Offset (MSB)")
    CSR_REG("H264VD_DQM_PTS_OL",0x0408, "DQM PTS Post Accumulator Offset (LSB)")
    CSR_REG("H264VD_DQM_PTS_AM",0x040C, "DQM PTS Accumulator (MSB)")
    CSR_REG("H264VD_DQM_PTS_AL",0x0410, "DQM PTS Accumulator (LSB)")
    CSR_REG("H264VD_DQM_PTS_SM",0x0414, "DQM PTS Accumulator Step Size (MSB)")
    CSR_REG("H264VD_DQM_PTS_SL",0x0418, "DQM PTS Accumulator Step Size (LSB)")
    CSR_REG("H264VD_DQM_DEST_Y",0x041C, "DQM Destination Y Buffer Register Address")
    CSR_REG("H264VD_DQM_DEST_UV",0x0420, "DQM Destination UV Buffer Register Address")
    CSR_REG("H264VD_DQM_DEST_FLIP",0x0424, "DQM Destination Overlay Flip Mode Register Address ")
    CSR_REG("H264VD_DQM_DQ_CS",0x0428, "DQM Display Queue Control/Status")
    CSR_REG("H264VD_DQM_DQ_UV_ADR",0x042C, "DQM Display Queue UV Address")
    CSR_REG("H264VD_DQM_DQ_Y_ADR",0x0430, "DQM Display Queue Y Address")
    CSR_REG("H264VD_DQM_DQ_PTS_M",0x0434, "DQM Display Queue PTS Value (MSB)")
    CSR_REG("H264VD_DQM_DQ_PTS_L",0x0438, "DQM Display Queue PTS Value (LSB)")
    CSR_REG("H264VD_DQM_ODPQ_CS",0x043C, "DQM Ordered Decoded Picture Queue Control/Status")
    CSR_REG("H264VD_DQM_ODPQ_DATA",0x0440, "DQM Ordered Decoded Picture Queue Data")
    CSR_REG("H264VD_DQM_ODPQ_WMRK",0x0444, "DQM Ordered Decoded Picture Queue Watermark")
    CSR_REG("H264VD_DQM_DPB_STAT",0x0448, "DQM DPB Status")
    CSR_REG("H264VD_DQM_RDLY_CS",0x044C, "DQM Release Delay Control/Status")
    CSR_REG("RES5",0x0450,"")

    /* Slice Decoder Register */
    CSR_REG("H264VD_SD_SMP_RD",0x1000, "Semaphore Read")
    CSR_REG("H264VD_SD_SMP_MSK_RD",0x1004, "Interrupt Mask Read")
    CSR_REG("H264VD_SD_SMP_SET",0x1008, "Semaphore Set")
    CSR_REG("H264VD_SD_SMP_CLR",0x100C, "Semaphore Clear")
    CSR_REG("H264VD_SD_SMP_MSK_SET",0x1010, "Interrupt Mask Set")
    CSR_REG("H264VD_SD_SMP_MSK_CLR",0x1014, "Interrupt Mask Clear")
    CSR_REG("H264VD_SD_HDAT",0x1018, "Host Data Register")
    CSR_REG("H264VD_SD_SDDAT",0x101C, "Data Register")
    CSR_REG("H264VD_SD_DQ_PUSH",0x1020, "Display Queue Push")
    CSR_REG("H264VD_SD_DQ_STAT",0x1024, "Display Queue Status")
    /* gap */
    CSR_REG("H264VD_SD_DPB_INIT",0x1040, "DPB Initialize")
    CSR_REG("H264VD_SD_DPB_FRM_SZ_STAT",0x1044, "DPB Image Frame Size Status")
    CSR_REG("H264VD_SD_DPB_FRM_SZ_CTRL",0x1048, "DPB Image Frame Size Control (Override)")
    CSR_REG("H264VD_SD_DPB_NUMB_OVR",0x104C, "DPB Image Component Size Control (in KB)")
    CSR_REG("H264VD_SD_DPB_FS_VALUES",0x1050, "DPB Frame Store Values (Set by H264VD_DPB_FS_CTRL)")
    CSR_REG("H264VD_SD_DPB_FS_OFFSET",0x1054, "DPB Frame Store Offset")
    CSR_REG("H264VD_SD_FSD",0x1058, "Frame System Data (aka FAV)")
    /* gap */
    CSR_REG("H264VD_SD_SD_INT_CTRL",0x10C0, "Slice Decoder Enable and Interrupt Control")
    CSR_REG("H264VD_SD_INT_STAT",0x10C4, "Slice Decoder Interrupt Status")
    CSR_REG("H264VD_SD_SOFT_RST",0x10FC, "Slice Decoder Soft Reset")
    CSR_REG("H264VD_SD_BSD_PSR_STAT",0x1100, "Parser Status")
    CSR_REG("H264VD_SD_BSD_STAT",0x1104, "BSD Status")
    /* gap */
    CSR_REG("H264VD_SD_BSD_RBSP_CTRL",0x1110, "RBSP Feed Control")
    CSR_REG("H264VD_SD_BSD_DATA",0x1114, "BSD Data Register")
    CSR_REG("H264VD_SD_BSD_NAL_TYPE",0x1118, "NAL Type")
    CSR_REG("H264VD_SD_BSD_BBB_STAT",0x111C, "BBB Buffer Bits")
    CSR_REG("H264VD_SD_BSD_GUE_DEC",0x1120, "Golomb UE Decode")
    CSR_REG("H264VD_SD_BSD_GSE_DEC",0x1124, "Golomb SE Decode")
    CSR_REG("H264VD_SD_BSD_EXP_GME_INTRA",0x1128, "Exp Golomb ME Intra")
    /* gap */
    CSR_REG("H264VD_SD_BSD_EXP_GME_INTER",0x1138, "Exp Golomb ME Inter")
    /* gap */
    CSR_REG("H264VD_SD_BSD_IMG_INIT",0x1140, "Image Initialize")
    /* gap */
    CSR_REG("H264VD_SD_BSD_SLICE_P1",0x1150, "Slice Parameter 1")
    CSR_REG("H264VD_SD_BSD_SLICE_P2",0x1154, "Slice Parameter 2")
    CSR_REG("H264VD_SD_BSD_SLICE_START",0x1158, "Slice Start")
    CSR_REG("H264VD_SD_BSD_MB_CTRL",0x115C, "Macro Block Control for Override engine current MB address/ X and Y positions")
    /* gap */
    CSR_REG("H264VD_SD_BSD_BYTE_ALIGN",0x117C, "Force Byte Align")
    CSR_REG("H264VD_SD_BSD_BBB_TRAIL",0x1180, "BBB Buffer Trailing Bits")
    CSR_REG("H264VD_SD_BSD_GET_BITS",0x1184, "BSD Get Bits: 1 to 30 bits based on Address")
    CSR_REG("H264VD_SD_MPR_TF_POC",0x1300, "Top Field Picture POC")
    CSR_REG("H264VD_SD_MPR_BF_POC",0x1304, "Bottom Field Picture POC")
    /* gap */
    CSR_REG("H264VD_SD_MPR_LST0",0x1380, "MPR List 0")
    CSR_REG("H264VD_SD_MPR_LST1",0x1384, "MPR List 1")
    CSR_REG("H264VD_SD_MPR_LST2",0x1388, "MPR List 2")
    CSR_REG("H264VD_SD_MPR_LST3",0x138C, "MPR List 3")
    CSR_REG("H264VD_SD_MPR_LST4",0x1390, "MPR List 4")
    CSR_REG("H264VD_SD_MPR_LST5",0x1394, "MPR List 5")
    CSR_REG("H264VD_SD_MPR_LST6",0x1398, "MPR List 6")
    CSR_REG("H264VD_SD_MPR_LST7",0x139C, "MPR List 7")
    CSR_REG("H264VD_SD_MPR_LST8",0x13A0, "MPR List 8")
    CSR_REG("H264VD_SD_MPR_LST9",0x13A4, "MPR List 9")
    CSR_REG("H264VD_SD_MPR_LST10",0x13A8, "MPR List 10")
    CSR_REG("H264VD_SD_MPR_LST11",0x13AC, "MPR List 11")
    CSR_REG("H264VD_SD_MPR_LST12",0x13B0, "MPR List 12")
    CSR_REG("H264VD_SD_MPR_LST13",0x13B4, "MPR List 13")
    CSR_REG("H264VD_SD_MPR_LST14",0x13B8, "MPR List 14")
    CSR_REG("H264VD_SD_MPR_LST15",0x13BC, "MPR List 15")
    /* gap */
    CSR_REG("H264VD_SD_INTC_INT_MASK",0x1400, "Interrupt Mask")
    CSR_REG("H264VD_SD_INTC_WR_INT_PEND",0x1404, "Write interrupt pending")
    CSR_REG("H264VD_SD_INTC_INT_FORCE",0x1408, "Interrupt Force")
    CSR_REG("H264VD_SD_INTC_CLR_INT_PEND",0x140C, "Clear interrupt pending")
    CSR_REG("H264VD_SD_TIMER_0_VALUE",0x1800, "Timer 0 Value")
    CSR_REG("H264VD_SD_TIMER_LOAD_0_VALUE",0x1804, "Load value 0")
    CSR_REG("H264VD_SD_TIMER_0_CTRL",0x1808, "Timer 0 Control")
    /* gap */
    CSR_REG("H264VD_SD_TIMER_1_VALUE",0x1810, "Timer 1 Value")
    CSR_REG("H264VD_SD_TIMER_LOAD_1_VALUE",0x1814, "Load value 1")
    CSR_REG("H264VD_SD_TIMER_1_CTRL",0x1818, "Timer 1 Control")
    CSR_REG("H264VD_SD_TIMER_SCALER_VALUE",0x1820, "Scaler Value")
    CSR_REG("H264VD_SD_TIMER_SCALER_PRELOAD",0x1824, "Scaler PreLoad")
    /* gap */
    CSR_REG("H264VD_SD_DMA_EM_ADDRESS",0x1C00, "External Memory Address")
    CSR_REG("H264VD_SD_DMA_INTERNAL_CONFIG",0x1C04, "Internal config")
    CSR_REG("H264VD_SD_DMA_DO_MEM_TRANSFR",0x1C08, "Do memory transfer")
    CSR_REG("H264VD_SD_DMA_TRANSFR_STATUS",0x1C0C, "Transfer Status")

    /* vSpart Debug Port Registers */
    CSR_REG("H264VD_VSPARC_REGFILE",0x2000, "Windowed Register File")
    CSR_REG("H264VD_VSPARC_GLOBALREGS",0x2204, "Processor Global Registers (%g0 to %g7)")
    CSR_REG("H264VD_VSPARC_FPC",0x2300, "Fetch Program Counter")
    CSR_REG("H264VD_VSPARC_FSTATUS",0x2308, "Fetch Status (Supervisor Bit)")
    CSR_REG("H264VD_VSPARC_DPC",0x2310, "Decode Program Counter")
    CSR_REG("H264VD_VSPARC_D_INST",0x2314, "Decode Instruction")
    CSR_REG("H264VD_VSPARC_DSTATUS",0x2318, "Decode Status Flags")
    CSR_REG("H264VD_VSPARC_EPC",0x2320, "Execute Program Counter")
    CSR_REG("H264VD_VSPARC_E_INST",0x2324, "Execute Instruction")
    CSR_REG("H264VD_VSPARC_ESTATUS",0x2328, "Execute Status Flags")
    CSR_REG("H264VD_VSPARC_MSTATUS",0x2338, "Memory Status Flags")
    CSR_REG("H264VD_VSPARC_WSTATUS",0x2348, "Write Status Flags")
    CSR_REG("H264VD_VSPARC_DCTRL",0x2400, "Debugger Control Register")
    CSR_REG("H264VD_VSPARC_DSTAT",0x2404, "Debugger Status Register / Single Step")
    CSR_REG("H264VD_VSPARC_PCBREAK0",0x2480, "PC Breakpoint 0")
    CSR_REG("PCBREAKMASK0",0x2484, "PC Breakpoint Mask 0")
    CSR_REG("H264VD_VSPARC_PCBREAK1",0x2490, "PC Breakpoint 1")
    CSR_REG("PCBREAKMASK1",0x2494, "PC Breakpoint Mask 1")
    CSR_REG("H264VD_VSPARC_PCBREAK2",0x24A0, "PC Breakpoint 2")
    CSR_REG("PCBREAKMASK2",0x24A4, "PC Breakpoint Mask 2")
    CSR_REG("H264VD_VSPARC_PCBREAK3",0x24B0, "PC Breakpoint 3")
    CSR_REG("PCBREAKMASK3",0x24B4, "PC Breakpoint Mask 3")

    CSR_REG("H264VD_VSPARC_DATABREAK0",0x24C0, "Data Access Breakpoint 0")
    CSR_REG("H264VD_VSPARC_DATABREAKMASK0",0x24C4, "Data Access Breakpoint Mask 0")
    CSR_REG("H264VD_VSPARC_DATABREAK1",0x24D0, "Data Access Breakpoint 1")
    CSR_REG("H264VD_VSPARC_DATABREAKMASK1",0x24D4, "Data Access Breakpoint Mask 1")
    CSR_REG("H264VD_VSPARC_DATABREAK2",0x24E0, "Data Access Breakpoint 2")
    CSR_REG("H264VD_VSPARC_DATABREAKMASK2",0x24E4, "Data Access Breakpoint Mask 2")
    CSR_REG("H264VD_VSPARC_DATABREAK3",0x24F0, "Data Access Breakpoint 3")
    CSR_REG("H264VD_VSPARC_DATABREAKMASK3",0x24F4, "Data Access Breakpoint Mask 3")
    CSR_REG("H264VD_VSPARC_LRAM",0x2800, "Local SRAM Area")
    CSR_REG("H264VD_VSPARC_MEM",0x8000, "Slice Decoder Controller shared code/data memory window.")

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_GEN1_H264VD_specific_events[] =
{
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN1_H264VD_sven_module =
{
    "GEN1_H264",
    SVEN_module_GEN1_H264VD,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN1_H264VD,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: H264 Decode Function (GEN1)",
    g_GEN1_H264VD_specific_events,          /* TODO-Later: Define important events specific to my module */
    NULL                            /* extension list */
};
