/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_GEN1_TSP_versions.
 */
static const struct EAS_Register g_csr_GEN1_MPEG2E[] =
{    
	{"ENCODER_DESIGNATION",                    0x0000,	NULL, 	"CS6610e Designation register",				NULL }, /*Fill out the bit break outs as we go*/
	{"HARDWARE_VERSION", 				0x0008, 	NULL, 	"Hardware Version Number", 				NULL },
	{"FIRMWARE_VERSION", 				0x000C, 	NULL, 	"Firmware Version Number", 					NULL },
	{"FIRMWARE_STATUS", 				0x0010, 	NULL, 	"Provides Status Information from Firmware", 	NULL },
	{"SOFTWARE_RESET", 					0x0014, 	NULL, 	"Performs a Software Reset", 				NULL },
	{"HARDWARE_RESET", 					0x0018, 	NULL, 	"Performs a Hardware Reset", 				NULL },
	{"INTERRUPT_ENABLE", 				0x001c, 	NULL, 	"Enables firmware generated interupts",		NULL },
	{"INTERRUPT_LATCH", 					0x0020, 	NULL, 	"Provides the status of firware interupts",		NULL },
	{"APB_SWITCH_ENABLE", 				0x002C, 	NULL, 	"APB Switch Enable Register",				NULL },
	{"APB_BASE_ADDRESS", 				0x0030, 	NULL, 	"Programmable APB base address for external access to vSPARC controlled address space",		NULL },
	{"MESSAGE_STATUS", 					0x0040, 	NULL, 	"Status of software messaging interupts",		NULL },
	{"MSG_TO_CORE_FIFO", 				0x0044, 	NULL, 	"FIFO used to send message to the core",				NULL },
	{"MSG_TO_HOST_FIFO", 				0x0044, 	NULL, 	"FIFO used to send message to the host",				NULL },
	{"UPDATE_CONTROL", 					0x0080, 	NULL, 	"controls encoder configuration updates",				NULL },
	{"GOP_COUNT", 						0x0084, 	NULL, 	"Specifies the GOP structure of the encoded video",		NULL },
	{"I_COUNT", 							0x0088, 	NULL, 	"Specifies the GOP structure of the encoded video",		NULL },
	{"SEGMENT_COUNT", 					0x008C, 	NULL, 	"Specifies the GOP structure of the encoded video",		NULL },
	{"B_FRAME_COUNT", 					0x0090, 	NULL, 	"Specifies the GOP structure of the encoded video",		NULL },
	{"RATE_CONTROL_MODE", 				0x0094, 	NULL, 	"Used to set up Rate Control Mode",					NULL },
	{"INITIAL_QUANTIZATION_PARAMETER_I_FRAME",	0x0098, 	NULL, 	"Used to set up Rate Control Mode",			NULL },
	{"CODING_STRUCTURE", 				0x009C, 	NULL, 	"Specifies feild or frame based encoding",				NULL },
	{"INITIAL_QUANTIZATION_P_FRAME",		0x00A0, 	NULL, 	"Used to set up Rate Control Mode",			NULL },
	{"INITIAL_QUANTIZATION_B_FRAME",		0x00A4, 	NULL, 	"Used to set up Rate Control Mode",			NULL },
	{"INCLUDE_PES_HEADER",				0x00A8, 	NULL, 	"Determines if PES Headers are inserted",				NULL },
	{"STREAM_ID",						0x00AC, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"PACKET_LENGTH",					0x00B0, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"SCRAMBLING_CONTROL",				0x00B4, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"PRIORITY",							0x00B8, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"DATA_ALIGNMENT_INDICATOR",		0x00BC, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"COPYRIGHT_INDICATOR",				0x00C0, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"ORIGINAL_COPY",					0x00C4, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"PTS_DTS_FLAGS",					0x00C8, 	NULL, 	"Determines if PTS/DTS headers are added before picture headers",			NULL },
	{"HORIZONTAL_SIZE",					0x00CC, 	NULL, 	"Horizontal size of the encoded Image",		NULL },
	{"VERTICAL_SIZE",					0x00D0, 	NULL, 	"Vertical size of the encoded Image",			NULL },
	{"ASPECT_RATIO",						0x00D4, 	NULL, 	"Used only for Header Configuration",			NULL },	
	{"FRAME_RATE",						0x00D8, 	NULL, 	"Used to specify the frame rate of the Video as specified in the standards",			NULL },	
	{"BIT_RATE",							0x00DC, 	NULL, 	"Used to specify the bit rate of the Video as specified in the standards",			NULL },
	{"VBV_BUFFER_SIZE",					0x00E0, 	NULL, 	"Used only for Header Configuration",			NULL },	
	{"CONSTRAINED_PARAMETERS_FLAG",	0x00E4, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"INTRA_QUANTIZER_MATRIX",			0x00E8, 	NULL, 	"Used only for Header Configuration",			NULL },	
	{"NON_INTRA_QUANTIZER_MATRIX",		0x00EC, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"INCLUDE_SEQUENCE_EXTENSION",		0x00F0, 	NULL, 	"Determines if the sequence extension header is included",			NULL },
	{"PROFILE_AND_LEVEL_INDICATION",		0x00F4, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"PROGRESSIVE_SEQUENCE",			0x00F8, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"CHROMA_FORMAT",					0x00FC, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"LOW_DELAY",						0x0100, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"INCLUDE_SEQUENCE_DISPLAY_EXTENSION",		0x0104, 	NULL, 	"Determines if the sequence display extension header is included",			NULL },
	{"VIDEO_FORMAT",					0x0108, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"INCLUDE_COLOR_DESCRIPTION",		0x010C, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"COLOR_PRIMARIES",					0x0110, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"TRANSFER_CHARACTERSTICS",		0x0114, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"MATRIX_COEFFICENTS",				0x0118, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"DISPLAY_HORIZONTAL_SIZE",			0x011C, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"DISPLAY_VERTICAL_SIZE",			0x0120, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"TEMPRORAL_REFERENCE",				0x0124, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"VBV_DELAY",						0x0128, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"FULL_PEL_FORWARD_VECTOR_AND_F_CODE",						0x012C, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"FULL_PEL_BACKWARD_VECTOR_AND_F_CODE",						0x0130, 	NULL, 	"Used only for Header Configuration",			NULL },
	{"INCLUDE_PICTURE_CODING_EXTENSION",		0x0134, 	NULL, 	"Determines if the picture coding extension header is included",			NULL },
	{"FORWARD_HORIZONTAL_F_CODE", 		0x0138, 	NULL, "F-Codes for motion vector coding are specific for each of the motion types", 		NULL},
	{"FORWARD_VERTICAL_F_CODE", 		0x013C, 	NULL, "F-Codes for motion vector coding are specific for each of the motion types", 		NULL},
	{"BACKWARD_HORIZONTAL_F_CODE", 	0x0140, 	NULL, "F-Codes for motion vector coding are specific for each of the motion types", 		NULL},
	{"BACKWARD_VERTICAL_F_CODE", 		0x0144, 	NULL, "F-Codes for motion vector coding are specific for each of the motion types", 		NULL},
	{"INTRA_DC_PRECISION", 				0x0148, 	NULL, "Specifies the precision of the Intra DC coefficents", 		NULL},
	{"TOP_FEILD_FIRST", 					0x014C, 	NULL, "Specifies the order of feilds in a video frame",	 		NULL},
	{"FRAME_PREDICTION_FRAME_DCT", 		0x0150, 	NULL, "Used only for Header Configuration",	 				NULL},
	{"CONCEALMENT_MOTION_VECTORS", 	0x0154, 	NULL, "Used only for Header Configuration",	 			NULL},
	{"QUANTIZATION_SCALE_TYPE", 			0x0158, 	NULL, "Used to select between quantization tables",	 		NULL},	
	{"INTRA_VLC_FORMAT", 				0x015C, 	NULL, "Selects the required VLC Table",			 		NULL},
	{"ALTERNATE_SCAN", 					0x0160, 	NULL, "Sepcifies a Zig Zag or an Alternate Scan",		NULL},
	{"REPEAT_FIRST_FEILD", 				0x0164, 	NULL, "Used only for Header Configuration",			NULL},
	{"CHROMA_420_TYPE", 					0x0168, 	NULL, "Used only for Header Configuration",			NULL},
	{"PROGRESSIVE_FRAME", 				0x016C, 	NULL, "Used only for Header Configuration",			NULL},
	/*******************************Picture Display Extension******************************************/
	{"INCLUDE_PICTURE_DISPLAY_EXTENSION", 				0x0170, 	NULL, "Determines if the picture display extension header is included",			NULL},
	{"FRAME_CENTER_HORIZONTAL_OFFSET_1", 				0x0174, 	NULL, "Used only for Header Configuration",			NULL},
	{"FRAME_CENTER_VERTICAL_OFFSET_1", 	0x0178, 	NULL, "Used only for Header Configuration",			NULL},
	{"FRAME_CENTER_HORIZONTAL_OFFSET_2", 				0x017C, 	NULL, "Used only for Header Configuration",			NULL},	
	{"FRAME_CENTER_VERTICAL_OFFSET_2", 	0x0180, 	NULL, "Used only for Header Configuration",			NULL},
	{"FRAME_CENTER_HORIZONTAL_OFFSET_3", 				0x0184, 	NULL, "Used only for Header Configuration",			NULL},	
	{"FRAME_CENTER_VERTICAL_OFFSET_3", 	0x0188, 	NULL, "Used only for Header Configuration",			NULL},	
	/***********************************Copyright Extension********************************************/
	{"INCLUDE_COPYRIGHT_EXTENSION",		0x018C, 	NULL, "Determines if the Copyright extension header is included",			NULL},
	{"COPYRIGHT_FLAG", 					0x0190, 	NULL, "Used only for Header Configuration",			NULL},
	{"COPYRIGHT_IDENTIFIER", 			0x0194, 	NULL, "Used only for Header Configuration",			NULL},
	{"ORIGINAL_OR_COPY", 				0x0198, 	NULL, "Used only for Header Configuration",			NULL},
	{"COPYRIGHT_NUMBER_1", 				0x019C, 	NULL, "Used only for Header Configuration",			NULL},
	{"COPYRIGHT_NUMBER_2", 				0x01A0, 	NULL, "Used only for Header Configuration",			NULL},
	{"COPYRIGHT_NUMBER_3", 				0x01A4, 	NULL, "Used only for Header Configuration",			NULL},
	/*********************************Quant Matrix Extension******************************************/
	{"INCLUDE_QUANT_MATRIX_EXTENSION", 				0x01A8, 	NULL, "Determines if the quant matrix extension header is included",			NULL},
	{"LOAD_INTRA_QUANTIZER_MATRIX", 				0x01AC, 	NULL, "Used only for Header Configuration",			NULL},
	{"LOAD_NON_INTRA_QUANTIZER_MATRIX", 			0x01B0, 	NULL, "Used only for Header Configuration",			NULL},
	/********************************Rate Control Configuration****************************************/
	{"I_FRAME_WEIGHT", 					0x01B4, 	NULL, "Provides a weight to all the I frames within a GOP as a ratio. The sum of all three should be 4096",			NULL},
	{"P_FRAME_WEIGHT", 					0x01B8, 	NULL, "Provides a weight to all the P frames within a GOP as a ratio. The sum of all three should be 4096",			NULL},
	{"B_FRAME_WEIGHT", 					0x01BC, 	NULL, "Provides a weight to all the P frames within a GOP as a ratio. The sum of all three should be 4096",			NULL},
	{"VBR_MINIMUM_THRESHOLD", 			0x01C0, 	NULL, "Reduction in bit-rate permitted by the VBR adjustment (presented as a ratio over 256)",			NULL},
	{"VBR_MAXIMUM_THRESHOLD", 			0x01C4, 	NULL, "Increase in bit-rate permitted by the VBR adjustment (presented as a ratio over 256)",			NULL},
	{"VBR_PROTECTION", 					0x01C8, 	NULL, "VBR adjustment Factor",			NULL},
	{"VBR_K_FACTOR", 					0x01CC, 	NULL, "VBR adjustment Factor",			NULL},
	{"PES_PACKET_LIMIT", 					0x01F4, 	NULL, "Bit count between PES packets",	NULL},
	/*******************************Meta-Data Interface**********************************************/
	{"MDI_FILL_LEVEL", 					0x0200, 	NULL, "Provides number of elements currently in MDI",			NULL},
	{"MDI_PREFILL_LEVEL", 				0x0204, 	NULL, "Specifies Minimum number of elements that can be in a buffer before processing can continue",			NULL},
	{"MDI_ELEMENT_0", 					0x0300, 	NULL, "MDI Element 0 is used to add elements to the queue",			NULL},
	{"MDI_ELEMENT_1", 					0x0310, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_2", 					0x0320, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_3", 					0x0330, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_4", 					0x0340, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_5", 					0x0350, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_6", 					0x0360, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_7", 					0x0370, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_8", 					0x0380, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_9", 					0x0390, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_10", 					0x03A0, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_11", 					0x03B0, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_12", 					0x03C0, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_13", 					0x03D0, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_14", 					0x03E0, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	{"MDI_ELEMENT_15", 					0x03F0, 	NULL, "Elements contained in MDI queue can be accessed as elements 1 through 15. The Number of valid elements can be seen in fill register level",			NULL},
	/*****************************Custom Quant Tables********************************************/
	{"MPEG2_INTRA_QUANT_MATRIX", 		0x0400, 	NULL, "The Quant table entries are mapped starting left to right and top to bottom. For examples see EAS",			NULL},
	{"MPEG2_NON_INTRA_QUANT_MATRIX", 	0x0500, 	NULL, "The Quant table entries are mapped starting left to right and top to bottom. For examples see EAS",			NULL},
	/********************************Instruction Ram*********************************************/
	{"INSTRUCTION_RAM", 					0x4000, 	NULL, "Instruction RAM",			NULL},
	/***************************** Frame Buffer Manager and DMA Streamer Register Map**********************/
	{"MPG2VE_ADDR_Y_IDX0", 				0x1500, 	NULL, "Index 0 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX1", 				0x1504, 	NULL, "Index 1 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX2", 				0x1508, 	NULL, "Index 2 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX3", 				0x150C, 	NULL, "Index 3 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX4", 				0x1510, 	NULL, "Index 4 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX5", 				0x1514, 	NULL, "Index 5 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX6", 				0x1518, 	NULL, "Index 6 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX7", 				0x151C, 	NULL, "Index 0 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX8", 				0x1520, 	NULL, "Index 0 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX9", 				0x1524, 	NULL, "Index 0 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX10", 			0x1528, 	NULL, "Index 0 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX11", 			0x152C, 	NULL, "Index 0 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX12", 			0x1530, 	NULL, "Index 0 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX13", 			0x1534, 	NULL, "Index 0 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX14", 			0x1538, 	NULL, "Index 0 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_Y_IDX15", 			0x153C, 	NULL, "Index 0 of the logical address to Luma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX0", 				0x1540, 	NULL, "Index 0 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX1", 				0x1544, 	NULL, "Index 1 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX2", 				0x1548, 	NULL, "Index 2 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX3", 				0x154C, 	NULL, "Index 3 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX4", 				0x1550, 	NULL, "Index 4 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX5", 				0x1554, 	NULL, "Index 5 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX6", 				0x1558, 	NULL, "Index 6 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX7", 				0x155C, 	NULL, "Index 0 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX8", 				0x1560, 	NULL, "Index 0 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX9", 				0x1564, 	NULL, "Index 0 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX10", 			0x1568, 	NULL, "Index 0 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX11", 			0x156C, 	NULL, "Index 0 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX12", 			0x1570, 	NULL, "Index 0 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX13", 			0x1574, 	NULL, "Index 0 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX14", 			0x1578, 	NULL, "Index 0 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	{"MPG2VE_ADDR_C_IDX15", 			0x157C, 	NULL, "Index 0 of the logical address to chroma Phyiscal Address Look Up Table in Frame Buffer Manager",			NULL},
	/*******************************************DMA Streamer*****************************************/
	{"MPG2VE_STREAM_CFG", 			0x1600, 	NULL, "Configuration for the DMA Streamer",			NULL},
	{"MPG2VE_STREAM_ADDR", 			0x1604, 	NULL, "Address Pointer to the base of circular output stream buffer",			NULL},
	{"MPG2VE_STREAM_READ_ADDR", 	0x1608, 	NULL, "Address in circular buffer which would be read next by SW",			NULL},
	{"MPG2VE_STREAM_SIZE", 			0x160C, 	NULL, "Size of circular output stream buffer measured in bytes",			NULL},
	{"MPG2VE_STREAM_WRITE_ADDR", 	0x1610, 	NULL, "Address in circular buffer which would be wrritten next by SW",			NULL},
	{"MPG2VE_STREAM_INTERUPT", 		0x1614, 	NULL, "Interupts from a DMA streamer unit",			NULL},
	{"MPG2VE_STREAM_INTERUPT_MASK", 		0x1618, 	NULL, "Interupts mask for a DMA streamer unit",			NULL},
	{"MPG2VE_ADDR_LOG_QUEUE", 		0x161C, 	NULL, "TOP of address log queue",			NULL},
	/*****************************************Test Registers******************************************/
	{"MPG2VE_TEST1", 		0x1700, 	NULL, "TEST 1 REGISTER ",			NULL},
	{"MPG2VE_TEST2", 		0x1704, 	NULL, "TEST 2 REGISTER ",			NULL},
	{"MPG2VE_TEST3", 		0x1708, 	NULL, "TEST 3 REGISTER ",			NULL},
	{"MPG2VE_TEST4", 		0x170C, 	NULL, "TEST 4 REGISTER ",			NULL},
	/****************************************Spare Registers****************************************/
	{"MPG2VE_SPARE1", 		0x1710, 	NULL, "SPARE 1 REGISTER ",			NULL},
	{"MPG2VE_SPARE2", 		0x1714, 	NULL, "SPARE 2 REGISTER ",			NULL},
	{"MPG2VE_SPARE3", 		0x1718, 	NULL, "SPARE 3 REGISTER ",			NULL},
	{"MPG2VE_SPARE4", 		0x171C, 	NULL, "SPARE 4 REGISTER ",			NULL},
	
	CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_GEN1_MPEG2E_specific_events[] =
{
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN1_MPEG2E_sven_module =
{
    "GEN1_MPEG2E",
    SVEN_module_GEN1_MPEG2E,
    0x0,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN1_MPEG2E,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: MPEG2Encoder Function (GEN1)",     /* TODO: Get a better text string */
    g_GEN1_MPEG2E_specific_events,          /* TODO-Later: Define important events specific to my module */
    NULL                           /* extension list */
};
