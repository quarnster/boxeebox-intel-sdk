/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

static const struct EAS_Register g_csr_GEN1_VDC[] =
{
	{   "OVA_OBUF_OY",	0x30104, NULL,	"Overlay Buffer 1 Y Pointer",	NULL	},
	{	"OVA_OBUF_0U",	0x30108, NULL,	"Overlay Buffer 0 U Pointer",	NULL	},
	{	"OVA_OBUF_0V",	0x3010C, NULL,	"Overlay Buffer 0 V Pointer",	NULL	},
	{	"OVA_OBUF_1U",	0x30110, NULL,	"Overlay Buffer 1 U Pointer",	NULL	},
	{	"OVA_OBUF_1V",	0x30114, NULL,	"Overlay Buffer 1 V Pointer",	NULL	},
	{	"OVA_OSTRIDE",	0x30118, NULL,	"Overlay Stride",				NULL	},
	{	"OVA_YRGB_VPH",	0x3011C, NULL,	"Y/RGB Vertical Phase 0/1", 	NULL	},
	{	"OVA_UV_VPH",	0x30120, NULL,	"UV Vertical Phase 0/1",		NULL	},
	{	"OVA_HORZ_PH",	0x30124, NULL,	"Horizontal Phase",				NULL	},
	{	"OVA_INIT_PHS",	0x30128, NULL,	"Initial Phase Shift",			NULL	},
	{	"OVA_DWINPOS",	0x3012C, NULL,	"Destination Window Position",	NULL	},
	{	"OVA_DWINSZ",	0X30130, NULL,	"Destination Window Size",		NULL	},
	{	"OVA_SWIDTH",	0x30134, NULL,	"Source Width",					NULL	},
	{	"OVA_SWIDTHSW",	0x30138, NULL,	"Source Width In SWORDS",		NULL	},
	{	"OVA_SHEIGHT",	0x3013C, NULL,	"Source Height",				NULL	},
	{	"OVA_YRGBSCALE",0x30140, NULL,	"Y/RGB Scale Factor",			NULL	},
	{	"OVA_UVSCALE",	0x30144, NULL,	"U V Scale Factor",				NULL	},
	{	"OVA_OCLRC0",	0x30148, NULL, 	"Overlay Color Correction 0",	NULL	},
	{	"OVA_OCLRC1",	0x3014C, NULL,	"Overlay Color Correction 1",	NULL	},
	{	"OVA_OCONFIG",	0x30164, NULL,	"Overlay Configuration"	,		NULL	},
	{	"OVA_OCOMD",	0x30168, NULL,	"Overlay Command",				NULL	},
	{	"OVA_OFLIPMODE",0x3016C, NULL,	"Overlay Flip Mode",			NULL	},
	{	"OVA_OFDROP",	0x30170, NULL,	"Overlay Frame Drop Counter",	NULL	},
	{	"OVA_OFREPEAT",	0x30174, NULL,	"Overlay Frame Repeat Counter",	NULL	},
	{	"OVA_UVSCALEV",	0x301a4, NULL,	"UV Vertical Downscale Integer",NULL	},
	{	"OVA_Y_VCOEFS",	0x30200, NULL,	"Overlay Y Vertical Filter Coefficient",	NULL	},
	{	"OVA_Y_HCOEFS",	0x30300, NULL,	"Overlay Y Horizontal Filter Coefficients",	NULL},
	{	"OVA_UV_VCOEFS",0x30500, NULL,	"Overlay UV Vertical Filter Coefficients",	NULL},
	{	"OVA_UV_HCOEFS",0x30600, NULL,	"Overlay UV Horizontal Filter Coefficients",NULL},
	{   "OVB_OBUF_OY",	0x31104, NULL,	"Overlay Buffer 1 Y Pointer",	NULL	},
	{	"OVB_OBUF_0U",	0x31108, NULL,	"Overlay Buffer 0 U Pointer",	NULL	},
	{	"OVB_OBUF_0V",	0x3110C, NULL,	"Overlay Buffer 0 V Pointer",	NULL	},
	{	"OVB_OBUF_1U",	0x31110, NULL,	"Overlay Buffer 1 U Pointer",	NULL	},
	{	"OVB_OBUF_1V",	0x31114, NULL,	"Overlay Buffer 1 V Pointer",	NULL	},
	{	"OVB_OSTRIDE",	0x31118, NULL,	"Overlay Stride",				NULL	},
	{	"OVB_YRGB_VPH",	0x3111C, NULL,	"Y/RGB Vertical Phase 0/1", 	NULL	},
	{	"OVB_UV_VPH",	0x31120, NULL,	"UV Vertical Phase 0/1",		NULL	},
	{	"OVB_HORZ_PH",	0x31124, NULL,	"Horizontal Phase",				NULL	},
	{	"OVB_INIT_PHS",	0x31128, NULL,	"Initial Phase Shift",			NULL	},
	{	"OVB_DWINPOS",	0x3112C, NULL,	"Destination Window Position",	NULL	},
	{	"OVB_DWINSZ",	0x31130, NULL,	"Destination Window Size",		NULL	},
	{	"OVB_SWIDTH",	0x31134, NULL,	"Source Width",					NULL	},
	{	"OVB_SWIDTHSW",	0x31138, NULL,	"Source Width In SWORDS",		NULL	},
	{	"OVB_SHEIGHT",	0x3113C, NULL,	"Source Height",				NULL	},
	{	"OVB_YRGBSCALE",0x31140, NULL,	"Y/RGB Scale Factor",			NULL	},
	{	"OVB_UVSCALE",	0x31144, NULL,	"U V Scale Factor",				NULL	},
	{	"OVB_OCLRC0",	0x31148, NULL,	"Overlay Color Correction 0",	NULL	},
	{	"OVB_OCLRC1",	0x3114C, NULL,	"Overlay Color Correction 1",	NULL	},
	{	"OVB_OCONFIG",	0x31164, NULL,	"Overlay Configuration"	,		NULL	},
	{	"OVB_OCOMD",	0x31168, NULL,	"Overlay Command",				NULL	},
	{	"OVB_OFLIPMODE",0x3116C, NULL,	"Overlay Flip Mode",			NULL	},
	{	"OVB_OFDROP",	0x31170, NULL,	"Overlay Frame Drop Counter",	NULL	},
	{	"OVB_OFREPEAT",	0x31174, NULL,	"Overlay Frame Repeat Counter",	NULL	},
	{	"OVB_UVSCALEV",	0x311a4,	 NULL,"UV Vertical Downscale Integer",NULL	},
	{	"OVB_Y_VCOEFS",	0x31200, NULL,	"Overlay Y Vertical Filter Coefficient",	NULL	},
	{	"OVB_Y_HCOEFS",	0x31300, NULL,	"Overlay Y Horizontal Filter Coefficients",	NULL},
	{	"OVB_UV_VCOEFS",0x31500, NULL,	"Overlay UV Vertical Filter Coefficients",	NULL},
	{	"OVB_UV_HCOEFS",0x31600, NULL,	"Overlay UV Horizontal Filter Coefficients",NULL},
    {	"DPLL_CTRL",	0x6014, NULL,		"DPLL_CTRL-DPLL Control Register",	NULL },
	{	"CLKGATE", 	0x6200,	NULL,	"Clock Gating Disable",	NULL,},
	{	"DPALETTE_A", 	0xA000,	NULL,	"DPALETTE_A Pipe A Display Palette",NULL,	},
	{	"HTOTAL_A", 	0x6000,	NULL,	"HTOTAL_A Pipe A Horizontal Total Register",NULL,},
	{	"HBLANK_A", 	0x6004,	NULL,	"HBLANK_A Pipe A Horizontal Blank Register",NULL,},
	{	"HSYNC_A", 	0x6008,	NULL,	"HSYNC_A Pipe A Horizontal Sync Register",	NULL,},
	{	"VTOTAL_A", 	0x600C,	NULL,	"VTOTAL_A	Pipe A Vertical Total Register",NULL},
	{	"VBLANK_A", 	0x60010,NULL,	"VBLANK_A Pipe A Vertical Blank Register",	NULL},
	{	"VSYNC_A", 	0x60014,NULL,	"VSYNCH_A Pipe A Vertical Sync Register",	NULL,},
	{	"PIPEASRC", 	0x6001c,NULL,	"Pipe A Source Image Size",					NULL,},
	{	"BCLRPAT_A", 	0x60020,NULL,	"Pipe A Border Color Pattern Register",		NULL,},
	{	"CANVSCLR_A", 	0x60024,NULL,	"Pipe A Canvas (Background) Color Register",NULL,},
	{	"VSYNCSHIFT_A",	0x60028, NULL,	"Vertical Sync Shift Register",			NULL,},
	{	"CRCCtrlColorA",0x60050,NULL,	"Pipe A CRC Color Channel Control Register(RED)",NULL,},
	{	"PVOCONFIG",	0x61140, NULL,	"Pixel Video Output Configuration Register",	NULL,},
	{	"TMCR0",		0x62200, NULL,	"Tiled Memory Configuration Register",		NULL,},
	{	"TMTAR0",		0x62204, NULL,	"Tiled Memory Top Address Register",		NULL,},
	{	"TMBAR0",		0x62208, NULL,	"Tiled Memory Base Address Register",		NULL,},
 	{	"TMCR1",		0x62210,  NULL,	"Tiled Memory Configuration Register",		NULL,},
	{	"TMTAR1",		0x62214,NULL,	"Tiled Memory Top Address Register",		NULL,},
	{	"TMBAR1",		0x62218, NULL,	"Tiled Memory Base Address Register",		NULL,},
	{	"CRCCtrlColorA0",	0x60054, NULL,	"Pipe A CRC Color Channel Control Register (Green)",	NULL,},
	{	"CRCCtrlColorA1",	0x60058, NULL,	"Pipe A CRC Color Channel Control Register (BLUE)",	NULL,},
	{	"CRCCtrlColorA2",	0x6005C, NULL,	"Pipe A CRC Color Channel Control Register (ALPHA)",	NULL,},
	{	"CRCResColorA0",	0x60060, NULL,	"Pipe A CRC Color Channel Result Register (Red)",	NULL,},
	{	"CRCResColorA1",	0x60064, NULL,	"Pipe A CRC Color Channel Result Register (Green)",	NULL,},
	{	"CRCResColorA2",	0x60068, NULL,	"Pipe A CRC Color Channel Result Register (Blue)",	NULL,},
	{	"CRCResColorA3",	0x6006c, NULL,	"Pipe A CRC Color Channel Result Register (ALPHA)",	NULL,},
	{	"IPEACONF",			0x70008, NULL,	"Pipe A Configuration Register",NULL,	},
	{	"PIPEGCMAXRED",		0x70010, NULL,	"Pipe Gamma Correction Max Red",NULL,	},
	{	"PIPEGCMAXGRN",		0x70014, NULL,	"Pipe Gamma Correction Max Green",NULL,	},
	{	"PIPEGCMAXBLU",		0x70018, NULL,	"Pipe Gamma Correction Max Red",NULL,	},
	{	"PIPEASTAT",		0x70024, NULL,	"Pipe A Display Status",NULL,			},
	{	"DSPARB_DDB",		0x70030, NULL,	" DSPARBConfiguration",NULL,			},
	{	"PipeAFrameHigh",	0x70040, NULL,	"Frame Count",			NULL,			},
	{	"PipeAFramePixel",	0x70044, NULL,	" Pixel Count",			NULL,			},
	{	"CHKN_BITS",		0x70400, NULL,	" Chicken Bits ",		NULL,			},
	{	"DSPBCNTR",			0x71180, NULL,	"Subtitle Plane Plane Control Register",	NULL,	},
	{	"DSPBADDR",			0x71184, NULL,	"Subtitle Plane Start Address Register",	NULL,	},
	{	"DSPBSTRIDE",		0x71188, NULL,	"Subtitle Plane Stride Register",			NULL,	},
	{	"DSPBPOS",			0x7118c, NULL,	"Subtitle Position Register",				NULL,	},
	{	"DSPBSIZE",			0x71190, NULL,	"Subtitle Height and Width Register",		NULL,	},
	{	"DSPCCNTR",			0x72180, NULL,	"Graphics Plane  Control Register",			NULL,	},
	{	"DSPCADDR",			0x72184, NULL,	"Graphics Plane Start Address Register",	NULL,	},
	{	"DSPCSTRIDE",		0x72188, NULL,	"Graphics Plane Stride Register ",			NULL,	},
    {	"TV_out_Control",			0x68000, NULL,	NULL, NULL,	},
	{	"TV_DAC_Control_Status",	0x68004, NULL,	NULL, NULL,	},
	{	"reserved_1",					0x68008, NULL,	NULL, NULL,	},
	{	"reserved_2",					0x6800C, NULL,	NULL, NULL,	},
	{	"Color_Space_Convert_Y",	0x68010, NULL,	NULL,NULL,	},
	{	"Color_Space_Convert_Y2",	0x68014, NULL,	NULL,NULL,	},
	{	"Color_Space_Convert_U",	0x68018, NULL,	NULL,NULL,	},
	{	"Color_Space_Convert_U2",	0x6801C, NULL,	NULL,NULL,	},
	{	"Color_Space_Convert_V",	0x68020, NULL,	NULL,NULL,	},
	{	"Color_Space_Convert_V2",	0x68024, NULL,	NULL,NULL,	},
	{	"Color_Knobs",				0x68028,	NULL, NULL,NULL,	},
	{	"Color_Level_Control",		0x6802C,	NULL, NULL,NULL,	},
	{	"H_Control1_Hsync_Htotal",	0x68030,	NULL, NULL,NULL,	},
	{	"H_Control2_Hsync_H_Burst_Control",		0x68034,	NULL,NULL,NULL,	},
	{	"H_Control3_Blanking",					0x68038,	NULL,NULL,NULL,	},
	{	"V_Control1_NBR_and_VI_end",			0x6803c,	NULL,NULL,NULL,	},
	{	"V_Control2_Vsync_Control",				0x68040,	NULL,NULL,NULL,	},
	{	"V_Control3_Equalisation_Control",		0x68044,	NULL,NULL,NULL,	},
	{	"V_Control4_v_burst_field_1",			0x68048,	NULL,NULL,NULL,	},
	{	"V_Control5_v_burst_field_2",			0x6804c,	NULL,NULL,NULL,	},
	{	"V_Control6_v_burst_field_3",			0x68050,	NULL,NULL,NULL,	},
	{	"V_Control7_v_burst_field_4",			0x68054,	NULL,NULL,NULL,	},
	{	"reserved_3"					,			0x68058,	NULL,NULL,NULL,	},
	{	"SC_Control_1_enables_Burst_level_SC_DDA1",		0x68060,	NULL,NULL,NULL,	},
	{	"SC_Control_2_SC_DDA2",		0x68064,	NULL,NULL,NULL,	},
	{	"SC_Control_3_SC_DDA3",		0x68068,	NULL,NULL,NULL,	},
	{	"reserved_4",						0x6806c,	NULL,NULL,NULL,	},
	{	"Window_Position",				0x68070,	NULL,NULL,NULL,	},
	{	"Window_size",					0x68074,		NULL,NULL,NULL,	},
	{	"reserved_5",						0x68078,		NULL,NULL,NULL,	},
	{	"Filter_Control_1_Mode_and_H_frac",	0x68080,	NULL,NULL,NULL,},
	{	"Filter_Control_2_Vert_scale",		0x68084,	NULL,NULL,NULL,},
	{	"Filter_Control_3_Vert_Initial_Phase",0x68088,	NULL,NULL,NULL,},
	{	"Sin_Rom",								0x6808c,	NULL,NULL,NULL,},
	{	"CC_Control",							0x68090,	NULL,NULL,NULL,},
	{	"CC_Data_Field_1",						0x68094,	NULL,NULL,NULL,},
	{	"CC_Data_Filed_2",						0x68098,	NULL,NULL,NULL,},
	{	"reserved_6",							0x6809C,	NULL,NULL,NULL,},
	{	"WSS_Control",							0x680B0,	NULL,NULL,NULL,},
	{	"WSS_DATA",								0x680B8,	NULL,NULL,NULL,},
	{	"reserved_7",							0x680BC,	NULL,NULL,NULL,},
	{	"H_Filter_Y_Coefficients",				0x68100,	NULL,NULL,NULL,},
	{	"H_Filter_C_Coefficients",				0x68200,	NULL,NULL,NULL,},
	{	"V_Filter_Y_Coefficients",				0x68300,	NULL,NULL,NULL,},
	{	"V_Filter_C_Coefficients",				0x68400,	NULL,NULL,NULL,},

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */



/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_GEN1_VDC_specific_events[] =
{
    { "OUT_FIFO_FULL",      1,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    2,      "", NULL },

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN1_VDC_sven_module =
{
    "GEN1_VDC",
    SVEN_module_GEN1_VDC,
    1*1024*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN1_VDC,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "VDC: VDC Function (GEN1)",     /* TODO: Get a better text string */
    g_GEN1_VDC_specific_events,          /* TODO-Later: Define important events specific to my module */
    NULL                            /* extension list */
};
