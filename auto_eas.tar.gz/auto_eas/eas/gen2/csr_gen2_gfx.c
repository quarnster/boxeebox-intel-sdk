/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_GFX_versions.
 */
static const struct EAS_Register g_csr_GEN1_GFX[] =
{
{  "Software_Reset",	0x0080,  NULL, NULL, NULL,},
{  "Interrupt_Status", 0x012C,  NULL, NULL, NULL,},
{  "Interrupt_Enable", 0x0130,  NULL, NULL, NULL,},
{  "Interrupt_Clear",	0x0134,  NULL, NULL, NULL,},
{  "Memory_Page_Size", 0x0140,  NULL, NULL, NULL,},
{  "3D_Region_HeaderBase",	0x0608,  NULL, NULL, NULL,},
{  "3D_Object_Base",	0x060C,  NULL, NULL, NULL,},
{  "3D_Z_Load_Store_Control",	0x0610,  NULL, NULL, NULL,},
{  "3D_FPU_PerpendicularCompare",0x0614,  NULL, NULL, NULL,},
{  "3D_FPU_Cull_Value",0x0618,  NULL, NULL, NULL,},
{  "3D_Pixel_Sampling",0x061C,  NULL, NULL, NULL,},
{  "3D_Colour_Key_1",	0x0624,  NULL, NULL, NULL,},
{  "3D_Colour_Key_2",	0x0628,  NULL, NULL, NULL,},
{  "3D_Colour_Key_UV", 0x062C,  NULL, NULL, NULL,},
{  "3D_Colour_Key_Mask",		0x0630,  NULL, NULL, NULL,},
{  "3D_Vertex_Fog_Colour",		0x063C,  NULL, NULL, NULL,},
{  "3D_Vertex_Fog_Status",		0x0640,  NULL, NULL, NULL,},
{  "3D_scalar_Control",		0x0644,  NULL, NULL, NULL,},
{  "3D_Blend_ARGB_Sum",		0x0648,  NULL, NULL, NULL,},
{  "3D_Write_Control", 		0x0650,  NULL, NULL, NULL,},
{  "3D_Write_X_Clipping",		0x0654,  NULL, NULL, NULL,},
{  "3D_Write_Y_Clipping",		0x0658,  NULL, NULL, NULL,},
{  "3D_Render_Address",		0x065C,  NULL, NULL, NULL,},
{  "3D_Write_Stride",			0x0660,  NULL, NULL, NULL,},
{  "3D_Texture_Latency",		0x0664,  NULL, NULL, NULL,},
{  "3D_Z_Base_Address",		0x0674,  NULL, NULL, NULL,},
{  "3D_Start_Render",			0x0680,  NULL, NULL, NULL,},
{  "3D_Flat_Shaded_Colour_Source", 0x06D0,  NULL, NULL, NULL,},
{  "3D_ZLoad_Background_Tag",	0x06D8,  NULL, NULL, NULL,},
{  "3D_ZLoad_Background_Depth",0x06DC,  NULL, NULL, NULL,},
{  "3D_1Bpp_Background_Colour",0x06E0,  NULL, NULL, NULL,},
{  "3D_1Bpp_Foreground_Colour",0x06E4,  NULL, NULL, NULL,},
{  "3D_1Bpp_Use_Register_Values",0x06E8,  NULL, NULL, NULL,},
{  "3D_Render_ID",			0x06EC,  NULL, NULL, NULL,},
{  "3D_Texture_Decimation",0x06F0,  NULL, NULL, NULL,},
{  "TA_Start",				0x0800,  NULL, NULL, NULL,},
{  "TA_Restart",			0x0804,  NULL, NULL, NULL,},
{  "TA_Abort",				0x0808,  NULL, NULL, NULL,},
{  "TA_Render_ID",			0x0810,  NULL, NULL, NULL,},
{  "TA_Context_Load",		0x0814,  NULL, NULL, NULL,},
{  "TA_Context_Store",		0x0818,  NULL, NULL, NULL,},
{  "TA_Context_Reset",		0x081C,  NULL, NULL, NULL,},
{  "TA_Context_Base",		0x0820,  NULL, NULL, NULL,},
{  "EVM_Page_Table_Base_Address", 0x0824,  NULL, NULL, NULL,},
{  "EVM_List_Start_Page",	0x0828,  NULL, NULL, NULL,},
{  "EVM_List_End_Page",	0x082C,  NULL, NULL, NULL,},
{  "EVM_Render_Timeout",	0x0830,  NULL, NULL, NULL,},
{  "EVM_TA_Timeout",		0x0834,  NULL, NULL, NULL,},
{  "EVM_Init",				0x0838,  NULL, NULL, NULL,},
{  "TA_ObjectBase_Address",0x083C,  NULL, NULL, NULL,},
{  "TA_Tail_Pointer_Base_Address", 0x0840,  NULL, NULL, NULL,},
{  "TA_Region_Base_Address",0x0844,  NULL, NULL, NULL,},
{  "TA_X_Screen_Clip",	0x084C,  NULL, NULL, NULL,},
{  "TA_Y_Screen_Clip", 0x0850,  NULL, NULL, NULL,},
{  "TA_RHW_Clamp",		0x0854,  NULL, NULL, NULL,},
{  "TA_RHW_Compare",	0x0858,  NULL, NULL, NULL,},
{  "TA_Configuration", 0x085C,  NULL, NULL, NULL,},
{  "EVM_Context_Base_Address", 0x0864,  NULL, NULL, NULL,},
{  "ISP1_Signature", 0x0CC4,  NULL, NULL, NULL,},
{  "TSP1_Signature", 0x0CCC,  NULL, NULL, NULL,},
{  "Diagnostics_Enable",	0x0CE0,  NULL, NULL, NULL,},
{  "MBX_Lite_Core_ID",		0x0F00,  NULL, NULL, NULL,},
{  "MBX_Lite_Core_Revision",0x0F10,  NULL, NULL, NULL,},
/*MB Lite* v1.1+ Specific Registers */
{ "Clock_Ratio_Status", 0x0090, NULL, NULL, NULL,},
{ "2D_Idle_Timeout_Clock_Cycle_Count", 0x0100, NULL, NULL, NULL,},
{ "Startup_Timeout_Clock_Cycle_Count", 0x0104 , NULL, NULL, NULL,},
{ "General_Purpose_Output", 0x0108, NULL, NULL, NULL,},
    CSR_NULL_TERM()

};
#endif /* !SVEN_INTERNAL_BUILD */



/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_GEN1_GFX_specific_events[] =
{

/******EXAMPLES*******

    { "OUT_FIFO_FULL",      1,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    2,      "", NULL },

 ****END EXAMPLES*****/

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN1_GFX_sven_module =
{
    "GEN1_GFX",
    SVEN_module_GEN1_GFX,
    256,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN1_GFX,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: GFX Function (GEN1)",    /* TODO: Get a better text string */
    g_GEN1_GFX_specific_events,       /* TODO-Later: Define important events specific to my module */
    NULL                          /* extension list */
};

