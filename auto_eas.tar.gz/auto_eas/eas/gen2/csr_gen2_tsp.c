/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

static const struct EAS_RegBits g_csr_BSR_TSP_PF_STATUS_OLO[] =
{
    { "RSVD_31_11",11,21,"",NULL },      /* */
    { "OCF",10,1,"",NULL },      /* */
    { "CRC",9,1,"",NULL },     /* */
    { "DIS",8,1,"",NULL },    /* */
    { "DET",7,1,"",NULL },   /* */
    { "PPF",6,1,"",NULL },    /* */
    { "WDT",5,1,"",NULL },       /* */
    { "FE",4,1,"",NULL },      /* */
    { "FF",3,1,"",NULL },    /* */
    { "PLT",2,1,"",NULL },             /* */
    { "PGT",1,1,"",NULL },      /* */
    { "EN",0,1,"",NULL },        /* */

    CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_BSR_TSP_PCR_CONFIG[] =
{
    { "IRQ_EN",31,1,"",NULL },      /* */
    { "RSVD_30_6",6,25,"",NULL },      /* */
    { "FIRST",5,1,"",NULL },       /* */
    { "RSVD_4_1",1,4,"",NULL },      /* */
    { "EN",0,1,"",NULL },        /* */

    CSR_BB_NULL_TERM()
};

/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_GEN1_TSP_versions.
 */
static const struct EAS_Register g_csr_GEN1_TSP[] =
{
    CSR_REG("PF_P1CFG"                         ,0x00000, "")
    CSR_REG("PF_S1CFG"                         ,0x00008, "")

    CSR_REG("PF1_PMM_0"                     ,0x04000, "")
    CSR_REG("PF1_PMM_1"                     ,0x04004, "")
    CSR_REG("PF1_PMM_2"                     ,0x04008, "")
    CSR_REG("PF1_PMM_3"                     ,0x0400C, "")
    CSR_REG("PF1_PMM_4"                     ,0x04010, "")
    CSR_REG("PF1_PMM_5"                     ,0x04014, "")
    CSR_REG("PF1_PMM_6"                     ,0x04018, "")
    CSR_REG("PF1_PMM_7"                     ,0x0401C, "")
    CSR_REG("PF1_PMM_8"                     ,0x04020, "")
    CSR_REG("PF1_PMM_9"                     ,0x04024, "")
    CSR_REG("PF1_PMM_10"                    ,0x04028, "")
    CSR_REG("PF1_PMM_11"                    ,0x0402C, "")
    CSR_REG("PF1_PMM_12"                    ,0x04030, "")
    CSR_REG("PF1_PMM_13"                    ,0x04034, "")
    CSR_REG("PF1_PMM_14"                    ,0x04038, "")
    CSR_REG("PF1_PMM_15"                    ,0x0403C, "")
    CSR_REG("PF1_PMM_16"                    ,0x04040, "")
    CSR_REG("PF1_PMM_17"                    ,0x04044, "")
    CSR_REG("PF1_PMM_18"                    ,0x04048, "")
    CSR_REG("PF1_PMM_19"                    ,0x0404C, "")
    CSR_REG("PF1_PMM_20"                    ,0x04050, "")
    CSR_REG("PF1_PMM_21"                    ,0x04054, "")
    CSR_REG("PF1_PMM_22"                    ,0x04058, "")
    CSR_REG("PF1_PMM_23"                    ,0x0405C, "")
    CSR_REG("PF1_PMM_24"                    ,0x04060, "")
    CSR_REG("PF1_PMM_25"                    ,0x04064, "")
    CSR_REG("PF1_PMM_26"                    ,0x04068, "")
    CSR_REG("PF1_PMM_27"                    ,0x0406C, "")
    CSR_REG("PF1_PMM_28"                    ,0x04070, "")
    CSR_REG("PF1_PMM_29"                    ,0x04074, "")
    CSR_REG("PF1_PMM_30"                    ,0x04078, "")
    CSR_REG("PF1_PMM_31"                    ,0x0407C, "")

    CSR_REG("PF1_CONFIG"                       ,0x04100, "")
    CSR_REG_W_BB("PF1_STATUS"                  ,0x04104,g_csr_BSR_TSP_PF_STATUS_OLO,   "Pre-filter 0 Filter Status")

    CSR_REG("PF1_DMA_BASE"                     ,0x04200, "")
    CSR_REG("PF1_DMA_SIZE"                     ,0x04204, "")
    CSR_REG("PF1_DMA_WR_PTR"                    ,0x04208, "")
    CSR_REG("PF1_DMA_SHDW_WR_PTR_ADDR"         ,0x0420C, "")
    CSR_REG("PF1_DMA_RD_PTR"                   ,0x04210, "")
    CSR_REG("PF1_DMA_SHDW_WR_CNTR"             ,0x04214, "")
    CSR_REG("PF1_NIM_WDT"                      ,0x04218, "")

    /* Prefilter Timebase 1 */
    CSR_REG_W_BB("PF1_PCR_CONFIG"              ,0x04300,g_csr_BSR_TSP_PCR_CONFIG, "")
    CSR_REG("PF1_TBASE_LOCAL_0"                ,0x04304, "")
    CSR_REG("PF1_TBASE_LOCAL_1"                ,0x04308, "")
    CSR_REG("PF1_PCR_LOCAL_A0"                 ,0x0430C, "")
    CSR_REG("PF1_PCR_LOCAL_A1"                 ,0x04310, "")
    CSR_REG("PF1_PCR_LOCAL_B0"                 ,0x04314, "")
    CSR_REG("PF1_PCR_LOCAL_B1"                 ,0x04318, "")
    CSR_REG("PF1_PCR_REMOTE_A0"                ,0x0431C, "")
    CSR_REG("PF1_PCR_REMOTE_A1"                ,0x04320, "")
    CSR_REG("PF1_PCR_REMOTE_B0"                ,0x04324, "")
    CSR_REG("PF1_PCR_REMOTE_B1"                ,0x04328, "")

    CSR_REG("PF1_STC_GEN_CONFIG"               ,0x04400, "")
    CSR_REG("PF1_DDS_CONFIG"                   ,0x04404, "")
    CSR_REG("PF1_VCXO_CONFIG"                  ,0x04408, "")

    /* Prefilter Timebase 2 */
    CSR_REG("PF2_TBASE_LOCAL_0"                ,0x08304, "")
    CSR_REG("PF2_TBASE_LOCAL_1"                ,0x08308, "")
    CSR_REG("PF2_PCR_LOCAL_A0"                 ,0x0830C, "")
    CSR_REG("PF2_PCR_LOCAL_A1"                 ,0x08310, "")
    CSR_REG("PF2_PCR_LOCAL_B0"                 ,0x08314, "")
    CSR_REG("PF2_PCR_LOCAL_B1"                 ,0x08318, "")
    CSR_REG("PF2_STC_GEN_CONFIG"               ,0x08400, "")
    CSR_REG("PF2_DDS_CONFIG"                   ,0x08404, "")
    CSR_REG("PF2_VCXO_CONFIG"                  ,0x08408, "")

    /* Prefilter Timebase 3 */
    CSR_REG("PF3_TBASE_LOCAL_0"                ,0x0c304, "")
    CSR_REG("PF3_TBASE_LOCAL_1"                ,0x0c308, "")
    CSR_REG("PF3_PCR_LOCAL_A0"                 ,0x0c30C, "")
    CSR_REG("PF3_PCR_LOCAL_A1"                 ,0x0c310, "")
    CSR_REG("PF3_PCR_LOCAL_B0"                 ,0x0c314, "")
    CSR_REG("PF3_PCR_LOCAL_B1"                 ,0x0c318, "")
    CSR_REG("PF3_STC_GEN_CONFIG"               ,0x0c400, "")
    CSR_REG("PF3_DDS_CONFIG"                   ,0x0c404, "")
    CSR_REG("PF3_VCXO_CONFIG"                  ,0x0c408, "")

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_GEN1_TSP_specific_events[] =
{
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN1_TSP_sven_module =
{
    "GEN1_TSP",
    SVEN_module_GEN1_PREFILT,
    128*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN1_TSP,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: TSP Function (GEN1)",     /* TODO: Get a better text string */
    g_GEN1_TSP_specific_events,          /* TODO-Later: Define important events specific to my module */
    NULL                            /* extension list */
};
