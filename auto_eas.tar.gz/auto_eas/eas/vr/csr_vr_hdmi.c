/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

#ifdef SVEN_INTERNAL_BUILD
static const struct EAS_RegBits g_csr_vr_hdmi_HGCR[] = 
{
    { "EN_AVMUTE",          31, 1, "", NULL },
    /* 0    RW  NA  This enables support of AV_MUTE. The unit will not respond to general control packets if this bit is not set. AVMUTE support is optional */
    { "SYNC_CNT_POS2NEG",   30, 1, "", NULL },
    /* 0    RW  NA  If set, this bit enables the video format counters to count from the rising edge of HSYNC/VSYNC to the falling edge of HSYNC/VSYNC. By default the unit counts rising edge to rising edge. */
    { "RSTR_HDCP_CTXT",     29, 1, "", NULL },
    /* 0    RW  NA  Instructs the Unit to restore HDCP context. Used to restore context after reset if the unit was in AVMUTE state prior to reset. */
    { "RSVD",               26, 3, "", NULL },
    /* 0    RV  NA  Reserved for future use. */
    { "KEY_WR_DONE",        25, 1, "", NULL },
    /* 0    RW       */
    { "SEL_KEY_BANK",       24, 1, "", NULL },
    /* 0    RW  NA  0 => Select Key bank from SW 1 => Select Key bank from UEE */
    { "IGNR_DIP_PSR_ERR",   23, 1, "", NULL },
    /* 0    RW  NA  Instructs the BCH decoder and Audio sub-system to ignore Parser Decoding and Synch errors in Data Island Packets. When this bit is set, BCH will ignore Parser errors and do BCH error detection/correction.
            When this bit is not set, on a Parser Error, BCH will not do any decoding/correction and just pass the packet. The audio subsystem will also ignore Parser errors and will process the packet as a normal packet. */
    { "AVMUTE_STATE",       22, 1, "", NULL },
    /* 0    RW  NA  Setting this bit tells the unit that it should go into AV_MUTE state. The unit looks for a Set to Clear transition to detect Clear AVMUTE condition.  PLC Test compliance spec suggest that a Sink should be able to clear AV_MUTE state is no CLR AV_MUTE packet is received within 5 seconds of receiving a SET AV_MUTE packet. SW will be interrupted when a SET AV_MUTE condition is detected, however the unit might required a reset to recover from Synch errors. In this case, SW can set this bit after reset to inform the unit that it should go into AVMUTE state. If a Clr AVMUTE packet is not detected, SW can then clear this bit to ensure that the unit goes back to a Clear AVMUTE state.  */
    { "INH_ACP",            21, 1, "", NULL },
    /* 0    RW  NA  Setting of this bit indicates HDMI to stop sending ACP packets to Audio unit - they will get dropped within HDMI */
    { "INH_ISCRC2",         20, 1, "", NULL },
    /* 0    RW  NA  Setting of this bit indicates HDMI to stop sending ISCRC2 packets to the Audio unit - they will get dropped within HDMI */
    { "INH_ISCRC1",         19, 1, "", NULL },
    /* 0    RW  NA  Setting of this bit indicates HDMI to stop sending ISCRC1 packets to the Audio unit - they will get dropped within HDMI */
    { "INH_AUD_INF",        18, 1, "", NULL },
    /* 0    RW  NA  Setting of this bit indicates HDMI to stop sending Audio InfoFrame packets to the Audio unit */
    { "INH_AUD_SMPL",       17, 1, "", NULL },
    /* 0    RW  NA  Setting of this bit indicates HDMI to stop sending Audio sample data to the Audio unit */
    { "PIX_DENSITY",        15, 2, "", NULL },
    /* 0    RW  NA  00 - 8B: Pixel Density
        01 - 10b: Pixel Density
        10 - 12b: Pixel Density
        11 - Not used
    */
    { "INTL_VID",           14, 1, "", NULL },
    /* 0    RW  NA  This indicates that Interlaced Video is being received. The unit is controlled by this bit even though the unit reports what it is detecting in a similar HDMI Status register bit. SW uses this bit to override what the unit is detecting. */
    { "DIS_HDCP",           13, 1, "", NULL },
    /* 0    RW  NA  Disables HDCP sub-system when set to 1 */
    { "IGNR_BCH_ERR",       12, 1, "", NULL },
    /* 0    RW  NA  This bit will ensure that HDMI unit does not drop packets with BCH errors.
    NOTE : SW needs to mask the interrupt for this condition separately using Interrupt Mask Register. */
    { "PIX_CNT_LEN",        10, 2, "", NULL },
    /* 0    RW  NA  Number of HSYNCs (lines) during which number of Pixels in a Line is calculated.
        00: 8
        01: 16
        10: 32
        11: 64
    */
    { "PIX_RPT_CNT",        6,  4, "", NULL },
    /* 0    RW  NA  Indicates the Pixel repetition count. See Table 1 16 for encoding of these 4 bits */
    { "DIS_HDMI",           5,  1, "", NULL },
    /* 0    RW  NA  Disables the unit from acting as a HDMI Rx */
    { "VID_FRMT",           3,  2, "", NULL },
    /* 0    RW  NA
        00: RGB
        01: YCrCb 4:4:4
        10: YCrCb 4:2:2
        11: RSVD 
    */
    { "INIT_DN",            2,  1, "", NULL },
    /* 0    RW  NA  This indicates that HDMI and all other units required to receive incoming data (VCAP and Audio) have been setup */
    { "VSYNC_ACT_HIGH",     1,  1, "", NULL },
    /* 0    RV  NA  Indicates that VSYNC being received from HDMI source is active High. Default value of 0 indicates Active Low VSYNC */
    { "HSYNC_ACT_HIGH",     0,  1, "", NULL },
    /* 0    RV  NA  Indicates that HSYNC being received from HDMI source is active High. Default value of 0 indicates Active Low HSYNC */

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Register defines pulled from HDMI EAS 12oct2005 */
static const struct EAS_RegBits g_csr_vr_hdmi_HGSR[] = 
{
    { "RSVD_32_21",         21, 11, "", NULL },
    /* 0    RV  NA  Reserved */
    { "AUTH_STATE",         20, 1, "", NULL },
    /* 0    RO  NA  Indicates that HDCP Subsystem is in Authenticated state */
    { "EDID_BUF_FULL",      19, 1, "", NULL },
    /* 0    RO  NA  Bit indicating that the 64 B EDID buffer is full. SW can write new values to the HEDR. */
    { "ENC_EN",             18, 1, "", NULL },
    /* 0    RO  NA  0 indicates no encryption. '1' indicates encryption is enabled by Source. */
    { "HDMI_OR_DVI",        17, 1, "", NULL },
    /* 0    RO  NA  Bit indicating whether VR is in HDMI or DVI mode. Default mode is DVI. Upon receipt of first DIP preamble followed by Data Island Leading Guard Band, will be set to '1' by the parser. */
    { "INTL_VID_DTCT",      16, 1, "", NULL },
    /* 0    RO  NA  Indicates that HDMI has detected Interlaced video (from Field1/2 detection) */
    { "RSVD_15_12",         12, 4, "", NULL },
    /* 0    RV  NA  Reserved */
    { "UEE_KEY_BUF_RDY",    11, 1, "", NULL },
    /* 0    RWC NA  Indicates that the UEE Key bank is initialized (cleared after reset) and ready to receive UEE keys. */
    { "CSR_KEY_BUF_RDY",    10, 1, "", NULL },
    /* 0    RWC NA  Indicates that the CSR Key bank is initialized (cleared after reset) and ready to receive keys from SW */
    { "HDMI_VDP_LGB_ERR",   9,  1, "", NULL },
    /* 0    RWC NA  Indicates that the HDMI unit saw an error in the video guard band. */
    { "HDMI_DIP_GB_ERR",    8,  1, "", NULL },
    /* 0    RWC NA  Indicates that the HDMI unit saw an error in the data guard band. */
    { "RSVD_7_4",           4,  4, "", NULL },
    /* 0    RV  NA  Reserved for future use */
    { "CH_ALIGN",           3,  1, "", NULL },
    /* 0    RWC NA  The unit has achieved inter-channel alignment */
    { "CSL_LOCK_ERR",       2,  1, "", NULL },
    /* 0    RWC NA  The symbol lock logic has detected an error */
    { "CSL_LOCK",           1,  1, "", NULL },
    /* 0    RWC NA  The unit has achieved symbol lock on all channels */
    { "PXL_DT_SNT",         0,  1, "", NULL },
    /* 0    RWC NA  Valid Pixel data has been sent to VCAP from HDMI */

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Register defines pulled from HDMI EAS 12oct2005 */
static const struct EAS_RegBits g_csr_vr_hdmi_HISR[] = 
{
    { "RECV_AUTH_REQ",      31, 1, "", NULL },
    /* 0    RWC NA  Generation of interrupt when authentication request is received. */
    { "HSCNT_ERR",          30, 1, "", NULL },
    /* 0    RWC NA  HSYNC Count error - Number of received HSYNCs more than Threshold value */
    { "HISR_RSVD4",         29, 1, "", NULL },
    /* 0    RV  NA  Reserved for future use */
    { "HISR_RSVD3",         28, 1, "", NULL },
    /* 0    RV  NA  Reserved for future use */
    { "HISR_RSVD2",         27, 1, "", NULL },
    /* 0    RV  NA  Reserved for future use */
    { "HISR_RSVD1",         26, 1, "", NULL },
    /* 0    RV  NA  Reserved for future use */
    { "PIX_CLK_FRQ_CHNG",   25, 1, "", NULL },
    /* 0    RWC NA  Change in pixel clock frequency detected */
    { "PIX_CNT_ERR",        24, 1, "", NULL },
    /* 0    RWC NA  Pixel Count Error - Number of Pixels more than threshold value */
    { "FLD_DTCT_ERR",       23, 1, "", NULL },
    /* 0    RWC NA  Error due to mismatch between expected video format vs. what is detected (interlaced vs. progressive). */
    { "INVALID_CTRL_CHAR",  22, 1, "", NULL },
    /* 0    RWC NA  Erroneous control period symbol. Means that the CP could not be decoded from 10 bits to 2bits. */
    { "I2C_GEN_CALL",       21, 1, "", NULL },
    /* 0    RWC NA  Generate interrupt for any exception that the HDMI I2C control logic is not able to handle and demands SW intervention. SW is expected to access the I2C registers and may be required to clear/reset the I2C unit */
    { "SLOW_CLK_CNDTN",     20, 1, "", NULL },
    /* 0    RWC NA  Generation of interrupt when incoming pixel clock drops below 25 MHz */
    { "5V_LOST",            19, 1, "", NULL },
    /* 0    RWC NA  Indicates that 5V was lost - informs SW that a Source is no longer connected to the system. */
    { "I2C_EDID_BUF_EMPTY", 18, 1, "", NULL },
    /* 0    RWC NA  Indicates that the 64-byte EDID buffer within the HDMI unit is almost empty and stop condition is not seen on the I2C bus. */
    { "I2C_EDID_STOP",      17, 1, "", NULL },
    /* 0    RWC NA  Indicates that the I2C unit has received a stop sequence and doesn't need to send any more EDID data. */
    { "I2C_EDID_START",     16, 1, "", NULL },
    /* 0    RWC NA  Indicates that the I2C unit has received a valid start sequence and is holding the I2C bus (waiting to transmit EDID data). SW needs to fetch EDID data and write to HEDR */
    { "PIX_RPT_ERR",        15, 1, "", NULL },
    /* 0    RWC NA  Generation of error when unit detects pixel repetition error. Error arises when pixel repetition counter has not reached zero at end of line. */
    { "MPG_INFRM_CHNG",     14, 1, "", NULL },
    /* 0    RWC NA  Generation of interrupt when MPEG InfoFrame comparison indicates a different packet */
    { "SPD_INFRM_CHNG",     13, 1, "", NULL },
    /* 0    RWC NA  Generation of interrupt when Source Product Descriptor InfoFrame comparison indicates a different packet */
    { "VNDSP_INFRM_CHNG",   12, 1, "", NULL },
    /* 0    RWC NA  Generation of interrupt when Vendor Specific InfoFrame comparison indicates a different packet */
    { "AVI_INFRM_CHNG",     11, 1, "", NULL },
    /* 0    RWC NA  Generation of interrupt when AVI InfoFrame comparison indicates a different packet */
    { "AUD_INFRM_CHNG",     10, 1, "", NULL },
    /* 0    RWC NA  Generation of interrupt when Audio InfoFrame comparison indicates a different packet */
    { "CTS_CNTR_ZERO",      9,  1, "", NULL },
    /* 0    RWC NA  CTS Counter reached Zero */
    { "SYNC_CNTR_DN0",      8,  1, "", NULL },
    /* RWC  NA  Indication to SW that the video format counters have updated both the line length (pix_cnt) and line count (hsync count) registers. */
    { "BCH_ERR",            7,  1, "", NULL },
    /* 0    RWC NA  BCH Error detected. Only uncorrectable errors are reported. */
    { "CLR_AVMUTE",         6,  1, "", NULL },
    /* 0    RWC NA  Generation of interrupt on clear AVMUTE condition */
    { "SET_AVMUTE",         5,  1, "", NULL },
    /* 0    RWC NA  Generation of interrupt on set AVMUTE condition */
    { "DECODE_ERR",         4,  1, "", NULL },
    /* 0    RWC NA  Generation of interrupt on Decoding errors */
    { "PLL_LOCK",           3,  1, "", NULL },
    /* 0    RV  NA  Generation of interrupt on when PLL in Phy achieves lock */
    { "CH_ALIGN_ERR",       2,  1, "", NULL },
    /* 0    RWC NA  Error in inter-channel alignment. Means that the data across the three channels is not aligned. Set by parser.  */
    { "PLL_LOCK_LOST",      1,  1, "", NULL },
    /* 0    RWC NA  Generation of interrupt when PLL looses lock. */
    { "5V_DTCT",            0,  1, "", NULL },
    /* 0    RWC NA  Generation of interrupt when HDMI detects 5V after initial reset. This is raised even if a High level is detected on the 5V signal - not just a rising edge of the 5V signal. */

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Register defines pulled from HDMI EAS 02nov2005 */
static const struct EAS_RegBits g_csr_vr_hdmi_ISRH[] = 
{
    // 31:13        000000H RV  RV  Reserved
    { "Reserved_31_13",         13, 19, "", NULL },

    //12        0   RW  RWC Slave Address Detected:
    //              0: No slave address detected. 
    //              1: I2C unit detected a 71bit address that matches the general call address or ISAR[13:7]. An interrupt is signalled when enabled in the ICR.  This is for the segment pointer slave address detected.
    { "SegPtr_SlaveAddrDet",    12, 1, "", NULL },

    // 11       0   RW  RWC Slave Address Detected: 
    //          0: No slave address detected. 
    //          1: I2C unit detected a 7-bit address that matches the general call address or ISAR[6:0]. An interrupt is signalled when enabled in the ICR.  This is for the EDID slave address detected
    { "EDID_SlaveAddrDet",      11, 1, "", NULL },

    // 10       0   RW  RWC Bus Error Detected: 
    //          0: No error detected. 
    //          1: The I2C unit sets this bit when it detects one of the following error conditions: As a master transmitter, no Ack was detected on the interface after a byte was sent. As a slave receiver, the I2C unit generates a Nack pulse. When an error occurs, I2C bus transactions continue. Software must guarantee that misplaced START and STOP conditions do not occur. 
    { "BusErrDet",              10, 1, "", NULL },

    // 09       0   RW  RWC Slave Address Detected: 
    //          0: No slave address detected. 
    //          1: I2C unit detected a 7-bit address that matches the HDCP address. An interrupt is signalled when enabled in the ICR.  This is for the HDCP slave address detected. NOTE: This address is not set via the ISAR.
    { "HDCP_SlaveAddrDet",      9,  1, "", NULL },

    // 08       0   RW  RWC General Call Address Detected:
    //          0: No general call address received. 
    //          1: I2C unit received a general call address. 
    { "GeneralCall",            8,  1, "", NULL },

    // 07       0   RW  RWC IDBR Receive Full:
    //          0: The IDBR has not received a new data byte or the I2C unit is idle. 
    //          1: The IDBR register received a new data byte from the I2C bus. An interrupt is signalled when enabled in the ICR. 
    { "IDBR_ReceiveFull",       7,  1, "", NULL },

    // 06       0   RW  RWC IDBR Transmit Empty: 
    //          0: The data byte is still being transmitted. 
    //          1: The I2C unit has finished transmitting a data byte on the I2C bus. An interrupt is signalled when enabled in the ICR.
    { "IDBR_XMitEmpty",         6,  1, "", NULL },

    // 05       0   RW  RWC Arbitration Loss Detected: used during multi-master operation. Cleared when arbitration is won or never took place. Set when the I2C unit loses arbitration. 
    { "ArbLossDet",             5,  1, "", NULL },

    // 04       0   RW  RWC Slave STOP Detected: 
    //          0: No STOP detected. 
    //          1: Set when the I2C unit detects a STOP while in slave-receive or slave-transmit mode. 
    { "SlaveSTOPDet",           4,  1, "", NULL },

    // 03       0   RW  RO  I2C Bus Busy: I2C bus is idle or the I2C unit is using the bus (i.e., unit busy). Set when the I2C bus is busy but the Vermilion Range's I2C unit is not involved in the transaction. 
    { "I2CBusBusy",             3,  1, "", NULL },

    // 02       0   RW  RO  Unit Busy: I2C unit not busy. Set when the Vermilion Range's I2C unit is busy. This is defined as the time between the first START and STOP. 
    { "I2CUnitBusy",            2,  1, "", NULL },

    // 01       0   RW  RO  Ack/Nack Status: The I2C unit received or sent an Ack on the bus. 
    //          0: The I2C unit received or sent an Ack on the bus. 
    //          1: The I2C unit received or sent a Nack. 
    //          This bit is used in slave transmit mode to determine when the byte transferred is the last one. This bit is updated after each byte and Ack/Nack information is received.
    { "AckIODet",               1,  1, "", NULL },

    // 00       0   RW  RO  Read/Write Mode: 
    //          0: The I2C unit is in master-transmit or slave-receive mode. 
    //          1: reserved. This is the R/W# bit of the slave address. It is automatically cleared by hardware after a stop state.
    { "ReadWriteMode",          0,  1, "", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

// Bits	Symbol	Default	Access	Description
static const struct EAS_RegBits g_csr_vr_hdmi_PWR_CTRL[] = 
{
    { "reserved",   3, 29,  "0	RW	PLL PFD chopper: analog delay timer enable. Default value is 0", NULL },
    { "pwrhdcp",    2,  1,  "1	RW	Gate HDCP clock", NULL },
    { "pwraudio",   1,  1,  "1	RW	Gate Audio clock", NULL },
    { "pwrhdmi",    0,  1,  "1	RW	Gate HDMI Core clock", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

// Bits	Symbol	Default	Access	Description
static const struct EAS_RegBits g_csr_vr_hdmi_PHY_CFG0[] = 
{
    { "hplldiv",    0,  6,  "PLL 1/N dividers setting. It is a n+2 divider. Bit5 of divider setting. Default value is 3", NULL },
    { "chpenb",     6,  1,  "0	RW	PLL PFD chopper: analog delay timer enable. Default value is 0", NULL },
    { "chpdlyb",    7,  1,  "0	RW	PLL chopper enable. Default value is 0", NULL },
    { "vstart",     8,  2,  "0	RW	PLL startup voltage select bits. Default value is 0", NULL },
    { "pfdtime",    10, 2,  "0	RW	PLL PFD chopper timer delay control bits. Default value is 0", NULL },
    { "yankvsel",   12, 2,  "0	RW	PLL yank voltage select bits. Default value is 0", NULL },
    { "Fbwen",      14, 1,  "1	RW	PLL fixed bandwidth mode enable. Default value is 1", NULL },
    { "filtresen",  15, 1,  "0	RW	PLL fixed bandwidth mode filter resistor enable. Default value is 0", NULL },
    { "loopresen",  16, 1,  "0	RW	PLL fixed bandwidth mode loop resistor enable. Default value is 0", NULL },
    { "iddqen",     17, 1,  "0	RW	PLL 3.3V IO buffer power saving iddq enable", NULL },
    { "mon1en",     18, 1,  "1	RW	PLL monitor #1 output enable. Default value is 1", NULL },
    { "mon2en",     19, 1,  "1	RW	PLL monitor #2 output enable. Default value is 1", NULL },
    { "prephenb",   20, 1,  "0	RW	Peripheral clock disable. Default value is 0", NULL },
    { "Pllenb",     21, 1,  "0	RW	PLL startup signal. Default value is 0", NULL },
    { "corefbselb", 22, 1,  "1	RW	PLL normal operation mode enable. Default value is 1", NULL },
    { "pllbypass",  23, 1,  "0	RW	PLL bypass mode enable. Default value is 0", NULL },
    { "wkpulldnen", 24, 1,  "0	RW	PLL 3.3V IO buffer weak pulldown enable", NULL },
    { "wkpullupen", 25, 1,  "0	RW	PLL 3.3V IO buffer weak pullup enable", NULL },
    { "fixedpulse", 26, 1,  "0	RW	PLL fixed pulse enable. Default value is 0", NULL },
    { "fbclkdisable",27, 1,  "0	RW	PLL feedback disable for yank testability. Default value is 0", NULL },
    { "Pwrdn",      28, 1,  "0	RW	Power down the PLL and switch to bypass mode. Default value is 0", NULL },
    { "gen2enb",    29, 1,  "1	RW	Gen 2 PLL Mode disable. Default value is 1 ", NULL },
    { "Reserved",   30, 2,  "0	RW	Reserved for future use", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_vr_hdmi_PHY_CFG1[] = 
{
    { "phsel",  0, 10,  "0]	0	RW	programmable charge pump current control bits. Default value is 2", NULL },
    { "mon1sel0",   10, 1,  "1	RW	Bit 0 of monitor #1 select bits. Default value is 1", NULL },
    { "mon1sel1",   11, 1,  "0	RW	Bit 1 of monitor #1 select bits. Default value is 0", NULL },
    { "mon1sel2",   12, 1,  "1	RW	Bit 2 of monitor #1 select bits. Default value is 1", NULL },
    { "mon1sel3",   13, 1,  "0	RW	Bit 3 of monitor #1 select bits. Default value is 0", NULL },
    { "mon2sel0",   14, 1,  "0	RW	Bit 0 of monitor #2 select bits. Default value is 0", NULL },
    { "mon2sel1",   15, 1,  "1	RW	Bit 1 of monitor #2 select bits. Default value is 1", NULL },
    { "mon2sel2",   16, 1,  "0	RW	Bit 2 of monitor #2 select bits. Default value is 0", NULL },
    { "mon2sel3",   17, 1,  "1	RW	Bit 3 of monitor #2 select bits. Default value is 1", NULL },
    { "vcosel0",    18, 1,  "1	RW	Bit 0 of VCO buffer current source control bits. Default value is 1", NULL },
    { "vcosel1",    19, 1,  "1	RW	Bit 1 of VCO buffer current source control bits. Default value is 1", NULL },
    { "vcosel2",    20, 1,  "0	RW	Bit 2 of VCO buffer current source control bits. Default value is 0", NULL },
    { "minushalf1", 21, 1,  "0	RW	Monitor #1 minushalf enable. Default value is 0", NULL },
    { "plushalf1",  22, 1,  "0	RW	Monitor #1 plushalf enable. Default value is 0", NULL },
    { "minushalf2", 23, 1,  "0	RW	Monitor #2 minushalf enable. Default value is 0", NULL },
    { "plushalf2",  24, 1,  "0	RW	Monitor #2 plushalf enable. Default value is 0", NULL },
    { "Reserved",   25, 7,  "0	RW	Reserved for future use", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

				
static const struct EAS_RegBits g_csr_vr_hdmi_PHY_CFG2[] = 
{
    { "RCVEN",          0,  1,  "1	RW	Receiver Enable. This bit (=1) will enable the high speed receiver to amplify the low swing differential input. Default should be 1. This bit is currently unused in VR.", NULL },
    { "NBIASBYPCNTL",   1,  1,  "0	RW	Nbias bypass control. Default should be 0.", NULL },
    { "PBIASBYPCNTL",   2,  1,  "0	RW	Pbias bypass control. Default should be 0.", NULL },
    { "VREFBYPCNTL",    3,  1,  "0	RW	Bypass of tunable bias voltage for nbias and pbias. Default value is '0.", NULL },
    { "TERMEN_GND",     4,  1,  "0	RW	Termination Enable. This bit (=1) will enable the termination to VSS. Default value is 0.", NULL },
    { "RC",             5, 20,  "RW	Bit0 of 20 bit thermometer code used for calibration. Default value is 0", NULL },
    { "TERMEN_PWR",     25, 1,  "0	RW	Termination Enable. This bit (=0) will enable the termination to VCC. Default value is 0.", NULL },
    { "RCB_0_4",        26, 5,  "0	RW	Bit0 of 20 bit thermometer code used for calibration. Default value is 0", NULL },
    { "RCOMP_BYPASS",   31, 1,  "0	RW	Rcomp Bypss", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};
				
static const struct EAS_RegBits g_csr_vr_hdmi_PHY_CFG3[] = 
{
    { "RCB_5_20",   0,  15, "RW	Bit5-20 bit thermometer code used for calibration. Default value is 0", NULL },
    { "FTSvalid",   15, 1,  "1	RW	Enables programming gain of prop filter (=1). Default value is 1.", NULL },
    { "FTS0",       16, 1,  "1	RW	Bit0 of 3 bit threshold value. Default value is 1.", NULL },
    { "FTS1",       17, 1,  "1	RW	Bit1 of 3 bit threshold value. Default value is 1.", NULL },
    { "FTS2",       18, 1,  "1	RW	Bit2 of 3 bit threshold value. Default value is 1.", NULL },
    { "ENRO1",      19, 1,  "1	RW	Programmable blanking of advance/retard signals to PI/DAC. Default is 1.", NULL },
    { "ENRO2",      20, 1,  "0	RW	Programmable blanking of advance/retard signals to PI/DAC. Default is 0.", NULL },
    { "ENRO3",      21, 1,  "0	RW	Programmable blanking of advance/retard signals to PI/DAC. Default is 0.", NULL },
    { "Ocfg5step",  22, 1,  "0	RW	Enable DAC 5-step. Default is 0.", NULL },
    { "Ocfgovrden", 23, 1,  "0	RW	DAC override enable. Default is 0.", NULL },
    { "Ocfgquad0",  24, 1,  "0	RW	Quadsel0 override. Default is 0.", NULL },
    { "Ocfgquad1",  25, 1,  "0	RW	Quadsel1 override. Default is 0.", NULL },
    { "Ocfgph0",    26, 1,  "0	RW	Dac0 override. Default is 0.", NULL },
    { "Ocfgph1",    27, 1,  "0	RW	Dac1 override. Default is 0.", NULL },
    { "Ocfgph2",    28, 1,  "0	RW	Dac2 override. Default is 0.", NULL },
    { "Ocfgph3",    29, 1,  "0	RW	Dac3 override. Default is 0.", NULL },
    { "Ocfgph4",    30, 1,  "0	RW	Dac4 override. Default is 0.", NULL },
    { "Ocfgph5",    31, 1,  "0	RW	Dac5 override. Default is 0.", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_vr_hdmi_PHY_CFG4[] = 
{
    { "Ocfgph6",    0,  1,  "0	RW	Dac6 override. Default is 0.", NULL },
    { "Ocfgph7",    1,  1,  "0	RW	Dac7 override. Default is 0.", NULL },
    { "Ocfgph8",    2,  1,  "0	RW	Dac8 override. Default is 0.", NULL },
    { "Ocfgph9",    3,  1,  "0	RW	Dac9 override. Default is 0.", NULL },
    { "Ocfgph10",   4,  1,  "0	RW	Dac10 override. Default is 0.", NULL },
    { "Ocfgph11",   5,  1,  "0	RW	Dac11 override. Default is 0.", NULL },
    { "Ocfgph12",   6,  1,  "0	RW	Dac12 override. Default is 0.", NULL },
    { "Ocfgph13",   7,  1,  "0	RW	Dac13 override. Default is 0.", NULL },
    { "Ocfgph14",   8,  1,  "0	RW	Dac14 override. Default is 0.", NULL },
    { "Pianclkbufen",   9,  1,  "1	RW	PI clock output enable. Default is 1.", NULL },
    { "pianpclk1obssel",    10, 1,  "0	RW	Signal to select monitor port output. Default is 0.", NULL },
    { "pianpclk2obssel",    11, 1,  "0	RW	Signal to select monitor port output. Default is 0.", NULL },
    { "obsven",     12, 1,  "0	RW	Enable monitor port output. Default is 0.", NULL },
    { "plushalf",   13, 1,  "0	RW	Signal to select resistor strength for driver amplifier of monitor port. Default is 0.", NULL },
    { "minushalf",  14, 1,  "0	RW	Signal to select resistor strength for driver amplifier of monitor port. Default is 0.", NULL },
    { "cslsel",     15, 1,  "0	RW	Selects either the custom or synthesized output of the channel sync. '0 selects custom, '1 selects synthesized. Default value is '0.", NULL },
    { "nstr",       16, 4,  "RW	Strength of 3.3V IO pull down. Default is 3", NULL },
    { "pstr",       20, 4,  "RW	Strength of 3.3V IO pull up. Default is 3", NULL },
    { "clksel",     24, 2,  "0	RW	Signal to select clock monitor port output among channels.  Default is 0", NULL },
    { "Datasel",    26, 2,  "0	RW	Signal to select data monitor port output among channels.  Default is 0", NULL },
    { "Prd12sel",   28, 1,  "0	RW	Signal to select data monitor port output in channel.  Default is 0", NULL },
    { "Reserved",   29, 3,  "0	RW	Reserved for future use.", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_vr_hdmi_PHY_CTRL[] = 
{
    { "RSVD",       2,  30,  "0	RV	NA	Reserved", NULL },
    { "ASRT_HPD",   1,  1,  "0	RW	NA	EDID Ready for Read; implies Phy can raise HPD; Every time VR's EDID changes, SW has to clear this bit for 100 msec. HDMI spec requires HPD to be deasserted for 100 msec. NOTE: SW cannot assert and then de-assert HPD without giving a reset to the unit.", NULL },
    { "TMDS_CLK_EN",0,  1,  "0	RW	NA	This bit ensures that the PLL output clock is not gated indefinitely (possible if the Lock signal from PLL is never generated). SW should set this bit 100 ms after receiving the 5V detected interrupt.", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Copied from HDMI EAS 13oct2005 by Pat Brouillette */
static const struct EAS_Register g_csr_vr_hdmi[] =
{
    { "HGCR",                       0x0, g_csr_vr_hdmi_HGCR, "HDMI General Control register.    00H", NULL },
    { "HICR",                       0x4, NULL, "HDMI Interrupt Control Register 00H", NULL },
    { "HGSR",                       0x8, g_csr_vr_hdmi_HGSR, "HDMI Status Register  00H - see note at bottom of table", NULL },
    { "HISR",                       0xC, g_csr_vr_hdmi_HISR, "HDMI Interrupt Status register    00H", NULL },
    { "HDCP_BKSV0",             0x10, NULL, "Bksv value's Byte 0 (LSB)  00H", NULL },
    { "HDCP_BKSV1",             0x14, NULL, "Bksv value's Byte 1    00H", NULL },
    { "HDCP_BKSV2",             0x18, NULL, "Bksv value's Byte 2    00H", NULL },
    { "HDCP_BKSV3",             0x1C, NULL, "Bksv value's Byte 3    00H", NULL },
    { "HDCP_BKSV4",             0x20, NULL, "Bksv value's Byte 4 (MSB)  00H", NULL },
    { "HDCP_RI0",                   0x24, NULL, "Byte 0 (LSB) is Ri' or Ro' 00H", NULL },
    { "HDCP_RI1",                   0x28, NULL, "Byte 1 (MSB) is Ri' or Ro' 00H", NULL },
    { "HDCP_PJ",                    0x2C, NULL, "LSB 1 Byte is Pj'  00H", NULL },
    { "HDCP_AKSV0",             0x30, NULL, "Aksv value's Byte 0 LSB    00H", NULL },
    { "HDCP_AKSV1",             0x34, NULL, "Aksv value's Byte 1    00H", NULL },
    { "HDCP_AKSV2",             0x38, NULL, "Aksv value's Byte 2    00H", NULL },
    { "HDCP_AKSV3",             0x3C, NULL, "Aksv value's Byte 3    00H", NULL },
    { "HDCP_AKSV4",             0x40, NULL, "Aksv value's Byte 4 MSB    00H", NULL },
    { "HDCP_AINFO",             0x44, NULL, "Ainfo register. LSB 1 Byte Written by Source   00H", NULL },
    { "HDCP_AN0",                   0x48, NULL, "An written by Source. Byte 0 LSB   00H", NULL },
    { "HDCP_AN1",                   0x4C, NULL, "An written by Source. Byte 1   00H", NULL },
    { "HDCP_AN2",                   0x50, NULL, "An written by Source. Byte 2   00H", NULL },
    { "HDCP_AN3",                   0x54, NULL, "An written by Source. Byte 3   00H", NULL },
    { "HDCP_AN4",                   0x58, NULL, "An written by Source. Byte 4   00H", NULL },
    { "HDCP_AN5",                   0x5C, NULL, "An written by Source. Byte 5   00H", NULL },
    { "HDCP_AN6",                   0x60, NULL, "An written by Source. Byte 6   00H", NULL },
    { "HDCP_AN7",                   0x64, NULL, "An written by Source. Byte 7 MSB   00H", NULL },
    { "HDCP_BCAPS",             0x68, NULL, "Bcaps value LSB 1Byte, maintained by Software. Can be Hardwired Also - TBD 00H", NULL },
    { "HDCP_BSTAT0",                0x6C, NULL, "LSB byte 0 is Bstatus register. Managed by SW  00H", NULL },
    { "HDCP_BSTAT1",                0x70, NULL, "MSB byte 1 is Bstatus register.    00H", NULL },
    { "I2C_ICR",                    0x74, NULL, "ICRH)  I2C Control Register -16 bits, used for I2C configuration and control   00H", NULL },
    { "I2C_ISR",                    0x78, g_csr_vr_hdmi_ISRH, "ISRH)    I2C Status Register - 11 bits to indicate the status of the I2C and its interrupt   00H", NULL },
    { "I2C_ISAR",                   0x7C, NULL, "ISARH) I2C Slave Address Register - 14 bits for I2C Slave Addresses    00H", NULL },
    { "I2C_IDBR",                   0x80, NULL, "IDBRH) I2C Data Buffer Register - 8 bits of data buffered from the I2C bus 00H", NULL },
    { "I2C_IBMR",                       0x84, NULL, "IBMRH) I2C Bus Monitor Register - 2 bits which mirror the values of SCL and SDA    00H", NULL },
    { "EDID_DATA",                  0x88, NULL, "HEDR)  EDID data register - 32 bits of EDID data will be written to this register by SW    00H", NULL },
    { "EDID_ADDR",                  0x8C, NULL, "HEAR)  The EDID offset address requested by the Source.    00H", NULL },
    { "PIX_CNT_REG",                0x90, NULL, "Pixel counter (line length) Value  00H", NULL },
    { "HSYNC_CNT_REG",              0x94, NULL, "HSYNC Counter (number of lines) value  00H", NULL },
    { "PIX_CLK_FRQ_REG",            0x98, NULL, "Pixel Clock frequency counter value    00H", NULL },
    { "EVEN_FIELD_THRSH",           0x9C, NULL, "MSB [25:13]: Threshold between VSYNC and HSYNC edges (default 0x64)    LSB[12:0]: Threshold between HSYNC and VSYNC edges (default 0x64)   If the difference lies between the two values, it is considered an even field. C8064H", NULL },
    { "HSCNT_PIX_CNT_VAR_THRSH",   0xA0, NULL, "MSB[31:16]: Threshold value for variation in HSYNC above/below which HSYNC is considered changed    LSB[15:0]: Threshold value for variation in VSYNC above/below which VSYNC is considered changed 00H", NULL },
    { "SLOW_PIX_CLK_THRSH",     0xA4, NULL, "Specifies a Threshold below which Pixel clock would be below 25MHz. HW compares the Pixel clock frequency counter with this when this is a non-zero value 00H", NULL },
    { "PIX_CLK_FRQ_AVG_REG",       0xA8, NULL, "The HDMI_PIX_CLK_FRQ_REG (above) is averaged over the number of cycles of the 90kHz clock, which is programmed in this register.    00H", NULL },
    { "VSIP_WRD0_REG",              0xAC, NULL, "Vendor specific InfoFrame Packet, Word 0   -- see notes at bottom of table--", NULL },
    { "VSIP_WRD1_REG",              0xB0, NULL, "Vendor specific InfoFrame Packet, Word 1   --", NULL },
    { "VSIP_WRD2_REG",              0xB4, NULL, "Vendor specific InfoFrame Packet, Word 2   --", NULL },
    { "VSIP_WRD3_REG",              0xB8, NULL, "Vendor specific InfoFrame Packet, Word 3   --", NULL },
    { "VSIP_WRD4_REG",              0xBC, NULL, "Vendor specific InfoFrame Packet, Word 4   --", NULL },
    { "VSIP_WRD5_REG",              0xC0, NULL, "Vendor specific InfoFrame Packet, Word 5   --", NULL },
    { "VSIP_WRD6_REG",              0xC4, NULL, "Vendor specific InfoFrame Packet, Word 6   --", NULL },
    { "VSIP_WRD7_REG",              0xC8, NULL, "Vendor specific InfoFrame Packet, Word 7   --", NULL },
    { "VSIP_WRD8_REG",              0xCC, NULL, "Vendor specific InfoFrame Packet, Word 8   --", NULL },
    { "AVI_WRD0_REG",               0xD0, NULL, "AVI InfoFrame Packet, Word 0   --", NULL },
    { "AVI_WRD1_REG",               0xD4, NULL, "AVI InfoFrame Packet, Word 1   --", NULL },
    { "AVI_WRD2_REG",               0xD8, NULL, "AVI InfoFrame Packet, Word 2   --", NULL },
    { "AVI_WRD3_REG",               0xDC, NULL, "AVI InfoFrame Packet, Word 3   --", NULL },
    { "AVI_WRD4_REG",               0xE0, NULL, "AVI InfoFrame Packet, Word 4   --", NULL },
    { "AVI_WRD5_REG",               0xE4, NULL, "AVI InfoFrame Packet, Word 5   --", NULL },
    { "AVI_WRD6_REG",               0xE8, NULL, "AVI InfoFrame Packet, Word 6   --", NULL },
    { "AVI_WRD7_REG",               0xEC, NULL, "AVI InfoFrame Packet, Word 7   --", NULL },
    { "AVI_WRD8_REG",               0xF0, NULL, "AVI InfoFrame Packet, Word 8   --", NULL },
    { "SPD_WRD0_REG",               0xF4, NULL, "SPD InfoFrame Packet, Word 0   --", NULL },
    { "SPD_WRD1_REG",               0xF8, NULL, "SPD InfoFrame Packet, Word 1   --", NULL },
    { "SPD_WRD2_REG",               0xFC, NULL, "SPD InfoFrame Packet, Word 2   --", NULL },
    { "SPD_WRD3_REG",               0x100, NULL, "SPD InfoFrame Packet, Word 3  --", NULL },
    { "SPD_WRD4_REG",               0x104, NULL, "SPD InfoFrame Packet, Word 4  --", NULL },
    { "SPD_WRD5_REG",               0x108, NULL, "SPD InfoFrame Packet, Word 5  --", NULL },
    { "SPD_WRD6_REG",               0x10C, NULL, "SPD InfoFrame Packet, Word 6  --", NULL },
    { "SPD_WRD7_REG",               0x110, NULL, "SPD InfoFrame Packet, Word 7  --", NULL },
    { "SPD_WRD8_REG",               0x114, NULL, "SPD InfoFrame Packet, Word 8  --", NULL },
    { "MPG_WRD0_REG",               0x118, NULL, "MPG InfoFrame Packet, Word 0  --", NULL },
    { "MPG_WRD1_REG",               0x11C, NULL, "MPG InfoFrame Packet, Word 1  --", NULL },
    { "MPG_WRD2_REG",               0x120, NULL, "MPG InfoFrame Packet, Word 2  --", NULL },
    { "MPG_WRD3_REG",               0x124, NULL, "MPG InfoFrame Packet, Word 3  --", NULL },
    { "MPG_WRD4_REG",               0x128, NULL, "MPG InfoFrame Packet, Word 4  --", NULL },
    { "MPG_WRD5_REG",               0x12C, NULL, "MPG InfoFrame Packet, Word 5  --", NULL },
    { "MPG_WRD6_REG",               0x130, NULL, "MPG InfoFrame Packet, Word 6  --", NULL },
    { "MPG_WRD7_REG",               0x134, NULL, "MPG InfoFrame Packet, Word 7  --", NULL },
    { "MPG_WRD8_REG",               0x138, NULL, "MPG InfoFrame Packet, Word 8  --", NULL },
    { "HDCP_KEY0_REG0",         0x13C, NULL, "HDCP KEY 0 Lower 32 bits  00H", NULL },
    { "HDCP_KEY0_REG1",         0x140, NULL, "HDCP KEY 0 Upper 24 bits  00H", NULL },
    { "HDCP_KEY1_REG0",         0x144, NULL, "HDCP KEY 1 Lower 32 bits  00H", NULL },
    { "HDCP_KEY1_REG1",         0x148, NULL, "HDCP KEY 1 Upper 24 bits  00H", NULL },
    { "HDCP_KEY2_REG0",         0x14C, NULL, "HDCP KEY 2 Lower 32 bits  00H", NULL },
    { "HDCP_KEY2_REG1",         0x150, NULL, "HDCP KEY 2 Upper 24 bits  00H", NULL },
    { "HDCP_KEY3_REG0",         0x154, NULL, "HDCP KEY 3 Lower 32 bits  00H", NULL },
    { "HDCP_KEY3_REG1",         0x158, NULL, "HDCP KEY 3 Upper 24 bits  00H", NULL },
    { "HDCP_KEY4_REG0",         0x15C, NULL, "HDCP KEY 4 Lower 32 bits  00H", NULL },
    { "HDCP_KEY4_REG1",         0x160, NULL, "HDCP KEY 4 Upper 24 bits  00H", NULL },
    { "HDCP_KEY5_REG0",         0x164, NULL, "HDCP KEY 5 Lower 32 bits  00H", NULL },
    { "HDCP_KEY5_REG1",         0x168, NULL, "HDCP KEY 5 Upper 24 bits  00H", NULL },
    { "HDCP_KEY6_REG0",         0x16C, NULL, "HDCP KEY 6 Lower 32 bits  00H", NULL },
    { "HDCP_KEY6_REG1",         0x170, NULL, "HDCP KEY 6 Upper 24 bits  00H", NULL },
    { "HDCP_KEY7_REG0",         0x174, NULL, "HDCP KEY 7 Lower 32 bits  00H", NULL },
    { "HDCP_KEY7_REG1",         0x178, NULL, "HDCP KEY 7 Upper 24 bits  00H", NULL },
    { "HDCP_KEY8_REG0",         0x17C, NULL, "HDCP KEY 8 Lower 32 bits  00H", NULL },
    { "HDCP_KEY8_REG1",         0x180, NULL, "HDCP KEY 8 Upper 24 bits  00H", NULL },
    { "HDCP_KEY9_REG0",         0x184, NULL, "HDCP KEY 9 Lower 32 bits  00H", NULL },
    { "HDCP_KEY9_REG1",         0x188, NULL, "HDCP KEY 9 Upper 24 bits  00H", NULL },
    { "HDCP_KEY10_REG0",            0x18C, NULL, "HDCP KEY 10 Lower 32 bits 00H", NULL },
    { "HDCP_KEY10_REG1",            0x190, NULL, "HDCP KEY 10 Upper 24 bits 00H", NULL },
    { "HDCP_KEY11_REG0",            0x194, NULL, "HDCP KEY 11 Lower 32 bits 00H", NULL },
    { "HDCP_KEY11_REG1",            0x198, NULL, "HDCP KEY 11 Upper 24 bits 00H", NULL },
    { "HDCP_KEY12_REG0",            0x19C, NULL, "HDCP KEY 12 Lower 32 bits 00H", NULL },
    { "HDCP_KEY12_REG1",            0x1A0, NULL, "HDCP KEY 12 Upper 24 bits 00H", NULL },
    { "HDCP_KEY13_REG0",            0x1A4, NULL, "HDCP KEY 13 Lower 32 bits 00H", NULL },
    { "HDCP_KEY13_REG1",            0x1A8, NULL, "HDCP KEY 13 Upper 24 bits 00H", NULL },
    { "HDCP_KEY14_REG0",            0x1AC, NULL, "HDCP KEY 14 Lower 32 bits 00H", NULL },
    { "HDCP_KEY14_REG1",            0x1B0, NULL, "HDCP KEY 14 Upper 24 bits 00H", NULL },
    { "HDCP_KEY15_REG0",            0x1B4, NULL, "HDCP KEY 15 Lower 32 bits 00H", NULL },
    { "HDCP_KEY15_REG1",            0x1B8, NULL, "HDCP KEY 15 Upper 24 bits 00H", NULL },
    { "HDCP_KEY16_REG0",            0x1BC, NULL, "HDCP KEY 16 Lower 32 bits 00H", NULL },
    { "HDCP_KEY16_REG1",            0x1C0, NULL, "HDCP KEY 16 Upper 24 bits 00H", NULL },
    { "HDCP_KEY17_REG0",            0x1C4, NULL, "HDCP KEY 17 Lower 32 bits 00H", NULL },
    { "HDCP_KEY17_REG1",            0x1C8, NULL, "HDCP KEY 17 Upper 24 bits 00H", NULL },
    { "HDCP_KEY18_REG0",            0x1CC, NULL, "HDCP KEY 18 Lower 32 bits 00H", NULL },
    { "HDCP_KEY18_REG1",            0x1D0, NULL, "HDCP KEY 18 Upper 24 bits 00H", NULL },
    { "HDCP_KEY19_REG0",            0x1D4, NULL, "HDCP KEY 19 Lower 32 bits 00H", NULL },
    { "HDCP_KEY19_REG1",            0x1D8, NULL, "HDCP KEY 19 Upper 24 bits 00H", NULL },
    { "HDCP_KEY20_REG0",            0x1DC, NULL, "HDCP KEY 20 Lower 32 bits 00H", NULL },
    { "HDCP_KEY20_REG1",            0x1E0, NULL, "HDCP KEY 20 Upper 24 bits 00H", NULL },
    { "HDCP_KEY21_REG0",            0x1E4, NULL, "HDCP KEY 21 Lower 32 bits 00H", NULL },
    { "HDCP_KEY21_REG1",            0x1E8, NULL, "HDCP KEY 21 Upper 24 bits 00H", NULL },
    { "HDCP_KEY22_REG0",            0x1EC, NULL, "HDCP KEY 22 Lower 32 bits 00H", NULL },
    { "HDCP_KEY22_REG1",            0x1F0, NULL, "HDCP KEY 22 Upper 24 bits 00H", NULL },
    { "HDCP_KEY23_REG0",            0x1F4, NULL, "HDCP KEY 23 Lower 32 bits 00H", NULL },
    { "HDCP_KEY23_REG1",            0x1F8, NULL, "HDCP KEY 23 Upper 24 bits 00H", NULL },
    { "HDCP_KEY24_REG0",            0x1FC, NULL, "HDCP KEY 24 Lower 32 bits 00H", NULL },
    { "HDCP_KEY24_REG1",            0x200, NULL, "HDCP KEY 24 Upper 24 bits 00H", NULL },
    { "HDCP_KEY25_REG0",            0x204, NULL, "HDCP KEY 25 Lower 32 bits 00H", NULL },
    { "HDCP_KEY25_REG1",            0x208, NULL, "HDCP KEY 25 Upper 24 bits 00H", NULL },
    { "HDCP_KEY26_REG0",            0x20C, NULL, "HDCP KEY 26 Lower 32 bits 00H", NULL },
    { "HDCP_KEY26_REG1",            0x210, NULL, "HDCP KEY 26 Upper 24 bits 00H", NULL },
    { "HDCP_KEY27_REG0",            0x214, NULL, "HDCP KEY 27 Lower 32 bits 00H", NULL },
    { "HDCP_KEY27_REG1",            0x218, NULL, "HDCP KEY 27 Upper 24 bits 00H", NULL },
    { "HDCP_KEY28_REG0",            0x21C, NULL, "HDCP KEY 28 Lower 32 bits 00H", NULL },
    { "HDCP_KEY28_REG1",            0x220, NULL, "HDCP KEY 28 Upper 24 bits 00H", NULL },
    { "HDCP_KEY29_REG0",            0x224, NULL, "HDCP KEY 29 Lower 32 bits 00H", NULL },
    { "HDCP_KEY29_REG1",            0x228, NULL, "HDCP KEY 29 Upper 24 bits 00H", NULL },
    { "HDCP_KEY30_REG0",            0x22C, NULL, "HDCP KEY 30 Lower 32 bits 00H", NULL },
    { "HDCP_KEY30_REG1",            0x230, NULL, "HDCP KEY 30 Upper 24 bits 00H", NULL },
    { "HDCP_KEY31_REG0",            0x234, NULL, "HDCP KEY 31 Lower 32 bits 00H", NULL },
    { "HDCP_KEY31_REG1",            0x238, NULL, "HDCP KEY 31 Upper 24 bits 00H", NULL },
    { "HDCP_KEY32_REG0",            0x23C, NULL, "HDCP KEY 32 Lower 32 bits 00H", NULL },
    { "HDCP_KEY32_REG1",            0x240, NULL, "HDCP KEY 32 Upper 24 bits 00H", NULL },
    { "HDCP_KEY33_REG0",            0x244, NULL, "HDCP KEY 33 Lower 32 bits 00H", NULL },
    { "HDCP_KEY33_REG1",            0x248, NULL, "HDCP KEY 33 Upper 24 bits 00H", NULL },
    { "HDCP_KEY34_REG0",            0x24C, NULL, "HDCP KEY 34 Lower 32 bits 00H", NULL },
    { "HDCP_KEY34_REG1",            0x250, NULL, "HDCP KEY 34 Upper 24 bits 00H", NULL },
    { "HDCP_KEY35_REG0",            0x254, NULL, "HDCP KEY 35 Lower 32 bits 00H", NULL },
    { "HDCP_KEY35_REG1",            0x258, NULL, "HDCP KEY 35 Upper 24 bits 00H", NULL },
    { "HDCP_KEY36_REG0",            0x25C, NULL, "HDCP KEY 36 Lower 32 bits 00H", NULL },
    { "HDCP_KEY36_REG1",            0x260, NULL, "HDCP KEY 36 Upper 24 bits 00H", NULL },
    { "HDCP_KEY37_REG0",            0x264, NULL, "HDCP KEY 37 Lower 32 bits 00H", NULL },
    { "HDCP_KEY37_REG1",            0x268, NULL, "HDCP KEY 37 Upper 24 bits 00H", NULL },
    { "HDCP_KEY38_REG0",            0x26C, NULL, "HDCP KEY 38 Lower 32 bits 00H", NULL },
    { "HDCP_KEY38_REG1",            0x270, NULL, "HDCP KEY 38 Upper 24 bits 00H", NULL },
    { "HDCP_KEY39_REG0",            0x274, NULL, "HDCP KEY 39 Lower 32 bits 00H", NULL },
    { "HDCP_KEY39_REG1",            0x278, NULL, "HDCP KEY 39 Upper 24 bits 00H", NULL },
    { "CTS_REG",                   0x27C, NULL, "HDMI CTS register  00H", NULL },
    { "AINFO_LOCAL_REG",           0x280, NULL, "HDMI Ainfo Locally latched value register", NULL },
    { "PWR_CTRL_REG",              0x284, g_csr_vr_hdmi_PWR_CTRL, "HDMI Power Control Register    07H", NULL },
    { "PHY_CFG0_REG",              0x288, g_csr_vr_hdmi_PHY_CFG0, "HDMI Phy Config0 Register  204C4003H", NULL },
    { "PHY_CFG1_REG",              0x28C, g_csr_vr_hdmi_PHY_CFG1, "HDMI Phy Config1 Register  E9402H", NULL },
    { "PHY_CFG2_REG",              0x290, g_csr_vr_hdmi_PHY_CFG2, "HDMI Phy Config2 Register  01H", NULL },
    { "PHY_CFG3_REG",              0x294, g_csr_vr_hdmi_PHY_CFG3, "HDMI Phy Config3 Register  7FFE0H", NULL },
    { "PHY_CFG4_REG",              0x298, g_csr_vr_hdmi_PHY_CFG4, "HDMI Phy Config4 Register  550200H", NULL },
    { "PHY_CTRL_REG",               0x29C, g_csr_vr_hdmi_PHY_CTRL, "HDMI Phy Control Register 00H", NULL },
    { "DEBUG_REG",                  0x2AC, NULL, "HDMI Debug register   00H", NULL },

    { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct SVEN_Module_EventSpecific g_vr_hdmi_specific_events[] =
{
    { "HDCP_ACTIVE",        1,      "HDCP Cipher has become active", NULL },
    { "HDCP_INACTIVE",      2,      "HDCP Cipher has deactivated", NULL },
    { "HSYNC_POL_ERR",      3,      "", NULL },
    { "VSYNC_POL_ERR",      4,      "", NULL },

    { NULL, 0, "", NULL }   /* NULL Terminated */
};

static const struct ModuleReverseDefs g_hdmi_sven_module =
{
    "GEN2_HDMI",
    SVEN_module_GEN2_HDMI,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_vr_hdmi,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "HDMI: HDMI Receiver (GEN2)",
    g_vr_hdmi_specific_events,
    NULL /* extension list */
};
