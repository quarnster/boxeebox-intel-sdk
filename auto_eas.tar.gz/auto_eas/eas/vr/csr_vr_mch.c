/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Simplest Possible example of EAS definition */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
#ifdef SVEN_INTERNAL_BUILD
/* Declare the bit-breakout for the register defined in the EAS_Register defs below.
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MyModule_versions.
 */
static const struct EAS_RegBits g_csr_NOAR1[] =
{
    { "RESERVED_31_25", 25, 7,"",NULL},    /* reserved bits [31..25] in this register */
    { "Partition_Tap2_Enable",  19, 6,"",NULL},    /* Bits [24..19]Sets up the 2nd Unit ID from where the data is routed   */
    { "RESERVED_18",18,1,"",NULL }, /* Bit 18 reserved */
    { "Unit_Noagrpsel2",    13, 5,"",NULL},    /* Bits [17..13] Group Select for the Eight bit bus 2  */
    { "Reserved_12",    12, 1,"",NULL},    /* Bit 12 reserved */
    { "Partition_Tap1_Enable",  6,  6,"",NULL},    /* Bits [6..11]Sets up the 1st Unit ID from where the data is routed   */
    { "Reserved_5", 5,  1,"",NULL},    /* Bit 12 reserved */
    { "Unit_Noagrpsel1",    0,  5,"",NULL},    /* Bits [0..4] Group Select for the Eight bit bus 1 */
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_NOAR2[] =
{
    { "RESERVED_31_25", 25, 7,"",NULL},    /* reserved bits [31..25] in this register */
    { "Partition_Tap4_Enable",  19, 6,"",NULL},    /* Bits [24..19]Sets up the 4th Unit ID from where the data is routed   */
    { "RESERVED_18",18,1,"",NULL }, /* Bit 18 reserved */
    { "Unit_Noagrpsel4",    13, 5,"",NULL},    /* Bits [17..13] Group Select for the Eight bit bus 4 */
    { "Reserved_12",    12, 1,"",NULL},    /* Bit 12 reserved */
    { "Partition_Tap3_Enable",  6,  6,"",NULL},    /* Bits [6..11]Sets up the 3rd Unit ID from where the data is routed   */
    { "Reserved_5", 5,  1,"",NULL},    /* Bit 12 reserved */
    { "Unit_Noagrpsel3",    0,  5,"",NULL},    /* Bits [0..4] Group Select for the Eight bit bus 3 */
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_NOAR3[] =
{
    { "RESERVED_31_29", 29, 3,"",NULL},    /* reserved bits [31..29] in this register */
    { "Partition_Sigsel3",  24, 5,"",NULL},    /* signal select for NOA bit 3. To be used by partition unit to select from <unit>_noabus1, <unit>_noabus2, <unit>_noabus3 and <unit>_noabus4 */
    { "RESERVED_21_23",21,3,"",NULL },  /* Bits 21 to 23 are reserved */
    { "Unit_Noagrpsel2", 16,    5,"",NULL},     /* signal select for NOA bit 2. To be used by partition unit to select from <unit>_noabus1, <unit>_noabus2, <unit>_noabus3 and <unit>_noabus4 */
    { "Reserved_12",    13, 3,"",NULL},    /* Bit [13...15] are reserved */
    { "Partition_Tap1_Enable",  8,  5,"",NULL},    /* signal select for NOA bit 1. To be used by partition unit to select from <unit>_noabus1, <unit>_noabus2, <unit>_noabus3 and <unit>_noabus4 */
    { "Reserved_5", 5,  3,"",NULL},    /* Bits [5...7] are reserved */
    { "Unit_Noagrpsel1",    0,  5,"",NULL},    /* signal select for NOA bit 1. To be used by partition unit to select from <unit>_noabus1, <unit>_noabus2, <unit>_noabus3 and <unit>_noabus4 */
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};



static const struct EAS_RegBits g_csr_NOAR4[] =
{
    { "RESERVED_31_29", 29, 3,"",NULL},    /* reserved bits [31..29] in this register */
    { "Partition_Sigsel3",  24, 5,"",NULL},    /* signal select for NOA bit 7. To be used by partition unit to select from <unit>_noabus1, <unit>_noabus2, <unit>_noabus3 and <unit>_noabus4 */
    { "RESERVED_21_23",21,3,"",NULL },  /* Bits 21 to 23 are reserved */
    { "Unit_Noagrpsel2", 16,    5,"",NULL},     /* signal select for NOA bit 6. To be used by partition unit to select from <unit>_noabus1, <unit>_noabus2, <unit>_noabus3 and <unit>_noabus4 */
    { "Reserved_12",    13, 3,"",NULL},    /* Bit [13...15] are reserved */
    { "Partition_Tap1_Enable",  8,  5,"",NULL},    /* signal select for NOA bit 5. To be used by partition unit to select from <unit>_noabus1, <unit>_noabus2, <unit>_noabus3 and <unit>_noabus4 */
    { "Reserved_5", 5,  3,"",NULL},    /* Bits [5...7] are reserved */
    { "Unit_Noagrpsel1",    0,  5,"",NULL},    /* signal select for NOA bit 4. To be used by partition unit to select from <unit>_noabus1, <unit>_noabus2, <unit>_noabus3 and <unit>_noabus4 */
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};



static const struct EAS_RegBits g_csr_NOAR5[] =
{
    { "Partition_ClkSel7",  28, 4,"",NULL},    /* Partition Clock Selection 7 */
    { "Partition_ClkSel6",  24, 4,"",NULL},    /* Partition Clock Selection 6 */
    { "Partition_ClkSel5",  20, 4,"",NULL},    /* Partition Clock Selection 5 */
    { "Partition_ClkSel4",  16, 4,"",NULL},    /* Partition Clock Selection 4 */
    { "Partition_ClkSel3",  12, 4,"",NULL},    /* Partition Clock Selection 3 */
    { "Partition_ClkSel2",   8, 4,"",NULL},    /* Partition Clock Selection 2 */
    { "Partition_ClkSel1",   4, 4,"",NULL},    /* Partition Clock Selection 1 */
    { "Partition_ClkSel0",   0, 4,"",NULL},    /* Partition Clock Selection 0 */
    { NULL,0,0,"",NULL }    /* NULL Terminated */

};


static const struct EAS_RegBits g_csr_NOAR6[] =
{
    {"RESERVED_31", 31, 1,"",NULL},    /* reserved bit [31] in this register */
    {"DT_Parcel7",  28, 3,"", NULL},/*DT Parsel7 partition select for NOA bit 7. To be used by dtunit. n=7.111 : p8_dt_noa[n]110 : p7_dt_noa[n] 101 : p6_dt_noa[n]100 : p5_dt_noa[n] 011 : p4_dt_noa[n] 010 : p3_dt_noa[n] 001 : p2_dt_noa[n] 000 : p1_dt_noa[n]*/
    {"RESERVED_27", 27, 1,"",NULL},    /* reserved bit [27] in this register */
    {"DT_Parcel6",  24, 3,"", NULL},/*DT Parsel6 partition select for NOA bit 6. To be used by dtunit. n=6.111 : p8_dt_noa[n]110 : p7_dt_noa[n] 101 : p6_dt_noa[n]100 : p5_dt_noa[n] 011 : p4_dt_noa[n] 010 : p3_dt_noa[n] 001 : p2_dt_noa[n] 000 : p1_dt_noa[n]*/
    {"RESERVED_23", 23, 1,"",NULL},    /* reserved bit [23] in this register */
    {"DT_Parcel5",  20, 3,"", NULL},/*DT Parsel5 partition select for NOA bit 5. To be used by dtunit. n=5.111 : p8_dt_noa[n]110 : p7_dt_noa[n] 101 : p6_dt_noa[n]100 : p5_dt_noa[n] 011 : p4_dt_noa[n] 010 : p3_dt_noa[n] 001 : p2_dt_noa[n] 000 : p1_dt_noa[n]*/
    {"RESERVED_19", 19, 1,"",NULL},    /* reserved bit [19] in this register */
    {"DT_Parcel4",  16, 3,"", NULL},/*DT Parsel4 partition select for NOA bit 4. To be used by dtunit. n=4.111 : p8_dt_noa[n]110 : p7_dt_noa[n] 101 : p6_dt_noa[n]100 : p5_dt_noa[n] 011 : p4_dt_noa[n] 010 : p3_dt_noa[n] 001 : p2_dt_noa[n] 000 : p1_dt_noa[n]*/
    {"RESERVED_15", 15, 1,"",NULL},    /* reserved bit [15] in this register */
    {"DT_Parcel3",  12, 3,"", NULL},/*DT Parsel3 partition select for NOA bit 3. To be used by dtunit. n=3.111 : p8_dt_noa[n]110 : p7_dt_noa[n] 101 : p6_dt_noa[n]100 : p5_dt_noa[n] 011 : p4_dt_noa[n] 010 : p3_dt_noa[n] 001 : p2_dt_noa[n] 000 : p1_dt_noa[n]*/
    {"RESERVED_11", 11, 1,"",NULL},    /* reserved bit [11] in this register */
    {"DT_Parcel2",   8, 3,"", NULL},/*DT Parsel2 partition select for NOA bit 2. To be used by dtunit. n=2.111 : p8_dt_noa[n]110 : p7_dt_noa[n] 101 : p6_dt_noa[n]100 : p5_dt_noa[n] 011 : p4_dt_noa[n] 010 : p3_dt_noa[n] 001 : p2_dt_noa[n] 000 : p1_dt_noa[n]*/
    {"RESERVED_7",   7, 1,"",NULL},    /* reserved bit [7] in this register */
    {"DT_Parcel1",   4, 3,"", NULL},/*DT Parsel1 partition select for NOA bit 1. To be used by dtunit. n=1.111 : p8_dt_noa[n]110 : p7_dt_noa[n] 101 : p6_dt_noa[n]100 : p5_dt_noa[n] 011 : p4_dt_noa[n] 010 : p3_dt_noa[n] 001 : p2_dt_noa[n] 000 : p1_dt_noa[n]*/
    {"RESERVED_3",   3, 1,"",NULL},    /* reserved bit [3] in this register */
    {"DT_Parcel0",   0, 3,"", NULL},/*DT Parsel6 partition select for NOA bit 0. To be used by dtunit. n=0.111 : p8_dt_noa[n]110 : p7_dt_noa[n] 101 : p6_dt_noa[n]100 : p5_dt_noa[n] 011 : p4_dt_noa[n] 010 : p3_dt_noa[n] 001 : p2_dt_noa[n] 000 : p1_dt_noa[n]*/
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_NOAR7[] =
{
    {"RESERVED_25_31",  25, 7,"",NULL},    /* reserved bit [25...31] in this register */
    {"SV_DIAGNOSTIC_TAP_ENABLE", 24, 1, "", NULL}, /* SV Diagnostic Tap Enabled */
    {"RESERVED_23_22",  22, 2,"",NULL},    /* reserved bit [22...23] in this register */
    {"NOA_OUTPUT_PAD_FLOP_CONTROL", 21, 1, "", NULL}, /* NOA Output Pad Flop Control: Default (Flops will be bypassed at the IO pads) 1:NOA[7:0] will be flopped by NOA[16] NOA [15:8] will be flopped by NOA[17] */
    {"Partition_CH2SigSel", 19, 2,"",NULL}, /*signal select for Second Channel NOA to select between the 4 8-bit buses for NOA bit [15:8]. Used in partition unit. */
    {"RESERVED_18", 18, 1,"",NULL},    /* reserved bit [18] in this register */
    {"Partition_CH2clkSel", 14, 4,"",NULL}, /* clock select for Second Channel NOA bit [15:8]. Used in partition unit.*/
    {"RESERVED_13", 13, 1,"",NULL},    /* reserved bit [13] in this register */
    {"DT_Ch2Parcel", 10, 3,"",NULL }, /*partition select Second Channel output for NOA bit [15:8]. Used in dtunit.*/
    {"NOA_Output_Clksel0",6,4, "", NULL},/*Used to select which clock domain will be used as output on NOA bit 16 (NOACLK[0]) */
    {"NOA_Output_Clksel1", 5,2, "", NULL}, /*Used to select which clock domain will be used as output on NOA bit 17 (NOACLK[1]) */
    {"NOA_Bypass", 1, 1, "", NULL}, /*used to select non flopped output path for data0*/
    {"NOA_ENABLE",0,1,"", NULL}, /*NOA test mode enable bit*/
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_CWSEL[] =
{
    { "RESERVED_31_23", 23, 9,"",NULL},    /* reserved bits [31..29] in this register */
    { "DSU_GROUP_DATA_INPUT_BYPASS_TIMING_CHARACTERIZATION",    21, 2,"",NULL},    /* determine the behavior of the DSU output. Bit 21 is used to determine whether the flops of data input at are bypassed or not. Bit 22 is used in Timing Characterization mode*/
    { "DSU_PREVIOUS_CW_DATA_INPUT_FLOP_BYPASS",20,1,"",NULL },  /* When this bit is 1, the data from the previous DSU will bypass the flops*/
    { "DSU_8X1_mux_Select", 14, 6,"",NULL},     /* There are two 8X1 muxes in each DSU. These 6 bits are used to control these two muxes.  */
    {"2nd_Chipwatcher_DSU_Select", 7, 7, "",NULL}, /*2nd Chipwatcher DSU Select*/
    {"1st_Chipwatcher_DSU_Select", 0, 7, "",NULL}, /*1st Chipwatcher DSU Select*/
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};



static const struct EAS_RegBits g_csr_MCH_INT_STATUS[] =
{
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};
/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.

 */

static const struct EAS_Register g_csr_MCH[] =
{

    CSR_REG("TCR_0",             0x0100, "Tiling Configuration Register (Channel 0)")
    CSR_REG("SDIR_0",            0x0104, "SDRAM Initialization Register (Channel 0)")
    CSR_REG("SDCR0_0",           0x0108, "SDRAM Control Register 0 (Channel 0)")
    CSR_REG("SDCR1_0",           0x010c, "SDRAM Control Register 1 (Channel 0)")
    CSR_REG("SDBR_0",            0x0110, "SDRAM Base Register (Channel 0)")
    CSR_REG("SBR_0",             0x0114, "SDRAM Boundary Register (Channel 0)")
    CSR_REG("CACR_0",            0x0118, "MCU Channel Arbitration Control Register (Channel 0)")
    CSR_REG("RFR_0",             0x0120, "Refresh Frequency Register (Channel 0)")
    CSR_REG("ODTCR_0",           0x0124, "ODT Control Register (Channel 0)")
    CSR_REG("SDPR0_0",           0x0128, "SDRAM Page Register 0 (Channel 0)")
    CSR_REG("SDPR1_0",           0x012c, "SDRAM Page Register 1 (Channel 0)")
    CSR_REG("SDPR2_0",           0x0130, "SDRAM Page Register 2 (Channel 0)")
    CSR_REG("SDPR3_0",           0x0134, "SDRAM Page Register 3 (Channel 0)")
    CSR_REG("SDPR4_0",           0x0138, "SDRAM Page Register 4 (Channel 0)")
    CSR_REG("SDPR5_0",           0x013c, "SDRAM Page Register 5 (Channel 0)")
    CSR_REG("SDPR6_0",           0x0140, "SDRAM Page Register 6 (Channel 0)")
    CSR_REG("SDPR7_0",           0x0144, "SDRAM Page Register 7 (Channel 0)")

    CSR_REG("TCR_1",             0x0180, "Tiling Configuration Register (Channel 1)")
    CSR_REG("SDIR_1",            0x0184, "SDRAM Initialization Register (Channel 1)")
    CSR_REG("SDCR0_1",           0x0188, "SDRAM Control Register 0 (Channel 1)")
    CSR_REG("SDCR1_1",           0x018c, "SDRAM Control Register 1 (Channel 1)")
    CSR_REG("SDBR_1",            0x0190, "SDRAM Base Register (Channel 1)")
    CSR_REG("SBR_1",             0x0194, "SDRAM Boundary Register (Channel 1)")
    CSR_REG("CACR_1",            0x0198, "MCU Channel Arbitration Control Register (Channel 1)")
    CSR_REG("RFR_1",             0x01a0, "Refresh Frequency Register (Channel 1)")
    CSR_REG("ODTCR_1",           0x01a4, "ODT Control Register (Channel 1)")
    CSR_REG("SDPR0_1",           0x01a8, "SDRAM Page Register 0 (Channel 1)")
    CSR_REG("SDPR1_1",           0x01ac, "SDRAM Page Register 1 (Channel 1)")
    CSR_REG("SDPR2_1",           0x01b0, "SDRAM Page Register 2 (Channel 1)")
    CSR_REG("SDPR3_1",           0x01b4, "SDRAM Page Register 3 (Channel 1)")
    CSR_REG("SDPR4_1",           0x01b8, "SDRAM Page Register 4 (Channel 1)")
    CSR_REG("SDPR5_1",           0x01bc, "SDRAM Page Register 5 (Channel 1)")
    CSR_REG("SDPR6_1",           0x01c0, "SDRAM Page Register 6 (Channel 1)")
    CSR_REG("SDPR7_1",           0x01c4, "SDRAM Page Register 7 (Channel 1)")

    CSR_REG("VDCEN1",            0x0280, "VDC Virtual Port 1 Enable")
    CSR_REG("VDCEN2",            0x0284, "VDC Virtual Port 2 Enable")
    CSR_REG("DPEEN1",            0x0288, "DPE Virtual Port 1 Enable")
    CSR_REG("DPEEN2",            0x028C, "DPE Virtual Port 2 Enable")
    CSR_REG("CH0_ARB_PORT0",     0x0290, "Channel 0 Port 0 Arbitration Registers")
    CSR_REG("CH0_ARB_PORT1",     0x0294, "Channel 0 Port 1 Arbitration Registers")
    CSR_REG("CH0_ARB_PORT2",     0x0298, "Channel 0 Port 2 Arbitration Registers")
    CSR_REG("CH0_ARB_PORT3",     0x029C, "Channel 0 Port 3 Arbitration Registers")
    CSR_REG("CH0_ARB_PORT4",     0x02A0, "Channel 0 Port 4 Arbitration Registers")
    CSR_REG("CH0_ARB_PORT5",     0x02A4, "Channel 0 Port 5 Arbitration Registers")
    CSR_REG("CH0_ARB_PORT6",     0x02A8, "Channel 0 Port 6 Arbitration Registers")
    CSR_REG("CH0_ARB_PORT7",     0x02AC, "Channel 0 Port 7 Arbitration Registers")
    CSR_REG("CH0_ARB_PORT8",     0x02B0, "Channel 0 Port 8 Arbitration Registers")
    CSR_REG("CH0_ARB_PORT9",     0x02B4, "Channel 0 Port 9 Arbitration Registers")
    CSR_REG("CH1_ARB_PORT0",     0x02B8, "Channel 1 Port 0 Arbitration Registers")
    CSR_REG("CH1_ARB_PORT1",     0x02BC, "Channel 1 Port 1 Arbitration Registers")
    CSR_REG("CH1_ARB_PORT2",     0x02C0, "Channel 1 Port 2 Arbitration Registers")
    CSR_REG("CH1_ARB_PORT3",     0x02C4, "Channel 1 Port 3 Arbitration Registers")
    CSR_REG("CH1_ARB_PORT4",     0x02C8, "Channel 1 Port 4 Arbitration Registers")
    CSR_REG("CH1_ARB_PORT5",     0x02CC, "Channel 1 Port 5 Arbitration Registers")
    CSR_REG("CH1_ARB_PORT6",     0x02D0, "Channel 1 Port 6 Arbitration Registers")
    CSR_REG("CH1_ARB_PORT7",     0x02D4, "Channel 1 Port 7 Arbitration Registers")
    CSR_REG("CH1_ARB_PORT8",     0x02D8, "Channel 1 Port 8 Arbitration Registers")
    CSR_REG("CH1_ARB_PORT9",     0x02DC, "Channel 1 Port 9 Arbitration Registers")
    CSR_REG("CENTRAL_ARB",       0x02E0, "Central Arbitration Register")
    CSR_REG("CENTRAL_CNTL",      0x02E4, "Central Control Register")

    CSR_REG("AVROOT_CSR",        0x0700, "Root Interrupt Control Register")
    CSR_REG("AVROOT_MSILOCK",    0x0704, "Root Interrupt MSI Lock Register")
    CSR_REG("AVROOT_STS",        0x0708, "Root Interrupt Status register")
    CSR_REG("AVROOT_IE",         0x070C, "Root Interrupt enable Register")
    CSR_REG("AVROOT_SEOI",       0x0710, "Soft EOI Register")
    CSR_REG("VGAEMU_IO",         0x0720, "VGA I/O Space Emulation configuration register")
    CSR_REG("VGAEMU_MEM",        0x0724, "VGA Memory Space Emulation configuration register")
    CSR_REG("VGAEMU_ADDR",       0x0728, "VGA Access Temporary Address Register")
    CSR_REG("VGAEMU_DATA",       0x072C, "VGA Access Temporary Data Register")
    CSR_REG("AVROOT_TEST",       0x077C, "Test")

    CSR_REG("PMUCTRL",           0x0B00, "PMU Control Register")
    CSR_REG("PMU_INT_ENABLE",    0x0B08, "PMU Interrupt Enable Register")
    CSR_REG("PMU_INT_STATUS",    0x0B0C, "PMU Interrupt Status Register")
    CSR_REG("PMUCTTHRESH0",      0x0B10, "PMU Event Count 0 Threshold Register")
    CSR_REG("PMUCTTHRESH1",      0x0B14, "PMU Event Count 1 Threshold Register")
    CSR_REG("PMUTIMETHRESH",     0x0B18, "PMU Timer Threshold Register")
    CSR_REG("PMUCT0",            0x0B1C, "PMU Event Count 0 Register")
    CSR_REG("PMUCT1",            0x0B20, "PMU Event Count 1 Register")
    CSR_REG("PMUTIMER",          0x0B24, "PMU Timer Register")

    /* THESE ARE FROM THE CLOCK POWER UNIT */
    CSR_REG("CP_CNTL_STS",       0x0C00, "Clock Control and Status")
    CSR_REG("CP_SS_XMIT_H2MC",   0x0C04, "Stepping Stone H to MC Transmit Pattern")
    CSR_REG("CP_SS_RCV_H2MC",    0x0C08, "Stepping Stone H to MC Receive Pattern")
    CSR_REG("CP_SS_XMIT_MC2H",   0x0C0C, "Stepping Stone MC to H Transmit Pattern")
    CSR_REG("CP_SS_RCV_MC2H",    0x0C10, "Stepping Stone MC to H Receive Pattern")
    CSR_REG("CP_SS_PHASE",       0x0C14, "Stepping Stone Phase Control")
    CSR_REG("CP_FCCCC",          0x0C18, "Frequency and Clock Crossing Change Control ")
    CSR_REG("CP_SSKPD",          0x0C1C, "Sticky Scratchpad Register")
    CSR_REG("CP_PLL_ADDR",       0x0C20, "PLL Address Register")
    CSR_REG("CP_PLL_DATA",       0x0C24, "PLL Data Register")
    CSR_REG("CP_CLK_INV",        0x0C2C, "Clock Invert")
    CSR_REG("CP_OVER_CLK",       0x0C30, "Overclocking Control and Status")
    CSR_REG("CP_L2_DIV_CTRL_0",  0x0C38, "Second Level Divider Control 0")
    CSR_REG("CP_L2_DIV_CTRL_1",  0x0C3C, "Second Level Divider Control 1")
    CSR_REG("CP_UNIT_RST",       0x0C40, "Unit Reset")
    CSR_REG("CP_CG_EN",          0x0C44, "Clock Gate Enable")
    CSR_REG("CP_CG_DIS",         0x0C48, "Clock Gate Disable")
    CSR_REG("CP_GFX_CLK_CTRL",   0x0C4C, "GFX Clock Control")
    CSR_REG("CP_FUSE_0",         0x0C50, "Fuse 0")
    CSR_REG("CP_FUSE_1",         0x0C54, "Fuse 1")
    CSR_REG("CP_FUSE_2",         0x0C58, "Fuse 2")
    CSR_REG("CP_DDS_CNTL_0",     0x0C60, "DDS0 Control")
    CSR_REG("CP_DDS_CNTL_1",     0x0C64, "DDS1 Control")
    CSR_REG("CP_GTS_CNTL",       0x0C68, "Global Timestamp Control")
    CSR_REG("CP_GTS_PRST",       0x0C6C, "Global Timestamp Preset")
    CSR_REG("CP_STRAP_STS_0",    0x0C70, "Strap Status 0")
    CSR_REG("CP_STRAP_STS_1",    0x0C74, "Strap Status 1")
    CSR_REG("CP_THERM_CNTL",     0x0C78, "Thermal Sensor Control")
    CSR_REG("CP_THERM_STS",      0x0C7C, "Thermal Sensor Status")
    CSR_REG("CP_THERM_ERR",      0x0C80, "Thermal Sensor Error")
    CSR_REG("CP_IUB",            0x0CD0, "In Use Bits")

    CSR_REG("FAKE_REG_00",       0x0D00, "The next 64 registers are fakes for TBE Access")
/*
    Removed by Pat Brouillette (2006-05-19) to reduce debug console "peek" chuff

    CSR_REG("FAKE_REG_01",       0x0D04, "They were added because of a request by")
    CSR_REG("FAKE_REG_02",       0x0D08, "Todd Stevens, Pat Brouillette,")
    CSR_REG("FAKE_REG_03",       0x0D0C, "Dave McDonnell, and Devangi Bhatt")
    CSR_REG("FAKE_REG_04",       0x0D10, "Registers 04-07 are used by Masud Khan")
    CSR_REG("FAKE_REG_05",       0x0D14, "")
    CSR_REG("FAKE_REG_06",       0x0D18, "")
    CSR_REG("FAKE_REG_07",       0x0D1C, "These are used for expansion bus transaction setting")
    CSR_REG("FAKE_REG_08",       0x0D20, "Please ignore them for other testing...")
    CSR_REG("FAKE_REG_09",       0x0D24, "")
    CSR_REG("FAKE_REG_10",       0x0D28, "")
    CSR_REG("FAKE_REG_11",       0x0D2C, "")
    CSR_REG("FAKE_REG_12",       0x0D30, "")
    CSR_REG("FAKE_REG_13",       0x0D34, "")
    CSR_REG("FAKE_REG_14",       0x0D38, "")
    CSR_REG("FAKE_REG_15",       0x0D3C, "")
    CSR_REG("FAKE_REG_16",       0x0D40, "")
    CSR_REG("FAKE_REG_17",       0x0D44, "")
    CSR_REG("FAKE_REG_18",       0x0D48, "")
    CSR_REG("FAKE_REG_19",       0x0D4C, "")
    CSR_REG("FAKE_REG_20",       0x0D50, "")
    CSR_REG("FAKE_REG_21",       0x0D54, "")
    CSR_REG("FAKE_REG_22",       0x0D58, "")
    CSR_REG("FAKE_REG_23",       0x0D5C, "")
    CSR_REG("FAKE_REG_24",       0x0D60, "")
    CSR_REG("FAKE_REG_25",       0x0D64, "")
    CSR_REG("FAKE_REG_26",       0x0D68, "")
    CSR_REG("FAKE_REG_27",       0x0D6C, "")
    CSR_REG("FAKE_REG_28",       0x0D70, "")
    CSR_REG("FAKE_REG_29",       0x0D74, "")
    CSR_REG("FAKE_REG_30",       0x0D78, "")
    CSR_REG("FAKE_REG_31",       0x0D7C, "")
    CSR_REG("FAKE_REG_32",       0x0D80, "")
    CSR_REG("FAKE_REG_33",       0x0D84, "")
    CSR_REG("FAKE_REG_34",       0x0D88, "")
    CSR_REG("FAKE_REG_35",       0x0D8C, "")
    CSR_REG("FAKE_REG_36",       0x0D90, "")
    CSR_REG("FAKE_REG_37",       0x0D94, "")
    CSR_REG("FAKE_REG_38",       0x0D98, "")
    CSR_REG("FAKE_REG_39",       0x0D9C, "")
    CSR_REG("FAKE_REG_40",       0x0DA0, "")
    CSR_REG("FAKE_REG_41",       0x0DA4, "")
    CSR_REG("FAKE_REG_42",       0x0DA8, "")
    CSR_REG("FAKE_REG_43",       0x0DAC, "")
    CSR_REG("FAKE_REG_44",       0x0DB0, "")
    CSR_REG("FAKE_REG_45",       0x0DB4, "")
    CSR_REG("FAKE_REG_46",       0x0DB8, "")
    CSR_REG("FAKE_REG_47",       0x0DBC, "")
    CSR_REG("FAKE_REG_48",       0x0DC0, "")
    CSR_REG("FAKE_REG_49",       0x0DC4, "")
    CSR_REG("FAKE_REG_50",       0x0DC8, "")
    CSR_REG("FAKE_REG_51",       0x0DCC, "")
    CSR_REG("FAKE_REG_52",       0x0DD0, "")
    CSR_REG("FAKE_REG_53",       0x0DD4, "")
    CSR_REG("FAKE_REG_54",       0x0DD8, "")
    CSR_REG("FAKE_REG_55",       0x0DDC, "")
    CSR_REG("FAKE_REG_56",       0x0DE0, "")
    CSR_REG("FAKE_REG_57",       0x0DE4, "")
    CSR_REG("FAKE_REG_58",       0x0DE8, "")
    CSR_REG("FAKE_REG_59",       0x0DEC, "")
    CSR_REG("FAKE_REG_60",       0x0DF0, "")
    CSR_REG("FAKE_REG_61",       0x0DF4, "")
    CSR_REG("FAKE_REG_62",       0x0DF8, "")
    CSR_REG("FAKE_REG_63",       0x0DFC, "")
*/

    CSR_REG_W_BB("NOAR1",             0x0E30, g_csr_NOAR1, "Node Observation Architecture 1")
    CSR_REG_W_BB("NOAR2",             0x0E34, g_csr_NOAR2, "Node Observation Architecture 2")
    CSR_REG_W_BB("NOAR3",             0x0E38, g_csr_NOAR3, "Node Observation Architecture 3")
    CSR_REG_W_BB("NOAR4",             0x0E3C, g_csr_NOAR4, "Node Observation Architecture 4")
    CSR_REG_W_BB("NOAR5",             0x0E40, g_csr_NOAR5, "Node Observation Architecture 5")
    CSR_REG_W_BB("NOAR6",             0x0E44, g_csr_NOAR6, "Node Observation Architecture 6")
    CSR_REG_W_BB("NOAR7",             0x0E48, g_csr_NOAR7, "Node Observation Architecture 7")
    CSR_REG_W_BB("CWSEL",             0x0E50, g_csr_CWSEL, "CW Selection Register")

    CSR_REG("PMUSELECT",         0x0E60, "PMU Event Selection Register")

    CSR_NULL_TERM()

};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_MCH_specific_events[] =
{
    { "Message_Test",       1,      "Message Test", NULL },
    { "Firmware_Load",      2,      "Firmware Load", NULL },
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_MCH_sven_module =
{
    "GEN2_MCH",               /* TODO: Get a Module Name from Pat B */
    SVEN_module_GEN2_MCH,     /* TODO: Find your module in <sven_module.h> */
    4*1024,                 /* Size of Registers */
#ifdef SVEN_INTERNAL_BUILD
    g_csr_MCH,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MCH: MCH (GEN2)",
    g_MCH_specific_events,  /* TODO-Later: Define important events specific to my module */
    NULL /* extension list */
};
