/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

#ifdef SVEN_INTERNAL_BUILD
/* Register defines pulled from VCAP EAS */
static const struct EAS_RegBits g_csr_vr_vcap_POLARITY[] = 
{
    /* Copied from EAS */
    {"RESERVED",            12, 20, "", NULL },
    {"FIELD2_POLARITY",     11, 1, "", NULL },
    /* 0    RW  1 : Field Bit is active high in Stream 2        
                0 : Field Bit is active low in Stream 2 */
    {"FIELD1_POLARITY",     10, 1, "", NULL },
    /* 0    RW  1 : Field Bit is active high in Stream 1        
                0 : Field Bit is active low in Stream 1 */
    {"FIELD0_POLARITY",     9, 1, "", NULL },
    /* 0    RW  1 : Field Bit is active high in Stream 0
                0 : Field Bit is active low in Stream 0 */
    {"VSYNC2_POLARITY",     8, 1, "", NULL },
    /* 0    RW  1 : VSync Bit is active high in Stream 2        
                0 : VSync Bit is active low in Stream 2 */
    {"VSYNC1_POLARITY",     7, 1, "", NULL },
    /* 0    RW  1 : VSync Bit is active high in Stream 1        
                0 : VSync Bit is active low in Stream 1 */
    {"VSYNC0_POLARITY",     6, 1, "", NULL },
    /* 0    RW  1 : VSync Bit is active high in Stream 0        
                0 : VSync Bit is active low in Stream 0 */
    {"HSYNC2_POLARITY",     5, 1, "", NULL },
    /* 0    RW  1 : HSync Bit is active high in Stream 2        
                0 : HSync Bit is active low in Stream 2 */
    {"HSYNC1_POLARITY",     4, 1, "", NULL },
    /* 0    RW  1 : HSync Bit is active high in Stream 1        
                0 : HSync Bit is active low in Stream 1 */
    {"HSYNC0_POLARITY",     3, 1, "", NULL },
    /* 0    RW  1 : HSync Bit is active high in Stream 0        
                0 : HSync Bit is active low in Stream 0 */
    {"CLKIN2_POLARITY",     2, 1, "", NULL },
    /* 0    RW  1 : Source Clock Bit is active high in Stream 2 
                0 : Source Clock Bit is active low in Stream 2 */
    {"CLKIN1_POLARITY",     1, 1, "", NULL },
    /* 0    RW  1 : Source Clock Bit is active high in Stream 1 
                0 : Source Clock Bit is active low in Stream 1 */
    {"CLKIN0_POLARITY",     0, 1, "", NULL },
    /* 0    RW  1 : Source Clock Bit is active high in Stream 0 
                0 : Source Clock Bit is active low in Stream 0 */

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Register defines pulled from VCAP EAS */
static const struct EAS_RegBits g_csr_vr_vcap_INT[] = 
{
    /* Table Copy from EAS */
    { "RESERVED",               24, 8, "", NULL },

    { "VID1_WATCHDOG_INT",      23, 1, "", NULL },      
    /* 0    RW  1 : No Data was received on Vid1 port for 64 clock cycles. Should be used to detect plug / unplug of Video source 
                0 : Data is being received at aleast once per 64 vcap-clock cycle period. Indicates Vid1 source is plugged in and transferring data. */
    { "VID0_WATCHDOG_INT",      22, 1, "", NULL },      
    /* 0    RW  1 : No Data was received on Vid0 port for 64 clock cycles. Should be used to detect plug / unplug of Video source 
                0 : Data is being received at aleast once per 64 vcap-clock cycle period. Indicates Vid0 source is plugged in and transferring data. */
    { "HDMI_FRAME_DROPPED_IN",  21, 1, "", NULL },
    /* 0    RW  1 : One or more HDMI Frames were dropped, because input Free List was empty when frame was received. */
    { "HDMI_FRAME_DROPPED_OUT", 20, 1, "", NULL },
    /* 0    RW  1 : One or more HDMI Frames were dropped, because output descriptor list was full when frame transfer was completed. */
    { "VID1_FRAME_DROPPED_IN",  19, 1, "", NULL },
    /* 0    RW  1 : One or more Vid1 Frames were dropped, because input Free List was empty when frame was received. */
    { "VID1_FRAME_DROPPED_OUT", 18, 1, "", NULL },
    /* 0    RW  1 : One or more Vid1 Frames were dropped, because output descriptor list was full when frame transfer was completed. */
    { "VID0_FRAME_DROPPED_IN",  17, 1, "", NULL },
    /* 0    RW  1 : One or more Vid0  Frames were dropped, because input Free List was empty when frame was received. */
    { "VID0_FRAME_DROPPED_OUT", 16, 1, "", NULL },
    /* 0    RW  1 : One or more Vid0 Frames were dropped, because output descriptor list was full when frame transfer was completed. */
    { "HDMI_LINE_MISMATCH",     15, 1, "", NULL },      
    /* 0    RW  1 : Number of lines per frame fall outside expected +/- threshold 
                0 : Number of lines per frame fall within expected +/- threshold */
    { "HDMI_PIXEL_MISMATCH",    14, 1, "", NULL },  
    /* 0    RW  1 : Number of pixels per line falls outside expected +/- threshold 
                0 : Number of pixels per line falls within expected +/- threshold */
    { "VID1_LINE_MISMATCH",     13, 1, "", NULL },      
    /* 0    RW  1 : Number of lines per frame fall outside expected +/- threshold 
                0 : Number of lines per frame fall within expected +/- threshold */
    { "VID1_PIXEL_MISMATCH",    12, 1, "", NULL },  
    /* 0    RW  1 : Number of pixels per line falls outside expected +/- threshold 
                0 : Number of pixels per line falls within expected +/- threshold */
    { "VID0_LINE_MISMATCH",     11, 1, "", NULL },      
    /* 0    RW  1 : Number of lines per frame fall outside expected +/- threshold 
                0 : Number of lines per frame fall within expected +/- threshold */
    { "VID0_PIXEL_MISMATCH",    10, 1, "", NULL },  
    /* 0    RW  1 : Number of pixels per line falls outside expected +/- threshold 
                0 : Number of pixels per line falls within expected +/- threshold */
    { "OUTPUT_DESC_INT",        9,  1, "", NULL },      
    /* 0    RW  1 : Output Descriptor List Has Reached Threshold  
                0 : Output Descriptor List below Threshold */
    { "FREE_LIST2_INT",         8,  1, "", NULL },          
    /* 0    RW  1 : Free List Has Reached Threshold  
                0 : Free List below Threshold */
    { "FREE_LIST1_INT",         7,  1, "", NULL },          
    /* 0    RW  1 : Free List Has Reached Threshold  
                0 : Free List below Threshold */
    { "FREE_LIST0_INT",         6,  1, "", NULL },          
    /* 0    RW  1 : Free List Has Reached Threshold  
                0 : Free List below Threshold */
    { "IN2_FIFO_B_INT",         5,  1, "", NULL },          
    /* 0    RW  1 : Stream 2 FIFO_B is has reached threshold  
                0 : Stream 2 FIFO_B is below threshold */
    { "IN2_FIFO_A_INT",         4,  1, "", NULL },          
    /* 0    RW  1 : Stream 2 FIFO_A is has reached threshold  
                0 : Stream 2 FIFO_A is below threshold */
    { "IN1_FIFO_B_INT",         3,  1, "", NULL },          
    /* 0    RW  1 : Stream 1 FIFO_B is has reached threshold  
                0 : Stream 1 FIFO_B is below threshold */
    { "IN1_FIFO_A_INT",         2,  1, "", NULL },          
    /* 0    RW  1 : Stream 1 FIFO_A is has reached threshold  
                0 : Stream 1 FIFO_A is below threshold */
    { "IN0_FIFO_B_INT",         1,  1, "", NULL },
    /* 0    RW  1 : Stream 0 FIFO_B is has reached threshold
                0 : Stream 0 FIFO_B is below threshold */
    { "IN0_FIFO_A_INT",         0,  1, "", NULL },          
    /* 0    RW  1 : Stream 0 FIFO_A is has reached threshold  
                0 : Stream 0 FIFO_A is below threshold */

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_vr_vcap_CONFIG[] = 
{
    { "RSVD_31_30",         30, 2, "RESERVED", NULL },
    { "STR2_F_DETECT",      29, 1, "HDMI: Field Detect", NULL },
    { "STR1_F_DETECT",      28, 1, "STR1: Field Detect", NULL },
    { "STR0_F_DETECT",      27, 1, "STR0: Field Detect", NULL },
    { "STR2_FV_START",      26, 1, "HDMI: SOF based on field", NULL },
    { "STR1_FV_START",      25, 1, "STR1: SOF based on field", NULL },
    { "STR0_FV_START",      24, 1, "STR0: SOF based on field", NULL },
    { "STR2_1120",          23, 1, "HDMI: YUV 1120", NULL },
    { "STR1_1120",          22, 1, "STR1: YUV 1120", NULL },
    { "STR0_1120",          21, 1, "STR2: YUV 1120", NULL },
    { "DMA_SIZE",           19, 2, "DMA Size", NULL },
    { "STR2_PROGRESSIVE",   18, 1, "HDMI: Progressive", NULL },
    { "STR1_PROGRESSIVE",   17, 1, "STR1: Progressive", NULL },
    { "STR0_PROGRESSIVE",   16, 1, "STR0: Progressive", NULL },
    { "STR2_EXT_SYNC",      15, 1, "HDMI: Ext Sync", NULL },
    { "STR1_EXT_SYNC",      14, 1, "STR1: Ext Sync", NULL },
    { "STR0_EXT_SYNC",      13, 1, "STR0: Ext Sync", NULL },
    { "STR2_PIX_RES",       12, 1, "HDMI: 10 bit res", NULL },
    { "STR1_PIX_RES",       11, 1, "STR1: 10 bit res", NULL },
    { "STR0_PIX_RES",       10, 1, "STR0: 10 bit res", NULL },
    { "STR2_PIX_TYPE",      9, 1, "HDMI: is RGB", NULL },
    { "STR1_PIX_TYPE",      8, 1, "STR1: is RGB", NULL },
    { "STR0_PIX_TYPE",      7, 1, "STR0: is RGB", NULL },
    { "STR2_YUV444",        6, 1, "HDMJ: is YUV444", NULL },
    { "CSC2_ENABLE",        5, 1, "HDMI: CSC Enable", NULL },
    { "CSC1_ENABLE",        4, 1, "CSC1 Enable", NULL },
    { "CSC1_OWNER",         3, 1, "CSC1 Owner", NULL },
    { "STR2_ENABLE",        2, 1, "HDMI: Str Enable", NULL },
    { "STR1_ENABLE",        1, 1, "STR1: Str Enable", NULL },
    { "STR0_ENABLE",        0, 1, "STR0: Str Enable", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_vr_vcap_FIFO_THRESHOLDS[] = 
{
    { "RSVD_31_24",         24, 8, "RESERVED", NULL },

/* DMA FIFO THRESHHOLDS
    Interrupt is triggered if number of entries in
    Data FIFO equals or exceeds  threshold
    00 : Threshold = 256 Bytes
    01 : Threshold = 192 Bytes
    10 : Threshold = 128 Bytes
    11 : Threshold = 64 Bytes
*/

    { "IN2_FIFO_B_TH",      22, 2, "HDMI: FIFO_B_TH", NULL },
    { "IN2_FIFO_A_TH",      20, 2, "HDMI: FIFO_A_TH", NULL },
    { "IN1_FIFO_B_TH",      18, 2, "STR1: FIFO_B_TH", NULL },
    { "IN1_FIFO_A_TH",      16, 2, "STR1: FIFO_A_TH", NULL },
    { "IN0_FIFO_B_TH",      14, 2, "STR0: FIFO_B_TH", NULL },
    { "IN0_FIFO_A_TH",      12, 2, "STR0: FIFO_A_TH", NULL },

    { "OUTPUT_DESC_TH",     9, 3, "Output Descriptor Threshhold", NULL },
    { "FREE_LIST2_TH",      6, 3, "HDMI Descriptor Threshhold", NULL },
    { "FREE_LIST1_TH",      3, 3, "STR1 Descriptor Threshhold", NULL },
    { "FREE_LIST0_TH",      0, 3, "STR0 Descriptor Threshhold", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_vr_vcap_FLOW_ID_ww0406[] =
{
    { "Reserved_31_12",    12, 20, "Reserved[31.12]", NULL },
    { "HDMI",               8,  4,  "HDMI: FLOW_ID", NULL },
    { "VID1",               4,  4,  "VID1: FLOW_ID", NULL },
    { "VID0",               0,  4,  "VID0: FLOW_ID", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_vr_vcap_YSTART_ww0406[] =
{
    { "Reserved_31_29",    29, 3,  "Reserved[31.29]", NULL },
    { "FIELD2",            16, 13, "First Line to be Captured in Field2.", NULL },
    { "Reserved_15_13",    13, 3,  "Reserved[15.13]", NULL },
    { "FIELD1",             0, 13, "Line Number of Top left Corner", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_vr_vcap_OUT_DESC_0[] =
{
/* Output Buffer Descriptor: DWORD 0
 *
 *  Bits    Description
 *  31:30   Descriptor type:        2'b10: Output descriptor contains the pointers to picture buffers
 *  29:28   Video_Context           - Not used . Set to 2'b00
 *  27:24   Flow_ID                 - Software programs the Flow ID for each channel in the
 *                                    VCAP_FLOWID  registers.    Default  :4'b0000
 *  23      Interrupt_on_descriptor - Not Used  Default : 1'b0 
 *  22      Interrupt_on_done       - Not Used  Default : 1'b0
 *  21:16   Video Flow Event        - Based on Video Statistics Generator results. Each event has a bit associated with it.
 *                                    If multiple events occur during a frame, the Flow Events are Or'ed together.
 *              00h - No event
 *              01h - Data Corrupted in Frame because Data FIFO was full.
 *              02h - Frame statistics exceeds tolerance specified in stream's HSYNC_VSYNC_TOL register.
 *                    Also asserted  hdmi_vid_fmt_chng was aserrted during this frame.
 *              08h - HDMI Error flag received (only set for HDMI frames
 *              10h - Frame Discontinuity -- Indicates First Frame of Captured Stream
 *  15      PTS_Valid               - If set, indicates the DWORD 04h contains a valid Presentation Time Stamp (PTS). 
 *              1h  - PTS is always valid for VCAP output descriptors
 *  14      Complete Descriptor     - Not Used  1h - Always Complete
 *  13      Video_type              - Used to indicate the video buffer type. 
 *              0: YCrCb - Uses DWORD 08h and DWORD 0Ch  to provide Y and UV buffer pointers.
 *              1: RGB - Uses DWORD 08h  to provide RGB buffer pointer. DWORD 0Ch may be used for packing flags.
 *  12      Reserved
 *  11:0    Software Attribute or Video Buffer Handle -
 *          12-bit field used by the buffer identifier to avoid reverse lookup of the
 *          configuration data buffer for its de-allocation. This field is only used
 *          by the software and is ignored by hardware. 
 */
    { "DESC_TYPE",          30, 2, "2'b10: Output descriptor contains the pointers to picture buffers", NULL },
    { "VID_CONTEXT",        28, 2, "Not used . Set to 2'b00", NULL },
    { "FLOW_ID",            24, 4, "Software programs the Flow ID for each channel", NULL },
    { "INT_ON_DESC",        23, 1, "Not Used  Default : 1'b0", NULL },
    { "INT_ON_DONE",        22, 1, "Not Used  Default : 1'b0", NULL },
    { "VID_FLOW_EVENT",     16, 6, "Based on Video Statistics Generator results", NULL },
    { "PTS_VALID",          15, 1, "1h  - PTS is always valid for VCAP output descriptors", NULL },
    { "DESC_COMPLETE",      14, 1, "1h - Always Complete", NULL },
    { "VID_TYPE",           13, 1, "0 - YCbCr 1 - RGB", NULL },
    { "RESERVED",           12, 1, "Unused", NULL },
    { "BUF_HANDLE",          0, 12, "BufHandle", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Copied from VCAP EAS 13oct2005 by Pat Brouillette */
static const struct EAS_Register g_csr_vr_vcap[] =
{
    { "CONFIG",                0x00, g_csr_vr_vcap_CONFIG, "Config Register", NULL },
    { "SYNC_POLARITY",          0x04, g_csr_vr_vcap_POLARITY, "Polarity for all Video Sync bits", NULL },
    { "INT_STATUS",            0x08, g_csr_vr_vcap_INT, "Interrupt Status Register", NULL },
    { "FIFO_THRESHOLDS",       0x0c, g_csr_vr_vcap_FIFO_THRESHOLDS, "Thresholds for all FIFOs and Lists", NULL },
    { "INT_MASK",              0x10, NULL, "Interrupt Mask Register", NULL },
    { "CSC1_CONFIG",           0x14, NULL, "Contains config information for CSC1 ", NULL },
    { "CSC2_CONFIG",           0x18, NULL, "Contains config information for CSC2", NULL },
    { "VID0_FIELD_DETECT_THRESHOLD",    0x1c, NULL, "VID0_FIELD_DETECT_THRESHOLD", NULL },
    { "VID1_FIELD_DETECT_THRESHOLD",    0x20, NULL, "VID1_FIELD_DETECT_THRESHOLD", NULL },
    { "HDMI_FIELD_DETECT_THRESHOLD",    0x24, NULL, "HDMI_FIELD_DETECT_THRESHOLD", NULL },
    { "RESERVED_28h",          0x28, NULL, "reserved", NULL },
    { "RESERVED_2ch",          0x2c, NULL, "reserved", NULL },
    { "RESERVED_30h",          0x30, NULL, "reserved", NULL },
    { "RESERVED_34h",          0x34, NULL, "reserved", NULL },
    { "FLOW_ID",               0x38, g_csr_vr_vcap_FLOW_ID_ww0406, "Contains the flow_id for all 3 streams", NULL },
    { "VID0_XSTART",           0x3c, NULL, "Indicated Cropping location for Stream0 (inclusive)", NULL },
    { "VID0_YSTART",           0x40, g_csr_vr_vcap_YSTART_ww0406, "Indicated Cropping location for Stream0 (inclusive)", NULL },
    { "VID0_XSTOP",            0x44, NULL, "Indicated Cropping location for Stream0 (inclusive)", NULL },
    { "VID0_YSTOP",            0x48, g_csr_vr_vcap_YSTART_ww0406, "Indicated Cropping location for Stream0 (inclusive)", NULL },
    { "VID1_XSTART",           0x4c, NULL, "Indicated Cropping location for Stream1 (inclusive)", NULL },
    { "VID1_YSTART",           0x50, g_csr_vr_vcap_YSTART_ww0406, "Indicated Cropping location for Stream1 (inclusive)", NULL },
    { "VID1_XSTOP",            0x54, NULL, "Indicated Cropping location for Stream1 (inclusive)", NULL },
    { "VID1_YSTOP",            0x58, g_csr_vr_vcap_YSTART_ww0406, "Indicated Cropping location for Stream1 (inclusive)", NULL },
    { "HDMI_XSTART",           0x5c, NULL, "Indicated Cropping location for Stream2 (inclusive)", NULL },
    { "HDMI_YSTART",           0x60, g_csr_vr_vcap_YSTART_ww0406, "Indicated Cropping location for Stream2 (inclusive)", NULL },
    { "HDMI_XSTOP",            0x64, NULL, "Indicated Cropping location for Stream2 (inclusive)", NULL },
    { "HDMI_YSTOP",            0x68, g_csr_vr_vcap_YSTART_ww0406, "Indicated Cropping location for Stream2 (inclusive)", NULL },
    { "VID0_PITCH",            0x6c, NULL, "Stream 0 Pitch", NULL },
    { "VID1_PITCH",            0x70, NULL, "Stream 1 Pitch", NULL },
    { "HDMI_PITCH",            0x74, NULL, "Stream 2 Pitch", NULL },
    { "VID0_TOT_PIX_PER_LN",   0x78, NULL, "Expected Pixels per line (Hsync active to next Hsync active)", NULL },
    { "VID1_TOT_PIX_PER_LN",   0x7c, NULL, "Expected Pixels per line (Hsync active to next Hsync active)", NULL },
    { "HDMI_TOT_PIX_PER_LN",   0x80, NULL, "Expected Pixels per line (Hsync active to next Hsync active)", NULL },
    { "VID0_TOT_LN_PER_FM",    0x84, NULL, "Expected Lines per frame (Moving average over 2 frames of duration between Vsync active to next Vsync active)", NULL },
    { "VID1_TOT_LN_PER_FM",    0x88, NULL, "Expected Lines per frame (Moving average over 2 frames of duration between Vsync active to next Vsync active)", NULL },
    { "HDMI_TOT_LN_PER_FM",    0x8c, NULL, "Expected Lines per frame (Average number of Hsyncs between Vsync active to next Vsync active)", NULL },
    { "VID0_HSYNC_VSYNC_TOL",  0x90, NULL, "Contains tolerance above/below frame events 02 is generated.", NULL },
    { "VID1_HSYNC_VSYNC_TOL",  0x94, NULL, "Contains tolerance above/below frame events 02 is generated.", NULL },
    { "HDMI_HSYNC_VSYNC_TOL",  0x98, NULL, "Contains tolerance above/below frame events 02 is generated.", NULL },
    { "VID0_PIXEL_CNTR",       0x9c, NULL, "Counts number of pixels between consecutive active edges of hysnc", NULL },
    { "VID0_LINE_CNTR",        0xA0, NULL, "Counts moving average of (current and previous) number of hsyncs between consecutive vsyncs", NULL },
    { "VID1_PIXEL_CNTR",       0xA4, NULL, "Counts number of pixels between consecutive active edges of hysnc", NULL },
    { "VID1_LINE_CNTR",        0xA8, NULL, "Counts moving average of (current and previous) number of hsyncs between consecutive vsyncs", NULL },
    { "HDMI_PIXEL_CNTR",       0xAC, NULL, "Counts number of pixels between consecutive active edges of hysnc", NULL },
    { "HDMI_LINE_CNTR",        0xB0, NULL, "Counts moving average of (current and previous) number of hsyncs between consecutive vsyncs", NULL },
    { "FREE0_PTR",             0xB4, NULL, "Contains rd, wr pointers for  free list0", NULL },
    { "FREE1_PTR",             0xB8, NULL, "Contains rd, wr pointers for  free list1", NULL },
    { "FREE2_PTR",             0xBC, NULL, "Contains rd, wr pointers for  free list2", NULL },
    { "OUT_PTR",               0xC0, NULL, "Contains rd, wr pointers for  output descriptor list", NULL },
    { "FREE_LIST_0",           0x100, NULL, "base of FREE FIFO 0", NULL },
    { "FREE_LIST_1",           0x140, NULL, "base of FREE FIFO 1", NULL },
    { "FREE_LIST_2",           0x180, NULL, "base of FREE FIFO 2", NULL },


    { "OUT_DESC0_W0",          0x200, g_csr_vr_vcap_OUT_DESC_0, "OUT Descriptor-0 Word 0", NULL },
    { "OUT_DESC1_W0",          0x210, g_csr_vr_vcap_OUT_DESC_0, "OUT Descriptor-1 Word 0", NULL },
    { "OUT_DESC2_W0",          0x220, g_csr_vr_vcap_OUT_DESC_0, "OUT Descriptor-2 Word 0", NULL },
    { "OUT_DESC3_W0",          0x230, g_csr_vr_vcap_OUT_DESC_0, "OUT Descriptor-3 Word 0", NULL },
    { "OUT_DESC4_W0",          0x240, g_csr_vr_vcap_OUT_DESC_0, "OUT Descriptor-4 Word 0", NULL },
    { "OUT_DESC5_W0",          0x250, g_csr_vr_vcap_OUT_DESC_0, "OUT Descriptor-5 Word 0", NULL },
    { "OUT_DESC6_W0",          0x260, g_csr_vr_vcap_OUT_DESC_0, "OUT Descriptor-6 Word 0", NULL },
    { "OUT_DESC7_W0",          0x270, g_csr_vr_vcap_OUT_DESC_0, "OUT Descriptor-7 Word 0", NULL },
    { "OUT_DESC",              0x200, NULL, "base of OUT FIFO", NULL },

    { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* SVEN_INTERNAL_BUILD */

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct SVEN_Module_EventSpecific g_vr_vcap_specific_events[] =
{
    { "OUT_FRAME_READ",     1,      "Output Frame Descriptor Read", NULL },
    { "OUT_FIFO_FULL",      2,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    3,      "", NULL },

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_vcap_sven_module =
{
    "GEN2_VCAP",
    SVEN_module_GEN2_VCAP,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_vr_vcap,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "VCAP: Video Capture (GEN2)",
    g_vr_vcap_specific_events,
    NULL /* extension list */
};
