/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
////////////////////////////////////////////////////////////////////////////////
///
/// @brief      "Reversible" register definitions for VR MPG2VD
///
/// @author     Pat Brouillette, John Carroll, and Steven Krebs
///
/// @note       This file belongs in /sven.
///
/// The source code contained or described herein and all documents related to
/// the source code ("Material") are owned by Intel Corporation or its suppliers
/// or licensors. Title to the Material remains with Intel Corporation or its
/// suppliers and licensors. The Material contains trade secrets and proprietary
/// and confidential information of Intel or its suppliers and licensors. The
/// Material is protected by worldwide copyright and trade secret laws and
/// treaty provisions.  No part of the Material may be used, copied, reproduced,
/// modified, published, uploaded, posted, transmitted, distributed, or
/// disclosed in any way without Intel�s prior express written permission.
///
/// No license under any patent, copyright, trade secret or other intellectual
/// property right is granted to or conferred upon you by disclosure or delivery
/// of the Materials, either expressly, by implication, inducement, estoppel or
/// otherwise. Any license under such intellectual property rights must be
/// express and approved by Intel in writing.
//
//  Note:       See Doxygen Manual http://www.doxygen.org/commands.html for
//              Special Commands used by doxygen tool to create documentation.
////////////////////////////////////////////////////////////////////////////////
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
//
/// Struct of bits used by MPG2VD various registers
static const struct EAS_RegBits g_csr_MPG2VD_Streams[] =
{
    { "reserved_31_2",                  2, 30,"",NULL},
    { "Stream1",                        1,  1,"",NULL},
    { "Stream0",                        0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// Struct of bits used by MPG2VD SED register
static const struct EAS_RegBits g_csr_MPG2VD_SED[] =
{
    { "reserved_31_4",                  4, 28,"",NULL},
    { "ByteSwap1",                      3,  1,"",NULL},
    { "ByteSwap0",                      2,  1,"",NULL},
    { "Stream1",                        1,  1,"",NULL},
    { "Stream0",                        0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// Struct of bits used by the MPEG2 decoder Stream DMA Engine Master Control Register: SDEMC
static const struct EAS_RegBits g_csr_MPG2VD_SDEMC[] =
{
    { "reserved_31_16",                16, 16,"",NULL},
    { "DMAStream1LLPauseModeStatus",   15,  1,"",NULL},
    { "DMAStream0LLPauseModeStatus",   14,  1,"",NULL},
    { "DMAStream1LinearFetchMode",     13,  1,"",NULL},
    { "DMAStream0LinearFetchMode",     12,  1,"",NULL},
    { "DMAStream1LLPauseMode",         11,  1,"",NULL},
    { "DMAStream0LLPauseMode",         10,  1,"",NULL},
    { "DMAStream1MaxBurst32Bytes",      9,  1,"",NULL},
    { "DMAStream0MaxBurst32Bytes",      8,  1,"",NULL},
    { "DMAStream1LinkedListMode",       7,  1,"",NULL},
    { "DMAStream0LinkedListMode",       6,  1,"",NULL},
    { "DMAStream1FIFOEmpty",            5,  1,"Default b1",NULL},
    { "DMAStream0FIFOEmpty",            4,  1,"Default b1",NULL},
    { "FlushDMAStream1",                3,  1,"",NULL},
    { "FlushDMAStream0",                2,  1,"",NULL},
    { "StartDMAStream1",                1,  1,"",NULL},
    { "StartDMAStream0",                0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// Struct of bits used by the MPEG2 decoder Core Control Registers: S0CC S1CC
static const struct EAS_RegBits g_csr_MPG2VD_CoreControl[] =
{
    { "reserved_31_13",                 13, 19,"",NULL},
    { "DoingDecode",                    12, 1,"",NULL},
    { "reserved_11_10",                 10, 2,"",NULL},
    { "PIPScalarMode",                  8,  2,"",NULL}, // 9:8
    { "reserved_7_5",                   5,  3,"",NULL}, // 7:5
    { "ElementaryStreamMask",           4,  1,"",NULL},
    { "reserved_3_2",                   2,  2,"",NULL}, // 3:2
    { "ProgressiveRefreshEnable",       1,  1,"",NULL},
    { "ResetCore",                      0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// Struct of bits used by the MPEG2 decoder Interupt Mask registers: IM0 IM1
/// and MPG2V decoder Interupt Status registers: IS0 IS1
static const struct EAS_RegBits g_csr_MPG2VD_Interupts[] =
{
    // 31:23 DECODER_INTERRUPTS
    { "StallPictEnd",                   31, 1,"",NULL},
    { "StallPictBegin",                 30, 1,"",NULL},
    { "StallGOPAfter",                  29, 1,"",NULL},
    { "StallSeqBegin",                  28, 1,"",NULL},
    { "PictureBroken",                  27, 1,"",NULL},
    { "VidRecover",                     26, 1,"",NULL},
    { "ASDBufferOverflow",              25, 1,"",NULL},
    { "HaveASD",                        24, 1,"",NULL},
    { "FrameDone",                      23, 1,"",NULL},

    { "reserved_22_21",                 21, 2,"",NULL},

    // 20:13 FBM_INTERRUPTS
    { "FrameDroppedDueToVDCKeepOut",    20, 1,"",NULL},
    { "PresentToDisplayDetected",       19, 1,"",NULL},
    { "ProgressiveSequence",            18, 1,"",NULL},
    { "HorizontalSize",                 17, 1,"",NULL},
    { "VerticalSize",                   16, 1,"",NULL},
    { "FrameRateCode",                  15, 1,"",NULL},
    { "AspectRatioChange",              14, 1,"",NULL},
    { "Chroma420Frame",                 13, 1,"",NULL},

    //  9:7  DMA
    { "reserved_12",                    12, 1,"",NULL},
    { "STCCounterTimeout",              11, 1,"",NULL},
    { "CanDisplay",                     10, 1,"",NULL},

    { "CircularOrLinearBufferEmpty",    9, 1,"",NULL},
    { "CircularBufferAlmostEmpty",      8, 1,"",NULL},
    { "LinkedListIntrBitInDesc",        7, 1,"",NULL},

    //  6:0  PES_INTERRUPTS
    { "EndOfParsingCurrentPacket",      6,  1,"",NULL},
    { "DiscontinuityPacketFound",       5,  1,"",NULL},
    { "PTSFound",                       4,  1,"",NULL},
    { "ext_fifo_data",                  3,  1,"",NULL},
    { "ext_fifo_service",               2,  1,"",NULL},
    { "timeout_s",                      1,  1,"",NULL},
    { "timeout_d",                      0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
//
/// Struct of bits used by the MPEG2 decoder Stall Mask registers: S0SM S1SM
static const struct EAS_RegBits g_csr_MPG2VD_StallMask[] =
{
    { "reserved_31_5",                  5, 27,"",NULL},
    { "Skip_B_Pictures",                4,  1,"",NULL},
    { "STALL_PICT_END",                 3,  1,"",NULL},
    { "STALL_PICT_BEGIN",               2,  1,"",NULL},
    { "STALL_GOP_AFTER",                1,  1,"",NULL},
    { "STALL_SEQ_BEGIN",                0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// Struct of bits used by the MPEG2 decoder Stall Control registers: S0SC S1SC
static const struct EAS_RegBits g_csr_MPG2VD_StallControl[] =
{
    { "reserved_31_2",                  2, 30,"",NULL},
    { "SkipToNext",                     1,  1,"",NULL},
    { "StallContinue",                  0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// Struct of bits used by the FBM Buffer Info registers: FBM0BI FBM1BI
static const struct EAS_RegBits g_csr_FBM_BufferInfo[] =
{
    { "reserved_31_23",                23,  9,"",NULL},
    { "Discontinuity",                 22,  1,"",NULL},
    { "ProgSeq",                       21,  1,"",NULL},
    { "ProgFrame",                     20,  1,"",NULL},
    { "PictStruct",                    18,  2,"",NULL}, // 18:19
    { "TopFieldFirst",                 17,  1,"",NULL},
    { "ReptFirstField",                16,  1,"",NULL},
    { "SequenceNumber",                 6, 10,"",NULL}, // 15:6
    { "FwdRefFrame",                    5,  1,"",NULL},
    { "BwdRefFrame",                    4,  1,"",NULL},
    { "InDisplayQueue",                 3,  1,"",NULL},
    { "DecoderLocked",                  2,  1,"",NULL},
    { "PictureCodingType",              0,  2,"",NULL}, // 1:0
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};


//
/// Struct of bits used by the FBM Buffer Display Queue Status: FBM0DQS FBM1DQS
static const struct EAS_RegBits g_csr_FBM_DisplayQueueStatus[] =
{
    { "reserved_31_14",                14, 18,"",NULL},
    { "SWDisplayQNotEmpty",            13,  1,"",NULL},
    { "HWDisplayQNotEmpty",            12,  1,"",NULL},
    { "DecodeInProgress",              11,  1,"",NULL},
    { "reserved_10",                   10,  1,"",NULL}, 
    { "CanDisplayBuffer",               5,  5,"Valid while decoding and with STALL_PICT_END",NULL},
    { "CurDecodeBuffer",                0,  5,"Valid while decoding and with STALL_PICT_END",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};


//
/// Struct of bits used by the FBM Buffer Resolution Info registers: FBM0BRI FBM1BRI
static const struct EAS_RegBits g_csr_FBM_BufferResInfo[] =
{
    { "ProgSequence",                  31,  1,"",NULL},
    { "HorizontalSize",                20, 11,"",NULL}, // 30:20
    { "VerticalSize",                   9, 11,"",NULL}, // 19:9
    { "FrameRateCode",                  5,  4,"",NULL}, //  8:5
    { "AspectRatioInfo",                1,  4,"",NULL}, //  4:1
    { "Chroma420",                      0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// Struct of bits used by the Stream 0/1 FIFO Status register: SDFSTAT
static const struct EAS_RegBits g_csr_MPG2VD_SDFSTAT[] =
{
    { "reserved_31_8",                  8, 24,"",NULL},
    { "Stream1FSMIdle",                 7,  1,"",NULL},
    { "Stream1PESStall",                6,  1,"",NULL},
    { "Stream1SyncFIFOEmpty",           5,  1,"",NULL},
    { "Stream1AsyncFIFOEmpty",          4,  1,"",NULL},
    { "Stream0FSMIdle",                 3,  1,"",NULL},
    { "Stream0PESStall",                2,  1,"",NULL},
    { "Stream0SyncFIFOEmpty",           1,  1,"",NULL},
    { "Stream0AsyncFIFOEmpty",          0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// Struct of bits used by the PES Packet Parser Control register: PPCR
static const struct EAS_RegBits g_csr_MPG2VD_PPCR[] =
{
    { "PESERRCLR",                     31,  1,"SW error clear",NULL},
    { "PESEN",                         30,  1,"Parser Enable",NULL},
    { "PESBP",                         29,  1,"Parser Bypass",NULL},
    { "Decoder_Flush",                 28,  1,"",NULL},
    { "NFlush",                        27,  1,"",NULL},
    { "STCCLR",                        26,  1,"",NULL},
    { "reserved_25_24",                24,  2,"",NULL},
    { "STRMID_8_EN",                   23,  1,"",NULL},
    { "STRMID_8_DS",                   22,  1,"",NULL},
    { "STRMID_7_EN",                   21,  1,"",NULL},
    { "STRMID_7_DS",                   20,  1,"",NULL},
    { "STRMID_6_EN",                   19,  1,"",NULL},
    { "STRMID_6_DS",                   18,  1,"",NULL},
    { "STRMID_5_EN",                   17,  1,"",NULL},
    { "STRMID_5_DS",                   16,  1,"",NULL},
    { "STRMID_4_EN",                   15,  1,"",NULL},
    { "STRMID_4_DS",                   14,  1,"",NULL},
    { "STRMID_3_EN",                   13,  1,"",NULL},
    { "STRMID_3_DS",                   12,  1,"",NULL},
    { "STRMID_2_EN",                   11,  1,"",NULL},
    { "STRMID_2_DS",                   10,  1,"",NULL},
    { "STRMID_1_EN",                    9,  1,"Prog Startcode ID 1 enable",NULL},
    { "STRMID_1_DS",                    8,  1,"Discont id for start code ID 1",NULL},
    { "reserved_7_6",                   6,  2,"",NULL},
    { "EXT_FIFO_TH",                    0,  6,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

//
/// Struct of bits used by the Stream 0/1 STC Control register: STC_CTRL
static const struct EAS_RegBits g_csr_MPG2VD_STC_CTRL[] =
{
    { "reserved_31_10",                10, 22,"",NULL},
    { "DisableSTCCounter",              9,  1,"",NULL},
    { "VDC_STC_SampleSelect",           8,  1,"",NULL},
    { "Counter90KhzPrescalerSelect",    7,  1,"",NULL},
    { "PrefilterClockSelect",           5,  2,"",NULL},
    { "STC_CNT_ACTIVE",                 4,  1,"",NULL},
    { "CounterTimeoutEnable",           3,  1,"",NULL},
    { "CounterTimeoutMode",             2,  1,"",NULL},
    { "SwitchControl",                  0,  2,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MPG2VD_versions.
 */
static const struct EAS_Register g_csr_GEN2_MPG2VD[] =
{
    /* GLOBAL TOP LEVEL REGISTERS */
    CSR_REG("MDRC",        0x000, "Reset MPEG2 Decoder Data path")
    CSR_REG_W_BB("SED",    0x004, g_csr_MPG2VD_SED, "Stream Enable/Disable")
    CSR_REG_W_BB("SAS",    0x008, g_csr_MPG2VD_Streams, "Stream Active Status")
    CSR_REG_W_BB("SDEMC",  0x00c, g_csr_MPG2VD_SDEMC,   "Stream DMA Engine Master Control")
    CSR_REG_W_BB("IM0",    0x010, g_csr_MPG2VD_Interupts, "Interrupt Mask Stream 0")
    CSR_REG_W_BB("IM1",    0x014, g_csr_MPG2VD_Interupts, "Interrupt Mask Stream 1")
    CSR_REG_W_BB("IS",     0x018, g_csr_MPG2VD_Streams, "Interrupt Status")
    CSR_REG_W_BB("IS0",    0x01c, g_csr_MPG2VD_Interupts, "Interrupt Status Stream 0")
    CSR_REG_W_BB("IS1",    0x020, g_csr_MPG2VD_Interupts, "Interrupt Status Stream 0")
    CSR_REG("INTCR0",      0x024, "Interrupt Counter Stream 0")
    CSR_REG("INTCR1",      0x028, "Interrupt Counter Stream 1")
    CSR_REG_W_BB("PWRSED", 0x030, g_csr_MPG2VD_Streams, "Stream Enable(1)/Disable(0) for (VR) Power Savings ") // Not in Olo

    /* STREAM 0 - ELEMENTARY STREAM DECODER REGISTERS */
    CSR_REG_W_BB("S0CC",   0x100, g_csr_MPG2VD_CoreControl, "Decoder 0 Core Control")
    CSR_REG_W_BB("S0SM",   0x104, g_csr_MPG2VD_StallMask, "Decoder 0 Core Stall Mask")
    CSR_REG_W_BB("S0SS",   0x108, g_csr_MPG2VD_StallMask, "Decoder 0 Core Stall Status")
    CSR_REG_W_BB("S0SC",   0x10c, g_csr_MPG2VD_StallControl, "Decoder 0 Core Stall Control")
    CSR_REG("S0ASDBC",     0x110, "Decoder 0 Core Additional Stream Data Buffer Configuration")
    CSR_REG("S0ASDFP",     0x114, "Decoder 0 Core Additional Stream Data Front Pointer")
    CSR_REG("S0ASDBP",     0x118, "Decoder 0 Core Additional Stream Data Back Pointer")
    CSR_REG("S0ASDR",      0x11c, "Decoder 0 Core Additional Stream Data Read")
    CSR_REG("S0SI1",       0x120, "Decoder 0 Core Sequence Info 1")
    CSR_REG("S0SI2",       0x124, "Decoder 0 Core Sequence Info 2")
    CSR_REG("S0SI3",       0x128, "Decoder 0 Core Sequence Info 3")
    CSR_REG("S0SI4",       0x12c, "Decoder 0 Core Sequence Info 4")
    CSR_REG("S0PI1",       0x130, "Decoder 0 Core Picture Info 1")
    CSR_REG("S0PI2",       0x134, "Decoder 0 Core Picture Info 2")
    CSR_REG("S0PI3",       0x138, "Decoder 0 Core Picture Info 3")
    CSR_REG("S0PCE",       0x13c, "Decoder 0 Core Picture Coding Extension with Composite Display Flag Set")
    CSR_REG("S0SDE1",      0x140, "Decoder 0 Core Sequence Display Extension 1")
    CSR_REG("S0SDE2",      0x144, "Decoder 0 Core Sequence Display Extension 2")
    CSR_REG("S0GH",        0x148, "Decoder 0 Core GOP Header")

    /* STREAM 1 - ELEMENTARY STREAM DECODER REGISTERS */
    CSR_REG_W_BB("S1CC",   0x180, g_csr_MPG2VD_CoreControl, "Decoder 1 Core Control")
    CSR_REG_W_BB("S1SM",   0x184, g_csr_MPG2VD_StallMask, "Decoder 1 Core Stall Mask")
    CSR_REG_W_BB("S1SS",   0x188, g_csr_MPG2VD_StallMask, "Decoder 1 Core Stall Status")
    CSR_REG_W_BB("S1SC",   0x18c, g_csr_MPG2VD_StallControl, "Decoder 1 Core Stall Control")
    CSR_REG("S1ASDBC",     0x190, "Decoder 1 Core Additional Stream Data Configuration")
    CSR_REG("S1ASDFP",     0x194, "Decoder 1 Core Additional Stream Data Front Pointer")
    CSR_REG("S1ASDBP",     0x198, "Decoder 1 Core Additional Stream Data Back Pointer")
    CSR_REG("S1ASDR",      0x19c, "Decoder 1 Core Additional Stream Data Read")
    CSR_REG("S1SI1",       0x1a0, "Decoder 1 Core Sequence Info 1")
    CSR_REG("S1SI2",       0x1a4, "Decoder 1 Core Sequence Info 2")
    CSR_REG("S1SI3",       0x1a8, "Decoder 1 Core Sequence Info 3")
    CSR_REG("S1SI4",       0x1ac, "Decoder 1 Core Sequence Info 4")
    CSR_REG("S1PI1",       0x1b0, "Decoder 1 Core Picture Info 1")
    CSR_REG("S1PI2",       0x1b4, "Decoder 1 Core Picture Info 2")
    CSR_REG("S1PI3",       0x1b8, "Decoder 1 Core Picture Info 3")
    CSR_REG("S1PCE",       0x1bc, "Decoder 1 Core Picture Coding Extension with Composite Display Flag Set")
    CSR_REG("S1SDE1",      0x1c0, "Decoder 1 Core Sequence Display Extension 1")
    CSR_REG("S1SDE2",      0x1c4, "Decoder 1 Core Sequence Display Extension 2")
    CSR_REG("S1GH",        0x1c8, "Decoder 1 Core GOP Header")

    /* STREAM 0 - FBM REGISTERS */
    CSR_REG("FBM0BE",      0x200, "FBM Master Buffer Enables")
    CSR_REG("FBM0PAP",     0x204, "FBM Buffer Pool Address Pointer")
    CSR_REG("FBM0YBA",     0x208, "FBM Y Buffer Address")
    CSR_REG("FBM0UVBA",    0x20c, "FBM UV Buffer Address")
    CSR_REG("FBM0PYBA",    0x210, "FBM PIP Y Buffer Address")
    CSR_REG("FBM0PUVBA",   0x214, "FBM PIP UV Buffer Address")
    CSR_REG_W_BB("FBM0BI", 0x218, g_csr_FBM_BufferInfo,   "FBM Buffer Info")
    CSR_REG_W_BB("FBM0BRI",0x21c, g_csr_FBM_BufferResInfo, "FBM Buffer Resolution Info")
    CSR_REG("FBM0GC",      0x220, "FBM General Control")
    CSR_REG("FBM0TDR",     0x224, "FBM Tracker Display Queue Release")
    CSR_REG("FBM0DQS",     0x228, "FBM Output Queue Status")
    CSR_REG("FBM0DQPO",    0x22c, "FBM Output Queue Entries")

    /* New registers added 1/9/2006 ~JWC */
    CSR_REG("FBM0PTSC",    0x230, "FBM PTS Control")
    CSR_REG("FBM0PTVM",    0x234, "FBM PTS Table (MSB)")
    CSR_REG("FBM0PTVL",    0x238, "FBM PTS Table (LSB)")
    CSR_REG("FBM0PTSOM",   0x23c, "FBM PTS Offset (MSB)")
    CSR_REG("FBM0PTSOL",   0x240, "FBM PTS Offset (LSB)")
    CSR_REG("FBM0PTSAM",   0x244, "FBM PTS Accum Init Value (MSB)")
    CSR_REG("FBM0PTSAL",   0x248, "FBM PTS Accum Init Value (LSB)")
    CSR_REG("FBM0PTSASM",  0x24c, "FBM PTS Accum Step Size (MSB)")
    CSR_REG("FBM0PTSASL",  0x250, "FBM PTS Accum Step Size (LSB)")
    CSR_REG("FBM0DYR",     0x254, "FBM Destination Y Buffer Register Address")
    CSR_REG("FBM0DUVR",    0x258, "FBM Destination UV Buffer Register Address")
    CSR_REG("FBM0DFMR",    0x25c, "FBM Destination flip mode Register Address")
    CSR_REG("FBM0NDB",     0x260, "FBM Next Display Buffer")
    CSR_REG("FBM0NDBR",    0x264, "FBM Next Display Buffer Resolution")
    CSR_REG("FBM0PSCO1",   0x268, "FBM Pan Scan Frame Center Offset 1")
    CSR_REG("FBM0PSCO2",   0x26c, "FBM Pan Scan Frame Center Offset 2")
    CSR_REG("FBM0PSCO3",   0x270, "FBM Pan Scan Frame Center Offset 3")
    CSR_REG("FBM0SQY",     0x274, "FBM Software Queue Y Address")
    CSR_REG("FBM0SQUV",    0x278, "FBM Software Queue UV Address")
    CSR_REG("FBM0SQPM",    0x27c, "FBM Software Queue PTS Value (MSB)")
    /* End registers added 1/9/2006 */

    CSR_REG("FBM0SQPL",    0x280, "FBM Software Queue PTS value (LSB)")
    CSR_REG("FBM0FQCS",    0x284, "FBM Buffer Software Queue Control Status")
    CSR_REG("FBM0PEDA",    0x288, "FBM PES Extension DMA Address")
    CSR_REG("FBM0UEDA",    0x28C, "FBM User Extension DMA Address")
    CSR_REG("FBM0PEDS",    0x290, "FBM PES Extension DMA Size")
    CSR_REG("FBM0UEDS",    0x294, "FBM User Extension DMA Size")
    CSR_REG("FBM0PEO",     0x298, "FBM PES Extension Overflow")
    CSR_REG("FBM0UEO",     0x29C, "FBM User Extension Overflow")
    CSR_REG("FBM0EC1",     0x2A0, "FBM End_Code_1")
    CSR_REG("FBM0EC2",     0x2A4, "FBM End Code 2")
    CSR_REG("FBM0GC2",     0x2A8, "FBM General Control 2")
    CSR_REG("FBM0SW",      0x2AC, "FBM Stride Width")
    CSR_REG("FBM0META0",   0x2B0, "FBM Metadata 0")
    CSR_REG("FBM0META1",   0x2B4, "FBM Metadata 1")
    CSR_REG("FBM0META2",   0x2B8, "FBM Metadata 2")
    CSR_REG("FBM0META3",   0x2BC, "FBM Metadata 3")
    CSR_REG("FBM0META4",   0x2C0, "FBM Metadata 4")
    CSR_REG("FBM0META5",   0x2C4, "FBM Metadata 5")
    CSR_REG("FBM0CDT",     0x2C8, "FBM Can Display Threshold")
    CSR_REG("FBM0BDRI",    0x2CC, "FBM Buffer Display Resolution Info")
    CSR_REG("FBM0DYVPRA",  0x2D0, "FBM Destination Y Vertical Phase Register Address")
    CSR_REG("FBM0SQYVP",   0x2D4, "FBM Software Queue Y Vertical Phase")
    CSR_REG("FBM0DUVVPR",  0x2D8, "FBM Destination UV Vertical Phase Register")
    CSR_REG("FBM0SQUVVP",  0x2DC, "FBM Software Queue UV Vertical Phase")
    CSR_REG("FBM0DHPRA",   0x2E0, "FBM Destination Horizontal Phase Register Address")
    CSR_REG("FBM0SQHP",    0x2E4, "FBM Software Queue Horizontal Phase")
    CSR_REG("FBM0DIPSR",   0x2E8, "FBM Destination Initial Phase Shift Register")
    CSR_REG("FBM0SQIPS",   0x2EC, "FBM Software Queue Initial Phase Shift")

    /* STREAM 1 - FBM REGISTERS */
    CSR_REG("FBM1BE",      0x300, "FBM Master Buffer Enables")
    CSR_REG("FBM1PAP",     0x304, "FBM Buffer Pool Address Pointer")
    CSR_REG("FBM1YBA",     0x308, "FBM Y Buffer Address")
    CSR_REG("FBM1UVBA",    0x30c, "FBM UV Buffer Address")
    CSR_REG("FBM1PYBA",    0x310, "FBM PIP Y Buffer Address ")
    CSR_REG("FBM1PUVBA",   0x314, "FBM PIP UV Buffer Address ")
    CSR_REG_W_BB("FBM1BI", 0x318, g_csr_FBM_BufferInfo, "FBM Buffer Info")
    CSR_REG_W_BB("FBM1BRI",0x31c, g_csr_FBM_BufferResInfo, "FBM Buffer Resolution Info")
    CSR_REG("FBM1GC",      0x320, "FBM General Control")
    CSR_REG("FBM1TDR",     0x324, "FBM Tracker Display Queue Release")
    CSR_REG("FBM1DQS",     0x328, "FBM Display Queue Status")
    CSR_REG("FBM1DQPO",    0x32c, "FBM Display Queue Entries")
    CSR_REG("FBM1PTSC",    0x330, "FBM PTS Control")
    CSR_REG("FBM1PTVM",    0x334, "FBM PTS Table (MSB)")
    CSR_REG("FBM1PTVL",    0x338, "FBM PTS Table (LSB)")
    CSR_REG("FBM1PTSOM",   0x33c, "FBM PTS Offset (MSB)")
    CSR_REG("FBM1PTSOL",   0x340, "FBM PTS Offset (LSB)")
    CSR_REG("FBM1PTSAM",   0x344, "FBM PTS Accum Init Value (MSB)")
    CSR_REG("FBM1PTSAL",   0x348, "FBM PTS Accum Init Value (LSB)")
    CSR_REG("FBM1PTSASM",  0x34c, "FBM PTS Accum Step Size (MSB)")
    CSR_REG("FBM1PTSASL",  0x350, "FBM PTS Accum Step Size (LSB)")
    CSR_REG("FBM1DYR",     0x354, "FBM Destination Y Buffer Register Address")
    CSR_REG("FBM1DUVR",    0x358, "FBM Destination UV Buffer Register Address")
    CSR_REG("FBM1DFMR",    0x35c, "FBM Destination flip mode Register Address")
    CSR_REG("FBM1NDB",     0x360, "FBM Next Display Buffer")
    CSR_REG("FBM1NDBR",    0x364, "FBM Next Display Buffer Resolution")
    CSR_REG("FBM1PSCO1",   0x368, "FBM Pan Scan Frame Center Offset 1")
    CSR_REG("FBM1PSCO2",   0x36c, "FBM Pan Scan Frame Center Offset 2")
    CSR_REG("FBM1PSCO3",   0x370, "FBM Pan Scan Frame Center Offset 3")
    CSR_REG("FBM1SQY",     0x374, "FBM Software Queue Y Address")
    CSR_REG("FBM1SQUV",    0x378, "FBM Software Queue UV Address")
    CSR_REG("FBM1SQPM",    0x37c, "FBM Software Queue PTS Value (MSB)")
    CSR_REG("FBM1SQPL",    0x380, "FBM Software Queue PTS value (LSB)")
    CSR_REG("FBM1FQCS",    0x384, "FBM Buffer Software Queue Control Status")
    CSR_REG("FBM1PEDA",    0x388, "FBM PES Extension DMA Address")
    CSR_REG("FBM1UEDA",    0x38C, "FBM User Extension DMA Address")
    CSR_REG("FBM1PEDS",    0x390, "FBM PES Extension DMA Size")
    CSR_REG("FBM1UEDS",    0x394, "FBM User Extension DMA Size")
    CSR_REG("FBM1PEO",     0x398, "FBM PES Extension Overflow")
    CSR_REG("FBM1UEO",     0x39C, "FBM User Extension Overflow")
    CSR_REG("FBM1EC1",     0x3A0, "FBM End_Code_1")
    CSR_REG("FBM1EC2",     0x3A4, "FBM End Code 2")
    CSR_REG("FBM1GC2",     0x3A8, "FBM General Control 2")
    CSR_REG("FBM1SW",      0x3AC, "FBM Stride Width")
    CSR_REG("FBM1META0",   0x3B0, "FBM Metadata 0")
    CSR_REG("FBM1META1",   0x3B4, "FBM Metadata 1")
    CSR_REG("FBM1META2",   0x3B8, "FBM Metadata 2")
    CSR_REG("FBM1META3",   0x3BC, "FBM Metadata 3")
    CSR_REG("FBM1META4",   0x3C0, "FBM Metadata 4")
    CSR_REG("FBM1META5",   0x3C4, "FBM Metadata 5")
    CSR_REG("FBM1CDT",     0x3C8, "FBM Can Display Threshold")
    CSR_REG("FBM1BDRI",    0x3CC, "FBM Buffer Display Resolution Info")
    CSR_REG("FBM1DYVPRA",  0x3D0, "FBM Destination Y Vertical Phase Register Address")
    CSR_REG("FBM1SQYVP",   0x3D4, "FBM Software Queue Y Vertical Phase")
    CSR_REG("FBM1DUVVPR",  0x3D8, "FBM Destination UV Vertical Phase Register")
    CSR_REG("FBM1SQUVVP",  0x3DC, "FBM Software Queue UV Vertical Phase")
    CSR_REG("FBM1DHPRA",   0x3E0, "FBM Destination Horizontal Phase Register Address")
    CSR_REG("FBM1SQHP",    0x3E4, "FBM Software Queue Horizontal Phase")
    CSR_REG("FBM1DIPSR",   0x3E8, "FBM Destination Initial Phase Shift Register")
    CSR_REG("FBM1SQIPS",   0x3EC, "FBM Software Queue Initial Phase Shift")

    /* STREAM 0 - PES PACKET PARSER REGISTERS */
    CSR_REG("PPTCR0",      0x400, "PES Packet Parser 0 Timer Control Register")
    CSR_REG_W_BB("PPCR0",  0x404, g_csr_MPG2VD_PPCR, "PES Packet Parser 0 Control Register")
    CSR_REG("PPSR0",       0x408, "PES Packet Parser 0 Status Register")
    CSR_REG("PPIDR0",      0x40c, "PES Packet Parser 0 Status ID Register")
    CSR_REG("PPDR10",      0x410, "PES Packet Parser 0 Data Register 1")
    CSR_REG("PPDR20",      0x414, "PES Packet Parser 0 Data Register 2")
    CSR_REG("PPDR30",      0x418, "PES Packet Parser 0 Data Register 3")
    CSR_REG("PPDR40",      0x41c, "PES Packet Parser 0 Data Register 4")
    CSR_REG("PPDR50",      0x420, "PES Packet Parser 0 Data Register 5")
    CSR_REG("PPDR60",      0x424, "PES Packet Parser 0 Data Register 6")
    CSR_REG("PPDR70",      0x428, "PES Packet Parser 0 Data Register 7")
    CSR_REG("PPEDR0",      0x42c, "PES Packet Parser 0 Extension Data Register")
    CSR_REG("PPSC10",      0x430, "PES Packet Parser 0 Programmable Start Codes 1")
    CSR_REG("PPSC20",      0x434, "PES Packet Parser 0 Programmable Start Codes 2")
    CSR_REG("PDOSM0",      0x438, "PES Packet Parser 0 Discontinuity Old STC (MSB)")
    CSR_REG("PDOSL0",      0x43c, "PES Packet Parser 0 Discontinuity Old STC (LSB)")
    CSR_REG("PDNSM0",      0x440, "PES Packet Parser 0 Discontinuity NEW STC (MSB)")
    CSR_REG("PDNSL0",      0x444, "PES Packet Parser 0 Discontinuity NEW STC (LSB)")

    /* STREAM 1 - PES PACKET PARSER REGISTERS */
    CSR_REG("PPTCR1",      0x480, "PES Packet Parser 1 Timer Control Register")
    CSR_REG_W_BB("PPCR1",  0x484, g_csr_MPG2VD_PPCR, "PES Packet Parser 1 Control Register")
    CSR_REG("PPSR1",       0x488, "PES Packet Parser 1 Status Register")
    CSR_REG("PPIDR1",      0x48c, "PES Packet Parser 1 Status ID Register")
    CSR_REG("PPDR11",      0x490, "PES Packet Parser 1 Data Register 1")
    CSR_REG("PPDR21",      0x494, "PES Packet Parser 1 Data Register 2")
    CSR_REG("PPDR31",      0x498, "PES Packet Parser 1 Data Register 3")
    CSR_REG("PPDR41",      0x49c, "PES Packet Parser 1 Data Register 4")
    CSR_REG("PPDR51",      0x4a0, "PES Packet Parser 1 Data Register 5")
    CSR_REG("PPDR61",      0x4a4, "PES Packet Parser 1 Data Register 6")
    CSR_REG("PPDR71",      0x4a8, "PES Packet Parser 1 Data Register 7")
    CSR_REG("PPEDR1",      0x4ac, "PES Packet Parser 1 Extension Data Register")
    CSR_REG("PPSC11",      0x4b0, "PES Packet Parser 1 Programmable Start Codes 1")
    CSR_REG("PPSC21",      0x4b4, "PES Packet Parser 1 Programmable Start Codes 2")
    CSR_REG("PDOSM1",      0x4b8, "PES Packet Parser 1 Discontinuity Old STC (MSB)")
    CSR_REG("PDOSL1",      0x4bc, "PES Packet Parser 1 Discontinuity Old STC (LSB)")
    CSR_REG("PDNSM1",      0x4c0, "PES Packet Parser 1 Discontinuity NEW STC (MSB)")
    CSR_REG("PDNSL1",      0x4c4, "PES Packet Parser 1 Discontinuity NEW STC (LSB)")

    /* STREAM 0 - DMA ENGINE REGISTERS */
    CSR_REG("SD0CBBA",     0x500, "Stream 0 DMA Circular/Linear Buffer Base Address")
    CSR_REG("SD0SBRP",     0x504, "Stream 0 DMA Source Block Register Address of Read Pointer")
    CSR_REG("SD0CBS",      0x508, "Stream 0 DMA Circular/Linear Buffer Size")
    CSR_REG("SD0PDV",      0x50c, "Stream 0 DMA Read/Write Pointer Watermark")
    CSR_REG("SD0WT",       0x510, "Stream 0 DMA Watchdog Timer")
    CSR_REG("SD0LRP",      0x514, "Stream 0 DMA Local Read Pointer")
    CSR_REG("SD0LWP",      0x518, "Stream 0 DMA Local Write Pointer")
    CSR_REG("SD0LINK",     0x51c, "Stream 0 DMA Link Address")
    CSR_REG("SD0LLSA",     0x520, "Stream 0 DMA Link List Source Address")
    CSR_REG("SD0LNDA",     0x524, "Stream 0 DMA Link List Next Descriptor Address")
    CSR_REG("SD0LDBC",     0x528, "Stream 0 DMA Link List Data Buffer Byte Count")
    CSR_REG("SD0LCBC",     0x52c, "Stream 0 DMA Link List Current Data Buffer Byte Count")
    CSR_REG("SD0LDC",      0x530, "Stream 0 DMA Link List Descriptor Control")

    /* STREAM 1 - DMA ENGINE REGISTERS */
    CSR_REG("SD1CBBA",     0x580, "Stream 1 DMA Circular/Linear Buffer Base Address")
    CSR_REG("SD1SBRP",     0x584, "Stream 1 DMA Source Block Register Address of Read Pointer")
    CSR_REG("SD1CBS",      0x588, "Stream 1 DMA Circular/Linear Buffer Size")
    CSR_REG("SD1PDV",      0x58c, "Stream 1 DMA Read/Write Pointer Watermark")
    CSR_REG("SD1WT",       0x590, "Stream 1 DMA Watchdog Timer")
    CSR_REG("SD1LRP",      0x594, "Stream 1 DMA Local Read Pointer")
    CSR_REG("SD1LWP",      0x598, "Stream 1 DMA Local Write Pointer")
    CSR_REG("SD1LINK",     0x59c, "Stream 1 DMA Link Address")
    CSR_REG("SD1LLSA",     0x5a0, "Stream 1 DMA Link List Source Address")
    CSR_REG("SD1LNDA",     0x5a4, "Stream 1 DMA Link List Next Descriptor Address")
    CSR_REG("SD1LDBC",     0x5a8, "Stream 1 DMA Link List Data Buffer Byte Count")
    CSR_REG("SD1LCBC",     0x5ac, "Stream 1 DMA Link List Current Data Buffer Byte Count")
    CSR_REG("SD1LDC",      0x5b0, "Stream 1 DMA Link List Descriptor Control")

    CSR_REG("SD0FWP",      0x700, "Stream 0 FIFO input")
    CSR_REG("SD1FWP",      0x704, "Stream 1 FIFO input")
    CSR_REG_W_BB("SDFSTAT",0x708, g_csr_MPG2VD_SDFSTAT, "FIFO Status")

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_GEN2_MPG2VD_specific_events[] =
{
    { "INTERRUPT_OCCURED",  1,      "mpg2vd has an interrupt to service",   NULL },
    { "CAN_DISPLAY",        2,      "mpg2vd has a frame ready for display", NULL },
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN2_MPG2VD_sven_module =
{
    "GEN2_MPG2VD",
    SVEN_module_GEN2_MPG2VD,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN2_MPG2VD,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: MPG2VD Function (GEN2)",
    g_GEN2_MPG2VD_specific_events,
    NULL                            /* extension list */
};
