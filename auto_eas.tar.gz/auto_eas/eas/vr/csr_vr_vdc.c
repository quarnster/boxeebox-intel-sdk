/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Bitwise Breakups of GPU registers */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

#ifdef SVEN_INTERNAL_BUILD
static const struct EAS_RegBits g_csr_VDC_HTOTAL_A[] =
{
    { "RSVD_31_29", 29, 3, "", NULL },
    { "HTOTAL", 16, 13, "", NULL },
    { "RSVD_15_13", 13, 3, "", NULL },
    { "HACTIVE", 0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_HBLANK_A[] =
{
    { "RSVD_31_29", 29, 3, "", NULL },
    { "HBLANK_END", 16, 13, "", NULL },
    { "RSVD_15_13", 13, 3, "", NULL },
    { "HBLANK_START", 0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_HSYNC_A[] =
{
    { "RSVD_31_29", 29, 3, "", NULL },
    { "HSYNC_END", 16, 13, "", NULL },
    { "RSVD_15_13", 13, 3, "", NULL },
    { "HSYNC_START", 0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_VTOTAL_A[] =
{
    { "RSVD_31_29", 29, 3, "", NULL },
    { "VTOTAL", 16, 13, "", NULL },
    { "RSVD_15_13", 13, 3, "", NULL },
    { "VACTIVE", 0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_VBLANK_A[] =
{
    { "RSVD_31_29", 29, 3, "", NULL },
    { "VBLANK_END", 16, 13, "", NULL },
    { "RSVD_15_13", 13, 3, "", NULL },
    { "VBLANK_START", 0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_VSYNC_A[] =
{
    { "RSVD_31_29", 29, 3, "", NULL },
    { "VSYNC_END", 16, 13, "", NULL },
    { "RSVD_15_13", 13, 3, "", NULL },
    { "VSYNC_START", 0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_PIPEASRC[] =
{
    { "RSVD_31_28", 28, 4, "", NULL },
    { "HSRC_SZ", 16, 12, "", NULL },
    { "RSVD_15_12", 12, 4, "", NULL },
    { "VSRC_SZ", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_CANVSCLR_A[] =
{
    { "RSVD_31_30", 30, 2, "", NULL },
    { "RED", 20, 10, "RED", NULL },
    { "GREEN", 10, 10, "GREEN", NULL },
    { "BLUE", 0, 10, "BLUE", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_PVOCONFIG[] =
{
    { "RSVD_31", 31, 1, "MDVO_Enable - Write as 1", NULL },
    { "RSVD_30", 30, 1, "PVO_TV_TEST - Write as 0", NULL },
    { "RSVD_29", 29, 1, "SEL_HREF - Write as 0", NULL },
    { "RSVD_28", 28, 1, "SEL_VREF - Write as 0", NULL },
    { "RSVD_27", 27, 1, "PIXEL_DIS - Write as 0", NULL },
    { "PIXEL_SWAP", 26, 1, "Swap bit order in MDVO - 0-RGB 1-BGR", NULL },
    { "RSVD_25", 25, 1, "DE_DIS - Write as 0", NULL },
    { "DE_INV", 24, 1, "Invert MDVO_DE signal polarity", NULL },
    { "RSVD_23", 23, 1, "HREF_DIS - Write as 0", NULL },
    { "HREF_INV", 22, 1, "Invert Hsync polarity", NULL },
    { "RSVD_21", 21, 1, "VREF_DIS - Write as 0", NULL },
    { "VREF_INV", 20, 1, "Invert Vsync polarity", NULL },
    { "RSVD_19", 19, 1, "CLK_DIS - Write as 0", NULL },
    { "CLK_INV", 18, 1, "Invert pixel IDCK", NULL },
    { "RSVD_17", 17, 1, "PIXEL_STALL 0.5 - Write as 0", NULL },
    { "CLK_DIV2", 16, 1, "pixel IDCK/2 Mode", NULL },
    { "ESTRB_INV", 15, 1, "Invert ESTRB polarity - valid only if clk_div2 is set", NULL },
    { "RSVD_14_0", 0, 15, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_PIPEACONF[] =
{
    { "PIPE_ENABLE", 31, 1, "Bus Interface Reset", NULL },
    { "RSVD_30_29", 29, 2, "", NULL },
    { "FRAME_ST_DELAY", 27, 2, "00-framestart on 1st hblank after vblank 01-2nd hblank 10-3rd hblank 11-4th hblank", NULL },
    { "RSVD_26", 26, 1, "", NULL },
    { "FRAME_BORDER", 25, 1, "Test Mode 0-normal 1-border color substituted", NULL },
    { "RSVD_24", 24, 1, "", NULL },
    { "INTERLACED_MODE", 21, 3, "0xx-prog 100-rsvd 101-int w/ vert sync shift 110-int w/ fld ind, 111-int w/ fld 0 only", NULL },
    { "RSVD_20", 20, 1, "", NULL },
    { "PLANES_OFFSET", 19, 1, "0-normal 1-disabledplanes", NULL },
    { "ARGB_OUTPUT_MODE", 18, 1, "mdvo o/p 0-30bRGB 1-32bARGB", NULL },
    { "RSVD_17_0", 0, 18, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_PIPEASTAT[] =
{
    { "FIFO_UNDERRUN", 31, 1, "1-underflow occurred 0-not", NULL },
    { "RSVD_30", 30, 1, "", NULL },
    { "CRC_ERROR_ENABLE", 29, 1, "0-disabled 1-enable", NULL },
    { "CRC_DONE_ENABLE", 28, 1, "0-disabled 1-enable", NULL },
    { "RSVD_27_26", 26, 2, "", NULL },
    { "VSYNC_ENABLE", 25, 1, "0-disabled 1-enable", NULL },
    { "VBLANK_ENABLE", 24, 1, "0-disabled 1-enable", NULL },
    { "RSVD_23_22", 22, 2, "", NULL },

    { "ODDFLD_ENABLE", 21, 1, "0-disabled 1-enable", NULL },
    { "EVENFLD_ENABLE", 20, 1, "0-disabled 1-enable", NULL },
    { "RSVD_19_18", 18, 2, "", NULL },
    { "FRAMESTART_ENABLE", 17, 1, "0-disabled 1-enable", NULL },
    { "RSVD_16_14", 18, 2, "", NULL },
    { "CRC_ERROR", 13, 1, "0-not occured 1-occured", NULL },
    { "CRC_DONE", 12, 1, "0-crc not done 1-crc done", NULL },
    { "RSVD_11_10", 10, 2, "", NULL },
    { "VSYNC", 9, 1, "0-not occured 1-occured", NULL },
    { "VBLANK", 8, 1, "0-not occured 1-occured", NULL },
    { "RSVD_7_6", 6, 2, "", NULL },
    { "ODDFLD", 5, 1, "0-not occured 1-occured", NULL },
    { "EVENFLD", 4, 1, "0-not occured 1-occured", NULL },
    { "RSVD_3_2", 2, 2, "", NULL },
    { "FRAMESTART", 1, 1, "0-not occured 1-occured", NULL },
    { "RSVD_0", 0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_RCOMPSTAT[] =
{
    { "VDC_I_RCOMPL", 31, 1, "RO - i/p from RCOMP logic signifying it is ready", NULL },
    { "RSVD_30_4", 4, 27, "", NULL },
    { "DISABLE_PWRSV", 3, 1, "0-enable powersave 1-disable", NULL },
    { "MDVO_PAD_ENABLE", 2, 1, "Must be set to 1 to enable MDVO", NULL },
    { "RSVD_1", 1, 1, "", NULL },
    { "PULLDOWN_ENABLE", 0, 1, "default 1, must be 0 when mdvo pad enabled", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_DSPCCNTR[] =
{
    { "GFX_ENABLE", 31, 1, "1-enable graphics plane 0-disable", NULL },
    { "GFX_GAMMA_BYPASS", 30, 1, "0-gammacorrection 1-gammabypass", NULL },
    { "GFX_SRCFMT", 26, 4, "0011-1555 0110-x888 0111-8888 others-rsvd", NULL },
    { "GFX_ALPHACONST", 25, 1, "0-all opaque 1-use const alpha", NULL },
    { "GFX_ALPHAMULT", 24, 1, "0-RGB premult w/ alpha 1-not premult", NULL },
    { "RSVD_23_22", 22, 2, "", NULL },
    { "GFX_DOUBLE", 20, 2, "00-no line/pixel dup 01-line/pixel doub 11-pix doub", NULL },
    { "RSVD_19_15", 15, 5, "", NULL },
    { "GFX_HOR_MULT", 11, 4, "used if double=0 0000-1x 0001-2x ... 1001-10x rest rsvd", NULL },
    { "RSVD_10_8", 8, 3, "", NULL },
    { "CONST_ALPHA", 0, 8, "Constant alpha - used if srcfmt=0110", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_DSPCSTRIDE[] =
{
    { "RSVD_31", 31, 1, "", NULL },
    { "GFX_STRIDE", 0, 31, "stride in bytes", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_DSPCPOS[] =
{
    { "RSVD_31_28", 28, 4, "", NULL },
    { "YPOS", 16, 12, "y pos", NULL },
    { "RSVD_15_12", 12, 4, "", NULL },
    { "XPOS", 0, 12, "x pos", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_DSPCSIZE[] =
{
    { "RSVD_31_28", 28, 4, "", NULL },
    { "HEIGHT", 16, 12, "ht", NULL },
    { "RSVD_15_12", 12, 4, "", NULL },
    { "WIDTH", 0, 12, "wdth", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_VDC_DSPCGAMLUT[] =
{
    { "RSVD_31_30", 30, 2, "", NULL },
    { "RED", 20, 10, "red", NULL },
    { "GREEN", 10, 10, "GREEN", NULL },
    { "BLUE", 0, 10, "BLUE", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_CHAP_versions.
 */
static const struct EAS_Register g_csr_VDC[] =
{
    /* region 8, dspblut is 256 4 byte entries, accessed dword at a time */
    CSR_REG("DSPBLUT",      0x0b000,    "Subtitle LUT Access")

    /* Spoof: Memory Group start = 0x30000 size = 0x200 */
    /* Real: Memory Group start = 0x30000 size = 0x1000 */
    CSR_REG("DOVSTAA",      0x30008,    "Display/Overlay Status Register")
    CSR_REG("OVBUF_POFFA",  0x30064,    "Overlay Video Pixel Offset")
    CSR_REG("OVBUF_YA",     0x30100,    "Overlay Video Y Pointer")
    CSR_REG("OVBUF_UVA",    0x30108,    "Overlay Video UV Pointer")
    CSR_REG("OV_STRIDEA",   0x30118,    "Overlay Video Stride")
    CSR_REG("DWINPOSA",     0x3012C,    "Destination Window Position")
    CSR_REG("DWINSZA",      0x30130,    "Destination Window Size")
    CSR_REG("SWIDTHA",      0x30134,    "Source Width")
    CSR_REG("SHEIGHTA",     0x3013C,    "Source Height")
    CSR_REG("OCLRC0A",      0x30148,    "Overlay Color Correction 0")
    CSR_REG("OCLRC1A",      0x3014C,    "Overlay Color Correction 1")
    CSR_REG("OCONFIGA",     0x30164,    "Overlay Configuration")
    CSR_REG("OCOMDA",       0x30168,    "Overlay Command")
    CSR_REG("OFLIPMODEA",   0x3016C,    "Overlay Flip Mode")
    CSR_REG("OFDROPA",      0x30170,    "Overlay Frame Drop Counter")
    CSR_REG("OFREPEATA",    0x30174,    "Overlay Frame Repeat Counter")

    /* Group start = 0x30800 size = 0x200 */
    CSR_REG("OSPBUF_YA",    0x30800,    "Overlay Still Picture Y Pointer")
    CSR_REG("OSPBUF_UVA",   0x30804,    "Overlay Still Picture UV Pointer")
    CSR_REG("OSWBUFA",      0x30808,    "Overlay Switching Plane Pointer")
    CSR_REG("OSP_STRIDEA",  0x3080C,    "Overlay Still Picture Stride")
    CSR_REG("OSW_STRIDEA",  0x30810,    "Overlay switching plane stride")
    CSR_REG("OVPRNGSRA",    0x30814,    "Overlay PRNG Shift Register")
    CSR_REG("OSPBUF_POFFA", 0x3081C,    "Overlay Still Picture Pixel Offset")
    CSR_REG("OSWBUF_POFFA", 0x30820,    "Overlay Switching Plane Pixel Offset")

    /* region 9, 258 entries, 4 bytes each */
    CSR_REG("OVGAMLUTA",    0x30900,    "Overlay Gamma Correction Registers")

    /* Memory Group start = 0x31000 size = 0x200 */
    CSR_REG("DOVSTAB",      0x31008,    "Display/Overlay Status Register")
    CSR_REG("OVBUF_POFFB",  0x31064,    "Overlay Video Pixel Offset")
    CSR_REG("OVBUF_YB",     0x31100,    "Overlay Video Y Pointer")
    CSR_REG("OVBUF_UVB",    0x31108,    "Overlay Video UV Pointer")
    CSR_REG("OV_STRIDEB",   0x31118,    "Overlay Video Stride")
    CSR_REG("DWINPOSB",     0x3112C,    "Destination Window Position")
    CSR_REG("DWINSZB",      0x31130,    "Destination Window Size")
    CSR_REG("SWIDTHB",      0x31134,    "Source Width")
    CSR_REG("SHEIGHTB",     0x3113C,    "Source Height")
    CSR_REG("OCLRC0B",      0x31148,    "Overlay Color Correction 0")
    CSR_REG("OCLRC1B",      0x3114C,    "Overlay Color Correction 1")
    CSR_REG("OCONFIGB",     0x31164,    "Overlay Configuration")
    CSR_REG("OCOMDB",       0x31168,    "Overlay Command")
    CSR_REG("OFLIPMODEB",   0x3116C,    "Overlay Flip Mode")
    CSR_REG("OFDROPB",      0x31170,    "Overlay Frame Drop Counter")
    CSR_REG("OFREPEATB",    0x31174,    "Overlay Frame Repeat Counter")

    CSR_REG("OVPRNGSRB",    0x31814,    "Overlay PRNG Shift Register")

    /* region 10, 258 entries, 4 bytes each */
    CSR_REG("OVGAMLUTB",    0x31900,    "Overlay Gamma Correction Registers")

    /* Memory Group start = 0x34000 size = 0x200 */
    CSR_REG("DOVSTA_SD",    0x34008,    "Display/Overlay Status Register")
    CSR_REG("OBUF_POFFSD",  0x34064,    "Overlay Buffer Pixel Offset")
    CSR_REG("OBUF_YSD",     0x34100,    "Overlay Buffer 0 Y Pointer")
    CSR_REG("OBUF_UVSD",    0x34108,    "Overlay Buffer 0 UV Pointer")
    CSR_REG("SC_SWIDTHSWSD",0x34114,    "Scaled Source SWORD width")        /* added in 0.9 EAS - JWC */
    CSR_REG("OSTRIDESD",    0x34118,    "Overlay Stride")
    CSR_REG("Y_VPHSD",      0x3411C,    "Y Vertical Phase 0/1")
    CSR_REG("UV_VPHSD",     0x34120,    "UV Vertical Phase 0/1")
    CSR_REG("HORZ_PHSD",    0x34124,    "Horizontal Phase")
    CSR_REG("INIT_PHSSD",   0x34128,    "Initial Phase Shift")
    CSR_REG("SWIDTHSD",     0x34134,    "Source Width")
    CSR_REG("SWIDTHSWSD",   0x34138,    "Source SWORD width")
    CSR_REG("SHEIGHTSD",    0x3413C,    "Source Height")
    CSR_REG("YSCALESD",     0x34140,    "Y Scale Factor")
    CSR_REG("UVSCALESD",    0x34144,    "U V Scale Factor")
    CSR_REG("OCOMDSD",      0x34168,    "Overlay Command")
    CSR_REG("OFLIPMODESD",  0x3416C,    "Overlay Flip Mode")
    CSR_REG("OFDROPSD",     0x34170,    "Overlay Frame Drop Counter")
    CSR_REG("OFREPEATSD",   0x34174,    "Overlay Frame Repeat Counter")
    CSR_REG("UVSCALEVSD",   0x341A4,    "UV Vertical Downscale Integer ")

    /* this is an array of 26 members 4 bytes each */
    CSR_REG( "Y_VCOEFS_SD0",  0x34200, "Overlay Y Vertical Filter Coefficients (SD) #0")
    CSR_REG( "Y_VCOEFS_SD1",  0x34204, "Overlay Y Vertical Filter Coefficients (SD) #1")
    CSR_REG( "Y_VCOEFS_SD2",  0x34208, "Overlay Y Vertical Filter Coefficients (SD) #2")
    CSR_REG( "Y_VCOEFS_SD3",  0x3420C, "Overlay Y Vertical Filter Coefficients (SD) #3")
    CSR_REG( "Y_VCOEFS_SD4",  0x34210, "Overlay Y Vertical Filter Coefficients (SD) #4")
    CSR_REG( "Y_VCOEFS_SD5",  0x34214, "Overlay Y Vertical Filter Coefficients (SD) #5")
    CSR_REG( "Y_VCOEFS_SD6",  0x34218, "Overlay Y Vertical Filter Coefficients (SD) #6")
    CSR_REG( "Y_VCOEFS_SD7",  0x3421C, "Overlay Y Vertical Filter Coefficients (SD) #7")
    CSR_REG( "Y_VCOEFS_SD8",  0x34220, "Overlay Y Vertical Filter Coefficients (SD) #8")
    CSR_REG( "Y_VCOEFS_SD9",  0x34224, "Overlay Y Vertical Filter Coefficients (SD) #9")
    CSR_REG( "Y_VCOEFS_SD10", 0x34228, "Overlay Y Vertical Filter Coefficients (SD) #10")
    CSR_REG( "Y_VCOEFS_SD11", 0x3422C, "Overlay Y Vertical Filter Coefficients (SD) #11")
    CSR_REG( "Y_VCOEFS_SD12", 0x34230, "Overlay Y Vertical Filter Coefficients (SD) #12")
    CSR_REG( "Y_VCOEFS_SD13", 0x34234, "Overlay Y Vertical Filter Coefficients (SD) #13")
    CSR_REG( "Y_VCOEFS_SD14", 0x34238, "Overlay Y Vertical Filter Coefficients (SD) #14")
    CSR_REG( "Y_VCOEFS_SD15", 0x3423C, "Overlay Y Vertical Filter Coefficients (SD) #15")
    CSR_REG( "Y_VCOEFS_SD16", 0x34240, "Overlay Y Vertical Filter Coefficients (SD) #16")
    CSR_REG( "Y_VCOEFS_SD17", 0x34244, "Overlay Y Vertical Filter Coefficients (SD) #17")
    CSR_REG( "Y_VCOEFS_SD18", 0x34248, "Overlay Y Vertical Filter Coefficients (SD) #18")
    CSR_REG( "Y_VCOEFS_SD19", 0x3424C, "Overlay Y Vertical Filter Coefficients (SD) #19")
    CSR_REG( "Y_VCOEFS_SD20", 0x34250, "Overlay Y Vertical Filter Coefficients (SD) #20")
    CSR_REG( "Y_VCOEFS_SD21", 0x34254, "Overlay Y Vertical Filter Coefficients (SD) #21")
    CSR_REG( "Y_VCOEFS_SD22", 0x34258, "Overlay Y Vertical Filter Coefficients (SD) #22")
    CSR_REG( "Y_VCOEFS_SD23", 0x3425C, "Overlay Y Vertical Filter Coefficients (SD) #23")
    CSR_REG( "Y_VCOEFS_SD24", 0x34260, "Overlay Y Vertical Filter Coefficients (SD) #24")
    CSR_REG( "Y_VCOEFS_SD25", 0x34264, "Overlay Y Vertical Filter Coefficients (SD) #25")
    /* {"y_vcoefs_sd",0x34200,4,NULL,vdcPutRegister,0,0,0,0,NULL}, */

    /* this is an array of 43 members 4 bytes each */
    CSR_REG( "Y_HCOEFS_SD0",  0x34300, "Overlay Y Horizontal Filter Coefficients (SD) #0")
    CSR_REG( "Y_HCOEFS_SD1",  0x34304, "Overlay Y Horizontal Filter Coefficients (SD) #1")
    CSR_REG( "Y_HCOEFS_SD2",  0x34308, "Overlay Y Horizontal Filter Coefficients (SD) #2")
    CSR_REG( "Y_HCOEFS_SD3",  0x3430C, "Overlay Y Horizontal Filter Coefficients (SD) #3")
    CSR_REG( "Y_HCOEFS_SD4",  0x34310, "Overlay Y Horizontal Filter Coefficients (SD) #4")
    CSR_REG( "Y_HCOEFS_SD5",  0x34314, "Overlay Y Horizontal Filter Coefficients (SD) #5")
    CSR_REG( "Y_HCOEFS_SD6",  0x34318, "Overlay Y Horizontal Filter Coefficients (SD) #6")
    CSR_REG( "Y_HCOEFS_SD7",  0x3431C, "Overlay Y Horizontal Filter Coefficients (SD) #7")
    CSR_REG( "Y_HCOEFS_SD8",  0x34320, "Overlay Y Horizontal Filter Coefficients (SD) #8")
    CSR_REG( "Y_HCOEFS_SD9",  0x34324, "Overlay Y Horizontal Filter Coefficients (SD) #9")
    CSR_REG( "Y_HCOEFS_SD10", 0x34328, "Overlay Y Horizontal Filter Coefficients (SD) #10")
    CSR_REG( "Y_HCOEFS_SD11", 0x3432C, "Overlay Y Horizontal Filter Coefficients (SD) #11")
    CSR_REG( "Y_HCOEFS_SD12", 0x34330, "Overlay Y Horizontal Filter Coefficients (SD) #12")
    CSR_REG( "Y_HCOEFS_SD13", 0x34334, "Overlay Y Horizontal Filter Coefficients (SD) #13")
    CSR_REG( "Y_HCOEFS_SD14", 0x34338, "Overlay Y Horizontal Filter Coefficients (SD) #14")
    CSR_REG( "Y_HCOEFS_SD15", 0x3433C, "Overlay Y Horizontal Filter Coefficients (SD) #15")
    CSR_REG( "Y_HCOEFS_SD16", 0x34340, "Overlay Y Horizontal Filter Coefficients (SD) #16")
    CSR_REG( "Y_HCOEFS_SD17", 0x34344, "Overlay Y Horizontal Filter Coefficients (SD) #17")
    CSR_REG( "Y_HCOEFS_SD18", 0x34348, "Overlay Y Horizontal Filter Coefficients (SD) #18")
    CSR_REG( "Y_HCOEFS_SD19", 0x3434C, "Overlay Y Horizontal Filter Coefficients (SD) #19")
    CSR_REG( "Y_HCOEFS_SD20", 0x34350, "Overlay Y Horizontal Filter Coefficients (SD) #20")
    CSR_REG( "Y_HCOEFS_SD21", 0x34354, "Overlay Y Horizontal Filter Coefficients (SD) #21")
    CSR_REG( "Y_HCOEFS_SD22", 0x34358, "Overlay Y Horizontal Filter Coefficients (SD) #22")
    CSR_REG( "Y_HCOEFS_SD23", 0x3435C, "Overlay Y Horizontal Filter Coefficients (SD) #23")
    CSR_REG( "Y_HCOEFS_SD24", 0x34360, "Overlay Y Horizontal Filter Coefficients (SD) #24")
    CSR_REG( "Y_HCOEFS_SD25", 0x34364, "Overlay Y Horizontal Filter Coefficients (SD) #25")
    CSR_REG( "Y_HCOEFS_SD26", 0x34368, "Overlay Y Horizontal Filter Coefficients (SD) #26")
    CSR_REG( "Y_HCOEFS_SD27", 0x3436C, "Overlay Y Horizontal Filter Coefficients (SD) #27")
    CSR_REG( "Y_HCOEFS_SD28", 0x34370, "Overlay Y Horizontal Filter Coefficients (SD) #28")
    CSR_REG( "Y_HCOEFS_SD29", 0x34374, "Overlay Y Horizontal Filter Coefficients (SD) #29")
    CSR_REG( "Y_HCOEFS_SD30", 0x34378, "Overlay Y Horizontal Filter Coefficients (SD) #30")
    CSR_REG( "Y_HCOEFS_SD31", 0x3437C, "Overlay Y Horizontal Filter Coefficients (SD) #31")
    CSR_REG( "Y_HCOEFS_SD32", 0x34380, "Overlay Y Horizontal Filter Coefficients (SD) #32")
    CSR_REG( "Y_HCOEFS_SD33", 0x34384, "Overlay Y Horizontal Filter Coefficients (SD) #33")
    CSR_REG( "Y_HCOEFS_SD34", 0x34388, "Overlay Y Horizontal Filter Coefficients (SD) #34")
    CSR_REG( "Y_HCOEFS_SD35", 0x3438C, "Overlay Y Horizontal Filter Coefficients (SD) #35")
    CSR_REG( "Y_HCOEFS_SD36", 0x34390, "Overlay Y Horizontal Filter Coefficients (SD) #36")
    CSR_REG( "Y_HCOEFS_SD37", 0x34394, "Overlay Y Horizontal Filter Coefficients (SD) #37")
    CSR_REG( "Y_HCOEFS_SD38", 0x34398, "Overlay Y Horizontal Filter Coefficients (SD) #38")
    CSR_REG( "Y_HCOEFS_SD39", 0x3439C, "Overlay Y Horizontal Filter Coefficients (SD) #39")
    CSR_REG( "Y_HCOEFS_SD40", 0x343A0, "Overlay Y Horizontal Filter Coefficients (SD) #40")
    CSR_REG( "Y_HCOEFS_SD41", 0x343A4, "Overlay Y Horizontal Filter Coefficients (SD) #41")
    CSR_REG( "Y_HCOEFS_SD42", 0x343A8, "Overlay Y Horizontal Filter Coefficients (SD) #42")
    /* {"Y_HCOEFS_SD",0x34300,4,NULL,vdcPutRegister,0,0,0,0,NULL}, */

    /* this is aN array of 26 members 4 bytes each */
    CSR_REG( "UV_VCOEFS_SD0",  0x34500, "Overlay UV Vertical Filter Coefficients (SD) #0")
    CSR_REG( "UV_VCOEFS_SD1",  0x34504, "Overlay UV Vertical Filter Coefficients (SD) #1")
    CSR_REG( "UV_VCOEFS_SD2",  0x34508, "Overlay UV Vertical Filter Coefficients (SD) #2")
    CSR_REG( "UV_VCOEFS_SD3",  0x3450C, "Overlay UV Vertical Filter Coefficients (SD) #3")
    CSR_REG( "UV_VCOEFS_SD4",  0x34510, "Overlay UV Vertical Filter Coefficients (SD) #4")
    CSR_REG( "UV_VCOEFS_SD5",  0x34514, "Overlay UV Vertical Filter Coefficients (SD) #5")
    CSR_REG( "UV_VCOEFS_SD6",  0x34518, "Overlay UV Vertical Filter Coefficients (SD) #6")
    CSR_REG( "UV_VCOEFS_SD7",  0x3451C, "Overlay UV Vertical Filter Coefficients (SD) #7")
    CSR_REG( "UV_VCOEFS_SD8",  0x34520, "Overlay UV Vertical Filter Coefficients (SD) #8")
    CSR_REG( "UV_VCOEFS_SD9",  0x34524, "Overlay UV Vertical Filter Coefficients (SD) #9")
    CSR_REG( "UV_VCOEFS_SD10", 0x34528, "Overlay UV Vertical Filter Coefficients (SD) #10")
    CSR_REG( "UV_VCOEFS_SD11", 0x3452C, "Overlay UV Vertical Filter Coefficients (SD) #11")
    CSR_REG( "UV_VCOEFS_SD12", 0x34530, "Overlay UV Vertical Filter Coefficients (SD) #12")
    CSR_REG( "UV_VCOEFS_SD13", 0x34534, "Overlay UV Vertical Filter Coefficients (SD) #13")
    CSR_REG( "UV_VCOEFS_SD14", 0x34538, "Overlay UV Vertical Filter Coefficients (SD) #14")
    CSR_REG( "UV_VCOEFS_SD15", 0x3453C, "Overlay UV Vertical Filter Coefficients (SD) #15")
    CSR_REG( "UV_VCOEFS_SD16", 0x34540, "Overlay UV Vertical Filter Coefficients (SD) #16")
    CSR_REG( "UV_VCOEFS_SD17", 0x34544, "Overlay UV Vertical Filter Coefficients (SD) #17")
    CSR_REG( "UV_VCOEFS_SD18", 0x34548, "Overlay UV Vertical Filter Coefficients (SD) #18")
    CSR_REG( "UV_VCOEFS_SD19", 0x3454C, "Overlay UV Vertical Filter Coefficients (SD) #19")
    CSR_REG( "UV_VCOEFS_SD20", 0x34550, "Overlay UV Vertical Filter Coefficients (SD) #20")
    CSR_REG( "UV_VCOEFS_SD21", 0x34554, "Overlay UV Vertical Filter Coefficients (SD) #21")
    CSR_REG( "UV_VCOEFS_SD22", 0x34558, "Overlay UV Vertical Filter Coefficients (SD) #22")
    CSR_REG( "UV_VCOEFS_SD23", 0x3455C, "Overlay UV Vertical Filter Coefficients (SD) #23")
    CSR_REG( "UV_VCOEFS_SD24", 0x34560, "Overlay UV Vertical Filter Coefficients (SD) #24")
    CSR_REG( "UV_VCOEFS_SD25", 0x34564, "Overlay UV Vertical Filter Coefficients (SD) #25")
    /* {"UV_VCOEFS_SD",0x34500,4,NULL,vdcPutRegister,0,0,0,0,NULL}, */

    /* this is an array of 26 members 4 bytes each */
    CSR_REG( "UV_HCOEFS_SD0",  0x34600, "Overlay UV Horizontal Filter Coefficients (SD) #0")
    CSR_REG( "UV_HCOEFS_SD1",  0x34604, "Overlay UV Horizontal Filter Coefficients (SD) #1")
    CSR_REG( "UV_HCOEFS_SD2",  0x34608, "Overlay UV Horizontal Filter Coefficients (SD) #2")
    CSR_REG( "UV_HCOEFS_SD3",  0x3460C, "Overlay UV Horizontal Filter Coefficients (SD) #3")
    CSR_REG( "UV_HCOEFS_SD4",  0x34610, "Overlay UV Horizontal Filter Coefficients (SD) #4")
    CSR_REG( "UV_HCOEFS_SD5",  0x34614, "Overlay UV Horizontal Filter Coefficients (SD) #5")
    CSR_REG( "UV_HCOEFS_SD6",  0x34618, "Overlay UV Horizontal Filter Coefficients (SD) #6")
    CSR_REG( "UV_HCOEFS_SD7",  0x3461C, "Overlay UV Horizontal Filter Coefficients (SD) #7")
    CSR_REG( "UV_HCOEFS_SD8",  0x34620, "Overlay UV Horizontal Filter Coefficients (SD) #8")
    CSR_REG( "UV_HCOEFS_SD9",  0x34624, "Overlay UV Horizontal Filter Coefficients (SD) #9")
    CSR_REG( "UV_HCOEFS_SD10", 0x34628, "Overlay UV Horizontal Filter Coefficients (SD) #10")
    CSR_REG( "UV_HCOEFS_SD11", 0x3462C, "Overlay UV Horizontal Filter Coefficients (SD) #11")
    CSR_REG( "UV_HCOEFS_SD12", 0x34630, "Overlay UV Horizontal Filter Coefficients (SD) #12")
    CSR_REG( "UV_HCOEFS_SD13", 0x34634, "Overlay UV Horizontal Filter Coefficients (SD) #13")
    CSR_REG( "UV_HCOEFS_SD14", 0x34638, "Overlay UV Horizontal Filter Coefficients (SD) #14")
    CSR_REG( "UV_HCOEFS_SD15", 0x3463C, "Overlay UV Horizontal Filter Coefficients (SD) #15")
    CSR_REG( "UV_HCOEFS_SD16", 0x34640, "Overlay UV Horizontal Filter Coefficients (SD) #16")
    CSR_REG( "UV_HCOEFS_SD17", 0x34644, "Overlay UV Horizontal Filter Coefficients (SD) #17")
    CSR_REG( "UV_HCOEFS_SD18", 0x34648, "Overlay UV Horizontal Filter Coefficients (SD) #18")
    CSR_REG( "UV_HCOEFS_SD19", 0x3464C, "Overlay UV Horizontal Filter Coefficients (SD) #19")
    CSR_REG( "UV_HCOEFS_SD20", 0x34650, "Overlay UV Horizontal Filter Coefficients (SD) #20")
    CSR_REG( "UV_HCOEFS_SD21", 0x34654, "Overlay UV Horizontal Filter Coefficients (SD) #21")
    CSR_REG( "UV_HCOEFS_SD22", 0x34658, "Overlay UV Horizontal Filter Coefficients (SD) #22")
    CSR_REG( "UV_HCOEFS_SD23", 0x3465C, "Overlay UV Horizontal Filter Coefficients (SD) #23")
    CSR_REG( "UV_HCOEFS_SD24", 0x34660, "Overlay UV Horizontal Filter Coefficients (SD) #24")
    CSR_REG( "UV_HCOEFS_SD25", 0x34664, "Overlay UV Horizontal Filter Coefficients (SD) #25")
    /* {"uv_hcoefssd",0x34600,4,NULL,vdcPutRegister,0,0,0,0,NULL}, */

    /* Memory Group start = 0x35000 size = 0x200 */
    CSR_REG("DOVSTA_HD",    0x35008,    "Display/Overlay Status Register")
    CSR_REG("OBUF_POFFHD",  0x35064,    "Overlay Buffer Pixel Offset")
    CSR_REG("OBUF_YHD",     0x35100,    "Overlay Buffer 0 Y Pointer")
    CSR_REG("OBUF_UVHD",    0x35108,    "Overlay Buffer 0 UV Pointer")
    CSR_REG("SC_SWIDTHSWHD",0x35114,    "Scaled Source SWORD width")   /* added in 0.9 EAS - JWC */
    CSR_REG("OSTRIDEHD",    0x35118,    "Overlay Stride")
    CSR_REG("Y_VPHHD",      0x3511C,    "Y Vertical Phase 0/1")
    CSR_REG("UV_VPHHD",     0x35120,    "UV Vertical Phase 0/1")
    CSR_REG("HORZ_PHHD",    0x35124,    "Horizontal Phase")
    CSR_REG("INIT_PHSHD",   0x35128,    "Initial Phase Shift")
    CSR_REG("SWIDTHHD",     0x35134,    "Source Width")
    CSR_REG("SWIDTHSWHD",   0x35138,    "Source SWORD width")
    CSR_REG("SHEIGHTHD",    0x3513C,    "Source Height")
    CSR_REG("YSCALEHD",     0x35140,    "Y Scale Factor")
    CSR_REG("UVSCALEHD",    0x35144,    "U V Scale Factor")
    CSR_REG("OCOMDHD",      0x35168,    "Overlay Command")
    CSR_REG("OFLIPMODEHD",  0x3516C,    "Overlay Flip Mode")
    CSR_REG("OFDROPHD",     0x35170,    "Overlay Frame Drop Counter")
    CSR_REG("OFREPEATHD",   0x35174,    "Overlay Frame Repeat Counter")
    CSR_REG("UVSCALEVHD",   0x351A4,    "UV Vertical Downscale Integer ")

    /* 26 entries * 4 bytes */
    CSR_REG( "Y_VCOEFS_HD0",  0x35200, "Overlay Y Vertical Filter Coefficients (HD) #0")
    CSR_REG( "Y_VCOEFS_HD1",  0x35204, "Overlay Y Vertical Filter Coefficients (HD) #1")
    CSR_REG( "Y_VCOEFS_HD2",  0x35208, "Overlay Y Vertical Filter Coefficients (HD) #2")
    CSR_REG( "Y_VCOEFS_HD3",  0x3520C, "Overlay Y Vertical Filter Coefficients (HD) #3")
    CSR_REG( "Y_VCOEFS_HD4",  0x35210, "Overlay Y Vertical Filter Coefficients (HD) #4")
    CSR_REG( "Y_VCOEFS_HD5",  0x35214, "Overlay Y Vertical Filter Coefficients (HD) #5")
    CSR_REG( "Y_VCOEFS_HD6",  0x35218, "Overlay Y Vertical Filter Coefficients (HD) #6")
    CSR_REG( "Y_VCOEFS_HD7",  0x3521C, "Overlay Y Vertical Filter Coefficients (HD) #7")
    CSR_REG( "Y_VCOEFS_HD8",  0x35220, "Overlay Y Vertical Filter Coefficients (HD) #8")
    CSR_REG( "Y_VCOEFS_HD9",  0x35224, "Overlay Y Vertical Filter Coefficients (HD) #9")
    CSR_REG( "Y_VCOEFS_HD10", 0x35228, "Overlay Y Vertical Filter Coefficients (HD) #10")
    CSR_REG( "Y_VCOEFS_HD11", 0x3522C, "Overlay Y Vertical Filter Coefficients (HD) #11")
    CSR_REG( "Y_VCOEFS_HD12", 0x35230, "Overlay Y Vertical Filter Coefficients (HD) #12")
    CSR_REG( "Y_VCOEFS_HD13", 0x35234, "Overlay Y Vertical Filter Coefficients (HD) #13")
    CSR_REG( "Y_VCOEFS_HD14", 0x35238, "Overlay Y Vertical Filter Coefficients (HD) #14")
    CSR_REG( "Y_VCOEFS_HD15", 0x3523C, "Overlay Y Vertical Filter Coefficients (HD) #15")
    CSR_REG( "Y_VCOEFS_HD16", 0x35240, "Overlay Y Vertical Filter Coefficients (HD) #16")
    CSR_REG( "Y_VCOEFS_HD17", 0x35244, "Overlay Y Vertical Filter Coefficients (HD) #17")
    CSR_REG( "Y_VCOEFS_HD18", 0x35248, "Overlay Y Vertical Filter Coefficients (HD) #18")
    CSR_REG( "Y_VCOEFS_HD19", 0x3524C, "Overlay Y Vertical Filter Coefficients (HD) #19")
    CSR_REG( "Y_VCOEFS_HD20", 0x35250, "Overlay Y Vertical Filter Coefficients (HD) #20")
    CSR_REG( "Y_VCOEFS_HD21", 0x35254, "Overlay Y Vertical Filter Coefficients (HD) #21")
    CSR_REG( "Y_VCOEFS_HD22", 0x35258, "Overlay Y Vertical Filter Coefficients (HD) #22")
    CSR_REG( "Y_VCOEFS_HD23", 0x3525C, "Overlay Y Vertical Filter Coefficients (HD) #23")
    CSR_REG( "Y_VCOEFS_HD24", 0x35260, "Overlay Y Vertical Filter Coefficients (HD) #24")
    CSR_REG( "Y_VCOEFS_HD25", 0x35264, "Overlay Y Vertical Filter Coefficients (HD) #25")
    /* {"y_vcoefs_hd",0x35200,104,NULL,vdcPutRegister,0,0,0,0,NULL}, */

    /* 43 entries * 4 bytes */
    CSR_REG( "Y_HCOEFS_HD0",  0x35300, "Overlay Y Horizontal Filter Coefficients (HD) #0")
    CSR_REG( "Y_HCOEFS_HD1",  0x35304, "Overlay Y Horizontal Filter Coefficients (HD) #1")
    CSR_REG( "Y_HCOEFS_HD2",  0x35308, "Overlay Y Horizontal Filter Coefficients (HD) #2")
    CSR_REG( "Y_HCOEFS_HD3",  0x3530C, "Overlay Y Horizontal Filter Coefficients (HD) #3")
    CSR_REG( "Y_HCOEFS_HD4",  0x35310, "Overlay Y Horizontal Filter Coefficients (HD) #4")
    CSR_REG( "Y_HCOEFS_HD5",  0x35314, "Overlay Y Horizontal Filter Coefficients (HD) #5")
    CSR_REG( "Y_HCOEFS_HD6",  0x35318, "Overlay Y Horizontal Filter Coefficients (HD) #6")
    CSR_REG( "Y_HCOEFS_HD7",  0x3531C, "Overlay Y Horizontal Filter Coefficients (HD) #7")
    CSR_REG( "Y_HCOEFS_HD8",  0x35320, "Overlay Y Horizontal Filter Coefficients (HD) #8")
    CSR_REG( "Y_HCOEFS_HD9",  0x35324, "Overlay Y Horizontal Filter Coefficients (HD) #9")
    CSR_REG( "Y_HCOEFS_HD10", 0x35328, "Overlay Y Horizontal Filter Coefficients (HD) #10")
    CSR_REG( "Y_HCOEFS_HD11", 0x3532C, "Overlay Y Horizontal Filter Coefficients (HD) #11")
    CSR_REG( "Y_HCOEFS_HD12", 0x35330, "Overlay Y Horizontal Filter Coefficients (HD) #12")
    CSR_REG( "Y_HCOEFS_HD13", 0x35334, "Overlay Y Horizontal Filter Coefficients (HD) #13")
    CSR_REG( "Y_HCOEFS_HD14", 0x35338, "Overlay Y Horizontal Filter Coefficients (HD) #14")
    CSR_REG( "Y_HCOEFS_HD15", 0x3533C, "Overlay Y Horizontal Filter Coefficients (HD) #15")
    CSR_REG( "Y_HCOEFS_HD16", 0x35340, "Overlay Y Horizontal Filter Coefficients (HD) #16")
    CSR_REG( "Y_HCOEFS_HD17", 0x35344, "Overlay Y Horizontal Filter Coefficients (HD) #17")
    CSR_REG( "Y_HCOEFS_HD18", 0x35348, "Overlay Y Horizontal Filter Coefficients (HD) #18")
    CSR_REG( "Y_HCOEFS_HD19", 0x3534C, "Overlay Y Horizontal Filter Coefficients (HD) #19")
    CSR_REG( "Y_HCOEFS_HD20", 0x35350, "Overlay Y Horizontal Filter Coefficients (HD) #20")
    CSR_REG( "Y_HCOEFS_HD21", 0x35354, "Overlay Y Horizontal Filter Coefficients (HD) #21")
    CSR_REG( "Y_HCOEFS_HD22", 0x35358, "Overlay Y Horizontal Filter Coefficients (HD) #22")
    CSR_REG( "Y_HCOEFS_HD23", 0x3535C, "Overlay Y Horizontal Filter Coefficients (HD) #23")
    CSR_REG( "Y_HCOEFS_HD24", 0x35360, "Overlay Y Horizontal Filter Coefficients (HD) #24")
    CSR_REG( "Y_HCOEFS_HD25", 0x35364, "Overlay Y Horizontal Filter Coefficients (HD) #25")
    CSR_REG( "Y_HCOEFS_HD26", 0x35368, "Overlay Y Horizontal Filter Coefficients (HD) #26")
    CSR_REG( "Y_HCOEFS_HD27", 0x3536C, "Overlay Y Horizontal Filter Coefficients (HD) #27")
    CSR_REG( "Y_HCOEFS_HD28", 0x35370, "Overlay Y Horizontal Filter Coefficients (HD) #28")
    CSR_REG( "Y_HCOEFS_HD29", 0x35374, "Overlay Y Horizontal Filter Coefficients (HD) #29")
    CSR_REG( "Y_HCOEFS_HD30", 0x35378, "Overlay Y Horizontal Filter Coefficients (HD) #30")
    CSR_REG( "Y_HCOEFS_HD31", 0x3537C, "Overlay Y Horizontal Filter Coefficients (HD) #31")
    CSR_REG( "Y_HCOEFS_HD32", 0x35380, "Overlay Y Horizontal Filter Coefficients (HD) #32")
    CSR_REG( "Y_HCOEFS_HD33", 0x35384, "Overlay Y Horizontal Filter Coefficients (HD) #33")
    CSR_REG( "Y_HCOEFS_HD34", 0x35388, "Overlay Y Horizontal Filter Coefficients (HD) #34")
    CSR_REG( "Y_HCOEFS_HD35", 0x3538C, "Overlay Y Horizontal Filter Coefficients (HD) #35")
    CSR_REG( "Y_HCOEFS_HD36", 0x35390, "Overlay Y Horizontal Filter Coefficients (HD) #36")
    CSR_REG( "Y_HCOEFS_HD37", 0x35394, "Overlay Y Horizontal Filter Coefficients (HD) #37")
    CSR_REG( "Y_HCOEFS_HD38", 0x35398, "Overlay Y Horizontal Filter Coefficients (HD) #38")
    CSR_REG( "Y_HCOEFS_HD39", 0x3539C, "Overlay Y Horizontal Filter Coefficients (HD) #39")
    CSR_REG( "Y_HCOEFS_HD40", 0x353A0, "Overlay Y Horizontal Filter Coefficients (HD) #40")
    CSR_REG( "Y_HCOEFS_HD41", 0x353A4, "Overlay Y Horizontal Filter Coefficients (HD) #41")
    CSR_REG( "Y_HCOEFS_HD42", 0x353A8, "Overlay Y Horizontal Filter Coefficients (HD) #42")
    /* {"y_hcoefs_hd",0x35300,172,NULL,vdcPutRegister,0,0,0,0,NULL}, */

    /* 26 entries * 4 bytes */
    CSR_REG( "UV_VCOEFS_HD0",  0x35500, "Overlay UV Vertical Filter Coefficients (HD) #0")
    CSR_REG( "UV_VCOEFS_HD1",  0x35504, "Overlay UV Vertical Filter Coefficients (HD) #1")
    CSR_REG( "UV_VCOEFS_HD2",  0x35508, "Overlay UV Vertical Filter Coefficients (HD) #2")
    CSR_REG( "UV_VCOEFS_HD3",  0x3550C, "Overlay UV Vertical Filter Coefficients (HD) #3")
    CSR_REG( "UV_VCOEFS_HD4",  0x35510, "Overlay UV Vertical Filter Coefficients (HD) #4")
    CSR_REG( "UV_VCOEFS_HD5",  0x35514, "Overlay UV Vertical Filter Coefficients (HD) #5")
    CSR_REG( "UV_VCOEFS_HD6",  0x35518, "Overlay UV Vertical Filter Coefficients (HD) #6")
    CSR_REG( "UV_VCOEFS_HD7",  0x3551C, "Overlay UV Vertical Filter Coefficients (HD) #7")
    CSR_REG( "UV_VCOEFS_HD8",  0x35520, "Overlay UV Vertical Filter Coefficients (HD) #8")
    CSR_REG( "UV_VCOEFS_HD9",  0x35524, "Overlay UV Vertical Filter Coefficients (HD) #9")
    CSR_REG( "UV_VCOEFS_HD10", 0x35528, "Overlay UV Vertical Filter Coefficients (HD) #10")
    CSR_REG( "UV_VCOEFS_HD11", 0x3552C, "Overlay UV Vertical Filter Coefficients (HD) #11")
    CSR_REG( "UV_VCOEFS_HD12", 0x35530, "Overlay UV Vertical Filter Coefficients (HD) #12")
    CSR_REG( "UV_VCOEFS_HD13", 0x35534, "Overlay UV Vertical Filter Coefficients (HD) #13")
    CSR_REG( "UV_VCOEFS_HD14", 0x35538, "Overlay UV Vertical Filter Coefficients (HD) #14")
    CSR_REG( "UV_VCOEFS_HD15", 0x3553C, "Overlay UV Vertical Filter Coefficients (HD) #15")
    CSR_REG( "UV_VCOEFS_HD16", 0x35540, "Overlay UV Vertical Filter Coefficients (HD) #16")
    CSR_REG( "UV_VCOEFS_HD17", 0x35544, "Overlay UV Vertical Filter Coefficients (HD) #17")
    CSR_REG( "UV_VCOEFS_HD18", 0x35548, "Overlay UV Vertical Filter Coefficients (HD) #18")
    CSR_REG( "UV_VCOEFS_HD19", 0x3554C, "Overlay UV Vertical Filter Coefficients (HD) #19")
    CSR_REG( "UV_VCOEFS_HD20", 0x35550, "Overlay UV Vertical Filter Coefficients (HD) #20")
    CSR_REG( "UV_VCOEFS_HD21", 0x35554, "Overlay UV Vertical Filter Coefficients (HD) #21")
    CSR_REG( "UV_VCOEFS_HD22", 0x35558, "Overlay UV Vertical Filter Coefficients (HD) #22")
    CSR_REG( "UV_VCOEFS_HD23", 0x3555C, "Overlay UV Vertical Filter Coefficients (HD) #23")
    CSR_REG( "UV_VCOEFS_HD24", 0x35560, "Overlay UV Vertical Filter Coefficients (HD) #24")
    CSR_REG( "UV_VCOEFS_HD25", 0x35564, "Overlay UV Vertical Filter Coefficients (HD) #25")
    /* {"uv_vcoefs_hd",0x35500,104,NULL,vdcPutRegister,0,0,0,0,NULL}, */

    /* 26 entries * 4 bytes */
    CSR_REG( "UV_HCOEFS_HD0",  0x35600, "Overlay UV Horizontal Filter Coefficients (HD) #0")
    CSR_REG( "UV_HCOEFS_HD1",  0x35604, "Overlay UV Horizontal Filter Coefficients (HD) #1")
    CSR_REG( "UV_HCOEFS_HD2",  0x35608, "Overlay UV Horizontal Filter Coefficients (HD) #2")
    CSR_REG( "UV_HCOEFS_HD3",  0x3560C, "Overlay UV Horizontal Filter Coefficients (HD) #3")
    CSR_REG( "UV_HCOEFS_HD4",  0x35610, "Overlay UV Horizontal Filter Coefficients (HD) #4")
    CSR_REG( "UV_HCOEFS_HD5",  0x35614, "Overlay UV Horizontal Filter Coefficients (HD) #5")
    CSR_REG( "UV_HCOEFS_HD6",  0x35618, "Overlay UV Horizontal Filter Coefficients (HD) #6")
    CSR_REG( "UV_HCOEFS_HD7",  0x3561C, "Overlay UV Horizontal Filter Coefficients (HD) #7")
    CSR_REG( "UV_HCOEFS_HD8",  0x35620, "Overlay UV Horizontal Filter Coefficients (HD) #8")
    CSR_REG( "UV_HCOEFS_HD9",  0x35624, "Overlay UV Horizontal Filter Coefficients (HD) #9")
    CSR_REG( "UV_HCOEFS_HD10", 0x35628, "Overlay UV Horizontal Filter Coefficients (HD) #10")
    CSR_REG( "UV_HCOEFS_HD11", 0x3562C, "Overlay UV Horizontal Filter Coefficients (HD) #11")
    CSR_REG( "UV_HCOEFS_HD12", 0x35630, "Overlay UV Horizontal Filter Coefficients (HD) #12")
    CSR_REG( "UV_HCOEFS_HD13", 0x35634, "Overlay UV Horizontal Filter Coefficients (HD) #13")
    CSR_REG( "UV_HCOEFS_HD14", 0x35638, "Overlay UV Horizontal Filter Coefficients (HD) #14")
    CSR_REG( "UV_HCOEFS_HD15", 0x3563C, "Overlay UV Horizontal Filter Coefficients (HD) #15")
    CSR_REG( "UV_HCOEFS_HD16", 0x35640, "Overlay UV Horizontal Filter Coefficients (HD) #16")
    CSR_REG( "UV_HCOEFS_HD17", 0x35644, "Overlay UV Horizontal Filter Coefficients (HD) #17")
    CSR_REG( "UV_HCOEFS_HD18", 0x35648, "Overlay UV Horizontal Filter Coefficients (HD) #18")
    CSR_REG( "UV_HCOEFS_HD19", 0x3564C, "Overlay UV Horizontal Filter Coefficients (HD) #19")
    CSR_REG( "UV_HCOEFS_HD20", 0x35650, "Overlay UV Horizontal Filter Coefficients (HD) #20")
    CSR_REG( "UV_HCOEFS_HD21", 0x35654, "Overlay UV Horizontal Filter Coefficients (HD) #21")
    CSR_REG( "UV_HCOEFS_HD22", 0x35658, "Overlay UV Horizontal Filter Coefficients (HD) #22")
    CSR_REG( "UV_HCOEFS_HD23", 0x3565C, "Overlay UV Horizontal Filter Coefficients (HD) #23")
    CSR_REG( "UV_HCOEFS_HD24", 0x35660, "Overlay UV Horizontal Filter Coefficients (HD) #24")
    CSR_REG( "UV_HCOEFS_HD25", 0x35664, "Overlay UV Horizontal Filter Coefficients (HD) #25")
    /* {"uv_hcoefs_hd",0x35600,104,NULL,vdcPutRegister,0,0,0,0,NULL}, */

    /* Memory Group start = 0x60000 size = 0x200 */
    CSR_REG_W_BB("HTOTAL_A",         0x60000,    g_csr_VDC_HTOTAL_A, "Pipe A Horizontal Total Register")
    CSR_REG_W_BB("HBLANK_A",         0x60004,    g_csr_VDC_HBLANK_A, "Pipe A Horizontal Blank Register")
    CSR_REG_W_BB("HSYNC_A",          0x60008,    g_csr_VDC_HSYNC_A, "Pipe A Horizontal Sync Register")
    CSR_REG_W_BB("VTOTAL_A",         0x6000C,    g_csr_VDC_VTOTAL_A, "Pipe A Vertical Total Register")
    CSR_REG_W_BB("VBLANK_A",         0x60010,    g_csr_VDC_VBLANK_A, "Pipe A Vertical Blank Register")
    CSR_REG_W_BB("VSYNC_A",          0x60014,    g_csr_VDC_VSYNC_A, "Pipe A Vertical Sync Register")
    CSR_REG("VSYNCSHIFT_A",     0x60028,    "Vertical Sync Shift Register")
    CSR_REG_W_BB("PIPEASRC",         0x6001C,    g_csr_VDC_PIPEASRC, "Pipe A Source Image Size")
    CSR_REG("BCLRPAT_A",        0x60020,    "Pipe A Border Color Pattern Register")
    CSR_REG_W_BB("CANVSCLR_A",       0x60024,    g_csr_VDC_CANVSCLR_A, "Pipe A Canvas (Background) Color Register")

    CSR_REG("CRCCTRLCOLORA",    0x60050,    "Pipe A CRC Color Channel Control Register (Red)")
    CSR_REG("CRCCTRLCOLORA0",   0x60054,    "Pipe A CRC Color Channel Control Register (Green)")
    CSR_REG("CRCCTRLCOLORA1",   0x60058,    "Pipe A CRC Color Channel Control Register (Blue)")
    CSR_REG("CRCCTRLCOLORA2",   0x6005C,    "Pipe A CRC Color Channel Control Register (Alpha)")
    CSR_REG("CRCRESCOLORA0",    0x60060,    "Pipe A CRC Color Channel Result Register (Red)")
    CSR_REG("CRCRESCOLORA1",    0x60064,    "Pipe A CRC Color Channel Result Register (Green)")
    CSR_REG("CRCRESCOLORA2",    0x60068,    "Pipe A CRC Color Channel Result Register (Blue)")
    CSR_REG("CRCRESCOLORA3",    0x6006C,    "Pipe A CRC Color Channel Result Register (Alpha)")

    /* put this in special region, offset 8 */
    CSR_REG_W_BB("PVOCONFIG",        0x61140,    g_csr_VDC_PVOCONFIG, "Pixel Video Output Configuration Register")

    /* Memory Group start = 0x70000 size = 0x200 */
    CSR_REG_W_BB("PIPEACONF",        0x70008,    g_csr_VDC_PIPEACONF, "Pipe A Configuration Register")
    CSR_REG_W_BB("PIPEASTAT",        0x70024,    g_csr_VDC_PIPEASTAT, "Pipe A Display Status")
    CSR_REG("DSPARB",           0x70030,    "DDB Configuration")
    CSR_REG("PIPEAFRAMEHIGH",   0x70040,    "Frame Count")
    CSR_REG("PIPEAFRAMEPIXEL",  0x70044,    "Pixel Count")
    CSR_REG_W_BB("RCOMPSTAT",        0x70048,    g_csr_VDC_RCOMPSTAT, "MDVO RCOMP STATUS REGISTER")
    CSR_REG("RCOMPCFG",         0x7004C,    "MDVO RCOMP CONFIG REGISTER")
    CSR_REG("GBLCTRSTRED",      0x70050,    "Global Contrast Adjustment Weight for Red")
    CSR_REG("GBLCTRSTGREEN",    0x70054,    "Global Contrast Adjustment Weight for GREEN")
    CSR_REG("GBLCTRSTBLUE",     0x70058,    "Global Contrast Adjustment Weight for Blue")
    CSR_REG("GBLBRT",           0x7005C,    "Global Brightness Adjustment Coefficient")
    CSR_REG("CURCNTR",          0x70080,    "Cursor Control Register")
    CSR_REG("CURABASE",         0x70084,    "Cursor Base Address Register")
    CSR_REG("CURAPOS",          0x70088,    "Cursor Position Register")
    CSR_REG("CURAPALET0",       0x70090,    "Cursor Palette Register 0")
    CSR_REG("CURAPALET1",       0x70094,    "Cursor Palette Register 1")
    CSR_REG("CURAPALET2",       0x70098,    "Cursor Palette Register 2")
    CSR_REG("CURAPALET3",       0x7009C,    "Cursor Palette Register 3")
    CSR_REG("CURARESV",         0x7018C,    "Cursor (Reserved)")

    CSR_REG("CHKN_BITS",        0x70400,    "Chicken Bits")

    /* Memory Group start = 0x71000 size = 0x200 */
    CSR_REG("DSPBCNTR",         0x71180,    "Subtitle Plane Control Register")
    CSR_REG("DSPBADDR",         0x71184,    "Subtitle Plane Start Address Register")
    CSR_REG("DSPBSTRIDE",       0x71188,    "Subtitle Plane Stride Register")
    CSR_REG("DSPBPOS",          0x7118C,    "Subtitle Position Register")
    CSR_REG("DSPBSIZE",         0x71190,    "Subtitle Height and Width Register")

    /* Memory Group start = 0x72100 size = 0x200 */
    CSR_REG_W_BB("DSPCCNTR",         0x72180,    g_csr_VDC_DSPCCNTR, "Graphics Plane Control Register")
    CSR_REG("DSPCADDR",         0x72184,    "Graphics Plane Start Address Register")
    CSR_REG_W_BB("DSPCSTRIDE",       0x72188,    g_csr_VDC_DSPCSTRIDE, "Graphics Plane Stride Register")
    CSR_REG_W_BB("DSPCPOS",          0x7218C,    g_csr_VDC_DSPCPOS, "Graphics Plane Position Register")
    CSR_REG_W_BB("DSPCSIZE",         0x72190,    g_csr_VDC_DSPCSIZE, "Graphics Plane Height and Width Register")

    /* region 11, 129 entries, 4 bytes each */
    CSR_REG("DSPCGAMLUT",       0x72200,    "Graphics Plane Gamma Correction Registers")

    /* Memory Group start = 0x78000 size = 0x200 */
    CSR_REG("HTOTAL_SD",        0x78000,    "Pipe Horizontal Total Register")
    CSR_REG("HBLANK_SD",        0x78004,    "Pipe Horizontal Blank Register")
    CSR_REG("HSYNC_SD",         0x78008,    "Pipe Horizontal Sync Register")
    CSR_REG("VTOTAL_SD",        0x7800C,    "Pipe Vertical Total Register")
    CSR_REG("VBLANK_SD",        0x78010,    "Pipe Vertical Blank Register")
    CSR_REG("VSYNC_SD",         0x78014,    "Pipe Vertical Sync Register")
    CSR_REG("VSYNCSHIFT_SD",    0x78028,    "Vertical Sync Shift Register")
    CSR_REG("PADRSTCNTRL_SD",   0x78044,    "Pads Reset Controls")  /* added in 0.9 EAS - JWC */
    CSR_REG("RCOMPCFG_SD",      0x7804C,    "Rcomp Config Register")        /* added in 0.9 EAS - JWC */
    CSR_REG("PIPEACONF_SD",     0x78050,    "Pipe Configuration Register")
    CSR_REG("PIPEASTAT_SD",     0x78054,    "Pipe Display Status")
    CSR_REG("PIPEAFRAMEHIGH_SD",0x78058,    "Frame Count")
    CSR_REG("PIPEAFRAMEPIXEL_SD",0x7805C,   "Pixel Count")

    /* Memory Group start = 0x79000 size = 0x200 */
    CSR_REG("HTOTAL_HD",        0x79000,    "Pipe Horizontal Total Register")
    CSR_REG("HBLANK_HD",        0x79004,    "Pipe Horizontal Blank Register")
    CSR_REG("HSYNC_HD",         0x79008,    "Pipe Horizontal Sync Register")
    CSR_REG("VTOTAL_HD",        0x7900C,    "Pipe Vertical Total Register")
    CSR_REG("VBLANK_HD",        0x79010,    "Pipe Vertical Blank Register")
    CSR_REG("VSYNC_HD",         0x79014,    "Pipe Vertical Sync Register")
    CSR_REG("VSYNCSHIFT_HD",    0x79028,    "Vertical Sync Shift Register")
    CSR_REG("PADRSTCNTRL_HD",   0x79044,    "Pads Reset Controls")  /* added in 0.9 EAS - JWC */
    CSR_REG("RCOMPCFG_HD",      0x7904C,    "Rcomp Config Register")        /* added in 0.9 EAS - JWC */
    CSR_REG("PIPEACONF_HD",     0x79050,    "Pipe Configuration Register")
    CSR_REG("PIPEASTAT_HD",     0x79054,    "Pipe Display Status")
    CSR_REG("PIPEAFRAMEHIGH_HD",0x79058,    "Frame Count")
    CSR_REG("PIPEAFRAMEPIXEL_HD",0x7905C,   "Pixel Count")


    CSR_NULL_TERM()
};
#endif /* SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_VDC_specific_events[] =
{
    { "OUT_FIFO_FULL",      1,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    2,      "", NULL },

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_VDC_sven_module =
{
    "GEN2_VDC",
    SVEN_module_GEN2_VDC,
    1*1024*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_VDC,
#else
    NULL,
#endif
    "MMOD: VDC Function (GEN2)",      /* TODO: Get a better text string */
    g_VDC_specific_events,          /* TODO-Later: Define important events specific to my module */
    NULL                            /* extension list */
};
