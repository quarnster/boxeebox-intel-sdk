/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Simplest Possible example of EAS definition */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
#ifdef SVEN_INTERNAL_BUILD

/* Declare the bit-breakout for the register defined in the EAS_Register defs below.
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MyModule_versions.
 */
static const struct EAS_RegBits g_bit_breakout_vr_SPI_CntrlReg0[] = 
{
    { "RESERVED_31_16",		  16,16, "", NULL },
    { "SCR",         			8,	8, "Serial Clock Rate", NULL },		// Value (0 to 255) used to generate transmission rate of SSP.
                                                                     // Bit rate = 3.6864x106 / (2 x (SCR + 1)) where SCR is a decimal integer
    { "Enable",           		7,	1, "Synchronous Serial Port Enable", NULL }, // 0: SSP operation disabled 
    { "RESERVED_6",  		   6, 1, "", NULL },
    { "FrameFormat",    		4,	2, "", NULL },    // 00: Motorola SPI format.
    { "DataSizeSelect", 		0,	4, "", NULL }, 	// 0-2 undefined. 0011=4, 0100=5, ... , 1110=15, 1111=16 bit data.
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_bit_breakout_vr_SPI_CntrlReg1[] = 
{
    { "RESERVED_31_16",16,16, "", NULL },
    { "STRF",  		  15, 1, "Select FIFO for EFWR", NULL },
    { "EFWR",          14,	1, "Enable FIFO Write/Read", NULL },
    { "RESERVED_13_12",12, 2, "", NULL },
    { "RFT",           10,	2, "Receive FIFO Threshold", NULL }, // Threshold level at which Receive FIFO asserts interrupt. This level should be set to the desired threshold value minus 1.
    { "RESERVED_9_8",  	8, 2, "", NULL },
    { "TFT",           	6,	2, "Transmit FIFO Threshold", NULL }, // Threshold level at which Transmit FIFO asserts interrupt. This level should be set to the desired threshold value minus 1.
    { "RESERVED_5",  	5, 1, "", NULL },
    { "SPH",  		      4, 1, "SCLK phase setting", NULL },
    { "SPO",  		      3, 1, "SCLK polarity setting", NULL },
    { "LBM",  		      2, 1, "Loop-Back Mode", NULL },
    { "TIE",  		      1, 1, "Transmit FIFOInterrupt Enable", NULL },
    { "RIE",  		      0, 1, "Receive FIFO Interrupt Enable", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};


static const struct EAS_RegBits g_bit_breakout_vr_SPI_Status[] = 
{
    { "RESERVED_31_14",16,14, "", NULL },
    { "RFL",  		     12, 2, "Receive FIFO level", NULL },
    { "RESERVED_11_10",10, 2, "", NULL },
    { "TFL",  	         8, 2, "Transmit FIFO level", NULL },
    { "ROR",           	7,	1, "Receive FIFO overrun", NULL }, // Threshold level at which Transmit FIFO asserts interrupt. This level should be set to the desired threshold value minus 1.
    { "RFS",  		      6, 1, "Receive FIFO Service Request", NULL },
    { "TFS",  		      5, 1, "Transmit FIFO Service Request", NULL },
    { "BUSY",  		   4, 1, "", NULL },    // 1 = currently transmitting or receiving a frame.
    { "RNE",  		      3, 1, "Receive FIFO not empty", NULL },
    { "TNF",  		      2, 1, "Transmit FIFO not full", NULL },
    { "RESERVED_1",     1, 1, "", NULL },
    { "ALT_FRM", 	      0, 1, "", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};


/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MyModule_versions.
 */
static const struct EAS_Register g_csr_vr_SPI[] =
{
    { "CntrlReg0",    0x00, g_bit_breakout_vr_SPI_CntrlReg0, "Control Register 0", NULL }, /* reg bits defined above */
    { "CntrlReg1",    0x04, g_bit_breakout_vr_SPI_CntrlReg1, "Control Register 1", NULL },
    { "Status",       0x08, g_bit_breakout_vr_SPI_Status   , "Status Register"   , NULL },
    { "InterruptTest",0x0C, NULL                           , "Interrupt Test"    , NULL },
    { "Data",         0x10, NULL                           , "Data"              , NULL },
    { "TestClock",    0x14, NULL                           , "Test Clock Enable" , NULL },
    { "TestControl",  0x18, NULL                           , "Test Control"      , NULL },
    { "TestMode",     0x1C, NULL                           , "Test Mode"         , NULL },
    { "TestInputStimulus",0x20, NULL                       , "Test Input Stimulus", NULL },
    { "TestOutputCapture",0x24, NULL                       , "Test Output Capture", NULL },
	{ NULL,0,NULL,"",NULL }	/* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

/*	 TODO-Later: Define important events specific to my module
 *  Use the below structure for creating trackable high level events versus 
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_vr_SPI_specific_events[] =
{
	{ "OUT_FIFO_FULL",		1,		"Software did read captured frames in time", NULL },
	{ "IN_FIFO_STARVED",	2,		"", NULL },

	{ NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_vr_SPI_sven_module =
{
	"GEN2_SPI",                     /* Module Name */
	SVEN_module_GEN2_SPI,           /* Module ID in <sven_module.h> */
   0x100,                        /* Size of register IO bank */
#ifdef SVEN_INTERNAL_BUILD
	g_csr_vr_SPI,                 /* The main table that contains the reversible register definitions. */
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
	"SPI: Serial Peripheral Interface (GEN2)",
	g_vr_SPI_specific_events,     /* Define important events specific to my module */
	NULL                          /* EAS extension list */
};
