/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
static const struct EAS_RegBits g_csr_BSR_TSP_PF_ENABLE[] =
{
    { "RSVD_31_11",11,21,"",NULL },      /* */
    { "OCF",10,1,"",NULL },      /* */
    { "CRC",9,1,"",NULL },     /* */
    { "DIS",8,1,"",NULL },    /* */
    { "DET",7,1,"",NULL },   /* */
    { "PPF",6,1,"",NULL },    /* */
    { "WDT",5,1,"",NULL },       /* */
    { "FE",4,1,"",NULL },      /* */
    { "FF",3,1,"",NULL },    /* */
    { "PLT",2,1,"",NULL },             /* */
    { "PGT",1,1,"",NULL },      /* */
    { "EN",0,1,"",NULL },        /* */

    CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_BSR_TSP_PF_STATUS_VR[] =
{
    { "RSVD_31_11",11,21,"",NULL },      /* */
    { "OCF",10,1,"",NULL },      /* */
    { "CRC",9,1,"",NULL },     /* */
    { "DIS",8,1,"",NULL },    /* */
    { "DET",7,1,"",NULL },   /* */
    { "PPF",6,1,"",NULL },    /* */
    { "WDT",5,1,"",NULL },       /* */
    { "FE",4,1,"",NULL },      /* */
    { "FF",3,1,"",NULL },    /* */
    { "PLT",2,1,"",NULL },             /* */
    { "PGT",1,1,"",NULL },      /* */
    { "RSVD_0",0,1,"",NULL },        /* */

    CSR_BB_NULL_TERM()
};


/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_TSP_versions.
 */
static const struct EAS_Register g_csr_TSP[] =
{

    CSR_REG("PF_P0CFG",                  0x00000,    "Pre-Filter NIM Parallel 0 Config")
    CSR_REG("PF_P1CFG",                  0x00004,    "Pre-Filter NIM Parallel 1 Config")
    CSR_REG("PF_S0CFG",                  0x00008,    "Pre-Filter NIM Serial 0 Config")
    CSR_REG("PF_S1CFG",                  0x0000C,    "Pre-Filter NIM Serial 1 Config")
    CSR_REG("PF_OC_MODE",                0x00020,    "Pre-filter OpenCable Mode")

    /* This block is 1394 registers */
    CSR_REG("CE_CONFIG_RX",              0x00040,    "CE Configuration Register 0 (Receive)")
    CSR_REG("CE_CONFIG_TX",              0x00044,    "CE Configuration Register 1 (Transmit)")
    CSR_REG("CE_INTERRUPT_ENABLE",       0x00048,    "CE Interrupt Enable Register")
    CSR_REG("CE_INTERRUPT_STATUS",       0x0004C,    "CE Interrupt Status Register")
    CSR_REG("CE_TX_FORCE",               0x0006C,    "CE Force Register")
    CSR_REG("CE_RX_TS_LOAD",             0x00080,    "Receive Timestamp counter load value")
    /* CSR_REG("CE_RX_TS_CNT",           0x00084,    "Receive Timestamp counter")                    NO LONGER NEEDED.  Removed by JWC (1394regs.doc)*/
    CSR_REG("CE_RX_TS_NEW",              0x00088,    "Receive Timestamp New Value")
    CSR_REG("CE_RX_TS_OLD",              0x0008C,    "Receive Timestamp Old Value")
    CSR_REG("CE_RX_DIF_DELAY",           0x00090,    "Delay between FrameSync and DIF in DV mode")
    CSR_REG("CE_RX_PACKET_SIZE",         0x00098,    "Input packet size in bytes")
    /* CSR_REG("CE_TX_TS_LOAD",          0x000C0,    "Transmit Timestamp counter load value")        NO LONGER NEEDED.  Removed by JWC (1394regs.doc) */
    /* CSR_REG("CE_TX_TS_CNT",           0x000C4,    "Transmit Timestamp counter")                   NO LONGER NEEDED.  Removed by JWC (1394regs.doc) */
    CSR_REG("CE_TX_TS_NEW",              0x000C8,    "Transmit Timestamp New Value")
    CSR_REG("CE_TX_TS_OLD",              0x000CC,    "Transmit Timestamp Old Value")
    CSR_REG("CE_OUT_FRAME_INTERVAL",     0x000D0,    "DV Frame interval")
    CSR_REG("CE_OUT_PACKET_INTERVAL",    0x000D4,    "DV Packet interval within DV frame")
    CSR_REG("CE_DIF_PACKET_SIZE",        0x000D8,    "DV DIF packet size in bytes")
    CSR_REG("CE_DIF_FRAME_SIZE",         0x000DC,    "DV Video Frame size in DIF packets")
    /* CSR_REG("CE_OUT_FRAME_INTERVAL_CNT",0x000E0,  "Current Frame Interval Counter")               NO LONGER NEEDED.  Removed by JWC (1394regs.doc) */
    /* CSR_REG("CE_OUT_PACKET_INTERVAL_CNT",0x000E4, "Current Packet Counter")                       NO LONGER NEEDED.  Removed by JWC (1394regs.doc) */
    CSR_REG("CE_PACKET_SIZE_CNT",        0x000E8,    "Current Number of Bytes to the end of DIF packet")
    CSR_REG("CE_DIF_FRAME_SIZE_CNT",     0x000EC,    "Current Number of DIF packets to the end of the current DV frame")

    /* this is an array of 32 members 4 bytes each */
    /* CSR_REG("PF0_PMM",                0x04000,    "Pre-filter 0 Mask / Match") */
    CSR_REG("PF0_PMM_0",                 0x04000,    "Pre-filter 0 PID 0 Mask / Match")
    CSR_REG("PF0_PMM_1",                 0x04004,    "Pre-filter 0 PID 1 Mask / Match")
    CSR_REG("PF0_PMM_2",                 0x04008,    "Pre-filter 0 PID 2 Mask / Match")
    CSR_REG("PF0_PMM_3",                 0x0400c,    "Pre-filter 0 PID 3 Mask / Match")
    CSR_REG("PF0_PMM_4",                 0x04010,    "Pre-filter 0 PID 4 Mask / Match")
    CSR_REG("PF0_PMM_5",                 0x04014,    "Pre-filter 0 PID 5 Mask / Match")
    CSR_REG("PF0_PMM_6",                 0x04018,    "Pre-filter 0 PID 6 Mask / Match")
    CSR_REG("PF0_PMM_7",                 0x0401c,    "Pre-filter 0 PID 7 Mask / Match")
    CSR_REG("PF0_PMM_8",                 0x04020,    "Pre-filter 0 PID 8 Mask / Match")
    CSR_REG("PF0_PMM_9",                 0x04024,    "Pre-filter 0 PID 9 Mask / Match")
    CSR_REG("PF0_PMM_10",                0x04028,    "Pre-filter 0 PID 10 Mask / Match")
    CSR_REG("PF0_PMM_11",                0x0402c,    "Pre-filter 0 PID 11 Mask / Match")
    CSR_REG("PF0_PMM_12",                0x04030,    "Pre-filter 0 PID 12 Mask / Match")
    CSR_REG("PF0_PMM_13",                0x04034,    "Pre-filter 0 PID 13 Mask / Match")
    CSR_REG("PF0_PMM_14",                0x04038,    "Pre-filter 0 PID 14 Mask / Match")
    CSR_REG("PF0_PMM_15",                0x0403c,    "Pre-filter 0 PID 15 Mask / Match")
    CSR_REG("PF0_PMM_16",                0x04040,    "Pre-filter 0 PID 16 Mask / Match")
    CSR_REG("PF0_PMM_17",                0x04044,    "Pre-filter 0 PID 17 Mask / Match")
    CSR_REG("PF0_PMM_18",                0x04048,    "Pre-filter 0 PID 18 Mask / Match")
    CSR_REG("PF0_PMM_19",                0x0404c,    "Pre-filter 0 PID 19 Mask / Match")
    CSR_REG("PF0_PMM_20",                0x04050,    "Pre-filter 0 PID 20 Mask / Match")
    CSR_REG("PF0_PMM_21",                0x04054,    "Pre-filter 0 PID 21 Mask / Match")
    CSR_REG("PF0_PMM_22",                0x04058,    "Pre-filter 0 PID 22 Mask / Match")
    CSR_REG("PF0_PMM_23",                0x0405c,    "Pre-filter 0 PID 23 Mask / Match")
    CSR_REG("PF0_PMM_24",                0x04060,    "Pre-filter 0 PID 24 Mask / Match")
    CSR_REG("PF0_PMM_25",                0x04064,    "Pre-filter 0 PID 25 Mask / Match")
    CSR_REG("PF0_PMM_26",                0x04068,    "Pre-filter 0 PID 26 Mask / Match")
    CSR_REG("PF0_PMM_27",                0x0406c,    "Pre-filter 0 PID 27 Mask / Match")
    CSR_REG("PF0_PMM_28",                0x04070,    "Pre-filter 0 PID 28 Mask / Match")
    CSR_REG("PF0_PMM_29",                0x04074,    "Pre-filter 0 PID 29 Mask / Match")
    CSR_REG("PF0_PMM_30",                0x04078,    "Pre-filter 0 PID 30 Mask / Match")
    CSR_REG("PF0_PMM_31",                0x0407c,    "Pre-filter 0 PID 31 Mask / Match")

    CSR_REG("PF0_CFG",                   0x004100,   "Pre-filter 0 Config")
    CSR_REG_W_BB("PF0_STATUS",           0x004104,g_csr_BSR_TSP_PF_STATUS_VR,   "Pre-filter 0 Filter Status")
    CSR_REG_W_BB("PF0_ENABLE",           0x004108,g_csr_BSR_TSP_PF_ENABLE,   "Pre-filter 0 Filter Enable")   /* added ~jwcarrol 10/26/2005 */

    CSR_REG("PF0_DMA_BASE",              0x004200,   "Pre-filter 0 DMA Base Addr")
    CSR_REG("PF0_DMA_SIZE",              0x004204,   "Pre-filter 0 DMA Size")
    CSR_REG("PF0_DMA_WR_PTR",            0x004208,   "Pre-filter 0 DMA Write Pointer")
    CSR_REG("PF0_DMA_SHDW_WR_PTR_ADDR",  0x00420C,   "Pre-filter 0 DMA Shadow Write Ptr Addr")
    CSR_REG("PF0_DMA_RD_PTR",            0x004210,   "Pre-filter 0 DMA Read Pointer")
    CSR_REG("PF0_DMA_SHDW_WR_CNTR",      0x004214,   "Pre-filter 0 DMA Shadow Write Counter")
    CSR_REG("PF0_NIM_WDT",               0x004218,   "Pre-filter 0 NIM Watch Dog Timer")
    CSR_REG("PF0_PCR_CONFIG",            0x004300,   "Pre-filter 0 PCR Config")
    CSR_REG("PF0_TBASE_LOCAL_0",         0x004304,   "Pre-filter 0 Time base Local 0")
    CSR_REG("PF0_TBASE_LOCAL_1",         0x004308,   "Pre-filter 0 Time Base Local 1")
    CSR_REG("PF0_PCR_LOCAL_A0",          0x00430C,   "Pre-filter 0 PCR Local A0")
    CSR_REG("PF0_PCR_LOCAL_A1",          0x004310,   "Pre-filter 0 PCR Local A1")
    CSR_REG("PF0_PCR_LOCAL_B0",          0x004314,   "Pre-filter 0 PCR Local B0")
    CSR_REG("PF0_PCR_LOCAL_B1",          0x004318,   "Pre-filter 0 PCR Local B1")
    CSR_REG("PF0_PCR_REMOTE_A0",         0x00431C,   "Pre-filter 0 PCR Remote A0")
    CSR_REG("PF0_PCR_REMOTE_A1",         0x004320,   "Pre-filter 0 PCR Remote A1")
    CSR_REG("PF0_PCR_REMOTE_B0",         0x004324,   "Pre-filter 0 PCR Remote B0")
    CSR_REG("PF0_PCR_REMOTE_B1",         0x004328,   "Pre-filter 0 PCR Remote B1")
    CSR_REG("PF0_OC_CONFIG",             0x004340,   "Pre-filter 0 OpenCable Configuration")
    CSR_REG("PF0_OC_HDR0A",              0x004344,   "Pre-filter 0 OpenCable HDR0a")
    CSR_REG("PF0_OC_HDR0B",              0x004348,   "Pre-filter 0 OpenCable HDR0b")
    CSR_REG("PF0_OC_HDR1A",              0x00434C,   "Pre-filter 0 OpenCable HDR1a")
    CSR_REG("PF0_OC_HDR1B",              0x004350,   "Pre-filter 0 OpenCable HDR1b")
    CSR_REG("PF0_OC_HDR2A",              0x004354,   "Pre-filter 0 OpenCable HDR2a")
    CSR_REG("PF0_OC_HDR2B",              0x004358,   "Pre-filter 0 OpenCable HDR2b")

    /* this is an array of 32 members 4 bytes each */
    /* CSR_REG("pf1_pmm",                0x008000,   "Pre-filter 1 Mask / Match") */
    CSR_REG("PF1_PMM_0",                 0x008000,   "Pre-filter 1 PID 0 Mask / Match")
    CSR_REG("PF1_PMM_1",                 0x008004,   "Pre-filter 1 PID 1 Mask / Match")
    CSR_REG("PF1_PMM_2",                 0x008008,   "Pre-filter 1 PID 2 Mask / Match")
    CSR_REG("PF1_PMM_3",                 0x00800c,   "Pre-filter 1 PID 3 Mask / Match")
    CSR_REG("PF1_PMM_4",                 0x008010,   "Pre-filter 1 PID 4 Mask / Match")
    CSR_REG("PF1_PMM_5",                 0x008014,   "Pre-filter 1 PID 5 Mask / Match")
    CSR_REG("PF1_PMM_6",                 0x008018,   "Pre-filter 1 PID 6 Mask / Match")
    CSR_REG("PF1_PMM_7",                 0x00801c,   "Pre-filter 1 PID 7 Mask / Match")
    CSR_REG("PF1_PMM_8",                 0x008020,   "Pre-filter 1 PID 8 Mask / Match")
    CSR_REG("PF1_PMM_9",                 0x008024,   "Pre-filter 1 PID 9 Mask / Match")
    CSR_REG("PF1_PMM_10",                0x008028,   "Pre-filter 1 PID 10 Mask / Match")
    CSR_REG("PF1_PMM_11",                0x00802c,   "Pre-filter 1 PID 11 Mask / Match")
    CSR_REG("PF1_PMM_12",                0x008030,   "Pre-filter 1 PID 12 Mask / Match")
    CSR_REG("PF1_PMM_13",                0x008034,   "Pre-filter 1 PID 13 Mask / Match")
    CSR_REG("PF1_PMM_14",                0x008038,   "Pre-filter 1 PID 14 Mask / Match")
    CSR_REG("PF1_PMM_15",                0x00803c,   "Pre-filter 1 PID 15 Mask / Match")
    CSR_REG("PF1_PMM_16",                0x008040,   "Pre-filter 1 PID 16 Mask / Match")
    CSR_REG("PF1_PMM_17",                0x008044,   "Pre-filter 1 PID 17 Mask / Match")
    CSR_REG("PF1_PMM_18",                0x008048,   "Pre-filter 1 PID 18 Mask / Match")
    CSR_REG("PF1_PMM_19",                0x00804c,   "Pre-filter 1 PID 19 Mask / Match")
    CSR_REG("PF1_PMM_20",                0x008050,   "Pre-filter 1 PID 20 Mask / Match")
    CSR_REG("PF1_PMM_21",                0x008054,   "Pre-filter 1 PID 21 Mask / Match")
    CSR_REG("PF1_PMM_22",                0x008058,   "Pre-filter 1 PID 22 Mask / Match")
    CSR_REG("PF1_PMM_23",                0x00805c,   "Pre-filter 1 PID 23 Mask / Match")
    CSR_REG("PF1_PMM_24",                0x008060,   "Pre-filter 1 PID 24 Mask / Match")
    CSR_REG("PF1_PMM_25",                0x008064,   "Pre-filter 1 PID 25 Mask / Match")
    CSR_REG("PF1_PMM_26",                0x008068,   "Pre-filter 1 PID 26 Mask / Match")
    CSR_REG("PF1_PMM_27",                0x00806c,   "Pre-filter 1 PID 27 Mask / Match")
    CSR_REG("PF1_PMM_28",                0x008070,   "Pre-filter 1 PID 28 Mask / Match")
    CSR_REG("PF1_PMM_29",                0x008074,   "Pre-filter 1 PID 29 Mask / Match")
    CSR_REG("PF1_PMM_30",                0x008078,   "Pre-filter 1 PID 30 Mask / Match")
    CSR_REG("PF1_PMM_31",                0x00807c,   "Pre-filter 1 PID 31 Mask / Match")

    CSR_REG("PF1_CFG",                   0x008100,   "Pre-filter 1 Config")
    CSR_REG_W_BB("PF1_STATUS",           0x008104,g_csr_BSR_TSP_PF_STATUS_VR,   "Pre-filter 1 Filter Status")
    CSR_REG_W_BB("PF1_ENABLE",           0x008108,g_csr_BSR_TSP_PF_ENABLE,   "Pre-filter 1 Filter Enable")  /*added ~jwcarrol 10/26/2005 */

    CSR_REG("PF1_DMA_BASE",              0x008200,   "Pre-filter 1 DMA Base Addr")
    CSR_REG("PF1_DMA_SIZE",              0x008204,   "Pre-filter 1 DMA Size")
    CSR_REG("PF1_DMA_WR_PTR",            0x008208,   "Pre-filter 1 DMA Write Pointer")
    CSR_REG("PF1_DMA_SHDW_WR_PTR_ADDR",  0x00820C,   "Pre-filter 1 DMA Shadow Write Ptr Addr")
    CSR_REG("PF1_DMA_RD_PTR",            0x008210,   "Pre-filter 1 DMA Read Pointer")
    CSR_REG("PF1_DMA_SHDW_WR_CNTR",      0x008214,   "Pre-filter 1 DMA Shadow Write Counter")
    CSR_REG("PF1_NIM_WDT",               0x008218,   "Pre-filter 1 NIM Watch Dog Timer")
    CSR_REG("PF1_PCR_CONFIG",            0x008300,   "Pre-filter 1 PCR Config")
    CSR_REG("PF1_TBASE_LOCAL_0",         0x008304,   "Pre-filter 1 Time base Local 0")
    CSR_REG("PF1_TBASE_LOCAL_1",         0x008308,   "Pre-filter 1 Time base Local 1")
    CSR_REG("PF1_PCR_LOCAL_A0",          0x00830C,   "Pre-filter 1 PCR Local A0")
    CSR_REG("PF1_PCR_LOCAL_A1",          0x008310,   "Pre-filter 1 PCR Local A1")
    CSR_REG("PF1_PCR_LOCAL_B0",          0x008314,   "Pre-filter 1 PCR Local B0")
    CSR_REG("PF1_PCR_LOCAL_B1",          0x008318,   "Pre-filter 1 PCR Local B1")
    CSR_REG("PF1_PCR_REMOTE_A0",         0x00831C,   "Pre-filter 1 PCR Remote A0")
    CSR_REG("PF1_PCR_REMOTE_A1",         0x008320,   "Pre-filter 1 PCR Remote A1")
    CSR_REG("PF1_PCR_REMOTE_B0",         0x008324,   "Pre-filter 1 PCR Remote B0")
    CSR_REG("PF1_PCR_REMOTE_B1",         0x008328,   "Pre-filter 1 PCR Remote B1")
    CSR_REG("PF1_OC_CONFIG",             0x008340,   "Pre-filter 1 OpenCable Configuration")
    CSR_REG("PF1_OC_HDR0A",              0x008344,   "Pre-filter 1 OpenCable HDR0a")
    CSR_REG("PF1_OC_HDR0B",              0x008348,   "Pre-filter 1 OpenCable HDR0b")
    CSR_REG("PF1_OC_HDR1A",              0x00834C,   "Pre-filter 1 OpenCable HDR1a")
    CSR_REG("PF1_OC_HDR1B",              0x008350,   "Pre-filter 1 OpenCable HDR1b")
    CSR_REG("PF1_OC_HDR2A",              0x008354,   "Pre-filter 1 OpenCable HDR2a")
    CSR_REG("PF1_OC_HDR2B",              0x008358,   "Pre-filter 1 OpenCable HDR2b")

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_TSP_specific_events[] =
{
    { "OUT_FIFO_FULL",      1,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    2,      "", NULL },

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_TSP_sven_module =
{
    "GEN2_TSP",
    SVEN_module_GEN2_PREFILT,
    128*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_TSP,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: TSP Function (GEN2)",      /* TODO: Get a better text string */
    g_TSP_specific_events,          /* TODO-Later: Define important events specific to my module */
    NULL                            /* extension list */
};
