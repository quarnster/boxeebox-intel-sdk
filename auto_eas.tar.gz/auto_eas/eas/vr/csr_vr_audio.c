/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

#define CSR_BASE 0x80000
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Simplest Possible example of EAS definition */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

/* Declare the bit-breakout for the register defined in the EAS_Register defs below.
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MyModule_versions.
 */
static const struct EAS_RegBits g_csr_AUDIO_CSR[] =
{
    { "XREMAP",      20,12,"Address of the window into the Intel MSA address space for IA32 accesses.",NULL },
    { "DTS_ENABLE",  19, 1,"Fuse value",NULL },
    { "RSVD_18_5",    8,11,"",NULL },
    { "REMAP",        4, 4,"",NULL },
    { "DSP_INIT",     3, 1,"",NULL },
    { "DSP_RST",      2, 1,"",NULL },
    { "SWRST",        1, 1,"Software Reset. When asserted, active low, drives reset to all dependent blocks, except DSP processor.",NULL },
    { "CLKEN",        0, 1,"When asserted, active high, enables the clock to dependent blocks.",NULL },
    { NULL,0,0,"",NULL }
};

static const struct EAS_RegBits g_csr_AUDIO_ISRX[] =
{
    { "RSVD_31_30",30,2,"",NULL },   /* 31:30 - Reserved */
    { "PCR3",      29,1,"",NULL },   /* 29 - PCR 3 discontinuity interrupt to IA CPU */
    { "PCR2",      28,1,"",NULL },   /* 28 - PCR 2 discontinuity interrupt to IA CPU */
    { "PCR1",      27,1,"",NULL },   /* 27 - PCR 1 discontinuity interrupt to IA CPU */
    { "PCR0",      26,1,"",NULL },   /* 26 - PCR 0 discontinuity interrupt to IA CPU */
    { "IPCD",      25,1,"",NULL },   /* 25 - IPCD Interrupt Request to IA CPU */
    { "IPCX",      24,1,"",NULL },   /* 24 - IPCX Interrupt Request to IA CPU */
    { "TX2_PEND",  23,1,"",NULL },   /* 23 - TX2 interrupt pending to CPU */
    { "TX1_PEND",  22,1,"",NULL },   /* 22 - TX1 interrupt pending to CPU */
    { "TX0_PEND",  21,1,"",NULL },   /* 21 - TX0 interrupt pending to CPU */
    { "RX1_PEND",  20,1,"",NULL },   /* 20 - RX1 interrupt pending to CPU */
    { "RX0_PEND",  19,1,"",NULL },   /* 19 - RX0 interrupt pending to CPU */
    { "DMA7_DES",  18,1,"",NULL },   /* 18 - DMA7 Destination  Interrupt pending to CPU */
    { "DMA7_SRC",  17,1,"",NULL },   /* 17 - DMA7 Source Interrupt pending to CPU */
    { "DMA6_DES",  16,1,"",NULL },   /* 16 - DMA6 Destination  Interrupt pending to CPU */
    { "DMA6_SRC",  15,1,"",NULL },   /* 15 - DMA6 Source Interrupt pending to CPU */
    { "DMA5_DES",  14,1,"",NULL },   /* 14 - DMA5 Destination  Interrupt pending to CPU */
    { "DMA5_SRC",  13,1,"",NULL },   /* 13 - DMA5 Source Interrupt pending to CPU */
    { "DMA4_DES",  12,1,"",NULL },   /* 12 - DMA4 Destination  Interrupt pending to CPU */
    { "DMA4_SRC",  11,1,"",NULL },   /* 11 - DMA4 Source Interrupt pending to CPU */
    { "DMA3_DES",  10,1,"",NULL },   /* 10 - DMA3 Destination  Interrupt pending to CPU */
    { "DMA3_SRC",   9,1,"",NULL },    /* 9  - DMA3 Source Interrupt pending to CPU */
    { "DMA2_DES",   8,1,"",NULL },    /* 8  - DMA2 Destination  Interrupt pending to CPU */
    { "DMA2_SRC",   7,1,"",NULL },    /* 7  - DMA2 Source Interrupt pending to CPU */
    { "DMA1_DES",   6,1,"",NULL },    /* 6  - DMA1 Destination  Interrupt pending to CPU */
    { "DMA1_SRC",   5,1,"",NULL },    /* 5  - DMA1 Source Interrupt pending to CPU */
    { "DMA0_DES",   4,1,"",NULL },    /* 4  - DMA0 Destination  Interrupt pending to CPU */
    { "DMA0_SRC",   3,1,"",NULL },    /* 3  - DMA0 Source Interrupt pending to CPU */
    { "ETS2",       2,1,"",NULL },    /* 2  - ETS2 Interrupt pending to CPU */
    { "ETS1",       1,1,"",NULL },    /* 1  - ETS1 Interrupt pending to CPU */
    { "ETS0",       0,1,"",NULL },    /* 0  - ETS0 Interrupt pending to CPU */
    { NULL,         0,0,"",NULL }     /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_AUDIO_IMRX[] =
{
    { "RSVD_31_30",30,2,"",NULL },   /* 31:30 - Reserved */
    { "PCR3",29,1,"",NULL },   /* 29 - PCR 3 discontinuity interrupt enable to IA CPU */
    { "PCR2",28,1,"",NULL },   /* 28 - PCR 2 discontinuity interrupt enable to IA CPU */
    { "PCR1",27,1,"",NULL },   /* 27 - PCR 1 discontinuity interrupt enable to IA CPU */
    { "PCR0",26,1,"",NULL },   /* 26 - PCR 0 discontinuity interrupt enable to IA CPU */
    { "IPCD",25,1,"",NULL },   /* 25 - IPCD Interrupt enable to IA CPU */
    { "IPCX",24,1,"",NULL },   /* 24 - IPCX Interrupt enable to IA CPU */
    { "TX2_PEND",23,1,"",NULL },   /* 23 - TX2 interrupt enable to CPU */
    { "TX1_PEND",22,1,"",NULL },   /* 22 - TX1 interrupt enable to CPU */
    { "TX0_PEND",21,1,"",NULL },   /* 21 - TX0 interrupt enable to CPU */
    { "RX1_PEND",20,1,"",NULL },   /* 20 - RX1 interrupt enable to CPU */
    { "RX0_PEND",19,1,"",NULL },   /* 19 - RX0 interrupt enable to CPU */
    { "DMA7_DES",18,1,"",NULL },   /* 18 - DMA7 Destination  interrupt enable to CPU */
    { "DMA7_SRC",17,1,"",NULL },   /* 17 - DMA7 Source interrupt enable to CPU */
    { "DMA6_DES",16,1,"",NULL },   /* 16 - DMA6 Destination  interrupt enable to CPU */
    { "DMA6_SRC",15,1,"",NULL },   /* 15 - DMA6 Source interrupt enable to CPU */
    { "DMA5_DES",14,1,"",NULL },   /* 14 - DMA5 Destination  interrupt enable to CPU */
    { "DMA5_SRC",13,1,"",NULL },   /* 13 - DMA5 Source interrupt enable to CPU */
    { "DMA4_DES",12,1,"",NULL },   /* 12 - DMA4 Destination  interrupt enable to CPU */
    { "DMA4_SRC",11,1,"",NULL },   /* 11 - DMA4 Source interrupt enable to CPU */
    { "DMA3_DES",10,1,"",NULL },   /* 10 - DMA3 Destination  interrupt enable to CPU */
    { "DMA3_SRC",9,1,"",NULL },    /* 9  - DMA3 Source interrupt enable to CPU */
    { "DMA2_DES",8,1,"",NULL },    /* 8  - DMA2 Destination  interrupt enable to CPU */
    { "DMA2_SRC",7,1,"",NULL },    /* 7  - DMA2 Source interrupt enable to CPU */
    { "DMA1_DES",6,1,"",NULL },    /* 6  - DMA1 Destination  interrupt enable to CPU */
    { "DMA1_SRC",5,1,"",NULL },    /* 5  - DMA1 Source interrupt enable to CPU */
    { "DMA0_DES",4,1,"",NULL },    /* 4  - DMA0 Destination  interrupt enable to CPU */
    { "DMA0_SRC",3,1,"",NULL },    /* 3  - DMA0 Source interrupt enable to CPU */
    { "ETS2",2,1,"",NULL },        /* 2  - ETS2 interrupt enable to CPU */
    { "ETS1",1,1,"",NULL },        /* 1  - ETS1 interrupt enable to CPU */
    { "ETS0",0,1,"",NULL },        /* 0  - ETS0 interrupt enable to CPU */
    { NULL,0,0,"",NULL }           /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_AUDIO_ISRD[] =
{
    { "RSVD_31_30",30,2,"",NULL },   /* 31:30 - Reserved */
    { "PCR3",29,1,"",NULL },   /* 29 - PCR 3 discontinuity interrupt to IA DSP */
    { "PCR2",28,1,"",NULL },   /* 28 - PCR 2 discontinuity interrupt to IA DSP */
    { "PCR1",27,1,"",NULL },   /* 27 - PCR 1 discontinuity interrupt to DSP */
    { "PCR0",26,1,"",NULL },   /* 26 - PCR 0 discontinuity interrupt to DSP */
    { "IPCD",25,1,"",NULL },   /* 25 - IPCD Interrupt Request to IA DSP */
    { "IPCX",24,1,"",NULL },   /* 24 - IPCX Interrupt Request to IA DSP */
    { "TX2_PEND",23,1,"",NULL },   /* 23 - TX2 interrupt pending to DSP */
    { "TX1_PEND",22,1,"",NULL },   /* 22 - TX1 interrupt pending to DSP */
    { "TX0_PEND",21,1,"",NULL },   /* 21 - TX0 interrupt pending to DSP */
    { "RX1_PEND",20,1,"",NULL },   /* 20 - RX1 interrupt pending to DSP */
    { "RX0_PEND",19,1,"",NULL },   /* 19 - RX0 interrupt pending to DSP */
    { "DMA7_DES",18,1,"",NULL },   /* 18 - DMA7 Destination  Interrupt pending to DSP */
    { "DMA7_SRC",17,1,"",NULL },   /* 17 - DMA7 Source Interrupt pending to DSP */
    { "DMA6_DES",16,1,"",NULL },   /* 16 - DMA6 Destination  Interrupt pending to DSP */
    { "DMA6_SRC",15,1,"",NULL },   /* 15 - DMA6 Source Interrupt pending to DSP */
    { "DMA5_DES",14,1,"",NULL },   /* 14 - DMA5 Destination  Interrupt pending to DSP */
    { "DMA5_SRC",13,1,"",NULL },   /* 13 - DMA5 Source Interrupt pending to DSP */
    { "DMA4_DES",12,1,"",NULL },   /* 12 - DMA4 Destination  Interrupt pending to DSP */
    { "DMA4_SRC",11,1,"",NULL },   /* 11 - DMA4 Source Interrupt pending to DSP */
    { "DMA3_DES",10,1,"",NULL },   /* 10 - DMA3 Destination  Interrupt pending to DSP */
    { "DMA3_SRC",9,1,"",NULL },    /* 9  - DMA3 Source Interrupt pending to DSP */
    { "DMA2_DES",8,1,"",NULL },    /* 8  - DMA2 Destination  Interrupt pending to DSP */
    { "DMA2_SRC",7,1,"",NULL },    /* 7  - DMA2 Source Interrupt pending to DSP */
    { "DMA1_DES",6,1,"",NULL },    /* 6  - DMA1 Destination  Interrupt pending to DSP */
    { "DMA1_SRC",5,1,"",NULL },    /* 5  - DMA1 Source Interrupt pending to DSP */
    { "DMA0_DES",4,1,"",NULL },    /* 4  - DMA0 Destination  Interrupt pending to DSP */
    { "DMA0_SRC",3,1,"",NULL },    /* 3  - DMA0 Source Interrupt pending to DSP */
    { "ETS2",2,1,"",NULL },        /* 2  - ETS2 Interrupt pending to DSP */
    { "ETS1",1,1,"",NULL },        /* 1  - ETS1 Interrupt pending to DSP */
    { "ETS0",0,1,"",NULL },        /* 0  - ETS0 Interrupt pending to DSP */
    { NULL,0,0,"",NULL }           /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_AUDIO_IMRD[] =
{
    { "RSVD_31_30",30,2,"",NULL },   /* 31:30 - Reserved */
    { "PCR3",29,1,"",NULL },   /* 29 - PCR 3 discontinuity interrupt to IA DSP */
    { "PCR2",28,1,"",NULL },   /* 28 - PCR 2 discontinuity interrupt to IA DSP */
    { "PCR1",27,1,"",NULL },   /* 27 - PCR 1 discontinuity interrupt to DSP */
    { "PCR0",26,1,"",NULL },   /* 26 - PCR 0 discontinuity interrupt to DSP */
    { "IPCD",25,1,"",NULL },   /* 25 - IPCD Interrupt enable to IA DSP */
    { "IPCX",24,1,"",NULL },   /* 24 - IPCX Interrupt enable to IA DSP */
    { "TX2_PEND",23,1,"",NULL },   /* 23 - TX2 Interrupt enable to DSP */
    { "TX1_PEND",22,1,"",NULL },   /* 22 - TX1 Interrupt enable to DSP */
    { "TX0_PEND",21,1,"",NULL },   /* 21 - TX0 Interrupt enable to DSP */
    { "RX1_PEND",20,1,"",NULL },   /* 20 - RX1 Interrupt enable to DSP */
    { "RX0_PEND",19,1,"",NULL },   /* 19 - RX0 Interrupt enable to DSP */
    { "DMA7_DES",18,1,"",NULL },   /* 18 - DMA7 Destination  Interrupt enable to DSP */
    { "DMA7_SRC",17,1,"",NULL },   /* 17 - DMA7 Source Interrupt enable to DSP */
    { "DMA6_DES",16,1,"",NULL },   /* 16 - DMA6 Destination  Interrupt enable to DSP */
    { "DMA6_SRC",15,1,"",NULL },   /* 15 - DMA6 Source Interrupt enable to DSP */
    { "DMA5_DES",14,1,"",NULL },   /* 14 - DMA5 Destination  Interrupt enable to DSP */
    { "DMA5_SRC",13,1,"",NULL },   /* 13 - DMA5 Source Interrupt enable to DSP */
    { "DMA4_DES",12,1,"",NULL },   /* 12 - DMA4 Destination  Interrupt enable to DSP */
    { "DMA4_SRC",11,1,"",NULL },   /* 11 - DMA4 Source Interrupt enable to DSP */
    { "DMA3_DES",10,1,"",NULL },   /* 10 - DMA3 Destination  Interrupt enable to DSP */
    { "DMA3_SRC",9,1,"",NULL },    /* 9  - DMA3 Source Interrupt enable to DSP */
    { "DMA2_DES",8,1,"",NULL },    /* 8  - DMA2 Destination  Interrupt enable to DSP */
    { "DMA2_SRC",7,1,"",NULL },    /* 7  - DMA2 Source Interrupt enable to DSP */
    { "DMA1_DES",6,1,"",NULL },    /* 6  - DMA1 Destination  Interrupt enable to DSP */
    { "DMA1_SRC",5,1,"",NULL },    /* 5  - DMA1 Source Interrupt enable to DSP */
    { "DMA0_DES",4,1,"",NULL },    /* 4  - DMA0 Destination  Interrupt enable to DSP */
    { "DMA0_SRC",3,1,"",NULL },    /* 3  - DMA0 Source Interrupt enable to DSP */
    { "ETS2",2,1,"",NULL },        /* 2  - ETS2 Interrupt enable to DSP */
    { "ETS1",1,1,"",NULL },        /* 1  - ETS1 Interrupt enable to DSP */
    { "ETS0",0,1,"",NULL },        /* 0  - ETS0 Interrupt enable to DSP */
    { NULL,0,0,"",NULL }           /* NULL Terminated */
};

/* IPCX.Inter-process Communication Register for IA32 */
static const struct EAS_RegBits g_csr_AUDIO_IPCX[] =
{
    { "BUSY",31,1,"",NULL },       /* 31 - Busy */
    { "DONE",30,1,"",NULL },       /* 30 - Done */
    { "RSVD_29_16",16,14,"",NULL },      /* 29 : 16 - reserved */
    { "CPU_MSA_MSG",0,16,"",NULL },/* 15 : 0 - CPU to Intel MSA Message */
    { NULL,0,0,"",NULL }          /* NULL Terminated */
};

/* IPCD.Inter-process Communication Register for DSP */
static const struct EAS_RegBits g_csr_AUDIO_IPCD[] =
{
    { "BUSY",31,1,"",NULL },       /* 31 - Busy */
    { "DONE",30,1,"",NULL },       /* 30 - Done */
    { "RSVD_29_16",16,14,"",NULL },      /* 29 : 16 - reserved */
    { "MSA_CPU_MSG",0,16,"",NULL },/* 15 : 0 - Intel MSA to CPU Message */
    { NULL,0,0,"",NULL }           /* NULL Terminated */
};

/* MSARVEC.Intel MSA Reset Vector  - No Break Up Needed */
/* ETS0.Interrupt Event Time Stamp Channel 0 -  No Break Up Needed */
/* ETS1.Interrupt Event Time Stamp Channel 1 -  No Break Up Needed */
/* ETS2.Interrupt Event Time Stamp Channel 2 -  No Break Up Needed */

/* CGR.Clock Gating Config Register */
static const struct EAS_RegBits g_csr_AUDIO_CGR[] =
{
     { "RSVD_31_7",7,25,"",NULL },        /* 31 : 7 - Reserved */
     { "RESAMP_CG_EN",6,1,"",NULL }, /* 6 - Enable Clock gating for Resampler ( 1: Enable; 0: Disable) */
     { "MSA_CG_EN",5,1,"",NULL },    /* 5 - Enable Clock gating for MSA ( 1: Enable; 0: Disable) */
     { "TX2_CG_EN",4,1,"",NULL },    /* 4 - Enable Clock gating for TX2 CHANNEL ( 1: Enable; 0: Disable) */
     { "TX1_CG_EN",3,1,"",NULL },    /* 3 - Enable Clock gating for TX1 CHANNEL ( 1: Enable; 0: Disable) */
     { "TX0_CG_EN",2,1,"",NULL },    /* 2 - Enable Clock gating for TX0 CHANNEL ( 1: Enable; 0: Disable) */
     { "RX1_CG_EN",1,1,"",NULL },    /* 1 - Enable Clock gating for RX1 CHANNEL ( 1: Enable; 0: Disable) */
     { "RX0_CG_EN",0,1,"",NULL },    /* 0 - Enable Clock gating for RX0 CHANNEL ( 1: Enable; 0: Disable) */
    { NULL,0,0,"",NULL }            /* NULL Terminated */
};

/* SCR0 - Presentation Time Counter Control */
static const struct EAS_RegBits g_csr_AUDIO_SCR0[] =
{
    { "RSVD_31_3",3,29,"",NULL },        /* 31 : 3 - Reserved */
    { "TIME_BASE_SEL",1,2,"",NULL },/* 2 : 1 Time base Select */
    { "RSVD_0_0",0,1,"",NULL },         /* 0 : Reserved */
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* SCR1 - Presentation Time Counter Control */
static const struct EAS_RegBits g_csr_AUDIO_SCR1[] =
{
    { "RSVD_31_3",3,29,"",NULL },        /* 31 : 3 - Reserved */
    { "TIME_BASE_SEL",1,2,"",NULL },/* 2 : 1 Time base Select */
    { "RSVD_0_0",0,1,"",NULL },         /* 0 : Reserved */
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* SCR2 - Presentation Time Counter Control */
static const struct EAS_RegBits g_csr_AUDIO_SCR2[] =
{
    { "RSVD_31_3",3,29,"",NULL },        /* 31 : 3 - Reserved */
    { "TIME_BASE_SEL",1,2,"",NULL },/* 2 : 1 Time base Select */
    { "RSVD_0_0",0,1,"",NULL },         /* 0 : Reserved */
    { NULL,0,0,"",NULL }            /* NULL Terminated */
};

/* SPRSCS.S/PDIF Re-sampler Counter Sample Register */
static const struct EAS_RegBits g_csr_AUDIO_SPRSCS[] =
{
    { "RSVD_31_20",20,12,"",NULL },  /* 31 : 20 - Reserved */
    { "CNTR_VAL",0,20,"",NULL },     /* 19 : 0 - Sampled Counter Value */
    { NULL,0,0,"",NULL }             /* NULL Terminated */
};

/* SPRSFC */
static const struct EAS_RegBits g_csr_AUDIO_SPRSFC[] =
{
    { "RSVD_31_4",4,28,"",NULL },   /* 31 : 4 - Reserved */
    { "CNTR_VAL",0,4,"",NULL },     /* 3 : 0 - Number of Frames to be counted before sampling the free-counter */
    { NULL,0,0,"",NULL }            /* NULL Terminated */
};

/* RXSACR0.Global Control Register */
static const struct EAS_RegBits g_csr_AUDIO_RXSACR0[] =
{
    { "RSVD_31_7",7,25,"",NULL },   /* 31 : 7 - Reserved */
    { "SEL_INPUTS",5,2,"",NULL },   /* 6 : 5 - Selects Inputs */
    { "SP_RW_FN_EN",4,1,"",NULL },  /* 4 - This bit enables a special purpose FIFO Write/Read function */
    { "RST_FIFO_REGS",3,1,"",NULL },/* 3 - Resets FIFOs logic and all registers, except this register (SACR0) */
    { "BITCLK_DIR",2,1,"",NULL },   /* 2 - This bit specifies input/output direction of BITCLK */
    { "RSVD_1_1",1,1,"",NULL },     /* 1 - Reserved */
    { "EN_RX",0,1,"",NULL },        /* 0 - Enable RX function */
    { NULL,0,0,"",NULL }           /* NULL Terminated */
};

/* RXSACR1.Serial Audio I2S/MSB-Justified Control Register */
static const struct EAS_RegBits g_csr_AUDIO_RXSACR1[] =
{
    { "RSVD_31_21",21,11,"",NULL },		/* 31 : 21 - Reserved */
    { "TS_FILTER_EN",20,1,"",NULL },		/* 20 - Timestamp Filter Enable */
    { "DMA_CONTEXT",17,3,"",NULL },		/* 19 : 17 - DMA Context Number */
    { "TS_FIFO_THLD",15,2,"",NULL },		/* 16 : 15 -  Time stamp fifo Threshold */
    { "RSVD_14_10",10,5,"",NULL },       /* 14 : 10 - Reserved */
    { "DATA_STORE_MODE",8,2,"",NULL },	/* 9 : 8  - Data Storage Mode */
    { "DATA_SAMP_SZ",7,1,"",NULL },		/* 7 - Data Sample Size */
    { "RSVD_6_0",0,7,"",NULL },			/* 6 : 0 - Reserved */
    { NULL,0,0,"",NULL }				/* NULL Terminated */
};

/* RXSASR0.Serial Audio I2S/MSB-Justified Interface and FIFO Status Register */
static const struct EAS_RegBits g_csr_AUDIO_RXSASR0[] =
{
    { "RSVD_31_11",11,21,"",NULL },			/* 31 : 11 - Reserved */
	{ "TS_FIFO_LVL",8,3,"",NULL },			/* 10 : 8 - Timestamp FIFO Level */
	{ "I2S_SHUTDN",7,1,"",NULL },			/* 7 - I2S Controller CLean Shutdown */
	{ "FIFO_OEVRRUN_INT",6,1,"",NULL },		/* 6 - FIFO Overrun */
    { "RSVD_5_5",5,1,"",NULL },				/* 5 - Reserved */
	{ "FIFO_SERVICE_REQ",4,1,"",NULL },		/* 4 - FIFO Service Request */
	{ "RSVD_3_3",3,1,"",NULL },				/* 3 - Reserved */
	{ "BUSY",2,1,"",NULL }	,				/* 2 - RX BUSY */
	{ "FIFO_EMPTY",1,1,"",NULL },			/* 1 - FIFO EMPTY */
	{ "RSVD_0_0",0,1,"",NULL },				/* 1 - Reserved */
	{ NULL,0,0,"",NULL }					/* NULL Terminated */
};

/* RXSAIMR.Serial Audio Interrupt Mask Register */
static const struct EAS_RegBits g_csr_AUDIO_RXSAIMR[] =
{	
	{ "RSVD_31_16",16,16,"",NULL },   /* 31 : 16 - Reserved */
	{ "HDMI_CNTRL_FIFO_OVERRUN_INT_EN",15,1,"",NULL },	/* 15 - Enable HDMI control FIFO overrun error interrupt */
	{ "HDMI_CNTRL_FIFO_SERVICE_INT_EN",14,1,"",NULL },	/* 14 - Enable HDMI Control FIFO service interrupt */
	{ "HDMI_SYNC_ERR_INT_EN",13,1,"",NULL },				/* 13 - Enable HDMI Synch error interrupt */
	{ "HDMI_CLEAR_AVMUTE_INT_EN",12,1,"",NULL },			/* 12 - Enable HDMI Clear AVMUTE interrupt */
	{ "HDMI_SET_AVMUTE_INT_EN",11,1,"",NULL },			/* 11 - Enable HDMI Set AVMUTE interrupt */
	{ "I2S_FRAME_INT_EN",10,1,"",NULL },					/* 10 - Enable I2S Frame interrupt (valid for I2S and S/PDIF) */
	{ "SPDIF_SYNC_ERR_INT_EN",9,1,"",NULL },				/* 9 - Enable S/PDIF synch error interrupt (valid only in S/PDIF input mode) */
	{ "SPDIF_BLOCK_CMP_INT_EN",8,1,"",NULL },			/* 8 - Enable S/PDIF Block complete interrupt (Valid for HDMI and S/PDIF) */
	{ "TIME_STAMP_FIFO_SER_REQ_INT_EN",7,1,"",NULL },		/* 7 - Enable Timestamp FIFO Service Request Interrupt */
	{ "FIFO_OVERRUN_INT_EN",6,1,"",NULL },			/* 6 - Enable Receive FIFO Overrun condition based interrupt */
	{ "RSVD_5_5",5,1,"",NULL },							/* 5 - Reserved */
	{ "FIFO_SER_REQ_EN",4,1,"",NULL },				/* 4 - Enable Recieve FIFO Service Request based interrupt */
	{ "SPDIF_VAL_BIT_INT_EN",3,1,"",NULL },					/* 3 - Enable SPDIF Validity bit interrupt */
	{ "SPDIF_PAR_ERR_INT_EN",2,1,"",NULL },				/* 2 - Enable SPDIF Parity error interrupt */
	{ "RSVD_1_0",0,2,"",NULL },							/* 1 : 0 - Reserved */
	{ NULL,0,0,"",NULL }								/* NULL Terminated */
};

/* RXSAISR.Serial Audio Interrupt Status Register */
static const struct EAS_RegBits g_csr_AUDIO_RXSAISR[] =
{
	{ "RSVD_31_12",12,20,"",NULL },   /* 31 : 12 - Reserved */
	{ "HDMI_CNTRL_FIFO_OVERRUN_INT",11,1,"",NULL }, /* 11 - HDMI Control FIFO overrun error interrupt */
	{ "HDMI_CNTRL_FIFO_SERVICE_INT",10,1,"",NULL }, /* 10 - HDMI Control FIFO Service Request interrupt */
	{ "TIME_STAMP_FIFO_SER_REQ_INT",9,1,"",NULL },	/* 9 - Timestamp FIFO Service Request Interrupt */
	{ "CLEAR_FIFO_OVERRUN_INT",8,1,"",NULL },		/* 8 - Clear Receive FIFO overrun Interrupt */
	{ "HDMI_SYNC_ERR_INT",7,1,"",NULL },				/* 7 - HDMI Synch Error Interrupt */
	{ "HDMI_CLEAR_AVMUTE_INT",6,1,"",NULL },			/* 6 - HDMI Clear AV MUTE interrupt */
	{ "HDMI_SET_AVMUTE_INT",5,1,"",NULL },			/* 5 - HDMI Set AV MUTE interrupt */
	{ "I2S_FRAME_INT",4,1,"",NULL },					/* 4 - I2S/ S/PDIF Frame interrupt */
	{ "SPDIF_VAL_BIT_INT",3,1,"",NULL },				/* 3 - S/PDIF invalid bit interrupt */
	{ "SPDIF_PAR_ERR_INT",2,1,"",NULL },				/* 2 - S/PDIF Parity error interrupt */
	{ "SPDIF_BLOCK_CMP_INT",1,1,"",NULL },			/* 1 - S/PDIF Block Interrupt */
	{ "SPDIF_SYNC_ERR_INT",0,1,"",NULL },			/* 0 - S/PDIF input synch error interrupt */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* RXSADIV.Audio Clock Divider Control */
static const struct EAS_RegBits g_csr_AUDIO_RXSADIV[] =
{
	{ "RSVD_31_7",7,25,"",NULL },					/* 31 : 7 - Reserved */
	{ "AUDIO_CLK_DIV",0,7,"",NULL },					/* 6 : 0 - Audio CLock Divider */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* RXSARR.Serial Audio Receive Register - No Break Up Needed */

/* RXSAFTH.Serial Audio FIFO Threshold Register */
static const struct EAS_RegBits g_csr_AUDIO_RXSAFTH[] =
{
	{ "RSVD_31_16",16,16,"",NULL },					/* 31 : 16 - Reserved */
	{ "FIFO_THLD",0,16,"",NULL },					/* 15 : 0 - Upper FIFO Threshold of Receive Channel in words */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/*RXSADESC */
static const struct EAS_RegBits g_csr_AUDIO_RXSADESC[] =
{
	{ "FRAME_DESC",16,16,"",NULL },					/* 31 : 16 - 16-bit Frame Descriptor */
	{ "FRAME_SIZE",0,16,"",NULL },					/* 15 : 0 - Frame Size */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* RXSAFL.Serial Audio FIFO Level Register */
static const struct EAS_RegBits g_csr_AUDIO_RXSAFL[] =
{
	{ "RSVD_31_8",8,24,"",NULL },					/* 31 : 8 - Reserved */
	{ "RX_FIFO_LEVEL",0,8,"",NULL },					/* 7 : 0 - Upper FIFO level of Receive Channel in words */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* RXSATS.Audio Capture Block Timestamp - No Break Up Needed  */
/* RXSABAP.Audio Sample Block Buffer Pointer - No Break Up Needed */
/* RXSACUDR. S/PDIF Audio Capture User Data Registers - No Break Up Needed */
/* RXSACSR.Audio Capture Channel Status Registers - No Break Up Needed */
/* RXSAVR.Audio Capture Validity Status Registers  - No Break Up Needed */
/* RXSPDBP.Audio Capture SPDIF Block Address Pointer FIFO - No Break Up Needed */
/*************************************RX CHANNEL REGISTERS ENDED***************************************************/

/*************************************TX CHANNEL REGISTERS BEGIN***************************************************/
/* TXSACR0.Global Control Register */
static const struct EAS_RegBits g_csr_AUDIO_TXSACR0[] =
{
    { "RSVD_31_7",7,25,"",NULL },    /* 31 : 7 - Reserved */
    { "SEL_OUTPUTS",5,2,"",NULL },    /* 6 : 5 - Selects Outputs */
    { "SP_RW_FN_EN",4,1,"",NULL } ,  /* 4 - This bit enables a special purpose FIFO Write/Read function */
    { "RST_FIFO_REGS",3,1,"",NULL }, /* 3 - Resets FIFOs logic and all registers, except this register (SACR0) */
    { "RSVD_2_2",2,1,"",NULL },    /* 2 - Reserved */
    { "RSVD_1_1",1,1,"",NULL },      /* 1 - Reserved */
    { "EN_TX",0,1,"",NULL },         /* 0 - Enable TX function */
    { NULL,0,0,"",NULL }            /* NULL Terminated */
};

/* TXSACR1.Serial Audio I2S/MSB-Justified Control Register */
static const struct EAS_RegBits g_csr_AUDIO_TXSACR1[] =
{
    { "RSVD_31_21",21,11,"",NULL },		/* 31 : 21 - Reserved */
    { "TS_FILTER_EN",20,1,"",NULL },		/* 20 - Timestamp Filter Enable */
    { "DMA_CONTEXT",17,3,"",NULL },		/* 19 : 17 - DMA Context Number */
    { "TS_FIFO_THLD",15,2,"",NULL },		/* 16 : 15 -  Time stamp fifo Threshold */
    { "RSVD_14_10",10,5,"",NULL },       /* 14 : 10 - Reserved */
    { "DATA_STORE_MODE",8,2,"",NULL },	/* 9 : 8  - Data Storage Mode */
    { "DATA_SAMP_SZ",7,1,"",NULL },		/* 7 - Data Sample Size */
    { "RSVD_6_1",1,7,"",NULL },			/* 6 : 1 - Reserved */
    { "ALT_MODE",0,1,"",NULL },			/* 0 - Specify Alternate Mode (I2S or MSB-Justified) Operation */
    { NULL,0,0,"",NULL }				/* NULL Terminated */
};

/* TXSASR0.Serial Audio I2S/MSB-Justified Interface and FIFO Status Register */
static const struct EAS_RegBits g_csr_AUDIO_TXSASR0[] =
{
    { "RSVD_31_11",11,21,"",NULL },			/* 31 : 11 - Reserved */
	{ "TS_FIFO_LVL",8,3,"",NULL },			/* 10 : 8 - Timestamp FIFO Level */
	{ "I2S_SHUTDN",7,1,"",NULL },			/* 7 - I2S Controller CLean Shutdown */
	{ "FIFO_OEVRRUN_INT",6,1,"",NULL },		/* 6 - FIFO Overrun */
    { "RSVD_5_5",5,1,"",NULL },				/* 5 - Reserved */
	{ "FIFO_SERVICE_REQ",4,1,"",NULL },		/* 4 - FIFO Service Request */
	{ "RSVD_3_3",3,1,"",NULL },				/* 3 - Reserved */
	{ "BUSY",2,1,"",NULL }	,				/* 2 - TX BUSY */
	{ "FIFO_EMPTY",1,1,"",NULL },			/* 1 - FIFO EMPTY */
	{ "RSVD_0_0",0,1,"",NULL },				/* 1 - Reserved */
	{ NULL,0,0,"",NULL }					/* NULL Terminated */
};

/* TXSAIMR.Serial Audio Interrupt Mask Register */
static const struct EAS_RegBits g_csr_AUDIO_TXSAIMR[] =
{	
	{ "RSVD_31_16",16,16,"",NULL } ,  /* 31 : 16 - Reserved */
	{ "HDMI_CNTRL_FIFO_OVERRUN_INT_EN",15,1,"",NULL },	/* 15 - Enable HDMI control FIFO overrun error interrupt */
	{ "HDMI_CNTRL_FIFO_SERVICE_INT_EN",14,1,"",NULL },	/* 14 - Enable HDMI Control FIFO service interrupt */
	{ "HDMI_SYNC_ERR_INT_EN",13,1,"",NULL }	,			/* 13 - Enable HDMI Synch error interrupt */
	{ "HDMI_CLEAR_AVMUTE_INT_EN",12,1,"",NULL },			/* 12 - Enable HDMI Clear AVMUTE interrupt */
	{ "HDMI_SET_AVMUTE_INT_EN",11,1,"",NULL },			/* 11 - Enable HDMI Set AVMUTE interrupt */
	{ "I2S_FRAME_INT_EN",10,1,"",NULL },					/* 10 - Enable I2S Frame interrupt (valid for I2S and S/PDIF) */
	{ "SPDIF_SYNC_ERR_INT_EN",9,1,"",NULL }	,			/* 9 - Enable S/PDIF synch error interrupt (valid only in S/PDIF input mode) */
	{ "SPDIF_BLOCK_CMP_INT_EN",8,1,"",NULL },			/* 8 - Enable S/PDIF Block complete interrupt (Valid for HDMI and S/PDIF) */
	{ "TIME_STAMP_FIFO_SER_REQ_INT_EN",7,1,"",NULL },		/* 7 - Enable Timestamp FIFO Service Request Interrupt */
	{ "FIFO_OVERRUN_INT_EN",6,1,"",NULL },			/* 6 - Enable Receive FIFO Overrun condition based interrupt */
	{ "RSVD_5_5",5,1,"",NULL },							/* 5 - Reserved */
	{ "FIFO_SER_REQ_EN",4,1,"",NULL },				/* 4 - Enable Recieve FIFO Service Request based interrupt */
	{ "SPDIF_VAL_BIT_INT_EN",3,1,"",NULL }	,				/* 3 - Enable SPDIF Validity bit interrupt */
	{ "SPDIF_PAR_ERR_INT_EN",2,1,"",NULL },				/* 2 - Enable SPDIF Parity error interrupt */
	{ "RSVD_1_0",0,2,"",NULL },							/* 1 : 0 - Reserved */
	{ NULL,0,0,"",NULL }								/* NULL Terminated */
};

/* TXSAISR.Serial Audio Interrupt Status Register */
static const struct EAS_RegBits g_csr_AUDIO_TXSAISR[] =
{
	{ "RSVD_31_12",12,20,"",NULL },   /* 31 : 12 - Reserved */
	{ "HDMI_CNTRL_FIFO_OVERRUN_INT",11,1,"",NULL }, /* 11 - HDMI Control FIFO overrun error interrupt */
	{ "HDMI_CNTRL_FIFO_SERVICE_INT",10,1,"",NULL }, /* 10 - HDMI Control FIFO Service Request interrupt */
	{ "TIME_STAMP_FIFO_SER_REQ_INT",9,1,"",NULL },	/* 9 - Timestamp FIFO Service Request Interrupt */
	{ "CLEAR_FIFO_OVERRUN_INT",8,1,"",NULL },		/* 8 - Clear Receive FIFO overrun Interrupt */
	{ "HDMI_SYNC_ERR_INT",7,1,"",NULL },				/* 7 - HDMI Synch Error Interrupt */
	{ "HDMI_CLEAR_AVMUTE_INT",6,1,"",NULL }	,		/* 6 - HDMI Clear AV MUTE interrupt */
	{ "HDMI_SET_AVMUTE_INT",5,1,"",NULL },			/* 5 - HDMI Set AV MUTE interrupt */
	{ "I2S_FRAME_INT",4,1,"",NULL }	,				/* 4 - I2S/ S/PDIF Frame interrupt */
	{ "SPDIF_VAL_BIT_INT",3,1,"",NULL },				/* 3 - S/PDIF invalid bit interrupt */
	{ "SPDIF_PAR_ERR_INT",2,1,"",NULL },				/* 2 - S/PDIF Parity error interrupt */
	{ "SPDIF_BLOCK_CMP_INT",1,1,"",NULL },			/* 1 - S/PDIF Block Interrupt */
	{ "SPDIF_SYNC_ERR_INT",0,1,"",NULL },			/* 0 - S/PDIF input synch error interrupt */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TXSADIV.Audio Clock Divider Control */
static const struct EAS_RegBits g_csr_AUDIO_TXSADIV[] =
{
	{ "RSVD_31_7",7,25,"",NULL },					/* 31 : 7 - Reserved */
	{ "AUDIO_CLK_DIV",0,7,"",NULL }	,				/* 6 : 0 - Audio CLock Divider */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TXSATR.Serial Audio Transmit Register - - No Break Up Needed  */
/* TXSAFTH.Serial Audio FIFO Threshold Register */
static const struct EAS_RegBits g_csr_AUDIO_TXSAFTH[] =
{
	{ "RSVD_31_16",16,16,"",NULL }	,				/* 31 : 16 - Reserved */
	{ "FIFO_THLD",0,16,"",NULL },					/* 15 : 0 - Upper FIFO Threshold of Receive Channel in words */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TXSAFL.Serial Audio FIFO Level Register */
static const struct EAS_RegBits g_csr_AUDIO_TXSAFL[] =
{
	{ "RSVD_31_8",8,24,"",NULL }	,				/* 31 : 8 - Reserved */
	{ "FIFO_LEVEL",0,8,"",NULL },					/* 7 : 0 - Upper FIFO level of Receive Channel in words */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TX0SASUDxS/PDIF Output User Data Register Attributes - No Break Up Needed */
/*	TX0SASUDCUser Data Control Register Attributes */
static const struct EAS_RegBits g_csr_AUDIO_TXSASUDC[] =
{
	{ "RSVD_31_1",1,31,"",NULL },					/* 31 : 1 - Reserved */
	{ "LD_UD_REGISTERS",0,1,"",NULL },				/* 0 - Load the User Data registers (SASUD0  SASUD11)into buffer for insertion into S/PDIF data stream. This bit will be automatically reset to 0. */
	{ NULL,0,0,"",NULL }							/* NULL Terminated */
};

/* TX0SASCSxS/PDIF Channel Status Register Attributes */
/* TX0SASCSC */

/*************************************TX CHANNEL REGISTERS ENDED***************************************************/

/**************************************DMA REGISTERS BEGIN*********************************************************/
/* CURR_DESCR - No Break Up Needed  */
/* DSTDMA_BOT - No Break Up Needed  */
/* DSTDMA_SIZE - No Break Up Needed  */
/* DSTDMA_START - No Break Up Needed  */
/* DSTDMA_STOP - No Break Up Needed  */
/* DSTDMA_TOP - No Break Up Needed  */
/* NEXT_DESCR - No Break Up Needed  */
/* SRCDMA_BOT - No Break Up Needed  */
/* SRCDMA_SIZE - No Break Up Needed  */
/* SRCDMA_START - No Break Up Needed  */
/* SRCDMA_STOP - No Break Up Needed  */
/* SRCDMA_TOP - No Break Up Needed  */

/* FLAGS MODE */
static const struct EAS_RegBits g_csr_FLAGS_MODE[] =
{
      { "DMA_CONTEXT_ACTIVE",31,1,"",NULL },			/* 31 RO DMA context is active */
	  { "SRC_INT_EN",30,1,"",NULL },					/* 30 RW Source Interrupt Enable */
	  { "DST_INT_EN",29,1,"",NULL },					/* 29 RW Destination Interrupt Enable */
	  { "LINK_LIST_TERM",28,1,"",NULL },				/* 28 RW Do not fetch tje next descriptor when the current transfer has finished */
	  { "RD_SWAP_ENDIAN",27,1,"",NULL },				/* 27 RW Read Swap Endianism */
	  { "WR_SWAP_ENDIAN",26,1,"",NULL },				/* 26 RW Write Swap Endianism */
	  { "SRC_ENDIANISM",25,1,"",NULL },				/* 25 RW Source Endianism */
	  { "DST_ENDIANISM",24,1,"",NULL },				/* 24 RW Destination Endianism */
	  { "SUB_UNIT_SEL",20,4,"",NULL },				/* 23 : 20 RW Sub unit select */
	  { "XSI_DMA_GAP",61,4,"",NULL },				/* 19 :16 RW Between bursts (meaning the larger of the 2 burst sizes) the context is .locked. for <XDMA_GAP value> XSI bus clocks */
	  { "XSI_DMA_BURST_SZ",12,5,"",NULL }	,		/* 15 : 12 The DMA will transfer data to the Global Agent in bursts of this value */
	  { "DMA_BURST_SZ",8,4,"",NULL },				/* 11 : 8 The DMA will transfer data to the Local Agent in bursts of this value */
	  { "READ_EN",7,1,"",NULL },						/* 7 RW The DMA will read data from the global address space and write it into the local address space */
	  { "SRC_ADDR_MODE",5,2,"",NULL },				/* 6 : 5 Source addressing mode */
	  { "SRC_LINK_LIST",4,1,"",NULL },				/* 4 RW Source link list */
	  { "WRITE_EN",3,1,"",NULL },					/* 3 RW The DMA will read data from the local address space and write it into the global address space */
	  { "DST_ADDR_MODE",1,2,"",NULL },				/* 2 : 1 RW Destination Addressing Mode */
	  { "DST_LINK_LIST",0,1,"",NULL },				/* 0 RW Destination Link List Enable */
	  { NULL,0,0,"",NULL }							/* NULL Terminated */

};
/**************************************DMA REGISTERS END*********************************************************/

/**************************************RESAMPLER REGISTERS BEGIN**************************/
static const struct EAS_RegBits g_csr_RESAMP_CSR[] =
{
    { "RSVD_31_15",15,17,"",NULL },
    { "AUDIO_SAMP_TYPE",12,3,"",NULL },
    { "RSVD_11_10",10,2,"",NULL },
    { "OUT_ASTA_DNE_INT_EN",9,1,"",NULL },
    { "OUT_ASTA_DNE",8,1,"",NULL },
    { "IN_ASTA_DNE_INT_EN",7,1,"",NULL },
    { "IN_ASTA_DNE",6,1,"",NULL },
    { "FLUSH_INT_EN",5,1,"",NULL },
    { "FLUSH_EN",4,1,"",NULL },
    { "RSVD_3_3",3,1,"",NULL },
    { "START",2,1,"",NULL },
    { "FLUSH",1,1,"",NULL },
    { "RESET",0,1,"",NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*FILTER CONFIG REGISTER*/
static const struct EAS_RegBits g_csr_RESAMP_FILTER_CR1[] =
{
    { "RSVD_31_26",26,6,"",NULL },
    { "TAP_COUNT",24,2,"",NULL },
    { "RSVD_23_22",22,2,"",NULL },
    { "PHASE_ADD_INT",20,2,"",NULL },
    { "PHASE_ADD_FRACT",0,20,"",NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */

};
static const struct EAS_RegBits g_csr_RESAMP_FILTER_CR2[] =
{
    { "RSVD_31_20",20,12,"",NULL },
    { "CURRENT_PHASE",0,20,"",NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */

};

/* ASTA_PARAM1 - No Break Up Needed */
/* ASTA_PARAM2 */
static const struct EAS_RegBits g_csr_RESAMP_ASTA_PARAM_2[] =
{
    { "RSVD_31_15",15,17,"",NULL },
    { "INTERLEAVE_SIZE",12,3,"",NULL },
    { "TRANSFER_SIZE",0,12,"",NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */

};

/* ASTA_PARAM3 */
static const struct EAS_RegBits g_csr_RESAMP_ASTA_PARAM_3[] =
{
    { "RSVD_31_16",16,16,"",NULL },
    { "IN_WR_PTR_WRAP_BIT",15,1,"",NULL },
    { "IN_WR_PTR",8,7,"",NULL },
    { "IN_START_PTR_WRAP_BIT",7,1,"",NULL },
    { "IN_START_PTR",0,7,"",NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */

};


/**************************************RESAMPLER REGISTERS END****************************/

static const struct EAS_RegBits g_csr_MSA_INT_STATUS[] =
{
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MyModule_versions.
 *      AU_AUX_BASE+0000h - AU_AUX_BASE+0FFFh   Audio Configuration and Control registers
 *      AU_AUX_BASE+1000h - AU_AUX_BASE+1FFF    DMA Contexts and Control Structures
 *      AU_AUX_BASE+2000h - AU_AUX_BASE+2FFF    I2S/SPDIF Output Channels
 *      AU_AUX_BASE+3000h - AU_AUX_BASE+3FFF    I2S Audio Capture Interfaces And HDMI audio support registers
 *      AU_AUX_BASE+4000h  AU_AUX_BASE+5FFFh   Audio Re-sampler Coefficient Memory
 *      AU_AUX_BASE+6000h  AU_AUX_BASE+6FFFh   Audio Re-sampler CSR
 */
static const struct EAS_Register g_csr_vr_AUDIO[] =
{

	{"CSR",                     CSR_BASE+0x000000,g_csr_AUDIO_CSR ,"Configuration and Status Register.",NULL },
    { "ISRX",                  CSR_BASE+0x000004,g_csr_AUDIO_ISRX, "IA32 Interrupt Status Register.",NULL },
    { "ISRD",                  CSR_BASE+0X000008,g_csr_AUDIO_ISRD, "Intel MSA Interrupt Status Register.",NULL },
    { "IMRX",                  CSR_BASE+0X00000C,g_csr_AUDIO_IMRX, "IA32 Interrupt Mask Register.",NULL },
    { "IMRD",                  CSR_BASE+0X000010,g_csr_AUDIO_IMRD, "Intel MSA Interrupt Mask Register.",NULL },
    { "IPCX",                  CSR_BASE+0X000014,g_csr_AUDIO_IPCX, "Inter-process Communication register for IA32 CPU.",NULL },
    { "IPCD",                  CSR_BASE+0X000018,g_csr_AUDIO_IPCD, "Inter-process Communication Intel MSA.",NULL },
    { "MSARVEC",               CSR_BASE+0X00001C,NULL, "Intel MSA Reset Vector.",NULL },
    { "ETS0",                  CSR_BASE+0X000020,NULL, "Interrupt Event Time Stamp register 0",NULL },
    { "ETS1",                  CSR_BASE+0X000024,NULL, "Interrupt Event Time Stamp register 1",NULL },
    { "ETS2",                  CSR_BASE+0X000028,NULL, "Interrupt Event Time Stamp register 2",NULL },
    { "CGR",                   CSR_BASE+0X00002C,g_csr_AUDIO_CGR, "Clock Gating config register",NULL },
    { "SCR0",                  CSR_BASE+0X000040,g_csr_AUDIO_SCR0, "Presentation time counter select register 0",NULL },
    { "SCR1",                  CSR_BASE+0X000044,g_csr_AUDIO_SCR1, "Presentation time counter select register 1",NULL },
    { "SCR2",                  CSR_BASE+0X000048,g_csr_AUDIO_SCR2, "Presentation time counter select register 2",NULL },
    { "SPRSCS",                CSR_BASE+0X000050,g_csr_AUDIO_SPRSCS, "S/PDIF re-sampler counter sample Register",NULL },
    { "SPRSFC",                CSR_BASE+0X000054,g_csr_AUDIO_SPRSFC, "S/PDIF Re-sampler Frame count Register",NULL },

    /* DMA Control/Context Registers */
    { "DMA0_CURR_DESCR",       CSR_BASE+0X001008,NULL ,"Current descriptor address pointer",NULL },
    { "DMA0_NEXT_DESCR",       CSR_BASE+0X00100C,NULL, "Next descriptor address pointer.",NULL },
    { "DMA0_SRCDMA_START",     CSR_BASE+0X001010,NULL, "Start address of the Source DMA buffer in the BI address space.",NULL },
    { "DMA0_DSTDMA_START",     CSR_BASE+0X001014,NULL, "Start address of the Destination DMA buffer in the BI address space.",NULL },
    { "DMA0_SRCDMA_SIZE",      CSR_BASE+0X001018,NULL, "Total size of the block of data (in bytes) to be read from the source location.",NULL },
    { "DMA0_FLAGS_MODE",       CSR_BASE+0X00101C,g_csr_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
    { "DMA0_SRCDMA_START_ALIAS",CSR_BASE+0x001020,NULL, "This is the alias of Source DMA Start Register SRCDMA_START",NULL },
    { "DMA0_SRCDMA_BOT",       CSR_BASE+0X001024,NULL, "Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA0_SRCDMA_TOP",       CSR_BASE+0X001028,NULL, "Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA0_DSTDMA_BOT",       CSR_BASE+0X00102C,NULL, "Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA0_DSTDMA_TOP",       CSR_BASE+0X001030,NULL, "Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA0_DSTDMA_SIZE",      CSR_BASE+0X001034,NULL, "Size of the block of data (in bytes) to be sent to the destination location.",NULL },
    { "DMA0_SRCDMA_STOP",      CSR_BASE+0X001038,NULL, "Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
    { "DMA0_DSTDMA_STOP",      CSR_BASE+0X00103C,NULL, "Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

    { "DMA1_CURR_DESCR",       CSR_BASE+0X001048,NULL, " Current descriptor address pointer",NULL },
    { "DMA1_NEXT_DESCR",       CSR_BASE+0X00104C,NULL, " Next descriptor address pointer.",NULL },
    { "DMA1_SRCDMA_START",     CSR_BASE+0X001050,NULL, " Start address of the Source DMA buffer in the BI address space.",NULL },
    { "DMA1_DSTDMA_START",     CSR_BASE+0X001054,NULL, " Start address of the Destination DMA buffer in the BI address space.",NULL },
    { "DMA1_SRCDMA_SIZE",      CSR_BASE+0X001058,NULL, " Total size of the block of data (in bytes) to be read from the source location.",NULL },
    { "DMA1_FLAGS_MODE",       CSR_BASE+0X00105C,g_csr_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
    { "DMA1_SRCDMA_START_ALIAS",CSR_BASE+0x001060,NULL, " This is the alias of Source DMA Start Register SRCDMA_START",NULL },
    { "DMA1_SRCDMA_BOT",       CSR_BASE+0X001064,NULL, " Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA1_SRCDMA_TOP",       CSR_BASE+0X001068,NULL, " Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA1_DSTDMA_BOT",       CSR_BASE+0X00106C,NULL, " Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA1_DSTDMA_TOP",       CSR_BASE+0X001070,NULL, " Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA1_DSTDMA_SIZE",      CSR_BASE+0X001074,NULL, " Size of the block of data (in bytes) to be sent to the destination location.",NULL },
    { "DMA1_SRCDMA_STOP",      CSR_BASE+0X001078,NULL, " Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
    { "DMA1_DSTDMA_STOP",      CSR_BASE+0X00107C,NULL, " Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

    { "DMA2_CURR_DESCR",       CSR_BASE+0X001088,NULL, " Current descriptor address pointer",NULL },
    { "DMA2_NEXT_DESCR",       CSR_BASE+0X00108C,NULL, " Next descriptor address pointer.",NULL },
    { "DMA2_SRCDMA_START",     CSR_BASE+0X001090,NULL, " Start address of the Source DMA buffer in the BI address space.",NULL },
    { "DMA2_DSTDMA_START",     CSR_BASE+0X001094,NULL, " Start address of the Destination DMA buffer in the BI address space.",NULL },
    { "DMA2_SRCDMA_SIZE",      CSR_BASE+0X001098,NULL, " Total size of the block of data (in bytes) to be read from the source location.",NULL },
    { "DMA2_FLAGS_MODE",       CSR_BASE+0X00109C,g_csr_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
    { "DMA2_SRCDMA_START_ALIAS",CSR_BASE+0x0010A0,NULL, " This is the alias of Source DMA Start Register SRCDMA_START",NULL },
    { "DMA2_SRCDMA_BOT",       CSR_BASE+0X0010A4,NULL, " Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA2_SRCDMA_TOP",       CSR_BASE+0X0010A8,NULL, " Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA2_DSTDMA_BOT",       CSR_BASE+0X0010AC,NULL, " Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA2_DSTDMA_TOP",       CSR_BASE+0X0010B0,NULL, " Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA2_DSTDMA_SIZE",      CSR_BASE+0X0010B4,NULL, " Size of the block of data (in bytes) to be sent to the destination location.",NULL },
    { "DMA2_SRCDMA_STOP",      CSR_BASE+0X0010B8,NULL, " Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
    { "DMA2_DSTDMA_STOP",      CSR_BASE+0X0010BC,NULL, " Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

    { "DMA3_CURR_DESCR",       CSR_BASE+0X0010C8,NULL, " Current descriptor address pointer",NULL },
    { "DMA3_NEXT_DESCR",       CSR_BASE+0X0010CC,NULL, " Next descriptor address pointer.",NULL },
    { "DMA3_SRCDMA_START",     CSR_BASE+0X0010D0,NULL, " Start address of the Source DMA buffer in the BI address space.",NULL },
    { "DMA3_DSTDMA_START",     CSR_BASE+0X0010D4,NULL, " Start address of the Destination DMA buffer in the BI address space.",NULL },
    { "DMA3_SRCDMA_SIZE",      CSR_BASE+0X0010D8,NULL, " Total size of the block of data (in bytes) to be read from the source location.",NULL },
    { "DMA3_FLAGS_MODE",       CSR_BASE+0X0010DC,g_csr_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
    { "DMA3_SRCDMA_START_ALIAS",CSR_BASE+0x0010E0,NULL, " This is the alias of Source DMA Start Register SRCDMA_START",NULL },
    { "DMA3_SRCDMA_BOT",       CSR_BASE+0X0010E4,NULL, " Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA3_SRCDMA_TOP",       CSR_BASE+0X0010E8,NULL, " Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA3_DSTDMA_BOT",       CSR_BASE+0X0010EC,NULL, " Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA3_DSTDMA_TOP",       CSR_BASE+0X0010F0,NULL, " Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA3_DSTDMA_SIZE",      CSR_BASE+0X0010F4,NULL, " Size of the block of data (in bytes) to be sent to the destination location.",NULL },
    { "DMA3_SRCDMA_STOP",      CSR_BASE+0X0010F8,NULL, " Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
    { "DMA3_DSTDMA_STOP",      CSR_BASE+0X0010FC,NULL, " Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

    { "DMA4_CURR_DESCR",       CSR_BASE+0X001108,NULL, " Current descriptor address pointer",NULL },
    { "DMA4_NEXT_DESCR",       CSR_BASE+0X00110C,NULL, " Next descriptor address pointer.",NULL },
    { "DMA4_SRCDMA_START",     CSR_BASE+0X001110,NULL, " Start address of the Source DMA buffer in the BI address space.",NULL },
    { "DMA4_DSTDMA_START",     CSR_BASE+0X001114,NULL, " Start address of the Destination DMA buffer in the BI address space.",NULL },
    { "DMA4_SRCDMA_SIZE",      CSR_BASE+0X001118,NULL, " Total size of the block of data (in bytes) to be read from the source location.",NULL },
    { "DMA4_FLAGS_MODE",       CSR_BASE+0X00111C,g_csr_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
    { "DMA4_SRCDMA_START_ALIAS",CSR_BASE+0x001120,NULL," This is the alias of Source DMA Start Register SRCDMA_START",NULL },
    { "DMA4_SRCDMA_BOT",       CSR_BASE+0X001124,NULL, " Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA4_SRCDMA_TOP",       CSR_BASE+0X001128,NULL, " Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA4_DSTDMA_BOT",       CSR_BASE+0X00112C,NULL, " Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA4_DSTDMA_TOP",       CSR_BASE+0X001130,NULL, " Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA4_DSTDMA_SIZE",      CSR_BASE+0X001134,NULL, " Size of the block of data (in bytes) to be sent to the destination location.",NULL },
    { "DMA4_SRCDMA_STOP",      CSR_BASE+0X001138,NULL, " Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
    { "DMA4_DSTDMA_STOP",      CSR_BASE+0X00113C,NULL, " Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

    { "DMA5_CURR_DESCR",       CSR_BASE+0X001148,NULL, " Current descriptor address pointer",NULL },
    { "DMA5_NEXT_DESCR",       CSR_BASE+0X00114C,NULL, " Next descriptor address pointer.",NULL },
    { "DMA5_SRCDMA_START",     CSR_BASE+0X001150,NULL, " Start address of the Source DMA buffer in the BI address space.",NULL },
    { "DMA5_DSTDMA_START",     CSR_BASE+0X001154,NULL, " Start address of the Destination DMA buffer in the BI address space.",NULL },
    { "DMA5_SRCDMA_SIZE",      CSR_BASE+0X001158,NULL, " Total size of the block of data (in bytes) to be read from the source location.",NULL },
    { "DMA5_FLAGS_MODE",       CSR_BASE+0X00115C,g_csr_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
    { "DMA5_SRCDMA_START_ALIAS",CSR_BASE+0x001160,NULL, " This is the alias of Source DMA Start Register SRCDMA_START",NULL },
    { "DMA5_SRCDMA_BOT",       CSR_BASE+0X001164,NULL, " Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA5_SRCDMA_TOP",       CSR_BASE+0X001168,NULL, " Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA5_DSTDMA_BOT",       CSR_BASE+0X00116C,NULL, " Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA5_DSTDMA_TOP",       CSR_BASE+0X001170,NULL, " Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA5_DSTDMA_SIZE",      CSR_BASE+0X001174,NULL, " Size of the block of data (in bytes) to be sent to the destination location.",NULL },
    { "DMA5_SRCDMA_STOP",      CSR_BASE+0X001178,NULL, " Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
    { "DMA5_DSTDMA_STOP",      CSR_BASE+0X00117C,NULL, " Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

    { "DMA6_CURR_DESCR",       CSR_BASE+0X001188,NULL, " Current descriptor address pointer",NULL },
    { "DMA6_NEXT_DESCR",       CSR_BASE+0X00118C,NULL, " Next descriptor address pointer.",NULL },
    { "DMA6_SRCDMA_START",     CSR_BASE+0X001190,NULL, " Start address of the Source DMA buffer in the BI address space.",NULL },
    { "DMA6_DSTDMA_START",     CSR_BASE+0X001194,NULL, " Start address of the Destination DMA buffer in the BI address space.",NULL },
    { "DMA6_SRCDMA_SIZE",      CSR_BASE+0X001198,NULL, " Total size of the block of data (in bytes) to be read from the source location.",NULL },
    { "DMA6_FLAGS_MODE",       CSR_BASE+0X00119C,g_csr_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
    { "DMA6_SRCDMA_START_ALIAS",CSR_BASE+0x0011A0,NULL, " This is the alias of Source DMA Start Register SRCDMA_START",NULL },
    { "DMA6_SRCDMA_BOT",       CSR_BASE+0X0011A4,NULL, " Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA6_SRCDMA_TOP",       CSR_BASE+0X0011A8,NULL, " Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA6_DSTDMA_BOT",       CSR_BASE+0X0011AC,NULL, " Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA6_DSTDMA_TOP",       CSR_BASE+0X0011B0,NULL, " Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA6_DSTDMA_SIZE",      CSR_BASE+0X0011B4,NULL, " Size of the block of data (in bytes) to be sent to the destination location.",NULL },
    { "DMA6_SRCDMA_STOP",      CSR_BASE+0X0011B8,NULL, " Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
    { "DMA6_DSTDMA_STOP",      CSR_BASE+0X0011BC,NULL, " Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

    { "DMA7_CURR_DESCR",       CSR_BASE+0X0011C8,NULL, " Current descriptor address pointer",NULL },
    { "DMA7_NEXT_DESCR",       CSR_BASE+0X0011CC,NULL, " Next descriptor address pointer.",NULL },
    { "DMA7_SRCDMA_START",     CSR_BASE+0X0011D0,NULL, " Start address of the Source DMA buffer in the BI address space.",NULL },
    { "DMA7_DSTDMA_START",     CSR_BASE+0X0011D4,NULL, " Start address of the Destination DMA buffer in the BI address space.",NULL },
    { "DMA7_SRCDMA_SIZE",      CSR_BASE+0X0011D8,NULL, " Total size of the block of data (in bytes) to be read from the source location.",NULL },
    { "DMA7_FLAGS_MODE",       CSR_BASE+0X0011DC,g_csr_FLAGS_MODE, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.",NULL },
    { "DMA7_SRCDMA_START_ALIAS",CSR_BASE+0x0011E0,NULL, " This is the alias of Source DMA Start Register SRCDMA_START",NULL },
    { "DMA7_SRCDMA_BOT",       CSR_BASE+0X0011E4,NULL, " Address of the bottom of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA7_SRCDMA_TOP",       CSR_BASE+0X0011E8,NULL, " Address of the top of the Source DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA7_DSTDMA_BOT",       CSR_BASE+0X0011EC,NULL, " Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA7_DSTDMA_TOP",       CSR_BASE+0X0011F0,NULL, " Address of the top of the Destination DMA buffer (used for circular buffer modes only).",NULL },
    { "DMA7_DSTDMA_SIZE",      CSR_BASE+0X0011F4,NULL, " Size of the block of data (in bytes) to be sent to the destination location.",NULL },
    { "DMA7_SRCDMA_STOP",      CSR_BASE+0X0011F8,NULL, " Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },
    { "DMA7_DSTDMA_STOP",      CSR_BASE+0X0011FC,NULL, " Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.",NULL },

    /* I2S or S/PDIF or HDMI Support Registers */
    { "TX0SACR0",              CSR_BASE+0X002000,g_csr_AUDIO_TXSACR0, "Global Control Register",NULL },
    { "TX0SACR1",              CSR_BASE+0X002004,g_csr_AUDIO_TXSACR1, "Serial Audio I2S/MSB-Justified Control Register",NULL },
    { "TX0SASR0",              CSR_BASE+0X002008,g_csr_AUDIO_TXSASR0, "Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL },
    { "TX0SAIMR",              CSR_BASE+0X00200C,g_csr_AUDIO_TXSAIMR, "Serial Audio Interrupt Mask Register",NULL },
    { "TX0SAISR",              CSR_BASE+0X002010,g_csr_AUDIO_TXSAISR, "Serial Audio Interrupt Status Register",NULL },
    { "TX0SADIV",              CSR_BASE+0X002014,g_csr_AUDIO_TXSADIV, "Audio Clock Divider Register",NULL },
    { "TX0SATR",               CSR_BASE+0X002018,NULL, "Serial Audio Transmit Register",NULL },
    { "TX0SAFTH",              CSR_BASE+0X00201C,g_csr_AUDIO_TXSAFTH, "Serial Audio FIFO Threshold Register",NULL },
    { "TX0SAFL",               CSR_BASE+0X002020,g_csr_AUDIO_TXSAFL, "Serial Audio FIFO Level Register",NULL },
    { "TX0SASUDX",             CSR_BASE+0X002040,NULL, "S/PDIF transmit user data bits registers",NULL },
    { "TX0SASUDC",             CSR_BASE+0X002070,g_csr_AUDIO_TXSASUDC, "S/PDIF transmit user data control Register",NULL },
    { "TX0SASCSXA",            CSR_BASE+0X002080,NULL, "S/PDIF transmit channel status Registers",NULL },
    { "TX0SASCSXB",            CSR_BASE+0X002084,NULL, "S/PDIF transmit channel status Registers",NULL },
    { "TX0SASCSC",             CSR_BASE+0X00208C,NULL, "S/PDIF transmit Channel status ctrl Register",NULL },

    { "TX1SACR0",              CSR_BASE+0X002100,g_csr_AUDIO_TXSACR0, "Global Control Register",NULL },
    { "TX1SACR1",              CSR_BASE+0X002104,g_csr_AUDIO_TXSACR1, "Serial Audio I2S/MSB-Justified Control Register",NULL },
    { "TX1SASR0",              CSR_BASE+0X002108,g_csr_AUDIO_TXSASR0, "Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL },
    { "TX1SAIMR",              CSR_BASE+0X00210C,g_csr_AUDIO_TXSAIMR, "Serial Audio Interrupt Mask Register",NULL },
    { "TX1SAISR",              CSR_BASE+0X002110,g_csr_AUDIO_TXSAISR, "Serial Audio Interrupt Status Register",NULL },
    { "TX1SADIV",              CSR_BASE+0X002114,g_csr_AUDIO_TXSADIV, "Audio Clock Divider Register",NULL },
    { "TX1SATR",               CSR_BASE+0X002118,NULL, "Serial Audio Transmit Register",NULL },
    { "TX1SAFTH",              CSR_BASE+0X00211C,g_csr_AUDIO_TXSAFTH, "Serial Audio FIFO Threshold Register",NULL },
    { "TX1SAFL",               CSR_BASE+0X002120,g_csr_AUDIO_TXSAFL, "Serial Audio FIFO Level Register",NULL },
    { "TX1SASUDX",             CSR_BASE+0X002140,NULL, "S/PDIF transmit user data bits registers",NULL },
    { "TX1SASUDC",             CSR_BASE+0X002170,g_csr_AUDIO_TXSASUDC, "S/PDIF transmit user data control Register",NULL },
    { "TX1SASCSXA",            CSR_BASE+0X002180,NULL, "S/PDIF transmit channel status Registers",NULL },
    { "TX1SASCSXB",            CSR_BASE+0X002184,NULL, "S/PDIF transmit channel status Registers",NULL },
    { "TX1SASCSC",             CSR_BASE+0X00218C,NULL, "S/PDIF transmit Channel status ctrl Register",NULL },

    { "TX2SACR0",              CSR_BASE+0X002200,g_csr_AUDIO_TXSACR0, "Global Control Register",NULL },
    { "TX2SACR1",              CSR_BASE+0X002204,g_csr_AUDIO_TXSACR1, "Serial Audio I2S/MSB-Justified Control Register",NULL },
    { "TX2SASR0",              CSR_BASE+0X002208,g_csr_AUDIO_TXSASR0, "Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL },
    { "TX2SAIMR",              CSR_BASE+0X00220C,g_csr_AUDIO_TXSAIMR, "Serial Audio Interrupt Mask Register",NULL },
    { "TX2SAISR",              CSR_BASE+0X002210,g_csr_AUDIO_TXSAISR, "Serial Audio Interrupt Status Register",NULL },
    { "TX2SADIV",              CSR_BASE+0X002214,g_csr_AUDIO_TXSADIV, "Audio Clock Divider Register",NULL },
    { "TX2SATR",               CSR_BASE+0X002218,NULL, "Serial Audio Transmit Register",NULL },
    { "TX2SAFTH",              CSR_BASE+0X00221C,g_csr_AUDIO_TXSAFTH, "Serial Audio FIFO Threshold Register",NULL },
    { "TX2SAFL",               CSR_BASE+0X002220,g_csr_AUDIO_TXSAFL, "Serial Audio FIFO Level Register",NULL },
    { "TX2SASUDX",             CSR_BASE+0X002240,NULL, "S/PDIF transmit user data bits Register",NULL },
    { "TX2SASUDC",             CSR_BASE+0X002270,g_csr_AUDIO_TXSASUDC, "S/PDIF transmit user data control Register",NULL },
    { "TX2SASCSXA",            CSR_BASE+0X002280,NULL, "S/PDIF transmit channel status Register",NULL },
    { "TX2SASCSXB",            CSR_BASE+0X002284,NULL, "S/PDIF transmit channel status Register",NULL },
    { "TX2SASCSC",             CSR_BASE+0X00228C,NULL, "S/PDIF transmit Channel status ctrl Register",NULL },

    { "RX0SACR0",              CSR_BASE+0X003000,g_csr_AUDIO_RXSACR0, "Global Control Register",NULL },
    { "RX0SACR1",              CSR_BASE+0X003004,g_csr_AUDIO_RXSACR1, "Serial Audio I2S/MSB-Justified Control Register",NULL },
    { "RX0SASR0",              CSR_BASE+0X003008,g_csr_AUDIO_RXSASR0, "Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL },
    { "RX0SAIMR",              CSR_BASE+0X00300C,g_csr_AUDIO_RXSAIMR, "Serial Audio Interrupt Mask Register",NULL },
    { "RX0SAISR",              CSR_BASE+0X003010,g_csr_AUDIO_RXSAISR, "Serial Audio Interrupt Status Register",NULL },
    { "RX0SADIV",              CSR_BASE+0X003014, g_csr_AUDIO_RXSADIV,"Audio Clock Divider Register",NULL },
    { "RX0SARR",               CSR_BASE+0X003018,NULL, "Serial Audio Receive Register",NULL },
    { "RX0SAFTH",              CSR_BASE+0X00301C,g_csr_AUDIO_RXSAFTH, "Serial Audio FIFO Threshold Register",NULL },
    { "RX0SAFL",               CSR_BASE+0X003020,g_csr_AUDIO_RXSAFL, "Serial Audio FIFO Level Register",NULL },
    { "RX0SADESC",             CSR_BASE+0X003024,g_csr_AUDIO_RXSASR0, "Audio capture Block size Register",NULL },
    { "RX0SATS",               CSR_BASE+0X003028,NULL, "Audio Capture block timestamp",NULL },
    { "RX0SABAP",              CSR_BASE+0X00302C,NULL, "Audio Sample block buffer pointer",NULL },
    { "RX0SACUDR",             CSR_BASE+0X003030,NULL, "Audio Capture User Data bit FIFO",NULL },
    { "RX0SACSR",              CSR_BASE+0X003034,NULL, "Audio Capture Channel Status bit FIFO",NULL },
    { "RX0SAVR",               CSR_BASE+0X003038,NULL, "Audio Capture Validity bit FIFO",NULL },
    { "RX0SPDBP",              CSR_BASE+0X00303C,NULL, "Audio Capture SPDIF Block address Pointer FIFO",NULL },

    { "RX1SACR0",              CSR_BASE+0X003100,g_csr_AUDIO_RXSACR0, "Global Control Register",NULL },
    { "RX1SACR1",              CSR_BASE+0X003104,g_csr_AUDIO_RXSACR1,"Serial Audio I2S/MSB-Justified Control Register",NULL },
    { "RX1SASR0",              CSR_BASE+0X003108,g_csr_AUDIO_RXSASR0, "Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL },
    { "RX1SAIMR",              CSR_BASE+0X00310C,g_csr_AUDIO_RXSAIMR, "Serial Audio Interrupt Mask Register",NULL },
    { "RX1SAISR",              CSR_BASE+0X003110,g_csr_AUDIO_RXSAISR, "Serial Audio Interrupt Status Register",NULL },
    { "RX1SADIV",              CSR_BASE+0X003114,g_csr_AUDIO_RXSADIV, "Audio Clock Divider Register",NULL },
    { "RX1SARR",               CSR_BASE+0X003118,NULL, "Serial Audio Receive Register",NULL },
    { "RX1SAFTH",              CSR_BASE+0X00311C,g_csr_AUDIO_RXSAFTH, "Serial Audio FIFO Threshold Register",NULL },
    { "RX1SAFL",               CSR_BASE+0X003120,g_csr_AUDIO_RXSAFL, "Serial Audio FIFO Level Register",NULL },
    { "RX1SADESC",             CSR_BASE+0X003124,NULL, "Audio capture Block size Register",NULL },
    { "RX1SATS",               CSR_BASE+0X003128,NULL, "Audio Capture block timestamp",NULL },
    { "RX1SABAP",              CSR_BASE+0X00312C,NULL, "Audio Sample block buffer pointer",NULL },
    { "RX1SACUDR",             CSR_BASE+0X003130,NULL, "Audio Capture User Data bit FIFO",NULL },
    { "RX1SACSR",              CSR_BASE+0X003134,NULL, "Audio Capture Channel Status bit FIFO",NULL },
    { "RX1SAVR",               CSR_BASE+0X003138,NULL, "Audio Capture Validity bit FIFO",NULL },
    { "RX1SPDBP",              CSR_BASE+0X00313C,NULL, "Audio Capture SPDIF Block address Pointer FIFO",NULL },

    { "HDNVAL",                CSR_BASE+0X003400,NULL, "Current value of HDMI N",NULL },
    { "HDRSCS",                CSR_BASE+0X003404,NULL, "HDMI Re-sampler counter sample Register",NULL },
    { "HDRSCT",                CSR_BASE+0X003408,NULL, "HDMI Re-sampler CTS count Register",NULL },
    { "HDAUCF",                CSR_BASE+0X00340C,NULL, "HDMI Audio Control FIFO",NULL },
    { "HDAUCFCFG",             CSR_BASE+0X003410,NULL, "HDMI Audio Control FIFO Configuration Register",NULL },
    { "HDAUCFL",               CSR_BASE+0X003414,NULL, "HDMI Audio Control FIFO Level",NULL },

    /* Audio Re-sampler CSR */
    { "RESAMPLER_CONTROL_REGISTER",CSR_BASE+0x006000,g_csr_RESAMP_CSR, "Re-sampler controls and status register.",NULL },
    { "FILTER_CONFIG_REGISTER1",   CSR_BASE+0X006004,g_csr_RESAMP_FILTER_CR1, "Filter taps and phase increment value",NULL },
    { "FILTER_CONFIG_REGISTER2",   CSR_BASE+0X006008,g_csr_RESAMP_FILTER_CR2, "Current phase value of filter",NULL },
    { "IN_ASTA_PARAM1",            CSR_BASE+0X006010,NULL, "Configures the in_ASTA Intel MSA side address",NULL },
    { "IN_ASTA_PARAM2",            CSR_BASE+0X006014,g_csr_RESAMP_ASTA_PARAM_2, "Configures the in_ASTA transfer parameters",NULL },
    { "IN_ASTA_PARAM3",            CSR_BASE+0X006018,g_csr_RESAMP_ASTA_PARAM_3, "Configures the in_ASTA local side parameters",NULL },
    { "OUT_ASTA_PARAM1",           CSR_BASE+0X006020,NULL, "Configures the out_ASTA Intel MSA address",NULL },
    { "OUT_ASTA_PARAM2",           CSR_BASE+0X006024,g_csr_RESAMP_ASTA_PARAM_2, "Configures the out_ASTA transfer parameters",NULL },

    CSR_NULL_TERM()

};
#endif /* !SVEN_INTERNAL_BUILD */

/*	 TODO-Later: Define important events specific to my module
 *  Use the below structure for creating trackable high level events versus 
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_vr_AUDIO_specific_events[] =
{
    { "Message_Test",       1,      "Message Test", NULL },
    { "Firmware_Load",      2,      "Firmware Load", NULL },
    { "Audio_Decode_Start", 3,      "avdl_auddec_start()", NULL },
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_AUDIO_sven_module =
{
    "GEN2_AUDIO",               /* Module Name */
    SVEN_module_GEN2_AUDIO,     /* Module in <sven_module.h> */
    1*1024*1024,              /* Memory size of register space */
#ifdef SVEN_INTERNAL_BUILD
    g_csr_vr_AUDIO,           /* The main table that contains the reversible register definitions. */
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "AUDIO: (GEN2)",
    g_vr_AUDIO_specific_events, /* Define important events specific to my module */
    NULL                      /* EAS extension list */
};
