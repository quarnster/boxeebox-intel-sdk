/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Simplest Possible example of EAS definition */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

#ifdef SVEN_INTERNAL_BUILD
/* Declare the bit-breakout for the register defined in the EAS_Register defs below.
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_TSD_versions.
 */
static const struct EAS_RegBits g_csr_TSD_CRYPTO_CONTROL[] =
{
    { "RESERVED_31_8",          8,  24,"",NULL},    /* reserved bits [32..8] in this register */
    { "WATCHDOG_CFG",           4,  4,"",NULL}, /* WATCHDOG config  */
    { "STREAM_3_ENABLE",        3,  1,"",NULL},     /* Stream 3 enable  */
    { "STREAM_2_ENABLE",        2,  1,"",NULL},     /* Stream 2 enable  */
    { "STREAM_1_ENABLE",        1,  1,"",NULL},     /* Stream 1 enable  */
    { "STREAM_0_ENABLE",        0,  1,"",NULL},     /* Stream 0 enable  */

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_TSD_CRYPTO_STATUS[] =
{
    { "RESERVED_31_8",          5,  27,"",NULL},    /* reserved bits [31..8] in this register */
    { "Back_Door_Key_Busy",     4,  1,"",NULL},
    { "Invalid_Key",                3,  1,"",NULL},
    { "Output_Ready",               2,  1,"",NULL},
    { "Input_Ready",                1,  1,"",NULL},
    { "Busy",                       0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_TSD_CRC_CONTROL[] =
{
    { "RESERVED_31_2",          2,  30,"",NULL},    /* reserved bits [32..4] in this register */
    { "BIT_DIRECTION",              1,  1,"",NULL},
    { "CRC_ENABLE",             0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_TSD_CRC_STATUS[] =
{
    { "RESERVED_31_1",          1,  31,"",NULL},    /* reserved bits [32..4] in this register */
    { "CRC_Error",              0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_TSD_PM_CONTROL[] =
{
    { "RESERVED_32_4",          4,  28,"",NULL},    /* reserved bits [32..4] in this register */
    { "COMBO_MATCH_ENABLE",     3,  1,"",NULL},
    { "MASK_MATCH_ENABLE",      2,  1,"",NULL},
    { "DIFF_MATCH_ENABLE",      1,  1,"",NULL},
    { "EXACT_MATCH_ENABLE",     0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_TSD_PM_STATUS[] =
{
    { "RESERVED_32_4",          4,  28,"",NULL},    /* reserved bits [32..4] in this register */
    { "COMBO_MATCH_ENABLE",     3,  1,"",NULL},
    { "MASK_MATCH_ENABLE",      2,  1,"",NULL},
    { "DIFF_MATCH_ENABLE",      1,  1,"",NULL},
    { "EXACT_MATCH_ENABLE",     0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_TSD_IO_CONTROL[] =
{
    { "RESERVED_31_4",          4,  28,"",NULL},    /* reserved bits [32..4] in this register */
    { "Send_Remaining",             3,  1,"",NULL},
    { "Send_Enable",                2,  1,"",NULL},
    { "Fetch_Enable",               1,  1,"",NULL},
    { "Input_Flush",                0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_TSD_IO_STATUS[] =
{
    { "RESERVED_31_4",          4,  28,"",NULL},    /* reserved bits [32..4] in this register */
    { "Send_Remaining_Busy",        3,  1,"",NULL},
    { "Out_FIFO_Emtpy",             2,  1,"",NULL},
    { "Shift_Busy",             1,  1,"",NULL},
    { "Input_Flush_Busy",       0,  1,"",NULL},
    
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_TSD_versions.
 */
static const struct EAS_Register g_csr_TSD[] =
{
    /* Crypto Engine Unit registers */
    { "CRYPTO_CONTROL", 0x0000, g_csr_TSD_CRYPTO_CONTROL, "Crypto Control Register",NULL },
    { "CRYPTO_STATUS",   0x0004, g_csr_TSD_CRYPTO_STATUS, "Crypto Status Register",NULL },

    /* Data Shift Register Unit registers */
    { "DSR_DATA_03", 0x0810, NULL, "Data Shift Data_03 Register",NULL},
    { "DSR_DATA_47", 0x0814, NULL, "Data Shift Data_47 Register",NULL},
    { "DSR_DATA_8B", 0x0818, NULL, "Data Shift Data_8B Register",NULL},
    { "DSR_DATA_CF", 0x081C, NULL, "Data Shift Data_CF Register",NULL},

    /* CRC Checker Unit registers */
    { "CRC_CONTROL", 0x1000, g_csr_TSD_CRC_CONTROL, "CRC check control register",NULL },
    { "CRC_STATUS", 0x1004, g_csr_TSD_CRC_STATUS, "CRC check status register",NULL },
    { "CRC_ACCUMULATOR", 0x1010, NULL, "CRC accumulator register",NULL },

    /* Pattern Matcher Unit registers */
    { "PM_CONTROL", 0x1800, g_csr_TSD_PM_CONTROL, "Pattern Matcher Unit Control",NULL},
    { "PM_STATUS", 0x1804, g_csr_TSD_PM_STATUS, "Pattern Matcher Unit Status",NULL},
    { "PM_MASK_03", 0x1810, NULL, "Pattern Matcher Unit Mask03",NULL},
    { "PM_MASK_47", 0x1814, NULL, "Pattern Matcher Unit Mask47",NULL},
    { "PM_MATCH_03", 0x1820, NULL, "Pattern Matcher Unit Match03",NULL},
    { "PM_MATCH_47", 0x1824, NULL, "Pattern Matcher Unit Match03",NULL},

    /* I/O Controller Unit registers */
    { "IO_CONTROL", 0x2000, g_csr_TSD_IO_CONTROL, "I/O controller control Register",NULL },
    { "IO_STATUS", 0x2004, g_csr_TSD_IO_STATUS, "I/O controller status Register",NULL },
    { "IO_INPUT_START_ADDR", 0x2010, NULL, "I/O controller input start address Register",NULL },
    { "IO_INPUT_CURR_ADDR", 0x2014, NULL, "I/O controller input current address Register",NULL },
    { "IO_INPUT_SIZE", 0x2018, NULL, "I/O controller input size Register",NULL },
    { "IO_OUTPUT_START_ADDR", 0x2028, NULL, "I/O controller output start address Register",NULL },
    { "IO_OUTPUT_CURR_ADDR", 0x202C, NULL, "I/O controller output current address Register",NULL },
    { "IO_OUTPUT_SIZE", 0x2030, NULL, "I/O controller output size Register",NULL },

    { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

static const struct SVEN_Module_EventSpecific g_TSD_specific_events[] =
{
    { "TSD_EVENTAME_0",     1,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    2,      "", NULL },

    { "FW_RCV_IPC_CMD_SET_INPUT_STREAM",           0x80, "", NULL },
    { "FW_RCV_IPC_CMD_CONTROL_INPUT_STREAM",       0x81, "", NULL },
    { "FW_RCV_IPC_CMD_SET_FILTER",                 0x82, "", NULL },
    { "FW_RCV_IPC_CMD_CTRL_CRYPTO_ON_FILTER",      0x83, "", NULL },
    { "FW_RCV_IPC_CMD_ADD_PID",                    0x84, "", NULL },
    { "FW_RCV_IPC_CMD_ADD_FILTER_TO_PID",          0x85, "", NULL },
    { "FW_RCV_IPC_CMD_CONTROL_PID",                0x86, "", NULL },
    { "FW_RCV_IPC_CMD_CONTROL_FILTER",             0x87, "", NULL },
    { "FW_RCV_IPC_CMD_DELETE_PID",                 0x88, "", NULL },
    { "FW_RCV_IPC_CMD_DELETE_FILTER_FROM_PID",     0x89, "", NULL },
    { "FW_RCV_IPC_CMD_SET_FILTER_WPA",             0x8a, "", NULL },
    { "FW_RCV_IPC_CMD_ADD_MM_FILTER",              0x8b, "", NULL },
    { "FW_RCV_IPC_CMD_SET_CRYPTO_PARAMS",          0x8c, "", NULL },
    { "FW_RCV_IPC_CMD_SET_CRYPTO_KEY",             0x8d, "", NULL },
    { "FW_RCV_IPC_CMD_SET_STR_CRYPTO_INFO",        0x8e, "", NULL },
    { "FW_RCV_IPC_CMD_RESET_INDEX_COUNT",          0x8f, "", NULL },
    { "FW_RCV_IPC_CMD_SET_DISCONT_PKT_STREAM_ID",  0x90, "", NULL },
    { "FW_RCV_IPC_CMD_SET_PCR_PID",                0x91, "", NULL },
    { "FW_RCV_IPC_CMD_RESET_FILTER",               0x92, "", NULL },
    { "FW_RCV_IPC_CMD_RESET_STREAM",               0x93, "", NULL },
    { "FW_RCV_IPC_CMD_SET_STREAM_LOW_WM",          0x94, "", NULL },
    { "FW_RCV_IPC_CMD_SET_FILTER_HIGH_WM",         0x95, "", NULL },
    { "FW_RCV_IPC_CMD_SET_FILTER_CF",              0x96, "", NULL },
    
    { NULL,0,NULL,NULL }
};

static const struct ModuleReverseDefs g_TSD_sven_module =
{
    "GEN2_TSD",                           /* */
    SVEN_module_GEN2_TSDEMUX,             /*  */
    128*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_TSD,                          /* Register Breakout */
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "TSD: TransportStreamDemux (GEN2)",   /* */
    g_TSD_specific_events,   /* TODO-Later: Define important events specific to my module */
    NULL /* extension list */
};
