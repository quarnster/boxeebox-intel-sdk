/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_CHAP_versions.
 */
static const struct EAS_Register g_csr_CHAP[] =
{
    CSR_REG( "CHAPCMD0",     0x000,  "CHAP Command 0")
    CSR_REG( "CHAPEV0",      0x004,  "CHAP Events 0")
    CSR_REG( "CHAPSTAT0",    0x008,  "CHAP Status 0")
    CSR_REG( "CHAPDATA0",    0x00C,  "CHAP Data 0")
    CSR_REG( "CHAPCMD1",     0x010,  "CHAP Command 1")
    CSR_REG( "CHAPEV1",      0x014,  "CHAP Events 1")
    CSR_REG( "CHAPSTAT1",    0x018,  "CHAP Status 1")
    CSR_REG( "CHAPDATA1",    0x01C,  "CHAP Data 1")
    CSR_REG( "CHAPCMD2",     0x020,  "CHAP Command 2")
    CSR_REG( "CHAPEV2",      0x024,  "CHAP Events 2")
    CSR_REG( "CHAPSTAT2",    0x028,  "CHAP Status 2")
    CSR_REG( "CHAPDATA2",    0x02C,  "CHAP Data 2")
    CSR_REG( "CHAPCMD3",     0x030,  "CHAP Command 3")
    CSR_REG( "CHAPEV3",      0x034,  "CHAP Events 3")
    CSR_REG( "CHAPSTAT3",    0x038,  "CHAP Status 3")
    CSR_REG( "CHAPDATA3",    0x03C,  "CHAP Data 3")
    CSR_REG( "CHAPCMD4",     0x040,  "CHAP Command 4")
    CSR_REG( "CHAPEV4",      0x044,  "CHAP Events 4")
    CSR_REG( "CHAPSTAT4",    0x048,  "CHAP Status 4")
    CSR_REG( "CHAPDATA4",    0x04C,  "CHAP Data 4")
    CSR_REG( "CHAPCMD5",     0x050,  "CHAP Command 5")
    CSR_REG( "CHAPEV5",      0x054,  "CHAP Events 5")
    CSR_REG( "CHAPSTAT5",    0x058,  "CHAP Status 5")
    CSR_REG( "CHAPDATA5",    0x05C,  "CHAP Data 5")
    CSR_REG( "CHAPCMD6",     0x060,  "CHAP Command 6")
    CSR_REG( "CHAPEV6",      0x064,  "CHAP Events 6")
    CSR_REG( "CHAPSTAT6",    0x068,  "CHAP Status 6")
    CSR_REG( "CHAPDATA6",    0x06C,  "CHAP Data 6")
    CSR_REG( "CHAPCMD7",     0x070,  "CHAP Command 7")
    CSR_REG( "CHAPEV7",      0x074,  "CHAP Events 7")
    CSR_REG( "CHAPSTAT7",    0x078,  "CHAP Status 7")
    CSR_REG( "CHAPDATA7",    0x07C,  "CHAP Data 7")

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_CHAP_specific_events[] =
{

/******EXAMPLES*******

    { "OUT_FIFO_FULL",      1,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    2,      "", NULL },

 ****END EXAMPLES*****/

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_CHAP_sven_module =
{
    "GEN2_CHAP",
    SVEN_module_GEN2_CHAP,
    0x00,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_CHAP,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "CHAP: CHAP Function (GEN2)",     /* TODO: Get a better text string */
    g_CHAP_specific_events,         /* TODO-Later: Define important events specific to my module */
    NULL                            /* extension list */
};
