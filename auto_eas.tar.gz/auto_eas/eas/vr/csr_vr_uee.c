/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_UEE_versions.
 */
static const struct EAS_Register g_csr_UEE[] =
{
    CSR_REG("DMA_0_CURR_DESCR",          0x0008, "Current descriptor address pointer")
    CSR_REG("DMA_0_NEXT_DESCR",          0x000C, "Next descriptor address pointer.")
    CSR_REG("DMA_0_SRCDMA_START",        0x0010, "Start address of the Source DMA buffer in the BI address space.")
    CSR_REG("DMA_0_DSTDMA_START",        0x0014, "Start address of the Destination DMA buffer in the BI address space.")
    CSR_REG("DMA_0_SRCDMA_SIZE",         0x0018, "Total size of the block of data (in bytes) to be read from the source location.")
    CSR_REG("DMA_0_FLAGS_MODE",          0x001C, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.")
    CSR_REG("DMA_0_SRCDMA_START_ALIAS",  0x0020, "This is the alias of Source DMA Start Register SRCDMA_START")
    CSR_REG("DMA_0_SRCDMA_BOT",          0x0024, "Address of the bottom of the Source DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_0_SRCDMA_TOP",          0x0028, "Address of the top of the Source DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_0_DSTDMA_BOT",          0x002C, "Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_0_DSTDMA_TOP",          0x0030, "Address of the top of the Destination DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_0_DSTDMA_SIZE",         0x0034, "Size of the block of data (in bytes) to be sent to the destination location.")
    CSR_REG("DMA_0_SRCDMA_STOP",         0x0038, "Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.")
    CSR_REG("DMA_0_DSTDMA_STOP",         0x003C, "Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.")

    /* DMA Context 1 */
    CSR_REG("DMA_1_CURR_DESCR",          0x0048, "Current descriptor address pointer")
    CSR_REG("DMA_1_NEXT_DESCR",          0x004C, "Next descriptor address pointer.")
    CSR_REG("DMA_1_SRCDMA_START",        0x0050, "Start address of the Source DMA buffer in the BI address space.")
    CSR_REG("DMA_1_DSTDMA_START",        0x0054, "Start address of the Destination DMA buffer in the BI address space.")
    CSR_REG("DMA_1_SRCDMA_SIZE",         0x0058, "Total size of the block of data (in bytes) to be read from the source location.")
    CSR_REG("DMA_1_FLAGS_MODE",          0x005C, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.")
    CSR_REG("DMA_1_SRCDMA_START_ALIAS",  0x0060, "This is the alias of Source DMA Start Register SRCDMA_START")
    CSR_REG("DMA_1_SRCDMA_BOT",          0x0064, "Address of the bottom of the Source DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_1_SRCDMA_TOP",          0x0068, "Address of the top of the Source DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_1_DSTDMA_BOT",          0x006C, "Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_1_DSTDMA_TOP",          0x0070, "Address of the top of the Destination DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_1_DSTDMA_SIZE",         0x0074, "Size of the block of data (in bytes) to be sent to the destination location.")
    CSR_REG("DMA_1_SRCDMA_STOP",         0x0078, "Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.")
    CSR_REG("DMA_1_DSTDMA_STOP",         0x007C, "Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.")

    /* DMA Context 2 */
    CSR_REG("DMA_2_CURR_DESCR",          0x0088, "Current descriptor address pointer")
    CSR_REG("DMA_2_NEXT_DESCR",          0x008C, "Next descriptor address pointer.")
    CSR_REG("DMA_2_SRCDMA_START",        0x0090, "Start address of the Source DMA buffer in the BI address space.")
    CSR_REG("DMA_2_DSTDMA_START",        0x0094, "Start address of the Destination DMA buffer in the BI address space.")
    CSR_REG("DMA_2_SRCDMA_SIZE",         0x0098, "Total size of the block of data (in bytes) to be read from the source location.")
    CSR_REG("DMA_2_FLAGS_MODE",          0x009C, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.")
    CSR_REG("DMA_2_SRCDMA_START_ALIAS",  0x00A0, "This is the alias of Source DMA Start Register SRCDMA_START")
    CSR_REG("DMA_2_SRCDMA_BOT",          0x00A4, "Address of the bottom of the Source DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_2_SRCDMA_TOP",          0x00A8, "Address of the top of the Source DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_2_DSTDMA_BOT",          0x00AC, "Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_2_DSTDMA_TOP",          0x00B0, "Address of the top of the Destination DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_2_DSTDMA_SIZE",         0x00B4, "Size of the block of data (in bytes) to be sent to the destination location.")
    CSR_REG("DMA_2_SRCDMA_STOP",         0x00B8, "Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.")
    CSR_REG("DMA_2_DSTDMA_STOP",         0x00BC, "Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.")

    /* DMA Context 3 */
    CSR_REG("DMA_3_CURR_DESCR",          0x00C8, "Current descriptor address pointer")
    CSR_REG("DMA_3_NEXT_DESCR",          0x00CC, "Next descriptor address pointer.")
    CSR_REG("DMA_3_SRCDMA_START",        0x00D0, "Start address of the Source DMA buffer in the BI address space.")
    CSR_REG("DMA_3_DSTDMA_START",        0x00D4, "Start address of the Destination DMA buffer in the BI address space.")
    CSR_REG("DMA_3_SRCDMA_SIZE",         0x00D8, "Total size of the block of data (in bytes) to be read from the source location.")
    CSR_REG("DMA_3_FLAGS_MODE",          0x00DC, "Miscellaneous Control/Status: flags, modes, quality of service, addresses, etc.")
    CSR_REG("DMA_3_SRCDMA_START_ALIAS",  0x00E0, "This is the alias of Source DMA Start Register SRCDMA_START")
    CSR_REG("DMA_3_SRCDMA_BOT",          0x00E4, "Address of the bottom of the Source DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_3_SRCDMA_TOP",          0x00E8, "Address of the top of the Source DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_3_DSTDMA_BOT",          0x00EC, "Address of the bottom of the Destination DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_3_DSTDMA_TOP",          0x00F0, "Address of the top of the Destination DMA buffer (used for circular buffer modes only).")
    CSR_REG("DMA_3_DSTDMA_SIZE",         0x00F4, "Size of the block of data (in bytes) to be sent to the destination location.")
    CSR_REG("DMA_3_SRCDMA_STOP",         0x00F8, "Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space.")
    CSR_REG("DMA_3_DSTDMA_STOP",         0x00FC, "Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space.")

    CSR_REG("STATUS",                    0x1000, "UEE Miscellaneous Status")
    CSR_REG("CONTROL",                   0x1004, "UEE Control Register")

    CSR_REG("AES_RX_DATA",               0x1400, "Receive (Inbound) Data used for direct access mode only.")
    CSR_REG("AES_TX_DATA",               0x1404, "Transmit (outbound) Data used for direct access mode only.")
    /* CSR_REG("AES_HKEY_MODE",          0x1408, "AES HKEY Mode register controls the reading and writing of Hidden Keys for HKEY operations.")  REMOVED IN EAS 0.9 JWC */
    CSR_REG("AES_MODE",                  0x140C, "Configuration register for AES cipher.")
    CSR_REG("AES_KEY7",                  0x1410, "Bits 255:224 of 256-bit AES Key Store.")
    CSR_REG("AES_KEY6",                  0x1414, "Bits 223:192 of 256-bit AES Key Store.")
    CSR_REG("AES_KEY5",                  0x1418, "Bits 191:160 of 192 and 256-bit AES Key Store.")
    CSR_REG("AES_KEY4",                  0x141C, "Bits 159:128 of 192 and 256-bit AES Key Store.")
    CSR_REG("AES_KEY3",                  0x1420, "Bits 127:96 of the 128,192, and 256-bit AES Key Store.")
    CSR_REG("AES_KEY2",                  0x1424, "Bits 95:64 of the 128,192, and 256-bit AES Key Store.")
    CSR_REG("AES_KEY1",                  0x1428, "Bits 63:32 of the 128,192, and 256-bit AES Key Store.")
    CSR_REG("AES_KEY0",                  0x142C, "Least Significant Bits 31:0 of the 128,192, and 256-bit AES Key Store.")
    CSR_REG("AES_IV3",                   0x1430, "Most Significant Bits 127:96 of the AES Initialization Vector Store.")
    CSR_REG("AES_IV2",                   0x1434, "Bits 95:64 of the AES Initialization Vector Store.")
    CSR_REG("AES_IV1",                   0x1438, "Bits 63:32 of the AES Initialization Vector Store.")
    CSR_REG("AES_IV0",                   0x143C, "Least Significant Bits 31:0 of the AES Initialization Vector Store.")

    /* More Aliases */
    CSR_REG("AES_SRCDMA_START_ALIAS",    0x1440, "Start-address of the source DMA buffer. This is also the current address pointer into the source buffer.")
    CSR_REG("AES_DSTDMA_START_ALIAS",    0x1444, "Start-address of the destination DMA buffer. This is also the current address pointer into the destination buffer (write pointer).")
    CSR_REG("AES_SRCDMA_SIZE_ALIAS",     0x1448, "Total size of the block of data (in bytes) to be read from the source location.")
    CSR_REG("AES_DSTDMA_SIZE_ALIAS",     0x144C, "Total size of the block of data (in bytes) to be sent to the destination location.")
    CSR_REG("AES_FLAGS_MODE_ALIAS",      0x1450, "Miscellaneous Control/Status: Flags, Modes, Quality of Service, and Addresses")
    CSR_REG("AES_HKEY_MODE_ALIAS",       0x1458, "AES HKEY Mode register controls the reading and writing of Hidden Keys for HKEY operations.")
    CSR_REG("AES_MODE_ALIAS",            0x145C, "Configuration register for AES cipher.")
    CSR_REG("AES_DMUX_SRCDMA_START_ALIAS",0x1460,"Start-address of the source DMA buffer. This is also the current address pointer into the source buffer.")
    CSR_REG("AES_DMUX_DSTDMA_START_ALIAS",0x1464,"Start-address of the destination DMA buffer. This is also the current address pointer into the destination buffer (write pointer).")
    CSR_REG("AES_DMUX_SRCDMA_SIZE_ALIAS",0x1468, "Total size of the block of data (in bytes) to be read from the source location.")
    CSR_REG("AES_DMUX_DSTDMA_SIZE_ALIAS",0x146C, "Total size of the block of data (in bytes) to be sent to the destination location.")
    CSR_REG("AES_DMUX_FLAGS_MODE_ALIAS", 0x1470, "Miscellaneous Control/Status: Flags, Modes, Quality of Service, and Addresses")


    CSR_REG("C2_RX_DATA0",               0x1800, "Receive (Inbound) Data used for direct access mode only.")
    CSR_REG("C2_RX_DATA1",               0x1804, "Receive (Inbound) Data used for direct access mode only.")
    CSR_REG("C2_TX_DATA0",               0x1808, "Transmit (outbound) Data used for direct access mode only.")
    CSR_REG("C2_TX_DATA1",               0x180C, "Transmit (outbound) Data used for direct access mode only.")
    CSR_REG("C2_MODE",                   0x1818, "Configuration registers for C2 cipher.")
    CSR_REG("C2_KEY0",                   0x181C, "Least Significant Bits 31:0 of the 56-bit C2 Key.")

    /*  More Aliases */
    CSR_REG("C2_SRCDMA_START_ALIAS",     0x1830, "Start-address of the source DMA buffer. This is also the current address pointer into the source buffer.")
    CSR_REG("C2_DSTDMA_START_ALIAS",     0x1834, "Start-address of the destination DMA buffer. This is also the current address pointer into the destination buffer (write pointer). ")
    CSR_REG("C2_SRCDMA_SIZE_ALIAS",      0x1838, "Total size of the block of data (in bytes) to be read from the source location.")
    CSR_REG("C2_DSTDMA_SIZE_ALIAS",      0x183C, "Total size of the block of data (in bytes) to be sent to the destination location.")
    CSR_REG("C2_FLAGS_MODE_ALIAS",       0x1840, "Miscellaneous Control/Status: Flags, Modes, Quality of Service, and Addresses")
    CSR_REG("C2_MODE_ALIAS",             0x184C, "Configuration register for C2 cipher.")
    CSR_REG("C2_DMUX_SRCDMA_START_ALIAS",0x1850, "Start-address of the source DMA buffer. This is also the current address pointer into the source buffer.")
    CSR_REG("C2_DMUX_DSTDMA_START_ALIAS",0x1854, "Start-address of the destination DMA buffer. This is also the current address pointer into the destination buffer (write pointer).")
    CSR_REG("C2_DMUX_SRCDMA_SIZE_ALIAS", 0x1858, "Total size of the block of data (in bytes) to be read from the source location.")
    CSR_REG("C2_DMUX_DSTDMA_SIZE_ALIAS", 0x185C, "Total size of the block of data (in bytes) to be sent to the destination location.")
    CSR_REG("C2_DMUX_FLAGS_MODE_ALIAS",  0x1860, "Miscellaneous Control/Status: Flags, Modes, Quality of Service, and Addresses")

    CSR_REG("CSS_RX_DATA",               0x1C00, "Receive (Inbound) Data: This field is used for direct access mode only.")
    CSR_REG("CSS_TX_DATA",               0x1C04, "Transmit (outbound) Data: This field is used for direct access mode only.")
    CSR_REG("CSS_MODE",                  0x1C10, "Configuration register for CSS stream cipher.")
    CSR_REG("CSS_TK1",                   0x1C14, "CSS TK 1: Bits 39:32 of the Video Title Key.")
    CSR_REG("CSS_TK0",                   0x1C18, "CSS TK 0: Bits 31:0 of the Video Title Key.")
    CSR_REG("CSS_TKC1",                  0x1C1C, "CSS TKC 1: Bits 39:32 of the Video Title Key Conversion Data.")
    CSR_REG("CSS_TKC0",                  0x1C20, "CSS TKC 0: Bits 31:0 of the Video Title Key Conversion Data.")

    /* More Aliases */
    CSR_REG("CSS_SRCDMA_START_ALIAS",    0x1C30, "Start-address of the source DMA buffer. This is also the current address pointer into the source buffer.")
    CSR_REG("CSS_DSTDMA_START_ALIAS",    0x1C34, "Start-address of the destination DMA buffer. This is also the current address pointer into the destination buffer (write pointer).")
    CSR_REG("CSS_SRCDMA_SIZE_ALIAS",     0x1C38, "Total size of the block of data (in bytes) to be read from the source location.")
    CSR_REG("CSS_DSTDMA_SIZE_ALIAS",     0x1C3C, "Total size of the block of data (in bytes) to be sent to the destination location.")
    CSR_REG("CSS_FLAGS_MODE_ALIAS",      0x1C40, "Miscellaneous Control/Status: Flags, Modes, Quality of Service, and Addresses")
    CSR_REG("CSS_MODE_ALIAS",            0x1C4C, "Configuration register for CSS cipher.")
    CSR_REG("CSS_DMUX_SRCDMA_START_ALIAS",0x1C50,"Start-address of the source DMA buffer. This is also the current address pointer into the source buffer.")
    CSR_REG("CSS_DMUX_DSTDMA_START_ALIAS",0x1C54,"Start-address of the destination DMA buffer. This is also the current address pointer into the destination buffer (write pointer).")
    CSR_REG("CSS_DMUX_SRCDMA_SIZE_ALIAS",0x1C58, "Size of the block of data (in bytes) to fetched from the source location.")
    CSR_REG("CSS_DMUX_DSTDMA_SIZE_ALIAS",0x1C5C, "Total size of the block of data (in bytes) to be sent to the destination location.")
    CSR_REG("CSS_DMUX_FLAGS_MODE_ALIAS", 0x1C60, "Miscellaneous Control/Status: Flags, Modes, Quality of Service, and Addresses")

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_UEE_specific_events[] =
{

/******EXAMPLES*******

    { "OUT_FIFO_FULL",      1,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    2,      "", NULL },

 ****END EXAMPLES*****/

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_UEE_sven_module =
{
    "GEN2_UEE",
    SVEN_module_GEN2_UEE,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_UEE,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: UEE Function (GEN2)",      /* TODO: Get a better text string */
    g_UEE_specific_events,          /* TODO-Later: Define important events specific to my module */
    NULL                            /* extension list */
};
