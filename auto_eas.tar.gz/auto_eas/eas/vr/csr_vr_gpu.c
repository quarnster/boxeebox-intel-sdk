/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Bitwise Breakups of GPU registers */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

#ifdef SVEN_INTERNAL_BUILD
static const struct EAS_RegBits g_csr_GPU_SW_RESET[] =
{
    { "RSVD_31_9", 9, 23, "", NULL },
    { "BIF_RST", 8, 1, "Bus Interface Reset", NULL },
    { "RSVD_7_5", 5, 3, "", NULL },
    { "TA_RST", 4, 1, "Tile Accelerator Reset - for ta and vgp lite", NULL },
    { "RSVD_3_1", 1, 3, "", NULL },
    { "PVR_RST", 0, 1, "3D RESET", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_CLK_RATIO[] =
{
    { "RSVD_31_2", 2, 30, "", NULL },
    { "CLK_RATIO", 0, 2, "Clock Ratio Status", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_IDLE_COUNT[] =
{
    { "RSVD_31_16", 16, 16, "", NULL },
    { "IDLE_COUNT", 0, 16, "VAL Idle Count Value in clocks", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_ACTIVITY_COUNT[] =
{
    { "RSVD_31_8", 8, 24, "", NULL },
    { "ACTIVITY_COUNT", 0, 8, "Activity Timeout count in clocks", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_GPO[] =
{
    { "RSVD_31_8", 8, 24, "", NULL },
    { "GPO", 0, 8, "General Purpose Output Controls", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_INT_STATUS[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "RSVD_24", 24, 1, "Returns 1", NULL },
    { "TA_FIFO_USED", 16, 8, "RO - dwords written to TA slave port fifo (128)", NULL },
    { "INT_MASTER", 15, 1, "RO - Master Int status - set if any int set and enabled", NULL },
    { "RSVD_14_11", 11, 4, "", NULL },
    { "2D_SYNC_INT", 10, 1, "2D Driver Synchronization Interrupt", NULL },
    { "TA_STREAM_ERR", 9, 1, "TA Input Stream Error", NULL },
    { "TA_CONTEXT", 8, 1, "TA Context Finished", NULL },
    { "INT_TA_TIMEOUT", 7, 1, "Event Manager TA timeout cleanup Complete", NULL },
    { "INT_EVM_DALLOC", 6, 1, "Event Manager 3D render dealloc Complete", NULL },
    { "INT_TA_OFLOW", 5, 1, "TA Out of Memory", NULL },
    { "INT_TA", 4, 1, "TA Complete", NULL },
    { "INT_ISP", 3, 1, "ISP Render Complete", NULL },
    { "INT_3D", 2, 1, "3D Render Complete", NULL },
    { "RSVD_0_1", 0, 2, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_INT_ENABLE[] =
{
    { "RSVD_31_16", 16, 16, "", NULL },
    { "INT_ENABLE", 15, 1, "Master Enable. int is gen if this bit and INT_MASTER in status are set", NULL },
    { "RSVD_14_11", 11, 4, "", NULL },
    { "2D_SYNC_INT", 10, 1, "2D Driver Synchronization Interrupt Enable", NULL },
    { "TA_STREAM_ERR", 9, 1, "TA Input Stream Error Enable", NULL },
    { "TA_CONTEXT", 8, 1, "TA Context Enable", NULL },
    { "INT_TA_TIMEOUT", 7, 1, "Event Manager TA timeout cleanup Complete Enable", NULL },
    { "INT_EVM_DALLOC", 6, 1, "Event Manager 3D render dealloc Complete Enable", NULL },
    { "INT_TA_OFLOW", 5, 1, "TA Out of Memory Enable", NULL },
    { "INT_TA", 4, 1, "TA Complete Enable", NULL },
    { "INT_ISP", 3, 1, "ISP Render Complete Enable", NULL },
    { "INT_3D", 2, 1, "3D Render Complete Enable", NULL },
    { "RSVD_0_1", 0, 2, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_INT_CLEAR[] =
{
    { "RSVD_31_11", 11, 21, "", NULL },
    { "2D_SYNC_INT", 10, 1, "2D Driver Synchronization Interrupt Clear", NULL },
    { "TA_STREAM_ERR", 9, 1, "TA Input Stream Error Clear", NULL },
    { "TA_CONTEXT", 8, 1, "TA Context Clear", NULL },
    { "INT_TA_TIMEOUT", 7, 1, "Event Manager TA timeout cleanup Complete Clear", NULL },
    { "INT_EVM_DALLOC", 6, 1, "Event Manager 3D render dealloc Complete Clear", NULL },
    { "INT_TA_OFLOW", 5, 1, "TA Overflow Clear", NULL },
    { "INT_TA", 4, 1, "TA Complete Clear", NULL },
    { "INT_ISP", 3, 1, "ISP Render Complete Clear", NULL },
    { "INT_3D", 2, 1, "3D Render Complete Clear", NULL },
    { "RSVD_1_0", 0, 2, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MEMPAGE_SIZE[] =
{
    { "RSVD_31_3", 3, 21, "", NULL },
    { "MEM_PG_SIZE", 0, 3, "000b 0.25KB 001b 0.5KB 010b 1KB 011b 2KB 1xxb 4KB", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_RGNBASE[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "REGIONHDR_BASE", 2, 23, "Bits 24:2 of region header base address. 32MB range on DWord boundaries", NULL },
    { "RSVD_1_0", 0, 2, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_OBJBASE[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "OBJ_PARAM_BASE", 12, 13, "32MB range on 4KB boundaries", NULL },
    { "RSVD_11_0", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_ZLOADSTORE[] =
{
    { "RSVD_31_20", 20, 12, "", NULL },
    { "ZONLY_RENDER", 19, 1, "0 normal, 1 render z to update z buffer - fast render", NULL },
    { "RSVD_18", 18, 1, "", NULL },
    { "Z_FORMAT", 16, 2, "00b 28b float (msb) plus 1 bit mask plane, 11-no ext z buffer, rest reserved", NULL },
    { "RSVD_15", 15, 1, "", NULL },
    { "ZLS_EXTENT", 7, 8, "width in tiles of ext depth buffer - 0x00 1tile/16pix...0xff 256tiles/2048pix", NULL },
    { "RSVD_6_2", 2, 5, "", NULL },
    { "ZSTORE_ENABLE", 1, 1, "depth buffer stored if per tile enable set in reg header", NULL },
    { "ZLOAD_ENABLE", 0, 1, "depth buffer read if per tile enable set in reg header", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_FPUPERPVAL[] =
{
    { "RSVD_31", 31, 1, "", NULL },
    { "FPU_PERP_VAL", 4, 27, "value to compare with triangle's determinant - if det <, use perp math", NULL },
    { "RSVD_3_0", 0, 4, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_FPUCULLVAL[] =
{
    { "RSVD_31", 31, 1, "", NULL },
    { "FPU_CULL_VAL", 4, 27, "value to compare with triangle's determinant - if det <, cull traingle", NULL },
    { "RSVD_3_0", 0, 4, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_3DPIXSAMP[] =
{
    { "RSVD_31_18", 18, 14, "", NULL },
    { "DCALC_MODE", 16, 2, "x,y for num polynomial for 3D -> 11 reserved 10-toplft 01-x=y=0 00-vertice avg", NULL },
    { "RSVD_15_3", 3, 13, "", NULL },
    { "TSP_TEX_POS", 2, 1, "to fetch texels - 0 0, 0 1 0.5, 0.5", NULL },
    { "TSP_PIX_POS", 1, 1, "to fetch pixels for texture n shading - 0 0, 0 1 0.5, 0.5", NULL },
    { "TSP_FPU_POS", 0, 1, "to fetch for hidden surface removal - 0 0, 0 1 0.5, 0.5", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_CK1[] =
{
    { "RSVD_31_24", 24, 8, "", NULL },
    { "CK1_R", 16, 8, "color key selected when CK_SEL=00 and tex fmt not yuv", NULL },
    { "CK1_G", 8, 8, "color key selected when CK_SEL=00 and tex fmt not yuv", NULL },
    { "CK1_B", 0, 8, "color key selected when CK_SEL=00 and tex fmt not yuv", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_CK2[] =
{
    { "RSVD_31_24", 24, 8, "", NULL },
    { "CK2_R", 16, 8, "color key selected when CK_SEL=01 and tex fmt not yuv", NULL },
    { "CK2_G", 8, 8, "color key selected when CK_SEL=01 and tex fmt not yuv", NULL },
    { "CK2_B", 0, 8, "color key selected when CK_SEL=01 and tex fmt not yuv", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_CKUV[] =
{
    { "RSVD_31_16", 24, 16, "", NULL },
    { "CK_U", 8, 8, "color key selected when CK_SEL(1)=0 and tex fmt yuv", NULL },
    { "CK_V", 0, 8, "color key selected when CK_SEL=0 and tex fmt yuv", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_CKMASK[] =
{
    { "RSVD_31_3", 3, 29, "", NULL },
    { "CK_MASK", 0, 3, "000 mask no bits, 001-mask 1 lsb, 111 - mask 7 lsb", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_FOGCOLVERT[] =
{
    { "RSVD_31_24", 24, 8, "", NULL },
    { "VERT_FOG_COL", 0, 24, "RGB color used for vertex fogging", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_FOGSTATUS[] =
{
    { "RSVD_31_24", 24, 8, "", NULL },
    { "VERT_FOG_COL", 0, 24, "RGB color used for vertex fogging returned for use in Zloadstore", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_SCALERCTL[] =
{
    { "RSVD_31_2", 2, 30, "", NULL },
    { "HSCALE", 1, 1, "Horiz downscaling: 0-noscale 1-scaleby2", NULL},
    { "VSCALE", 0, 1, "Vert downscaling: 0-noscale 1-scaleby2", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_BLENDCTL[] =
{
    { "RSVD_31_17", 17, 30, "", NULL },
    { "FORCE_ALPHA", 16, 1, "alpha control - 0-nomod 1-0xff", NULL},
    { "RSVD_15_1", 1, 15, "", NULL },
    { "SUB_128", 0, 1, "0-nooffset 1-apply-128 for each argb component -> offset control for tex blend", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_ARGBSUM[] =
{
    { "RSVD_31_1", 1, 31, "", NULL },
    { "ARGB_SUM", 0, 1, "dot product sum control - 0-addRGB 1-addARGB", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_FBCTL[] =
{
    { "RSVD_31_20", 20, 12, "", NULL },
    { "FB_ALPHA_THRESHOLD", 12, 8, "for 1555 if internal alpha > - 1 to topbit else 0", NULL},
    { "FB_KVAL", 4, 8, "constant alpha value", NULL},
    { "FB_DITHER", 3, 1, "ctrl conv from 8888 to 16bit 0-truncpix, 1-ditherpix", NULL},
    { "FB_PACKMODE", 0, 3, "Pixel packing mode for 3D pixel writes 000-555, 001-565,010-4444,011-1555, 100-888, 101-x888, 110-8888, 111-reserved", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_FBXCLIP[] =
{
    { "RSVD_31_27", 27, 5, "", NULL },
    { "FB_XCLIP_MAX", 16, 11, "pix w/ x> are clipped", NULL},
    { "RSVD_15_11", 11, 5, "", NULL },
    { "FB_XCLIP_MIN", 0, 11, "pix w/ x < are clipped", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_FBYCLIP[] =
{
    { "RSVD_31_26", 26, 6, "", NULL },
    { "FB_YCLIP_MAX", 16, 10, "pix w/ y> are clipped", NULL},
    { "RSVD_15_10", 10, 6, "", NULL },
    { "FB_YCLIP_MIN", 0, 10, "pix w/ y < are clipped", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_FBSTART[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "FBSTART", 2, 23, "start of 3d render address - 32MB range on dword boundary", NULL},
    { "RSVD_0_1", 0, 2, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_FBLINESTRIDE[] =
{
    { "RSVD_31_12", 12, 20, "", NULL },
    { "FB_LINESTRIDE", 0, 12, "width of line when rendering 3D pixels into frame buffer ", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_LATENCYCOUNT[] =
{
    { "RSVD_31_4", 4, 28, "", NULL },
    { "TEX_LATENCY", 0, 4, "no of clks to delay tex mem requests to allow req to be gpd into bursts", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_ZBASEADDR[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "ZBASEADDR", 2, 23, "start of zbuff mem address - 32MB range on dword boundary", NULL},
    { "RSVD_0_1", 0, 2, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_3DFLATSHADEDCS[] =
{
    { "RSVD_31_1", 1, 31, "", NULL },
    { "FLAT_SHADE_SRC", 0, 1, "base and offset color of a triangle", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_3D_ZL_BACKGROUND_TAG[] =
{
    { "RSVD_31_30", 30, 2, "", NULL },
    { "ZL_BGT_OFFSET", 29, 1, "offset parameter present", NULL},
    { "ZL_BGT_NUM_UV", 28, 1, "no of texture layers", NULL},
    { "ZL_BGT_TEXTURED", 27, 1, "textured flag", NULL},
    { "ZL_BGT_RES1", 25, 2, "rsvd - write 0x0", NULL},
    { "ZL_BGT_RES0", 21, 4, "rsvd - write 0x8", NULL},
    { "ZL_BGT_ADDRESS", 0, 21, "tag address: 8MB on dword boundary", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_3D_ZL_BACKGROUND_DEPTH[] =
{
    { "RSVD_31", 31, 1, "", NULL },
    { "ZL_BG_DEPTH", 4, 27, "28b float - init ISP depth buffer when zloadfmt = 0x3", NULL},
    { "RSVD_3_1", 1, 3, "", NULL },
    { "ZL_BG_MSK_PLANE", 0, 1, "init ISP mask buffer when zloadfmt = 0x3", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_USE_1BPP_REGS_CTL[] =
{
    { "RSVD_31_1", 1, 31, "", NULL },
    { "1BPP_USE", 0, 1, "use 1bpp texture format regs", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_3D_RENDER_ID[] =
{
    { "RSVD_31_1", 1, 31, "", NULL },
    { "PVR_RENDER_ID", 0, 1, "keep track of 2 inde frames ", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_3D_TEX_DECIM[] =
{
    { "RSVD_31_17", 17, 15, "", NULL },
    { "TEX_DEC_CTRL", 16, 1, "0-off 1-on", NULL},
    { "RSVD_15_3", 3, 13, "", NULL },
    { "TEX_DEC_FAC", 0, 3, "000-normal 001-1 010-2 others rsrvd", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_RENDER_ID[] =
{
    { "RSVD_31_1", 1, 31, "", NULL },
    { "TA_RENDER_ID", 0, 1, "keep track of 2 inde frames ", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_CONTEXT_BASE[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "TA_CONTEXT_BASE", 8, 19, "32MB range on 256B boundary ", NULL},
    { "RSVD_7_0", 0, 8, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_EVM_PAGETBL_BASE[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "EVM_LIST_BASE", 8, 19, "32MB range on 256B boundary ", NULL},
    { "RSVD_7_0", 0, 8, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_EVM_LIST_START[] =
{
    { "RSVD_31_13", 13, 19, "", NULL },
    { "EVM_LIST_START", 0, 13, "first page allocated by evm ", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_EVM_LIST_END[] =
{
    { "RSVD_31_13", 13, 19, "", NULL },
    { "EVM_LIST_END", 0, 13, "first page allocated by evm ", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_OBJDATABASE[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "TA_OBJ_BASE", 12, 13, "32MB range on dword boundary ", NULL},
    { "RSVD_11_0", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_TAILPTRBASE[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "TA_TPC_BASE_ADDR", 8, 17, "32MB range on 256B boundary ", NULL},
    { "RSVD_7_0", 0, 8, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_REGION_BASE[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "TA_RGN_BASE", 2, 23, "32MB range on dword boundary ", NULL},
    { "RSVD_1_0", 0, 2, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_XCLIP[] =
{
    { "RSVD_31_27", 27, 5, "", NULL },
    { "TA_XCLIP_MAX", 16, 11, "pix w/ x> are clipped", NULL},
    { "RSVD_15_11", 11, 5, "", NULL },
    { "TA_XCLIP_MIN", 0, 11, "pix w/ x < are clipped", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_YCLIP[] =
{
    { "RSVD_31_26", 26, 6, "", NULL },
    { "TA_YCLIP_MAX", 16, 10, "pix w/ y> are clipped", NULL},
    { "RSVD_15_10", 10, 6, "", NULL },
    { "TA_YCLIP_MIN", 0, 10, "pix w/ y < are clipped", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_RHWCLAMP[] =
{
    { "RSVD_31", 31, 1, "", NULL },
    { "TA_RHWCLAMP", 4, 27, "", NULL},
    { "RSVD_3_0", 0, 4, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_RHWCOMP[] =
{
    { "RSVD_31", 31, 1, "", NULL },
    { "TA_RHW_COMP", 4, 27, "", NULL},
    { "RSVD_3_0", 0, 4, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_CONFIG[] =
{
    { "RSVD_31", 31, 1, "", NULL },
    { "SNAP_DISABLE", 30, 1, "", NULL },
    { "RGN_HDR_GEN", 27, 3, "", NULL },
    { "RENDER_WDTH", 20, 7, "", NULL },
    { "ZLOADSTORE_CTRL", 18, 2, "", NULL },
    { "RSVD_17_16", 16, 2, "", NULL },
    { "RENDER_HT", 10, 6, "", NULL },
    { "NO_DEALLOC", 9, 1, "", NULL },
    { "NO_INIT", 8, 1, "", NULL },
    { "COMPLETE_ON_TERMINATE", 7, 1, "", NULL },
    { "PX_CENTER", 6, 1, "", NULL },
    { "INV_OFFSET_ALPHA", 5, 1, "", NULL },
    { "INV_BASE_ALPHA", 4, 1, "", NULL },
    { "RSVD_3", 3, 1, "", NULL },
    { "SUPER_SAMPLE_Y", 2, 1, "", NULL },
    { "SUPER_SAMPLE_X", 1, 1, "", NULL },
    { "SMALL_OBJ_CULL", 0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_TA_EVM_CONTEXT_FLUSH_ADDR[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "EVM_CTX_BASE", 14, 11, "32MB range on 256B boundary ", NULL},
    { "RSVD_13_0", 0, 14, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MBX1_DIAG_EN[] =
{
    { "RSVD_31_1", 1, 31, "", NULL },
    { "DIAG_ENABLE", 0, 1, "for debug 1-enabled 0-not", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_CORE_ID[] =
{
    { "GROUP_ID", 24, 8, "RO - 0x01", NULL},
    { "CORE_ID", 16, 8, "RO - 0x02", NULL },
    { "RSVD_15_2", 2, 14, "", NULL},
    { "CORE_CFG_MMU", 1, 1, "RO", NULL},
    { "CORE_CFG_VGP", 0, 1, "RO", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_REVISION[] =
{
    { "RSVD_31_24", 24, 8, "", NULL },
    { "MAJOR_REV", 16, 8, "RO - 0x01", NULL},
    { "MINOR_REV", 8, 8, "RO - 0x01", NULL},
    { "MAINT_REV", 0, 8, "RO", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_PAGE0_ADDR[] =
{
    { "MMU_TABLE_0", 12, 20, "4GB range on 4KB boundary", NULL},
    { "RSVD_11_0", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_PAGE1_ADDR[] =
{
    { "MMU_TABLE_1", 12, 20, "4GB range on 4KB boundary", NULL},
    { "RSVD_11_0", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_PAGE2_ADDR[] =
{
    { "MMU_TABLE_2", 12, 20, "4GB range on 4KB boundary", NULL},
    { "RSVD_11_0", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_PAGE3_ADDR[] =
{
    { "MMU_TABLE_3", 12, 20, "4GB range on 4KB boundary", NULL},
    { "RSVD_11_0", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_PAGE4_ADDR[] =
{
    { "MMU_TABLE_4", 12, 20, "4GB range on 4KB boundary", NULL},
    { "RSVD_11_0", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_PAGE5_ADDR[] =
{
    { "MMU_TABLE_5", 12, 20, "4GB range on 4KB boundary", NULL},
    { "RSVD_11_0", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_PAGE6_ADDR[] =
{
    { "MMU_TABLE_6", 12, 20, "4GB range on 4KB boundary", NULL},
    { "RSVD_11_0", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_PAGE7_ADDR[] =
{
    { "MMU_TABLE_7", 12, 20, "4GB range on 4KB boundary", NULL},
    { "RSVD_11_0", 0, 12, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_ENABLE[] =
{
    { "RSVD_31_25", 25, 7, "", NULL },
    { "MMU_INVAL_STA", 24, 1, "RO - 1-cacheinvalid in progress, 0-normal", NULL},
    { "RSVD_23_17", 17, 7, "", NULL },
    { "MMU_RDY", 16, 1, "RO - 1-MMU initialized 0-not", NULL},
    { "RSVD_15_9", 9, 7, "", NULL },
    { "MMU_INVAL", 8, 1, "WO - invalidate index n phyaddr", NULL},
    { "RSVD_7_1", 1, 7, "", NULL },
    { "MMU_ENABLE", 0, 1, "0-notranslation 1-addrtranslation", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_IDX_INVAL[] =
{
    { "RSVD_31_13", 13, 19, "", NULL },
    { "MMU_TAG", 8, 5, "", NULL},
    { "MMU_INDEX", 0, 8, "", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_GPU_MMU_PHYSADD_INVAL[] =
{
    { "RSVD_31_21", 21, 11, "", NULL },
    { "MMU_PHYSADD", 0, 21, "top 21 bits of addr to replace cache", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Simplest Possible example of EAS definition */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

/* Declare the register names and their offsets, NULL terminated
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_GPU_versions.
 */
static const struct EAS_Register g_csr_GPU[] =
{
    CSR_REG_W_BB("SW_RESET",            0x0080, g_csr_GPU_SW_RESET, "Software Reset")
    CSR_REG_W_BB("CLK_RATIO",                0x0090, g_csr_GPU_CLK_RATIO, "Clock Ratio Status")
    CSR_REG_W_BB("IDLE_COUNT",               0x0100, g_csr_GPU_IDLE_COUNT, "2D Idle Timeout Clock Cycle Count")
    CSR_REG_W_BB("ACTIVITY_COUNT",           0x0104, g_csr_GPU_ACTIVITY_COUNT, "Startup Timeout Clock Cycle Count")
    CSR_REG_W_BB("GPO",                      0x0108, g_csr_GPU_GPO, "General Purpose Output")
    CSR_REG_W_BB("INT_STATUS",               0x012C, g_csr_GPU_INT_STATUS, "Interrupt Status")
    CSR_REG_W_BB("INT_ENABLE",               0x0130, g_csr_GPU_INT_ENABLE, "Interrupt Enable")
    CSR_REG_W_BB("INT_CLEAR",                0x0134, g_csr_GPU_INT_CLEAR, "Interrupt Clear")
    CSR_REG_W_BB("MEMPAGE_SIZE",             0x0140, g_csr_GPU_MEMPAGE_SIZE, "Memory Page Size")
    CSR_REG_W_BB("RGNBASE",                  0x0608, g_csr_GPU_RGNBASE, "3D Region Header Base")
    CSR_REG_W_BB("OBJBASE",                  0x060C, g_csr_GPU_OBJBASE, "3D Object Base")
    CSR_REG_W_BB("ZLOADSTORE",               0x0610, g_csr_GPU_ZLOADSTORE, "3D Z Load Store Control")

    CSR_REG_W_BB("FPUPERPVAL",               0x0614, g_csr_GPU_FPUPERPVAL, "3D FPU Perpendicular Compare")
    CSR_REG_W_BB("FPUCULLVAL",               0x0618, g_csr_GPU_FPUCULLVAL, "3D FPU Cull Value")
    CSR_REG_W_BB("3DPIXSAMP",                0x061C, g_csr_GPU_3DPIXSAMP, "3D Pixel Sampling")
    CSR_REG_W_BB("CK1",                      0x0624, g_csr_GPU_CK1, "3D Colour Key 1")
    CSR_REG_W_BB("CK2",                      0x0628, g_csr_GPU_CK2, "3D Colour Key 2")
    CSR_REG_W_BB("CKUV",                     0x062C, g_csr_GPU_CKUV, "3D Colour Key UV")
    CSR_REG_W_BB("CKMASK",                   0x0630, g_csr_GPU_CKMASK, "3D Colour Key Mask")
    CSR_REG_W_BB("FOGCOLVERT",               0x063C, g_csr_GPU_FOGCOLVERT, "3D Vertex Fog Colour")
    CSR_REG_W_BB("VERTFOGSTATUS",            0x0640, NULL, "RO - 3D Vertex Fog Status: Current fog color")

    CSR_REG_W_BB("SCALERCTL",                0x0644, g_csr_GPU_SCALERCTL, "3D Scaler Control")
    CSR_REG_W_BB("BLENDCTL",                 0x0648, g_csr_GPU_BLENDCTL, "3D Blend Control")
    CSR_REG_W_BB("ARGBSUM",                  0x064C, g_csr_GPU_ARGBSUM, "3D Blend ARGB Sum")
    CSR_REG_W_BB("FBCTL",                    0x0650, g_csr_GPU_FBCTL, "3D Write Control")
    CSR_REG_W_BB("FBXCLIP",                  0x0654, g_csr_GPU_FBXCLIP, "3D Write X Clipping")
    CSR_REG_W_BB("FBYCLIP",                  0x0658, g_csr_GPU_FBYCLIP, "3D Write Y Clipping")
    CSR_REG_W_BB("FBSTART",                  0x065C, g_csr_GPU_FBSTART, "3D Render Address")

    CSR_REG_W_BB("FBLINESTRIDE",             0x0660, g_csr_GPU_FBLINESTRIDE, "3D Write Stride")
    CSR_REG_W_BB("LATENCYCOUNT",             0x0664, g_csr_GPU_LATENCYCOUNT, "3D Texture Latency")

    CSR_REG_W_BB("ZBASEADDR",                0x0674, g_csr_GPU_ZBASEADDR, "3D Z Base Address")

    CSR_REG_W_BB("STARTRENDER",              0x0680, NULL, "WO - 3D Start Render")
    CSR_REG_W_BB("3DFLATSHADEDCS",           0x06D0, g_csr_GPU_3DFLATSHADEDCS, "3D Flat Shaded Colour Source")
    CSR_REG_W_BB("3D_ZL_BACKGROUND_TAG",     0x06D8, g_csr_GPU_3D_ZL_BACKGROUND_TAG, "3D ZLoad Background Tag")
    CSR_REG_W_BB("3D_ZL_BACKGROUND_DEPTH",   0x06DC, g_csr_GPU_3D_ZL_BACKGROUND_DEPTH, "3D ZLoad Background Depth")

    CSR_REG_W_BB("1BPP_BACKGROUND_COLOUR",   0x06E0, NULL, "3D 1Bpp Background Colour")
    CSR_REG_W_BB("1BPP_FOREGROUND_COLOUR",   0x06E4, NULL, "3D 1Bpp Foreground Colour")

    CSR_REG_W_BB("USE_1BPP_REGS_CTL",        0x06E8, g_csr_GPU_USE_1BPP_REGS_CTL, "3D 1Bpp Use Register Values")
    CSR_REG_W_BB("3D_RENDER_ID",             0x06EC, g_csr_GPU_3D_RENDER_ID, "3D Render ID")
    CSR_REG_W_BB("3D_TEX_DECIM",             0x06F0, g_csr_GPU_3D_TEX_DECIM, "3D Texture Decimation")

    CSR_REG_W_BB("TA_START",                 0x0800, NULL, "WO - TA Start")
    CSR_REG_W_BB("TA_RESTART",               0x0804, NULL, "WO - TA Restart")
    CSR_REG_W_BB("TA_ABORT",                 0x0808, NULL, "WO - TA Abort")

    CSR_REG_W_BB("TA_RENDER_ID",             0x0810, g_csr_GPU_TA_RENDER_ID, "TA Render ID")
    CSR_REG_W_BB("TA_CONTEXT_LOAD",          0x0814, NULL, "WO - TA Context Load")
    CSR_REG_W_BB("TA_CONTEXT_STORE",         0x0818, NULL, "WO - TA Context Store")
    CSR_REG_W_BB("TA_CONTEXT_RESET",         0x081C, NULL, "WO - TA Context Reset")
    CSR_REG_W_BB("TA_CONTEXT_BASE",          0x0820, g_csr_GPU_TA_CONTEXT_BASE, "TA Context Base")
    CSR_REG_W_BB("TA_EVM_PAGETBL_BASE",      0x0824, g_csr_GPU_TA_EVM_PAGETBL_BASE, "EVM Page Table Base Address")
    CSR_REG_W_BB("TA_EVM_LIST_START",        0x0828, g_csr_GPU_TA_EVM_LIST_START, "EVM List Start Page")
    CSR_REG_W_BB("TA_EVM_LIST_END",          0x082C, g_csr_GPU_TA_EVM_LIST_END, "EVM List End Page")
    CSR_REG_W_BB("TA_EVM_RENDER_TIMEOUT",    0x0830, NULL, "WO - EVM Render Timeout")
    CSR_REG_W_BB("TA_EVM_TA_TIMEOUT",        0x0834, NULL, "WO - EVM TA Timeout")
    CSR_REG_W_BB("TA_EVM_INIT",              0x0838, NULL, "WO - EVM Init")
    CSR_REG_W_BB("TA_OBJDATABASE",           0x083C, g_csr_GPU_TA_OBJDATABASE, "TA Object Base Address")
    CSR_REG_W_BB("TA_TAILPTRBASE",           0x0840, g_csr_GPU_TA_TAILPTRBASE, "TA Tail Pointer Base Address")
    CSR_REG_W_BB("TA_REGION_BASE",           0x0844, g_csr_GPU_TA_REGION_BASE, "TA Region Base Address")
    CSR_REG_W_BB("TAGLOBREG_GLOBAL_LIST_CTRL",0x0848, NULL, "TA Global List Control")
    CSR_REG_W_BB("TA_XCLIP",                 0x084C, g_csr_GPU_TA_XCLIP, "TA X Screen Clip")
    CSR_REG_W_BB("TA_YCLIP",                 0x0850, g_csr_GPU_TA_YCLIP, "TA Y Screen Clip")
    CSR_REG_W_BB("TA_RHWCLAMP",              0x0854, g_csr_GPU_TA_RHWCLAMP, "TA RHW Clamp")
    CSR_REG_W_BB("TA_RHWCOMP",               0x0858, g_csr_GPU_TA_RHWCOMP, "TA RHW Compare")
    CSR_REG_W_BB("TA_CONFIG",                0x085C, g_csr_GPU_TA_CONFIG, "TA Configuration")
    CSR_REG_W_BB("TA_EVM_CONTEXT_FLUSH_ADDR",0x0864, g_csr_GPU_TA_EVM_CONTEXT_FLUSH_ADDR, "EVM Context Base Address")

    CSR_REG_W_BB("MBX1_ISP1_SIG",            0x0CC4, NULL, "RO - ISP1 Signature")
    CSR_REG_W_BB("MBX1_TSP1_SIG",            0x0CCC, NULL, "RO - TSP1 Signature")
    CSR_REG_W_BB("MBX1_DIAG_EN",             0x0CE0, g_csr_GPU_MBX1_DIAG_EN, "Diagnostics Enable")

    CSR_REG_W_BB("CORE_ID",                  0x0F00, g_csr_GPU_CORE_ID, "MBX Lite Core ID")
    CSR_REG_W_BB("REVISION",                 0x0F10, g_csr_GPU_REVISION, "MBX Lite Core Revision")

    CSR_REG_W_BB("MMU_PAGE0_ADDR",           0x1000, g_csr_GPU_MMU_PAGE0_ADDR, "MMU Table Page 0 Address")
    CSR_REG_W_BB("MMU_PAGE1_ADDR",           0x1004, g_csr_GPU_MMU_PAGE1_ADDR, "MMU Table Page 1 Address")
    CSR_REG_W_BB("MMU_PAGE2_ADDR",           0x1008, g_csr_GPU_MMU_PAGE2_ADDR, "MMU Table Page 2 Address")
    CSR_REG_W_BB("MMU_PAGE3_ADDR",           0x100C, g_csr_GPU_MMU_PAGE3_ADDR, "MMU Table Page 3 Address")
    CSR_REG_W_BB("MMU_PAGE4_ADDR",           0x1010, g_csr_GPU_MMU_PAGE4_ADDR, "MMU Table Page 4 Address")
    CSR_REG_W_BB("MMU_PAGE5_ADDR",           0x1014, g_csr_GPU_MMU_PAGE5_ADDR, "MMU Table Page 5 Address")
    CSR_REG_W_BB("MMU_PAGE6_ADDR",           0x1018, g_csr_GPU_MMU_PAGE6_ADDR, "MMU Table Page 6 Address")
    CSR_REG_W_BB("MMU_PAGE7_ADDR",           0x101C, g_csr_GPU_MMU_PAGE7_ADDR, "MMU Table Page 7 Address")
    CSR_REG_W_BB("MMU_ENABLE",               0x1020, g_csr_GPU_MMU_ENABLE, "MMU Enable")
    CSR_REG_W_BB("MMU_IDX_INVAL",            0x1024, g_csr_GPU_MMU_IDX_INVAL, "MMU Index Invalidate")
    CSR_REG_W_BB("MMU_PHYSADD_INVAL",        0x1028, g_csr_GPU_MMU_PHYSADD_INVAL, "MMU Phys Add Invalidate")


    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_GPU_specific_events[] =
{

/******EXAMPLES*******

    { "OUT_FIFO_FULL",      1,      "Software did read captured frames in time", NULL },
    { "IN_FIFO_STARVED",    2,      "", NULL },

 ****END EXAMPLES*****/

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GPU_sven_module =
{
    "GEN2_GPU",
    SVEN_module_GEN2_GPU,
    16*1024*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GPU,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: GPU Function (GEN2)",    /* TODO: Get a better text string */
    g_GPU_specific_events,        /* TODO-Later: Define important events specific to my module */
    NULL                          /* extension list */
};
