/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
static const struct EAS_Register g_csr_ENCODER[] =
{
   { NULL,0,NULL,"",NULL }   /* NULL Terminated */
};
#endif /* INTERNAL_BUILD */

static const struct SVEN_Module_EventSpecific g_ENCODER_specific_events[] =
{
   #include "ismd_standard_events.c"

   /* When "ES buffer Ready to output" message is received from firmware */
   { "OUTPUT_ES", 8, "\tStreamID=%d OutPortID=%d OutBuf=%d ", NULL },

   /* When the first framebuffer was received by the driver */
   { "FIRST_FRAME", 9, "\tStreamID=%d InPortID=%d FB=%d", NULL },
 
   /* When the videnc state is changed */
   { "SET_STATE", 16, "\tstate=%d", NULL },

   /* When the videnc instance is opened for a stream */
   { "OPEN", 17, "\tStream ID=%d InPortID=%d OutPortID=%d ismd_dev_handle=%d codec=%d", NULL},

   /* When the videnc driver identifies EOS on input */
   { "EOS_FOUND", 18, "\tStreamID=%d InPortID=%d FB=%d TotalFramesReceived=%d", NULL },

   /* When the EOS is triggered */
   { "EOS_TRIGGERED", 19, "\tStreamID=%d OutPortID=%d", NULL },

   /* videnc driver HAL messages */
   { "HAL_GET_FW_VER", 0x40, "  encoder %08x,%08x", NULL },

   { "HAL_TX_FRM_TO_FW", 0x4e, " hand: %08x id %08x pa %08x len %08x flg %08x smd %08x", NULL },
   { "HAL_TX_ES_TO_FW", 0x4e, " hand: %08x id %08x pa %08x len %08x flg %08x smd %08x", NULL },
   { "HAL_WKLD_TX", 0x50, "   hand: %08x id %08x pa %08x len %08x flg %08x", NULL },
   { "HAL_WKLD_RX", 0x51, "   hand: %08x id %08x pa %08x len %08x flg %08x", NULL },

     /* When the hal is opened */
     { "HAL_OPEN", 0x62, "\tCodec=%d", NULL },

   /* When the hal is closed */
   { "HAL_CLOSE", 0x63, "\tHalHandle=%d FW Handle=%d", NULL },

   { "HAL_GET_DESCR_ERR"  , 0x76, "ERROR: can not read buffer descriptor, handle: %d, ret=%d", NULL },

     { NULL, 0, "", NULL }
};
//
static const struct ModuleReverseDefs g_ENCODER_sven_module =
{
	"SW_ENCODER",
	SVEN_module_ENCODER,
	0,                          /* Size of MMRs */
#ifdef SVEN_INTERNAL_BUILD
	g_csr_ENCODER,               /*  */
#else
	NULL,                       /* What is the latest HW version to use? */
#endif
	"ENCODER: ENCODER",/* Get a better text string */
	g_ENCODER_specific_events,   /* Define important events specific to my module */
	NULL                        /* extension list */
};

