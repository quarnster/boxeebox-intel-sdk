/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Simplest Possible example of EAS definition */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

/* Declare the bit-breakout for the register defined in the EAS_Register defs below.
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_MyModule_versions.
 */

//------------------------------------------------------------------------------
// BSR_AVO_VER
//     
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_VERSION[] =
{
    { "RSVD_31_16",         16,16, "",NULL },  /* 31 : 16 - Reserved */
	{ "Year",               12, 4, "",NULL },  /* 15 : 12 - Version Build Year (0-15) */
	{ "Month",               8, 4, "",NULL },  /* 11 :  8 - Version Build Month (1-12) */
	{ "Date",                3, 5, "",NULL },  /*  7 :  3 - Version Build Date (1-31) */
    { "Version",             0, 3, "",NULL },  /*  2 :  0 - Version Build Number (0-7) */
    { NULL,                  0, 0, "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_ID
//     
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_ID[] =
{
    { "RSVD_31_16",         16,16, "",NULL },  /* 31 : 16 - Reserved */
	{ "FPGA_ID",            12, 4, "",NULL },  /* 15 : 12 - FPGA Identification */
	{ "FEATURE_ID",          8, 4, "",NULL },  /* 11 :  8 - Feature Identification */
    { "PROJECT_ID",          0, 8, "",NULL },  /*  7 :  0 - Project Identification */
    { NULL,                  0, 0, "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_CONTROL
//    Master Control Register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_CONTROL[] =
{
    { "RSVD_31_18",         28,4, "",NULL },   /* 31 : 28 - Reserved */
	{ "Reset_Strap_Enable", 27,1, "",NULL },   /* 27      - *** The definition is wrong here*** */
	{ "LB_Select",          26,1, "",NULL },   /* 26      - Determines whether Local Bus or I2S 6-Ch TBE is allowed to write to DDR2 memory. */
	{ "SD_Select",          25,1, "",NULL },   /* 25      - Determines whether AUXSD or MS-POD TBE is allowed to write to DDR2 memory. */
	{ "HD_Select",          24,1, "",NULL },   /* 24      - Determines whether AUXHD or IEEE1394 TBE is allowed to write to DDR2 memory. */
	{ "AUDIO_MODE",         22,2, "",NULL },   /* 23 : 22 - Determine's which AUDIO TBE is connected to the AHB-Lite Arbiter. */
	{ "PCOMP_ON",           21,1, "",NULL },   /* 21      - Pixel Comparison on/off. */
	{ "Global_PLLENA",      20,1, "",NULL },   /* 20      - Enable bit to drive the Global PLL Enable Pin of fpga */
	{ "IEEE1394_PLL_RST",   19,1, "",NULL },   /* 19      - Reset for the IEEE1394 PLL */
	{ "MSPOD_PLL_RST",      18,1, "",NULL },   /* 18      - Reset for the MS-POD PLL */
    { "AUXSD_PLL_RST",      17,1, "",NULL },   /* 17      - Reset for the AUXSD PLL */
    { "AUXHD_PLL_RST",      16,1, "",NULL },   /* 16      - Reset for the AUXHD PLL */
    { "MDVO_PLL_RST",       15,1, "",NULL },   /* 15      - Reset for the MDVO PLL */
    { "VIDEO_PLL_RST",      14,1, "",NULL },   /* 14      - Reset for the Video PLL */
    { "DDR_PLL_RST",        13,1, "",NULL },   /* 13      - Reset the PLL in the DDR SDRAM Controller */
    { "AUX_VIDEO_RST_N",    12,1, "",NULL },   /* 12      - Reset for AUXHD, AUXSD, MS-POD & IEEE1394 TBE's */
    { "PCOMP_RST_N",        11,1, "",NULL },   /* 11      - Reset for the PCOMP (Pixel Comparison) TBE */
    { "HRESET_N",           10,1, "",NULL },   /* 10      - Reset for all the AHB-Lite bus and Memory Controller TBE's */
    { "AUDIO_RST_N",        9, 1,  "",NULL },  /*  9      - Reset for the all Audio Capture TBE's (2Ch I2S, 6Ch I2S, SPORT, and S/PDIF) */
    { "MDVO_RST_N",         8, 1,  "",NULL },  /*  8      - Reset for the MDVO Capture and Dual Link SDI TBE's */
    { "SPD_SCL_PIN_STAT",   7, 1,  "",NULL },  /*  7      - DIMM SPD I2C Clock Pin Status */
    { "SPD_SDA_PIN_STAT",   6, 1,  "",NULL },  /*  6      - DIMM SPD I2C Data Pin Status */
    { "SPD_SCL_PIN_CTRL",   5, 1,  "",NULL },  /*  5      - DIMM SPD I2C Clock Pin Control */
    { "SPD_SDA_PIN_CTRL",   4, 1,  "",NULL },  /*  4      - DIMM SPD I2C Data Pin Control */
    { "LED3",               3, 1,  "",NULL },  /*  3      - General purpose green LED */
    { "LED2",               2, 1,  "",NULL },  /*  2      - General purpose amber LED */
    { "LED1",               1, 1,  "",NULL },  /*  1      - General purpose red LED */
    { "LED0",               0, 1,  "",NULL },  /*  0      - AVO FPGA configuration */
    { NULL,                 0, 0,  "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_STATUS
//     Master Status Register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_STATUS[] =
{
    { "RSVD_31_9",          9,23, "",NULL },   /* 31 : 9 - Reserved */
    { "DDR_INIT",           8, 1,  "",NULL },  /* 8      - DDR Controller's Initialization Sequence Done Indication. */
    { "IEEE1394_PLL_LOCK",  7, 1,  "",NULL },  /* 7      - IEEE1394 PLL Lock Status */
    { "MSPOD_PLL_LOCK",     6, 1,  "",NULL },  /* 6      - MS-POD PLL Lock Status */
    { "AUXSD_PLL_LOCK",     5, 1,  "",NULL },  /* 5      - AUXSD PLL Lock Status */
    { "AUXHD_PLL_LOCK",     4, 1,  "",NULL },  /* 4      - AUXHD PLL Lock Status */
    { "LB_PLL_LOCK",        3, 1,  "",NULL },  /* 3      - Local Bus PLL Lock Status */
    { "MDVO_PLL_LOCK",      2, 1,  "",NULL },  /* 2      - MDVO PLL Lock Status */
    { "VIDEO_PLL_LOCK",     1, 1,  "",NULL },  /* 1      - Video PLL Lock Status */
    { "DDR_PLL_LOCK",       0, 1,  "",NULL },  /* 0      - DDR Controller's PLL Lock Status */
    { NULL,                 0, 0,  "",NULL }   /* NULL Terminated */
};

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// MDVO Capture TBE Registers
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

//------------------------------------------------------------------------------
// BSR_AVO_MDVO_CONTROL
//     MDVO Capture Interface Unit Control Register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_MDVO_CONTROL[] =
{
    { "Signal_Capture_Mode",          31, 1,  "",NULL },  /*  31       - This capture mode is almost the same as Pre-DAC capture mode. */
	{ "MDVO_mem_agnt_loopctrl_7_0",   23, 8,  "",NULL },  /*  30 : 23  - These bits set the loop count value for the memory agent's buffer. */
	{ "MDVO_mem_agnt_burst_size_4_0", 18, 5,  "",NULL },  /*  22 : 18  - These bits determine the size of the AHB-Lite bus transactions that the memory agent should be configured for. */
	{ "MDVO_mem_agnt_mode_1_0",       16, 2,  "",NULL },  /*  17 : 16  - These bits determine the mode in which the memory agent operates. */
	{ "Ext_fifo_sclk",                15, 1,  "",NULL },  /*  15       - This bit controls the SCLK line to the external fifo.  */
	{ "Ext_fifo_sen_n",               14, 1,  "",NULL },  /*  14       - This bit controls the SEN line to the external fifo.  */
	{ "Ext_fifo_fwft_si",             13, 1,  "",NULL },  /*  13       - This bit controls the dual purpose FWFT_SI pin of the external IDT fifo. */
	{ "Ext_fifo_partial_reset_l",     12, 1,  "",NULL },  /*  12       - This bit control the Partial Reset line for the external IDT fifo. */
	{ "Ext_fifo_master_reset_l",      11, 1,  "",NULL },  /*  11       - This bit control the Master Reset line for the external IDT fifo. */
	{ "Ext_fifo_ld_n",                10, 1,  "",NULL },  /*  10       - LD Control bit to pre-configure the offset register in the external IDT fifo */
	{ "Ext_fifo_fsel1",                9, 1,  "",NULL },  /*   9       - FSEL1 Control bit to pre-configure the offset register in the external IDT fifo */
    { "Ext_fifo_fsel0",                8, 1,  "",NULL },  /*   8       - FSEL0 Control bit to pre-configure the offset register in the external IDT fifo */
    { "PreDAC_Mode",                   7, 1,  "",NULL },  /*   7       - Set the MDVO TBE in a Pre-DAC Mode where HSYNC, VSYNC, and DE also become part of the data. */
    { "Mem_agnt_go",                   6, 1,  "",NULL },  /*   6       - Force the memory agent to empty it's fifo */
    { "Blanking",                      5, 1,  "",NULL },  /*   5       - Capture Blanking info from Gen2 Device */
    { "Mem_Agent_En",                  4, 1,  "",NULL },  /*   4       - Enable for Memory Agent in MDVO Block */
    { "Enable",                        3, 1,  "",NULL },  /*   3       - Video Capture Enable */
    { "Format",                        0, 3,  "",NULL },  /*   2 : 0   - Incoming Picture Format */
    { NULL,                            0, 0,  "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_MDVO_STAT
//     MDVO Capture Interface Unit Status Register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_MDVO_STAT[] =
{
    { "RSVD_31_18",      18,14,  "",NULL },  /*  31 : 18  - Reserved */
	{ "Underrun_flag",   17, 1,  "",NULL },  /*  17       - Under-run condition detected by the memory agent */
	{ "Loop_done",       16, 1,  "",NULL },  /*  16       - Loop completed by the memory agent. */
	{ "MDVO_fifo_usedw",  8, 8,  "",NULL },  /*  15 :  8  - Used word count on the memory agent fifo */
	{ "Start_of_frame",   7, 1,  "",NULL },  /*   7       - Start of first frame indication from the interface block. */
    { "Ext_fifo_paf",     6, 1,  "",NULL },  /*   6       - External fifo programmable almost full flag */
    { "Ext_fifo_pae",     5, 1,  "",NULL },  /*   5       - External fifo programmable almost empty flag */
    { "Ext_fifo_hf",      4, 1,  "",NULL },  /*   4       - External fifo half full flag */
    { "Ext_fifo_ff",      3, 1,  "",NULL },  /*   3       - External fifo full flag */
    { "Ext_fifo_ef",      2, 1,  "",NULL },  /*   2       - External fifo empty flag */
    { "Fifo_overwrite",   1, 1,  "",NULL },  /*   1       - Fifo Over-write Alarm bit for memory agent fifo */
    { "RSVD_0",           0, 1,  "",NULL },  /*   0       - Reserved */
    { NULL,               0, 0,  "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_MDVO_START_ADDR
//     Starting Memory Address for the MDVO Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_MDVO_START_ADDR[] =
{
    { "Start_Pointer", 0,32,  "",NULL },  /*   31 : 0 - This write pointer points to the address of the memory location where the AVO fpga is to start writing incoming active video. */
    { NULL,            0, 0,  "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_MDVO_END_ADDR
//     Ending Memory Address for the MDVO Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_MDVO_END_ADDR[] =
{
    { "End_Pointer", 0,32,  "",NULL },  /*   31 : 0 - This write pointer points to the address of the memory location where the AVO fpga is to End (and wrap around) writing incoming active video. */
    { NULL,          0, 0,  "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_MDVO_WRITE_PTR
//     Write Pointer Register for the MDVO Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_MDVO_WRITE_PTR[] =
{
    { "Write_Pointer", 0,32,  "",NULL },  /*   31 : 0 - This write pointer points to the address of the memory location where incoming active video was last written. */
    { NULL,            0, 0,  "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_MDVO_READ_PTR
//     Read Pointer Register for the MDVO Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_MDVO_READ_PTR[] =
{
    { "Read_Pointer", 0,32,  "",NULL },  /*   31 : 0 - This write pointer points to the address of the memory location where memory agent read pointer is pointing. */
    { NULL,           0, 0,  "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_MDVO_FRAME_COUNTER
//     Frame counter for the MDVO Packing State Machine Block
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_MDVO_FRAME_COUNTER[] =
{
    { "Frame_Counter", 0,32,  "",NULL },  /*   31 : 0 - This counter represents the number of frames received by the MDVO packing state machine block. */
    { NULL,            0, 0,  "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_MDVO_MISC_COUNTER
//------------------------------------------------------------------------------
//     Miscellaneous counters and flags in MDVO Packing State Machine Block
static const struct EAS_RegBits g_csr_AVO_MDVO_MISC_COUNTER[] =
{
	{ "MDVO_Flags",    24, 8,  "",NULL },  /*   31 : 24 - Formatting/de-lineation flags generated in Packing State Machine Block of MDVO TBE */
	{ "RSVD",          23, 1,  "",NULL },  /*   23      - Reserved */
	{ "Line_Counter",  12,11,  "",NULL },  /*   22 : 12 - Line Counter in Packing State Machine Block of MDVO TBE */
    { "Pixel_Counter",  0,12,  "",NULL },  /*   11 :  0 - Pixel Counter in Packing State Machine Block of MDVO TBE */
    { NULL,             0, 0,  "",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_MDVO_ALT_CONTROL
// **** The LLD document needs to be revised ****
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// BSR_AVO_MDVO_DIAG_REGISTER
// **** The LLD document needs to be revised ****
//------------------------------------------------------------------------------

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// AUXSD Capture TBE Registers
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

//------------------------------------------------------------------------------
// BSR_AVO_AUXSD_CONTROL
//   AUXSD Capture Interface Unit Control Register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXSD_CONTROL[] =
{
	{ "RSVD",                          31,1,"",NULL },  /* Reserved */
	{ "AUXSD_mem_agnt_loopctrl_7_0",   23,8,"",NULL },  /* 30 : 23 - These bits set the loop count value for the memory agent's buffer. */
	{ "AUXSD_mem_agnt_burst_size_4_0", 18,5,"",NULL },  /* 22 : 18 - These bits determine the size of the AHB-Lite bus transactions that the memory agent should be configured for. */
    { "AUXSD_mem_agnt_mode_1_0",       16,2,"",NULL },  /* 17 : 16 - These bits determine the mode in which the memory agent operates. */
	{ "RSVD_15_6",                     6,10,"",NULL },  /* 15 : 6 - Reserved */
    { "Blanking",                      5, 1,"",NULL },  /* 5 - Capture Blanking info from Vermilion */
    { "MEM_AGENT_EN",                  4, 1,"",NULL },  /* 4 - Enable for Memory Agent in AUXSD Block */
	{ "Enable",                        3, 1,"",NULL },  /* 3 - AUXSD Enable */
    { "Reserved",                      2, 1,"",NULL },  /* 2 - Reserved */
    { "Reset_Counters",                1, 1,"",NULL },  /* 1 - Reset counters. */
    { "Storage_CRC_mode",              0, 1,"",NULL },  /* 0 - Select the Storage mode or CRC compare mode of operation. */
    { NULL,                            0, 0,"",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXSD_STAT
//   AUXSD Capture Interface Unit Status Register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXSD_STAT[] =
{
	{ "RSVD_31_28",              31,4,"",NULL },   /* 31 : 28 - Reserved */
	{ "CRC_COMP_wusedw",         27,8,"",NULL },   /* 27 : 20 - Used word count on CRC FIFO reading CRC data from memory. */
	{ "RSVD_19_17",              17,3,"",NULL },   /* 19 : 17 - Reserved */
	{ "Loop_done",               16,1,"",NULL },   /* 16 - Loop completed by the memory agent. */
	{ "AUXSD_fifo_usedw",        8, 8,"",NULL },   /* 15 : 8 - Used word count on the memory agent fifo writing video data to memory. */
	{ "Start_of_frame",          7, 1,"",NULL },   /* 7 - Start of first frame indication from the interface block. */
	{ "RSVD_6_3",                3, 4,"",NULL },   /* 6 : 3 - CRC error detected. */
	{ "Pixel_Error",             2, 1,"",NULL },   /* 2 - CRC error detected. */
	{ "Data_out_FIFO_Overwrite", 1, 1,"",NULL },   /* 1 - A FIFO overwrite condition detected writing video data to memory. */
	{ "CRC_in_FIFO_Underrun",    0, 1,"",NULL },   /* 0 - A FIFO under run occurred when reading CRC data from memory. */
	{ NULL,                      0, 0,"",NULL }    /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXSD_START_ADDR
//   Starting Memory Address for the AUXSD Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXSD_START_ADDR[] =
{
	{ "Start_Pointer", 0,32,"",NULL }, /* 31 : 0 - This write pointer points to the address of the memory location where the AVO FPGA is to start writing incoming AUXSD video. */
	{ NULL,            0, 0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXSD_END_ADDR
//   Ending Memory Address for the AUXSD Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXSD_END_ADDR[] =
{
	{ "End_Pointer", 0,32,"",NULL },  /* 31 : 0 - This write pointer points to the address of the memory location where the AVO FPGA is to End (and wrap around) writing incoming AUXSD video. */
	{ NULL,          0, 0,"",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXSD_WRITE_PTR
//   Write Pointer Register for the AUXSD Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXSD_WRITE_PTR[] =
{
	{ "Write_Pointer", 0,32,"",NULL }, /* 31 : 0 - This write pointer points to the address of the memory location where incoming active video was last written. */
	{ NULL,            0, 0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXSD_READ_PTR
//   Read Pointer Register for the AUXSD Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXSD_READ_PTR[] =
{
	{ "Read_Pointer", 0,32,"",NULL }, /* 31 : 0 - This write pointer points to the address of the memory location where the CRC read pointer is pointing. */
	{ NULL,           0, 0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXSD_FIELD_COUNTER
//   Field counter for the AUXSD Block
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXSD_FIELD_COUNTER[] =
{
	{ "Field_Counter", 0,32,"",NULL }, /* 31 : 0 - This counter represents the number of Fields received by the AUXSD block. */
	{ NULL,            0, 0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXSD_MISC_COUNTER
//   Line and Byte counters in AUXSD Block
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXSD_MISC_COUNTER[] =
{
	{ "Line_Counter", 17,16,"",NULL }, /* 31 :16 - Line Counter in Packing State Machine Block of AUXSD TBE */
	{ "Byte_Counter", 0, 16,"",NULL }, /* 15 : 0 - Byte Counter in Packing State Machine Block of AUXSD TBE */
	{ NULL,           0,  0,"",NULL }  /* NULL Terminated */
};

////////////////////////////////////////////////////////////////////////////////
// *****************************************************************************
// ** AUXHD CRC Comparison Unit Registers **
// CRC is not working so far
// *****************************************************************************
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
// AUXHD Capture TBE Registers
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////

//------------------------------------------------------------------------------
//BSR_AVO_AUXHD_CONTROL (Page 100, Section 6.9.1)
//  AUXHD Capture Interface Unit Control Register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_CONTROL[] =
{
	{ "RSVD",                          31,1,"",NULL },  /* Reserved */
	{ "AUXHD_mem_agnt_loopctrl_7_0",   23,8,"",NULL },  /* 30 : 23 - These bits set the loop count value for the memory agent's buffer. */
	{ "AUXHD_mem_agnt_burst_size_4_0", 18,5,"",NULL },  /* 22 : 18 - These bits determine the size of the AHB-Lite bus transactions that the memory agent should be configured for. */
    { "AUXHD_mem_agnt_mode_1_0",       16,2,"",NULL },  /* 17 : 16 - These bits determine the mode in which the memory agent operates. */
	{ "RSVD_15_9",                     9, 7,"",NULL },  /* 15 : 9 - Reserved */
	{ "Ignore_SOF",                    8, 1,"",NULL },  /* 8 - Ignore Start of Frame */
    { "Data_width",                    6, 2,"",NULL },  /* 7 : 6 - Width of the AUXHD data */
    { "Blanking",                      5, 1,"",NULL },  /* 5 - Capture Blanking info from Vermilion */
    { "MEM_AGENT_EN",                  4, 1,"",NULL },  /* 4 - Enable for Memory Agent in AUXHD Block */
	{ "Enable",                        3, 1,"",NULL },  /* 3 - AUXHD Enable */
    { "LAmode",                        2, 1,"",NULL },  /* 2 - Mode : Loop or Streaming Mode */
    { "Reset_Counters",                1, 1,"",NULL },  /* 1 - Reset counters. */
    { "Storage_CRC_mode",              0, 1,"",NULL },  /* 0 - Select the Storage mode or CRC compare mode of operation. */
    { NULL,                            0, 0,"",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_STAT
//   AUXHD Capture Interface Unit Status Register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_STAT[] =
{
	{ "RSVD_31_28",              31,4,"",NULL },   /* 31 : 28 - Reserved */
	{ "CRC_COMP_wusedw",         27,8,"",NULL },   /* 27 : 20 - Used word count on CRC FIFO reading CRC data from memory. */
	{ "RSVD_19_17",              17,3,"",NULL },   /* 19 : 17 - Reserved */
	{ "Loop_done",               16,1,"",NULL },   /* 16 - Loop completed by the memory agent. */
	{ "AUXHD_fifo_usedw",        8, 8,"",NULL },   /* 15 : 8 - Used word count on the memory agent fifo writing video data to memory. */
	{ "Start_of_frame",          7, 1,"",NULL },   /* 7 - Start of first frame indication from the interface block. */
	{ "RSVD_6_3",                3, 4,"",NULL },   /* 6 : 3 - CRC error detected. */
	{ "Pixel_Error",             2, 1,"",NULL },   /* 2 - CRC error detected. */
	{ "Data_out_FIFO_Overwrite", 1, 1,"",NULL },   /* 1 - A FIFO overwrite condition detected writing video data to memory. */
	{ "CRC_in_FIFO_Underrun",    0, 1,"",NULL },   /* 0 - A FIFO under run occurred when reading CRC data from memory. */
	{ NULL,                      0, 0,"",NULL }    /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_START_ADDR
//   Starting Memory Address for the AUXHD Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_START_ADDR[] =
{
	{ "Start_Pointer", 0,32,"",NULL }, /* 31 : 0 - This write pointer points to the address of the memory location where the AVO FPGA is to start writing incoming AUXHD video. */
	{ NULL,            0, 0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_END_ADDR
//   Ending Memory Address for the AUXHD Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_END_ADDR[] =
{
	{ "End_Pointer", 0,32,"",NULL },  /* 31 : 0 - This write pointer points to the address of the memory location where the AVO FPGA is to End (and wrap around) writing incoming AUXHD video. */
	{ NULL,          0, 0,"",NULL }   /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_WRITE_PTR
//   Write Pointer Register for the AUXHD Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_WRITE_PTR[] =
{
	{ "Write_Pointer", 0,32,"",NULL }, /* 31 : 0 - This write pointer points to the address of the memory location where incoming active video was last written. */
	{ NULL,            0, 0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_READ_PTR
//   Read Pointer Register for the AUXHD Memory Agent
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_READ_PTR[] =
{
	{ "Read_Pointer", 0,32,"",NULL }, /* 31 : 0 - This write pointer points to the address of the memory location where the CRC read pointer is pointing. */
	{ NULL,           0, 0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_FIELD_COUNTER
//   Field counter for the AUXHD Block
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_FIELD_COUNTER[] =
{
	{ "Field_Counter", 0,32,"",NULL }, /* 31 : 0 - This counter represents the number of Fields received by the AUXHD block. */
	{ NULL,            0, 0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_MISC_COUNTER
//   Line and Byte counters in AUXHD Block
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_MISC_COUNTER[] =
{
	{ "Line_Counter", 17,16,"",NULL }, /* 31 :16 - Line Counter in Packing State Machine Block of AUXHD TBE */
	{ "Byte_Counter", 0, 16,"",NULL }, /* 15 : 0 - Byte Counter in Packing State Machine Block of AUXHD TBE */
	{ NULL,           0,  0,"",NULL }  /* NULL Terminated */
};

// ** AUXHD CRC Comparison Unit Registers **
// CRC is not working so far

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_HSYNC
//   Hsync timing register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_HSYNC[] =
{
	{ "Hsync_Fall", 17,16,"",NULL }, /* 31 :16 - The number of Y values from the beginning of the scan line to the falling edge of the Hsync signal. */
	{ "Hsync_Rise", 0, 16,"",NULL }, /* 15 : 0 - The number of Y values from the beginning of the scan line to the rising edge of the Hsync signal. */
	{ NULL,         0,  0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_VSYNC_BYTE
//------------------------------------------------------------------------------
//   Vsync byte timing register
static const struct EAS_RegBits g_csr_AVO_AUXHD_VSYNC_BYTE[] =
{
	{ "Vsync_Fall", 17,16,"",NULL }, /* 31 :16 - The number of Y values from the beginning of the scan line to the falling edge of the Vsync signal. */
	{ "Vsync_Rise", 0, 16,"",NULL }, /* 15 : 0 - The number of Y values from the beginning of the scan line to the rising edge of the Vsync signal. */
	{ NULL,         0,  0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_VSYNC_LINE
//   Vsync line timing register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_VSYNC_LINE[] =
{
	{ "Vsync_Fall", 17,16,"",NULL }, /* 31 :16 - The number of lines from the beginning of the field to the falling edge of the Vsync signal. */
	{ "Vsync_Rise", 0, 16,"",NULL }, /* 15 : 0 - The number of lines from the beginning of the scan line to the rising edge of the Vsync signal. */
	{ NULL,         0,  0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_FIELD_BYTE
//   Field byte timing register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_FIELD_BYTE[] =
{
	{ "Field_Fall", 17,16,"",NULL }, /* 31 :16 - The number of Y values from the beginning of the scan line to the falling edge of the Field signal. */
	{ "Field_Rise", 0, 16,"",NULL }, /* 15 : 0 - The number of Y values from the beginning of the scan line to the rising edge of the Field signal. */
	{ NULL,         0,  0,"",NULL }  /* NULL Terminated */
};

//------------------------------------------------------------------------------
// BSR_AVO_AUXHD_FIELD_LINE
//   Field line timing register
//------------------------------------------------------------------------------
static const struct EAS_RegBits g_csr_AVO_AUXHD_FIELD_LINE[] =
{
	{ "Field_Fall", 17,16,"",NULL }, /* 31 :16 - The number of lines from the beginning of the field to the falling edge of the Field signal. */
	{ "Field_Rise", 0, 16,"",NULL }, /* 15 : 0 - The number of lines from the beginning of the scan line to the rising edge of the Field signal. */
	{ NULL,         0,  0,"",NULL }  /* NULL Terminated */
};

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
static const struct EAS_Register g_csr_AVO[] =
{
	{ "VERSION",             0x0000, g_csr_AVO_VERSION,             "AVO Version Register", NULL},
    { "ID",                  0x0004, g_csr_AVO_ID,                  "AVO ID Register", NULL },
	{ "CONTROL",             0x0008, g_csr_AVO_CONTROL,             "Master Control Register", NULL },
	{ "STATUS",              0x000C, g_csr_AVO_STATUS,              "Master Status Register", NULL },

	// MDVO
	{ "MDVO_CONTROL",        0x0000, g_csr_AVO_MDVO_CONTROL,        "MDVO Capture Interface Unit Control Register", NULL },
	{ "MDVO_STAT",           0x0004, g_csr_AVO_MDVO_STAT,           "MDVO Capture Interface Unit Status Register", NULL },
	{ "MDVO_START_ADDR",     0x0008, g_csr_AVO_MDVO_START_ADDR,     "Starting Memory Address for the MDVO Memory Agent", NULL },
	{ "MDVO_END_ADDR",       0x000C, g_csr_AVO_MDVO_END_ADDR,       "Ending Memory Address for the MDVO Memory Agent", NULL },
	{ "MDVO_WRITE_PTR",      0x0010, g_csr_AVO_MDVO_WRITE_PTR,      "Write Pointer Register for the MDVO Memory Agent", NULL },
	{ "MDVO_READ_PTR",       0x0014, g_csr_AVO_MDVO_READ_PTR,       "Read Pointer Register for the MDVO Memory Agent", NULL },
	{ "MDVO_FRAME_COUNTER",  0x0018, g_csr_AVO_MDVO_FRAME_COUNTER,  "Frame counter for the MDVO Packing State Machine Block", NULL },
	{ "MDVO_MISC_COUNTER",   0x001C, g_csr_AVO_MDVO_MISC_COUNTER,   "Miscellaneous counters and flags in MDVO Packing State Machine Block", NULL },

	// AUXSD
    { "AUXSD_CONTROL",       0x0000, g_csr_AVO_AUXSD_CONTROL,       "AUXSD Capture Interface Unit Control Register", NULL },
    { "AUXSD_STAT",          0x0004, g_csr_AVO_AUXSD_STAT,          "AUXSD Capture Interface Unit Status Register", NULL },
    { "AUXSD_START_ADDR",    0x0008, g_csr_AVO_AUXSD_START_ADDR,    "Starting Memory Address for the AUXSD Memory Agent", NULL },
    { "AUXSD_END_ADDR",      0x000C, g_csr_AVO_AUXSD_END_ADDR,      "I2S AVI Buffer End Address", NULL },
    { "AUXSD_WRITE_PTR",     0x0010, g_csr_AVO_AUXSD_WRITE_PTR,     "I2S AVI Buffer Read Pointer", NULL },
    { "AUXSD_READ_PTR",      0x0014, g_csr_AVO_AUXSD_READ_PTR,      "Read Pointer Register for the AUXSD Memory Agent", NULL },
	{ "AUXSD_FIELD_COUNTER", 0x0018, g_csr_AVO_AUXSD_FIELD_COUNTER, "Field counter for the AUXSD Block", NULL },
	{ "AUXSD_MISC_COUNTER",  0x001C, g_csr_AVO_AUXSD_MISC_COUNTER,  "Line and Byte counters in AUXSD Block", NULL },

	// AUXHD
	{ "AUXHD_CONTROL",       0x0000, g_csr_AVO_AUXHD_CONTROL,       "AUXHD Capture Interface Unit Control Register", NULL },
	{ "AUXHD_STAT",          0x0004, g_csr_AVO_AUXHD_STAT,          "AUXHD Capture Interface Unit Status Register", NULL },
	{ "AUXHD_START_ADDR",    0x0008, g_csr_AVO_AUXHD_START_ADDR,    "Starting Memory Address for the AUXHD Memory Agent", NULL },
	{ "AUXHD_END_ADDR",      0x000C, g_csr_AVO_AUXHD_END_ADDR,      "Ending Memory Address for the AUXHD Memory Agent", NULL },
	{ "AUXHD_WRITE_PTR",     0x0010, g_csr_AVO_AUXHD_WRITE_PTR,     "Write Pointer Register for the AUXHD Memory Agent", NULL },
	{ "AUXHD_READ_PTR",      0x0014, g_csr_AVO_AUXHD_READ_PTR,      "Read Pointer Register for the AUXHD Memory Agent", NULL },
	{ "AUXHD_FIELD_COUNTER", 0x0018, g_csr_AVO_AUXHD_FIELD_COUNTER, "Field counter for the AUXHD Block", NULL },
	{ "AUXHD_MISC_COUNTER",  0x001C, g_csr_AVO_AUXHD_MISC_COUNTER,  "Line and Byte counters in AUXHD Block", NULL },
	{ "AUXHD_HSYNC",         0x0038, g_csr_AVO_AUXHD_HSYNC,         "Hsync timing register", NULL },
	{ "AUXHD_VSYNC_BYTE",    0x003C, g_csr_AVO_AUXHD_VSYNC_BYTE,    "Vsync byte timing register", NULL },
	{ "AUXHD_VSYNC_LINE",    0x0040, g_csr_AVO_AUXHD_VSYNC_LINE,    "Vsync line timing register", NULL },
	{ "AUXHD_FIELD_BYTE",    0x0044, g_csr_AVO_AUXHD_FIELD_BYTE,    "Field byte timing register", NULL },
	{ "AUXHD_FIELD_LINE",    0x0048, g_csr_AVO_AUXHD_FIELD_LINE,    "Field line timing register", NULL },

    CSR_NULL_TERM()
};
#endif /* !SVEN_INTERNAL_BUILD */

static const struct SVEN_Module_EventSpecific g_tbe_avo_specific_events[] =
{
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_TBE_AVO_sven_module =
{
    "TBE_AVO",              /*  */
    SVEN_module_TBE_AVO,    /*  */
    0x02000000,             /* BAR SIZE ***** ??? UNKNOWN so far ***** [Commented by Xiaoming Sun] */
#ifdef SVEN_INTERNAL_BUILD
    g_csr_AVO,              /* What is the latest HW version to use? */
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "TBE: AVO Multi-Stream Stimulus Card (mirrored FPGAs)",        /* text string */
    g_tbe_avo_specific_events,  /* TODO-Later: Define important events specific to my module */
    NULL /* extension list */
};
