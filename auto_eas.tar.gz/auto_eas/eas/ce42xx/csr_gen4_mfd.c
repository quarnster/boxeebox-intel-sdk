/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_unit.h"
#endif

#if 0
static const struct EAS_RegBits g_csr_mfd_UPCOMD0 [] = {
  { "LINE_DOUBLE",		25,	1},     /* 0 : No Line duplication     */
  { "PXL_DOUBLE",		24,	1},	/* 0 : No Line duplicatio  */
  { "CONST_ALPHA",	        16,	8}, 	/* Constant Alpha   */
  { "VIDEO_FORMAT",	        10,	5}, 	/* 00000: Pseudo-planar YCbCr 4:2:2 8-bit */
  { "UP_ENBL",	         0,	1}, 	/* Universal plane Enable */
  { NULL }    /* NULL terminator */
};
#endif

static const struct EAS_RegBits g_csr_gen4_mfd_SIF_SOFT_RST[] =
{
	{"RESERVED",					8, 24, "Reserved", NULL },
	{"NOTUSED",						7, 1,  "Notused", NULL },
	{"MINIP_RST",					6, 1,  "Mini-pipeline Software reset", NULL },
	{"MPG4VD_RST",					5, 1,  "MPEG4 software Reset", NULL },
	{"MPG2VD_RST",					4, 1,  "MPEG2 Software reset", NULL },
	{"VC1VD_RST",					3, 1,  "VC1VD Software Reset", NULL },
	{"H264VD_RST",					2, 1,  "H264 Software Reset", NULL },
	{"CP_RST",						1, 1,  "Control Processor Reset", NULL },
	{"PH_RST",						0, 1,  "Peripheral hardware synchronous reset", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_HOST_INT_STAT[] =
{
	{"RESERVED0",					12, 20, "Reserved", NULL },
	{"VC1_SIF_INTR",				11, 1,  "VC1 Slice 0 generated semaphore Interrupt", NULL },
	{"RESERVED1",					10, 1,  "reserved", NULL },
	{"H264_SIF_INTR",				9, 1,   "H264 Slice ) generated semaphore interrupt", NULL },
	{"RESERVED2", 					8, 1,   "reserved", NULL },
	{"GBL_SIF_INTR", 				7, 1,   "Global SIF interrupt", NULL },
	{"DMA_INTR",					6, 1,   "DMA Interrupt", NULL },
	{"CORE_INTR",					5, 1,   "Slice Decoder and Mini- pipeline Interrupt", NULL },
	{"SCD_INTR",					4, 1,   "SCD Interrupt", NULL },
	{"SIF_INTR",					3, 1,   "SIF Interrupt", NULL },
	{"MFD_TIMER1_INTR",				2, 1,   "MFD Timer1 Interrupt", NULL },
	{"MFD_TIMER0_INTR",				1, 1,   "MFD Timer 0 Interrupt", NULL },
	{"RESERVED3",					0, 1,   "Reserved", NULL },

	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_DECODER_SEL[] =
{
	{"RESERVED",					1, 31, "Reserved", NULL },
	{"RSB",							0, 1,  "0=h264 access to RSB. 1=VC1 access to RSB", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_HOST_INT_EN[] =
{
	{"RESERVED0",					12, 20, "Reserved", NULL },
	{"VC1_SIF_INTR_EN",				11, 1,  "VC1 Slice 0 generated semaphore Interrupt Enable", NULL },
	{"RESERVED1",					10, 1,  "reserved", NULL },
	{"H264_SIF_INTR_EN",			9, 1,   "H264 Slice ) generated semaphore interrupt Enable", NULL },
	{"RESERVED2", 					8, 1,   "reserved", NULL },
	{"GBL_SIF_INTR_EN", 			7, 1,   "Global SIF interrupt Enable", NULL },
	{"DMA_INTR_EN",					6, 1,   "DMA Interrupt Enable", NULL },
	{"CORE_INTR_EN",				5, 1,   "Slice Decoder and Mini- pipeline Interrupt Enable", NULL },
	{"SCD_INTR_EN",					4, 1,   "SCD Interrupt Enable", NULL },
	{"SIF_INTR_EN",					3, 1,   "SIF Interrupt Enable", NULL },
	{"MFD_TIMER1_INTR_EN",			2, 1,   "MFD Timer1 Interrupt Enable", NULL },
	{"MFD_TIMER0_INTR_EN",			1, 1,   "MFD Timer 0 Interrupt Enable", NULL },
	{"RESERVED3",					0, 1,   "Reserved", NULL },

	CSR_BB_NULL_TERM()   /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_gen4_mfd_SIF_SYS_PMODE[] =
{
	{"RESERVED",					18, 14, "Reserved", NULL },
	{"FW_RANGE",					15, 3,  "Selects window of addresses to access code RAM", NULL },
	{"RESERVED1",					1, 14,  "Reserved", NULL },
	{"AHB_APB_BRG_MODE"	,			0, 1,   "0=normal operation, 1= debug mode", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VSP_SIF_INT_STATUS[] =
{
	{"RESERVED",					2, 30, "Reserved", NULL },
	{"VC1_SIF_INTR",					1, 1,  "VC1 Slice 0 SIF Interrupt", NULL },
	{"H264_SIF_INTR",				0, 1,  "H264_SIF_Interrupt", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VSP_CORE_INT_STATUS[] =
{
	{"RESERVED0",					6, 26, "Reserved", NULL },
	{"MPEG4_INTR",					5, 1,  "MPEG4VD Interrupt", NULL },
	{"MINIPIPELINE_BSD_INTR",		4, 1,  "Mini-Pipeline BSD Interrupt", NULL },
	{"RESERVED1",					3, 1,  "reserved", NULL },
	{"MPG2_INTR",					2, 1,  "MPEG2 Pipeline Slice Interrupt", NULL },
	{"VC1_SIF_INTR",					1, 1,  "VC1 Slice 0 SIF Interrupt", NULL },
	{"H264_SIF_INTR",				0, 1,  "H264_SIF_Interrupt", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VSP_SCD_INT_STATUS[] =
{
	{"RESERVED0",					6, 26, "Reserved", NULL },
	{"MPEG4_INTR",					5, 1,  "MPEG4VD Interrupt", NULL },
	{"MINIPIPELINE_BSD_INTR",		4, 1,  "Mini-Pipeline BSD Interrupt", NULL },
	{"RESERVED1",					3, 1,  "reserved", NULL },
	{"MPG2_INTR",					2, 1,  "MPEG2 Pipeline Slice Interrupt", NULL },
	{"VC1_SIF_INTR",				1, 1,  "VC1 Slice 0 SIF Interrupt", NULL },
	{"H264_SIF_INTR",				0, 1,  "H264_SIF_Interrupt", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VSP_DMA_INT_STATUS[] =
{
	{"RESERVED0",					6, 26, "Reserved", NULL },
	{"MPEG4_INTR",					5, 1,  "MPEG4VD Interrupt", NULL },
	{"MINIPIPELINE_BSD_INTR",		4, 1,  "Mini-Pipeline BSD Interrupt", NULL },
	{"RESERVED1",					3, 1,  "reserved", NULL },
	{"MPG2_INTR",					2, 1,  "MPEG2 Pipeline Slice Interrupt", NULL },
	{"VC1_SIF_INTR",				1, 1,  "VC1 Slice 0 SIF Interrupt", NULL },
	{"H264_SIF_INTR",				0, 1,  "H264_SIF_Interrupt", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_gen4_mfd_VCMH_FBW[] =
{
	{"RESERVED",					4, 28, 	"Reserved", NULL },
	{"VCMH_FR_BUFFER_WIDTH",		0, 4,   "VCMH Frame Buffer Width", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_MFD_SEC_STATUS[] =
{
	{"AV_BASE_ADDR",				29, 3,  "base address of the 512MB AV window", NULL },
	{"RESERVED0",					25, 4,  "Reserved", NULL },
	{"AV_BASE_ADDR_LCK",			24, 1,  "AV_window has been locked", NULL },
	{"RESERVED1",					2, 22,  "Reserved", NULL },
	{"AGNT_TRSTD",					1, 1,   "Determines if Global VSparc is trusted or not", NULL },
	{"EXEN_ENBL",					0, 1,   "Execution Enable", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_MFD_SEC_THREAT[] =
{
	{"RESERVED",					1, 31,  "Reserved", NULL },
	{"SEC_THREAT",					0, 1,   "Security Threat bit", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_INTC_INT_MSK[] =
{
	{"RESERVED0",					8, 24, "Reserved", NULL },
	{"GBL_SIF_INTR_MSK", 			7, 1,   "Global SIF interrupt Mask", NULL },
	{"DMA_INTR_MSK",				6, 1,   "DMA Interrupt Mask", NULL },
	{"CORE_INTR_MSK",				5, 1,   "Slice Decoder and Mini- pipeline Interrupt Mask", NULL },
	{"SCD_INTR_MSK",				4, 1,   "SCD Interrupt Mask", NULL },
	{"SIF_INTR_MSK",				3, 1,   "SIF Interrupt Mask", NULL },
	{"MFD_TIMER1_INTR_MSK",			2, 1,   "MFD Timer1 Interrupt Mask", NULL },
	{"MFD_TIMER0_INTR_MSK",			1, 1,   "MFD Timer 0 Interrupt Mask", NULL },
	{"RESERVED1",					0, 1,   "Reserved", NULL },

	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_INTC_WR_INT_PEND[] =
{
	{"RESERVED0",					8, 24,  "Reserved", NULL },
	{"GBL_SIF_INTR_PEND", 			7, 1,   "Global SIF interrupt Pending", NULL },
	{"DMA_INTR_PEND",				6, 1,   "DMA Interrupt Pending", NULL },
	{"CORE_INTR_PEND",				5, 1,   "Slice Decoder and Mini- pipeline Interrupt Pending", NULL },
	{"SCD_INTR_PEND",				4, 1,   "SCD Interrupt Pending", NULL },
	{"SIF_INTR_PEND",				3, 1,   "SIF Interrupt Pending", NULL },
	{"MFD_TIMER1_INTR_PEND",		2, 1,   "MFD Timer1 Interrupt Pending", NULL },
	{"MFD_TIMER0_INTR_PEND",		1, 1,   "MFD Timer 0 Interrupt Pending", NULL },
	{"RESERVED1",					0, 1,   "Reserved", NULL },

	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_INTC_INT_FORCE[] =
{
	{"RESERVED0",					8, 24,  "Reserved", NULL },
	{"GBL_SIF_INTR_FORCE", 			7, 1,   "Global SIF interrupt ", NULL },
	{"DMA_INTR_FORCE",				6, 1,   "DMA Interrupt ", NULL },
	{"CORE_INTR_FORCE",				5, 1,   "Slice Decoder and Mini- pipeline Interrupt ", NULL },
	{"SCD_INTR_FORCE",				4, 1,   "SCD Interrupt ", NULL },
	{"SIF_INTR_FORCE",				3, 1,   "SIF Interrupt ", NULL },
	{"MFD_TIMER1_INTR_FORCE",		2, 1,   "MFD Timer1 Interrupt ", NULL },
	{"MFD_TIMER0_INTR_FORCE",		1, 1,   "MFD Timer 0 Interrupt ", NULL },
	{"RESERVED1",					0, 1,   "Reserved", NULL },

	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_INTC_CLR_INT_PEND[] =
{
	{"RESERVED0",					8, 24,  "Reserved", NULL },
	{"GBL_SIF_INTR_PEND", 			7, 1,   "Global SIF interrupt ", NULL },
	{"DMA_INTR_PEND",				6, 1,   "DMA Interrupt ", NULL },
	{"CORE_INTR_PEND",				5, 1,   "Slice Decoder and Mini- pipeline Interrupt ", NULL },
	{"SCD_INTR_PEND",				4, 1,   "SCD Interrupt ", NULL },
	{"SIF_INTR_PEND",				3, 1,   "SIF Interrupt ", NULL },
	{"MFD_TIMER1_INTR_PEND",		2, 1,   "MFD Timer1 Interrupt ", NULL },
	{"MFD_TIMER0_INTR_PEND",		1, 1,   "MFD Timer 0 Interrupt ", NULL },
	{"RESERVED1",					0, 1,   "Reserved", NULL },

	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_TIMER0_VAL[] =
{
	{"RESERVED",					24, 8, 	"Reserved", NULL },
	{"TIMER0_VAL",					0, 24, 	"Timer 0 Value", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_TIMER0_LVAL[] =
{
	{"RESERVED",					24, 8, 	"Reserved", NULL },
	{"TIMER0_LVAL",					0, 24, 	"Timer 0 Load Value", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_TIMER0_CON[] =
{
	{"RESERVED",					3, 29, 	"Reserved", NULL },
	{"TIMER0_IRQ",					2, 1, 	"Timer 0 IRQ", NULL },
	{"TIMER0_RESTART",				1, 1, 	"Timer 0 Restart", NULL },
	{"TIMER0_EN",					0, 1, 	"Timer 0 Enable", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_TIMER1_VAL[] =
{
	{"RESERVED",					24, 8, 	"Reserved", NULL },
	{"TIMER1_VAL",					0, 24, 	"Timer 1 Value", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_TIMER1_LVAL[] =
{
	{"RESERVED",					24, 8, 	"Reserved", NULL },
	{"TIMER1_LVAL",					0, 24, 	"Timer 1 Load Value", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_TIMER1_CON[] =
{
	{"RESERVED",					3, 29, 	"Reserved", NULL },
	{"TIMER1_IRQ",					2, 1, 	"Timer 1 IRQ", NULL },
	{"TIMER1_RESTART",				1, 1, 	"Timer 1 Restart", NULL },
	{"TIMER1_EN",					0, 1, 	"Timer 1 Enable", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_TIMER_SCALER[] =
{
	{"RESERVED",					10, 22, "Reserved", NULL },
	{"TIMER_SCALER_VAL",			0, 10,	"Timer Scaler Value", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_TIMER_PRESET[] =
{
	{"RESERVED",					10, 22, "Reserved", NULL },
	{"TIMER_PRELOAD",				0, 10,	"Timer Scaler Preload Value", NULL },
	CSR_BB_NULL_TERM()
};


static const struct EAS_RegBits g_csr_gen4_mfd_LINEAR_DMA_CONF[] =
{
	{"DATA_ACCESS",					31, 1,  "0=through VCMH, 1=through Hostside", NULL },
	{"LOAD_STORE",					30, 1,  "0= Store Operation 1= Load operation", NULL },
	{"NO_WORDS",					16, 14, "Number of 32 bit words minus 1", NULL },
	{"BASE_ADDR_XFER",				0, 16,  "Base address in vsaprc memory for the transfer", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_LINEAR_DMA_XFER_STAT[] =
{
	{"RESERVED",					1, 31,  "Reserved", NULL },
	{"DO_TRANSFER",					0, 1,   "Set hIgh when Do Transfer Instruction is sent", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SMP_RD[] =
{
	{"SEM_HOST",					16, 16, "Semaphore bits set by host", NULL },
	{"SEM_SD",						0, 16,  "Semaphore bits set by slice decoder via semaphore set register", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_INT_EN_RD[] =
{
	{"SD_INT_EN",					16, 16, "Slice Decoder bits in the Interrupt enable register", NULL },
	{"HOST_INT_MSK",				0, 16,  "Interrupt mask used to generate interrupts for host", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SMP_SET[] =
{
	{"RESERVED",					16, 16,  "Reserved", NULL },
	{"H264_SLICE_SEM",				2, 14,   "H264 Slice Semaphore bits", NULL },
	{"IDR_BIT",						1, 1, 	 "New IDR bit", NULL },
	{"FRAME_BIT",					0, 1, 	 "New Frame bit", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SMP_CLR[] =
{
	{"CLR_HOST_SEM",					16, 16, "Clears the host portion of semaphore register", NULL },
	{"RESERVED",					0, 16,  "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SMP_MASK_SET[] =
{
	{"RESERVED",					16, 16,  "Reserved", NULL },
	{"INTR_MSK_H264",				0, 16,   "Interrupt mask used to generate interrupts for H264 slice", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SMP_MASK_CLR[] =
{
	{"RESERVED",					16, 16,  "Reserved", NULL },
	{"INTR_MSK_H264",				0, 16,   "Interrupt mask used to generate interrupts for H264 slice", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_PIP_CTRL[] =
{
	{"RESERVED",					3, 29, 	"Reserved", NULL },
	{"PIP_TEST",					2, 1,   "Pip_Test", NULL },
	{"PIP_SCALER_MODE",				0, 2,   "Pip_scaler_mode", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_PIP_STAT[] =
{
	{"Reserved",					1, 31, "Reserved", NULL },
	{"PIP_BUSY",					0, 1,  "PIP_busy", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_PIP_TST_CTRL[] =
{
	{"RESERVED",					28, 4, "Reserved", NULL },
	{"PIP_WR_WORDS_PER_ROW",		27, 1, "PIP_wr_words_per_row", NULL },
	{"PIP_WR_NUM_ROWS",				23, 4, "PIP WR Num rows", NULL },
	{"PIP_WR_COL_POS",				15, 8, "PIP WR Col POS", NULL },
	{"PIP_WR_ROW_POS",				4, 11, "PIP WR Row Pos", NULL },
	{"PIP_WR_DATA_TYPE",			2, 2,  "PIP WR data type", NULL },
	{"PIP_WR_FIELD_FRAME",			1, 1,  "PIP WR field frame", NULL },
	{"PIP_WR_GNT",					0, 1,  "PIP WR GNT", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DPN_INIT[] =
{
	{"RESERVED0",					24, 8, "Reserved", NULL },
	{"FR_WIDTH",					16, 8, "Frame width in macroblocks", NULL },
	{"RESERVED1",					8, 8,  "Reserved", NULL },
	{"FR_HEIGHT",					0, 8,  "Frame height in macroblocks", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DPB_FRM_SZ_STAT[] =
{
	{"RESERVED0",					30, 2,  "Reserved", NULL },
	{"FR_STORE_SIZE",				16, 14, "Frame store size in kilobytes", NULL },
	{"RESERVED1",					15, 1,  "Reserved", NULL },
	{"FR_SIZE",						0, 15,  "Frame size in macroblocks", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DPB_FRM_SZ_CTRL[] =
{
	{"RESERVED0",					30, 2,  "Reserved", NULL },
	{"FR_STORE_SIZE",				16, 14, "Frame store size in kilobytes", NULL },
	{"RESERVED1",					15, 1,  "Reserved", NULL },
	{"FR_SIZE",						0, 15,  "Frame size in macroblocks", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DPB_NUMB_OVR[] =
{
	{"RESERVED",					5, 27,  "Reserved", NULL },
	{"DISP_DPB_NUMB",				0, 5,   "Used to read/write to disp_dpb_numb", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DANGLING_FIELD[] =
{
	{"RESERVED",					1, 31,  "Reserved", NULL },
	{"DANGLING_FIELD",				0, 1,   "Dangling Field", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfdH264_0_DISP_TAG[] =
{
	{"RESERVED0",			25, 7, "Reserved", NULL },
	{"OVERFLOW",			24, 1, "Overflow", NULL },
	{"RESERVED1",			21, 3, "Reserved", NULL },
	{"DISP_Q_CNT",			16, 5, "Displayed queue count", NULL },
	{"RESERVED2",			8, 8,  "Reserved", NULL },
	{"NEXT_TAG",			0, 8,  "Next Tag", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DPB_MBI_ADDR_LUT_WR_DATA[] =
{
	{"MBI_LUT_DATA",				6, 26,  "Macroblock Info LUT data", NULL },
	{"RESERVED",					0, 6,   "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DPB_UV_ADDR_LUT_WR_DATA[] =
{
	{"UV_LUT_DATA",					6, 26,  "UV LUT data", NULL },
	{"RESERVED",					0, 6,   "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DPB_Y_ADDR_LUT_WR_DATA[] =
{
	{"Y_LUT_DATA",					6, 26,  "Macroblock Info LUT data", NULL },
	{"RESERVED",					5, 1,   "Reserved", NULL },
	{"LUT_ACCESS_ADDR",				0, 5,   "Address for LUT access", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_CORE_CONFIG[] =
{
	{"MPD_BASE_UNIT_EN",			0, 1, "MPD_BASE_UNIT_ENABLE", NULL },
	{"MPD_DPB_LUT_EN",				1, 1, "MPD_DPB_LUT_ENABLE", NULL },
	{"MPD_DQ_EN",					2, 1, "MPD_DQ_ENABLE", NULL },
	{"MPD_DQ_16",					3, 1, "MPD_DQ_16", NULL },
	{"MPD_BS_SYNC_EN",				4, 1, "MPD_BS_SYNC_ENABLE", NULL },
	{"MPD_USE_FS_EN",				5, 1, "MPD_USE_FS_ENABLE", NULL },
	{"MPD_SIF_METRICS_EN",			6, 1, "MPD_SIF_METRICS_ENABLE", NULL },
	{"MPD_DBF_XOBUF_EN",			7, 1, "MPD_DBF_XOBUF_ENABLE", NULL },
	{"RESERVED",					8, 24, "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SOFT_RST[] =
{
	{"RESERVED",				3, 29, "Reserved", NULL },
	{"DQ_RST",					2, 1, "Reset display queue", NULL },
	{"BSD_IB_RST",				1, 1, "Reset BSD input buffer", NULL },
	{"SDE_RST",					0, 1, "Reset Slice Decode Engine", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_STAT[] =
{
	{"CURRENT_MB_NUM",				16, 16, "Current macroblock number", NULL },
	{"RESERVED",					12, 4, "Reserved", NULL },
	{"DATA_UNDERFLOW",				11, 1, "Data underflow during NAL decoding", NULL },
	{"BS_SI_FLAG",					10, 1, "BS_SI_FLAG enabled", NULL },
	{"BSD_DEC_DATA_ERR",			9, 1, "BSD_DEC_DATA_ERR", NULL },
	{"MPR_ERR",						8, 1, "MPR_ERR", NULL },
	{"PXD_ERR",						7, 1, "PXD_ERR", NULL },
	{"VLC_DEC_ERR",					6, 1, "VLC_DEC_ERR", NULL },
	{"ERR_SDEC",					5, 1, "Error in slice decode", NULL },
	{"FORCE_IP",					4, 1, "Force in progress", NULL },
	{"WTBL_DEC_IP",					3, 1, "weighting table decode", NULL },
	{"FRM_IP",						2, 1, "frame in progress", NULL },
	{"IMG_IP",						1, 1, "image in progress", NULL },
	{"SLICE_IP",					0, 1, "Slice in progress", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_RBSP_CTRL[] =
{
	{"RESERVED",					1, 31, "Reserved", NULL },
	{"DATA_PASS",					0, 1, "Enable/disable data passing from parser to decoder", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_INT_CTRL[] =
{
	{"CORE_EN",					0, 1, "Core Enable bit", NULL },
	{"FR_INTR",					1, 1, "Frame Interrupt bit", NULL },
	{"SLICE_INTR",				2, 1, "Slice Interrupt bit", NULL },
	{"SC_INTR",					3, 1, "Start Code interrupt bit", NULL },
	{"RESERVED0",				4, 3, "Reserved", NULL },
	{"DISP_Q",					7, 1, "Use of display queue for signalling displayed frames", NULL },
	{"RESERVED1",				8, 24, "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_INT_STAT[] =
{
	{"SEM_BIT",						0, 1, "Semaphore Interrupt bit", NULL },
	{"FRM_INT_BIT",					1, 1, "Frame Interrupt bit", NULL },
	{"SLICE_INT_BIT",				2, 1, "Slice Interrupt bit", NULL },
	{"SC_INTR_BIT",					3, 1, "Start Code Interrupt bit", NULL },
	{"RESERVED",					4, 28, "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_IMG_INIT[] =
{
	{"RESERVED",						26, 6, "Reserved", NULL },
	{"MONO_WTBL_DEC_MODE",				25, 1, "monochrome weghting decoding mode", NULL },
	{"SCALING_LST_PRST_8X8_INTER_Y",	24, 1, "scaling list 8x8 inter y", NULL },
	{"SCALING_LST_PRST_8X8_INTRA_Y",	23, 1, "scaling list 8x8 intra y", NULL },
	{"SCALING_LST_PRST_4x4_INTER_V",	22, 1, "scaling list 4x4 inter v", NULL },
	{"SCALING_LST_PRST_4x4_INTER_U",	21, 1, "scaling list 4x4 inter u", NULL },
	{"SCALING_LST_PRST_4x4_INTER_Y",	20, 1, "scaling list 4x4 inter y", NULL },
	{"SCALING_LST_PRST_4x4_INTRA_V",	19, 1, "scaling list 4x4 intra v", NULL },
	{"SCALING_LST_PRST_4x4_INTRA_U",	18, 1, "scaling list 4x4 intra u", NULL },
	{"SCALING_LST_PRST_4x4_INTRA_Y",	17, 1, "scaling list 4x4 intra y", NULL },
	{"SCALING_MAT_FLAG",				16, 1, "Scaling matrix present flag", NULL },
	{"RECPOINT_SEI",					15, 1, "Recovery point sei message", NULL },
	{"IMG_MONO_FLAG",					14, 1, "Image monochrome flag", NULL },
	{"TRANSFORM_8x8_FLAG",				13, 1, "Transform 8x8 mode flag", NULL },
	{"FRM_STORE_ID",					8, 5, "Frame store id", NULL },
	{"DIRECT_8x8_INF_FLAG",				7, 1, "Direct 8x8 inference flag", NULL },
	{"FRM_MB_FLAG",						6, 1, "Frame MBs only flag", NULL },
	{"CONSTRAINED_IP",					5, 1, "constarined intra prediction", NULL },
	{"EC_MODE_FLAG",					4, 1, "entropy coding mode flag", NULL },
	{"MB_AFR_FLAG",						3, 1, "Macroblock adaptive frame field decoding", NULL },
	{"IMG_IDR_FLAG",					2, 1, "Image IDR flag", NULL },
	{"PIC_STRUCT",						0, 2, "Picture structure", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_SLICE_P1[] =
{
	{"RESERVED2",					23, 9, "Reserved", NULL },
	{"MB_SKIP",						22, 1, "MB skipped", NULL },
	{"NUMREF1",						16, 6, "Number of references in list 1", NULL },
	{"RESERVED1",					14, 2, "Reserved", NULL },
	{"NUMREF0",						8, 6, "Number of reference indices in list 0", NULL },
	{"RESERVED0",					7, 1, "Reserved", NULL },
	{"WT_PRD_FLAG",					6, 1, "Weighted prediction flag", NULL },
	{"WT_BIPRED_IDC",				4, 2, "Weighted Bi-prediction IDC", NULL },
	{"SLICETYPE",					1, 3, "Slice type of picture", NULL },
	{"DISP_FLAG",					0, 1, "Disposable flag", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_SLICE_P2[] =
{
	{"RESERVED",					24, 8, "Reserved", NULL },
	{"CHROMA_TYPE",					19, 5, "Chroma qp offset bits", NULL },
	{"B_TYPE",						18, 1, "B picture type", NULL },
	{"BETA_OFFSET",					14, 4, "beta offset ", NULL },
	{"ALPHA_C0_OFFSET",				10, 4, "alpha c0 offset", NULL },
	{"DEBLK_FILTER_IDC_DIS",		8, 2, "disable deblocking filter idc", NULL },
	{"CURRSLICE_QP",				2, 6, "current slice quantisation parameter", NULL },
	{"CABAC_INIT_IDC",				0, 2, "cabac init idc", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_SLICE_START[] =
{
	{"NUM_MB_REWIND",				28, 4, "Number of macroblocks to rewind", NULL },
	{"RESERVED",					23, 5, "Reserved", NULL },
	{"CONCEALMENT_METHOD",			22, 1, "Type of concealment method to be used", NULL },
	{"CONCEALMENT_PIC_FIELD",		21, 1, "Type of concealment method to be used", NULL },
	{"CONCEALMENT_PIC",				16, 5, "Conceament picture", NULL },
	{"NUM_FIRST_MB",				0, 16, "Number of first macroblock", NULL }, 					//Fix this
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_MB_CTRL[] =
{
	{"RESERVED",					31, 1, "Reserved", NULL },
	{"LOAD_MB_YPOS",				24, 7, "Load MB Y position", NULL },
	{"LOAD_MB_XPOS",				16, 8, "load MB X position", NULL },
	{"LOAD_MB_ADDR",				0, 16, "Load Macroblock address", NULL },												//fix this
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_QM_DEC_START[] =
{
	{"RESERVED",			3, 29, "Reserved", NULL },
	{"IDC",					0, 3, "IDC of quantization matrix", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_DEC_START[] =
{
	{"RESERVED",					22, 10, "Reserved", NULL },
	{"DEBLCK_FILTER_RDY",			21, 1, "Deblocking filter ready", NULL },
	{"IP_RDY",						20, 1, "inter prediction ready", NULL },
	{"PIXEL_DEC_RDY",				19, 1, "Pixel dcoder ready", NULL },
	{"BO_BUFF_RDY",					18, 1, "Bits out buffer ready", NULL },
	{"CURR_ST_SD",					3, 15, "current state of slice decoder", NULL },
	{"QT_DEC_STAT",					0, 3, "Quantization table decoidng status", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_QM_LOAD_START[] =
{
	{"RESERVED",			4, 28, "Reserved", NULL },
	{"VALUES",				3, 1, "No values will follow if 1", NULL },
	{"IDC",					0, 3, "IDC of quantization matrix", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_RSB_DDR_BA[] =
{
	{"MFD_RSB_ADDR",				3, 29, "MFD RSB address", NULL },
	{"Reserved",					0, 3, "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DEC_STATUS[] =
{
	{"RESERVED",					2, 30, "Reserved", NULL },
	{"BS_IB_EMPTY_H264",			1, 1, "bs_ib_empty_h264", NULL },
	{"H264_FR_ACTIVE",				0, 1, "H264_frame_dec_active", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SIF_SMP_RS[] =
{
	{"SEM_SD",				16, 16, "Semaphore bits set by slice decoder", NULL },
	{"SEM_HOST",			0, 16, "SEmaphore bits set by Host", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SIF_MASK_RS[] =
{
	{"SEM_SD",				16, 16, "Semaphore Mask bits set by slice decoder", NULL },
	{"SEM_HOST",			0, 16, "SEmaphore Mask bits set by Host", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SIF_SMP_RC[] =
{
	{"SEM_SD",				16, 16, "Semaphore bits set by slice decoder", NULL },
	{"SEM_HOST",			0, 16, "SEmaphore bits set by Host", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SIF_MASK_RC[] =
{
	{"SEM_SD",				16, 16, "Semaphore Mask bits set by slice decoder", NULL },
	{"SEM_HOST",			0, 16, "SEmaphore Mask bits set by Host", NULL },
	CSR_BB_NULL_TERM()
};


static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SED[] =
{
	{"RESERVED",				3, 29, "Reserved", NULL },
	{"BYTESWAP_DBG",			2, 1, "Byte swap debug", NULL },
	{"BYTESWAP",				1, 1, "Byte swap stream data", NULL },
	{"STREAM_EN",				0, 1, "Stream enable", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_SDEMC[] =
{
	{"RESERVED",				10, 22, "reserved", NULL },
	{"STREAMDMA_DBG",			9, 1, "stream dma debug checksum adder", NULL },
	{"STREAMDMA_IDLE",			8, 1, "stream dma idle", NULL },
	{"STREAMDMA_LL_PAUSE",		7, 1, "stream dma linked list pause mode", NULL },
	{"STREAMDMA_LINEAR_FETCH",	6, 1, "stream dma linear fetch mode", NULL },
	{"STREAMDMA_PAUSE",			5, 1, "stream dma pause/resume mode", NULL },
	{"STREAMDMA_MAXBURST",		4, 1, "stream dma maximum burst", NULL },
	{"STREAMDMA_LL",			3, 1, "stream dma linked list mode", NULL },
	{"STREAMDMA_CB_EMPTY",		2, 1, "stream dma circular buffer empty", NULL },
	{"STREAMDMA_FLUSH",			1, 1, "stream dma fifo flush", NULL },
	{"STREAMDMA_START",			0, 1, "stream dma start", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DMA_WDT[] =
{
	{"WDT_EN",				31, 1, "watch dog timer enable", NULL },
	{"RESERVED",			24, 7, "reserved", NULL },
	{"WDT_VALUE",			0, 24, "watch dog timer time out value", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DMA_SDLINK[] =
{
	{"LINK_ADDR",				5, 27, "Link Address", NULL },
	{"RESERVED",				0, 5, "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DMA_SDLNDA[] =
{
	{"NEXT_DESC_ADDR",				5, 27, "Next Descriptor Address", NULL },
	{"RESERVED",					0, 5, "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DMA_SDLDC[] =
{
	{"TERM",				32, 1, "Term", NULL },
	{"INTR",				31, 1, "Intr", NULL },
	{"RESERVED",			0, 30, "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DMA_FIFO_STAT[] =
{
	{"RESERVED",				13, 19, "Reserved", NULL },
	{"NUM_BYTES",				3, 10, "Number of bytes", NULL },
	{"SCD_STALL",				2, 1, "SCD stall", NULL },
	{"SYNC_FIFO_EMPTY",			1, 1, "synchronous FIFO empty", NULL },
	{"ASYNC_FIFO_EMPTY",		0, 1, "asynchronous FIFO empty", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DMA_INT_EN[] =
{
	{"RESERVED",		6, 26, "Reserved", NULL },
	{"CD_CNTR_EMPTY",	5, 1, "DMA Cd counter empty interrupt", NULL },
	{"EMPTY",			4, 1, "DMA empty interrupt", NULL },
	{"CB",				3, 1, "DMA circular buffer empty interrupt", NULL },
	{"LL",				2, 1, "DMA linkedlist interrupt", NULL },
	{"WDT",				1, 1, "Watch dog timer interrupt", NULL },
	{"LINEAR_EMPTY",	0, 1, "Linear Buffer empty interrupt", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_DMA_INT_STAT[] =
{
	{"RESERVED",		6, 26, "Reserved", NULL },
	{"CD_CNTR_EMPTY",	5, 1, "DMA Cd counter empty interrupt", NULL },
	{"EMPTY",			4, 1, "DMA empty interrupt", NULL },
	{"CB",				3, 1, "DMA circular buffer empty interrupt", NULL },
	{"LL",				2, 1, "DMA linkedlist interrupt", NULL },
	{"WDT",				1, 1, "Watch dog timer interrupt", NULL },
	{"LINEAR_EMPTY",	0, 1, "Linear Buffer empty interrupt", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_CD_CNTR[] =
{
	{"CD_EN",			31, 1, "CD enable", NULL },
	{"RESERVED",		20, 11, "Reserved", NULL },
	{"CD_CNTR",			0, 20, "CD counter", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_GUE_DEC[] =
{
	{"RESERVED",		1, 31, "Reserved", NULL },
	{"READ",			0, 1, "0: goulomb decoded value in BSD 1: still not decoded", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_GSE_DEC[] =
{
	{"RESERVED",		1, 31, "Reserved", NULL },
	{"READ",			0, 1, "0: goulomb decoded value in BSD 1: still not decoded", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_EXP_GME_INTRA[] =
{
	{"RESERVED",		1, 31, "Reserved", NULL },
	{"READ",			0, 1, "0: goulomb decoded value in BSD 1: still not decoded", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_EXP_GME_INTER[] =
{
	{"RESERVED",		1, 31, "Reserved", NULL },
	{"READ",			0, 1, "0: goulomb decoded value in BSD 1: still not decoded", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_BBB_STAT[] =
{
	{"RESERVED2",		25, 7, "Reserved", NULL },
	{"DATA_UNDERFLOW_NAL",	24, 1, "Data underflow under NAL decoding", NULL },
	{"RESERVED1",		17, 7, "Reserved", NULL },
	{"BITS_ENDED",		16, 1, "Bits ended", NULL },
	{"RESERVED0",		6, 10, "Reserved", NULL },
	{"NUM_BITS_BBB", 	0, 6, "Number of bits in BBB", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_H264_0_BSD_GET_BITS[] =
{
	{"VALID",			31, 1, "Valid", NULL },
	{"RETURNED_BITS",	0, 31, "Returned Bits", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_SCD_XCR[] =
{
	{"SCDFWEN",			   24, 1, "SCD FW Mode Enable", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_SCD_FWCTRL[] =
{
	{"GET_BYTE",			31, 1, "initiate single byte pop pf pipeline registers", NULL },
	{"PYLD_REL",			30, 1, "Release payload bytes", NULL },
	{"PIPE_DFLUSH",			29, 1, "Flush captured SC", NULL },
	{"RESERVED2",			28, 1, "Reserved", NULL },
	{"RESERVED1",			18, 10, "Reserved", NULL },
	{"STREAM_MSK",			17, 1, "mask byte stream data to the decoder", NULL },
	{"SC_DET_ALL",			16, 1, "SCD detects all start codes", NULL },
	{"RESERVED0",			0, 16, "Reserved", NULL },
	CSR_BB_NULL_TERM()
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_STREAM_FORMAT_1[] =
{
   {"PROFILE",                                          0,  2,  "", NULL },
   {"LEVEL",                                            2,  3,  "", NULL },
   {"CHROMAFORMAT",                                     5,  2,  "", NULL },
   {"FRMRTQ",                                           7,  3,  "", NULL },
   {"BITRTQ",                                          10,  5,  "", NULL },
   {"POSTPRO",                                         15,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_CODED_SIZE[] =
{
   {"WIDTH",                                              16, 12,  "", NULL },
   {"HEIGHT",                                              0, 12,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_STREAM_FORMAT_2[] =
{
   {"PSF",                                                 4,  1,  "", NULL },
   {"FINTERPFLAG",                                         3,  1,  "", NULL },
   {"TFCNTRFLAG",                                          2,  1,  "", NULL },
   {"INTERLACE",                                           1,  1,  "", NULL },
   {"PULLDOWN",                                            0,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_ENTRY_POINT_1[] =
{
   {"EXTENDED_DMV",                                       13,  1,  "", NULL },
   {"QUANTIZER",                                          11,  2,  "", NULL },
   {"OVERLAP",                                            10,  1,  "", NULL },
   {"VS_TRANSFORM",                                        9,  1,  "", NULL },
   {"DQUANT",                                              7,  2,  "", NULL },
   {"EXTENDED_MV",                                         6,  1,  "", NULL },
   {"FASTUVMC",                                            5,  1,  "", NULL },
   {"LOOPFILTER",                                          4,  1,  "", NULL },
   {"REFDIST_FLAG",                                        3,  1,  "", NULL },
   {"PANSCAN_FLAG",                                        2,  1,  "", NULL },
   {"CLOSED_ENTRY",                                        1,  1,  "", NULL },
   {"BROKEN_LINK",                                         0,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_RANGE_MAP[] =
{
   {"RANGE_MAP_UV",                                        5,  3,  "", NULL },
   {"RANGE_MAP_UV_FLAG",                                   4,  1,  "", NULL },
   {"RANGE_MAP_Y",                                         1,  3,  "", NULL },
   {"RANGE_MAP_Y_FLAG",                                    0,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_FRAME_TYPE[] =
{
   {"PTYPE",                                               2,  4,  "", NULL },
   {"FCM",                                                 0,  2,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_RECON_CONTROL[] =
{
   {"RNDCTRL",                                             0,  1,  "", NULL },
   {"UVSAMP",                                              1,  1,  "", NULL },
   {"PQUANT",                                              3,  5,  "", NULL },
   {"HALFQP",                                              8,  1,  "", NULL },
   {"UNIFORM_QNT",                                         9,  1,  "", NULL },
   {"POSTPROC",                                           10,  2,  "", NULL },
   {"CONDOVER",                                           12,  2,  "", NULL },
   {"PQINDEX_LE8",                                        14,  1,  "", NULL },
   {"RANGE_REF_RED_TYPE",                                 15,  1,  "", NULL },
   {"RANGE_REF_RED_EN",                                   16,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_MOTION_VECTOR_CONTROL[] =
{
   {"MVRANGE",                                             0,  2,  "", NULL },
   {"MVMODE",                                              2,  3,  "", NULL },
   {"MVTAB",                                              17,  3,  "", NULL },
   {"DMVRANGE",                                           20,  2,  "", NULL },
   {"MV4SWITCH",                                          22,  1,  "", NULL },
   {"MBMODETAB",                                          24,  3,  "", NULL },
   {"NUMREF",                                             27,  1,  "", NULL },
   {"REFFIELD",                                           28,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_INTENSITY_COMPENSATION[] =
{
   {"INT_COMP_1",                                          0,  1,  "", NULL },
   {"LUMA_SCALE_1",                                        1,  6,  "", NULL },
   {"LUMA_SHIFT_1",                                        7,  6,  "", NULL },
   {"INT_COMP_2",                                         13,  1,  "", NULL },
   {"LUMA_SCALE_2",                                       14,  6,  "", NULL },
   {"LUMA_SHIFT_2",                                       20,  6,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_REFERENCE_B_FRACTION[] =
{
   {"BFRACTION_DEN",                                       0,  4,  "", NULL },
   {"BFRACTION_NUM",                                       4,  4,  "", NULL },
   {"REFDIST",                                             8,  4,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_BLOCK_CONTROL[] =
{
   {"CBPTAB",                                              0,  3,  "", NULL },
   {"TTMFB",                                               3,  1,  "", NULL },
   {"TTFRM",                                               4,  2,  "", NULL },
   {"MV2BPTAB",                                            6,  2,  "", NULL },
   {"MV4BPTAB",                                            8,  2,  "", NULL },
   {"INITIAL_MV_Y",                                       10,  7,  "", NULL },
   {"BP_RAW_ID2",                                         17,  1,  "", NULL },
   {"BP_RAW_ID1",                                         18,  1,  "", NULL },
   {"BP_RAW_ID0",                                         19,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_TRANSFORM_DATA[] =
{
   {"TRANSACFRM",                                          0,  2,  "", NULL },
   {"TRANSACFRM2",                                         2,  2,  "", NULL },
   {"TRANSDCTAB",                                          4,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_VOP_DEQUANT[] =
{
   {"PQUANT_ALT",                                          0,  5,  "", NULL },
   {"DQUANTFRM",                                           5,  1,  "", NULL },
   {"DQPROFILE",                                           6,  2,  "", NULL },
   {"DQES",                                                8,  2,  "", NULL },
   {"DQBILEVEL",                                          10,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_CURR_FRAME_ID[] =
{
   {"FBID",                                                0,  5,  "", NULL },
   {"FCM",                                                30,  2,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_FIELD_REF_FRAME_ID[] =
{
   {"TOP_FIELD",                                           0,  1,  "", NULL },
   {"SECOND_FIELD",                                        1,  1,  "", NULL },
   {"ANCHOR",                                              2,  1,  "", NULL },
   {"CUR_REF",                                             3,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_IMAGE_STRUCTURE[] =
{
   {"IMG_STRUC",                                           0,  2,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_ALT_FRAME_TYPE[] =
{
   {"FCM",                                                 0,  2,  "", NULL },
   {"PTYPE",                                               2,  4,  "", NULL },
   {"PQUANT",                                              6,  5,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_INT_COMP_FWD_BOT[] =
{
   {"INT_COMP_1",                                          0,  1,  "", NULL },
   {"LUMA_SCALE_1",                                        1,  6,  "", NULL },
   {"LUMA_SHIFT_1",                                        7,  6,  "", NULL },
   {"INT_COMP_2",                                         13,  1,  "", NULL },
   {"LUMA_SCALE_2",                                       14,  6,  "", NULL },
   {"LUMA_SHIFT_2",                                       20,  6,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_INT_COMP_BWD_TOP[] =
{
   {"INT_COMP_1",                                          0,  1,  "", NULL },
   {"LUMA_SCALE_1",                                        1,  6,  "", NULL },
   {"LUMA_SHIFT_1",                                        7,  6,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_SEQPIC_INT_COMP_BWD_BOT[] =
{
   {"INT_COMP_1",                                          0,  1,  "", NULL },
   {"LUMA_SCALE_1",                                        1,  6,  "", NULL },
   {"LUMA_SHIFT_1",                                        7,  6,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_BP_CONTROL_STATUS[] =
{
   {"BPP_START",                                           0,  1,  "", NULL },
   {"RDBACK_MODE",                                        10,  1,  "", NULL },
   {"EXIT_RDBACK",                                        11,  1,  "", NULL },
   {"ACT_BUF",                                            12,  2,  "", NULL },
   {"IDLE",                                               30,  1,  "", NULL },
   {"ENDIAN",                                             31,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_BP_DATA_IN_POSITION_N_SIZE[] =
{
   {"MB_PER_ROW",                                          0,  6,  "", NULL },
   {"COL_POS",                                             8,  2,  "", NULL },
   {"ROW_POS",                                            16,  7,  "", NULL },
   {"FULL_WORD",                                          30,  1,  "", NULL },
   {"BITBUILD",                                           31,  1,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_mfd_VC1_0_MBDEC_STATUS[] =
{
   {"DONE",                                                0,  1,  "", NULL },
   {"MB_ERROR",                                            1,  1,  "", NULL },
   {"BE_PIC_DONE",                                         2,  1,  "", NULL },
   {"BE_ROW_DONE",                                         3,  1,  "", NULL },
   {"MBX",                                                 8,  8,  "", NULL },
   {"MBY",                                                16,  8,  "", NULL },
   {"MBDSTATE",                                           24,  8,  "", NULL },
   CSR_BB_NULL_TERM()   /* NULL Terminated */
};



static const struct EAS_Register g_csr_gen4_mfd_sv[]= {
  /* Top level register map */
  {"SIF_HW_ID",                        0x00000, NULL, "MFD SIF HW ID",           NULL},
  {"SIF_FW_ID",                        0x00004, NULL, "MFD SIF FW ID",           NULL},
  {"SIF_SOFT_RST",                     0x00008, g_csr_gen4_mfd_SIF_SOFT_RST, "MFD SIF SOFT RST",        NULL},
  {"HOST_INT_STAT",                    0x0000C, g_csr_gen4_mfd_HOST_INT_STAT, "MFD HOST INT STAT",       NULL},
  {"DECODER_SEL",                      0x00010, g_csr_gen4_mfd_DECODER_SEL, "MFD DECODER SEL",         NULL},
  {"HOST_INT_EN",                      0x00014, g_csr_gen4_mfd_HOST_INT_EN, "MFD HOST INT EN",         NULL},
  {"SIF_SYS_PMODE",                    0x00018, g_csr_gen4_mfd_SIF_SYS_PMODE, "MFD SIF SYS PMODE",       NULL},
  {"SIF_HOST_SMP_SET",                 0x0001C, NULL, "MFD SIF HOST SMP SET",    NULL},
  {"SIF_HOST_SMP_MASK",                0x00020, NULL, "MFD SIF HOST SMP MASK",   NULL},
  {"SIF_CORE_SMP_SET",                 0x00024, NULL, "MFD SIF CORE SMP SET",    NULL},
  {"SIF_CORE_SMP_MASK",                0x00028, NULL, "MFD SIF CORE SMP MASK",   NULL},
  {"SIF_HOST_SMP_DATA",                0x0002C, NULL, "MFD SIF HOST SMP DATA",   NULL},
  {"SIF_CORE_SMP_DATA",                0x00030, NULL, "MFD SIF CORE SMP DATA",   NULL},
  {"VSPARC_SIF_INT_STATUS",            0x00034, g_csr_gen4_mfd_VSP_SIF_INT_STATUS, "MFD VSPARC SIF INT STAT", NULL},
  {"VSPARC_CORE_INT_STATUS",           0x00038, g_csr_gen4_mfd_VSP_CORE_INT_STATUS, "MFD VSPARC CORE INT STA", NULL},
  {"VSPARC_SCD_INT_STATUS",            0x0003c, g_csr_gen4_mfd_VSP_SCD_INT_STATUS, "MFD VSPARC SCD INT STAT", NULL},
  {"VSPARC_DMA_INT_STATUS",            0x00040, g_csr_gen4_mfd_VSP_DMA_INT_STATUS, "MFD VSPARC DMA INT STAT", NULL},
  /* The following register no longer exists in RTL */
  /* {"OMAR_CONTROL",                     0x00044, NULL, "MFD OMAR CONTROL       ", NULL},  */
  {"VCMH_FBW",                         0x00048, g_csr_gen4_mfd_VCMH_FBW, "MFD VCMH FBW",            NULL},
  {"OMAR_FW_STATUS",                   0x0004c, NULL, "MFD OMAR FW STATUS",      NULL},
  {"OMAR_FW_DATA",                     0x00050, NULL, "MFD OMAR FW DATA",        NULL},

  /*  Security Registers */
  {"SEC_STATUS",					   0x00054, g_csr_gen4_gv_MFD_SEC_STATUS, "MFD SEC STATUS",		NULL},
  {"SEC_THREAT",					   0x00058, g_csr_gen4_gv_MFD_SEC_THREAT, "MFD SEC THREAT",		NULL},

  /* Interrupt controller register */
  {"INTC_INT_MASK",                    0x00200, g_csr_gen4_mfd_INTC_INT_MSK, "MFD INIC INT MASK",       NULL},
  {"INTC_INT_PEND",                    0x00204, g_csr_gen4_mfd_INTC_WR_INT_PEND, "MFD INTC INT PEND",       NULL},
  {"INTC_INT_FORCE",                   0x00208, g_csr_gen4_mfd_INTC_INT_FORCE, "MFD INTC INT FORCE",      NULL},
  {"INTC_CLR_INT_PEND",                0x0020C, g_csr_gen4_mfd_INTC_CLR_INT_PEND, "MFD INTC CLR INT PEND",   NULL},

  /* Timer register map */
  {"TIMER0_VAL",                       0x00400, g_csr_gen4_mfd_TIMER0_VAL, "MFD TIMER0 VAL",          NULL},
  {"TIMER0_LOAD",                      0x00404, g_csr_gen4_mfd_TIMER0_LVAL, "MFD TIMER0 LOAD",         NULL},
  {"TIMER0_CTRL",                      0x00408, g_csr_gen4_mfd_TIMER0_CON, "MFD TIMER0 CTRL",         NULL},
  /* NOTE: 0x0040C is not used. */
  {"TIMER1_VAL",                       0x00410, g_csr_gen4_mfd_TIMER1_VAL, "MFD TIMER1 VAL",          NULL},
  {"TIMER1_LOAD",                      0x00414, g_csr_gen4_mfd_TIMER1_LVAL, "MFD TIMER1 LOAD",         NULL},
  {"TIMER1_CTRL",                      0x00418, g_csr_gen4_mfd_TIMER1_CON, "MFD TIMER1 CTRL",         NULL},
  {"TIMER_SCALER",                     0x00420, g_csr_gen4_mfd_TIMER_SCALER, "MFD TIMER SCALER",        NULL},
  {"TIMER_PRESET",                     0x00424, g_csr_gen4_mfd_TIMER_PRESET, "MFD TIMER PRESET",        NULL},

  /* Linear DMA */
  {"LINEAR_DMA_EMA",                   0x00A00, NULL, "MFD LINEAR DMA EMA",             NULL},
  {"LINEAR_DMA_CONF",                  0x00A04, g_csr_gen4_mfd_LINEAR_DMA_CONF, "MFD LINEAR DMA CONF",            NULL},
  {"LINEAR_DMA_DO_XFER",               0x00A08, NULL, "MFD LINEAR DMA DO XFER",         NULL},
  {"LINEAR_DMA_XFER_STAT",             0x00A0C, g_csr_gen4_mfd_LINEAR_DMA_XFER_STAT, "MFD LINEAR DMA XFER STA",        NULL},

  /* DQM
  {"DQM_ODPQ_CS",                      0x00B5C, NULL, "MFD DQM ODPQ CS",                NULL},
  {"DQM_ODPQ_DATA_OFFSET",             0x00B60, NULL, "MFD DQM ODPQ DATA OFFSE",        NULL},
  {"DQM_ODPQ_CUSTOM_DATA",             0x00B64, NULL, "MFD DQM ODPQ CUSTOM DAT",        NULL},
  {"DQM_ODPQ_RETURN",                  0x00B68, NULL, "MFD DQM ODPQ RETURN",            NULL},
  {"DQM_DSPLY_FREED_CNT_WTRMRK",       0x00B6C, NULL, "MFD DQM DSPLY FREED CNT WTRMRK", NULL},*/


  /* H264 #0  (CS7051) 0x1000 to 0x1FFF  */
  {"H264_0_SMP_RD",                    0x01000, g_csr_gen4_mfd_H264_0_SMP_RD, "MFD H264 0 SMP RD",            NULL},
  {"H264_0_INT_EN_RD",                 0x01004, g_csr_gen4_mfd_H264_0_INT_EN_RD, "MFD H264 0 INT EN RD",         NULL},
  {"H264_0_SMP_SET",                   0x01008, g_csr_gen4_mfd_H264_0_SMP_SET, "MFD H264 0 SMP SET",           NULL},
  {"H264_0_SMP_CLR",                   0x0100C, g_csr_gen4_mfd_H264_0_SMP_CLR, "MFD H264 0 SMP CLR",           NULL},
  {"H264_0_SMP_MSK_SET",               0x01010, g_csr_gen4_mfd_H264_0_SMP_MASK_SET, "MFD H264 0 SMP MSK SET",       NULL},
  {"H264_0_SMP_MSK_CLR",               0x01014, g_csr_gen4_mfd_H264_0_SMP_MASK_CLR, "MFD H264 0 SMP MSK CLR",       NULL},
  {"H264_0_HDAT",                      0x01018, NULL, "MFD H264 0 HDAT",              NULL},
  {"H264_0_SDDAT",                     0x0101C, NULL, "MFD H264 0 SDDAT",             NULL},
  {"H264_0_DQ_PUSH",                   0x01020, NULL, "MFD H264 0 DQ PUSH",           NULL},
  {"H264_0_DQ_STAT",                   0x01024, NULL, "MFD H264 0 DQ STAT",           NULL},
  {"H264_0_DPB_INIT",                  0x01040, g_csr_gen4_mfd_H264_0_DPN_INIT, "MFD H264 0 DPB INIT",          NULL},
  {"H264_0_DPB_FRM_SZ_STAT",           0x01044, g_csr_gen4_mfd_H264_0_DPB_FRM_SZ_STAT, "MFD H264 0 DPB FRM SZ STAT",   NULL},
  {"H264_0_DPB_FRM_SZ_CTRL",           0x01048, g_csr_gen4_mfd_H264_0_DPB_FRM_SZ_CTRL, "MFD H264 0 DPB FRM SZ CTRL",   NULL},
  {"H264_0_DPB_NUMB_OVR",              0x0104C, g_csr_gen4_mfd_H264_0_DPB_NUMB_OVR, "MFD H264 0 DPB NUMB OVR",      NULL},
  {"H264_0_DANGLING_FIELD",            0x0105C, g_csr_gen4_mfd_H264_0_DANGLING_FIELD, "MFD H264 0 DANGLING FIELD",    NULL},
  {"H264_0_DISP_TAG",                  0x01060, g_csr_gen4_mfdH264_0_DISP_TAG, "MFD H264 0 DISP TAG",            NULL},
  {"H264_0_DPB_MBI_ADDR_LUT_WR",       0x0107C, g_csr_gen4_mfd_H264_0_DPB_MBI_ADDR_LUT_WR_DATA, "MFD H264 0 DPB MBI ADDR LUT WR", NULL},
  {"H264_0_DPB_UV_ADDR_LUT_WR",        0x01080, g_csr_gen4_mfd_H264_0_DPB_UV_ADDR_LUT_WR_DATA, "MFD H264 0 DPB UV ADDR LUT WR",  NULL},
  {"H264_0_DPB_Y_ADDR_LUT_WR",         0x01084, g_csr_gen4_mfd_H264_0_DPB_Y_ADDR_LUT_WR_DATA, "MFD H264 0 DPB Y ADDR LUT WR",   NULL},
  {"H264_0_FRAME_CYC_COUNT",           0x01090, NULL, "MFD H264 0 FRAME CYC COUNT",     NULL},
  {"H264_0_IB_WAIT_COUNT",             0x01094, NULL, "MFD H264 0 IB WAIT COUNT",     NULL},
  {"H264_0_RBSP_COUNT",                0x01098, NULL, "MFD H264 0 RBSP COUNT",        NULL},
  {"H264_0_MPR_COUNT",                 0x0109C, NULL, "MFD H264 0 MPR COUNT",         NULL},
  {"H264_0_CORE_CONFIG",               0x010A0, g_csr_gen4_mfd_H264_0_CORE_CONFIG, "MFD H264 0 CORE CONFIG",       NULL},
  {"H264_0_INT_CTRL",                  0x010C0, g_csr_gen4_mfd_H264_0_INT_CTRL, "MFD H264 0 INT CTRL",          NULL},
  {"H264_0_INT_STAT",                  0x010C4, g_csr_gen4_mfd_H264_0_INT_STAT, "MFD H264 0 INT STAT",          NULL},
  {"H264_0_SOFT_RST",                  0x010FC, g_csr_gen4_mfd_H264_0_SOFT_RST, "MFD H264 0 SOFT RST",          NULL},
  {"H264_0_BSD_PSR_STAT",              0x01100, NULL, "MFD H264 0 BSD PSR STAT",      NULL},
  {"H264_0_BSD_STAT",                  0x01104, g_csr_gen4_mfd_H264_0_BSD_STAT, "MFD H264 0 BSD STAT",          NULL},
  {"H264_0_BSD_RBSP_CTRL",             0x01110, g_csr_gen4_mfd_H264_0_BSD_RBSP_CTRL, "MFD H264 0 BSD RBSP CTRL",     NULL},
  {"H264_0_BSD_DATA",                  0x01114, NULL, "MFD H264 0 BSD DATA",          NULL},
  {"H264_0_BSD_NAL_TYPE",              0x01118, NULL, "MFD H264 0 BSD NAL TYPE",      NULL},
  {"H264_0_BSD_BBB_STAT",              0x0111C, g_csr_gen4_mfd_H264_0_BSD_BBB_STAT, "MFD H264 0 BSD BBB STAT",      NULL},
  {"H264_0_BSD_GUE_DEC",               0x01120, g_csr_gen4_mfd_H264_0_BSD_GUE_DEC, "H264 0 BSD GUE DEC",       NULL},
  {"H264_0_BSD_GSE_DEC",               0x01124, g_csr_gen4_mfd_H264_0_BSD_GSE_DEC, "MFD H264 0 BSD GSE DEC",       NULL},
  {"H264_0_BSD_EXP_GME_INTRA",         0x01128, g_csr_gen4_mfd_H264_0_BSD_EXP_GME_INTRA, "MFD H264 0 BSD EXP GME INTRA", NULL},
  {"H264_0_BSD_EXP_GME_INTER",         0x01138, g_csr_gen4_mfd_H264_0_BSD_EXP_GME_INTER, "MFD H264 0 BSD EXP GME INTER", NULL},
  {"H264_0_BSD_IMG_INIT",              0x01140, g_csr_gen4_mfd_H264_0_BSD_IMG_INIT, "MFD H264 0 BSD IMG INIT",      NULL},
  {"H264_0_BSD_SLICE_P1",              0x01150, g_csr_gen4_mfd_H264_0_BSD_SLICE_P1, "MFD H264 0 BSD SLICE P1",      NULL},
  {"H264_0_BSD_SLICE_P2",              0x01154, g_csr_gen4_mfd_H264_0_BSD_SLICE_P2, "MFD H264 0 BSD SLICE P2",      NULL},
  {"H264_0_BSD_SLICE_START",           0x01158, g_csr_gen4_mfd_H264_0_BSD_SLICE_START, "MFD H264 0 BSD SLICE START",   NULL},
  {"H264_0_BSD_MB_CTRL",               0x0115C, g_csr_gen4_mfd_H264_0_BSD_MB_CTRL, "MFD H264 0 BSD MB CTRL",       NULL},
  {"H264_0_BSD_QM_DEC_START",          0x01160, g_csr_gen4_mfd_H264_0_BSD_QM_DEC_START, "MFD H264 0 BSD QM DEC START",  NULL},
  {"H264_0_BSD_DEC_STAT",              0x01164, g_csr_gen4_mfd_H264_0_BSD_DEC_START, "MFD H264 0 BSD DEC STAT",      NULL},
  {"H264_0_BSD_QM_LOAD_START",         0x01168, g_csr_gen4_mfd_H264_0_BSD_QM_LOAD_START, "MFD H264 0 BSD QM LOAD START", NULL},
  {"H264_0_BSD_QM_LOAD_VALUE",         0x0116C, NULL, "MFD H264 0 BSD QM LOAD VALUE", NULL},
  {"H264_0_BSD_BYTE_ALIGN",            0x0117C, NULL, "MFD H264 0 BSD BYTE ALIGN",    NULL},
  {"H264_0_BSD_BBB_TRAIL",             0x01180, NULL, "MFD H264 0 BSD BBB TRAIL",     NULL},
  {"H264_0_BSD_GET_BITS01",            0x01184, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS01",    NULL},
  {"H264_0_BSD_GET_BITS02",            0x01188, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS02",    NULL},
  {"H264_0_BSD_GET_BITS03",            0x0118C, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS03",    NULL},
  {"H264_0_BSD_GET_BITS04",            0x01190, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS04",    NULL},
  {"H264_0_BSD_GET_BITS05",            0x01194, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS05",    NULL},
  {"H264_0_BSD_GET_BITS06",            0x01198, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS06",    NULL},
  {"H264_0_BSD_GET_BITS07",            0x0119C, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS07",    NULL},
  {"H264_0_BSD_GET_BITS08",            0x011A0, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS08",    NULL},
  {"H264_0_BSD_GET_BITS09",            0x011A4, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS09",    NULL},
  {"H264_0_BSD_GET_BITS10",            0x011A8, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS10",    NULL},
  {"H264_0_BSD_GET_BITS11",            0x011AC, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS11",    NULL},
  {"H264_0_BSD_GET_BITS12",            0x011B0, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS12",    NULL},
  {"H264_0_BSD_GET_BITS13",            0x011B4, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS13",    NULL},
  {"H264_0_BSD_GET_BITS14",            0x011B8, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS14",    NULL},
  {"H264_0_BSD_GET_BITS15",            0x011BC, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS15",    NULL},
  {"H264_0_BSD_GET_BITS16",            0x011C0, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS16",    NULL},
  {"H264_0_BSD_GET_BITS17",            0x011C4, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS17",    NULL},
  {"H264_0_BSD_GET_BITS18",            0x011C8, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS18",    NULL},
  {"H264_0_BSD_GET_BITS19",            0x011CC, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS19",    NULL},
  {"H264_0_BSD_GET_BITS20",            0x011D0, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS20",    NULL},
  {"H264_0_BSD_GET_BITS21",            0x011D4, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS21",    NULL},
  {"H264_0_BSD_GET_BITS22",            0x011D8, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS22",    NULL},
  {"H264_0_BSD_GET_BITS23",            0x011DC, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS23",    NULL},
  {"H264_0_BSD_GET_BITS24",            0x011E0, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS24",    NULL},
  {"H264_0_BSD_GET_BITS25",            0x011E4, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS25",    NULL},
  {"H264_0_BSD_GET_BITS26",            0x011E8, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS26",    NULL},
  {"H264_0_BSD_GET_BITS27",            0x011EC, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS27",    NULL},
  {"H264_0_BSD_GET_BITS28",            0x011F0, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS28",    NULL},
  {"H264_0_BSD_GET_BITS29",            0x011F4, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS29",    NULL},
  {"H264_0_BSD_GET_BITS30",            0x011F8, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS30",    NULL},
  {"H264_0_BSD_GET_BITS31",            0x011FC, g_csr_gen4_mfd_H264_0_BSD_GET_BITS, "MFD H264 0 BSD GET BITS31",    NULL},
  {"H264_0_MPR_TF_POC",                0x01300, NULL, "MFD H264 0 MPR TF POC",        NULL},
  {"H264_0_MPR_BF_POC",                0x01304, NULL, "MFD H264 0 MPR BF POC",        NULL},
  {"H264_0_MPR_LST00",                 0x01380, NULL, "MFD H264 0 MPR LST00",         NULL},
  {"H264_0_MPR_LST01",                 0x01384, NULL, "MFD H264 0 MPR LST01",         NULL},
  {"H264_0_MPR_LST02",                 0x01388, NULL, "MFD H264 0 MPR LST02",         NULL},
  {"H264_0_MPR_LST03",                 0x0138C, NULL, "MFD H264 0 MPR LST03",         NULL},
  {"H264_0_MPR_LST04",                 0x01390, NULL, "MFD H264 0 MPR LST04",         NULL},
  {"H264_0_MPR_LST05",                 0x01394, NULL, "MFD H264 0 MPR LST05",         NULL},
  {"H264_0_MPR_LST06",                 0x01398, NULL, "MFD H264 0 MPR LST06",         NULL},
  {"H264_0_MPR_LST07",                 0x0139C, NULL, "MFD H264 0 MPR LST07",         NULL},
  {"H264_0_MPR_LST08",                 0x013A0, NULL, "MFD H264 0 MPR LST08",         NULL},
  {"H264_0_MPR_LST09",                 0x013A4, NULL, "MFD H264 0 MPR LST09",         NULL},
  {"H264_0_MPR_LST10",                 0x013A8, NULL, "MFD H264 0 MPR LST10",         NULL},
  {"H264_0_MPR_LST11",                 0x013AC, NULL, "MFD H264 0 MPR LST11",         NULL},
  {"H264_0_MPR_LST12",                 0x013B0, NULL, "MFD H264 0 MPR LST12",         NULL},
  {"H264_0_MPR_LST13",                 0x013B4, NULL, "MFD H264 0 MPR LST13",         NULL},
  {"H264_0_MPR_LST14",                 0x013B8, NULL, "MFD H264 0 MPR LST14",         NULL},
  {"H264_0_MPR_LST15",                 0x013BC, NULL, "MFD H264 0 MPR LST15",         NULL},

  /* SIF and Stream Control */
  {"H264_0_RSB_DDR_BA",                0x01808, g_csr_gen4_mfd_H264_0_RSB_DDR_BA, "MFD H264 0 RSB DDR BA",        NULL},
  /* contains 2 status bits (bs_ib_empty and frm_dec_active) */
  {"H264_0_DEC_STATUS",                0x0180C, g_csr_gen4_mfd_H264_0_DEC_STATUS, "MFD H264 0 DEC STATUS",        NULL},
  {"H264_0_SIF_SMP_RS",                0x01810, g_csr_gen4_mfd_H264_0_SIF_SMP_RS, "MFD H264 0 SIF SMP RS",        NULL},
  {"H264_0_SIF_MSK_RS",                0x01814, g_csr_gen4_mfd_H264_0_SIF_MASK_RS, "MFD H264 0 SIF MSK RS",        NULL},
  {"H264_0_SIF_HDAT",                  0x01818, NULL, "MFD H264 0 SIF HDAT",          NULL},
  {"H264_0_SIF_SDDAT",                 0x0181C, NULL, "MFD H264 0 SIF SDDAT",         NULL},
  {"H264_0_SIF_SMP_RC",                0x01820, g_csr_gen4_mfd_H264_0_SIF_SMP_RC, "MFD H264 0 SIF SMP RC",        NULL},
  {"H264_0_SIF_MSK_RC",                0x01824, g_csr_gen4_mfd_H264_0_SIF_MASK_RC, "MFD H264 0 SIF MSK RC",        NULL},

  /* Stream DMA */
  {"H264_0_SED",                       0x01900, g_csr_gen4_mfd_H264_0_SED, "MFD H264 0 SED",                NULL},
  {"H264_0_SDEMC",                     0x01904, g_csr_gen4_mfd_H264_0_SDEMC, "MFD H264 0 SDEMC",              NULL},
  {"H264_0_DMA_CB_BASE",               0x01908, NULL, "MFD H264 0 DMA CB BASE",        NULL},
  {"H264_0_DMA_SB_RDPTR",              0x0190C, NULL, "MFD H264 0 DMA SB RDPTR",       NULL},
  {"H264_0_DMA_CB_SIZE",               0x01910, NULL, "MFD H264 0 DMA CB SIZE",        NULL},
  {"H264_0_DMA_WTRMARK",               0x01914, NULL, "MFD H264 0 DMA WTRMARK",        NULL},
  {"H264_0_DMA_WDT",                   0x01918, g_csr_gen4_mfd_H264_0_DMA_WDT, "MFD H264 0 DMA WDT",            NULL},
  {"H264_0_DMA_CB_RDPTR",              0x0191C, NULL, "MFD H264 0 DMA CB RDPTR",       NULL},
  {"H264_0_DMA_CB_WRPTR",              0x01920, NULL, "MFD H264 0 DMA CB WRPTR",       NULL},
  {"H264_0_DMA_SDLINK",                0x01924, g_csr_gen4_mfd_H264_0_DMA_SDLINK, "MFD H264 0 DMA SDLINK",         NULL},
  {"H264_0_DMA_SDLLSA",                0x01928, NULL, "MFD H264 0 DMA SDLLSA",         NULL},
  {"H264_0_DMA_SDLNDA",                0x0192C, g_csr_gen4_mfd_H264_0_DMA_SDLNDA, "MFD H264 0 DMA SDLNDA",         NULL},
  {"H264_0_DMA_SDLDBC",                0x01930, NULL, "MFD H264 0 DMA SDLDBC",         NULL},
  {"H264_0_DMA_SDLCBC",                0x01934, NULL, "MFD H264 0 DMA SDLCBC",         NULL},
  {"H264_0_DMA_SDLDC",                 0x01938, g_csr_gen4_mfd_H264_0_DMA_SDLDC, "MFD H264 0 DMA SDLDC",          NULL},
  {"H264_0_DMA_FIFO",                  0x0193C, NULL, "MFD H264 0 DMA FIFO",           NULL},
  {"H264_0_DMA_FIFO_STAT",             0x01940, g_csr_gen4_mfd_H264_0_DMA_FIFO_STAT, "MFD H264 0 DMA FIFO STAT",      NULL},
  {"H264_0_DMA_INT_EN",                0x01944, g_csr_gen4_mfd_H264_0_DMA_INT_EN, "MFD H264 0 DMA INT EN",         NULL},
  {"H264_0_DMA_INT_STAT",              0x01948, g_csr_gen4_mfd_H264_0_DMA_INT_STAT, "MFD H264 0 DMA INT STAT",       NULL},
  {"H264_0_DMA_BS_CNTR",               0x0194C, NULL, "MFD H264 0 DMA BS CNTR",        NULL},
  {"H264_0_DMA_CD_CNTR",               0x01950, g_csr_gen4_mfd_H264_0_CD_CNTR, "MFD H264 0 DMA CD CNTR",        NULL},

  /* Start Code Detector  (SCD) */
  {"H264_0_SCD_XCR",                   0x01A00, g_csr_gen4_mfd_SCD_XCR, "MFD H264 0 SCD XCR",            NULL},
  {"H264_0_SCD_XSCR1",                 0x01A04, NULL, "MFD H264 0 SCD XSCR1",          NULL},
  {"H264_0_SCD_XSCR2",                 0x01A08, NULL, "MFD H264 0 SCD XSCR2",          NULL},
  {"H264_0_SCD_FWPREAD",               0x01A0C, NULL, "MFD H264 0 SCD FWPREAD",        NULL},
  {"H264_0_SCD_FWCRTL",                0x01A10, g_csr_gen4_mfd_SCD_FWCTRL, "MFD H264 0 SCD FWCRTL",         NULL},
  {"H264_0_SCD_FWSTAT",                0x01A14, NULL, "MFD H264 0 SCD FWSTAT",         NULL},
  {"H264_0_SCD_WRCTRL",                0x01A18, NULL, "MFD H264 0 SCD WRCTRL",         NULL},
  {"H264_0_SCD_WRDATA",                0x01A1C, NULL, "MFD H264 0 SCD WRDATA",         NULL},

  /* PIP Scaler Registers */
  {"H264_0_PIP_CTRL",                  0x01B00, g_csr_gen4_mfd_H264_0_PIP_CTRL, "MFD H264 0 PIP CTRL",           NULL},
  {"H264_0_PIP_STAT",                  0x01B04, g_csr_gen4_mfd_H264_0_PIP_STAT, "MFD H264 0 PIP STAT",           NULL},
  {"H264_0_PIP_CDYB",                  0x01B08, NULL, "MFD H264 0 PIP CDYB",           NULL},
  {"H264_0_PIP_CDUB",                  0x01B0c, NULL, "MFD H264 0 PIP CDUB",           NULL},
  {"H264_0_PIP_TST_CTRL",              0x01B10, g_csr_gen4_mfd_PIP_TST_CTRL, "MFD H264 0 PIP TST CTRL",       NULL},
  {"H264_0_PIP_TST_WR_DATA_LO",        0x01B14, NULL, "MFD H264 0 PIP TST WR DATA LO", NULL},
  {"H264_0_PIP_TST_WR_DATA_HI",        0x01B18, NULL, "MFD H264 0 PIP TST WR DATA HI", NULL},

  /*  VC1 #0 (CS7150) 0x2000 to 0x2FFF */
  {"VC1_0_SMP_RD",                     0x02000, NULL, "MFD VC1 0 SMP RD",             NULL},
  {"VC1_0_INT_EN_RD",                  0x02004, NULL, "MFD VC1 0 INT EN RD",          NULL},
  {"VC1_0_SMP_SET",                    0x02008, NULL, "MFD VC1 0 SMP SET",            NULL},
  {"VC1_0_SMP_CLR",                    0x0200C, NULL, "MFD VC1 0 SMP CLR",            NULL},
  {"VC1_0_SMP_MSK_SET",                0x02010, NULL, "MFD VC1 0 SMP MSK SET",        NULL},
  {"VC1_0_SMP_MSK_CLR",                0x02014, NULL, "MFD VC1 0 SMP MSK CLR",        NULL},
  {"VC1_0_HDAT",                       0x02018, NULL, "MFD VC1 0 HDAT",               NULL},
  {"VC1_0_SDDAT",                      0x0201C, NULL, "MFD VC1 0 SDDAT",              NULL},
  {"VC1_0_DQ_PUSH",                    0x02020, NULL, "MFD VC1 0 DQ PUSH",            NULL},
  {"VC1_0_DQ_STAT",                    0x02024, NULL, "MFD VC1 0 DQ STAT",            NULL},
  {"VC1_0_DPB_INIT",                   0x02040, NULL, "MFD VC1 0 DPB INIT",           NULL},
  {"VC1_0_DPB_FRM_SZ_STAT",            0x02044, NULL, "MFD VC1 0 DPB FRM SZ STAT",    NULL},
  {"VC1_0_DPB_FRM_SZ_CTRL",            0x02048, NULL, "MFD VC1 0 DPB FRM SZ CTRL",    NULL},
  {"VC1_0_DPB_NUMB_OVR",               0x0204C, NULL, "MFD VC1 0 DPB NUMB_OVR",       NULL},
  {"VC1_0_DPB_FS_SETTING",             0x02050, NULL, "MFD VC1 0 DPB FS SETTING",     NULL},
  {"VC1_0_DPB_LOAD_OFFSET",            0x02054, NULL, "MFD VC1 0 DPB LOAD OFFSET",    NULL},
  {"VC1_0_FSD",                        0x02058, NULL, "MFD VC1 0 FSD",                NULL},
  {"VC1_0_DANGLING_FIELD",             0x0205C, NULL, "MFD VC1 0 DANGLING FIELD",     NULL},
  {"VC1_0_DISP_TAG",                   0x02060, NULL, "MFD VC1 0 DISP TAG",           NULL},
  {"VC1_0_DPB_UV_ADDR_LUT_WR",         0x02080, NULL, "MFD VC1 0 DPB UV ADDR LUT WR", NULL},
  {"VC1_0_DPB_Y_ADDR_LUT_WR",          0x02084, NULL, "MFD VC1 0 DPB Y ADDR LUT WR",  NULL},
  {"VC1_0_MPS_RD_BYTE_COUNT",          0x02088, NULL, "MFD VC1 0 MPS RD BYTE COUNT",  NULL},
  {"VC1_0_SLC_IN_FRM_COUNT",           0x0208C, NULL, "MFD VC1 0 SLC IN FRM COUNT",   NULL},
  {"VC1_0_FRAME_CYC_COUNT",            0x02090, NULL, "MFD VC1 0 FRAME CYC COUNT",    NULL},
  {"VC1_0_IB_WAIT_COUNT",              0x02094, NULL, "MFD VC1 0 IB WAIT COUNT",      NULL},
  {"VC1_0_RBSP_COUNT",                 0x02098, NULL, "MFD VC1 0 RBSP COUNT",         NULL},
  {"VC1_0_BS2RBSP_STATUS",             0x0209C, NULL, "MFD VC1 0 BS2RBSP STATUS",     NULL},
  {"VC1_0_CORE_CONFIG",                0x020A0, NULL, "MFD VC1 0 CORE CONFIG",        NULL},
  {"VC1_0_RBSP_CTRL",                  0x020A4, NULL, "MFD VC1 0 RBSP CTRL",          NULL},
  {"VC1_0_INT_CTRL",                   0x020C0, NULL, "MFD VC1 0 INT CTRL",           NULL},
  {"VC1_0_INT_STAT",                   0x020C4, NULL, "MFD VC1 0 INT STAT",           NULL},
  {"VC1_0_SOFT_RST",                   0x020C8, NULL, "MFD VC1 0 SOFT RST",           NULL},
  {"VC1_0_BSP_BYTE_ALIGN",             0x02100, NULL, "MFD VC1 0 BSP BYTE ALIGN",     NULL},
  {"VC1_0_BSP_GET_BITS01",             0x02104, NULL, "MFD VC1 0 BSP GET BITS01",     NULL},
  {"VC1_0_BSP_GET_BITS02",             0x02108, NULL, "MFD VC1 0 BSP GET BITS02",     NULL},
  {"VC1_0_BSP_GET_BITS03",             0x0210C, NULL, "MFD VC1 0 BSP GET BITS03",     NULL},
  {"VC1_0_BSP_GET_BITS04",             0x02110, NULL, "MFD VC1 0 BSP GET BITS04",     NULL},
  {"VC1_0_BSP_GET_BITS05",             0x02114, NULL, "MFD VC1 0 BSP GET BITS05",     NULL},
  {"VC1_0_BSP_GET_BITS06",             0x02118, NULL, "MFD VC1 0 BSP GET BITS06",     NULL},
  {"VC1_0_BSP_GET_BITS07",             0x0211C, NULL, "MFD VC1 0 BSP GET BITS07",     NULL},
  {"VC1_0_BSP_GET_BITS08",             0x02120, NULL, "MFD VC1 0 BSP GET BITS08",     NULL},
  {"VC1_0_BSP_GET_BITS09",             0x02124, NULL, "MFD VC1 0 BSP GET BITS09",     NULL},
  {"VC1_0_BSP_GET_BITS10",             0x02128, NULL, "MFD VC1 0 BSP GET BITS10",     NULL},
  {"VC1_0_BSP_GET_BITS11",             0x0212C, NULL, "MFD VC1 0 BSP GET BITS11",     NULL},
  {"VC1_0_BSP_GET_BITS12",             0x02130, NULL, "MFD VC1 0 BSP GET BITS12",     NULL},
  {"VC1_0_BSP_GET_BITS13",             0x02134, NULL, "MFD VC1 0 BSP GET BITS13",     NULL},
  {"VC1_0_BSP_GET_BITS14",             0x02138, NULL, "MFD VC1 0 BSP GET BITS14",     NULL},
  {"VC1_0_BSP_GET_BITS15",             0x0213C, NULL, "MFD VC1 0 BSP GET BITS15",     NULL},
  {"VC1_0_BSP_GET_BITS16",             0x02140, NULL, "MFD VC1 0 BSP GET BITS16",     NULL},
  {"VC1_0_BSP_GET_BITS17",             0x02144, NULL, "MFD VC1 0 BSP GET BITS17",     NULL},
  {"VC1_0_BSP_GET_BITS18",             0x02148, NULL, "MFD VC1 0 BSP GET BITS18",     NULL},
  {"VC1_0_BSP_GET_BITS19",             0x0214C, NULL, "MFD VC1 0 BSP GET BITS19",     NULL},
  {"VC1_0_BSP_GET_BITS20",             0x02150, NULL, "MFD VC1 0 BSP GET BITS20",     NULL},
  {"VC1_0_BSP_GET_BITS21",             0x02154, NULL, "MFD VC1 0 BSP GET BITS21",     NULL},
  {"VC1_0_BSP_GET_BITS22",             0x02158, NULL, "MFD VC1 0 BSP GET BITS22",     NULL},
  {"VC1_0_BSP_GET_BITS23",             0x0215C, NULL, "MFD VC1 0 BSP GET BITS23",     NULL},
  {"VC1_0_BSP_GET_BITS24",             0x02160, NULL, "MFD VC1 0 BSP GET BITS24",     NULL},
  {"VC1_0_BSP_GET_BITS25",             0x02164, NULL, "MFD VC1 0 BSP GET BITS25",     NULL},
  {"VC1_0_BSP_GET_BITS26",             0x02168, NULL, "MFD VC1 0 BSP GET BITS26",     NULL},
  {"VC1_0_BSP_GET_BITS27",             0x0216C, NULL, "MFD VC1 0 BSP GET BITS27",     NULL},
  {"VC1_0_BSP_GET_BITS28",             0x02170, NULL, "MFD VC1 0 BSP GET BITS28",     NULL},
  {"VC1_0_BSP_GET_BITS29",             0x02174, NULL, "MFD VC1 0 BSP GET BITS29",     NULL},
  {"VC1_0_BSP_GET_BITS30",             0x02178, NULL, "MFD VC1 0 BSP GET BITS30",     NULL},
  {"VC1_0_BSP_GET_BITS31",             0x0217C, NULL, "MFD VC1 0 BSP GET BITS31",     NULL},
  {"VC1_0_BSP_STATUS",                 0x02180, NULL, "MFD VC1 0 BSP STATUS",         NULL},
  {"VC1_0_BSP_CTRL",                   0x02184, NULL, "MFD VC1 0 BSP CTRL",           NULL},
  {"VC1_0_BSP_SHOW_BITS",              0x02188, NULL, "MFD VC1 0 BSP SHOW BITS",      NULL},
  {"VC1_0_BSP_SHOW_BITS_FLPD",         0x0218C, NULL, "MFD VC1 0 BSP SHOW BITS FLPD", NULL},
  {"VC1_0_BSP_IGNORE_BBB_LEVEL",       0x02190, NULL, "MFD VC1 0 BSP IGNORE BBB LEVEL",       NULL},
  {"VC1_0_BSP_HEADER_VLC_PTYPE",       0x021C0, NULL, "MFD VC1 0 BSP HEADER VLC PTYPE",       NULL},
  {"VC1_0_BSP_HEADER_VLC_FTYPE",       0x021C4, NULL, "MFD VC1 0 BSP HEADER VLC FTYPE",       NULL},
  {"VC1_0_BSP_HEADER_VLC_MVRANGE",     0x021C8, NULL, "MFD VC1 0 BSP HEADER VLC MVRANGE",     NULL},
  {"VC1_0_BSP_HEADER_VLC_MVMODE",      0x021CC, NULL, "MFD VC1 0 BSP HEADER VLC MVMODE",      NULL},
  {"VC1_0_BSP_HEADER_VLC_MVMODE2",     0x021D0, NULL, "MFD VC1 0 BSP HEADER VLC MVMODE2",     NULL},
  {"VC1_0_BSP_HEADER_VLC_DMVRANGE",    0x021D4, NULL, "MFD VC1 0 BSP HEADER VLC DMVRANGE",    NULL},
  {"VC1_0_BSP_HEADER_VLC_BPPMODE",     0x021D8, NULL, "MFD VC1 0 BSP HEADER VLC BPPMODE",     NULL},
  {"VC1_0_BSP_HEADER_VLC_BPPVLC2",     0x021DC, NULL, "MFD VC1 0 BSP HEADER VLC BPPVLC2",     NULL},
  {"VC1_0_BSP_HEADER_VLC_BPPVLC6",     0x021E0, NULL, "MFD VC1 0 BSP HEADER VLC BPPVLC6",     NULL},
  {"VC1_0_BSP_HEADER_VLC_BFRACT",      0x021E4, NULL, "MFD VC1 0 BSP HEADER VLC BFRACT",      NULL},
  {"VC1_0_BSP_HEADER_VLC_REFDIST",     0x021E8, NULL, "MFD VC1 0 BSP HEADER VLC REFDIST",     NULL},
  {"VC1_0_SEQPIC_GENERAL_CORE_CONFIG", 0x02200, NULL, "MFD VC1 0 SEQPIC GENERAL CORE CONFIG", NULL},
  {"VC1_0_SEQPIC_STREAM_FORMAT_1",     0x02204, g_csr_gen4_mfd_VC1_0_SEQPIC_STREAM_FORMAT_1, "MFD VC1 0 SEQPIC STREAM FORMAT 1",     NULL},
  {"VC1_0_SEQPIC_CODED_SIZE",          0x02208, g_csr_gen4_mfd_VC1_0_SEQPIC_CODED_SIZE, "MFD VC1 0 SEQPIC CODED SIZE",          NULL},
  {"VC1_0_SEQPIC_STREAM_FORMAT_2",     0x0220C, g_csr_gen4_mfd_VC1_0_SEQPIC_STREAM_FORMAT_2, "MFD VC1 0 SEQPIC STREAM FORMAT 2",     NULL},
  {"VC1_0_SEQPIC_ENTRY_POINT_1",       0x02210, g_csr_gen4_mfd_VC1_0_SEQPIC_ENTRY_POINT_1, "MFD VC1 0 SEQPIC ENTRY POINT 1",       NULL},
  {"VC1_0_SEQPIC_RANGE_MAP",           0x02214, g_csr_gen4_mfd_VC1_0_SEQPIC_RANGE_MAP, "MFD VC1 0 SEQPIC RANGE MAP",           NULL},
  {"VC1_0_SEQPIC_FRAME_TYPE",          0x02218, g_csr_gen4_mfd_VC1_0_SEQPIC_FRAME_TYPE, "MFD VC1 0 SEQPIC FRAME TYPE",          NULL},
  {"VC1_0_SEQPIC_RECON_CONTROL",       0x0221C, g_csr_gen4_mfd_VC1_0_SEQPIC_RECON_CONTROL, "MFD VC1 0 SEQPIC RECON CONTROL",       NULL},
  {"VC1_0_SEQPIC_MOTION_VECTOR_CONTROL",  0x02220, g_csr_gen4_mfd_VC1_0_SEQPIC_MOTION_VECTOR_CONTROL, "MFD VC1 0 SEQPIC MOTION VECTOR CONTROL",  NULL},
  {"VC1_0_SEQPIC_INTENSITY_COMPENSATION", 0x02224, g_csr_gen4_mfd_VC1_0_SEQPIC_INTENSITY_COMPENSATION, "MFD VC1 0 SEQPIC INTENSITY COMPENSATION", NULL},
  {"VC1_0_SEQPIC_REFERENCE_B_FRACTION",   0x02228, g_csr_gen4_mfd_VC1_0_SEQPIC_REFERENCE_B_FRACTION, "MFD VC1 0 SEQPIC REFERENCE B FRACTION",   NULL},
  {"VC1_0_SEQPIC_BLOCK_CONTROL",          0x0222C, g_csr_gen4_mfd_VC1_0_SEQPIC_BLOCK_CONTROL, "MFD VC1 0 SEQPIC BLOCK CONTROL",   NULL},
  {"VC1_0_SEQPIC_TRANSFORM_DATA",      0x02230, g_csr_gen4_mfd_VC1_0_SEQPIC_TRANSFORM_DATA, "MFD VC1 0 SEQPIC TRANSFORM DATA",     NULL},
  {"VC1_0_SEQPIC_VOP_DEQUANT",         0x02234, g_csr_gen4_mfd_VC1_0_SEQPIC_VOP_DEQUANT, "MFD VC1 0 SEQPIC VOP DEQUANT",        NULL},
  {"VC1_0_SEQPIC_CURR_FRAME_ID",       0x02238, g_csr_gen4_mfd_VC1_0_SEQPIC_CURR_FRAME_ID, "MFD VC1 0 SEQPIC CURR FRAME ID",      NULL},
  {"VC1_0_SEQPIC_CURR_DISPLAY_ID",     0x0223C, g_csr_gen4_mfd_VC1_0_SEQPIC_CURR_FRAME_ID, "MFD VC1 0 SEQPIC CURR DISPLAY ID",    NULL},
  {"VC1_0_SEQPIC_FWD_REF_FRAME_ID",    0x02240, g_csr_gen4_mfd_VC1_0_SEQPIC_CURR_FRAME_ID, "MFD VC1 0 SEQPIC FWD REF FRAME ID",   NULL},
  {"VC1_0_SEQPIC_BWD_REF_FRAME_ID",    0x02244, g_csr_gen4_mfd_VC1_0_SEQPIC_CURR_FRAME_ID, "MFD VC1 0 SEQPIC BWD REF FRAME ID",   NULL},
  {"VC1_0_SEQPIC_FIELD_REF_FRAME_ID",  0x02248, g_csr_gen4_mfd_VC1_0_SEQPIC_FIELD_REF_FRAME_ID, "MFD VC1 0 SEQPIC FIELD REF FRAME ID", NULL},
  {"VC1_0_SEQPIC_AUX_FRAME_CONTROL",   0x0224C, g_csr_gen4_mfd_VC1_0_SEQPIC_CURR_FRAME_ID, "MFD VC1 0 SEQPIC AUX FRAME CONTROL",  NULL},
  {"VC1_0_SEQPIC_IMAGE_STRUCTURE",     0x02250, g_csr_gen4_mfd_VC1_0_SEQPIC_IMAGE_STRUCTURE, "MFD VC1 0 SEQPIC IMAGE STRUCTURE",    NULL},
  {"VC1_0_SEQPIC_ALT_FRAME_TYPE",      0x02254, g_csr_gen4_mfd_VC1_0_SEQPIC_ALT_FRAME_TYPE, "MFD VC1 0 SEQPIC ALT FRAME TYPE",     NULL},
  {"VC1_0_SEQPIC_INT_COMP_FWD_BOT",    0x02258, g_csr_gen4_mfd_VC1_0_SEQPIC_INT_COMP_FWD_BOT, "MFD VC1 0 INTENSITY COMPENSATION FWD BOT", NULL},
  {"VC1_0_SEQPIC_INT_COMP_BWD_TOP",    0x0225C, g_csr_gen4_mfd_VC1_0_SEQPIC_INT_COMP_BWD_TOP, "MFD VC1 0 INTENSITY COMPENSATION BWD TOP", NULL},
  {"VC1_0_SEQPIC_INT_COMP_BWD_BOT",    0x02260, g_csr_gen4_mfd_VC1_0_SEQPIC_INT_COMP_BWD_BOT, "MFD VC1 0 INTENSITY COMPENSATION BWD BOT", NULL},
  {"VC1_0_MBDEC_STATUS",               0x02300, g_csr_gen4_mfd_VC1_0_MBDEC_STATUS, "MFD VC1 0 MBDEC STATUS",              NULL},
  {"VC1_0_MBDEC_FRAME_START",          0x02304, NULL, "MFD VC1 0 MBDEC FRAME START",         NULL},
  {"VC1_0_MBDEC_FW_DEBUG",             0x02308, NULL, "MFD VC1 0 MBDEC FW DEBUG",               NULL},
  {"VC1_0_MBDEC_MBQDEBUG",             0x0230C, NULL, "MFD VC1 0 MBDEC MBQDEBUG",               NULL},
  {"VC1_0_MBDEC_MPRDEBUG",             0x02310, NULL, "MFD VC1 0 MBDEC MPRDEBUG",               NULL},
  {"VC1_0_MBDEC_MASDEBUG",             0x02314, NULL, "MFD VC1 0 MBDEC MASDEBUG",               NULL},
  {"VC1_0_MBDEC_BPPDEBUG",             0x02318, NULL, "MFD VC1 0 MBDEC BPPDEBUG",               NULL},
  {"VC1_0_MBDEC_DPBMCDEBUG",           0x0231C, NULL, "MFD VC1 0 MBDEC DPBMCDEBUG",             NULL},
  {"VC1_0_MBDEC_GENDEBUG",             0x02320, NULL, "MFD VC1 0 MBDEC GENDEBUG",               NULL},
  {"VC1_0_FW_DEBUG",                   0x02324, NULL, "MFD VC1 0 FW DEBUG",                     NULL},
  {"VC1_0_MBDEC_ERROR_CONCEAL_CONTROL", 0x02340, NULL, "MFD VC1 0 MBDEC ERROR CONCEAL CONTROL", NULL},
  {"VC1_0_BP_CONTROL_STATUS",          0x02400, g_csr_gen4_mfd_VC1_0_BP_CONTROL_STATUS, "MFD VC1 0 BP CONTROL STATUS",            NULL},
  {"VC1_0_BP_DATA_IN_STATUS",          0x02404, NULL, "MFD VC1 0 BP DATA IN STATUS",            NULL},
  {"VC1_0_BP_DATA_IN_VALUE",           0x02408, NULL, "MFD VC1 0 BP DATA IN VALUE",             NULL},
  {"VC1_0_BP_DATA_IN_POSITION_N_SIZE", 0x0240C, g_csr_gen4_mfd_VC1_0_BP_DATA_IN_POSITION_N_SIZE, "MFD VC1 0 BP DATA IN POSITION N SIZE",   NULL},

  /* SIF and Stream Control */
  {"VC1_0_MBA_ENABLE",                 0x02800, NULL, "MFD VC1 0 MBA ENABLE", NULL},
  {"VC1_0_RSB_DDR_BA",                 0x02808, NULL, "MFD VC1 0 RSB DDR BA", NULL},
  /* contains 2 status bits (bs_ib_empty and frm_dec_active) */
  {"VC1_0_DEC_STATUS",                 0x0280C, NULL, "MFD VC1 0 DEC STATUS", NULL},
  {"VC1_0_SIF_SMP_RS",                 0x02810, NULL, "MFD VC1 0 SIF SMP RS", NULL},
  {"VC1_0_SIF_MSK_RS",                 0x02814, NULL, "MFD VC1 0 SIF MSK RS", NULL},
  {"VC1_0_SIF_HDAT",                   0x02818, NULL, "MFD VC1 0 SIF HDAT",   NULL},
  {"VC1_0_SIF_SDDAT",                  0x0281C, NULL, "MFD VC1 0 SIF SDDAT",  NULL},
  {"VC1_0_SIF_SMP_RC",                 0x02820, NULL, "MFD VC1 0 SIF SMP RC", NULL},
  {"VC1_0_SIF_MSK_RC",                 0x02824, NULL, "MFD VC1 0 SIF MSK RC", NULL},

  /* Stream DMA */
  {"VC1_0_SED",                        0x02900, NULL, "MFD VC1 0 SED",           NULL},
  {"VC1_0_SDEMC",                      0x02904, NULL, "MFD VC1 0 SDEMC",         NULL},
  {"VC1_0_DMA_CB_BASE",                0x02908, NULL, "MFD VC1 0 DMA CB BASE",   NULL},
  {"VC1_0_DMA_SB_RDPTR",               0x0290C, NULL, "MFD VC1 0 DMA SB RDPTR",  NULL},
  {"VC1_0_DMA_CB_SIZE",                0x02910, NULL, "MFD VC1 0 DMA CB SIZE",   NULL},
  {"VC1_0_DMA_WTRMARK",                0x02914, NULL, "MFD VC1 0 DMA WTRMARK",   NULL},
  {"VC1_0_DMA_WDT",                    0x02918, NULL, "MFD VC1 0 DMA WDT",       NULL},
  {"VC1_0_DMA_CB_RDPTR",               0x0291C, NULL, "MFD VC1 0 DMA CB RDPTR",  NULL},
  {"VC1_0_DMA_CB_WRPTR",               0x02920, NULL, "MFD VC1 0 DMA CB WRPTR",  NULL},
  {"VC1_0_DMA_SDLINK",                 0x02924, NULL, "MFD VC1 0 DMA SDLINK",    NULL},
  {"VC1_0_DMA_SDLLSA",                 0x02928, NULL, "MFD VC1 0 DMA SDLLSA",    NULL},
  {"VC1_0_DMA_SDLNDA",                 0x0292C, NULL, "MFD VC1 0 DMA SDLNDA",    NULL},
  {"VC1_0_DMA_SDLDBC",                 0x02930, NULL, "MFD VC1 0 DMA SDLDBC",    NULL},
  {"VC1_0_DMA_SDLCBC",                 0x02934, NULL, "MFD VC1 0 DMA SDLCBC",    NULL},
  {"VC1_0_DMA_SDLDC",                  0x02938, NULL, "MFD VC1 0 DMA SDLDC",     NULL},
  {"VC1_0_DMA_FIFO",                   0x0293C, NULL, "MFD VC1 0 DMA FIFO",      NULL},
  {"VC1_0_DMA_FIFO_STAT",              0x02940, NULL, "MFD VC1 0 DMA FIFO STAT", NULL},
  {"VC1_0_DMA_INT_EN",                 0x02944, NULL, "MFD VC1 0 DMA INT EN",    NULL},
  {"VC1_0_DMA_INT_STAT",               0x02948, NULL, "MFD VC1 0 DMA INT STAT",  NULL},
  {"VC1_0_DMA_BS_CNTR",                0x0294C, NULL, "MFD VC1 0 DMA BS CNTR",   NULL},

  /*  Start Code Detector  (SCD) */
  {"VC1_0_SCD_XCR",                    0x02A00, g_csr_gen4_mfd_SCD_XCR, "MFD VC1 0 SCD XCR",     NULL},
  {"VC1_0_SCD_XSCR1",                  0x02A04, NULL, "MFD VC1 0 SCD XSCR1",   NULL},
  {"VC1_0_SCD_XSCR2",                  0x02A08, NULL, "MFD VC1 0 SCD XSCR2",   NULL},
  {"VC1_0_SCD_FWPREAD",                0x02A0C, NULL, "MFD VC1 0 SCD FWPREAD", NULL},
  {"VC1_0_SCD_FWCRTL",                 0x02A10, g_csr_gen4_mfd_SCD_FWCTRL, "MFD VC1 0 SCD FWCRTL",  NULL},
  {"VC1_0_SCD_FWSTAT",                 0x02A14, NULL, "MFD VC1 0 SCD FWSTAT",  NULL},
  {"VC1_0_SCD_WRCTRL",                 0x02A18, NULL, "MFD VC1 0 SCD WRCTRL",  NULL},
  {"VC1_0_SCD_WRDATA",                 0x02A1C, NULL, "MFD VC1 0 SCD WRDATA",  NULL},

  /* PIP Scaler Registers */
  {"VC1_0_PIP_CTRL",                   0x02B00, NULL, "MFD VC1 0 PIP CTRL",           NULL},
  {"VC1_0_PIP_STAT",                   0x02B04, NULL, "MFD VC1 0 PIP STAT",           NULL},
  {"VC1_0_PIP_CDYB",                   0x02B08, NULL, "MFD VC1 0 PIP CDYB",           NULL},
  {"VC1_0_PIP_CDUB",                   0x02B0C, NULL, "MFD VC1 0 PIP CDUB",           NULL},
  {"VC1_0_PIP_TST_CTRL",               0x02B10, NULL, "MFD VC1 0 PIP TST CTRL",       NULL},
  {"VC1_0_PIP_TST_WR_DATA_LO",         0x02B14, NULL, "MFD VC1 0 PIP TST WR DATA LO", NULL},
  {"VC1_0_PIP_TST_WR_DATA_HI",         0x02B18, NULL, "MFD VC1 0 PIP TST WR DATA HI", NULL},

  /* MPEG2D 0x3000 to 0x3FFF */
  {"MPG2VD_SAS",                       0x03000, NULL, "MFD MPG2VD SAS",   NULL},
  {"MPG2VD_IM",                        0x03004, NULL, "MFD MPG2VD IM",    NULL},
  {"MPG2VD_IS",                        0x03008, NULL, "MFD MPG2VD IS",    NULL},
  {"MPG2VD_DCC",                       0x0300C, NULL, "MFD MPG2VD DCC",   NULL},
  {"MPG2VD_DCSI1",                     0x03010, NULL, "MFD MPG2VD DCSI1", NULL},
  {"MPG2VD_DCSI2",                     0x03014, NULL, "MFD MPG2VD DCSI2", NULL},
  {"MPG2VD_DCPI1",                     0x03018, NULL, "MFD MPG2VD DCPI1", NULL},
  {"MPG2VD_DCPCE1",                    0x0301C, NULL, "MFD MPG2VD DCPCE1",NULL},
  {"MPG2VD_PPE",                       0x03020, NULL, "MFD MPG2VD PPE",   NULL},
  {"MPG2VD_QMA",                       0x03024, NULL, "MFD MPG2VD QMA",   NULL},
  {"MPG2VD_QMD",                       0x03028, NULL, "MFD MPG2VD QMD",   NULL},
  {"MPG2VD_CDYB",                      0x0302C, NULL, "MFD MPG2VD CDYB",  NULL},
  {"MPG2VD_CDUB",                      0x03030, NULL, "MFD MPG2VD CDUB",  NULL},
  {"MPG2VD_BRYB",                      0x03034, NULL, "MFD MPG2VD BRYB",  NULL},
  {"MPG2VD_BRUB",                      0x03038, NULL, "MFD MPG2VD BRUB",  NULL},
  {"MPG2VD_FRYB",                      0x0303C, NULL, "MFD MPG2VD FRYB",  NULL},
  {"MPG2VD_FRUB",                      0x03040, NULL, "MFD MPG2VD FRUB",  NULL},
  {"MPG2VD_STAT",                      0x03044, NULL, "MFD MPG2VD STAT",  NULL},

  /* Deblocking Filter */
  {"MPG2VD_DBF_CTRL",                  0x03400, NULL, "MFD MPG2VD DBF CTRL", NULL},
  {"MPG2VD_DBF_YDDA",                  0x03404, NULL, "MFD MPG2VD DBF YDDA", NULL},
  {"MPG2VD_DBF_CDDA",                  0x03408, NULL, "MFD MPG2VD DBF CDDA", NULL},
  {"MPG2VD_DBF_QSMF",                  0x0340C, NULL, "MFD MPG2VD DBF QSMF", NULL},
  {"MPG2VD_DBF_IFSV",                  0x03410, NULL, "MFD MPG2VD DBF IFSV", NULL},
  {"MPG2VD_DBF_PFSV",                  0x03414, NULL, "MFD MPG2VD DBF PFSV", NULL},
  {"MPG2VD_DBF_BFSV",                  0x03418, NULL, "MFD MPG2VD DBF BFSV", NULL},

  /* MPEG2VD MBAC Enable */
  {"MPG2VD_MBAC_ENABLE",               0x03800, NULL, "MFD MPG2VD MBAC ENABLE", NULL},

  /* SIF and Stream Control */
  {"MPG2VD_DEC_STATUS",                0x03824, NULL, "MFD MPG2VD DEC STATUS", NULL},

  /* Stream DMA */
  {"MPG2VD_SED",                       0x03900, NULL, "MFD MPG2VD SED",           NULL},
  {"MPG2VD_SDEMC",                     0x03904, NULL, "MFD MPG2VD SDEMC",         NULL},
  {"MPG2VD_DMA_CB_BASE",               0x03908, NULL, "MFD MPG2VD DMA CB BASE",   NULL},
  {"MPG2VD_DMA_SB_RDPTR",              0x0390C, NULL, "MFD MPG2VD DMA SB RDPTR",  NULL},
  {"MPG2VD_DMA_CB_SIZE",               0x03910, NULL, "MFD MPG2VD DMA CB SIZE",   NULL},
  {"MPG2VD_DMA_WTRMARK",               0x03914, NULL, "MFD MPG2VD DMA WTRMARK",   NULL},
  {"MPG2VD_DMA_WDT",                   0x03918, NULL, "MFD MPG2VD DMA WDT",       NULL},
  {"MPG2VD_DMA_CB_RDPTR",              0x0391C, NULL, "MFD MPG2VD DMA CB RDPTR",  NULL},
  {"MPG2VD_DMA_CB_WRPTR",              0x03920, NULL, "MFD MPG2VD DMA CB WRPTR",  NULL},
  {"MPG2VD_DMA_SDLINK",                0x03924, NULL, "MFD MPG2VD DMA SDLINK",    NULL},
  {"MPG2VD_DMA_SDLLSA",                0x03928, NULL, "MFD MPG2VD DMA SDLLSA",    NULL},
  {"MPG2VD_DMA_SDLNDA",                0x0392C, NULL, "MFD MPG2VD DMA SDLNDA",    NULL},
  {"MPG2VD_DMA_SDLDBC",                0x03930, NULL, "MFD MPG2VD DMA SDLDBC",    NULL},
  {"MPG2VD_DMA_SDLCBC",                0x03934, NULL, "MFD MPG2VD DMA SDLCBC",    NULL},
  {"MPG2VD_DMA_SDLDC",                 0x03938, NULL, "MFD MPG2VD DMA SDLDC",     NULL},
  {"MPG2VD_DMA_FIFO",                  0x0393C, NULL, "MFD MPG2VD DMA FIFO",      NULL},
  {"MPG2VD_DMA_FIFO_STAT",             0x03940, NULL, "MFD MPG2VD DMA FIFO STAT", NULL},
  {"MPG2VD_DMA_INT_EN",                0x03944, NULL, "MFD MPG2VD DMA INT EN",    NULL},
  {"MPG2VD_DMA_INT_STAT",              0x03948, NULL, "MFD MPG2VD DMA INT STAT",  NULL},
  {"MPG2VD_DMA_BS_CNTR",               0x0394C, NULL, "MFD MPG2VD DMA BS CNTR",   NULL},

  /* Start Code Detector (SCD) */
  {"MPG2VD_SCD_XCR",                   0x03A00, g_csr_gen4_mfd_SCD_XCR, "MFD MPG2VD SCD XCR",    NULL},
  {"MPG2VD_SCD_XSCR1",                 0x03A04, NULL, "MFD MPG2VD SCD XSCR1",  NULL},
  {"MPG2VD_SCD_XSCR2",                 0x03A08, NULL, "MFD MPG2VD SCD XSCR2",  NULL},
  {"MPG2VD_SCD_FWPREA",                0x03A0C, NULL, "MFD MPG2VD SCD FWPREA", NULL},
  {"MPG2VD_SCD_FWCRTL",                0x03A10, g_csr_gen4_mfd_SCD_FWCTRL, "MFD MPG2VD SCD FWCRTL", NULL},
  {"MPG2VD_SCD_FWSTAT",                0x03A14, NULL, "MFD MPG2VD SCD FWSTAT", NULL},
  {"MPG2VD_SCD_WRCTRL",                0x03A18, NULL, "MFD MPG2VD SCD WRCTRL", NULL},
  {"MPG2VD_SCD_WRDATA",                0x03A1C, NULL, "MFD MPG2VD SCD WRDATA", NULL},

  /* PIP Scaler Registers */
  {"MPG2VD_PIP_CTRL",                  0x03B00, NULL, "MFD MPG2VD PIP CTRL",           NULL},
  {"MPG2VD_PIP_STAT",                  0x03B04, NULL, "MFD MPG2VD PIP STAT",           NULL},
  {"MPG2VD_PIP_CDYB",                  0x03B08, NULL, "MFD MPG2VD PIP CDYB",           NULL},
  {"MPG2VD_PIP_CDUB",                  0x03B0C, NULL, "MFD MPG2VD PIP CDUB",           NULL},
  {"MPG2VD_PIP_TST_CTRL",              0x03B10, NULL, "MFD MPG2VD PIP TST CTRL",       NULL},
  {"MPG2VD_PIP_TST_WR_DATA_LO",        0x03B14, NULL, "MFD MPG2VD PIP TST WR DATA LO", NULL},
  {"MPG2VD_PIP_TST_WR_DATA_HI",        0x03B18, NULL, "MFD MPG2VD PIP TST WR DATA HI", NULL},

  /*  H264 #1  (CS7051) 0x4000 to 0x4FFF */
  {"H264_1_SMP_RD",                    0x04000, NULL, "MFD H264 1 SMP RD",      NULL},
  {"H264_1_INT_EN_RD",                 0x04004, NULL, "MFD H264 1 INT EN RD",   NULL},
  {"H264_1_SMP_SET",                   0x04008, NULL, "MFD H264 1 SMP SET",     NULL},
  {"H264_1_SMP_CLR",                   0x0400C, NULL, "MFD H264 1 SMP CLR",     NULL},
  {"H264_1_SMP_MSK_SET",               0x04010, NULL, "MFD H264 1 SMP MSK SET", NULL},
  {"H264_1_SMP_MSK_CLR",               0x04014, NULL, "MFD H264 1 SMP MSK CLR", NULL},
  {"H264_1_HDAT",                      0x04018, NULL, "MFD H264 1 HDAT",        NULL},
  {"H264_1_SDDAT",                     0x0401C, NULL, "MFD H264 1 SDDAT",       NULL},
  {"H264_1_DQ_PUSH",                   0x04020, NULL, "MFD H264 1 DQ PUSH",     NULL},
  {"H264_1_DQ_STAT",                   0x04024, NULL, "MFD H264 1 DQ STAT",     NULL},
  {"H264_1_DPB_INIT",                  0x04040, NULL, "MFD H264 1 DPB INIT",    NULL},
  {"H264_1_DPB_FRM_SZ_STAT",           0x04044, NULL, "MFD H264 1 DPB FRM SZ STAT", NULL},
  {"H264_1_DPB_FRM_SZ_CTRL",           0x04048, NULL, "MFD H264 1 DPB FRM SZ CTRL", NULL},
  {"H264_1_DPB_NUMB_OVR",              0x0404C, NULL, "MFD H264 1 DPB NUMB OVR",    NULL},
  {"H264_1_DPB_FS_VALUES",             0x04050, NULL, "MFD H264 1 DPB FS VALUES",   NULL},
  {"H264_1_DPB_FS_OFFSET",             0x04054, NULL, "MFD H264 1 DPB FS OFFSET",   NULL},
  {"H264_1_FSD",                       0x04058, NULL, "MFD H264 1 FSD",             NULL},
  {"H264_1_DANGLING_FIELD",            0x0405C, NULL, "MFD H264 1 DANGLING FIELD",  NULL},
  {"H264_1_DISP_TAG",                  0x04060, NULL, "MFD H264 1 DISP TAG",            NULL},
  {"H264_1_DPB_MBI_ADDR_LUT_WR",       0x0407C, NULL, "MFD H264 1 DPB MBI ADDR LUT WR", NULL},
  {"H264_1_DPB_UV_ADDR_LUT_WR",        0x04080, NULL, "MFD H264 1 DPB UV ADDR LUT WR",  NULL},
  {"H264_1_DPB_Y_ADDR_LUT_WR",         0x04084, NULL, "MFD H264 1 DPB Y ADDR LUT WR",   NULL},
  {"H264_1_FRAME_CYC_COUNT",           0x04090, NULL, "MFD H264 1 FRAME CYC COUNT",     NULL},
  {"H264_1_IB_WAIT_COUNT",             0x04094, NULL, "MFD H264 1 IB WAIT COUNT",       NULL},
  {"H264_1_RBSP_COUNT",                0x04098, NULL, "MFD H264 1 RBSP COUNT",          NULL},
  {"H264_1_MPR_COUNT",                 0x0409C, NULL, "MFD H264 1 MPR COUNT",           NULL},
  {"H264_1_CORE_CONFIG",               0x040A0, NULL, "MFD H264 1 CORE CONFIG",         NULL},
  {"H264_1_INT_CTRL",                  0x040C0, NULL, "MFD H264 1 INT CTRL",            NULL},
  {"H264_1_INT_STAT",                  0x040C4, NULL, "MFD H264 1 INT STAT",            NULL},
  {"H264_1_SOFT_RST",                  0x040FC, NULL, "MFD H264 1 SOFT RST",            NULL},
  {"H264_1_BSD_PSR_STAT",              0x04100, NULL, "MFD H264 1 BSD PSR STAT",        NULL},
  {"H264_1_BSD_STAT",                  0x04104, NULL, "MFD H264 1 BSD STAT",            NULL},
  {"H264_1_BSD_RBSP_CTRL",             0x04110, NULL, "MFD H264 1 BSD RBSP CTRL",       NULL},
  {"H264_1_BSD_DATA",                  0x04114, NULL, "MFD H264 1 BSD DATA",            NULL},
  {"H264_1_BSD_NAL_TYPE",              0x04118, NULL, "MFD H264 1 BSD NAL TYPE",        NULL},
  {"H264_1_BSD_BBB_STAT",              0x0411C, NULL, "MFD H264 1 BSD BBB STAT",        NULL},
  {"H264_1_BSD_GUE_DEC",               0x04120, NULL, "MFD H264 1 BSD GUE DEC",         NULL},
  {"H264_1_BSD_GSE_DEC",               0x04124, NULL, "MFD H264 1 BSD GSE DEC",         NULL},
  {"H264_1_BSD_EXP_GME_INTRA",         0x04128, NULL, "MFD H264 1 BSD EXP GME_INTRA",   NULL},
  {"H264_1_BSD_EXP_GME_INTER",         0x04138, NULL, "MFD H264 1 BSD EXP GME_INTER",   NULL},
  {"H264_1_BSD_IMG_INIT",              0x04140, NULL, "MFD H264 1 BSD IMG INIT",        NULL},
  {"H264_1_BSD_SLICE_P1",              0x04150, NULL, "MFD H264 1 BSD SLICE P1",        NULL},
  {"H264_1_BSD_SLICE_P2",              0x04154, NULL, "MFD H264 1 BSD SLICE P2",        NULL},
  {"H264_1_BSD_SLICE_START",           0x04158, NULL, "MFD H264 1 BSD SLICE START",     NULL},
  {"H264_1_BSD_MB_CTRL",               0x0415C, NULL, "MFD H264 1 BSD MB CTRL",         NULL},
  {"H264_1_BSD_QM_DEC_START",          0x04160, NULL, "MFD H264 1 BSD QM DEC START",    NULL},
  {"H264_1_BSD_DEC_STAT",              0x04164, NULL, "MFD H264 1 BSD DEC STAT",        NULL},
  {"H264_1_BSD_QM_LOAD_START",         0x04168, NULL, "MFD H264 1 BSD QM LOAD START",   NULL},
  {"H264_1_BSD_QM_LOAD_VALUE",         0x0416C, NULL, "MFD H264 1 BSD QM LOAD VALUE",   NULL},
  {"H264_1_BSD_BYTE_ALIGN",            0x0417C, NULL, "MFD H264 1 BSD BYTE ALIGN", NULL},
  {"H264_1_BSD_BBB_TRAIL",             0x04180, NULL, "MFD H264 1 BSD BBB TRAIL",  NULL},
  {"H264_1_BSD_GET_BITS01",            0x04184, NULL, "MFD H264 1 BSD GET BITS01", NULL},
  {"H264_1_BSD_GET_BITS02",            0x04188, NULL, "MFD H264 1 BSD GET BITS02", NULL},
  {"H264_1_BSD_GET_BITS03",            0x0418C, NULL, "MFD H264 1 BSD GET BITS03", NULL},
  {"H264_1_BSD_GET_BITS04",            0x04190, NULL, "MFD H264 1 BSD GET BITS04", NULL},
  {"H264_1_BSD_GET_BITS05",            0x04194, NULL, "MFD H264 1 BSD GET BITS05", NULL},
  {"H264_1_BSD_GET_BITS06",            0x04198, NULL, "MFD H264 1 BSD GET BITS06", NULL},
  {"H264_1_BSD_GET_BITS07",            0x0419C, NULL, "MFD H264 1 BSD GET BITS07", NULL},
  {"H264_1_BSD_GET_BITS08",            0x041A0, NULL, "MFD H264 1 BSD GET BITS08", NULL},
  {"H264_1_BSD_GET_BITS09",            0x041A4, NULL, "MFD H264 1 BSD GET BITS09", NULL},
  {"H264_1_BSD_GET_BITS10",            0x041A8, NULL, "MFD H264 1 BSD GET BITS10", NULL},
  {"H264_1_BSD_GET_BITS11",            0x041AC, NULL, "MFD H264 1 BSD GET BITS11", NULL},
  {"H264_1_BSD_GET_BITS12",            0x041B0, NULL, "MFD H264 1 BSD GET BITS12", NULL},
  {"H264_1_BSD_GET_BITS13",            0x041B4, NULL, "MFD H264 1 BSD GET BITS13", NULL},
  {"H264_1_BSD_GET_BITS14",            0x041B8, NULL, "MFD H264 1 BSD GET BITS14", NULL},
  {"H264_1_BSD_GET_BITS15",            0x041BC, NULL, "MFD H264 1 BSD GET BITS15", NULL},
  {"H264_1_BSD_GET_BITS16",            0x041C0, NULL, "MFD H264 1 BSD GET BITS16", NULL},
  {"H264_1_BSD_GET_BITS17",            0x041C4, NULL, "MFD H264 1 BSD GET BITS17", NULL},
  {"H264_1_BSD_GET_BITS18",            0x041C8, NULL, "MFD H264 1 BSD GET BITS18", NULL},
  {"H264_1_BSD_GET_BITS19",            0x041CC, NULL, "MFD H264 1 BSD GET BITS19", NULL},
  {"H264_1_BSD_GET_BITS20",            0x041D0, NULL, "MFD H264 1 BSD GET BITS20", NULL},
  {"H264_1_BSD_GET_BITS21",            0x041D4, NULL, "MFD H264 1 BSD GET BITS21", NULL},
  {"H264_1_BSD_GET_BITS22",            0x041D8, NULL, "MFD H264 1 BSD GET BITS22", NULL},
  {"H264_1_BSD_GET_BITS23",            0x041DC, NULL, "MFD H264 1 BSD GET BITS23", NULL},
  {"H264_1_BSD_GET_BITS24",            0x041E0, NULL, "MFD H264 1 BSD GET BITS24", NULL},
  {"H264_1_BSD_GET_BITS25",            0x041E4, NULL, "MFD H264 1 BSD GET BITS25", NULL},
  {"H264_1_BSD_GET_BITS26",            0x041E8, NULL, "MFD H264 1 BSD GET BITS26", NULL},
  {"H264_1_BSD_GET_BITS27",            0x041EC, NULL, "MFD H264 1 BSD GET BITS27", NULL},
  {"H264_1_BSD_GET_BITS28",            0x041F0, NULL, "MFD H264 1 BSD GET BITS28", NULL},
  {"H264_1_BSD_GET_BITS29",            0x041F4, NULL, "MFD H264 1 BSD GET BITS29", NULL},
  {"H264_1_BSD_GET_BITS30",            0x041F8, NULL, "MFD H264 1 BSD GET BITS30", NULL},
  {"H264_1_BSD_GET_BITS31",            0x041FC, NULL, "MFD H264 1 BSD GET BITS31", NULL},
  {"H264_1_MPR_TF_POC",                0x04300, NULL, "MFD H264 1 MPR TF POC", NULL},
  {"H264_1_MPR_BF_POC",                0x04304, NULL, "MFD H264 1 MPR BF POC", NULL},
  {"H264_1_MPR_LST00",                 0x04380, NULL, "MFD H264 1 MPR LST00",  NULL},
  {"H264_1_MPR_LST01",                 0x04384, NULL, "MFD H264 1 MPR LST01",  NULL},
  {"H264_1_MPR_LST02",                 0x04388, NULL, "MFD H264 1 MPR LST02",  NULL},
  {"H264_1_MPR_LST03",                 0x0438C, NULL, "MFD H264 1 MPR LST03",  NULL},
  {"H264_1_MPR_LST04",                 0x04390, NULL, "MFD H264 1 MPR LST04",  NULL},
  {"H264_1_MPR_LST05",                 0x04394, NULL, "MFD H264 1 MPR LST05",  NULL},
  {"H264_1_MPR_LST06",                 0x04398, NULL, "MFD H264 1 MPR LST06",  NULL},
  {"H264_1_MPR_LST07",                 0x0439C, NULL, "MFD H264 1 MPR LST07",  NULL},
  {"H264_1_MPR_LST08",                 0x043A0, NULL, "MFD H264 1 MPR LST08",  NULL},
  {"H264_1_MPR_LST09",                 0x043A4, NULL, "MFD H264 1 MPR LST09",  NULL},
  {"H264_1_MPR_LST10",                 0x043A8, NULL, "MFD H264 1 MPR LST10",  NULL},
  {"H264_1_MPR_LST11",                 0x043AC, NULL, "MFD H264 1 MPR LST11",  NULL},
  {"H264_1_MPR_LST12",                 0x043B0, NULL, "MFD H264 1 MPR LST12",  NULL},
  {"H264_1_MPR_LST13",                 0x043B4, NULL, "MFD H264 1 MPR LST13",  NULL},
  {"H264_1_MPR_LST14",                 0x043B8, NULL, "MFD H264 1 MPR LST14",  NULL},
  {"H264_1_MPR_LST15",                 0x043BC, NULL, "MFD H264 1 MPR LST15",  NULL},

  /* SIF and Stream Control */
  {"H264_1_RSB_DDR_BA",                0x04808, NULL, "MFD H264 1 RSB DDR BA", NULL},
  /* contains 2 status bits (bs_ib_empty and frm_dec_active) */
  {"H264_1_DEC_STATUS",                0x0480C, NULL, "MFD H264 1 DEC STATUS", NULL},
  {"H264_1_SIF_SMP_RS",                0x04810, NULL, "MFD H264 1 SIF SMP RS", NULL},
  {"H264_1_SIF_MSK_RS",                0x04814, NULL, "MFD H264 1 SIF MSK RS", NULL},
  {"H264_1_SIF_HDAT",                  0x04818, NULL, "MFD H264 1 SIF HDAT",   NULL},
  {"H264_1_SIF_SDDAT",                 0x0481C, NULL, "MFD H264 1 SIF SDDAT",  NULL},
  {"H264_1_SIF_SMP_RC",                0x04820, NULL, "MFD H264 1 SIF SMP RC", NULL},
  {"H264_1_SIF_MSK_RC",                0x04824, NULL, "MFD H264 1 SIF MSK RC", NULL},

  /* Stream DMA */
  {"H264_1_SED",                       0x04900, NULL, "MFD H264 1 SED",           NULL},
  {"H264_1_SDEMC",                     0x04904, NULL, "MFD H264 1 SDEMC",         NULL},
  {"H264_1_DMA_CB_BASE",               0x04908, NULL, "MFD H264 1 DMA CB BASE",   NULL},
  {"H264_1_DMA_SB_RDPTR",              0x0490C, NULL, "MFD H264 1 DMA SB RDPTR",  NULL},
  {"H264_1_DMA_CB_SIZE",               0x04910, NULL, "MFD H264 1 DMA CB SIZE",   NULL},
  {"H264_1_DMA_WTRMARK",               0x04914, NULL, "MFD H264 1 DMA WTRMARK",   NULL},
  {"H264_1_DMA_WDT",                   0x04918, NULL, "MFD H264 1 DMA WDT",       NULL},
  {"H264_1_DMA_CB_RDPTR",              0x0491C, NULL, "MFD H264 1 DMA CB RDPTR",  NULL},
  {"H264_1_DMA_CB_WRPTR",              0x04920, NULL, "MFD H264 1 DMA CB WRPTR",  NULL},
  {"H264_1_DMA_SDLINK",                0x04924, NULL, "MFD H264 1 DMA SDLINK",    NULL},
  {"H264_1_DMA_SDLLSA",                0x04928, NULL, "MFD H264 1 DMA SDLLSA",    NULL},
  {"H264_1_DMA_SDLNDA",                0x0492C, NULL, "MFD H264 1 DMA SDLNDA",    NULL},
  {"H264_1_DMA_SDLDBC",                0x04930, NULL, "MFD H264 1 DMA SDLDBC",    NULL},
  {"H264_1_DMA_SDLCBC",                0x04934, NULL, "MFD H264 1 DMA SDLCBC",    NULL},
  {"H264_1_DMA_SDLDC",                 0x04938, NULL, "MFD H264 1 DMA SDLDC",     NULL},
  {"H264_1_DMA_FIFO",                  0x0493C, NULL, "MFD H264 1 DMA FIFO",      NULL},
  {"H264_1_DMA_FIFO_STAT",             0x04940, NULL, "MFD H264 1 DMA FIFO STAT", NULL},
  {"H264_1_DMA_INT_EN",                0x04944, NULL, "MFD H264 1 DMA INT EN",    NULL},
  {"H264_1_DMA_INT_STAT",              0x04948, NULL, "MFD H264 1 DMA INT STAT",  NULL},
  {"H264_1_DMA_BS_CNTR",               0x0494C, NULL, "MFD H264 1 DMA BS CNTR",   NULL},
  /* Start Code Detector (SCD) */
  {"H264_1_SCD_XCR",                   0x04A00, g_csr_gen4_mfd_SCD_XCR, "MFD H264 1 SCD XCR",            NULL},
  {"H264_1_SCD_XSCR1",                 0x04A04, NULL, "MFD H264 1 SCD XSCR1",          NULL},
  {"H264_1_SCD_XSCR2",                 0x04A08, NULL, "MFD H264 1 SCD XSCR2",          NULL},
  {"H264_1_SCD_FWPREAD",               0x04A0C, NULL, "MFD H264 1 SCD FWPREAD",        NULL},
  {"H264_1_SCD_FWCRTL",                0x04A10, g_csr_gen4_mfd_SCD_FWCTRL, "MFD H264 1 SCD FWCRTL",         NULL},
  {"H264_1_SCD_FWSTAT",                0x04A14, NULL, "MFD H264 1 SCD FWSTAT",         NULL},
  {"H264_1_SCD_WRCTRL",                0x04A18, NULL, "MFD H264 1 SCD WRCTRL",         NULL},
  {"H264_1_SCD_WRDATA",                0x04A1C, NULL, "MFD H264 1 SCD WRDATA",         NULL},

  /* PIP Scaler Registers */
  {"H264_1_PIP_CTRL",                  0x04B00, NULL, "MFD H264 1 PIP CTRL",           NULL},
  {"H264_1_PIP_STAT",                  0x04B04, NULL, "MFD H264 1 PIP STAT",           NULL},
  {"H264_1_PIP_CDYB",                  0x04B08, NULL, "MFD H264 1 PIP CDYB",           NULL},
  {"H264_1_PIP_CDUB",                  0x04B0C, NULL, "MFD H264 1 PIP CDUB",           NULL},
  {"H264_1_PIP_TST_CTRL",              0x04B10, NULL, "MFD H264 1 PIP TST CTRL",       NULL},
  {"H264_1_PIP_TST_WR_DATA_LO",        0x04B14, NULL, "MFD H264 1 PIP TST WR DATA LO", NULL},
  {"H264_1_PIP_TST_WR_DATA_HI",        0x04B18, NULL, "MFD H264 1 PIP TST WR DATA HI", NULL},

  /* VC1 #0 (CS7150) 0x5000 to 0x5FFF */
  {"VC1_1_SMP_RD",                     0x05000, NULL, "MFD VC1 1 SMP RD",             NULL},
  {"VC1_1_INT_EN_RD",                  0x05004, NULL, "MFD VC1 1 INT EN RD",          NULL},
  {"VC1_1_SMP_SET",                    0x05008, NULL, "MFD VC1 1 SMP SET",            NULL},
  {"VC1_1_SMP_CLR",                    0x0500C, NULL, "MFD VC1 1 SMP CLR",            NULL},
  {"VC1_1_SMP_MSK_SET",                0x05010, NULL, "MFD VC1 1 SMP MSK SET",        NULL},
  {"VC1_1_SMP_MSK_CLR",                0x05014, NULL, "MFD VC1 1 SMP MSK CLR",        NULL},
  {"VC1_1_HDAT",                       0x05018, NULL, "MFD VC1 1 HDAT",               NULL},
  {"VC1_1_SDDAT",                      0x0501C, NULL, "MFD VC1 1 SDDAT",              NULL},
  {"VC1_1_DQ_PUSH",                    0x05020, NULL, "MFD VC1 1 DQ PUSH",            NULL},
  {"VC1_1_DQ_STAT",                    0x05024, NULL, "MFD VC1 1 DQ STAT",            NULL},
  {"VC1_1_DPB_INIT",                   0x05040, NULL, "MFD VC1 1 DPB INIT",           NULL},
  {"VC1_1_DPB_FRM_SZ_STAT",            0x05044, NULL, "MFD VC1 1 DPB FRM SZ STAT",    NULL},
  {"VC1_1_DPB_FRM_SZ_CTRL",            0x05048, NULL, "MFD VC1 1 DPB FRM SZ CTRL",    NULL},
  {"VC1_1_DPB_NUMB_OVR",               0x0504C, NULL, "MFD VC1 1 DPB NUMB OVR",       NULL},
  {"VC1_1_DPB_FS_SETTING",             0x05050, NULL, "MFD VC1 1 DPB FS SETTING",     NULL},
  {"VC1_1_DPB_LOAD_OFFSET",            0x05054, NULL, "MFD VC1 1 DPB LOAD OFFSET",    NULL},
  {"VC1_1_FSD",                        0x05058, NULL, "MFD VC1 1 FSD",                NULL},
  {"VC1_1_DANGLING_FIELD",             0x0505C, NULL, "MFD VC1 1 DANGLING FIELD",     NULL},
  {"VC1_1_DISP_TAG",                   0x05060, NULL, "MFD VC1 1 DISP TAG",           NULL},
  {"VC1_1_DPB_UV_ADDR_LUT_WR",         0x02080, NULL, "MFD VC1 1 DPB UV ADDR LUT WR", NULL},
  {"VC1_1_DPB_Y_ADDR_LUT_WR",          0x02084, NULL, "MFD VC1 1 DPB Y ADDR LUT WR",  NULL},
  {"VC1_1_MPS_RD_BYTE_COUNT",          0x05088, NULL, "MFD VC1 1 MPS RD BYTE COUNT",  NULL},
  {"VC1_1_SLC_IN_FRM_COUNT",           0x0508C, NULL, "MFD VC1 1 SLC IN FRM COUNT",   NULL},
  {"VC1_1_FRAME_CYC_COUNT",            0x05090, NULL, "MFD VC1 1 FRAME CYC COUNT",    NULL},
  {"VC1_1_IB_WAIT_COUNT",              0x05094, NULL, "MFD VC1 1 IB WAIT COUNT",      NULL},
  {"VC1_1_RBSP_COUNT",                 0x05098, NULL, "MFD VC1 1 RBSP COUNT",     NULL},
  {"VC1_1_BS2RBSP_STATUS",             0x0509C, NULL, "MFD VC1 1 BS2RBSP STATUS", NULL},
  {"VC1_1_CORE_CONFIG",                0x050A0, NULL, "MFD VC1 1 CORE CONFIG",    NULL},
  {"VC1_1_RBSP_CTRL",                  0x050A4, NULL, "MFD VC1 1 RBSP CTRL",      NULL},
  {"VC1_1_INT_CTRL",                   0x050C0, NULL, "MFD VC1 1 INT CTRL",       NULL},
  {"VC1_1_INT_STAT",                   0x050C4, NULL, "MFD VC1 1 INT STAT",       NULL},
  {"VC1_1_SOFT_RST",                   0x050C8, NULL, "MFD VC1 1 SOFT RST",       NULL},
  {"VC1_1_BSP_BYTE_ALIGN",             0x05100, NULL, "MFD VC1 1 BSP BYTE ALIGN", NULL},
  {"VC1_1_BSP_GET_BITS01",             0x05104, NULL, "MFD VC1 1 BSP GET BITS01", NULL},
  {"VC1_1_BSP_GET_BITS02",             0x05108, NULL, "MFD VC1 1 BSP GET BITS02", NULL},
  {"VC1_1_BSP_GET_BITS03",             0x0510C, NULL, "MFD VC1 1 BSP GET BITS03", NULL},
  {"VC1_1_BSP_GET_BITS04",             0x05110, NULL, "MFD VC1 1 BSP GET BITS04", NULL},
  {"VC1_1_BSP_GET_BITS05",             0x05114, NULL, "MFD VC1 1 BSP GET BITS05", NULL},
  {"VC1_1_BSP_GET_BITS06",             0x05118, NULL, "MFD VC1 1 BSP GET BITS06", NULL},
  {"VC1_1_BSP_GET_BITS07",             0x0511C, NULL, "MFD VC1 1 BSP GET BITS07", NULL},
  {"VC1_1_BSP_GET_BITS08",             0x05120, NULL, "MFD VC1 1 BSP GET BITS08", NULL},
  {"VC1_1_BSP_GET_BITS09",             0x05124, NULL, "MFD VC1 1 BSP GET BITS09", NULL},
  {"VC1_1_BSP_GET_BITS10",             0x05128, NULL, "MFD VC1 1 BSP GET BITS10", NULL},
  {"VC1_1_BSP_GET_BITS11",             0x0512C, NULL, "MFD VC1 1 BSP GET BITS11", NULL},
  {"VC1_1_BSP_GET_BITS12",             0x05130, NULL, "MFD VC1 1 BSP GET BITS12", NULL},
  {"VC1_1_BSP_GET_BITS13",             0x05134, NULL, "MFD VC1 1 BSP GET BITS13", NULL},
  {"VC1_1_BSP_GET_BITS14",             0x05138, NULL, "MFD VC1 1 BSP GET BITS14", NULL},
  {"VC1_1_BSP_GET_BITS15",             0x0513C, NULL, "MFD VC1 1 BSP GET BITS15", NULL},
  {"VC1_1_BSP_GET_BITS16",             0x05140, NULL, "MFD VC1 1 BSP GET BITS16", NULL},
  {"VC1_1_BSP_GET_BITS17",             0x05144, NULL, "MFD VC1 1 BSP GET BITS17", NULL},
  {"VC1_1_BSP_GET_BITS18",             0x05148, NULL, "MFD VC1 1 BSP GET BITS18", NULL},
  {"VC1_1_BSP_GET_BITS19",             0x0514C, NULL, "MFD VC1 1 BSP GET BITS19", NULL},
  {"VC1_1_BSP_GET_BITS20",             0x05150, NULL, "MFD VC1 1 BSP GET BITS20", NULL},
  {"VC1_1_BSP_GET_BITS21",             0x05154, NULL, "MFD VC1 1 BSP GET BITS21", NULL},
  {"VC1_1_BSP_GET_BITS22",             0x05158, NULL, "MFD VC1 1 BSP GET BITS22", NULL},
  {"VC1_1_BSP_GET_BITS23",             0x0515C, NULL, "MFD VC1 1 BSP GET BITS23", NULL},
  {"VC1_1_BSP_GET_BITS24",             0x05160, NULL, "MFD VC1 1 BSP GET BITS24", NULL},
  {"VC1_1_BSP_GET_BITS25",             0x05164, NULL, "MFD VC1 1 BSP GET BITS25", NULL},
  {"VC1_1_BSP_GET_BITS26",             0x05168, NULL, "MFD VC1 1 BSP GET BITS26", NULL},
  {"VC1_1_BSP_GET_BITS27",             0x0516C, NULL, "MFD VC1 1 BSP GET BITS27", NULL},
  {"VC1_1_BSP_GET_BITS28",             0x05170, NULL, "MFD VC1 1 BSP GET BITS28", NULL},
  {"VC1_1_BSP_GET_BITS29",             0x05174, NULL, "MFD VC1 1 BSP GET BITS29", NULL},
  {"VC1_1_BSP_GET_BITS30",             0x05178, NULL, "MFD VC1 1 BSP GET BITS30", NULL},
  {"VC1_1_BSP_GET_BITS31",             0x0517C, NULL, "MFD VC1 1 BSP GET BITS31", NULL},
  {"VC1_1_BSP_STATUS",                 0x05180, NULL, "MFD VC1 1 BSP STATUS",     NULL},
  {"VC1_1_BSP_CTRL",                   0x05184, NULL, "MFD VC1 1 BSP CTRL",       NULL},
  {"VC1_1_BSP_SHOW_BITS",              0x05188, NULL, "MFD VC1 1 BSP SHOW BITS",  NULL},
  {"VC1_1_BSP_SHOW_BITS_FLPD",         0x0518C, NULL, "MFD VC1 1 BSP SHOW BITS FLPD",   NULL},
  {"VC1_1_BSP_IGNORE_BBB_LEVEL",       0x05190, NULL, "MFD VC1 1 BSP IGNORE BBB LEVEL", NULL},
  {"VC1_1_BSP_HEADER_VLC_PTYPE",       0x051C0, NULL, "MFD VC1 1 BSP HEADER VLC PTYPE", NULL},
  {"VC1_1_BSP_HEADER_VLC_FTYPE",       0x051C4, NULL, "MFD VC1 1 BSP HEADER VLC FTYPE", NULL},
  {"VC1_1_BSP_HEADER_VLC_MVRANGE",     0x051C8, NULL, "MFD VC1 1 BSP HEADER VLC MVRANGE",     NULL},
  {"VC1_1_BSP_HEADER_VLC_MVMODE",      0x051CC, NULL, "MFD VC1 1 BSP HEADER VLC MVMODE",      NULL},
  {"VC1_1_BSP_HEADER_VLC_MVMODE2",     0x051D0, NULL, "MFD VC1 1 BSP HEADER VLC MVMODE2",     NULL},
  {"VC1_1_BSP_HEADER_VLC_DMVRANGE",    0x051D4, NULL, "MFD VC1 1 BSP HEADER VLC DMVRANGE",    NULL},
  {"VC1_1_BSP_HEADER_VLC_BPPMODE",     0x051D8, NULL, "MFD VC1 1 BSP HEADER VLC BPPMODE",     NULL},
  {"VC1_1_BSP_HEADER_VLC_BPPVLC2",     0x051DC, NULL, "MFD VC1 1 BSP HEADER VLC BPPVLC2",     NULL},
  {"VC1_1_BSP_HEADER_VLC_BPPVLC6",     0x051E0, NULL, "MFD VC1 1 BSP HEADER VLC BPPVLC6",     NULL},
  {"VC1_1_BSP_HEADER_VLC_BFRACT",      0x051E4, NULL, "MFD VC1 1 BSP HEADER VLC BFRACT",      NULL},
  {"VC1_1_BSP_HEADER_VLC_REFDIST",     0x051E8, NULL, "MFD VC1 1 BSP HEADER VLC REFDIST",     NULL},
  {"VC1_1_SEQPIC_GENERAL_CORE_CONFIG", 0x05200, NULL, "MFD VC1 1 SEQPIC GENERAL CORE CONFIG", NULL},
  {"VC1_1_SEQPIC_STREAM_FORMAT_1",     0x05204, NULL, "MFD VC1 1 SEQPIC STREAM FORMAT 1",     NULL},
  {"VC1_1_SEQPIC_CODED_SIZE",          0x05208, NULL, "MFD VC1 1 SEQPIC CODED SIZE",          NULL},
  {"VC1_1_SEQPIC_STREAM_FORMAT_2",     0x0520C, NULL, "MFD VC1 1 SEQPIC STREAM FORMAT 2",     NULL},
  {"VC1_1_SEQPIC_ENTRY_POINT_1",       0x05210, NULL, "MFD VC1 1 SEQPIC ENTRY POINT 1",       NULL},
  {"VC1_1_SEQPIC_RANGE_MAP",           0x05214, NULL, "MFD VC1 1 SEQPIC RANGE MAP",           NULL},
  {"VC1_1_SEQPIC_FRAME_TYPE",          0x05218, NULL, "MFD VC1 1 SEQPIC FRAME TYPE",          NULL},
  {"VC1_1_SEQPIC_RECON_CONTROL",       0x0521C, NULL, "MFD VC1 1 SEQPIC RECON CONTROL",       NULL},
  {"VC1_1_SEQPIC_MOTION_VECTOR_CONTROL",  0x05220, NULL, "MFD VC1 1 SEQPIC MOTION VECTOR CONTROL",  NULL},
  {"VC1_1_SEQPIC_INTENSITY_COMPENSATION", 0x05224, NULL, "MFD VC1 1 SEQPIC INTENSITY COMPENSATION", NULL},
  {"VC1_1_SEQPIC_REFERENCE_B_FRACTION", 0x05228, NULL, "MFD VC1 1 SEQPIC REFERENCE B FRACTION", NULL},
  {"VC1_1_SEQPIC_BLOCK_CONTROL",        0x0522C, NULL, "MFD VC1 1 SEQPIC BLOCK CONTROL",        NULL},
  {"VC1_1_SEQPIC_TRANSFORM_DATA",       0x05230, NULL, "MFD VC1 1 SEQPIC TRANSFORM DATA",       NULL},
  {"VC1_1_SEQPIC_VOP_DEQUANT",          0x05234, NULL, "MFD VC1 1 SEQPIC VOP DEQUANT",          NULL},
  {"VC1_1_SEQPIC_CURR_FRAME_ID",        0x05238, NULL, "MFD VC1 1 SEQPIC CURR FRAME ID",        NULL},
  {"VC1_1_SEQPIC_CURR_DISPLAY_ID",      0x0523C, NULL, "MFD VC1 1 SEQPIC CURR DISPLAY ID",      NULL},
  {"VC1_1_SEQPIC_FWD_REF_FRAME_ID",     0x05240, NULL, "MFD VC1 1 SEQPIC FWD REF FRAME ID",     NULL},
  {"VC1_1_SEQPIC_BWD_REF_FRAME_ID",     0x05244, NULL, "MFD VC1 1 SEQPIC BWD REF FRAME ID",     NULL},
  {"VC1_1_SEQPIC_FIELD_REF_FRAME_ID",   0x05248, NULL, "MFD VC1 1 SEQPIC FIELD REF FRAME ID",   NULL},
  {"VC1_1_SEQPIC_AUX_FRAME_CONTROL",    0x0524C, NULL, "MFD VC1 1 SEQPIC AUX FRAME CONTROL",    NULL},
  {"VC1_1_SEQPIC_IMAGE_STRUCTURE",      0x05250, NULL, "MFD VC1 1 SEQPIC IMAGE STRUCTURE",      NULL},
  {"VC1_1_SEQPIC_ALT_FRAME_TYPE",       0x05254, NULL, "MFD VC1 1 SEQPIC ALT FRAME TYPE",       NULL},
  {"VC1_1_MBDEC_STATUS",                0x05300, NULL, "MFD VC1 1 MBDEC STATUS",                NULL},
  {"VC1_1_MBDEC_FRAME_START",           0x05304, NULL, "MFD VC1 1 MBDEC FRAME START",           NULL},
  {"VC1_1_MBDEC_FW_DEBUG",              0x05308, NULL, "MFD VC1 1 MBDEC FW DEBUG",              NULL},
  {"VC1_1_MBDEC_MBQDEBUG",              0x0530C, NULL, "MFD VC1 1 MBDEC MBQDEBUG",              NULL},
  {"VC1_1_MBDEC_MPRDEBUG",              0x05310, NULL, "MFD VC1 1 MBDEC MPRDEBUG",              NULL},
  {"VC1_1_MBDEC_MASDEBUG",              0x05314, NULL, "MFD VC1 1 MBDEC MASDEBUG",              NULL},
  {"VC1_1_MBDEC_BPPDEBUG",              0x05318, NULL, "MFD VC1 1 MBDEC BPPDEBUG",              NULL},
  {"VC1_1_MBDEC_DPBMCDEBUG",            0x0531C, NULL, "MFD VC1 1 MBDEC DPBMCDEBUG",            NULL},
  {"VC1_1_MBDEC_GENDEBUG",              0x05320, NULL, "MFD VC1 1 MBDEC GENDEBUG",              NULL},
  {"VC1_1_FW_DEBUG",                    0x05324, NULL, "MFD VC1 1 FW DEBUG",                    NULL},
  {"VC1_1_MBDEC_ERROR_CONCEAL_CONTROL", 0x05340, NULL, "MFD VC1 1 MBDEC ERROR CONCEAL CONTROL", NULL},
  {"VC1_1_BP_CONTROL_STATUS",           0x05400, NULL, "MFD VC1 1 BP CONTROL STATUS",           NULL},
  {"VC1_1_BP_DATA_IN_STATUS",           0x05404, NULL, "MFD VC1 1 BP DATA IN STATUS",           NULL},
  {"VC1_1_BP_DATA_IN_VALUE",            0x05408, NULL, "MFD VC1 1 BP DATA IN VALUE",            NULL},
  {"VC1_1_BP_DATA_IN_POSITION_N_SIZE",  0x0540C, NULL, "MFD VC1 1 BP DATA IN POSITION N SIZE",  NULL},

  /* SIF and Stream Control */
  {"VC1_1_MBA_ENABLE",                  0x05800, NULL, "MFD VC1 1 MBA ENABLE", NULL},
  {"VC1_1_RSB_DDR_BA",                  0x05808, NULL, "MFD VC1 1 RSB DDR BA", NULL},
  /* contains 2 status bits (bs_ib_empty and frm_dec_active) */
  {"VC1_1_DEC_STATUS",                  0x0580C, NULL, "MFD VC1 1 DEC STATUS", NULL},
  {"VC1_1_SIF_SMP_RS",                  0x05810, NULL, "MFD VC1 1 SIF SMP RS", NULL},
  {"VC1_1_SIF_MSK_RS",                  0x05814, NULL, "MFD VC1 1 SIF MSK RS", NULL},
  {"VC1_1_SIF_HDAT",                    0x05818, NULL, "MFD VC1 1 SIF HDAT",   NULL},
  {"VC1_1_SIF_SDDAT",                   0x0581C, NULL, "MFD VC1 1 SIF SDDAT",  NULL},
  {"VC1_1_SIF_SMP_RC",                  0x05820, NULL, "MFD VC1 1 SIF SMP RC", NULL},
  {"VC1_1_SIF_MSK_RC",                  0x05824, NULL, "MFD VC1 1 SIF MSK RC", NULL},

  /* Stream DMA */
  {"VC1_1_SED",                         0x05900, NULL, "MFD VC1 1 SED",           NULL},
  {"VC1_1_SDEMC",                       0x05904, NULL, "MFD VC1 1 SDEMC",         NULL},
  {"VC1_1_DMA_CB_BASE",                 0x05908, NULL, "MFD VC1 1 DMA CB BASE",   NULL},
  {"VC1_1_DMA_SB_RDPTR",                0x0590C, NULL, "MFD VC1 1 DMA SB RDPTR",  NULL},
  {"VC1_1_DMA_CB_SIZE",                 0x05910, NULL, "MFD VC1 1 DMA CB SIZE",   NULL},
  {"VC1_1_DMA_WTRMARK",                 0x05914, NULL, "MFD VC1 1 DMA WTRMARK",   NULL},
  {"VC1_1_DMA_WDT",                     0x05918, NULL, "MFD VC1 1 DMA WDT",       NULL},
  {"VC1_1_DMA_CB_RDPTR",                0x0591C, NULL, "MFD VC1 1 DMA CB RDPTR",  NULL},
  {"VC1_1_DMA_CB_WRPTR",                0x05920, NULL, "MFD VC1 1 DMA CB WRPTR",  NULL},
  {"VC1_1_DMA_SDLINK",                  0x05924, NULL, "MFD VC1 1 DMA SDLINK",    NULL},
  {"VC1_1_DMA_SDLLSA",                  0x05928, NULL, "MFD VC1 1 DMA SDLLSA",    NULL},
  {"VC1_1_DMA_SDLNDA",                  0x0592C, NULL, "MFD VC1 1 DMA SDLNDA",    NULL},
  {"VC1_1_DMA_SDLDBC",                  0x05930, NULL, "MFD VC1 1 DMA SDLDBC",    NULL},
  {"VC1_1_DMA_SDLCBC",                  0x05934, NULL, "MFD VC1 1 DMA SDLCBC",    NULL},
  {"VC1_1_DMA_SDLDC",                   0x05938, NULL, "MFD VC1 1 DMA SDLDC",     NULL},
  {"VC1_1_DMA_FIFO",                    0x0593C, NULL, "MFD VC1 1 DMA FIFO",      NULL},
  {"VC1_1_DMA_FIFO_STAT",               0x05940, NULL, "MFD VC1 1 DMA FIFO STAT", NULL},
  {"VC1_1_DMA_INT_EN",                  0x05944, NULL, "MFD VC1 1 DMA INT EN",    NULL},
  {"VC1_1_DMA_INT_STAT",                0x05948, NULL, "MFD VC1 1 DMA INT STAT",  NULL},
  {"VC1_1_DMA_BS_CNTR",                 0x0594C, NULL, "MFD VC1 1 DMA BS CNTR",   NULL},

  /* Start Code Detector (SCD) */
  {"VC1_1_SCD_XCR",                     0x05A00, g_csr_gen4_mfd_SCD_XCR, "MFD VC1 1 SCD XCR",     NULL},
  {"VC1_1_SCD_XSCR1",                   0x05A04, NULL, "MFD VC1 1 SCD XSCR1",   NULL},
  {"VC1_1_SCD_XSCR2",                   0x05A08, NULL, "MFD VC1 1 SCD XSCR2",   NULL},
  {"VC1_1_SCD_FWPREAD",                 0x05A0C, NULL, "MFD VC1 1 SCD FWPREAD", NULL},
  {"VC1_1_SCD_FWCRTL",                  0x05A10, g_csr_gen4_mfd_SCD_FWCTRL, "MFD VC1 1 SCD FWCRTL",  NULL},
  {"VC1_1_SCD_FWSTAT",                  0x05A14, NULL, "MFD VC1 1 SCD FWSTAT",  NULL},
  {"VC1_1_SCD_WRCTRL",                  0x05A18, NULL, "MFD VC1 1 SCD WRCTRL",  NULL},
  {"VC1_1_SCD_WRDATA",                  0x05A1C, NULL, "MFD VC1 1 SCD WRDATA",  NULL},

  /* PIP Scaler Registers */
  {"VC1_1_PIP_CTRL",                    0x05B00, NULL, "MFD VC1 1 PIP CTRL",           NULL},
  {"VC1_1_PIP_STAT",                    0x05B04, NULL, "MFD VC1 1 PIP STAT",           NULL},
  {"VC1_1_PIP_CDYB",                    0x05B08, NULL, "MFD VC1 1 PIP CDYB",           NULL},
  {"VC1_1_PIP_CDUB",                    0x05B0c, NULL, "MFD VC1 1 PIP CDUB",           NULL},
  {"VC1_1_PIP_TST_CTRL",                0x05B10, NULL, "MFD VC1 1 PIP TST CTRL",       NULL},
  {"VC1_1_PIP_TST_WR_DATA_LO",          0x05B14, NULL, "MFD VC1 1 PIP TST WR DATA LO", NULL},
  {"VC1_1_PIP_TST_WR_DATA_HI",          0x05B18, NULL, "MFD VC1 1 PIP TST WR DATA HI", NULL},

  /* 06000 to 06FFF MPG4                                            */
   //Byte Stream Processor Registers
   //MPG4VD_BSP_IMEM	6000H-63FFF	XXXXXXXXH	BSP RISC Instruction Memory
   //MPG4VD_BSP_DMEM	6400H-64FFF	XXXXXXXXH	BSP RISC Data Memory
   {"MPG4VD_BSP_IMEM", 	0x6000, NULL,  "BSP RISC Instruction Memory", NULL },
   {"MPG4VD_BSP_DMEM", 	0x6400, NULL,  "BSP RISC Data Memory", NULL },
   {"MPG4VD_BSP_RISC_CTRL",  	0x6500, NULL,  "BSP RISC Control", NULL },
   {"MPG4VD_BSP_RISC_STATUS",   	0x6504, NULL,  "BSP RISC Status", NULL },
   {"MPG4VD_BSP_IRQ_STATUS", 	0x6508, NULL,  "BSP RISC IRQ Status", NULL },
   {"MPG4VD_BSP_IRQ_MASK",   	0x650C, NULL,  "BSP RISC IRQ Mask", NULL },
   {"MPG4VD_BSP_IPC_STATUS", 	0x6510, NULL,  "BSP RISC IPC Status", NULL },
   {"MPG4VD_BSP_HOST_DB_CMD",   	0x6514, NULL,  "BSP RISC to Host Doorbell Command", NULL },
   {"MPG4VD_BSP_RISC_DB_CMD",   	0x6518, NULL,  "BSP Host to RISC Doorbell Command", NULL },
   {"MPG4VD_BSP_IMEM_PAGE",  	0x651C, NULL,  "BSP RISC Instruction Memory Page", NULL },
   {"MPG4VD_BSP_DMEM_PAGE",  	0x6520, NULL,  "BSP RISC Data Memory Page", NULL },
   {"MPG4VD_BSP_MMR_ADDR",   	0x6524, NULL,  "BSP Coprocessor MMR Address", NULL },
   {"MPG4VD_BSP_MMR_DATA",   	0x6528, NULL,  "BSP Coprocessor MMR Data", NULL },
   {"MPG4VD_BSP_FRAME_INFO",   	0x652C, NULL,  "BSP Coprocessor Frame Info", NULL },
   {"MPG4VD_BSP_DBG_RF_ACC_ADDR",  	0x6538, NULL,  "BSP Debugger Register File Access Address", NULL },
   {"MPG4VD_BSP_DBG_RF_ACC", 	0x653C, NULL,  "BSP Debugger Register File Access", NULL },
   {"MPG4VD_BSP_DBG_FETCH_PC",  	0x6540, NULL,  "BSP Debugger Fetch Stage Program Counter", NULL },
   {"MPG4VD_BSP_DBG_FETCH_STATUS", 	0x6544, NULL,  "BSP Debugger Fetch Stage Status", NULL },
   {"MPG4VD_BSP_DBG_DEC_PC", 	0x6548, NULL,  "BSP Debugger Decode Stage Program Counter", NULL },
   {"MPG4VD_BSP_DBG_DEC_INSTR", 	0x654C, NULL,  "BSP Debugger Decode Stage Instruction", NULL },
   {"MPG4VD_BSP_DBG_DEC_STATUS",   	0x6550, NULL,  "BSP Debugger Decode Stage Status", NULL },
   {"MPG4VD_BSP_DBG_EXEC_PC",   	0x6554, NULL,  "BSP Debugger Execute Stage Program Counter", NULL },
   {"MPG4VD_BSP_DBG_EXEC_INSTR",   	0x6558, NULL,  "BSP Debugger Execute Stage Instruction", NULL },
   {"MPG4VD_BSP_DBG_EXEC_STATUS",  	0x655C, NULL,  "BSP Debugger execute Stage Status", NULL },
   {"MPG4VD_BSP_DBG_MEM_STATUS",   	0x6560, NULL,  "BSP debugger Memory Stage Status", NULL },
   {"MPG4VD_BSP_DBG_WR_STATUS", 	0x6564, NULL,  "BSP Debugger Write Stage Status", NULL },
   {"MPG4VD_BSP_DBG_CTRL",   	0x6568, NULL,  "BSP Debugger Control", NULL },
   {"MPG4VD_BSP_DBG_STATUS", 	0x656C, NULL,  "BSP Debugger Status", NULL },
   {"MPG4VD_BSP_DBG_PC_BP0", 	0x6570, NULL,  "BSP Debugger Program Counter Breakpoint 0", NULL },
   {"MPG4VD_BSP_DBG_PC_BP1", 	0x6574, NULL,  "BSP Debugger Program Counter Breakpoint 1", NULL },
   {"MPG4VD_BSP_DBG_PC_BP2", 	0x6578, NULL,  "BSP Debugger Program Counter Breakpoint 2", NULL },
   {"MPG4VD_BSP_DBG_PC_BP3", 	0x657C, NULL,  "BSP Debugger Program Counter Breakpoint 3", NULL },
   {"MPG4VD_BSP_DBG_PC_BP0_MASK",  	0x6580, NULL,  "BSP Debugger Program Counter Breakpoint 0 Mask", NULL },
   {"MPG4VD_BSP_DBG_PC_BP1_MASK",  	0x6584, NULL,  "BSP Debugger Program Counter Breakpoint 1 Mask", NULL },
   {"MPG4VD_BSP_DBG_PC_BP2_MASK",  	0x6588, NULL,  "BSP Debugger Program Counter Breakpoint 2 Mask", NULL },
   {"MPG4VD_BSP_DBG_PC_BP3_MASK",  	0x658C, NULL,  "BSP Debugger Program Counter Breakpoint 3 Mask", NULL },
   {"MPG4VD_BSP_DBG_DATA_BP0",  	0x6590, NULL,  "BSP Debugger Data Breakpoint 0", NULL },
   {"MPG4VD_BSP_DBG_DATA_BP1",  	0x6594, NULL,  "BSP Debugger Data Breakpoint 1", NULL },
   {"MPG4VD_BSP_DBG_DATA_BP2",  	0x6598, NULL,  "BSP Debugger Data Breakpoint 2", NULL },
   {"MPG4VD_BSP_DBG_DATA_BP3",  	0x659C, NULL,  "BSP Debugger Data Breakpoint 3", NULL },
   {"MPG4VD_BSP_DBG_DATA_BP0_MASK",   	0x65A0, NULL,  "BSP Debugger Data Breakpoint 0 Mask", NULL },
   {"MPG4VD_BSP_DBG_DATA_BP1_MASK",   	0x65A4, NULL,  "BSP Debugger Data Breakpoint 1 Mask", NULL },
   {"MPG4VD_BSP_DBG_DATA_BP2_MASK",   	0x65A8, NULL,  "BSP Debugger Data Breakpoint 2 Mask", NULL },
   {"MPG4VD_BSP_DBG_DATA_BP3_MASK",   	0x65AC, NULL,  "BSP Debugger Data Breakpoint 3 Mask", NULL },
   {"MPG4VD_INTR_STATUS", 	0x6604, NULL,  "Interrupt Status", NULL },
   {"MPG4VD_INTR_MASK",   	0x6608, NULL,  "Interrupt Mask", NULL },
   {"MPG4VD_CFG",    0x660C, NULL, "Configuration ", NULL },
   {"MPG4VD_MB_PER_ROW",  	0x6610, NULL,  "Number of Macroblocks Per Row", NULL },
   {"MPG4VD_MB_ROWS",  	0x6614, NULL,  "Number of Macroblocks Rows", NULL },
   {"MPG4VD_IQ_TABLE_WRDATA",   	0x6618, NULL,  "Inverse Quant Table Write Data", NULL },
   {"MPG4VD_Y0_BASE_ADDR",   	0x661C, NULL,  "Luma Buffer 0 Base Address", NULL },
   {"MPG4VD_Y1_BASE_ADDR",   	0x6620, NULL,  "Luma Buffer 1 Base Address", NULL },
   {"MPG4VD_Y2_BASE_ADDR",   	0x6624, NULL,  "Luma Buffer 2 Base Address", NULL },
   {"MPG4VD_Y3_BASE_ADDR",   	0x6628, NULL,  "Luma Buffer 3 Base Address", NULL },
   {"MPG4VD_C0_BASE_ADDR",   	0x662C, NULL,  "Chroma Buffer 0 Base Address", NULL },
   {"MPG4VD_C1_BASE_ADDR",   	0x6630, NULL,  "Chroma Buffer 1 Base Address", NULL },
   {"MPG4VD_C2_BASE_ADDR",   	0x6634, NULL,  "Chroma Buffer 2 Base Address", NULL },
   {"MPG4VD_C3_BASE_ADDR",   	0x6638, NULL,  "Chroma Buffer 3 Base Address", NULL },
   {"MPG4VD_MBI0_BASE_ADDR", 	0x663C, NULL,  "MB Info Buffer 0 Base Address", NULL },
   {"MPG4VD_MBI1_BASE_ADDR", 	0x6640, NULL,  "MB Info Buffer 1 Base Address", NULL },
   {"MPG4VD_MBI2_BASE_ADDR", 	0x6644, NULL,  "MB Info Buffer 2 Base Address", NULL },
   {"MPG4VD_MBI3_BASE_ADDR", 	0x6648, NULL,  "MB Info Buffer 3 Base Address", NULL },
   {"MPG4VD_DBI0_BASE_ADDR", 	0x664C, NULL,  "DB Info Buffer 0 Base Address", NULL },
   {"MPG4VD_DBI1_BASE_ADDR", 	0x6650, NULL,  "DB Info Buffer 1 Base Address", NULL },
   {"MPG4VD_DBI2_BASE_ADDR", 	0x6654, NULL,  "DB Info Buffer 2 Base Address", NULL },
   {"MPG4VD_DBI3_BASE_ADDR", 	0x6658, NULL,  "DB Info Buffer 3 Base Address", NULL },
   {"MPG4VD_IPB_BASE_ADDR",  	0x665C, NULL,  "AC Intra-Prediction Buffer Base Address", NULL },
   {"MPG4VD_PDMA_CFG", 	0x6660, NULL,  "Pixel DMA Configuration", NULL },
   {"MPG4VD_PDMA_STATUS", 	0x6664, NULL,  "Pixel DMA Status", NULL },
   {"MPG4VD_FFLS0_PKTCNT",   	0x6680, NULL,  "FFLS0 Packet Count", NULL },
   {"MPG4VD_FFLS1_PKTCNT",   	0x6684, NULL,  "FFLS1 Packet Count", NULL },
   {"MPG4VD_FFLS2_PKTCNT",   	0x6688, NULL,  "FFLS2 Packet Count", NULL },
   {"MPG4VD_FFLS3_PKTCNT",   	0x668C, NULL,  "FFLS3 Packet Count", NULL },
   {"MPG4VD_FFLS4_PKTCNT",   	0x6690, NULL,  "FFLS4 Packet Count", NULL },
   {"MPG4VD_FFLS5_PKTCNT",   	0x6694, NULL,  "FFLS5 Packet Count", NULL },
   {"MPG4VD_FFLS6_PKTCNT",   	0x6698, NULL,  "FFLS6 Packet Count", NULL },
   {"MPG4VD_FFLS7_PKTCNT",   	0x669C, NULL,  "FFLS7 Packet Count", NULL },
   //Stream DMA Engine Registers
   {"MPG4VD_SED",   	0x6900, NULL,  "Stream Enable/Disable", NULL },
   {"MPG4VD_SDEMC", 	0x6904, NULL,  "Stream DMA Engine Master Control", NULL },
   {"MPG4VD_DMA_CB_BASE", 	0x6908, NULL,  "Stream DMA Circular/Linear Buffer Base Address", NULL },
   {"MPG4VD_DMA_SB_RDPTR",   	0x690C, NULL,  "Stream DMA Source Block Register Address of Read Pointer", NULL },
   {"MPG4VD_DMA_CB_SIZE", 	0x6910, NULL,  "Stream DMA Circular/Linear Buffer Size", NULL },
   {"MPG4VD_DMA_WTRMARK", 	0x6914, NULL,  "Stream DMA Read/Write Pointer Watermark", NULL },
   {"MPG4VD_DMA_WDT",  	0x6918, NULL,  "Stream DMA Watchdog Timer", NULL },
   {"MPG4VD_DMA_CB_RDPTR",   	0x691C, NULL,  "Stream DMA Local Read Pointer", NULL },
   {"MPG4VD_DMA_CB_WRPTR",   	0x6920, NULL,  "Stream DMA Local Write Pointer ", NULL },
   {"MPG4VD_DMA_SDLINK",  	0x6924, NULL,  "Stream DMA Link Address ", NULL },
   {"MPG4VD_DMA_SDLLSA",  	0x6928, NULL,  "Stream DMA Link List Source Address", NULL },
   {"MPG4VD_DMA_SDLNDA",  	0x692C, NULL,  "Stream DMA Link List Next Descriptor Address", NULL },
   {"MPG4VD_DMA_SDLDBC",  	0x6930, NULL,  "Stream DMA Link List Data Buffer Byte Count", NULL },
   {"MPG4VD_DMA_SDLCBC",  	0x6934, NULL,  "Stream DMA Link List Current Data Buffer Byte Count", NULL },
   {"MPG4VD_DMA_SDLDC",   	0x6938, NULL,  "Stream DMA Link List Descriptor Control", NULL },
   {"MPG4VD_DMA_FIFO", 	0x693C, NULL,  "Stream DMA FIFO Write Data", NULL },
   {"MPG4VD_DMA_FIFO_STAT",  	0x6940, NULL,  "Stream DMA FIFO Status ", NULL },
   {"MPG4VD_DMA_INT_EN",  	0x6944, NULL,  "Stream DMA Interrupt Enable", NULL },
   {"MPG4VD_DMA_INT_STAT",   	0x6948, NULL,  "Stream DMA Interrupt Status", NULL },
   {"MPG4VD_DMA_BS_CNTR", 	0x694C, NULL,  "Stream DMA Byte Stream Counter", NULL },
   //Start Code Detector Registers
   {"MPG4VD_SCD_XCR",  	0x6A00, g_csr_gen4_mfd_SCD_XCR,  "Start Code Detector Control Register", NULL },
   {"MPG4VD_SCD_XSCR1",   	0x6A04, NULL,  "Start Code Detector Programmable Start Codes 1", NULL },
   {"MPG4VD_SCD_XSCR2",   	0x6A08, NULL,  "Start Code Detector Programmable Start Codes 2", NULL },
   {"MPG4VD_SCD_FWPREAD", 	0x6A0C, NULL,  "Start Code Detector Firmware Mode Peek Read", NULL },
   {"MPG4VD_SCD_FWCTRL",  	0x6A10, NULL,  "Start Code Detector Firmware Mode Control", NULL },
   {"MPG4VD_SCD_FWSTAT",  	0x6A14, NULL,  "Start Code Detector Firmware Mode Status", NULL },
   {"MPG4VD_SCD_WRCTRL",  	0x6A18, NULL,  "Start Code Detector Write Data Control", NULL },
   {"MPG4VD_SCD_WRDATA",  	0x6A1C, NULL,  "Start Code Detector Write Data", NULL },
   //PiP Scaler Registers
   {"MPG4VD_PIP_CTRL", 	0x6B00, NULL,  "PiP Control Register", NULL },
   {"MPG4VD_PIP_STAT", 	0x6B04, NULL,  "PiP Status Register", NULL },
   {"MPG4VD_PIP_CDYB", 	0x6B08, NULL,  "PiP Current Decode Y Buffer Address", NULL },
   {"MPG4VD_PIP_CDUB", 	0x6B0C, NULL,  "PiP Current Decode UV Buffer Address", NULL },
   {"MPG4VD_PIP_TST_CTRL",   	0x6B10, NULL,  "PiP Test Control Register", NULL },
   {"MPG4VD_PIP_TST_WR_DATA_LO",   	0x6B14, NULL,  "PiP Test Data [31:0] Register", NULL },
   {"MPG4VD_PIP_TST_WR_DATA_HI",   	0x6B18, NULL,  "PiP Test Data [63:0] Register", NULL },

  /* VSPARC debugger                                                  */
  /* 7000H to 71FCH 00000000H Windowed Register File                  */
  /* VSPARC_GLOBALREGS  2200H to 221CH Processor Global Registers */
  {"VSPARC_FPC",                        0x07500, NULL, "MFD VSPARC FPC",            NULL},
  {"VSPARC_FSTATUS",                    0x07508, NULL, "MFD VSPARC FSTATUS",        NULL},
  {"VSPARC_DPC",                        0x07510, NULL, "MFD VSPARC DPC",            NULL},
  {"VSPARC_D_INST",                     0x07514, NULL, "MFD VSPARC D INST",         NULL},
  {"VSPARC_DSTATUS",                    0x07518, NULL, "MFD VSPARC DSTATUS",        NULL},
  {"VSPARC_EPC",                        0x07520, NULL, "MFD VSPARC EPC",            NULL},
  {"VSPARC_E_INST",                     0x07524, NULL, "MFD VSPARC E INST",         NULL},
  {"VSPARC_ESTATUS",                    0x07528, NULL, "MFD VSPARC ESTATUS",        NULL},
  {"VSPARC_MSTATUS",                    0x07538, NULL, "MFD VSPARC MSTATUS",        NULL},
  {"VSPARC_WSTATUS",                    0x07548, NULL, "MFD VSPARC WSTATUS",        NULL},
  {"VSPARC_DCTRL",                      0x07600, NULL, "MFD VSPARC DCTRL",          NULL},
  {"VSPARC_DSTAT",                      0x07604, NULL, "MFD VSPARC DSTAT",          NULL},
  {"VSPARC_PCBREAK0",                   0x07680, NULL, "MFD VSPARC PCBREAK0",       NULL},
  {"VSPARC_PCBREAKMASK0",               0x07684, NULL, "MFD VSPARC PCBREAKMASK0",   NULL},
  {"VSPARC_PCBREAK1",                   0x07690, NULL, "MFD VSPARC PCBREAK1",       NULL},
  {"VSPARC_PCBREAKMASK1",               0x07694, NULL, "MFD VSPARC PCBREAKMASK1",   NULL},
  {"VSPARC_PCBREAK2",                   0x076A0, NULL, "MFD VSPARC PCBREAK2",       NULL},
  {"VSPARC_PCBREAKMASK2",               0x076A4, NULL, "MFD VSPARC PCBREAKMASK2",   NULL},
  {"VSPARC_PCBREAK3",                   0x076B0, NULL, "MFD VSPARC PCBREAK3",       NULL},
  {"VSPARC_PCBREAKMASK3",               0x076B4, NULL, "MFD VSPARC PCBREAKMASK3",   NULL},
  {"VSPARC_DATABREAK0",                 0x076C0, NULL, "MFD VSPARC DATABREAK0",     NULL},
  {"VSPARC_DATABREAKMASK0",             0x076C4, NULL, "MFD VSPARC DATABREAKMASK0", NULL},
  {"VSPARC_DATABREAK1",                 0x076D0, NULL, "MFD VSPARC DATABREAK1",     NULL},
  {"VSPARC_DATABREAKMASK1",             0x076D4, NULL, "MFD VSPARC DATABREAKMASK1", NULL},
  {"VSPARC_DATABREAK2",                 0x076E0, NULL, "MFD VSPARC DATABREAK2",     NULL},
  {"VSPARC_DATABREAKMASK2",             0x076E4, NULL, "MFD VSPARC DATABREAKMASK2", NULL},
  {"VSPARC_DATABREAK3",                 0x076F0, NULL, "MFD VSPARC DATABREAK3",     NULL},
  {"VSPARC_DATABREAKMASK3",             0x076F4, NULL, "MFD VSPARC DATABREAKMASK3", NULL},

  /* VSPARC_LRAM 7800H to 7FFCH 00000000H Local SRAM Area */
  /* VSPARC_MEM FF9A8000H - FF9AFFFCH Code ram (windowed) */

  /* VSPARC code ram */
  {"VSPARC_CODERAM",                    0x08000, NULL,      "MFD VSPARC CODERAM     ", NULL},

  { NULL,0,NULL,NULL,NULL }    /* NULL terminator */
};

static const struct SVEN_Module_EventSpecific g_GEN4_MFD_SV_specific_events[] =
{
   #include "ismd_standard_events.c"

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   { "MESSAGE_TX_TO_FW", 1, "", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   { "MESSAGE_RX_FROM_FW", 2, "", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* When the bottom-half event handler is invoked */
   { "BOTTOM_HALF_HANDLER",3, "\tIndex=%d Context=0x%x time=%lld", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* When buffer is read from the port */
   { "INPUT_PORT_BUFFER",4, "\tBufId=%d size=%d OPTS=%ld LPTS=%ld Tag=%d", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* When an es buffer descriptor is queued in the firmware */
   { "ENQUEUE_ES_BUFFER",5, "\tIndex=%d Buf_Id=%d SA=0x%x PA=0x%lx tsize=0x%x flag=0x%x", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* When an es buffer release message is received from the firmware */
   { "RELEASE_ES_BUFFER",6, "\tIndex=%d BufId=%ld PA=0x%lx VA=0x%lx EQ=%ld DQ=%ld", NULL },

   /* When "Frame Decoded" message is received from firmware */
   { "DECODE_ORDER_FRAME", 7, "\tStreamID=%d index=%d OutFb=%d LockCnt=%d FbType=%d", NULL },

   /* When "Frame Ready to display" message is received from firmware */
   { "DISPLAY_ORDER_FRAME", 8, "\tStreamID=%d OutPortID=%d OutFb=%d FbType=%d OPTS=0x%x LPTS=0x%x ", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* When a frame is written to the output port */
   { "OUTPUT_PORT_BUFFER",9, "\tN=%d FbId=%d BufId=0x%x YAdd:0x%x PTS=0x%x%x", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* When "Frame Release" message is received from firmware */
   { "RELEASE_FRAME_BUFFER",10, "\tN=%d FbId=%d BufId=0x%x YAdd:0x%x AllocN=%d", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* When the input port is empty */
   { "INPUT_PORT_EMPTY",11, "\tPort Empty: ret: %d", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* When frame buffer is allocated */
   { "FB_ALLOCATED",12, "\tN=%d FbId=%d BufId=0x%x YAdd:0x%x RlsN=%d FbCt=%d", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* When frame buffer is released */
   { "FB_RELEASED",13, "\tN=%d FbId=%d BufId=0x%x YAdd:0x%x AllocN=%d FbCt=%d", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* information related to input port and input queue */
   { "INPUT_INFO",14, "\tStreamID=%d ret=%d PMDepth=%ld PDepth=%ld QDepth=%d QBytes=%ld", NULL},

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* Indicates that ES attributes were found on input */
   { "ES_ATTR_FOUND", 15, "\tOPTS=0x%x%x LPTS=0x%x%x DISC=%d", NULL },

   /* Legacy SVEN event from Gen3. This is currently not supported in Gen4 */
   /* When input port port depth changes based on vbv_buf_size ( from_stream) */
   { "IP_DEPTH_CHANGED", 16, "\tvbv_buf_bytes=%ld ismd_buf_size=%ld old_depth=%d new_depth=%d", NULL },

   /* When the viddec instance is opened for a stream */
   { "OPEN", 17, "\tStream ID=%d InPortID=%d OutPortID=%d ismd_dev_handle=%d initial_codec=%d max_frames_to_decode=%llu", NULL},

   /* When the viddec driver processes client_id tag */
   { "CLIENT_ID_PROCESSED", 18, "\tStreamID=%d OutPortID=%d OutFB=%d ClientID=%d", NULL },

   /* When the EOS is triggered */
   { "EOS_TRIGGERED", 19, "\tStreamID=%d OutPortID=%d", NULL },

   /* When frame buffer is dropped - drop reason: Look at error flags in viddec_fw_common_defs.h*/
   { "DROP_ERR_FRAME", 20, "\tStreamID=%d Error=0x%x Fb=0x%x FbType:0x%x OPTS=0x%x LPTS=0x%x", NULL },

   /* When discontinuity is seen on the input ES buffer */
   { "DISCONT_ON_INPUT", 21, "\tStreamID=%d EsBuf=%d", NULL },

   /* When the set state is called */
   { "SET_STATE", 22, "\tStreamID=%d present_state=%d requested_state=%d %d %d %d", NULL },

   /* GEN4 viddec driver HAL messages */
   { "HAL_GET_FW_VER", 0x40, "  decoder %08x,%08x parser %08x,%08x", NULL },

   { "HAL_WKLD_ITEM", 0x41, "   n %3d type %08x [ %08x %08x %08x ]", NULL },

   { "HAL_WM_FR_INC", 0x42, "   ctx %08x id %08x smd_id %08x", NULL },
   { "HAL_WM_FR_DEC", 0x43, "   ctx %08x id %08x smd_id %08x", NULL },
   { "HAL_WM_ES_INC", 0x44, "   ctx %08x id %08x smd_id %08x", NULL },
   { "HAL_WM_ES_DEC", 0x45, "   ctx %08x id %08x smd_id %08x", NULL },

   { "HAL_WITEM_TAG", 0x46, "   n %3d type %08x [     %08x     %08x bid %08x ]", NULL },
   { "HAL_WITEM_DONE", 0x47, "  n %3d type %08x [  pa %08x siz %08x bid %08x ]", NULL },
   { "HAL_WITEM_CONT", 0x48, "  n %3d type %08x [  pa %08x siz %08x bid %08x ]", NULL },
   { "HAL_WITEM_REORD", 0x49, " n %3d type %08x [ off %08x  s0 %08x  s1 %08x ]", NULL },
   { "HAL_WITEM_FREF", 0x4a, "  n %3d type %08x [ bid %08x ypa %08x upa %08x pos %2d ]", NULL },
   { "HAL_WITEM_FREL", 0x4b, "  n %3d type %08x [ bid %08x ypa %08x upa %08x pos %2d ]", NULL },
   { "HAL_WITEM_FDISP", 0x4c, " n %3d type %08x [ bid %08x ypa %08x upa %08x pos %2d ]", NULL },
   { "HAL_WITEM_ESBUF", 0x4d, " n %3d type %08x [  pa %08x siz %08x flg %08x ]", NULL },

   { "HAL_TX_ES_TO_FW", 0x4e, " hand: %08x id %08x pa %08x len %08x flg %08x smd %08x", NULL },

   { "HAL_WKLD_TX_P", 0x50, "   hand: %08x id %08x pa %08x len %08x flg %08x", NULL },
   { "HAL_WKLD_RX_P", 0x51, "   hand: %08x id %08x pa %08x len %08x flg %08x", NULL },
   { "HAL_WKLD_TX_D", 0x52, "   hand: %08x id %08x pa %08x len %08x flg %08x wkh %08x", NULL },
   { "HAL_WKLD_RX_D", 0x53, "   hand: %08x id %08x pa %08x len %08x flg %08x", NULL },

   { "HAL_WKLD_FOUT", 0x54, "   hand: %08x wl %08x id %08x ypa %08x upa %08x iid %08x", NULL },

   { "HAL_FBA_ALLOC", 0x60, "   ctx: %08x index: %08x smd_id %08x lok %2d type %d rslt %d", NULL },
   { "HAL_FBA_RELEASE", 0x61, " ctx: %08x index: %08x smd_id %08x lok %2d type %d rsmd %d", NULL },

   /* When the hal is opened */
   { "HAL_OPEN", 0x62, "\tCodec=%d", NULL },

   /* When the hal (first stage) is closed */
   { "HAL_CLOSE_STAGE1", 0x63, "\tHalHandle=%d ParserHandle=%d DecoderHandle=%d", NULL },

   /* When the hal (second stage) is closed */
   { "HAL_CLOSE_STAGE2", 0x70, "\tHalHandle=%d ParserHandle=%d DecoderHandle=%d", NULL },

   /* When the hal frame buffer is released */
   { "HAL_FB_IS_RELEASED", 0x71, "\tHandle=%d Index=%d Type=%d OutFb=%d IsWrit=%d IsDisp=%d", NULL },

   /* When the hal frame buffer is displayed */
   { "HAL_FB_IS_DISPLAYED", 0x72, "\tHandle=%d Index=%d Type=%d OutFb=%d IsWrit=%d IsRel=%d", NULL },

   /* When the hal frame is written */
   { "HAL_FB_IS_WRITTEN", 0x73, "\tHandle=%d Index=%d Type=%d OutFb=%d IsRel=%d IsDisp=%d", NULL },

   /* FB ARRAY DUMP */
   { "HAL_FB_ARRAY", 0x74, "    ctx=%08x Idx=%2d err=%08x F(R/W/D/0)=%08x id %08x lk %08x", NULL },

   /* When discontinuity is seen on a wkld from parser */
   { "HAL_DISCONT_ON_WKLD", 0x75, "\tHandle=%d wl=%08x FrmId=%d", NULL },

   { "HAL_GET_DESCR_ERR"  , 0x76, "ERROR: can not read buffer descriptor, handle: %d, ret=%d", NULL },

   /* When an unsupported Stream Format is detected*/
   { "HAL_UNSUPPORTED_3D_AVC_STREAM_FORMAT_DETECTED", 0x77, "ctx: %08x quincunx_flag=%d arrangment_type=%d", NULL },

   /* FIRMWARE TX Messages */
   { "FW_PICOSVEN", 0x80, "     %08x %08x %08x %08x %08x %08x", NULL },
   { "FW_DK_STM_QUERY", 0x81, " PATH %d SZ_PER %08x SZ_PER_DDR %08x SZ_SCR %08x ret %d", NULL },

   { "FW_DK_PIPE_OPEN", 0x82, " PIPE_TO_FW %d PIPE_TO_HOST %d ret %d", NULL },
   { "FW_DK_PIPE_FREE", 0x83, " PIPE_TO_FW %d PIPE_TO_HOST %d ret %d", NULL },

   { "FW_DK_STM_OPEN", 0x84, "  FMT %d  PER %08x PER_PA %08x SCR_PA %08x PIPE2FW %d PIPE2HOST %d", NULL },
   { "FW_DK_STM_PIPE", 0x85, "  PIPE %d CB_PA %08x CB_SIZE %08x RPOS_PA %08x WPOS_PA %08x DIR %d", NULL },
   { "FW_DK_STM_FLUSH", 0x86, " STM %d retval %d", NULL },
   { "FW_DK_STM_CLOSE", 0x87, " STM %d retval %d", NULL },

   { "FW_DK_WL_START", 0x88, "  STM %d FMT %d PRI %d WL_PA %08x WL_LEN %08x WL_ID %08x", NULL },
   { "FW_DK_ISR", 0x89, "       %08x %08x %08x %08x %08x %08x", NULL },
   { "FW_DK_WL_DONE", 0x8a, "   HWP %d FMT %d PRI %d WL_PA %08x WL_LEN %08x WL_ID %08x", NULL },

   { "FW_DM_CTX_LOAD", 0x8b, "  HWP %d PER %08x PER_PA %08x SCR_PA %08x LOC %08x SIZ %08x ", NULL },
   { "FW_DM_CTX_SAVE", 0x8c, "  HWP %d PER %08x PER_PA %08x SCR_PA %08x LOC %08x SIZ %08x ", NULL },

   { "FW_AUTOAPI_CMD", 0x8d, "   CMDID %08x CB %08x [%08x %08x %08x %08x] ", NULL },
   { "FW_AUTOAPI_DEFER", 0x8e, " CMDID %08x CB %08x [%08x %08x %08x %08x] ", NULL },
   { "FW_AUTOAPI_CMPLT", 0x8f, " CMDID %08x CB %08x [%08x %08x %08x %08x] ", NULL },

   /* MPEG2 Specific SVEN Messages */
   { "FW_MP2_HW_INIT", 0x90, "    RETURN %d", NULL},
   { "FW_MP2_REG_RESET", 0x91, "  FRAME %d DCSI1 0x%08x DCSI2 0x%08x DCPI1 0x%08x DCPCE1 0x%08x", NULL},
   { "FW_MP2_REG_WRITE", 0x92, "  FRAME %d DCSI1 0x%08x DCSI2 0x%08x DCPI1 0x%08x DCPCE1 0x%08x", NULL},
   { "FW_MP2_WL_FIELD", 0x93, "   FRAME %d CURR_WI %d", NULL},
   { "FW_MP2_DMA_APPEND", 0x94, " FRAME %d START_ADD 0x%08x END_ADD 0x%08x SIZE %d", NULL},
   { "FW_MP2_FRM_OUT", 0x95, "    FRAME %d TYPE %d CURR_Y 0x%08x CURR_UV 0x%08x", NULL},
   { "FW_MP2_FRM_REF", 0x96, "    FRAME %d TYPE %d PAST_Y 0x%08x PAST_UV 0x%08x FUT_Y 0x%08x FUT_UV 0x%08x", NULL},
   { "FW_MP2_PIP_SCALE", 0x97, "  FRAME %d PIP_Y 0x%08x PIP_UV 0x%08x SCALE_FACTOR %d MBAC_EN %d", NULL},
   { "FW_MP2_WL_FRAME", 0x98, "   FRAME %d CURR_WI %d", NULL},
   { "FW_MP2_FRAME_DONE", 0x99, " FRAME %d", NULL},
   { "FW_MP2_INTR_STAT", 0x9a, "  FRAME %d POLLED_STAT 0x%08x MB_NUM %8d SCD_STAT 0x%08x DMA_STAT 0x%08x", NULL},
   { "FW_MP2_NUM_ERR_MB", 0x9b, " FRAME %d NUM_ERR_MB %d", NULL },
   { "FW_CODEC_FRAME_POLL", 0x9c, "reg 0x%08x ret 0x%08X err 0x%08x 0x%08X 0x%08X 0x%08X", NULL},
   { "FW_MP2_INSUFF_MEM", 0x9d, "  FRAME %d POLLED_STAT 0x%08x MB_NUM %8d ERROR_CODE %d ", NULL},

   

   /* MPEG4 Specific SVEN Messages */
   { "FW_MP4_RESET", 0xA0, "      RESET", NULL},
   { "FW_MP4_BSP_NORMAL", 0xA1, " PHYS_ADDR 0x%08X LEN %d", NULL},
   { "FW_MP4_BSP_DP", 0xA2, "     PHYS_ADDR 0x%08X LEN %d", NULL},
   { "FW_MP4_BSP_LOAD_START", 0xA3, " INDEX %d PHYS_ADDR 0x%08X LEN %d", NULL},
   { "FW_MP4_BSP_LOAD_DONE", 0xA4, "  DMEM_OFFSET 0x%08X", NULL},
   { "FW_MP4_BSP_IMEM_WRITE", 0xA5, " FW_SIZE_REM %d FW_PHYS_START 0x%08X PAGE %d COPY_SIZE %d", NULL},
   { "FW_MP4_BSP_DMEM_WRITE", 0xA6, " DMEM_SIZE_REM %d DMEM_PHYS_START 0x%08X PAGE %d COPY_SIZE %d", NULL},
   { "FW_MP4_REG_WRITE", 0xA7, "  REG_OFFSET 0x%04X REG_VALUE 0x%08X", NULL},
   { "FW_MP4_FRAME", 0xA8, "      INDEX %d Y 0x%08X UV 0x%08X MBINFO 0x%08X DBINFO 0x%08X", NULL},
   { "FW_MP4_POLL", 0xA9, "       INTR_STAT 0x%08X HOST_DB 0x%08X RET_VAL %d BS_CNTR 0x%08X PHASE %d TIME_OUT %d", NULL},
   { "FW_MP4_DMEM_DATA", 0xAA, "  OFFSET 0x%08x DATA 0x%08X", NULL},
   /* Common SVEN Messages */
   { "FW_WL_START_BEGIN", 0xB0, "    WL_PHYS=%08X PIP=%08X frame_no=%d %08X %08X line=%d ",  NULL},
   { "FW_WL_START_END", 0xB1, "      WL_PHYS=%08X PIP=%08X frame_no=%d %08X %08X line=%d ",  NULL},
   { "FW_WL_POLL_BEGIN", 0xB2, "     %08X %08X %08X %08X %08X %08X ",  NULL},
   { "FW_WL_POLL_END", 0xB3, "       %08X %08X %08X %08X %08X %08X ",  NULL},
   { "FW_WL_DONE", 0xB4, "           WL_PHYS=%08X PIP=%08X frame_no=%d %08X %08X line=%d ",  NULL},
   { "FW_WL_DONE_CL_START", 0xB5, "  %08X %08X %08X %08X %08X %08X ",  NULL},
   { "FW_WL_DONE_CL_END", 0xB6, "    %08X %08X %08X %08X %08X %08X ",  NULL},
   { "FW_WL_SLICE_BEGIN", 0xB7, "    WL_PHYS=%08X PIP=%08X slice_no=%d %08X %08X line=%d ",  NULL},
   { "FW_WL_SLICE_END", 0xB8, "      WL_PHYS=%08X PIP=%08X slice_no=%d %08X %08X line=%d ",  NULL},
   { "FW_WL_SLICE_HW_BEGIN", 0xB9, " WL_PHYS=%08X PIP=%08X slice_no=%d %08X %08X line=%d ",  NULL},
   { "FW_PRCS_WL_BEGIN", 0xBA, "     WL_PHYS=%08X PIP=%08X item_no=%d %08X %08X line=%d ",  NULL},
   { "FW_PRCS_WL_END", 0xBB, "       WL_PHYS=%08X PIP=%08X item_no=%d %08X %08X line=%d ",  NULL},
   { "FW_WL_ERROR", 0xBC, "          WL_PHYS=%08X PIP=%08X line=%d Err1=%08X err2=%08X err3==%08X ",  NULL},
   /* Streamer DMA */
   { "FW_ST_DMA_STATS", 0xF0, "  BASE %04x NDESCS %d SIZE 0x%08x (%6d) DESC_PA 0x%08x FIRST_PA 0x%08x", NULL},
   

{ NULL, 0, "", NULL }
};

static const struct ModuleReverseDefs g_GEN4_MFD_sven_module =
{
    "GEN4_MFD",
    SVEN_module_GEN4_MFD,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen4_mfd_sv,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MFD: MFD (GEN4)",
    g_GEN4_MFD_SV_specific_events,
    NULL /* extension list */
};

