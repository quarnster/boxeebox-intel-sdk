/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct EAS_RegBits g_csr_ce4100_cru_TM_CMD[] = 
{
    {"reserved",           		11, 21, "reserved", NULL },
    {"VSYNC_SEL",          	10, 1, "VSYNC timestamp src 0= PipeA 1= PipeB", NULL },
    {"M150_300",            	9, 1, "Enable 180kHz counter", NULL },
    {"M300_BYPASS",         	8, 1, "Enable 27MHz counter", NULL },
    {"COMP_ENABLE",         	7, 1, "Enable Event comparator", NULL },
    {"MASTER_CLOCK",        	6, 1, "use master clock (VCXO or DDS_0) to drive this timing channel", NULL },
    {"MODE",                		4, 2, "Enable 33-bit presentation counter comparison", NULL },
    {"TS_SOURCE",           	0, 4, "source for timestamping", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_DDS_FREQ[] =
{
	{"reserved",			27, 5, "Reserved : Reads as 0 and writes are ignored", NULL},
	{"DDS_FREQ",		0,27, "Frequency setting for DDS", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_SET_STC_HI[] = 
{
    {"reserved1",          		25, 7, "reserved", NULL },
    {"PRESC_SET",          	16, 9, "The new data to be written into prescaler register", NULL },
    {"reserved0",          		10, 6,"reserved", NULL },
    {"MSB_STC",            	0, 10, "Desired value of Bit 32 of the STC counter in Chan", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_LAST_TS_LO[] = 
{
	{"Media_TB_UPD",	   	31, 1, "Flag bit for writing SET_STC value in the wall clock.  MSB when read.", NULL },
	{"Unlock_TS",		   	1, 30, "Enable new timestamp capture into LAST_TS_HI and LAST_TS_LO register", NULL },
	{"Make_SW_TS", 		0, 1, "SW trigger bit when written 1 to.  LSB of lower byte of wall clock when read", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_LAST_TS_HI[] = 
{
    {"NEW_TS",             		31, 1, "set when timestamp registers are updated by hardware ", NULL },
    {"reserved",           		25, 6, "reserved", NULL },
    {"PRESC",              		16, 9, "The new data to be written into prescaler register", NULL },
    {"reserved0",          		10, 6,"reserved", NULL },
    {"MSB_STC",            	0, 10, "Desired value of Bit 32 of the STC counter in Chan", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_COMP_HI[] = 
{
	{"reserved",           	10, 22, "Reserved", NULL},
	{"MSB_STC",             	0, 10, "Bits 41:32 of COMPARE register ", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_VSYNC_HI[] = 
{
	{"NEW_VSYNC",		31, 1, "indicates a new VSYNC event has occured and timestamp is captured", NULL },
	{"reserved0",           	10,21, "Reserved", NULL},
	{"MSB_STC",             	0, 10, "Captured value of bits 41:33 of the STC counter", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_STC_HI[] = 
{
	{"reserved",           	10, 22, "Reserved", NULL},
	{"MSB_STC",             	0, 10, "Bits 41:32 of COMPARE register ", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_INT_STATUS[] = 
{
   	{"reserved3",          	25, 7, "Reserved", NULL},
    {"COMPARE_SYS",        	24, 1, "The running value in System Time counter matched the desired compare setting", NULL },
   	{"reserved2",          	19, 5, "Reserved", NULL},
	{"COMPARE_9",          	18, 1, "The running value in STC counter of Channel 9 matched the desired compare setting", NULL },
	{"CAPTURE_SYT2",       	17, 1, "The valid timestamp was captured in System Time capture register 2 (for received packets on Ethernet)", NULL },
    {"CAPTURE_SYT1",       	16, 1, "The valid timestamp was captured in System Time capture register 1 (for transmitted packets on Ethernet)", NULL},
   	{"COMPARE_8",          	15, 1, "The running value in STC counter of Channel 8 matched the desired compare setting", NULL },
    {"COMPARE_7",          	14, 1, "The running value in STC counter of Channel 7 matched the desired compare setting", NULL },
    {"COMPARE_6",          	13, 1, "The running value in STC counter of Channel 6 matched the desired compare setting", NULL },
    {"COMPARE_5",          	12, 1, "The running value in STC counter of Channel 5 matched the desired compare setting", NULL },
    {"COMPARE_4",          	11, 1, "The running value in STC counter of Channel 4 matched the desired compare setting", NULL },
    {"COMPARE_3",          	10, 1, "The running value in STC counter of Channel 3 matched the desired compare setting", NULL },
    {"COMPARE_2",           	9, 1, "The running value in STC counter of Channel 2 matched the desired compare setting", NULL },
    {"COMPARE_1",           	8, 1, "The running value in STC counter of Channel 1 matched the desired compare setting", NULL },
   	{"reserved0",           	0, 8, "Reserved", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_INT_ENABLE[] = 
{
   	{"reserved3",          	25, 7, "Reserved", NULL},
    {"COMPARE_SYS",        	24, 1, "The running value in System Time counter matched the desired compare setting", NULL },
   	{"reserved2",          	19, 5, "Reserved", NULL},
	{"COMPARE_9",          	18, 1, "The running value in STC counter of Channel 9 matched the desired compare setting", NULL },
	{"CAPTURE_SYT2",       	17, 1, "The valid timestamp was captured in System Time capture register 2 (for received packets on Ethernet)", NULL },
    {"CAPTURE_SYT1",       	16, 1, "The valid timestamp was captured in System Time capture register 1 (for transmitted packets on Ethernet)", NULL},
   	{"COMPARE_8",          	15, 1, "The running value in STC counter of Channel 8 matched the desired compare setting", NULL },
    {"COMPARE_7",          	14, 1, "The running value in STC counter of Channel 7 matched the desired compare setting", NULL },
    {"COMPARE_6",          	13, 1, "The running value in STC counter of Channel 6 matched the desired compare setting", NULL },
    {"COMPARE_5",          	12, 1, "The running value in STC counter of Channel 5 matched the desired compare setting", NULL },
    {"COMPARE_4",          	11, 1, "The running value in STC counter of Channel 4 matched the desired compare setting", NULL },
    {"COMPARE_3",          	10, 1, "The running value in STC counter of Channel 3 matched the desired compare setting", NULL },
    {"COMPARE_2",           	9, 1, "The running value in STC counter of Channel 2 matched the desired compare setting", NULL },
    {"COMPARE_1",           	8, 1, "The running value in STC counter of Channel 1 matched the desired compare setting", NULL },
   	{"reserved0",           	0, 8, "Reserved", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_CW_OMAR_CTRL[] = 
{
    {"reserved",          		3, 29, "Reserved", NULL},
    {"OMAR1_MUX",           	2, 1, "omar bus1", NULL },
   	{"OMAR0_MUX",          		1, 1, "omar bus0", NULL},
   	{"DOORSTEP_0_MUX",          0, 1, "Not used ", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_VCXO_DAC_CTRL[] = 
{
   	{"PAT_CTNL",           	30, 2, "Output pattern selection Delta sigma, All zero, All one, Fixed 1-1-0 output seq.", NULL},
   	{"VCX0_ENABLE", 		29, 1, "vcx0_enable", NULL},
    {"reserved1",          	24, 5, "Reserved", NULL},
    {"FREQ_DIV",           	16, 8, "Delta-Sigma update frequency is bus clock / (2*freq_div+1)", NULL },
   	{"reserved0",          	12, 4, "Reserved", NULL},
   	{"VCXO_DAC",            0, 12, "12-bit ", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_VCXO_DIG_DAC_CTRL[] = 
{
   	{"reserved1",          	16, 16, "Reserved", NULL},
    {"DIG_VCX0_INTERVAL",   2, 14, "Number of dig_vcxo_ref_clk between activates", NULL },
   	{"DIG_VCX0_ADV_SEL",    1, 1, "Perform advance or retard", NULL},
   	{"DIG_VCX0_EN",         0, 1, "Enable Digital VCX0", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_ce4100_cru_TS_DDS_MAP_CTRL[] =
{
 	{"reserved1",				28, 4, "Reserved", NULL},
	{"TS_OUT1_MAP",			24, 4, "Select which DDS output drives TS ouput channel 1 timestamp cntr ctrl for packet Tx timing ctrl", NULL},
	{"reserved0",				16, 8, "Reserved", NULL},
	{"TS_IN4_MAP",			12, 4, "Select which DDS o/p drives TS input channel 4 timestamp cntr ctrl for packet timing ctrl", NULL},
	{"TS_IN3_MAP",			 8, 4, "Select which DDS o/p drives TS input channel 3 timestamp cntr ctrl for packet timing ctrl", NULL},
	{"TS_IN2_MAP",			 4, 4, "Select which DDS o/p drives TS input channel 2 timestamp cntr ctrl for packet timing ctrl", NULL},
	{"TS_IN1_MAP",			 0, 4, "Select which DDS o/p drives TS input channel 1 timestamp cntr ctrl for packet timing ctrl", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_TS_DDS_MAP2_CTRL[] =
{
	{"reserved0",			16, 16, "Reserved", NULL},
	{"TS_IN8_MAP",			12, 4, "Select which DDS o/p drives TS input channel 4 timestamp cntr ctrl for packet timing ctrl", NULL},
	{"TS_IN7_MAP",			 8, 4, "Select which DDS o/p drives TS input channel 3 timestamp cntr ctrl for packet timing ctrl", NULL},
	{"TS_IN6_MAP",			 4, 4, "Select which DDS o/p drives TS input channel 2 timestamp cntr ctrl for packet timing ctrl", NULL},
	{"TS_IN5_MAP",			 0, 4, "Select which DDS o/p drives TS input channel 1 timestamp cntr ctrl for packet timing ctrl", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_NET_CMD[] =
{
	{"reserved1", 				7, 25, "reserved1", NULL},
	{"COMP_ENABLE", 			6, 1, "Enable Event comparator", NULL},
 	{"reserved0",				0, 6, "Reserved", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_NET_GET_SYSTIME[] =
{
 	{"reserved1",				0, 32, "Reserved", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_FILTER_CFG_A1[] =
{
 	{"TXFILTER_EN",		31, 1, "Enable packet filtering in TX direction", NULL},
	{"RXFILTER_EN",		30,  1, " Enable packet filtering in RX direction", NULL},
	{"reserved",			29, 1, "Reserved", NULL},
	{"IP_L2",				28, 1, "filter will operate in IP/UDP mode or in Ethernet mode", NULL},
	{"PTP_VER",			24, 4, "4-bit PTP version", NULL},
	{"DA_HASH",			16,  8, "Ethernet CRC calculated", NULL},
	{"ETHER_TYPE",		0, 16, "Ether type field for packet filter", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_FILTER_CFG_B1[] =
{
	{"TAG_MAC",				31, 1, "Detect tagged MAC field", NULL},
	{"CHECK_CRC",			30, 1, "Check for valid CRC 32", NULL},
	{"MSG_TYPE",				29, 1, "Compare Mesaage Type", NULL},
	{"PTP_VER",				28, 1, "Compare PTP version", NULL},
	{"DEST_PORT1",			27, 1, "Compare destination port", NULL},
	{"IP_PROTO",				26, 1, "Compare IP protocol", NULL},
	{"ETHER_TYPE",			25, 1, "Compare ether type", NULL},
	{"DA_HASH",				24, 1, "enable exclusion of DA hash in teh tiemstamping filter", NULL},
	{"PROTO",				16, 8, "IP protocol ", NULL},
	{"DEST_PORT",			0, 16, "16 -bit destination port", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_FILTER_CFG_C1[] =
{
 	{"DEST_IP_ADDR_3",				24, 8, "Destination IP address for PTP packets, this address is used in both transmit and receive filters", NULL},
	{"DEST_IP_ADDR_2",				16, 8, "Destination IP address for PTP packets, this address is used in both transmit and receive filters", NULL},
	{"DEST_IP_ADDR_1",				8, 8, "Destination IP address for PTP packets, this address is used in both transmit and receive filters", NULL},
	{"DEST_IP_ADDR_0",				0, 8, "Destination IP address for PTP packets, this address is used in both transmit and receive filters", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_FILTER_CFG_D1[] =
{
 	{"reserved1",				16, 16, "Reserved", NULL},
	{"DEST_IP_MASK",				0, 16, "Ip address mask", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_MSG_DATA_1[] =
{
	{"MSGID_3",				24, 8, "Byte 37 or 65 of PTP message", NULL},
	{"MSGID_2",				16, 8, "Byte 36 or 64 of PTP message", NULL},
	{"MSGID_1",				8, 8, "Byte 35 or 63 of PTP message", NULL},
	{"MSGID_0",				0, 8, "Byte 34 or 62 of PTP message", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_MSG_DATA_2[] =
{
	{"MSGID_7",				24, 8, "Byte 41 or 69 of PTP message", NULL},
	{"MSGID_6",				16, 8, "Byte 40 or 68 of PTP message", NULL},
	{"MSGID_5",				8, 8, "Byte 39 or 67 of PTP message", NULL},
	{"MSGID_4",				0, 8, "Byte 38 or 66 of PTP message", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_ce4100_cru_MSG_DATA_3[] =
{
	{"MSGSEQ_1",				24, 8, "Byte 45 or 73 of PTP message", NULL},
	{"MSGSEQ_0",				16, 8, "Byte 44 or 72 of PTP message", NULL},
	{"MSGID_9",				8, 8, "Byte 43 or 71 of PTP message", NULL},
	{"MSGID_8",				0, 8, "Byte 42 or 70 of PTP message", NULL},
	{ NULL,0,0,"",NULL }    /* NULL Terminated */
};


#define CRU_TCHAN_BASE_DIFF	  0x0040
#define TCHAN_BASE_0  (CRU_TCHAN_BASE_DIFF * 0)
#define TCHAN_BASE_1  (CRU_TCHAN_BASE_DIFF * 1)
#define TCHAN_BASE_2  (CRU_TCHAN_BASE_DIFF * 2)
#define TCHAN_BASE_3  (CRU_TCHAN_BASE_DIFF * 3)
#define TCHAN_BASE_4  (CRU_TCHAN_BASE_DIFF * 4)
#define TCHAN_BASE_5  (CRU_TCHAN_BASE_DIFF * 5)


static const struct EAS_Register g_csr_ce4100_cru[] =
{
    { "0_TM_CMD",       	    TCHAN_BASE_0 + 0x00, g_csr_ce4100_cru_TM_CMD, "Configuration", NULL },
    { "0_DDS_FREQ",    		    TCHAN_BASE_0 + 0x08, g_csr_ce4100_cru_DDS_FREQ, "DDS Frequency", NULL },
    { "0_GET_SYSTIME",		    TCHAN_BASE_0 + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
    { "0_SET_STC_LO",   	    TCHAN_BASE_0 + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
    { "0_SET_STC_HI",   	    TCHAN_BASE_0 + 0x14, g_csr_ce4100_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
    { "0_LAST_TS_LO",   	    TCHAN_BASE_0 + 0x18, g_csr_ce4100_cru_LAST_TS_LO, "Correlated timestamp capture of STC", NULL },
    { "0_LAST_TS_HI",   	    TCHAN_BASE_0 + 0x1C, g_csr_ce4100_cru_LAST_TS_HI, "Most significant bit of STC", NULL },
    { "0_COMP_LO",      		TCHAN_BASE_0 + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
    { "0_COMP_HI",      		TCHAN_BASE_0 + 0x24, g_csr_ce4100_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
    { "0_VSYNC_LO",     	    TCHAN_BASE_0 + 0x28, NULL, "Vertical Sync Timestamp", NULL },
    { "0_VSYNC_HI",     		TCHAN_BASE_0 + 0x2c, g_csr_ce4100_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
    { "0_STC_LO",   	        TCHAN_BASE_0 + 0x30, NULL, "Current value of STC [31:0]", NULL },
    { "0_STC_HI",   	        TCHAN_BASE_0 + 0x34, g_csr_ce4100_cru_STC_HI, "Current value of STC [41:32]", NULL },

    { "1_TM_CMD",               TCHAN_BASE_1 + 0x00, g_csr_ce4100_cru_TM_CMD, "Configuration", NULL },
    { "1_DDS_FREQ",             TCHAN_BASE_1 + 0x08, g_csr_ce4100_cru_DDS_FREQ, "DDS Frequency", NULL },
    { "1_GET_SYSTIME",          TCHAN_BASE_1 + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
    { "1_SET_STC_LO",           TCHAN_BASE_1 + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
    { "1_SET_STC_HI",           TCHAN_BASE_1 + 0x14, g_csr_ce4100_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
    { "1_LAST_TS_LO",           TCHAN_BASE_1 + 0x18, g_csr_ce4100_cru_LAST_TS_LO, "Correlated timestamp capture of STC", NULL },
    { "1_LAST_TS_HI",           TCHAN_BASE_1 + 0x1C, g_csr_ce4100_cru_LAST_TS_HI, "Most significant bit of STC", NULL },
    { "1_COMP_LO",              TCHAN_BASE_1 + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
    { "1_COMP_HI",              TCHAN_BASE_1 + 0x24, g_csr_ce4100_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
    { "1_VSYNC_LO",             TCHAN_BASE_1 + 0x28, NULL, "Vertical Sync Timestamp", NULL },
    { "1_VSYNC_HI",             TCHAN_BASE_1 + 0x2c, g_csr_ce4100_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
    { "1_STC_LO",               TCHAN_BASE_1 + 0x30, NULL, "Current value of STC [31:0]", NULL },
    { "1_STC_HI",               TCHAN_BASE_1 + 0x34, g_csr_ce4100_cru_STC_HI, "Current value of STC [41:32]", NULL },

    { "2_TM_CMD",               TCHAN_BASE_2 + 0x00, g_csr_ce4100_cru_TM_CMD, "Configuration", NULL },
    { "2_DDS_FREQ",             TCHAN_BASE_2 + 0x08, g_csr_ce4100_cru_DDS_FREQ, "DDS Frequency", NULL },
    { "2_GET_SYSTIME",          TCHAN_BASE_2 + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
    { "2_SET_STC_LO",           TCHAN_BASE_2 + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
    { "2_SET_STC_HI",           TCHAN_BASE_2 + 0x14, g_csr_ce4100_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
    { "2_LAST_TS_LO",           TCHAN_BASE_2 + 0x18, g_csr_ce4100_cru_LAST_TS_LO, "Correlated timestamp capture of STC", NULL },
    { "2_LAST_TS_HI",           TCHAN_BASE_2 + 0x1C, g_csr_ce4100_cru_LAST_TS_HI, "Most significant bit of STC", NULL },
    { "2_COMP_LO",              TCHAN_BASE_2 + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
    { "2_COMP_HI",              TCHAN_BASE_2 + 0x24, g_csr_ce4100_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
    { "2_VSYNC_LO",             TCHAN_BASE_2 + 0x28, NULL, "Vertical Sync Timestamp", NULL },
    { "2_VSYNC_HI",             TCHAN_BASE_2 + 0x2c, g_csr_ce4100_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
    { "2_STC_LO",               TCHAN_BASE_2 + 0x30, NULL, "Current value of STC [31:0]", NULL },
    { "2_STC_HI",               TCHAN_BASE_2 + 0x34, g_csr_ce4100_cru_STC_HI, "Current value of STC [41:32]", NULL },

    { "3_TM_CMD",               TCHAN_BASE_3 + 0x00, g_csr_ce4100_cru_TM_CMD, "Configuration", NULL },
    { "3_DDS_FREQ",             TCHAN_BASE_3 + 0x08, g_csr_ce4100_cru_DDS_FREQ, "DDS Frequency", NULL },
    { "3_GET_SYSTIME",          TCHAN_BASE_3 + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
    { "3_SET_STC_LO",           TCHAN_BASE_3 + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
    { "3_SET_STC_HI",           TCHAN_BASE_3 + 0x14, g_csr_ce4100_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
    { "3_LAST_TS_LO",           TCHAN_BASE_3 + 0x18, g_csr_ce4100_cru_LAST_TS_LO, "Correlated timestamp capture of STC", NULL },
    { "3_LAST_TS_HI",           TCHAN_BASE_3 + 0x1C, g_csr_ce4100_cru_LAST_TS_HI, "Most significant bit of STC", NULL },
    { "3_COMP_LO",              TCHAN_BASE_3 + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
    { "3_COMP_HI",              TCHAN_BASE_3 + 0x24, g_csr_ce4100_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
    { "3_VSYNC_LO",             TCHAN_BASE_3 + 0x28, NULL, "Vertical Sync Timestamp", NULL },
    { "3_VSYNC_HI",             TCHAN_BASE_3 + 0x2c, g_csr_ce4100_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
    { "3_STC_LO",               TCHAN_BASE_3 + 0x30, NULL, "Current value of STC [31:0]", NULL },
    { "3_STC_HI",               TCHAN_BASE_3 + 0x34, g_csr_ce4100_cru_STC_HI, "Current value of STC [41:32]", NULL },

    { "4_TM_CMD",               TCHAN_BASE_4 + 0x00, g_csr_ce4100_cru_TM_CMD, "Configuration", NULL },
    { "4_DDS_FREQ",             TCHAN_BASE_4 + 0x08, g_csr_ce4100_cru_DDS_FREQ, "DDS Frequency", NULL },
    { "4_GET_SYSTIME",          TCHAN_BASE_4 + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
    { "4_SET_STC_LO",           TCHAN_BASE_4 + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
    { "4_SET_STC_HI",           TCHAN_BASE_4 + 0x14, g_csr_ce4100_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
    { "4_LAST_TS_LO",           TCHAN_BASE_4 + 0x18, g_csr_ce4100_cru_LAST_TS_LO, "Correlated timestamp capture of STC", NULL },
    { "4_LAST_TS_HI",           TCHAN_BASE_4 + 0x1C, g_csr_ce4100_cru_LAST_TS_HI, "Most significant bit of STC", NULL },
    { "4_COMP_LO",              TCHAN_BASE_4 + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
    { "4_COMP_HI",              TCHAN_BASE_4 + 0x24, g_csr_ce4100_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
    { "4_VSYNC_LO",             TCHAN_BASE_4 + 0x28, NULL, "Vertical Sync Timestamp", NULL },
    { "4_VSYNC_HI",             TCHAN_BASE_4 + 0x2c, g_csr_ce4100_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
    { "4_STC_LO",               TCHAN_BASE_4 + 0x30, NULL, "Current value of STC [31:0]", NULL },
    { "4_STC_HI",               TCHAN_BASE_4 + 0x34, g_csr_ce4100_cru_STC_HI, "Current value of STC [41:32]", NULL },

    { "5_TM_CMD",               TCHAN_BASE_5 + 0x00, g_csr_ce4100_cru_TM_CMD, "Configuration", NULL },
    { "5_DDS_FREQ",             TCHAN_BASE_5 + 0x08, g_csr_ce4100_cru_DDS_FREQ, "DDS Frequency", NULL },
    { "5_GET_SYSTIME",          TCHAN_BASE_5 + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
    { "5_SET_STC_LO",           TCHAN_BASE_5 + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
    { "5_SET_STC_HI",           TCHAN_BASE_5 + 0x14, g_csr_ce4100_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
    { "5_LAST_TS_LO",           TCHAN_BASE_5 + 0x18, g_csr_ce4100_cru_LAST_TS_LO, "Correlated timestamp capture of STC", NULL },
    { "5_LAST_TS_HI",           TCHAN_BASE_5 + 0x1C, g_csr_ce4100_cru_LAST_TS_HI, "Most significant bit of STC", NULL },
    { "5_COMP_LO",              TCHAN_BASE_5 + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
    { "5_COMP_HI",              TCHAN_BASE_5 + 0x24, g_csr_ce4100_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
    { "5_VSYNC_LO",             TCHAN_BASE_5 + 0x28, NULL, "Vertical Sync Timestamp", NULL },
    { "5_VSYNC_HI",             TCHAN_BASE_5 + 0x2c, g_csr_ce4100_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
    { "5_STC_LO",               TCHAN_BASE_5 + 0x30, NULL, "Current value of STC [31:0]", NULL },
    { "5_STC_HI",               TCHAN_BASE_5 + 0x34, g_csr_ce4100_cru_STC_HI, "Current value of STC [41:32]", NULL },

    { "INT_STATUS",              0x200, g_csr_ce4100_cru_INT_STATUS, "Interrupt Status", NULL },
    { "INT_ENABLE",              0x204, g_csr_ce4100_cru_INT_ENABLE, "Interrupt Mask", NULL },
    { "CW_OMAR_CTRL",              0x208, g_csr_ce4100_cru_CW_OMAR_CTRL, "Omar CW muxing", NULL },
    { "TS_DDS_MAP2",        0x20C, g_csr_ce4100_cru_TS_DDS_MAP2_CTRL, "TS DDS MAP Control", NULL},
    { "VCXO_DAC",              0x210, g_csr_ce4100_cru_VCXO_DAC_CTRL, "VCXO DAC Control", NULL},
    { "TS_DDS_MAP",     0x214, g_csr_ce4100_cru_TS_DDS_MAP_CTRL, "TS DDS MAP Control", NULL},
    { "VCXO_DIG_DAC",              0x218, g_csr_ce4100_cru_VCXO_DIG_DAC_CTRL, "VCXO DAC Control", NULL},
	
    { "NET_CMD",                  0x300, g_csr_ce4100_cru_NET_CMD, "Command and configuration of network timestamper", NULL },
    { "NET_DDS_FREQ",         0x308, g_csr_ce4100_cru_DDS_FREQ, "Frequency settings for network timebase DDS", NULL },
    { "NET_GET_SYSTIME",     0x30c, g_csr_ce4100_cru_NET_GET_SYSTIME, "Running status of System Time bits [31:0]", NULL },
    { "NET_CAPLOW_TX",       0x310, NULL, "System Time Capture register C [31:0] - Network TX packets", NULL },
    { "NET_CAPLOW_RX",       0x314, NULL, "System Time Capture register C [31:0] - Network RX packets", NULL },
    { "NET_COMPLOW_S",       0x318, NULL, "System Time Compare Register C [31:0] general purpose", NULL },

    { "FILTER_CFG_A1",		0x0380, g_csr_ce4100_cru_FILTER_CFG_A1, "Packet Filter configuration and Enables", NULL },
    { "FILTER_CFG_B1",		0x0384, g_csr_ce4100_cru_FILTER_CFG_B1, "Parameters for IP-based IEEE1588 protocol implementation", NULL },
    { "FILTER_CFG_C1",		0x0388, g_csr_ce4100_cru_FILTER_CFG_C1, "IP protocol data", NULL },
    { "FILTER_CFG_D1",		0x038C, g_csr_ce4100_cru_FILTER_CFG_D1, "IP Protocol data", NULL },
		
    { "MSG_DATA_1_TX",	0x03A0, g_csr_ce4100_cru_MSG_DATA_1, "Transmit Message Captured data", NULL },
    { "MSG_DATA_2_TX",	0x03A4, g_csr_ce4100_cru_MSG_DATA_2, "Transmit Message Captured data", NULL },
    { "MSG_DATA_3_TX",	0x03A8, g_csr_ce4100_cru_MSG_DATA_3, "Transmit Message Captured data", NULL },
		
    { "MSG_DATA_1_RX",	0x03E0, g_csr_ce4100_cru_MSG_DATA_1, "Receive Message Captured data", NULL },
    { "MSG_DATA_2_RX",	0x03E4, g_csr_ce4100_cru_MSG_DATA_2, "Receive Message Captured data", NULL },
    { "MSG_DATA_3_RX",	0x03E8, g_csr_ce4100_cru_MSG_DATA_3, "Receive Message Captured data", NULL },
	
    /* ---------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------- */
    /* The following definitions are abbreviations used by the driver / HAL to simplify register programming for multiple units */
    /* ---------------------------------------------------------------------------------- */
    /* ---------------------------------------------------------------------------------- */
   
    { "TM_CMD",            0x00, g_csr_ce4100_cru_TM_CMD, "Configuration", NULL },
    { "DDS_PHASE",         0x04, NULL, "unused: dds phase", NULL },
    { "DDS_FREQ",          0x08, g_csr_ce4100_cru_DDS_FREQ, "DDS Frequency", NULL },
    { "GET_SYSTIME",       0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
    { "SET_STC_LO",        0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
    { "SET_STC_HI",        0x14, g_csr_ce4100_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
    { "GET_STC_LO",        0x18, g_csr_ce4100_cru_LAST_TS_LO, "Correlated timestamp capture of STC", NULL },
    { "GET_STC_HI",        0x1C, g_csr_ce4100_cru_LAST_TS_HI, "Most significant bit of STC", NULL }, 
    { "COMP_LO",           0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
    { "COMP_HI",           0x24, g_csr_ce4100_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
    { "VSYNC_LO",          0x28, NULL, "Vertical Sync Timestamp", NULL },
    { "VSYNC_HI",          0x2c, g_csr_ce4100_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
    { "STC_LO",            0x30, NULL, "Current time from STC", NULL },
    { "STC_HI",            0x34, g_csr_ce4100_cru_COMP_HI, "Most significant bits of STC", NULL },

    { "UNIT_BASE",          0,      NULL, "Base of CRU", NULL },
    { "SUBUNIT_BASE_DIFF",  0x0040, NULL, "Interval of Sub-units", NULL },
    { "SUBUNIT_0_BASE",     0x0000, NULL, "Base of Unit 0", NULL },
    { "SUBUNIT_1_BASE",     0x0040, NULL, "Base of Unit 1", NULL },
    { "SUBUNIT_2_BASE",     0x0080, NULL, "Base of Unit 2", NULL },
    { "SUBUNIT_3_BASE",     0x00C0, NULL, "Base of Unit 3", NULL },
    { "SUBUNIT_4_BASE",     0x0100, NULL, "Base of Unit 4", NULL },
    { "SUBUNIT_5_BASE",     0x0140, NULL, "Base of Unit 5", NULL },
   
    { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct SVEN_Module_EventSpecific g_ce4100_cru_specific_events[] =
{
      { "HAL_ISR_WITH_NO_ALARM", 1, "Known to happen when alarm cancellation is done just before the alarm goes off, phys_clk: 0x%X,  curr_hi: %u, curr_lo: %u, alarm_hi: %u, alarm_lo: %u", NULL },
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_ce4100_cru_sven_module =
{
    "CE4100_CRU",
    SVEN_module_CE4100_CRU,
    0x00000400,            /* size of CSR Space */
#ifdef SVEN_INTERNAL_BUILD
    g_csr_ce4100_cru,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "CRU: CE4100 Clock Recovery Unit",
    g_ce4100_cru_specific_events,
    NULL /* extension list */
};
