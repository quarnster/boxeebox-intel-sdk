/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef CSR_GEN4_HDVCAP_C
#define CSR_GEN4_HDVCAP_C

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_unit.h"
#endif

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

#ifdef SVEN_INTERNAL_BUILD
#define GEN4_HDVCAP_BASE 0x0000
/*----------------------------------------------------------------------
Copied by Ramya Ranganathan from HDVCAP EAS Ver 1.0 on Feb23-09
Register 	        Offset  Default         Register Name/ Function
-------------------------------------------------------------------------
HDVCAP_GLOBAL_CTL	A000H	00000000H	Global Control
HDVCAP_VIDEO_CTL	A004H	00000000H	Video Control
HDVCAP_PDMA_CTL		A008H	00000000H	Pixel DMA Control
HDVCAP_INT_STATUS	A00CH	00000000H	Interrupt Status
HDVCAP_INT_MASK		A010H	00000000H	Interrupt Mask
HDVCAP_LINE_START_0	A014H	00000000H	Line Start Field 0
HDVCAP_LINE_END_0	A018H	00000000H	Line End Field 0
HDVCAP_LINE_START_1	A01CH	00000000H	Line Start Field 1
HDVCAP_LINE_END_1	A020H	00000000H	Line End Field 1
HDVCAP_BUF_A_FRAME_0	A024H	00000000H	Buffer A Frame 0 Base Address Pointer
HDVCAP_BUF_B_FRAME_0	A028H	00000000H	Buffer B Frame 0 Base Address Pointer 
HDVCAP_BUF_A_FRAME_1	A02CH	00000000H	Buffer A Frame 1 Base Address Pointer 
HDVCAP_BUF_B_FRAME_1	A030H	00000000H	Buffer B Frame 1 Base Address Pointer 
HDVCAP_PITCH		A034H	00000000H	Pitch
HDVCAP_BUF_A_SIZE	A038H	00000000H	Buffer A Size
HDVCAP_BUF_B_SIZE	A03CH	00000000H	Buffer B size
HDVCAP_TS_CTL		A040H	00000000H	Timestamp Control
HDVCAP_TS_PRELOAD_LSB	A044H	00000000H	Timestamp Preload Counter LSB
HDVCAP_TS_PRELOAD_MSB	A048H	00000000H	Timestamp Preload Counter MSB
HDVCAP_TS_LSB_0		A04CH	00000000H	Timestamp LSB Buffer 0
HDVCAP_TS_MSB_0		A050H	00000000H	Timestamp LSB Buffer 0
HDVCAP_TS_LSB_1		A054H	00000000H	Timestamp LSB Buffer 1
HDVCAP_TS_MSB_1		A058H	00000000H	Timestamp LSB Buffer 1
HDVCAP_TS_COUNTER_LSB	A05CH	00000000H	Timestamp Counter LSB
HDVCAP_TS_COUNTER_MSB	A060H	00000000H	Timestamp Counter MSB
HDVCAP_CSC_C		A064H	00000000H	Color Space Converter Clamp
HDVCAP_CSC_YG_OFF	A068H	00000000H	Color Space Converter Y/G Offset
HDVCAP_CSC_CB_OFF	A06CH	00000000H	Color Space Converter Cb/B offset
HDVCAP_CSC_CR_OFF	A070H	00000000H	Color Space Converter Cr/R offset
HDVCAP_CSC_C01		A074H	00000000H	Color Space Converter Coefficients 0 & 1
HDVCAP_CSC_C23		A078H	00000000H	Color Space Converter Coefficients 2 & 3
HDVCAP_CSC_C45		A07CH	00000000H	Color Space Converter Coefficients 4 & 5
HDVCAP_CSC_C67		A080H	00000000H	Color Space Converter Coefficients 6 & 7
HDVCAP_CSC_C8		A084H	00000000H	Color Space Converter Coefficient 8
HDVCAP_FILTER_C01	A088H	00000000H	444-to-422 Filter Coefficients 0 & 1
HDVCAP_FILTER_C23	A08CH	00000000H	444-to-422 Filter Coefficient 2
HDVCAP_PRNGSR		A090H	00000000H	Dithering PRNG Shift Register
HDVCAP_STAT_TOTAL	A094H	00000000H	Total pixels/line & lines/frame measured
HDVCAP_STAT_ACTIVE	A098H	00000000H	Active pixels/line & lines/frame measured
HDVCAP_STAT_ACTIVE	A09CH	00000000H	General statistics

*/

/****************************************************************/
#define GEN4_HDVCAP_GLOBAL_CTL_OFFSET	(GEN4_HDVCAP_BASE + 0x000	)
#define GEN4_HDVCAP_VIDEO_CTL_OFFSET	(GEN4_HDVCAP_BASE + 0x004		)
#define GEN4_HDVCAP_PDMA_CTL_OFFSET	(GEN4_HDVCAP_BASE + 0x008		)
#define GEN4_HDVCAP_INT_STATUS_OFFSET	(GEN4_HDVCAP_BASE + 0x00C	        )
#define GEN4_HDVCAP_INT_MASK_OFFSET	(GEN4_HDVCAP_BASE + 0x010	        )
#define GEN4_HDVCAP_LINE_START_0_OFFSET	(GEN4_HDVCAP_BASE + 0x014	)
#define GEN4_HDVCAP_LINE_END_0_OFFSET	(GEN4_HDVCAP_BASE + 0x018	)
#define GEN4_HDVCAP_LINE_START_1_OFFSET	(GEN4_HDVCAP_BASE + 0x01C	)
#define GEN4_HDVCAP_LINE_END_1_OFFSET	(GEN4_HDVCAP_BASE + 0x020	)
#define GEN4_HDVCAP_BUF_A_FRAME_0_OFFSET (GEN4_HDVCAP_BASE + 0x024	)
#define GEN4_HDVCAP_BUF_B_FRAME_0_OFFSET (GEN4_HDVCAP_BASE + 0x028	)
#define GEN4_HDVCAP_BUF_A_FRAME_1_OFFSET (GEN4_HDVCAP_BASE + 0x02C	)
#define GEN4_HDVCAP_BUF_B_FRAME_1_OFFSET (GEN4_HDVCAP_BASE + 0x030	)
#define GEN4_HDVCAP_PITCH_OFFSET	 (GEN4_HDVCAP_BASE + 0x034	)
#define GEN4_HDVCAP_BUF_A_SIZE_OFFSET	(GEN4_HDVCAP_BASE + 0x038	)
#define GEN4_HDVCAP_BUF_B_SIZE_OFFSET	(GEN4_HDVCAP_BASE + 0x03C	)
#define GEN4_HDVCAP_TS_CTL_OFFSET	(GEN4_HDVCAP_BASE + 0x040	)
#define GEN4_HDVCAP_TS_PRELOAD_LSB_OFFSET (GEN4_HDVCAP_BASE + 0x044      )
#define GEN4_HDVCAP_TS_PRELOAD_MSB_OFFSET	(GEN4_HDVCAP_BASE + 0x048	)
#define GEN4_HDVCAP_TS_LSB_0_OFFSET		(GEN4_HDVCAP_BASE + 0x04C	)
#define GEN4_HDVCAP_TS_MSB_0_OFFSET		(GEN4_HDVCAP_BASE + 0x050	)
#define GEN4_HDVCAP_TS_LSB_1_OFFSET		(GEN4_HDVCAP_BASE + 0x054	)
#define GEN4_HDVCAP_TS_MSB_1_OFFSET		(GEN4_HDVCAP_BASE + 0x058	)
#define GEN4_HDVCAP_TS_COUNTER_LSB_OFFSET	(GEN4_HDVCAP_BASE + 0x05C	)
#define GEN4_HDVCAP_TS_COUNTER_MSB_OFFSET	(GEN4_HDVCAP_BASE + 0x060	)
#define GEN4_HDVCAP_CSC_C_OFFSET		(GEN4_HDVCAP_BASE + 0x064	)
#define GEN4_HDVCAP_CSC_YG_OFF_OFFSET	(GEN4_HDVCAP_BASE + 0x068	)
#define GEN4_HDVCAP_CSC_CB_OFF_OFFSET	(GEN4_HDVCAP_BASE + 0x06C	)
#define GEN4_HDVCAP_CSC_CR_OFF_OFFSET	(GEN4_HDVCAP_BASE + 0x070	)
#define GEN4_HDVCAP_CSC_C01_OFFSET	(GEN4_HDVCAP_BASE + 0x074	)
#define GEN4_HDVCAP_CSC_C23_OFFSET	(GEN4_HDVCAP_BASE + 0x078	)
#define GEN4_HDVCAP_CSC_C45_OFFSET	(GEN4_HDVCAP_BASE + 0x07C	)
#define GEN4_HDVCAP_CSC_C67_OFFSET	(GEN4_HDVCAP_BASE + 0x080	)
#define GEN4_HDVCAP_CSC_C8_OFFSET	(GEN4_HDVCAP_BASE + 0x084	)
#define GEN4_HDVCAP_FILTER_C01_OFFSET	(GEN4_HDVCAP_BASE + 0x088	)
#define GEN4_HDVCAP_FILTER_C23_OFFSET	(GEN4_HDVCAP_BASE + 0x08C	)
#define GEN4_HDVCAP_PRNGSR_OFFSET	(GEN4_HDVCAP_BASE + 0x090	)
#define GEN4_HDVCAP_STAT_TOTAL_OFFSET	(GEN4_HDVCAP_BASE + 0x094	)
#define GEN4_HDVCAP_STAT_ACTIVE_OFFSET	(GEN4_HDVCAP_BASE + 0x098	)
/*#define GEN4_HDVCAP_STAT_ACTIVE_OFFSET	(GEN4_HDVCAP_BASE + 0x09C	) */
/*************************************************************************/

/* 5.3.1	HDVCAP Global Control Register
Memory Address Offset: A000H
Register Name: HDVCAP_GLOBAL_CTL
Clock Domain: hdvcap_clk
 
-------------------------------------------------------------------
Bits	Default	Access	Description
-------------------------------------------------------------------
31:3	0H	RV	Reserved
2	0H	RW	Capture Input Disable
			0 = Enabled
			1 = Disabled
1	0H	RW	Capture Clock Invert Control
			0 = Normal, Positive Edge Clock Capture
			1 = Invert, Negative Edge Clock Capture
0	0H	RW	HDVCAP Enable
			0 = Disabled
			1 = Enabled
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_GLOBAL_CTL[] = 
{
    { "CAP_INPUT_DISABLE",         2, 1, "", NULL },
    { "CAP_CLK_INV_CTRL",         1, 1, "", NULL },
    { "HDVCAP_ENABLE",         0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.2	HDVCAP Video Control Register
Memory Address Offset: A004H
Register Name: HDVCAP_VIDEO_CTL
Clock Domain: hdvcap_clk

-------------------------------------------------------------------
Bits	Default	Access	Description
-------------------------------------------------------------------
31:25	0H	RV	Reserved
24:21	0H	RW	BT656 Video Test Pattern Generator Mode Select
			0000 = NTSC Color Bars 100/0/75/0
			0001 = PAL Color Bars 100/0/75/0
			0010 = NTSC Color Bars 100/0/100/0
			0011 = PAL Color Bars 100/0/100/0
			0100 = NTSC Luma Ramp
			0101 = PAL Luma Ramp
			0110 = NTSC Red Screen
			0111 = PAL Red Screen
			1000 = NTSC Green Screen
			1001 = PAL Green Screen
			1010 = NTSC Blue Screen
			1011 = PAL Blue Screen
			1100 = NTSC Magenta Screen
			1101 = PAL Magenta Screen
			1110 = NTSC YCBCR Ramp
			1111 = PAL YCBCR Ramp
20	0H	RW	BT656 Video Test Pattern Generator Enable
			0 = Disable (normal operation)
			1 = Enable
19:17	0H	RW	12-bit to 10/8-bit Dithering/Rounding
			000 = Disabled (bypass)
			001 = 12-bit to 8-bit Dithering Enabled
			010 = 12-bit to 10-bit Dithering Enabled
			011 = 12-bit to 8-bit Rounding Enabled
			100 = 12-bit to 10-bit Rounding Enabled
			101-111 = Disabled (bypass)
16:15	0H	RW	444-to-422 Conversion Filter
			00 = Disabled (bypass)
			01 = Enable Filtering
			10 = Enable Pixel Drop Only (All pass filter)
			11 = Disabled (bypass)
14	0H	RW	Color Space Conversion
			1 = Enabled
			0 = Disabled (bypass)
13	0H	RW	External DE Polarity (EIA/CEA-861 only)
			0 = Active High
			1 = Active Low
12	0H	RW	External VSYNC Polarity (EIA/CEA-861 only)
			0 = Active Low
			1 = Active High
11	0H	RW	External HSYNC Polarity (EIA/CEA-861 only)
			0 = Active Low
			1 = Active High
10	0H	RW	Progressive Scan Mode (BT656, BT1120, EIA/CEA-861)
			0 = Interlace
			1 = Progressive
9:8	0H	RW	BT656 Swap Mode (see Table 5 5) (BT656 only) 
7:5	0H	RW	Video Input Mode (see Table 4 3)
4:0	0H	RW	Video Format Mode (see Table 4 4)
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_VIDEO_CTL[] = 
{
    { "BT656_VIDEO_TEST_PATTERN_GEN_MODE_SEL",  21, 4, "", NULL },
    { "BT656_VIDEO_TEST_PATTERN_GEN_EN",  20, 1, "", NULL },
    { "12BIT_TO_10_8Bit_DITHERING",  17, 3, "", NULL },
    { "444_TO_422_CONV_FILTER",  15, 2, "", NULL },
    { "CSC_EN",  14, 1, "", NULL },
    { "EXT_DE_POLARITY",  13, 1, "", NULL },
    { "EXT_VSYNC_POLARITY",  12, 1, "", NULL },
    { "EXT_HSYNC_POLARITY",  11, 1, "", NULL },
    { "PROGRESSIVE_SCAN_MODE",  10, 1, "", NULL },
    { "BT656_SWAP_MODE",        8, 2, "", NULL },
    { "VIDEO_INPUT_MODE",       5, 3, "", NULL },
    { "VIDEO_FMT_MODE",         0, 5, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.3	HDVCAP Pixel DMA Control Register
Memory Address Offset: 1408H
Register Name: HDVCAP_PDMA_CTL
Clock Domain: hdvcap_clk

-------------------------------------------------------------------
Bits	Default	Access	Description
-------------------------------------------------------------------

31:24	0H	RV	Reserved
23:16	0H	RW	Alpha Value
                        For ARGB or ACrYCb pack mode this value defines the alpha value
15:7	0H	RW	Unused
6	0H	RW	Address Out of Range Enable
                        0 = Disabled
                        1 = Enabled
5	0H	RW	Field 0 First
                        0 = Field 1 First
                        1 = Field 0 First
4	0H	RW	Stall Pixel DMA
                        0 = Normal
                        1 = Stall
3	0H	RW	Pack Mode (8-bit mode only)
                        0 = ARGB, ACrYCb
                        1 = Fully Packed
2	0H	RW	Pixel DMA FIFO Auto Clear Disable
                        0 = Enabled
                        1 = Disabled
1:0	0H	RW	Unused
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_PDMA_CTL[] = 
{
    { "RESERVED",  24, 8, "", NULL },
    { "ALPHA_VALUE",  16, 8, "", NULL },
    { "UNUSED_2",  7, 9, "", NULL },
    { "ADDRESS_OUT_OF_RANGE_ENABLE",  6, 1, "", NULL },
    { "FIELD_0_FIRST",  5, 1, "", NULL },
    { "STALL_PIXEL_DMA",  4, 1, "", NULL },
    { "PACK_MODE",        3, 1, "", NULL },
    { "PDMA_FIFO_AUTO_CLEAR_DISABLE",       2, 1, "", NULL },
    { "UNUSED_1",         0, 2, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.4	HDVCAP Interrupt Status Register
Memory Address Offset: 140CH
Register Name: HDVCAP_INT_STATUS
Clock Domain: hdvcap_clk

Table 5 7   HDVCAP Interrupt Status Register
-------------------------------------------------------------------------
Bits	Default	Access	Description
-------------------------------------------------------------------------
31:8	0H	RV	Reserved
7	0H	RWC	Frame Buffer 1 Field 1 Done Interrupt
                        1 = Active
                        0 = Non-active
6	0H	RWC	Frame Buffer 1 Field 0 Done Interrupt
                        1 = Active
                        0 = Non-active
5	0H	RWC	Frame Buffer 0 Field 1 Done Interrupt
                        1 = Active
                        0 = Non-active
4	0H	RWC	Frame Buffer 0 Field 0 Done Interrupt
                        1 = Active
                        0 = Non-active
3	0H	RWC	Buffer B Address Out of Range Interrupt
                        1 = Active
                        0 = Non-active
2	0H	RWC	Buffer A Address Out of Range Interrupt
                        1 = Active
                        0 = Non-active
1	0H	RWC	Pixel DMA Is Stalled Interrupt
                        1 = Active
                        0 = Non-active
0	0H	RWC	Video Sync Loss Interrupt
                        1 = Active
                        0 = Non-active
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_INT_STATUS[] = 
{
    { "RESERVED",  8, 24, "", NULL },
    { "BUF1_FIELD1_DNE_INT",  7, 1, "", NULL },
    { "BUF1_FIELD0_DNE_INT",  6, 1, "", NULL },
    { "BUF0_FIELD1_DNE_INT",  5, 1, "", NULL },
    { "BUF0_FIELD0_DNE_INT",  4, 1, "", NULL },
    { "BUF_B_OUT_OF_RANGE_INT",  3, 1, "", NULL },
    { "BUF_A_OUT_OF_RANGE_INT",        2, 1, "", NULL },
    { "PDMA_STALL_INT",       1, 1, "", NULL },
    { "VIDEO_SYNC_LOSS_INT",         0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.5	HDVCAP Interrupt Mask Register
Memory Address Offset: 1410H
Register Name: HDVCAP_INT_MASK
Clock Domain: hdvcap_clk

Table 5 8   HDVCAP Interrupt Mask Register

Bits	Default	Access	Description

31:8	0H	RV	Reserved
7	0H	RW	Frame Buffer 1 Field 1 Done Mask
                        1 = Enable
                        0 = Mask
6	0H	RW	Frame Buffer 1 Field 0 Done Mask
                        1 = Enable
                        0 = Mask
5	0H	RW	Frame Buffer 0 Field 1 Done Mask
                        1 = Enable
                        0 = Mask
4	0H	RW	Frame Buffer 0 Field 0 Done Mask
                        1 = Enable
                        0 = Mask
3	0H	RW	Buffer B Address Out of Range Mask
                        1 = Enable
                        0 = Mask
2	0H	RW	Buffer A Address Out of Range Mask
                        1 = Enable
                        0 = Mask
1	0H	RW	Pixel DMA Is Stalled Mask
                        1 = Enable
                        0 = Mask
0	0H	RW	Video Sync Loss Mask
                        1 = Enable
                        0 = Mask

*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_INT_MASK[] = 
{
    { "RESERVED",  8, 24, "", NULL },
    { "BUF1_FIELD1_DNE_INT",  7, 1, "", NULL },
    { "BUF1_FIELD0_DNE_INT",  6, 1, "", NULL },
    { "BUF0_FIELD1_DNE_INT",  5, 1, "", NULL },
    { "BUF0_FIELD0_DNE_INT",  4, 1, "", NULL },
    { "BUF_B_OUT_OF_RANGE_INT",  3, 1, "", NULL },
    { "BUF_A_OUT_OF_RANGE_INT",        2, 1, "", NULL },
    { "PDMA_STALL_INT",       1, 1, "", NULL },
    { "VIDEO_SYNC_LOSS_INT",         0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.6	HDVCAP Line Start Field 0 Register
Memory Address Offset: 1414H
Register Name: HDVCAP_LINE_START_0
Clock Domain: hdvcap_clk

Table 5 9   HDVCAP Line Start Field 0 Register
---------------------------------------------------
Bits	Default	Access	Description
---------------------------------------------------
31:13	0H	RV	Reserved
12:0	0H	RW	Starting line number for field 0 capture.  Valid range is 0 to 8191.
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_LINE_START_0[] = 
{
    { "RESERVED",  13, 19, "", NULL },
    { "LINE_START_NUM_FOR_FIELD0_CAP",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.7	HDVCAP Line End Field 0 Register
Memory Address Offset: 1418H
Register Name: HDVCAP_LINE_END_0
Clock Domain: hdvcap_clk

Table 5 10   HDVCAP Line End Field 0 Register
------------------------------------------------------------
Bits	Default	Access	Description
------------------------------------------------------------
31:13	0H	RV	Reserved
12:0	0H	RW	Ending line number for field 0 capture.  Valid range is 0 to 8191.
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_LINE_END_0[] = 
{
    { "RESERVED",  13, 19, "", NULL },
    { "LINE_END_NUM_FOR_FIELD0_CAP",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.6	HDVCAP Line Start Field 1 Register
Memory Address Offset: 141CH
Register Name: HDVCAP_LINE_START_1
Clock Domain: hdvcap_clk

Table 5 9   HDVCAP Line Start Field 1 Register
---------------------------------------------------
Bits	Default	Access	Description
---------------------------------------------------
31:13	0H	RV	Reserved
12:0	0H	RW	Starting line number for field 1 capture.  Valid range is 0 to 8191.
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_LINE_START_1[] = 
{
    { "RESERVED",  13, 19, "", NULL },
    { "LINE_START_NUM_FOR_FIELD1_CAP",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.7	HDVCAP Line End Field 1 Register
Memory Address Offset: 1420H
Register Name: HDVCAP_LINE_END_1
Clock Domain: hdvcap_clk

Table 5 10   HDVCAP Line End Field 1 Register
------------------------------------------------------------
Bits	Default	Access	Description
------------------------------------------------------------
31:13	0H	RV	Reserved
12:0	0H	RW	Ending line number for field 1 capture.  Valid range is 0 to 8191.
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_LINE_END_1[] = 
{
    { "RESERVED",  13, 19, "", NULL },
    { "LINE_END_NUM_FOR_FIELD1_CAP",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.10	HDVCAP Buffer A Frame 0 Register
Memory Address Offset: 1424H
Register Name: HDVCAP_BUF_A_FRAME_0
Clock Domain: hdvcap_clk

Table 5 13   HDVCAP Buffer A Frame 0 Register
--------------------------------------------------------
Bits	Default	Access	Description
--------------------------------------------------------
31:0	0H	RW	Buffer A component memory base address pointer for frame buffer 0
 */
static const struct EAS_RegBits g_csr_gen4_hdvcap_BUF_A_FRAME_0[] = 
{
    { "BUF_A_FRAME_0_BASE_ADDR_PTR",         0, 32, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.11	HDVCAP Buffer B Frame 0 Register
Memory Address Offset: 1428H
Register Name: HDVCAP_BUF_B_FRAME_0
Clock Domain: hdvcap_clk

Table 5 14   HDVCAP Buffer B Frame 0 Register
------------------------------------------------------
Bits	Default	Access	Description
------------------------------------------------------
31:0	0H	RW	Buffer B component memory base address pointer for frame buffer 0
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_BUF_B_FRAME_0[] = 
{
    { "BUF_B_FRAME_0_BASE_ADDR_PTR",         0, 32, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.12	HDVCAP Buffer A Frame 1 Register
Memory Address Offset: 142CH
Register Name: HDVCAP_BUF_A_FRAME_1
Clock Domain: hdvcap_clk

HDVCAP Buffer A Frame 1 Register
-------------------------------------------------------------
Bits	Default	Access	Description
-------------------------------------------------------------
31:0	0H	RW	Buffer A component memory base address pointer for frame buffer 1
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_BUF_A_FRAME_1[] = 
{
    { "BUF_A_FRAME_1_BASE_ADDR_PTR",         0, 32, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.13	HDVCAP Buffer B Frame 1 Register
Memory Address Offset: 1430H
Register Name: HDVCAP_BUF_B_FRAME_1
Clock Domain: hdvcap_clk

Table 5 16   HDVCAP Buffer B Frame 1 Register
--------------------------------------------------------
Bits	Default	Access	Description
--------------------------------------------------------
31:0	0H	RW	Buffer B component memory base address pointer for frame buffer 1
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_BUF_B_FRAME_1[] = 
{
    { "BUF_B_FRAME_1_BASE_ADDR_PTR",         0, 32, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.14	HDVCAP Pitch Register
Memory Address Offset: 1434H
Register Name: HDVCAP_PITCH
Clock Domain: hdvcap_clk

Table 5 17   HDVCAP Pitch Register
------------------------------------------------
Bits	Default	Access	Description
------------------------------------------------
31:16	0H	RV	Reserved
15:0	0H	RW	Horizontal pitch/stride in bytes
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_PITCH[] = 
{
    { "RESERVED",         16, 16, "", NULL },
    { "HORIZONTAL_PITCH_IN_BYTES",         0, 16, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.15	HDVCAP Buffer A Size Register
Memory Address Offset: 1438H
Register Name: HDVCAP_BUF_A_SIZE
Clock Domain: hdvcap_clk

Table 5 18   HDVCAP Buffer A Size Register
------------------------------------------
Bits	Default	Access	Description
------------------------------------------
31:0	0H	RW	Buffer A size in bytes
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_BUF_A_SIZE[] = 
{
    { "BUF_A_SIZE_IN_BYTES",         0, 32, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.16	HDVCAP Buffer B Size Register
Memory Address Offset: 143CH
Register Name: HDVCAP_BUF_B_SIZE
Clock Domain: hdvcap_clk

Table 5 19   HDVCAP Buffer B Size Register
------------------------------------------
Bits	Default	Access	Description
------------------------------------------
31:0	0H	RW	Buffer B size in bytes
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_BUF_B_SIZE[] = 
{
    { "BUF_B_SIZE_IN_BYTES",         0, 32, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.17	HDVCAP Timestamp Control Register
Memory Address Offset: 1440H
Register Name: HDVCAP_TS_CTL
Clock Domain: hdvcap_clk

Table 5 20   HDVCAP Timestamp Control Register
-----------------------------------------------
Bits	Default	Access	Description
-----------------------------------------------
31:1	0H	RV	Reserved
0	0H	WA	Load timestamp counter
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_TS_CTL[] = 
{
    { "RESERVED",         1, 31, "", NULL },
    { "LOAD_TS_COUNTER",         0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.18	HDVCAP Timestamp Preload Counter LSB Register
Memory Address Offset: 1444H
Register Name: HDVCAP_TS_PRELOAD_LSB
Clock Domain: hdvcap_clk

Table 5 21   HDVCAP Timestamp Preload LSB Register
----------------------------------------
Bits	Default	Access	Description
----------------------------------------
31:0	0H	RW	Timestamp preload counter LSB
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_TS_PRELOAD_LSB[] = 
{
    { "TS_PRELOAD_COUNTER_LSB",         0, 32, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


/*
5.3.19	HDVCAP Timestamp Preload Counter MSB Register
Memory Address Offset: 1448H
Register Name: HDVCAP_TS_PRELOAD_MSB
Clock Domain: hdvcap_clk

Table 5 22   HDVCAP Timestamp Preload MSB Register
-------------------------------------------
Bits	Default	Access	Description
-------------------------------------------
31:1	0H	RV	Reserved
0	0H	RW	Timestamp preload counter MSB
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_TS_PRELOAD_MSB[] = 
{
    { "RESERVED",         1, 31, "", NULL },
    { "TS_PRELOAD_COUNTER_MSB",         0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.20	HDVCAP Timestamp LSB Buffer 0 Register
Memory Address Offset: 144CH
Register Name: HDVCAP_TS_LSB_0
Clock Domain: hdvcap_clk

Table 5 23   HDVCAP Timestamp LSB Buffer 0 Register
-----------------------------------------------------
Bits	Default	Access	Description
-----------------------------------------------------
31:0	0H	RO	Captured timestamp [31:0] for frame buffer 0
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_TS_LSB_0[] = 
{
    { "CAP_TS_LSB_0",         0, 32, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


/*
5.3.21	HDVCAP Timestamp MSB Buffer 0 Register
Memory Address Offset: 1450H
Register Name: HDVCAP_TS_MSB_0
Clock Domain: hdvcap_clk

Table 5 24   HDVCAP Timestamp MSB Buffer 0 Register
---------------------------------------------
Bits	Default	Access	Description
---------------------------------------------
31:1	0H	RV	Reserved
0	0H	RO	Captured timestamp [32] for frame buffer 0
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_TS_MSB_0[] = 
{
    { "RESERVED",         1, 31, "", NULL },
    { "CAP_TS_MSB_0",         0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.22	HDVCAP Timestamp LSB Buffer 1 Register
Memory Address Offset: 1454H
Register Name: HDVCAP_TS_LSB_1
Clock Domain: hdvcap_clk

Table 5 25   HDVCAP Timestamp LSB Buffer 1 Register
-----------------------------------------------------
Bits	Default	Access	Description
-----------------------------------------------------
31:0	0H	RO	Captured timestamp [31:0] for frame buffer 1
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_TS_LSB_1[] = 
{
    { "CAP_TS_LSB_1",         0, 32, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.23	HDVCAP Timestamp MSB Buffer 1 Register
Memory Address Offset: 1458H
Register Name: HDVCAP_TS_MSB_1
Clock Domain: hdvcap_clk

Table 5 26   HDVCAP Timestamp MSB Buffer 1 Register
------------------------------------------
Bits	Default	Access	Description
------------------------------------------
31:1	0H	RV	Reserved
0	0H	RO	Captured timestamp [32] for frame buffer 1
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_TS_MSB_1[] = 
{
    { "RESERVED",         1, 31, "", NULL },
    { "CAP_TS_MSB_1",         0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.24	HDVCAP Timestamp Counter LSB Register
Memory Address Offset: 145CH
Register Name: HDVCAP_TS_COUNTER_LSB
Clock Domain: hdvcap_clk

Table 5 27   HDVCAP Timestamp Counter LSB Register
------------------------------------------------------
Bits	Default	Access	Description
------------------------------------------------------
31:0	0H	RO	Real-time timestamp counter value LSB
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_TS_COUNTER_LSB[] = 
{
    { "CAP_TS_LSB_1",         0, 32, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.25	HDVCAP Timestamp Counter MSB Register
Memory Address Offset: 1460H
Register Name: HDVCAP_TS_COUNTER_MSB
Clock Domain: hdvcap_clk

Table 5 28   HDVCAP Timestamp Counter MSB Register
-------------------------------------------
Bits	Default	Access	Description
-------------------------------------------
31:1	0H	RV	Reserved
0	0H	RO	Real-time timestamp counter value MSB
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_TS_COUNTER_MSB[] = 
{
    { "RESERVED",         1, 31, "", NULL },
    { "REALTIME_TS_COUNTER_VAL_MSB",         0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.26	HDVCAP CSC Clamp Register
Memory Address Offset: 1464H
Register Name: HDVCAP_CSC_C
Clock Domain: hdvcap_clk

Table 5 29   HDVCAP CSC Clamp Register
------------------------------------------------
Bits	Default	Access	Description
------------------------------------------------
31:6	0H	RV	Reserved
5	0H	RW	VAL_SHIFT_FACTOR
                        1 = Use full overrun value for shift value
                        0 = Use half overrun value for shift value
4	0H	RW	VAL_SHIFT_EN
                        1 = Enable output shift
                        0 = Disable output shift
3	0H	RW	C_OCLAMP_SEL
                        1 = Cb/B, Cr/R is clamped to 0xF00
                        0 = Cb/B, Cr/R is clamped to 0xEB0
2	0H	RW	EN_OCLAMP
                        1 = Output clamping enabled
                        0 = Output clamping disabled
                        If Enabled, 
                        Y/G Range: [0x100, 0xEB0]
                        Cb/B,Cr/R Range: [0x100, 0xEB0] when C_OCLAMP_SEL = 0
                        Cb/B,Cr/R Range: [0x100, 0xF00] when C_OCLAMP_SEL = 1
1	0H	RW	C_ICLAMP_SEL
                        1 = Cb/B, Cr/R is clamped to 0xF00
                        0 = Cb/B, Cr/R is clamped to 0xEB0
0	0H	RW	EN_ICLAMP
                        1 = Input clamping enabled
                        0 = Input clamping disabled
                        If Enabled, 
                        Y/G Range: [0x100, 0xEB0]
                        Cb/B,Cr/R Range: [0x100, 0xEB0] when C_ICLAMP_SEL = 0
                        Cb/B,Cr/R Range: [0x100, 0xF00] when C_ICLAMP_SEL = 1
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_CSC_C[] = 
{
    { "RESERVED",         6, 26, "", NULL },
    { "VAL_SHIFT_FACTOR",         5, 1, "", NULL },
    { "VAL_SHIFT_EN",         4, 1, "", NULL },
    { "C_OCLAMP_SEL",         3, 1, "", NULL },
    { "EN_OCLAMP",         2, 1, "", NULL },
    { "C_ICLAMP_SEL",         1, 1, "", NULL },
    { "EN_ICLAMP",         0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.27	HDVCAP CSC Y/G Offset Register
Memory Address Offset: 1468H
Register Name: HDVCAP_CSC_YG_OFF
Clock Domain: hdvcap_clk

Table 5 30   HDVCAP CSC Y/G Offset Register
---------------------------------------------
Bits	Default	Access	Description
---------------------------------------------
31:29	0H	RV	Reserved
28:16	0H	RW	YG_OOFF: 2's complement signed output offset for Y/G
15:13	0H	RW	Unused
12:0	0H	RW	YG_IOFF: 2's complement signed input offset for Y/G
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_CSC_YG_OFF[] = 
{
    { "RESERVED",         29, 3, "", NULL },
    { "YG_OOFF",         16, 13, "", NULL },
    { "UNUSED",         13, 3, "", NULL },
    { "YG_IOFF",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.28	HDVCAP CSC Cb/B Offset Register
Memory Address Offset: 146CH
Register Name: HDVCAP_CSC_CB_OFF
Clock Domain: hdvcap_clk
Table 5 31   HDVCAP CSC Cb/B Offset Register
Bits	Default	Access	Description
31:29	0H	RV	Reserved
28:16	0H	RW	CB_OOFF: 2's complement signed output offset for Cb/B
15:13	0H	RW	Unused
12:0	0H	RW	CB_IOFF: 2's complement signed input offset for Cb/B
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_CSC_CB_OFF[] = 
{
    { "RESERVED",         29, 3, "", NULL },
    { "CB_OOFF",         16, 13, "", NULL },
    { "UNUSED",         13, 3, "", NULL },
    { "CB_IOFF",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.29	HDVCAP CSC Cr/R Offset Register
Memory Address Offset: 1470H
Register Name: HDVCAP_CSC_CR_OFF
Clock Domain: hdvcap_clk
Table 5 32   HDVCAP CSC Cr/R Offset Register
Bits	Default	Access	Description
31:29	0H	RV	Reserved
28:16	0H	RW	CB_OOFF: 2's complement signed output offset for Cr/R
15:13	0H	RW	Unused
12:0	0H	RW	CB_IOFF: 2's complement signed input offset for Cr/R
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_CSC_CR_OFF[] = 
{
    { "RESERVED",         29, 3, "", NULL },
    { "CB_OOFF",         16, 13, "", NULL },
    { "UNUSED",         13, 3, "", NULL },
    { "CB_IOFF",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


/*
5.3.30	HDVCAP CSC Coefficient 01 Register
Memory Address Offset: 1474H
Register Name: HDVCAP_CSC_C01
Clock Domain: hdvcap_clk
Table 5 33   HDVCAP CSC Coefficient 01 Register
Bits	Default	Access	Description
31:29	0H	RV	Reserved
28:16	0H	RW	C1: 2's complement signed coefficient 1 (3.10 format)
15:13	0H	RW	Unused
12:0	0H	RW	C0: 2's complement signed coefficient 0 (3.10 format)
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_CSC_C01[] = 
{
    { "RESERVED",         29, 3, "", NULL },
    { "C1",         16, 13, "", NULL },
    { "UNUSED",         13, 3, "", NULL },
    { "C0",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.31	HDVCAP CSC Coefficient 23 Register
Memory Address Offset: 1478H
Register Name: HDVCAP_CSC_C23
Clock Domain: hdvcap_clk
Table 5 34   HDVCAP CSC Coefficient 23 Register
Bits	Default	Access	Description
31:29	0H	RV	Reserved
28:16	0H	RW	C3: 2's complement signed coefficient 3 (3.10 format)
15:13	0H	RW	Unused
12:0	0H	RW	C2: 2's complement signed coefficient 2 (3.10 format)
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_CSC_C23[] = 
{
    { "RESERVED",         29, 3, "", NULL },
    { "C3",         16, 13, "", NULL },
    { "UNUSED",         13, 3, "", NULL },
    { "C2",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


/*
5.3.32	HDVCAP CSC Coefficient 45 Register
Memory Address Offset: 147CH
Register Name: HDVCAP_CSC_C23
Clock Domain: hdvcap_clk
Table 5 35   HDVCAP CSC Coefficient 45 Register
Bits	Default	Access	Description
31:29	0H	RV	Reserved
28:16	0H	RW	C5: 2's complement signed coefficient 5 (3.10 format)
15:13	0H	RW	Unused
12:0	0H	RW	C4: 2's complement signed coefficient 4 (3.10 format)
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_CSC_C45[] = 
{
    { "RESERVED",         29, 3, "", NULL },
    { "C5",         16, 13, "", NULL },
    { "UNUSED",         13, 3, "", NULL },
    { "C4",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.33	HDVCAP CSC Coefficient 67 Register
Memory Address Offset: 1480H
Register Name: HDVCAP_CSC_C67
Clock Domain: hdvcap_clk
Table 5 36   HDVCAP CSC Coefficient 67 Register
Bits	Default	Access	Description
31:29	0H	RV	Reserved
28:16	0H	RW	C7: 2's complement signed coefficient 7 (3.10 format)
15:13	0H	RW	Unused
12:0	0H	RW	C6: 2's complement signed coefficient 6 (3.10 format)
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_CSC_C67[] = 
{
    { "RESERVED",         29, 3, "", NULL },
    { "C7",         16, 13, "", NULL },
    { "UNUSED",         13, 3, "", NULL },
    { "C6",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


/*
5.3.34	HDVCAP CSC Coefficient 8 Register
Memory Address Offset: 1484H
Register Name: HDVCAP_CSC_C8
Clock Domain: hdvcap_clk
Table 5 37   HDVCAP CSC Coefficient 8 Register
Bits	Default	Access	Description
31:13	0H	RV	Reserved
12:0	0H	RW	C8: 2's complement signed coefficient 8 (3.10 format)
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_CSC_C8[] = 
{
    { "RESERVED",         13, 19, "", NULL },
    { "C8",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.35	HDVCAP Filter Coefficient 01 Register
Memory Address Offset: 1488H
Register Name: HDVCAP_FILTER_C01
Clock Domain: hdvcap_clk
Table 5 38   HDVCAP Filter Coefficient 01 Register
Bits	Default	Access	Description
31:26	0H	RV	Reserved
25:16	0H	RW	C1: 2's complement signed coefficient 1
15:10	0H	RW	Unused
9:0	0H	RW	C0: 2's complement signed coefficient 0
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_FILTER_C01[] = 
{
    { "RESERVED",         26, 6, "", NULL },
    { "C1",         16, 10, "", NULL },
    { "UNUSED",         10, 6, "", NULL },
    { "C0",         0, 10, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.36	HDVCAP Filter Coefficient 23 Register
Memory Address Offset: 148CH
Register Name: HDVCAP_FILTER_C23
Clock Domain: hdvcap_clk
Table 5 39   HDVCAP Filter Coefficient 23 Register
Bits	Default	Access	Description
31:26	0H	RV	Reserved
25:16	0H	RW	C3: 2's complement signed coefficient 3
15:10	0H	RW	Unused
9:0	0H	RW	C2: 2's complement signed coefficient 2
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_FILTER_C23[] = 
{
    { "RESERVED",         26, 6, "", NULL },
    { "C3",         16, 10, "", NULL },
    { "UNUSED",         10, 6, "", NULL },
    { "C2",         0, 10, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.37	HDVCAP Dithering PRNG Shift Register
Memory Address Offset: 1490H
Register Name: HDVCAP_PRNGSR
Clock Domain: hdvcap_clk
Table 5 40   HDVCAP Dithering PRNG Shift Register
Bits	Default	Access	Description
31:30	0H	RV	Reserved
29:16	0H	RW	PRNG shift register seed 2
15:13	0H	RW	unused
12:0	0H	RW	PRNG shift register seed 1
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_PRNGSR[] = 
{
    { "RESERVED",         30, 2, "", NULL },
    { "PRNG_SEED2",         16, 13, "", NULL },
    { "UNUSED",         13, 3, "", NULL },
    { "PRNG_SEED1",         0, 13, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


/*
5.3.38	HDVCAP Statistics Total Register
Memory Address Offset: 1494H
Register Name: HDVCAP_STAT_TOTAL
Clock Domain: hdvcap_clk
Table 5 41   HDVCAP Statistics Total Register
Bits	Default	Access	Description
31:16	0H	RO	Total number of lines per frame (active + blanking)
15:0	0H	RO	Total number of pixels per line (active + blanking)
*/

static const struct EAS_RegBits g_csr_gen4_hdvcap_STAT_TOTAL[] = 
{
    { "PIXEL_PER_FRAME",         16, 16, "", NULL },
    { "PIXEL_PER_LINE",         0, 16, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*
5.3.39	HDVCAP Statistics Active Register
Memory Address Offset: 1498H
Register Name: HDVCAP_STAT_ACTIVE
Clock Domain: hdvcap_clk
Table 5 42   HDVCAP Statistics Active Register
Bits	Default	Access	Description
31:16	0H	RO	Total number of active lines per frame
15:0	0H	RO	Total number of active pixels per line
*/
static const struct EAS_RegBits g_csr_gen4_hdvcap_STAT_ACTIVE[] = 
{
    { "PIXEL_PER_FRAME",         16, 16, "", NULL },
    { "PIXEL_PER_LINE",         0, 16, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Copied from GEN4 HDVCAP EAS Rev 1.0 3/18/2009 by Ramya Ranganathan */
static const struct EAS_Register g_csr_gen4_hdvcap[] =
{
 {"GLOBAL_CTL", GEN4_HDVCAP_GLOBAL_CTL_OFFSET ,g_csr_gen4_hdvcap_GLOBAL_CTL,"",NULL},	
 {"VIDEO_CTL", GEN4_HDVCAP_VIDEO_CTL_OFFSET ,g_csr_gen4_hdvcap_VIDEO_CTL,"",NULL},	
 {"PDMA_CTL", GEN4_HDVCAP_PDMA_CTL_OFFSET  ,g_csr_gen4_hdvcap_PDMA_CTL,"",NULL},	
 {"INT_STATUS", GEN4_HDVCAP_INT_STATUS_OFFSET ,g_csr_gen4_hdvcap_INT_STATUS,"",NULL},	
 {"INT_MASK", GEN4_HDVCAP_INT_MASK_OFFSET ,g_csr_gen4_hdvcap_INT_MASK,"",NULL},	
 {"LINE_START_0", GEN4_HDVCAP_LINE_START_0_OFFSET	 ,g_csr_gen4_hdvcap_LINE_START_0,"",NULL},
 {"LINE_END_0", GEN4_HDVCAP_LINE_END_0_OFFSET ,g_csr_gen4_hdvcap_LINE_END_0,"",NULL},	
 {"LINE_START_1", GEN4_HDVCAP_LINE_START_1_OFFSET	 ,g_csr_gen4_hdvcap_LINE_START_1,"",NULL},
 {"LINE_END_1", GEN4_HDVCAP_LINE_END_1_OFFSET ,g_csr_gen4_hdvcap_LINE_END_1,"",NULL},	
 {"BUF_A_FRAME_0", GEN4_HDVCAP_BUF_A_FRAME_0_OFFSET  ,g_csr_gen4_hdvcap_BUF_A_FRAME_0,"",NULL},
 {"BUF_B_FRAME_0", GEN4_HDVCAP_BUF_B_FRAME_0_OFFSET  ,g_csr_gen4_hdvcap_BUF_B_FRAME_0,"",NULL},
 {"BUF_A_FRAME_1", GEN4_HDVCAP_BUF_A_FRAME_1_OFFSET  ,g_csr_gen4_hdvcap_BUF_A_FRAME_1,"",NULL},
 {"BUF_B_FRAME_1", GEN4_HDVCAP_BUF_B_FRAME_1_OFFSET  ,g_csr_gen4_hdvcap_BUF_B_FRAME_1,"",NULL},
 {"PITCH", GEN4_HDVCAP_PITCH_OFFSET ,g_csr_gen4_hdvcap_PITCH,"",NULL},	 
 {"BUF_A_SIZE", GEN4_HDVCAP_BUF_A_SIZE_OFFSET ,g_csr_gen4_hdvcap_BUF_A_SIZE,"",NULL},	
 {"BUF_B_SIZE", GEN4_HDVCAP_BUF_B_SIZE_OFFSET ,g_csr_gen4_hdvcap_BUF_B_SIZE,"",NULL},	
 {"TS_CTL", GEN4_HDVCAP_TS_CTL_OFFSET ,g_csr_gen4_hdvcap_TS_CTL,"",NULL},	
 {"TS_PRELOAD_LSB", GEN4_HDVCAP_TS_PRELOAD_LSB_OFFSET ,g_csr_gen4_hdvcap_TS_PRELOAD_LSB,"",NULL}, 
 {"TS_PRELOAD_MSB",  GEN4_HDVCAP_TS_PRELOAD_MSB_OFFSET ,g_csr_gen4_hdvcap_TS_PRELOAD_MSB,"",NULL},	
 {"TS_LSB",  GEN4_HDVCAP_TS_LSB_0_OFFSET ,g_csr_gen4_hdvcap_TS_LSB_0,"",NULL},		
 {"TS_MSB",  GEN4_HDVCAP_TS_MSB_0_OFFSET ,g_csr_gen4_hdvcap_TS_MSB_0,"",NULL},		
 {"TS_LSB_1",  GEN4_HDVCAP_TS_LSB_1_OFFSET ,g_csr_gen4_hdvcap_TS_LSB_1,"",NULL},		
 {"TS_MSB_1",  GEN4_HDVCAP_TS_MSB_1_OFFSET ,g_csr_gen4_hdvcap_TS_MSB_1,"",NULL},		
 {"TS_COUNTER_LSB",  GEN4_HDVCAP_TS_COUNTER_LSB_OFFSET ,g_csr_gen4_hdvcap_TS_COUNTER_LSB,"",NULL},	
 {"TS_COUNTER_MSB",  GEN4_HDVCAP_TS_COUNTER_MSB_OFFSET ,g_csr_gen4_hdvcap_TS_COUNTER_MSB,"",NULL},	
 {"CSC_C",  GEN4_HDVCAP_CSC_C_OFFSET	,g_csr_gen4_hdvcap_CSC_C ,"",NULL}, 	
 {"CSC_YG",  GEN4_HDVCAP_CSC_YG_OFF_OFFSET ,g_csr_gen4_hdvcap_CSC_YG_OFF ,"",NULL},	
 {"CSC_CB",  GEN4_HDVCAP_CSC_CB_OFF_OFFSET,g_csr_gen4_hdvcap_CSC_CB_OFF ,"",NULL}, 	
 {"CSC_CR",  GEN4_HDVCAP_CSC_CR_OFF_OFFSET,g_csr_gen4_hdvcap_CSC_CR_OFF ,"",NULL}, 	
 {"CSC_C01",  GEN4_HDVCAP_CSC_C01_OFFSET,g_csr_gen4_hdvcap_CSC_C01 ,"",NULL}, 	
 {"CSC_C23",  GEN4_HDVCAP_CSC_C23_OFFSET ,g_csr_gen4_hdvcap_CSC_C23,"",NULL},	
 {"CSC_C45",  GEN4_HDVCAP_CSC_C45_OFFSET,g_csr_gen4_hdvcap_CSC_C45 ,"",NULL}, 	
 {"CSC_C67",   GEN4_HDVCAP_CSC_C67_OFFSET,g_csr_gen4_hdvcap_CSC_C67 ,"",NULL}, 	
 {"CSC_C8",   GEN4_HDVCAP_CSC_C8_OFFSET ,g_csr_gen4_hdvcap_CSC_C8,"",NULL},	
 {"FILTER_C01",   GEN4_HDVCAP_FILTER_C01_OFFSET ,g_csr_gen4_hdvcap_FILTER_C01,"",NULL},	
 {"FILTER_C23",   GEN4_HDVCAP_FILTER_C23_OFFSET  ,g_csr_gen4_hdvcap_FILTER_C23,"",NULL},  	
 {"PRNGSR",   GEN4_HDVCAP_PRNGSR_OFFSET  ,g_csr_gen4_hdvcap_PRNGSR,"",NULL},	
 {"STAT_TOTAL",   GEN4_HDVCAP_STAT_TOTAL_OFFSET  ,g_csr_gen4_hdvcap_STAT_TOTAL,"",NULL},	
 {"STAT_ACTIVE",   GEN4_HDVCAP_STAT_ACTIVE_OFFSET	,g_csr_gen4_hdvcap_STAT_ACTIVE,"",NULL},
 { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

static const struct SVEN_Module_EventSpecific g_gen4_hdvcap_specific_events[] =
{
    #include "../ismd_standard_events.c"
    {"OPEN", 103, "\tStream ID: 0x%06x In Port ID: %d, Out Port ID: %d ", NULL},
    {"PORT_WRITE_FAILED", 1, "\tOutput port: %d O Buffer %d Cur depth: %d Valid: %d\n", NULL},
    {"VIDEO_MODE_CHANGE", 2, "\tAdjusted: %d Valid: %d Width: %d Height: %d Cont Rate: %d Refresh: %d\n", NULL},
    {"AUDIO_MODE_CHANGE", 3, "\tValid: %d Format: %d Num Ch: %d Freq: %d Sample Size: %d:\n", NULL},
    {"FRAME_RX", 4, "\tActual TS/2 = 0x%x Expected TS/2 = 0x%x\n", NULL},
    {"PLAY", 5, "\tState changed to play \n", NULL},
    {"STOP", 6, "\tState changed to stop \n", NULL},
    {"SUBMIT_VIDEO_BUFFER", 7, "\tWidth =%d Height =%d Addr = 0x%x Size = 0x%x Misc = 0x%x Stride = %d \n", NULL},
    {"SUBMIT_AUDIO_BUFFER", 8, "\tBuffer Size = %d Addr = 0x%x Size = 0x%x \n", NULL},
    {"NEW_SEGMENT_OUT", 9, "\tStart: %d Stop: %d Linear Start: %d Req Rate: %d Applied Rate: %d Valid: %d \n", NULL},
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_gen4_hdvcap_sven_module =
{
    "GEN4_HDVCAP",
    SVEN_module_GEN4_HDVCAP,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen4_hdvcap,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "HDVCAP: HDVCAP (GEN4)",
    g_gen4_hdvcap_specific_events,
    NULL /* extension list */
};

#endif
