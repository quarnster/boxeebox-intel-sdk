/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

/* Written by: Reshma Kamat */


#ifndef CSR_GEN4_GV_C
#define CSR_GEN4_GV_C "csr_gen4_gv.c"

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

#define GV_BASE		0x7000

static const struct EAS_RegBits g_csr_gen4_gv_GV_CONTROL[] = 
{
	{"RESERVED0",					8, 24, "Reserved", NULL },
	{"WATCHDOG_TIMER_ENABLE",		7, 1,  "Enable counting of 32-bit free running down counter", NULL },
	{"ATR",							5, 2,  "RISC access to all address space", NULL },
	{"CW_PIO_SEL",					3, 2,  "Chipwatcher mux sel", NULL },
	{"RESERVED1",					1, 2,  "Reserved", NULL },
	{"GV_RESET_I",					0, 1,  "RISC Global vSparc Reset", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_ICACHE_BASE_ADDR[] =
{
	{"BASE_ADDR",					14, 18,  "Instruction code base system address", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_WATCHDOG_TIMER[] =
{
	{"TIMER", 						0, 32,  "32 bit down counting watchdog timer", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_CACHELINE_INVALIDATE0[] =
{
	{"CACHE_INVL_MSK",				0, 32, 	"32-bit mask for cacheline invalidate", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_CACHELINE_INVALIDATE1[] =
{
	{"CACHE_INVL_MSK",				0, 32, 	"32-bit mask for cacheline invalidate", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_CACHELINE_INVALIDATE2[] =
{
	{"CACHE_INVL_MSK",				0, 32, 	"32-bit mask for cacheline invalidate", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_GV_DMA_SYS_ADDR[] =
{
	{"SYS_ADDR",				2, 30,  "32-bit System address. It should be DWORD aligned", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_GV_DMA_LCL_ADDR[] =
{
	{"RESERVED",					16, 16,  "Reserved", NULL },
	{"LCL_ADDR",					2, 14,	 "16-bit local address It must be DOWRD aligned", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_GV_DMA_CTRL_STATUS[] =
{
	{"RESERVED",					23, 9,  "Reserved", NULL },
	{"DMA_START",					22, 1,  "Initiates DMA. This bit self clears", NULL },
	{"DMA_DONE",					21, 1,  "Inidcates completion of DMA", NULL },
	{"DMA_BUSY",					20, 1,  "Indicates DMA unit is busy", NULL },
	{"DMA_BURST", 					18, 2,  "Set maximum burst size to use on SAP bus", NULL },
	{"BYTE_SWAP", 					17, 1,  "Byte swapped within a word during trasnfer", NULL },
	{"DMA_DIR",						16, 1,  "If set, transfer is from Local to system side", NULL },
	{"DMA_SIZE",					0, 16,  "16-bit DMA transfer count", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_HOST_DOORBELL[] =
{
	{"CMD",				0, 32,  "32-bit software defined doorbell message", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_HOST_IPC_STATUS[] =
{
	{"RESERVED",					2, 30,  "Reserved", NULL },
	{"DONE", 						1, 1,   "Mailbox is ready for next message", NULL },
	{"READY",						0, 1,   "Doorbell register is ready for next message", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_GV_DOORBELL[] =
{
	{"CMD",				0, 32,  "32-bit software defined doorbell message", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_GV_IPC_STATUS[] =
{
	{"RESERVED",					2, 30,  "Reserved", NULL },
	{"DONE", 						1, 1,   "Mailbox is ready for next message", NULL },
	{"READY",						0, 1,   "Doorbell register is ready for next message", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_GV_SEC_STATUS[] =
{
	{"AV_BASE_ADDR",				29, 3,  "base address of the 512MB AV window", NULL },
	{"RESERVED0",					25, 4,  "Reserved", NULL },
	{"AV_BASE_ADDR_LCK",			24, 1,  "AV_window has been locked", NULL },
	{"RESERVED1",					2, 22,  "Reserved", NULL },
	{"AGNT_TRSTD",					1, 1,   "Determines if Global VSparc is trusted or not", NULL },
	{"EXEN_ENBL",					0, 1,   "Execution Enable", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_GV_SEC_THREAT[] =
{
	{"RESERVED",					1, 31,  "Reserved", NULL },
	{"SEC_THREAT",					0, 1,   "Security Threat bit", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_GV_SEC_CTRL[] =
{
	{"RESERVED",					3, 29,	"Reserved", NULL },
	{"SEC_ATTR",					0, 3,   "Security Attribute of Master", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_HOST_INTR_ENBL[] =
{
	{"RESERVED",					7, 25,  "Reserved", NULL },
	{"VSP_ILLEGAL_EVT",				6, 1,   "VSParc Illegal Event", NULL },
	{"WATCHDOG_TIMER",				5, 1,   "Watchdog timer event interrupt enable", NULL },
	{"EXT_EVT",						4, 1,   "External Event interrupt enable", NULL },
	{"GV_EVT",						3, 1,   "Global vSparc event interrupt enable and status register", NULL },
	{"GV_DMA_DONE", 				2, 1,   "Global vSparc DMA event interrupt enable and status register", NULL },
	{"HOST_DOORBELL_EVT", 			1, 1,   "Host doorbell event interrupt enable and status register", NULL },
	{"GV_DOORBELL_EVT",				0, 1,   "Global vSparc Doorbell event interrupt enable and status register", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_GV_INTR_ENBL[] =
{
	{"RESERVED",					7, 25,  "Reserved", NULL },
	{"VSP_ILLEGAL_EVT",				6, 1,   "VSParc Illegal Event", NULL },
	{"WATCHDOG_TIMER",				5, 1,   "Watchdog timer event interrupt enable", NULL },
	{"EXT_EVT",						4, 1,   "External Event interrupt enable", NULL },
	{"GV_EVT",						3, 1,   "Global vSparc event interrupt enable and status register", NULL },
	{"GV_DMA_DONE", 				2, 1,   "Global vSparc DMA event interrupt enable and status register", NULL },
	{"HOST_DOORBELL_EVT", 			1, 1,   "Host doorbell event interrupt enable and status register", NULL },
	{"GV_DOORBELL_EVT",				0, 1,   "Global vSparc Doorbell event interrupt enable and status register", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_INTR_STATUS[] =
{
	{"RESERVED",					7, 25,  "Reserved", NULL },
	{"VSP_ILLEGAL_EVT",				6, 1,   "VSParc Illegal Event", NULL },
	{"WATCHDOG_TIMER",				5, 1,   "Watchdog timer event interrupt enable", NULL },
	{"EXT_EVT",						4, 1,   "External Event interrupt enable", NULL },
	{"GV_EVT",						3, 1,   "Global vSparc event interrupt enable and status register", NULL },
	{"GV_DMA_DONE", 				2, 1,   "Global vSparc DMA event interrupt enable and status register", NULL },
	{"HOST_DOORBELL_EVT", 			1, 1,   "Host doorbell event interrupt enable and status register", NULL },
	{"GV_DOORBELL_EVT",				0, 1,   "Global vSparc Doorbell event interrupt enable and status register", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_EXT_EVT_ENBL[] =
{
	{"VSP_ILLEGAL_ACCESS",			31, 1,   "bit set when vSparc does illegal data fetch", NULL },
	{"RESERVED0",					18, 13,  "Reserved", NULL },
	{"MFD_MP_DMA_INTR",				17, 1,   "Interrupt from MFD Mini Pipe Streamer DMA", NULL },
	{"MFD_MP_SCD_INTR",				16, 1,   "Interrupt from MFD Mini Pipe Start Code Detector", NULL },
	{"MFD_MP_BSD_INTR",				15, 1,   "Interrupt from MFD Mini Pipe Byte Stream Decoder", NULL },
	{"MFD_CORE_INT",				14, 1,   "Interrupt from MFD H264/ VC1 pipeline", NULL },
	{"MFD_SCD_INT",					13, 1,   "Interrupt from MFD pipeline Start Code detector", NULL },
	{"MFD_DMA_INT",					12, 1,   "Interrupt from MFD pipeline's Streamer DMAs", NULL },
	{"RESERVED1",					0, 12,   "Reserved", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_EXT_EVT_STAT[] =
{
	{"VSP_ILLEGAL_ACCESS",			31, 1,   "bit set when vSparc does illegal data fetch", NULL },
	{"RESERVED0",					18, 13,  "Reserved", NULL },
	{"MFD_MP_DMA_INTR",				17, 1,   "Interrupt from MFD Mini Pipe Streamer DMA", NULL },
	{"MFD_MP_SCD_INTR",				16, 1,   "Interrupt from MFD Mini Pipe Start Code Detector", NULL },
	{"MFD_MP_BSD_INTR",				15, 1,   "Interrupt from MFD Mini Pipe Byte Stream Decoder", NULL },
	{"MFD_CORE_INT",				14, 1,   "Interrupt from MFD H264/ VC1 pipeline", NULL },
	{"MFD_SCD_INT",					13, 1,   "Interrupt from MFD pipeline Start Code detector", NULL },
	{"MFD_DMA_INT",					12, 1,   "Interrupt from MFD pipeline's Streamer DMAs", NULL },
	{"RESERVED1",					0, 12,   "Reserved", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_SYS_EVT_BITS[] =
{
	{"VCAP",				   28, 1,  "Video Capture", NULL },
	{"UART1",				27, 1,  "UART 1", NULL },
	{"SATA1",			   26, 1,  "SATA 1", NULL },
	{"PMU",			      25, 1,  "PMU", NULL },
	{"USB1",			      24, 1,  "USB 1", NULL },
	{"SATA0",			   23, 1,  "SATA 0", NULL },
	{"USB0",			      22, 1,  "USB 0", NULL },
	{"GIGE",			      21, 1,  "Gigabit Ethernet", NULL },
	{"RES1",			      19, 2,  "reserved[19-20]", NULL },
	{"SPI",			      18, 1,  "SPI", NULL },
	{"SMART_CARD",			17, 1,  "Smart Card", NULL },
	{"I2C",			      16, 1,  "I2C 0/1/2", NULL },
	{"GPIO_AUX",			15, 1,  "GPIO_AUX", NULL },
	{"UART0",				14, 1,  "UART 0", NULL },
	{"NAND",				   13, 1,  "SEC", NULL },
	{"SEC",				   12, 1,  "SEC", NULL },
	{"HDMI_TX",				11, 1,  "HDMI Transmitter", NULL },
	{"DPE",					10, 1,  "Display Processing Engine", NULL },
	{"VDC",					9, 1,   "Video Display Controller", NULL },
	{"AUD",					8, 1,   "Audio Interface", NULL },
	{"DSP1",					7, 1,   "DSP 0", NULL },
	{"DSP0",					6, 1,   "DSP 0", NULL },
	{"TSD",					5, 1,   "Transport Stream Demux", NULL },
	{"TSP",					4, 1,   "Transport Stream Prefilter", NULL },
	{"CRU",					3, 1,   "Clock Recovery Unit", NULL },
	{"MFD",					2, 1,   "Viddec", NULL },
	{"RES0",					1, 1,   "Reserved", NULL },
	{"GFX",					0, 1,   "Graphics", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_FS_PC[] =
{
	{"GV_DB_FPC",					0, 32,	"Address of current instruction in fetch stage of VSP pipeline", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_FS_STAT[] =
{
	{"RESERVED",					1, 31,  "Reserved", NULL },
	{"GV_DB_SU",					0, 1,   "System/User of instruction in fetch stage", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DS_PC[] =
{
	{"GV_DB_DPC",					0, 32,	"Address of current instruction in decode stage of VSP pipeline", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DS_INST[] =
{
	{"GV_DB_DINST",					0, 32,	"Current instruction in decode stage of VSP pipeline", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DS_STAT[] =
{
	{"RESERVED",					7, 25,  "Reserved", NULL },
	{"GV_DB_DCWP",					4, 3,   "Decode stage Current window pointer", NULL },
	{"GV_DB_DICC",					0, 4,   "Decode stage Instruction Condition codes", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_ES_PC[] =
{
	{"GV_DB_EPC",					0, 32,	"Address of current instruction in execution stage of VSP pipeline", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_ES_INST[] =
{
	{"GV_DB_EINST",					0, 32,	"Current instruction in decode stage of VSP pipeline", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_ES_STAT[] =
{
	{"RESERVED",					7, 25,  "Reserved", NULL },
	{"GV_DB_ECWP",					4, 3,   "Execution stage Current window pointer", NULL },
	{"GV_DB_EICC",					0, 4,   "Execution stage Instruction Condition codes", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_MS_STAT[] =
{
	{"RESERVED",					7, 25,  "Reserved", NULL },
	{"GV_DB_MCWP",					4, 3,   "Memory stage Current window pointer", NULL },
	{"GV_DB_MICC",					0, 4,   "Memory stage Instruction Condition codes", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_WS_STAT[] =
{
	{"RESERVED",					7, 25,  "Reserved", NULL },
	{"GV_DB_WCWP",					4, 3,   "Write stage Current window pointer", NULL },
	{"GV_DB_WICC",					0, 4,   "Write stage Instruction Condition codes", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_CTRL[] =
{
	{"RESERVED0", 					12, 20,	 "Reserved", NULL },
	{"GV_DB_DBP3EN",				11, 1,   "Data Address Breakpoint 3 Enable", NULL },
	{"GV_DB_DBP2EN", 				10, 1,   "Data Address Breakpoint 2 Enable", NULL },
	{"GV_DB_DBP1EN",				9, 1,    "Data Address Breakpoint 1 Enable", NULL },
	{"GV_DB_DBP0EN", 				8, 1,    "Data Address Breakpoint 0 Enable", NULL },
	{"GV_DB_PCBP3EN",				7, 1, 	 "Program Counter Breakpoint 3 Enable", NULL },
	{"GV_DB_PCBP2EN", 	    		6, 1,    "program Counter Breakpoint 2 Enable", NULL },
	{"GV_DB_PCBP1EN",				5, 1,    "program Counter Breakpoint 1 Enable", NULL },
	{"GV_DB_PCBP0EN",				4, 1,    "Program Counter Breakpoint 0 Enable", NULL },
	{"RESERVED1",					2, 2,    "Reserved", NULL },
	{"GV_DB_SINGLE_STEP",			1, 1,    "Single Step", NULL },
	{"RESERVED2",					0, 1,    "Reserved", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_STAT[] =
{
	{"RESERVED0", 					12, 20,	 "Reserved", NULL },
	{"GV_DB_DBP3TR",				11, 1,   "Data Address Breakpoint 3 Enable cleared by writing to this status register", NULL },
	{"GV_DB_DBP2TR", 				10, 1,   "Data Address Breakpoint 2 Enable cleared by writing to this status register", NULL },
	{"GV_DB_DBP1TR",				9, 1,    "Data Address Breakpoint 1 Enable cleared by writing to this status register", NULL },
	{"GV_DB_DBP0TR", 				8, 1,    "Data Address Breakpoint 0 Enable cleared by writing to this status register", NULL },
	{"GV_DB_PCBP3TR",				7, 1, 	 "Program Counter Breakpoint 3 Enable cleared by writing to this status register", NULL },
	{"GV_DB_PCBP2TR", 	    		6, 1,    "program Counter Breakpoint 2 Enable cleared by writing to this status register", NULL },
	{"GV_DB_PCBP1TR",				5, 1,    "program Counter Breakpoint 1 Enable cleared by writing to this status register", NULL },
	{"GV_DB_PCBP0TR",				4, 1,    "Program Counter Breakpoint 0 Enable cleared by writing to this status register", NULL },
	{"RESERVED1",					2, 2,    "Reserved", NULL },
	{"GV_DB_STALLED",				1, 1,    "Processor Stalled", NULL },
	{"GV_DB_ERR",					0, 1,    "vSPARC Error", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_PCBP0[] =
{
	{"GV_DB_PCBP0",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_PCBP0_MSK[] =
{
	{"GV_DB_PCBP0MSK",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_PCBP1[] =
{
	{"GV_DB_PCBP1",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_PCBP1_MSK[] =
{
	{"GV_DB_PCBP1MSK",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_PCBP2[] =
{
	{"GV_DB_PCBP2",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_PCBP2_MSK[] =
{
	{"GV_DB_PCBP2MSK",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_PCBP3[] =
{
	{"GV_DB_PCBP3",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_PCBP3_MSK[] =
{
	{"GV_DB_PCBP3MSK",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DBP0[] =
{
	{"GV_DB_DBP0",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DBP0_MSK[] =
{
	{"GV_DB_DBP0MSK",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DBP1[] =
{
	{"GV_DB_DBP1",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DBP1_MSK[] =
{
	{"GV_DB_DBP1MSK",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DBP2[] =
{
	{"GV_DB_DBP2",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DBP2_MSK[] =
{
	{"GV_DB_DBP2MSK",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DBP3[] =
{
	{"GV_DB_DBP3",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_gv_DBG_DBP3_MSK[] =
{
	{"GV_DB_DBP3MSK",					0, 32,  "Address of instruction vSparc will break on", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

/*static const struct EAS_RegBits g_csr_gen4_gv_REG_FILE_ACCESS[] =
{
}
*/

static const struct EAS_Register g_csr_gen4_gv[] =
{
	{"CONTROL",						(GV_BASE+0x00), g_csr_gen4_gv_GV_CONTROL, "Reset and Configuration", NULL },
	{"ICACHE_BASE_ADDRESS",			(GV_BASE+0X04), g_csr_gen4_gv_ICACHE_BASE_ADDR, "Instruction Cache base address", NULL },
	{"WATCHDOG_TIMER",				(GV_BASE+0x08), g_csr_gen4_gv_WATCHDOG_TIMER, "Watchdog Timer", NULL },
	{"CACHELINE_INVALIDATE0",		(GV_BASE+0x10), g_csr_gen4_gv_CACHELINE_INVALIDATE0, "Icacheline invalidate mask", NULL },
	{"CACHELINE_INVALIDATE1",		(GV_BASE+0x14), g_csr_gen4_gv_CACHELINE_INVALIDATE1, "Icacheline invalidate mask", NULL },
	{"CACHELINE_INVALIDATE2",		(GV_BASE+0x18), g_csr_gen4_gv_CACHELINE_INVALIDATE2, "Icacheline invalidate mask", NULL },
	{"DMA_SYSTEM_ADDRESS",			(GV_BASE+0x20), g_csr_gen4_gv_GV_DMA_SYS_ADDR, "DMA system address", NULL },
	{"DMA_LOCAL_ADDRESS",			(GV_BASE+0x24), g_csr_gen4_gv_GV_DMA_LCL_ADDR, "DMA local address", NULL },
	{"DMA_CONTROL_STATUS",			(GV_BASE+0x28), g_csr_gen4_gv_GV_DMA_CTRL_STATUS, "DMA control and status register", NULL },
	{"HOST_DOORBELL", 				(GV_BASE+0x30), g_csr_gen4_gv_HOST_DOORBELL, "Host processor Doorbell register", NULL },
	{"HOST_IPC_STATUS",				(GV_BASE+0x34), g_csr_gen4_gv_HOST_IPC_STATUS, "Host IPC Status register", NULL },
	{"DOORBELL",					(GV_BASE+0x38), g_csr_gen4_gv_GV_DOORBELL, "Global vSparc Doorbell Register", NULL },
	{"IPC_STATUS",					(GV_BASE+0x3c), g_csr_gen4_gv_GV_IPC_STATUS, "Global vSparc IPC Status Register", NULL },
	{"SEC_STATUS",					(GV_BASE+0x40), g_csr_gen4_gv_GV_SEC_STATUS, "GV Security Status Regsiter", NULL },
	{"SEC_THREAT",					(GV_BASE+0x44), g_csr_gen4_gv_GV_SEC_THREAT, "Security Threat Regsiter", NULL },
	{"SEC_CONTROL",					(GV_BASE+0x48), g_csr_gen4_gv_GV_SEC_CTRL, "Secuurity Control Regsiter", NULL },
	{"HOST_INTERRUPT_ENABLE",		(GV_BASE+0x50), g_csr_gen4_gv_HOST_INTR_ENBL, "Interrupt Enable Register for host processor", NULL },
	{"INTERRUPT_ENABLE",			(GV_BASE+0x54), g_csr_gen4_gv_GV_INTR_ENBL, "Interrupt Enable Register for GV", NULL },
	{"INTERRUPT_STATUS",			(GV_BASE+0x58), g_csr_gen4_gv_INTR_STATUS, "Interrupt Status Register", NULL },
	{"SYS_EVENT_ENABLE", 			(GV_BASE+0x60), g_csr_gen4_gv_SYS_EVT_BITS, "System Event interrupt enable register", NULL },
	{"SYS_EVENT_STATUS",			(GV_BASE+0x64),    g_csr_gen4_gv_SYS_EVT_BITS, "System Event Status Regsiter", NULL },
	{"EXT_EVENT_ENABLE", 			(GV_BASE+0x70), g_csr_gen4_gv_EXT_EVT_ENBL, "External Event interrupt enable register", NULL },
	{"EXT_EVENT_STATUS",			(GV_BASE+0x74), g_csr_gen4_gv_EXT_EVT_STAT, "External Event Status Regsiter", NULL },
	{"DBG_FS_PC",					(GV_BASE+0x400), g_csr_gen4_gv_DBG_FS_PC, "Fetch Stage Program Counter", NULL },
	{"DBG_FS_STATUS",				(GV_BASE+0x408), g_csr_gen4_gv_DBG_FS_STAT, "Fetch Stage Status", NULL },
	{"DBG_DS_PC", 					(GV_BASE+0x410), g_csr_gen4_gv_DBG_DS_PC, "Decode Stage Program counter", NULL },
	{"DBG_DS_INST", 				(GV_BASE+0x414), g_csr_gen4_gv_DBG_DS_INST, "Decode Stage Instruction", NULL },
	{"DBG_DS_STATUS",				(GV_BASE+0x418), g_csr_gen4_gv_DBG_DS_STAT, "Decode Stage Status Register", NULL },
	{"DBG_ES_PC",					(GV_BASE+0x420), g_csr_gen4_gv_DBG_ES_PC, "Execution stage Program Counter", NULL },
	{"DBG_ES_INST",	 				(GV_BASE+0x424), g_csr_gen4_gv_DBG_ES_INST, "Execution Stage Instruction", NULL },
	{"DBG_ES_STATUS",				(GV_BASE+0x428), g_csr_gen4_gv_DBG_ES_STAT, "execution Stage Status", NULL },
	{"DBG_MS_STATUS",				(GV_BASE+0x438), g_csr_gen4_gv_DBG_MS_STAT, "Mmeory Stage Status", NULL },
	{"DBG_WS_STATUS",				(GV_BASE+0x448), g_csr_gen4_gv_DBG_WS_STAT, "Write Stage Status", NULL },
	{"DBG_CONTROL",					(GV_BASE+0x500), g_csr_gen4_gv_DBG_CTRL, "Debugger Control", NULL },
	{"DBG_STATUS",					(GV_BASE+0x504), g_csr_gen4_gv_DBG_STAT, "Debugger Status", NULL },
	{"DBG_PC_BREAKPOINT0",			(GV_BASE+0x580), g_csr_gen4_gv_DBG_PCBP0, "Program Counter Breakpoint 0", NULL },
	{"DBG_PC_BREAKPOINT0_MSK",		(GV_BASE+0x584), g_csr_gen4_gv_DBG_PCBP0_MSK, "Program Counter Breakpoint 0 Mask", NULL },
	{"DBG_PC_BREAKPOINT1",			(GV_BASE+0x590), g_csr_gen4_gv_DBG_PCBP1, "Program Counter Breakpoint 1", NULL },
	{"DBG_PC_BREAKPOINT1_MSK",		(GV_BASE+0x594), g_csr_gen4_gv_DBG_PCBP1_MSK, "Program Counter Breakpoint 1 Mask", NULL },
	{"DBG_PC_BREAKPOINT2",			(GV_BASE+0x5A0), g_csr_gen4_gv_DBG_PCBP2, "Program Counter Breakpoint 2", NULL },
	{"DBG_PC_BREAKPOINT2_MSK",		(GV_BASE+0x5A4), g_csr_gen4_gv_DBG_PCBP2_MSK, "Program Counter Breakpoint 2 Mask", NULL },	
	{"DBG_PC_BREAKPOINT3",			(GV_BASE+0x5B0), g_csr_gen4_gv_DBG_PCBP3, "Program Counter Breakpoint 3", NULL },
	{"DBG_PC_BREAKPOINT3_MSK",		(GV_BASE+0x5B4), g_csr_gen4_gv_DBG_PCBP3_MSK, "Program Counter Breakpoint 3 Mask", NULL },
	{"DBG_DATA_BREAKPOINT0",		(GV_BASE+0x5C0), g_csr_gen4_gv_DBG_DBP0, "Data Breakpoint 0", NULL },
	{"DBG_DATA_BREAKPOINT0_MSK",	(GV_BASE+0x5C4), g_csr_gen4_gv_DBG_DBP0_MSK, "Data Breakpoint 0 Mask", NULL },
	{"DBG_DATA_BREAKPOINT1",		(GV_BASE+0x5D0), g_csr_gen4_gv_DBG_DBP1, "Data Breakpoint 1", NULL },
	{"DBG_DATA_BREAKPOINT1_MSK",	(GV_BASE+0x5D4), g_csr_gen4_gv_DBG_DBP1_MSK, "Data Breakpoint 1 Mask", NULL },
	{"DBG_DATA_BREAKPOINT2",		(GV_BASE+0x5E0), g_csr_gen4_gv_DBG_DBP2, "Data Breakpoint 2", NULL },
	{"DBG_DATA_BREAKPOINT2_MSK",	(GV_BASE+0x5E4), g_csr_gen4_gv_DBG_DBP2_MSK, "Data Breakpoint 2 Mask", NULL },	
	{"DBG_DATA_BREAKPOINT3",		(GV_BASE+0x5F0), g_csr_gen4_gv_DBG_DBP3, "Data Breakpoint 3", NULL },
	{"DBG_DATA_BREAKPOINT3_MSK",	(GV_BASE+0x5F4), g_csr_gen4_gv_DBG_DBP3_MSK, "Data Breakpoint 3 Mask", NULL },

	{"DMEM",	0x8000, NULL, "Data Memory", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

static const struct SVEN_Module_EventSpecific g_gen4_gv_specific_events[] =
{
   { "FW_AUTOAPI_CMD", 0x80, "     cmd %08x cmdbuf %08x [%08x %08x %08x %08x]", NULL },
   { "FW_PK_ES_START", 0x81, "     stm: %08x time: %7d pa %08x len %08x id %08x flg %08x", NULL },
   { "FW_PK_ES_DONE", 0x82, "      stm: %08x time: %7d pa %08x len %08x id %08x flg %08x", NULL },
   { "FW_PK_WL_DONE", 0x83, "      stm: %08x time: %7d pa %08x len %08x id %08x flg %08x", NULL },
   { "FW_PK_STREAM_STATUS", 0x84, "    stm: %d es_buf=%d Freewkld=%d output=%d status=%d %d", NULL },
   { "FW_FATAL_STACK_CORRPON", 0x85, "   FATL ERROR 0x%08X 0x%08X 0x%08X 0x%08X 0x%08X 0x%08X", NULL },
   { "FW_PK_SCHDL_STRM_START", 0x86, "    stm: %d input_es=%d out_wklds=%d free_wklds=%d %d %d", NULL },
   { "FW_PK_SCHDL_STRM_END", 0x87, "    stm: %d input_es=%d out_wklds=%d free_wklds=%d %d %d", NULL },
   { "FW_FATAL_WKLD_OVERLFOW", 0x88, "    item_type:0x%08X wkld_addr=0x%08X %d %d %d %d", NULL },
   { "FW_FATAL_BUFFER_OVERLFOW", 0x89, "    es_addr:0x%08X es_id=0x%08X %d %d %d %d", NULL },
   { "FW_PM_WORKLOAD_STATUS", 0x8a, "    error:0x%08X wkld_addr=0x%08X num_items=%d next=%d %d %d", NULL },
   { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN4_GV_sven_module =
{
    "GEN4_GV",
    SVEN_module_GEN4_GV,
    128*1024,            /* size of CSR Space */
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen4_gv,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "GV: Gen4 Global vSparc",\
    g_gen4_gv_specific_events,
    NULL /* extension list */

#endif

};
