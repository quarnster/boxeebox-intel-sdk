// /*
// 
//   This file is provided under a dual BSD/GPLv2 license.  When using or
//   redistributing this file, you may do so under either license.
// 
//   GPL LICENSE SUMMARY
// 
//   Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
// 
//   This program is free software; you can redistribute it and/or modify
//   it under the terms of version 2 of the GNU General Public License as
//   published by the Free Software Foundation.
// 
//   This program is distributed in the hope that it will be useful, but
//   WITHOUT ANY WARRANTY; without even the implied warranty of
//   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//   General Public License for more details.
// 
//   You should have received a copy of the GNU General Public License
//   along with this program; if not, write to the Free Software
//   Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
//   The full GNU General Public License is included in this distribution
//   in the file called LICENSE.GPL.
// 
//   Contact Information:
//     Intel Corporation
//     2200 Mission College Blvd.
//     Santa Clara, CA  97052
// 
//   BSD LICENSE
// 
//   Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
//   All rights reserved.
// 
//   Redistribution and use in source and binary forms, with or without
//   modification, are permitted provided that the following conditions
//   are met:
// 
//     * Redistributions of source code must retain the above copyright
//       notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above copyright
//       notice, this list of conditions and the following disclaimer in
//       the documentation and/or other materials provided with the
//       distribution.
//     * Neither the name of Intel Corporation nor the names of its
//       contributors may be used to endorse or promote products derived
//       from this software without specific prior written permission.
// 
//   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
//   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
//   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
//   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
//   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
//   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
//   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
//   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
//   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
//   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
//   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
// 
// */
// 

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_unit.h"
#endif
#ifdef SVEN_INTERNAL_BUILD


// Define individual offsets for various sub-units of DPE

#define DPE_420_422_BASE_OFFSET	0x0180
#define DPE_RNR_BASE_OFFSET 0x0400

#define DPE_DRTA_NP1_Y_BASE_OFFSET 0x0200
#define DPE_DRTA_NP1_UV_BASE_OFFSET 0x0280
#define DPE_DRTA_NM1_YUV_BASE_OFFSET 0x1580
#define DPE_DRTA_N_YUV_BASE_OFFSET 0x1500
#define DPE_DRTA_NM1_MH_BASE_OFFSET 0x1600

#define DPE_DWTA_NP1_YUV_BASE_OFFSET 0x1680
#define DPE_DWTA_N_MH_BASE_OFFSET 0x1700
#define DPE_DWTA_N_YUV_BASE_OFFSET 0x4100

#define DPE_FGT_BASE_OFFSET 0x0500
#define DPE_HSC_BASE_OFFSET 0x2000
#define DPE_VSC_BASE_OFFSET 0x3000

#define DPE_DI_BASE_OFFSET 0x1400


#define DPE_DMA_BASE_OFFSET 0x6000
#define DPE_CP_BASE_OFFSET 0x7000

//------------------------------------DRTA_______________________________

static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NP1_Y_DMA_READ_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NP1_Y_DMA_READ_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NP1_Y_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "drta_en",		 0,	 1),     /*enable drta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};



static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NP1_Y_DMA_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NP1_UV_DMA_READ_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NP1_UV_DMA_READ_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NP1_UV_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "drta_en",		 0,	 1),     /*enable drta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NP1_UV_DMA_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NM1_YUV_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "drta_en",		 0,	 1),     /*enable drta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NM1_YUV_DMA_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};




static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_N_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_N_YUV_DMA_READ_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_N_YUV_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "drta_en",		 0,	 1),     /*enable drta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_N_YUV_DMA_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};



static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NM1_MH_DMA_READ_STRIDE_HEIGHT_REGISTER [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NM1_MH_DMA_READ_STRIDE_WIDTH_REGISTER [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NM1_MH_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "drta_en",		 0,	 1),     /*enable drta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DRTA_NM1_MH_DMA_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

//-----------------------------------DWTA--------------------------------------------

static const struct EAS_RegBits g_csr_gen4_DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_WIDTH [] =
{
    CSR_BB( "out_stride_w",		 7,	 9),     /*stride width*/
   	CSR_BB( "in_stride_off",		 0,	 6),     /*input stride offset*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DWTA_NP1_YUV_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "dwta_en",		 0,	 1),     /*enable dwta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DWTA_N_MH_DMA_WRITE_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DWTA_N_MH_DMA_WRITE_STRIDE_WIDTH [] =
{
    CSR_BB( "out_stride_w",		 7,	 9),     /*stride width*/
   	CSR_BB( "in_stride_off",		 0,	 6),     /*input stride offset*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DWTA_N_MH_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "dwta_en",		 0,	 1),     /*enable dwta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_WIDTH [] =
{
    CSR_BB( "out_stride_w",		 7,	 9),     /*stride width*/
   	CSR_BB( "in_stride_off",		 0,	 6),     /*input stride offset*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DWTA_N_YUV_DMA_CONTROL_REGISTER [] =
{
    CSR_BB( "dwta_en",		 0,	 1),     /*enable dwta to read data out from cluster shared mem to dma block */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


//-------------------------------------------------------DPE_420_422---------------------------------------------------


static const struct EAS_RegBits g_csr_gen4_DPE_420_422_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_420_422_Y_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_420_422_cbcr_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_420_422_Converter_Control [] =
{
    CSR_BB( "Pxl_repeat",        4,  1),     /*1: UV pixel is repeated, 0: UV pixel are interpolated*/
    CSR_BB( "PI",		 3,	 1),     /*Raw picture type 0: progressive/1: interlaced*/
    CSR_BB( "TOP",		 2,	 1),	/* 0: bottom field, 1: top field */
    CSR_BB( "BYP",		 1,	 1),     /*1: bypass 420 to 422 converter; used when passing 422 format*/
    CSR_BB( "UNIT_EN",	 0,	 1),	/* Unit Enable (0: C422 off, 1: C422 on) */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

//----------------------------------------------------------------------CP-----------


static const struct EAS_RegBits g_csr_gen4_DPE_CP_CONTROL_REGISTER [] =
{
    CSR_BB( "STC3_Enable",		19,	 1),     /*System Time Counter 3 Enable*/
   	CSR_BB( "STC3_Clk_Sel",		17,	 2),     /*2-bit clock select:0: Clk_90,1: dds0_clk,2: dds1_clk */
  	CSR_BB( "STC2_Enable",		16,	 1),     /*System Time Counter 2 Enable*/
	CSR_BB( "STC2_Clk_Sel",		14,	 2),     /*2-bit clock select:0: Clk_90,1: dds0_clk,2: dds1_clk */
	CSR_BB( "STC1_Enable",		13,	 1),     /*System Time Counter 1 Enable*/
	CSR_BB( "STC1_Clk_Sel",		11,	 2),     /*2-bit clock select:0: Clk_90,1: dds0_clk,2: dds1_clk */
	CSR_BB( "STC0_Enable",		10,	 1),     /*System Time Counter 0 Enable*/
   	CSR_BB( "STC0_Clk_Sel",		 8,	 2),     /*2-bit clock select:0: Clk_90,1: dds0_clk,2: dds1_clk */
  	CSR_BB( "Watchdog_Timer_enable",		 7,	 1),     /*If set it will enable counting of 32-bit free running down counter*/
	CSR_BB( "ATR",				 5,	 2),     /*ATR: added to RISC external memory access address */
	CSR_BB( "PIP",				 2,	 1),     /*PIP: Mode for PIP or Main */
	CSR_BB( "DPE_Reset_l",       1,	 1),     /*DPE Pipeline reset: active low*/
	CSR_BB( "CP_Reset_l",		 0,	 1),     /*RISC Control Processor Reset: active low*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_CP_ICACHE_BASE_ADDRESS [] =
{
    CSR_BB( "Base_address",		14,	 18),     /*Instruction code base system address*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_WATCHDOG_TIMER [] =
{
    CSR_BB( "Timer",		0,	 20),     /*20-bit down-counting watchdog timer*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CACHELINE_INVALIDATE0 [] =
{
    CSR_BB( "Cacheline_Invalidate_mask",		0,	 32),     /*32-bit mask for cache line invalidate*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CACHELINE_INVALIDATE1 [] =
{
    CSR_BB( "Cacheline_Invalidate_mask",		0,	 32),     /*32-bit mask for cache line invalidate*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CACHELINE_INVALIDATE2 [] =
{
    CSR_BB( "Cacheline_Invalidate_mask",		0,	 32),     /*32-bit mask for cache line invalidate*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_DMA_SYSTEM_ADDRESS [] =
{
    CSR_BB( "System_address",		0,	 32),     /*32-bit System Address. Address must be DWORD aligned*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_DMA_LOCAL_ADDRESS [] =
{
    CSR_BB( "Local_address",		0,	 16),     /*16-bit local address. Address must be DWORD aligned*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_DMA_CONTROL_STATUS [] =
{
    CSR_BB( "DMA_START",		22,	 1),     /*Setting this bit initiates the DMA. The bit self clears*/
   	CSR_BB( "DMA_DONE",		21,	 1),     /*Set, on completion of DMA. Used with DMA interrupt */
  	CSR_BB( "DMA_BUSY",		20,	 1),     /*If set, indicates DMA unit is busy*/
	CSR_BB( "DMA_BURST",		18,	 2),     /*Sets the max burst size to use on SAP bus*/
	CSR_BB( "BYTE_SWAP",		17,	 1),     /*If set, the data will byte swapped within a word during the transfer*/
	CSR_BB( "DMA_Direction",	16,	 1),     /*If set, the data transfer is from Local to System side.*/
	CSR_BB( "DMA_Size",		 0,	16),     /*16-bit DMA transfer count in bytes*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HOST_DOORBELL [] =
{
   	CSR_BB( "Doorbell_command",		0,	 32),     /*32-bit software defined doorbell message*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_DOORBELL [] =
{
    CSR_BB( "Doorbell_command",		0,	 32),     /*32-bit software defined doorbell message*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HOST_IPC_STATUS [] =
{
    CSR_BB( "DONE",		1,	 1),     /*If set, Indicates that mailbox is ready for next message*/
	CSR_BB( "READY",		0,	 1),     /*If set, Indicates that doorbell register is ready for next message*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_IPC_STATUS [] =
{
    CSR_BB( "DONE",		1,	 1),     /*If set, Indicates that mailbox is ready for next message*/
	CSR_BB( "READY",		0,	 1),     /*If set, Indicates that doorbell register is ready for next message*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_SYSTEM_TIME_COUNTER0 [] =
{
    CSR_BB( "STC",		0,	 32),     /*32-bit System Time Counter Value*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_SYSTEM_TIME_COUNTER1 [] =
{
    CSR_BB( "STC",		0,	 32),     /*32-bit System Time Counter Value*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_SYSTEM_TIME_COUNTER2 [] =
{
    CSR_BB( "STC",		0,	 32),     /*32-bit System Time Counter Value*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_SYSTEM_TIME_COUNTER3 [] =
{
    CSR_BB( "STC",		0,	 32),     /*32-bit System Time Counter Value*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HOST_INTERRUPT_ENABLE [] =
{
    CSR_BB( "Vsparc_illegal_event",	6,	 1),     /*Vsparc illigal event. Please refer to External event CSR for details*/
   	CSR_BB( "Watchdog_timer",		5,	 1),     /*Watchdog timer event interrupt enable and status register*/
  	CSR_BB( "Ext_Event",			4,	 1),     /*External event interrupt enable and status register.*/
	CSR_BB( "DPE_Event",			3,	 2),     /*DPE event interrupt enable and status register.*/
	CSR_BB( "CP_DMA_done",		2,	 1),     /*CP DMA event interrupt enable and status register.*/
	CSR_BB( "HOST_Doorbell_Event",	1,	 1),     /*Host Doorbell event interrupt enable and status register*/
	CSR_BB( "CP_Doorbell_Event",		0,	 1),     /*CP Doorbell event interrupt enable and status register*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_INTERRUPT_ENABLE [] =
{
    CSR_BB( "Vsparc_illegal_event",	6,	 1),     /*Vsparc illigal event. Please refer to External event CSR for details*/
   	CSR_BB( "Watchdog_timer",		5,	 1),     /*Watchdog timer event interrupt enable and status register*/
  	CSR_BB( "Ext_Event",			4,	 1),     /*External event interrupt enable and status register.*/
	CSR_BB( "DPE_Event",			3,	 2),     /*DPE event interrupt enable and status register.*/
	CSR_BB( "CP_DMA_done",		2,	 1),     /*CP DMA event interrupt enable and status register.*/
	CSR_BB( "HOST_Doorbell_Event",	1,	 1),     /*Host Doorbell event interrupt enable and status register*/
	CSR_BB( "CP_Doorbell_Event",		0,	 1),     /*CP Doorbell event interrupt enable and status register*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_CP_INTERRUPT_STATUS_REGISTER [] =
{
    CSR_BB( "Vsparc_illegal_event",	6,	 1),     /*Vsparc illigal event. Please refer to External event CSR for details*/
   	CSR_BB( "Watchdog_timer",		5,	 1),     /*Watchdog timer event interrupt enable and status register*/
  	CSR_BB( "Ext_Event",			4,	 1),     /*External event interrupt enable and status register.*/
	CSR_BB( "DPE_Event",			3,	 2),     /*DPE event interrupt enable and status register.*/
	CSR_BB( "CP_DMA_done",		2,	 1),     /*CP DMA event interrupt enable and status register.*/
	CSR_BB( "HOST_Doorbell_Event",	1,	 1),     /*Host Doorbell event interrupt enable and status register*/
	CSR_BB( "CP_Doorbell_Event",		0,	 1),     /*CP Doorbell event interrupt enable and status register*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DPE_EVENT_ENABLE_REGISTER [] =
{
    CSR_BB( "NP1_Y_R_DMA_DONE",		23,	 1),     /*DPE Read NP1 (Y) stride_done*/
   	CSR_BB( "NP1_UV_R_DMA_DONE",		22,	 1),     /*DPE Read NP1 (UV) stride_don*/
  	CSR_BB( "NP1_YUV_W_DMA_DONE",		21,	 1),     /*DPE Write NP1 (Y) stride_done*/
	CSR_BB( "NM1_YUV_R_DMA_DONE",		20,	 1),     /*DPE Read N-1 (Y) stride_done*/
	CSR_BB( "NM1_MH_R_DMA_DONE",		19,	 1),     /*DPE Read  MH stride_done*/
	CSR_BB( "N_YUV_R_DMA_DONE",		18,	 1),     /*DPE Read N YUV stride_done*/
	CSR_BB( "N_Y_W_DMA_DONE",		17,	 1),     /*DPE Final Write N (Y) stride_done */
	CSR_BB( "N_UV_W_DMA_DONE",		16,	 1),     /*DPE Final Write N (UV) stride_done*/
   	CSR_BB( "N_MH_W_DMA_DONE",		15,	 1),     /*DPE_MH DMA stride_done*/
  	CSR_BB( "NP1_Y_R_DRTA_DONE",		14,	 1),     /*DPE_NP1_Y_DRTA stride_done*/
	CSR_BB( "NP1_UV_R_DRTA_DONE",		13,	 1),     /*DPE_NP1_UV_DRTA stride_done */
	CSR_BB( "NM1_YUV_R_DRTA_DONE",	12,	 1),     /*DPE_NM1_YUV_DRTA stride_done */
	CSR_BB( "NM1_MH_R_DRTA_DONE",		11,	 1),     /*DPE_MH_R_DRTA stride_done */
	CSR_BB( "N_YUV_R_DRTA_DONE",		 10,	 1),     /*DPE_N_YUV_R_DRTA stride_done */
	CSR_BB( "NP1_YUV_W_DWTA_DONE",	 9,	 1),     /*DPE_NP1_YUV_W_DWTA stride_done */
   	CSR_BB( "N_YUV_W_DWTA_DONE",		 8,	 1),     /*DPE_N_YUV_W_DWTA stride_done*/
  	CSR_BB( "N_MH_W_DWTA_DONE",		 7,	 1),     /*DPE_MH_W_DWTA stride_done*/
	CSR_BB( "VS_DONE",			 6,	 1),     /*Vertical Scaler stride_done*/
	CSR_BB( "HS_DONE",		 	 5,	 1),     /*Horizontal scaler stride_done*/
	CSR_BB( "DI_DONE",	 		 4,	 1),     /*Deinterlacer stride_done*/
    CSR_BB( "FGT_UV_DONE",		 3,	 1),     /*Film Grain stride_done*/
	CSR_BB( "FGT_Y_DONE",		 2,	 1),     /*Film Grain stride_done*/
	CSR_BB( "422_DONE",	 		 1,	 1),     /*422 stride_done*/
	CSR_BB( "RNR_DONE",			 0,	 1),     /*Ringing noise Removal stride _done*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DPE_EVENT_STATUS_REGISTER [] =
{

    CSR_BB( "NP1_Y_R_DMA_DONE",		23,	 1),     /*DPE Read NP1 (Y) stride_done*/
   	CSR_BB( "NP1_UV_R_DMA_DONE",		22,	 1),     /*DPE Read NP1 (UV) stride_don*/
  	CSR_BB( "NP1_YUV_W_DMA_DONE",		21,	 1),     /*DPE Write NP1 (Y) stride_done*/
	CSR_BB( "NM1_YUV_R_DMA_DONE",		20,	 1),     /*DPE Read N-1 (Y) stride_done*/
	CSR_BB( "NM1_MH_R_DMA_DONE",		19,	 1),     /*DPE Read  MH stride_done*/
	CSR_BB( "N_YUV_R_DMA_DONE",		18,	 1),     /*DPE Read N YUV stride_done*/
	CSR_BB( "N_Y_W_DMA_DONE",		17,	 1),     /*DPE Final Write N (Y) stride_done */
	CSR_BB( "N_UV_W_DMA_DONE",		16,	 1),     /*DPE Final Write N (UV) stride_done*/
   	CSR_BB( "N_MH_W_DMA_DONE",		15,	 1),     /*DPE_MH DMA stride_done*/
  	CSR_BB( "NP1_Y_R_DRTA_DONE",		14,	 1),     /*DPE_NP1_Y_DRTA stride_done*/
	CSR_BB( "NP1_UV_R_DRTA_DONE",		13,	 1),     /*DPE_NP1_UV_DRTA stride_done */
	CSR_BB( "NM1_YUV_R_DRTA_DONE",	12,	 1),     /*DPE_NM1_YUV_DRTA stride_done */
	CSR_BB( "NM1_MH_R_DRTA_DONE",		11,	 1),     /*DPE_MH_R_DRTA stride_done */
	CSR_BB( "N_YUV_R_DRTA_DONE",		 10,	 1),     /*DPE_N_YUV_R_DRTA stride_done */
	CSR_BB( "NP1_YUV_W_DWTA_DONE",	 9,	 1),     /*DPE_NP1_YUV_W_DWTA stride_done */
   	CSR_BB( "N_YUV_W_DWTA_DONE",		 8,	 1),     /*DPE_N_YUV_W_DWTA stride_done*/
  	CSR_BB( "N_MH_W_DWTA_DONE",		 7,	 1),     /*DPE_MH_W_DWTA stride_done*/
	CSR_BB( "VS_DONE",			 6,	 1),     /*Vertical Scaler stride_done*/
	CSR_BB( "HS_DONE",		 	 5,	 1),     /*Horizontal scaler stride_done*/
	CSR_BB( "DI_DONE",	 		 4,	 1),     /*Deinterlacer stride_done*/
    CSR_BB( "FGT_UV_DONE",		 3,	 1),     /*Film Grain stride_done*/
	CSR_BB( "FGT_Y_DONE",		 2,	 1),     /*Film Grain stride_done*/
	CSR_BB( "422_DONE",	 		 1,	 1),     /*422 stride_done*/
	CSR_BB( "RNR_DONE",			 0,	 1),     /*Ringing noise Removal stride _done*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_EXT_EVENT_ENABLE_REGISTER [] =
{

    CSR_BB( "VSparc_Illegal_Access",		31,	 1),     /*This bit gets set anytime VSPARC does an illgal data fetch.*/
   	CSR_BB( "Mfd_int",				17,	 1),     /**/
	CSR_BB( "Gfx_int",				16,	 1),     /* */
	CSR_BB( "Demux_int",				15,	 1),     /**/
   	CSR_BB( "Prefilter_int",			14,	 1),     /**/
  	CSR_BB( "Comp_int",				13,	 1),     /**/
	CSR_BB( "Audio_int",				12,	 1),     /**/
	CSR_BB( "VDC_Video1_OVRkeepout_p0_5",	 6,	 6),     /*These bit is only in the EXT_EVENT_STATUS_REGISTER When this Bit is set by VDC Video Plane 2 */
	CSR_BB( "VDC_Flip_p0_5",			 0,	 6),     /*Status bit set on receiving the video flip signal from VDC video plane 1*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_EXT_EVENT_STATUS_REGISTER [] =
{

    CSR_BB( "VSparc_Illegal_Access",		31,	 1),     /*This bit gets set anytime VSPARC does an illgal data fetch.*/
   	CSR_BB( "Mfd_int",				17,	 1),     /**/
	CSR_BB( "Gfx_int",				16,	 1),     /* */
	CSR_BB( "Demux_int",				15,	 1),     /**/
   	CSR_BB( "Prefilter_int",			14,	 1),     /**/
  	CSR_BB( "Comp_int",				13,	 1),     /**/
	CSR_BB( "Audio_int",				12,	 1),     /**/
	CSR_BB( "VDC_Video1_OVRkeepout_p0_5",	 6,	 6),     /*These bit is only in the EXT_EVENT_STATUS_REGISTER When this Bit is set by VDC Video Plane 2 */
	CSR_BB( "VDC_Flip_p0_5",			 0,	 6),     /*Status bit set on receiving the video flip signal from VDC video plane 1*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

//-------------------------------- RNR ------------------Deringing-------------------

static const struct EAS_RegBits g_csr_gen4_DPE_Deringing_Stride_Height_Register [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_Deringing_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_Deringing_Control_Register [] =
{
    CSR_BB( "rnr_bypass",		 1,	 1),     /*Bypass Deringing*/
    CSR_BB( "rnr_en",		 	 0,	 1),	/* Enable Deringing*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_Deringing_Threshold_Register [] =
{
    CSR_BB( "rnr_disthigh_threshold",			 20,	 10),     /*This threshold is the high threshold*/
    CSR_BB( "rnr_average_threshold",		 	 10,	 10),	/*This threshold is used in comparing averaged value versus original pixel value*/
    CSR_BB( "rnr_distlow_threshold",		 	  0,	 10),	/* This threshold is the low threshold*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};




///---------------------------------------------DI--------




static const struct EAS_RegBits g_csr_gen4_DPE_DI_Stride_Height_Register [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Field_Nplus1_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Field_N_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Field_Nless1_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Field_MH_Stride_Width_Register [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Field_FMD_Stride_Width_Register [] =
{
    CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Field_N_Next_Block_Parameters_Register [] =
{
    CSR_BB( "onext_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels)*/
	CSR_BB( "next_wr_y",			 0,	 5),     /*Vertical block size for following unit in pipe (in pixels). */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Control_Register [] =
{
   CSR_BB( "Black_spatial",		31,	 1),     /*1: Use black pixel to replace SDI output, 0: Use SDI output as is for intenal use only*/
  	CSR_BB( "SDI_stride_mode",		30,	 1),     /*For internal C-model configuration only, treat as reserved bit for external use*/
	CSR_BB( "Mh_disable",			29,	 1),     /*For internal use only, treat as reserved bit for external use*/
	CSR_BB( "Const_md",			28,	 1),     /*For internal use only, treat as reserved bit for external use*/
	CSR_BB( "Const_md_value",		27,	 1),     /*For internal use only, treat as reserved bit for external use*/
    CSR_BB( "Chkn_mdaf",       26,  1),     /*Chicken bit for post motion detection motion history adjustment. 1: enable, 0: disable*/
    CSR_BB( "Chkn_mdaf_conservative_chk",       25,  1),     /*Chicken bit(conservative) for motion history. 0: perform post motion-detection adjustment on SAD & MAD history all the time. 1: perform post motion-detection adjustment on SAD & MAD by checking their conservation*/
    CSR_BB( "Chkn_weight_fix",       24,  1),     /*Chicken bit for motion history weight. 1: enable pre motion-detection motion history adjustment. 0: disalbe*/
    CSR_BB( "Chkn_mdaf_check_md",       23,  1),     /*Chicken bit to overrule MD decision. 1: Bypass post motion-detection adjustment of motion history when no motion is detected. 0: perform adjustment always*/
    CSR_BB( "Swap23_mode",      10,  1),     /*1: To support UV upsample in VSC, swap line2 and line3 in every four outpu lines, 0: disable swap line2 and line3*/
	CSR_BB( "FilmMode_1_0",		 8,	 2),     /*11: reserved*/
   	CSR_BB( "CONST_HISTORY",		 7,	 1),     /*Enable constant history, the history data will not be write to or read from external DRAM*/
  	CSR_BB( "Software_Frame_Start",	 6,	 1),     /*1: Software is done programming registers for current frame and it is OK for DI to overwrite frame-based status*/
	CSR_BB( "BYPASS_SPATIAL_NRF",		 5,	 1),     /*1: Bypass the spatial NRF */
	CSR_BB( "BYPASSNRF",		 	 4,	 1),     /*1: Bypass NRF*/
	CSR_BB( "TOP_FIELD",	 		 3,	 1),     /*0:bottom field/1:top field. Must set to 1 for progressive frames*/
	CSR_BB( "SPATIAL",			 2,	 1),     /*1: Motion detection turned off. DI uses field N only for deinterlacing (Pspatial)*/
	CSR_BB( "Progressive",	 	 1,	 1),     /*1: The video input to DI has progressive content 0: The video input to DI has interlaced content*/
	CSR_BB( "Bypass",			 0,	 1),     /*1: pass-through mode (DISABLE must be 0). BYPASS is different from DISABLE*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_SAD_Threshold_Parameter_Register [] =
{
    CSR_BB( "SAD_WEIGHT_PRE2",       28, 3),     /*The weight used for pre motion-detection SAD motion history adjustment when SAD score >= SAD history input and chkn_weight_fix=1*/
    CSR_BB( "SAD_WEIGHT_PRE1",       24, 3),     /*The weight used for pre motion-detection SAD motion history adjustment when SAD score < SAD history input and chkn_weight_fix=1*/
    CSR_BB( "MAX_NOISE_LEVEL",		16,	 8),     /*Max Noise Level . Threshold. U.7.0.   The range of possible values is [0..255]*/
    CSR_BB( "SAD_WEIGHT_POST",       12, 3),     /*The weight used for post motion-detection SAD motion history adjustment*/
	CSR_BB( "SAD_START_VALUE",		 0,	10),     /*SAD Start Value. U.10.0. The range of possible values is [0..1023]*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_MAD_History_Parameter_Register [] =
{
    CSR_BB( "MAD_HISTORY_VALUE",		16,	 6),     /*MAD history constant value, U.8.0. The range of possible values is [0..63]*/
	CSR_BB( "MAD_CAP",			 8,	 8),     /*MAD Cap. U.8.0.The mad_cap >= mad_min.   The range of possible values is [0..255]*/
	CSR_BB( "MAD_MIN",		 	 0,	 8),     /*MAD minimum value. U.8.0. The range of possible values is [0..255]*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_SAD_History_Parameter_Register [] =
{
    CSR_BB( "SAD_HISTORY_VALUE",		0,	 10),     /*SAD history constant value. The range of possible values is [0..1023]*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_Noise_Range_Register [] =
{
    CSR_BB( "NOISE_RNG2_MAX",		24,	 8),     /*MMaximum value of the range of noise for noise pixel accumulation*/
	CSR_BB( "NOISE_RNG2_MIN",		16,	 8),     /*Minimum value of the range of noise for noise pixel  accumulation*/
	CSR_BB( "NOISE_RNG1_MAX",		 8,	 8),     /*Maximum value of the range of noise for noise level accumulation*/
	CSR_BB( "NOISE_RNG1_MIN",		 0,	 8),     /*Minimum value of the range of noise for noise level accumulation*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_Noise_Level_Register [] =
{
    CSR_BB( "Noiselvl",		0,	 30),     /*The count is reset to zero at the beginning of frame by sw_frame_done */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_Noise_Pixel_Count_Register [] =
{
    CSR_BB( "Noisepixcnt",		0,	 22),     /*The count is reset to zero at the beginning of frame by sw_frame_done */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_Noise_Pixel_Count2_Register [] =
{
    CSR_BB( "Noisepixcnt2",		0,	 22),     /*Nnoise pixel count for zero-motion MAD threshold adjustment.   */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_Static_Noise_Level_Register [] =
{
    CSR_BB( "Noiselvl",		0,	 30),     /*The count is reset to zero at the beginning of frame by sw_frame_done */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_Static_Noise_Pixel_Count_Register [] =
{
    CSR_BB( "Noisepixcnt",		0,	 22),     /*The count is reset to zero at the beginning of frame by sw_frame_done */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_Static_Noise_Pixel_Count2_Register [] =
{
    CSR_BB( "Noisepixcnt2",		0,	 22),     /*Noise pixel count for zero-motion MAD threshold adjustment.   */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_Motion_Detect_Threshold_Register [] =
{
    CSR_BB( "MAD_WEIGHT_PRE",       28, 3),     /*The weight used for pre motion-detection MAD motion history adjustment*/
    CSR_BB( "MAD_WEIGHT_POST",       24, 3),     /*The weight used for post motion-detection MAD motion history adjustment*/
    CSR_BB( "thdm",		16,	 6),     /*Initial value of zero-motion MAD threshold for next  input picture*/
	CSR_BB( "Ln",			 0,	12),     /*Ln history for zero-motion SAD threshold adjustment*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_NRF_Index_Shift_Register [] =
{
    CSR_BB( "SWSHIFT",		 2,	2),     /*Number of bits to shift to right for spatial weight index, possible values are 0, 1, 2*/
	CSR_BB( "TWSHIFT",		 0,	2),     /*Number of bits to shift to right for spatial weight index, possible values are 0, 1, 2*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_DI_FMD_min_max_diff_Registers [] =
{
    CSR_BB( "Min_diff",		 	16,	16),     /*Minimum difference for avgDC value*/
	CSR_BB( "Max_diff",		 	 0,	16),     /*Max difference for avgDC value*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_FMD_TC_prev_count_Registers [] =
{
    CSR_BB( "TCP_COUNTER",		 	0,	20),     /*The tearing counter gives number of artifacts detected for given current field when weaved with next field*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_FMD_TC_next_count_Registers [] =
{
    CSR_BB( "TCN_COUNTER",		 	0,	20),     /*The tearing counter gives number of artifacts detected for given current field when weaved with next field*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DI_FMD_FDC_Registers [] =
{
    CSR_BB( "FD_COUNTER",		 	0,	20),     /*Gives the number of pixels between previous field and next field*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};






//---------------------------------------FGT_-----------------------------------------------------




static const struct EAS_RegBits g_csr_gen4_DPE_FGT_Y_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_Y_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_UV_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_FGT_UV_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_Y_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_UV_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_CONTROL [] =
{
    CSR_BB( "fgt_bypass",			 7,	 1),     /*1: Disable FGT */
   	CSR_BB( "fgt_y_bypass",		 6,	 1),     /*This bit  is the inversion of comp_model_present_flag[0]*/
  	CSR_BB( "fgt_U_bypass",		 5,	 1),     /*This bit  is the inversion of comp_model_present_flag[1]*/
	CSR_BB( "fgt_V_bypass",		 4,	 1),     /*This bit  is the inversion of comp_model_present_flag[2]*/
	CSR_BB( "sw_pic_cfg_done",		 3,	 1),     /*1: Software is done with setting up the FGT to process next picture. */
	CSR_BB( "log2_scale_factor",		 0,	 3),     /*This is used to uniform;ly scale down all color components of all noise pixels. */
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gen4_DPE_FGT_PRNG_Y_STRIDE_PARAMS [] =
{
    CSR_BB( "nnext_stride_strt_off",		 	12,	  9),     /*Offset to the leftmost pixel location of next stride */
    CSR_BB( "next_row_strt_off",			 0,	 12),	/*Offset from the leftmost pixel of the current stride row to the leftmost pixel of next stride row which is equivalent to the picture width*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_PRNG_UV_STRIDE_PARAMS [] =
{
    CSR_BB( "nnext_stride_strt_off",		 	12,	  9),     /*Offset to the leftmost pixel location of next stride */
    CSR_BB( "next_row_strt_off",			 0,	 12),	/*Offset from the leftmost pixel of the current stride row to the leftmost pixel of next stride row which is equivalent to the picture width*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_Y_PRNG_SEED [] =
{
    CSR_BB( "PRNG_Y_Seed",		 	0,	  32),     /*32-bit seed to start processing Y components of pixels in the stride*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_U_PRNG_SEED [] =
{
    CSR_BB( "PRNG_U_Seed",		 	0,	  32),     /*32-bit seed to start processing Y components of pixels in the stride*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_gen4_DPE_FGT_V_PRNG_SEED [] =
{
    CSR_BB( "PRNG_V_Seed",		 	0,	  32),     /*32-bit seed to start processing Y components of pixels in the stride*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_Y_NP_Parameter_Table [] =
{
    CSR_BB( "bypass_fgt",				12,	 1),     /*1: Skip */
    CSR_BB( "comp_model_value",			 4,	 8),	/*Valid range[0, 255], */
    CSR_BB( "np_cache_offset",			 0,	 4),	/*The offset of the corresponding 64X64 noise pattern in local sram cache*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_U_NP_Parameter_Table [] =
{
    CSR_BB( "bypass_fgt",				12,	 1),     /*1: Skip */
    CSR_BB( "comp_model_value",			 4,	 8),	/*Valid range[0, 255], */
    CSR_BB( "np_cache_offset",			 0,	 4),	/*The offset of the corresponding 64X64 noise pattern in local sram cache*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_FGT_V_NP_Parameter_Table [] =
{
    CSR_BB( "bypass_fgt",				12,	 1),     /*1: Skip */
    CSR_BB( "comp_model_value",			 4,	 8),	/*Valid range[0, 255], */
    CSR_BB( "np_cache_offset",			 0,	 4),	/*The offset of the corresponding 64X64 noise pattern in local sram cache*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};



//----------------------------------------DMA-----------------------------

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_Mode_Register [] =
{
    CSR_BB( "Dpe_dma_en",		 	11,	 1),     /*1: Enable DPE_DMA */
    CSR_BB( "N_YUV_W_en",		 	10,	 1),     /*1: Enable N_YUV_W DMA thread */
	CSR_BB( "FG_R_enable",		 9,	 1),     /*1: Enable DMA thread FG_R*/
	CSR_BB( "N_MH_W_enable",		 8,	 1),     /*1: Enable DMA thread N_MH_W*/
   	CSR_BB( "N_UV_W_enable",		 7,	 1),     /*1: Enable DMA thread N_UV_WM*/
  	CSR_BB( "N_Y_W_enable",	 	 6,	 1),     /*1: Enable DMA thread N_Y_W*/
	CSR_BB( "NP1_YUV_W_enable",		 5,	 1),     /*1: Enable DMA thread NP1_YUV_W */
	CSR_BB( "N_YUV_R_enable",		 4,	 1),     /*1: Enable DMA thread N_YUV_R*/
	CSR_BB( "NM1_MH_R_enable",	 	 3,	 1),     /*1: Enable DMA thread NM1_MH_R*/
	CSR_BB( "NM1_YUV_R_enable",		 2,	 1),     /*1: Enable DMA thread NM1_YUV_R*/
	CSR_BB( "NP1_UV_R_enable",	 	 1,	 1),     /*1: Enable DMA thread NP1_UV_R*/
	CSR_BB( "NP1_Y_R_enable",		 0,	 1),     /*1: Enable DMA thread NP1_Y_R*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_SAP_MEM_Parameters_Register [] =
{
    CSR_BB( "lsb_pad",		 	31,	  1),     /*Applicable only if pix_wsel=0. */
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_Y_Picture_Parameter_Register [] =
{
	CSR_BB( "top_disable",		 31,	  1),     /*Disable reading of top field*/
	CSR_BB( "bottom_disable",	 	 30,	  1),     /*Disable reading of bottom field*/
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_UV_Picture_Parameter_Register [] =
{
	CSR_BB( "top_disable",		 31,	  1),     /*Disable reading of top field*/
	CSR_BB( "bottom_disable",	 	 30,	  1),     /*Disable reading of bottom field*/
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_Y_Top_Field_Starting_Address_Register [] =
{
    CSR_BB( "top_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_UV_Top_Field_Starting_Address_Register [] =
{
    CSR_BB( "top_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_Y_Bottom_Field_Starting_Address_Register [] =
{
    CSR_BB( "Bottom_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_UV_Bottom_Field_Starting_Address_Register [] =
{
    CSR_BB( "Bottom_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NM1_YUV_R_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NM1_MH_R_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_YUV_R_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_YUV_W_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_Y_W_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_UV_W_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_MH_W_Param_Register [] =
{
	CSR_BB( "pix_wsel",		 	 29,	  1),     /*If 0, output pixel width is 8 bits.If 1, output pixel width is 10 bits */
	CSR_BB( "pic_line_w",	 	 12,	 15),     /*Bytes allocated per scan line for the picture in DRAM frame buffer. */
	CSR_BB( "stride_h",			  0,	 11),     /*Vertical height of the picture in pixels. If the picture is a interlaced field*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NM1_YUV_R_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NM1_MH_R_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_YUV_R_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_YUV_W_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_Y_W_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_UV_W_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_MH_W_Start_Addr_Register [] =
{
    CSR_BB( "pic_start_addr",		 	0,	  32),     /*Starting byte address of the corresponding top field in the frame buffer that contains the current picture*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_Y_R_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_UV_R_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NM1_YUV_R_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NM1_MH_R_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_YUV_R_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_NP1_YUV_W_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_Y_W_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_UV_W_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_DMA_N_MH_W_Stride_Param_Register [] =
{
    CSR_BB( "pix_coord_x",		 	16,	  11),     /*X pixel offset of the first pixel in the stride from left edge */
	CSR_BB( "stride_w",		 	 	 7,	   9),     /*Input/output stride width*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};


//--------------------------------------- Vsc-------------------------------




static const struct EAS_RegBits g_csr_gen4_DPE_VSC_STRIDE_HEIGHT [] =
{
    CSR_BB( "out_stride_h",             16,      11),   /* Out stride height in terms of pixel */
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_VSC_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_VSC_PREV_BLOCK_PARAMS [] =
{
    CSR_BB( "next_wr_offset_y",		 8,	 5),     /*Vertical write offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_VSC_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB( "next_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_VSC_IN_FIFO_PARAMS1 [] =
{
    CSR_BB( "In_fifo_startaddr",		12,	 18),     /*Physical address for first location of in_FIFO (in pixels)*/
    CSR_BB( "In_fifo_width",			 0,	  9),	/*Width of in_FIFO (in pixels)*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_VSC_IN_FIFO_PARAMS2 [] =
{
    CSR_BB( "In_fifo_size",			 8,	 15),     /*Size of in_fifo (in pixels)*/
    CSR_BB( "In_fifo_height",			 0,	  6),	/*Height of in_fifo (in pixels)*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_VSC_OUT_FIFO_PARAMS1 [] =
{
    CSR_BB( "Out_fifo_startaddr",		12,	 18),     /*Physical address for first location of out_FIFO (in pixels)*/
    CSR_BB( "Out_fifo_width",			 0,	  9),	/*Width of out_FIFO (in pixels)*/

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_VSC_OUT_FIFO_PARAMS2 [] =
{
    CSR_BB( "Out_fifo_size",			8,	15),     /*Size of out_fifo (in pixels)*/
    CSR_BB( "Out_fifo_height",			 0,	  6),	/*Height of out_fifo (in pixels)*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_VSC_CONTROL [] =
{
    CSR_BB( "UV_420_422_en",     5,  1),    /* 0: Disable UV upsample, 1: Enable 420 UV upsample to 422 UV */
    CSR_BB( "dering_en",     4,  1),    /* Enable derining feature in VSC */
    CSR_BB( "pic_done",		 3,	 1),     /*1: Reset internal counters and states to be ready for next picture. After reset, VSC automatically clears this bit.*/
   	CSR_BB( "bank_sel",		 2,	 1),     /*1: Select coefficient memory 1 for polyphase filter coefficients*/
  	CSR_BB( "bypass",		 1,	 1),     /*Vertical Scaler Unit bypass*/
	CSR_BB( "en",			 0,	 1),     /*Vertical Scaler Unit Enable*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_VSC_SCALE_FACTOR [] =
{
    CSR_BB( "ISF",			0,	21),     /*Contains the value of 1/Scale factor*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_VSC_PHASE_CONFIG [] =
{
    CSR_BB( "SIP",			 8,	20),     /*Scaled Initial Phase. This needs to be  programmed to (Initial phase/TNP). */
    CSR_BB( "TNP",			 0,	 8),	/*Total number of phases used in the filter bank. */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};


//---------------------------HSC---------------------------------------


static const struct EAS_RegBits g_csr_gen4_DPE_HSC_STRIDE_HEIGHT [] =
{
    CSR_BB( "num_strides",		12,	 4),     /*Number of strides per frame. */
    CSR_BB( "stride_h",		 0,	11),	/* Stride Height in terms of pixels  */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_STRIDE_WIDTH [] =
{
    CSR_BB( "next_rd_offset_x",		27,	 5),     /*Required for the producer consumer model*/
   	CSR_BB( "pix_coord_x",		16,	11),     /*X pixel coordinate of the first pixel in the stride*/
  	CSR_BB( "out_stride_w",		 7,	 9),     /*Output stride width*/
	CSR_BB( "RM",				 6,	 1),     /*Indicates whether this stride is the right most stride*/
	CSR_BB( "LM",				 5,	 1),     /*Indicates whether this stride is a left most stride*/
	CSR_BB( "in_stride_off",		 0,	 5),     /*Input stride offset*/
   	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_STRIDE_SCALING_PARAMS1 [] =
{
    CSR_BB( "In_stride_w",		20,	 9),     /*Typically, most units have a out_stride_w, which reflects how many pixels the algorithm will output.  */
    CSR_BB( "SIP",			 0,	17),	/* Scaled initial phase for the first output pixel in the stride */

    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_STRIDE_SCALING_PARAMS2 [] =
{
    CSR_BB( "SISF",		0,	 21),     /*The start value of 1/scale factor for the stride.  */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_PREV_BLOCK_PARAMS[] =
{
    CSR_BB( "prev_wr_y",			 0,	 5),	/*Vertical block size for following unit in pipe (in pixels*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_NEXT_BLOCK_PARAMS [] =
{
    CSR_BB( "next_rd_offset_y",		 8,	 5),     /*Vertical read offset (from top of stride) for following unit in pipe (in pixels). */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_CONTROL [] =
{
    CSR_BB( "dering_en",     4,  1),    /* Enable derining feature in HSC */
    CSR_BB( "bank_sel",		 2,	 1),     /*Selects the coefficient memory(0/1) that will be used by the HSC*/
  	CSR_BB( "en",			 0,	 1),     /*Horizontal Scaler Unit Enable*/
	CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_PHASE_CONFIG [] =
{
    CSR_BB( "SIP",			 8,	16),     /*Scaled Initial Phase. This needs to be  programmed to (Initial phase/TNP). */
    CSR_BB( "TNP",			 0,	 8),	/*Total number of phases used in the filter bank. */
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_REGION1_START_VALUE [] =
{
    CSR_BB( "SISF",			0,	21),     /*Contains the value of 1/Scale factor*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_REGION1_SCALE_INCR [] =
{
    CSR_BB( "PC",				20,	11),     /*Pixel count for this region. The starting scale factor for the first pixel is SISF*/
    CSR_BB( "ISF_INCR",			 0,	17),	/*Per pixel increment of the inverse scale factor.*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_REGION2_START_VALUE [] =
{
    CSR_BB( "SISF",			0,	21),     /*Contains the value of 1/Scale factor*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_REGION2_SCALE_INCR [] =
{
    CSR_BB( "PC",				20,	11),     /*Pixel count for this region. The starting scale factor for the first pixel is SISF*/
    CSR_BB( "ISF_INCR",			 0,	17),	/*Per pixel increment of the inverse scale factor.*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_REGION3_START_VALUE [] =
{
    CSR_BB( "SISF",			0,	21),     /*Contains the value of 1/Scale factor*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gen4_DPE_HSC_REGION3_SCALE_INCR [] =
{
    CSR_BB( "PC",				20,	11),     /*Pixel count for this region. The starting scale factor for the first pixel is SISF*/
    CSR_BB( "ISF_INCR",			 0,	17),	/*Per pixel increment of the inverse scale factor.*/
    CSR_BB_NULL_TERM()    /* NULL terminator */
};
//------------------------------------------------end of bit breakout -------------------------------


static const struct EAS_Register g_csr_GEN4_DPE [] =
{

/* DPE 420 422 */

	CSR_REG_W_BB("DPE_420_422_STRIDE_HEIGHT",		DPE_420_422_BASE_OFFSET + 0x00, g_csr_gen4_DPE_420_422_STRIDE_HEIGHT,"Stride height and no of strides - fixed for all strides in one picture")

   	CSR_REG_W_BB("DPE_420_422_Y_STRIDE_WIDTH",		DPE_420_422_BASE_OFFSET + 0x04, g_csr_gen4_DPE_420_422_Y_STRIDE_WIDTH,"N Component Y stride width")

   	CSR_REG_W_BB("DPE_420_422_cbcr_STRIDE_WIDTH",	DPE_420_422_BASE_OFFSET + 0x08,g_csr_gen4_DPE_420_422_cbcr_STRIDE_WIDTH, "N Component cbcr stride width")

   	CSR_REG_W_BB("DPE_420_422_Converter_Control",	DPE_420_422_BASE_OFFSET + 0x60,g_csr_gen4_DPE_420_422_Converter_Control, "control register")

/*DPE CP*/
	CSR_REG_W_BB("CP_CONTROL_REGISTER",			DPE_CP_BASE_OFFSET + 0x00,g_csr_gen4_DPE_CP_CONTROL_REGISTER, "Controls the reset and configuration of Control Plane")

	CSR_REG_W_BB("CP_ICACHE_BASE_ADDRESS",		DPE_CP_BASE_OFFSET + 0x04,g_csr_gen4_DPE_CP_ICACHE_BASE_ADDRESS, "Instruction Code base system address")

	CSR_REG_W_BB("CP_WATCHDOG_TIMER",			DPE_CP_BASE_OFFSET + 0x08,g_csr_gen4_DPE_CP_WATCHDOG_TIMER, "A free running watchdog timer")

	CSR_REG_W_BB("CACHELINE_INVALIDATE0",		DPE_CP_BASE_OFFSET + 0x10,g_csr_gen4_DPE_CACHELINE_INVALIDATE0, "32-bit lower Icache line invalidate mask")

	CSR_REG_W_BB("CACHELINE_INVALIDATE1",		DPE_CP_BASE_OFFSET + 0x14,g_csr_gen4_DPE_CACHELINE_INVALIDATE1, "32-bit lower Icache line invalidate mask")

	CSR_REG_W_BB("CACHELINE_INVALIDATE2",		DPE_CP_BASE_OFFSET + 0x18,g_csr_gen4_DPE_CACHELINE_INVALIDATE2, "32-bit lower Icache line invalidate mask")

	CSR_REG_W_BB("CP_DMA_SYSTEM_ADDRESS",		DPE_CP_BASE_OFFSET + 0x20,g_csr_gen4_DPE_CP_DMA_SYSTEM_ADDRESS, "32-bit system address for DMA")

	CSR_REG_W_BB("CP_DMA_LOCAL_ADDRESS",		DPE_CP_BASE_OFFSET + 0x24,g_csr_gen4_DPE_CP_DMA_LOCAL_ADDRESS, "16-bit local address for DMA")

	CSR_REG_W_BB("CP_DMA_CONTROL_STATUS",		DPE_CP_BASE_OFFSET + 0x28,g_csr_gen4_DPE_CP_DMA_CONTROL_STATUS, "DMA control and status register")

	CSR_REG_W_BB("HOST_DOORBELL",			DPE_CP_BASE_OFFSET + 0x30,g_csr_gen4_DPE_HOST_DOORBELL, "Host Processor doorbell register")

	CSR_REG_W_BB("HOST_IPC_STATUS",			DPE_CP_BASE_OFFSET + 0x34,g_csr_gen4_DPE_HOST_IPC_STATUS, "Host Processor doorbell and mailbox status register")

	CSR_REG_W_BB("CP_DOORBELL",				DPE_CP_BASE_OFFSET + 0x38,g_csr_gen4_DPE_CP_DOORBELL, "Control Processor doorbell register")

	CSR_REG_W_BB("CP_IPC_STATUS",			DPE_CP_BASE_OFFSET + 0x3C,g_csr_gen4_DPE_CP_IPC_STATUS, "Control Processor doorbell and mailbox status register")

	CSR_REG_W_BB("CP_SYSTEM_TIME_COUNTER0",		DPE_CP_BASE_OFFSET + 0x40,g_csr_gen4_DPE_CP_SYSTEM_TIME_COUNTER0, "System time stamp counter0 for video stream")

	CSR_REG_W_BB("CP_SYSTEM_TIME_COUNTER1",		DPE_CP_BASE_OFFSET + 0x44,g_csr_gen4_DPE_CP_SYSTEM_TIME_COUNTER1, "System time stamp counter1 for video stream")

	CSR_REG_W_BB("CP_SYSTEM_TIME_COUNTER2",		DPE_CP_BASE_OFFSET + 0x48,g_csr_gen4_DPE_CP_SYSTEM_TIME_COUNTER2, "System time stamp counter2 for video stream")

	CSR_REG_W_BB("CP_SYSTEM_TIME_COUNTER3",		DPE_CP_BASE_OFFSET + 0x4C,g_csr_gen4_DPE_CP_SYSTEM_TIME_COUNTER3, "System time stamp counter3 for video stream")

	CSR_REG_W_BB("HOST_INTERRUPT_ENABLE",		DPE_CP_BASE_OFFSET + 0x50,g_csr_gen4_DPE_HOST_INTERRUPT_ENABLE, "Interrupt enable register for Host Processor")

	CSR_REG_W_BB("CP_INTERRUPT_ENABLE",			DPE_CP_BASE_OFFSET + 0x54,g_csr_gen4_DPE_CP_INTERRUPT_ENABLE,"Interrupt enable register for Control Processor")

	CSR_REG_W_BB("CP_INTERRUPT_STATUS_REGISTER",	DPE_CP_BASE_OFFSET + 0x58,g_csr_gen4_DPE_CP_INTERRUPT_STATUS_REGISTER, "Current Interrupt Status ")

	CSR_REG_W_BB("DPE_EVENT_ENABLE_REGISTER",		DPE_CP_BASE_OFFSET + 0x60,g_csr_gen4_DPE_DPE_EVENT_ENABLE_REGISTER, "DPE event interrupt enable register")

	CSR_REG_W_BB("DPE_EVENT_STATUS_REGISTER",		DPE_CP_BASE_OFFSET + 0x64,g_csr_gen4_DPE_DPE_EVENT_STATUS_REGISTER, "DPE event status register")

	CSR_REG_W_BB("EXT_EVENT_ENABLE_REGISTER",		DPE_CP_BASE_OFFSET + 0x70,g_csr_gen4_DPE_EXT_EVENT_ENABLE_REGISTER, "External event interrupt enable register")

	CSR_REG_W_BB("EXT_EVENT_STATUS_REGISTER", 		DPE_CP_BASE_OFFSET + 0x74,g_csr_gen4_DPE_EXT_EVENT_STATUS_REGISTER, "External event status register")
/*DPE DI*/

	CSR_REG_W_BB("DI_Stride_Height_Register",				DPE_DI_BASE_OFFSET + 0x00,g_csr_gen4_DPE_DI_Stride_Height_Register, "is used to set up the stride height and number of strides per frame")

	CSR_REG_W_BB("DI_Field_Nplus1_Stride_Width_Register",			DPE_DI_BASE_OFFSET + 0x04,g_csr_gen4_DPE_DI_Field_Nplus1_Stride_Width_Register, "set up the per stride input stride width, stride offset and output stride width for Field N+1")

	CSR_REG_W_BB("DI_Field_N_Stride_Width_Register",			DPE_DI_BASE_OFFSET + 0x08,g_csr_gen4_DPE_DI_Field_N_Stride_Width_Register, "set up the per stride input stride width, stride offset and output stride width for Field N")

	CSR_REG_W_BB("DI_Field_Nless1_Stride_Width_Register",			DPE_DI_BASE_OFFSET + 0x0c,g_csr_gen4_DPE_DI_Field_Nless1_Stride_Width_Register, "set up the per stride input stride width, stride offset and output stride width for Field 1")

	CSR_REG_W_BB("DI_Field_MH_Stride_Width_Register",			DPE_DI_BASE_OFFSET + 0x10,g_csr_gen4_DPE_DI_Field_MH_Stride_Width_Register, "sset up the per stride input stride width, stride offset and output stride width for motion history")

	CSR_REG_W_BB("DI_Field_FMD_Stride_Width_Register",			DPE_DI_BASE_OFFSET + 0x14,g_csr_gen4_DPE_DI_Field_FMD_Stride_Width_Register, "set up the per stride input stride width, stride offset and output stride width for film mode detection")

	CSR_REG_W_BB("DI_Field_N_Next_Block_Parameters_Register",		DPE_DI_BASE_OFFSET + 0x18,g_csr_gen4_DPE_DI_Field_N_Next_Block_Parameters_Register, "used to set up the next block parameters")

	CSR_REG_W_BB("DI_Control_Register",					DPE_DI_BASE_OFFSET + 0x20,g_csr_gen4_DPE_DI_Control_Register, "control register")

	CSR_REG_W_BB("DI_Status_Register",					DPE_DI_BASE_OFFSET + 0x24, NULL , "status register")

	CSR_REG_W_BB("DI_Motion_Detect_SAD_Threshold_Parameter_Register",	DPE_DI_BASE_OFFSET + 0x30,g_csr_gen4_DPE_DI_Motion_Detect_SAD_Threshold_Parameter_Register, "DI_Motion_Detect_SAD_Threshold_Parameter_Register")

	CSR_REG_W_BB("DI_Motion_Detect_MAD_History_Parameter_Register",	DPE_DI_BASE_OFFSET + 0x34,g_csr_gen4_DPE_DI_Motion_Detect_MAD_History_Parameter_Register, "DI_Motion_Detect_MAD_Hsitory_Parameter_Register")

	CSR_REG_W_BB("DI_Motion_Detect_SAD_History_Parameter_Register",	DPE_DI_BASE_OFFSET + 0x38,g_csr_gen4_DPE_DI_Motion_Detect_SAD_History_Parameter_Register, "DI_Motion_Detect_SAD_Hsitory_Parameter_Register")

	CSR_REG_W_BB("DI_Motion_Detect_Noise_Range_Register",		DPE_DI_BASE_OFFSET + 0x3c,g_csr_gen4_DPE_DI_Motion_Detect_Noise_Range_Register, "DI_Motion_Detect Noise Range Register")

	CSR_REG_W_BB("DI_Motion_Detect_Noise_Level_Register",		DPE_DI_BASE_OFFSET + 0x40,g_csr_gen4_DPE_DI_Motion_Detect_Noise_Level_Register, "DI_Motion_Detect Noise level Register")

	CSR_REG_W_BB("DI_Motion_Detect_Noise_Pixel_Count_Register",		DPE_DI_BASE_OFFSET + 0x44,g_csr_gen4_DPE_DI_Motion_Detect_Noise_Pixel_Count_Register, "DI_Motion_Detect Noise pixel count Register")

	CSR_REG_W_BB("DI_Motion_Detect_Noise_Pixel_Count2_Register",	DPE_DI_BASE_OFFSET + 0x48,g_csr_gen4_DPE_DI_Motion_Detect_Noise_Pixel_Count2_Register, "DI_Motion_Detect Noise pixel count2 Register")

	CSR_REG_W_BB("DI_Motion_Detect_Threshold_Register",			DPE_DI_BASE_OFFSET + 0x4c,g_csr_gen4_DPE_DI_Motion_Detect_Threshold_Register, "DI_Motion_Detect threshold Register")

	CSR_REG_W_BB("DI_NRF_Index_Shift_Registers",			DPE_DI_BASE_OFFSET + 0x50,g_csr_gen4_DPE_DI_NRF_Index_Shift_Register, "DI_NRF_Index_Shift_Registers")

	CSR_REG_W_BB("DI_Motion_Detect_Static_Noise_Level_Register",		DPE_DI_BASE_OFFSET + 0x5c,g_csr_gen4_DPE_DI_Motion_Detect_Static_Noise_Level_Register, "DI_Motion_Detect Static Noise level Register")

	CSR_REG_W_BB("DI_Motion_Detect_Static_Noise_Pixel_Count_Register",		DPE_DI_BASE_OFFSET + 0x60,g_csr_gen4_DPE_DI_Motion_Detect_Static_Noise_Pixel_Count_Register, "DI_Motion_Detect Static Noise pixel count Register")

	CSR_REG_W_BB("DI_Motion_Detect_Static_Noise_Pixel_Count2_Register",	DPE_DI_BASE_OFFSET + 0x64,g_csr_gen4_DPE_DI_Motion_Detect_Static_Noise_Pixel_Count2_Register, "DI_Motion_Detect Static Noise pixel count2 Register")


	CSR_REG_W_BB("DI_FMD_min_max_diff_Registers",			DPE_DI_BASE_OFFSET + 0x68,g_csr_gen4_DPE_DI_FMD_min_max_diff_Registers, "DI_FMD_min_max_diff_Registers")

	CSR_REG_W_BB("DI_FMD_TC_prev_count_Registers",			DPE_DI_BASE_OFFSET + 0x6c,g_csr_gen4_DPE_DI_FMD_TC_prev_count_Registers, "DI_FMD_TC_prev_count_Registers")

	CSR_REG_W_BB("DI_FMD_TC_next_count_Registers",			DPE_DI_BASE_OFFSET + 0x70,g_csr_gen4_DPE_DI_FMD_TC_next_count_Registers, "DI_FMD_TC_next_count_Registers")

	CSR_REG_W_BB("DI_FMD_FDC_Registers",				DPE_DI_BASE_OFFSET + 0x74,g_csr_gen4_DPE_DI_FMD_FDC_Registers, "DI_FMD_FDC_Registers")



/* DPE Deringing */

	CSR_REG_W_BB("Deringing_Stride_Height_Register",		DPE_RNR_BASE_OFFSET + 0x00,g_csr_gen4_DPE_Deringing_Stride_Height_Register, "set up the stride height and number of strides per frame")

	CSR_REG_W_BB("Deringing_Stride_Width_Register",		DPE_RNR_BASE_OFFSET + 0x04,g_csr_gen4_DPE_Deringing_Stride_Width_Register, "set up the input stride width, stride offset and output stride width for frame N")

	CSR_REG_W_BB("Deringing_Control_Register",			DPE_RNR_BASE_OFFSET + 0x40,g_csr_gen4_DPE_Deringing_Control_Register, "Deringing_Control_Register")

	CSR_REG_W_BB("Deringing_Threshold_Register",		DPE_RNR_BASE_OFFSET + 0x44,g_csr_gen4_DPE_Deringing_Threshold_Register, "Deringing_Threshold_Register")


/* DPE FGT */

	CSR_REG_W_BB("FGT_Y_STRIDE_HEIGHT",		DPE_FGT_BASE_OFFSET + 0x00,g_csr_gen4_DPE_FGT_Y_STRIDE_HEIGHT,"DPE FGT Y stride height")

  	CSR_REG_W_BB("FGT_Y_STRIDE_WIDTH",		DPE_FGT_BASE_OFFSET + 0x04,g_csr_gen4_DPE_FGT_Y_STRIDE_WIDTH,"DPE FGT Y stride width")

        CSR_REG_W_BB("FGT_UV_STRIDE_HEIGHT",	DPE_FGT_BASE_OFFSET + 0x08,g_csr_gen4_DPE_FGT_UV_STRIDE_HEIGHT,"DPE FGT UV stride height")

        CSR_REG_W_BB("FGT_UV_STRIDE_WIDTH",		DPE_FGT_BASE_OFFSET + 0x0C,g_csr_gen4_DPE_FGT_UV_STRIDE_WIDTH,"DPE FGT UV stride width")

	CSR_REG_W_BB("FGT_Y_NEXT_BLOCK_PARAMS",	DPE_FGT_BASE_OFFSET + 0x10,g_csr_gen4_DPE_FGT_Y_NEXT_BLOCK_PARAMS,"Pixel Data Block Size and Offset parameters for next block in pipeline")

  	CSR_REG_W_BB("FGT_UV_NEXT_BLOCK_PARAMS",	DPE_FGT_BASE_OFFSET + 0x14,g_csr_gen4_DPE_FGT_UV_NEXT_BLOCK_PARAMS,"Pixel Data Block Size and Offset parameters for next block in pipeline")

 	CSR_REG_W_BB("FGT_CONTROL",			DPE_FGT_BASE_OFFSET + 0x20, g_csr_gen4_DPE_FGT_CONTROL,"General configuration that affects the entire FGT like bypass")

  	CSR_REG_W_BB("FGT_PRNG_Y_STRIDE_PARAMS",	DPE_FGT_BASE_OFFSET + 0x34,g_csr_gen4_DPE_FGT_PRNG_Y_STRIDE_PARAMS,"FGT Y configuration parameters for configuring PRNG to handle stride-based processing")

   CSR_REG_W_BB("FGT_PRNG_UV_STRIDE_PARAMS",	DPE_FGT_BASE_OFFSET + 0x38,g_csr_gen4_DPE_FGT_PRNG_UV_STRIDE_PARAMS,"FGT UV configuration parameters for configuring PRNG to handle stride-based processing")

  	CSR_REG_W_BB("FGT_Y_PRNG_SEED",		DPE_FGT_BASE_OFFSET + 0x28,g_csr_gen4_DPE_FGT_Y_PRNG_SEED,"FGT PRNG seed value of the current stride for Y component")

	CSR_REG_W_BB("FGT_U_PRNG_SEED",		DPE_FGT_BASE_OFFSET + 0x2C,g_csr_gen4_DPE_FGT_U_PRNG_SEED,"FGT PRNG seed value of the current stride for U component")

	CSR_REG_W_BB("FGT_V_PRNG_SEED",		DPE_FGT_BASE_OFFSET + 0x30,g_csr_gen4_DPE_FGT_V_PRNG_SEED,"FGT PRNG seed value of the current stride for V component")

	CSR_REG_W_BB("FGT_Y_NP_Parameter_Table",	DPE_FGT_BASE_OFFSET + 0x100,g_csr_gen4_DPE_FGT_Y_NP_Parameter_Table,"There are 256 registers that stores the noise-pattern parameters like the offset in NP cache and scaling factor for each possible value of 8X8 block")

	CSR_REG_W_BB("FGT_U_NP_Parameter_Table",	DPE_FGT_BASE_OFFSET + 0x500,g_csr_gen4_DPE_FGT_U_NP_Parameter_Table,"There are 256 registers that stores the noise-pattern parameters like the offset in NP cache and scaling factor for each possible value of 8X8 block")

	CSR_REG_W_BB("FGT_V_NP_Parameter_Table",	DPE_FGT_BASE_OFFSET + 0x900,g_csr_gen4_DPE_FGT_V_NP_Parameter_Table,"There are 256 registers that stores the noise-pattern parameters like the offset in NP cache and scaling factor for each possible value of 8X8 block")


/*DPE HSC Block*/

	CSR_REG_W_BB("HSC_STRIDE_HEIGHT",			DPE_HSC_BASE_OFFSET + 0x00,g_csr_gen4_DPE_HSC_STRIDE_HEIGHT, "Stride height configuration")

	CSR_REG_W_BB("HSC_STRIDE_WIDTH",			DPE_HSC_BASE_OFFSET + 0x04,g_csr_gen4_DPE_HSC_STRIDE_WIDTH, "Stride width configuration")

	CSR_REG_W_BB("HSC_STRIDE_SCALING_PARAMS1",		DPE_HSC_BASE_OFFSET + 0x08,g_csr_gen4_DPE_HSC_STRIDE_SCALING_PARAMS1, "Stride scaling params1 for the current stride")

	CSR_REG_W_BB("HSC_STRIDE_SCALING_PARAMS2",		DPE_HSC_BASE_OFFSET + 0x0C,g_csr_gen4_DPE_HSC_STRIDE_SCALING_PARAMS2, "Stride scaling params2 for the current stride")

	CSR_REG_W_BB("HSC_PREV_BLOCK_PARAMS",		DPE_HSC_BASE_OFFSET + 0x20,g_csr_gen4_DPE_HSC_PREV_BLOCK_PARAMS, "Pixel Data Block Size and Offset parameters for previous block in pipeline")

	CSR_REG_W_BB("HSC_NEXT_BLOCK_PARAMS",		DPE_HSC_BASE_OFFSET + 0x24,g_csr_gen4_DPE_HSC_NEXT_BLOCK_PARAMS, "Pixel Data Block Size and Offset parameters for next block in pipeline")

	CSR_REG_W_BB("HSC_CONTROL",				DPE_HSC_BASE_OFFSET + 0x40,g_csr_gen4_DPE_HSC_CONTROL, "Control/Configuration register for the unit")

	CSR_REG_W_BB("HSC_PHASE_CONFIG",			DPE_HSC_BASE_OFFSET + 0x44,g_csr_gen4_DPE_HSC_PHASE_CONFIG, "Total number of phases")

	CSR_REG_W_BB("HSC_REGION1_START_VALUE",		DPE_HSC_BASE_OFFSET + 0x48,g_csr_gen4_DPE_HSC_REGION1_START_VALUE, "Start parameter for region 1")

	CSR_REG_W_BB("HSC_REGION1_SCALE_INCR",		DPE_HSC_BASE_OFFSET + 0x4C,g_csr_gen4_DPE_HSC_REGION1_SCALE_INCR,"Inverse scale factor increment for region 1")

	CSR_REG_W_BB("HSC_REGION2_START_VALUE",		DPE_HSC_BASE_OFFSET + 0x50,g_csr_gen4_DPE_HSC_REGION2_START_VALUE, "Start parameter for region 2")

	CSR_REG_W_BB("HSC_REGION2_SCALE_INCR",		DPE_HSC_BASE_OFFSET + 0x54,g_csr_gen4_DPE_HSC_REGION2_SCALE_INCR, "Inverse scale factor increment for region 2")

	CSR_REG_W_BB("HSC_REGION3_START_VALUE",		DPE_HSC_BASE_OFFSET + 0x58,g_csr_gen4_DPE_HSC_REGION3_START_VALUE, "Start parameter for region 3")

	CSR_REG_W_BB("HSC_REGION3_SCALE_INCR",		DPE_HSC_BASE_OFFSET + 0x5C,g_csr_gen4_DPE_HSC_REGION3_SCALE_INCR, "Inverse scale factor increment for region 3")

	CSR_REG_W_BB("HSC_Y_POLY_COEFF_BANK0",		DPE_HSC_BASE_OFFSET + 0x0400, NULL, "Y polyphase coefficient memory Bank 0")

	CSR_REG_W_BB("HSC_Y_POLY_COEFF_BANK1",		DPE_HSC_BASE_OFFSET + 0x0800, NULL,"Y polyphase coefficient memory Bank 1")

	CSR_REG_W_BB("HSC_UV_POLY_COEFF_BANK0",		DPE_HSC_BASE_OFFSET + 0x0C00, NULL,"UV polyphase coefficient memory Bank 0")

	CSR_REG_W_BB("HSC_UV_POLY_COEFF_BANK1",		DPE_HSC_BASE_OFFSET + 0x0E00, NULL,"UV polyphase coefficient memory Bank 1")


/*DPE VSC Block*/

	CSR_REG_W_BB("VSC_STRIDE_HEIGHT",			DPE_VSC_BASE_OFFSET + 0x00,g_csr_gen4_DPE_VSC_STRIDE_HEIGHT, "Stride height configuration")

	CSR_REG_W_BB("VSC_STRIDE_WIDTH",			DPE_VSC_BASE_OFFSET + 0x04,g_csr_gen4_DPE_VSC_STRIDE_WIDTH, "Stride width configuration")

	CSR_REG_W_BB("VSC_PREV_BLOCK_PARAMS",		DPE_VSC_BASE_OFFSET + 0x20,g_csr_gen4_DPE_VSC_PREV_BLOCK_PARAMS, "Pixel Data Block Size and Offset parameters for previous block in pipeline")

	CSR_REG_W_BB("VSC_NEXT_BLOCK_PARAMS",		DPE_VSC_BASE_OFFSET + 0x24,g_csr_gen4_DPE_VSC_NEXT_BLOCK_PARAMS, "Pixel Data Block Size and Offset parameters for next block in pipeline")

	CSR_REG_W_BB("VSC_IN_FIFO_PARAMS1",			DPE_VSC_BASE_OFFSET + 0x28,g_csr_gen4_DPE_VSC_IN_FIFO_PARAMS1, "Shared Memory Input FIFO parameters")

	CSR_REG_W_BB("VSC_IN_FIFO_PARAMS2",			DPE_VSC_BASE_OFFSET + 0x2C,g_csr_gen4_DPE_VSC_IN_FIFO_PARAMS2, "Shared Memory Input FIFO parameters")

	CSR_REG_W_BB("VSC_OUT_FIFO_PARAMS1",		DPE_VSC_BASE_OFFSET + 0x30,g_csr_gen4_DPE_VSC_OUT_FIFO_PARAMS1, "Shared Memory Output FIFO parameters")

	CSR_REG_W_BB("VSC_OUT_FIFO_PARAMS2",		DPE_VSC_BASE_OFFSET + 0x34,g_csr_gen4_DPE_VSC_OUT_FIFO_PARAMS2, "Shared Memory Output FIFO parameters")

	CSR_REG_W_BB("VSC_CONTROL",				DPE_VSC_BASE_OFFSET + 0x40,g_csr_gen4_DPE_VSC_CONTROL, "Control/Configuration register for the unit")

	CSR_REG_W_BB("VSC_SCALE_FACTOR",			DPE_VSC_BASE_OFFSET + 0x44,g_csr_gen4_DPE_VSC_SCALE_FACTOR, "Inverse scale factor value")

	CSR_REG_W_BB("VSC_PHASE_CONFIG",			DPE_VSC_BASE_OFFSET + 0x48,g_csr_gen4_DPE_VSC_PHASE_CONFIG, "Phase configuration parameters including number of phases and initial phase")

	CSR_REG_W_BB("VSC_Y_POLY_COEFF_BANK0",		DPE_VSC_BASE_OFFSET + 0x0400, NULL, "Y polyphase coefficient memory Bank 0")

	CSR_REG_W_BB("VSC_Y_POLY_COEFF_BANK1",		DPE_VSC_BASE_OFFSET + 0x0800, NULL,"Y polyphase coefficient memory Bank 1")

	CSR_REG_W_BB("VSC_UV_POLY_COEFF_BANK0",		DPE_VSC_BASE_OFFSET + 0x0C00, NULL,"UV polyphase coefficient memory Bank 0")

	CSR_REG_W_BB("VSC_UV_POLY_COEFF_BANK1",		DPE_VSC_BASE_OFFSET + 0x0E00, NULL, "UV polyphase coefficient memory Bank 1")


/*DPE DMA Write transfer agent */

	CSR_REG_W_BB("DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_HEIGHT",		DPE_DWTA_NP1_YUV_BASE_OFFSET + 0x00, g_csr_gen4_DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_HEIGHT, "This register is used to set up the stride height and number of strides per frame")

 	CSR_REG_W_BB("DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_WIDTH",		DPE_DWTA_NP1_YUV_BASE_OFFSET + 0x04, g_csr_gen4_DPE_DWTA_NP1_YUV_DMA_WRITE_STRIDE_WIDTH, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DWTA_NP1_YUV_DMA_CONTROL_REGISTER",		DPE_DWTA_NP1_YUV_BASE_OFFSET + 0x08, g_csr_gen4_DPE_DWTA_NP1_YUV_DMA_CONTROL_REGISTER, "This register is used to enable/disable DWTA")


	CSR_REG_W_BB("DPE_DWTA_N_MH_DMA_WRITE_STRIDE_HEIGHT",		DPE_DWTA_N_MH_BASE_OFFSET + 0x00, g_csr_gen4_DPE_DWTA_N_MH_DMA_WRITE_STRIDE_HEIGHT, "This register is used to set up the stride height and number of strides per frame")

 	CSR_REG_W_BB("DPE_DWTA_N_MH_DMA_WRITE_STRIDE_WIDTH",		DPE_DWTA_N_MH_BASE_OFFSET + 0x04, g_csr_gen4_DPE_DWTA_N_MH_DMA_WRITE_STRIDE_WIDTH, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DWTA_N_MH_DMA_CONTROL_REGISTER",			DPE_DWTA_N_MH_BASE_OFFSET + 0x08, g_csr_gen4_DPE_DWTA_N_MH_DMA_CONTROL_REGISTER, "This register is used to enable/disable DWTA")


	CSR_REG_W_BB("DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_HEIGHT",		DPE_DWTA_N_YUV_BASE_OFFSET + 0x00, g_csr_gen4_DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_HEIGHT, "This register is used to set up the stride height and number of strides per frame")

 	CSR_REG_W_BB("DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_WIDTH",		DPE_DWTA_N_YUV_BASE_OFFSET + 0x04, g_csr_gen4_DPE_DWTA_N_YUV_DMA_WRITE_STRIDE_WIDTH, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DWTA_N_YUV_DMA_CONTROL_REGISTER",			DPE_DWTA_N_YUV_BASE_OFFSET + 0x08, g_csr_gen4_DPE_DWTA_N_YUV_DMA_CONTROL_REGISTER, "This register is used to enable/disable DWTA")

/*DPE DMA Read transfer agent */

	CSR_REG_W_BB("DPE_DRTA_NP1_Y_DMA_READ_STRIDE_HEIGHT_REGISTER",		DPE_DRTA_NP1_Y_BASE_OFFSET + 0x00, g_csr_gen4_DPE_DRTA_NP1_Y_DMA_READ_STRIDE_HEIGHT_REGISTER, "This register is used to set up the stride height and number of strides per frame. ")

	CSR_REG_W_BB("DPE_DRTA_NP1_Y_DMA_READ_STRIDE_WIDTH_REGISTER",		DPE_DRTA_NP1_Y_BASE_OFFSET + 0x04, g_csr_gen4_DPE_DRTA_NP1_Y_DMA_READ_STRIDE_WIDTH_REGISTER, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DRTA_NP1_Y_DMA_CONTROL_REGISTER",				DPE_DRTA_NP1_Y_BASE_OFFSET + 0x0c, g_csr_gen4_DPE_DRTA_NP1_Y_DMA_CONTROL_REGISTER, "This register is used to enable/disable DRTA")

	CSR_REG_W_BB("DPE_DRTA_NP1_Y_DMA_NEXT_BLOCK_PARAMS",			DPE_DRTA_NP1_Y_BASE_OFFSET + 0x08, g_csr_gen4_DPE_DRTA_NP1_Y_DMA_NEXT_BLOCK_PARAMS, "used to setup dma read data param")


	CSR_REG_W_BB("DPE_DRTA_NP1_UV_DMA_READ_STRIDE_HEIGHT_REGISTER",		DPE_DRTA_NP1_UV_BASE_OFFSET + 0x00, g_csr_gen4_DPE_DRTA_NP1_UV_DMA_READ_STRIDE_HEIGHT_REGISTER, "This register is used to set up the stride height and number of strides per frame. ")

	CSR_REG_W_BB("DPE_DRTA_NP1_UV_DMA_READ_STRIDE_WIDTH_REGISTER",		DPE_DRTA_NP1_UV_BASE_OFFSET + 0x04, g_csr_gen4_DPE_DRTA_NP1_UV_DMA_READ_STRIDE_WIDTH_REGISTER, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DRTA_NP1_UV_DMA_CONTROL_REGISTER",			DPE_DRTA_NP1_UV_BASE_OFFSET + 0x0c, g_csr_gen4_DPE_DRTA_NP1_UV_DMA_CONTROL_REGISTER, "This register is used to enable/disable DRTA")

	CSR_REG_W_BB("DPE_DRTA_NP1_UV_DMA_NEXT_BLOCK_PARAMS",			DPE_DRTA_NP1_UV_BASE_OFFSET + 0x08,g_csr_gen4_DPE_DRTA_NP1_UV_DMA_NEXT_BLOCK_PARAMS, "used to setup dma read data param")


	CSR_REG_W_BB("DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER",		DPE_DRTA_NM1_YUV_BASE_OFFSET + 0x00, g_csr_gen4_DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER, "This register is used to set up the stride height and number of strides per frame. ")

	CSR_REG_W_BB("DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_WIDTH_REGISTER",		DPE_DRTA_NM1_YUV_BASE_OFFSET + 0x04, g_csr_gen4_DPE_DRTA_NM1_YUV_DMA_READ_STRIDE_WIDTH_REGISTER, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DRTA_NM1_YUV_DMA_CONTROL_REGISTER",			DPE_DRTA_NM1_YUV_BASE_OFFSET + 0x0c, g_csr_gen4_DPE_DRTA_NM1_YUV_DMA_CONTROL_REGISTER, "This register is used to enable/disable DRTA")

	CSR_REG_W_BB("DPE_DRTA_NM1_YUV_DMA_NEXT_BLOCK_PARAMS",			DPE_DRTA_NM1_YUV_BASE_OFFSET + 0x08,g_csr_gen4_DPE_DRTA_NM1_YUV_DMA_NEXT_BLOCK_PARAMS, "used to setup dma read data param")



	CSR_REG_W_BB("DPE_DRTA_N_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER",		DPE_DRTA_N_YUV_BASE_OFFSET + 0x00, g_csr_gen4_DPE_DRTA_N_YUV_DMA_READ_STRIDE_HEIGHT_REGISTER, "This register is used to set up the stride height and number of strides per frame. ")

	CSR_REG_W_BB("DPE_DRTA_N_YUV_DMA_READ_STRIDE_WIDTH_REGISTER",		DPE_DRTA_N_YUV_BASE_OFFSET + 0x04, g_csr_gen4_DPE_DRTA_N_YUV_DMA_READ_STRIDE_WIDTH_REGISTER, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DRTA_N_YUV_DMA_CONTROL_REGISTER",				DPE_DRTA_N_YUV_BASE_OFFSET + 0x0c, g_csr_gen4_DPE_DRTA_N_YUV_DMA_CONTROL_REGISTER, "This register is used to enable/disable DRTA")

	CSR_REG_W_BB("DPE_DRTA_N_YUV_DMA_NEXT_BLOCK_PARAMS",			DPE_DRTA_N_YUV_BASE_OFFSET + 0x08,g_csr_gen4_DPE_DRTA_N_YUV_DMA_NEXT_BLOCK_PARAMS, "used to setup dma read data param")



	CSR_REG_W_BB("DPE_DRTA_NM1_MH_DMA_READ_STRIDE_HEIGHT_REGISTER",		DPE_DRTA_NM1_MH_BASE_OFFSET + 0x00, g_csr_gen4_DPE_DRTA_NM1_MH_DMA_READ_STRIDE_HEIGHT_REGISTER, "This register is used to set up the stride height and number of strides per frame. ")

	CSR_REG_W_BB("DPE_DRTA_NM1_MH_DMA_READ_STRIDE_WIDTH_REGISTER",		DPE_DRTA_NM1_MH_BASE_OFFSET + 0x04, g_csr_gen4_DPE_DRTA_NM1_MH_DMA_READ_STRIDE_WIDTH_REGISTER, "This register is used to set up the input stride width, stride offset and output stride width")

	CSR_REG_W_BB("DPE_DRTA_NM1_MH_DMA_CONTROL_REGISTER",			DPE_DRTA_NM1_MH_BASE_OFFSET + 0x0c, g_csr_gen4_DPE_DRTA_NM1_MH_DMA_CONTROL_REGISTER, "This register is used to enable/disable DRTA")

	CSR_REG_W_BB("DPE_DRTA_NM1_MH_DMA_NEXT_BLOCK_PARAMS",			DPE_DRTA_NM1_MH_BASE_OFFSET + 0x08,g_csr_gen4_DPE_DRTA_NM1_MH_DMA_NEXT_BLOCK_PARAMS, "used to setup dma read data param")



/* DPE DMA */

 	CSR_REG_W_BB("DMA_Mode_Register",						DPE_DMA_BASE_OFFSET + 0x74, g_csr_gen4_DPE_DMA_Mode_Register, "DMA_Mode_Register")

	CSR_REG_W_BB("DMA_SAP_MEM_Parameters_Register",				DPE_DMA_BASE_OFFSET + 0x78, g_csr_gen4_DPE_DMA_SAP_MEM_Parameters_Register, "SAP_MEM_Parameters_Register")

	CSR_REG_W_BB("DMA_NP1_Y_Picture_Parameter_Register",			DPE_DMA_BASE_OFFSET + 0x00, g_csr_gen4_DPE_DMA_NP1_Y_Picture_Parameter_Register, "NP1_Y_Picture_Parameter_Register")

	CSR_REG_W_BB("DMA_NP1_UV_Picture_Parameter_Register",			DPE_DMA_BASE_OFFSET + 0x0c, g_csr_gen4_DPE_DMA_NP1_UV_Picture_Parameter_Register, "DMA_NP1_UV_Picture_Parameter_Register")

	CSR_REG_W_BB("DMA_NP1_Y_Top_Field_Starting_Address_Register",		DPE_DMA_BASE_OFFSET + 0x04, g_csr_gen4_DPE_DMA_NP1_Y_Top_Field_Starting_Address_Register, "DMA_NP1_Y_Top_Field_Starting_Address_Register")

	CSR_REG_W_BB("DMA_NP1_UV_Top_Field_Starting_Address_Register",		DPE_DMA_BASE_OFFSET + 0x10, g_csr_gen4_DPE_DMA_NP1_UV_Top_Field_Starting_Address_Register, "DMA_NP1_UV_Top_Field_Starting_Address_Register")

	CSR_REG_W_BB("DMA_NP1_Y_Bottom_Field_Starting_Address_Register",		DPE_DMA_BASE_OFFSET + 0x08, g_csr_gen4_DPE_DMA_NP1_Y_Bottom_Field_Starting_Address_Register, "DMA_NP1_Y_Bottom_Field_Starting_Address_Register")

	CSR_REG_W_BB("DMA_NP1_UV_Bottom_Field_Starting_Address_Register",		DPE_DMA_BASE_OFFSET + 0x14, g_csr_gen4_DPE_DMA_NP1_UV_Bottom_Field_Starting_Address_Register, "DMA_NP1_UV_Bottom_Field_Starting_Address_Register")

	CSR_REG_W_BB("DMA_NM1_YUV_R_Param_Register",				DPE_DMA_BASE_OFFSET + 0x18, g_csr_gen4_DPE_DMA_NM1_YUV_R_Param_Register, "DMA_NM1_YUV_R_Param_Register")

	CSR_REG_W_BB("DMA_NM1_MH_R_Param_Register",					DPE_DMA_BASE_OFFSET + 0x20, g_csr_gen4_DPE_DMA_NM1_MH_R_Param_Register, "DMA_NM1_MH_R_Param_Register")

	CSR_REG_W_BB("DMA_N_YUV_R_Param_Register",					DPE_DMA_BASE_OFFSET + 0x28, g_csr_gen4_DPE_DMA_N_YUV_R_Param_Register, "DMA_N_YUV_R_Param_Register")

	CSR_REG_W_BB("DMA_NP1_YUV_W_Param_Register",				DPE_DMA_BASE_OFFSET + 0x30, g_csr_gen4_DPE_DMA_NP1_YUV_W_Param_Register, "DMA_NP1_YUV_W_Param_Register")

	CSR_REG_W_BB("DMA_N_Y_W_Param_Register",					DPE_DMA_BASE_OFFSET + 0x38, g_csr_gen4_DPE_DMA_N_Y_W_Param_Register, "DMA_N_Y_W_Param_Register")

	CSR_REG_W_BB("DMA_N_UV_W_Param_Register",					DPE_DMA_BASE_OFFSET + 0x40, g_csr_gen4_DPE_DMA_N_UV_W_Param_Register, "DMA_N_UV_W_Param_Register")

	CSR_REG_W_BB("DMA_N_MH_W_Param_Register",					DPE_DMA_BASE_OFFSET + 0x48, g_csr_gen4_DPE_DMA_N_MH_W_Param_Register, "DMA_N_MH_W_Param_Register")

	CSR_REG_W_BB("DMA_NM1_YUV_R_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x1c, g_csr_gen4_DPE_DMA_NM1_YUV_R_Start_Addr_Register, "DMA_NM1_YUV_R_Start_Addr_Register")

	CSR_REG_W_BB("DMA_NM1_MH_R_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x24, g_csr_gen4_DPE_DMA_NM1_MH_R_Start_Addr_Register, "DMA_NM1_MH_R_Start_Addr_Register")

	CSR_REG_W_BB("DMA_N_YUV_R_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x2c, g_csr_gen4_DPE_DMA_N_YUV_R_Start_Addr_Register, "DMA_N_YUV_R_Start_Addr_Register")

	CSR_REG_W_BB("DMA_NP1_YUV_W_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x34, g_csr_gen4_DPE_DMA_NP1_YUV_W_Start_Addr_Register, "DMA_NP1_YUV_W_Start_Addr_Register")

	CSR_REG_W_BB("DMA_N_Y_W_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x3c, g_csr_gen4_DPE_DMA_N_Y_W_Start_Addr_Register, "DMA_N_Y_W_Start_Addr_Register")

	CSR_REG_W_BB("DMA_N_UV_W_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x44, g_csr_gen4_DPE_DMA_N_UV_W_Start_Addr_Register, "DMA_N_UV_W_Start_Addr_Register")

	CSR_REG_W_BB("DMA_N_MH_W_Start_Addr_Register",				DPE_DMA_BASE_OFFSET + 0x4c, g_csr_gen4_DPE_DMA_N_MH_W_Start_Addr_Register, "DMA_N_MH_W_Start_Addr_Register")

	CSR_REG_W_BB("DMA_NP1_Y_R_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x50, g_csr_gen4_DPE_DMA_NP1_Y_R_Stride_Param_Register, "DMA_NP1_Y_R_Stride_Param_Register")

	CSR_REG_W_BB("DMA_NP1_UV_R_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x54, g_csr_gen4_DPE_DMA_NP1_UV_R_Stride_Param_Register, "DMA_NP1_UV_R_Stride_Param_Register")

	CSR_REG_W_BB("DMA_NM1_YUV_R_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x58, g_csr_gen4_DPE_DMA_NM1_YUV_R_Stride_Param_Register, "DMA_NM1_YUV_R_Stride_Param_Register")

	CSR_REG_W_BB("DMA_NM1_MH_R_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x5c, g_csr_gen4_DPE_DMA_NM1_MH_R_Stride_Param_Register, "DMA_NM1_MH_R_Stride_Param_Register")

	CSR_REG_W_BB("DMA_N_YUV_R_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x60, g_csr_gen4_DPE_DMA_N_YUV_R_Stride_Param_Register, "DMA_N_YUV_R_Stride_Param_Register")

	CSR_REG_W_BB("DMA_NP1_YUV_W_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x64, g_csr_gen4_DPE_DMA_NP1_YUV_W_Stride_Param_Register, "DMA_NP1_YUV_W_Stride_Param_Register")

	CSR_REG_W_BB("DMA_N_Y_W_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x68, g_csr_gen4_DPE_DMA_N_Y_W_Stride_Param_Register, "DMA_N_Y_W_Stride_Param_Register")

	CSR_REG_W_BB("DMA_N_UV_W_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x6c, g_csr_gen4_DPE_DMA_N_UV_W_Stride_Param_Register, "DMA_N_UV_W_Stride_Param_Register")

	CSR_REG_W_BB("DMA_N_MH_W_Stride_Param_Register",				DPE_DMA_BASE_OFFSET + 0x70, g_csr_gen4_DPE_DMA_N_MH_W_Stride_Param_Register, "DMA_N_MH_W_Stride_Param_Register")

    CSR_NULL_TERM()    /* NULL terminator */
};

#endif /* !SVEN_INTERNAL_BUILD */


/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */

static const struct SVEN_Module_EventSpecific g_GEN4_DPE_specific_events[] =
{
    //not used
    { "MESSAGE_DPE_INIT", 1, "\tVPP get initialized!", NULL }, //hh add the event for init

	//used 1 time
    { "READ_INPUT_BUFFER", 2, "\tVPP Stream ID: %d, Buffer ID: 0x%x, U Addr: 0x%x, Y Addr: 0x%x, PTS/2: 0x%x, Polarity: %d", NULL }, //hh add the event for monitor input buffer

	//used 2 times
    { "WRITE_OUTPUT_BUFFER", 3, "\tVPP Stream ID: %d, Out Port: %d, In Buffer: 0x%x, Frames Out: %d, Out Buffer: 0x%x!, PTS/2 0x%x", NULL }, //hh add the event for monitor output buffer

	//used 1 time
    { "VPP_FW_START", 4, "\tVPP Core start FW!", NULL }, // add the event for fw start

	//used 1 time
    { "VPP_FW_RX", 5, "\tVPP Core received message from FW!", NULL }, //add the event for fw rx

	//used 1 time
    { "SPA", 6, "\tVPP fc:%d, iw:%d, ih:%d ow:%dk oh:%d, di:0x%x", NULL }, //add the event for calculate fw performance
                                                                //fc: time cycle for FW processing one frame
                                                                //ih: input height
                                                                //iw: input width
                                                                //oh: output height
                                                                //ow: output width
                                                                //di: stream id + deinterlace flag
                                                                // stream id [31-4]
                                                                // deinterlace flag [3-0]
                                                                // 0:di 1:i-bypass 2:p-bypass

	//used 1 time
    // { "FLUSH_START", 7, " VPP Flush start", NULL }, //add the event for flush start

	//used 1 time(s)
    { "FLUSH_STOP", 8, "\tVPP Flush stop", NULL }, //add the event for flush stop

	//used 1 time(s)
    { "FMD_DETECT", 9, "\tVPP Fmd detect", NULL }, //fmd detect

	//used 2 time(s)
    { "FMD_32", 10, "\tVPP Fmd 3:2 start", NULL }, //fmd 3:2 start

	//used 2 time(s)
    { "FMD_22", 11, "\tVPP Fmd 2:2 start", NULL }, //fmd 2:2 start

	//used 1 time(s)
    { "FMD_DUP", 12, "\tVPP Fmd dup", NULL }, //fmd duplicate

	//used 1 time(s)
    { "FMD_START", 13, "\tVPP Fmd start", NULL }, //fmd start

	//used 1 time(s)
    { "FMD_NEW", 14, "\tVPP Fmd start", NULL }, //fmd new frame

	//not used
    { "INTBUF_ALLOC", 15, "\tVPP int buf", NULL }, //intermediate buffer alloc

	//not used
    { "OUTBUF_ALLOC", 16, "\tVPP out buf", NULL }, //output buffer alloc

	//used 3 time(s)
    { "OUT_OF_MEMORY", 17, "\tVPP out of memory", NULL }, //out of memory event

	//used 1 time(s)
    { "LOOKAHEAD_READ_INPUT_BUF", 18, "\tVPP Read lookahead", NULL }, //out of memory event

	//used 1 time(s)
    { "BH_ISR_ENTER", 19, "\tVPP Bottom half ISR enter ", NULL }, //bottom half isr

	//used 1 time(s)
    { "CURRENT_INPUT_DEPTH", 20, "\tVPP Stream ID: 0x%06x Depth: %d, Status: 0x%x Mask: 0x%x, (prior depth: %d)", NULL }, //depth of the input port

	//used 1 time(s)
    { "METADATA_PAN_SCAN", 21, "\tVPP Stream ID: 0x%06x Field: %d, V Offset: %d, H Offset: %d, V Size: %d, H Size: %d", NULL }, //depth of the input port

	 { "CLIENT_ID_IN",      22, "\tStream ID: 0x%06x Port ID: %d id: %d", NULL},

	 { "CLIENT_ID_OUT",     23, "\tStream ID: 0x%06x Port ID: %d id: %d", NULL},

	 { "EOS_IN",            24, "\tStream ID: 0x%06x Port ID: %d", NULL},

	 { "EOS_OUT",           25, "\tStream ID: 0x%06x Port ID: %d", NULL},

	 { "BUFFER_DEREF_FAIL", 26, "\tBuffer ID: %d", NULL},

	 { "BUFFER_DEREF",      27, "\tBuffer ID: %d", NULL},

	 { "BUFFER_ADDREF_FAIL", 28, "\tBuffer ID: %d", NULL},

	 { "BUFFER_ADDREF",      29, "\tBuffer ID: %d", NULL},

	 { "INPUT_PORT_EVENT",   30, "\tStream ID: %d; Level %d", NULL},

	 { "OUTPUT_PORT_EVENT",  31, "\tStream ID: %d; Level %d", NULL},

	 {"INTIAL_INPUT_BUFFER_READ_TIME", 32, "\tStream ID: 0x%06x; Buffer: %d; PTS/2: 0x%08x; Polarity: %d; Repeat Flag: %d; Content Rate: %d", NULL},

	 {"INTIAL_INPUT_BUFFER_READ_SIZE", 33, "\tStream ID: 0x%06x; Buffer: %d; Aspect Ratio: %d:%d; Size(WxH): %dx%d", NULL},

	 {"OUTPUT_BUFFER_WRITE", 34, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d", NULL},

	 {"OUTPUT_NON_FRAME_BUFFER", 35, "\tStream ID: 0x%06x; Buffer: %d", NULL},

	 {"QUEUE_WORK_ITEM", 36, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d; Flags 0x%08x", NULL},

	 {"SEND_FRAME_TO_FW_WORK", 37, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d; Flags 0x%08x", NULL},


	 {"FW_SOURCE_RECTANGE", 38, "\tStream ID: 0x%06x; Destination Buffer: %d; Start (%d, %d); End (%d, %d)", NULL},

	 {"FW_DEST_RECTANGE", 39, "\tStream ID: 0x%06x; Destination Buffer: %d; Start (%d, %d); End (%d, %d)", NULL},

	 {"GET_FRAME_FROM_FW_WORK", 40, "\tStream ID: 0x%06x; Destination Buffer: %d; Source Buffer: %d; Flags 0x%08x", NULL},  

	 {"READ_IN_BUFFER", 41, "\tStream ID: 0x%06x Port: %d, Buffer: %d, PTS/2: 0x%08x", NULL},

	 {"INTIAL_INPUT_BUFFER_READ_COLOR", 42, "\tStream ID: 0x%06x; Buffer: %d; Color Space: %d; Gamma: %d; Pixel Format: %d", NULL},

    //50-59 reserved for FW Params
    {"FW_PARAMS_IN_RECT_POINTS", 50, "\tTop Left:(%d, %d) Bottom Right:(%d, %d)", NULL},
    {"FW_PARAMS_IN_RECT_SIZE", 51, "\tWidth: %d; Height: %d; Stride: %d", NULL},
    {"FW_PARAMS_OUT_RECT_POINTS", 52, "\tTop Left:(%d,%d); Bottom Right:(%d, %d)", NULL},
    {"FW_PARAMS_OUT_RECT_SIZE", 53, "\tWidth: %d; Height: %d; Stride: %d", NULL},
    {"FW_PARAMS_FLAGS", 54, "\tGeneral: 0x%08x; HSC/VSC: 0x%08x; App:0x%08x", NULL},
    {"FW_PARAMS_SETTINGS", 55, "\tNRF Level %d; FMD Mode: %d; MAD Threshold Delta: %d", NULL},
    {"FW_PARAMS_DI_WEIGHTS", 56, "\tMAD Post: %d; MAD Pre: %d; SAD Post: %d; SAD Pre 1: %d; SAD Pre 2: %d", NULL},
    {"FW_PARAMS_SHIFTS", 57, "\tHSC Y: %d; HSC UV: %d; VSC Y: %d; VSC UV1: %d", NULL},
    {"FW_PARAMS_BUFFERS", 58, "\tDI N-1: 0x%x; DI N: 0x%x; DI N+1: 0x%x; MH N-1: 0x%x; MH N: 0x%x", NULL},

#include "../ismd_standard_events.c"
	// Each module can define it's own OPEN event (103), but it should always have the form:
	//{"OPEN",                103, "\tStream ID: 0x%06x In Port ID: %d, Out Port ID: %d <additional init parameters here>", NULL},
	{"OPEN",                103, "\tStream ID: 0x%06x In Port ID: %d, Out Port ID: %d", NULL},

    { NULL, 0, "", NULL }
};
static const struct ModuleReverseDefs g_GEN4_DPE_sven_module =
{
    "GEN4_DPE",
    SVEN_module_GEN4_DPE,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN4_DPE,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "DPE: DPE (GEN4)",
    g_GEN4_DPE_specific_events,
    NULL /* extension list */
};
