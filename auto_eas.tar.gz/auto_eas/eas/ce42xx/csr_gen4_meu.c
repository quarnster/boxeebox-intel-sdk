/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

/* Written by: Thripthi */


#ifndef CSR_GEN4_MEU_C
#define CSR_GEN4_MEU_C "csr_gen4_meu.c"

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

#define MEU_BASE		0x00000

static const struct EAS_RegBits g_csr_gen4_meu_MEU_STATUS[] = 
{
	{"RESERVED",					7, 32, "Reserved", NULL },
	{"MEU_PRCSS_HEAD",		6, 7,  "Statemachine signal indicates read-decrypt-modify-encrypt-write on header portion of writes", NULL },
	{"MEU_PRCSS_BODY",							5, 6,  "Statemachine signal indicates processing of the body of the transaction", NULL },
	{"MEU_PRCSS_TAIL",					4, 5,  "", NULL },
	{"MEU_RD_CMD",					3, 4,  "", NULL },
	{"MEU_REGION_ZERO",					2, 3,  "", NULL },
	{"MEU_BUSY",					1, 2,  "", NULL },
	{"MEU_AES_BUSY",					0, 1,  "", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_CONTROL[] =
{
	{"RESERVED",					1, 32,  "", NULL },
	{"MEU_LOCK_KEYS",					0, 1,  "", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES0_ENC_KEY0[] =
{
	{"MEU_AES0_ENC_KEY0", 						0, 32,  "", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES1_ENC_KEY0[] =
{
            {"MEU_AES1_ENC_KEY0",                                            0, 32,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES0_ENC_KEY1[] =
{
            {"MEU_AES0_ENC_KEY1",                                            0, 32,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES1_ENC_KEY1[] =
{
                {"MEU_AES1_ENC_KEY1",                                            0, 32,  "", NULL },
                                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES0_ENC_KEY2[] =
{
            {"MEU_AES0_ENC_KEY2",                                            0, 32,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES1_ENC_KEY2[] =
{
                {"MEU_AES1_ENC_KEY2",                                            0, 32,  "", NULL },
                                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES0_ENC_KEY3[] =
{
            {"MEU_AES0_ENC_KEY3",                                            0, 32,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES1_ENC_KEY3[] =
{
                {"MEU_AES1_ENC_KEY3",                                            0, 32,  "", NULL },
                                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES0_DEC_KEY0[] =
{
	{"MEU_AES0_ENC_KEY0", 						0, 32,  "", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES1_DEC_KEY0[] =
{
            {"MEU_AES1_ENC_KEY0",                                            0, 32,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES0_DEC_KEY1[] =
{
            {"MEU_AES0_ENC_KEY1",                                            0, 32,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES1_DEC_KEY1[] =
{
                {"MEU_AES1_ENC_KEY1",                                            0, 32,  "", NULL },
                                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES0_DEC_KEY2[] =
{
            {"MEU_AES0_ENC_KEY2",                                            0, 32,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES1_DEC_KEY2[] =
{
                {"MEU_AES1_ENC_KEY2",                                            0, 32,  "", NULL },
                                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES0_DEC_KEY3[] =
{
            {"MEU_AES0_ENC_KEY3",                                            0, 32,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_AES1_DEC_KEY3[] =
{
                {"MEU_AES1_ENC_KEY3",                                            0, 32,  "", NULL },
                                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_ATU_SRC_BASE0[] =
{
            {"MEU_ATU_SRC_BASE",                                            12, 32,  "", NULL },
            {"RESERVED",                                            0, 12,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_ATU_SRC_BASE1[] =
{
            {"MEU_ATU_SRC_BASE",                                            12, 32,  "", NULL },
            {"RESERVED",                                            0, 12,  "", NULL },
            CSR_BB_NULL_TERM()   /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_gen4_meu_MEU_ATU_DST_BASE0[] =
{
            {"MEU_ATU_DST_BASE",                                            12, 32,  "", NULL },
            {"RESERVED",                                            0, 12,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_ATU_DST_BASE1[] =
{
            {"MEU_ATU_DST_BASE",                                            12, 32,  "", NULL },
            {"RESERVED",                                            0, 12,  "", NULL },
            CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_ATU_ADDR_MASK0[] =
{
            {"MEU_ATU_MASK",                                            12, 32,  "", NULL },
            {"RESERVED",                                            0, 12,  "", NULL },
                    CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen4_meu_MEU_ATU_ADDR_MASK1[] =
{
            {"MEU_ATU_MASK",                                            12, 32,  "", NULL },
            {"RESERVED",                                            0, 12,  "", NULL },
            CSR_BB_NULL_TERM()   /* NULL Terminated */
};

/*static const struct EAS_RegBits g_csr_gen4_meu_REG_FILE_ACCESS[] =
{
}
*/

static const struct EAS_Register g_csr_gen4_meu[] =
{
	{"STATUS",						(MEU_BASE+0x0), g_csr_gen4_meu_MEU_STATUS, "MEU Status Register", NULL },
	{"CONTROL",			(MEU_BASE+0x8), g_csr_gen4_meu_MEU_CONTROL, "MEU Control Register", NULL },
	{"MEU_AES0_ENC_KEY0",				(MEU_BASE+0x10), g_csr_gen4_meu_MEU_AES0_ENC_KEY0, "AES0 Encryption Key[31:0]", NULL },
	{"MEU_AES0_ENC_KEY1",		(MEU_BASE+0x14), g_csr_gen4_meu_MEU_AES0_ENC_KEY1, "AES0 Encryption Key[63:32]", NULL },
	{"MEU_AES0_ENC_KEY2",		(MEU_BASE+0x18), g_csr_gen4_meu_MEU_AES0_ENC_KEY2, "AES0 Encryption Key[95:64]", NULL },
	{"MEU_AES0_ENC_KEY3",		(MEU_BASE+0x1C), g_csr_gen4_meu_MEU_AES0_ENC_KEY3, "AES0 Encryption Key[127:96]", NULL },
	{"MEU_AES0_DEC_KEY0",			(MEU_BASE+0x20), g_csr_gen4_meu_MEU_AES0_DEC_KEY0, "AES0 Decryption Key[31:0]", NULL },
	{"MEU_AES0_DEC_KEY1",			(MEU_BASE+0x24), g_csr_gen4_meu_MEU_AES0_DEC_KEY1, "AES0 Decryption Key[63:32]", NULL },
	{"MEU_AES0_DEC_KEY2",			(MEU_BASE+0x28), g_csr_gen4_meu_MEU_AES0_DEC_KEY2, "AES0 Decryption Key[95:64]", NULL },
	{"MEU_AES0_DEC_KEY3", 				(MEU_BASE+0x2C), g_csr_gen4_meu_MEU_AES0_DEC_KEY3, "AES0 Decryption Key[127:96]", NULL },
	{"MEU_AES1_ENC_KEY0",				(MEU_BASE+0x30), g_csr_gen4_meu_MEU_AES1_ENC_KEY0, "AES1 Encryption Key[31:0]", NULL },
	{"MEU_AES1_ENC_KEY1",					(MEU_BASE+0x34), g_csr_gen4_meu_MEU_AES1_ENC_KEY1, "AES1 Encryption Key[63:32]", NULL },
	{"MEU_AES1_ENC_KEY2",					(MEU_BASE+0x38), g_csr_gen4_meu_MEU_AES1_ENC_KEY2, "AES1 Encryption Key[95:64]", NULL },
	{"MEU_AES1_ENC_KEY3",					(MEU_BASE+0x3C), g_csr_gen4_meu_MEU_AES1_ENC_KEY3, "AES1 Encryption Key[127:96]", NULL },
	{"MEU_AES1_DEC_KEY0",					(MEU_BASE+0x40), g_csr_gen4_meu_MEU_AES1_DEC_KEY0, "AES1 Decryption Key[31:0]", NULL },
	{"MEU_AES1_DEC_KEY1",					(MEU_BASE+0x44), g_csr_gen4_meu_MEU_AES1_DEC_KEY1, "AES1 Decryption Key[63:32]", NULL },
	{"MEU_AES1_DEC_KEY2",		(MEU_BASE+0x48), g_csr_gen4_meu_MEU_AES1_DEC_KEY2, "AES1 Decryption Key[95:64]", NULL },
	{"MEU_AES1_DEC_KEY3",			(MEU_BASE+0x4C), g_csr_gen4_meu_MEU_AES1_DEC_KEY3, "AES1 Decryption Key[127:96]", NULL },
	{"MEU_ATU_SRC_BASE0",			(MEU_BASE+0x50), g_csr_gen4_meu_MEU_ATU_SRC_BASE0, "ATU Source Base register 0", NULL },
	{"MEU_ATU_DST_BASE0", 			(MEU_BASE+0x54), g_csr_gen4_meu_MEU_ATU_DST_BASE0, "ATU Destination Base register 0", NULL },
	{"MEU_ATU_ADDR_MASK0",			(MEU_BASE+0x58), g_csr_gen4_meu_MEU_ATU_ADDR_MASK0, "ATU Address Mask register 0", NULL },
	{"MEU_ATU_SRC_BASE1",					(MEU_BASE+0x60), g_csr_gen4_meu_MEU_ATU_SRC_BASE1, "ATU Source Base register 1", NULL },
	{"MEU_ATU_DST_BASE1",				(MEU_BASE+0x64), g_csr_gen4_meu_MEU_ATU_DST_BASE1, "ATU Destination Base register 1", NULL },
	{"MEU_ATU_ADDR_MASK1", 					(MEU_BASE+0x68), g_csr_gen4_meu_MEU_ATU_ADDR_MASK1, "ATU Address Mask register 1", NULL },
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

static const struct SVEN_Module_EventSpecific g_gen4_meu_specific_events[] =
{
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_GEN4_MEU_sven_module =
{
    "GEN4_MEU",
    SVEN_module_GEN4_MEU,
    64*1024,            /* size of CSR Space */
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen4_meu,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MEU: Gen4 MEU",\
    g_gen4_meu_specific_events,
    NULL /* extension list */

#endif

};
