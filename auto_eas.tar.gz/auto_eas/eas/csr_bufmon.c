/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* NO Registers for the bufmon as it is entirely a software component */
static const struct EAS_Register g_csr_BUFMON[] =
{
   { NULL,0,NULL,"",NULL }   /* NULL Terminated */
};
#endif /* INTERNAL_BUILD */

/*   Use the below structure for creating trackable high level events versus 
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_BUFMON_specific_events[] =
{
   /* When an underrun event has been detected */
   { "UNDERRUN_DETECTED", 1,"  id:%x event:%x renderer:%d max_amt:%d", NULL },

   /* When an underrun event was ignored because it came from an unregistered renderer */
   { "UNDERRUN_IGNORED_BAD_RENDERER", 2,"  id:%x event:%x renderer:%d", NULL },

   /* When an underrun event was ignored because it came soon after an overrun*/
   { "UNDERRUN_IGNORED_OVERRUN_WAIT", 3,"  id:%x event:%x renderer:%d", NULL },

   /* When an overrun event has been detected */
   { "OVERRUN_DETECTED", 4,"  id:%x", NULL },

   /* When an overrun event immediately followed an underrun event */
   { "CRIT_ERROR_DETECTED", 5,"  id:%x", NULL },

   /* When an event strobe failed */
   { "ERROR_STROBING_EVENT", 6,"  id:%x event:%x err:%d", NULL },

   /* When a renderer query failed */
   { "ERROR_QUERYING_REND", 7,"  id:%x renderer:%d err:%d", NULL },

   /* When an event wait failed and a new event is allocated */
   { "ERROR_ON_EVENT_WAIT", 8,"  id:%x event:%x err:%d new event:%x", NULL },

   /* When the clock is adjusted */
   { "CLOCK_ADJUSTED", 9,"  id:%x clock:%x adjustment:%d", NULL },

   /* Error on adjusting the clock */
   { "CLOCK_ADJUST_ERROR", 10,"  id:%x clock:%x err:%d", NULL },

   /* Renderer added */
   { "REND_ADDED", 11,"  id:%x renderer:%d event:%x", NULL },

   /* Renderer removed */
   { "REND_REMOVED", 12,"  id:%x renderer:%d", NULL },

   /* Port added */
   { "PORT_ADDED", 13,"  id:%x port:%x", NULL },

   /* Port removed */
   { "PORT_REMOVED", 14,"  id:%x port:%x", NULL },

   /* Port flushed */
   { "PORT_FLUSHED", 15,"  id:%x port:%x", NULL },

   /* Port flush error */
   { "PORT_FLUSH_ERROR", 16,"  id:%x port%x err:%d", NULL },

   /* When an underrun event was ignored because it came soon after another underrun*/
   { "UNDERRUN_IGNORED_UNDERRUN_WAIT", 17,"  id:%x event:%x renderer:%d", NULL },

#include "./ismd_standard_events.c"

   { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_BUFMON_sven_module =
{
   "SW_BUFMON",                /*  */
   SVEN_module_BUFMON,         /* Find your module in <sven_module.h> */
   0,                          /* Size of MMRs */
#ifdef SVEN_INTERNAL_BUILD
   g_csr_BUFMON,               /*  */
#else
   NULL,                       /* What is the latest HW version to use? */
#endif
   "BUFMON: Buffering Monitor",/* Get a better text string */
   g_BUFMON_specific_events,   /* Define important events specific to my module */
   NULL                        /* extension list */
};
