/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* NO Registers for the VTC as it is largely a software component */
static const struct EAS_Register g_csr_VIDREND[] =
{
   { NULL,0,NULL,"",NULL }   /* NULL Terminated */
};
#endif /* INTERNAL_BUILD */

/*   Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_VIDREND_specific_events[] =
{
   /* When first frame is sent to vbd_flip */
   { "FIRST_FLIP",            1,"\tid:%x y:%x pts:%x sch:%x cur:%x pred:%x", NULL },

   /* When second frame is sent to vbd_flip */
   { "SECOND_FLIP",           2,"\tid:%x y:%x pts:%x sch:%x cur:%x pred:%x", NULL },

   /* When any frame (other than first and second) is sent to vbd_flip */
   { "FLIP",                  3,"\tid:%x y:%x pts:%x sch:%x cur:%x pred:%x", NULL },

   /* When a frame is dropped */
   { "DROP",                  4,"\tid:%x y:%x sch:%x newsch:%x pred:%x bound:%x", NULL },

   /* When a frame is chosen for flip because max_hold_time is exceeded instead of pts */
   { "FLIP_HOLD",             5,"\tid:%x pts:%x y:%x sch:%x ts:%x curr:%x", NULL },

   /* Describes the status when the top-half is called */
   { "STATUS",                6,"\tcurr:%x predict:%x bound:%x nxt:%x prevfl:%x curfl:%x", NULL },

   /* Shows timing details during the process of selecting a frame for display */
   { "TIMING",                7,"\tpredict:%x%08x bound:%x%08x curr_diff:%x prev_diff:%x", NULL },

   /* When a frame buffer is released by the renderer */
   { "RELEASE",               8,"\tid:%x y:%x pts:%x sch:%x evnt:%x cont_rate:%d", NULL },

   /* When a frame buffer is read from the port */
   { "PORTREAD",              9,"\tid:%x y:%x pts:%x%08x cur:%x base:%x", NULL },

   /* When incoming pts is modified - when display_first_frame_first is enabled */
   { "PTSMOD",               10,"\tid:%x newpts:%x%08x origpts:%x%08x sven_cadence: %x", NULL },

   /* When an out of order frame is received */
   { "OUT_OF_ORDER",         11,"id:%x y:%x pts:%x%08x prev:%x%08x", NULL },

   /* When a frame buffer is added to the internal queue */
   { "IPQADD",               12,"\tid:%x y:%x pts:%x%08x cur:%x base:%x", NULL },

   /* When a late frame is received in the renderer */
   { "LATEFRAME",            13,"\tid:%x y:%x sch:%x%08x curr:%x%08x", NULL },

   /* When no new frames are available - all frames in the renderer are flipped or dropped */
   { "STARVING",             14,"\thd:%d prevfl:%d curfl:%d nxt:%d base:0x%x curr:0x%x",NULL},

   /* When flush process is started */
   // Updated to a standard event (in ismd_standard_events.c 
   //{ "FLUSH_START",          15,"\thd:%x tl:%x cur:%x nxt:%x prevfl:%x curfl:%x", NULL },

   /* When flush process is done */
   { "FLUSH_STOP",           16,"\thd:%x tl:%x cur:%x nxt:%x prevfl:%x curfl:%x", NULL },

   /* When bottom-half does not read from port because enough frames exist in the ipq */
   { "FR_EXISTS",            17,"\tlastsch:%x%08x curr:%x%08x prefetch:%x%08x", NULL },

   /* When vsync interrupt is received in the top-half */
   { "VSYNC",                18,"\tPolarity: %d", NULL },

   /* When renderer is skipping a vsync interrupt because half rate is enabled */
   { "HALF_RATE",            19,"\tSKIP %d", NULL },

   /* When a vsync interrupt is received later than threshold */
   { "LATEVSYNC",            20,"\tcurr:%x%08x vsync:%x%08x threshold:%x", NULL },

   /* Status of the IPQ */
   { "IPQSTAT",              21,"\thd:%x tl:%x cur:%x nxt:%x prevfl:%x curfl:%x", NULL },

   /* Flip timing for current frame on display at vsync */
   { "FLIP_TIMING",          22,"\tframe on display: vsync:%x%08x orig_pts:%x%08x local_pts:%x%08x", NULL },

   /* When an out of segment frame is received */
   { "OUT_OF_SEGMENT",       23,"id:%x y:%x in_pts:%x%08x sta:%x sto:%x", NULL },

   /* When a new segment is received in BH */
   { "NEW_SEGMENT",          24,"\tid:%x sta:%x sto:%x line_st:%x req_rate:%d app_rate:%d", NULL },

   /* When a new segment is received in TH */
   { "TH_NEW_SEGMENT",       25,"\tid:%x sta:%x sto:%x line_st:%x play_rate:%d scachg:%d", NULL },

   /* When a new basetime is set */
   { "BASE_TIME",            26, "\tbase_time: %x", NULL },

   /* When a discontinuous frame is dropped */
   { "DISCONTINUITY_DROP",   27, "\tid:%x y:%x rend_time:%x%08x prev_rend_time:%x%08x", NULL },

   /* When a discontinuous frame is dropped */
   { "INTPOL_PTS_DROP",      28, "\tid:%x y:%x pts:%x%08x", NULL },

   /* When the last flipped buffer is referenced during flush */
   { "FLUSH_BUFFER_REF",     29, "\tid:%x", NULL },

   /* When the last flipped buffer is de-referenced after flush */
   { "FLUSH_BUFFER_DEREF",   30, "\tid:%x", NULL },

   /* PTS Modification during Discontinuity*/
   { "MODIFIED_PTS",         31, "\tid:%x local_pts:%x%08x mod_pts:%x%08x cadence:%d", NULL },

#include "./ismd_standard_events.c"

   /* When a video frame is presented to the display */
   { "VID_PRESENT",          32, "\tStream ID: 0x%06x Plane: %d, Buffer: %d, PTS/2: 0x%08x, STC/2: 0x%08x, NextVsync/2: 0x%08x", NULL},
   { "UNDER_FLOW",           33, "\tStream ID: 0x%06x Port: %d hd:%d prevfl:%d curfl:%d nxt:%d", NULL},
   { "OPEN",                 34, "\tStream ID: 0x%06x In Port ID: %d, Out Port ID: %d ", NULL},

   /* When buffer underrun has occurred */
   { "UNDERRUN",             35,"\tid:%x y:%x amount:%d", NULL },

   /* When the clock is set in renderer */
   { "SET_CLOCK",            36,"\tclock:%d current_time:0x%x", NULL },

   /* When the play rate changes through in-band or out-of-band trick mode transition */
   { "PLAY_RATE",            37, "\tStream ID:0x%06x Play Rate:%d", NULL},

   /* When the play rate changes through in-band or out-of-band trick mode transition */
   { "SET_PLAY_RATE",        38, "\tStream ID:0x%06x play rate:%d old:%d lin:%u sca:%u calcsca:%u", NULL},

   { "DROP_LINKED",          39, "\tBase: %d, Dep: %d, Base Time: %x, Dep Time %x", NULL },
   { "DELAYED_BASE",         40, "\tBase: %d, Dep: %d, Base Time: %x, Dep Time %x", NULL },
   { "DELAYED_DEP",          41, "\tBase: %d, Dep: %d, Base Time: %x, Dep Time %x", NULL },
   { "START_OF_SEGMENT",     42, "\tid:%x y:%x pts:%x%08x cur:%x base:%x", NULL },
   { "STRICT_NS_POLICY_DROP",43, "\tid:%x y:%x pts:%x%08x segment.start:%x segment.stop:%x", NULL },
   { "TIMING_ADJUST",        44, "\tPTS: %d; RendTime: %d; VSync: %d; RendVsync: %d; Adj: %d; Locked: %d", NULL },
   { "TIMING_ADJUST_DELTA",  45, "\tPTS: %d; InRate: %d; OutRate: %d; Offset: %d; Adj: %d; Locked: %d", NULL },
   { "HANDLE_VSYNC",         46, "\tPolarity: %d", NULL },

   /* a frame arrived and is schedualed to be displayed on a v-sync that has already occured, or will occure before it can be sent to the VDC */
   { "PREDICTED_LATEFRAME",  47, "\tStream ID:0x%06x Buffer ID:%08x Render PTS: %x%08x Predicted V-Sunc:%x%08x", NULL},
   
   /*Track buffer refrences */
   { "BUFFER_DEREF_FAIL",    48, "\tBuffer ID: %d", NULL},
   { "BUFFER_DEREF",         49, "\tBuffer ID: %d", NULL},
   { "BUFFER_ADDREF_FAIL",   50, "\tBuffer ID: %d", NULL},
   { "BUFFER_ADDREF",        51, "\tBuffer ID: %d", NULL},
   { "MASKED_DROP",          52, "\tBuffer ID: %d;frtype: %d; vrmask: %d", NULL},
   { "INITIAL_INPUT_FRAME",  53, "\tBuffer ID: %d;frtype: %d", NULL},
   

   { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_VIDREND_sven_module =
{
   "SW_VIDREND",               /*  */
   SVEN_module_VIDREND,        /* Find your module in <sven_module.h> */
   0,                          /* Size of MMRs */
#ifdef SVEN_INTERNAL_BUILD
   g_csr_VIDREND,              /*  */
#else
   NULL,                       /* What is the latest HW version to use? */
#endif
   "VIDREND: Video Renderer",  /* Get a better text string */
   g_VIDREND_specific_events,  /* Define important events specific to my module */
   NULL                        /* extension list */
};
