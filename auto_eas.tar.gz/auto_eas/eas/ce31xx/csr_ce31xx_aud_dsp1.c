/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef _CSR_GEN3_AUD_DSP1_C
#define _CSR_GEN3_AUD_DSP1_C "csr_gen3_aud_dsp1.c"

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif


/* Audio DSP unit Memory Allocation and Registers
	The Audio DSP registers are allocated from the base address AU_DSP_BASE in the following manner:
	AU_DSP_BASE = <AUDIO_DSP0(1)_MBAR>0_0000H (IA Viewpoint)
*/

#ifdef SVEN_INTERNAL_BUILD

#define GEN3_MAX_AUD_DSP 2
#define GEN3_AUD_DSP1_BASE 0x00000 
#define UNDEFINDED_SYMBOL "UNDEFINED"
#define RESERVED_SYMBOL "RESERVED"


//Common Control Register bit breakouts
// see csr_gen3_aud_dsp0.c for definitions
extern const struct EAS_RegBits g_gen3_easbb_AUD_DSP_CSR[];
extern const struct EAS_RegBits g_gen3_easbb_AUD_DSP_ISRX[];
extern const struct EAS_RegBits g_gen3_easbb_AUD_DSP_ISRD[];
extern const struct EAS_RegBits g_gen3_easbb_AUD_DSP_IMRX[];
extern const struct EAS_RegBits g_gen3_easbb_AUD_DSP_IMRD[];
extern const struct EAS_RegBits g_gen3_easbb_AUD_DSP_IPCX[];
extern const struct EAS_RegBits g_gen3_easbb_AUD_DSP_IPCD[];


//Audio DSP Register Maps


static const struct EAS_Register g_gen3_easr_AUD_DSP1[] =
{//DSP1 Common Control Registers
	{"CSR",  GEN3_AUD_DSP1_BASE+0x0000, g_gen3_easbb_AUD_DSP_CSR,  "CSR - DSP1 Configuration and Status Register. This register controls clock and reset of the block, various configurations of the block and reflects general status of the block. default(00008001h) ",NULL}, 
	{"ISRX", GEN3_AUD_DSP1_BASE+0x0004, g_gen3_easbb_AUD_DSP_ISRX, "ISRX - DSP1 IA32 Interrupt Status Register. This register reflects status of an interrupted mapped event.  default(00000000h)",NULL}, 
	{"ISRD", GEN3_AUD_DSP1_BASE+0x0008, g_gen3_easbb_AUD_DSP_ISRD, "ISRD - DSP1 DSP Interrupt Status Register. This register reflects status of an interrupted mapped event.  default(00000000h)",NULL}, 
	{"IMRX", GEN3_AUD_DSP1_BASE+0x000C, g_gen3_easbb_AUD_DSP_IMRX, "IMRX - DSP1 IA32 Interrupt Mask Register. This register enables/disables interrupts. default(00000000h) ",NULL}, 
	{"IMRD", GEN3_AUD_DSP1_BASE+0x0010, g_gen3_easbb_AUD_DSP_IMRD, "IMRD - DSP1 DSP Interrupt Mask Register. This register enables/disables interrupts.  default(00000000h)",NULL}, 
	{"IPCX", GEN3_AUD_DSP1_BASE+0x0014, g_gen3_easbb_AUD_DSP_IPCX, "IPCX - DSP1 Inter-process Communication register for IA32 CPU. This register is used for IA32 messaging to the DSP default(00000000h)",NULL}, 
	{"IPCD", GEN3_AUD_DSP1_BASE+0x0018, g_gen3_easbb_AUD_DSP_IPCD, "IPCD - DSP1 Inter-process Communication for DSP. This register is used for DSP messaging to IA32. default(00000000h)",NULL}, 
	CSR_NULL_TERM()/* NULL Terminated */
};
#endif /* SVEN_INTERNAL_BUILD */


//Audio DSP
/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_gen3_AUD_DSP1_specific_events[] =
{
   { "CUSTOM_MESSAGE", 1, " custom_msg_ID:%d field1:0x%x field2:0x%x field3:0x%x field4:0x%x field5:0x%x", NULL },
   { "HOST_MSG_RECEIVED", 2, " message:%d wl:%d data0:%d data1:%d", NULL },	
   { "PIPE_REMOVED", 3, " wl:%d", NULL },	
   { "CODEC_API_INIT_COMPLETE", 4, " stage_task: %d", NULL },		
   { "STREAM_SYNC_FOUND", 5, " wl:%d", NULL },			 	
   { "FRAME_DECODED", 6, " wl:%d count:%d cycle_consumed:%d", NULL },			 		
   { "CODEC_API_INIT_FAILED", 7, " stage_task: %d", NULL },	
   { "CODEC_GENERATED_OUTPUT", 8, " format: %d, output_level: %d, sample_rate: %d, sample_size: %d, ch_cnt : %d, ch_map: 0x%x", NULL },	
   { "FW_LOADED", 9, " ", NULL }, 	 	
   { "UNSUPPORTED_CODEC", 10, " wl:%d algo:%d", NULL },
   { "INVALID_HOST_REQUEST", 11, " wl:%d message:%d in_use:%d started:%d configured:%d", NULL }, 	 				 	
   { "SET_MEM_PTR_COMPLETE", 12, " stage_task: %d", NULL },	
   { "SET_MEM_PTR_FAILED", 13, " stage_task: %d", NULL },	
   { "SET_CODEC_PARAM_COMPLETE", 14, " stage_task:%d parameter:%d value:%d", NULL },		
   { "SET_CODEC_PARAM_FAILED", 15, " stage_task:%d parameter:%d value:%d", NULL },
   { "DECODE_FRAME_FAILED", 16, " wl:%d", NULL },			
   { "PIPE_STOPPED", 17, " wl:%d", NULL },					
   { "HTODMAILBOX_VALUE", 18, " offset_0:0x%x offset_1:0x%x offset_2:0x%x offset_3:0x%x offset_4:0x%x offset_5:0x%x", NULL },						 
   { "PIPE_STARTED", 19, " wl:%d", NULL },			
   { "STAGE_INFO", 20, " wl:%d stage_index:%d task:%d input_count:%d output_count:%d", NULL },
   { "JOB_EXECUTION_FAILED", 21, " wl:%d valid:%d bufs_count:%d job_handle:%d", NULL },	
   { "JOB_EXECUTION_COMPLETE", 22, " wl:%d valid:%d bufs_count:%d job_handle:%d", NULL },	
   { "STAGE_EXECUTION_FAILED", 23, " wl:%d index:%d task:%d", NULL },		 	
   { "STAGE_EXECUTION_COMPLETE", 24, " wl:%d index:%d task:%d inputs:%d outputs:%d done:%d", NULL },	
   { "PSM_BUFFER", 25, " handle:%d in_use:%d smd_buf_alloc:%d smd_buf:0x%x phys_add:0x%x size:%d", NULL },	
   { "AUX_PSM_BUFFER_ASSIGNED", 26, " psm_buf_index:%d", NULL },
   { "AUX_PSM_BUFFER_UNAVAILABLE", 27, " ", NULL },
   { "NO_OUTPUT", 28, " wl:%d", NULL },				 
   { "INTERRUPT_HANDLER", 29, " ipcx:%x ipcd:%x isrd:%x imrd:%x", NULL },				 		 	
   { "EXCEPTION_HANDLER", 30, " cause:%d", NULL },				 		 		
   { "NO_INPUT_JOB", 31, " cur_in_job_handle:%d cur_in_job_valid:%d", NULL },				 		 			 	
   { "PIPE_ADDED", 32, " wl:%d", NULL },		
   { "PIPE_CONFIGURED", 33, " wl:%d", NULL },	
   { "CUSTOM_MESSAGE_DECIMAL_VALUE", 34, " custom_msg_ID:%d field1:%d field2:%d field3:%d field4:%d field5:%d", NULL },
   { "DECODER_FLUSH", 35, " wl_id:%d", NULL },
   { "EXE_SRC_STAGE", 36, " wl_id:%d, in_sample_rate: %d, out_sample_rate: %d, in_sample_size: %d, in_ch_count: %d, eos?: %d", NULL }, 
   { "EXE_PACKETIZER_STAGE", 37, " wl_id:%d, input_cnt: %d, input_level: %d, output_level: %d, eos?: %d, debug: %d", NULL }, 
   { "INPUT_STAGE_BUFFER_DEQUEUE", 38, " wl_id:%d, buffer_cnt: %d, buffer_level: %d, sample_size: %d, sample_rate: %d, ch_cnt: %d", NULL },
   { "CODEC_API_INIT", 39, " codec:%d, api_size: %d, allocated_api_size: %d", NULL },
   { "CODEC_BUFFER_UPDATE", 40, " codec: %d, input_buf_level: %d input_req: %d, input_buf_offset: %d, dec_buf_level: %d, bytes_to_cpy: %d", NULL },
   { "CODEC_INIT_NOT_DONE", 41, " wl: %d, codec: %d, input_bytes_consumed: %d, input_req: %d, dec_buf_level: %d ", NULL },
   { "CODEC_SET_MEMTABS", 42, " codec: %d, req_mem: %d, allocated_mem: %d, codec_mem_base: %d, memtabs_offset: %d ", NULL },
   { "CODEC_SET_PERSISTANT", 43, " codec: %d, req_mem: %d, allocated_mem: %d, codec_mem_base: %d, persistant_offset: %d ", NULL },
   { "CODEC_SET_SCRATCH", 44, " codec: %d, req_mem: %d, allocated_mem: %d, codec_mem_base: %d, scratch_offset: %d ", NULL },
   { "PACKETIZER_SYNC_NOT_FOUND", 45, " codec: %d, in_buffer_level: %d ", NULL },
   { "PACKETIZER_INVALID_FRAME_SIZE", 46, " codec: %d, in_buffer_level: %d ", NULL },
   { "PACKETIZER_FRAME_INFO", 47, " codec: %d, frame_size: %d, sample_rate: %d ", NULL },
   { "EXE_DMIX_STAGE", 48, " wl_id: %d, sample_rate: %d, sample_size: %d, ch_cnt: %d, input_level: %d, output_level: %d ", NULL },
   { "EXE_INTRLVR_STAGE", 49, " wl_id: %d, sample_rate: %d, sample_size: %d, ch_cnt: %d, input_level: %d, output_level: %d ", NULL },
   { "EXE_DEINTRLVR_STAGE", 50, " wl_id: %d, sample_rate: %d, sample_size: %d, ch_cnt: %d, input_level: %d, ch_config: 0x%x ", NULL },
   { "EXE_MIXER_STAGE", 51, " input_num: %d, sample_rate: %d, sample_size: %d, ch_cnt: %d, input_level: %d, num_output_ch: %d ", NULL },
   { "PCM_DVD_HEADER_INFO", 52, " ch_count: %d, sample_size: %d, sample_rate: %d, bytes_till_pts: %d, in_buf_offset: %d ", NULL },
   { "EXE_DATA_DIVIDER_STAGE", 53, " wl_id:%d, input_cnt: %d, input_level: %d, output_level: %d, eos?: %d, chunk_size: %d", NULL }, 
   { "EXE_OUTPUT_STAGE", 54, " wl_id:%d, input_cnt: %d, input_level: %d, output_buf_level: %d, eos?: %d, output_exists?: %d", NULL }, 
   { "INVALID_METADATA", 55, " line_number: %d, sample_rate: %d, sample_size: %d, ch_count: %d, ch_conf: %d, input_level: %d", NULL }, 
   { "INVALID_CH_CONFIG", 56, " line_number: %d, input_ch_config: 0x%x, output_ch_config: 0x%x, ch_count: 0x%x,  %x %x", NULL },
   { "CH_CONFIG_INFO", 57, " line_number: %d, input_ch_config: 0x%x, output_ch_config: 0x%x, ch_count: 0x%x, input_level: %d", NULL },
   { "EXE_BASS_MAN_STAGE", 58, " enabled: %d, input_ch_config: 0x%x, ch_flags: 0x%x, ch_count: 0x%x, input_level: %d, output_level: %d", NULL },
   { "PIPE_STAGE_PERFORMANCE", 59, " task: %d, field2: %d, sample_count: 0x%x%08x, ccount: 0x%x%08x", NULL },
   { "PCM_DECODE_FLUSH", 60, " PCM decoder recieved flush command!", NULL },
   { "EXE_PRESRC_STAGE", 61, " wl_id:%d, in_sample_rate: %d, out_sample_rate: %d, in_sample_size: %d, in_ch_count: %d, eos?: %d", NULL }, 
   { "EXE_DELAY_MAN_STAGE", 62, " enabled: %d, input_ch_config: 0x%x, ch_flags: 0x%x, ch_count: 0x%x, input_level: %d, output_level: %d", NULL},
   { "STAGE_BYPASS", 63, " curr_stage_out_cnt: %d, next_stage_in_cnt: %d, curr_stage_in_add: 0x%x, next_stage_in_add: 0x%x, nxt_stg_in_num: %d ", NULL}, 
   { "STAGE_IN_USE", 64, " curr_stage_out_cnt: %d, next_stage_in_cnt: %d, curr_stage_in_add: 0x%x, next_stage_in_add: 0x%x, nxt_stg_in_num: %d ", NULL}, 
   { "CODEC_METADATA_ASSOCIATION_QUEUE_OVERRUN", 65, " codec format: %d, mda-input_index: %d, mda-output_index: %d, init_done: %d, stream_pos call result: %d ", NULL},
   { "EXE_WATERMARK_STAGE", 66, " enabled: %d, input_ch_config: 0x%x, ch_count: 0x%x, input_level: %d, output_level: %d field6: %d", NULL },
   { "MDA_STREAM_POS_IN", 67, " input_index: %d, curr_stream_pos: %d, rang_begin: %d, rang_end: %d, aux_level: %d input_level: %d", NULL },
   { "MDA_STREAM_POS_OUT", 68, " output_index: %d, curr_stream_pos: %d, rang_begin: %d, rang_end: %d, aux_level: %d output_level: %d", NULL },
   { "MDA_STREAM_POS_OUT_DISCARD", 69, " output_index: %d, curr_stream_pos: %d, rang_begin: %d, rang_end: %d, aux_level: %d output_level: %d", NULL },
   { "WATERMARK_ERROR", 70, " line_number: %d, result: %d, field3: 0x%x, field4: 0x%x, field5: 0x%x, field6: 0x%x", NULL },
   { "EXE_AD", 71, " field1: %d, field2: %d, field3: %d, field4: %d, field5: %d, field6: %d", NULL },
   { "EXE_AUDIO_QUALITY_STAGE", 72, " input: %d, ctx_index: %d, in_use: %d, init_done: %d, input_level: %d, sample_rate: %d", NULL },
   { "AUDIO_QUALITY_CUSTOM", 73, " line_number: %d,  %d,  %d,  %d,  %d,  %d", NULL },
   { "EXE_PER_OUTPUT_DELAY_STAGE", 74, "input: %d, output: %d, sample_rate: %d, channel_count: %d, input_level: %d, output_level: %d", NULL},
   { "EXE_BIT_DEPTH_CONVERT", 75, "set_output_smpl_sz: %d, actual_out_smpl_sz: %d, input_level: %d, output_level: %d, ch_cfg: 0x%x, sample_rate: %d", NULL},
   { "DECODER_ERROR_RECONFIG", 76, "result: %d, algo: %d, processing_eos: %d", NULL},
   { "DTS_DMIX_RUNNING", 77, "input_ch_cnt: %d, output_ch_cnt: %d, need_2_stage_dmix?: %d, dmix_mode: %d, ouput_index: %d, ch_map: 0x%x ", NULL},
   { "DOLBY_BSI_INFO", 78, " bsid: %d, smt:xbe:mixe: 0x%x, acmod: 0x%x, legac_dmix: 0x%x, ltrt_dmix: 0x%x, loro_dmix: 0x%x ", NULL},
   { "MS10_DDC_FRAME_SYNC", 79, " sync: %d, main: %d, frm_m: %d, frm_a: %d, convs: %d, blk: %d ", NULL},
   { "CAPP_STREAM_METADATA_CHANGE", 80, " old_sample_rate: %d, new_sample_rate: %d, old_sample_size: %d, new_sample_size: %d, old_channel_count: %d, new_channel_count: %d", NULL },
   { "CAPP_METADATA_ASSOCIATION_QUEUE_OVERRUN", 81, " mda_queue_size: %d, input_byte_pos: %d, output_byte_pos: %d, bytes_buffered_in_custom_library: %d", NULL },
   { "CAPP_EXECUTE_FAILED", 82, " mode: %d, bytes_offered: %d, bytes_consumed: %d, capp_result: %d", NULL },
   { "CAPP_INSUFFICIENT_OUT_BUFFER_SPACE", 83, " out_buffer_level: %d, in_buffer_level: %d, max_capp_output: %d, stage_input_level: %d", NULL },
   { "CAPP_INVALID_METADATA_ASSOCIATION", 84, " line_number: %d, input_byte_pos: %d, output_byte_pos: %d, mda start byte: %d, mda size: %d", NULL },
   { "CAPP_MISSING_END_OF_SEGMENT", 85, " line_number: %d, input_byte_pos: %d, output_byte_pos: %d", NULL },
   { "CAPP_STAGE_DISABLED", 86, " line_number: %d, mode: %d, input_byte_pos: %d, output_byte_pos: %d, in_buffer_level: %d, out_buffer_level: %d", NULL },
   { "CAPP_UNKNOWN_MODE", 87, " line_number: %d, mode: %d", NULL },   
   { "CAPP_STAGE_ENABLED", 88, " line_number: %d, mode: %d, PTS:0x%x%08x ", NULL },
   { "CAPP_PREPARED_INPUT", 89, " PTS:0x%x%08x, stage_input_level: %d, bytes_copied: %d, in_buffer_level: %d", NULL },
   { "CAPP_EXECUTE_CALL", 90, " mode: %d, PTS:0x%x%08x, bytes_offered: %d, bytes_consumed: %d, bytes_produced: %d", NULL },   
   { "CAPP_STAGE_OUTPUT", 91, " PTS:0x%x%08x, out_buffer_bytes_copied: %d, stage_output_level: %d, input_byte_pos: %d, output_byte_pos: %d", NULL },        
   { "CAPP_INIT_STAGE", 92, "", NULL },        
   { "CAPP_CLEANUP_STAGE", 93, " enabled: %d, handle: %d, result: %d", NULL },        
   { "CAPP_FLUSH_STAGE", 94, " enabled: %d, handle: %d, result: %d", NULL },       
   { "SRS_STAGE_EXE", 95, " ", NULL },   
   { "IEC_PARSER_STAGE_EXE", 96, " Init done: %d, Mode: %d, Input Level: %d, Output Level: %d, Parsing result: %d, EOS or Tags: %d", NULL },
   { "IEC_61937_EXE", 97, " Sync state: %d, offset: %d, data type: %d, sub data type: %d, dep info: %d, burst payload error: %d", NULL }, 
   { "STAGE_EXECUTION_SKIPPED", 99, " wl:%d index:%d task:%d inputs:%d outputs:%d done:%d", NULL },
   { "WAITING_ON_IO_EVENT", 100, " ", NULL },
   { "OUTPUT_QUEUE_FULL", 101, "  wl:%d queue:%d  ", NULL },
   { NULL, 0, NULL, NULL }	 	
	 
};

static const struct ModuleReverseDefs g_gen3_AUD_DSP1_sven_module =
{
    "GEN3_AUD_DSP1",               /* Module Name */
    SVEN_module_GEN3_AUD_DSP1,     /* Module ID> */
    1024*1024,                  /* Memory size of register space */
#ifdef SVEN_INTERNAL_BUILD
    g_gen3_easr_AUD_DSP1, 
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "AUDIO: AUDIO_DSP1 (Intel(r) Media Processor CE 31xx)",   
    g_gen3_AUD_DSP1_specific_events, 
    NULL /* extension list */
};
#endif //#ifndef _CSR_GEN3_AUD_DSP1_C
