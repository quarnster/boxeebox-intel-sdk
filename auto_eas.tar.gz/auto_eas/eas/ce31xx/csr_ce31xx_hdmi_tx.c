/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_unit.h"
#endif

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

#ifdef SVEN_INTERNAL_BUILD
//#define GEN3_HDMI_TX_BASE 0xFFE80000
#define GEN3_HDMI_TX_BASE 0x0000
/*
Copied by Ramya Ranganathan from HDMI EAS Ver 0.61 on Feb15-07
Offset	Register Unit	Register Name/ Function
0000h-0FFFh	XSIDMAR	HDMI UDMA context registers (XSI clock domain)
1000h-10FFh 	XSIGCR	HDMI Unit & Phy registers (XSI clock domain)
1100h-11FFh 	XSII2CR	I2C Unit registers (XSI clock domain)
1200h-124Bh	XSIHI2CR	HDMI I2C HW registers (XSI clock domain)
124Ch-1FFFh		Reserved
2000h-2FFFh	PCLKVIDR	HDMI Input Video processing registers (Pixel clock domain)
3000h-3FFFh	TMDSVIDR	HDMI Output Video Format Registers (TMDS clock domain)
4000h-4FFFh	TMDSAUDR	HDMI Audio Format Registers (TMDS clock domain)
5000h-5FFFh	TMDSHDCPR	HDCP Registers (TMDS clock domain)
6000h-6FFFh	TMDSINFR	Infoframe Registers (TMDS clock domain)
7000h-7FFFh	HCBR	Intel Reserved (Chicken Bits)
8000h-FFFFh		Unused
*/

#define GEN3_HDMI_TX_XSIDMAR_BASE    GEN3_HDMI_TX_BASE+0x0000	
#define GEN3_HDMI_TX_XSIGCR_BASE     GEN3_HDMI_TX_BASE+0x1000   
#define GEN3_HDMI_TX_XSII2CR_BASE	   GEN3_HDMI_TX_BASE+0x1100 
#define GEN3_HDMI_TX_XSIHI2CR_BASE   GEN3_HDMI_TX_BASE+0x1200 
#define GEN3_HDMI_TX_PCLKVIDR_BASE   GEN3_HDMI_TX_BASE+0x2000 
#define GEN3_HDMI_TX_TMDSVIDR_BASE   GEN3_HDMI_TX_BASE+0x3000 
#define GEN3_HDMI_TX_TMDSAUDR_BASE   GEN3_HDMI_TX_BASE+0x4000 
#define GEN3_HDMI_TX_TMDSINFR_BASE   GEN3_HDMI_TX_BASE+0x4100 
#define GEN3_HDMI_TX_TMDSHDCPR_BASE  GEN3_HDMI_TX_BASE+0x5000	
#define GEN3_HDMI_TX_HCBR_BASE	   GEN3_HDMI_TX_BASE+0x7000 



#define GEN3_HDMI_TX_CURR_DESCR_OFFSET         GEN3_HDMI_TX_XSIDMAR_BASE + 0x0008
#define GEN3_HDMI_TX_NEXT_DESCR_OFFSET         GEN3_HDMI_TX_XSIDMAR_BASE + 0x000C
#define GEN3_HDMI_TX_SRCDMA_START_OFFSET       GEN3_HDMI_TX_XSIDMAR_BASE + 0x0010
#define GEN3_HDMI_TX_DSTDMA_START_OFFSET       GEN3_HDMI_TX_XSIDMAR_BASE + 0x0014
#define GEN3_HDMI_TX_SRCDMA_SIZE_OFFSET        GEN3_HDMI_TX_XSIDMAR_BASE + 0x0018
#define GEN3_HDMI_TX_FLAGS_MODE_OFFSET         GEN3_HDMI_TX_XSIDMAR_BASE + 0x001C
#define GEN3_HDMI_TX_SRCDMA_START_ALS_OFFSET   GEN3_HDMI_TX_XSIDMAR_BASE + 0x0020
#define GEN3_HDMI_TX_SRCDMA_BOT_OFFSET         GEN3_HDMI_TX_XSIDMAR_BASE + 0x0024
#define GEN3_HDMI_TX_SRCDMA_TOP_OFFSET         GEN3_HDMI_TX_XSIDMAR_BASE + 0x0028
#define GEN3_HDMI_TX_DSTDMA_BOT_OFFSET         GEN3_HDMI_TX_XSIDMAR_BASE + 0x002C
#define GEN3_HDMI_TX_DSTDMA_TOP_OFFSET         GEN3_HDMI_TX_XSIDMAR_BASE + 0x0030
#define GEN3_HDMI_TX_DSTDMA_SIZE_OFFSET        GEN3_HDMI_TX_XSIDMAR_BASE + 0x0034
#define GEN3_HDMI_TX_SRCDMA_STOP_OFFSET        GEN3_HDMI_TX_XSIDMAR_BASE + 0x0038
#define GEN3_HDMI_TX_DSTDMA_STOP_OFFSET        GEN3_HDMI_TX_XSIDMAR_BASE + 0x003C


#define GEN3_HDMI_TX_HCR_OFFSET         GEN3_HDMI_TX_XSIGCR_BASE + 0x0000
#define GEN3_HDMI_TX_HICR_OFFSET        GEN3_HDMI_TX_XSIGCR_BASE + 0x0004
#define GEN3_HDMI_TX_HSR_OFFSET         GEN3_HDMI_TX_XSIGCR_BASE + 0x0008
#define GEN3_HDMI_TX_HISR_OFFSET        GEN3_HDMI_TX_XSIGCR_BASE + 0x000C
#define GEN3_HDMI_TX_HPCR_OFFSET        GEN3_HDMI_TX_XSIGCR_BASE + 0x001C
#define GEN3_HDMI_TX_RSVD_20_FF_OFFSET  GEN3_HDMI_TX_XSIGCR_BASE + 0x0020

#define GEN3_HDMI_TX_ICRH_OFFSET        GEN3_HDMI_TX_XSII2CR_BASE + 0x0000
#define GEN3_HDMI_TX_ISRH_OFFSET        GEN3_HDMI_TX_XSII2CR_BASE + 0x0004
#define GEN3_HDMI_TX_IDBRH_OFFSET       GEN3_HDMI_TX_XSII2CR_BASE + 0x0008
#define GEN3_HDMI_TX_IBMRH_OFFSET       GEN3_HDMI_TX_XSII2CR_BASE + 0x000C
#define GEN3_HDMI_TX_RSVD_10_FF_OFFSET  GEN3_HDMI_TX_XSII2CR_BASE + 0x0010

#define GEN3_HDMI_TX_HI2CRDB0_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0000
#define GEN3_HDMI_TX_HI2CRDB1_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0004
#define GEN3_HDMI_TX_HI2CRDB2_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0008
#define GEN3_HDMI_TX_HI2CRDB3_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x000C
#define GEN3_HDMI_TX_HI2CRDB4_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0010 
#define GEN3_HDMI_TX_HI2CRDB5_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0014
#define GEN3_HDMI_TX_HI2CRDB6_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0018
#define GEN3_HDMI_TX_HI2CRDB7_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x001C
#define GEN3_HDMI_TX_HI2CRDB8_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0020
#define GEN3_HDMI_TX_HI2CRDB9_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0024
#define GEN3_HDMI_TX_HI2CRDB10_OFFSET   GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0028
#define GEN3_HDMI_TX_HI2CRDB11_OFFSET   GEN3_HDMI_TX_XSIHI2CR_BASE + 0x002C
#define GEN3_HDMI_TX_HI2CRDB12_OFFSET   GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0030
#define GEN3_HDMI_TX_HI2CRDB13_OFFSET   GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0034
#define GEN3_HDMI_TX_HI2CRDB14_OFFSET   GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0038
#define GEN3_HDMI_TX_HI2CRDB15_OFFSET   GEN3_HDMI_TX_XSIHI2CR_BASE + 0x003C
#define GEN3_HDMI_TX_HI2CHCR_OFFSET     GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0040
#define GEN3_HDMI_TX_HI2CTDR0_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0044 
#define GEN3_HDMI_TX_HI2CTDR1_OFFSET    GEN3_HDMI_TX_XSIHI2CR_BASE + 0x0048 
#define GEN3_HDMI_TX_RSVD_4C_FF_OFFSET  GEN3_HDMI_TX_XSIHI2CR_BASE + 0x004C

/* 1.13.5	Input Video Processing Registers (2000h-2FFFh) */
#define GEN3_HDMI_TX_DCR_OFFSET         GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0000
#define GEN3_HDMI_TX_DPRNGSR_OFFSET     GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0004
#define GEN3_HDMI_TX_CSCCR_OFFSET       GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0008
#define GEN3_HDMI_TX_RSVD_C_FF_OFFSET   GEN3_HDMI_TX_PCLKVIDR_BASE + 0x000C

#define GEN3_HDMI_TX_UPCSCC_OFFSET     GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0100
#define GEN3_HDMI_TX_UPCSCYGOFF_OFFSET  GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0104
#define GEN3_HDMI_TX_UPCSCCBOFF_OFFSET  GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0108  
#define GEN3_HDMI_TX_UPCSCCROFF_OFFSET  GEN3_HDMI_TX_PCLKVIDR_BASE + 0x010C
#define GEN3_HDMI_TX_UPCSC_C01_OFFSET   GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0110
#define GEN3_HDMI_TX_UPCSC_C23_OFFSET   GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0114
#define GEN3_HDMI_TX_UPCSC_C45_OFFSET   GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0118
#define GEN3_HDMI_TX_UPCSC_C67_OFFSET   GEN3_HDMI_TX_PCLKVIDR_BASE + 0x011C
#define GEN3_HDMI_TX_UPCSC_C8_OFFSET    GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0120
#define GEN3_HDMI_TX_RSVD_124_FFF_OFFSET       GEN3_HDMI_TX_PCLKVIDR_BASE + 0x0124

/* 1.13.6	HDMI Video Format Registers (3000h-3FFFh) */

#define GEN3_HDMI_TX_VOFR_OFFSET          GEN3_HDMI_TX_TMDSVIDR_BASE + 0x0000
#define GEN3_HDMI_TX_RSVD_4_FF_OFFSET     GEN3_HDMI_TX_TMDSVIDR_BASE + 0x0004
#define GEN3_HDMI_TX_HBLANK_A_OFFSET      GEN3_HDMI_TX_TMDSVIDR_BASE + 0x0100
#define GEN3_HDMI_TX_VTOTAL_A_OFFSET      GEN3_HDMI_TX_TMDSVIDR_BASE + 0x0104
#define RSVD_11C_FFFOFFSET   GEN3_HDMI_TX_TMDSVIDR_BASE + 0x011C

/* 1.13.7	Audio Control Registers (4000h-4FFFh) */

#define GEN3_HDMI_TX_AFCR_OFFSET                 GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0000
#define GEN3_HDMI_TX_HWCTS_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0004
#define GEN3_HDMI_TX_ACRNR_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0008
#define GEN3_HDMI_TX_ACRCTSR_OFFSET              GEN3_HDMI_TX_TMDSAUDR_BASE + 0x000C
#define GEN3_HDMI_TX_ASCDIVR_OFFSET              GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0010
#define GEN3_HDMI_TX_AFTHR_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0014
#define GEN3_HDMI_TX_AFLR_OFFSET                 GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0018
#define GEN3_HDMI_TX_USDR0_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x001C
#define GEN3_HDMI_TX_USDR1_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0020
#define GEN3_HDMI_TX_USDR2_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0024
#define GEN3_HDMI_TX_USDR3_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0028
#define GEN3_HDMI_TX_USDR4_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x002C
#define GEN3_HDMI_TX_USDR5_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0030
#define GEN3_HDMI_TX_USDR6_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0034
#define GEN3_HDMI_TX_USDR7_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0038
#define GEN3_HDMI_TX_USDR8_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x003C
#define GEN3_HDMI_TX_USDR9_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0040
#define GEN3_HDMI_TX_USDR10_OFFSET               GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0044
#define GEN3_HDMI_TX_USDR11_OFFSET               GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0048
#define GEN3_HDMI_TX_USDCR_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x004C
#define GEN3_HDMI_TX_CHSR0_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0050
#define GEN3_HDMI_TX_CHSR1_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0054
#define GEN3_HDMI_TX_CHSCR_OFFSET                GEN3_HDMI_TX_TMDSAUDR_BASE + 0x0058


/* INFO FRAME REGISTERS */
#define GEN3_HDMI_TX_IF0HB2_HB0_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0000
#define GEN3_HDMI_TX_IF0PB3_PB0_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0004
#define GEN3_HDMI_TX_IF0PB7_PB4_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0008
#define GEN3_HDMI_TX_IF0PB11_PB8_OFFSET          GEN3_HDMI_TX_TMDSINFR_BASE + 0x000C
#define GEN3_HDMI_TX_IF0PB15_PB12_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0010
#define GEN3_HDMI_TX_IF0PB19_PB16_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0014
#define GEN3_HDMI_TX_IF0PB23_PB20_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0018
#define GEN3_HDMI_TX_IF0PB27_PB24_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x001C
#define GEN3_HDMI_TX_IF1HB2_HB0_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0020
#define GEN3_HDMI_TX_IF1PB3_PB0_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0024
#define GEN3_HDMI_TX_IF1PB7_PB4_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0028
#define GEN3_HDMI_TX_IF1PB11_PB8_OFFSET          GEN3_HDMI_TX_TMDSINFR_BASE + 0x002C
#define GEN3_HDMI_TX_IF1PB15_PB12_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0030
#define GEN3_HDMI_TX_IF1PB19_PB16_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0034
#define GEN3_HDMI_TX_IF1PB23_PB20_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0038
#define GEN3_HDMI_TX_IF1PB27_PB24_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x003C
#define GEN3_HDMI_TX_IF2HB2_HB0_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0040
#define GEN3_HDMI_TX_IF2PB3_PB0_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0044
#define GEN3_HDMI_TX_IF2PB7_PB4_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0048
#define GEN3_HDMI_TX_IF2PB11_PB8_OFFSET          GEN3_HDMI_TX_TMDSINFR_BASE + 0x004C
#define GEN3_HDMI_TX_IF2PB15_PB12_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0050
#define GEN3_HDMI_TX_IF2PB19_PB16_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0054
#define GEN3_HDMI_TX_IF2PB23_PB20_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0058
#define GEN3_HDMI_TX_IF2PB27_PB24_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x005C
#define GEN3_HDMI_TX_IF3HB2_HB0_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0060
#define GEN3_HDMI_TX_IF3PB3_PB0_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0064
#define GEN3_HDMI_TX_IF3PB7_PB4_OFFSET           GEN3_HDMI_TX_TMDSINFR_BASE + 0x0068
#define GEN3_HDMI_TX_IF3PB11_PB8_OFFSET          GEN3_HDMI_TX_TMDSINFR_BASE + 0x006C
#define GEN3_HDMI_TX_IF3PB15_PB12_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0070
#define GEN3_HDMI_TX_IF3PB19_PB16_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0074
#define GEN3_HDMI_TX_IF3PB23_PB20_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x0078
#define GEN3_HDMI_TX_IF3PB27_PB24_OFFSET         GEN3_HDMI_TX_TMDSINFR_BASE + 0x007C
/*
#define GEN3_HDMI_TX_IF0DESCR_OFFSET             GEN3_HDMI_TX_TMDSINFR_BASE + 0x0400
#define GEN3_HDMI_TX_IF1DESCR_OFFSET             GEN3_HDMI_TX_TMDSINFR_BASE + 0x0404
#define GEN3_HDMI_TX_IF2DESCR_OFFSET             GEN3_HDMI_TX_TMDSINFR_BASE + 0x0408
#define GEN3_HDMI_TX_IF3DESCR_OFFSET             GEN3_HDMI_TX_TMDSINFR_BASE + 0x040C
#define GEN3_HDMI_TX_RSVD_A8_OFFSET              GEN3_HDMI_TX_TMDSINFR_BASE + 0x0410
*/

#define GEN3_HDMI_TX_IF0DESCR_OFFSET             GEN3_HDMI_TX_TMDSINFR_BASE + 0x0080
#define GEN3_HDMI_TX_IF1DESCR_OFFSET             GEN3_HDMI_TX_TMDSINFR_BASE + 0x0084
#define GEN3_HDMI_TX_IF2DESCR_OFFSET             GEN3_HDMI_TX_TMDSINFR_BASE + 0x0088
#define GEN3_HDMI_TX_IF3DESCR_OFFSET             GEN3_HDMI_TX_TMDSINFR_BASE + 0x008C
#define GEN3_HDMI_TX_RSVD_A8_OFFSET              GEN3_HDMI_TX_TMDSINFR_BASE + 0x0090


/* 1.13.8	HDCP Registers (5000h-5FFFh) */
#define GEN3_HDMI_TX_HHCR_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0000
#define GEN3_HDMI_TX_HHSR_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0004
#define GEN3_HDMI_TX_HRN0_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0008
#define GEN3_HDMI_TX_HRN1_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x000C

#define GEN3_HDMI_TX_HAN0_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0010
#define GEN3_HDMI_TX_HAN1_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0014
#define GEN3_HDMI_TX_HAK0_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0018
#define GEN3_HDMI_TX_HAK1_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x001C
#define GEN3_HDMI_TX_HBK0_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0020
#define GEN3_HDMI_TX_HBK1_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0024
#define GEN3_HDMI_TX_HPR0_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0028
#define GEN3_HDMI_TX_HR0_OFFSET                  GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x002C
#define GEN3_HDMI_TX_HPPJ_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0030
#define GEN3_HDMI_TX_HPJ_OFFSET                  GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0034
#define GEN3_HDMI_TX_HKBE0_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0038
#define GEN3_HDMI_TX_HKBE1_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x003C
#define GEN3_HDMI_TX_RSVD_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0040

#define GEN3_HDMI_TX_HK0L_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0060
#define GEN3_HDMI_TX_HK0M_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0064
#define GEN3_HDMI_TX_HK1L_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0068
#define GEN3_HDMI_TX_HK1M_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x006C

#define GEN3_HDMI_TX_HK2L_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0070
#define GEN3_HDMI_TX_HK2M_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0074
#define GEN3_HDMI_TX_HK3L_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0078
#define GEN3_HDMI_TX_HK3M_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x007C

#define GEN3_HDMI_TX_HK4L_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0080
#define GEN3_HDMI_TX_HK4M_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0084
#define GEN3_HDMI_TX_HK5L_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0088
#define GEN3_HDMI_TX_HK5M_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x008C

#define GEN3_HDMI_TX_HK6L_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0090
#define GEN3_HDMI_TX_HK6M_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0094
#define GEN3_HDMI_TX_HK7L_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0098
#define GEN3_HDMI_TX_HK7M_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x009C

#define GEN3_HDMI_TX_HK8L_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00A0
#define GEN3_HDMI_TX_HK8M_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00A4
#define GEN3_HDMI_TX_HK9L_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00A8
#define GEN3_HDMI_TX_HK9M_OFFSET                 GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00AC

#define GEN3_HDMI_TX_HK10L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00B0
#define GEN3_HDMI_TX_HK10M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00B4
#define GEN3_HDMI_TX_HK11L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00B8
#define GEN3_HDMI_TX_HK11M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00BC

#define GEN3_HDMI_TX_HK12L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00C0
#define GEN3_HDMI_TX_HK12M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00C4
#define GEN3_HDMI_TX_HK13L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00C8
#define GEN3_HDMI_TX_HK13M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00CC

#define GEN3_HDMI_TX_HK14L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00D0
#define GEN3_HDMI_TX_HK14M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00D4
#define GEN3_HDMI_TX_HK15L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00D8
#define GEN3_HDMI_TX_HK15M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00DC

#define GEN3_HDMI_TX_HK16L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00E0
#define GEN3_HDMI_TX_HK16M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00E4
#define GEN3_HDMI_TX_HK17L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00E8
#define GEN3_HDMI_TX_HK17M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00EC

#define GEN3_HDMI_TX_HK18L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00F0
#define GEN3_HDMI_TX_HK18M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00F4
#define GEN3_HDMI_TX_HK19L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00F8
#define GEN3_HDMI_TX_HK19M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x00FC

#define GEN3_HDMI_TX_HK20L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0100
#define GEN3_HDMI_TX_HK20M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0104
#define GEN3_HDMI_TX_HK21L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0108
#define GEN3_HDMI_TX_HK21M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x010C

#define GEN3_HDMI_TX_HK22L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0110
#define GEN3_HDMI_TX_HK22M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0114
#define GEN3_HDMI_TX_HK23L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0118
#define GEN3_HDMI_TX_HK23M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x011C

#define GEN3_HDMI_TX_HK24L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0120
#define GEN3_HDMI_TX_HK24M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0124
#define GEN3_HDMI_TX_HK25L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0128
#define GEN3_HDMI_TX_HK25M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x012C

#define GEN3_HDMI_TX_HK26L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0130
#define GEN3_HDMI_TX_HK26M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0134
#define GEN3_HDMI_TX_HK27L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0138
#define GEN3_HDMI_TX_HK27M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x013C

#define GEN3_HDMI_TX_HK28L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0140
#define GEN3_HDMI_TX_HK28M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0144
#define GEN3_HDMI_TX_HK29L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0148
#define GEN3_HDMI_TX_HK29M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x014C

#define GEN3_HDMI_TX_HK30L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0150
#define GEN3_HDMI_TX_HK30M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0154
#define GEN3_HDMI_TX_HK31L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0158
#define GEN3_HDMI_TX_HK31M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x015C

#define GEN3_HDMI_TX_HK32L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0160
#define GEN3_HDMI_TX_HK32M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0164
#define GEN3_HDMI_TX_HK33L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0168
#define GEN3_HDMI_TX_HK33M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x016C

#define GEN3_HDMI_TX_HK34L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0170
#define GEN3_HDMI_TX_HK34M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0174
#define GEN3_HDMI_TX_HK35L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0178
#define GEN3_HDMI_TX_HK35M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x017C

#define GEN3_HDMI_TX_HK36L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0180
#define GEN3_HDMI_TX_HK36M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0184
#define GEN3_HDMI_TX_HK37L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0188
#define GEN3_HDMI_TX_HK37M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x018C

#define GEN3_HDMI_TX_HK38L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0190
#define GEN3_HDMI_TX_HK38M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0194
#define GEN3_HDMI_TX_HK39L_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x0198
#define GEN3_HDMI_TX_HK39M_OFFSET                GEN3_HDMI_TX_TMDSHDCPR_BASE + 0x019C

/*******************************************
 * Control and I2C Registers (1000h-1FFFh) *
 *******************************************/
/* HCR- HDMI Control Register
   Memory Address Offset:	HCR 1000h-1003h
   Default Value:	00000000h
   Normal Access:	RW
   Size:	32 bits 
-------------------------------------------------------------------
Bits	Symbol	Default	Access	Description
-------------------------------------------------------------------
31:29			RV	Reserved. Write as zero.
28:16			RV	
15:7			RV	
6		0	RW	Audio Enable
				0: Audio disable
				1: Audio enable
				SW must disable audio in case of 
				change in audio format or sampling rate
5		0	RW	HDCP Enable
				0: HDCP disabled
				1: HDCP enabled
4		0	RW	HDMI Unit Enable
				0: HDMI Unit disabled
				1: HDMI Unit enabled
3		0	RW	HDMI 5V Enable
				0: Do not assert 5V signal 
				1: Assert 5V signal (HDMI PHY o/p)
2		1	RW	Gate Audio clock
				0: HDMI audio clock enabled
				1: HDMI audio clock gated
1		1	RW	Gate Pixel clock
				0: HDMI pixel clock enabled
				1: HDMI pixel clock gated
0		1	RW	Gate TMDS clock
				0: HDMI TMDS clock enabled
				1: HDMI TMDS clock gated
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_HCR[] = 
{
    //{ "",               29, 3, "", NULL },
    //{ "",               16, 13, "", NULL },
    //{ "",               7,  9, "", NULL },
    { "AUDIO_EN",             6,  1, "", NULL },
    { "HDCP_EN",              5, 1, "", NULL },
    { "HDMI_UNIT_EN",         4, 1, "", NULL },
    { "HDMI_5V_EN",         3, 1, "", NULL },
    { "GATE_AUDIO_CLK",         2, 1, "", NULL },
    { "GATE_PIXEL_CLK",         1, 1, "", NULL },
    { "GATE_TMDS_CLK",         0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* HICR- HDMI Interrupt Control Register
   Memory Address Offset:	HICR 1004h-1007h
   Default Value:	00000000h
   Normal Access:	RW
   Size:	32 bits
----------------------------------------------------------------------
Bits	Symbol	Default	Access	Description
----------------------------------------------------------------------
31:29			RW	Reserved. Write as zero.
28:21			RW	
20			RW	Enable interrupt when all 40keys available from SEC
19			RW	Enable Ri (128th Frame) available interrupt
18			RW	Enable Pre Ri (127th Frame) vailable interrupt
17			RW	Enable Pj (16th Frame) available interrupt
16			RW	Enable Pre Pj (15th Frame) available interrupt
15			RW	Encrypted Frame sent interrupt
14			RW	Enable M0 push to SEC done interrupt
13			RW	Enable Ro Done Interrupt
12			RW	Enable Key Buffer Ready interrupt
11:7			RW	
6			RW	Enable DMA Dst interrupt
5			RW	Enable DMA Src interrupt
4			RW	Enable I2C bus error interrupt
3			RW	Enable I2C buffer full interrupt
2			RW	Enable I2C transaction done interrupt
1			RW	Enable loss of HPD interrupt
0			RW	Enable HPD detected interrupt

*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_HICR[] = 
{
    //{ "",         29, 3, "", NULL },
    //{ "",         21, 8, "", NULL },
    { "EN_INT_ON_40_KEYS_AVAIL_FROM_SEC",                20, 1, "", NULL },
    { "EN_RI_AVAIL_INT",  19,1,"",NULL },
    { "EN_PRE_RI_AVAIL_INT",  18,1,"",NULL },
    { "EN_PJ_AVAIL_INT",  17,1,"",NULL },
    { "EN_PRE_PJ_AVAIL_INT",  16,1,"",NULL },
    { "ENCRYPT_FRAME_SENT_INT", 15,1,"",NULL },
    { "EM_MO_PUSH_TO_SEC_DNE_INT", 14,1,"",NULL },
    { "EN_RO_DNE_INT",    13, 1, "", NULL },
    { "EN_KEY_BUF_RDY_INT",    12, 1, "", NULL },
    //{ "",                7, 5, "", NULL },
    { "EN_DMA_DST_INT",                6, 1, "", NULL },
    { "EN_DMA_SRC_INT",                5, 1, "", NULL },
    { "EN_I2C_BUS_ERR_INT",                4, 1, "", NULL },
    { "EN_I2C_BUF_FUL_INT",                3,  1, "", NULL },
    { "EN_I2C_TRANS_DNE_INT",                2,  1, "", NULL },
    { "EN_LOSS_HPD_INT",    1,  1, "", NULL },
    { "EN_HPD_DET_INT",     0,  1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* HSR- HDMI Status Register
   Memory Address Offset:	HSR 1008h-100Bh
   Default Value:	00000000h
   Normal Access:	RW
   Size:	32 bits
Bits	Symbol	Default	Access	Description
31:29			RW	
28:16			RW	
15:2			RW	
1		0	RO	I2C Unit Busy
                                0: The HW I2C unit is available
                                1: HW is performing I2C transactions, 
                                the unit registers (offset 1100-11FFh) are 
                                not available to SW/CPU
0		0	RV	Reserved
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_HSR[] = 
{
    //{ "",      29, 3, "", NULL },
    //{ "",             16, 13, "", NULL },
    //{ "",      2, 14, "", NULL },
    { "I2C_UNIT_BUSY",             1,  1, "", NULL },
    //{ "",             0,  1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* HISR- HDMI Interrupt Status Register
   Memory Address Offset:	HISR 100Ch-100Eh
   Default Value:	00000000h
   Normal Access:	RW
   Size:	32 bits
Bits	Symbol	Default	Access	Description
31:29			RWC	Reserved. Write as zero.
28:21			RWC	Reserved
20			RWC	All keys received from SEC
19			RWC	Ri (128th Frame) available 
18			RWC	Pre Ri (127th Frame) vailable 
17			RWC	Pj (16th Frame) available 
16			RWC	Pre Pj (15th Frame) available 
15			RWC	Encrypted Frame sent
14			RWC	M0 push to SEC done
13			RWC	Ro calculation done. Ro Available
12			RWC	Key Buffer Ready after reset
11:7			RWC	
6			RWC	DMA DST interrupt
5			RWC	DMA SRC interrupt
4			RWC	I2C bus error occurred
3			RWC	I2C read buffer is full
2			RWC	I2C HW unit has completed the transaction
1			RWC	HDMI Unit detected loss of HPD
0			RWC	HDMI Unit detected HPD
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_HISR[] = 
{
    //{ "",                       29, 3, "", NULL },
    //{ "",                       21, 8, "", NULL },
    { "ALL_KEYS_RCVD_FROM_SEC",       20, 1, "", NULL },
    { "RI_AVAIL",                       19, 1, "", NULL },
    { "PRE_RI_AVAIL",                       18,  1, "", NULL },
    { "PJ_AVAIL",                       17,  1, "", NULL },
    { "PRE_PJ_AVAIL",        16,  1, "", NULL },
    { "ENCRYPTED_FRAME_SENT",                15,  1, "", NULL },
    { "MO_PUSH_TO_SEC_DONE",                14,  1, "", NULL },
    { "RO_AVAIL",                13,  1, "", NULL },
    { "KEY_BUFF_RDY_AFTER_RST",                12,  1, "", NULL },
    //{ "" , 7,5,"",NULL},
    {"DMA_DST_INT", 6,1,"",NULL},
    { "DMA_SRC_INT",                5, 1, "", NULL },
    { "I2C_BUS_ERR_INT",                4, 1, "", NULL },
    { "I2C_BUF_FUL_INT",                3,  1, "", NULL },
    { "I2C_TRANS_DNE_INT",                2,  1, "", NULL },
    { "LOSS_HPD_INT",    1,  1, "", NULL },
    { "HPD_DET_INT",     0,  1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* ICRH - I2C Control Register (HDMI)
   Memory Address Offset:	ICRH 1100h-1103h
   The IA core uses the bits in the I2C Control Register (ICR) to control the I2C unit. 
   ------------------------------------------------------------------
   Bits	   Symbol	Default	  Access        Description
   ------------------------------------------------------------------
		        	I2C  |	PCI	
   ------------------------------------------------------------------
   31:16		0	RV	RV	Reserved
   15		        0b	RO	RW	Fast Mode:
                                                0: 100 Kbit/sec. operation 
                                                1: 400 Kbit/sec. operation
   14		        0b	RO	RW	Unit Reset:
                                                0: No reset.
                                                1: Reset the I2C unit only
   13		        0b	RO	RW	Slave Address Detected Interrupt Enable:
                                                0: Disable interrupt
                                                1: Enables the I2C unit to interrupt the IA core 
                                                   upon detecting a slave address match or a general call address.
   12		        0b	RO	RW	Arbitration Loss Detected Interrupt Enable:
                                                0: Disable interrupt
                                                1: Enables the I2C unit to interrupt the IA core upon 
                                                   losing arbitration while in Master mode.
   11		        0b	RO	RW	Slave STOP Detected Interrupt Enable: 
                                                0: Disable interrupt
                                                1: Enables the I2C unit to interrupt the IA core when 
                                                   it detects a STOP condition while in slave mode.
   10		        0b	RO	RW	Bus Error Interrupt Enable: 
                                                0: Disable interrupt
                                                1: Enables the I2C unit to interrupt the IA core for the following 
                                                   I2C bus errors: As a master transmitter, no Ack was detected after 
                                                   a byte was sent. As a slave receiver, the I2C unit generated 
                                                   a NACK pulse. Software is responsible for guaranteeing that 
                                                   misplaced START and STOP conditions do not occur. 
   09		        0b	RO	RW	IDBRH Receive Full Interrupt Enable:
                                                0: Disable interrupt
                                                1: Enables the I2C unit to interrupt the IA core when the IDBRH 
                                                   has received a data byte from the I2C bus.
   08		        0b	RO	RW	IDBRH Transmit Empty Interrupt Enable: 
                                                0: Disable interrupt
                                                1: Enables the I2C unit to interrupt the IA core after transmitting 
                                                   a byte onto the I2C bus.
   07		        0b	RO	RW	General Call Disable:
                                                0: Enables the I2C unit to respond to general call messages
                                                1: Disables I2C unit response to general call messages as a slave. 
                                                   This bit must be set when sending a master mode general 
                                                   call message from the I2C unit.
   06		        0b	RO	RW	I2C Unit Enable: 
                                                0: Disables the unit and does not master any transactions or 
                                                   respond to any slave transactions
                                                1: Enables the I2C unit (defaults to slave-receive mode). 
                                                   Software must guarantee the I2C bus is idle before setting this bit.
   05		        0b	RO	RW	SCL Enable:
                                                0: Disables the I2C unit from driving the SCL line
                                                1: Enables the I2C clock output for master mode operation. 
                                                   The ICCR must be programmed with a valid value before setting 
                                                   this bit. 
   04		        0b	RO	RW	Master Stop: used by the I2C unit when in master mode to generate 
                                                a STOP without transmitting another data byte. The I2C unit transmits 
                                                STOP using the STOP ICR bit only. The I2C unit sends STOP without data 
                                                transmission. 
                                                When in Master transmit mode, after transmitting a data byte, 
                                                the ICR's Transfer Byte bit is cleared and IDBRH Transmit Empty 
                                                bit is set. When no more data bytes need to be sent, setting master 
                                                abort bit sends the STOP. The Transfer Byte bit (03) must remain clear.
                                                In master-receive mode, when a Nack is sent without a STOP 
                                                (STOP ICR bit was not set) and the CE 31xx does not send a repeated 
                                                START, setting this bit sends the STOP. Once again, the Transfer Byte 
                                                bit (03) must remain cleared.
   03		        0b	RO	RW	Transfer Byte: used to send/receive a byte on the I2C bus. Cleared by
                                                I2C unit when the byte is sent/received. The IA core can monitor this 
                                                bit to determine when the byte transfer has completed. 
                                                In master or slave mode, after each byte transfer including Ack/Nack 
                                                bit, the I2C unit holds the SCL line low (inserting wait states) until
                                                the Transfer Byte bit is set. 
   02		        0b	RO	RW	Ack/Nack Control: defines the type of Ack pulse sent by the 
                                                I2C unit when in master receive mode. The I2C unit sends an Ack pulse 
                                                after receiving a data byte. The I2C unit sends a negative Ack (Nack) 
                                                after receiving a data byte when this bit is '1'.The I2C unit 
                                                automatically sends an Ack pulse when responding to its slave address 
                                                or when responding in slave-receive mode, independent of the Ack/Nack 
                                                control bit setting.
   01		        0b	RO	RW	STOP: used to initiate a STOP condition after transferring the next 
                                                data byte on the I2C bus when in master mode. In master-receive mode, 
                                                the Ack/Nack control bit must be set in conjunction with this bit. 
                                                See Default, "for more details on the STOP state. 
                                                0: Do not send a STOP. 
                                                1: Send a STOP.
   00		        0b	RO	RW	START: used to initiate a START condition to the I2C unit when in 
                                                master mode. See Default   "for more details on the START state. 
                                                0: Do not send a START. 
                                                1: Send a START.
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_ICRH[] = 
{
    { "RSVD_16_16",                16,  16, "", NULL },
    { "FAST_MODE",                 15,  1, "", NULL },
    { "UNIT_RESET",                14,  1, "", NULL },
    { "SLAVE_ADDR_DET_INT_EN",     13,  1, "", NULL },
    { "ARB_LOSS_DET_INT_EN",       12,  1, "", NULL },
    { "SLAVE_STOP_DET_INT_EN",     11,  1, "", NULL },
    { "BUS_ERR_INT_EN",            10,  1, "", NULL },
    { "IDBRH_RCV_FULL_INT_EN",     9,  1, "", NULL },
    { "IDBRH_TRANS_EMPTY_INT_EN",  8,  1, "", NULL },
    { "GEN_CALL_DIS",              7,  1, "", NULL },
    { "I2C_UNIT_EN",               6,  1, "", NULL },
    { "SCL_ENABLE",                5,  1, "", NULL },
    { "MASTER_STOP",               4,  1, "", NULL },
    { "TRANSFER_BYTE",             3,  1,  "", NULL },
    { "ACK_NACK_CTRL",             2,  1,  "", NULL },
    { "STOP",                      1,  1,  "", NULL },
    { "START",                     0,  1,  "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* ISRH - I2C Status Register (HDMI)
   Memory Address Offset:	ISRH 1104h-1107h
   ------------------------------------------------------------------
   Bits	   Symbol	Default	  Access        Description
   ------------------------------------------------------------------
		        	I2C  |	PCI	
   ------------------------------------------------------------------
   31:11		0	RV	RV	Reserved
   10		        0b	RC	RV	Bus Error Detected:
                                                0: No error detected.             
   09		        0b	RC	RV	Slave Address Detected:
                                                0: No slave address detected. 
                                                1: I2C unit detected a 7-bit address that 
                                                   matches the general call address or ISAR. 
                                                   An interrupt is signaled when enabled in the ICR. 
   08		        0b	RC	RV	General Call Address Detected:
                                                0: No general call address received
                                                1: I2C unit received a general call address. 
   07		        0b	RC	RV	IDBRH Receive Full:
                                                0: The IDBRH has not received a new data byte or the I2C unit is idle. 
                                                1: The IDBRH register received a new data byte from the I2C bus. 
                                                   An interrupt is signaled when enabled in the ICR. 
   06		        0b	RC	RV	IDBRH Transmit Empty:  
                                                0: The data byte is still being transmitted.
                                                1: The I2C unit has finished transmitting a data byte on the I2C bus. 
                                                   An interrupt is signaled when enabled in the ICR.
   05		        0b	RC	RV	Arbitration Loss Detected:  
                                                read-only: used during multi-master operation. 
                                                Cleared when arbitration is won or never took place. 
                                                Set when the I2C unit loses arbitration. 
   04		        0b	RC	RV	Slave STOP Detected: No STOP detected. 
                                                Set when the I2C unit detects a STOP while in slave-receive or 
                                                slave-transmit mode. 
   03		        0b	RO	RV	I2C Bus Busy: I2C bus is idle or the I2C unit is using the bus 
                                                (i.e., unit busy). Set when the I2C bus is busy but the CE 31xx's 
                                                I2C unit is not involved in the transaction. 
   02		        0b	RO	RV	Unit Busy: I2C unit not busy. Set when the CE 31xx's I2C unit is busy. 
                                                This is defined as the time between the first START and STOP. 
   01		        0b	RO	RV	Ack/Nack Status: 
                                                0: The I2C unit received or sent an Ack on the bus. 
                                                1: The I2C unit received or sent a Nack. 
   00		        0b	RO	RV	Read/Write Mode: 
                                                0: The I2C unit is in master-transmit or slave-receive mode. 
                                                1: reserved. This is the R/W# bit of the slave address. It
                                                is automatically cleared by hardware after a stop state.

*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_ISRH[] = 
{
    {"",11,21,"",NULL},
    {"BUS_ERR_DETECTED",10,1,"",NULL},
    {"SLAVE_ADDR_DETECTED",9,1,"",NULL},
    {"GENERAL_CALL_ADDR_DETECTED",8,1,"",NULL},
    {"IDBRH_RECV_FULL",7,1,"",NULL},
    {"IDBRH_TRANS_EMPTY",6,1,"",NULL},
    {"ARB_LOSS_DETECTED",5,1,"",NULL},
    {"SLAVE_STOP_DETECTED",4,1,"",NULL},
    {"I2C_BUS_BUSY",3,1,"",NULL},
    {"UNIT_BUSY",2,1,"",NULL},
    {"ACK_NACK_STATUS",1,1,"",NULL},
    {"RD_WR_MODE",0,1,"",NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* IDBR - I2C Data Buffer Register 
   ------------------------------------------------------------------
   Bits	   Symbol	Default	  Access        Description
   ------------------------------------------------------------------
		        	I2C  |	PCI	
   ------------------------------------------------------------------
   31:08		0	RV	RV	Reserved
   07:00		00h	RW	RW	I2C Data Buffer: Buffer for I2C bus send/receive data.

*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_IDBRH[] = 
{
    { "RSVD_31_08",                8,  24, "", NULL },
    { "I2C_DATA_BUFFER",           0,  8, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* IBMRH-I2C Bus Monitor Register (HDMI)
   Memory Address Offset:	IBMRH 110Ch-110Fh
   ------------------------------------------------------------------
   Bits	   Symbol	Default	  Access        Description
   ------------------------------------------------------------------
		        	I2C  |	PCI	
   ------------------------------------------------------------------
   31:02		0	RV	RV	Reserved
   01		        1b	RO	RO	SCL Status: This bit continuously reflects the value of the SCL pin.
   00		        s1b	RO	RO	SDA Status: This bit continuously reflects the value of the SDA pin.

*/
				
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_IBMRH[] = 
{
    { "RSVD_31_02",                2,  30, "", NULL },
    { "SCL_STATUS",                1,  1, "", NULL },
    { "SDA_STATUS",                0,  1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};
		
/* I2CHCR-I2C Hardware Control Register
   Memory Address Offset:	I2CHCR 1110h-1113h
   Default Value:	00000000h
   Normal Access:	RW
   Size:	32 bits
   ------------------------------------------------------------------
   Bits	   Symbol      Default  Access        Description
   ------------------------------------------------------------------
   31:30		        RV            Reserved. Write as zero.
   29:20		0	RW	      Number of bytes to read/write
                                             10 bit value indicating number of bytes to read/write before 
                                             issuing an I2C STOP                                           
   19:12		0	RW	     Segment pointer address (only valid when transaction type is 11)
                                             8 bit segment pointer offset address to read from
   11:4		        0	RW	     Offset address
                                             8 bit start offset address (in the sink) to read from/write to
   3:2		        0	RW	     I2C Transaction Type
                                             00: HDCP transaction (read or write)
                                             01: HDCP Ri read transaction
                                             10: EDID read transaction
                                             11: E-EDID read transaction (segment pointer must be programmed)
   1                    0       RW           Continue transaction 					     
   0		        0	RW	     Transaction enable
                                             0: Disable I2C transactions by HW
                                             1: Enable HW to perform I2C transactions
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_PHY_I2CHCR[] = 
{
    { "RSVD_31_30",                30,  2, "", NULL },
    { "NO_OF_BYTES",               20,  10, "", NULL },
    { "SEG_PTR_ADDR",              12,  8, "", NULL },
    { "START_OFFSET_ADDR",         4,   8, "", NULL },
    { "I2C_TRANS_TYPE",            2,   2, "", NULL },
    { "CONT_TRANS",                1,   1, "", NULL },
    { "TRANS_EN",                  0,   1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* I2CTR0 - I2C Transmit Data Register0
   Memory Address Offset:	I2CTR0 1114h-1117h
   Default Value:	00000000h
   Normal Access:	RW
   Size:	32 bits
   ------------------------------------------------------------------
   Bits	   Symbol      Default  Access        Description
   ------------------------------------------------------------------
   31:0			        RW	      Data to be written over I2C to the HDMI receiver

*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_I2CTR0[] = 
{
   { "DATA",                  0,   32, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* I2CTR1- I2C Transmit Data Register1 
   Memory Address Offset:	I2CTR1 1118h-111Bh
   Default Value:	00000000h
   Normal Access:	RW
   Size:	32 bits
   ------------------------------------------------------------------
   Bits	   Symbol      Default  Access        Description
   ------------------------------------------------------------------
   31:0			        RW	      Data to be written over I2C to the HDMI receiver

*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_I2CTR1[] = 
{
   { "DATA",                  0,   32, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* I2CRDB0-I2CRDB19 - I2C Read Data Buffer
   Memory Address Offset:	I2CRDB 111Ch-116Bh
   Default Value:	00000000h
   Normal Access:	RW
   Size:	20 X 32 bits
*/
   //NO BIT BREAK OUT FOR THIS REGISTER

/*******************************************
 * Input Video Processing Registers (2000h-2FFFh)   *
 *******************************************/

/* DCR -Dither Control Register
Memory Address Offset:	DCR 2000h-2003h
Default Value:	00000000h
Normal Access:	RW
Size:	32 bits
Table 1 17. Dither Control Register

Bits	Symbol	Default	Access	Description
31:3			RV	Reserved. Write as zero.
2		0	RW	Controls HDMI TX dither enable (if bit 0 is enabled):
                                0: Select Rounding (default)
                                1: Select Dither
1		0	RW	Controls HDMI TX Dither output (if bit 0 is enabled):
                                0: 12 to 10 bit dither/rounding
                                1: 12 to 8 bit dither/rounding
0		0	RW	Bypass HDMI TX dithering logic (see Note below)
                                0: Don't bypass dither/rounding (enabled)
                                1: Disable dither/rounding
                                Note: Dithering is bypassed, irrespective 
                                of this bit, when input pixels are converted 
                                to YCbCr422.
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_DCR[] = 
{
   //{ "",                  3,   29, "", NULL },
   { "SEL_DITHER_ROUNDING",  2,   1, "", NULL },
   { "SEL_12TO10_12TO8",      1,   1, "", NULL },
   { "BYPASS_HDMI_TX_DITHER_LOGIC",      0,   1, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* DPRNGSR-Dither PRNG Shift Register

This register can be used to program and read current values out of shift register1 and shift register2 in the pseudo random number generator (PRNG) used for the Dither functionality. A write to these registers initializes the seeds for random number generation.
Memory Address Offset: 2004h - 2007h
Default Value:	00000000h
Access:	RW
Size:	32 bits 

Table 1 18. DPRNG Shift Register
Bits	Symbol	Default	Access	Description

31:30			RV	Reserved.
29:16	seed2		RW	PRNG Shift Register2
15:13			RV	Reserved.
12:0	seed1		RW	PRNG Shift Register1
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_DPRNGSR[] = 
{
   //{ "",                  30,   2, "", NULL },
   { "SEED2",  16,   14, "PRNG Shift register 2", NULL },
   //{ "",      13,   3, "", NULL },
   { "SEED1",      0,   13, "PRNG Shift Register 1", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* CSCCR - CSC Control Register
Memory Address Offset:	CSCCR 2008h-200Bh
Default Value:	00000000h
Normal Access:	RW
Size:	32 bits
Table 1 19. CSC Control Register

Bits	Symbol	Default	Access	Description
31:3			RV	Reserved. Write as zero.
2		0	RW	Convert to 422 format (only 12 bit 422 is supported)
                                0: Send output of CSC unchanged (as is)
                                1: Convert to YCbCr 422 output (there is an 
                                   assumption here that the CSC has been 
                                   correctly programmed to output YCbCr 444)
1		0	RW	Input colorspace of VDC data
                                0: RGB 444
                                1: YCbCr 444
0		0	RW	Enables/disables HDMI TX colorspace conversion logic
                                0: CSC unit disabled
                                1: CSC unit enabled
                                Note: If CSC unit is enabled, 
                                then CSC registers (offset 2100h - 21FFh) 
                                need to be programmed accordingly
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_CSCCR[] = 
{
   //{ "",                  3,   29, "", NULL },
   { "CONVERT_TO_422",  2,   1, "", NULL },
   { "INPUT_CS",      1,   1, "", NULL },
   { "EN_HDMI_TX_CSC",      0,   1, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* UPCSCC - Universal Plane CSC Clamp Register
   Memory Address Offset:	UPCSCC 2100h-2103h 
   Default Value:		UPCSCC = 00000000h
   Access:			RW
   Size: 			32 bits 
   Bits	Symbol	Default	Access	Description
   31:6			RV	Reserved.
   5	VAL_SHIFT_FACTOR		RW	0 - use half overrun value for shift value
                                                1 - use full overrun value for shift value
   4	VAL_SHIFT_EN		RW	Enable output shifted by a value
   3	C_OCLAMP_SEL		RW	0 - Cb/B,Cr/R is clamped to 940
                                        1 - Cb/B, Cr/R is clamped to 960
   2	EN_OCLAMP		RW	Enable output clamping
                                        If enabled:
					Y/G range is limited to [64,940]
					Cb/B, Cr/R range is limited to either [64,940] or [64 960] 
					(depending onCb/Cr clamp select).
   1	C_ICLAMP_SEL		RW	0 - Cb/B,Cr/R is clamped to 940
                                        1 - Cb/B, Cr/R is clamped to 960
   0	EN_ICLAMP		RW	Enable input clamping
                                        If enabled:
                                        Y/G range is limited to [64,940]
					Cb/B, Cr/R range is limited to either [64,940] or [64 960] 
					(depending onCb/Cr clamp select).
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_UPCSCC[] = 
{
   //{ "",                  6,   26, "", NULL },
   { "VAL_SHIFT_FACTOR",  5,   1, "", NULL },
   { "VAL_SHIFT_EN",      4,   1, "", NULL },
   { "C_OCLAMP_SEL",      3,   1, "", NULL },
   { "EN_OCLAMP",      2,   1, "", NULL },
   { "C_ICLAMP_SEL",      1,   1, "", NULL },
   { "EN_ICLAMP",      0,   1, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* UPCSCYGOFF - Universal Plane CSC Y/G Offset Register
   Memory Address Offset:	UPCSCYGOFF 2104h-2107h 
   Default Value:		UPCSCYGOFF = 00000000h
   Access:			RW
   Size: 			32 bits 
   Bits	        Symbol	Default	Access	Description
   31:30			RV	Reserved.
   29:16	YG_OOFF		RW	2's complement signed output offset for Y/G
   15:11			RV	Reserved
   10:0	        YG_IOFF		RW	2's complement signed input offset for Y/G
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_UPCSCYGOFF[] = 
{
   { "RSVD_31_30",                  30,   2, "", NULL },
   { "YG_OOFF",                     16,   14, "", NULL },
   { "RSVD_15_11",                  11,   5, "", NULL },
   { "YG_IOFF",                     0,   11, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};


/* UPCSCCBOFF - Universal Plane CSC Cb/B Offset Register
   Memory Address Offset:	UPCSCCBOFF 2108h-210Bh 
   Default Value:		UPCSCCBOFF = 00000000h
   Access:			RW
   Size: 			32 bits 

   Bits	        Symbol	Default	Access	Description
   31:30			RV	Reserved.
   29:16	CB_OOFF		RW	2's complement signed output offset for Cb/B
   15:11			RV	Reserved
   10:0	        CB_IOFF		RW	2's complement signed input offset for Cb/B
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_UPCSCCBOFF[] = 
{
   { "RSVD_31_30",                  30,   2, "", NULL },
   { "CB_OOFF",                     16,   14, "", NULL },
   { "RSVD_15_11",                  11,   5, "", NULL },
   { "CB_IOFF",                     0,   11, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* UPCSCCROFF - Universal Plane CSC Cr/R Offset Register
   Memory Address Offset:	UPCSCCROFF 210Ch-210Fh (address)?
   Default Value:		UPCSCCROFF = 00000000h
   Access:			RW
   Size: 			32 bits 

   Bits	        Symbol	Default	Access	Description
   31:30			RV	Reserved.
   29:16	CR_OOFF		RW	2's complement signed output offset for Cr/R
   15:11			RV	Reserved
   10:0	        CR_IOFF		RW	2's complement signed input offset for Cr/R
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_UPCSCCROFF[] = 
{
   { "RSVD_31_30",                  30,   2, "", NULL },
   { "CR_OOFF",                     16,   14, "", NULL },
   { "RSVD_15_11",                  11,   5, "", NULL },
   { "CR_IOFF",                     0,   11, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* UPCSCC01- Universal Plane CSC Coefficient01 Register
   Memory Address Offset:	UPCSCC01 2110h-2113h
   Default Value:		UPCSCC01 = 00000000h
   Access:			RW
   Size: 			32 bits 

   Bits	      Symbol	Default	Access	Description
   31:30			RV	Reserved.
   26:16	C1		RW	2's complement signed coefficient 1 (1.10 format)
   15:11			RV	Reserved
   10:0	        C0		RW	2's complement signed coefficient 0  (1.10 format)
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_UPCSCC01[] = 
{
   { "RSVD_31_30",                  30,   2, "", NULL },
   { "C1",                          16,   14, "", NULL },
   { "RSVD_15_11",                  11,   5, "", NULL },
   { "C0",                          0,   11, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* UPCSCC23 - Universal Plane CSC Coefficient23 Register
   Memory Address Offset:	UPCSCC23 2114h-2117h
   Default Value:		UPCSCC23 = 00000000h
   Access:			RW
   Size: 			32 bits 

   Bits	Symbol	Default	Access	Description
   31:30	       	RV	Reserved.
   26:16	C3     	RW	2's complement signed coefficient 1 (1.10 format)
   15:11	       	RV	Reserved
   10:0	        C2    	RW	2's complement signed coefficient 0  (1.10 format)
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_UPCSCC23[] = 
{
   { "RSVD_31_30",                  30,   2, "", NULL },
   { "C3",                          16,   14, "", NULL },
   { "RSVD_15_11",                  11,   5, "", NULL },
   { "C2",                          0,   11, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* UPCSCC45 - Universal Plane CSC Coefficient45 Register
   Memory Address Offset:	UPCSCC45 2118h-211Bh
   Default Value:		UPCSCC45 = 00000000h
   Access:			RW
   Size: 			32 bits 

   Bits	Symbol	Default	Access	Description
   31:30	       	RV	Reserved.
   26:16	C5     	RW	2's complement signed coefficient 1 (1.10 format)
   15:11	       	RV	Reserved
   10:0	        C4      RW	2's complement signed coefficient 0  (1.10 format)
  
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_UPCSCC45[] = 
{
   { "RSVD_31_30",                  30,   2, "", NULL },
   { "C5",                          16,   14, "", NULL },
   { "RSVD_15_11",                  11,   5, "", NULL },
   { "C4",                          0,   11, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* UPCSCC67 - Universal Plane CSC Coefficient 67 Register
   Memory Address Offset:	UPCSCC67 211Ch-211Fh
   Default Value:		UPCSCC67 = 00000000h
   Access:			RW
   Size: 			32 bits 

Bits	Symbol	Default	Access	Description
31:30			RV	Reserved.
26:16	C7		RW	2's complement signed coefficient 1 (1.10 format)
15:11			RV	Reserved
10:0	C6		RW	2's complement signed coefficient 0  (1.10 format)
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_UPCSCC67[] = 
{
   { "RSVD_31_30",                  30,   2, "", NULL },
   { "C7",                          16,   14, "", NULL },
   { "RSVD_15_11",                  11,   5, "", NULL },
   { "C6",                          0,   11, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* UPCSCC8 - Universal Plane CSC Coefficient8 Register
   Memory Address Offset:	UPCSCC8 2120h-2123h
   Default Value:		UPCSCC8 = 00000000h
   Access:			RW
   Size: 			32 bits 

Bits	Symbol	Default	Access	Description
31:11			RV	Reserved.
10:0	C8		RW	2's complement signed coefficient 0  (1.10 format)
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_UPCSCC8[] = 
{
   { "RSVD_31_11",                  11,   21, "", NULL },
   { "C8",                          0,   11, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/******************************************************
 *  HDMI Video Format register
 ******************************************************/
/* Video Output Format Register
Memory Address Offset:	VOFR_A 3000h-3003h
Default Value:	00000000h
Normal Access:	RW
Size:	32 bits

Table 1 30. Video Output Format Register
Bits	Symbol	Default	Access	Description

31:5			RV	Reserved. Write as zero.
4		1	RW	VSYNC output polarity
                                0: Active low VSYNC (-ve polarity)
                                1: Active high VSYNC (+ve polarity)
3		1	RW	HSYNC output polarity
                                0: Active low HSYNC (-ve polarity)
                                1: Active high HSYNC (+ve polarity)
2:1		0	RW	Pixel depth of HDMI TX output
                                00: 8 bit pixel depth 
                                (Note: 12 bit YCbCr 422 - requires this to be set to '00')
                                01: 10 bit pixel depth
                                10: 12 bit pixel depth
                                11: not allowed
0		0	RW	HDMI or DVI mode of HDMI TX output
                                0: DVI output
                                1: HDMI output
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_VOFR[] = 
{
  //{ "",                  5, 27  , "", NULL },
  { "VSYNC_OUTPUT_POLARITY",                  4, 1, "", NULL },
  { "HSYNC_OUTPUT_POLARITY",                  3, 1, "", NULL },
  { "PIXEL_DEPTH",                  1, 2, "", NULL },
  { "HDMI_DVI_MODE",                  0, 1, "", NULL },
  { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* HBLANK_A-Pipe A Horizontal Blank Register
   Memory Address Offset:	HBLANK_A 3100h-3103h
   Default Value:	00000000h
   Normal Access:	RW
   Size:	32 bits

Bits	Symbol	Default	Access	Description
31:28			RV	Reserved. Read Only.
27:16	hactive		RW	Pipe A Horizontal Active display pixels
15:10			RV	Reserved. Read Only.
9:0	hblank		RW	Pipe A Horizontal Blank Display clocks. 
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_HBLANK_A[] = 
{
   //{ "RSVD_31_29",                  29,   3, "", NULL },
   { "HACTIVE",                       16,   12, "", NULL },
   //{ "RSVD_15_13",                  13,   3, "", NULL },
   { "HBLANK",                        0,   10, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* VTOTAL_A-Pipe A Vertical Total Register
   Memory Address Offset:	VTOTAL_A 3104h-3107Fh
   Default Value:	00000000h
   Normal Access:	RW
   Size:	32 bits

Bits	Symbol	Default	Access	Description
31:29			RV	Reserved. Write as zero.
28:16	vtotal		RW	Pipe A Vertical Total Display Lines.
15:12			RV	Reserved. Write as zero.
11:0	vactive		RW	Pipe A Vertical Active Display Lines.
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_VTOTAL_A[] = 
{
   { "RSVD_31_29",                  29,   3, "", NULL },
   { "VTOTAL",                      16,   13, "", NULL },
   { "RSVD_15_12",                  12,   4, "", NULL },
   { "VACTIVE",                     0,   12, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};


/*******************************************
 * Audio Control Registers (3000h-3FFFh)   *
 *******************************************/

/* 1.15.5.1	Audio Format Control Register
   Memory Address Offset:	AFCR 3000h-3003h
   Default Value:	00000000h
   Normal Access:	RW
   Size:	32 bits

Table 1-35. Audio Format Control Register
Bit	Symbol  	Default	Access	Description
31:10	Unused		        RV	Reserved
9	Validity	0	RW	Validity Bit (V)
                                        HW will pack this bit into both the L & R sub-frames
8	Sample Flat	0	RW	Sample Flat bit
                                        When set the sample flat bit will be set in all HDMI sub-packets.
7	Set Block begin	0	RW	Controls the B bit in the header for non Layout 0 mode
                                        0: The B bit will be set only for sub-packet 0
					1: The B bit in the Audio sample packet header will be set for all valid sub-packets.
6	Fs > 192 KHz	0	RW	This bit is used only by the ACR (N/CTS) logic.
                                        0: The audio sample frequency fs is less than 192 kHz
					1: The audio sample frequency is greater than 192 kHz
5:4	Num. audioch	0	RW	00: 2 channels (stereo)
                                        01: 3 or 4 channels 
                                        10: 5 channels or 6 channels
                                        11: 7 channels or 8 channels 
3:2	Format	        0	RW	00: L-PCM or IEC 61937
                                        01: High Bit Rate IEC 61937 stream packet
					10: One Bit Audio Sample packet (not supported)
					11: DST Audio Sample packet (not supported)
1	Layout	        0	RW	0: Layout 0
                                        1: Layout 1 
0	Audio Enable	0	RW	Controls generation of N/CTS and transmission of audio sample packets
                                        0: Audio sample packets are not transmitted, CTS calculation/transmission is disabled
					1: Audio sample packets are transmitted & CTS calculation is enabled

*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_AFCR[] = 
{
   { "VALIDITY",        9,    1, "", NULL },
   { "SAMPLE_FLAT",        8,    1, "", NULL },
   { "SET_BLOCK_BEGIN",        7,    1, "", NULL },
   { "FS_GREATER_THAN_192",        6,    1, "", NULL },
   { "NUM_CHANNELS",             4,    2, "", NULL },
   { "FORMAT",                   2,    2, "", NULL },
   { "LAYOUT",                   1,    1, "", NULL },
   { "AUDIO_EN",                 0,    1, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Audio Rate Control Register
Memory Address Offset:	ARCR 4004h-4007h
Default Value:	00000000h
Normal Access:	RW
Size:	32 bits

Table 1-40. Audio Rate Control Register
Bit	Symbol	Default	Access	Description
31:29	num_lines_between_aud_pkts	0	RW	Number of lines between audio packets
                                                        Send available num. of audio packets/line (13:9) every
                                                        000: Every line
                                                        001: Every alternate line
                                                        010: Every three lines
                                                        011: Every 4 lines
                                                        100: Every 5 lines
                                                        101: Every 6 lines
                                                        110: Every 7 lines
                                                        111: Every 8 lines
28:24		                       0	RW	Unused
23:8	num_audio_pkts	               0	RW	Total number ('n') of audio packets to be transmitted over m video fields
7:5	num_fields	                0	RW	Number of fields (m) over which 'n' audio packets need to be sent
                                                        000: Don't use this parameter
                                                        3'h1 - 3'h7 - 1 through 7 fields
4:0	aud_pkt_per_line	         0	RW	5 bit value (decimal 2 through 18 - see this spreadsheet - 1st tab - HDMI audio Modes New)
                                                        This value is programmed based on the audio sample rate, number of channels and corresponding video format
*/
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_ARCR[] = 
{
   { "NO_LINES_BETWEEN_AUDIO_PACKETS",            29,3   , "", NULL },
   //{ "",            24,   5, "", NULL },
   { "N_AUDIO_PKTS",            8,   16, "", NULL },
   { "M_VIDEO_FIELDS",                  5,   3, "", NULL },
   { "NO_OF_AUDIO_PKTS_PER_LINE",                 0,    5, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* InfoFrame Descriptor Register
Memory Address Offset:	IF0DESCR 4500h-4503h
Default Value:	00000000h
Normal Access:	RW
Size:	2 bits

Table 1-46. IF0DESC Register
----------------------------
Bit	Name	Default	Access	Description
31:2			RV	
1			RW	InfoFrame0 transmit frequency
                                0: Send every frame
				1: Send once
0			RW	InfoFrame0 Valid bit
                                0: Invalid (don't send)
				1: Valid (send)
Note: HW will clear the valid bit - for cases where transmit frequency (bit1) was set to '1' - send once.
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_IFDESC[] = 
{
   { "TRANS_FREQ",            1,    1, "", NULL },
   { "VALID",                 0,    1, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/*     Audio Clock Recovery CTS Register
Memory Address Offset:	ACRCTSR 400Ch-400Fh
Default Value:	00000000h
Normal Access:	RW
Size:	21 bits

Table 1-37. CTS Register
------------------------
Bit	Name	Default	Access	Description
31:21			RV	
20			RW	Bypass CTS calculation
                                0: HW will calculate CTS
				1: Use programmed value of CTS
19:0			RW	20 bit CTS value
 */
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_ACRCTSR[] = 
{
   { "BYPASS_CTS",                  20,   1, "", NULL },
   { "CTS_VAL",                 0,    19, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* HHCR- HDMI HDCP Control Register
Bits	Symbol	Default	Access	Description
31:11			RV	Reserved. Write as zero.
11		0	RW	Ring cipher enable
                                0: Ring cipher disabled
                                1: Ring cipher enabled
10		0	RW	Enable 1.1 Features
                                0: 1.1 Features disabled
                                1: 1.1 Features Enabled
9		0	RW	Enhanced Link Verification Enable
                                0: Enh. Link Verification is disabled
				1: Enh. Link Verification is Enabled
8		0	RW	Advance Cipher Mode Enable
                                0: Adv. Cipher mode is disabled
				1: Adv. Cipher mode is enabled.
7		0	RW	REPEATER 
                                0: Device connected to CE 31xx is not a repeater
				1: Device connected is a repeater
6		0	RW	EESS Enable
                                0: EESS Signaling Disabled
				1: EESS Signaling Enabled
5		0	RW	OESS Enable
                                0: OESS Signaling Disabled
				1: OESS Signaling Enabled
4		0	RW	Encryption Enable
                                0: Encryption is disabled 
				1: All frames from the next active VSYNC edge are encrypted if unit is in Authenticated state
3		0	RW	Authenticated State
                                0: Authentication not established with Sink 
                                1: Successful authentication with Sink. HDMI unit goes into Auth. state
2		0	RW	Push M0
                                0: M0 is stored locally after Ro calculation
                                1: Active edge triggers the HDMI unit to push M0 value to SEC
1		0	RW	Calculate Ro
                                0: Ro Calculation disabled
				1: Active edge triggers capture of Ro
0		0	RW	Calculate An
                                0: An Capture disabled
                                1: Active edge triggers capture of An from Cipher in Ring Mode
*/

static const struct EAS_RegBits g_csr_gen3_hdmi_tx_HHCR[] = 
{
   { "RING_CIPHER_EN",                 11,    1, "", NULL },
   { "FEATURE_1_1_EN",                 10,    1, "", NULL },
   { "ENHANCE_LINK_VERIFICATION_EN",   9,    1, "", NULL },
   { "ADV_CIPHER_EN",                  8,    1, "", NULL },
   { "REPEATER",                       7,    1, "", NULL },
   { "EESS_EN",                        6,    1, "", NULL },
   { "OESS_EN",                        5,    1, "", NULL },
   { "ENCRYPTION_EN",                  4,    1, "", NULL },
   { "AUTHENTICATED_STATE",            3,    1, "", NULL },
   { "PUSH_M0",                        2,    1, "", NULL },
   { "CALCULATE_R0",                   1,    1, "", NULL },
   { "CALCULATE_AN",                   0,    1, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};


/* FLAGS_MODE Register
   Bits	Name	                         Default	 Description
   31	ACTIVE: DMA Active	         0	         '1' - DMA context is active (has been started but has not finished). 
                                                         '0' - DMA context is not active.
   30	SRC_INT: Source Interrupt Enable 0	         Interrupt when the current (active context) transfer has finished 
                                                         (source byte counter reaches zero) or when in circular-buffer 
							 addressing mode the circular buffer is empty.  
							 '1' = enable interrupt, '0' = do not interrupt
   29	DST_INT:
        Destination Interrupt Enable	 0	         Interrupt when the current (active context) transfer has finished 
	                                                 (destination byte counter reaches zero) or when in circular-buffer 
							 addressing mode and the circular buffer is full. '1' = enable interrupt
							 , '0' = do not interrupt
   28	TERM: Linked-List Terminator	 0	         Do not fetch the next descriptor when the current (active context) 
                                                         transfer has finished (byte counter reaches zero). '1' = terminate, 
							 '0' = go read next descriptor. NOTE: (Valid only in linked-list mode).
   27	RD_SWAP_ENDIAN	                 0	         Read Swap Endianism:  This bit control whether the data on a DMA 
                                                         "read" (a transfer from global address space to local address space) 
							 is endian swapped. 
							 NOTE: (Valid only in "store-and-forward mode").
							 '1' - Swap Endianism, 
							 '0' - Don't Swap Endianism.
   26	WR_SWAP_ENDIAN	                 0	         Write Swap Endianism: This bit controls whether the data on a DMA 
                                                         "write" (a transfer from local address space to global address space) 
							 is endian swapped. 
							 NOTE: (Valid only in "store-and-forward mode").
							 '1' - Swap Endianism, 
							 '0' - Don't Swap Endianism.
   25	SRC_ENDIANISM	                 0	         Source Endianism: Indicates what the source endianism is and is used 
                                                         by hardware to generate the appropriate byte enables for non-32bit aligned accesses.
							 '1' - Big Endianism, 
							 '0' - Little Endianism.
   24	DST_ENDIANISM	                 0	         Destination Endianism: Indicates what the destination endianism is and 
                                                         is used by hardware to generate the appropriate byte enables for 
							 non-32bit aligned accesses.
							 '1' - Big Endianism, 
							 '0' - Little Endianism.
   23:20 STRFWD_SEL: Local Agent Select	0000	         These 4-bits select which Local Agent will act as the intermediate 
                                                         unit in a "store-and-forward" mode transfer.  The reason these bits 
							 are needed in "store-and-forward" mode is because the source and 
							 destination addresses both reside in the global address space 
							 (in other modes, one is used for the global address space and the 
							 other for the local address space).
							 NOTE: (Valid only in "store-and-forward mode").
							 0000 - Local Agent 0
							 0001 - Local Agent 1
							 0010  - Local Agent 2
							 0011 - Local Agent 3
							 0100 - Local Agent 4
							 0101 - Local Agent 5
							 0110  - Local Agent 6
							 0111 - Local Agent 7	1000 - Local Agent 8
							 1001 - Local Agent 9
							 1010  - Local Agent 10
							 1011 - Local Agent 11
							 1100 - Local Agent 12
							 1101 - Local Agent 13
							 1110  - Local Agent 14
							 1111 - Local Agent 15

    19:16	XDMA_GAP: XSI DMA GAP	0000	         Between bursts (meaning the larger of the 2 burst sizes) the context 
                                                         is "locked" for <XDMA_GAP value> XSI bus clocks.  I.E. - Every time 
							 a burst of data is transferred, the DMA will stop working on the 
							 context, swap it out, and then "lock" it for <XDMA_GAP value> XSI 
							 clocks (hardware ~= time-out counter).  During this idle period, 
							 the DMA context-arbiter will look for other active contexts to work on.
							 NOTE: (If this value is set to zero, the context is never "locked", 
							 but it WILL be swapped-out.  When the round-robin context arbiter 
							 reaches the context again, it will become active).
							 0000 - 0 clocks
							 0001 - 16 clocks
							 0010 - 64 clocks
							 0011 - 256 clocks
							 0100 - 1024 clocks	0101 - 2048 clocks
							 0110 - 4096 clocks
							 0111 - 8192 clocks
							 others - undefined
							 
   15:12	XBURST_SZ: XSI DMA Burst Size	0000	The DMA will transfer data to the Global Agent in bursts of this value 
                                                        (except for a possible partial-burst at the end of the transfer).  
							I.E. - On the Global Agent port, only one address will be provided for 
							each <XBURST_SZ value> of data.  In Gen2, this will translate into 
							the number of bytes per XSI Bus transfer (use 256-byte maximum for best 
							performance).
							NOTE: (The Global Agent MUST have burst support 
							if any value other than 4-bytes is used).
							0000 - 4 bytes
							0001 - 8 Bytes
							0010  - 16 bytes
							0011 - 32 bytes	0100 - 64 bytes
							0101 - 128 Bytes
							0110  - 256 bytes
							others - undefined

    11:8	BURST_SZ: DMA Burst Size	0000	The DMA will transfer data to the Local Agent in bursts of this value 
                                                        (except for a possible partial-burst at the end of the transfer).  
							I.E. - On the Local Agent port, only one address will be provided for 
							each <BURST_SZ value> of data.
							NOTE: (The Local Agent MUST have burst support if any value other 
							than 4-bytes is used. Local agents of the HDMI only support 4 byte bursts).
							0000 - 4 bytes
							0001 - 8 Bytes	others - undefined
							
       7	READ_EN:Read Enable	         0	The DMA will read data from the global address space and write it into 
                                                        the local address space (DMA direction is with respect to the Local 
							Agent).  When both READ_EN and WRITE_EN are set, the DMA operates in 
							"store-and-forward" mode. For HDMI always set to '1'.
     6:5	SRC_ADDR_MODE: Source Addressing Mode	00	Source Addressing Mode:
                                                                "00" - Linear- addressing mode.
								"01" - Circular- addressing mode.
								"10" - Fixed - addressing mode
								"11" - Fixed Continuous
     4	        SRC_LINK_LIST: Source Link List Enable	0	Source Link List Enable (always set to '1'): 
                                                                "0" - Linked-list mode disabled.
								"1" - Linked-list mode enabled.
     3	        WRITE_EN: Write Enable	                 0	The DMA will read data from the local address space and write 
                                                                it into the global address space (DMA direction is with respect 
								to the Local Agent).  When both READ_EN and WRITE_EN are set, 
								the DMA operates in "store-and-forward" mode. For HDMI always 
								set to '0'.
    2:1	        DST_ADDR_MODE: Destination Addressing Mode 00	Destination Addressing Mode (always set to '11'):
                                                                "00" - Linear- addressing mode.
								"01" - Circular- addressing mode.
								"10" - Fixed - addressing mode
								"11" - Fixed continuous
     0	DST_LINK_LIST: Destination Link List Enable	0	Destination Link List Enable (always set to '0'): 
                                                                "0" - Linked-list mode disabled.
								"1" - Linked-list mode enabled.

 */
static const struct EAS_RegBits g_csr_gen3_hdmi_tx_FLAGS_MODE[] = 
{
  { "ACTIVE",                31,   1, "", NULL },
  { "SRC_INT",                30,   1, "", NULL },
  { "DST_INT",                29,   1, "", NULL },
  { "TERM",                28,   1, "", NULL },
  { "RD_SWAP_ENDIAN",                27,   1, "", NULL },
  { "WR_SWAP_ENDIAN",                26,   1, "", NULL },
  { "SRC_ENDIANISM",                25,   1, "", NULL },
  { "DST_ENDIANISM",                24,   1, "", NULL },
  { "STRFWD_SEL",                20,   4, "", NULL },
  { "XDMA_GAP",                16,   4, "", NULL },
  { "XBURST_SZ",                12,   4, "", NULL },
  { "BURST_SZ",                8,   4, "", NULL },
  { "READ_EN",                7,   1, "", NULL },
  { "SRC_ADDR_MODE",                5,   2, "", NULL },
   { "SRC_LINK_LIST",               4,   1, "", NULL },
   { "WRITE_EN",                    3,   1, "", NULL },
   { "DST_ADDR_MODE",               1,   2, "", NULL },
   { "DST_LINK_LIST",               0,    1, "", NULL },
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* Copied from GEN3 HDMI TX EAS Rev 0.61 15Feb2007 by Ramya Ranganathan */
static const struct EAS_Register g_csr_gen3_hdmi_tx[] =
{

  {"CURR_DESCR",   GEN3_HDMI_TX_CURR_DESCR_OFFSET, NULL,"",NULL},
  {"NEXT_DESCR",   GEN3_HDMI_TX_NEXT_DESCR_OFFSET, NULL,"",NULL},
  {"SRCDMA_START", GEN3_HDMI_TX_SRCDMA_START_OFFSET, NULL,"",NULL},
  {"DSTDMA_START", GEN3_HDMI_TX_DSTDMA_START_OFFSET, NULL,"",NULL},
  {"SRCDMA_SIZE",  GEN3_HDMI_TX_SRCDMA_SIZE_OFFSET, NULL,"",NULL},
  {"FLAGS_MODE",   GEN3_HDMI_TX_FLAGS_MODE_OFFSET, g_csr_gen3_hdmi_tx_FLAGS_MODE,"",NULL},
  {"SRCDMA_START_ALIAS", GEN3_HDMI_TX_SRCDMA_START_ALS_OFFSET, NULL,"",NULL},
  {"SRCDMA_BOT",   GEN3_HDMI_TX_SRCDMA_BOT_OFFSET, NULL,"",NULL},
  {"SRCDMA_TOP",   GEN3_HDMI_TX_SRCDMA_TOP_OFFSET, NULL,"",NULL},
  {"DSTDMA_BOT",   GEN3_HDMI_TX_DSTDMA_BOT_OFFSET, NULL,"",NULL},
  {"DSTDMA_TOP",   GEN3_HDMI_TX_DSTDMA_TOP_OFFSET, NULL,"",NULL},
  {"DSTDMA_SIZE",  GEN3_HDMI_TX_DSTDMA_SIZE_OFFSET, NULL,"",NULL},
  {"SRCDMA_STOP",  GEN3_HDMI_TX_SRCDMA_STOP_OFFSET, NULL,"",NULL},
  {"DSTDMA_STOP",  GEN3_HDMI_TX_DSTDMA_STOP_OFFSET, NULL,"",NULL},

  {"HCR",          GEN3_HDMI_TX_HCR_OFFSET, g_csr_gen3_hdmi_tx_HCR,"HDMI Control Register",NULL},
  {"HICR",         GEN3_HDMI_TX_HICR_OFFSET, g_csr_gen3_hdmi_tx_HICR,"HDMI Interrupt Control Register",NULL},
  {"HSR",          GEN3_HDMI_TX_HSR_OFFSET, g_csr_gen3_hdmi_tx_HSR,"HDMI Status Register",NULL},
  {"HISR",         GEN3_HDMI_TX_HISR_OFFSET, g_csr_gen3_hdmi_tx_HISR,"HDMI Interrupt Status Register",NULL},
  {"HPCR",         GEN3_HDMI_TX_HPCR_OFFSET, NULL,"Phy Control register",NULL},
  {"ICRH",         GEN3_HDMI_TX_ICRH_OFFSET, g_csr_gen3_hdmi_tx_ICRH,"I2C Control Register HDMI",NULL},
  {"ISRH",         GEN3_HDMI_TX_ISRH_OFFSET, g_csr_gen3_hdmi_tx_ISRH,"I2C Status Register HDMI",NULL},
  {"IDBRH",        GEN3_HDMI_TX_IDBRH_OFFSET, g_csr_gen3_hdmi_tx_IDBRH,"I2C Data Buffer Register HDMI",NULL},
  {"IBMRH",        GEN3_HDMI_TX_IBMRH_OFFSET, g_csr_gen3_hdmi_tx_IBMRH,"I2C Bus Monitor Register HDMI",NULL},
  {"HI2CRDB0",     GEN3_HDMI_TX_HI2CRDB0_OFFSET, NULL,"HDMI I2C Read Data buffer0",NULL},
  {"HI2CRDB1",     GEN3_HDMI_TX_HI2CRDB1_OFFSET, NULL,"HDMI I2C Read Data buffer1",NULL},
  {"HI2CRDB2",     GEN3_HDMI_TX_HI2CRDB2_OFFSET, NULL,"HDMI I2C Read Data buffer2",NULL},
  {"HI2CRDB3",     GEN3_HDMI_TX_HI2CRDB3_OFFSET, NULL,"HDMI I2C Read Data buffer3",NULL},
  {"HI2CRDB4",     GEN3_HDMI_TX_HI2CRDB4_OFFSET, NULL,"HDMI I2C Read Data buffer4",NULL},
  {"HI2CRDB5",     GEN3_HDMI_TX_HI2CRDB5_OFFSET, NULL,"HDMI I2C Read Data buffer5",NULL},
  {"HI2CRDB6",     GEN3_HDMI_TX_HI2CRDB6_OFFSET, NULL,"HDMI I2C Read Data buffer6",NULL},
  {"HI2CRDB7",     GEN3_HDMI_TX_HI2CRDB7_OFFSET, NULL,"HDMI I2C Read Data buffer7",NULL},
  {"HI2CRDB8",     GEN3_HDMI_TX_HI2CRDB8_OFFSET, NULL,"HDMI I2C Read Data buffer8",NULL},
  {"HI2CRDB9",     GEN3_HDMI_TX_HI2CRDB9_OFFSET, NULL,"HDMI I2C Read Data buffer9",NULL},
  {"HI2CRDB10",    GEN3_HDMI_TX_HI2CRDB10_OFFSET, NULL,"HDMI I2C Read Data buffer10",NULL},
  {"HI2CRDB11",    GEN3_HDMI_TX_HI2CRDB11_OFFSET, NULL,"HDMI I2C Read Data buffer11",NULL},
  {"HI2CRDB12",    GEN3_HDMI_TX_HI2CRDB12_OFFSET, NULL,"HDMI I2C Read Data buffer12",NULL},
  {"HI2CRDB13",    GEN3_HDMI_TX_HI2CRDB13_OFFSET, NULL,"HDMI I2C Read Data buffer13",NULL},
  {"HI2CRDB14",    GEN3_HDMI_TX_HI2CRDB14_OFFSET, NULL,"HDMI I2C Read Data buffer14",NULL},
  {"HI2CRDB15",    GEN3_HDMI_TX_HI2CRDB15_OFFSET, NULL,"HDMI I2C Read Data buffer15",NULL},
  {"HI2CHCR",      GEN3_HDMI_TX_HI2CHCR_OFFSET, g_csr_gen3_hdmi_tx_PHY_I2CHCR,"HDMI I2C Hardware Control Register",NULL},
  {"HI2CTDR0",     GEN3_HDMI_TX_HI2CTDR0_OFFSET, NULL,"HDMI I2C Transmit data Register0",NULL},
  {"HI2CTDR1",     GEN3_HDMI_TX_HI2CTDR1_OFFSET, NULL,"HDMI I2C Transmit data Register1",NULL},

  /* 1.13.5       Input Video Processing Registers (2000h-2FFFh) */
  {"DCR",          GEN3_HDMI_TX_DCR_OFFSET, g_csr_gen3_hdmi_tx_DCR,"HDMI Video Dither Control Register",NULL},
  {"DPRNGSR",      GEN3_HDMI_TX_DPRNGSR_OFFSET, g_csr_gen3_hdmi_tx_DPRNGSR,"HDMI Dither PRNG Shift Register",NULL},
  {"CSCCR",        GEN3_HDMI_TX_CSCCR_OFFSET, g_csr_gen3_hdmi_tx_CSCCR,"HDMI Video CSC Control Register",NULL},
  {"UPCSCC",       GEN3_HDMI_TX_UPCSCC_OFFSET, g_csr_gen3_hdmi_tx_UPCSCC,"Universal plane CSC Clamp Register",NULL},
  {"UPCSCYGOFF",   GEN3_HDMI_TX_UPCSCYGOFF_OFFSET, g_csr_gen3_hdmi_tx_UPCSCYGOFF,"Universal plane CSC Y/G Offset Register",NULL},
  {"UPCSCCBOFF",   GEN3_HDMI_TX_UPCSCCBOFF_OFFSET, g_csr_gen3_hdmi_tx_UPCSCCBOFF,"Universal plane CSC Cb/B Offset Register",NULL},
  {"UPCSCCROFF",   GEN3_HDMI_TX_UPCSCCROFF_OFFSET,  g_csr_gen3_hdmi_tx_UPCSCCROFF,"Universal plane CSC Cr/R Offset Register",NULL},
  {"UPCSC_C01",    GEN3_HDMI_TX_UPCSC_C01_OFFSET, g_csr_gen3_hdmi_tx_UPCSCC01,"Universal Plane CSC Coefficients 0,1 Register",NULL},
  {"UPCSC_C23",    GEN3_HDMI_TX_UPCSC_C23_OFFSET, g_csr_gen3_hdmi_tx_UPCSCC23,"Universal Plane CSC Coefficients 2,3 Register",NULL},
  {"UPCSC_C45",    GEN3_HDMI_TX_UPCSC_C45_OFFSET, g_csr_gen3_hdmi_tx_UPCSCC45,"Universal Plane CSC Coefficients 4,5 Register",NULL},
  {"UPCSC_C67",    GEN3_HDMI_TX_UPCSC_C67_OFFSET, g_csr_gen3_hdmi_tx_UPCSCC67,"Universal Plane CSC Coefficients 6,7 Register",NULL},
  {"UPCSC_C8",     GEN3_HDMI_TX_UPCSC_C8_OFFSET, g_csr_gen3_hdmi_tx_UPCSCC8,"Universal Plane CSC Coefficients 8 Register",NULL},

  /* 1.13.6	HDMI Video Format Registers (3000h-3FFFh) */  
  {"VOFR",         GEN3_HDMI_TX_VOFR_OFFSET, g_csr_gen3_hdmi_tx_VOFR,"Video Output Format Register",NULL},
  {"HBLANK_A",     GEN3_HDMI_TX_HBLANK_A_OFFSET, g_csr_gen3_hdmi_tx_HBLANK_A,"Display Pipe A Horizontal Blank Register",NULL},
  {"VTOTAL_A",     GEN3_HDMI_TX_VTOTAL_A_OFFSET, g_csr_gen3_hdmi_tx_VTOTAL_A,"Display Pipe A Vertical Total Register",NULL},

  /* 1.13.7       Audio Control Registers (4000h-4FFFh) */
  {"AFCR",	  GEN3_HDMI_TX_AFCR_OFFSET, g_csr_gen3_hdmi_tx_AFCR,"Audio Format Control Register",NULL},
  {"HWCTS",	  GEN3_HDMI_TX_HWCTS_OFFSET, NULL,"CTS Value calculated by HW",NULL},
  {"ACRNR",	  GEN3_HDMI_TX_ACRNR_OFFSET, NULL,"Audio Clock Recovery N Reg",NULL},
  {"ACRCTSR",	  GEN3_HDMI_TX_ACRCTSR_OFFSET,g_csr_gen3_hdmi_tx_ACRCTSR,"Audio Clock Recovery CTS Reg",NULL},
  {"ASCDIVR",	  GEN3_HDMI_TX_ASCDIVR_OFFSET, NULL,"Audio Clock divider register",NULL},
  {"AFTHR",       GEN3_HDMI_TX_AFTHR_OFFSET, NULL,"Audio Fifo Threshold Register",NULL},
  {"AFLR",        GEN3_HDMI_TX_AFLR_OFFSET, NULL,"Audio Fifo Level Register",NULL},
  {"USDR0",       GEN3_HDMI_TX_USDR0_OFFSET, NULL,"Audio User Data Register0 ",NULL},
  {"USDR1",       GEN3_HDMI_TX_USDR1_OFFSET, NULL,"Audio User Data Register1 ",NULL},
  {"USDR2",       GEN3_HDMI_TX_USDR2_OFFSET, NULL,"Audio User Data Register2 ",NULL},
  {"USDR3",       GEN3_HDMI_TX_USDR3_OFFSET, NULL,"Audio User Data Register3 ",NULL},
  {"USDR4",       GEN3_HDMI_TX_USDR4_OFFSET, NULL,"Audio User Data Register4 ",NULL},
  {"USDR5",       GEN3_HDMI_TX_USDR5_OFFSET, NULL,"Audio User Data Register5 ",NULL},
  {"USDR6",       GEN3_HDMI_TX_USDR6_OFFSET, NULL,"Audio User Data Register6 ",NULL},
  {"USDR7",       GEN3_HDMI_TX_USDR7_OFFSET, NULL,"Audio User Data Register7 ",NULL},
  {"USDR8",       GEN3_HDMI_TX_USDR8_OFFSET, NULL,"Audio User Data Register8 ",NULL},
  {"USDR9",       GEN3_HDMI_TX_USDR9_OFFSET, NULL,"Audio User Data Register9 ",NULL},
  {"USDR10",      GEN3_HDMI_TX_USDR10_OFFSET, NULL,"Audio User Data Register10 ",NULL},
  {"USDR11",      GEN3_HDMI_TX_USDR11_OFFSET, NULL,"Audio User Data Register11 ",NULL},
  {"USDCR",       GEN3_HDMI_TX_USDCR_OFFSET, NULL,"Audio User Data Control Register",NULL},
  {"CHSR0",       GEN3_HDMI_TX_CHSR0_OFFSET, NULL,"Audio Channel Status Register0",NULL},
  {"CHSR1",       GEN3_HDMI_TX_CHSR1_OFFSET, NULL,"Audio Channel Status Register1",NULL},
  {"CHSCR",       GEN3_HDMI_TX_CHSCR_OFFSET, NULL,"Audio Channel Status Control Register",NULL},

  /*               Info Frame Registers  */
  {"IF0HB2_HB0",   GEN3_HDMI_TX_IF0HB2_HB0_OFFSET, NULL,"	Infoframe0 Header HB2-HB0",NULL},
  {"IF0PB3_PB0",   GEN3_HDMI_TX_IF0PB3_PB0_OFFSET, NULL,"	Infoframe0 PB3-PB0",NULL},
  {"IF0PB7_PB4",   GEN3_HDMI_TX_IF0PB7_PB4_OFFSET, NULL,"	Infoframe0 PB7-PB4",NULL},
  {"IF0PB11_PB8",  GEN3_HDMI_TX_IF0PB11_PB8_OFFSET, NULL,"	Infoframe0 PB11-PB8",NULL},
  {"IF0PB15_PB12", GEN3_HDMI_TX_IF0PB15_PB12_OFFSET, NULL,"	Infoframe0 PB15-PB12",NULL},
  {"IF0PB19_PB16", GEN3_HDMI_TX_IF0PB19_PB16_OFFSET, NULL,"	Infoframe0 PB19-PB16",NULL},
  {"IF0PB23_PB20", GEN3_HDMI_TX_IF0PB23_PB20_OFFSET, NULL,"	Infoframe0 PB23-PB20",NULL},
  {"IF0PB27_PB24", GEN3_HDMI_TX_IF0PB27_PB24_OFFSET, NULL,"	Infoframe0 PB27-PB24",NULL},
  {"IF1HB2_HB0",   GEN3_HDMI_TX_IF1HB2_HB0_OFFSET, NULL,"	Infoframe1 Header HB2-HB0",NULL},
  {"IF1PB3_PB0",   GEN3_HDMI_TX_IF1PB3_PB0_OFFSET, NULL,"	Infoframe1 PB3-PB0",NULL},
  {"IF1PB7_PB4",   GEN3_HDMI_TX_IF1PB7_PB4_OFFSET, NULL,"	Infoframe1 PB7-PB4",NULL},
  {"IF1PB11_PB8",  GEN3_HDMI_TX_IF1PB11_PB8_OFFSET, NULL,"	Infoframe1 PB11-PB8",NULL},
  {"IF1PB15_PB12", GEN3_HDMI_TX_IF1PB15_PB12_OFFSET, NULL,"	Infoframe1 PB15-PB12",NULL},
  {"IF1PB19_PB16", GEN3_HDMI_TX_IF1PB19_PB16_OFFSET, NULL,"	Infoframe1 PB19-PB16",NULL},
  {"IF1PB23_PB20", GEN3_HDMI_TX_IF1PB23_PB20_OFFSET, NULL,"	Infoframe1 PB23-PB20",NULL},
  {"IF1PB27_PB24", GEN3_HDMI_TX_IF1PB27_PB24_OFFSET, NULL,"	Infoframe1 PB27-PB24",NULL},
  {"IF2HB2_HB0",   GEN3_HDMI_TX_IF2HB2_HB0_OFFSET, NULL,"	Infoframe2 Header HB2-HB0",NULL},
  {"IF2PB3_PB0",   GEN3_HDMI_TX_IF2PB3_PB0_OFFSET, NULL,"	Infoframe2 PB3-PB0",NULL},
  {"IF2PB7_PB4",   GEN3_HDMI_TX_IF2PB7_PB4_OFFSET, NULL,"	Infoframe2 PB7-PB4",NULL},
  {"IF2PB11_PB8",  GEN3_HDMI_TX_IF2PB11_PB8_OFFSET, NULL,"	Infoframe2 PB11-PB8",NULL},
  {"IF2PB15_PB12", GEN3_HDMI_TX_IF2PB15_PB12_OFFSET, NULL,"	Infoframe2 PB15-PB12",NULL},
  {"IF2PB19_PB16", GEN3_HDMI_TX_IF2PB19_PB16_OFFSET, NULL,"	Infoframe2 PB19-PB16",NULL},
  {"IF2PB23_PB20", GEN3_HDMI_TX_IF2PB23_PB20_OFFSET, NULL,"	Infoframe2 PB23-PB20",NULL},
  {"IF2PB27_PB24", GEN3_HDMI_TX_IF2PB27_PB24_OFFSET, NULL,"	Infoframe2 PB27-PB24",NULL},
  {"IF3HB2_HB0",   GEN3_HDMI_TX_IF3HB2_HB0_OFFSET, NULL,"	Infoframe3 Header HB2-HB0",NULL},
  {"IF3PB3_PB0",   GEN3_HDMI_TX_IF3PB3_PB0_OFFSET, NULL,"	Infoframe3 PB3-PB0",NULL},
  {"IF3PB7_PB4",   GEN3_HDMI_TX_IF3PB7_PB4_OFFSET, NULL,"	Infoframe3 PB7-PB4",NULL},
  {"IF3PB11_PB8",  GEN3_HDMI_TX_IF3PB11_PB8_OFFSET, NULL,"	Infoframe3 PB11-PB8",NULL},
  {"IF3PB15_PB12", GEN3_HDMI_TX_IF3PB15_PB12_OFFSET, NULL,"	Infoframe3 PB15-PB12",NULL},
  {"IF3PB19_PB16", GEN3_HDMI_TX_IF3PB19_PB16_OFFSET, NULL,"	Infoframe3 PB19-PB16",NULL},
  {"IF3PB23_PB20", GEN3_HDMI_TX_IF3PB23_PB20_OFFSET, NULL,"	Infoframe3 PB23-PB20",NULL},
  {"IF3PB27_PB24", GEN3_HDMI_TX_IF3PB27_PB24_OFFSET, NULL,"	Infoframe3 PB27-PB24",NULL},
  {"IF0DESCR",     GEN3_HDMI_TX_IF0DESCR_OFFSET, g_csr_gen3_hdmi_tx_IFDESC,"	Infoframe0 descriptor register",NULL},
  {"IF1DESCR",     GEN3_HDMI_TX_IF1DESCR_OFFSET, g_csr_gen3_hdmi_tx_IFDESC,"	Infoframe1 descriptor register",NULL},
  {"IF2DESCR",     GEN3_HDMI_TX_IF2DESCR_OFFSET, g_csr_gen3_hdmi_tx_IFDESC,"	Infoframe2 descriptor register",NULL},
  {"IF3DESCR",     GEN3_HDMI_TX_IF3DESCR_OFFSET, g_csr_gen3_hdmi_tx_IFDESC,"	Infoframe3 descriptor register",NULL},

  /* 1.13.8	HDCP Registers (5000h-5FFFh) */
  {"HHCR",         GEN3_HDMI_TX_HHCR_OFFSET, g_csr_gen3_hdmi_tx_HHCR,"HDMI HDCP Control Register",NULL},
  {"HHSR",         GEN3_HDMI_TX_HHSR_OFFSET, NULL,"HDMI HDCP Status Register",NULL},
  {"HRN0",         GEN3_HDMI_TX_HRN0_OFFSET, NULL,"HDMI HDCP RNG0 Register",NULL},
  {"HRN1",         GEN3_HDMI_TX_HRN1_OFFSET, NULL,"HDMI HDCP RNG1 Register",NULL},
  {"HAN0",         GEN3_HDMI_TX_HAN0_OFFSET, NULL,"HDMI HDCP AN0 Register",NULL},
  {"HAN1",         GEN3_HDMI_TX_HAN1_OFFSET, NULL,"HDMI HDCP AN1 Register",NULL},
  {"HAK0",         GEN3_HDMI_TX_HAK0_OFFSET, NULL,"HDMI HDCP AKSV0 Register",NULL},
  {"HAK1",         GEN3_HDMI_TX_HAK1_OFFSET, NULL,"HDMI HDCP AKSV1 Register",NULL},
  {"HBK0",         GEN3_HDMI_TX_HBK0_OFFSET, NULL,"HDMI HDCP BKSV0 Register",NULL},
  {"HBK1",         GEN3_HDMI_TX_HBK1_OFFSET, NULL,"HDMI HDCP BKSV1 Register",NULL},
  {"HPR0",         GEN3_HDMI_TX_HPR0_OFFSET, NULL,"HDMI HDCP PRE R0 Register",NULL},
  {"HR0",          GEN3_HDMI_TX_HR0_OFFSET, NULL,"HDMI HDCP R0Register",NULL},
  {"HPPJ",         GEN3_HDMI_TX_HPPJ_OFFSET, NULL,"HDMI HDCP PRE PJ Register",NULL},
  {"HPJ",          GEN3_HDMI_TX_HPJ_OFFSET, NULL,"HDMI HDCP PJ Register",NULL},
  {"HKBE0",        GEN3_HDMI_TX_HKBE0_OFFSET, NULL,"HDMI HDCP Key Bank Extension 0",NULL},
  {"HKBE1",        GEN3_HDMI_TX_HKBE1_OFFSET, NULL,"HDMI HDCP Key Bank Extension 1",NULL},
  {"HK0L",         GEN3_HDMI_TX_HK0L_OFFSET, NULL,"HDMI HDCP Key0 LSB Register",NULL},
  {"HK0M",         GEN3_HDMI_TX_HK0M_OFFSET, NULL,"HDMI HDCP Key0 MSB Register",NULL},
  {"HK1L",         GEN3_HDMI_TX_HK1L_OFFSET, NULL,"HDMI HDCP Key1 LSB Register",NULL},
  {"HK1M",         GEN3_HDMI_TX_HK1M_OFFSET, NULL,"HDMI HDCP Key1 MSB Register",NULL},
  {"HK2L",         GEN3_HDMI_TX_HK2L_OFFSET, NULL,"HDMI HDCP Key2 LSB Register",NULL},
  {"HK2M",         GEN3_HDMI_TX_HK2M_OFFSET, NULL,"HDMI HDCP Key2 MSB Register",NULL},
  {"HK3L",         GEN3_HDMI_TX_HK3L_OFFSET, NULL,"HDMI HDCP Key3 LSB Register",NULL},
  {"HK3M",         GEN3_HDMI_TX_HK3M_OFFSET, NULL,"HDMI HDCP Key3 MSB Register",NULL},
  {"HK4L",         GEN3_HDMI_TX_HK4L_OFFSET, NULL,"HDMI HDCP Key4 LSB Register",NULL},
  {"HK4M",         GEN3_HDMI_TX_HK4M_OFFSET, NULL,"HDMI HDCP Key4 MSB Register",NULL},
  {"HK5L",         GEN3_HDMI_TX_HK5L_OFFSET, NULL,"HDMI HDCP Key5 LSB Register",NULL},
  {"HK5M",         GEN3_HDMI_TX_HK5M_OFFSET, NULL,"HDMI HDCP Key5 MSB Register",NULL},
  {"HK6L",         GEN3_HDMI_TX_HK6L_OFFSET, NULL,"HDMI HDCP Key6 LSB Register",NULL},
  {"HK6M",         GEN3_HDMI_TX_HK6M_OFFSET, NULL,"HDMI HDCP Key6 MSB Register",NULL},
  {"HK7L",         GEN3_HDMI_TX_HK7L_OFFSET, NULL,"HDMI HDCP Key7 LSB Register",NULL},
  {"HK7M",         GEN3_HDMI_TX_HK7M_OFFSET, NULL,"HDMI HDCP Key7 MSB Register",NULL},
  {"HK8L",         GEN3_HDMI_TX_HK8L_OFFSET, NULL,"HDMI HDCP Key8 LSB Register",NULL},
  {"HK8M",         GEN3_HDMI_TX_HK8M_OFFSET, NULL,"HDMI HDCP Key8 MSB Register",NULL},
  {"HK9L",         GEN3_HDMI_TX_HK9L_OFFSET, NULL,"HDMI HDCP Key9 LSB Register",NULL},
  {"HK9M",         GEN3_HDMI_TX_HK9M_OFFSET, NULL,"HDMI HDCP Key9 MSB Register",NULL},
  {"HK10L",         GEN3_HDMI_TX_HK10L_OFFSET, NULL,"HDMI HDCP Key10 LSB Register",NULL},
  {"HK10M",         GEN3_HDMI_TX_HK10M_OFFSET, NULL,"HDMI HDCP Key10 MSB Register",NULL},
  {"HK11L",         GEN3_HDMI_TX_HK11L_OFFSET, NULL,"HDMI HDCP Key11 LSB Register",NULL},
  {"HK11M",         GEN3_HDMI_TX_HK11M_OFFSET, NULL,"HDMI HDCP Key11 MSB Register",NULL},
  {"HK12L",         GEN3_HDMI_TX_HK12L_OFFSET, NULL,"HDMI HDCP Key12 LSB Register",NULL},
  {"HK12M",         GEN3_HDMI_TX_HK12M_OFFSET, NULL,"HDMI HDCP Key12 MSB Register",NULL},
  {"HK13L",         GEN3_HDMI_TX_HK13L_OFFSET, NULL,"HDMI HDCP Key13 LSB Register",NULL},
  {"HK13M",         GEN3_HDMI_TX_HK13M_OFFSET, NULL,"HDMI HDCP Key13 MSB Register",NULL},
  {"HK14L",         GEN3_HDMI_TX_HK14L_OFFSET, NULL,"HDMI HDCP Key14 LSB Register",NULL},
  {"HK14M",         GEN3_HDMI_TX_HK14M_OFFSET, NULL,"HDMI HDCP Key14 MSB Register",NULL},
  {"HK15L",         GEN3_HDMI_TX_HK15L_OFFSET, NULL,"HDMI HDCP Key15 LSB Register",NULL},
  {"HK15M",         GEN3_HDMI_TX_HK15M_OFFSET, NULL,"HDMI HDCP Key15 MSB Register",NULL},
  {"HK16L",         GEN3_HDMI_TX_HK16L_OFFSET, NULL,"HDMI HDCP Key16 LSB Register",NULL},
  {"HK16M",         GEN3_HDMI_TX_HK16M_OFFSET, NULL,"HDMI HDCP Key16 MSB Register",NULL},
  {"HK17L",         GEN3_HDMI_TX_HK17L_OFFSET, NULL,"HDMI HDCP Key17 LSB Register",NULL},
  {"HK17M",         GEN3_HDMI_TX_HK17M_OFFSET, NULL,"HDMI HDCP Key17 MSB Register",NULL},
  {"HK18L",         GEN3_HDMI_TX_HK18L_OFFSET, NULL,"HDMI HDCP Key18 LSB Register",NULL},
  {"HK18M",         GEN3_HDMI_TX_HK18M_OFFSET, NULL,"HDMI HDCP Key18 MSB Register",NULL},
  {"HK19L",         GEN3_HDMI_TX_HK19L_OFFSET, NULL,"HDMI HDCP Key19 LSB Register",NULL},
  {"HK19M",         GEN3_HDMI_TX_HK19M_OFFSET, NULL,"HDMI HDCP Key19 MSB Register",NULL},
  {"HK20L",         GEN3_HDMI_TX_HK20L_OFFSET, NULL,"HDMI HDCP Key20 LSB Register",NULL},
  {"HK20M",         GEN3_HDMI_TX_HK20M_OFFSET, NULL,"HDMI HDCP Key20 MSB Register",NULL},
  {"HK21L",         GEN3_HDMI_TX_HK21L_OFFSET, NULL,"HDMI HDCP Key21 LSB Register",NULL},
  {"HK21M",         GEN3_HDMI_TX_HK21M_OFFSET, NULL,"HDMI HDCP Key21 MSB Register",NULL},
  {"HK22L",         GEN3_HDMI_TX_HK22L_OFFSET, NULL,"HDMI HDCP Key22 LSB Register",NULL},
  {"HK22M",         GEN3_HDMI_TX_HK22M_OFFSET, NULL,"HDMI HDCP Key22 MSB Register",NULL},
  {"HK23L",         GEN3_HDMI_TX_HK23L_OFFSET, NULL,"HDMI HDCP Key23 LSB Register",NULL},
  {"HK23M",         GEN3_HDMI_TX_HK23M_OFFSET, NULL,"HDMI HDCP Key23 MSB Register",NULL},
  {"HK24L",         GEN3_HDMI_TX_HK24L_OFFSET, NULL,"HDMI HDCP Key24 LSB Register",NULL},
  {"HK24M",         GEN3_HDMI_TX_HK24M_OFFSET, NULL,"HDMI HDCP Key24 MSB Register",NULL},
  {"HK25L",         GEN3_HDMI_TX_HK25L_OFFSET, NULL,"HDMI HDCP Key25 LSB Register",NULL},
  {"HK25M",         GEN3_HDMI_TX_HK25M_OFFSET, NULL,"HDMI HDCP Key25 MSB Register",NULL},
  {"HK26L",         GEN3_HDMI_TX_HK26L_OFFSET, NULL,"HDMI HDCP Key26 LSB Register",NULL},
  {"HK26M",         GEN3_HDMI_TX_HK26M_OFFSET, NULL,"HDMI HDCP Key26 MSB Register",NULL},
  {"HK27L",         GEN3_HDMI_TX_HK27L_OFFSET, NULL,"HDMI HDCP Key27 LSB Register",NULL},
  {"HK27M",         GEN3_HDMI_TX_HK27M_OFFSET, NULL,"HDMI HDCP Key27 MSB Register",NULL},
  {"HK28L",         GEN3_HDMI_TX_HK28L_OFFSET, NULL,"HDMI HDCP Key28 LSB Register",NULL},
  {"HK28M",         GEN3_HDMI_TX_HK28M_OFFSET, NULL,"HDMI HDCP Key28 MSB Register",NULL},
  {"HK29L",         GEN3_HDMI_TX_HK29L_OFFSET, NULL,"HDMI HDCP Key29 LSB Register",NULL},
  {"HK29M",         GEN3_HDMI_TX_HK29M_OFFSET, NULL,"HDMI HDCP Key29 MSB Register",NULL},
  {"HK30L",         GEN3_HDMI_TX_HK30L_OFFSET, NULL,"HDMI HDCP Key30 LSB Register",NULL},
  {"HK30M",         GEN3_HDMI_TX_HK30M_OFFSET, NULL,"HDMI HDCP Key30 MSB Register",NULL},
  {"HK31L",         GEN3_HDMI_TX_HK31L_OFFSET, NULL,"HDMI HDCP Key31 LSB Register",NULL},
  {"HK31M",         GEN3_HDMI_TX_HK31M_OFFSET, NULL,"HDMI HDCP Key31 MSB Register",NULL},
  {"HK32L",         GEN3_HDMI_TX_HK32L_OFFSET, NULL,"HDMI HDCP Key32 LSB Register",NULL},
  {"HK32M",         GEN3_HDMI_TX_HK32M_OFFSET, NULL,"HDMI HDCP Key32 MSB Register",NULL},
  {"HK33L",         GEN3_HDMI_TX_HK33L_OFFSET, NULL,"HDMI HDCP Key33 LSB Register",NULL},
  {"HK33M",         GEN3_HDMI_TX_HK33M_OFFSET, NULL,"HDMI HDCP Key33 MSB Register",NULL},
  {"HK34L",         GEN3_HDMI_TX_HK34L_OFFSET, NULL,"HDMI HDCP Key34 LSB Register",NULL},
  {"HK34M",         GEN3_HDMI_TX_HK34M_OFFSET, NULL,"HDMI HDCP Key34 MSB Register",NULL},
  {"HK35L",         GEN3_HDMI_TX_HK35L_OFFSET, NULL,"HDMI HDCP Key35 LSB Register",NULL},
  {"HK35M",         GEN3_HDMI_TX_HK35M_OFFSET, NULL,"HDMI HDCP Key35 MSB Register",NULL},
  {"HK36L",         GEN3_HDMI_TX_HK36L_OFFSET, NULL,"HDMI HDCP Key36 LSB Register",NULL},
  {"HK36M",         GEN3_HDMI_TX_HK36M_OFFSET, NULL,"HDMI HDCP Key36 MSB Register",NULL},
  {"HK37L",         GEN3_HDMI_TX_HK37L_OFFSET, NULL,"HDMI HDCP Key37 LSB Register",NULL},
  {"HK37M",         GEN3_HDMI_TX_HK37M_OFFSET, NULL,"HDMI HDCP Key37 MSB Register",NULL},
  {"HK38L",         GEN3_HDMI_TX_HK38L_OFFSET, NULL,"HDMI HDCP Key38 LSB Register",NULL},
  {"HK38M",         GEN3_HDMI_TX_HK38M_OFFSET, NULL,"HDMI HDCP Key38 MSB Register",NULL},
  {"HK39L",         GEN3_HDMI_TX_HK39L_OFFSET, NULL,"HDMI HDCP Key39 LSB Register",NULL},
  {"HK39M",         GEN3_HDMI_TX_HK39M_OFFSET, NULL,"HDMI HDCP Key39 MSB Register",NULL},
  { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct SVEN_Module_EventSpecific g_gen3_hdmi_specific_events[] =
{
    { "HDCP_ACTIVE",        1,      "HDCP Cipher has become active", NULL },
    { "HDCP_INACTIVE",      2,      "HDCP Cipher has deactivated", NULL },
    { "HSYNC_POL_ERR",      3,      "", NULL },
    { "VSYNC_POL_ERR",      4,      "", NULL },

    { NULL, 0, "", NULL }   /* NULL Terminated */
};

static const struct ModuleReverseDefs g_gen3_HDMI_TX_sven_module =
{
    "GEN3_HDMI_TX",
    SVEN_module_GEN3_HDMI_TX,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen3_hdmi_tx,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "HDMI: HDMI Transmitter (GEN3)",
    g_gen3_hdmi_specific_events,
    NULL /* extension list */
};
