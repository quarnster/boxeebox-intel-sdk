/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_unit.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

static const struct EAS_RegBits g_csr_tve_TVCTRL [] = {
  { "ENC_ENABLE",       31,   1, "", NULL},  /* */
  { "ENC_PIPESEL",      30,   1, "0:PipeA(HDMI); 1:PipeB(Blender)", NULL},  /* */
  { "reserved_29_27",   27,   3, "", NULL},  /*  */
  { "reserved_26_24",   24,   3, "", NULL},  /*  */
  { "RGB",              23,   1, "", NULL},  /* */
  { "3CH_SYNC",         22,   1, "", NULL},  /* */
  { "TRILEVEL_SYNC",    21,   1, "", NULL},  /* */
  { "SLOW_SYNC",        20,   1, "", NULL},  /* */
  { "OVERSAMPLE",       18,   2, "0:4x(480/576p);1:2x(720p/1080i);2:None;3:8x", NULL},  /* */
  { "reserved_17",      17,   1, "", NULL},  /* */
  { "reserved_16",      16,   1, "", NULL},  /* */
  { "FIELD_SWAP",       15,   1, "", NULL},  /* */
  { "YC_SKEW",          12,   3, "", NULL},  /*  */
  { "Intel_Reserved",   11,   1, "scratch (preserve this bit)", NULL},  /* */
  { "TP_SIZE",           9,   2, "0:640x480;1:720;2:1080", NULL},  /* */
  { "TP_INTERLACED",     8,   1, "Enable Test Pattern Interlaced", NULL},  /*  */
  { "reserved_7_4",      4,   4, "", NULL},  /*  */
  { "ENC_TEST_MODE",     0,   4, "0:Norm;1:Combo;2:Vert75%Color;3:Horz75%Color;etc...", NULL},  /* */
  { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_tve_PIPEBCONF [] = {
  { "PipeB_Enable",     31,   1, "", NULL},  /* */
  { "PipeB_Destination",29,   2, "00:Enc1;01:Enc0;10:Res;11:Both", NULL},  /*  */
  { "Frmstart_Delay",   27,   2, "", NULL},  /* */
  { "reserved_26_21",   21,   6, "", NULL},  /* */
  { "Interlaced_Mode",  20,   1, "0:Progressive; 1:Interlaced", NULL},  /*  */
  { "Force_Planes_Off", 19,   1, "0:Norm; 1:Disabled", NULL},  /*  */
  { "reserved_18_0",     0,  18, "", NULL},  /* */
  { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_tve_TVCCCTRL [] = {
  { "CC_ENA",           31,   1, "", NULL},  /* */
  { "reserved_30_28",   28,   3, "", NULL},  /*  */
  { "CC_FID",           27,   1, "0 reserved", NULL},  /* */
  { "reserved_26",      26,   1, "", NULL},  /* */
  { "CC_HOFF",          16,  10, "(usually 135)", NULL},  /*  */
  { "reserved_15_6",     6,  10, "", NULL},  /*  */
  { "CC_LINE",           0,   6, "(usually 21)", NULL},  /* */
  { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_tve_TVCCDATA [] = {
  { "CC_RDY",           31,   1, "(read only) 0:CC engine ready; 1: data fifo full", NULL},  /* */
  { "reserved_30_15",   15,  16, "", NULL},  /*  */
  { "CC_D2",             8,   7, "cc_data2", NULL},  /*  */
  { "reserved_7",        7,   1, "", NULL},  /*  */
  { "CC_D1",             0,   7, "cc_data1", NULL},  /* */
  { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_Register g_csr_gen3_tve[]= {
   /* TV-Encoder 0 */
  {"TVE0_TVCTRL",        0x58000, g_csr_tve_TVCTRL, "", NULL}, 
  {"TVE0_TVDACCTRL",     0x58004, NULL, "", NULL},
  {"TVE0_TVCSCY1",       0x58010, NULL, "", NULL},
  {"TVE0_TVCSCY2",       0x58014, NULL, "", NULL},
  {"TVE0_TVCSCU1",       0x58018, NULL, "", NULL},
  {"TVE0_TVCSCU2",       0x5801C, NULL, "", NULL},
  {"TVE0_TVCSCV1",       0x58020, NULL, "", NULL},
  {"TVE0_TVCSCV2",       0x58024, NULL, "", NULL},
  {"TVE0_TVVBIYLEVEL",   0x58008, NULL, "", NULL},
  {"TVE0_TVUVOFF",       0x5800C, NULL, "", NULL},
  {"TVE0_TVBCSH",        0x58028, NULL, "", NULL},
  {"TVE0_TVBLEVEL",      0x5802C, NULL, "", NULL},
  {"TVE0_TVHCTRL1",      0x58030, NULL, "", NULL},
  {"TVE0_TVHCTRL3",      0x58038, NULL, "", NULL},
  {"TVE0_TVVCTRL1",      0x5803C, NULL, "", NULL},
  {"TVE0_TVVCTRL2",      0x58040, NULL, "", NULL},
  {"TVE0_TVVCTRL3",      0x58044, NULL, "", NULL},
  {"TVE0_TVWINPOS",      0x58070, NULL, "", NULL},
  {"TVE0_TVWINSZ",       0x58074, NULL, "", NULL},
  {"TVE0_TVFILTCTRL1",   0x58080, NULL, "", NULL},
  
  {"TVE0_TVCCCTRL",      0x58090, g_csr_tve_TVCCCTRL, "TV Closed Caption Control", NULL},
  {"TVE0_TVCCDATA1",     0x58094, g_csr_tve_TVCCDATA, "TV CC Data Field 1", NULL},
  {"TVE0_TVCCDATA2",     0x58098, g_csr_tve_TVCCDATA, "TV CC Data Field 2", NULL},
  
  {"TVE0_TVHYCOEFF_0",   0x58100, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_1",   0x58104, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_2",   0x58108, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_3",   0x5810c, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_4",   0x58110, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_5",   0x58114, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_6",   0x58118, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_7",   0x5811c, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_8",   0x58120, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_9",   0x58124, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_10",  0x58128, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_11",  0x5812c, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_12",  0x58130, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_13",  0x58134, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_14",  0x58138, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_15",  0x5813c, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_16",  0x58140, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_17",  0x58144, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_18",  0x58148, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_19",  0x5814c, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_20",  0x58150, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_21",  0x58154, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_22",  0x58158, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_23",  0x5815c, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_24",  0x58160, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_25",  0x58164, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_26",  0x58168, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_27",  0x5816c, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_28",  0x58170, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_29",  0x58174, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_30",  0x58178, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_31",  0x5817c, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_32",  0x58180, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_33",  0x58184, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_34",  0x58188, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_35",  0x5818c, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_36",  0x58190, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_37",  0x58194, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_38",  0x58198, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_39",  0x5819c, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_40",  0x581a0, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_41",  0x581a4, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_42",  0x581a8, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_43",  0x581ac, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_44",  0x581b0, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_45",  0x581b4, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_46",  0x581b8, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_47",  0x581bc, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_48",  0x581c0, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_49",  0x581c4, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_50",  0x581c8, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_51",  0x581cc, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_52",  0x581d0, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_53",  0x581d4, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_54",  0x581d8, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_55",  0x581dc, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_56",  0x581e0, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_57",  0x581e4, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_58",  0x581e8, NULL, "", NULL},
  {"TVE0_TVHYCOEFF_59",  0x581ec, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_0",  0x58200, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_1",  0x58204, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_2",  0x58208, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_3",  0x5820c, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_4",  0x58210, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_5",  0x58214, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_6",  0x58218, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_7",  0x5821c, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_8",  0x58220, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_9",  0x58224, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_10", 0x58228, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_11", 0x5822c, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_12", 0x58230, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_13", 0x58234, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_14", 0x58238, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_15", 0x5823c, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_16", 0x58240, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_17", 0x58244, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_18", 0x58248, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_19", 0x5824c, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_20", 0x58250, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_21", 0x58254, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_22", 0x58258, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_23", 0x5825c, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_24", 0x58260, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_25", 0x58264, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_26", 0x58268, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_27", 0x5826c, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_28", 0x58270, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_29", 0x58274, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_30", 0x58278, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_31", 0x5827c, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_32", 0x58280, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_33", 0x58284, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_34", 0x58288, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_35", 0x5828c, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_36", 0x58290, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_37", 0x58294, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_38", 0x58298, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_39", 0x5829c, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_40", 0x582a0, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_41", 0x582a4, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_42", 0x582a8, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_43", 0x582ac, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_44", 0x582b0, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_45", 0x582b4, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_46", 0x582b8, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_47", 0x582bc, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_48", 0x582c0, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_49", 0x582c4, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_50", 0x582c8, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_51", 0x582cc, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_52", 0x582d0, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_53", 0x582d4, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_54", 0x582d8, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_55", 0x582dc, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_56", 0x582e0, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_57", 0x582e4, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_58", 0x582e8, NULL, "", NULL},
  {"TVE0_TVHUVCOEFF_59", 0x582ec, NULL, "", NULL},

   /* TV-Encoder 1 */
  {"TVE1_HTOTALB",       0x68500, NULL, "", NULL},
  {"TVE1_HBLANKB",       0x68504, NULL, "", NULL},
  {"TVE1_HSYNCB",        0x68508, NULL, "", NULL},
  {"TVE1_VTOTALB",       0x6850C, NULL, "", NULL},
  {"TVE1_VBLANKB",       0x68510, NULL, "", NULL},
  {"TVE1_VSYNCB",        0x68514, NULL, "", NULL},
  {"PIPEBCONF",          0x68550, g_csr_tve_PIPEBCONF, "Pipe B Config", NULL},
  {"PIPEBSTAT",          0x68554, NULL, "", NULL},
  {"TVE1_TVCTRL",        0x68000, NULL, "", NULL},
  {"TVE1_TVDACCTRL",     0x68004, NULL, "", NULL},
  {"TVE1_TVCSCY1",       0x68010, NULL, "", NULL},
  {"TVE1_TVCSCY2",       0x68014, NULL, "", NULL},
  {"TVE1_TVCSCU1",       0x68018, NULL, "", NULL},
  {"TVE1_TVCSCU2",       0x6801C, NULL, "", NULL},
  {"TVE1_TVCSCV1",       0x68020, NULL, "", NULL},
  {"TVE1_TVCSCV2",       0x68024, NULL, "", NULL},
  {"TVE1_TVVBIYLEVEL",   0x68008, NULL, "", NULL},
  {"TVE1_TVUVOFF",       0x6800C, NULL, "", NULL},
  {"TVE1_TVBCSH",        0x68028, NULL, "", NULL},
  {"TVE1_TVBLEVEL",      0x6802C, NULL, "", NULL},
  {"TVE1_TVHCTRL1",      0x68030, NULL, "", NULL},
  {"TVE1_TVHCTRL2",      0x68034, NULL, "", NULL},
  {"TVE1_TVHCTRL3",      0x68038, NULL, "", NULL},
  {"TVE1_TVVCTRL1",      0x6803C, NULL, "", NULL},
  {"TVE1_TVVCTRL2",      0x68040, NULL, "", NULL},
  {"TVE1_TVVCTRL3",      0x68044, NULL, "", NULL},
  {"TVE1_TVVCTRL4",      0x68048, NULL, "", NULL},
  {"TVE1_TVVCTRL5",      0x6804C, NULL, "", NULL},
  {"TVE1_TVVCTRL6",      0x68050, NULL, "", NULL},
  {"TVE1_TVVCTRL7",      0x68054, NULL, "", NULL},
  {"TVE1_TVSCCTRL1",     0x68060, NULL, "", NULL},
  {"TVE1_TVSCCTRL2",     0x68064, NULL, "", NULL},
  {"TVE1_TVSCCTRL3",     0x68068, NULL, "", NULL},
  {"TVE1_TVWINPOS",      0x68070, NULL, "", NULL},
  {"TVE1_TVWINSZ",       0x68074, NULL, "", NULL},
  {"TVE1_TVFILTCTRL1",   0x68080, NULL, "", NULL},
  {"TVE1_TVSINROM",      0x6808C, NULL, "", NULL},
  {"TVE1_TVHYCOEFF",     0x68100, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF",    0x68200, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_0",   0x68100, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_1",   0x68104, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_2",   0x68108, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_3",   0x6810c, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_4",   0x68110, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_5",   0x68114, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_6",   0x68118, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_7",   0x6811c, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_8",   0x68120, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_9",   0x68124, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_10",  0x68128, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_11",  0x6812c, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_12",  0x68130, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_13",  0x68134, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_14",  0x68138, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_15",  0x6813c, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_16",  0x68140, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_17",  0x68144, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_18",  0x68148, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_19",  0x6814c, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_20",  0x68150, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_21",  0x68154, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_22",  0x68158, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_23",  0x6815c, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_24",  0x68160, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_25",  0x68164, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_26",  0x68168, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_27",  0x6816c, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_28",  0x68170, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_29",  0x68174, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_30",  0x68178, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_31",  0x6817c, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_32",  0x68180, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_33",  0x68184, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_34",  0x68188, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_35",  0x6818c, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_36",  0x68190, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_37",  0x68194, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_38",  0x68198, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_39",  0x6819c, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_40",  0x681a0, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_41",  0x681a4, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_42",  0x681a8, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_43",  0x681ac, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_44",  0x681b0, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_45",  0x681b4, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_46",  0x681b8, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_47",  0x681bc, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_48",  0x681c0, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_49",  0x681c4, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_50",  0x681c8, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_51",  0x681cc, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_52",  0x681d0, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_53",  0x681d4, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_54",  0x681d8, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_55",  0x681dc, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_56",  0x681e0, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_57",  0x681e4, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_58",  0x681e8, NULL, "", NULL},
  {"TVE1_TVHYCOEFF_59",  0x681ec, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_0",  0x68200, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_1",  0x68204, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_2",  0x68208, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_3",  0x6820c, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_4",  0x68210, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_5",  0x68214, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_6",  0x68218, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_7",  0x6821c, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_8",  0x68220, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_9",  0x68224, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_10", 0x68228, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_11", 0x6822c, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_12", 0x68230, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_13", 0x68234, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_14", 0x68238, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_15", 0x6823c, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_16", 0x68240, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_17", 0x68244, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_18", 0x68248, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_19", 0x6824c, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_20", 0x68250, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_21", 0x68254, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_22", 0x68258, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_23", 0x6825c, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_24", 0x68260, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_25", 0x68264, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_26", 0x68268, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_27", 0x6826c, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_28", 0x68270, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_29", 0x68274, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_30", 0x68278, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_31", 0x6827c, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_32", 0x68280, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_33", 0x68284, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_34", 0x68288, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_35", 0x6828c, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_36", 0x68290, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_37", 0x68294, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_38", 0x68298, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_39", 0x6829c, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_40", 0x682a0, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_41", 0x682a4, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_42", 0x682a8, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_43", 0x682ac, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_44", 0x682b0, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_45", 0x682b4, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_46", 0x682b8, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_47", 0x682bc, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_48", 0x682c0, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_49", 0x682c4, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_50", 0x682c8, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_51", 0x682cc, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_52", 0x682d0, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_53", 0x682d4, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_54", 0x682d8, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_55", 0x682dc, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_56", 0x682e0, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_57", 0x682e4, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_58", 0x682e8, NULL, "", NULL},
  {"TVE1_TVHUVCOEFF_59", 0x682ec, NULL, "", NULL},
  { NULL,0,NULL,NULL,NULL }    /* NULL terminator */
};
#endif

static const struct SVEN_Module_EventSpecific g_GEN3_TVE_specific_events[] =
{
    { NULL, 0, "", NULL }
};

static const struct ModuleReverseDefs g_GEN3_TVE_sven_module =
{
    "GEN3_TVE",
    SVEN_module_GEN3_TVE,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen3_tve,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "TVE: TVE (GEN3)",
    g_GEN3_TVE_specific_events,
    NULL /* extension list */
};

