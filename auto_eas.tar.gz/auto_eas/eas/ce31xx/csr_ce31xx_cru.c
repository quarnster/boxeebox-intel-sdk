/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct EAS_RegBits g_csr_gen3_cru_TM_CMD[] =
{
    {"reserved",           11, 21, "reserved", NULL },
    {"VSYNC_SEL",          10, 1, "VSYNC timestamp src 0= PipeA 1= PipeB", NULL },
    {"M150_300",            9, 1, "Enable 180kHz counter", NULL },
    {"M300_BYPASS",         8, 1, "Enable 27MHz counter", NULL },
    {"COMP_ENABLE",         7, 1, "Enable Event comparator", NULL },
    {"MASTER_CLOCK",        6, 1, "use master clock (VCXO or DDS_0) to drive this timing channel", NULL },
    {"MODE",                4, 2, "Enable 33-bit presentation counter comparison", NULL },
    {"TS_SOURCE",           0, 4, "source for timestamping", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen3_cru_SET_STC_HI[] =
{
    {"reserved1",          25, 7, "reserved", NULL },
    {"PRESC_SET",          16, 9, "The new data to be written into prescaler register", NULL },
    {"reserved0",          10, 6,"reserved", NULL },
    {"MSB_STC",            0, 10, "Desired value of Bit 32 of the STC counter in Chan", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen3_cru_GET_STC_HI[] =
{
    {"NEW_TS",             31, 1, "set when timestamp registers are updated by hardware ", NULL },
    {"reserved",           25, 6, "reserved", NULL },
    {"PRESC",              16, 9, "The new data to be written into prescaler register", NULL },
    {"reserved0",          10, 6,"reserved", NULL },
    {"MSB_STC",            0, 10, "Desired value of Bit 32 of the STC counter in Chan", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen3_cru_GET_STC_LO[] =
{
   {"Media_TB_UPD",     31, 1, "Flag bit for writing SET_STC value in the wall clock.  MSB when read.", NULL },
   {"STC",                 2, 30, "Lower bits of the wall clock when read", NULL },
   {"Unlock_TS",        2, 1, "lock ts bit", NULL },
   {"Make_SW_TS",           0, 1, "SW trigger bit when written 1 to.  LSB of lower byte of wall clock when read", NULL },
   { NULL,0,0,"",NULL } /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen3_cru_VSYNC_HI[] =
{
   {"reserved0",           10,22, "Reserved", NULL},
   {"VSYNC_HI",             0, 10, "Vertical Sync Timestamp MSBits", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen3_cru_COMP_HI[] =
{
   {"reserved",           10, 22, "Reserved", NULL},
   {"MSB_STC",             0, 10, "Bits 41:32 of COMPARE register ", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_gen3_cru_INTERRUPT[] =
{
      {"reserved3",          25, 7, "Reserved", NULL},
    {"COMPARE_SYS",        24, 1, "The running value in System Time counter matched the desired compare setting", NULL },
      {"reserved2",          18, 6, "Reserved", NULL},
    {"CAPTURE_SYT2",       17, 1, "The valid timestamp was captured in System Time capture register 2 (for received packets on Ethernet)", NULL },
    {"CAPTURE_SYT1",       16, 1, "The valid timestamp was captured in System Time capture register 1 (for transmitted packets on Ethernet)", NULL},
      {"reserved1",          14, 2, "Reserved", NULL},
    {"COMPARE_6",          13, 1, "The running value in STC counter of Channel 6 matched the desired compare setting", NULL },
    {"COMPARE_5",          12, 1, "The running value in STC counter of Channel 5 matched the desired compare setting", NULL },
    {"COMPARE_4",          11, 1, "The running value in STC counter of Channel 4 matched the desired compare setting", NULL },
    {"COMPARE_3",          10, 1, "The running value in STC counter of Channel 3 matched the desired compare setting", NULL },
    {"COMPARE_2",           9, 1, "The running value in STC counter of Channel 2 matched the desired compare setting", NULL },
    {"COMPARE_1",           8, 1, "The running value in STC counter of Channel 1 matched the desired compare setting", NULL },
      {"reserved0",           0, 8, "Reserved", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};


static const struct EAS_RegBits g_csr_gen3_cru_VCXO_DAC_CTRL[] =
{
      {"PAT_CTNL",           30, 2, "Output pattern selection Delta sigma, All zero, All one, Fixed 1-1-0 output seq.", NULL},
    {"reserved1",          24, 6, "Reserved", NULL},
    {"FREQ_DIV",           16, 8, "Delta-Sigma update frequency is bus clock / (2*freq_div+1)", NULL },
      {"reserved0",          14, 2, "Reserved", NULL},
      {"VCXO_DAC",            0, 12, "12-bit ", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen3_cru_TS_DDS_MAP_CTRL[] =
{
   {"reserved1",        28, 4, "Reserved", NULL},
   {"TS_OUT1_MAP",         24, 4, "Select which DDS output drives TS ouput channel 1 timestamp cntr ctrl for packet Tx timing ctrl", NULL},
   {"reserved0",        16, 8, "Reserved", NULL},
   {"TS_IN4_MAP",       12, 4, "Select which DDS o/p drives TS input channel 4 timestamp cntr ctrl for packet timing ctrl", NULL},
   {"TS_IN3_MAP",        8, 4, "Select which DDS o/p drives TS input channel 3 timestamp cntr ctrl for packet timing ctrl", NULL},
   {"TS_IN2_MAP",        4, 4, "Select which DDS o/p drives TS input channel 2 timestamp cntr ctrl for packet timing ctrl", NULL},
   {"TS_IN1_MAP",        0, 4, "Select which DDS o/p drives TS input channel 1 timestamp cntr ctrl for packet timing ctrl", NULL},
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

// The following register is gen5 only
static const struct EAS_RegBits g_csr_gen3_cru_TS_DDS_MAP2_CTRL[] =
{
   {"reserved0",        16, 16, "Reserved", NULL},
   {"TS_IN8_MAP",       12, 4, "Select which DDS o/p drives TS input channel 8 timestamp cntr ctrl for packet timing ctrl", NULL},
   {"TS_IN7_MAP",        8, 4, "Select which DDS o/p drives TS input channel 7 timestamp cntr ctrl for packet timing ctrl", NULL},
   {"TS_IN6_MAP",        4, 4, "Select which DDS o/p drives TS input channel 6 timestamp cntr ctrl for packet timing ctrl", NULL},
   {"TS_IN5_MAP",        0, 4, "Select which DDS o/p drives TS input channel 5 timestamp cntr ctrl for packet timing ctrl", NULL},
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen3_cru_DDS_FREQ[] =
{
   {"reserved",         28, 4, "Reserved : Reads as 0 and writes are ignored", NULL},
   {"DDS_FREQ",          0,28, "Frequency setting for DDS", NULL},
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen3_cru_TS_CTRL[] =
{
   {"reserved",          1,31,"Reserved : ", NULL},
   {"VPLL_REFIN",        0,1, "VCXO or DDS0 for VPLL", NULL},
   { NULL,0,0,"",NULL }    /* NULL Terminated */
};


#define GEN3_CRU_TCHAN_BASE_DIFF   0x0040


static const struct EAS_Register g_csr_gen3_cru[] =
{
    { "0_TM_CMD",       (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x00, g_csr_gen3_cru_TM_CMD, "Configuration", NULL },
    { "0_DDS_PHASE",    (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x04, NULL, "unused: dds phase", NULL },
    { "0_DDS_FREQ",     (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x08, g_csr_gen3_cru_DDS_FREQ, "DDS Frequency", NULL },
    { "0_GET_SYSTIME_1",(0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
    { "0_SET_STC_LO",   (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
    { "0_SET_STC_HI",   (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x14, g_csr_gen3_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
    { "0_GET_STC_LO",   (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x18, g_csr_gen3_cru_GET_STC_LO, "Correlated timestamp capture of STC", NULL },
    { "0_GET_STC_HI",   (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x1C, g_csr_gen3_cru_GET_STC_HI, "Most significant bit of STC", NULL },
    { "0_COMP_LO",      (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
    { "0_COMP_HI",      (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x24, g_csr_gen3_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
    { "0_VSYNC_LO",     (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x28, NULL, "Vertical Sync Timestamp", NULL },
    { "0_VSYNC_HI",     (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x2c, g_csr_gen3_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
   { "0_STC_LO",     (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x30, NULL, "Current time from STC", NULL },
    { "0_STC_HI",    (0 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x34, g_csr_gen3_cru_COMP_HI, "Most significant bits of STC", NULL },

   { "1_TM_CMD",     (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x00, g_csr_gen3_cru_TM_CMD, "Configuration", NULL },
   { "1_DDS_PHASE",  (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x04, NULL, "unused: dds phase", NULL },
   { "1_DDS_FREQ",   (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x08, g_csr_gen3_cru_DDS_FREQ, "DDS Frequency", NULL },
   { "1_GET_SYSTIME_1",(1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
   { "1_SET_STC_LO", (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
   { "1_SET_STC_HI", (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x14, g_csr_gen3_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
   { "1_GET_STC_LO", (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x18, g_csr_gen3_cru_GET_STC_LO, "Correlated timestamp capture of STC", NULL },
   { "1_GET_STC_HI", (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x1C, g_csr_gen3_cru_GET_STC_HI, "Most significant bit of STC", NULL },
   { "1_COMP_LO",    (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
   { "1_COMP_HI",    (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x24, g_csr_gen3_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
   { "1_VSYNC_LO",   (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x28, NULL, "Vertical Sync Timestamp", NULL },
   { "1_VSYNC_HI",   (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x2c, g_csr_gen3_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
   { "1_STC_LO",     (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x30, NULL, "Current time from STC", NULL },
    { "1_STC_HI",    (1 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x34, g_csr_gen3_cru_COMP_HI, "Most significant bits of STC", NULL },

   { "2_TM_CMD",     (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x00, g_csr_gen3_cru_TM_CMD, "Configuration", NULL },
   { "2_DDS_PHASE",  (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x04, NULL, "unused: dds phase", NULL },
   { "2_DDS_FREQ",   (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x08, g_csr_gen3_cru_DDS_FREQ, "DDS Frequency", NULL },
   { "2_GET_SYSTIME_1",(2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
   { "2_SET_STC_LO", (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
   { "2_SET_STC_HI", (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x14, g_csr_gen3_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
   { "2_GET_STC_LO", (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x18, g_csr_gen3_cru_GET_STC_LO, "Correlated timestamp capture of STC", NULL },
   { "2_GET_STC_HI", (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x1C, g_csr_gen3_cru_GET_STC_HI, "Most significant bit of STC", NULL },
   { "2_COMP_LO",    (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
   { "2_COMP_HI",    (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x24, g_csr_gen3_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
   { "2_VSYNC_LO",   (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x28, NULL, "Vertical Sync Timestamp", NULL },
   { "2_VSYNC_HI",   (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x2c, g_csr_gen3_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
   { "2_STC_LO",     (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x30, NULL, "Current time from STC", NULL },
    { "2_STC_HI",    (2 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x34, g_csr_gen3_cru_COMP_HI, "Most significant bits of STC", NULL },

   { "3_TM_CMD",     (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x00, g_csr_gen3_cru_TM_CMD, "Configuration", NULL },
   { "3_DDS_PHASE",  (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x04, NULL, "unused: dds phase", NULL },
   { "3_DDS_FREQ",   (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x08, g_csr_gen3_cru_DDS_FREQ, "DDS Frequency", NULL },
   { "3_GET_SYSTIME_1",(3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
   { "3_SET_STC_LO", (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
   { "3_SET_STC_HI", (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x14, g_csr_gen3_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
   { "3_GET_STC_LO", (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x18, g_csr_gen3_cru_GET_STC_LO, "Correlated timestamp capture of STC", NULL },
   { "3_GET_STC_HI", (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x1C, g_csr_gen3_cru_GET_STC_HI, "Most significant bit of STC", NULL },
   { "3_COMP_LO",    (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
   { "3_COMP_HI",    (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x24, g_csr_gen3_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
   { "3_VSYNC_LO",   (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x28, NULL, "Vertical Sync Timestamp", NULL },
   { "3_VSYNC_HI",   (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x2c, g_csr_gen3_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
   { "3_STC_LO",     (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x30, NULL, "Current time from STC", NULL },
    { "3_STC_HI",    (3 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x34, g_csr_gen3_cru_COMP_HI, "Most significant bits of STC", NULL },

   { "4_TM_CMD",     (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x00, g_csr_gen3_cru_TM_CMD, "Configuration", NULL },
   { "4_DDS_PHASE",  (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x04, NULL, "unused: dds phase", NULL },
   { "4_DDS_FREQ",   (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x08, g_csr_gen3_cru_DDS_FREQ, "DDS Frequency", NULL },
   { "4_GET_SYSTIME_1",(4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
   { "4_SET_STC_LO", (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
   { "4_SET_STC_HI", (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x14, g_csr_gen3_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
   { "4_GET_STC_LO", (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x18, g_csr_gen3_cru_GET_STC_LO, "Correlated timestamp capture of STC", NULL },
   { "4_GET_STC_HI", (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x1C, g_csr_gen3_cru_GET_STC_HI, "Most significant bit of STC", NULL },
   { "4_COMP_LO",    (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
   { "4_COMP_HI",    (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x24, g_csr_gen3_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
   { "4_VSYNC_LO",   (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x28, NULL, "Vertical Sync Timestamp", NULL },
   { "4_VSYNC_HI",   (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x2c, g_csr_gen3_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
   { "4_STC_LO",     (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x30, NULL, "Current time from STC", NULL },
    { "4_STC_HI",    (4 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x34, g_csr_gen3_cru_COMP_HI, "Most significant bits of STC", NULL },

   { "5_TM_CMD",     (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x00, g_csr_gen3_cru_TM_CMD, "Configuration", NULL },
   { "5_DDS_PHASE",  (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x04, NULL, "unused: dds phase", NULL },
   { "5_DDS_FREQ",   (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x08, g_csr_gen3_cru_DDS_FREQ, "DDS Frequency", NULL },
   { "5_GET_SYSTIME_1",(5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
   { "5_SET_STC_LO", (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
   { "5_SET_STC_HI", (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x14, g_csr_gen3_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
   { "5_GET_STC_LO", (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x18, g_csr_gen3_cru_GET_STC_LO, "Correlated timestamp capture of STC", NULL },
   { "5_GET_STC_HI", (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x1C, g_csr_gen3_cru_GET_STC_HI, "Most significant bit of STC", NULL },
   { "5_COMP_LO",    (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
   { "5_COMP_HI",    (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x24, g_csr_gen3_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
   { "5_VSYNC_LO",   (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x28, NULL, "Vertical Sync Timestamp", NULL },
   { "5_VSYNC_HI",   (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x2c, g_csr_gen3_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
   { "5_STC_LO",     (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x30, NULL, "Current time from STC", NULL },
    { "5_STC_HI",    (5 * GEN3_CRU_TCHAN_BASE_DIFF) + 0x34, g_csr_gen3_cru_COMP_HI, "Most significant bits of STC", NULL },


    { "INT_STATUS",                          0x200, g_csr_gen3_cru_INTERRUPT, "Interrupt Status", NULL },
    { "INT_ENABLE",                          0x204, g_csr_gen3_cru_INTERRUPT, "Interrupt Mask", NULL },
    { "MASTER_DDS_FREQ",                     0x208, g_csr_gen3_cru_DDS_FREQ, "Master DDS Frequency", NULL },
    { "TS_CTRL",                             0x20c, g_csr_gen3_cru_TS_CTRL, "Controls the video PLL clock source", NULL },
      { "VCXO_DAC",                     0x210, g_csr_gen3_cru_VCXO_DAC_CTRL, "VCXO DAC Control", NULL},
      { "TS_DDS_MAP",                      0x214, g_csr_gen3_cru_TS_DDS_MAP_CTRL, "TS DDS MAP Control", NULL},
    { "TS_DDS_MAP2",                      0x20c, g_csr_gen3_cru_TS_DDS_MAP2_CTRL, "TS DDS MAP2 Control", NULL}, // gen5 only

    { "NET_CMD",                             0x300, NULL, "Command and configuration of network timestamper", NULL },
    { "NET_DDS_FREQ",                        0x308, NULL, "Frequency settings for network timebase DDS", NULL },
    { "NET_GET_SYSTIME",                     0x30c, NULL, "Running status of System Time bits [31:0]", NULL },
    { "NET_CAPLOW_TX",                       0x310, NULL, "System Time Capture register C [31:0] - Network TX packets", NULL },
    { "NET_CAPLOW_RX",                       0x314, NULL, "System Time Capture register C [31:0] - Network RX packets", NULL },
    { "NET_COMPLOW_S",                       0x318, NULL, "", NULL },

    { "FILTER_CFG_A1",  0x0380, NULL, "Packet Filter configuration and Enables", NULL },
    { "FILTER_CFG_B1",  0x0384, NULL, "Parameters for IP-based IEEE1588 protocol implementation", NULL },
    { "FILTER_CFG_C1",  0x0388, NULL, "IP protocol data", NULL },
    { "FILTER_CFG_D1",  0x038C, NULL, "IP Protocol data", NULL },

    { "MSG_DATA_1_TX",  0x03A0, NULL, "Transmit Message Captured data", NULL },
    { "MSG_DATA_2_TX",  0x03A4, NULL, "Transmit Message Captured data", NULL },
    { "MSG_DATA_3_TX",  0x03A8, NULL, "Transmit Message Captured data", NULL },

    { "MSG_DATA_1_RX",  0x03E0, NULL, "Receive Message Captured data", NULL },
    { "MSG_DATA_2_RX",  0x03E4, NULL, "Receive Message Captured data", NULL },
    { "MSG_DATA_3_RX",  0x03E8, NULL, "Receive Message Captured data", NULL },



   /* ---------------------------------------------------------------------------------- */
   /* ---------------------------------------------------------------------------------- */
   /* The following definitions are abbreviations used by the driver / HAL to simplify register programming for multiple units */
   /* ---------------------------------------------------------------------------------- */
   /* ---------------------------------------------------------------------------------- */
    { "TM_CMD",            0x00, g_csr_gen3_cru_TM_CMD, "Configuration", NULL },
    { "DDS_PHASE",         0x04, NULL, "unused: dds phase", NULL },
    { "DDS_FREQ",          0x08, g_csr_gen3_cru_DDS_FREQ, "DDS Frequency", NULL },
    { "GET_SYSTIME_1",     0x0c, NULL, "32-Bit correlated timestamp from system timebase", NULL },
    { "SET_STC_LO",        0x10, NULL, "LSB of STC[31:0],  preset value for timebase ", NULL },
    { "SET_STC_HI",        0x14, g_csr_gen3_cru_SET_STC_HI, "Set value for prescaler for timebase channel,STC [33]", NULL },
    { "GET_STC_LO",        0x18, g_csr_gen3_cru_GET_STC_LO, "Correlated timestamp capture of STC", NULL },
    { "GET_STC_HI",        0x1C, g_csr_gen3_cru_GET_STC_HI, "Most significant bit of STC", NULL },
    { "COMP_LO",           0x20, NULL, "Event Comparison time for Channel 1, least significant bits", NULL },
    { "COMP_HI",           0x24, g_csr_gen3_cru_COMP_HI, "Event Comparison time , MSB and prescaler", NULL },
    { "VSYNC_LO",          0x28, NULL, "Vertical Sync Timestamp", NULL },
    { "VSYNC_HI",          0x2c, g_csr_gen3_cru_VSYNC_HI, "Vertical Sync timestamp", NULL },
   { "STC_LO",          0x30, NULL, "Current time from STC", NULL },
    { "STC_HI",            0x34, g_csr_gen3_cru_COMP_HI, "Most significant bits of STC", NULL },

    { "SUBUNIT_BASE_DIFF",  0x0040, 0, "Base diff of Units", NULL },
    { "SUBUNIT_0_BASE",     0x0000, 0, "Base of Unit 0", NULL },
   { "SUBUNIT_1_BASE",     0x0040, 0, "Base of Unit 1", NULL },
   { "SUBUNIT_2_BASE",     0x0080, 0, "Base of Unit 2", NULL },
   { "SUBUNIT_3_BASE",     0x00C0, 0, "Base of Unit 3", NULL },
   { "SUBUNIT_4_BASE",     0x0100, 0, "Base of Unit 4", NULL },
   { "SUBUNIT_5_BASE",     0x0140, 0, "Base of Unit 5", NULL },


    { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct SVEN_Module_EventSpecific g_gen3_cru_specific_events[] =
{
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_gen3_cru_sven_module =
{
    "GEN3_CRU",
    SVEN_module_GEN3_CRU,
    0x00000400,            /* size of CSR Space */
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen3_cru,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "CRU: Gen3 Clock Recovery Unit",
    g_gen3_cru_specific_events,
    NULL /* extension list */
};



