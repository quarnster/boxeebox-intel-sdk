/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_unit.h"
#endif

#if 0
static const struct EAS_RegBits g_csr_mfd_UPCOMD0 [] = {
  { "LINE_DOUBLE",		25,	1},     /* 0 : No Line duplication     */
  { "PXL_DOUBLE",		24,	1},	/* 0 : No Line duplicatio  */
  { "CONST_ALPHA",	        16,	8}, 	/* Constant Alpha   */
  { "VIDEO_FORMAT",	        10,	5}, 	/* 00000: Pseudo-planar YCbCr 4:2:2 8-bit */
  { "UP_ENBL",	         0,	1}, 	/* Universal plane Enable */
  { NULL }    /* NULL terminator */
};
#endif

static const struct EAS_Register g_csr_gen3_mfd[]= {
  /* Top level register map */
  {"MFD_SIF_HW_ID",                        0x00000, NULL, "MFD SIF HW ID",           NULL}, 
  {"MFD_SIF_FW_ID",                        0x00004, NULL, "MFD SIF FW ID",           NULL},
  {"MFD_SIF_SOFT_RST",                     0x00008, NULL, "MFD SIF SOFT RST",        NULL},
  {"MFD_HOST_INT_STAT",                    0x0000C, NULL, "MFD HOST INT STAT",       NULL},
  {"MFD_DECODER_SEL",                      0x00010, NULL, "MFD DECODER SEL",         NULL},
  {"MFD_HOST_INT_EN",                      0x00014, NULL, "MFD HOST INT EN",         NULL},
  {"MFD_SIF_SYS_PMODE",                    0x00018, NULL, "MFD SIF SYS PMODE",       NULL},
  {"MFD_SIF_HOST_SMP_SET",                 0x0001C, NULL, "MFD SIF HOST SMP SET",    NULL},
  {"MFD_SIF_HOST_SMP_MASK",                0x00020, NULL, "MFD SIF HOST SMP MASK",   NULL},
  {"MFD_SIF_CORE_SMP_SET",                 0x00024, NULL, "MFD SIF CORE SMP SET",    NULL},
  {"MFD_SIF_CORE_SMP_MASK",                0x00028, NULL, "MFD SIF CORE SMP MASK",   NULL},
  {"MFD_SIF_HOST_SMP_DATA",                0x0002C, NULL, "MFD SIF HOST SMP DATA",   NULL},
  {"MFD_SIF_CORE_SMP_DATA",                0x00030, NULL, "MFD SIF CORE SMP DATA",   NULL},
  {"MFD_VSPARC_SIF_INT_STATUS",            0x00034, NULL, "MFD VSPARC SIF INT STAT", NULL},
  {"MFD_VSPARC_CORE_INT_STATUS",           0x00038, NULL, "MFD VSPARC CORE INT STA", NULL},
  {"MFD_VSPARC_SCD_INT_STATUS",            0x0003c, NULL, "MFD VSPARC SCD INT STAT", NULL},
  {"MFD_VSPARC_DMA_INT_STATUS",            0x00040, NULL, "MFD VSPARC DMA INT STAT", NULL},
  /* The following register no longer exists in RTL */
  /* {"MFD_OMAR_CONTROL",                     0x00044, NULL, "MFD OMAR CONTROL       ", NULL},  */
  {"MFD_VCMH_FBW",                         0x00048, NULL, "MFD VCMH FBW",            NULL},
  {"MFD_OMAR_FW_STATUS",                   0x0004c, NULL, "MFD OMAR FW STATUS",      NULL},
  {"MFD_OMAR_FW_DATA",                     0x00050, NULL, "MFD OMAR FW DATA",        NULL},

  /* Interrupt controller register */
  {"MFD_INTC_INT_MASK",                    0x00200, NULL, "MFD INIC INT MASK",       NULL}, 
  {"MFD_INTC_INT_PEND",                    0x00204, NULL, "MFD INTC INT PEND",       NULL}, 
  {"MFD_INTC_INT_FORCE",                   0x00208, NULL, "MFD INTC INT FORCE",      NULL}, 
  {"MFD_INTC_CLR_INT_PEND",                0x0020C, NULL, "MFD INTC CLR INT PEND",   NULL}, 

  /* Timer register map */
  {"MFD_TIMER0_VAL",                       0x00400, NULL, "MFD TIMER0 VAL",          NULL}, 
  {"MFD_TIMER0_LOAD",                      0x00404, NULL, "MFD TIMER0 LOAD",         NULL}, 
  {"MFD_TIMER0_CTRL",                      0x00408, NULL, "MFD TIMER0 CTRL",         NULL}, 
  /* NOTE: 0x0040C is not used. */
  {"MFD_TIMER1_VAL",                       0x00410, NULL, "MFD TIMER1 VAL",          NULL}, 
  {"MFD_TIMER1_LOAD",                      0x00414, NULL, "MFD TIMER1 LOAD",         NULL}, 
  {"MFD_TIMER1_CTRL",                      0x00418, NULL, "MFD TIMER1 CTRL",         NULL}, 
  {"MFD_TIMER_SCALER",                     0x00420, NULL, "MFD TIMER SCALER",        NULL}, 
  {"MFD_TIMER_PRESET",                     0x00424, NULL, "MFD TIMER PRESET",        NULL}, 

  /* Linear DMA */
  {"MFD_LINEAR_DMA_EMA",                   0x00A00, NULL, "MFD LINEAR DMA EMA",             NULL}, 
  {"MFD_LINEAR_DMA_CONF",                  0x00A04, NULL, "MFD LINEAR DMA CONF",            NULL}, 
  {"MFD_LINEAR_DMA_DO_XFER",               0x00A08, NULL, "MFD LINEAR DMA DO XFER",         NULL}, 
  {"MFD_LINEAR_DMA_XFER_STAT",             0x00A0C, NULL, "MFD LINEAR DMA XFER STA",        NULL}, 

  /* DQM */
  {"MFD_DQM_ODPQ_CS",                      0x00B5C, NULL, "MFD DQM ODPQ CS",                NULL},
  {"MFD_DQM_ODPQ_DATA_OFFSET",             0x00B60, NULL, "MFD DQM ODPQ DATA OFFSE",        NULL},
  {"MFD_DQM_ODPQ_CUSTOM_DATA",             0x00B64, NULL, "MFD DQM ODPQ CUSTOM DAT",        NULL},
  {"MFD_DQM_ODPQ_RETURN",                  0x00B68, NULL, "MFD DQM ODPQ RETURN",            NULL},
  {"MFD_DQM_DSPLY_FREED_CNT_WTRMRK",       0x00B6C, NULL, "MFD DQM DSPLY FREED CNT WTRMRK", NULL},


  /* H264 #0  (CS7051) 0x1000 to 0x1FFF  */
  {"MFD_H264_0_SMP_RD",                    0x01000, NULL, "MFD H264 0 SMP RD",            NULL},
  {"MFD_H264_0_INT_EN_RD",                 0x01004, NULL, "MFD H264 0 INT EN RD",         NULL},
  {"MFD_H264_0_SMP_SET",                   0x01008, NULL, "MFD H264 0 SMP SET",           NULL},
  {"MFD_H264_0_SMP_CLR",                   0x0100C, NULL, "MFD H264 0 SMP CLR",           NULL},
  {"MFD_H264_0_SMP_MSK_SET",               0x01010, NULL, "MFD H264 0 SMP MSK SET",       NULL},
  {"MFD_H264_0_SMP_MSK_CLR",               0x01014, NULL, "MFD H264 0 SMP MSK CLR",       NULL},
  {"MFD_H264_0_HDAT",                      0x01018, NULL, "MFD H264 0 HDAT",              NULL},
  {"MFD_H264_0_SDDAT",                     0x0101C, NULL, "MFD H264 0 SDDAT",             NULL},
  {"MFD_H264_0_DQ_PUSH",                   0x01020, NULL, "MFD H264 0 DQ PUSH",           NULL},
  {"MFD_H264_0_DQ_STAT",                   0x01024, NULL, "MFD H264 0 DQ STAT",           NULL},
  {"MFD_H264_0_DPB_INIT",                  0x01040, NULL, "MFD H264 0 DPB INIT",          NULL},
  {"MFD_H264_0_DPB_FRM_SZ_STAT",           0x01044, NULL, "MFD H264 0 DPB FRM SZ STAT",   NULL},
  {"MFD_H264_0_DPB_FRM_SZ_CTRL",           0x01048, NULL, "MFD H264 0 DPB FRM SZ CTRL",   NULL},
  {"MFD_H264_0_DPB_NUMB_OVR",              0x0104C, NULL, "MFD H264 0 DPB NUMB OVR",      NULL},
  {"MFD_H264_0_DPB_FS_VALUES",             0x01050, NULL, "MFD H264 0 DPB FS VALUES",     NULL},
  {"MFD_H264_0_DPB_FS_OFFSET",             0x01054, NULL, "MFD H264 0 DPB FS OFFSET",     NULL},
  {"MFD_H264_0_FSD",                       0x01058, NULL, "MFD H264 0 FSD",               NULL},
  {"MFD_H264_0_DANGLING_FIELD",            0x0105C, NULL, "MFD H264 0 DANGLING FIELD",    NULL},
  {"MFD_H264_0_DISP_TAG",                  0x01060, NULL, "MFD H264 0 DISP TAG",            NULL},
  {"MFD_H264_0_DPB_MBI_ADDR_LUT_WR",       0x0107C, NULL, "MFD H264 0 DPB MBI ADDR LUT WR", NULL},
  {"MFD_H264_0_DPB_UV_ADDR_LUT_WR",        0x01080, NULL, "MFD H264 0 DPB UV ADDR LUT WR",  NULL},
  {"MFD_H264_0_DPB_Y_ADDR_LUT_WR",         0x01084, NULL, "MFD H264 0 DPB Y ADDR LUT WR",   NULL},
  {"MFD_H264_0_FRAME_CYC_COUNT",           0x01090, NULL, "MFD H264 0 FRAME CYC COUNT",     NULL},
  {"MFD_H264_0_IB_WAIT_COUNT",             0x01094, NULL, "MFD H264 0 IB WAIT COUNT",     NULL},
  {"MFD_H264_0_RBSP_COUNT",                0x01098, NULL, "MFD H264 0 RBSP COUNT",        NULL},
  {"MFD_H264_0_MPR_COUNT",                 0x0109C, NULL, "MFD H264 0 MPR COUNT",         NULL},
  {"MFD_H264_0_CORE_CONFIG",               0x010A0, NULL, "MFD H264 0 CORE CONFIG",       NULL},
  {"MFD_H264_0_INT_CTRL",                  0x010C0, NULL, "MFD H264 0 INT CTRL",          NULL},
  {"MFD_H264_0_INT_STAT",                  0x010C4, NULL, "MFD H264 0 INT STAT",          NULL},
  {"MFD_H264_0_SOFT_RST",                  0x010FC, NULL, "MFD H264 0 SOFT RST",          NULL},
  {"MFD_H264_0_BSD_PSR_STAT",              0x01100, NULL, "MFD H264 0 BSD PSR STAT",      NULL},
  {"MFD_H264_0_BSD_STAT",                  0x01104, NULL, "MFD H264 0 BSD STAT",          NULL},
  {"MFD_H264_0_BSD_RBSP_CTRL",             0x01110, NULL, "MFD H264 0 BSD RBSP CTRL",     NULL},
  {"MFD_H264_0_BSD_DATA",                  0x01114, NULL, "MFD H264 0 BSD DATA",          NULL},
  {"MFD_H264_0_BSD_NAL_TYPE",              0x01118, NULL, "MFD H264 0 BSD NAL TYPE",      NULL},
  {"MFD_H264_0_BSD_BBB_STAT",              0x0111C, NULL, "MFD H264 0 BSD BBB STAT",      NULL},
  {"MFD_H264_0_BSD_GUE_DEC",               0x01120, NULL, "MFD_H264 0 BSD GUE DEC",       NULL},
  {"MFD_H264_0_BSD_GSE_DEC",               0x01124, NULL, "MFD H264 0 BSD GSE DEC",       NULL},
  {"MFD_H264_0_BSD_EXP_GME_INTRA",         0x01128, NULL, "MFD H264 0 BSD EXP GME INTRA", NULL},
  {"MFD_H264_0_BSD_EXP_GME_INTER",         0x01138, NULL, "MFD H264 0 BSD EXP GME INTER", NULL},
  {"MFD_H264_0_BSD_IMG_INIT",              0x01140, NULL, "MFD H264 0 BSD IMG INIT",      NULL},
  {"MFD_H264_0_BSD_SLICE_P1",              0x01150, NULL, "MFD H264 0 BSD SLICE P1",      NULL},
  {"MFD_H264_0_BSD_SLICE_P2",              0x01154, NULL, "MFD H264 0 BSD SLICE P2",      NULL},
  {"MFD_H264_0_BSD_SLICE_START",           0x01158, NULL, "MFD H264 0 BSD SLICE START",   NULL},
  {"MFD_H264_0_BSD_MB_CTRL",               0x0115C, NULL, "MFD H264 0 BSD MB CTRL",       NULL},
  {"MFD_H264_0_BSD_QM_DEC_START",          0x01160, NULL, "MFD H264 0 BSD QM DEC START",  NULL},
  {"MFD_H264_0_BSD_DEC_STAT",              0x01164, NULL, "MFD H264 0 BSD DEC STAT",      NULL},
  {"MFD_H264_0_BSD_QM_LOAD_START",         0x01168, NULL, "MFD H264 0 BSD QM LOAD START", NULL},
  {"MFD_H264_0_BSD_QM_LOAD_VALUE",         0x0116C, NULL, "MFD H264 0 BSD QM LOAD VALUE", NULL},
  {"MFD_H264_0_BSD_BYTE_ALIGN",            0x0117C, NULL, "MFD H264 0 BSD BYTE ALIGN",    NULL},
  {"MFD_H264_0_BSD_BBB_TRAIL",             0x01180, NULL, "MFD H264 0 BSD BBB TRAIL",     NULL},
  {"MFD_H264_0_BSD_GET_BITS01",            0x01184, NULL, "MFD H264 0 BSD GET BITS01",    NULL},
  {"MFD_H264_0_BSD_GET_BITS02",            0x01188, NULL, "MFD H264 0 BSD GET BITS02",    NULL},
  {"MFD_H264_0_BSD_GET_BITS03",            0x0118C, NULL, "MFD H264 0 BSD GET BITS03",    NULL},
  {"MFD_H264_0_BSD_GET_BITS04",            0x01190, NULL, "MFD H264 0 BSD GET BITS04",    NULL},
  {"MFD_H264_0_BSD_GET_BITS05",            0x01194, NULL, "MFD H264 0 BSD GET BITS05",    NULL},
  {"MFD_H264_0_BSD_GET_BITS06",            0x01198, NULL, "MFD H264 0 BSD GET BITS06",    NULL},
  {"MFD_H264_0_BSD_GET_BITS07",            0x0119C, NULL, "MFD H264 0 BSD GET BITS07",    NULL},
  {"MFD_H264_0_BSD_GET_BITS08",            0x011A0, NULL, "MFD H264 0 BSD GET BITS08",    NULL},
  {"MFD_H264_0_BSD_GET_BITS09",            0x011A4, NULL, "MFD H264 0 BSD GET BITS09",    NULL},
  {"MFD_H264_0_BSD_GET_BITS10",            0x011A8, NULL, "MFD H264 0 BSD GET BITS10",    NULL},
  {"MFD_H264_0_BSD_GET_BITS11",            0x011AC, NULL, "MFD H264 0 BSD GET BITS11",    NULL},
  {"MFD_H264_0_BSD_GET_BITS12",            0x011B0, NULL, "MFD H264 0 BSD GET BITS12",    NULL},
  {"MFD_H264_0_BSD_GET_BITS13",            0x011B4, NULL, "MFD H264 0 BSD GET BITS13",    NULL},
  {"MFD_H264_0_BSD_GET_BITS14",            0x011B8, NULL, "MFD H264 0 BSD GET BITS14",    NULL},
  {"MFD_H264_0_BSD_GET_BITS15",            0x011BC, NULL, "MFD H264 0 BSD GET BITS15",    NULL},
  {"MFD_H264_0_BSD_GET_BITS16",            0x011C0, NULL, "MFD H264 0 BSD GET BITS16",    NULL},
  {"MFD_H264_0_BSD_GET_BITS17",            0x011C4, NULL, "MFD H264 0 BSD GET BITS17",    NULL},
  {"MFD_H264_0_BSD_GET_BITS18",            0x011C8, NULL, "MFD H264 0 BSD GET BITS18",    NULL},
  {"MFD_H264_0_BSD_GET_BITS19",            0x011CC, NULL, "MFD H264 0 BSD GET BITS19",    NULL},
  {"MFD_H264_0_BSD_GET_BITS20",            0x011D0, NULL, "MFD H264 0 BSD GET BITS20",    NULL},
  {"MFD_H264_0_BSD_GET_BITS21",            0x011D4, NULL, "MFD H264 0 BSD GET BITS21",    NULL},
  {"MFD_H264_0_BSD_GET_BITS22",            0x011D8, NULL, "MFD H264 0 BSD GET BITS22",    NULL},
  {"MFD_H264_0_BSD_GET_BITS23",            0x011DC, NULL, "MFD H264 0 BSD GET BITS23",    NULL},
  {"MFD_H264_0_BSD_GET_BITS24",            0x011E0, NULL, "MFD H264 0 BSD GET BITS24",    NULL},
  {"MFD_H264_0_BSD_GET_BITS25",            0x011E4, NULL, "MFD H264 0 BSD GET BITS25",    NULL},
  {"MFD_H264_0_BSD_GET_BITS26",            0x011E8, NULL, "MFD H264 0 BSD GET BITS26",    NULL},
  {"MFD_H264_0_BSD_GET_BITS27",            0x011EC, NULL, "MFD H264 0 BSD GET BITS27",    NULL},
  {"MFD_H264_0_BSD_GET_BITS28",            0x011F0, NULL, "MFD H264 0 BSD GET BITS28",    NULL},
  {"MFD_H264_0_BSD_GET_BITS29",            0x011F4, NULL, "MFD H264 0 BSD GET BITS29",    NULL},
  {"MFD_H264_0_BSD_GET_BITS30",            0x011F8, NULL, "MFD H264 0 BSD GET BITS30",    NULL},
  {"MFD_H264_0_BSD_GET_BITS31",            0x011FC, NULL, "MFD H264 0 BSD GET BITS31",    NULL},
  {"MFD_H264_0_MPR_TF_POC",                0x01300, NULL, "MFD H264 0 MPR TF POC",        NULL},
  {"MFD_H264_0_MPR_BF_POC",                0x01304, NULL, "MFD H264 0 MPR BF POC",        NULL},
  {"MFD_H264_0_MPR_LST00",                 0x01380, NULL, "MFD H264 0 MPR LST00",         NULL},
  {"MFD_H264_0_MPR_LST01",                 0x01384, NULL, "MFD H264 0 MPR LST01",         NULL},
  {"MFD_H264_0_MPR_LST02",                 0x01388, NULL, "MFD H264 0 MPR LST02",         NULL},
  {"MFD_H264_0_MPR_LST03",                 0x0138C, NULL, "MFD H264 0 MPR LST03",         NULL},
  {"MFD_H264_0_MPR_LST04",                 0x01390, NULL, "MFD H264 0 MPR LST04",         NULL},
  {"MFD_H264_0_MPR_LST05",                 0x01394, NULL, "MFD H264 0 MPR LST05",         NULL},
  {"MFD_H264_0_MPR_LST06",                 0x01398, NULL, "MFD H264 0 MPR LST06",         NULL},
  {"MFD_H264_0_MPR_LST07",                 0x0139C, NULL, "MFD H264 0 MPR LST07",         NULL},
  {"MFD_H264_0_MPR_LST08",                 0x013A0, NULL, "MFD H264 0 MPR LST08",         NULL},
  {"MFD_H264_0_MPR_LST09",                 0x013A4, NULL, "MFD H264 0 MPR LST09",         NULL},
  {"MFD_H264_0_MPR_LST10",                 0x013A8, NULL, "MFD H264 0 MPR LST10",         NULL},
  {"MFD_H264_0_MPR_LST11",                 0x013AC, NULL, "MFD H264 0 MPR LST11",         NULL},
  {"MFD_H264_0_MPR_LST12",                 0x013B0, NULL, "MFD H264 0 MPR LST12",         NULL},
  {"MFD_H264_0_MPR_LST13",                 0x013B4, NULL, "MFD H264 0 MPR LST13",         NULL},
  {"MFD_H264_0_MPR_LST14",                 0x013B8, NULL, "MFD H264 0 MPR LST14",         NULL},
  {"MFD_H264_0_MPR_LST15",                 0x013BC, NULL, "MFD H264 0 MPR LST15",         NULL},

  /* SIF and Stream Control */
  {"MFD_H264_0_RSB_DDR_BA",                0x01808, NULL, "MFD H264 0 RSB DDR BA",        NULL},
  /* contains 2 status bits (bs_ib_empty and frm_dec_active) */
  {"MFD_H264_0_DEC_STATUS",                0x0180C, NULL, "MFD H264 0 DEC STATUS",        NULL},
  {"MFD_H264_0_SIF_SMP_RS",                0x01810, NULL, "MFD H264 0 SIF SMP RS",        NULL},
  {"MFD_H264_0_SIF_MSK_RS",                0x01814, NULL, "MFD H264 0 SIF MSK RS",        NULL},
  {"MFD_H264_0_SIF_HDAT",                  0x01818, NULL, "MFD H264 0 SIF HDAT",          NULL},
  {"MFD_H264_0_SIF_SDDAT",                 0x0181C, NULL, "MFD H264 0 SIF SDDAT",         NULL},
  {"MFD_H264_0_SIF_SMP_RC",                0x01820, NULL, "MFD H264 0 SIF SMP RC",        NULL},
  {"MFD_H264_0_SIF_MSK_RC",                0x01824, NULL, "MFD H264 0 SIF MSK RC",        NULL},

  /* Stream DMA */
  {"MFD_H264_0_SED",                       0x01900, NULL, "MFD H264 0 SED",                NULL},
  {"MFD_H264_0_SDEMC",                     0x01904, NULL, "MFD H264 0 SDEMC",              NULL},
  {"MFD_H264_0_DMA_CB_BASE",               0x01908, NULL, "MFD H264 0 DMA CB BASE",        NULL},
  {"MFD_H264_0_DMA_SB_RDPTR",              0x0190C, NULL, "MFD H264 0 DMA SB RDPTR",       NULL},
  {"MFD_H264_0_DMA_CB_SIZE",               0x01910, NULL, "MFD H264 0 DMA CB SIZE",        NULL},
  {"MFD_H264_0_DMA_WTRMARK",               0x01914, NULL, "MFD H264 0 DMA WTRMARK",        NULL},
  {"MFD_H264_0_DMA_WDT",                   0x01918, NULL, "MFD H264 0 DMA WDT",            NULL},
  {"MFD_H264_0_DMA_CB_RDPTR",              0x0191C, NULL, "MFD H264 0 DMA CB RDPTR",       NULL},
  {"MFD_H264_0_DMA_CB_WRPTR",              0x01920, NULL, "MFD H264 0 DMA CB WRPTR",       NULL},
  {"MFD_H264_0_DMA_SDLINK",                0x01924, NULL, "MFD H264 0 DMA SDLINK",         NULL},
  {"MFD_H264_0_DMA_SDLLSA",                0x01928, NULL, "MFD H264 0 DMA SDLLSA",         NULL},
  {"MFD_H264_0_DMA_SDLNDA",                0x0192C, NULL, "MFD H264 0 DMA SDLNDA",         NULL},
  {"MFD_H264_0_DMA_SDLDBC",                0x01930, NULL, "MFD H264 0 DMA SDLDBC",         NULL},
  {"MFD_H264_0_DMA_SDLCBC",                0x01934, NULL, "MFD H264 0 DMA SDLCBC",         NULL},
  {"MFD_H264_0_DMA_SDLDC",                 0x01938, NULL, "MFD H264 0 DMA SDLDC",          NULL},
  {"MFD_H264_0_DMA_FIFO",                  0x0193C, NULL, "MFD H264 0 DMA FIFO",           NULL},
  {"MFD_H264_0_DMA_FIFO_STAT",             0x01940, NULL, "MFD H264 0 DMA FIFO STAT",      NULL},
  {"MFD_H264_0_DMA_INT_EN",                0x01944, NULL, "MFD H264 0 DMA INT EN",         NULL},
  {"MFD_H264_0_DMA_INT_STAT",              0x01948, NULL, "MFD H264 0 DMA INT STAT",       NULL},
  {"MFD_H264_0_DMA_BS_CNTR",               0x0194C, NULL, "MFD H264 0 DMA BS CNTR",        NULL},

  /* Start Code Detector  (SCD) */
  {"MFD_H264_0_SCD_XCR",                   0x01A00, NULL, "MFD H264 0 SCD XCR",            NULL},
  {"MFD_H264_0_SCD_XSCR1",                 0x01A04, NULL, "MFD H264 0 SCD XSCR1",          NULL},
  {"MFD_H264_0_SCD_XSCR2",                 0x01A08, NULL, "MFD H264 0 SCD XSCR2",          NULL},
  {"MFD_H264_0_SCD_FWPREAD",               0x01A0C, NULL, "MFD H264 0 SCD FWPREAD",        NULL},
  {"MFD_H264_0_SCD_FWCRTL",                0x01A10, NULL, "MFD H264 0 SCD FWCRTL",         NULL},
  {"MFD_H264_0_SCD_FWSTAT",                0x01A14, NULL, "MFD H264 0 SCD FWSTAT",         NULL},
  {"MFD_H264_0_SCD_WRCTRL",                0x01A18, NULL, "MFD H264 0 SCD WRCTRL",         NULL},
  {"MFD_H264_0_SCD_WRDATA",                0x01A1C, NULL, "MFD H264 0 SCD WRDATA",         NULL},

  /* PIP Scaler Registers */
  {"MFD_H264_0_PIP_CTRL",                  0x01B00, NULL, "MFD H264 0 PIP CTRL",           NULL},
  {"MFD_H264_0_PIP_STAT",                  0x01B04, NULL, "MFD H264 0 PIP STAT",           NULL},
  {"MFD_H264_0_PIP_CDYB",                  0x01B08, NULL, "MFD H264 0 PIP CDYB",           NULL},
  {"MFD_H264_0_PIP_CDUB",                  0x01B0c, NULL, "MFD H264 0 PIP CDUB",           NULL},
  {"MFD_H264_0_PIP_TST_CTRL",              0x01B10, NULL, "MFD H264 0 PIP TST CTRL",       NULL},
  {"MFD_H264_0_PIP_TST_WR_DATA_LO",        0x01B14, NULL, "MFD H264 0 PIP TST WR DATA LO", NULL},
  {"MFD_H264_0_PIP_TST_WR_DATA_HI",        0x01B18, NULL, "MFD H264 0 PIP TST WR DATA HI", NULL},

  /*  VC1 #0 (CS7150) 0x2000 to 0x2FFF */
  {"MFD_VC1_0_SMP_RD",                     0x02000, NULL, "MFD VC1 0 SMP RD",             NULL},
  {"MFD_VC1_0_INT_EN_RD",                  0x02004, NULL, "MFD VC1 0 INT EN RD",          NULL},
  {"MFD_VC1_0_SMP_SET",                    0x02008, NULL, "MFD VC1 0 SMP SET",            NULL},
  {"MFD_VC1_0_SMP_CLR",                    0x0200C, NULL, "MFD VC1 0 SMP CLR",            NULL},
  {"MFD_VC1_0_SMP_MSK_SET",                0x02010, NULL, "MFD VC1 0 SMP MSK SET",        NULL},
  {"MFD_VC1_0_SMP_MSK_CLR",                0x02014, NULL, "MFD VC1 0 SMP MSK CLR",        NULL},
  {"MFD_VC1_0_HDAT",                       0x02018, NULL, "MFD VC1 0 HDAT",               NULL},
  {"MFD_VC1_0_SDDAT",                      0x0201C, NULL, "MFD VC1 0 SDDAT",              NULL},
  {"MFD_VC1_0_DQ_PUSH",                    0x02020, NULL, "MFD VC1 0 DQ PUSH",            NULL},
  {"MFD_VC1_0_DQ_STAT",                    0x02024, NULL, "MFD VC1 0 DQ STAT",            NULL},
  {"MFD_VC1_0_DPB_INIT",                   0x02040, NULL, "MFD VC1 0 DPB INIT",           NULL},
  {"MFD_VC1_0_DPB_FRM_SZ_STAT",            0x02044, NULL, "MFD VC1 0 DPB FRM SZ STAT",    NULL},
  {"MFD_VC1_0_DPB_FRM_SZ_CTRL",            0x02048, NULL, "MFD VC1 0 DPB FRM SZ CTRL",    NULL},
  {"MFD_VC1_0_DPB_NUMB_OVR",               0x0204C, NULL, "MFD VC1 0 DPB NUMB_OVR",       NULL},
  {"MFD_VC1_0_DPB_FS_SETTING",             0x02050, NULL, "MFD VC1 0 DPB FS SETTING",     NULL},
  {"MFD_VC1_0_DPB_LOAD_OFFSET",            0x02054, NULL, "MFD VC1 0 DPB LOAD OFFSET",    NULL},
  {"MFD_VC1_0_FSD",                        0x02058, NULL, "MFD VC1 0 FSD",                NULL},
  {"MFD_VC1_0_DANGLING_FIELD",             0x0205C, NULL, "MFD VC1 0 DANGLING FIELD",     NULL},
  {"MFD_VC1_0_DISP_TAG",                   0x02060, NULL, "MFD VC1 0 DISP TAG",           NULL},
  {"MFD_VC1_0_DPB_UV_ADDR_LUT_WR",         0x02080, NULL, "MFD VC1 0 DPB UV ADDR LUT WR", NULL},
  {"MFD_VC1_0_DPB_Y_ADDR_LUT_WR",          0x02084, NULL, "MFD VC1 0 DPB Y ADDR LUT WR",  NULL},
  {"MFD_VC1_0_MPS_RD_BYTE_COUNT",          0x02088, NULL, "MFD VC1 0 MPS RD BYTE COUNT",  NULL},
  {"MFD_VC1_0_SLC_IN_FRM_COUNT",           0x0208C, NULL, "MFD VC1 0 SLC IN FRM COUNT",   NULL},
  {"MFD_VC1_0_FRAME_CYC_COUNT",            0x02090, NULL, "MFD VC1 0 FRAME CYC COUNT",    NULL},
  {"MFD_VC1_0_IB_WAIT_COUNT",              0x02094, NULL, "MFD VC1 0 IB WAIT COUNT",      NULL},
  {"MFD_VC1_0_RBSP_COUNT",                 0x02098, NULL, "MFD VC1 0 RBSP COUNT",         NULL},
  {"MFD_VC1_0_BS2RBSP_STATUS",             0x0209C, NULL, "MFD VC1 0 BS2RBSP STATUS",     NULL},
  {"MFD_VC1_0_CORE_CONFIG",                0x020A0, NULL, "MFD VC1 0 CORE CONFIG",        NULL},
  {"MFD_VC1_0_RBSP_CTRL",                  0x020A4, NULL, "MFD VC1 0 RBSP CTRL",          NULL},
  {"MFD_VC1_0_INT_CTRL",                   0x020C0, NULL, "MFD VC1 0 INT CTRL",           NULL},
  {"MFD_VC1_0_INT_STAT",                   0x020C4, NULL, "MFD VC1 0 INT STAT",           NULL},
  {"MFD_VC1_0_SOFT_RST",                   0x020C8, NULL, "MFD VC1 0 SOFT RST",           NULL},
  {"MFD_VC1_0_BSP_BYTE_ALIGN",             0x02100, NULL, "MFD VC1 0 BSP BYTE ALIGN",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS01",             0x02104, NULL, "MFD VC1 0 BSP GET BITS01",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS02",             0x02108, NULL, "MFD VC1 0 BSP GET BITS02",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS03",             0x0210C, NULL, "MFD VC1 0 BSP GET BITS03",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS04",             0x02110, NULL, "MFD VC1 0 BSP GET BITS04",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS05",             0x02114, NULL, "MFD VC1 0 BSP GET BITS05",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS06",             0x02118, NULL, "MFD VC1 0 BSP GET BITS06",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS07",             0x0211C, NULL, "MFD VC1 0 BSP GET BITS07",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS08",             0x02120, NULL, "MFD VC1 0 BSP GET BITS08",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS09",             0x02124, NULL, "MFD VC1 0 BSP GET BITS09",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS10",             0x02128, NULL, "MFD VC1 0 BSP GET BITS10",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS11",             0x0212C, NULL, "MFD VC1 0 BSP GET BITS11",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS12",             0x02130, NULL, "MFD VC1 0 BSP GET BITS12",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS13",             0x02134, NULL, "MFD VC1 0 BSP GET BITS13",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS14",             0x02138, NULL, "MFD VC1 0 BSP GET BITS14",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS15",             0x0213C, NULL, "MFD VC1 0 BSP GET BITS15",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS16",             0x02140, NULL, "MFD VC1 0 BSP GET BITS16",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS17",             0x02144, NULL, "MFD VC1 0 BSP GET BITS17",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS18",             0x02148, NULL, "MFD VC1 0 BSP GET BITS18",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS19",             0x0214C, NULL, "MFD VC1 0 BSP GET BITS19",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS20",             0x02150, NULL, "MFD VC1 0 BSP GET BITS20",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS21",             0x02154, NULL, "MFD VC1 0 BSP GET BITS21",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS22",             0x02158, NULL, "MFD VC1 0 BSP GET BITS22",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS23",             0x0215C, NULL, "MFD VC1 0 BSP GET BITS23",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS24",             0x02160, NULL, "MFD VC1 0 BSP GET BITS24",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS25",             0x02164, NULL, "MFD VC1 0 BSP GET BITS25",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS26",             0x02168, NULL, "MFD VC1 0 BSP GET BITS26",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS27",             0x0216C, NULL, "MFD VC1 0 BSP GET BITS27",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS28",             0x02170, NULL, "MFD VC1 0 BSP GET BITS28",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS29",             0x02174, NULL, "MFD VC1 0 BSP GET BITS29",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS30",             0x02178, NULL, "MFD VC1 0 BSP GET BITS30",     NULL},
  {"MFD_VC1_0_BSP_GET_BITS31",             0x0217C, NULL, "MFD VC1 0 BSP GET BITS31",     NULL},
  {"MFD_VC1_0_BSP_STATUS",                 0x02180, NULL, "MFD VC1 0 BSP STATUS",         NULL},
  {"MFD_VC1_0_BSP_CTRL",                   0x02184, NULL, "MFD VC1 0 BSP CTRL",           NULL},
  {"MFD_VC1_0_BSP_SHOW_BITS",              0x02188, NULL, "MFD VC1 0 BSP SHOW BITS",      NULL},
  {"MFD_VC1_0_BSP_SHOW_BITS_FLPD",         0x0218C, NULL, "MFD VC1 0 BSP SHOW BITS FLPD", NULL},
  {"MFD_VC1_0_BSP_IGNORE_BBB_LEVEL",       0x02190, NULL, "MFD VC1 0 BSP IGNORE BBB LEVEL",       NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_PTYPE",       0x021C0, NULL, "MFD VC1 0 BSP HEADER VLC PTYPE",       NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_FTYPE",       0x021C4, NULL, "MFD VC1 0 BSP HEADER VLC FTYPE",       NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_MVRANGE",     0x021C8, NULL, "MFD VC1 0 BSP HEADER VLC MVRANGE",     NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_MVMODE",      0x021CC, NULL, "MFD VC1 0 BSP HEADER VLC MVMODE",      NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_MVMODE2",     0x021D0, NULL, "MFD VC1 0 BSP HEADER VLC MVMODE2",     NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_DMVRANGE",    0x021D4, NULL, "MFD VC1 0 BSP HEADER VLC DMVRANGE",    NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_BPPMODE",     0x021D8, NULL, "MFD VC1 0 BSP HEADER VLC BPPMODE",     NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_BPPVLC2",     0x021DC, NULL, "MFD VC1 0 BSP HEADER VLC BPPVLC2",     NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_BPPVLC6",     0x021E0, NULL, "MFD VC1 0 BSP HEADER VLC BPPVLC6",     NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_BFRACT",      0x021E4, NULL, "MFD VC1 0 BSP HEADER VLC BFRACT",      NULL},
  {"MFD_VC1_0_BSP_HEADER_VLC_REFDIST",     0x021E8, NULL, "MFD VC1 0 BSP HEADER VLC REFDIST",     NULL},
  {"MFD_VC1_0_SEQPIC_GENERAL_CORE_CONFIG", 0x02200, NULL, "MFD VC1 0 SEQPIC GENERAL CORE CONFIG", NULL},
  {"MFD_VC1_0_SEQPIC_STREAM_FORMAT_1",     0x02204, NULL, "MFD VC1 0 SEQPIC STREAM FORMAT 1",     NULL},
  {"MFD_VC1_0_SEQPIC_CODED_SIZE",          0x02208, NULL, "MFD VC1 0 SEQPIC CODED SIZE",          NULL},
  {"MFD_VC1_0_SEQPIC_STREAM_FORMAT_2",     0x0220C, NULL, "MFD VC1 0 SEQPIC STREAM FORMAT 2",     NULL},
  {"MFD_VC1_0_SEQPIC_ENTRY_POINT_1",       0x02210, NULL, "MFD VC1 0 SEQPIC ENTRY POINT 1",       NULL},
  {"MFD_VC1_0_SEQPIC_RANGE_MAP",           0x02214, NULL, "MFD VC1 0 SEQPIC RANGE MAP",           NULL},
  {"MFD_VC1_0_SEQPIC_FRAME_TYPE",          0x02218, NULL, "MFD VC1 0 SEQPIC FRAME TYPE",          NULL},
  {"MFD_VC1_0_SEQPIC_RECON_CONTROL",       0x0221C, NULL, "MFD VC1 0 SEQPIC RECON CONTROL",       NULL},
  {"MFD_VC1_0_SEQPIC_MOTION_VECTOR_CONTROL",  0x02220, NULL, "MFD VC1 0 SEQPIC MOTION VECTOR CONTROL",  NULL},
  {"MFD_VC1_0_SEQPIC_INTENSITY_COMPENSATION", 0x02224, NULL, "MFD VC1 0 SEQPIC INTENSITY COMPENSATION", NULL},
  {"MFD_VC1_0_SEQPIC_REFERENCE_B_FRACTION",   0x02228, NULL, "MFD VC1 0 SEQPIC REFERENCE B FRACTION",   NULL},
  {"MFD_VC1_0_SEQPIC_BLOCK_CONTROL",          0x0222C, NULL, "MFD VC1 0 SEQPIC BLOCK CONTROL",   NULL},
  {"MFD_VC1_0_SEQPIC_TRANSFORM_DATA",      0x02230, NULL, "MFD VC1 0 SEQPIC TRANSFORM DATA",     NULL},
  {"MFD_VC1_0_SEQPIC_VOP_DEQUANT",         0x02234, NULL, "MFD VC1 0 SEQPIC VOP DEQUANT",        NULL},
  {"MFD_VC1_0_SEQPIC_CURR_FRAME_ID",       0x02238, NULL, "MFD VC1 0 SEQPIC CURR FRAME ID",      NULL},
  {"MFD_VC1_0_SEQPIC_CURR_DISPLAY_ID",     0x0223C, NULL, "MFD VC1 0 SEQPIC CURR DISPLAY ID",    NULL},
  {"MFD_VC1_0_SEQPIC_FWD_REF_FRAME_ID",    0x02240, NULL, "MFD VC1 0 SEQPIC FWD REF FRAME ID",   NULL},
  {"MFD_VC1_0_SEQPIC_BWD_REF_FRAME_ID",    0x02244, NULL, "MFD VC1 0 SEQPIC BWD REF FRAME ID",   NULL},
  {"MFD_VC1_0_SEQPIC_FIELD_REF_FRAME_ID",  0x02248, NULL, "MFD VC1 0 SEQPIC FIELD REF FRAME ID", NULL},
  {"MFD_VC1_0_SEQPIC_AUX_FRAME_CONTROL",   0x0224C, NULL, "MFD VC1 0 SEQPIC AUX FRAME CONTROL",  NULL},
  {"MFD_VC1_0_SEQPIC_IMAGE_STRUCTURE",     0x02250, NULL, "MFD VC1 0 SEQPIC IMAGE STRUCTURE",    NULL},
  {"MFD_VC1_0_SEQPIC_ALT_FRAME_TYPE",      0x02254, NULL, "MFD VC1 0 SEQPIC ALT FRAME TYPE",     NULL},
  {"MFD_VC1_0_MBDEC_STATUS",               0x02300, NULL, "MFD VC1 0 MBDEC STATUS",              NULL},
  {"MFD_VC1_0_MBDEC_FRAME_START",          0x02304, NULL, "MFD VC1 0 MBDEC FRAME START",         NULL},
  {"MFD_VC1_0_MBDEC_FW_DEBUG",             0x02308, NULL, "MFD VC1 0 MBDEC FW DEBUG",               NULL},
  {"MFD_VC1_0_MBDEC_MBQDEBUG",             0x0230C, NULL, "MFD VC1 0 MBDEC MBQDEBUG",               NULL},
  {"MFD_VC1_0_MBDEC_MPRDEBUG",             0x02310, NULL, "MFD VC1 0 MBDEC MPRDEBUG",               NULL},
  {"MFD_VC1_0_MBDEC_MASDEBUG",             0x02314, NULL, "MFD VC1 0 MBDEC MASDEBUG",               NULL},
  {"MFD_VC1_0_MBDEC_BPPDEBUG",             0x02318, NULL, "MFD VC1 0 MBDEC BPPDEBUG",               NULL},
  {"MFD_VC1_0_MBDEC_DPBMCDEBUG",           0x0231C, NULL, "MFD VC1 0 MBDEC DPBMCDEBUG",             NULL},
  {"MFD_VC1_0_MBDEC_GENDEBUG",             0x02320, NULL, "MFD VC1 0 MBDEC GENDEBUG",               NULL},
  {"MFD_VC1_0_FW_DEBUG",                   0x02324, NULL, "MFD VC1 0 FW DEBUG",                     NULL},
  {"MFD_VC1_0_MBDEC_ERROR_CONCEAL_CONTROL", 0x02340, NULL, "MFD VC1 0 MBDEC ERROR CONCEAL CONTROL", NULL},
  {"MFD_VC1_0_BP_CONTROL_STATUS",          0x02400, NULL, "MFD VC1 0 BP CONTROL STATUS",            NULL},
  {"MFD_VC1_0_BP_DATA_IN_STATUS",          0x02404, NULL, "MFD VC1 0 BP DATA IN STATUS",            NULL},
  {"MFD_VC1_0_BP_DATA_IN_VALUE",           0x02408, NULL, "MFD VC1 0 BP DATA IN VALUE",             NULL},
  {"MFD_VC1_0_BP_DATA_IN_POSITION_N_SIZE", 0x0240C, NULL, "MFD VC1 0 BP DATA IN POSITION N SIZE",   NULL},

  /* SIF and Stream Control */
  {"MFD_VC1_0_MBA_ENABLE",                 0x02800, NULL, "MFD VC1 0 MBA ENABLE", NULL},
  {"MFD_VC1_0_RSB_DDR_BA",                 0x02808, NULL, "MFD VC1 0 RSB DDR BA", NULL},
  /* contains 2 status bits (bs_ib_empty and frm_dec_active) */
  {"MFD_VC1_0_DEC_STATUS",                 0x0280C, NULL, "MFD VC1 0 DEC STATUS", NULL},
  {"MFD_VC1_0_SIF_SMP_RS",                 0x02810, NULL, "MFD VC1 0 SIF SMP RS", NULL},
  {"MFD_VC1_0_SIF_MSK_RS",                 0x02814, NULL, "MFD VC1 0 SIF MSK RS", NULL},
  {"MFD_VC1_0_SIF_HDAT",                   0x02818, NULL, "MFD VC1 0 SIF HDAT",   NULL},
  {"MFD_VC1_0_SIF_SDDAT",                  0x0281C, NULL, "MFD VC1 0 SIF SDDAT",  NULL},
  {"MFD_VC1_0_SIF_SMP_RC",                 0x02820, NULL, "MFD VC1 0 SIF SMP RC", NULL},
  {"MFD_VC1_0_SIF_MSK_RC",                 0x02824, NULL, "MFD VC1 0 SIF MSK RC", NULL},

  /* Stream DMA */
  {"MFD_VC1_0_SED",                        0x02900, NULL, "MFD VC1 0 SED",           NULL},
  {"MFD_VC1_0_SDEMC",                      0x02904, NULL, "MFD VC1 0 SDEMC",         NULL},
  {"MFD_VC1_0_DMA_CB_BASE",                0x02908, NULL, "MFD VC1 0 DMA CB BASE",   NULL},
  {"MFD_VC1_0_DMA_SB_RDPTR",               0x0290C, NULL, "MFD VC1 0 DMA SB RDPTR",  NULL},
  {"MFD_VC1_0_DMA_CB_SIZE",                0x02910, NULL, "MFD VC1 0 DMA CB SIZE",   NULL},
  {"MFD_VC1_0_DMA_WTRMARK",                0x02914, NULL, "MFD VC1 0 DMA WTRMARK",   NULL},
  {"MFD_VC1_0_DMA_WDT",                    0x02918, NULL, "MFD VC1 0 DMA WDT",       NULL},
  {"MFD_VC1_0_DMA_CB_RDPTR",               0x0291C, NULL, "MFD VC1 0 DMA CB RDPTR",  NULL},
  {"MFD_VC1_0_DMA_CB_WRPTR",               0x02920, NULL, "MFD VC1 0 DMA CB WRPTR",  NULL},
  {"MFD_VC1_0_DMA_SDLINK",                 0x02924, NULL, "MFD VC1 0 DMA SDLINK",    NULL},
  {"MFD_VC1_0_DMA_SDLLSA",                 0x02928, NULL, "MFD VC1 0 DMA SDLLSA",    NULL},
  {"MFD_VC1_0_DMA_SDLNDA",                 0x0292C, NULL, "MFD VC1 0 DMA SDLNDA",    NULL},
  {"MFD_VC1_0_DMA_SDLDBC",                 0x02930, NULL, "MFD VC1 0 DMA SDLDBC",    NULL},
  {"MFD_VC1_0_DMA_SDLCBC",                 0x02934, NULL, "MFD VC1 0 DMA SDLCBC",    NULL},
  {"MFD_VC1_0_DMA_SDLDC",                  0x02938, NULL, "MFD VC1 0 DMA SDLDC",     NULL},
  {"MFD_VC1_0_DMA_FIFO",                   0x0293C, NULL, "MFD VC1 0 DMA FIFO",      NULL},
  {"MFD_VC1_0_DMA_FIFO_STAT",              0x02940, NULL, "MFD VC1 0 DMA FIFO STAT", NULL},
  {"MFD_VC1_0_DMA_INT_EN",                 0x02944, NULL, "MFD VC1 0 DMA INT EN",    NULL},
  {"MFD_VC1_0_DMA_INT_STAT",               0x02948, NULL, "MFD VC1 0 DMA INT STAT",  NULL},
  {"MFD_VC1_0_DMA_BS_CNTR",                0x0294C, NULL, "MFD VC1 0 DMA BS CNTR",   NULL},

  /*  Start Code Detector  (SCD) */
  {"MFD_VC1_0_SCD_XCR",                    0x02A00, NULL, "MFD VC1 0 SCD XCR",     NULL},
  {"MFD_VC1_0_SCD_XSCR1",                  0x02A04, NULL, "MFD VC1 0 SCD XSCR1",   NULL},
  {"MFD_VC1_0_SCD_XSCR2",                  0x02A08, NULL, "MFD VC1 0 SCD XSCR2",   NULL},
  {"MFD_VC1_0_SCD_FWPREAD",                0x02A0C, NULL, "MFD VC1 0 SCD FWPREAD", NULL},
  {"MFD_VC1_0_SCD_FWCRTL",                 0x02A10, NULL, "MFD VC1 0 SCD FWCRTL",  NULL},
  {"MFD_VC1_0_SCD_FWSTAT",                 0x02A14, NULL, "MFD VC1 0 SCD FWSTAT",  NULL},
  {"MFD_VC1_0_SCD_WRCTRL",                 0x02A18, NULL, "MFD VC1 0 SCD WRCTRL",  NULL},
  {"MFD_VC1_0_SCD_WRDATA",                 0x02A1C, NULL, "MFD VC1 0 SCD WRDATA",  NULL},

  /* PIP Scaler Registers */
  {"MFD_VC1_0_PIP_CTRL",                   0x02B00, NULL, "MFD VC1 0 PIP CTRL",           NULL},
  {"MFD_VC1_0_PIP_STAT",                   0x02B04, NULL, "MFD VC1 0 PIP STAT",           NULL},
  {"MFD_VC1_0_PIP_CDYB",                   0x02B08, NULL, "MFD VC1 0 PIP CDYB",           NULL},
  {"MFD_VC1_0_PIP_CDUB",                   0x02B0C, NULL, "MFD VC1 0 PIP CDUB",           NULL},
  {"MFD_VC1_0_PIP_TST_CTRL",               0x02B10, NULL, "MFD VC1 0 PIP TST CTRL",       NULL},
  {"MFD_VC1_0_PIP_TST_WR_DATA_LO",         0x02B14, NULL, "MFD VC1 0 PIP TST WR DATA LO", NULL},
  {"MFD_VC1_0_PIP_TST_WR_DATA_HI",         0x02B18, NULL, "MFD VC1 0 PIP TST WR DATA HI", NULL},

  /* MPEG2D 0x3000 to 0x3FFF */
  {"MFD_MPG2VD_SAS",                       0x03000, NULL, "MFD MPG2VD SAS",   NULL},
  {"MFD_MPG2VD_IM",                        0x03004, NULL, "MFD MPG2VD IM",    NULL},
  {"MFD_MPG2VD_IS",                        0x03008, NULL, "MFD MPG2VD IS",    NULL},
  {"MFD_MPG2VD_DCC",                       0x0300C, NULL, "MFD MPG2VD DCC",   NULL},
  {"MFD_MPG2VD_DCSI1",                     0x03010, NULL, "MFD MPG2VD DCSI1", NULL},
  {"MFD_MPG2VD_DCSI2",                     0x03014, NULL, "MFD MPG2VD DCSI2", NULL},
  {"MFD_MPG2VD_DCPI1",                     0x03018, NULL, "MFD MPG2VD DCPI1", NULL},
  {"MFD_MPG2VD_DCGH",                      0x0301C, NULL, "MFD MPG2VD DCGH",  NULL},
  {"MFD_MPG2VD_PPE",                       0x03020, NULL, "MFD MPG2VD PPE",   NULL},
  {"MFD_MPG2VD_QMA",                       0x03024, NULL, "MFD MPG2VD QMA",   NULL},
  {"MFD_MPG2VD_QMD",                       0x03028, NULL, "MFD MPG2VD QMD",   NULL},
  {"MFD_MPG2VD_CDYB",                      0x0302C, NULL, "MFD MPG2VD CDYB",  NULL},
  {"MFD_MPG2VD_CDUB",                      0x03030, NULL, "MFD MPG2VD CDUB",  NULL},
  {"MFD_MPG2VD_BRYB",                      0x03034, NULL, "MFD MPG2VD BRYB",  NULL},
  {"MFD_MPG2VD_BRUB",                      0x03038, NULL, "MFD MPG2VD BRUB",  NULL},
  {"MFD_MPG2VD_FRYB",                      0x0303C, NULL, "MFD MPG2VD FRYB",  NULL},
  {"MFD_MPG2VD_FRUB",                      0x03040, NULL, "MFD MPG2VD FRUB",  NULL},
  {"MFD_MPG2VD_STAT",                      0x03044, NULL, "MFD MPG2VD STAT",  NULL},

  /* Deblocking Filter */
  {"MFD_MPG2VD_DBF_CTRL",                  0x03400, NULL, "MFD MPG2VD DBF CTRL", NULL},
  {"MFD_MPG2VD_DBF_YDDA",                  0x03404, NULL, "MFD MPG2VD DBF YDDA", NULL},
  {"MFD_MPG2VD_DBF_CDDA",                  0x03408, NULL, "MFD MPG2VD DBF CDDA", NULL},
  {"MFD_MPG2VD_DBF_QSMF",                  0x0340C, NULL, "MFD MPG2VD DBF QSMF", NULL},
  {"MFD_MPG2VD_DBF_IFSV",                  0x03410, NULL, "MFD MPG2VD DBF IFSV", NULL},
  {"MFD_MPG2VD_DBF_PFSV",                  0x03414, NULL, "MFD MPG2VD DBF PFSV", NULL},
  {"MFD_MPG2VD_DBF_BFSV",                  0x03418, NULL, "MFD MPG2VD DBF BFSV", NULL},

  /* SIF and Stream Control */
  {"MFD_MPG2VD_DEC_STATUS",                0x03824, NULL, "MFD MPG2VD DEC STATUS", NULL},

  /* Stream DMA */
  {"MFD_MPG2VD_SED",                       0x03900, NULL, "MFD MPG2VD SED",           NULL},
  {"MFD_MPG2VD_SDEMC",                     0x03904, NULL, "MFD MPG2VD SDEMC",         NULL},
  {"MFD_MPG2VD_DMA_CB_BASE",               0x03908, NULL, "MFD MPG2VD DMA CB BASE",   NULL},
  {"MFD_MPG2VD_DMA_SB_RDPTR",              0x0390C, NULL, "MFD MPG2VD DMA SB RDPTR",  NULL},
  {"MFD_MPG2VD_DMA_CB_SIZE",               0x03910, NULL, "MFD MPG2VD DMA CB SIZE",   NULL},
  {"MFD_MPG2VD_DMA_WTRMARK",               0x03914, NULL, "MFD MPG2VD DMA WTRMARK",   NULL},
  {"MFD_MPG2VD_DMA_WDT",                   0x03918, NULL, "MFD MPG2VD DMA WDT",       NULL},
  {"MFD_MPG2VD_DMA_CB_RDPTR",              0x0391C, NULL, "MFD MPG2VD DMA CB RDPTR",  NULL},
  {"MFD_MPG2VD_DMA_CB_WRPTR",              0x03920, NULL, "MFD MPG2VD DMA CB WRPTR",  NULL},
  {"MFD_MPG2VD_DMA_SDLINK",                0x03924, NULL, "MFD MPG2VD DMA SDLINK",    NULL},
  {"MFD_MPG2VD_DMA_SDLLSA",                0x03928, NULL, "MFD MPG2VD DMA SDLLSA",    NULL},
  {"MFD_MPG2VD_DMA_SDLNDA",                0x0392C, NULL, "MFD MPG2VD DMA SDLNDA",    NULL},
  {"MFD_MPG2VD_DMA_SDLDBC",                0x03930, NULL, "MFD MPG2VD DMA SDLDBC",    NULL},
  {"MFD_MPG2VD_DMA_SDLCBC",                0x03934, NULL, "MFD MPG2VD DMA SDLCBC",    NULL},
  {"MFD_MPG2VD_DMA_SDLDC",                 0x03938, NULL, "MFD MPG2VD DMA SDLDC",     NULL},
  {"MFD_MPG2VD_DMA_FIFO",                  0x0393C, NULL, "MFD MPG2VD DMA FIFO",      NULL},
  {"MFD_MPG2VD_DMA_FIFO_STAT",             0x03940, NULL, "MFD MPG2VD DMA FIFO STAT", NULL},
  {"MFD_MPG2VD_DMA_INT_EN",                0x03944, NULL, "MFD MPG2VD DMA INT EN",    NULL},
  {"MFD_MPG2VD_DMA_INT_STAT",              0x03948, NULL, "MFD MPG2VD DMA INT STAT",  NULL},
  {"MFD_MPG2VD_DMA_BS_CNTR",               0x0394C, NULL, "MFD MPG2VD DMA BS CNTR",   NULL},

  /* Start Code Detector (SCD) */
  {"MFD_MPG2VD_SCD_XCR",                   0x03A00, NULL, "MFD MPG2VD SCD XCR",    NULL},
  {"MFD_MPG2VD_SCD_XSCR1",                 0x03A04, NULL, "MFD MPG2VD SCD XSCR1",  NULL},
  {"MFD_MPG2VD_SCD_XSCR2",                 0x03A08, NULL, "MFD MPG2VD SCD XSCR2",  NULL},
  {"MFD_MPG2VD_SCD_FWPREA",                0x03A0C, NULL, "MFD MPG2VD SCD FWPREA", NULL},
  {"MFD_MPG2VD_SCD_FWCRTL",                0x03A10, NULL, "MFD MPG2VD SCD FWCRTL", NULL},
  {"MFD_MPG2VD_SCD_FWSTAT",                0x03A14, NULL, "MFD MPG2VD SCD FWSTAT", NULL},
  {"MFD_MPG2VD_SCD_WRCTRL",                0x03A18, NULL, "MFD MPG2VD SCD WRCTRL", NULL},
  {"MFD_MPG2VD_SCD_WRDATA",                0x03A1C, NULL, "MFD MPG2VD SCD WRDATA", NULL},

  /* PIP Scaler Registers */
  {"MFD_MPG2VD_PIP_CTRL",                  0x03B00, NULL, "MFD MPG2VD PIP CTRL",           NULL},
  {"MFD_MPG2VD_PIP_STAT",                  0x03B04, NULL, "MFD MPG2VD PIP STAT",           NULL},
  {"MFD_MPG2VD_PIP_CDYB",                  0x03B08, NULL, "MFD MPG2VD PIP CDYB",           NULL},
  {"MFD_MPG2VD_PIP_CDUB",                  0x03B0C, NULL, "MFD MPG2VD PIP CDUB",           NULL},
  {"MFD_MPG2VD_PIP_TST_CTRL",              0x03B10, NULL, "MFD MPG2VD PIP TST CTRL",       NULL},
  {"MFD_MPG2VD_PIP_TST_WR_DATA_LO",        0x03B14, NULL, "MFD MPG2VD PIP TST WR DATA LO", NULL},
  {"MFD_MPG2VD_PIP_TST_WR_DATA_HI",        0x03B18, NULL, "MFD MPG2VD PIP TST WR DATA HI", NULL},

  /*  H264 #1  (CS7051) 0x4000 to 0x4FFF */
  {"MFD_H264_1_SMP_RD",                    0x04000, NULL, "MFD H264 1 SMP RD",      NULL},
  {"MFD_H264_1_INT_EN_RD",                 0x04004, NULL, "MFD H264 1 INT EN RD",   NULL},
  {"MFD_H264_1_SMP_SET",                   0x04008, NULL, "MFD H264 1 SMP SET",     NULL},
  {"MFD_H264_1_SMP_CLR",                   0x0400C, NULL, "MFD H264 1 SMP CLR",     NULL},
  {"MFD_H264_1_SMP_MSK_SET",               0x04010, NULL, "MFD H264 1 SMP MSK SET", NULL},
  {"MFD_H264_1_SMP_MSK_CLR",               0x04014, NULL, "MFD H264 1 SMP MSK CLR", NULL},
  {"MFD_H264_1_HDAT",                      0x04018, NULL, "MFD H264 1 HDAT",        NULL},
  {"MFD_H264_1_SDDAT",                     0x0401C, NULL, "MFD H264 1 SDDAT",       NULL},
  {"MFD_H264_1_DQ_PUSH",                   0x04020, NULL, "MFD H264 1 DQ PUSH",     NULL},
  {"MFD_H264_1_DQ_STAT",                   0x04024, NULL, "MFD H264 1 DQ STAT",     NULL},
  {"MFD_H264_1_DPB_INIT",                  0x04040, NULL, "MFD H264 1 DPB INIT",    NULL},
  {"MFD_H264_1_DPB_FRM_SZ_STAT",           0x04044, NULL, "MFD H264 1 DPB FRM SZ STAT", NULL},
  {"MFD_H264_1_DPB_FRM_SZ_CTRL",           0x04048, NULL, "MFD H264 1 DPB FRM SZ CTRL", NULL},
  {"MFD_H264_1_DPB_NUMB_OVR",              0x0404C, NULL, "MFD H264 1 DPB NUMB OVR",    NULL},
  {"MFD_H264_1_DPB_FS_VALUES",             0x04050, NULL, "MFD H264 1 DPB FS VALUES",   NULL},
  {"MFD_H264_1_DPB_FS_OFFSET",             0x04054, NULL, "MFD H264 1 DPB FS OFFSET",   NULL},
  {"MFD_H264_1_FSD",                       0x04058, NULL, "MFD H264 1 FSD",             NULL},
  {"MFD_H264_1_DANGLING_FIELD",            0x0405C, NULL, "MFD H264 1 DANGLING FIELD",  NULL},
  {"MFD_H264_1_DISP_TAG",                  0x04060, NULL, "MFD H264 1 DISP TAG",            NULL},
  {"MFD_H264_1_DPB_MBI_ADDR_LUT_WR",       0x0407C, NULL, "MFD H264 1 DPB MBI ADDR LUT WR", NULL},
  {"MFD_H264_1_DPB_UV_ADDR_LUT_WR",        0x04080, NULL, "MFD H264 1 DPB UV ADDR LUT WR",  NULL},
  {"MFD_H264_1_DPB_Y_ADDR_LUT_WR",         0x04084, NULL, "MFD H264 1 DPB Y ADDR LUT WR",   NULL},
  {"MFD_H264_1_FRAME_CYC_COUNT",           0x04090, NULL, "MFD H264 1 FRAME CYC COUNT",     NULL},
  {"MFD_H264_1_IB_WAIT_COUNT",             0x04094, NULL, "MFD H264 1 IB WAIT COUNT",       NULL},
  {"MFD_H264_1_RBSP_COUNT",                0x04098, NULL, "MFD H264 1 RBSP COUNT",          NULL},
  {"MFD_H264_1_MPR_COUNT",                 0x0409C, NULL, "MFD H264 1 MPR COUNT",           NULL},
  {"MFD_H264_1_CORE_CONFIG",               0x040A0, NULL, "MFD H264 1 CORE CONFIG",         NULL},
  {"MFD_H264_1_INT_CTRL",                  0x040C0, NULL, "MFD H264 1 INT CTRL",            NULL},
  {"MFD_H264_1_INT_STAT",                  0x040C4, NULL, "MFD H264 1 INT STAT",            NULL},
  {"MFD_H264_1_SOFT_RST",                  0x040FC, NULL, "MFD H264 1 SOFT RST",            NULL},
  {"MFD_H264_1_BSD_PSR_STAT",              0x04100, NULL, "MFD H264 1 BSD PSR STAT",        NULL},
  {"MFD_H264_1_BSD_STAT",                  0x04104, NULL, "MFD H264 1 BSD STAT",            NULL},
  {"MFD_H264_1_BSD_RBSP_CTRL",             0x04110, NULL, "MFD H264 1 BSD RBSP CTRL",       NULL},
  {"MFD_H264_1_BSD_DATA",                  0x04114, NULL, "MFD H264 1 BSD DATA",            NULL},
  {"MFD_H264_1_BSD_NAL_TYPE",              0x04118, NULL, "MFD H264 1 BSD NAL TYPE",        NULL},
  {"MFD_H264_1_BSD_BBB_STAT",              0x0411C, NULL, "MFD H264 1 BSD BBB STAT",        NULL},
  {"MFD_H264_1_BSD_GUE_DEC",               0x04120, NULL, "MFD H264 1 BSD GUE DEC",         NULL},
  {"MFD_H264_1_BSD_GSE_DEC",               0x04124, NULL, "MFD H264 1 BSD GSE DEC",         NULL},
  {"MFD_H264_1_BSD_EXP_GME_INTRA",         0x04128, NULL, "MFD H264 1 BSD EXP GME_INTRA",   NULL},
  {"MFD_H264_1_BSD_EXP_GME_INTER",         0x04138, NULL, "MFD H264 1 BSD EXP GME_INTER",   NULL},
  {"MFD_H264_1_BSD_IMG_INIT",              0x04140, NULL, "MFD H264 1 BSD IMG INIT",        NULL},
  {"MFD_H264_1_BSD_SLICE_P1",              0x04150, NULL, "MFD H264 1 BSD SLICE P1",        NULL},
  {"MFD_H264_1_BSD_SLICE_P2",              0x04154, NULL, "MFD H264 1 BSD SLICE P2",        NULL},
  {"MFD_H264_1_BSD_SLICE_START",           0x04158, NULL, "MFD H264 1 BSD SLICE START",     NULL},
  {"MFD_H264_1_BSD_MB_CTRL",               0x0415C, NULL, "MFD H264 1 BSD MB CTRL",         NULL},
  {"MFD_H264_1_BSD_QM_DEC_START",          0x04160, NULL, "MFD H264 1 BSD QM DEC START",    NULL},
  {"MFD_H264_1_BSD_DEC_STAT",              0x04164, NULL, "MFD H264 1 BSD DEC STAT",        NULL},
  {"MFD_H264_1_BSD_QM_LOAD_START",         0x04168, NULL, "MFD H264 1 BSD QM LOAD START",   NULL},
  {"MFD_H264_1_BSD_QM_LOAD_VALUE",         0x0416C, NULL, "MFD H264 1 BSD QM LOAD VALUE",   NULL},
  {"MFD_H264_1_BSD_BYTE_ALIGN",            0x0417C, NULL, "MFD H264 1 BSD BYTE ALIGN", NULL},
  {"MFD_H264_1_BSD_BBB_TRAIL",             0x04180, NULL, "MFD H264 1 BSD BBB TRAIL",  NULL},
  {"MFD_H264_1_BSD_GET_BITS01",            0x04184, NULL, "MFD H264 1 BSD GET BITS01", NULL},
  {"MFD_H264_1_BSD_GET_BITS02",            0x04188, NULL, "MFD H264 1 BSD GET BITS02", NULL},
  {"MFD_H264_1_BSD_GET_BITS03",            0x0418C, NULL, "MFD H264 1 BSD GET BITS03", NULL},
  {"MFD_H264_1_BSD_GET_BITS04",            0x04190, NULL, "MFD H264 1 BSD GET BITS04", NULL},
  {"MFD_H264_1_BSD_GET_BITS05",            0x04194, NULL, "MFD H264 1 BSD GET BITS05", NULL},
  {"MFD_H264_1_BSD_GET_BITS06",            0x04198, NULL, "MFD H264 1 BSD GET BITS06", NULL},
  {"MFD_H264_1_BSD_GET_BITS07",            0x0419C, NULL, "MFD H264 1 BSD GET BITS07", NULL},
  {"MFD_H264_1_BSD_GET_BITS08",            0x041A0, NULL, "MFD H264 1 BSD GET BITS08", NULL},
  {"MFD_H264_1_BSD_GET_BITS09",            0x041A4, NULL, "MFD H264 1 BSD GET BITS09", NULL},
  {"MFD_H264_1_BSD_GET_BITS10",            0x041A8, NULL, "MFD H264 1 BSD GET BITS10", NULL},
  {"MFD_H264_1_BSD_GET_BITS11",            0x041AC, NULL, "MFD H264 1 BSD GET BITS11", NULL},
  {"MFD_H264_1_BSD_GET_BITS12",            0x041B0, NULL, "MFD H264 1 BSD GET BITS12", NULL},
  {"MFD_H264_1_BSD_GET_BITS13",            0x041B4, NULL, "MFD H264 1 BSD GET BITS13", NULL},
  {"MFD_H264_1_BSD_GET_BITS14",            0x041B8, NULL, "MFD H264 1 BSD GET BITS14", NULL},
  {"MFD_H264_1_BSD_GET_BITS15",            0x041BC, NULL, "MFD H264 1 BSD GET BITS15", NULL},
  {"MFD_H264_1_BSD_GET_BITS16",            0x041C0, NULL, "MFD H264 1 BSD GET BITS16", NULL},
  {"MFD_H264_1_BSD_GET_BITS17",            0x041C4, NULL, "MFD H264 1 BSD GET BITS17", NULL},
  {"MFD_H264_1_BSD_GET_BITS18",            0x041C8, NULL, "MFD H264 1 BSD GET BITS18", NULL},
  {"MFD_H264_1_BSD_GET_BITS19",            0x041CC, NULL, "MFD H264 1 BSD GET BITS19", NULL},
  {"MFD_H264_1_BSD_GET_BITS20",            0x041D0, NULL, "MFD H264 1 BSD GET BITS20", NULL},
  {"MFD_H264_1_BSD_GET_BITS21",            0x041D4, NULL, "MFD H264 1 BSD GET BITS21", NULL},
  {"MFD_H264_1_BSD_GET_BITS22",            0x041D8, NULL, "MFD H264 1 BSD GET BITS22", NULL},
  {"MFD_H264_1_BSD_GET_BITS23",            0x041DC, NULL, "MFD H264 1 BSD GET BITS23", NULL},
  {"MFD_H264_1_BSD_GET_BITS24",            0x041E0, NULL, "MFD H264 1 BSD GET BITS24", NULL},
  {"MFD_H264_1_BSD_GET_BITS25",            0x041E4, NULL, "MFD H264 1 BSD GET BITS25", NULL},
  {"MFD_H264_1_BSD_GET_BITS26",            0x041E8, NULL, "MFD H264 1 BSD GET BITS26", NULL},
  {"MFD_H264_1_BSD_GET_BITS27",            0x041EC, NULL, "MFD H264 1 BSD GET BITS27", NULL},
  {"MFD_H264_1_BSD_GET_BITS28",            0x041F0, NULL, "MFD H264 1 BSD GET BITS28", NULL},
  {"MFD_H264_1_BSD_GET_BITS29",            0x041F4, NULL, "MFD H264 1 BSD GET BITS29", NULL},
  {"MFD_H264_1_BSD_GET_BITS30",            0x041F8, NULL, "MFD H264 1 BSD GET BITS30", NULL},
  {"MFD_H264_1_BSD_GET_BITS31",            0x041FC, NULL, "MFD H264 1 BSD GET BITS31", NULL},
  {"MFD_H264_1_MPR_TF_POC",                0x04300, NULL, "MFD H264 1 MPR TF POC", NULL},
  {"MFD_H264_1_MPR_BF_POC",                0x04304, NULL, "MFD H264 1 MPR BF POC", NULL},
  {"MFD_H264_1_MPR_LST00",                 0x04380, NULL, "MFD H264 1 MPR LST00",  NULL},
  {"MFD_H264_1_MPR_LST01",                 0x04384, NULL, "MFD H264 1 MPR LST01",  NULL},
  {"MFD_H264_1_MPR_LST02",                 0x04388, NULL, "MFD H264 1 MPR LST02",  NULL},
  {"MFD_H264_1_MPR_LST03",                 0x0438C, NULL, "MFD H264 1 MPR LST03",  NULL},
  {"MFD_H264_1_MPR_LST04",                 0x04390, NULL, "MFD H264 1 MPR LST04",  NULL},
  {"MFD_H264_1_MPR_LST05",                 0x04394, NULL, "MFD H264 1 MPR LST05",  NULL},
  {"MFD_H264_1_MPR_LST06",                 0x04398, NULL, "MFD H264 1 MPR LST06",  NULL},
  {"MFD_H264_1_MPR_LST07",                 0x0439C, NULL, "MFD H264 1 MPR LST07",  NULL},
  {"MFD_H264_1_MPR_LST08",                 0x043A0, NULL, "MFD H264 1 MPR LST08",  NULL},
  {"MFD_H264_1_MPR_LST09",                 0x043A4, NULL, "MFD H264 1 MPR LST09",  NULL},
  {"MFD_H264_1_MPR_LST10",                 0x043A8, NULL, "MFD H264 1 MPR LST10",  NULL},
  {"MFD_H264_1_MPR_LST11",                 0x043AC, NULL, "MFD H264 1 MPR LST11",  NULL},
  {"MFD_H264_1_MPR_LST12",                 0x043B0, NULL, "MFD H264 1 MPR LST12",  NULL},
  {"MFD_H264_1_MPR_LST13",                 0x043B4, NULL, "MFD H264 1 MPR LST13",  NULL},
  {"MFD_H264_1_MPR_LST14",                 0x043B8, NULL, "MFD H264 1 MPR LST14",  NULL},
  {"MFD_H264_1_MPR_LST15",                 0x043BC, NULL, "MFD H264 1 MPR LST15",  NULL},

  /* SIF and Stream Control */
  {"MFD_H264_1_RSB_DDR_BA",                0x04808, NULL, "MFD H264 1 RSB DDR BA", NULL},
  /* contains 2 status bits (bs_ib_empty and frm_dec_active) */
  {"MFD_H264_1_DEC_STATUS",                0x0480C, NULL, "MFD H264 1 DEC STATUS", NULL},
  {"MFD_H264_1_SIF_SMP_RS",                0x04810, NULL, "MFD H264 1 SIF SMP RS", NULL},
  {"MFD_H264_1_SIF_MSK_RS",                0x04814, NULL, "MFD H264 1 SIF MSK RS", NULL},
  {"MFD_H264_1_SIF_HDAT",                  0x04818, NULL, "MFD H264 1 SIF HDAT",   NULL},
  {"MFD_H264_1_SIF_SDDAT",                 0x0481C, NULL, "MFD H264 1 SIF SDDAT",  NULL},
  {"MFD_H264_1_SIF_SMP_RC",                0x04820, NULL, "MFD H264 1 SIF SMP RC", NULL},
  {"MFD_H264_1_SIF_MSK_RC",                0x04824, NULL, "MFD H264 1 SIF MSK RC", NULL},

  /* Stream DMA */
  {"MFD_H264_1_SED",                       0x04900, NULL, "MFD H264 1 SED",           NULL},
  {"MFD_H264_1_SDEMC",                     0x04904, NULL, "MFD H264 1 SDEMC",         NULL},
  {"MFD_H264_1_DMA_CB_BASE",               0x04908, NULL, "MFD H264 1 DMA CB BASE",   NULL},
  {"MFD_H264_1_DMA_SB_RDPTR",              0x0490C, NULL, "MFD H264 1 DMA SB RDPTR",  NULL},
  {"MFD_H264_1_DMA_CB_SIZE",               0x04910, NULL, "MFD H264 1 DMA CB SIZE",   NULL},
  {"MFD_H264_1_DMA_WTRMARK",               0x04914, NULL, "MFD H264 1 DMA WTRMARK",   NULL},
  {"MFD_H264_1_DMA_WDT",                   0x04918, NULL, "MFD H264 1 DMA WDT",       NULL},
  {"MFD_H264_1_DMA_CB_RDPTR",              0x0491C, NULL, "MFD H264 1 DMA CB RDPTR",  NULL},
  {"MFD_H264_1_DMA_CB_WRPTR",              0x04920, NULL, "MFD H264 1 DMA CB WRPTR",  NULL},
  {"MFD_H264_1_DMA_SDLINK",                0x04924, NULL, "MFD H264 1 DMA SDLINK",    NULL},
  {"MFD_H264_1_DMA_SDLLSA",                0x04928, NULL, "MFD H264 1 DMA SDLLSA",    NULL},
  {"MFD_H264_1_DMA_SDLNDA",                0x0492C, NULL, "MFD H264 1 DMA SDLNDA",    NULL},
  {"MFD_H264_1_DMA_SDLDBC",                0x04930, NULL, "MFD H264 1 DMA SDLDBC",    NULL},
  {"MFD_H264_1_DMA_SDLCBC",                0x04934, NULL, "MFD H264 1 DMA SDLCBC",    NULL},
  {"MFD_H264_1_DMA_SDLDC",                 0x04938, NULL, "MFD H264 1 DMA SDLDC",     NULL},
  {"MFD_H264_1_DMA_FIFO",                  0x0493C, NULL, "MFD H264 1 DMA FIFO",      NULL},
  {"MFD_H264_1_DMA_FIFO_STAT",             0x04940, NULL, "MFD H264 1 DMA FIFO STAT", NULL},
  {"MFD_H264_1_DMA_INT_EN",                0x04944, NULL, "MFD H264 1 DMA INT EN",    NULL},
  {"MFD_H264_1_DMA_INT_STAT",              0x04948, NULL, "MFD H264 1 DMA INT STAT",  NULL},
  {"MFD_H264_1_DMA_BS_CNTR",               0x0494C, NULL, "MFD H264 1 DMA BS CNTR",   NULL},
  /* Start Code Detector (SCD) */
  {"MFD_H264_1_SCD_XCR",                   0x04A00, NULL, "MFD H264 1 SCD XCR",            NULL},
  {"MFD_H264_1_SCD_XSCR1",                 0x04A04, NULL, "MFD H264 1 SCD XSCR1",          NULL},
  {"MFD_H264_1_SCD_XSCR2",                 0x04A08, NULL, "MFD H264 1 SCD XSCR2",          NULL},
  {"MFD_H264_1_SCD_FWPREAD",               0x04A0C, NULL, "MFD H264 1 SCD FWPREAD",        NULL},
  {"MFD_H264_1_SCD_FWCRTL",                0x04A10, NULL, "MFD H264 1 SCD FWCRTL",         NULL},
  {"MFD_H264_1_SCD_FWSTAT",                0x04A14, NULL, "MFD H264 1 SCD FWSTAT",         NULL},
  {"MFD_H264_1_SCD_WRCTRL",                0x04A18, NULL, "MFD H264 1 SCD WRCTRL",         NULL},
  {"MFD_H264_1_SCD_WRDATA",                0x04A1C, NULL, "MFD H264 1 SCD WRDATA",         NULL},

  /* PIP Scaler Registers */
  {"MFD_H264_1_PIP_CTRL",                  0x04B00, NULL, "MFD H264 1 PIP CTRL",           NULL},
  {"MFD_H264_1_PIP_STAT",                  0x04B04, NULL, "MFD H264 1 PIP STAT",           NULL},
  {"MFD_H264_1_PIP_CDYB",                  0x04B08, NULL, "MFD H264 1 PIP CDYB",           NULL},
  {"MFD_H264_1_PIP_CDUB",                  0x04B0C, NULL, "MFD H264 1 PIP CDUB",           NULL},
  {"MFD_H264_1_PIP_TST_CTRL",              0x04B10, NULL, "MFD H264 1 PIP TST CTRL",       NULL},
  {"MFD_H264_1_PIP_TST_WR_DATA_LO",        0x04B14, NULL, "MFD H264 1 PIP TST WR DATA LO", NULL},
  {"MFD_H264_1_PIP_TST_WR_DATA_HI",        0x04B18, NULL, "MFD H264 1 PIP TST WR DATA HI", NULL},

  /* VC1 #0 (CS7150) 0x5000 to 0x5FFF */
  {"MFD_VC1_1_SMP_RD",                     0x05000, NULL, "MFD VC1 1 SMP RD",             NULL},
  {"MFD_VC1_1_INT_EN_RD",                  0x05004, NULL, "MFD VC1 1 INT EN RD",          NULL},
  {"MFD_VC1_1_SMP_SET",                    0x05008, NULL, "MFD VC1 1 SMP SET",            NULL},
  {"MFD_VC1_1_SMP_CLR",                    0x0500C, NULL, "MFD VC1 1 SMP CLR",            NULL},
  {"MFD_VC1_1_SMP_MSK_SET",                0x05010, NULL, "MFD VC1 1 SMP MSK SET",        NULL},
  {"MFD_VC1_1_SMP_MSK_CLR",                0x05014, NULL, "MFD VC1 1 SMP MSK CLR",        NULL},
  {"MFD_VC1_1_HDAT",                       0x05018, NULL, "MFD VC1 1 HDAT",               NULL},
  {"MFD_VC1_1_SDDAT",                      0x0501C, NULL, "MFD VC1 1 SDDAT",              NULL},
  {"MFD_VC1_1_DQ_PUSH",                    0x05020, NULL, "MFD VC1 1 DQ PUSH",            NULL},
  {"MFD_VC1_1_DQ_STAT",                    0x05024, NULL, "MFD VC1 1 DQ STAT",            NULL},
  {"MFD_VC1_1_DPB_INIT",                   0x05040, NULL, "MFD VC1 1 DPB INIT",           NULL},
  {"MFD_VC1_1_DPB_FRM_SZ_STAT",            0x05044, NULL, "MFD VC1 1 DPB FRM SZ STAT",    NULL},
  {"MFD_VC1_1_DPB_FRM_SZ_CTRL",            0x05048, NULL, "MFD VC1 1 DPB FRM SZ CTRL",    NULL},
  {"MFD_VC1_1_DPB_NUMB_OVR",               0x0504C, NULL, "MFD VC1 1 DPB NUMB OVR",       NULL},
  {"MFD_VC1_1_DPB_FS_SETTING",             0x05050, NULL, "MFD VC1 1 DPB FS SETTING",     NULL},
  {"MFD_VC1_1_DPB_LOAD_OFFSET",            0x05054, NULL, "MFD VC1 1 DPB LOAD OFFSET",    NULL},
  {"MFD_VC1_1_FSD",                        0x05058, NULL, "MFD VC1 1 FSD",                NULL},
  {"MFD_VC1_1_DANGLING_FIELD",             0x0505C, NULL, "MFD VC1 1 DANGLING FIELD",     NULL},
  {"MFD_VC1_1_DISP_TAG",                   0x05060, NULL, "MFD VC1 1 DISP TAG",           NULL},
  {"MFD_VC1_1_DPB_UV_ADDR_LUT_WR",         0x02080, NULL, "MFD VC1 1 DPB UV ADDR LUT WR", NULL},
  {"MFD_VC1_1_DPB_Y_ADDR_LUT_WR",          0x02084, NULL, "MFD VC1 1 DPB Y ADDR LUT WR",  NULL},
  {"MFD_VC1_1_MPS_RD_BYTE_COUNT",          0x05088, NULL, "MFD VC1 1 MPS RD BYTE COUNT",  NULL},
  {"MFD_VC1_1_SLC_IN_FRM_COUNT",           0x0508C, NULL, "MFD VC1 1 SLC IN FRM COUNT",   NULL},
  {"MFD_VC1_1_FRAME_CYC_COUNT",            0x05090, NULL, "MFD VC1 1 FRAME CYC COUNT",    NULL},
  {"MFD_VC1_1_IB_WAIT_COUNT",              0x05094, NULL, "MFD VC1 1 IB WAIT COUNT",      NULL},
  {"MFD_VC1_1_RBSP_COUNT",                 0x05098, NULL, "MFD VC1 1 RBSP COUNT",     NULL},
  {"MFD_VC1_1_BS2RBSP_STATUS",             0x0509C, NULL, "MFD VC1 1 BS2RBSP STATUS", NULL},
  {"MFD_VC1_1_CORE_CONFIG",                0x050A0, NULL, "MFD VC1 1 CORE CONFIG",    NULL},
  {"MFD_VC1_1_RBSP_CTRL",                  0x050A4, NULL, "MFD VC1 1 RBSP CTRL",      NULL},
  {"MFD_VC1_1_INT_CTRL",                   0x050C0, NULL, "MFD VC1 1 INT CTRL",       NULL},
  {"MFD_VC1_1_INT_STAT",                   0x050C4, NULL, "MFD VC1 1 INT STAT",       NULL},
  {"MFD_VC1_1_SOFT_RST",                   0x050C8, NULL, "MFD VC1 1 SOFT RST",       NULL},
  {"MFD_VC1_1_BSP_BYTE_ALIGN",             0x05100, NULL, "MFD VC1 1 BSP BYTE ALIGN", NULL},
  {"MFD_VC1_1_BSP_GET_BITS01",             0x05104, NULL, "MFD VC1 1 BSP GET BITS01", NULL},
  {"MFD_VC1_1_BSP_GET_BITS02",             0x05108, NULL, "MFD VC1 1 BSP GET BITS02", NULL},
  {"MFD_VC1_1_BSP_GET_BITS03",             0x0510C, NULL, "MFD VC1 1 BSP GET BITS03", NULL},
  {"MFD_VC1_1_BSP_GET_BITS04",             0x05110, NULL, "MFD VC1 1 BSP GET BITS04", NULL},
  {"MFD_VC1_1_BSP_GET_BITS05",             0x05114, NULL, "MFD VC1 1 BSP GET BITS05", NULL},
  {"MFD_VC1_1_BSP_GET_BITS06",             0x05118, NULL, "MFD VC1 1 BSP GET BITS06", NULL},
  {"MFD_VC1_1_BSP_GET_BITS07",             0x0511C, NULL, "MFD VC1 1 BSP GET BITS07", NULL},
  {"MFD_VC1_1_BSP_GET_BITS08",             0x05120, NULL, "MFD VC1 1 BSP GET BITS08", NULL},
  {"MFD_VC1_1_BSP_GET_BITS09",             0x05124, NULL, "MFD VC1 1 BSP GET BITS09", NULL},
  {"MFD_VC1_1_BSP_GET_BITS10",             0x05128, NULL, "MFD VC1 1 BSP GET BITS10", NULL},
  {"MFD_VC1_1_BSP_GET_BITS11",             0x0512C, NULL, "MFD VC1 1 BSP GET BITS11", NULL},
  {"MFD_VC1_1_BSP_GET_BITS12",             0x05130, NULL, "MFD VC1 1 BSP GET BITS12", NULL},
  {"MFD_VC1_1_BSP_GET_BITS13",             0x05134, NULL, "MFD VC1 1 BSP GET BITS13", NULL},
  {"MFD_VC1_1_BSP_GET_BITS14",             0x05138, NULL, "MFD VC1 1 BSP GET BITS14", NULL},
  {"MFD_VC1_1_BSP_GET_BITS15",             0x0513C, NULL, "MFD VC1 1 BSP GET BITS15", NULL},
  {"MFD_VC1_1_BSP_GET_BITS16",             0x05140, NULL, "MFD VC1 1 BSP GET BITS16", NULL},
  {"MFD_VC1_1_BSP_GET_BITS17",             0x05144, NULL, "MFD VC1 1 BSP GET BITS17", NULL},
  {"MFD_VC1_1_BSP_GET_BITS18",             0x05148, NULL, "MFD VC1 1 BSP GET BITS18", NULL},
  {"MFD_VC1_1_BSP_GET_BITS19",             0x0514C, NULL, "MFD VC1 1 BSP GET BITS19", NULL},
  {"MFD_VC1_1_BSP_GET_BITS20",             0x05150, NULL, "MFD VC1 1 BSP GET BITS20", NULL},
  {"MFD_VC1_1_BSP_GET_BITS21",             0x05154, NULL, "MFD VC1 1 BSP GET BITS21", NULL},
  {"MFD_VC1_1_BSP_GET_BITS22",             0x05158, NULL, "MFD VC1 1 BSP GET BITS22", NULL},
  {"MFD_VC1_1_BSP_GET_BITS23",             0x0515C, NULL, "MFD VC1 1 BSP GET BITS23", NULL},
  {"MFD_VC1_1_BSP_GET_BITS24",             0x05160, NULL, "MFD VC1 1 BSP GET BITS24", NULL},
  {"MFD_VC1_1_BSP_GET_BITS25",             0x05164, NULL, "MFD VC1 1 BSP GET BITS25", NULL},
  {"MFD_VC1_1_BSP_GET_BITS26",             0x05168, NULL, "MFD VC1 1 BSP GET BITS26", NULL},
  {"MFD_VC1_1_BSP_GET_BITS27",             0x0516C, NULL, "MFD VC1 1 BSP GET BITS27", NULL},
  {"MFD_VC1_1_BSP_GET_BITS28",             0x05170, NULL, "MFD VC1 1 BSP GET BITS28", NULL},
  {"MFD_VC1_1_BSP_GET_BITS29",             0x05174, NULL, "MFD VC1 1 BSP GET BITS29", NULL},
  {"MFD_VC1_1_BSP_GET_BITS30",             0x05178, NULL, "MFD VC1 1 BSP GET BITS30", NULL},
  {"MFD_VC1_1_BSP_GET_BITS31",             0x0517C, NULL, "MFD VC1 1 BSP GET BITS31", NULL},
  {"MFD_VC1_1_BSP_STATUS",                 0x05180, NULL, "MFD VC1 1 BSP STATUS",     NULL},
  {"MFD_VC1_1_BSP_CTRL",                   0x05184, NULL, "MFD VC1 1 BSP CTRL",       NULL},
  {"MFD_VC1_1_BSP_SHOW_BITS",              0x05188, NULL, "MFD VC1 1 BSP SHOW BITS",  NULL},
  {"MFD_VC1_1_BSP_SHOW_BITS_FLPD",         0x0518C, NULL, "MFD VC1 1 BSP SHOW BITS FLPD",   NULL},
  {"MFD_VC1_1_BSP_IGNORE_BBB_LEVEL",       0x05190, NULL, "MFD VC1 1 BSP IGNORE BBB LEVEL", NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_PTYPE",       0x051C0, NULL, "MFD VC1 1 BSP HEADER VLC PTYPE", NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_FTYPE",       0x051C4, NULL, "MFD VC1 1 BSP HEADER VLC FTYPE", NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_MVRANGE",     0x051C8, NULL, "MFD VC1 1 BSP HEADER VLC MVRANGE",     NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_MVMODE",      0x051CC, NULL, "MFD VC1 1 BSP HEADER VLC MVMODE",      NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_MVMODE2",     0x051D0, NULL, "MFD VC1 1 BSP HEADER VLC MVMODE2",     NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_DMVRANGE",    0x051D4, NULL, "MFD VC1 1 BSP HEADER VLC DMVRANGE",    NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_BPPMODE",     0x051D8, NULL, "MFD VC1 1 BSP HEADER VLC BPPMODE",     NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_BPPVLC2",     0x051DC, NULL, "MFD VC1 1 BSP HEADER VLC BPPVLC2",     NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_BPPVLC6",     0x051E0, NULL, "MFD VC1 1 BSP HEADER VLC BPPVLC6",     NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_BFRACT",      0x051E4, NULL, "MFD VC1 1 BSP HEADER VLC BFRACT",      NULL},
  {"MFD_VC1_1_BSP_HEADER_VLC_REFDIST",     0x051E8, NULL, "MFD VC1 1 BSP HEADER VLC REFDIST",     NULL},
  {"MFD_VC1_1_SEQPIC_GENERAL_CORE_CONFIG", 0x05200, NULL, "MFD VC1 1 SEQPIC GENERAL CORE CONFIG", NULL},
  {"MFD_VC1_1_SEQPIC_STREAM_FORMAT_1",     0x05204, NULL, "MFD VC1 1 SEQPIC STREAM FORMAT 1",     NULL},
  {"MFD_VC1_1_SEQPIC_CODED_SIZE",          0x05208, NULL, "MFD VC1 1 SEQPIC CODED SIZE",          NULL},
  {"MFD_VC1_1_SEQPIC_STREAM_FORMAT_2",     0x0520C, NULL, "MFD VC1 1 SEQPIC STREAM FORMAT 2",     NULL},
  {"MFD_VC1_1_SEQPIC_ENTRY_POINT_1",       0x05210, NULL, "MFD VC1 1 SEQPIC ENTRY POINT 1",       NULL},
  {"MFD_VC1_1_SEQPIC_RANGE_MAP",           0x05214, NULL, "MFD VC1 1 SEQPIC RANGE MAP",           NULL},
  {"MFD_VC1_1_SEQPIC_FRAME_TYPE",          0x05218, NULL, "MFD VC1 1 SEQPIC FRAME TYPE",          NULL},
  {"MFD_VC1_1_SEQPIC_RECON_CONTROL",       0x0521C, NULL, "MFD VC1 1 SEQPIC RECON CONTROL",       NULL},
  {"MFD_VC1_1_SEQPIC_MOTION_VECTOR_CONTROL",  0x05220, NULL, "MFD VC1 1 SEQPIC MOTION VECTOR CONTROL",  NULL},
  {"MFD_VC1_1_SEQPIC_INTENSITY_COMPENSATION", 0x05224, NULL, "MFD VC1 1 SEQPIC INTENSITY COMPENSATION", NULL},
  {"MFD_VC1_1_SEQPIC_REFERENCE_B_FRACTION", 0x05228, NULL, "MFD VC1 1 SEQPIC REFERENCE B FRACTION", NULL},
  {"MFD_VC1_1_SEQPIC_BLOCK_CONTROL",        0x0522C, NULL, "MFD VC1 1 SEQPIC BLOCK CONTROL",        NULL},
  {"MFD_VC1_1_SEQPIC_TRANSFORM_DATA",       0x05230, NULL, "MFD VC1 1 SEQPIC TRANSFORM DATA",       NULL},
  {"MFD_VC1_1_SEQPIC_VOP_DEQUANT",          0x05234, NULL, "MFD VC1 1 SEQPIC VOP DEQUANT",          NULL},
  {"MFD_VC1_1_SEQPIC_CURR_FRAME_ID",        0x05238, NULL, "MFD VC1 1 SEQPIC CURR FRAME ID",        NULL},
  {"MFD_VC1_1_SEQPIC_CURR_DISPLAY_ID",      0x0523C, NULL, "MFD VC1 1 SEQPIC CURR DISPLAY ID",      NULL},
  {"MFD_VC1_1_SEQPIC_FWD_REF_FRAME_ID",     0x05240, NULL, "MFD VC1 1 SEQPIC FWD REF FRAME ID",     NULL},
  {"MFD_VC1_1_SEQPIC_BWD_REF_FRAME_ID",     0x05244, NULL, "MFD VC1 1 SEQPIC BWD REF FRAME ID",     NULL},
  {"MFD_VC1_1_SEQPIC_FIELD_REF_FRAME_ID",   0x05248, NULL, "MFD VC1 1 SEQPIC FIELD REF FRAME ID",   NULL},
  {"MFD_VC1_1_SEQPIC_AUX_FRAME_CONTROL",    0x0524C, NULL, "MFD VC1 1 SEQPIC AUX FRAME CONTROL",    NULL},
  {"MFD_VC1_1_SEQPIC_IMAGE_STRUCTURE",      0x05250, NULL, "MFD VC1 1 SEQPIC IMAGE STRUCTURE",      NULL},
  {"MFD_VC1_1_SEQPIC_ALT_FRAME_TYPE",       0x05254, NULL, "MFD VC1 1 SEQPIC ALT FRAME TYPE",       NULL},
  {"MFD_VC1_1_MBDEC_STATUS",                0x05300, NULL, "MFD VC1 1 MBDEC STATUS",                NULL},
  {"MFD_VC1_1_MBDEC_FRAME_START",           0x05304, NULL, "MFD VC1 1 MBDEC FRAME START",           NULL},
  {"MFD_VC1_1_MBDEC_FW_DEBUG",              0x05308, NULL, "MFD VC1 1 MBDEC FW DEBUG",              NULL},
  {"MFD_VC1_1_MBDEC_MBQDEBUG",              0x0530C, NULL, "MFD VC1 1 MBDEC MBQDEBUG",              NULL},
  {"MFD_VC1_1_MBDEC_MPRDEBUG",              0x05310, NULL, "MFD VC1 1 MBDEC MPRDEBUG",              NULL},
  {"MFD_VC1_1_MBDEC_MASDEBUG",              0x05314, NULL, "MFD VC1 1 MBDEC MASDEBUG",              NULL},
  {"MFD_VC1_1_MBDEC_BPPDEBUG",              0x05318, NULL, "MFD VC1 1 MBDEC BPPDEBUG",              NULL},
  {"MFD_VC1_1_MBDEC_DPBMCDEBUG",            0x0531C, NULL, "MFD VC1 1 MBDEC DPBMCDEBUG",            NULL},
  {"MFD_VC1_1_MBDEC_GENDEBUG",              0x05320, NULL, "MFD VC1 1 MBDEC GENDEBUG",              NULL},
  {"MFD_VC1_1_FW_DEBUG",                    0x05324, NULL, "MFD VC1 1 FW DEBUG",                    NULL},
  {"MFD_VC1_1_MBDEC_ERROR_CONCEAL_CONTROL", 0x05340, NULL, "MFD VC1 1 MBDEC ERROR CONCEAL CONTROL", NULL},
  {"MFD_VC1_1_BP_CONTROL_STATUS",           0x05400, NULL, "MFD VC1 1 BP CONTROL STATUS",           NULL},
  {"MFD_VC1_1_BP_DATA_IN_STATUS",           0x05404, NULL, "MFD VC1 1 BP DATA IN STATUS",           NULL},
  {"MFD_VC1_1_BP_DATA_IN_VALUE",            0x05408, NULL, "MFD VC1 1 BP DATA IN VALUE",            NULL},
  {"MFD_VC1_1_BP_DATA_IN_POSITION_N_SIZE",  0x0540C, NULL, "MFD VC1 1 BP DATA IN POSITION N SIZE",  NULL},

  /* SIF and Stream Control */
  {"MFD_VC1_1_MBA_ENABLE",                  0x05800, NULL, "MFD VC1 1 MBA ENABLE", NULL},
  {"MFD_VC1_1_RSB_DDR_BA",                  0x05808, NULL, "MFD VC1 1 RSB DDR BA", NULL},
  /* contains 2 status bits (bs_ib_empty and frm_dec_active) */
  {"MFD_VC1_1_DEC_STATUS",                  0x0580C, NULL, "MFD VC1 1 DEC STATUS", NULL},
  {"MFD_VC1_1_SIF_SMP_RS",                  0x05810, NULL, "MFD VC1 1 SIF SMP RS", NULL},
  {"MFD_VC1_1_SIF_MSK_RS",                  0x05814, NULL, "MFD VC1 1 SIF MSK RS", NULL},
  {"MFD_VC1_1_SIF_HDAT",                    0x05818, NULL, "MFD VC1 1 SIF HDAT",   NULL},
  {"MFD_VC1_1_SIF_SDDAT",                   0x0581C, NULL, "MFD VC1 1 SIF SDDAT",  NULL},
  {"MFD_VC1_1_SIF_SMP_RC",                  0x05820, NULL, "MFD VC1 1 SIF SMP RC", NULL},
  {"MFD_VC1_1_SIF_MSK_RC",                  0x05824, NULL, "MFD VC1 1 SIF MSK RC", NULL},

  /* Stream DMA */
  {"MFD_VC1_1_SED",                         0x05900, NULL, "MFD VC1 1 SED",           NULL},
  {"MFD_VC1_1_SDEMC",                       0x05904, NULL, "MFD VC1 1 SDEMC",         NULL},
  {"MFD_VC1_1_DMA_CB_BASE",                 0x05908, NULL, "MFD VC1 1 DMA CB BASE",   NULL},
  {"MFD_VC1_1_DMA_SB_RDPTR",                0x0590C, NULL, "MFD VC1 1 DMA SB RDPTR",  NULL},
  {"MFD_VC1_1_DMA_CB_SIZE",                 0x05910, NULL, "MFD VC1 1 DMA CB SIZE",   NULL},
  {"MFD_VC1_1_DMA_WTRMARK",                 0x05914, NULL, "MFD VC1 1 DMA WTRMARK",   NULL},
  {"MFD_VC1_1_DMA_WDT",                     0x05918, NULL, "MFD VC1 1 DMA WDT",       NULL},
  {"MFD_VC1_1_DMA_CB_RDPTR",                0x0591C, NULL, "MFD VC1 1 DMA CB RDPTR",  NULL},
  {"MFD_VC1_1_DMA_CB_WRPTR",                0x05920, NULL, "MFD VC1 1 DMA CB WRPTR",  NULL},
  {"MFD_VC1_1_DMA_SDLINK",                  0x05924, NULL, "MFD VC1 1 DMA SDLINK",    NULL},
  {"MFD_VC1_1_DMA_SDLLSA",                  0x05928, NULL, "MFD VC1 1 DMA SDLLSA",    NULL},
  {"MFD_VC1_1_DMA_SDLNDA",                  0x0592C, NULL, "MFD VC1 1 DMA SDLNDA",    NULL},
  {"MFD_VC1_1_DMA_SDLDBC",                  0x05930, NULL, "MFD VC1 1 DMA SDLDBC",    NULL},
  {"MFD_VC1_1_DMA_SDLCBC",                  0x05934, NULL, "MFD VC1 1 DMA SDLCBC",    NULL},
  {"MFD_VC1_1_DMA_SDLDC",                   0x05938, NULL, "MFD VC1 1 DMA SDLDC",     NULL},
  {"MFD_VC1_1_DMA_FIFO",                    0x0593C, NULL, "MFD VC1 1 DMA FIFO",      NULL},
  {"MFD_VC1_1_DMA_FIFO_STAT",               0x05940, NULL, "MFD VC1 1 DMA FIFO STAT", NULL},
  {"MFD_VC1_1_DMA_INT_EN",                  0x05944, NULL, "MFD VC1 1 DMA INT EN",    NULL},
  {"MFD_VC1_1_DMA_INT_STAT",                0x05948, NULL, "MFD VC1 1 DMA INT STAT",  NULL},
  {"MFD_VC1_1_DMA_BS_CNTR",                 0x0594C, NULL, "MFD VC1 1 DMA BS CNTR",   NULL},

  /* Start Code Detector (SCD) */
  {"MFD_VC1_1_SCD_XCR",                     0x05A00, NULL, "MFD VC1 1 SCD XCR",     NULL},
  {"MFD_VC1_1_SCD_XSCR1",                   0x05A04, NULL, "MFD VC1 1 SCD XSCR1",   NULL},
  {"MFD_VC1_1_SCD_XSCR2",                   0x05A08, NULL, "MFD VC1 1 SCD XSCR2",   NULL},
  {"MFD_VC1_1_SCD_FWPREAD",                 0x05A0C, NULL, "MFD VC1 1 SCD FWPREAD", NULL},
  {"MFD_VC1_1_SCD_FWCRTL",                  0x05A10, NULL, "MFD VC1 1 SCD FWCRTL",  NULL},
  {"MFD_VC1_1_SCD_FWSTAT",                  0x05A14, NULL, "MFD VC1 1 SCD FWSTAT",  NULL},
  {"MFD_VC1_1_SCD_WRCTRL",                  0x05A18, NULL, "MFD VC1 1 SCD WRCTRL",  NULL},
  {"MFD_VC1_1_SCD_WRDATA",                  0x05A1C, NULL, "MFD VC1 1 SCD WRDATA",  NULL},

  /* PIP Scaler Registers */
  {"MFD_VC1_1_PIP_CTRL",                    0x05B00, NULL, "MFD VC1 1 PIP CTRL",           NULL},
  {"MFD_VC1_1_PIP_STAT",                    0x05B04, NULL, "MFD VC1 1 PIP STAT",           NULL},
  {"MFD_VC1_1_PIP_CDYB",                    0x05B08, NULL, "MFD VC1 1 PIP CDYB",           NULL},
  {"MFD_VC1_1_PIP_CDUB",                    0x05B0c, NULL, "MFD VC1 1 PIP CDUB",           NULL},
  {"MFD_VC1_1_PIP_TST_CTRL",                0x05B10, NULL, "MFD VC1 1 PIP TST CTRL",       NULL},
  {"MFD_VC1_1_PIP_TST_WR_DATA_LO",          0x05B14, NULL, "MFD VC1 1 PIP TST WR DATA LO", NULL},
  {"MFD_VC1_1_PIP_TST_WR_DATA_HI",          0x05B18, NULL, "MFD VC1 1 PIP TST WR DATA HI", NULL},

  /* 06000 to 06FFF unused                                            */
  /* VSPARC debugger                                                  */
  /* 7000H to 71FCH 00000000H Windowed Register File                  */
  /* MFD_VSPARC_GLOBALREGS  2200H to 221CH Processor Global Registers */
  {"MFD_VSPARC_FPC",                        0x07300, NULL, "MFD VSPARC FPC",            NULL},
  {"MFD_VSPARC_FSTATUS",                    0x07308, NULL, "MFD VSPARC FSTATUS",        NULL},
  {"MFD_VSPARC_DPC",                        0x07310, NULL, "MFD VSPARC DPC",            NULL},
  {"MFD_VSPARC_D_INST",                     0x07314, NULL, "MFD VSPARC D INST",         NULL},
  {"MFD_VSPARC_DSTATUS",                    0x07318, NULL, "MFD VSPARC DSTATUS",        NULL},
  {"MFD_VSPARC_EPC",                        0x07320, NULL, "MFD VSPARC EPC",            NULL},
  {"MFD_VSPARC_E_INST",                     0x07324, NULL, "MFD VSPARC E INST",         NULL},
  {"MFD_VSPARC_ESTATUS",                    0x07328, NULL, "MFD VSPARC ESTATUS",        NULL},
  {"MFD_VSPARC_MSTATUS",                    0x07338, NULL, "MFD VSPARC MSTATUS",        NULL},
  {"MFD_VSPARC_WSTATUS",                    0x07348, NULL, "MFD VSPARC WSTATUS",        NULL},
  {"MFD_VSPARC_DCTRL",                      0x07400, NULL, "MFD VSPARC DCTRL",          NULL},
  {"MFD_VSPARC_DSTAT",                      0x07404, NULL, "MFD VSPARC DSTAT",          NULL},
  {"MFD_VSPARC_PCBREAK0",                   0x07480, NULL, "MFD VSPARC PCBREAK0",       NULL},
  {"MFD_VSPARC_PCBREAKMASK0",               0x07484, NULL, "MFD VSPARC PCBREAKMASK0",   NULL},
  {"MFD_VSPARC_PCBREAK1",                   0x07490, NULL, "MFD VSPARC PCBREAK1",       NULL},
  {"MFD_VSPARC_PCBREAKMASK1",               0x07494, NULL, "MFD VSPARC PCBREAKMASK1",   NULL},
  {"MFD_VSPARC_PCBREAK2",                   0x074A0, NULL, "MFD VSPARC PCBREAK2",       NULL},
  {"MFD_VSPARC_PCBREAKMASK2",               0x074A4, NULL, "MFD VSPARC PCBREAKMASK2",   NULL},
  {"MFD_VSPARC_PCBREAK3",                   0x074B0, NULL, "MFD VSPARC PCBREAK3",       NULL},
  {"MFD_VSPARC_PCBREAKMASK3",               0x074B4, NULL, "MFD VSPARC PCBREAKMASK3",   NULL},
  {"MFD_VSPARC_DATABREAK0",                 0x074C0, NULL, "MFD VSPARC DATABREAK0",     NULL},
  {"MFD_VSPARC_DATABREAKMASK0",             0x074C4, NULL, "MFD VSPARC DATABREAKMASK0", NULL},
  {"MFD_VSPARC_DATABREAK1",                 0x074D0, NULL, "MFD VSPARC DATABREAK1",     NULL},
  {"MFD_VSPARC_DATABREAKMASK1",             0x074D4, NULL, "MFD VSPARC DATABREAKMASK1", NULL},
  {"MFD_VSPARC_DATABREAK2",                 0x074E0, NULL, "MFD VSPARC DATABREAK2",     NULL},
  {"MFD_VSPARC_DATABREAKMASK2",             0x074E4, NULL, "MFD VSPARC DATABREAKMASK2", NULL},
  {"MFD_VSPARC_DATABREAK3",                 0x074F0, NULL, "MFD VSPARC DATABREAK3",     NULL},
  {"MFD_VSPARC_DATABREAKMASK3",             0x074F4, NULL, "MFD VSPARC DATABREAKMASK3", NULL},

  /* MFD_VSPARC_LRAM 7800H to 7FFCH 00000000H Local SRAM Area */
  /* MFD_VSPARC_MEM FF9A8000H - FF9AFFFCH Code ram (windowed) */

  /* VSPARC code ram */
  {"MFD_VSPARC_CODERAM",                    0x08000, NULL,      "MFD VSPARC CODERAM     ", NULL}, 

  { NULL,0,NULL,NULL,NULL }    /* NULL terminator */
};

static const struct SVEN_Module_EventSpecific g_GEN3_MFD_specific_events[] =
{
   { "MESSAGE_TX_TO_FW", 1, "", NULL },
   { "MESSAGE_RX_FROM_FW", 2, "", NULL },

   /* When the bottom-half event handler is invoked */
   { "BOTTOM_HALF_HANDLER",3, "\tIndex=%d Context=0x%x event=0x%x intr_cnt=%ld in_use=%d state=%d", NULL },

   /* When buffer is read from the port */
   { "INPUT_PORT_BUFFER",4, "\tBufId=0x%x size=%d OPTS=0x%x LPTS=0x%x%x Disc=%d", NULL },

   /* When an es buffer descriptor is queued in the firmware */
   { "ENQUEUE_ES_BUFFER",5, "\tIndex=%d BufId=0x%x PA=0x%lx VA=0x%lx tsize=0x%x SA=0x%x", NULL },

   /* When an es buffer release message is received from the firmware */
   { "DEREF_ES_BUFFER",6, "\tIndex=%d BufId=0x%x PA=0x%lx VA=0x%lx EQ=%ld DQ=%ld", NULL },

   /* When "Frame Decoded" message is received from firmware */
   { "DECODE_ORDER_FRAME", 7, "\tN=%d FbId=%d BufId=0x%x FrameType:%d OPTS:0x%x LPTS=0x%x", NULL },

   /* When "Frame Ready to display" message is received from firmware */
   { "DISPLAY_ORDER_FRAME", 8, "\tN=%d FbId=%d BufId=0x%x YAdd:0x%x PTS=0x%x%x", NULL },

   /* When a frame is written to the output port */
   { "OUTPUT_PORT_BUFFER",9, "\tN=%d FbId=%d BufId=0x%x YAdd:0x%x PTS=0x%x%x", NULL },

   /* When "Frame Release" message is received from firmware */
   { "RELEASE_FRAME_BUFFER",10, "\tN=%d FbId=%d BufId=0x%x YAdd:0x%x AllocN=%d num_entries=%d", NULL },

   /* When decoder flush is started */
   { "FLUSH_START_DEPRECATED",11, "\tStreamID=%d Discard=%d", NULL },

   /* When decoder flush is done */
   { "FLUSH_DONE" ,12, "\tResult=%d", NULL },

   /* When the input port is empty */
   { "INPUT_PORT_EMPTY",13, "\tPort Empty: ret: %d", NULL },

   /* When frame buffer is allocated */
   { "FB_ALLOCATED",14, "\t\tN=%d FbId=%d BufId=0x%x YAdd:0x%x RlsN=%d FbCt=%d", NULL },

   /* When frame buffer is released */
   { "FB_DEREF",15, "\t\tN=%d FbId=%d BufId=0x%x YAdd:0x%x AllocN=%d FbCt=%d", NULL },

   /* firmware metrics - internal use*/
   { "SPA",16, "\t\t\tfc=%d wc=%d tp=%d cd=%d wd=%d ht=%d", NULL },

   /* information related to input port and input queue */
   { "INPUT_INFO",17, "\t\tStreamID=%d ret=%d PMDepth=%ld PDepth=%ld QDepth=%d QBytes=%ld", NULL},

   /* Indicates that ES attributes were found on input */ 
   { "ES_ATTR_FOUND", 18, "\t\tOPTS=0x%x%x LPTS=0x%x%x DISC=%d", NULL },

   /* When es buffer descriptor(s) are asked for but not enough available - FW is throttling */
   { "LOW_DESCRIPTORS", 19, "\tTotal=%d Ask=%d Found=%d In_FW=%d EQ=%d DQ=%d", NULL },

    /* When input port port depth changes based on vbv_buf_size ( from_stream) */
   { "IP_DEPTH_CHANGED", 20, "\tvbv_buf_bytes=%ld ismd_buf_size=%ld old_depth=%d new_depth=%d", NULL },

    /* For debugging the misc issues */
   { "DEBUG", 21, "\t\t\td0=%ld d1=%ld d2=%ld d3=%ld d4=%ld d5=%ld", NULL },

   /* When frame buffer is allocated */
   { "PIP_FB_ALLOCATED",22, "\tN=%d FbId=%d BufId=0x%x YAdd:0x%x RlsN=%d FbCt=%d", NULL },

   /* When frame buffer is released */
   { "PIP_FB_DEREF",23,     "\tN=%d FbId=%d BufId=0x%x YAdd:0x%x AllocN=%d FbCt=%d", NULL },

   /* When frame buffer is dropped - drop reason: Look at viddec_frame_drop_reason_t in ismd_viddec_context.h*/
   { "DROP_FRAME", 24, "\tDropReason=%d FbId=%d BufId=0x%x YAdd:0x%x PTS=0x%x%x", NULL },

   /* When es buffer is dropped on input - drop reason: 1-ExceedsMaxDecode*/
   { "DROP_ES_DATA", 25, "\tDropReason=%d BufId=0x%x size=%d OPTS=0x%x LPTS=0x%x%x", NULL },

   /* When new segment is received by decoder */
   { "INPUT_NEWSEGMENT",26,"\tid:0x%x sta:0x%x sto:0x%x line_st:0x%x req_rate:%d rate_valid:%d", NULL },

   /* When new segment is output by decoder */
   { "OUTPUT_NEWSEGMENT",27,"\tid:0x%x sta:0x%x sto:0x%x line_st:0x%x req_rate:%d rate_valid:%d", NULL },

   /* When an es marker is marked as free due to release message is received from the firmware */
   { "FREE_ES_MARKER",28, "\t\tIndex=%d BufId=0x%x PA=0x%lx VA=0x%lx EQ=%ld DQ=%ld", NULL },

   /* Input Port Thread triggered */
   { "IN_PORT_THREAD_TRIG", 29, "\ttriggered_event=0x%x", NULL },
   
   /* Viddec Context OPEN success */
   { "OPEN_DEPRECATED", 30, "\t\t\tstream_id=%d ismd_dev_handle=0x%x initial_codec=%d", NULL },
   
   /* Viddec Close begins */
   { "START_CLOSE", 31, "\t\tstream_id=%d ismd_dev_handle=0x%x", NULL },

   /* Record set state event */
   { "SET_STATE", 32, "\t\tstate=%d", NULL },

   /* When an es marker descriptor is queued in the firmware */
   { "ENQUEUE_ES_MARKER", 33, "\tlsb_tag=%d msb_tag=0x%x PA=0x%lx size=0x%x", NULL },

   /* When reference count of a regular buffer is incremented */
   { "ADDREF",34,     "\t\t\tFbId=%d BufId=0x%x YAdd:0x%x %d %d %d", NULL },

   /* When the bottom-half event handler trys to process more input queue events*/
   { "BH_INPUT_QUEUE", 35, "\t\tIndex=%d Context=0x%x event=0x%x event_data=%ld", NULL },

   /* when input queue is empty */
   { "INPUT_QUEUE_EMPTY", 36, "\tmax_depth=%d available=0x%x max_msg_size=0x%x", NULL },

   /* when es marker found message is received */
   { "ES_MARKER_SEEN", 37, "\t\tindex=%d dsn=%d disc=%d opts:0x%x lpts:0x%x%x", NULL },

   /* when seq hrd found */
   { "SEQ_HDR_FOUND", 38, "\t\t1st seq hdr: %d, codec: %d, h x w = %d x %d, profile/level index: %d", NULL },

   /* when Resolution Change detected */
   { "RES_CHANGE", 39, "\t\told h x w = %d x %d --> new h x w = %d x %d", NULL },

   /* When an es buffer end of frame marker is sent to FW */
   { "ES_END_OF_FRAME_MARK", 40, "\tOffset=0x%x because of discontinuity:%d", NULL },

   /* When reference count of a pip buffer is incremented */
   { "PIP_ADDREF", 41,     "\t\t\tFbId=%d BufId=0x%x YAdd:0x%x %d %d %d", NULL },
   
   /* stream statistics */
   { "STREAM_STATISTICS", 42, "\tTotBytes=0x%x%x FrmsDecoded=0x%x FrmsDropped=0x%x ErrFrms=0x%x", NULL },

   /* When a frame is moved onto the internal frame display queue */
   { "DISPQ_IN_ENQUEUE", 43, "\t\tQ Head: %d, Q Tail: %d, Buffer Index: %d, New Depth: %d, PTS/2: 0x%08x, Max Depth: %d", NULL },

   /* When a frame is moved off of the internal frame display queue (to be handed off to the next element) */
   { "DISPQ_OUT_DEQUEUE", 44, "\t\tQ Head: %d, Q Tail: %d, Buffer Index: %d, New Depth: %d, PTS/2: 0x%08x, Max Depth: %d", NULL },

   /* When a frame is moved onto the internal frame display stack (used for reverse play) */
   { "DISP_STACK_PUSH", 45, "\t\tPtr: %d, Buffer Index: %d, New Depth: %d, PTS/2: 0x%08x, Max Depth: %d", NULL },

   /* When a frame is moved onto the internal frame display stack (used for reverse play) */
   { "DISP_STACK_POP", 46, "\t\tPtr: %d, Buffer Index: %d, New Depth: %d, PTS/2: 0x%08x, Max Depth: %d", NULL },

   /* When FW notifies of an unsupported profile */
   { "CONTENT_UNSUP_PROFILE", 47, "\t\tStream ID: 0x%06x, error_code: %d", NULL },

   /* When FW notifies of an unsupported level */
   { "CONTENT_UNSUP_LEVEL", 48, "\t\tStream ID: 0x%06x, error_code: %d", NULL },

   /* When FW notifies of an unsupported features */
   { "CONTENT_UNSUP_FEATURE", 49, "\t\tStream ID: 0x%06x, error_code: %d", NULL },

   /* When FW notifies of an unsupported resolution */
   { "CONTENT_UNSUP_RES", 50, "\t\tStream ID: 0x%06x, error_code: %d", NULL },

   /* When FW notifies of an unsupported resolution */
   { "CONTENT_SYNTAX", 51, "\t\tStream ID: 0x%06x, error_code: %d", NULL },

#include "ismd_standard_events.c"
	/* When an MFD instance is opened */
   {"OPEN",                103, "\tStream ID: 0x%06x In Port ID: %d, Out Port ID: %d ismd_dev_handle=0x%x initial_codec=%d, max frames to decode: %d", NULL},

   { NULL, 0, "", NULL }
};

static const struct ModuleReverseDefs g_GEN3_MFD_sven_module =
{
    "GEN3_MFD",
    SVEN_module_GEN3_MFD,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen3_mfd,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MFD: MFD (GEN3)",
    g_GEN3_MFD_specific_events,
    NULL /* extension list */
};

