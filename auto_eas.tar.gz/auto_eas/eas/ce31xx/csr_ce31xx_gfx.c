/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

static const struct EAS_RegBits g_csr_gfx_SW_RESET [] = 
{
    { "BIF_RST",		8,	1},     /* Bus Interface Reset     */
    { "TA_RST",		        4,	1},	/* Tile Accelarator Reset  */
    { "PVR_RST",	        0,	1}, 	/* 3D logic Reset          */
    { NULL }    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gfx_CLK_RATIO [] = 
{
    { "CLK_RATIO",	        0,	2}, 	/* Clock Ratio Status       */
    { NULL }    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gfx_IDLE_COUNT [] = 
{
    { "IDLE_COUNT",	        0,	15}, 	/* VAL idle count values (0..65535) in clocks  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_ACTIVITY_COUNT [] = 
{
    { "ACTIVITY_COUNT",	        0,	7}, 	/* Activity timeout count values (0..255) in clocks  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_GPO [] = 
{
    {"GPO",	                0,	7}, 	/* General purpose output controls  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_INT_STATUS [] = 
{
    {"TA_MACABORT_Y",	        28,	3}, 	/* Indicate Y offset of macrotile taking more memory  */
    {"TA_MACABORT_X",           25,     3},     /* Indicate X offset of macrotile taking more memory  */
    {"TA_MACABORT_VALID",       24,     1},     /* Indicates whether [30:25] bit are valid            */
    {"TA_FIFO_USED",            16,     8},     /* Number of bus width slots written into TA slave port */
    {"INT_MASTER",              15,     1},     /* Master Interrrupt status                             */
    {"2D_SYNC_INT",             10,     1},     /* 2D driver synchronization interrupt                  */
    {"TA_STREAM_ERR",            9,     1},     /* TA Input stream error                                */
    {"TA_CONTEXT",               8,     1},     /* TA context finished                                  */
    {"INT_TA_TIMEOUT",           7,     1},     /* Event Manager TA timeout cleanup complete            */
    {"INT_EVM_DALLOC",           6,     1},     /* EVM 3D render deallocaition complete                 */
    {"INT_TA_OFLOW",             5,     1},     /* TA out of memory                                     */
    {"INT_TA",                   4,     1},     /* TA complete                                          */
    {"INT_ISP",                  3,     1},     /* ISP render complete                                  */
    {"INT_3D",                   2,     1},     /* 3D render complete                                   */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_INT_ENABLE [] = 
{
    {"INT_ENABLE",	        15,	1}, 	/* Master enable bit                           */
    {"2D_SYNC_INT",             10,     1},     /* 2D driver synchronization interrupt enable  */
    {"TA_STREAM_ERR",            9,     1},     /* TA stream error enable                      */
    {"TA_CONTEXT",               8,     1},     /* TA context enable                           */
    {"INT_TA_TIMEOUT",           7,     1},     /* EVM TA timeout cleanup complete             */
    {"INT_EVM_DALLOC",           6,     1},     /* EVM 3D render deallocation complete enable  */
    {"INT_TA_OFLOW",             5,     1},     /* TA out of memory enable                     */
    {"INT_TA",                   4,     1},     /* TA complete enable                          */
    {"INT_ISP",                  3,     1},     /* ISP render complete enable                  */
    {"INT_3D",                   2,     1},     /* 3D render complete  enable                  */
    { NULL }    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gfx_INT_CLEAR [] = 
{
    {"2D_SYNC_INT",             10,     1},     /* 2D driver synchronization interrupt clear   */
    {"TA_STREAM_ERR",            9,     1},     /* TA stream error clear                       */
    {"TA_CONTEXT",               8,     1},     /* TA context clear                            */
    {"INT_TA_TIMEOUT",           7,     1},     /* EVM TA timeout cleanup complete clear       */
    {"INT_EVM_DALLOC",           6,     1},     /* EVM 3D render deallocation complete clear   */
    {"INT_TA_OFLOW",             5,     1},     /* TA out of memory clear                      */
    {"INT_TA",                   4,     1},     /* TA complete clear                           */
    {"INT_ISP",                  3,     1},     /* ISP render complete clear                   */
    {"INT_3D",                   2,     1},     /* 3D render complete  clear                   */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_MEMPAGE_SIZE [] = 
{
    {"MEM_PAGE_SIZE",            0,     3},     /* Memory page size              */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_RGNBASE [] = 
{
    {"REGIONHDR_BASE",           2,     23},     /* Region header base address   */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_OBJBASE [] = 
{
    {"OBJ_PARAM_BASE",          12,     13},     /* Obj parameter base          */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_ZLOADSTORE [] = 
{
    {"Z_ONLY_RENDER",           19,     1},     /* Only render Z so as to update Z buffer          */
    {"Z_FORMAT",                16,     2},     /* Z format                                        */
    {"ZLS_XEXTEND",              8,     7},     /* Width in tiles in external depth buffer         */
    {"ZSTORE_ENABLE",            1,     1},     /* The depth buffer is stored to memory            */
    {"ZLOAD_ENABLE",             0,     1},     /* The depth buffer is read from memory            */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_FPUPERPVAL [] = 
{
    {"FPU_PERP_VAL",             4,     27},     /* IEEE FP value to compare against triangles determinant  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_FPUCULLVAL [] = 
{
    {"FPU_CULL_VAL",             4,     27},     /* IEEE FP value to decide whether triangle should be culled  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_3DPIXSAMP [] = 
{
    {"DCALC_MODE",              16,     2},     /* Selects X and Y value when eval numerator poly of D   */
    {"FAST_ANTI_ALIAS",          3,     1},     /* Selects fast anti alias mode                          */
    {"TSP_TEXEL_SAMPLE_POS",     2,     1},     /* Selects sample position when fetching texel           */
    {"TSP_PIXEL_SAMPLE_POS",     1,     1},     /* Selects sample positions when fecthing pixel          */
    {"FPU_SAMPLE_POS",           0,     1},     /* Selects sample position when hidden surface removed   */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_CK1 [] = 
{
    {"CK1_R",                   16,     8},     /* Color Key 1 for R   */
    {"CK1_G",                    8,     8},     /* Color Key 1 for G   */ 
    {"CK1_B",                    0,     8},     /* Color Key 1 for B   */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_CK2 [] = 
{
    {"CK2_R",                   16,     8},     /* Color Key 2 for R   */
    {"CK2_G",                    8,     8},     /* Color Key 2 for G   */ 
    {"CK2_B",                    0,     8},     /* Color Key 2 for B   */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_CKUV [] = 
{
    {"CK_U",                    8,     8},     /* Color Key for U      */ 
    {"CK_V",                    0,     8},     /* Color Key for V      */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_CKMASK [] = 
{
    {"CK_MASK",                 0,     3},     /* Mask color key bits  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_FOGCOLVERT [] = 
{
    {"VERTEX_FOG_COLOR",        0,    24},     /* RGB color used during vertex fogging  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_VERTFOGSTATUS [] = 
{
    {"VERTEX_FOG_COLOR",        0,    24},     /* RGB color status during vertex fogging */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_SCALERCTL [] = 
{
    {"HORIZONTAL_UPSCALE",      3,     1},     /* Horizontal upscale of pixels from accumulation buffer */
    {"VERTICAL_UPSCALE",        2,     1},     /* Vertical upscale of pixels from accumulation buffer   */
    {"HORIZONTAL_SCALE",        1,     1},     /* Horizontal downscale of pixels from accumulation buffer */
    {"VERTICAL_SCALE",          0,     1},     /* Vertical downscale of pixels from accumulation buffer */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_BLENDCTL [] = 
{
    {"FORCE_ALPHA",      16,     1},     /* Accumalation buffer alpha value control */
    {"SUBTRACT_128",      0,     1},     /* Offset control for texture dot-product blend mode  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_ARGBSUM [] = 
{
    {"ARGB_SUM",      0,     1},     /* Dot product sum control register*/
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_FBCTL [] = 
{
    {"FB_YSIZETWIDDLE",      25,     4},     /* Number of tiles in Y  */
    {"FB_XSIZETWIDDLE",      21,     4},     /* Number of tiles in X    */
    {"FB_TWIDDLE",           20,     1},     /* Horizontal downscale of pixels from accumulation buffer */
    {"FB_ALPHA_THRESHOLD",   12,     8},     /* Alpha threshold used when encoding 1555 format */
    {"FB_KVAL",               4,     8},     /* Constant Alpha Value  */
    {"FB_DITHER",             3,     1},     /* Controls conversion of pixels from internal ARGB 8888 format to 16bit output formats (555, 565, 4444, 1555)   */
    {"FB_PACKMODE",           0,     3},     /* Pixel packing mode for 3D pixel writes */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_FBXCLIP [] = 
{
    {"FB_XCLIP_MAX",      16,     11},     /* Pixels with an X co-ordinate greater than this value are clipped and not written to the framebuffer */
    {"FB_XCLIP_MIN",       0,     11},     /* Pixels with an X co-ordinate less than this value are clipped and not written to the framebuffer.  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_FBYCLIP [] = 
{
    {"FB_YCLIP_MAX",      16,     11},     /* Pixels with an Y co-ordinate greater than this value are clipped and not written to the framebuffer */
    {"FB_YCLIP_MIN",       0,     11},     /* Pixels with an Y co-ordinate less than this value are clipped and not written to the framebuffer.  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_FBSTART [] = 
{
    {"RENDER_ADDRESS",       2,     26},     /* Start of render address. 256MB range on DWord boundaries.  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_FBLINESTRIDE [] = 
{
    {"FB_LINESTRIDE",       0,     12},     /* The width of a line when rendering 3D pixels into the framebuffer in DWord units  */
    { NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_gfx_LATENCYCOUNT [] = 
{
    {"Texture_Latency",       0,     4},     /* Number of clocks to delay texture memory requests to allow requests to be grouped into bursts  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_YUVCOEFFY [] = 
{
    {"YCOEFFB",        18,     7},     /* R = ((Y-16) * YcoeffR) + (U-128)*UcoeffR) + ((V-128)*VcoeffR)   */
    {"YCOEFFG",         9,     9},     /* G = ((Y-16) * YcoeffG) + (U-128)*UcoeffG) + ((V-128)*VcoeffG)*/
    {"YCOEFFR",         0,     9},     /* B = ((Y-16) * YcoeffB) + (U-128)*UcoeffB) + ((V-128)*VcoeffB) */
    { NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_gfx_YUVCOEFFU [] = 
{
    {"UCOEFFB",        18,     7},     /* R = ((Y-16) * YcoeffR) + (U-128)*UcoeffR) + ((V-128)*VcoeffR)   */
    {"UCOEFFG",         9,     9},     /* G = ((Y-16) * YcoeffG) + (U-128)*UcoeffG) + ((V-128)*VcoeffG)*/
    {"UCOEFFR",         0,     9},     /* B = ((Y-16) * YcoeffB) + (U-128)*UcoeffB) + ((V-128)*VcoeffB) */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_YUVCOEFFV [] = 
{
    {"VCOEFFB",        18,     7},     /* R = ((Y-16) * YcoeffR) + (U-128)*UcoeffR) + ((V-128)*VcoeffR)   */
    {"VCOEFFG",         9,     9},     /* G = ((Y-16) * YcoeffG) + (U-128)*UcoeffG) + ((V-128)*VcoeffG)*/
    {"VCOEFFR",         0,     9},     /* B = ((Y-16) * YcoeffB) + (U-128)*UcoeffB) + ((V-128)*VcoeffB) */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_ZBASEADDR [] = 
{
    {"ZBuffer_Base_Address",       2,     23},     /* ZBuffer base address, 32MB range on DWord boundaries.  */
    { NULL }    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_gfx_STARTRENDER [] = 
{
    {"START_RENDER",       0,     32},     /* Any write to this register starts a 3D Render  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_3DFLATSHADEDCS [] = 
{
    {"FLAT_SHADE_SRC",       0,     1},     /* Determines the base and offset colour of a flat shaded triangle  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_3D_ZL_BACKGROUND_TAG [] = 
{
    {"ZL_BGT_OFFSET",        29,     1},     /*Offset Parameter Present   */
    {"ZL_BGT_NUM_UV",        28,     1},     /* The number of texture layers*/
    {"ZL_BGT_TEXTURED",      27,     1},     /* Background Tag Textured Flag */
    {"ZL_BGT_RES1",          25,     2},     /* Reserved for Future Expansion   */
    {"ZL_BGT_RES0",          21,     4},     /* Reserved for Future Expansion*/
    {"ZL_BGT_ADDRESS",        0,    21},     /* Tag Address. */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx__ZL_BACKGROUND_DEPTH [] = 
{
    {"ZL_BG_DEPTH",           4,     27},     /*28bit Float. Note sign bit is reserved. Used to initialize the ISP depth buffer  */
    {"ZL_BG_MSK_PLANE",       0,     1},     /* Used to initialize the ISP mask plane buffer when Z Load Format is set to 0x3.  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_1BPP_BACKGROUND_COLOUR [] = 
{
    {"1BPP_BACKGROUND_COLOUR",       0,     32},     /* Colour used for 1 bit per pixel texture format background in ARGB format  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_1BPP_FOREGROUND_COLOUR [] = 
{
    {"1BPP_FOREGROUND_COLOUR",       0,     32},     /* Colour used for 1 bit per pixel texture format background in ARGB format  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_USE_1BPP_REGS_CTL [] = 
{
    {"USE_1BPP_REGS_CTL",       0,     1},     /* Use 1 bit per pixel texture format register values  */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_3D_RENDER_ID [] = 
{
    {"PVR_Render_ID",       0,     1},     /* The parameter management keeps track of 2 independent frames, both TA and 3D */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx__ZL_3D_TEX_DECIM [] = 
{
    {"Tex_Dec_Control",           16,     1},     /*Texture Half Decimation Factor Control  */
    {"Tex_Dec_Factor",             0,     3},     /* Texture Decimation Factor */
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_TA_START [] = 
{
    {"TA_START",       0,     32},     /* Kicks off the pointer allocation module within the tile accelerator*/
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_TA_RESTART [] = 
{
    {"TA_RESTART",       0,     32},     /*After a TA abort cycle is complete, a write to this register tells the TA to continue processing the input data*/
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_TA_ABORT [] = 
{
    {"TA_ABORT",       0,     32},     /*Causes the TA to issue an abort cycle*/
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_TA_ABORTXY [] = 
{
    {"TA_ABORTX",      17,     3},     /*The X address of the macro tile (in macrotiles) to be terminated during an abort cycle*/
    {"TA_ABORTY",       0,     3},     /*The Y address of the macro tile (in macrotiles) to be terminated during an abort cycle*/    
    { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_gfx_TA_RENDER_ID [] = 
{
    {"TA_RENDER_ID",      0,     1},     /*The parameter management keeps track of 2 independent frames*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_CONTEXT_LOAD [] = 
{
    {"TA_CONTEXT_LOAD",      0,     32},     /*This register can only be used when the tile accelerator is idle		*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_CONTEXT_STORE [] = 
{
    {"TA_CONTEXT_STORE",      0,     32},     /*This register can only be used when the tile accelerator is idle		*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_CONTEXT_RESET [] = 
{
    {"TA_CONTEXT_RESET",      0,     32},     /*This register can only be used when the tile accelerator is idle		*/
    { NULL }    /* NULL terinator */
};


static const struct EAS_RegBits g_csr_gfx_TA_CONTEXT_BASE [] = 
{
    {"TA_CONTEXT_BASE",      9,     16},     /*The base address for the context to be loaded and stored from/to	*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_EVM_PAGETBL_BASE [] = 
{
    {"EVM_LIST_BASE",      14,     11},     /*The base address for the page list where the event manager stores the current state of the memory allocation.*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_EVM_LIST_START [] = 
{
    {"EVM_LIST_START",      0,     13},     /*The first page to be allocated by the event manager*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_EVM_LIST_END [] = 
{
    {"EVM_LIST_END",      0,     13},     /*The last page to be allocated by the event manager*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_EVM_RENDER_TIMEOUT [] = 
{
    {"EVM_Render_Timeout",      0,     32},     /*In the event that the 3D core fails to complete a render due to invalid parameters*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_EVM_TA_TIMEOUT [] = 
{
    {"EVM_TA_Timeout",      0,     32},     /*In the event that the TA fails to complete*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_EVM_INIT [] = 
{
    {"EVM_INIT",      0,     32},     /*This register initializes the event manager*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_OBJDATABASE [] = 
{   
    {"TA_Obj_Base",      12,     13},     /*The base address of the object data as seen by the 3D core*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_TAILPTRBASE [] = 
{
    {"TA_TPC_Base_Addr",      16,     9},     /*The TA has a cache of the next address to be written to for each pointer list*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_REGION_BASE [] = 
{
    {"TA_Region_Base_Addr",      2,     23},     /*The region base address for the TA writing regions automatically into memory*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_GLOBAL_LIST_CTRL [] = 
{
    {"Global_MaxNumObj",     16,      8},     /*The maximum number of objects which can be inserted into the global list per TA kick*/
    {"Global_ObjSize",       15,      1},     /*The minimum size of an object in tiles for it to be treated as a global object*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_XCLIP [] = 
{
    {"TA_Screen_X_Clip_Max",      16,     11},     /*Max screen X clipping extent in pixels */
    {"TA_Screen_X_Clip_Min",        0,     11},     /*Min screen X clipping extent in pixels*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_YCLIP [] = 
{
    {"TA_Screen_Y_Clip_Max",      16,     11},     /*Max screen Y clipping extent in pixels */
    {"TA_Screen_Y_Clip_Min",        0,     11},     /*Min screen Y clipping extent in pixels*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_RHWCLAMP [] = 
{
    {"TA_RHW_Clamp",      4,     27},     /*An IEEE float value which RHW values are clamped to if less than this value*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_RHWCOMP [] = 
{
    {"TA_RHW_Comp",      4,     27},     /*This truncated IEEE value is tested against the RHW of an incoming object and if RHW is less than this, it is clamped to the clamp value*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_CONFIG [] = 
{
    {"PT_disable",                   31,      1},     /*Global perfect tiling disable*/
    {"TSnap_Disable",               30,      1},     /*The TA by default snaps pixels to 1/16 of a pixel granularity*/
    {"Region_Header_Generation",     27,      3},     /*The order in which to generate region headers, */
    {"Render_Width",                20,      7},     /*TA Render width in tiles  1*/
    {"Z_load_store_control",        18,      3},     /*Bits 30 (store) and 29 (load) of the region headers*/
    {"Render_Height",               10,      7},     /*TA Render height in tiles 1*/
    {"No_Deallocate",                9,      1},     /*Do not free up memory during 3D render (for use with Z only renders)*/
    {"No_Initialise",                8,      1},     /*Prevent Initialization of the tail pointer cache at TA end of stream */
    {"Complet_on_Terminate",          7,      1},     /*Insert end of list when TA receives a stream terminate object*/
    {"Pixel_Centre",                 6,      1},     /*When set, indicates that a sub-pixel triangle is only visible if it crosses the centre of the pixel. */
    {"Invert_Offset_Alpha",           5,      1},     /*Inverts Offset Alpha component of objects passed through the TA*/
    {"Invert_Base_Alpha",            4,      1},     /*Inverts Base Alpha component of objects passed through the TA*/
    {"TA_Dealloc_Glob",              3,      1},     /*Used to control memory deallocation when the TA runs out of memory*/
    {"Super_Sample_in_Y",            2,      1},     /*When set TA multiplies all incoming Y co-ordinates by two*/
    {"Super_Sample_in_X",            1,      1},     /*When set TA multiplies all incoming X co-ordinates by two*/
    {"Small_Object_Cull",            0,      1},     /*When set the TA culls small objects which are not visible */
    { NULL }    /* NULL terinator */
};


static const struct EAS_RegBits g_csr_gfx_3DSCREENSIZE [] = 
{
    
    {"Render_Height_6_4",             20,      3},     /*Render height in (tiles 1) When super sampling in Y is turned on, this must be (2*tiles) - 1*/
    {"Render_Height_3_0",              16,      4},     /*0*/
    {"Render_Width_6_4",               4,      3},     /*Render width in tiles  1 When super sampling in X is turned on, this must be (2*tiles) 1 */
    {"Render_Width_3_0",               0,      4},     /*0*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_EVM_CONTEXT_FLUSH_ADDR [] = 
{
    {"EVM_CTX_BASE",      14,     11},     /*The base address for flushing out the contents of the parameter management,*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TSP3_SIG [] = 
{
    {"TSP3_SIG",      0,     32},     /*TSP 3 Pipeline Signature Analysis Register*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_ISP1_SIG [] = 
{
    {"ISP1_SIG",      0,     32},     /*ISP1 Pipeline Signature Analysis Register*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TSP2_SIG [] = 
{
    {"TSP2_SIG",      0,     32},     /*TSP 2 Pipeline Signature Analysis Register*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TSP1_SIG [] = 
{
    {"TSP1_SIG",      0,     32},     /*TSP 1 Pipeline Signature Analysis Register*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TC_SIG [] = 
{
    {"TC_SIG",      0,     32},     /*Texture Cache Pipeline Signature Analysis Register*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_DIAG [] = 
{
    {"TA_DIAGS",      0,     28},     /*Tile Accelerator Internal Diagnostics Register*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_TA_STRIP_CNT [] = 
{
    {"TA_Strip_Count",      0,     10},     /*Tile Accelerator Diagnostics Register*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_DIAG_EN [] = 
{
    {"Diag_Enable",      0,     1},     /*Diagnostics Enable, for power saving reasons the signature are disabled by default.*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_ISP2_SIG [] = 
{
    {"ISP2_SIG",      0,     32},     /*ISP2 Pipeline Signature Analysis Register.*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_CORE_ID [] = 
{
    
    {"GROUP_ID",                  24,      8},     /*This identifies the core as part of an IMG IP family group*/
    {"CORE_ID",                    16,      8},     /*This identifies the member of the IP group*/
    {"CORE_CFG_MMU",                1,      1},     /*This bit indicates the presence of the MMU */
    {"CORE_CFG_VGP",               0,      1},     /*This bit indicates the presence of the VGP*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_REVISION [] = 
{
    
    {"Company",                       24,      8},     /*Company ID*/
    {"Major_Rev",                    16,      8},     /*Family Major Revision Code*/
    {"Minor_Rev",                     8,      8},     /*Core Minor Release Revision */
    {"Maintenance_Rev",               0,      8},     /*Maintenance Release Revision*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_DSGN_REV1 [] = 
{
    {"USER_REV1",      0,     32},     /*Designer Revision Field 1*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_DSGN_REV2 [] = 
{
    {"USER_REV2",      0,     32},     /*Designer Revision Field 2*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_PAGE0_ADDR [] = 
{
    {"MMU_Table_0",      12,     20},     /*Location of page 0 of the MMU translation table in system memory*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_PAGE1_ADDR [] = 
{
    {"MMU_Table_1",      12,     20},     /*Location of page 1 of the MMU translation table in system memory*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_PAGE2_ADDR [] = 
{
    {"MMU_Table_2",      12,     20},     /*Location of page 2 of the MMU translation table in system memory*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_PAGE3_ADDR [] = 
{
    {"MMU_Table_3",      12,     20},     /*Location of page 3 of the MMU translation table in system memory*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_PAGE4_ADDR [] = 
{
    {"MMU_Table_4",      12,     20},     /*Location of page 4 of the MMU translation table in system memory*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_PAGE5_ADDR [] = 
{
    {"MMU_Table_5",      12,     20},     /*Location of page 5 of the MMU translation table in system memory*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_PAGE6_ADDR [] = 
{
    {"MMU_Table_6",      12,     20},     /*Location of page 6 of the MMU translation table in system memory*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_PAGE7_ADDR [] = 
{
    {"MMU_Table_7",      12,     20},     /*Location of page 7 of the MMU translation table in system memory*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_ENABLE [] = 
{
    
    {"MMU_Inval_Status",                       24,      1},     /*Status Bit Indicating a cache invalidate is in progress*/
    {"MMU_Ready",                             16,      1},     /*Signals that the MMU cache has been initialized*/
    {"MMU_Invalidate",                          8,      1},     /*Setting this bit forces an MMU cache invalidate against the information contained in the MMU_Index*/
    {"MMU_Enable",                              0,      1},     /*No translation. Addresses are direct mapped in to bottom of address range*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_IDX_INVAL [] = 
{
    {"MMU_Tag",        8,     5},     /*MMU tag to be invalidated*/
    {"MMU_Index",      0,     8},     /*MMU index to be invalidated*/
    { NULL }    /* NULL terinator */
};

static const struct EAS_RegBits g_csr_gfx_MMU_PHYSADD_INVAL [] = 
{
    {"MMU_PhysAdd",      0,     21},     /*Contains the top 21 bits of the physical address which is used to replace the cache entry */
    { NULL }    /* NULL terinator */
};


static const struct EAS_Register g_csr_GEN3_GFX [] = 
{
  {"GLOBREG_SW_RESET", 0x0080, g_csr_gfx_SW_RESET, "software reset"}, 
           
  {"GLOBREG_CLK_RATIO", 0x0090, g_csr_gfx_CLK_RATIO, "Clock Ratio Status"}, 
           
  {"GLOBREG_IDLE_COUNT", 0x0100, g_csr_gfx_IDLE_COUNT, "2D Idle Timeout Clock Cycle Count"}, 
           
  {"GLOBREG_ACTIVITY_COUNT", 0x0104, g_csr_gfx_ACTIVITY_COUNT, "Startup Timeout Clock Cycle Count"}, 
  {"GLOBREG_FPUPERPVAL", 0x0614, g_csr_gfx_FPUPERPVAL, "3D FPU Perpendicular Com"}, 
           
  {"GLOBREG_FPUCULLVAL", 0x0618, g_csr_gfx_FPUCULLVAL, "3D FPU Cull Value"}, 
           
  {"GLOBREG_3DPIXSAMP", 0x061C, g_csr_gfx_3DPIXSAMP, "3D Pixel Sampling"}, 
           
  {"GLOBREG_CK1", 0x0624, g_csr_gfx_CK1, "3D Colour Key 1"}, 
           
  {"GLOBREG_CK2", 0x0628, g_csr_gfx_CK2, "3D Colour Key 2"}, 
           
  {"GLOBREG_CKUV", 0x062C, g_csr_gfx_CKUV, "3D Colour Key UV"}, 
           
  {"GLOBREG_CKMASK", 0x0630, g_csr_gfx_CKMASK, "3D Colour Key Mask"}, 
           
  {"GLOBREG_FOGCOLVERT", 0x063C, g_csr_gfx_FOGCOLVERT, "3D Vertex Fog Colour"}, 
           
  {"GLOBREG_VERTFOGSTATUS", 0x0640, g_csr_gfx_VERTFOGSTATUS, "3D Vertex Fog Status"}, 
           
  {"GLOBREG_SCALERCTL", 0x0644, g_csr_gfx_SCALERCTL, "3D Scaler Control"}, 
           
  {"GLOBREG_BLENDCTL", 0x0648, g_csr_gfx_BLENDCTL, "3D Blend Control"}, 
           
  {"GLOBREG_ARGBSUM", 0x064C, g_csr_gfx_ARGBSUM, "3D Blend ARGB Sum"}, 
           
  {"GLOBREG_FBCTL", 0x0650, g_csr_gfx_FBCTL, "3D Write Control"}, 
           
  {"GLOBREG_FBXCLIP", 0x0654, g_csr_gfx_FBXCLIP, "3D Write X Clipping"}, 
           
  {"GLOBREG_FBYCLIP", 0x0658, g_csr_gfx_FBYCLIP, "3D Write Y Clipping"}, 
           
  {"GLOBREG_FBSTART", 0x065C, g_csr_gfx_FBSTART, "3D Render Address"}, 
           
  {"GLOBREG_FBLINESTRIDE", 0x0660, g_csr_gfx_FBLINESTRIDE, "3D Write Stride"}, 
           
  {"GLOBREG_LATENCYCOUNT", 0x0664, g_csr_gfx_LATENCYCOUNT, "3D Texture Latency"}, 
           
  {"GLOBREG_YUVCOEFFY", 0x066C, g_csr_gfx_YUVCOEFFY, "YUV420/422 Y Coefficients"}, 
           
  {"GLOBREG_YUVCOEFFU", 0x0670, g_csr_gfx_YUVCOEFFU, "YUV420/422 U Coefficients"}, 
           
  {"GLOBREG_YUVCOEFFV", 0x0678, g_csr_gfx_YUVCOEFFV, "YUV420/422 V Coefficients"}, 
           
  {"GLOBREG_ZBASEADDR", 0x0674, g_csr_gfx_ZBASEADDR, "3D Z Base Address"}, 
           
  {"GLOBREG_STARTRENDER", 0x0680, g_csr_gfx_STARTRENDER, "3D Start Render"}, 
           
  {"GLOBREG_3DFLATSHADEDCS", 0x06D0, g_csr_gfx_3DFLATSHADEDCS, "3D Flat Shaded Colour Source"}, 
           
  {"GLOBREG_3D_ZL_BACKGROUND_TAG", 0x06D8, g_csr_gfx_3D_ZL_BACKGROUND_TAG, "3D ZLoad Background Tag"}, 
           
  {"GLOBREG_3D_ZL_BACKGROUND_DEPTH", 0x06DC, g_csr_gfx__ZL_BACKGROUND_DEPTH, "3D ZLoad Background Depth"}, 
           
  {"GLOBREG_1BPP_BACKGROUND_COLOUR", 0x06E0, g_csr_gfx_1BPP_BACKGROUND_COLOUR, "3D 1Bpp Background Colour"}, 
           
  {"GLOBREG_1BPP_FOREGROUND_COLOUR", 0x06E4, g_csr_gfx_1BPP_FOREGROUND_COLOUR, "3D 1Bpp Foreground Colour"},
           
  {"GLOBREG_USE_1BPP_REGS_CTL", 0x06E8, g_csr_gfx_USE_1BPP_REGS_CTL, "3D 1Bpp Use Register Values"}, 
           
  {"GLOBREG_3D_RENDER_ID", 0x06EC, g_csr_gfx_3D_RENDER_ID, "3D Render ID"}, 
           
  {"GLOBREG_3D_TEX_DECIM", 0x06F0, g_csr_gfx__ZL_3D_TEX_DECIM, "3D Texture Decimation"}, 
           
  {"TAGLOBREG_START", 0x0800, g_csr_gfx_TA_START, "TA Start"}, 
           
  {"TAGLOBREG_RESTART", 0x0804, g_csr_gfx_TA_RESTART, "TA Restart"}, 
           
  {"TAGLOBREG_ABORT", 0x0808, g_csr_gfx_TA_ABORT, "TA Abort"}, 
           
  {"TAGLOBREG_ABORTXY", 0x080C, g_csr_gfx_TA_ABORTXY, "TA Abort XY"}, 
           
  {"TAGLOBREG_RENDER_ID", 0x0810, g_csr_gfx_TA_RENDER_ID, "TA Render ID"}, 
           
  {"TAGLOBREG_CONTEXT_LOAD", 0x0814, g_csr_gfx_TA_CONTEXT_LOAD, "TA Context Load"}, 
           
  {"TAGLOBREG_CONTEXT_STORE", 0x0818, g_csr_gfx_TA_CONTEXT_STORE, "TA Context Store"}, 
           
  {"TAGLOBREG_CONTEXT_RESET", 0x081C, g_csr_gfx_TA_CONTEXT_RESET, "TA Context Reset"}, 
           
  {"TAGLOBREG_CONTEXT_BASE", 0x0820, g_csr_gfx_TA_CONTEXT_BASE, "TA Context Base"}, 
           
  {"TAGLOBREG_EVM_PAGETBL_BASE", 0x0824, g_csr_gfx_TA_EVM_PAGETBL_BASE, "EVM Page Table Base Address"}, 
           
  {"TAGLOBREG_EVM_LIST_START", 0x0828, g_csr_gfx_TA_EVM_LIST_START, "EVM List Start Page"}, 
           
  {"TAGLOBREG_EVM_LIST_END", 0x082C, g_csr_gfx_TA_EVM_LIST_END, "EVM List End Page"}, 
           
  {"TAGLOBREG_EVM_RENDER_TIMEOUT", 0x0830, g_csr_gfx_TA_EVM_RENDER_TIMEOUT, "EVM Render Timeout"}, 
           
  {"TAGLOBREG_EVM_TA_TIMEOUT", 0x0834, g_csr_gfx_TA_EVM_TA_TIMEOUT, "EVM TA Timeout"}, 
           
  {"TAGLOBREG_EVM_INIT", 0x0838, g_csr_gfx_TA_EVM_INIT, "EVM Init"}, 
           
  {"TAGLOBREG_OBJDATABASE", 0x083C, g_csr_gfx_TA_OBJDATABASE, "TA Object Base Address"}, 
           
  {"TAGLOBREG_TAILPTRBASE", 0x0840, g_csr_gfx_TA_TAILPTRBASE, "TA Tail Pointer Base Address"}, 
           
  {"TAGLOBREG_REGION_BASE", 0x0844, g_csr_gfx_TA_REGION_BASE, "TA Region Base Address"}, 
           
  {"TAGLOBREG_GLOBAL_LIST_CTRL", 0x0848, g_csr_gfx_TA_GLOBAL_LIST_CTRL, "TA Global List Control"}, 
           
  {"TAGLOBREG_XCLIP", 0x084C, g_csr_gfx_TA_XCLIP, "TA X Screen Clip"}, 
           
  {"TAGLOBREG_YCLIP", 0x0850, g_csr_gfx_TA_YCLIP, "TA Y Screen Clip"}, 
           
  {"TAGLOBREG_RHWCLAMP", 0x0854, g_csr_gfx_TA_RHWCLAMP, "TA RHW Clamp"}, 
           
  {"TAGLOBREG_RHWCOMP", 0x0858, g_csr_gfx_TA_RHWCOMP, "TA RHW Compare"}, 
           
  {"TAGLOBREG_CONFIG", 0x085C, g_csr_gfx_TA_CONFIG, "TA Configuration"}, 
           
  {"TAGLOBREG_3DSCREENSIZE", 0x0860, g_csr_gfx_3DSCREENSIZE, "3D Screen Size"}, 
           
  {"TAGLOBREG_EVM_CONTEXT_FLUSH_ADDR", 0x0864, g_csr_gfx_TA_EVM_CONTEXT_FLUSH_ADDR, "EVM Context Base Address"}, 
           
  {"TSP3_SIG", 0x0CC0, g_csr_gfx_TSP3_SIG, "TSP3 Signature"}, 

  {"ISP1_SIG", 0x0CC4, g_csr_gfx_ISP1_SIG, "ISP1 Signature"}, 
           
  {"TSP2_SIG", 0x0CC8, g_csr_gfx_TSP2_SIG, "TSP2 Signature"}, 
           
  {"TSP1_SIG", 0x0CCC, g_csr_gfx_TSP1_SIG, "TSP1 Signature"}, 
           
  {"TC_SIG", 0x0CD0, g_csr_gfx_TC_SIG, "Tex Cache Signature"}, 
           
  {"TA_DIAG", 0x0CD4, g_csr_gfx_TA_DIAG, "Tile Accelerator Diagnostics"}, 
           
  {"TA_STRIP_CNT", 0x0CD8, g_csr_gfx_TA_STRIP_CNT, "Tile Accelerator Strip Count"}, 
           
  {"DIAG_EN", 0x0CE0, g_csr_gfx_DIAG_EN, "Diagnostics Enable"}, 
           
  {"ISP2_SIG", 0x0CE4, g_csr_gfx_ISP2_SIG, "ISP2 Signature"}, 
           
  {"GLOBREG_CORE_ID", 0x0F00, g_csr_gfx_CORE_ID, "MBX Core ID"}, 
           
  {"GLOBREG_REVISION", 0x0F10, g_csr_gfx_REVISION, "MBX Core Revision"}, 
           
  {"GLOBREG_DSGN_REV1", 0x0F20, g_csr_gfx_DSGN_REV1, "MBX Designer Revision Field 1"}, 
           
  {"GLOBREG_DSGN_REV2", 0x0F30, g_csr_gfx_DSGN_REV2, "MBX Designer Revision Field 2"}, 
           
  {"GLOBREG_MMU_PAGE0_ADDR", 0x1000, g_csr_gfx_MMU_PAGE0_ADDR, "MMU Table Page 0 Address"}, 

  {"GLOBREG_MMU_PAGE1_ADDR", 0x1004, g_csr_gfx_MMU_PAGE1_ADDR, "MMU Table Page 1 Address"},

  {"GLOBREG_MMU_PAGE2_ADDR", 0x1008, g_csr_gfx_MMU_PAGE2_ADDR, "MMU Table Page 2 Address"},

  {"GLOBREG_MMU_PAGE3_ADDR", 0x100C, g_csr_gfx_MMU_PAGE3_ADDR, "MMU Table Page 3 Address"},

  {"GLOBREG_MMU_PAGE4_ADDR", 0x1010, g_csr_gfx_MMU_PAGE4_ADDR, "MMU Table Page 4 Address"},

  {"GLOBREG_MMU_PAGE5_ADDR", 0x1014, g_csr_gfx_MMU_PAGE5_ADDR, "MMU Table Page 5 Address"},

  {"GLOBREG_MMU_PAGE6_ADDR", 0x1018, g_csr_gfx_MMU_PAGE6_ADDR, "MMU Table Page 6 Address"},

  {"GLOBREG_MMU_PAGE7_ADDR", 0x101C, g_csr_gfx_MMU_PAGE7_ADDR, "MMU Table Page 7 Address"},
          
  {"GLOBREG_MMU_ENABLE", 0x1020, g_csr_gfx_MMU_ENABLE, "MMU Enable"}, 
           
  {"GLOBREG_MMU_IDX_INVAL", 0x1024, g_csr_gfx_MMU_IDX_INVAL, "MMU Index Invalidate"}, 
           
  {"GLOBREG_MMU_PHYSADD_INVAL", 0x1028, g_csr_gfx_MMU_PHYSADD_INVAL, "MMU Phys Add Invalidate"}, 

  { NULL }    /* NULL terminator */
};

#endif /* !SVEN_INTERNAL_BUILD */


/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */

static const struct SVEN_Module_EventSpecific g_GEN3_GFX_specific_events[] =
{
    { NULL, 0, "", NULL }
};

static const struct ModuleReverseDefs g_GEN3_GFX_sven_module =
{
    "GEN3_GFX",
    SVEN_module_GEN3_GFX,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN3_GFX,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MMOD: GFX Function (CM)",
    g_GEN3_GFX_specific_events,
    NULL                            /* extension list */
};
