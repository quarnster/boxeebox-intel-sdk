/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2008-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2008-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD


static const struct EAS_RegBits g_csr_gen3_GPIO_GPOUTR[] =
{
     { "RESERVED",      12, 20 },   // reserved
     { "GPIO_DATA",     0, 12 }, /* These 12 bits are GPIO output data pins for GPIO0 - GPIO11*/
     { NULL}    /* NULL Terminated */

};


static const struct EAS_RegBits g_csr_gen3_GPIO_GPIT1R0[] =
{

     { "GPIO_TYP7",      28, 4}, /* GPIO Interrupt Control for pins GPIO7*/     
     { "GPIO_TYP6",     24, 4}, /* GPIO Interrupt Control for pins GPIO6*/     
     { "GPIO_TYP5",      20, 4}, /* GPIO Interrupt Control for pins GPIO5*/     
     { "GPIO_TYP4",     16, 4}, /* GPIO Interrupt Control for pins GPIO4*/     
     { "GPIO_TYP3",      12, 4}, /* GPIO Interrupt Control for pins GPIO3*/     
     { "GPIO_TYP2",     8, 4}, /* GPIO Interrupt Control for pins GPIO2*/     
     { "GPIO_TYP1",      4, 4}, /* GPIO Interrupt Control for pins GPIO1*/     
     { "GPIO_TYP0",     0, 4}, /* GPIO Interrupt Control for pins GPIO0*/
     { NULL}    /* NULL Terminated */

};


static const struct EAS_RegBits g_csr_gen3_GPIO_mux_ctrl[] =
{

     { "RESERVED",           7, 25}, /* GPIO Interrupt Control for pins GPIO7*/     
     { "EXT_TS_MUX_CNTL",    6, 1}, /* GPIO or external thermal sensor*/     
     { "GBE_LINK_MUX_CNTL",  5, 1}, /* GPIO or GBE_Link pin*/     
     { "SC0_MUX_CTNL",       4, 1}, /* GPIO or Smart Card 0 pins*/     
     { "PUNIT_MUX_CNTL",     3, 1}, /* GPIO or Micro_TX0/Micro_Rx0*/     
     { "SC1_MUX_CNTL",       2, 1}, /* GPIO or Smart card 1*/     
     { "UART1_MUX_CNTL",     1, 1}, /* GPIO or UART1_RXD*/     
     { "UART0_MUX_CNTL",     0, 1}, /* GPIO or UART0*/
     { NULL}    /* NULL Terminated */

};



static const struct EAS_Register g_csr_gen3_gpio[] =
{

	{"GPIO_GPOUTR",     0x000,  g_csr_gen3_GPIO_GPOUTR, "GPIO 0:11 pin data output register."},
	{"GPIO_GPOER",      0x004,  g_csr_gen3_GPIO_GPOUTR, "GPIO 0:11 pin output driving register."},
	{"GPIO_GPINR",      0x008,  g_csr_gen3_GPIO_GPOUTR, "GPIO 0:11 pin status input level register."},
	{"GPIO_GPSTR",      0x00C,  g_csr_gen3_GPIO_GPOUTR, "GPIO 0:11 interrupt status register."},
	{"GPIO_GPIT1R0",    0x010,  g_csr_gen3_GPIO_GPIT1R0,"GPIO 0:7 interrupt type and control register."},
	{"GPIO_INT",        0x014,  g_csr_gen3_GPIO_GPOUTR, "GPIO interrupt register."},
   {"GPIO_GPIT1R1",    0x018,  NULL,              "GPIO 8:11 interrupt type and control register."},
	{"GPIO_MUX_CNTL",   0x01C,  g_csr_gen3_GPIO_mux_ctrl,"GPIO mux control register."},   
   { NULL,0,0,"",NULL }    /* NULL Terminated */

};


#endif /* !SVEN_INTERNAL_BUILD */






/*	Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_gen3_GPIO_specific_events[] =
{

	{ NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_gen3_GPIO_sven_module =
{
	"GEN3_GPIO",
	SVEN_module_GEN3_GPIO,
	256,
#ifdef SVEN_INTERNAL_BUILD
	g_csr_gen3_gpio,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
	"MMOD: GPIO Function (GEN3)",   	/* TODO: Get a better text string */
	g_gen3_GPIO_specific_events,   		/* TODO-Later: Define important events specific to my module */
	NULL 							/* extension list */
};
