/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

//****************************************************************************//
// Filename: csr_ce31xx_cw.h                                                      //
// Description: address definitions for CW registers                         //
// Source: DfX Seaction 52 CM EAS version 0.90 5/14/07
//****************************************************************************//
#ifndef _CE31XX_CWREG_H_
#define _CE31XX_CWREG_H_

//****************************************************************************//
//Top Level address definitions
//****************************************************************************//
//#define DFXUNIT_MBAR 0xFF8F0000
#define DFXUNIT_MBAR 0

//****************************************************************************//
// Functional Unit CW Offsets
// to be added to the specific CW and the MBAR definition
//****************************************************************************//
//Offset	Symbol	Register Name/Function	Default
//0100h	cw_global_control	Global Chipwatcher Control	00000000h
#define cw_global_control_off 			0x100
//0104-0108h		Reserved 	00000000h
//010Ch	cw_skew_clks_cntrl	CW Skew Control for cw_clk1 and cw_clk2	00000000h
#define	cw_skew_clks_cntrl_off			0x10C
//0110h	cw_skew7_0_cntrl	CW Skew Control Register for Bus bits 7-0	00000000h
#define cw_skew7_0_cntrl_off			0x110
//0114h	cw_skew15_8_cntrl	CW Skew Control Register for Bus bits 15-8	00000000h
#define cw_skew15_8_cntrl_off			0x114
//0118h	cw_skew23_16_cntrl	CW Skew Control Register for Bus bits 23-16	00000000h
#define	cw_skew23_16_cntrl_off			0x118
//011Ch	cw_skew31_24_cntrl	CW Skew Control Register for Bus bits 31-24	00000000h
#define cw_skew31_24_cntrl_off			0x11c
//0120h	cw_chain0_ctrl	CW Chain0 control 	00000000h
#define	cw_chain0_ctrl_off				0x120
//0124h	cw_chain1_ctrl	CW Chain1 control 	00000000h
#define	cw_chain1_ctrl_off				0x124
//0128h	cw_chain2_ control	CW Chain2 control 	00000000h
#define	cw_chain2_ctrl_off				0x128
//012Ch	cw_chain3_ control	CW Chain3 control 	00000000h
#define	cw_chain3_ctrl_off				0x12c
//0130h	cw_chain4_ control	CW Chain4 control 	00000000h
#define	cw_chain4_ctrl_off				0x130
//0134h	cw_chain5_ control	CW Chain5 control 	00000000h
#define	cw_chain5_ctrl_off				0x134
//0138h	cw_chain6_ control	CW Chain6 control 	00000000h
#define	cw_chain6_ctrl_off				0x138
//013Ch	cw_chain7_ control	CW Chain7 control 	00000000h
#define	cw_chain7_ctrl_off				0x13c
//0140h-014Fh		Reserved	00000000h
//0150h	usb_mux_control	    USB Pre-CW mux control	00000000h
#define	cw_usb_mux_ctrl_off				0x150
//0154h	sata_mux_control	SATA Pre-CW mux control	00000000h
#define	cw_sata_mux_ctrl_off				0x154
//0158h	pcie_mux_control	PCIe Pre-CW mux control	00000000h
#define	cw_pcie_mux_ctrl_off				0x158
//015Ch-017Fh		Reserved	00000000h
//0180h	cw_clk_sel_ctrl	CW Clock Select Control	00000000h
#define	cw_clk_sel_ctrl_off				0x180
//0184h-018Fh		Reserved	00000000h
//0190h	cw_byte07_00 _mux_ctrl	CW Byte Mux 07:00 Select Control	00000000h
#define	cw_byte07_00_mux_ctrl_off		0x190
//0194h	cw_byte15_08 _mux_ctrl	CW Byte Mux 15:08 Select Control	00000000h
#define cw_byte15_08_mux_ctrl_off		0x194
//0198h	cw_byte23_16 _mux_ctrl	CW Byte Mux 23:16 Select Control	00000000h
#define	cw_byte23_16_mux_ctrl_off		0x198
//019Ch	cw_byte31_24 _mux_ctrl	CW Byte Mux 31:24 Select Control	00000000h
#define	cw_byte31_24_mux_ctrl_off		0x19c
//01A0h-01AFh		Reserved	00000000h
//01B0h	cw_bit07_00 _mux_ctrl	CW Bit Mux 07:00 Select Control	00000000h
#define	cw_bit07_00_mux_ctrl_off		0x1b0
//01B4h	cw_bit15_08 _mux_ctrl	CW Bit Mux 15:08 Select Control	00000000h
#define	cw_bit15_08_mux_ctrl_off		0x1b4
//01B8h	cw_bit23_16 _mux_ctrl	CW Bit Mux 23:16 Select Control	00000000h
#define	cw_bit23_16_mux_ctrl_off		0x1b8
//01BCh	cw_bit31_24 _mux_ctrl	CW Bit Mux 31:24 Select Control	00000000h
#define	cw_bit31_24_mux_ctrl_off		0x1bc
//01C0h-01FFh		Reserved	00000000h

//****************************************************************************//
// Functional Unit CW Registers
// with some of the bit definitions
//****************************************************************************//
#define	cw_global_control		(DFXUNIT_MBAR+cw_global_control_off)
#define	gcCW_MMR_EN_WIDTH	1
#define	gcCW_MMR_EN_BIT		0x1F
#define	gcCW_MMR_EN			(1<<gcCW_MMR_ENBIT)
#define gcCW32_EN_WIDTH		1
#define gcCW32_ENBIT			1
#define gcCW32_EN				(1<<gcCW32_ENBIT)
#define gcCW16_EN_WIDTH		1
#define gcCW16_ENBIT			0
#define gcCW16_EN				(1<<gcCW16_ENBIT)

#define	cw_skew_clks_cntrl		(DFXUNIT_MBAR+cw_skew_clks_cntrl_off)
#define	cw_skew7_0_cntrl		(DFXUNIT_MBAR+cw_skew7_0_cntrl_off)
#define	cw_skew15_8_cntrl		(DFXUNIT_MBAR+cw_skew15_8_cntrl_off)
#define	cw_skew23_16_cntrl		(DFXUNIT_MBAR+cw_skew23_16_cntrl_off)
#define	cw_skew31_24_cntrl		(DFXUNIT_MBAR+cw_skew31_24_cntrl_off)

#define	cw_chain0_ctrl			(DFXUNIT_MBAR+cw_chain0_ctrl_off)
#define	bcP2SEL_BIT			0x10
#define	bcP2SEL_WIDTH			3
#define bcP1SEL_BIT				0xD
#define bcP1SEL_WIDTH			3
#define bcFLPBP_BIT				0xB
#define bcFLPBP_WIDTH			2
#define bcFLPBP_FD				(0<<bcFLPBP_BIT)
#define bcFLPBP_BFC				(1<<bcFLPBP_BIT)
#define bcFLPBP_BFP				(2<<bcFLPBP_BIT)
#define bcFLPBP_BFA				(3<<bcFLPBP_BIT)
#define	bcTEBP_BIT				0xA
#define	bcTEBP_WIDTH 			1
#define bcBLKID2_BIT				5
#define bcBLKID2_WIDTH			1
#define bcBLKID1_BIT				0
#define bcBLKID1_WIDTH			5
#define bcBLKID_COUNTER		0x1F

//example	mmiowrite(cw_chain1_ctrl, ((cscCHAIN0CLK1 << cscCLK2_SEL_BIT) | (cscCHAIN3CLK1 << cscCLK1_SEL_BIT));
//selects clk2 = chain0 clock1, and clk1 = chain3 clock1
#define	cw_chain1_ctrl			(DFXUNIT_MBAR+cw_chain1_ctrl_off)
#define	cw_chain2_ctrl			(DFXUNIT_MBAR+cw_chain2_ctrl_off)
#define	cw_chain3_ctrl			(DFXUNIT_MBAR+cw_chain3_ctrl_off)
#define	cw_chain4_ctrl			(DFXUNIT_MBAR+cw_chain4_ctrl_off)
#define	cw_chain5_ctrl			(DFXUNIT_MBAR+cw_chain5_ctrl_off)
#define	cw_chain6_ctrl			(DFXUNIT_MBAR+cw_chain6_ctrl_off)
#define	cw_chain7_ctrl			(DFXUNIT_MBAR+cw_chain7_ctrl_off)

#define cw_usb_mux_control		(DFXUNIT_MBAR+cw_usb_mux_ctrl_off)
#define umcUpperBusSwapBIT		20
#define umcUpperBusSwapWIDTH	1
#define umcUpperBusClkSelBIT	17
#define umcUpperBusClkSelWIDTH	3
#define umcLowerBusClkSelBIT	14
#define umcLowerBusClkSelWIDTH	3
#define umcUpperBusTblSelBIT	8
#define umcUpperBusTblSelWIDTH	6
#define umcLowerBusTblSelBIT	2
#define umcLowerBusTblSelWIDTH	6
#define umcUpperUSBSelBIT		1
#define umcUpperUSBSelWIDTH	1
#define umcLowerUSBSelBIT		0
#define umcLowerUSBSelWIDTH	1

#define cw_sata_mux_control   	(DFXUNIT_MBAR+cw_sata_mux_ctrl_off)
#define smcUpperBusSwapBIT		16
#define smcUpperBusSwapWIDTH	1
#define smcUpperBusTblSelBIT	8
#define smcUpperBusTblSelWIDTH	8
#define smcLowerBusTblSelBIT	0
#define smcLowerBusTblSelWIDTH	8

#define cw_pcie_mux_control  	(DFXUNIT_MBAR+cw_pcie_mux_ctrl_off)
#define pmcUpperBusClkSelBIT	19
#define pmcUpperBusClkSelWIDTH	3
#define pmcLowerBusClkSelBIT	16
#define pmcLowerBusClkSelWIDTH	3
#define pmcUpperBusTblSelBIT	9
#define pmcUpperBusTblSelWIDTH	7
#define pmcLowerBusTblSelBIT	2
#define pmcLowerBusTblSelWIDTH	7
#define pmcUpperBusLaneSelBIT	1
#define pmcUpperBusLaneSelWIDTH	1
#define pmcLowerBusLaneSelBIT	0
#define pmcLowerBusLaneSelWIDTH	1

#define	cw_clk_sel_ctrl			(DFXUNIT_MBAR+cw_clk_sel_ctrl_off)
#define	cscCLK2_SEL_BIT		4
#define	cscCLK2_SEL_WIDTH		4
#define	cscCLK1_SEL_BIT		0
#define	cscCLK1_SEL_WIDTH		4
#define cscCHAIN0CLK1			0
#define cscCHAIN0CLK2			1
#define cscCHAIN1CLK1			2
#define cscCHAIN1CLK2			3
#define cscCHAIN2CLK1			4
#define cscCHAIN2CLK2			5
#define cscCHAIN3CLK1			6
#define cscCHAIN3CLK2			7
#define cscCHAIN4CLK1			8
#define cscCHAIN4CLK2			9
#define cscCHAIN5CLK1			0xA
#define cscCHAIN5CLK2			0xB
#define cscCHAIN6CLK1			0xC
#define cscCHAIN6CLK2			0xD
#define cscCHAIN7CLK1			0xE
#define cscCHAIN7CLK2			0xF

//example mmiowrite(cw_byte07_00_mux_ctrl, (bmcCHAIN0_LSB << bmcBYTE7_SEL_BIT));
//sets byte7-0 = chain0[7:0], repeat for the other 7 selections (bmcBYTE[6:0]_SEL_BIT)
#define	cw_byte07_00_mux_ctrl	(DFXUNIT_MBAR+cw_byte07_00_mux_ctrl_off)
#define	bmcBYTE7_SEL_BIT		0x1C
#define	bmcBYTE_SEL_WIDTH	4
#define	bmcBYTE6_SEL_BIT		0x18
#define	bmcBYTE5_SEL_BIT		0x14
#define	bmcBYTE4_SEL_BIT		0x10
#define	bmcBYTE3_SEL_BIT		0xC
#define	bmcBYTE2_SEL_BIT		8
#define	bmcBYTE1_SEL_BIT		4
#define	bmcBYTE0_SEL_BIT		0
#define bmcCHAIN0_LSB			0
#define bmcCHAIN0_MSB			1
#define bmcCHAIN1_LSB			2
#define bmcCHAIN1_MSB			3
#define bmcCHAIN2_LSB			4
#define bmcCHAIN2_MSB			5
#define bmcCHAIN3_LSB			6
#define bmcCHAIN3_MSB			7
#define bmcCHAIN4_LSB			8
#define bmcCHAIN4_MSB			9
#define bmcCHAIN5_LSB			0xA
#define bmcCHAIN5_MSB			0xB
#define bmcCHAIN6_LSB			0xC
#define bmcCHAIN6_MSB			0xD
#define bmcCHAIN7_LSB			0xE
#define bmcCHAIN7_MSB			0xF

#define	cw_byte15_08_mux_ctrl	(DFXUNIT_MBAR+cw_byte15_08_mux_ctrl_off)
#define	cw_byte23_16_mux_ctrl	(DFXUNIT_MBAR+cw_byte23_16_mux_ctrl_off)
#define	cw_byte31_24_mux_ctrl	(DFXUNIT_MBAR+cw_byte31_24_mux_ctrl_off)

//example mmiowrite(cw_bit07_00_mux_ctrl, (bmcBIT0 << bmcBIT7_SEL_BIT));
//sets bits[7] = Bit0, repeat for the other 7 bits
#define	cw_bit07_00_mux_ctrl	(DFXUNIT_MBAR+cw_bit07_00_mux_ctrl_off)
#define	bmcBIT7_SEL_BIT		0x15
#define	bmcBIT_SEL_WIDTH		3
#define	bmcBIT6_SEL_BIT		0x12
#define	bmcBIT5_SEL_BIT		0xF
#define	bmcBIT4_SEL_BIT		0xC
#define	bmcBIT3_SEL_BIT		9
#define	bmcBIT2_SEL_BIT		6
#define	bmcBIT1_SEL_BIT		3
#define	bmcBIT0_SEL_BIT		0
#define bmcBIT0					0
#define bmcBIT1					1
#define bmcBIT2					2
#define bmcBIT3					3
#define bmcBIT4					4
#define bmcBIT5					5
#define bmcBIT6					6
#define bmcBIT7					7

#define	cw_bit15_08_mux_ctrl	(DFXUNIT_MBAR+cw_bit15_08_mux_ctrl_off)
#define	cw_bit23_16_mux_ctrl	(DFXUNIT_MBAR+cw_bit23_16_mux_ctrl_off)
#define	cw_bit31_24_mux_ctrl	(DFXUNIT_MBAR+cw_bit31_24_mux_ctrl_off)

#endif	//#ifndef _CE31XX_CWREG_H_

