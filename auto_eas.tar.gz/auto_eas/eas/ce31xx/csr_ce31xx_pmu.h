/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

//****************************************************************************//
// Filename: csr_cd31xx_pmu.h                                                      //
// Description: address definitions for PMU registers                         //
// Source: DfX Seaction 53 CM EAS version 0.91 4/18/07
//****************************************************************************//
#ifndef _CE31XX_PMUREG_H_
#define _CE31XX_PMUREG_H_

//****************************************************************************//
//Top Level address definitions
//****************************************************************************//
//#define DFXUNIT_MBAR 0xFF8F0000
#define DFXUNIT_MBAR 0
#define PMU_off 0x1000

//****************************************************************************//
// Functional Unit PMU Offsets
// to be added to the specific PMU and the MBAR definition
//****************************************************************************//
//	00H	pmu0_control	PMU0 Control Register	00000000h
#define PMU_control_off 			0x00

#define tcGlobalDisableBIT	0x1F
#define tcGlobalDisableWIDTH 1
#define tcGlobalDisable	(1<<tcGlobalDisableBIT)

#define tcOverflowBIT	0x0E
#define tcOverflowWIDTH	2
#define tcOverflowInput0 (0<<tcOverflowBIT)
#define tcOverflowInput1 (1<<tcOverflowBIT)
#define tcOverflowInput2 (2<<tcOverflowBIT)

#define tcInput0BIT		8
#define tcInput1BIT		0x0A
#define tcInput2BIT		0x0C
#define tcInputWIDTH	2
#define tcDurationInput	0
#define tcEdgeInput		1
#define tcTimerInput	2
#define tcDurationInput2	(tcDurationInput<<tcInput2BIT)
#define tcDurationInput1	(tcDurationInput<<tcInput1BIT)
#define tcDurationInput0	(tcDurationInput<<tcInput0BIT)
#define tcEdgeInput2	(tcEdgeInput<<tcInput2BIT)
#define tcEdgeInput1	(tcEdgeInput<<tcInput1BIT)
#define tcEdgeInput0	(tcEdgeInput<<tcInput0BIT)
#define tcTimerInput2	(tcTimerInput<<tcInput2BIT)
#define tcTimerInput1	(tcTimerInput<<tcInput1BIT)
#define tcTimerInput0	(tcTimerInput<<tcInput0BIT)

#define tcOverflowResetBIT 7
#define tcOverflowResetWIDTH 1
#define tcOverflowReset (1<<tcOverflowResetBIT)
#define tcCounterResetWIDTH 1
#define tcCounterReset2BIT 6
#define tcCounterReset2 (1<<tcCounterReset2BIT)
#define tcCounterReset1BIT 5
#define tcCounterReset1 (1<<tcCounterReset1BIT)
#define tcCounterReset0BIT 4
#define tcCounterReset0 (1<<tcCounterReset0BIT)
#define tcOverflowEnableWIDTH 1
#define tcOverflowEnableBIT 3
#define tcOverflowEnable (1<<tcOverflowEnableBIT)
#define tcCounterEnable2BIT 2
#define tcCounterEnableWIDTH 1
#define tcCounterEnable2 (1<<tcCounterEnable2BIT)
#define tcCounterEnable1BIT 1
#define tcCounterEnable1 (1<<tcCounterEnable1BIT)
#define tcCounterEnable0BIT 0
#define tcCounterEnable0 (1<<tcCounterEnable0)

//	04H	pmu0_counter_select	PMU0 Counter Event Selection Register	00000000h
#define PMU_counter_select_off		0x04
#define csEventCountWIDTH	5
#define csEventCount2_shift	0xA
#define csEventCount1_shift	5
#define csEventCount0_shift	0

//	08H	pmu0_int_enable	PMU0 Interrupt Enable Register	00000000h
#define PMU_int_enable_off	 		0x08
#define ieCounter0EnableWIDTH	1
#define ieCounter0EnableBIT	0
#define ieCounter0Enable	(1<<ieCounter0EnableBIT)
#define ieCounter1EnableBIT	1
#define ieCounter1Enable	(1<<ieCounter1EnableBIT)
#define ieCounter2EnableBIT	2
#define ieCounter2Enable	(1<<ieCounter2EnableBIT)

//	0CH	pmu0_int_status	PMU0 Interrupt Status Register	00000000h
#define PMU_int_status_off			0x0C
#define isCounter0ThreshBIT	0
#define isCounterThreshWIDTH	1
#define isCounter0Thresh	(1<<isCounter0ThreshBIT)
#define isCounter1ThreshBIT	1
#define isCounter1Thresh	(1<<isCounter1ThreshBIT)
#define isCounter2ThreshBIT	2
#define isCounter2Thresh	(1<<isCounter2ThreshBIT)
#define isPMUThreshWIDTH	0x3
#define isPMU0ThreshBIT	0x10
#define isPMU0Count0Thresh	(isCounter0Thresh<<isPMU0ThreshBIT)
#define isPMU0Count1Thresh	(isCounter1Thresh<<isPMU0ThreshBIT)
#define isPMU0Count2Thresh	(isCounter2Thresh<<isPMU0ThreshBIT)
#define isPMU1ThreshBIT	0x13
#define isPMU1Count0Thresh	(isCounter0Thresh<<isPMU1ThreshBIT)
#define isPMU1Count1Thresh	(isCounter1Thresh<<isPMU1ThreshBIT)
#define isPMU1Count2Thresh	(isCounter2Thresh<<isPMU1ThreshBIT)
#define isPMU2ThreshBIT	0x16
#define isPMU2Count0Thresh	(isCounter0Thresh<<isPMU2ThreshBIT)
#define isPMU2Count1Thresh	(isCounter1Thresh<<isPMU2ThreshBIT)
#define isPMU2Count2Thresh	(isCounter2Thresh<<isPMU2ThreshBIT)
#define isPMU3ThreshBIT	0x19
#define isPMU3Count0Thresh	(isCounter0Thresh<<isPMU3ThreshBIT)
#define isPMU3Count1Thresh	(isCounter1Thresh<<isPMU3ThreshBIT)
#define isPMU3Count2Thresh	(isCounter2Thresh<<isPMU3ThreshBIT)

//	10H	pmu0_event_count0_thrsh	PMU0 Event Count0 Threshold Register	FFFFFFFFh
#define	PMU_event_count0_thrsh_off	0x10
//	14H	pmu0_event_count1_thrsh	PMU0 Event Count1 Threshold Register	FFFFFFFFh
#define	PMU_event_count1_thrsh_off	0x14
//	18H	pmu0_event_count2_thrsh	PMU0 Event Count2 Threshold Register	FFFFFFFFh
#define	PMU_event_count2_thrsh_off	0x18
//	1CH	pmu0_event_count0	PMU0 Event Count0 Register	00000000h
#define PMU_event_count0_off		0x1C
//	20H	pmu0_event_count1	PMU0 Event Count1 Register	00000000h
#define PMU_event_count1_off		0x20
//	24H	pmu0_event_count2	PMU0 Event Count2 Register	00000000h
#define PMU_event_count2_off		0x24
//	28H	pmu0_overflow_count	PMU0 Overflow Counter Register	00000000h
#define PMU_overflow_count_off		0x28
//	2CH		Reserved	00000000h
//	30H	pmu0_start_stop_ctrl0	PMU0 Counter 0 Start/Stop Control Register	00000000h
#define PMU_start_stop_ctrl0_off	0x30
#define ssPmuStartStopWIDTH	2
#define ssPmu0Count0startBIT	0
#define ssPmu0Count0start	(1<<ssPmu0Count0startBIT)
#define ssPmu0Count0stop	(2<<ssPmu0Count0startBIT)
#define ssPmu0Count1startBIT	2
#define ssPmu0Count1start	(1<<ssPmu0Count1startBIT)
#define ssPmu0Count1stop	(2<<ssPmu0Count1startBIT)
#define ssPmu0Count2startBIT	4
#define ssPmu0Count2start	(1<<ssPmu0Count2startBIT)
#define ssPmu0Count2stop	(2<<ssPmu0Count2startBIT)
#define ssPmu1Count0startBIT	6
#define ssPmu1Count0start	(1<<ssPmu1Count0startBIT)
#define ssPmu1Count0stop	(2<<ssPmu1Count0startBIT)
#define ssPmu1Count1startBIT	8
#define ssPmu1Count1start	(1<<ssPmu1Count1startBIT)
#define ssPmu1Count1stop	(2<<ssPmu1Count1startBIT)
#define ssPmu1Count2startBIT	0xA
#define ssPmu1Count2start	(1<<ssPmu1Count2startBIT)
#define ssPmu1Count2stop	(2<<ssPmu1Count2startBIT)
#define ssPmu2Count0startBIT	0xC
#define ssPmu2Count0start	(1<<ssPmu2Count0startBIT)
#define ssPmu2Count0stop	(2<<ssPmu2Count0startBIT)
#define ssPmu2Count1startBIT	0xE
#define ssPmu2Count1start	(1<<ssPmu2Count1startBIT)
#define ssPmu2Count1stop	(2<<ssPmu2Count1startBIT)
#define ssPmu2Count2startBIT	0x10
#define ssPmu2Count2start	(1<<ssPmu2Count2startBIT)
#define ssPmu2Count2stop	(2<<ssPmu2Count2startBIT)
#define ssPmu3Count0startBIT	0x12
#define ssPmu3Count0start	(1<<ssPmu3Count0startBIT)
#define ssPmu3Count0stop	(2<<ssPmu3Count0startBIT)
#define ssPmu3Count1startBIT	0x14
#define ssPmu3Count1start	(1<<ssPmu3Count1startBIT)
#define ssPmu3Count1stop	(2<<ssPmu3Count1startBIT)
#define ssPmu3Count2startBIT	0x16
#define ssPmu3Count2start	(1<<ssPmu3Count1startBIT)
#define ssPmu3Count2stop	(2<<ssPmu3Count1startBIT)

//	34H	pmu0_start_stop_ctrl1	PMU0 Counter 1 Start/Stop Control Register	00000000h
#define PMU_start_stop_ctrl1_off	0x34
//	38H	pmu0_start_stop_ctrl2	PMU0 Counter 2 Start/Stop Control Register	00000000h
#define PMU_start_stop_ctrl2_off	0x38
//	3C-FFh		Reserved	00000000h

//****************************************************************************//
//PMU0 Functional unit
//PMU0 from MBAR and PMU offset is 0x000
//****************************************************************************//
#define PMU0_off (PMU_off+0x000)
//	1000H	pmu0_control	PMU0 Control Register	00000000h
#define pmu0_control 				(DFXUNIT_MBAR+PMU0_off+PMU_control_off)
//	1004H	pmu0_counter_select	PMU0 Counter Event Selection Register	00000000h
#define pmu0_counter_select			(DFXUNIT_MBAR+PMU0_off+PMU_counter_select_off)
//	1008H	pmu0_int_enable	PMU0 Interrupt Enable Register	00000000h
#define pmu0_int_enable				(DFXUNIT_MBAR+PMU0_off+PMU_int_enable_off)
//	100CH	pmu0_int_status	PMU0 Interrupt Status Register	00000000h
#define pmu0_int_status				(DFXUNIT_MBAR+PMU0_off+PMU_int_status_off)
//	1010H	pmu0_event_count0_thrsh	PMU0 Event Count0 Threshold Register	FFFFFFFFh
#define pmu0_event_count0_thrsh		(DFXUNIT_MBAR+PMU0_off+PMU_event_count0_thrsh_off)
//	1014H	pmu0_event_count1_thrsh	PMU0 Event Count1 Threshold Register	FFFFFFFFh
#define pmu0_event_count1_thrsh		(DFXUNIT_MBAR+PMU0_off+PMU_event_count1_thrsh_off)
//	1018H	pmu0_event_count2_thrsh	PMU0 Event Count2 Threshold Register	FFFFFFFFh
#define pmu0_event_count2_thrsh		(DFXUNIT_MBAR+PMU0_off+PMU_event_count2_thrsh_off)
//	101CH	pmu0_event_count0	PMU0 Event Count0 Register	00000000h
#define pmu0_event_count0			(DFXUNIT_MBAR+PMU0_off+PMU_event_count0_off)
//	1020H	pmu0_event_count1	PMU0 Event Count1 Register	00000000h
#define pmu0_event_count1			(DFXUNIT_MBAR+PMU0_off+PMU_event_count1_off)
//	1024H	pmu0_event_count2	PMU0 Event Count2 Register	00000000h
#define pmu0_event_count2			(DFXUNIT_MBAR+PMU0_off+PMU_event_count2_off)
//	1028H	pmu0_overflow_count	PMU0 Overflow Counter Register	00000000h
#define pmu0_overflow_count			(DFXUNIT_MBAR+PMU0_off+PMU_overflow_count_off)
//	102CH		Reserved	00000000h
//	1030H	pmu0_start_stop_ctrl0	PMU0 Counter 0 Start/Stop Control Register	00000000h
#define pmu0_start_stop_ctrl0		(DFXUNIT_MBAR+PMU0_off+PMU_start_stop_ctrl0_off)
//	1034H	pmu0_start_stop_ctrl1	PMU0 Counter 1 Start/Stop Control Register	00000000h
#define pmu0_start_stop_ctrl1		(DFXUNIT_MBAR+PMU0_off+PMU_start_stop_ctrl1_off)
//	1038H	pmu0_start_stop_ctrl2	PMU0 Counter 2 Start/Stop Control Register	00000000h
#define pmu0_start_stop_ctrl2		(DFXUNIT_MBAR+PMU0_off+PMU_start_stop_ctrl2_off)
//	103C-10FFh		Reserved	00000000h

//****************************************************************************//
//PMU1 Functional unit
//PMU1 from MBAR and PMU offset is 0x100
//****************************************************************************//
#define PMU1_off PMU_off+0x100
//	1100H	pmu1_control	PMU1 Control Register	00000000h
#define pmu1_control 				DFXUNIT_MBAR+PMU1_off+PMU_control_off
//	1104H	pmu1_counter_select	PMU1 Counter Event Selection Register	00000000h
#define pmu1_counter_select			DFXUNIT_MBAR+PMU1_off+PMU_counter_select_off
//	1108H	pmu1_int_enable	PMU1 Interrupt Enable Register	00000000h
#define pmu1_int_enable				DFXUNIT_MBAR+PMU1_off+PMU_int_enable_off
//	110CH	pmu1_int_status	PMU1 Interrupt Status Register	00000000h
#define pmu1_int_status				DFXUNIT_MBAR+PMU1_off+PMU_int_status_off
//	1110H	pmu1_event_count0_thrsh	PMU1 Event Count0 Threshold Register	FFFFFFFFh
#define pmu1_event_count0_thrsh		DFXUNIT_MBAR+PMU1_off+PMU_event_count0_thrsh_off
//	1114H	pmu1_event_count1_thrsh	PMU1 Event Count1 Threshold Register	FFFFFFFFh
#define pmu1_event_count1_thrsh		DFXUNIT_MBAR+PMU1_off+PMU_event_count1_thrsh_off
//	1118H	pmu1_event_count2_thrsh	PMU1 Event Count2 Threshold Register	FFFFFFFFh
#define pmu1_event_count2_thrsh		DFXUNIT_MBAR+PMU1_off+PMU_event_count2_thrsh_off
//	111CH	pmu1_event_count0	PMU1 Event Count0 Register	00000000h
#define pmu1_event_count0			DFXUNIT_MBAR+PMU1_off+PMU_event_count0_off
//	1120H	pmu1_event_count1	PMU1 Event Count1 Register	00000000h
#define pmu1_event_count1			DFXUNIT_MBAR+PMU1_off+PMU_event_count1_off
//	1124H	pmu1_event_count2	PMU1 Event Count2 Register	00000000h
#define pmu1_event_count2			DFXUNIT_MBAR+PMU1_off+PMU_event_count2_off
//	1128H	pmu1_overflow_count	PMU1 Overflow Counter Register	00000000h
#define pmu1_overflow_count			DFXUNIT_MBAR+PMU1_off+PMU_overflow_count_off
//	112CH		Reserved	00000000h
//	1130H	pmu1_start_stop_ctrl0	PMU1 Counter 0 Start/Stop Control Register	00000000h
#define pmu1_start_stop_ctrl0		DFXUNIT_MBAR+PMU1_off+PMU_start_stop_ctrl0_off
//	1134H	pmu1_start_stop_ctrl1	PMU1 Counter 1 Start/Stop Control Register	00000000h
#define pmu1_start_stop_ctrl1		DFXUNIT_MBAR+PMU1_off+PMU_start_stop_ctrl1_off
//	1138H	pmu1_start_stop_ctrl2	PMU1 Counter 2 Start/Stop Control Register	00000000h
#define pmu1_start_stop_ctrl2		DFXUNIT_MBAR+PMU1_off+PMU_start_stop_ctrl2_off
//	113C-11FFh		Reserved	00000000h

//****************************************************************************//
//PMU2 Functional unit
//PMU2 from MBAR and PMU offset is 0x200
//****************************************************************************//
#define PMU2_off PMU_off+0x200
//	1200H	pmu2_control	PMU2 Control Register	00000000h
#define pmu2_control 				DFXUNIT_MBAR+PMU2_off+PMU_control_off
//	1204H	pmu2_counter_select	PMU2 Counter Event Selection Register	00000000h
#define pmu2_counter_select			DFXUNIT_MBAR+PMU2_off+PMU_counter_select_off
//	1208H	pmu2_int_enable	PMU2 Interrupt Enable Register	00000000h
#define pmu2_int_enable				DFXUNIT_MBAR+PMU2_off+PMU_int_enable_off
//	120CH	pmu2_int_status	PMU2 Interrupt Status Register	00000000h
#define pmu2_int_status				DFXUNIT_MBAR+PMU2_off+PMU_int_status_off
//	1210H	pmu2_event_count0_thrsh	PMU2 Event Count0 Threshold Register	FFFFFFFFh
#define pmu2_event_count0_thrsh		DFXUNIT_MBAR+PMU2_off+PMU_event_count0_thrsh_off
//	1214H	pmu2_event_count1_thrsh	PMU2 Event Count1 Threshold Register	FFFFFFFFh
#define pmu2_event_count1_thrsh		DFXUNIT_MBAR+PMU2_off+PMU_event_count1_thrsh_off
//	1218H	pmu2_event_count2_thrsh	PMU2 Event Count2 Threshold Register	FFFFFFFFh
#define pmu2_event_count2_thrsh		DFXUNIT_MBAR+PMU2_off+PMU_event_count2_thrsh_off
//	121CH	pmu2_event_count0	PMU2 Event Count0 Register	00000000h
#define pmu2_event_count0			DFXUNIT_MBAR+PMU2_off+PMU_event_count0_off
//	1220H	pmu2_event_count1	PMU2 Event Count1 Register	00000000h
#define pmu2_event_count1			DFXUNIT_MBAR+PMU2_off+PMU_event_count1_off
//	1224H	pmu2_event_count2	PMU2 Event Count2 Register	00000000h
#define pmu2_event_count2			DFXUNIT_MBAR+PMU2_off+PMU_event_count2_off
//	1228H	pmu2_overflow_count	PMU2 Overflow Counter Register	00000000h
#define pmu2_overflow_count			DFXUNIT_MBAR+PMU2_off+PMU_overflow_count_off
//	122CH		Reserved	00000000h
//	1230H	pmu2_start_stop_ctrl0	PMU2 Counter 0 Start/Stop Control Register	00000000h
#define pmu2_start_stop_ctrl0		DFXUNIT_MBAR+PMU2_off+PMU_start_stop_ctrl0_off
//	1234H	pmu2_start_stop_ctrl1	PMU2 Counter 1 Start/Stop Control Register	00000000h
#define pmu2_start_stop_ctrl1		DFXUNIT_MBAR+PMU2_off+PMU_start_stop_ctrl1_off
//	1238H	pmu2_start_stop_ctrl2	PMU2 Counter 2 Start/Stop Control Register	00000000h
#define pmu2_start_stop_ctrl2		DFXUNIT_MBAR+PMU2_off+PMU_start_stop_ctrl2_off
//	123C-11FFh		Reserved	00000000h

//****************************************************************************//
//PMU3 Functional unit
//PMU3 from MBAR and PMU offset is 0x300
//****************************************************************************//
#define PMU3_off PMU_off+0x300
//	1300H	pmu3_control	PMU3 Control Register	00000000h
#define pmu3_control 				DFXUNIT_MBAR+PMU3_off+PMU_control_off
//	1304H	pmu3_counter_select	PMU3 Counter Event Selection Register	00000000h
#define pmu3_counter_select			DFXUNIT_MBAR+PMU3_off+PMU_counter_select_off
//	1308H	pmu3_int_enable	PMU3 Interrupt Enable Register	00000000h
#define pmu3_int_enable				DFXUNIT_MBAR+PMU3_off+PMU_int_enable_off
//	130CH	pmu3_int_status	PMU3 Interrupt Status Register	00000000h
#define pmu3_int_status				DFXUNIT_MBAR+PMU3_off+PMU_int_status_off
//	1310H	pmu3_event_count0_thrsh	PMU3 Event Count0 Threshold Register	FFFFFFFFh
#define pmu3_event_count0_thrsh		DFXUNIT_MBAR+PMU3_off+PMU_event_count0_thrsh_off
//	1314H	pmu3_event_count1_thrsh	PMU3 Event Count1 Threshold Register	FFFFFFFFh
#define pmu3_event_count1_thrsh		DFXUNIT_MBAR+PMU3_off+PMU_event_count1_thrsh_off
//	1318H	pmu3_event_count2_thrsh	PMU3 Event Count2 Threshold Register	FFFFFFFFh
#define pmu3_event_count2_thrsh		DFXUNIT_MBAR+PMU3_off+PMU_event_count2_thrsh_off
//	131CH	pmu3_event_count0	PMU3 Event Count0 Register	00000000h
#define pmu3_event_count0			DFXUNIT_MBAR+PMU3_off+PMU_event_count0_off
//	1320H	pmu3_event_count1	PMU3 Event Count1 Register	00000000h
#define pmu3_event_count1			DFXUNIT_MBAR+PMU3_off+PMU_event_count1_off
//	1324H	pmu3_event_count2	PMU3 Event Count2 Register	00000000h
#define pmu3_event_count2			DFXUNIT_MBAR+PMU3_off+PMU_event_count2_off
//	1328H	pmu3_overflow_count	PMU3 Overflow Counter Register	00000000h
#define pmu3_overflow_count			DFXUNIT_MBAR+PMU3_off+PMU_overflow_count_off
//	132CH		Reserved	00000000h
//	1330H	pmu3_start_stop_ctrl0	PMU3 Counter 0 Start/Stop Control Register	00000000h
#define pmu3_start_stop_ctrl0		DFXUNIT_MBAR+PMU3_off+PMU_start_stop_ctrl0_off
//	1334H	pmu3_start_stop_ctrl1	PMU3 Counter 1 Start/Stop Control Register	00000000h
#define pmu3_start_stop_ctrl1		DFXUNIT_MBAR+PMU3_off+PMU_start_stop_ctrl1_off
//	1338H	pmu3_start_stop_ctrl2	PMU3 Counter 2 Start/Stop Control Register	00000000h
#define pmu3_start_stop_ctrl2		DFXUNIT_MBAR+PMU3_off+PMU_start_stop_ctrl2_off
//	133C-11FFh		Reserved	00000000h

#endif	//#ifndef _CE31XX_PMUREG_H_

