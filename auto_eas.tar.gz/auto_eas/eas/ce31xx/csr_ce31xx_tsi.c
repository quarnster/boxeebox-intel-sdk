/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/****** Global registers ******/

static const struct EAS_RegBits g_csr_TSI_OC_MODE_REGISTER[] =
{
     { "RESERVED_31_3", 3, 29 }, /* Reserved */
     { "OCCRCI",        2, 1  }, /* OpenCable Header Field CRC Init Value(OCCRCI) FFH-1, 00H 0 */
     { "OCCE",          1, 1  }, /* OpenCable CableCARD bypass 1: internal bypass - 0: normal operation */
     { "OCSSE",         0, 1  }, /* OpenCable Single-Stream Enable(OCSSE) SS-1, MS-0 */
     {NULL}
};


/****** Bit breakout definitions *****/
static const struct EAS_RegBits g_csr_TSI_PF0_PMM0_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};

static const struct EAS_RegBits g_csr_TSI_PF0_PMM1_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};

static const struct EAS_RegBits g_csr_TSI_PF0_PMM2_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};

static const struct EAS_RegBits g_csr_TSI_PF0_PMM3_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM4_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM5_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM6_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM7_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM8_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM9_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM10_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM11_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM12_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM13_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM14_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM15_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM16_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM17_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM18_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM19_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM20_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM21_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM22_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM23_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM24_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM25_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM26_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM27_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM28_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM29_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM30_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PMM31_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_CFG_REGISTER[] =
{
     { "P_SN",           31, 1  }, /* Instance operates in Parallel (1) or Serial (0) Mode. The interface always operates in Serial mode.*/
     { "RESERVED_30",    30, 1  }, /* Reserved */
     { "EIS",            28, 2  }, /* Error Input Pin Select 00: Error pin not used 01: Use TS_ERR0 10: Use TS_ERR1 11: Reserved*/
     { "CP",             27, 1  }, /* Clock Polarity-When set, will invert the incoming NIM clock. */
     { "DP",             26, 1  }, /* Data Valid Polarity - When set, will invert the incoming NIM Data Valid signal. */
     { "EP",             25, 1  }, /* Error Polarity - When set, will invert the incoming NIM Error signal. */
     { "SP",             24, 1  }, /* Sync Polarity - When set, will invert the incoming NIM Sync signal. */
     { "RESERVED_23_15", 15, 9  }, /* Reserved */
     { "OCHDR_RM",       14, 1  }, /* Open Cable Header Removal (Only valid when OCEN is 1b1): 0: Remove the 12B Open Cable Header 1: Do not remove the 12B Open Cable Header */
     { "OC_CRC_MSK",     13, 1  }, /* Open Cable CRC Mask (Only valid when OCEN is 1b1) 1: Ignore CRC errors 0: Discard OC packets with CRC */
     { "OCEN",      	    12, 1  }, /* Open Cable Enable 1 - The stream will go out on MSPOD output and come back from MSPOD input. 0 - The stream will bypass CableCARD */
     { "CC",      	    10, 2  }, /* When inserting 30-bit time stamp header, CC is copied to the upper 2 bits of the 32-bit header. */
     { "TSHDR_FMT",       9, 1  }, /* Time Stamp Header Format: 0: Add the 32-bit time stamp header based on RX timebase counter. 1: The lower 30 bit s of the header is used for timestamping and the upper 2 bits are copied from CC field.*/
     { "TSHDR_EN",        8, 1  }, /* Time Stamp Header Enable: 1: Add the 4B Time Stamp Header based on RX timebase counter 0: Do not add the 4B Time Stamp Header (Should the 12B OC header be removed first?) */
     { "PGT",      	     7, 1  }, /* Packet too Large Mask: 1: Forward larger than exptected packets 0: Discard larger than expected packets NOTE: when enabled, if the packet size is greater than 252 bytes, only the first 252 bytes will be forwarded to memory due to internal FIFO size limit.*/
     { "PLT",      	     6, 1  }, /* Packet too Small Mask: 1: Forward smaller than exptected packets 0: Discard smaller than expected packets */
     { "DAV_MSK",         5, 1  }, /* Ignore DAV state 1: Ignore the state of DAV when counting packet bytes 0: Ignore bytes when DAV is inactive (also see bit 26) */
     { "ERR_MSK",         4, 1  }, /* Stream Error mask 1: Stream ERROR signal is ignored 0: Stream ERROR signal is used */
     { "ENDIAN",          3, 1  }, /* Endianess: When set, the bytes on a DWord basis (4B) will be reversed.  SW/FW must ensure swapping does not corrupt non-4B data. 1: Endianess swapped when sending data to the system bus 0: Endianess not swapped */
     { "MODE",      	     1, 2  }, /* Incoming Transport Stream mode 00: DVB (188 byte packet) 01: DirectTV (130 byte packet) 10, 11: Reserved */
     { "EN",      	     0, 1  }, /* Prefilter Enable 1: Enabled 0: Disables parsing of incoming packets */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_STATUS_REGISTER[] =
{
     { "RESERVED_31_12",  12, 20  }, /* Reserved */
     { "NIM_ERR",         11, 1  }, /* NIM error event detected*/
     { "DAV_LOW",         10, 1  }, /* NIM DAV low detected*/
     { "OCF",              9, 1  }, /* OpenCable FIFO Full*/
     { "CRC",              8, 1  }, /* OpenCable Header CRC Error*/
     { "DIS",              7, 1  }, /* PCR Discontinuity Detected The TStream had the discontinuity bit set in the PCR header*/
     { "DET",              6, 1  }, /* PCR Detected The TStream contains PCR information*/
     { "PPF",              5, 1  }, /* Packet Discard The internal FIFO used to stage the valid TStreams before sending to DDR dropped a packet due to overflow.*/
     { "WDT",              4, 1  }, /* NIM Watch Dog Timer Expired*/
     { "FE",               3, 1  }, /* DDR Memory Buffer Empty*/
     { "FF",               2, 1  }, /* DDR Memory Buffer  Full*/
     { "PLT",              1, 1  }, /* TStream Packet was less than the correct packet size */
     { "PGT",              0, 1  }, /* TStream Packet was greater than the correct packet size */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_ENABLE_REGISTER[] =
{
     { "RESERVED_31_12",  12, 20  }, /* Reserved */
     { "NIM_ERR",         11, 1  }, /* NIM error event enable*/
     { "DAV_LOW",         10, 1  }, /* NIM DAV low event Enable*/
     { "OCF",              9, 1  }, /* OpenCable FIFO Full Enable*/
     { "CRC",              8, 1  }, /* OpenCable Header CRC Error Enable*/
     { "DIS",              7, 1  }, /* PCR Discontinuity Detected Enable The TStream had the discontinuity bit set in the PCR header*/
     { "DET",              6, 1  }, /* PCR Detected Enable The TStream contains PCR information*/
     { "PPF",              5, 1  }, /* Packet Discard Interrupt Enable The internal FIFO used to stage the valid TStreams before sending to DDR is discarding a packet*/
     { "WDT",              4, 1  }, /* NIM Watch Dog Timer Expired Enable*/
     { "FE",               3, 1  }, /* DDR Memory Buffer Empty Enable*/
     { "FF",               2, 1  }, /* DDR Memory Buffer  Full Enble*/
     { "PLT",              1, 1  }, /* TStream Packet was less than the correct packet size enable */
     { "PGT",              0, 1  }, /* TStream Packet was greater than the correct packet size enable */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_FERR_STATUS_REGISTER[] =
{
     { "RESERVED_31_29", 29, 3  }, /* Reserved */
     { "FERR_VAL",       24, 5  }, /* Index of error causing FERR This field represents the bit position in the Prefilter X Status Register (offset 0x104) which caused FERR to assert.*/
     { "RESERVED_23_22", 22, 2  }, /* Reserved */
     { "PID",             8, 14 }, /* PID captured when FERR is set*/
     { "RESERVED_7_0",    0, 8  }, /* Index of error causing FERR This field represents the bit position in the Prefilter X Status Register (offset 0x104) which caused FERR to assert.*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_NIM_WDOG_TIMER_REGISTER[] =
{
     { "ENABLE", 31, 1  }, /* Enables the Watch Dog Timer */
     { "WDT",    0, 31  }, /* Watch Dog Timer Counter value*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_PCR_REMOTE_A1_REGISTER[] =
{
     { "PCRR_MSBA1",   31, 1  }, /* PCR MSB. This bit contains the 33rd bit (MSB) of the DVB PCR.*/
     { "RESERVED_30_17", 17, 14 }, /* Reserved */
     { "PCRR_LOCK",      16, 1 },  // must be written as zero by software to
                                   // allow an update by hardware
     { "RESERVED_15_9",  9, 7 },   // reserved
     { "PCRR_LSBSA1",    0, 9 }, /* These 9 bits are the Modulo 300 counter for the DVB PCR */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_OC_HEADER_CONFIG_REGISTER[] =
{
     { "RESERVED_31_30",  30, 2  }, /* Reserved */
     { "OCHS",            28, 2  }, /* OpenCable Header Select (OCHS) ={3,2,1,0} 3: OpenCable Dynamic Header Selected 2: OpenCable Static Header-2 Selected 1: OpenCable Static Header-1 Selected 0: OpenCable Static Header-0 Selected */
     { "RESERVED_27_10", 10, 18  }, /* Reserved */
     { "OCLTS",            9, 1  }, /* OpenCable LTS Field Enable(OCLTS), 1: Enable, LTS is inserted based on header selection and pfX_cfg.TSHDR_FMT. 0: Disable, all zeros are written into LTS field.*/
     { "RESERVED_8",       8, 1  }, /* Reserved */
     { "OCLTSID",          0, 8  }, /* OpenCable LTSID(OCLTSID), used w/ Dynamically allocated Header Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1 and so on */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_OC_HEADER_0A_REGISTER[] =
{
     { "OCLTSID",     24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",   8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0", 0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_OC_HEADER_1A_REGISTER[] =
{
     { "OCLTSID",      24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",    8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0",  0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF0_OC_HEADER_2A_REGISTER[] =
{
     { "OCLTSID",     24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",   8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0", 0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM0_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM1_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM2_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM3_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM4_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM5_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM6_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM7_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM8_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM9_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM10_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM11_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM12_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM13_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM14_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM15_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM16_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM17_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM18_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM19_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM20_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM21_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM22_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM23_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM24_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM25_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM26_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM27_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM28_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM29_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM30_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PMM31_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_CFG_REGISTER[] =
{
     { "P_SN",           31, 1  }, /* Instance operates in Parallel (1) or Serial (0) Mode. The interface always operates in Serial mode.*/
     { "RESERVED_30",    30, 1  }, /* Reserved */
     { "EIS",            28, 2  }, /* Error Input Pin Select 00: Error pin not used 01: Use TS_ERR0 10: Use TS_ERR1 11: Reserved*/
     { "CP",             27, 1  }, /* Clock Polarity-When set, will invert the incoming NIM clock. */
     { "DP",             26, 1  }, /* Data Valid Polarity - When set, will invert the incoming NIM Data Valid signal. */
     { "EP",             25, 1  }, /* Error Polarity - When set, will invert the incoming NIM Error signal. */
     { "SP",             24, 1  }, /* Sync Polarity - When set, will invert the incoming NIM Sync signal. */
     { "RESERVED_23_15", 15, 9  }, /* Reserved */
     { "OCHDR_RM",       14, 1  }, /* Open Cable Header Removal (Only valid when OCEN is 1b1): 0: Remove the 12B Open Cable Header 1: Do not remove the 12B Open Cable Header */
     { "OC_CRC_MSK",     13, 1  }, /* Open Cable CRC Mask (Only valid when OCEN is 1b1) 1: Ignore CRC errors 0: Discard OC packets with CRC */
     { "OCEN",      	    12, 1  }, /* Open Cable Enable 1 - The stream will go out on MSPOD output and come back from MSPOD input. 0 - The stream will bypass CableCARD */
     { "CC",      	    10, 2  }, /* When inserting 30-bit time stamp header, CC is copied to the upper 2 bits of the 32-bit header. */
     { "TSHDR_FMT",       9, 1  }, /* Time Stamp Header Format: 0: Add the 32-bit time stamp header based on RX timebase counter. 1: The lower 30 bit s of the header is used for timestamping and the upper 2 bits are copied from CC field.*/
     { "TSHDR_EN",        8, 1  }, /* Time Stamp Header Enable: 1: Add the 4B Time Stamp Header based on RX timebase counter 0: Do not add the 4B Time Stamp Header (Should the 12B OC header be removed first?) */
     { "PGT",      	     7, 1  }, /* Packet too Large Mask: 1: Forward larger than exptected packets 0: Discard larger than expected packets NOTE: when enabled, if the packet size is greater than 252 bytes, only the first 252 bytes will be forwarded to memory due to internal FIFO size limit.*/
     { "PLT",      	     6, 1  }, /* Packet too Small Mask: 1: Forward smaller than exptected packets 0: Discard smaller than expected packets */
     { "DAV_MSK",         5, 1  }, /* Ignore DAV state 1: Ignore the state of DAV when counting packet bytes 0: Ignore bytes when DAV is inactive (also see bit 26) */
     { "ERR_MSK",         4, 1  }, /* Stream Error mask 1: Stream ERROR signal is ignored 0: Stream ERROR signal is used */
     { "ENDIAN",          3, 1  }, /* Endianess: When set, the bytes on a DWord basis (4B) will be reversed.  SW/FW must ensure swapping does not corrupt non-4B data. 1: Endianess swapped when sending data to the system bus 0: Endianess not swapped */
     { "MODE",      	     1, 2  }, /* Incoming Transport Stream mode 00: DVB (188 byte packet) 01: DirectTV (130 byte packet) 10, 11: Reserved */
     { "EN",      	     0, 1  }, /* Prefilter Enable 1: Enabled 0: Disables parsing of incoming packets */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_STATUS_REGISTER[] =
{
     { "RESERVED_31_12",  12, 20  }, /* Reserved */
     { "NIM_ERR",         11, 1  }, /* NIM error event detected*/
     { "DAV_LOW",         10, 1  }, /* NIM DAV low detected*/
     { "OCF",              9, 1  }, /* OpenCable FIFO Full*/
     { "CRC",              8, 1  }, /* OpenCable Header CRC Error*/
     { "DIS",              7, 1  }, /* PCR Discontinuity Detected The TStream had the discontinuity bit set in the PCR header*/
     { "DET",              6, 1  }, /* PCR Detected The TStream contains PCR information*/
     { "PPF",              5, 1  }, /* Packet Discard The internal FIFO used to stage the valid TStreams before sending to DDR dropped a packet due to overflow.*/
     { "WDT",              4, 1  }, /* NIM Watch Dog Timer Expired*/
     { "FE",               3, 1  }, /* DDR Memory Buffer Empty*/
     { "FF",               2, 1  }, /* DDR Memory Buffer  Full*/
     { "PLT",              1, 1  }, /* TStream Packet was less than the correct packet size */
     { "PGT",              0, 1  }, /* TStream Packet was greater than the correct packet size */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_ENABLE_REGISTER[] =
{
     { "RESERVED_31_12",  12, 20  }, /* Reserved */
     { "NIM_ERR",         11, 1  }, /* NIM error event enable*/
     { "DAV_LOW",         10, 1  }, /* NIM DAV low event Enable*/
     { "OCF",              9, 1  }, /* OpenCable FIFO Full Enable*/
     { "CRC",              8, 1  }, /* OpenCable Header CRC Error Enable*/
     { "DIS",              7, 1  }, /* PCR Discontinuity Detected Enable The TStream had the discontinuity bit set in the PCR header*/
     { "DET",              6, 1  }, /* PCR Detected Enable The TStream contains PCR information*/
     { "PPF",              5, 1  }, /* Packet Discard Interrupt Enable The internal FIFO used to stage the valid TStreams before sending to DDR is discarding a packet*/
     { "WDT",              4, 1  }, /* NIM Watch Dog Timer Expired Enable*/
     { "FE",               3, 1  }, /* DDR Memory Buffer Empty Enable*/
     { "FF",               2, 1  }, /* DDR Memory Buffer  Full Enble*/
     { "PLT",              1, 1  }, /* TStream Packet was less than the correct packet size enable */
     { "PGT",              0, 1  }, /* TStream Packet was greater than the correct packet size enable */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_FERR_STATUS_REGISTER[] =
{
     { "RESERVED_31_29", 29, 3  }, /* Reserved */
     { "FERR_VAL",       24, 5  }, /* Index of error causing FERR This field represents the bit position in the Prefilter X Status Register (offset 0x104) which caused FERR to assert.*/
     { "RESERVED_23_22", 22, 2  }, /* Reserved */
     { "PID",             8, 14 }, /* PID captured when FERR is set*/
     { "RESERVED_7_0",    0, 8  }, /* Index of error causing FERR This field represents the bit position in the Prefilter X Status Register (offset 0x104) which caused FERR to assert.*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_NIM_WDOG_TIMER_REGISTER[] =
{
     { "ENABLE", 31, 1  }, /* Enables the Watch Dog Timer */
     { "WDT",    0, 31  }, /* Watch Dog Timer Counter value*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_PCR_REMOTE_A1_REGISTER[] =
{
     { "PCRR_MSBA1",   31, 1  }, /* PCR MSB. This bit contains the 33rd bit (MSB) of the DVB PCR.*/
     { "RESERVED_30_17", 17, 14 }, /* Reserved */
     { "PCRR_LOCK",      16, 1 },  // must be written as zero by software to
                                   // allow an update by hardware
     { "RESERVED_15_9",  9, 7 },   // reserved
     { "PCRR_LSBSA1",    0, 9 }, /* These 9 bits are the Modulo 300 counter for the DVB PCR */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_OC_HEADER_CONFIG_REGISTER[] =
{
     { "RESERVED_31_30",  30, 2  }, /* Reserved */
     { "OCHS",            28, 2  }, /* OpenCable Header Select (OCHS) ={3,2,1,0} 3: OpenCable Dynamic Header Selected 2: OpenCable Static Header-2 Selected 1: OpenCable Static Header-1 Selected 0: OpenCable Static Header-0 Selected */
     { "RESERVED_27_10", 10, 18  }, /* Reserved */
     { "OCLTS",            9, 1  }, /* OpenCable LTS Field Enable(OCLTS), 1: Enable, LTS is inserted based on header selection and pfX_cfg.TSHDR_FMT. 0: Disable, all zeros are written into LTS field.*/
     { "RESERVED_8",       8, 1  }, /* Reserved */
     { "OCLTSID",          0, 8  }, /* OpenCable LTSID(OCLTSID), used w/ Dynamically allocated Header Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1 and so on */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_OC_HEADER_0A_REGISTER[] =
{
     { "OCLTSID",     24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",   8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0", 0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_OC_HEADER_1A_REGISTER[] =
{
     { "OCLTSID",      24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",    8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0",  0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF1_OC_HEADER_2A_REGISTER[] =
{
     { "OCLTSID",     24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",   8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0", 0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM0_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM1_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM2_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM3_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM4_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM5_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM6_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM7_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM8_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM9_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM10_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM11_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM12_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM13_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM14_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM15_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM16_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM17_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM18_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM19_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM20_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM21_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM22_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM23_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM24_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM25_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM26_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM27_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM28_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM29_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM30_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PMM31_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_CFG_REGISTER[] =
{
     { "P_SN",           31, 1  }, /* Instance operates in Parallel (1) or Serial (0) Mode. The interface always operates in Serial mode.*/
     { "RESERVED_30",    30, 1  }, /* Reserved */
     { "EIS",            28, 2  }, /* Error Input Pin Select 00: Error pin not used 01: Use TS_ERR0 10: Use TS_ERR1 11: Reserved*/
     { "CP",             27, 1  }, /* Clock Polarity-When set, will invert the incoming NIM clock. */
     { "DP",             26, 1  }, /* Data Valid Polarity - When set, will invert the incoming NIM Data Valid signal. */
     { "EP",             25, 1  }, /* Error Polarity - When set, will invert the incoming NIM Error signal. */
     { "SP",             24, 1  }, /* Sync Polarity - When set, will invert the incoming NIM Sync signal. */
     { "RESERVED_23_15", 15, 9  }, /* Reserved */
     { "OCHDR_RM",       14, 1  }, /* Open Cable Header Removal (Only valid when OCEN is 1b1): 0: Remove the 12B Open Cable Header 1: Do not remove the 12B Open Cable Header */
     { "OC_CRC_MSK",     13, 1  }, /* Open Cable CRC Mask (Only valid when OCEN is 1b1) 1: Ignore CRC errors 0: Discard OC packets with CRC */
     { "OCEN",      	    12, 1  }, /* Open Cable Enable 1 - The stream will go out on MSPOD output and come back from MSPOD input. 0 - The stream will bypass CableCARD */
     { "CC",      	    10, 2  }, /* When inserting 30-bit time stamp header, CC is copied to the upper 2 bits of the 32-bit header. */
     { "TSHDR_FMT",       9, 1  }, /* Time Stamp Header Format: 0: Add the 32-bit time stamp header based on RX timebase counter. 1: The lower 30 bit s of the header is used for timestamping and the upper 2 bits are copied from CC field.*/
     { "TSHDR_EN",        8, 1  }, /* Time Stamp Header Enable: 1: Add the 4B Time Stamp Header based on RX timebase counter 0: Do not add the 4B Time Stamp Header (Should the 12B OC header be removed first?) */
     { "PGT",      	     7, 1  }, /* Packet too Large Mask: 1: Forward larger than exptected packets 0: Discard larger than expected packets NOTE: when enabled, if the packet size is greater than 252 bytes, only the first 252 bytes will be forwarded to memory due to internal FIFO size limit.*/
     { "PLT",      	     6, 1  }, /* Packet too Small Mask: 1: Forward smaller than exptected packets 0: Discard smaller than expected packets */
     { "DAV_MSK",         5, 1  }, /* Ignore DAV state 1: Ignore the state of DAV when counting packet bytes 0: Ignore bytes when DAV is inactive (also see bit 26) */
     { "ERR_MSK",         4, 1  }, /* Stream Error mask 1: Stream ERROR signal is ignored 0: Stream ERROR signal is used */
     { "ENDIAN",          3, 1  }, /* Endianess: When set, the bytes on a DWord basis (4B) will be reversed.  SW/FW must ensure swapping does not corrupt non-4B data. 1: Endianess swapped when sending data to the system bus 0: Endianess not swapped */
     { "MODE",      	     1, 2  }, /* Incoming Transport Stream mode 00: DVB (188 byte packet) 01: DirectTV (130 byte packet) 10, 11: Reserved */
     { "EN",      	     0, 1  }, /* Prefilter Enable 1: Enabled 0: Disables parsing of incoming packets */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_STATUS_REGISTER[] =
{
     { "RESERVED_31_12",  12, 20  }, /* Reserved */
     { "NIM_ERR",         11, 1  }, /* NIM error event detected*/
     { "DAV_LOW",         10, 1  }, /* NIM DAV low detected*/
     { "OCF",              9, 1  }, /* OpenCable FIFO Full*/
     { "CRC",              8, 1  }, /* OpenCable Header CRC Error*/
     { "DIS",              7, 1  }, /* PCR Discontinuity Detected The TStream had the discontinuity bit set in the PCR header*/
     { "DET",              6, 1  }, /* PCR Detected The TStream contains PCR information*/
     { "PPF",              5, 1  }, /* Packet Discard The internal FIFO used to stage the valid TStreams before sending to DDR dropped a packet due to overflow.*/
     { "WDT",              4, 1  }, /* NIM Watch Dog Timer Expired*/
     { "FE",               3, 1  }, /* DDR Memory Buffer Empty*/
     { "FF",               2, 1  }, /* DDR Memory Buffer  Full*/
     { "PLT",              1, 1  }, /* TStream Packet was less than the correct packet size */
     { "PGT",              0, 1  }, /* TStream Packet was greater than the correct packet size */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_ENABLE_REGISTER[] =
{
     { "RESERVED_31_12",  12, 20  }, /* Reserved */
     { "NIM_ERR",         11, 1  }, /* NIM error event enable*/
     { "DAV_LOW",         10, 1  }, /* NIM DAV low event Enable*/
     { "OCF",              9, 1  }, /* OpenCable FIFO Full Enable*/
     { "CRC",              8, 1  }, /* OpenCable Header CRC Error Enable*/
     { "DIS",              7, 1  }, /* PCR Discontinuity Detected Enable The TStream had the discontinuity bit set in the PCR header*/
     { "DET",              6, 1  }, /* PCR Detected Enable The TStream contains PCR information*/
     { "PPF",              5, 1  }, /* Packet Discard Interrupt Enable The internal FIFO used to stage the valid TStreams before sending to DDR is discarding a packet*/
     { "WDT",              4, 1  }, /* NIM Watch Dog Timer Expired Enable*/
     { "FE",               3, 1  }, /* DDR Memory Buffer Empty Enable*/
     { "FF",               2, 1  }, /* DDR Memory Buffer  Full Enble*/
     { "PLT",              1, 1  }, /* TStream Packet was less than the correct packet size enable */
     { "PGT",              0, 1  }, /* TStream Packet was greater than the correct packet size enable */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_FERR_STATUS_REGISTER[] =
{
     { "RESERVED_31_29", 29, 3  }, /* Reserved */
     { "FERR_VAL",       24, 5  }, /* Index of error causing FERR This field represents the bit position in the Prefilter X Status Register (offset 0x104) which caused FERR to assert.*/
     { "RESERVED_23_22", 22, 2  }, /* Reserved */
     { "PID",             8, 14 }, /* PID captured when FERR is set*/
     { "RESERVED_7_0",    0, 8  }, /* Index of error causing FERR This field represents the bit position in the Prefilter X Status Register (offset 0x104) which caused FERR to assert.*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_NIM_WDOG_TIMER_REGISTER[] =
{
     { "ENABLE", 31, 1  }, /* Enables the Watch Dog Timer */
     { "WDT",    0, 31  }, /* Watch Dog Timer Counter value*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_PCR_REMOTE_A1_REGISTER[] =
{
     { "PCRR_MSBA1",   31, 1  }, /* PCR MSB. This bit contains the 33rd bit (MSB) of the DVB PCR.*/
     { "RESERVED_30_17", 17, 14 }, /* Reserved */
     { "PCRR_LOCK",      16, 1 },  // must be written as zero by software to
                                   // allow an update by hardware
     { "RESERVED_15_9",  9, 7 },   // reserved
     { "PCRR_LSBSA1",    0, 9 }, /* These 9 bits are the Modulo 300 counter for the DVB PCR */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_OC_HEADER_CONFIG_REGISTER[] =
{
     { "RESERVED_31_30",  30, 2  }, /* Reserved */
     { "OCHS",            28, 2  }, /* OpenCable Header Select (OCHS) ={3,2,1,0} 3: OpenCable Dynamic Header Selected 2: OpenCable Static Header-2 Selected 1: OpenCable Static Header-1 Selected 0: OpenCable Static Header-0 Selected */
     { "RESERVED_27_10", 10, 18  }, /* Reserved */
     { "OCLTS",            9, 1  }, /* OpenCable LTS Field Enable(OCLTS), 1: Enable, LTS is inserted based on header selection and pfX_cfg.TSHDR_FMT. 0: Disable, all zeros are written into LTS field.*/
     { "RESERVED_8",       8, 1  }, /* Reserved */
     { "OCLTSID",          0, 8  }, /* OpenCable LTSID(OCLTSID), used w/ Dynamically allocated Header Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1 and so on */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_OC_HEADER_0A_REGISTER[] =
{
     { "OCLTSID",     24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",   8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0", 0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_OC_HEADER_1A_REGISTER[] =
{
     { "OCLTSID",      24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",    8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0",  0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF2_OC_HEADER_2A_REGISTER[] =
{
     { "OCLTSID",     24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",   8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0", 0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM0_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM1_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM2_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM3_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM4_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM5_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM6_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM7_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM8_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM9_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM10_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM11_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM12_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM13_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM14_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM15_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM16_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM17_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM18_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM19_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM20_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM21_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM22_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM23_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM24_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM25_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM26_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM27_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM28_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM29_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM30_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PMM31_REGISTER[] =
{
     { "ENABLE",      31, 1  }, /* Enables this Mask/Match register. When 0, compare results are igonred */
     { "MASK",        16, 15 }, /* Mask value for PID compare. 1: include corresponding bit in compare results, 0: ingore corresponding bit in the compare results*/
     { "RESERVED_15", 15, 1  }, /* Reserved bit */
     { "EXACTVALUE",   0, 15 }, /* Exact PID value to compare against*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_CFG_REGISTER[] =
{
     { "P_SN",           31, 1  }, /* Instance operates in Parallel (1) or Serial (0) Mode. The interface always operates in Serial mode.*/
     { "RESERVED_30",    30, 1  }, /* Reserved */
     { "EIS",            28, 2  }, /* Error Input Pin Select 00: Error pin not used 01: Use TS_ERR0 10: Use TS_ERR1 11: Reserved*/
     { "CP",             27, 1  }, /* Clock Polarity-When set, will invert the incoming NIM clock. */
     { "DP",             26, 1  }, /* Data Valid Polarity - When set, will invert the incoming NIM Data Valid signal. */
     { "EP",             25, 1  }, /* Error Polarity - When set, will invert the incoming NIM Error signal. */
     { "SP",             24, 1  }, /* Sync Polarity - When set, will invert the incoming NIM Sync signal. */
     { "RESERVED_23_15", 15, 9  }, /* Reserved */
     { "OCHDR_RM",       14, 1  }, /* Open Cable Header Removal (Only valid when OCEN is 1b1): 0: Remove the 12B Open Cable Header 1: Do not remove the 12B Open Cable Header */
     { "OC_CRC_MSK",     13, 1  }, /* Open Cable CRC Mask (Only valid when OCEN is 1b1) 1: Ignore CRC errors 0: Discard OC packets with CRC */
     { "OCEN",      	    12, 1  }, /* Open Cable Enable 1 - The stream will go out on MSPOD output and come back from MSPOD input. 0 - The stream will bypass CableCARD */
     { "CC",      	    10, 2  }, /* When inserting 30-bit time stamp header, CC is copied to the upper 2 bits of the 32-bit header. */
     { "TSHDR_FMT",       9, 1  }, /* Time Stamp Header Format: 0: Add the 32-bit time stamp header based on RX timebase counter. 1: The lower 30 bit s of the header is used for timestamping and the upper 2 bits are copied from CC field.*/
     { "TSHDR_EN",        8, 1  }, /* Time Stamp Header Enable: 1: Add the 4B Time Stamp Header based on RX timebase counter 0: Do not add the 4B Time Stamp Header (Should the 12B OC header be removed first?) */
     { "PGT",      	     7, 1  }, /* Packet too Large Mask: 1: Forward larger than exptected packets 0: Discard larger than expected packets NOTE: when enabled, if the packet size is greater than 252 bytes, only the first 252 bytes will be forwarded to memory due to internal FIFO size limit.*/
     { "PLT",      	     6, 1  }, /* Packet too Small Mask: 1: Forward smaller than exptected packets 0: Discard smaller than expected packets */
     { "DAV_MSK",         5, 1  }, /* Ignore DAV state 1: Ignore the state of DAV when counting packet bytes 0: Ignore bytes when DAV is inactive (also see bit 26) */
     { "ERR_MSK",         4, 1  }, /* Stream Error mask 1: Stream ERROR signal is ignored 0: Stream ERROR signal is used */
     { "ENDIAN",          3, 1  }, /* Endianess: When set, the bytes on a DWord basis (4B) will be reversed.  SW/FW must ensure swapping does not corrupt non-4B data. 1: Endianess swapped when sending data to the system bus 0: Endianess not swapped */
     { "MODE",      	     1, 2  }, /* Incoming Transport Stream mode 00: DVB (188 byte packet) 01: DirectTV (130 byte packet) 10, 11: Reserved */
     { "EN",      	     0, 1  }, /* Prefilter Enable 1: Enabled 0: Disables parsing of incoming packets */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_STATUS_REGISTER[] =
{
     { "RESERVED_31_12",  12, 20  }, /* Reserved */
     { "NIM_ERR",         11, 1  }, /* NIM error event detected*/
     { "DAV_LOW",         10, 1  }, /* NIM DAV low detected*/
     { "OCF",              9, 1  }, /* OpenCable FIFO Full*/
     { "CRC",              8, 1  }, /* OpenCable Header CRC Error*/
     { "DIS",              7, 1  }, /* PCR Discontinuity Detected The TStream had the discontinuity bit set in the PCR header*/
     { "DET",              6, 1  }, /* PCR Detected The TStream contains PCR information*/
     { "PPF",              5, 1  }, /* Packet Discard The internal FIFO used to stage the valid TStreams before sending to DDR dropped a packet due to overflow.*/
     { "WDT",              4, 1  }, /* NIM Watch Dog Timer Expired*/
     { "FE",               3, 1  }, /* DDR Memory Buffer Empty*/
     { "FF",               2, 1  }, /* DDR Memory Buffer  Full*/
     { "PLT",              1, 1  }, /* TStream Packet was less than the correct packet size */
     { "PGT",              0, 1  }, /* TStream Packet was greater than the correct packet size */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_ENABLE_REGISTER[] =
{
     { "RESERVED_31_12",  12, 20  }, /* Reserved */
     { "NIM_ERR",         11, 1  }, /* NIM error event enable*/
     { "DAV_LOW",         10, 1  }, /* NIM DAV low event Enable*/
     { "OCF",              9, 1  }, /* OpenCable FIFO Full Enable*/
     { "CRC",              8, 1  }, /* OpenCable Header CRC Error Enable*/
     { "DIS",              7, 1  }, /* PCR Discontinuity Detected Enable The TStream had the discontinuity bit set in the PCR header*/
     { "DET",              6, 1  }, /* PCR Detected Enable The TStream contains PCR information*/
     { "PPF",              5, 1  }, /* Packet Discard Interrupt Enable The internal FIFO used to stage the valid TStreams before sending to DDR is discarding a packet*/
     { "WDT",              4, 1  }, /* NIM Watch Dog Timer Expired Enable*/
     { "FE",               3, 1  }, /* DDR Memory Buffer Empty Enable*/
     { "FF",               2, 1  }, /* DDR Memory Buffer  Full Enble*/
     { "PLT",              1, 1  }, /* TStream Packet was less than the correct packet size enable */
     { "PGT",              0, 1  }, /* TStream Packet was greater than the correct packet size enable */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_FERR_STATUS_REGISTER[] =
{
     { "RESERVED_31_29", 29, 3  }, /* Reserved */
     { "FERR_VAL",       24, 5  }, /* Index of error causing FERR This field represents the bit position in the Prefilter X Status Register (offset 0x104) which caused FERR to assert.*/
     { "RESERVED_23_22", 22, 2  }, /* Reserved */
     { "PID",             8, 14 }, /* PID captured when FERR is set*/
     { "RESERVED_7_0",    0, 8  }, /* Index of error causing FERR This field represents the bit position in the Prefilter X Status Register (offset 0x104) which caused FERR to assert.*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_NIM_WDOG_TIMER_REGISTER[] =
{
     { "ENABLE", 31, 1  }, /* Enables the Watch Dog Timer */
     { "WDT",    0, 31  }, /* Watch Dog Timer Counter value*/
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_PCR_REMOTE_A1_REGISTER[] =
{
     { "PCRR_MSBA1",   31, 1  }, /* PCR MSB. This bit contains the 33rd bit (MSB) of the DVB PCR.*/
     { "RESERVED_30_17", 17, 14 }, /* Reserved */
     { "PCRR_LOCK",      16, 1 },  // must be written as zero by software to
                                   // allow an update by hardware
     { "RESERVED_15_9",  9, 7 },   // reserved
     { "PCRR_LSBSA1",    0, 9 }, /* These 9 bits are the Modulo 300 counter for the DVB PCR */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_OC_HEADER_CONFIG_REGISTER[] =
{
     { "RESERVED_31_30",  30, 2  }, /* Reserved */
     { "OCHS",            28, 2  }, /* OpenCable Header Select (OCHS) ={3,2,1,0} 3: OpenCable Dynamic Header Selected 2: OpenCable Static Header-2 Selected 1: OpenCable Static Header-1 Selected 0: OpenCable Static Header-0 Selected */
     { "RESERVED_27_10", 10, 18  }, /* Reserved */
     { "OCLTS",            9, 1  }, /* OpenCable LTS Field Enable(OCLTS), 1: Enable, LTS is inserted based on header selection and pfX_cfg.TSHDR_FMT. 0: Disable, all zeros are written into LTS field.*/
     { "RESERVED_8",       8, 1  }, /* Reserved */
     { "OCLTSID",          0, 8  }, /* OpenCable LTSID(OCLTSID), used w/ Dynamically allocated Header Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1 and so on */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_OC_HEADER_0A_REGISTER[] =
{
     { "OCLTSID",     24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",   8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0", 0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_OC_HEADER_1A_REGISTER[] =
{
     { "OCLTSID",      24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",    8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0",  0, 8  }, /* Reserved */
     {NULL}
};


static const struct EAS_RegBits g_csr_TSI_PF3_OC_HEADER_2A_REGISTER[] =
{
     { "OCLTSID",     24, 8  }, /* OpenCable LTSID (OCLTSID), used w/ LUT Based header. Note: only bits [3:0] are used in the LTSID field of OpenCable Header. For filter 0, LTSID[7:4] of the OpenCable header contains 0. For filter 1, LTSID[7:4] of the OpenCable header contains 1.*/
     { "OCHOSTRES",   8, 15  }, /* OpenCable HOSTres (OCHOSTres), used w/ LUT Based header. */
     { "RESERVED_7_0", 0, 8  }, /* Reserved */
     {NULL}
};




static const struct EAS_RegBits g_csr_gen3_tsi_INTERRUPT[] =
{
        {"reserved3",          25, 7, "Reserved", NULL},
    {"COMPARE_SYS",        24, 1, "The running value in System Time counter matched the desired compare setting", NULL },
        {"reserved2",          18, 6, "Reserved", NULL},
    {"CAPTURE_SYT2",       17, 1, "The valid timestamp was captured in System Time capture register 2 (for received packets on Ethernet)", NULL },
    {"CAPTURE_SYT1",       16, 1, "The valid timestamp was captured in System Time capture register 1 (for transmitted packets on Ethernet)", NULL},
        {"reserved1",          14, 2, "Reserved", NULL},
    {"COMPARE_6",          13, 1, "The running value in STC counter of Channel 6 matched the desired compare setting", NULL },
    {"COMPARE_5",          12, 1, "The running value in STC counter of Channel 5 matched the desired compare setting", NULL },
    {"COMPARE_4",          11, 1, "The running value in STC counter of Channel 4 matched the desired compare setting", NULL },
    {"COMPARE_3",          10, 1, "The running value in STC counter of Channel 3 matched the desired compare setting", NULL },
    {"COMPARE_2",           9, 1, "The running value in STC counter of Channel 2 matched the desired compare setting", NULL },
    {"COMPARE_1",           8, 1, "The running value in STC counter of Channel 1 matched the desired compare setting", NULL },
        {"reserved0",           0, 8, "Reserved", NULL},
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};




#define GEN3_CRU_TCHAN_1_BASE         0x0000
#define GEN3_CRU_TCHAN_2_BASE         0x0040
#define GEN3_CRU_TCHAN_3_BASE         0x0080
#define GEN3_CRU_TCHAN_4_BASE         0x00c0
#define GEN3_CRU_TCHAN_5_BASE         0x0100
#define GEN3_CRU_TCHAN_6_BASE         0x0140

#define GEN3_TSI_GLOBAL     0x00000
#define GEN3_TSI_0_BASE     0x04000
#define GEN3_TSI_1_BASE     0x08000
#define GEN3_TSI_2_BASE     0x0C000
#define GEN3_TSI_3_BASE     0x10000

/****** Local Register definitions *****/

static const struct EAS_Register g_csr_gen3_tsi[] =
{
		{"OC_MODE",				GEN3_TSI_GLOBAL + 0x00, g_csr_TSI_OC_MODE_REGISTER, "OpenCABLE Mode Config Register" },
		{"CE_CONFIG_RX",		GEN3_TSI_GLOBAL + 0x40, NULL, "CE Receive Configuration Register" },
		{"CE_CONFIG_TX",		GEN3_TSI_GLOBAL + 0x44, NULL, "CE Transmit Configuration Register" },
		{"CE_INTERRUPT_ENABLE",	GEN3_TSI_GLOBAL + 0x48, NULL, "CE Interrupt Enable Register" },
		{"CE_INTERRUPT_STATUS",	GEN3_TSI_GLOBAL + 0x4C, NULL, "CE Interrupt Status  Register" },
		{"CE_RX_TS_CAPTURE",    GEN3_TSI_GLOBAL + 0x88, NULL, "Receive Timestamp Capture Value for DV mode" },
		//NOTE: Since the CE receive interface is shared with TS3 input, the receive timestamp
		// counter is shared with pf3_timestamp_count.
		{"CE_RX_DIF_DELAY",      GEN3_TSI_GLOBAL + 0x90, NULL, "Delay between FrameSync and DIF in DV mode" },
		{"CE_TX_TS_CNT",	        GEN3_TSI_GLOBAL + 0xC0, NULL, "CE Transmit Timestamp Counter" },
		{"CE_OUT_FRAME_INTERVAL",GEN3_TSI_GLOBAL + 0xD0, NULL, "CE Transmit DV Frame Interval" },
		{"CE_OUT_PACKET_INTERVAL",GEN3_TSI_GLOBAL + 0xD4, NULL, "CE Transmit DV Packet Interval" },
		{"CE_DIF_PACKET_SIZE",	GEN3_TSI_GLOBAL + 0xD8, NULL, "DV Size of DIF Packet" },
		{"CE_DIF_FRAME_SIZE",	GEN3_TSI_GLOBAL + 0xDC, NULL, "CE Transmit DV Frame Size" },
		{"CE_OUT_FRAME_INTERVAL_CNT",	  GEN3_TSI_GLOBAL + 0xE0, NULL, "CE Transmit DV Frame Interval Count" },
		{"CE_OUT_PACKET_INTERVAL_CNT", GEN3_TSI_GLOBAL + 0xE4, NULL, "CE Transmit DV Packet Interval Count" },
		{"CE_PACKET_SIZE_CNT",	     GEN3_TSI_GLOBAL + 0xE8, NULL, "DV DIF Packet Current Byte Count" },
		{"CE_DIF_FRAME_SIZE_CNT",	 GEN3_TSI_GLOBAL + 0xEC, NULL, "CE Transmit DV Frame Size" },

		{"PFX_0_PMM0",				GEN3_TSI_0_BASE + 0x0, g_csr_TSI_PF0_PMM0_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM1",				GEN3_TSI_0_BASE + 0x4, g_csr_TSI_PF0_PMM1_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM2",				GEN3_TSI_0_BASE + 0x8, g_csr_TSI_PF0_PMM2_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM3",				GEN3_TSI_0_BASE + 0xc, g_csr_TSI_PF0_PMM3_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM4",				GEN3_TSI_0_BASE + 0x10, g_csr_TSI_PF0_PMM4_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM5",				GEN3_TSI_0_BASE + 0x14, g_csr_TSI_PF0_PMM5_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM6",				GEN3_TSI_0_BASE + 0x18, g_csr_TSI_PF0_PMM6_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM7",				GEN3_TSI_0_BASE + 0x1c, g_csr_TSI_PF0_PMM7_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM8",				GEN3_TSI_0_BASE + 0x20, g_csr_TSI_PF0_PMM8_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM9",				GEN3_TSI_0_BASE + 0x24, g_csr_TSI_PF0_PMM9_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM10",				GEN3_TSI_0_BASE + 0x28, g_csr_TSI_PF0_PMM10_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM11",				GEN3_TSI_0_BASE + 0x2c, g_csr_TSI_PF0_PMM11_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM12",				GEN3_TSI_0_BASE + 0x30, g_csr_TSI_PF0_PMM12_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM13",				GEN3_TSI_0_BASE + 0x34, g_csr_TSI_PF0_PMM13_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM14",				GEN3_TSI_0_BASE + 0x38, g_csr_TSI_PF0_PMM14_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM15",				GEN3_TSI_0_BASE + 0x3c, g_csr_TSI_PF0_PMM15_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM16",				GEN3_TSI_0_BASE + 0x40, g_csr_TSI_PF0_PMM16_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM17",				GEN3_TSI_0_BASE + 0x44, g_csr_TSI_PF0_PMM17_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM18",				GEN3_TSI_0_BASE + 0x48, g_csr_TSI_PF0_PMM18_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM19",				GEN3_TSI_0_BASE + 0x4c, g_csr_TSI_PF0_PMM19_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM20",				GEN3_TSI_0_BASE + 0x50, g_csr_TSI_PF0_PMM20_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM21",				GEN3_TSI_0_BASE + 0x54, g_csr_TSI_PF0_PMM21_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM22",				GEN3_TSI_0_BASE + 0x58, g_csr_TSI_PF0_PMM22_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM23",				GEN3_TSI_0_BASE + 0x5c, g_csr_TSI_PF0_PMM23_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM24",				GEN3_TSI_0_BASE + 0x60, g_csr_TSI_PF0_PMM24_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM25",				GEN3_TSI_0_BASE + 0x64, g_csr_TSI_PF0_PMM25_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM26",				GEN3_TSI_0_BASE + 0x68, g_csr_TSI_PF0_PMM26_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM27",				GEN3_TSI_0_BASE + 0x6c, g_csr_TSI_PF0_PMM27_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM28",				GEN3_TSI_0_BASE + 0x70, g_csr_TSI_PF0_PMM28_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM29",				GEN3_TSI_0_BASE + 0x74, g_csr_TSI_PF0_PMM29_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM30",				GEN3_TSI_0_BASE + 0x78, g_csr_TSI_PF0_PMM30_REGISTER, "Mask/Match register" },
		{"PFX_0_PMM31",				GEN3_TSI_0_BASE + 0x7c, g_csr_TSI_PF0_PMM31_REGISTER, "Mask/Match register" },
		{"PFX_0_CFG",				GEN3_TSI_0_BASE + 0x100, g_csr_TSI_PF0_CFG_REGISTER, "Prefilter Config register" },
		{"PFX_0_STATUS",				GEN3_TSI_0_BASE + 0x104, g_csr_TSI_PF0_STATUS_REGISTER, "Prefilter status register" },
		{"PFX_0_ENABLE",				GEN3_TSI_0_BASE + 0x108, g_csr_TSI_PF0_ENABLE_REGISTER, "Prefilter enable register" },
		{"PFX_0_FERR_STATUS",				GEN3_TSI_0_BASE + 0x10c, g_csr_TSI_PF0_FERR_STATUS_REGISTER, "Prefilter FERR status register" },
		{"PFX_0_DMA_BASE",  			GEN3_TSI_0_BASE + 0x200, NULL, "Prefilter DMA Base" },
		{"PFX_0_DMA_SIZE",  			GEN3_TSI_0_BASE + 0x204, NULL, "Prefilter DMA Size" },
		{"PFX_0_DMA_WR_PTR",			GEN3_TSI_0_BASE + 0x208, NULL, "Prefilter DMA Write Pointer" },
		{"PFX_0_DMA_SHDW_WR_PTR_ADDR",  		GEN3_TSI_0_BASE + 0x20c, NULL, "Prefilter DMA Shadow Write Pointer Address" },
		{"PFX_0_DMA_RD_PTR",			GEN3_TSI_0_BASE + 0x210, NULL, "Prefilter DMA Read Pointer" },
		{"PFX_0_DMA_SHDW_WR_CTR",        		GEN3_TSI_0_BASE + 0x214, NULL, "Prefilter DMA Shadow Write Counter" },
		{"PFX_0_NIM_WDT",        			GEN3_TSI_0_BASE + 0x218, g_csr_TSI_PF0_NIM_WDOG_TIMER_REGISTER, "Prefilter NIM Watch Dog Timer" },
		{"PFX_0_PCR_CFG",        	GEN3_TSI_0_BASE + 0x300, NULL, "Prefilter PCR Config" },
        //Reserved Registers from 0x300 to Ox31C =========================================================
		{"PFX_0_PCR_REMOTE_A0",        		GEN3_TSI_0_BASE + 0x31c, NULL, "Prefilter PCR Remote A0" },
		{"PFX_0_PCR_REMOTE_A1",     GEN3_TSI_0_BASE + 0x320, g_csr_TSI_PF0_PCR_REMOTE_A1_REGISTER, "Prefilter PCR Remote A1" },
        //OpenCable Related
		{"PFX_0_OC_HEADER_CFG",     GEN3_TSI_0_BASE + 0x340, g_csr_TSI_PF0_OC_HEADER_CONFIG_REGISTER, "Prefilter OC Header Config" },
		{"PFX_0_OC_HEADER_0A",      GEN3_TSI_0_BASE + 0x344, g_csr_TSI_PF0_OC_HEADER_0A_REGISTER,   "Prefilter OC Header-A0" },
		{"PFX_0_OC_HEADER_0B",      GEN3_TSI_0_BASE + 0x348, NULL,                                  "Prefilter OC Header-B0" },
		{"PFX_0_OC_HEADER_1A",      GEN3_TSI_0_BASE + 0x34C, g_csr_TSI_PF0_OC_HEADER_1A_REGISTER,   "Prefilter OC Header-A1" },
		{"PFX_0_OC_HEADER_1B",      GEN3_TSI_0_BASE + 0x350, NULL,                                  "Prefilter OC Header-B1" },
		{"PFX_0_OC_HEADER_2A",      GEN3_TSI_0_BASE + 0x354, g_csr_TSI_PF0_OC_HEADER_2A_REGISTER,   "Prefilter OC Header-A2" },
		{"PFX_0_OC_HEADER_2B",      GEN3_TSI_0_BASE + 0x358, NULL,                                  "Prefilter OC Header-B2" },
		{"PFX_0_OMAR_SEL",        	GEN3_TSI_0_BASE + 0x360, NULL, "Prefilter OMAR select" },
		{"PFX_0_TIMESTAMP_CTR",     GEN3_TSI_0_BASE + 0x400, NULL, "Prefilter time stamp counter" },
		{"PFX_1_PMM0",				GEN3_TSI_1_BASE + 0x0, g_csr_TSI_PF1_PMM0_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM1",				GEN3_TSI_1_BASE + 0x4, g_csr_TSI_PF1_PMM1_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM2",				GEN3_TSI_1_BASE + 0x8, g_csr_TSI_PF1_PMM2_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM3",				GEN3_TSI_1_BASE + 0xc, g_csr_TSI_PF1_PMM3_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM4",				GEN3_TSI_1_BASE + 0x10, g_csr_TSI_PF1_PMM4_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM5",				GEN3_TSI_1_BASE + 0x14, g_csr_TSI_PF1_PMM5_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM6",				GEN3_TSI_1_BASE + 0x18, g_csr_TSI_PF1_PMM6_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM7",				GEN3_TSI_1_BASE + 0x1c, g_csr_TSI_PF1_PMM7_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM8",				GEN3_TSI_1_BASE + 0x20, g_csr_TSI_PF1_PMM8_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM9",				GEN3_TSI_1_BASE + 0x24, g_csr_TSI_PF1_PMM9_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM10",				GEN3_TSI_1_BASE + 0x28, g_csr_TSI_PF1_PMM10_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM11",				GEN3_TSI_1_BASE + 0x2c, g_csr_TSI_PF1_PMM11_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM12",				GEN3_TSI_1_BASE + 0x30, g_csr_TSI_PF1_PMM12_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM13",				GEN3_TSI_1_BASE + 0x34, g_csr_TSI_PF1_PMM13_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM14",				GEN3_TSI_1_BASE + 0x38, g_csr_TSI_PF1_PMM14_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM15",				GEN3_TSI_1_BASE + 0x3c, g_csr_TSI_PF1_PMM15_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM16",				GEN3_TSI_1_BASE + 0x40, g_csr_TSI_PF1_PMM16_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM17",				GEN3_TSI_1_BASE + 0x44, g_csr_TSI_PF1_PMM17_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM18",				GEN3_TSI_1_BASE + 0x48, g_csr_TSI_PF1_PMM18_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM19",				GEN3_TSI_1_BASE + 0x4c, g_csr_TSI_PF1_PMM19_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM20",				GEN3_TSI_1_BASE + 0x50, g_csr_TSI_PF1_PMM20_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM21",				GEN3_TSI_1_BASE + 0x54, g_csr_TSI_PF1_PMM21_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM22",				GEN3_TSI_1_BASE + 0x58, g_csr_TSI_PF1_PMM22_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM23",				GEN3_TSI_1_BASE + 0x5c, g_csr_TSI_PF1_PMM23_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM24",				GEN3_TSI_1_BASE + 0x60, g_csr_TSI_PF1_PMM24_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM25",				GEN3_TSI_1_BASE + 0x64, g_csr_TSI_PF1_PMM25_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM26",				GEN3_TSI_1_BASE + 0x68, g_csr_TSI_PF1_PMM26_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM27",				GEN3_TSI_1_BASE + 0x6c, g_csr_TSI_PF1_PMM27_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM28",				GEN3_TSI_1_BASE + 0x70, g_csr_TSI_PF1_PMM28_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM29",				GEN3_TSI_1_BASE + 0x74, g_csr_TSI_PF1_PMM29_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM30",				GEN3_TSI_1_BASE + 0x78, g_csr_TSI_PF1_PMM30_REGISTER, "Mask/Match register" },
		{"PFX_1_PMM31",				GEN3_TSI_1_BASE + 0x7c, g_csr_TSI_PF1_PMM31_REGISTER, "Mask/Match register" },
		{"PFX_1_CFG",				GEN3_TSI_1_BASE + 0x100, g_csr_TSI_PF1_CFG_REGISTER, "Prefilter Config register" },
		{"PFX_1_STATUS",				GEN3_TSI_1_BASE + 0x104, g_csr_TSI_PF1_STATUS_REGISTER, "Prefilter status register" },
		{"PFX_1_ENABLE",				GEN3_TSI_1_BASE + 0x108, g_csr_TSI_PF1_ENABLE_REGISTER, "Prefilter enable register" },
		{"PFX_1_FERR_STATUS",				GEN3_TSI_1_BASE + 0x10c, g_csr_TSI_PF1_FERR_STATUS_REGISTER, "Prefilter FERR status register" },
		{"PFX_1_DMA_BASE",  			GEN3_TSI_1_BASE + 0x200, NULL, "Prefilter DMA Base" },
		{"PFX_1_DMA_SIZE",  			GEN3_TSI_1_BASE + 0x204, NULL, "Prefilter DMA Size" },
		{"PFX_1_DMA_WR_PTR",			GEN3_TSI_1_BASE + 0x208, NULL, "Prefilter DMA Write Pointer" },
		{"PFX_1_DMA_SHDW_WR_PTR_ADDR",  		GEN3_TSI_1_BASE + 0x20c, NULL, "Prefilter DMA Shadow Write Pointer Address" },
		{"PFX_1_DMA_RD_PTR",			GEN3_TSI_1_BASE + 0x210, NULL, "Prefilter DMA Read Pointer" },
		{"PFX_1_DMA_SHDW_WR_CTR",        		GEN3_TSI_1_BASE + 0x214, NULL, "Prefilter DMA Shadow Write Counter" },
		{"PFX_1_NIM_WDT",        			GEN3_TSI_1_BASE + 0x218, g_csr_TSI_PF1_NIM_WDOG_TIMER_REGISTER, "Prefilter NIM Watch Dog Timer" },
		{"PFX_1_PCR_CFG",        			GEN3_TSI_1_BASE + 0x300, NULL, "Prefilter PCR Config" },
        //Reserved Registers from 0x300 to Ox31C =========================================================
		{"PFX_1_PCR_REMOTE_A0",        		GEN3_TSI_1_BASE + 0x31c, NULL, "Prefilter PCR Remote A0" },
		{"PFX_1_PCR_REMOTE_A1",        		GEN3_TSI_1_BASE + 0x320, g_csr_TSI_PF1_PCR_REMOTE_A1_REGISTER, "Prefilter PCR Remote A1" },
        //OpenCable Related
		{"PFX_1_OC_HEADER_CFG",        		GEN3_TSI_1_BASE + 0x340, g_csr_TSI_PF1_OC_HEADER_CONFIG_REGISTER, "Prefilter OC Header Config" },
		{"PFX_1_OC_HEADER_0A",        		GEN3_TSI_1_BASE + 0x344, g_csr_TSI_PF1_OC_HEADER_0A_REGISTER,   "Prefilter OC Header-A0" },
		{"PFX_1_OC_HEADER_0B",        		GEN3_TSI_1_BASE + 0x348, NULL,                                  "Prefilter OC Header-B0" },
		{"PFX_1_OC_HEADER_1A",        		GEN3_TSI_1_BASE + 0x34C, g_csr_TSI_PF1_OC_HEADER_1A_REGISTER,   "Prefilter OC Header-A1" },
		{"PFX_1_OC_HEADER_1B",        		GEN3_TSI_1_BASE + 0x350, NULL,                                  "Prefilter OC Header-B1" },
		{"PFX_1_OC_HEADER_2A",        		GEN3_TSI_1_BASE + 0x354, g_csr_TSI_PF1_OC_HEADER_2A_REGISTER,   "Prefilter OC Header-A2" },
		{"PFX_1_OC_HEADER_2B",        		GEN3_TSI_1_BASE + 0x358, NULL,                                  "Prefilter OC Header-B2" },
		{"PFX_1_OMAR_SEL",        		GEN3_TSI_1_BASE + 0x360, NULL, "Prefilter OMAR select" },
		{"PFX_1_TIMESTAMP_CTR",        		GEN3_TSI_1_BASE + 0x400, NULL, "Prefilter time stamp counter" },
		{"PFX_2_PMM0",				GEN3_TSI_2_BASE + 0x0, g_csr_TSI_PF2_PMM0_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM1",				GEN3_TSI_2_BASE + 0x4, g_csr_TSI_PF2_PMM1_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM2",				GEN3_TSI_2_BASE + 0x8, g_csr_TSI_PF2_PMM2_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM3",				GEN3_TSI_2_BASE + 0xc, g_csr_TSI_PF2_PMM3_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM4",				GEN3_TSI_2_BASE + 0x10, g_csr_TSI_PF2_PMM4_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM5",				GEN3_TSI_2_BASE + 0x14, g_csr_TSI_PF2_PMM5_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM6",				GEN3_TSI_2_BASE + 0x18, g_csr_TSI_PF2_PMM6_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM7",				GEN3_TSI_2_BASE + 0x1c, g_csr_TSI_PF2_PMM7_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM8",				GEN3_TSI_2_BASE + 0x20, g_csr_TSI_PF2_PMM8_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM9",				GEN3_TSI_2_BASE + 0x24, g_csr_TSI_PF2_PMM9_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM10",				GEN3_TSI_2_BASE + 0x28, g_csr_TSI_PF2_PMM10_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM11",				GEN3_TSI_2_BASE + 0x2c, g_csr_TSI_PF2_PMM11_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM12",				GEN3_TSI_2_BASE + 0x30, g_csr_TSI_PF2_PMM12_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM13",				GEN3_TSI_2_BASE + 0x34, g_csr_TSI_PF2_PMM13_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM14",				GEN3_TSI_2_BASE + 0x38, g_csr_TSI_PF2_PMM14_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM15",				GEN3_TSI_2_BASE + 0x3c, g_csr_TSI_PF2_PMM15_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM16",				GEN3_TSI_2_BASE + 0x40, g_csr_TSI_PF2_PMM16_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM17",				GEN3_TSI_2_BASE + 0x44, g_csr_TSI_PF2_PMM17_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM18",				GEN3_TSI_2_BASE + 0x48, g_csr_TSI_PF2_PMM18_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM19",				GEN3_TSI_2_BASE + 0x4c, g_csr_TSI_PF2_PMM19_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM20",				GEN3_TSI_2_BASE + 0x50, g_csr_TSI_PF2_PMM20_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM21",				GEN3_TSI_2_BASE + 0x54, g_csr_TSI_PF2_PMM21_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM22",				GEN3_TSI_2_BASE + 0x58, g_csr_TSI_PF2_PMM22_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM23",				GEN3_TSI_2_BASE + 0x5c, g_csr_TSI_PF2_PMM23_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM24",				GEN3_TSI_2_BASE + 0x60, g_csr_TSI_PF2_PMM24_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM25",				GEN3_TSI_2_BASE + 0x64, g_csr_TSI_PF2_PMM25_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM26",				GEN3_TSI_2_BASE + 0x68, g_csr_TSI_PF2_PMM26_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM27",				GEN3_TSI_2_BASE + 0x6c, g_csr_TSI_PF2_PMM27_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM28",				GEN3_TSI_2_BASE + 0x70, g_csr_TSI_PF2_PMM28_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM29",				GEN3_TSI_2_BASE + 0x74, g_csr_TSI_PF2_PMM29_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM30",				GEN3_TSI_2_BASE + 0x78, g_csr_TSI_PF2_PMM30_REGISTER, "Mask/Match register" },
		{"PFX_2_PMM31",				GEN3_TSI_2_BASE + 0x7c, g_csr_TSI_PF2_PMM31_REGISTER, "Mask/Match register" },
		{"PFX_2_CFG",				GEN3_TSI_2_BASE + 0x100, g_csr_TSI_PF2_CFG_REGISTER, "Prefilter Config register" },
		{"PFX_2_STATUS",				GEN3_TSI_2_BASE + 0x104, g_csr_TSI_PF2_STATUS_REGISTER, "Prefilter status register" },
		{"PFX_2_ENABLE",				GEN3_TSI_2_BASE + 0x108, g_csr_TSI_PF2_ENABLE_REGISTER, "Prefilter enable register" },
		{"PFX_2_FERR_STATUS",				GEN3_TSI_2_BASE + 0x10c, g_csr_TSI_PF2_FERR_STATUS_REGISTER, "Prefilter FERR status register" },
		{"PFX_2_DMA_BASE",  			GEN3_TSI_2_BASE + 0x200, NULL, "Prefilter DMA Base" },
		{"PFX_2_DMA_SIZE",  			GEN3_TSI_2_BASE + 0x204, NULL, "Prefilter DMA Size" },
		{"PFX_2_DMA_WR_PTR",			GEN3_TSI_2_BASE + 0x208, NULL, "Prefilter DMA Write Pointer" },
		{"PFX_2_DMA_SHDW_WR_PTR_ADDR",  		GEN3_TSI_2_BASE + 0x20c, NULL, "Prefilter DMA Shadow Write Pointer Address" },
		{"PFX_2_DMA_RD_PTR",			GEN3_TSI_2_BASE + 0x210, NULL, "Prefilter DMA Read Pointer" },
		{"PFX_2_DMA_SHDW_WR_CTR",        		GEN3_TSI_2_BASE + 0x214, NULL, "Prefilter DMA Shadow Write Counter" },
		{"PFX_2_NIM_WDT",        			GEN3_TSI_2_BASE + 0x218, g_csr_TSI_PF2_NIM_WDOG_TIMER_REGISTER, "Prefilter NIM Watch Dog Timer" },
		{"PFX_2_PCR_CFG",        			GEN3_TSI_2_BASE + 0x300, NULL, "Prefilter PCR Config" },
        //Reserved Registers from 0x300 to Ox31C =========================================================
		{"PFX_2_PCR_REMOTE_A0",        		GEN3_TSI_2_BASE + 0x31c, NULL, "Prefilter PCR Remote A0" },
		{"PFX_2_PCR_REMOTE_A1",        		GEN3_TSI_2_BASE + 0x320, g_csr_TSI_PF2_PCR_REMOTE_A1_REGISTER, "Prefilter PCR Remote A1" },
        //OpenCable Related
		{"PFX_2_OC_HEADER_CFG",        		GEN3_TSI_2_BASE + 0x340, g_csr_TSI_PF2_OC_HEADER_CONFIG_REGISTER, "Prefilter OC Header Config" },
		{"PFX_2_OC_HEADER_0A",        		GEN3_TSI_2_BASE + 0x344, g_csr_TSI_PF2_OC_HEADER_0A_REGISTER,   "Prefilter OC Header-A0" },
		{"PFX_2_OC_HEADER_0B",        		GEN3_TSI_2_BASE + 0x348, NULL,                                  "Prefilter OC Header-B0" },
		{"PFX_2_OC_HEADER_1A",        		GEN3_TSI_2_BASE + 0x34C, g_csr_TSI_PF2_OC_HEADER_1A_REGISTER,   "Prefilter OC Header-A1" },
		{"PFX_2_OC_HEADER_1B",        		GEN3_TSI_2_BASE + 0x350, NULL,                                  "Prefilter OC Header-B1" },
		{"PFX_2_OC_HEADER_2A",        		GEN3_TSI_2_BASE + 0x354, g_csr_TSI_PF2_OC_HEADER_2A_REGISTER,   "Prefilter OC Header-A2" },
		{"PFX_2_OC_HEADER_2B",        		GEN3_TSI_2_BASE + 0x358, NULL,                                  "Prefilter OC Header-B2" },
		{"PFX_2_OMAR_SEL",        		GEN3_TSI_2_BASE + 0x360, NULL, "Prefilter OMAR select" },
		{"PFX_2_TIMESTAMP_CTR",        		GEN3_TSI_2_BASE + 0x400, NULL, "Prefilter time stamp counter" },
		{"PFX_3_PMM0",				GEN3_TSI_3_BASE + 0x0, g_csr_TSI_PF3_PMM0_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM1",				GEN3_TSI_3_BASE + 0x4, g_csr_TSI_PF3_PMM1_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM2",				GEN3_TSI_3_BASE + 0x8, g_csr_TSI_PF3_PMM2_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM3",				GEN3_TSI_3_BASE + 0xc, g_csr_TSI_PF3_PMM3_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM4",				GEN3_TSI_3_BASE + 0x10, g_csr_TSI_PF3_PMM4_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM5",				GEN3_TSI_3_BASE + 0x14, g_csr_TSI_PF3_PMM5_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM6",				GEN3_TSI_3_BASE + 0x18, g_csr_TSI_PF3_PMM6_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM7",				GEN3_TSI_3_BASE + 0x1c, g_csr_TSI_PF3_PMM7_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM8",				GEN3_TSI_3_BASE + 0x20, g_csr_TSI_PF3_PMM8_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM9",				GEN3_TSI_3_BASE + 0x24, g_csr_TSI_PF3_PMM9_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM10",				GEN3_TSI_3_BASE + 0x28, g_csr_TSI_PF3_PMM10_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM11",				GEN3_TSI_3_BASE + 0x2c, g_csr_TSI_PF3_PMM11_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM12",				GEN3_TSI_3_BASE + 0x30, g_csr_TSI_PF3_PMM12_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM13",				GEN3_TSI_3_BASE + 0x34, g_csr_TSI_PF3_PMM13_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM14",				GEN3_TSI_3_BASE + 0x38, g_csr_TSI_PF3_PMM14_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM15",				GEN3_TSI_3_BASE + 0x3c, g_csr_TSI_PF3_PMM15_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM16",				GEN3_TSI_3_BASE + 0x40, g_csr_TSI_PF3_PMM16_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM17",				GEN3_TSI_3_BASE + 0x44, g_csr_TSI_PF3_PMM17_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM18",				GEN3_TSI_3_BASE + 0x48, g_csr_TSI_PF3_PMM18_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM19",				GEN3_TSI_3_BASE + 0x4c, g_csr_TSI_PF3_PMM19_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM20",				GEN3_TSI_3_BASE + 0x50, g_csr_TSI_PF3_PMM20_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM21",				GEN3_TSI_3_BASE + 0x54, g_csr_TSI_PF3_PMM21_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM22",				GEN3_TSI_3_BASE + 0x58, g_csr_TSI_PF3_PMM22_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM23",				GEN3_TSI_3_BASE + 0x5c, g_csr_TSI_PF3_PMM23_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM24",				GEN3_TSI_3_BASE + 0x60, g_csr_TSI_PF3_PMM24_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM25",				GEN3_TSI_3_BASE + 0x64, g_csr_TSI_PF3_PMM25_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM26",				GEN3_TSI_3_BASE + 0x68, g_csr_TSI_PF3_PMM26_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM27",				GEN3_TSI_3_BASE + 0x6c, g_csr_TSI_PF3_PMM27_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM28",				GEN3_TSI_3_BASE + 0x70, g_csr_TSI_PF3_PMM28_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM29",				GEN3_TSI_3_BASE + 0x74, g_csr_TSI_PF3_PMM29_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM30",				GEN3_TSI_3_BASE + 0x78, g_csr_TSI_PF3_PMM30_REGISTER, "Mask/Match register" },
		{"PFX_3_PMM31",				GEN3_TSI_3_BASE + 0x7c, g_csr_TSI_PF3_PMM31_REGISTER, "Mask/Match register" },
		{"PFX_3_CFG",				GEN3_TSI_3_BASE + 0x100, g_csr_TSI_PF3_CFG_REGISTER, "Prefilter Config register" },
		{"PFX_3_STATUS",				GEN3_TSI_3_BASE + 0x104, g_csr_TSI_PF3_STATUS_REGISTER, "Prefilter status register" },
		{"PFX_3_ENABLE",				GEN3_TSI_3_BASE + 0x108, g_csr_TSI_PF3_ENABLE_REGISTER, "Prefilter enable register" },
		{"PFX_3_FERR_STATUS",				GEN3_TSI_3_BASE + 0x10c, g_csr_TSI_PF3_FERR_STATUS_REGISTER, "Prefilter FERR status register" },
		{"PFX_3_DMA_BASE",  			GEN3_TSI_3_BASE + 0x200, NULL, "Prefilter DMA Base" },
		{"PFX_3_DMA_SIZE",  			GEN3_TSI_3_BASE + 0x204, NULL, "Prefilter DMA Size" },
		{"PFX_3_DMA_WR_PTR",			GEN3_TSI_3_BASE + 0x208, NULL, "Prefilter DMA Write Pointer" },
		{"PFX_3_DMA_SHDW_WR_PTR_ADDR",  		GEN3_TSI_3_BASE + 0x20c, NULL, "Prefilter DMA Shadow Write Pointer Address" },
		{"PFX_3_DMA_RD_PTR",			        GEN3_TSI_3_BASE + 0x210, NULL, "Prefilter DMA Read Pointer" },
		{"PFX_3_DMA_SHDW_WR_CTR",        	GEN3_TSI_3_BASE + 0x214, NULL, "Prefilter DMA Shadow Write Counter" },
		{"PFX_3_NIM_WDT",        			GEN3_TSI_3_BASE + 0x218, g_csr_TSI_PF3_NIM_WDOG_TIMER_REGISTER, "Prefilter NIM Watch Dog Timer" },
		{"PFX_3_PCR_CFG",        			GEN3_TSI_3_BASE + 0x300, NULL, "Prefilter PCR Config" },
        //Reserved Registers from 0x300 to Ox31C =========================================================
		{"PFX_3_PCR_REMOTE_A0",        		GEN3_TSI_3_BASE + 0x31c, NULL, "Prefilter PCR Remote A0" },
		{"PFX_3_PCR_REMOTE_A1",        		GEN3_TSI_3_BASE + 0x320, g_csr_TSI_PF3_PCR_REMOTE_A1_REGISTER, "Prefilter PCR Remote A1" },
        //OpenCable Related
		{"PFX_3_OC_HEADER_CFG",        		GEN3_TSI_3_BASE + 0x340, g_csr_TSI_PF3_OC_HEADER_CONFIG_REGISTER, "Prefilter OC Header Config" },
		{"PFX_3_OC_HEADER_0A",        		GEN3_TSI_3_BASE + 0x344, g_csr_TSI_PF3_OC_HEADER_0A_REGISTER,   "Prefilter OC Header-A0" },
		{"PFX_3_OC_HEADER_0B",        		GEN3_TSI_3_BASE + 0x348, NULL,                                  "Prefilter OC Header-B0" },
		{"PFX_3_OC_HEADER_1A",        		GEN3_TSI_3_BASE + 0x34C, g_csr_TSI_PF3_OC_HEADER_1A_REGISTER,   "Prefilter OC Header-A1" },
		{"PFX_3_OC_HEADER_1B",        		GEN3_TSI_3_BASE + 0x350, NULL,                                  "Prefilter OC Header-B1" },
		{"PFX_3_OC_HEADER_2A",        		GEN3_TSI_3_BASE + 0x354, g_csr_TSI_PF3_OC_HEADER_2A_REGISTER,   "Prefilter OC Header-A2" },
		{"PFX_3_OC_HEADER_2B",        		GEN3_TSI_3_BASE + 0x358, NULL,                                  "Prefilter OC Header-B2" },
		{"PFX_3_OMAR_SEL",        		    GEN3_TSI_3_BASE + 0x360, NULL, "Prefilter OMAR select" },
		{"PFX_3_TIMESTAMP_CTR",        		GEN3_TSI_3_BASE + 0x400, NULL, "Prefilter time stamp counter" },
		//NOTE: Since the CE receive interface is shared with TS3 input, the receive timestamp
		// counter is shared with pf3_timestamp_count.
		{NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct SVEN_Module_EventSpecific g_gen3_tsi_specific_events[] =
{
    { "BUFFER_FULL",     1,      " Context %d's output buffer is full!", NULL },
    { "PACKET_LOSS",     2,      " Context %d dropped a buffer!", NULL },
    { "OC_FIFO_FULL",    3,      " Context %d's OpenCable FIFO is full!", NULL },
    { "OC_CRC",          4,      " Context %d had an OpenCable header CRC error!", NULL },
    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_gen3_tsi_sven_module =
{
    "GEN3_TSI",
    SVEN_module_GEN3_PREFILT,
    0x0000C000,						/* CSR Space is 0x4000 in size.  Filters range from 0x4000 to 0xC000*/
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen3_tsi,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "TSI: Third Generation Prefilter Unit",
    g_gen3_tsi_specific_events,
    NULL /* extension list */
};
