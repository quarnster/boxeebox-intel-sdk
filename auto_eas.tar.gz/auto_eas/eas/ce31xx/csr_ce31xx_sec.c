/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef SEC_SVEN_H
#define SEC_SVEN_H

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD

static const struct EAS_RegBits g_csr_sec_status [] = { 
  { "Reserved0", 0, 2 , NULL, NULL },
  { "HCU_BUSY", 2, 1 , NULL, NULL },
  { "CSS_BUSY", 3, 1 , NULL, NULL },
  { "C2_BUSY", 4, 1, NULL, NULL },
  { "AES_BUSY", 5, 1, NULL, NULL },
  { "DES_BUSY", 6, 1, NULL, NULL },
  { "Reserved1", 7, 25 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_control [] = { 
  { "HOST_ENABLE", 0, 1 , NULL, NULL },
  { "Reserved0", 1, 2 , NULL, NULL },
  { "EXP_WR_ENABLE", 3, 1, NULL, NULL },
  { "Reserved1", 4, 28, NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_config [] = { 
  { "EAU_PARITY_ODD", 0, 1 , NULL, NULL },
  { "Reserved2", 1, 31 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_threat [] = { 
  { "SYSTEM_RESET", 0, 1 , NULL, NULL },
  { "Reserved3", 1, 31 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_int_mask [] = { 
  { "Reserved4", 0, 1 , NULL, NULL },
  { "INT_MASK", 1, 15 , NULL, NULL },
  { "Reserved5", 16, 16 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_int_pending [] = { 
  { "Reserved6", 0, 1 , NULL, NULL },
  { "INT_PENDING", 1, 15 , NULL, NULL },
  { "Reserved7", 16, 16 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_int_force [] = { 
  { "Reserved8", 0, 1 , NULL, NULL },
  { "INT_FORCE", 1, 15 , NULL, NULL },
  { "Reserved9", 16, 16 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_int_clear_pending [] = { 
  { "INT_CLEAR_PENDING", 0, 32 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_int_status [] = { 
  { "TMR_MTB_INT", 31, 1 , NULL, NULL },
  { "TMR1_INT", 30, 1 , NULL, NULL },
  { "TMR0_INT", 29, 1 , NULL, NULL },
  { "EAU_PERR", 28, 1 , NULL, NULL },
  { "RNG_FIFO_FULL", 27, 1 , NULL, NULL },
  { "Reserved10", 26, 1 , NULL, NULL },
  { "EAU_INT", 25, 1 , NULL, NULL },
  { "HCU_DONE", 24, 1 , NULL, NULL },
  { "CSS_DONE", 23, 1 , NULL, NULL },
  { "C2_DONE", 22, 1 , NULL, NULL },
  { "AES_DONE", 21, 1 , NULL, NULL },
  { "DES_DONE", 20, 1 , NULL, NULL },
  { "Reserved11", 17, 3 , NULL, NULL },
  { "SRC_HCU_INT", 16, 1 , NULL, NULL },
  { "SRC_CSS_INT", 15, 1 , NULL, NULL },
  { "SRC_C2_INT", 14, 1 , NULL, NULL },
  { "SRC_AES_INT", 13, 1 , NULL, NULL },
  { "SRC_DES_INT", 12, 1 , NULL, NULL },
  { "Reserved12", 9, 3 , NULL, NULL },
  { "DST_HCU_INT", 8, 1 , NULL, NULL },
  { "DST_CSS_INT", 7, 1 , NULL, NULL },
  { "DST_C2_INT", 6, 1 , NULL, NULL },
  { "DST_AES_INT", 5, 1 , NULL, NULL },
  { "DST_DES_INT", 4, 1 , NULL, NULL },
  { "Reserved13", 2, 2 , NULL, NULL },
  { "IPC_OUTPUT_READY_INT", 1, 1 , NULL, NULL },
  { "IPC_INPUT_DOORBELL_INT", 0, 1 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_int_status_mask [] = { 
  { "INT_STATUS_MASK", 0, 32 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_int_nm_status [] = { 
  { "Reserved14", 6, 26 , NULL, NULL },
  { "TMR_WDOG_TIMEOUT", 5, 1 , NULL, NULL },
  { "TMR_MTB_OVERFLOW", 4, 1 , NULL, NULL },
  { "Reserved15", 3, 1 , NULL, NULL },
  { "DES_HKEY_ERROR", 2, 1 , NULL, NULL },
  { "AES_HKEY_ERROR", 1, 1 , NULL, NULL },
  { "ILLEGAL_MEM_ACCESS", 0, 1 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_int_nm_status_mask [] = { 
  { "INT_NM_STATUS_MASK", 0, 32 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_ipc_input_doorbell [] = { 
  { "IPC_INPUT_DOORBELL", 0, 32 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_ipc_output_doorbell [] = { 
  { "IPC_OUTPUT_DOORBELL", 0, 32 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_ipc_input_status [] = { 
  { "IPC_INPUT_READY", 0, 1 , NULL, NULL },
  { "Reserved16", 1, 31 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_ipc_output_status [] = { 
  { "IPC_OUTPUT_READY", 0, 1 , NULL, NULL },
  { "Reserved17", 1, 31 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_ipc_host_int_status [] = { 
  { "Reserved18", 22, 10 , NULL, NULL },
  { "TMR_WDOG_TIMEOUT", 21, 1 , NULL, NULL },
  { "TMR_MTB_OVERFLOW", 20, 1 , NULL, NULL },
  { "Reserved19", 19, 1 , NULL, NULL },
  { "DES_HKEY_ERROR", 18, 1 , NULL, NULL },
  { "AES_HKEY_ERROR", 17, 1 , NULL, NULL },
  { "ILLEGAL_MEM_ACCESS", 16, 1 , NULL, NULL },
  { "Reserved20", 2, 14 , NULL, NULL },
  { "IPC_INPUT_READY_INT", 1, 1 , NULL, NULL },
  { "IPC_OUTPUT_DOORBELL_INT", 0, 1 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_ipc_host_int_mask [] = { 
  { "Reserved21", 2, 30 , NULL, NULL },
  { "IPC_INPUT_READY_INT_MASK", 1, 1 , NULL, NULL },
  { "IPC_OUTPUT_DOORBELL_INT_MASK", 0, 1 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_ipc_input_payload [] = { 
  { "IPC_INPUT_PAYLOAD", 0, 512 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_ipc_output_payload [] = { 
  { "IPC_OUTPUT_PAYLOAD", 0, 512 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_ipc_shared_payload [] = { 
  { "IPC_SHARED_PAYLOAD", 0, 2048 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_debug_config [] = { 
  { "SEC_RISC_SYNC_RESET", 31, 1 , NULL, NULL },
  { "SEC_RISC_PERIPH_SYNC_RESET", 30, 1 , NULL, NULL },
  { "Reserved22", 2, 28 , NULL, NULL },
  { "SYS_PMODE", 0, 2 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_pmu_sel [] = { 
  { "Reserved23", 6, 26 , NULL, NULL },
  { "SEL1", 3, 3 , NULL, NULL },
  { "SEL0", 0, 3 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_omar_sel [] = { 
  { "Reserved24", 3, 29 , NULL, NULL },
  { "SEL", 0, 3 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_omar_scratch [] = { 
  { "Reserved25", 16, 16 , NULL, NULL },
  { "OMAR_SCRATCH", 0, 16 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_fuse_config0 [] = { 
  { "DEVELOPMENT_MODE", 31, 1 , NULL, NULL },
  { "REMAP_BOOT", 30, 1 , NULL, NULL },
  { "SHUTDOWN_MODE", 28, 2 , NULL, NULL },
  { "WDOG_SYS_RESET_ENABLE", 27, 1 , NULL, NULL },
  { "LO_8K_ROM_IMAGE", 26, 1 , NULL, NULL },
  { "HI_8K_ROM_IMAGE", 25, 1 , NULL, NULL },
  { "OTP_SELECT", 24, 1 , NULL, NULL },
  { "Reserved26", 22, 2 , NULL, NULL },
  { "FLASH_AUTH_SIZE", 20, 2 , NULL, NULL },
  { "KERNEL_OVERRIDE", 19, 1 , NULL, NULL },
  { "JTAG_PASSWORD_XOR", 18, 1 , NULL, NULL },
  { "JTAG_PASSWORD_ENABLE", 17, 1 , NULL, NULL },
  { "JTAG_PERM_XOR", 16, 1 , NULL, NULL },
  { "Reserved27", 15, 1 , NULL, NULL },
  { "DTV_ENABLE", 14, 1 , NULL, NULL },
  { "HKEY1_ALT_ENABLE", 13, 1 , NULL, NULL },
  { "HKEY0_ALT_ENABLE", 12, 1 , NULL, NULL },
  { "HKEY1_DERIVATIVE_ENABLE", 11, 1 , NULL, NULL },
  { "HKEY0_DERIVATIVE_ENABLE", 10, 1 , NULL, NULL },
  { "HKEY1_FW_ENABLE", 9, 1 , NULL, NULL },
  { "FKEY_ENABLE", 8, 1 , NULL, NULL },
  { "HKEY1_USE_PSK", 7, 1 , NULL, NULL },
  { "HKEY0_USE_SSK", 6, 1 , NULL, NULL },
  { "HKEY1_USE_AES", 5, 1 , NULL, NULL },
  { "HKEY0_USE_AES", 4, 1 , NULL, NULL },
  { "VGS_ENABLE", 3, 1 , NULL, NULL },
  { "RNG_HW_ENABLE", 2, 1 , NULL, NULL },
  { "HOSTACCESS_EN", 1, 1 , NULL, NULL },
  { "SECTUREBOOT_EN", 0, 1 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_fuse_status0 [] = { 
  { "SEC_FUSE_STATUS0", 0, 31 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_sys_atu_src_base0 [] = { 
  { "SYS_ATU_SRC_BASE", 12, 20 , NULL, NULL },
  { "Reserved28", 0, 12 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_sys_atu_src_base1 [] = { 
  { "SYS_ATU_SRC_BASE", 12, 20 , NULL, NULL },
  { "Reserved29", 0, 12 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_sys_atu_dst_base0 [] = { 
  { "SYS_ATU_DST_BASE", 12, 20 , NULL, NULL },
  { "Reserved30", 0, 12 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_sys_atu_dst_base1 [] = { 
  { "SYS_ATU_DST_BASE", 12, 20 , NULL, NULL },
  { "Reserved31", 0, 12 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_sys_atu_mask0 [] = { 
  { "SYS_ATU_MASK", 12, 20 , NULL, NULL },
  { "Reserved32", 0, 12 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_sys_atu_mask1 [] = { 
  { "SYS_ATU_MASK", 12, 20 , NULL, NULL },
  { "Reserved33", 0, 12 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_RegBits g_csr_sec_udma_context0_des_flags_mode [] = { 
  { "SYS_ATU_MASK", 12, 20 , NULL, NULL },
  { "Reserved34", 0, 12 , NULL, NULL },
  { NULL, 0, 0, NULL, NULL }    /* NULL terminator */
}; 

static const struct EAS_Register g_gen3_csr_sec [] ={ 
  { "SEC_STATUS", 0x0800, g_csr_sec_status, "SEC Status Register" , NULL }, /* reg bits defined above */
  { "SEC_CONTROL", 0x804, g_csr_sec_control, "SEC Control Register" , NULL },
  { "SEC_CONFIG", 0x80c, g_csr_sec_config, "SEC Config Register" , NULL },
  { "SEC_THREAT", 0x810, g_csr_sec_threat, "SEC Threat Register" , NULL },
  { "SEC_INT_MASK", 0xa00, g_csr_sec_int_mask, "SEC Interrupt Mask" , NULL },
  { "SEC_INT_PENDING", 0xa04, g_csr_sec_int_pending, "SEC Interrupt Pending" , NULL },
  { "SEC_INT_FORCE", 0xa08, g_csr_sec_int_force, "SEC Interrupt Force" , NULL },
  { "SEC_INT_CLEAR_PENDING", 0xa0c, g_csr_sec_int_clear_pending, "SEC Interrupt Clear Pending" , NULL },
  { "SEC_INT_STATUS", 0xa10, g_csr_sec_int_status, "SEC Interrupt Status" , NULL },
  { "SEC_INT_STATUS_MASK", 0xa14, g_csr_sec_int_status_mask, "SEC Interrupt Status Mask" , NULL },
  { "SEC_INT_NM_STATUS", 0xa18, g_csr_sec_int_nm_status, "SEC Interrupt NM Status" , NULL },
  { "SEC_INT_NM_STATUS_MASK", 0xa18, g_csr_sec_int_nm_status_mask, "SEC Interrupt NM Status Mask" , NULL },
  { "SEC_IPC_INPUT_DOORBELL", 0x400, g_csr_sec_ipc_input_doorbell, "IPC Input Doorbell", NULL },
  { "SEC_IPC_OUTPUT_DOORBELL", 0x404, g_csr_sec_ipc_output_doorbell, "IPC Output Doorbell", NULL },
  { "SEC_IPC_INPUT_STATUS", 0x408, g_csr_sec_ipc_input_status, "IPC Input Status", NULL },
  { "SEC_IPC_OUTPUT_STATUS", 0x40c, g_csr_sec_ipc_output_status, "IPC Output Status", NULL },
  { "SEC_IPC_HOST_INT_STATUS", 0x410, g_csr_sec_ipc_host_int_status, "IPC Host Interrupt Status", NULL },
  { "SEC_IPC_HOST_INT_MASK", 0x414, g_csr_sec_ipc_host_int_mask, "IPC Host Interrupt Mask", NULL },
  { "SEC_IPC_INPUT_PAYLOAD", 0x500, g_csr_sec_ipc_input_payload, "IPC Input Payload", NULL },
  { "SEC_IPC_OUTPUT_PAYLOAD", 0x580, g_csr_sec_ipc_output_payload, "IPC Output Payload", NULL },
  { "SEC_IPC_SHARED_PAYLOAD", 0x600, g_csr_sec_ipc_shared_payload, "IPC Shared Payload", NULL },
  { "SEC_DEBUG_CONFIG", 0x4e0, g_csr_sec_debug_config, "SEC Debug Config", NULL },
  { "SEC_PMU_SEL", 0x4e4, g_csr_sec_pmu_sel, "SEC PMU Select Register", NULL },
  { "SEC_OMAR_SEL", 0x4e8, g_csr_sec_omar_sel, "SEC OMAR Select Register", NULL },
  { "SEC_OMAR_SCRATCH", 0x4ec, g_csr_sec_omar_scratch, "SEC OMAR Scratch Register", NULL },
  { "SEC_FUSE_CONFIG0", 0x4f0, g_csr_sec_fuse_config0, "SEC Fuse Config0", NULL },
  { "SEC_FUSE_STATUS0", 0x4f0, g_csr_sec_fuse_status0, "SEC Fuse Status0", NULL },
  { "SEC_SYS_ATU_SRC_BASE0", 0x900, g_csr_sec_sys_atu_src_base0, "SEC_SYS_ATU_SRC_BASE0", NULL },
  { "SEC_SYS_ATU_SRC_BASE1", 0x904, g_csr_sec_sys_atu_src_base1, "SEC_SYS_ATU_SRC_BASE1", NULL },
  { "SEC_SYS_ATU_DST_BASE0", 0x908, g_csr_sec_sys_atu_dst_base0, "SEC_SYS_ATU_DST_BASE0", NULL },
  { "SEC_SYS_ATU_DST_BASE1", 0x90c, g_csr_sec_sys_atu_dst_base1, "SEC_SYS_ATU_DST_BASE1", NULL },
  { "SEC_SYS_ATU_ADDR_MASK0", 0x910, g_csr_sec_sys_atu_mask0, "SEC_SYS_ATU_ADDR_MASK0", NULL },
  { "SEC_SYS_ATU_ADDR_MASK1", 0x914, g_csr_sec_sys_atu_mask1, "SEC_SYS_ATU_ADDR_MASK1", NULL },

  { "SEC_UDMA_CONTEXT0_DES_RESERVED0", 0x4000, NULL, "DES DMA Context Reserved", NULL },
  { "SEC_UDMA_CONTEXT0_DES_RESERVED1", 0x4004, NULL, "DES DMA Context Reserved", NULL },
  { "SEC_UDMA_CONTEXT0_DES_CURR_DESCR", 0x4008, NULL, "DES DMA Context Current Descriptor", NULL },
  { "SEC_UDMA_CONTEXT0_DES_NEXT_DESCR", 0x400c, NULL, "DES DMA Next Descriptor", NULL },
  { "SEC_UDMA_CONTEXT0_DES_SRC_DMA_START", 0x4010, NULL, "DES DMA SrcDMA Start", NULL },
  { "SEC_UDMA_CONTEXT0_DES_DST_DMA_START", 0x4014, NULL, "DES DMA DstDMA Start", NULL },
  { "SEC_UDMA_CONTEXT0_DES_SRC_DMA_SIZE", 0x4018, NULL, "DES DMA SrcDMA Size", NULL },
  { "SEC_UDMA_CONTEXT0_DES_FLAGS_MODE", 0x401c, NULL , "DES Flags Mode", NULL },
  { "SEC_UDMA_CONTEXT0_DES_SRC_DMA_START_ALIAS", 0x4020, NULL, "DES SrcDMA Start Alias", NULL },
  { "SEC_UDMA_CONTEXT0_DES_DST_DMA_SIZE", 0x4034, NULL, "DES DstDMA Size", NULL },

  { "SEC_UDMA_CONTEXT1_AES_RESERVED0", 0x4040, NULL, "AES DMA Context Reserved", NULL },
  { "SEC_UDMA_CONTEXT1_AES_RESERVED1", 0x4044, NULL, "AES DMA Context Reserved", NULL },
  { "SEC_UDMA_CONTEXT1_AES_CURR_DESCR", 0x4048, NULL, "AES DMA Context Current Descriptor", NULL },
  { "SEC_UDMA_CONTEXT1_AES_NEXT_DESCR", 0x404c, NULL, "AES DMA Next Descriptor", NULL },
  { "SEC_UDMA_CONTEXT1_AES_SRC_DMA_START", 0x4050, NULL, "AES DMA SrcDMA Start", NULL },
  { "SEC_UDMA_CONTEXT1_AES_DST_DMA_START", 0x4054, NULL, "AES DMA DstDMA Start", NULL },
  { "SEC_UDMA_CONTEXT1_AES_SRC_DMA_SIZE", 0x4058, NULL, "AES DMA SrcDMA Size", NULL },
  { "SEC_UDMA_CONTEXT1_AES_FLAGS_MODE", 0x405c, NULL, "AES Flags Mode", NULL },
  { "SEC_UDMA_CONTEXT1_AES_SRC_DMA_START_ALIAS", 0x4060, NULL, "AES SrcDMA Start Alias", NULL },
  { "SEC_UDMA_CONTEXT1_AES_DST_DMA_SIZE", 0x4074, NULL, "AES DstDMA Size", NULL },

  { "SEC_UDMA_CONTEXT2_C2_RESERVED0", 0x4080, NULL, "C2 DMA Context Reserved", NULL },
  { "SEC_UDMA_CONTEXT2_C2_RESERVED1", 0x4084, NULL, "C2 DMA Context Reserved", NULL },
  { "SEC_UDMA_CONTEXT2_C2_CURR_DESCR", 0x4088, NULL, "C2 DMA Context Current Descriptor", NULL },
  { "SEC_UDMA_CONTEXT2_C2_NEXT_DESCR", 0x408c, NULL, "C2 DMA Next Descriptor", NULL },
  { "SEC_UDMA_CONTEXT2_C2_SRC_DMA_START", 0x4090, NULL, "C2 DMA SrcDMA Start", NULL },
  { "SEC_UDMA_CONTEXT2_C2_DST_DMA_START", 0x4094, NULL, "C2 DMA DstDMA Start", NULL },
  { "SEC_UDMA_CONTEXT2_C2_SRC_DMA_SIZE", 0x4098, NULL, "C2 DMA SrcDMA Size", NULL },
  { "SEC_UDMA_CONTEXT2_C2_FLAGS_MODE", 0x409c, NULL, "C2 Flags Mode", NULL },
  { "SEC_UDMA_CONTEXT2_C2_SRC_DMA_START_ALIAS", 0x40a0, NULL, "C2 SrcDMA Start Alias", NULL },
  { "SEC_UDMA_CONTEXT2_C2_DST_DMA_SIZE", 0x40b4, NULL, "C2 DstDMA Size", NULL },

  { "SEC_UDMA_CONTEXT3_CSS_RESERVED0", 0x40c0, NULL, "CSS DMA Context Reserved", NULL },
  { "SEC_UDMA_CONTEXT3_CSS_RESERVED1", 0x40c4, NULL, "CSS DMA Context Reserved", NULL },
  { "SEC_UDMA_CONTEXT3_CSS_CURR_DESCR", 0x40c8, NULL, "CSS DMA Context Current Descriptor", NULL },
  { "SEC_UDMA_CONTEXT3_CSS_NEXT_DESCR", 0x40cc, NULL, "CSS DMA Next Descriptor", NULL },
  { "SEC_UDMA_CONTEXT3_CSS_SRC_DMA_START", 0x40d0, NULL, "CSS DMA SrcDMA Start", NULL },
  { "SEC_UDMA_CONTEXT3_CSS_DST_DMA_START", 0x40d4, NULL, "CSS DMA DstDMA Start", NULL },
  { "SEC_UDMA_CONTEXT3_CSS_SRC_DMA_SIZE", 0x40d8, NULL, "CSS DMA SrcDMA Size", NULL },
  { "SEC_UDMA_CONTEXT3_CSS_FLAGS_MODE", 0x40dc, NULL, "CSS Flags Mode", NULL },
  { "SEC_UDMA_CONTEXT3_CSS_SRC_DMA_START_ALIAS", 0x40e0, NULL, "CSS SrcDMA Start Alias", NULL },
  { "SEC_UDMA_CONTEXT3_CSS_DST_DMA_SIZE", 0x40f4, NULL, "CSS DstDMA Size", NULL },

  { "SEC_UDMA_CONTEXT4_HCU_RESERVED0", 0x4100, NULL, "HCU DMA Context Reserved", NULL },
  { "SEC_UDMA_CONTEXT4_HCU_RESERVED1", 0x4104, NULL, "HCU DMA Context Reserved", NULL },
  { "SEC_UDMA_CONTEXT4_HCU_CURR_DESCR", 0x4108, NULL, "HCU DMA Context Current Descriptor", NULL },
  { "SEC_UDMA_CONTEXT4_HCU_NEXT_DESCR", 0x410c, NULL, "HCU DMA Next Descriptor", NULL },
  { "SEC_UDMA_CONTEXT4_HCU_SRC_DMA_START", 0x4120, NULL, "HCU DMA SrcDMA Start", NULL },
  { "SEC_UDMA_CONTEXT4_HCU_DST_DMA_START", 0x4124, NULL, "HCU DMA DstDMA Start", NULL },
  { "SEC_UDMA_CONTEXT4_HCU_SRC_DMA_SIZE", 0x4128, NULL, "HCU DMA SrcDMA Size", NULL },
  { "SEC_UDMA_CONTEXT4_HCU_FLAGS_MODE", 0x412c, NULL, "HCU Flags Mode", NULL },
  { "SEC_UDMA_CONTEXT4_HCU_SRC_DMA_START_ALIAS", 0x4130, NULL, "HCU SrcDMA Start Alias", NULL },
  { "SEC_UDMA_CONTEXT4_HCU_DST_DMA_SIZE", 0x4144, NULL, "HCU DstDMA Size", NULL },

  { NULL, 0, NULL, NULL, NULL } /* NULL terminator */
}; 
#endif /* SVEN_INTERNAL_BUILD */

static const struct SVEN_Module_EventSpecific g_gen3_sec_specific_events[] =
  {
    { NULL, 0, NULL, NULL }
  };

static const struct ModuleReverseDefs g_sec_sven_module = {	
  "GEN3_SEC",
  SVEN_module_GEN3_SEC,
  32*1024,
#ifdef SVEN_INTERNAL_BUILD
  g_gen3_csr_sec,
#else
  NULL,
#endif
  "SEC: SVEN Function (VR)",   /* TODO: Get a better text string */
  g_gen3_sec_specific_events,  /* TODO-Later: Define important events specific to my module */
  NULL /* extension list */
}; 

#endif // SEC_SVEN_H
