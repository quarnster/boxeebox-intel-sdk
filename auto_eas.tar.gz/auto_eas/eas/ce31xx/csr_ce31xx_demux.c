/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_unit.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */
/* Simplest Possible example of EAS definition */
/* ---------------------------------------------------------------- */
/* ---------------------------------------------------------------- */

/* Declare the bit-breakout for the register defined in the EAS_Register defs below.
 * Keep this table (static) so it is not visible outside of this module.
 * The only publicly visible pointer should be g_csr_GEN3_TSD_versions.
 */

static const struct EAS_RegBits g_csr_GEN3_TSD_CRYPTO_CONTROL[] =
{
    { "RESERVED_31_5",          5,  27,"",NULL},    /* reserved bits [32..5] in this register */
    { "Conformance_mode_select",     4,  1,"",NULL},/*0=DVB 2.0 ; 1= Conformance(DVB 1.2) */
    { "ACTIVE_KEY_TYPE",           0,  4,"",NULL}, /* 0 none;1 Single DES; 2 Double DES;3 Triple DES;4 DVB */

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN3_TSD_CRYPTO_STATUS[] =
{
    { "RESERVED_31_4",          4,  28,"",NULL},    /* reserved bits [31..4] in this register */
    { "Back_Door_Key_Busy",     3,  1,"",NULL},
    { "Output_Ready",               2,  1,"",NULL},
    { "Input_Ready",                1,  1,"",NULL},
    { "Busy",                       0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_GEN3_TSD_CRYPTO_IRQ[] =
{
    { "RESERVED_31_3",          3,  29,"",NULL},    /* reserved bits [31..3] in this register */
    { "Invalid_Key_IRQ",                2,  1,"",NULL},
    { "Output_Ready_IRQ",                1,  1,"",NULL},
    { "Input_Ready_IRQ",                 0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN3_TSD_CRYPTO_IRQ_MASK[] =
{
    { "RESERVED_31_3",          3,  29,"",NULL},    /* reserved bits [31..3] in this register */
    { "Invalid_Key_IRQ_MASK",                2,  1,"",NULL},
    { "Output_Ready_IRQ_MASK",                1,  1,"",NULL},
    { "Input_Ready_IRQ_MASK",                 0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN3_TSD_CRYPTO_ALG[] =
{
    { "RESERVED_31_5",          5,  27,"",NULL},    /* reserved bits [31..5] in this register */
    { "Default_Crypto_Algorithm",                 0,  5,"",NULL},
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN3_TSD_KEY_ADDR[] =
{
    { "RESERVED_31_8",          8,  24,"",NULL},    /* reserved bits [31..8] in this register */
    { "BackDoor_Key_Address",                 0,  8,"",NULL},
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN3_TSD_CRC_CONTROL[] =
{
    { "RESERVED_31_2",          2,  30,"",NULL},    /* reserved bits [32..4] in this register */
    { "BIT_DIRECTION",          1,  1,"",NULL},
    { "CRC_ENABLE",             0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN3_TSD_CRC_STATUS[] =
{
    { "RESERVED_31_1",          1,  31,"",NULL},    /* reserved bits [32..1] in this register */
    { "CRC_Error",              0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN3_TSD_PM_CONTROL[] =
{
    { "RESERVED_31_5",          5,  27,"",NULL},    /* reserved bits [32..4] in this register */
    { "MULTI_MATCH_ENABLE",      4,  1,"",NULL},
    { "COMBO_MATCH_ENABLE",      3,  1,"",NULL},
    { "MASK_MATCH_ENABLE",     2,  1,"",NULL},
    { "DIFF_MATCH_ENABLE",     1,  1,"",NULL},
    { "EXACT_MATCH_ENABLE",     0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN3_TSD_PM_STATUS[] =
{
    { "RESERVED_31_16",          16,  16,"",NULL},    /* reserved bits [32..16] in this register */
    { "MULTI_MATCH_OVERFLOW",     15,  1,"",NULL},
    { "RESERVED_14", 14,  1,"",NULL},    /* reserved bits [14] in this register */
    { "MULTI_MATCH_COUNTER",      8,  6,"",NULL},
    { "RESERVED_7_4",   4,  4,"",NULL},    /* reserved bits [7..4] in this register */
    { "COMBO_MATCH",      3,  1,"",NULL},
    { "MASK_MATCH",     2,  1,"",NULL},
    { "DIFF_MATCH",     1,  1,"",NULL},
    { "EXACT_MATCH",     0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_GEN3_TSD_PM_IRQ[] =
{
    { "RESERVED_31_5",          5,  27,"",NULL},    /* reserved bits [32..5] in this register */
    { "MULTI_MATCH_IRQ",      4,  1,"",NULL},
    { "COMBO_MATCH_IRQ",      3,  1,"",NULL},
    { "MASK_MATCH_IRQ",     2,  1,"",NULL},
    { "DIFF_MATCH_IRQ",     1,  1,"",NULL},
    { "EXACT_MATCH_IRQ",     0,  1,"",NULL},
    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_GEN3_TSD_PM_IRQ_MASK[] =
{
    { "RESERVED_31_4",          4,  28,"",NULL},    /* reserved bits [32..4] in this register */
    { "COMBO_MATCH_IRQ_MASK",      3,  1,"",NULL},
    { "MASK_MATCH_IRQ_MASK",      2,  1,"",NULL},
    { "DIFF_MATCH_IRQ_MASK",     1,  1,"",NULL},
    { "EXACT_MATCH_IRQ_MASK",     0,  1,"",NULL},
  { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN3_TSD_PM_MASK_CLEAR[] =
{
    { "RESERVED_31_8",          8,  24,"",NULL},    /* reserved bits [32..8] in this register */
    { "Clears_MASK_47",      4,  4,"",NULL},
    { "Clears_MASK_03",     0,  4,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_GEN3_TSD_IO_CONTROL[] =
{
    { "RESERVED_31_5",         5,  27,"",NULL},    /* reserved bits [32..5] in this register */
    { "DMEM_Mode",             4,  1,"",NULL},
    { "Send_Remaining",             3,  1,"",NULL},
    { "Send_Enable",                2,  1,"",NULL},
    { "Fetch_Enable",               1,  1,"",NULL},
    { "Input_Flush",                0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};
static const struct EAS_RegBits g_csr_GEN3_TSD_IO_OUTPUT_SND_THRES[] =
{
    { "RESERVED_31_4",          8,  24,"",NULL},    /* reserved bits [32..8] in this register */
    { "Threshold_Mask",           2,  6,"",NULL},
    { "Hardwired",                0,  2,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_GEN3_TSD_IO_INPUT_FETCH_THRES[] =
{
    { "RESERVED_31_4",          8,  24,"",NULL},    /* reserved bits [32..8] in this register */
    { "Threshold_Mask",           2,  6,"",NULL},
    { "Hardwired",                0,  2,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};


static const struct EAS_RegBits g_csr_GEN3_TSD_IO_STATUS[] =
{
    { "RESERVED_31_4",          4,  28,"",NULL},    /* reserved bits [32..4] in this register */
    { "Send_Remaining_Busy",        3,  1,"",NULL},
    { "Out_FIFO_Emtpy",             2,  1,"",NULL},
    { "Shift_Busy",             1,  1,"",NULL},
    { "Input_Flush_Busy",       0,  1,"",NULL},

    { NULL,0,0,NULL,NULL }    /* NULL terminator */
};

static const struct EAS_Register g_csr_GEN3_TSD[] =
{
    /* Crypto Engine Unit registers */
    { "CRYPTO_CONTROL", 0x0000, g_csr_GEN3_TSD_CRYPTO_CONTROL,    "Crypto Control Register",NULL },
    { "CRYPTO_STATUS",  0x0004, g_csr_GEN3_TSD_CRYPTO_STATUS,  "Crypto Status Register",NULL },
   { "CRYPTO_IRQ",   0x0008, g_csr_GEN3_TSD_CRYPTO_IRQ,  "Crypto IRQ Register", NULL, },
   { "CRYPTO_IRQ_MASK",0x000C,g_csr_GEN3_TSD_CRYPTO_IRQ_MASK,  "Crypto IRQ_MASK Register", NULL, },
   { "CRYPTO_IV_0",  0x0010,     NULL, "Least significant word", NULL, },
   { "CRYPTO_IV_1",  0x0014,  NULL, "Most significant word", NULL,},
   { "CRYPTO_KEY_0", 0x0018,  NULL, "Least significant word of crypto key" ,  NULL, },
   { "CRYPTO_KEY_1", 0x001c, NULL,"Middle signifiacnt word",NULL, },
   { "CRYPTO_KEY_2", 0x0020, NULL,"Middle signifiacnt word",NULL,},
   { "CRYPTO_KEY_3", 0x0024, NULL,"Middle signifiacnt word",NULL, },
   { "CRYPTO_KEY_4", 0x0028, NULL,"Middle signifiacnt word",NULL, },
   { "CRYPTO_KEY_5", 0x002c, NULL,"Most signifiacnt word",NULL, },
   { "CRYPTO_RESERVED0", 0x0030, NULL, "Reserved", NULL, },
   { "CRYPTO_ALGORITHM", 0x003C, g_csr_GEN3_TSD_CRYPTO_ALG,"Algorithm",NULL, },
   { "CRYPTO_DATAOUT_0", 0x0040, NULL, "LSB of the result of a crypto operation OUTPUT_READY status flag is asserted",NULL, },
   { "CRYPTO_DATAOUT_1", 0x0044, NULL, "MSB of result of crypto operation_OUTPUT_READY FLAG ASSERTED",NULL,},
   { "KEY_ADDR",  0x0048,g_csr_GEN3_TSD_KEY_ADDR, "Selects the current back-door crypto key", NULL, },
   { "CRYPTO_RESERVED1", 0x004c, NULL, "Reserved", NULL, },
   { "CRYPTO_SKEY_0", 0x0060, NULL, "Least significant word of Multi-2 System key"  ,  NULL, },
   { "CRYPTO_SKEY_1", 0x0064, NULL,"Middle signifiacnt word",NULL,},
   { "CRYPTO_SKEY_2", 0x0068, NULL,"Middle signifiacnt word",NULL, },
        { "CRYPTO_SKEY_3", 0x006c, NULL,"Middle signifiacnt word",NULL, },
        { "CRYPTO_SKEY_4", 0x0070, NULL,"Middle signifiacnt word",NULL, },
        { "CRYPTO_SKEY_5", 0x0074, NULL,"Middle signifiacnt word",NULL, },
        { "CRYPTO_SKEY_6", 0x0078, NULL,"Middle signifiacnt word",NULL, },
        { "CRYPTO_SKEY_7", 0x007c, NULL,"Most signifiacnt word",NULL, },
        { "CRYPTO_RESERVED2", 0x0080, NULL, "Reserved", NULL, },

    /* Data Shift Register Unit registers */
    { "DSR_CONTROL", 0x0800,  NULL, "Data Shift Control Register",NULL },
   { "DSR_STATUS",  0x0804,   NULL,    "Data Shift Register",NULL },
   { "DSR_IRQ",   0x0808,     NULL, "Data Shift IRQ Register", NULL, },
   { "DSR_IRQ_MASK",0x080C,   NULL, "Data shiftIRQ_MASK Register", NULL, },
    { "DSR_DATA_03", 0x0810, NULL, "Data Shift Data_03 Register",NULL},
    { "DSR_DATA_47", 0x0814, NULL, "Data Shift Data_47 Register",NULL},
    { "DSR_DATA_8B", 0x0818, NULL, "Data Shift Data_8B Register",NULL},
    { "DSR_DATA_CF", 0x081C, NULL, "Data Shift Data_CF Register",NULL},
    { "DSR_DATA_103", 0x0820, NULL, "Data Shift Data_103 Register",NULL},
    { "DSR_DATA_147", 0x0824, NULL, "Data Shift Data_147 Register",NULL},
    { "DSR_RESERVED", 0x0828, NULL, "Reserved", NULL, },

    /* CRC Checker Unit registers */
    { "CRC_CONTROL", 0x1000,  g_csr_GEN3_TSD_CRC_CONTROL, "CRC check control register",NULL },
    { "CRC_STATUS",     0x1004,  g_csr_GEN3_TSD_CRC_STATUS, "CRC check status register",NULL },
    { "CRC_IRQ",     0x1008,  NULL,             "CRC IRQ Register", NULL, },
   { "CRC_IRQ_MASK", 0x100C,  NULL, "CRCIRQ_MASK Register", NULL, },
    { "CRC_ACCUMULATOR",0x1010, NULL,  "CRC accumulator register",NULL },
   { "CRC_RESERVED", 0x101C, NULL,  "Reserved", NULL, },

    /* Pattern Matcher Unit registers */
    { "PM_CONTROL",   0x1800,g_csr_GEN3_TSD_PM_CONTROL,  "Pattern Matcher Unit Control",NULL},
    { "PM_STATUS",    0x1804,g_csr_GEN3_TSD_PM_STATUS,   "Pattern Matcher Unit Status",NULL},
    { "PM_IRQ",       0x1808,g_csr_GEN3_TSD_PM_IRQ,   "Pattern Matcher IRQ Register", NULL, },
   { "PM_IRQ_MASK",0x180C, g_csr_GEN3_TSD_PM_IRQ_MASK,   "Pattern Matcher IRQ_MASK Register", NULL, },
    { "PM_MASK_03", 0x1810,   NULL,    "Pattern Matcher Unit Mask03",NULL},
    { "PM_MASK_47", 0x1814,   NULL,    "Pattern Matcher Unit Mask47",NULL},
    { "PM_RESERVED0", 0x1818,    NULL, "Reserved", NULL, },
    { "PM_MATCH_03",0x1820,   NULL,    "Pattern Matcher Unit Match03",NULL},
    { "PM_MATCH_47",0x1824,   NULL,    "Pattern Matcher Unit Match03",NULL},
    { "PM_POLARITY_03",0x1828,   NULL,    "Pattern Matcher Unit POLARITY03",NULL},
    { "PM_POLARITY_47",0x182c,   NULL,    "Pattern Matcher Unit POLARITY03",NULL},
   { "PM_MASK_CLEAR",0x1830,g_csr_GEN3_TSD_PM_MASK_CLEAR,"Selectively clears bytes in the MATCH_* registers.", NULL, },
   { "PM_RESERVED",0x0834,    NULL,    "Reserved", NULL, },
    { "PM_MULTIMATCH_0",0x1840,  NULL,    "Bype locations of match 0 in multi matcher mode",NULL},
    { "PM_MULTIMATCH_1",0x1844,         NULL,   "Bype locations of match 1 in multi matcher mode",NULL},
    { "PM_MULTIMATCH_2",0x1848,         NULL,   "Bype locations of match 2 in multi matcher mode",NULL},
    { "PM_MULTIMATCH_3",0x184c,         NULL,   "Bype locations of match 3 in multi matcher mode",NULL},
    { "PM_MULTIMATCH_4",0x1850,         NULL,   "Bype locations of match 4 in multi matcher mode",NULL},
    { "PM_MULTIMATCH_5",0x1854,         NULL,   "Bype locations of match 5 in multi matcher mode",NULL},
    { "PM_MULTIMATCH_6",0x1858,         NULL,   "Bype locations of match 6 in multi matcher mode",NULL},
    { "PM_MULTIMATCH_7",0x185c,         NULL,   "Bype locations of match 7 in multi matcher mode",NULL},
   { "PM_RESERVED1", 0x1860,  NULL, "RESERVED", NULL, },

    /* I/O Controller Unit registers */
    { "IO_CONTROL",  0x2000, g_csr_GEN3_TSD_IO_CONTROL, "I/O controller control Register",NULL },
    { "IO_STATUS",   0x2004, g_csr_GEN3_TSD_IO_STATUS, "I/O controller status Register",NULL },
    { "IO_IRQ",      0x2008, NULL,  "I/O Controller IRQ Register", NULL, },
   { "IO_IRQ_MASK",0x200C, NULL, "I/O Controller IRQ_MASK Register", NULL, },
    { "IO_INPUT_START_ADDR",0x2010, NULL,  "I/O controller input start address Register",NULL},
    { "IO_INPUT_CURR_ADDR",   0x2014, NULL,   "I/O controller input current address Register",NULL },
    { "IO_INPUT_SIZE",     0x2018, NULL,   "I/O controller input size Register",NULL },
    { "IO_RESERVED0",      0x201C, NULL,   "IO_RESERVED",NULL, },
   { "IO_BYTES_SHIFTED_IN",0x2020, NULL,  "The value in this register is incremented by one each time a new byte is shifted into the DSR.", NULL, },
   { "IO_INPUT_FIFO_LEVEL",0x2024,  NULL, "The number of bytes currently available in the input FIFO for shifting into the DSR. ", NULL, },
    { "IO_OUTPUT_START_ADDR", 0x2028, NULL,   "I/O controller output start address Register",NULL },
    { "IO_OUTPUT_CURR_ADDR",  0x202C, NULL,   "I/O controller output current address Register",NULL },
    { "IO_OUTPUT_SIZE",       0x2030, NULL,   "I/O controller output size Register",NULL },
    { "IO_OUTPUT_SEND_THRESHOLD",0x2038,g_csr_GEN3_TSD_IO_OUTPUT_SND_THRES,    "Indicates a watermark for creating an xsi request to send out more stream data. ", NULL, },
   { "IO_INPUT_FETCH_THRESHOLD",0x203C,g_csr_GEN3_TSD_IO_INPUT_FETCH_THRES,   "Indicates a watermark for creating an xsi request to read in more stream data. ", NULL, },
   { "IO_OUTPUT_FIFO_LEVEL",0x2040, NULL, "The number of bytes currently available in the output FIFO for shifting into the DSR. ", NULL, },
    { "DMEM_INPUT_ADDR",0x2044, NULL,   "Address where data will be taken from DMEM to be placed into the register for shifting",NULL},
    { "DMEM_OUTPUT_ADDR",0x2048, NULL,  "Address where data will be written into DMEM from the register that buffers the data being shifted out",NULL},
   { "IO_RESERVED1", 0x204c, NULL,  "Reserved",                      NULL, },

   /* "Host Interface" Unit registers */
   { "HOST_CONTROL", 0x2800,  NULL, "Host Interface control Register",  NULL, },
   { "HOST_STATUS",  0x2804,  NULL, "Host Interface status Register",   NULL, },
   { "HOST_IRQ",     0x2808,  NULL, "Contains the IPC Doorbell IRQs.  They are cleared by writing a 1.", NULL, },
   { "HOST_IRQ_MASK",   0x280C,  NULL, "indicates the correlated IRQ signal from the IRQ register is masked.", NULL, },
   { "HOST_IPC_STATUS",0x2810,   NULL, "Contains the Ready and Done IPC flags for each of the processors.", NULL, },
   { "HOST_IPC_DOORBELL",  0x2814,  NULL,"Command mailbox for communicating with the host processor from the RISC controller.", NULL, },
   { "RISC_IPC_DOORBELL",  0x2818,  NULL,"Command mailbox for communicating with the RISC controller from the host processor.", NULL, },
   { "ICACHE_BASE_ADDRESS",0x281C,NULL,"Indicates the base address of the firmware image in the XSI memory space. ", NULL, },
   { "ICACHE_INVALIDATE_0",0x2820,  NULL,"Each bit in this register corresponds to a cache line in the RISC instruction cache. ", NULL, },
   { "ICACHE_INVALIDATE_1",0x2824,  NULL,"Each bit in this register corresponds to a cache line in the RISC instruction cache.", NULL, },
   { "ICACHE_INVALIDATE_2",0x2828,  NULL,"Each bit in this register corresponds to a cache line in the RISC instruction cache.", NULL, },
   { "ICACHE_INVALIDATE_3",0x282C,  NULL,"Each bit in this register corresponds to a cache line in the RISC instruction cache. ", NULL, },

   { "OMAR_MUX_SEL", 0x2830,  NULL, "Selects which set of debug signals get passed out the demux to the OMAR unit", NULL, },
   { "LDST_X", 0x2834,  NULL, "Endian control and byte count for LdSt operations", NULL, },
   { "HOST_RESERVED",      0x2838,  NULL,"Reserved 2", NULL, },

   /* "Host Coprocessor Control (debug mode) */
   { "Coproc_Interface_Opcode",  0x3000,  NULL,"The opcode written to this register is passed on to the coprocessor via the coprocessor interface ", NULL, },
   { "Coproc_Interface_Data",    0x3004,  NULL,"Data written to this register is passed on to the coprocessor via the coprocessor ", NULL, },
   { "Coproc_Interface_Aux",     0x3008, NULL,"Auxillary Interface", NULL },
    { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */



static const struct SVEN_Module_EventSpecific g_GEN3_TSD_specific_events[] =
{
   {"DTS_BUFFER",                  1, " Stream ID: 0x%06x, buffer %d, original 0x%x%.8x", NULL },
   { "IN_PORT_EMPTY",              2, " Stream ID: 0x%06x, port %d is empty", NULL },
   { "IN_BUFFERS_FULL",            4, " stream %d input to fw is full", NULL },
   { "OUT_PORT_FULL",              6, " PID %d, port %d for stream %d, filter %d is full", NULL },
   { "OUT_ENQUEUE",                7, " Stream ID: 0x%06x Port: %d, Buffer: %d, New Depth: %d PTS/2: 0x%08x Max Depth: %d", NULL},

   {"GET_PENDING_INTERRUPT",       10, " Interrupt source: 0x%08X", NULL },
   {"GET_BOOT_STATUS",             11, " BOOT!, ret = 0x%08X", NULL },
   {"GET_IPC_STATUS",              12, " IPC!, ret = 0x%08X", NULL },

   {"FW_STREAM_EMPTY",             14, " Stream ID 0x%06x Stream EMPTY!", NULL },
   {"FW_FILTER_NODE_DONE",         15, " Stream ID 0x%06x Filter NODE DONE!", NULL },
   {"FW_FILTER_FULL",              16, " Stream ID 0x%06x Filter FULL!", NULL },

   {"IPC_CMD_ID",                  17, "IPC cmd_id : 0x%x", NULL },
   {"IPC_SYNC_MODE",               18, "IPC synchronous mode on %d", NULL },
   {"IPC_CMD_ARGS",                19, "IPC command args bytes %d to %d: %.8x %.8x %.8x %.8x", NULL },

   {"OUT_BUFFER_SHRINK",           20, " Stream ID: 0x%06x, Out buffer pool shrinking! ismd_buffer_alloc() returned %d", NULL },
   {"OUT_BUFFER_ALLOCATED",        21, " Stream ID: 0x%06x, Allocated buffer %d for filter %d", NULL },
   {"OUT_BUFFER_DROPPED",          22, " Stream ID: 0x%06x, Dropping empty buffer %d", NULL }, // only in ver2

   {"DISCONTINUITY_FROM_FW",       24, " pcrs: old 0x%x%.8x new 0x%x%.8x avg 0x%x cnt %d", NULL },
   {"PTS_BUFFER",                  30, " Stream ID: 0x%06x, buffer %d, local 0x%x%.8x original 0x%x%.8x", NULL },

   // section filter events not logged in ver3 as filtering moved to FW
   {"SECTION_INVALID",             31, " Stream ID: 0x%06x, section incomplete? %d too big? %d", NULL },
   {"SECTION_BAD_CRC",             32, " Stream ID: 0x%06x, section filter %d len %u", NULL },
   {"SECTION_NO_MATCH",            33, " Stream ID: 0x%06x, section filter %d tid? %d pos. match? %d neg. match? %d", NULL },
   {"SECTION_MATCH",               34, " Stream ID: 0x%06x, section filter %d", NULL },

   {"FLUSH_START",                 35, " Stream ID: 0x%06x, In Port: %d, In Size: %d, Out ID: %d, Out Size: %d", NULL },
   {"FLUSH_COMPLETE",              36, " Stream ID: 0x%06x, In Port: %d, In Size: %d, Out ID: %d, Out Size: %d", NULL },
   {"NEW_SEG_OUT",                 38, " Stream ID: 0x%06x Port ID: %d Start/2: 0x%08x Stop/2: 0x%08x linear_start/2: 0x%08x req_rate: %d", NULL },
   {"NEW_SEG_IN",                  39, " Stream ID: 0x%06x Port ID: %d Start/2: 0x%08x Stop/2: 0x%08x linear_start/2: 0x%08x req_rate: %d", NULL },
   {"DISCONTINUITY_AT_INPUT",      40, " Stream ID: 0x%06x, discontinuity flag set on demux input buffer", NULL },
   {"DISCONTINUITY_AT_OUTPUT",     41, " Stream ID: 0x%06x, discontinuity flag set on demux original_pts = %x, local_pts = %x", NULL },
   {"ALLOC_FAIL_FOR_OUTPUT",       42, " Stream ID: 0x%06x, failed to add buffer to per stream output list, node count = %d", NULL },
   {"ALLOC_FAILURES",              43, " Stream ID: 0x%06x, Failed to allocate %d filter buffers failed and %d fw_output nodes", NULL },
   {"RELEASE_FAILED",              44, " Stream ID: 0x%06x, Failed to release nodes for filter %d, returned %d", NULL },
   {"IN_DEQUEUE",                  45, " Stream ID: 0x%06x, Port: %d, Buffer: %d, New Depth: %d, PTS/2: 0x%08x, Max Depth: %d", NULL },
   {"CONTENT_TIME_GAP",            46, " Stream ID: 0x%06x, PTS: 0x%x%08x", NULL },
   {"OPEN",                        47, " Stream ID: 0x%06x, In Port ID: %d, Out Port ID: %d, format: %d, out_buf_size: %d", NULL },
   {"CLOSE",                       48, " Stream ID: 0x%06x", NULL },
   {"OVER_FLOW",                   49, " Stream ID: 0x%06x, Port ID: %d, Buffer ID: %d", NULL },
   {"STATE_CHANGE",                50, " Stream ID: 0x%06x, Old State:~ %d, New Sate: %d", NULL },

   // Only in new demux (v3)
   {"IPC_ACK_INTR",                51, " Stream ID: 0x%06x", NULL },
   {"IPC_ERROR_CODE",              52, " Stream ID: 0x%06x, line number: %d, cmd %d ismd result %d", NULL },
   {"INIT_START",                  53, " Driver initialization started", NULL },
   {"INIT_SUCCESSFUL",             54, " Driver initialization successful", NULL },
   {"INIT_FAIL",                   55, " Driver initialization FAILURE - code %d", NULL },
   {"DEINIT_START",                56, " Driver deinitialization started", NULL },
   {"DEINIT_COMPLETE",             57, " Driver deinitialization complete", NULL },
   {"DEINIT_CLOSING_STREAM",       58, " Driver deinitialization auto-closing stream %d", NULL },
   {"CQ_INIT_SUCCESS",             59, " Circular Queue Init Success", NULL },
   {"MB_INIT_SUCCESS",             60, " Message Box Init Success", NULL },
   {"CLIENT_ID_TAG_AT_INPUT",      61, " Stream ID: 0x%06x, Port ID: %d, tag %d", NULL },
   {"CLIENT_ID_OUT",               62, " Stream ID: 0x%06x, filter id %d, port %d, buf %d, client ID %d", NULL },
   {"TTM_PTS_RECEIVED",            63, " Stream ID: 0x%06x, PTS 0x%X%08X, prev PTS 0x%X%08X", NULL },
   {"TTM_PTS_PCR_DELTA",           64, " Stream ID: 0x%06x, PTS 0x%X%08X, prev PCR 0x%X%08X", NULL },
   {"TTM_PCR_RECEIVED",            65, " Stream ID: 0x%06x, PCR 0x%X%08X, prev PCR 0x%X%08X", NULL },
   {"TTM_DISCON_RECEIVED",         66, " Stream ID: 0x%06x", NULL },
   {"TTM_NS_RECEIVED1",            67, " Stream ID: 0x%06x, start 0x%X%08X stop 0x%X%08X, segment_pos(32-0) 0x%08X", NULL },
   {"TTM_NS_RECEIVED2",            68, " Stream ID: 0x%06x, lin_start 0x%X%08X rate_valid %d req_rate %d app_rate %d", NULL },
   {"TTM_NS_PROCESSED1",           69, " Stream ID: 0x%06x, start 0x%X%08X stop 0x%X%08X, segment_pos(32-0) 0x%08X", NULL },
   {"TTM_NS_PROCESSED2",           70, " Stream ID: 0x%06x, lin_start 0x%X%08X rate_valid %d req_rate %d app_rate %d", NULL },
   {"TTM_COMMIT",                  71, " Stream ID: 0x%06x", NULL },
   {"TTM_DECOMMIT",                72, " Stream ID: 0x%06x", NULL },
   {"FW_STATS1",                   73, " stack bytes used %d, stack bytes free %d", NULL },
   {"FW_EBQ_EMPTY",                74, " Stream ID: 0x%06x, EBQ %d (buffer size %d) is empty", NULL },
   {"BUFFERING_EVENT",             75, " Stream ID: 0x%06x, pcr/2: 0x%08x, linear_pts: 0x%x%.8x, buffer_time: 0x%x%.8x", NULL },
   {"INDEXING_FROM_FW",            76, " Stream ID: 0x%06x, index data: 0x%08x  0x%08x 0x%08x 0x%08x", NULL },
   {"INDEXING_CONVERTED",          77, " Stream ID: 0x%06x, index data: 0x%08x  0x%08x 0x%08x 0x%08x", NULL },
   {"POWER_MODE_SET",              78, " Power Mode Set: Line number: %d Data: 0x%08x 0x%08x 0x%08x 0x%08x 0x%08x ", NULL },
   {"POWER_MODE_FAIL",             79, " Power Mode Fail: Line number: %d Data: 0x%08x 0x%08x 0x%08x 0x%08x 0x%08x ", NULL },

   {"GET_TIME_FAIL",               100, " Stream ID: 0x%06x, line number: %d, clock: %d, result: %d", NULL },
   {"SCHED_ALARM_FAIL",            101, " Stream ID: 0x%06x, line number: %d, clock: %d, result: %d", NULL },
   {"CANCEL_ALARM_FAIL",           102, " Stream ID: 0x%06x, line number: %d, clock: %d, alarm: %d, result: %d", NULL },
   {"EVENT_ALLOC_FAIL",            103, " Stream ID: 0x%06x, line number: %d, result: %d", NULL },
   {"EVENT_FREE_FAIL",             104, " Stream ID: 0x%06x, line number: %d, event: %d, result: %d", NULL },
   {"EVENT_WAIT_FAIL",             105, " Stream ID: 0x%06x, line number: %d, event: %d, result: %d", NULL },
   {"EVENT_SET_FAIL",              106, " Stream ID: 0x%06x, line number: %d, event: %d, result: %d", NULL },
   {"EVENT_STROBE_FAIL",           107, " Stream ID: 0x%06x, line number: %d, event: %d, result: %d", NULL },
   {"EVENT_ACK_FAIL",              108, " Stream ID: 0x%06x, line number: %d, event: %d, result: %d", NULL },
   {"THREAD_CREATE_FAIL",          109, " Stream ID: 0x%06x, line number: %d, result: %d", NULL },
   {"THREAD_WAIT_FAIL",            110, " Stream ID: 0x%06x, line number: %d, result: %d", NULL },
   {"THREAD_DESTROY_FAIL",         111, " Stream ID: 0x%06x, line number: %d, result: %d", NULL },
   {"SEMA_INIT_FAIL",              112, " Stream ID: 0x%06x, line number: %d, result: %d", NULL },
   {"INTERRUPT_ACQUIRE_FAIL",      113, " line number: %d", NULL },
   {"MALLOC_FAIL",                 114, " line number: %d", NULL },
   {"MB_INIT_FAIL",                115, " line number: %d, result %d", NULL },
   {"MB_FREE_FAIL",                116, " line number: %d, mb_handle: %d, result %d", NULL },
   {"MB_WRITE_FAIL",               117, " Stream ID: 0x%06x, line number: %d, mb_handle: %d, result %d", NULL },
   {"MB_WAKE_FAIL",                118, " Stream ID: 0x%06x, line number: %d, mb_handle: %d, result %d", NULL },
   {"CQ_INIT_FAIL",                119, " line number: %d, result %d", NULL },
   {"CLOCK_ALLOC_FAIL",            120, " Stream ID: 0x%06x, line number: %d, result: %d", NULL },
   {"BUFFER_ALLOC_FAIL",           121, " Stream ID: 0x%06x, line number: %d, result: %d", NULL },
   {"BUFFER_READ_DESC_FAIL",       122, " Stream ID: 0x%06x, line number: %d, buffer handle 0x%x, result: %d", NULL },
   {"BUFFER_FREE_FAIL",            123, " Stream ID: 0x%06x, line number: %d, buffer handle 0x%x, result: %d", NULL },
   {"CLOCK_FREE_FAIL",             124, " Stream ID: 0x%06x, line number: %d, clock 0x%x, result: %d", NULL },
   {"SECURE_LOAD_FAIL",            125, " Could not use secure FW load, result: %d", NULL },
   {"MEMORY_MAPPING_FAIL",         126, " Could not map memory", NULL },
   {"FW_BOOT_FAIL",                127, " result: %d", NULL },
   {"FW_BIST_FAIL",                128, " result: %d", NULL },
   {"CQ_CREATE_FAIL",              129, " Stream ID: 0x%06x, line number: %d, cq_ret %d", NULL },
   {"PORT_ALLOC_FAIL",             130, " Stream ID: 0x%06x, line number: %d, result %d", NULL },
   {"CQ_DELETE_FAIL",              130, " Stream ID: 0x%06x, line number: %d, cq_id %d, cq_ret %d", NULL },
   {"CQ_READ_FAIL",                132, " Stream ID: 0x%06x, line number: %d, cq_id %d, cq_ret %d", NULL },
   {"PORT_FREE_FAIL",              133, " Stream ID: 0x%06x, line number: %d port handle %d result %d", NULL },
   {"ALLOCATOR_FREE_FAILED",       134, " Probably something leaked as a result", NULL },
   {"CQ_CREATE_FAILURE",           135, " Circular Queue: Create Q Failed", NULL },
   {"CQ_DELETE_QUEUE",             136, " Circular Queue: Q Deleted, ID: %d", NULL },
   {"CQ_NONE_AVAILABLE",           137, " Circular Queue: No Descriptors Available", NULL },
   {"PORT_GET_STATUS_FAIL",        138, " Stream ID: 0x%06x, line number: %d port handle %d result %d", NULL },
   {"PORT_FLUSH_FAIL",             139, " Stream ID: 0x%06x, line number: %d port handle %d result %d", NULL },
   {"PORT_SET_NAME_FAIL",          140, " Stream ID: 0x%06x, line number: %d port handle %d result %d", NULL },
   {"PORT_LOOKAHEAD_FAIL",         141, " Stream ID: 0x%06x, line number: %d port handle %d position %d result %d", NULL },
   {"PORT_READ_FAIL",              142, " Stream ID: 0x%06x, line number: %d port handle %d result %d", NULL },
   {"CQ_WRITE_FAIL",               143, " Stream ID: 0x%06x, line number: %d, cq_id %d, cq_ret %d", NULL },
   {"TAG_COPY_FAIL",               144, " Stream ID: 0x%06x, line number: %d, from_buf %d to_buf %d result %d", NULL },
   {"MB_CREATE_FAIL",              145, " Message Box: Create Failed, line_number: %d, result %d", NULL },
   {"PORT_WRITE_FAIL",             146, " Stream ID: 0x%06x, line number: %d port handle %d result %d", NULL },
   {"BUFFER_ADD_REF_FAIL",         147, " Stream ID: 0x%06x, line number: %d, buffer handle 0x%x, result: %d", NULL },
   {"CLOCK_ROUTE_FAIL",            148, " Stream ID: 0x%06x, line number: %d, clock %d, destination %d, result: %d", NULL },
   {"OUT_LIST_ERROR",              149, " Stream ID: 0x%06x, line number: %d, ebq_num %d buffer 0x%x ref count %d", NULL },
   {"HIGH_LATENCY",                150, " line number: %d, High IRQ latency impacting with host->FW IPC", NULL },
   {"EVENT_RESET_FAIL",            151, " Stream ID: 0x%06x, line number: %d, event: %d, result: %d", NULL },
   {"BUFFER_ALIAS_FAIL",           152, " Stream ID: 0x%06x, line number: %d, buffer handle 0x%x, result: %d", NULL },

   {"ERR_FROM_FW",                 200, " Error code 0x%08x", NULL },
   {"FEATURE_NOT_IMPLEMENTED",     201, " line number: %d", NULL },
   {"NO_DEMUX",                    202, " Cannot find demux device!", NULL },
   {"NULL_POINTER_SUPPLIED",       203, " Got NULL pointer from API!", NULL },
   {"CANNOT_ALLOC_STREAM",         204, " Unable to allocate new stream to use!", NULL },
   {"CANNOT_ALLOC_HANDLE",         205, " Unable to allocate dev handle from core! Stream ID: 0x%06x, line number: %d, result %d", NULL },
   {"CANNOT_ALLOC_FILTER",         206, " Stream ID: 0x%06x: Unable to allocate new filter to use!", NULL },
   {"CANNOT_ALLOC_PID",            207, " Stream ID: 0x%06x: Unable to allocate new PID %d to use!", NULL },
   {"INVALID_STREAM_HANDLE",       208, " handle %d", NULL },
   {"INVALID_FILTER_HANDLE",       209, " Stream ID: 0x%06x, handle %d", NULL },
   {"INVALID_PID",                 210, " Stream ID: 0x%06x, PID: %d", NULL },
   {"STREAM_NOT_IN_USE",           211, " Stream ID: 0x%06x, line number: %d", NULL },
   {"INVALID_STREAM_TYPE",         212, " Invalid stream type from API!", NULL },
   {"INVALID_OP_FORMAT",           214, " Invalid output format from API!", NULL },
   {"INVALID_PID_TYPE",            215, " Invalid PID type from API!", NULL },
   {"BAD_DEV_STATE",               216, " Stream ID: 0x%06x, state: %d", NULL },
   {"INVALID_Q_LEVEL",             217, " Stream ID: 0x%06x, line number: %d, queue space %d larger than depth %d!", NULL },
   {"NO_MORE_EBQS",                218, " Stream ID: 0x%06x, line number: %d", NULL },
   {"BUFFER_LEAK",                 219, " Stream ID: 0x%06x, line number: %d Unexpected error might cause %d buffers to be leaked", NULL },
   {"EBQ_STILL_REFFED",            220, " Stream ID: 0x%06x, line number: %d Killing queue that still has references!", NULL },
   {"NO_PID_MAPPING_SLOTS",        221, " Stream ID: 0x%06x: PID %d (index %d) doesn't have any open slots for filter index %d!", NULL },
   {"OUT_QUEUE_FULL",              222, " Stream ID: 0x%06x, line number: %d", NULL },
   {"DEL_PID_WITH_MAPPINGS",       223, " Stream ID: 0x%06x: Delete PID %d with filter %d mapped!", NULL },
   {"OUT_BUF_WITH_DATA_AND_TAGS",  224, " Stream ID: 0x%06x, filter id %d, port %d, buf %d", NULL },
   {"OUT_BUF_NO_DATA_AND_NO_TAGS", 225, " Stream ID: 0x%06x, filter id %d, port %d, buf %d", NULL },
   {"OUT_MISMATCH",                226, " internal output error: Stream ID: 0x%06x, filter ID: %d buffer %d filter enabled %d, filter stream %d", NULL },
   {"MANY_FILTERS_EBQ",            227, " Stream ID: 0x%06x, line number: %d, many filters using buffer size %d, may cause performance issue", NULL },
   {"NOT_SUPPORTED_ON_PS",         228, " Stream ID: 0x%06x, line number: %d, This feature not available on program streams", NULL },
   {"INVALID_SECTION_FILTER_HANDLE",229, " Stream ID: 0x%06x, handle %d", NULL },
   {"SF_OPEN_FILTER_NOT_PSI",      230, " Stream ID: 0x%06x, line number: %d, handle 0x%x, filter handle 0x%x", NULL },
   {"CANNOT_ALLOC_SECTION_FILTER", 231, " Stream ID: 0x%06x: Unable to allocate new section filter to use!", NULL },
   {"SET_STR_CLOCK_AFTER_PCR",     232, " Stream ID: 0x%06x, line number: %d - use arrival time mode will not work", NULL },
   {"UNSET_CLOCK_WITH_ARRIVAL_TIME", 233, " Stream ID: 0x%06x, line number: %d - use arrival time mode will not work", NULL },
   {"USE_ARRIVAL_TIME_NO_CLOCK",   234, " Stream ID: 0x%06x, line number: %d - use arrival time mode will not work", NULL },
   {"TTM_TIMING_ERROR",            235, " Stream ID: 0x%06x, line number: %d - stream timing error", NULL },
   {"TTM_CANNOT_READ_CLOCK",       236, " Stream ID: 0x%06x, line number: %d - stream clock error", NULL },
   {"INVALID_SF_PARAMS",           237, " Stream ID: 0x%06x", NULL },
   {"PID_MAPPING_DNE",             238, " Stream ID: 0x%06x, PID %d, filter index %d", NULL },
   {"TSI_FAIL",                    239, " Stream ID: 0x%06x, line number %d, result %d", NULL },
   {"TSI_ALREADY_IN_USE",          240, " TSI number %d", NULL },
   {"CLOCK_SYNC_OPEN_FAIL",        241, " Stream ID: 0x%06x, line number %d, result %d", NULL },
   {"CLOCK_SYNC_CLOSE_FAIL",       242, " Stream ID: 0x%06x, line number %d, clock sync %d, result %d", NULL },
   {"CLOCK_SYNC_SET_CLOCK_FAIL",   243, " Stream ID: 0x%06x, line number %d, clock sync %d, clock %d result %d", NULL },
   {"CLOCK_SYNC_SET_ALGORITHM_FAIL",244, " Stream ID: 0x%06x, line number %d, clock sync %d, algorithm %d, result %d", NULL },
   {"INVALID_TS_INTERFACE",        245, " Interface ID %d is not valid", NULL },
   {"TSI_NOT_PRESENT",             246, " Stream %d does not have a TSI - invalid request", NULL },
   {"TSI_INVALID_CIRCBUF_SIZE",    247, " Buffer size %d is not valid for TSI use", NULL },
   {"CLOCK_NOT_SET",               248, " Stream %d does not have a clock set - invalid request", NULL },
   {"INVALID_STAT_TYPE",           249, " handle %d, type %d, PID %d", NULL },
   {"UNSUPPORTED_CRYPTO_ALG",      250, " handle %d, PID %d, algorithm %d", NULL },
   {"UNSUPPORTED_RESIDUAL_ALG",    251, " handle %d, PID %d, residual_type %d", NULL },
   {"UNSUPPORTED_IV_LEN",          252, " handle %d, PID %d, iv_length %d", NULL },
   {"UNSUPPORTED_ODD_EVEN",        253, " handle %d, PID %d, odd_or_even %d", NULL },
   {"UNSUPPORTED_KEY_LEN",         254, " handle %d, PID %d, key_length %d", NULL },
   {"UNSUPPORTED_SYS_KEY_LEN",     255, " handle %d, PID %d, skey_len %d", NULL },
   {"NO_CRYPTO_ON_PSI_INDEXING",   256, " Stream ID: 0x%06x, line number: %d, handle %d, filter_handle %d", NULL },
   {"MUST_SET_CRYPTO_ALG_FIRST",   257, " Stream ID: 0x%06x, line number: %d, PID %d", NULL },
   {"MULTI2_NOT_SET",              258, " Stream ID: 0x%06x, Need to set crypto alg to MULTI2 before setting system key", NULL },
   {"NO_PID_OPERATIONS_INDEX",     259, " Stream ID: 0x%06x, line number: %d, filter handle 0x%x attempting PID mapping/unmapping on index filter!", NULL },
   {"NOT_INDEX_FILTER",            260, " Stream ID: 0x%06x, line number: %d, filter handle 0x%x not an index filter!", NULL },
   {"CANNOT_COUNT_PKTS_FMT",       261, " Stream ID: 0x%06x, line number: %d, filter index %d fmt %d cannot count packets!", NULL },
   {"CANNOT_COUNT_PKTS_TYPE",      262, " Stream ID: 0x%06x, line number: %d, filter handle 0x%x can't count packets!!", NULL },
   {"SET_SLAVE_CLOCK_AFTER_PCR",   263, " Stream ID: 0x%06x, line number: %d - Clock driving may be incorrect", NULL },
   {"ERROR_LOW_ATS_BITS_SET",      264, " Stream ID: 0x%06x, line number: %d - Bits value 0x%08x has bits other than the upper two set", NULL },
   {"ERROR_UNSUPPORTED_INDEXING_TYPE", 265, " Stream ID: 0x%06x, line number: %d PID %d - indexing type 0x%08x is not supported", NULL },
   {"INDEXING_PARADIGM_MIXING",    266, " Stream ID: 0x%06x, line number: %d cannot mix indexing API paradigms!  Old fmt %d new fmt %d", NULL },
   {"INDEXING_ERROR",              267, " Stream ID: 0x%06x, line number: %d  Unexpected error when processing indexing", NULL },
   {"UNKNOWN_SOC",                 268, " Unknown SOC. Using settings for latest known SOC", NULL },
   {"UNSUPPORTED_BYTE_ORDER",      269, " handle %d, PID %d, byte_order %d", NULL },
   {"UNSUPPORTED_KEY_DECODE_TYPE", 270, " handle %d, PID %d, key_decode %d", NULL },
   {"UNSUPPORTED_KEY_SRC",         271, " handle %d, PID %d, key_src %d", NULL },
   {"UNSUPPORTED_KEY_TYPE",        272, " handle %d, PID %d, key_type %d", NULL },
   {"NSK_TABLE_ROW_OUT_OF_RANGE",  273, " handle %d, PID %d, table_row %d", NULL },
   {"NSK_KEY_SEL_INVALID",         274, " handle %d, PID %d, nsk_key_select %d", NULL },
   {"NSK_SLOT_NUM_INVALID",        275, " handle %d, PID %d, nsk_slot_num %d", NULL },
   {"SEC_KEY_SELECT_OUT_OF_RANGE", 276, " handle %d, PID %d, key_sel_sec %d", NULL },
   {"UNSUPPORTED_KEY_LOAD_TYPE",   277, " handle %d, PID %d, load_type %d", NULL },
   {"OUT_LIST_INVALID_COUNT",      278, " stream_id 0x%06x, list size %d", NULL },
   {"OUT_LIST_INVALID_REF",        279, " stream_id 0x%06x, buffer index %d ref count %d", NULL },
   {"OUT_LIST_DUP_BUF",            280, " stream_id 0x%06x, buffer index %d", NULL },
   {"LIST_NOT_SUPPORTED_ON_IDX",   281, " Cannot use buffer lists on indexing filters (not supported)", NULL },
   {"CANNOT_CTRL_SPLITTING_THIS_TYPE",282, " Buffer splitting cannot be controlled for this filter type", NULL },
   {"CANNOT_ALLOC_CRYPTO_CTXT",    283, " Stream ID: 0x%06x: Unable to allocate new crypto context to use!", NULL },

   {"API_STREAM_OPEN",             400, " stream_type: %d, handle_ptr: 0x%08X, port_handle_ptr: 0x%08X", NULL },
   {"AUTOAPI_STREAM_CLOSE",        401, " handle %d", NULL },
   {"API_STREAM_CLOSE",            402, " handle %d", NULL },
   {"API_STREAM_SET_STATE",        403, " handle %d, state %d", NULL },
   {"API_STREAM_FLUSH",            404, " handle %d", NULL },
   {"API_STREAM_SET_CLOCK",        405, " handle %d, clock %d", NULL },
   {"API_USE_ARRIVAL_TIME",        406, " handle %d, value %d", NULL },
   {"API_SET_BUFFERING_EVENT",     407, " handle %d, event %d, time %d", NULL },
   {"API_FILTER_OPEN",             408, " stream handle %d, output format %d, output buf size %d, filter_handle_ptr 0x%x, port_handle_ptr 0x%x", NULL },
   {"API_FILTER_CLOSE",            409, " stream handle %d, filter handle 0x%x", NULL },
   {"API_FILTER_START",            410, " stream handle %d, filter handle 0x%x", NULL },
   {"API_FILTER_STOP",             411, " stream handle %d, filter handle 0x%x", NULL },
   {"API_FILTER_FLUSH",            412, " stream handle %d, filter handle 0x%x", NULL },
   {"API_FILTER_MAP_TO_PID",       413, " stream handle %d, filter handle 0x%x, PID %d, pid_type %d", NULL },
   {"API_FILTER_UNMAP_FROM_PID",   414, " stream handle %d, filter handle 0x%x, PID %d", NULL },
   {"API_FILTER_MAP_TO_PIDS",      415, " stream handle %d, filter handle 0x%x, list size %d first pid %d", NULL },
   {"API_FILTER_UNMAP_FROM_PIDS",  416, " stream handle %d, filter handle 0x%x, list size %d first pid %d", NULL },
   {"API_FILTER_GET_MAPPED_PIDS",  417, " stream handle %d, filter handle 0x%x, pid_list_ptr %d list_size_ptr %d", NULL },
   {"API_FILTER_MAP_TO_SID",       418, " stream handle %d, filter handle 0x%x, sid %d, ssid %d offset %d", NULL },
   {"API_FILTER_UNMAP_FROM_SID",   419, " stream handle %d, filter handle 0x%x, sid %d, ssid %d", NULL },
   {"API_FILTER_GET_MAPPED_SID",   420, " stream handle %d, filter handle 0x%x, sid_ptr %d, ssid_ptr %d", NULL },
   {"API_PID_START",               421, " stream handle %d, PID %d", NULL },
   {"API_PID_STOP",                422, " stream handle %d, PID %d", NULL },
   {"API_GET_INPUT_PORT",          423, " stream handle %d, port_ptr %d", NULL },
   {"API_GET_OUTPUT_PORT",         424, " stream handle %d, filter handle 0x%x, port_ptr %d", NULL },
   {"API_SECTION_FILTER_OPEN",     425, " stream handle %d, filter handle 0x%x, pid %d, handle_ptr 0x%x", NULL },
   {"API_SECTION_FILTER_CLOSE",    426, " stream handle %d, section filter handle 0x%x", NULL },
   {"API_SECTION_FILTER_SET_PARAMS",427, " stream handle %d, section filter handle 0x%x, sf params ptr 0x%x", NULL },
   {"API_SECTION_FILTER_START",    428, " stream handle %d, section filter handle 0x%x", NULL },
   {"API_SECTION_FILTER_STOP",     429, " stream handle %d, section filter handle 0x%x", NULL },
   {"API_SECTION_FILTER_START_BY_PID",430, " stream handle %d, PID %d", NULL },
   {"API_SECTION_FILTER_STOP_BY_PID",431, " stream handle %d, PID %d", NULL },
   {"API_EN_DISCON_DETECT",        432, " stream handle %d", NULL },
   {"API_DIS_DISCON_DETECT",       433, " stream handle %d", NULL },
   {"API_SET_PCR_PID",             434, " stream handle %d, PCR PID %d", NULL },
   {"API_TSIN_OPEN",               435, " interface %d, stream handle %d", NULL },
   {"API_TSIN_SET_OVERRUN_EVENT",  436, " stream handle %d, overrun event %d", NULL },
   {"API_STREAM_SET_BASE_TIME",    437, " stream handle %d, base time 0x%X%08X", NULL },
   {"API_TSIN_SET_NIM_CONFIG",     438, " stream handle %d, config pointer 0x%X", NULL },
   {"API_TSIN_GET_BUFFER_LEVEL",   439, " stream handle %d, size pointer 0x%X, level pointer 0x%X", NULL },
   {"API_TSIN_SET_BUFFER_SIZE",    440, " stream handle %d, buffer size %d", NULL },
   {"API_TSIN_ENABLE_CLOCK_RECOVERY",441, " stream handle %d, PCR PID %d", NULL },
   {"API_TSIN_DISABLE_CLOCK_RECOVERY",442, " stream handle %d", NULL },
   {"API_TSIN_GET_CLOCK",          443, " stream handle %d, clock pointer 0x%x", NULL },
   {"API_TSIN_GET_RECOVERY_CLOCK", 444, " stream handle %d, recovery clock pointer 0x%x", NULL },
   {"API_TSIN_SET_OPEN_CABLE_LTSID",445, " stream handle %d, ltsid %d", NULL },
   {"API_TSIN_GET_OPEN_CABLE_LTSID",446, " stream handle %d, ltsid pointer 0x%x", NULL },
   {"API_TSIN_SET_OPEN_CABLE_MODE",447, " stream handle %d, mode %d", NULL },
   {"API_TSIN_GET_OPEN_CABLE_MODE",448, " stream handle %d, mode pointer 0x%x", NULL },
   {"API_TSIN_ENABLE_INTERNAL_BYPASS",449, " Enabling OC bypass", NULL },
   {"API_TSIN_DISABLE_INTERNAL_BYPASS",450, " Disabling OC bypass", NULL },
   {"API_ADD_STREAM_ID_EXTENSION_TO_PID",451, " stream handle %d, filter handle 0x%x, pid %d, extension %d", NULL },
   {"API_REMOVE_STREAM_ID_EXTENSION_FROM_PID",452, " stream handle %d, filter handle 0x%x, pid %d", NULL },
   {"API_ENABLE_PES_PVT_DATA",     453, " stream handle %d, pid %d", NULL },
   {"API_DISABLE_PES_PVT_DATA",    454, " stream handle %d, pid %d", NULL },
   {"API_ENABLE_LEAKY_FILTERS",    455, " stream handle %d", NULL },
   {"API_DISABLE_LEAKY_FILTERS",   456, " stream handle %d", NULL },
   {"API_GET_STATS",               457, " stream handle %d, PID %d, stats ptr 0x%X", NULL },
   {"API_RESET_STAT",              458, " stream handle %d, type %d, PID %d", NULL },
   {"API_TS_LOAD_KEY1",            459, " stream handle %d, PID %d, algorithm %d, residual_type %d, odd_or_even %d, key_length %d", NULL },
   {"API_TS_LOAD_KEY2",            460, " key[0-2] 0x%x 0x%x 0x%x, iv_len %d, iv[0-1] 0x%x 0x%x", NULL },
   {"API_TS_SET_CRYPTO_PARAMS",    461, " stream handle %d, PID %d, algorithm %d, residual_type %d, iv_len %d, iv[0] 0x%x", NULL },
   {"API_TS_SET_SYSTEM_KEY",       462, " stream handle %d, skey_len %d, key[0-3] 0x%x 0x%x 0x%x 0x%x", NULL },
   {"API_TS_SET_KEY",              463, " stream handle %d, PID %d, odd_or_even %d, key_length %d, key[0-1] 0x%x 0x%x", NULL },
   {"API_FILTER_SET_TS_CRYPTO",    464, " stream handle %d, filter handle 0x%x, enable_descr %d", NULL },
   {"API_RESET_INDEX_COUNT",       465, " stream handle %d, filter handle 0x%x, reset value %u", NULL },
   {"API_SET_INDEXING_ON_PID",     466, " stream handle %d, PID %d, enable %d", NULL },
   {"API_SET_PKT_CNTG_FILTER",     467, " stream handle %d, filter handle 0x%x, enable %d", NULL },
   {"API_FILTER_OPEN_INDEXER",     468, " stream handle %d, filter handle 0x%x, index_flt_ptr 0x%x, port handle_ptr 0x%x", NULL },
   {"API_SET_DISCON_EVENT",        469, " stream handle %d, event %d", NULL },
   {"API_SET_SLAVE_CLOCK",         470, " handle %d, clock %d", NULL },
   {"API_GET_STREAM_POSITION",     471, " handle %d, position pointer 0x%x", NULL },
   {"API_TSIN_SET_TS192_UPPER_BITS",472, " handle %d, bits value 0x%x", NULL },
   {"API_INDEXING_CONFIGURE_PID",  473, " handle %d, PID %d, type 0x%x", NULL },
   {"API_INDEXING_REMOVE_PID",     474, " handle %d, PID %d", NULL },
   {"API_INDEXING_REMOVE_ALL_PIDS",476, " handle %d", NULL },
   {"API_FILTER_SET_OVERRUN_EVENT",477, " stream handle %d, filter handle 0x%x, event %d", NULL },
   {"API_FILTER_SET_OVERRUN_RECOVERED_EVENT",478, " stream handle %d, filter handle 0x%x, event %d", NULL },
   {"API_SECTION_FILTER_SET_CRC_EVENT",479, " handle %d, section filter handle 0x%x, event %d", NULL },
   {"API_DESCRAMBLE_SET_PARAMS",   480, " stream handle %d, PID %d, algorithm %d, residual_type %d, iv_len & iv_bytes_order 0x%x, iv[0] 0x%x", NULL},
   {"API_DESCRAMBLE_SET_KEY_DIRECT",481, " stream handle %d, PID %d, odd_or_even %d, key_length & key_byte_order 0x%x, key[0-1] 0x%x 0x%x", NULL},
   {"API_DESCRAMBLE_SET_KEY_INDIRECT",482, " stream handle %d, PID %d, key_src %d, key_type %d, key_select 0x%x", NULL},
   {"API_DESCRAMBLE_SET_SYSTEM_KEY",483, " stream handle %d, skey_len & skey_byte_order 0x%x, key[0-3] 0x%x 0x%x 0x%x 0x%x", NULL},
   {"API_FILTER_ENABLE_LEAKY",     484, " stream handle %d, filter handle 0x%x", NULL},
   {"API_FILTER_DISABLE_LEAKY",    485, " stream handle %d, filter handle 0x%x", NULL},
   {"API_FILTER_OPEN_PRESET_BUFFERS",486, " stream handle %d, fmt %d, num buffers %d, first buffer 0x%x, filter handle ptr 0x%x, port handle ptr 0x%x,", NULL},
   {"API_FILTER_DISABLE_BUFFER_SPLITTING",487, " stream handle %d, filter handle 0x%x", NULL},
   {"API_FILTER_ENABLE_BUFFER_SPLITTING",488, " stream handle %d, filter handle 0x%x", NULL},
   {"API_CRYPTO_CONTEXT_ALLOC",              489, " stream handle %d", NULL},
   {"API_CRYPTO_CONTEXT_FREE",               490, " stream handle %d, context ID %d", NULL},
   {"API_CRYPTO_CONTEXT_ASSIGN_TO_PID",      491, " stream handle %d, context ID %d, PID %d", NULL},
   {"API_CRYPTO_CONTEXT_UNASSIGN_FROM_PID",  492, " stream handle %d, PID %d", NULL},

   { "FW_RCV_IPC_CMD_SET_INPUT_STREAM",           512, "", NULL },
   { "FW_RCV_IPC_CMD_CONTROL_INPUT_STREAM",       513, "", NULL },
   { "FW_RCV_IPC_CMD_SET_FILTER",                 514, "", NULL },
   { "FW_RCV_IPC_CMD_CTRL_CRYPTO_ON_FILTER",      515, "", NULL },
   { "FW_RCV_IPC_CMD_ADD_PID",                    516, "", NULL },
   { "FW_RCV_IPC_CMD_ADD_FILTER_TO_PID",          517, "", NULL },
   { "FW_RCV_IPC_CMD_CONTROL_PID",                518, "", NULL },
   { "FW_RCV_IPC_CMD_CONTROL_FILTER",             519, "", NULL },
   { "FW_RCV_IPC_CMD_DELETE_PID",                 510, "", NULL },
   { "FW_RCV_IPC_CMD_DELETE_FILTER_FROM_PID",     521, "", NULL },
   { "FW_RCV_IPC_CMD_SET_FILTER_WPA",             522, "", NULL },
   { "FW_RCV_IPC_CMD_ADD_MM_FILTER",              523, "", NULL },
   { "FW_RCV_IPC_CMD_SET_CRYPTO_PARAMS",          524, "", NULL },
   { "FW_RCV_IPC_CMD_SET_CRYPTO_KEY",             525, "", NULL },
   { "FW_RCV_IPC_CMD_SET_STR_CRYPTO_INFO",        526, "", NULL },
   { "FW_RCV_IPC_CMD_RESET_INDEX_COUNT",          527, "", NULL },
   { "FW_RCV_IPC_CMD_SET_DISCONT_PKT_STREAM_ID",  528, "", NULL },
   { "FW_RCV_IPC_CMD_SET_PCR_PID",                529, "", NULL },
   { "FW_RCV_IPC_CMD_RESET_FILTER",               530, "", NULL },
   { "FW_RCV_IPC_CMD_RESET_STREAM",               531, "", NULL },
   { "FW_RCV_IPC_CMD_SET_STREAM_LOW_WM",          532, "", NULL },
   { "FW_RCV_IPC_CMD_SET_FILTER_HIGH_WM",         533, "", NULL },
   { "FW_RCV_IPC_CMD_SET_FILTER_CF",              534, "", NULL },

   { "FW_KERN_DBG_INIT_TOO_MANY_THREADS",         600, " ERROR: Init: Kernel cannot support %d threads", NULL },
   { "FW_KERN_DBG_INIT_TOO_MANY_MODULES",         601, " ERROR: Init: Kernel cannot support %d modules", NULL },
   { "FW_KERN_DBG_INIT_NULL_STATE_MEM",           602, " ERROR: Init: NULL state memory", NULL },
   { "FW_KERN_DBG_INIT_NULL_ISR_ADDR",            603, " ERROR: Init: NULL ISR address", NULL },
   { "FW_KERN_DBG_INIT_NULL_MINTR_ADDR",          604, " ERROR: Init: NULL master ISR address", NULL },
   { "FW_KERN_DBG_INIT_NULL_MINTRM_ADDR",         605, " ERROR: Init: NULL master ISR mask address", NULL },
   { "FW_KERN_DBG_INIT_ZERO_MMSK",                606, " ERROR: Init: zero master ISR mask", NULL },
   { "FW_KERN_DBG_INIT_DONE",                     607, " KERNEL: Init complete", NULL },
   { "FW_KERN_DBG_REG_MODULE_NULL_PROC_FUNC",     608, " ERROR: Add module %d without a proc function", NULL },
   { "FW_KERN_DBG_REG_MODULE_DUP_ID",             609, " ERROR: Add module %d with a duplicate ID", NULL },
   { "FW_KERN_DBG_REG_MODULE_NO_ISR_BITS",        610, " ERROR: Add module %d without any ISR bits", NULL },
   { "FW_KERN_DBG_REG_MODULE_ID_TOO_BIG",         611, " ERROR: Add module with invalid ID %d", NULL },
   { "FW_KERN_DBG_REG_MODULE_DONE",               612, " Added module %d with ISR bits %x", NULL },
   { "FW_KERN_DBG_ADD_TASK_ID_TOO_BIG",           613, " ERROR: Add task: Thread %d using invalid module ID %d", NULL },
   { "FW_KERN_DBG_ADD_TASK_NULL_DATA",            614, " ERROR: Add task: Thread %d to module %d with NULL data", NULL },
   { "FW_KERN_DBG_ADD_TASK_UNINITIALIZED_MODULE", 615, " ERROR: Add task: Thread %d using unset module %d", NULL },
   { "FW_KERN_DBG_ADD_TASK_ALREADY_EXISTS",       616, " ERROR: Add task: Thread %d doubling on module %d", NULL },
   { "FW_KERN_DBG_ADD_TASK_DOUBLE_DIPPING",       617, " ERROR: Add task: Thread %d to module %d when blocked", NULL },
   { "FW_KERN_DBG_ADD_TASK",                      618, " Added task from thread %d to module %d, task mask 0x%x", NULL },
   { "FW_KERN_DBG_ADD_TASK_KICK",                 619, " Add task: Thread %d to module %d, kicking", NULL },
   { "FW_KERN_DBG_ISR_START_MODULE",              620, " ISR: Module %d bits 0x%x has ISR bit(s) set ISR: 0x%x", NULL },
   { "FW_KERN_DBG_ISR_END_MODULE",                621, " ISR: Done with module %d", NULL },
   { "FW_KERN_DBG_ISR_CALL_ISR_FUNC",             622, " ISR: About to call module %d ISR function", NULL },
   { "FW_KERN_DBG_ISR_DONE_ISR_FUNC",             623, " ISR: Done calling module %d ISR function, ret %d", NULL },
   { "FW_KERN_DBG_ISR_CALL_ISR_FAILURE",          624, " ERROR: Module %d ISR func had unexpected failure %d", NULL },
   { "FW_KERN_DBG_ISR_MODULE_DONE",               625, " ISR: Done processing module %d", NULL },
   { "FW_KERN_DBG_ISR_UNBLOCK_THREAD",            626, " ISR: Module %d unblocking thread %d, new mask 0x%x", NULL },
   { "FW_KERN_DBG_ISR_CALL_PROC_FUNC",            627, " ISR: Call module %d proc func for thread %d, P %d", NULL },
   { "FW_KERN_DBG_ISR_DONE_PROC_FUNC",            628, " ISR: Done module %d proc func for thread %d, P %d", NULL },
   { "FW_KERN_DBG_ISR_CALL_PROC_FAILURE",         629, " ERROR: Module %d proc func had unexpected failure %d", NULL },
   { "FW_KERN_DBG_ISR_ENTER",                     630, " ISR: Entering, Status Register 0x%x", NULL },
   { "FW_KERN_DBG_ISR_EXIT",                      631, " ISR: Exiting, Status Register 0x%x", NULL },
   { "FW_KERN_DBG_REG_THR_ID_TOO_BIG",            632, " ERROR: Add thread: invalid thread ID %d", NULL },
   { "FW_KERN_DBG_REG_THR_INVALID_PRIORITY",      633, " ERROR: Add thread: thread %d with bad priority %d", NULL },
   { "FW_KERN_DBG_REG_THR_NULL_FUNC_TABL",        634, " ERROR: Add thread: thread %d with NULL func table", NULL },
   { "FW_KERN_DBG_REG_THR_DUP_ID",                635, " ERROR: Add Thread: thread %d already added", NULL },
   { "FW_KERN_DBG_REG_THR_DONE",                  636, " Added thread %d, HPmask 0x%x, HPcount %d, LPmask 0x%x", NULL },
   { "FW_KERN_DBG_UNREG_THR_ID_TOO_BIG",          637, " ERROR: Remove thread with invalid ID %d", NULL },
   { "FW_KERN_DBG_UNREG_THR_NOT_INITIALIZED",     638, " ERROR: Remove thread %d but it's not added", NULL },
   { "FW_KERN_DBG_UNREG_THR_DONE",                639, " Rem thread %d, HPmask 0x%x, HPcount %d, LPmask 0x%x", NULL },
   { "FW_KERN_DBG_SCHED_ENTERED",                 640, " SCHED: Entering", NULL },
   { "FW_KERN_DBG_SCHED_CHK_THREAD",              641, " SCHED: P %d check thread %d, Pmask 0x%x, thread mask 0x%x, idle cnt %d", NULL },
   { "FW_KERN_DBG_SCHED_SEL_THREAD",              642, " SCHED: Selecting thread %d, %d %d", NULL },
   { "FW_KERN_DBG_SCHED_CALL_THREAD",             643, " SCHED: Call thread %d func for state %d", NULL },
   { "FW_KERN_DBG_SCHED_DONE_THREAD",             644, " SCHED: Done with thread %d, new thread user state %d", NULL },
   { "FW_KERN_DBG_SCHED_CHANGE_TO_LP",            645, " SCHED: Switch to low-priority streams, idle count %d", NULL },
   { "FW_KERN_DBG_SCHED_CHANGE_TO_HP",            646, " SCHED: Switch to high-priority streams", NULL },
   { "FW_KERN_DBG_SET_THR_STATE_UNINITIALIZED",   647, " ERROR: Set state for uninitialized thread %d", NULL },
   { "FW_KERN_DBG_SET_THR_STATE",                 648, " Set thread state for thread %d from %d to %d", NULL },
   { "FW_KERN_DBG_SET_THR_IDLE_UNINITIALIZED",    649, " ERROR: Set idle for uninitialized thread %d", NULL },
   { "FW_KERN_DBG_SET_THR_IDLE",                  650, " Set thread %d idle prev idle %d", NULL },

   { "FW_HAL_INIT",                               700, " HAL INIT ENTER: Module: 0x%x, Line: %d", NULL },
   { "FW_HAL_INIT_SUCCESS",                       701, " HAL INIT SUCCESS: Module: 0x%x, Line: %d", NULL },
   { "FW_HAL_ISR_ENTER",                          702, " HAL ISR: Entering. Module: 0x%x, Line: %d", NULL },
   { "FW_HAL_ISR_EXIT",                           703, " HAL ISR: Exiting. Module: 0x%x, Line: %d, Return Value: %d", NULL },
   { "FW_HAL_CRITICAL_ERROR",                     704, " HAL: Critical Error! Module: 0x%x, Line: %d, Error Code: %d, Secondary Error Code: %d", NULL },
   { "FW_HAL_DMA_BUSY",                           705, " HAL: DMA Busy. Module: 0x%x, Line: %d, DMA Status: %d", NULL },

   { "FW_CQ_INIT_SUCCESS",                        800, " Circular Queue Init Success", NULL },
   { "FW_CQ_CREATE_FAILURE",                      801, " Circular Queue: Create Q Failed", NULL },
   { "FW_CQ_DELETE_QUEUE",                        802, " Circular Queue: Q Deleted, ID: %d", NULL },
   { "FW_CQ_NONE_AVAILABLE",                      803, " Circular Queue: No Descriptors Available", NULL },

   { "FW_MB_INIT_SUCCESS",                        810, " Message Box Init Success", NULL },
   { "FW_MB_CREATE_FAIL",                         811, " Message Box: Create Failed, line_number: %d, result %d", NULL },
   { "FW_MB_FREE_FAIL",                           812, " Message Box: Delete Failed, line number: %d, mb_id: %d, result %d", NULL },
   { "FW_MB_READ_FAIL",                           813, " Message Box: Read Failed, result %d", NULL },
   { "FW_MB_WRITE_ACK_FAIL",                      814, " Message Box: Write Ack Failed, result %d", NULL },

   { "FW_IPC_ERROR",                              900, " IPC Error: Line number: %d, D1: 0x%X, D2: 0x%X, D3: 0x%X, D4: 0x%X, D5: 0x%X", NULL },
   { "FW_TS_PROCESSING_ERROR",                    901, " TS Processing Error: Line number: %d, D1: 0x%X, D2: 0x%X, D3: 0x%X, D4: 0x%X, D5: 0x%X", NULL },
   { "FW_NEED_DATA",                              902, " Packet processing paused waiting for more data. Line number: %d", NULL },
   { "FW_PES_PARSE_GOT_PUSI",                     903, " PES Parse: Starting new parse", NULL },
   { "FW_PES_PARSE_IDLE",                         904, " PES Parse: Idle", NULL },
   { "FW_PSI_PROCESSING_ERROR",                   905, " PSI Processing Error: Line number: %d, D1: 0x%X, D2: 0x%X, D3: 0x%X, D4: 0x%X, D5: 0x%X", NULL },
   { "FW_PSI_PWNED",                              906, " PSI Processing PWNED: Line number: %d, D1: 0x%X, D2: 0x%X, D3: 0x%X, D4: 0x%X, D5: 0x%X", NULL },
   { "FW_PSI_BUFFER_LEAK",                        907, " PSI Processing Accumulator Buffer Leaked: Line number: %d, D1: 0x%X, D2: 0x%X, D3: 0x%X, D4: 0x%X, D5: 0x%X", NULL },
   { "FW_PSI_CANT_GET_ACCUMULATOR",               908, " PSI Processing Can't Aquire an Accumulator: Line number: %d, D1: 0x%X, D2: 0x%X, D3: 0x%X, D4: 0x%X, D5: 0x%X", NULL },
   { "FW_PSI_SIZE_MISMATCH",                      909, " PSI Processing Size Mismatch on Accumlators: Line number: %d, D1: 0x%X, D2: 0x%X, D3: 0x%X, D4: 0x%X, D5: 0x%X", NULL },
   { "FW_POWER_MODE_SET",                         910, " FW Power Mode Set: Line number: %d Data: 0x%08x 0x%08x 0x%08x 0x%08x 0x%08x ", NULL },

// NOTE: event numbers cannot pass 1024


   { NULL,0,NULL,NULL }
};

static const struct ModuleReverseDefs g_GEN3_TSD_sven_module =
{
    "GEN3_DEMUX",                           /* */
    SVEN_module_GEN3_DEMUX,             /*  */
    128*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_GEN3_TSD,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "Demux: TS_PS Demux (GEN3)",   /* */
    g_GEN3_TSD_specific_events,   /* TODO-Later: Define important events specific to my module */
    NULL /* extension list */
};

