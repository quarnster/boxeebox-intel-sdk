/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifndef _CE31XX_CWREG_H_
#include "csr_ce31xx_cw.h"
#endif

#ifndef _CE31XX_PMUREG_H_
#include "csr_ce31xx_pmu.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* 
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
static const struct EAS_RegBits g_csr_gen3_dfx_da_PRESCALER[] = 
{
    {"CURRENT",             16, 16, "Prescaler Current Value", NULL },
    {"PRESCALER",           0, 16, "Prescaler Set Value", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* OMAR Register bit breakouts
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
static const struct EAS_RegBits g_csr_gen3_dfx_omar_CONTROL[] = 
{
    {"ENABLE",              0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen3_dfx_omar_HEADER_WORD[] = 
{
    {"HDR_WRAP",            30, 2, "Circular Wrap Counter", NULL },
    {"HDR_BURST",           25, 4, "Burst Counter", NULL },
    {"HDR_SAMP",            0, 24, "Sample Counter", NULL },

    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

static const struct EAS_RegBits g_csr_gen3_dfx_omar_UNIT_ENA_0[] = 
{
    {"ENA_31",              31, 1, "", NULL },
    {"ENA_30",              30, 1, "", NULL },
    {"ENA_29",              29, 1, "", NULL },
    {"ENA_28",              28, 1, "", NULL },
    {"ENA_27",              27, 1, "", NULL },
    {"ENA_26",              26, 1, "", NULL },
    {"ENA_25",              25, 1, "", NULL },
    {"ENA_24",              24, 1, "", NULL },
    {"ENA_23",              23, 1, "", NULL },
    {"ENA_22",              22, 1, "", NULL },
    {"ENA_21",              21, 1, "", NULL },
    {"ENA_20",              20, 1, "", NULL },
    {"ENA_19",              19, 1, "", NULL },
    {"ENA_18",              18, 1, "", NULL },
    {"ENA_17",              17, 1, "", NULL },
    {"ENA_16",              16, 1, "", NULL },
    {"ENA_15",              15, 1, "", NULL },
    {"ENA_14",              14, 1, "", NULL },
    {"ENA_13",              13, 1, "", NULL },
    {"ENA_12",              12, 1, "", NULL },
    {"ENA_11",              11, 1, "", NULL },
    {"ENA_10",              10, 1, "", NULL },
    {"ENA_9",               9, 1, "", NULL },
    {"ENA_8",               8, 1, "", NULL },
    {"ENA_7",               7, 1, "", NULL },
    {"ENA_6",               6, 1, "", NULL },
    {"ENA_5",               5, 1, "", NULL },
    {"ENA_4",               4, 1, "", NULL },
    {"ENA_3",               3, 1, "", NULL },
    {"ENA_2",               2, 1, "", NULL },
    {"ENA_1",               1, 1, "", NULL },
    {"ENA_0",               0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};
static const struct EAS_RegBits g_csr_gen3_dfx_omar_UNIT_ENA_1[] = 
{
    {"ENA_63",              31, 1, "", NULL },
    {"ENA_62",              30, 1, "", NULL },
    {"ENA_61",              29, 1, "", NULL },
    {"ENA_60",              28, 1, "", NULL },
    {"ENA_59",              27, 1, "", NULL },
    {"ENA_58",              26, 1, "", NULL },
    {"ENA_57",              25, 1, "", NULL },
    {"ENA_56",              24, 1, "", NULL },
    {"ENA_55",              23, 1, "", NULL },
    {"ENA_54",              22, 1, "", NULL },
    {"ENA_53",              21, 1, "", NULL },
    {"ENA_52",              20, 1, "", NULL },
    {"ENA_51",              19, 1, "", NULL },
    {"ENA_50",              18, 1, "", NULL },
    {"ENA_49",              17, 1, "", NULL },
    {"ENA_48",              16, 1, "", NULL },
    {"ENA_47",              15, 1, "", NULL },
    {"ENA_46",              14, 1, "", NULL },
    {"ENA_45",              13, 1, "", NULL },
    {"ENA_44",              12, 1, "", NULL },
    {"ENA_43",              11, 1, "", NULL },
    {"ENA_42",              10, 1, "", NULL },
    {"ENA_41",              9, 1, "", NULL },
    {"ENA_40",              8, 1, "", NULL },
    {"ENA_39",              7, 1, "", NULL },
    {"ENA_38",              6, 1, "", NULL },
    {"ENA_37",              5, 1, "", NULL },
    {"ENA_36",              4, 1, "", NULL },
    {"ENA_35",              3, 1, "", NULL },
    {"ENA_34",              2, 1, "", NULL },
    {"ENA_33",              1, 1, "", NULL },
    {"ENA_32",              0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};
static const struct EAS_RegBits g_csr_gen3_dfx_omar_BLOCK_MUX[] = 
{
    {"SEL_35_67",               3, 1, "", NULL },
    {"SEL_34_66",               2, 1, "", NULL },
    {"SEL_33_65",               1, 1, "", NULL },
    {"SEL_32_64",               0, 1, "", NULL },
    { NULL,0,0,"",NULL }    /* NULL Terminated */
};

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* DFX Register bit breakouts
/* ---------------------------------------------------------------------------------- */
/* PMU
/* ---------------------------------------------------------------------------------- */
static const struct EAS_RegBits g_csr_PMU_CONTROL[] = 
{
    { "GlobalDisable",tcGlobalDisableBIT,tcGlobalDisableWIDTH,"", NULL },
    { "Overflow",tcOverflowBIT,tcOverflowWIDTH,"", NULL },
    { "Input0",tcInput0BIT,tcInputWIDTH,"", NULL },
    { "Input1",tcInput1BIT,tcInputWIDTH,"", NULL },
    { "Input2",tcInput2BIT,tcInputWIDTH,"", NULL },
    { "OverflowReset",tcOverflowResetBIT,tcOverflowResetWIDTH,"", NULL },
    { "Counter2Reset",tcCounterReset2BIT,tcCounterResetWIDTH,"", NULL },
    { "Counter1Reset",tcCounterReset1BIT,tcCounterResetWIDTH,"", NULL },
    { "Counter0Reset",tcCounterReset0BIT,tcCounterResetWIDTH,"", NULL },
    { "OverflowEnable",tcOverflowEnableBIT,tcOverflowEnableWIDTH,"", NULL },
    { "Counter2Enable",tcCounterEnable2BIT,tcCounterEnableWIDTH,"", NULL },
    { "Counter1Enable",tcCounterEnable1BIT,tcCounterEnableWIDTH,"", NULL },
    { "Counter0Enable",tcCounterEnable0BIT,tcCounterEnableWIDTH,"", NULL },
 	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_PMU_COUNTER_SELECT[] = 
{
    { "EventCount2",csEventCount2_shift,csEventCountWIDTH,"", NULL },
    { "EventCount1",csEventCount1_shift,csEventCountWIDTH,"", NULL },
    { "EventCount0",csEventCount0_shift,csEventCountWIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_PMU_INTERRUPT_ENABLE[] = 
{
    { "Counter0InterruptEnable",ieCounter0EnableBIT,ieCounter0EnableWIDTH,"", NULL },
    { "Counter1InterruptEnable",ieCounter1EnableBIT,ieCounter0EnableWIDTH,"", NULL },
    { "Counter2InterruptEnable",ieCounter2EnableBIT,ieCounter0EnableWIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_PMU_COUNTER_ENABLE[] = 
{
    { "Counter0InterruptEnable",ieCounter0EnableBIT,ieCounter0EnableWIDTH,"", NULL },
    { "Counter1InterruptEnable",ieCounter1EnableBIT,ieCounter0EnableWIDTH,"", NULL },
    { "Counter2InterruptEnable",ieCounter2EnableBIT,ieCounter0EnableWIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_PMU_INTERRUPT_STATUS[] = 
{
    { "PMUCount0Threshold",isCounter0ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMUCount1Threshold",isCounter1ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMUCount2Threshold",isCounter2ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU0Count0Threshold",isPMU0ThreshBIT+isCounter0ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU0Count1Threshold",isPMU0ThreshBIT+isCounter1ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU0Count2Threshold",isPMU0ThreshBIT+isCounter2ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU1Count0Threshold",isPMU1ThreshBIT+isCounter0ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU1Count1Threshold",isPMU1ThreshBIT+isCounter1ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU1Count2Threshold",isPMU1ThreshBIT+isCounter2ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU2Count0Threshold",isPMU2ThreshBIT+isCounter0ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU2Count1Threshold",isPMU2ThreshBIT+isCounter1ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU2Count2Threshold",isPMU2ThreshBIT+isCounter2ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU3Count0Threshold",isPMU3ThreshBIT+isCounter0ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU3Count1Threshold",isPMU3ThreshBIT+isCounter1ThreshBIT,isCounterThreshWIDTH,"", NULL },
    { "PMU3Count2Threshold",isPMU3ThreshBIT+isCounter2ThreshBIT,isCounterThreshWIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_PMU_START_STOP_CONTROL[] = 
{
    { "PMU0Count0StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU0Count1StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU0Count2StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU1Count0StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU1Count1StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU1Count2StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU2Count0StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU2Count1StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU2Count2StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU3Count0StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU3Count1StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
    { "PMU3Count2StartStop",ssPmu0Count0startBIT,ssPmuStartStopWIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

/* ---------------------------------------------------------------------------------- */
/* CW Register bit breakouts
/* ---------------------------------------------------------------------------------- */
static const struct EAS_RegBits g_csr_CW_GLOBAL_CONTROL[] = 
{
    { "MMR_Enable",gcCW_MMR_EN_BIT,gcCW_MMR_EN_WIDTH,"", NULL },
    { "CW32_Enable",gcCW32_ENBIT,gcCW32_EN_WIDTH,"", NULL },
    { "CW16_Enable",gcCW16_ENBIT,gcCW16_EN_WIDTH,"", NULL },
 	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_CW_CHAIN_CONTROL[] = 
{
    { "P2SEL",bcP2SEL_BIT,bcP2SEL_WIDTH,"Upper Byte Group Selection", NULL },
    { "P1SEL",bcP1SEL_BIT,bcP1SEL_WIDTH,"Lower Byte Group Selection", NULL },
    { "FLPBP",bcFLPBP_BIT,bcFLPBP_WIDTH,"Flop Bypass", NULL },
    { "TEBP",bcTEBP_BIT,bcTEBP_WIDTH,"Timing Enabled Bypass Control for deskew characterization", NULL },
    { "BLKID2",bcBLKID2_BIT,bcBLKID2_WIDTH,"Block ID 2 Selection for compare", NULL },
    { "BLKID1",bcBLKID1_BIT,bcBLKID1_WIDTH,"Block ID 1 Selection for compare", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_CW_USB_MUX_CONTROL[] = 
{
    { "USB_UPPER_BUS_SWAP",umcUpperBusSwapBIT,umcUpperBusSwapWIDTH,"", NULL },
    { "USB_UPPER_BUS_CLOCK_SELECT",umcUpperBusClkSelBIT,umcUpperBusClkSelWIDTH,"", NULL },
    { "USB_LOWER_BUS_CLOCK_SELECT",umcLowerBusClkSelBIT,umcLowerBusClkSelWIDTH,"", NULL },
    { "USB_UPPER_BUS_TABLE_SELECT",umcUpperBusTblSelBIT,umcUpperBusTblSelWIDTH,"", NULL },
    { "USB_LOWER_BUS_TABLE_SELECT",umcLowerBusTblSelBIT,umcLowerBusTblSelWIDTH,"", NULL },
    { "USB_UPPER_USB_SELECT",umcUpperUSBSelBIT,umcUpperUSBSelWIDTH,"", NULL },
    { "USB_LOWER_USB_SELECT",umcLowerUSBSelBIT,umcLowerUSBSelWIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_CW_SATA_MUX_CONTROL[] = 
{
    { "SATA_UPPER_BUS_SWAP",smcUpperBusSwapBIT,smcUpperBusSwapWIDTH,"", NULL },
    { "SATA_UPPER_BUS_TABLE_SELECT",smcUpperBusTblSelBIT,smcUpperBusTblSelWIDTH,"", NULL },
    { "SATA_LOWER_BUS_TABLE_SELECT",smcLowerBusTblSelBIT,smcLowerBusTblSelWIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_CW_PCIE_MUX_CONTROL[] = 
{
    { "PCIE_UPPER_BUS_CLOCK_SELECT",pmcUpperBusClkSelBIT,pmcUpperBusClkSelWIDTH,"", NULL },
    { "PCIE_LOWER_BUS_CLOCK_SELECT",pmcLowerBusClkSelBIT,pmcLowerBusClkSelWIDTH,"", NULL },
    { "PCIE_UPPER_BUS_TABLE_SELECT",pmcUpperBusTblSelBIT,pmcUpperBusTblSelWIDTH,"", NULL },
    { "PCIE_LOWER_BUS_TABLE_SELECT",pmcLowerBusTblSelBIT,pmcLowerBusTblSelWIDTH,"", NULL },
    { "PCIE_UPPER_BUS_LANE_SELECT",pmcUpperBusLaneSelBIT,pmcUpperBusLaneSelWIDTH,"", NULL },
    { "PCIE_LOWER_BUS_LANE_SELECT",pmcLowerBusLaneSelBIT,pmcLowerBusLaneSelWIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_CW_CLOCK_SELECT_CONTROL[] = 
{
    { "CW_CLOCK2_SELECT_CONTROL",cscCLK2_SEL_BIT,cscCLK2_SEL_WIDTH,"", NULL },
    { "CW_CLOCK1_SELECT_CONTROL",cscCLK1_SEL_BIT,cscCLK1_SEL_WIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_CW_BYTE_MUX_CONTROL[] = 
{
    { "BYTE_7_15_23_31_SEL",bmcBYTE7_SEL_BIT,bmcBYTE_SEL_WIDTH,"", NULL },
    { "BYTE_6_14_22_30_SEL",bmcBYTE6_SEL_BIT,bmcBYTE_SEL_WIDTH,"", NULL },
    { "BYTE_5_13_21_29_SEL",bmcBYTE5_SEL_BIT,bmcBYTE_SEL_WIDTH,"", NULL },
    { "BYTE_4_12_20_28_SEL",bmcBYTE4_SEL_BIT,bmcBYTE_SEL_WIDTH,"", NULL },
    { "BYTE_3_11_19_27_SEL",bmcBYTE3_SEL_BIT,bmcBYTE_SEL_WIDTH,"", NULL },
    { "BYTE_2_10_18_26_SEL",bmcBYTE2_SEL_BIT,bmcBYTE_SEL_WIDTH,"", NULL },
    { "BYTE_1_9_17_25_SEL",bmcBYTE1_SEL_BIT,bmcBYTE_SEL_WIDTH,"", NULL },
    { "BYTE_0_8_16_24_SEL",bmcBYTE0_SEL_BIT,bmcBYTE_SEL_WIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

static const struct EAS_RegBits g_csr_CW_BIT_MUX_CONTROL[]= 
{
    { "BIT_7_15_23_31_SEL",bmcBIT7_SEL_BIT,bmcBIT_SEL_WIDTH,"", NULL },
    { "BIT_6_14_22_30_SEL",bmcBIT6_SEL_BIT,bmcBIT_SEL_WIDTH,"", NULL },
    { "BIT_5_13_21_29_SEL",bmcBIT5_SEL_BIT,bmcBIT_SEL_WIDTH,"", NULL },
    { "BIT_4_12_20_28_SEL",bmcBIT4_SEL_BIT,bmcBIT_SEL_WIDTH,"", NULL },
    { "BIT_3_11_19_27_SEL",bmcBIT3_SEL_BIT,bmcBIT_SEL_WIDTH,"", NULL },
    { "BIT_2_10_18_26_SEL",bmcBIT2_SEL_BIT,bmcBIT_SEL_WIDTH,"", NULL },
    { "BIT_1_9_17_25_SEL",bmcBIT1_SEL_BIT,bmcBIT_SEL_WIDTH,"", NULL },
    { "BIT_0_8_16_24_SEL",bmcBIT0_SEL_BIT,bmcBIT_SEL_WIDTH,"", NULL },
	{ NULL,0,0,"",NULL }	/* NULL Terminated */
};

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* DFX Registers
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
static const struct EAS_Register g_csr_gen3_dfx[] =
{
    /* OMAR Section of DFX */
    { "DBG_SCRATCH",                0x200, NULL, "Scratch", NULL },
    { "DBG_TIMESTAMP",              0x204, NULL, "Timestamp", NULL },
    { "DBG_PRESCALE",               0x208, g_csr_gen3_dfx_da_PRESCALER, "Timestamp Prescale", NULL },
    { "DBG_COUNT_SET",              0x210, NULL, "Counter Get", NULL },
    { "DBG_COUNT_GET",              0x214, NULL, "Counter Set", NULL },
    { "DBG_COUNT_INC",              0x218, NULL, "Counter Increment", NULL },

    { "OMAR_CONTROL",               0x2000, g_csr_gen3_dfx_omar_CONTROL, "Control Register", NULL },
    { "OMAR_INTERVAL_COUNT",        0x2008, NULL, "Sample Interval Countdown (XSI clocks)", NULL },
    { "OMAR_HEADER_WORD",           0x200c, g_csr_gen3_dfx_omar_HEADER_WORD, "(RO) Header Word", NULL },
    { "OMAR_CAP_BASE_ADDR",         0x2010, NULL, "Capture Buffer Base Address", NULL },
    { "OMAR_CAP_SIZE",              0x2014, NULL, "Capture Buffer Size in bytes", NULL },
    { "OMAR_CAP_CUR_PTR",           0x2018, NULL, "(RO) Capture Current Pointer", NULL },
    { "OMAR_UNIT_ENABLE_0",         0x2020, g_csr_gen3_dfx_omar_UNIT_ENA_0, "Capture Enable for units (00-1f)", NULL },
    { "OMAR_UNIT_ENABLE_1",         0x2024, g_csr_gen3_dfx_omar_UNIT_ENA_1, "Capture Enable for units (20-3f)", NULL },
    { "OMAR_HILO_SWAP",             0x2028, NULL, "HighLow Swap", NULL },
    { "OMAR_BLOCK_SWAP",            0x202c, NULL, "Block Swap", NULL },
    { "OMAR_BLOCK_MUX_SELECT",      0x2030, g_csr_gen3_dfx_omar_BLOCK_MUX, "Block Mux Select", NULL },
//PMU Registers
    { "PMU0_CONTROL",pmu0_control,g_csr_PMU_CONTROL, "PMU0 Control Register, Counter[2:0]", NULL },
    { "PMU1_CONTROL",pmu1_control,g_csr_PMU_CONTROL, "PMU1 Control Register, Counter[5:3]", NULL },
    { "PMU2_CONTROL",pmu2_control,g_csr_PMU_CONTROL, "PMU2 Control Register, Counter[8:6]", NULL },
    { "PMU3_CONTROL",pmu3_control,g_csr_PMU_CONTROL, "PMU3 Control Register, Counter[11:9]", NULL },
    { "PMU0_COUNTER_SELECT",pmu0_counter_select,g_csr_PMU_COUNTER_SELECT, "PMU0 Counter Select, Counter[2:0]", NULL },
    { "PMU1_COUNTER_SELECT",pmu1_counter_select,g_csr_PMU_COUNTER_SELECT, "PMU1 Counter Select, Counter[5:3]", NULL },
    { "PMU2_COUNTER_SELECT",pmu2_counter_select,g_csr_PMU_COUNTER_SELECT, "PMU2 Counter Select, Counter[8:6]", NULL },
    { "PMU3_COUNTER_SELECT",pmu3_counter_select,g_csr_PMU_COUNTER_SELECT, "PMU3 Counter Select, Counter[11:9]", NULL },
    { "PMU0_INTERRUPT_ENABLE",pmu0_int_enable,g_csr_PMU_INTERRUPT_ENABLE, "PMU0 Interrupt Enable, Counter[2:0]", NULL },
    { "PMU1_INTERRUPT_ENABLE",pmu1_int_enable,g_csr_PMU_INTERRUPT_ENABLE, "PMU1 Interrupt Enable, Counter[5:3]", NULL },
    { "PMU2_INTERRUPT_ENABLE",pmu2_int_enable,g_csr_PMU_INTERRUPT_ENABLE, "PMU2 Interrupt Enable, Counter[8:6]", NULL },
    { "PMU3_INTERRUPT_ENABLE",pmu3_int_enable,g_csr_PMU_INTERRUPT_ENABLE, "PMU3 Interrupt Enable, Counter[11:9]", NULL },
    { "PMU0_INTERRUPT_STATUS",pmu0_int_status,g_csr_PMU_INTERRUPT_STATUS, "PMU0 Interrupt Status, Counter[2:0]", NULL },
    { "PMU1_INTERRUPT_STATUS",pmu1_int_status,g_csr_PMU_INTERRUPT_STATUS, "PMU1 Interrupt Status, Counter[5:3]", NULL },
    { "PMU2_INTERRUPT_STATUS",pmu2_int_status,g_csr_PMU_INTERRUPT_STATUS, "PMU2 Interrupt Status, Counter[8:6]", NULL },
    { "PMU3_INTERRUPT_STATUS",pmu3_int_status,g_csr_PMU_INTERRUPT_STATUS, "PMU3 Interrupt Status, Counter[11:9]", NULL },
    { "PMU0_EVENT_COUNT0_THRESHOLD",pmu0_event_count0_thrsh, NULL, "PMU0 Event Count Theshold, Counter 0", NULL },
    { "PMU0_EVENT_COUNT1_THRESHOLD",pmu0_event_count1_thrsh, NULL, "PMU0 Event Count Theshold, Counter 1", NULL },
    { "PMU0_EVENT_COUNT2_THRESHOLD",pmu0_event_count2_thrsh, NULL, "PMU0 Event Count Theshold, Counter 2", NULL },
    { "PMU1_EVENT_COUNT0_THRESHOLD",pmu1_event_count0_thrsh, NULL, "PMU1 Event Count Theshold, Counter 3", NULL },
    { "PMU1_EVENT_COUNT1_THRESHOLD",pmu1_event_count1_thrsh, NULL, "PMU1 Event Count Theshold, Counter 4", NULL },
    { "PMU1_EVENT_COUNT2_THRESHOLD",pmu1_event_count2_thrsh, NULL, "PMU1 Event Count Theshold, Counter 5", NULL },
    { "PMU2_EVENT_COUNT0_THRESHOLD",pmu2_event_count0_thrsh, NULL, "PMU2 Event Count Theshold, Counter 6", NULL },
    { "PMU2_EVENT_COUNT1_THRESHOLD",pmu2_event_count1_thrsh, NULL, "PMU2 Event Count Theshold, Counter 7", NULL },
    { "PMU2_EVENT_COUNT2_THRESHOLD",pmu2_event_count2_thrsh, NULL, "PMU2 Event Count Theshold, Counter 8", NULL },
    { "PMU3_EVENT_COUNT0_THRESHOLD",pmu3_event_count0_thrsh, NULL, "PMU3 Event Count Theshold, Counter 9", NULL },
    { "PMU3_EVENT_COUNT1_THRESHOLD",pmu3_event_count1_thrsh, NULL, "PMU3 Event Count Theshold, Counter 10", NULL },
    { "PMU3_EVENT_COUNT2_THRESHOLD",pmu3_event_count2_thrsh, NULL, "PMU3 Event Count Theshold, Counter 11", NULL },
    { "PMU0_EVENT_COUNT0",pmu0_event_count0, NULL, "PMU0 Event Count 0, Counter 0", NULL },
    { "PMU0_EVENT_COUNT1",pmu0_event_count1, NULL, "PMU0 Event Count 1, Counter 1", NULL },
    { "PMU0_EVENT_COUNT2",pmu0_event_count2, NULL, "PMU0 Event Count 2, Counter 2", NULL },
    { "PMU1_EVENT_COUNT0",pmu1_event_count0, NULL, "PMU1 Event Count 0, Counter 3", NULL },
    { "PMU1_EVENT_COUNT1",pmu1_event_count1, NULL, "PMU1 Event Count 1, Counter 4", NULL },
    { "PMU1_EVENT_COUNT2",pmu1_event_count2, NULL, "PMU1 Event Count 2, Counter 5", NULL },
    { "PMU2_EVENT_COUNT0",pmu2_event_count0, NULL, "PMU2 Event Count 0, Counter 6", NULL },
    { "PMU2_EVENT_COUNT1",pmu2_event_count1, NULL, "PMU2 Event Count 1, Counter 7", NULL },
    { "PMU2_EVENT_COUNT2",pmu2_event_count2, NULL, "PMU2 Event Count 2, Counter 8", NULL },
    { "PMU3_EVENT_COUNT0",pmu3_event_count0, NULL, "PMU3 Event Count 0, Counter 9", NULL },
    { "PMU3_EVENT_COUNT1",pmu3_event_count1, NULL, "PMU3 Event Count 1, Counter 10", NULL },
    { "PMU3_EVENT_COUNT2",pmu3_event_count2, NULL, "PMU3 Event Count 2, Counter 11", NULL },
    { "PMU0_OVERFLOW_COUNT",pmu0_overflow_count, NULL, "PMU0 Overflow Count", NULL },
    { "PMU1_OVERFLOW_COUNT",pmu1_overflow_count, NULL, "PMU0 Overflow Count", NULL },
    { "PMU2_OVERFLOW_COUNT",pmu2_overflow_count, NULL, "PMU0 Overflow Count", NULL },
    { "PMU3_OVERFLOW_COUNT",pmu3_overflow_count, NULL, "PMU0 Overflow Count", NULL },
    { "PMU0_START_STOP_CONTROL0",pmu0_start_stop_ctrl0, NULL, "PMU0 Start Stop Control0, Counter 0", NULL },
    { "PMU0_START_STOP_CONTROL1",pmu0_start_stop_ctrl1, NULL, "PMU0 Start Stop Control1, Counter 1", NULL },
    { "PMU0_START_STOP_CONTROL2",pmu0_start_stop_ctrl2, NULL, "PMU0 Start Stop Control2, Counter 2", NULL },
    { "PMU1_START_STOP_CONTROL0",pmu1_start_stop_ctrl0, NULL, "PMU1 Start Stop Control0, Counter 3", NULL },
    { "PMU1_START_STOP_CONTROL1",pmu1_start_stop_ctrl1, NULL, "PMU1 Start Stop Control1, Counter 4", NULL },
    { "PMU1_START_STOP_CONTROL2",pmu1_start_stop_ctrl2, NULL, "PMU1 Start Stop Control2, Counter 5", NULL },
    { "PMU2_START_STOP_CONTROL0",pmu2_start_stop_ctrl0, NULL, "PMU2 Start Stop Control0, Counter 6", NULL },
    { "PMU2_START_STOP_CONTROL1",pmu2_start_stop_ctrl1, NULL, "PMU2 Start Stop Control1, Counter 7", NULL },
    { "PMU2_START_STOP_CONTROL2",pmu2_start_stop_ctrl2, NULL, "PMU2 Start Stop Control2, Counter 8", NULL },
    { "PMU3_START_STOP_CONTROL0",pmu3_start_stop_ctrl0, NULL, "PMU3 Start Stop Control0, Counter 9", NULL },
    { "PMU3_START_STOP_CONTROL1",pmu3_start_stop_ctrl1, NULL, "PMU3 Start Stop Control1, Counter 10", NULL },
    { "PMU3_START_STOP_CONTROL2",pmu3_start_stop_ctrl2, NULL, "PMU3 Start Stop Control2, Counter 11", NULL },
//CW Registers
    { "CW_GLOBAL_CONTROL",cw_global_control,g_csr_CW_GLOBAL_CONTROL, "CW0 Control Register, Counter[2:0]", NULL },
    { "CW_SKEW_CLKS_CONTROL",cw_skew_clks_cntrl,NULL,"CW Clocks Skew Control", NULL },
    { "CW_SKEW7_0_CONTROL",cw_skew7_0_cntrl,NULL,"CW Signals[7:0] Skew Control", NULL },
    { "CW_SKEW15_8_CONTROL",cw_skew15_8_cntrl,NULL,"CW Signals[15:8] Skew Control", NULL },
    { "CW_SKEW23_16_CONTROL",cw_skew23_16_cntrl,NULL,"CW Signals[23:16] Skew Control", NULL },
    { "CW_SKEW31_24_CONTROL",cw_skew31_24_cntrl,NULL,"CW Signals[32:24] Skew Control", NULL },
    { "CW_CHAIN0_CONTROL",cw_chain0_ctrl,g_csr_CW_CHAIN_CONTROL,"CW Chain 0 Control", NULL },
    { "CW_CHAIN1_CONTROL",cw_chain1_ctrl,g_csr_CW_CHAIN_CONTROL,"CW Chain 1 Control", NULL },
    { "CW_CHAIN2_CONTROL",cw_chain2_ctrl,g_csr_CW_CHAIN_CONTROL,"CW Chain 2 Control", NULL },
    { "CW_CHAIN3_CONTROL",cw_chain3_ctrl,g_csr_CW_CHAIN_CONTROL,"CW Chain 3 Control", NULL },
    { "CW_CHAIN4_CONTROL",cw_chain4_ctrl,g_csr_CW_CHAIN_CONTROL,"CW Chain 4 Control", NULL },
    { "CW_CHAIN5_CONTROL",cw_chain5_ctrl,g_csr_CW_CHAIN_CONTROL,"CW Chain 5 Control", NULL },
    { "CW_CHAIN6_CONTROL",cw_chain6_ctrl,g_csr_CW_CHAIN_CONTROL,"CW Chain 6 Control", NULL },
    { "CW_CHAIN7_CONTROL",cw_chain7_ctrl,g_csr_CW_CHAIN_CONTROL,"CW Chain 7 Control", NULL },
    { "CW_USB_MUX_CONTROL",cw_usb_mux_control,g_csr_CW_USB_MUX_CONTROL,"", NULL },
    { "CW_SATA_MUX_CONTROL",cw_sata_mux_control,g_csr_CW_SATA_MUX_CONTROL,"", NULL },
    { "CW_PCIE_MUX_CONTROL",cw_pcie_mux_control,g_csr_CW_PCIE_MUX_CONTROL,"", NULL },
    { "CW_CLOCK_SELECT_CONTROL",cw_clk_sel_ctrl,g_csr_CW_CLOCK_SELECT_CONTROL,"", NULL },
    { "CW_BYTE07_00_MUX_CONTROL",cw_byte07_00_mux_ctrl,g_csr_CW_BYTE_MUX_CONTROL,"", NULL },
    { "CW_BYTE15_08_MUX_CONTROL",cw_byte15_08_mux_ctrl,g_csr_CW_BYTE_MUX_CONTROL,"", NULL },
    { "CW_BYTE23_16_MUX_CONTROL",cw_byte23_16_mux_ctrl,g_csr_CW_BYTE_MUX_CONTROL,"", NULL },
    { "CW_BYTE31_24_MUX_CONTROL",cw_byte31_24_mux_ctrl,g_csr_CW_BYTE_MUX_CONTROL,"", NULL },
    { "CW_BIT07_00_MUX_CONTROL",cw_bit07_00_mux_ctrl,g_csr_CW_BIT_MUX_CONTROL,"", NULL },
    { "CW_BIT15_08_MUX_CONTROL",cw_bit15_08_mux_ctrl,g_csr_CW_BIT_MUX_CONTROL,"", NULL },
    { "CW_BIT23_16_MUX_CONTROL",cw_bit23_16_mux_ctrl,g_csr_CW_BIT_MUX_CONTROL,"", NULL },
    { "CW_BIT31_24_MUX_CONTROL",cw_bit31_24_mux_ctrl,g_csr_CW_BIT_MUX_CONTROL,"", NULL },

    { NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */

/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct SVEN_Module_EventSpecific g_gen3_dfx_specific_events[] =
{
	{ "OMAR_CAPTURE_START",			1, "", NULL },
	{ "OMAR_CAPTURE_STOP",			2, "", NULL },
//	{ "INTERVAL_CONFIGURATION",		3, " Counter %d\tThreshold 0x%08X\tMem_speed %dMHz, Interval %dsec", NULL },
	{ "INTERVAL_CONFIGURATION",		3, \
		" Counter %d, \
		 Threshold 0x%08X, \
		 Mem_speed %dMHz, \
		 Req Interval %dus, \
		 Comp Interval %dms", \
		NULL },
	{ "INTERVAL_MODE_INT",			4, " %d\t#1\t\t#2\t\t#3\t\tOVERFLOW\twhich=%d, ndx=%d", NULL },
	{ "INTERRUPT_DATA_0",			5, "\t0x%08X\t0x%08X\t0x%08X\t0x%08X", NULL },
	{ "INTERRUPT_DATA_1",			6, "\t0x%08X\t0x%08X\t0x%08X\t0x%08X", NULL },
	{ "INTERRUPT_DATA_2",			7, "\t0x%08X\t0x%08X\t0x%08X\t0x%08X", NULL },
	{ "INTERRUPT_DATA_3",			8, "\t0x%08X\t0x%08X\t0x%08X\t0x%08X", NULL },

	{ NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_gen3_dfx_sven_module =
{
    "GEN3_DFX",
    SVEN_module_GEN3_DFX,
    0x00010000,            /* size of CSR Space */
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen3_dfx,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "DFX: Gen3 DFX Control",
    g_gen3_dfx_specific_events,
    NULL /* extension list */
};
