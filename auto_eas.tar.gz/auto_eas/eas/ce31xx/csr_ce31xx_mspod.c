/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* ---------------------------------------------------------------------------------- */
/* MSPOD---------------------------------------------------------------------------------- */

static const struct EAS_RegBits g_csr_MS_CableCARD____HIF_CTRL_REG[] =
{
     { "RESERVED_11",   11, 20 },   /* Reserved */
     { "RX_CR0_FILTER", 10, 1  },   /* If set, this bit enables all received idles with CR=0 to be passed through to main memory. */
     { "RX_CR1_FILTER", 9, 1  },   /* If set, this bit enables all received idles with CR=1 to be passed through to main memory. */
     { "RX_ER_FILTER",  8, 1  },   /* If set, this bit enables all received idles with ER to be passed through to main memory. */
     { "RESERVED_02",  2, 6 },     /* Reserved */
     { "CLK_EN",       1, 1  },   /* Clock Enable.  This bit is used to gate xsi_clk to selected portions of the MSPOD Host Interface controller. 0:  gate clock 1:  do not gate clock */
     { "ENABLE",       0, 1  },   /* This bit must be set in order to enable the MS-CableCARD Host Interface.  */
     {NULL}
};

static const struct EAS_RegBits g_csr_MS_CableCARD____HOST_IF_STATUS_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_MS_CableCARD____HOST_IF_INT_ENABLE_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_MS_CableCARD____HOST_IF_INT_STATUS_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_MS_CableCARD____HOST_IF_RX_DROPS[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_CDMA_1394_INT_ENABLE_REG[] =
{
     { "RESERVED",         4,  32-4},  /*reserved*/
     { "1394_OUT_LL_DN_EN",3,  1},     /*1394 Out Linked List Done Interrupt Enable bit. */
     { "1394_OUT_DN_EN",   2,  1},     /*1394 Out DMA Done Interrupt Enable bit.*/
     { "1394_IN_LL_DN_EN", 1,  1},     /*1394 In Linked List Done Interrupt Enable bit.*/
     { "1394_IN_DN_EN",    0,  1},     /*1394 In DMA Done Interrupt Enable bit.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_CDMA_1394_INT_STATUS_REG[] =
{
     { "RESERVED",      4,  32-4},  /*reserved*/
     { "1394_OUT_LL_DN",3,  1},     /*1394 Out Linked List Done.  In Linked List mode, this bit is set whenever the end of the linked list has been reached.*/
     { "1394_OUT_DN",   2,  1},     /*1394 Out Done.  This bit is set whenever the DMA transfer has completed.*/
     { "1394_IN_LL_DN", 1,  1},     /*1394 In Linked List Done.  In Linked List mode, this bit is set whenever the end of the linked list has been reached.*/
     { "1394_IN_DN",    0,  1},     /*1394 In Done.  This bit is set whenever the DMA transfer has completed.   */
     {NULL}
};
static const struct EAS_RegBits g_csr_CDMA_P2P_INT_ENABLE_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_CDMA_P2P_INT_STATUS_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};

/* ---------------------------------------------------------------------------------- */
/* DMA REGISTER CONTEXTS  ----------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
static const struct EAS_RegBits g_csr_DMA_00_CUR_DESCR_REG[] =
{
     { "CURDESC",        0, 32  },   /* Current DMA descriptor for Linked List Mode Only.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_NEXT_DESCR_REG[] =
{
     { "NEXTDESC",                  2, 30  }, /* Next Descriptor Address.*/
     { "DEST_CIRBUF_PTR_ENABLE",    1,1},
     { "SRC_CIRBUF_PTR_ENABLE",     0,1},
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_SRCDMA_START_REG[] =
{
     { "SRCDMA_START",         0, 32  }, /* This is also the current address pointer into the source buffer (read-pointer).*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_DSTDMA_START_REG[] =
{
     { "DSTDMA_START",         0, 32  }, /* This is also the current address pointer into the destination buffer (write-pointer).  .*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_SRCDMA_SIZE_REG[] =
{
     { "SRCDMA_SIZE",         0, 32  }, /* Total size of the block of data (in bytes) to be read from the source location.  This register is also updated by hardware as the DMA transfers data */
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_FLAGS_MODE_REG[] =
{
	{"ACTIVE_DMA",      31,1    },   /*1: DMA context is active (has been started but has not finished). 0: DMA context is not active., bit(s):31, default(0), access(RO) */
	{"SRC_INT",         30,1    },  /*Interrupt when the current (active context) transfer has finished (source byte counter reaches zero) or when in circular-buffer addressing mode the circular buffer is empty.  1: enable interrupt 0: do not interrupt, bit(s):30, default(0), access(RW)"*/
	{"DST_INT",         29,1    },  /*Interrupt when the current (active context) transfer has finished (destination byte counter reaches zero) or when in circular-buffer addressing mode and the circular buffer is full. 1: enable interrupt 0: do not interrupt, bit(s):29, default(0), access(RW)"*/
	{"TERM",            28,1    },  /*Do not fetch the next descriptor when the current (active context) transfer has finished (byte counter reaches zero). 1: terminate 0: go read next descriptor , bit(s):28, default(0), access(RW) */
	{"RD_SWAP_ENDIAN",  27,1    },  /*Read Swap Endianism: This bit control whether the data on a DMA \"read\" (a transfer from global address space to local address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):27, default(0), access(RW)*/
	{"WR_SWAP_ENDIAN",  26,1    },  /*Write Swap Endianism: This bit controls whether the data on a DMA \"write\" (a transfer from local address space to global address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):26, default(0), access(RW)*/
	{"SRC_ENDIANISM",   25,1    },  /*Source Endianism: Indicates what the source endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):25, default(0), access(RW)*/
	{"DST_ENDIANISM",   24,1    },  /*,"Destination Endianism: Indicates what the destination endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):24, default(0), access(RW)*/
	{"SUBUNIT_ID",      20,4    },  /*,, default(0), access(RW)*/
	{"XDMA_GAP",        16,4    },  /*,"Between bursts (meaning the larger of the 2 burst sizes) the context is \"locked\" XDMA_GAP value XSI bus clocks., bit(s):19:16, default(0), access(RW)*/
	{"XBURST_SZ",       12,4    },  /*,"The DMA will transfer data to the Global Agent in bursts of this value., bit(s):15:12, default(0), access(RW)*/
	{"BURST_SZ",        8,4     },  /*,"The DMA will transfer data to the Local Agent in bursts of this value., bit(s):11:8, default(0), access(RW)*/
	{"READ_EN",         7,1     },  /*,"The DMA will read data from the global address space and write it into the local address space., bit(s):7, default(0), access(RW)*/
	{"SRC_ADDR_MODE",   5,2     },  /*,"Source Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):6:5, default(0), access(RW)*/
	{"SRC_LINK_LIST",   4,1     },  /*,"Source Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):4, default(0), access(RW)*/
	{"WRITE_EN",        3,1     },  /*,"The DMA will read data from the local address space and write it into the global address space., bit(s):3, default(0), access(RW)*/
	{"DST_ADDR_MODE",   1,2     },  /*,"Destination Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):2:1, default(0), access(RW)*/
	{"DST_LINK_LIST",   0,1     },  /*,"Destination Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):0, default(0), access(RW)*/
    {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_SRCDMA_START_ALIAS_REG[] =
{
     { "SRCDMA_ALIAS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_SRCDMA_BOT_REG[] =
{
     { "SRCDMA_BOT",         2, 30  }, /* Source Buffer Bottom.  32-bit aligned address marking the bottom of a circular-source-buffer.*/
     { "SRC_CIRBUF_SHARE",   0, 2  },  /* Source Circular-Buffer Pointer-Sharing Counter.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_SRCDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_DSTDMA_BOT_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_DSTDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_00_DSTDMA_SIZE_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
static const struct EAS_RegBits g_csr_DMA_01_CUR_DESCR_REG[] =
{
     { "CURDESC",        0, 32  },   /* Current DMA descriptor for Linked List Mode Only.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_NEXT_DESCR_REG[] =
{
     { "NEXTDESC",                  2, 30  }, /* Next Descriptor Address.*/
     { "DEST_CIRBUF_PTR_ENABLE",    1,1},
     { "SRC_CIRBUF_PTR_ENABLE",     0,1},
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_SRCDMA_START_REG[] =
{
     { "SRCDMA_START",         0, 32  }, /* This is also the current address pointer into the source buffer (read-pointer).*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_DSTDMA_START_REG[] =
{
     { "DSTDMA_START",         0, 32  }, /* This is also the current address pointer into the destination buffer (write-pointer).  .*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_SRCDMA_SIZE_REG[] =
{
     { "SRCDMA_SIZE",         0, 32  }, /* Total size of the block of data (in bytes) to be read from the source location.  This register is also updated by hardware as the DMA transfers data */
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_FLAGS_MODE_REG[] =
{
	{"ACTIVE_DMA",      31,1    },   /*1: DMA context is active (has been started but has not finished). 0: DMA context is not active., bit(s):31, default(0), access(RO) */
	{"SRC_INT",         30,1    },  /*Interrupt when the current (active context) transfer has finished (source byte counter reaches zero) or when in circular-buffer addressing mode the circular buffer is empty.  1: enable interrupt 0: do not interrupt, bit(s):30, default(0), access(RW)"*/
	{"DST_INT",         29,1    },  /*Interrupt when the current (active context) transfer has finished (destination byte counter reaches zero) or when in circular-buffer addressing mode and the circular buffer is full. 1: enable interrupt 0: do not interrupt, bit(s):29, default(0), access(RW)"*/
	{"TERM",            28,1    },  /*Do not fetch the next descriptor when the current (active context) transfer has finished (byte counter reaches zero). 1: terminate 0: go read next descriptor , bit(s):28, default(0), access(RW) */
	{"RD_SWAP_ENDIAN",  27,1    },  /*Read Swap Endianism: This bit control whether the data on a DMA \"read\" (a transfer from global address space to local address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):27, default(0), access(RW)*/
	{"WR_SWAP_ENDIAN",  26,1    },  /*Write Swap Endianism: This bit controls whether the data on a DMA \"write\" (a transfer from local address space to global address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):26, default(0), access(RW)*/
	{"SRC_ENDIANISM",   25,1    },  /*Source Endianism: Indicates what the source endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):25, default(0), access(RW)*/
	{"DST_ENDIANISM",   24,1    },  /*,"Destination Endianism: Indicates what the destination endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):24, default(0), access(RW)*/
	{"SUBUNIT_ID",      20,4    },  /*,, default(0), access(RW)*/
	{"XDMA_GAP",        16,4    },  /*,"Between bursts (meaning the larger of the 2 burst sizes) the context is \"locked\" XDMA_GAP value XSI bus clocks., bit(s):19:16, default(0), access(RW)*/
	{"XBURST_SZ",       12,4    },  /*,"The DMA will transfer data to the Global Agent in bursts of this value., bit(s):15:12, default(0), access(RW)*/
	{"BURST_SZ",        8,4     },  /*,"The DMA will transfer data to the Local Agent in bursts of this value., bit(s):11:8, default(0), access(RW)*/
	{"READ_EN",         7,1     },  /*,"The DMA will read data from the global address space and write it into the local address space., bit(s):7, default(0), access(RW)*/
	{"SRC_ADDR_MODE",   5,2     },  /*,"Source Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):6:5, default(0), access(RW)*/
	{"SRC_LINK_LIST",   4,1     },  /*,"Source Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):4, default(0), access(RW)*/
	{"WRITE_EN",        3,1     },  /*,"The DMA will read data from the local address space and write it into the global address space., bit(s):3, default(0), access(RW)*/
	{"DST_ADDR_MODE",   1,2     },  /*,"Destination Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):2:1, default(0), access(RW)*/
	{"DST_LINK_LIST",   0,1     },  /*,"Destination Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):0, default(0), access(RW)*/
    {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_SRCDMA_START_ALIAS_REG[] =
{
     { "SRCDMA_ALIAS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_SRCDMA_BOT_REG[] =
{
     { "SRCDMA_BOT",         2, 30  }, /* Source Buffer Bottom.  32-bit aligned address marking the bottom of a circular-source-buffer.*/
     { "SRC_CIRBUF_SHARE",   0, 2  },  /* Source Circular-Buffer Pointer-Sharing Counter.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_SRCDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_DSTDMA_BOT_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_DSTDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_01_DSTDMA_SIZE_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
static const struct EAS_RegBits g_csr_DMA_02_CUR_DESCR_REG[] =
{
     { "CURDESC",        0, 32  },   /* Current DMA descriptor for Linked List Mode Only.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_NEXT_DESCR_REG[] =
{
     { "NEXTDESC",                  2, 30  }, /* Next Descriptor Address.*/
     { "DEST_CIRBUF_PTR_ENABLE",    1,1},
     { "SRC_CIRBUF_PTR_ENABLE",     0,1},
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_SRCDMA_START_REG[] =
{
     { "SRCDMA_START",         0, 32  }, /* This is also the current address pointer into the source buffer (read-pointer).*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_DSTDMA_START_REG[] =
{
     { "DSTDMA_START",         0, 32  }, /* This is also the current address pointer into the destination buffer (write-pointer).  .*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_SRCDMA_SIZE_REG[] =
{
     { "SRCDMA_SIZE",         0, 32  }, /* Total size of the block of data (in bytes) to be read from the source location.  This register is also updated by hardware as the DMA transfers data */
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_FLAGS_MODE_REG[] =
{
	{"ACTIVE_DMA",      31,1    },   /*1: DMA context is active (has been started but has not finished). 0: DMA context is not active., bit(s):31, default(0), access(RO) */
	{"SRC_INT",         30,1    },  /*Interrupt when the current (active context) transfer has finished (source byte counter reaches zero) or when in circular-buffer addressing mode the circular buffer is empty.  1: enable interrupt 0: do not interrupt, bit(s):30, default(0), access(RW)"*/
	{"DST_INT",         29,1    },  /*Interrupt when the current (active context) transfer has finished (destination byte counter reaches zero) or when in circular-buffer addressing mode and the circular buffer is full. 1: enable interrupt 0: do not interrupt, bit(s):29, default(0), access(RW)"*/
	{"TERM",            28,1    },  /*Do not fetch the next descriptor when the current (active context) transfer has finished (byte counter reaches zero). 1: terminate 0: go read next descriptor , bit(s):28, default(0), access(RW) */
	{"RD_SWAP_ENDIAN",  27,1    },  /*Read Swap Endianism: This bit control whether the data on a DMA \"read\" (a transfer from global address space to local address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):27, default(0), access(RW)*/
	{"WR_SWAP_ENDIAN",  26,1    },  /*Write Swap Endianism: This bit controls whether the data on a DMA \"write\" (a transfer from local address space to global address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):26, default(0), access(RW)*/
	{"SRC_ENDIANISM",   25,1    },  /*Source Endianism: Indicates what the source endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):25, default(0), access(RW)*/
	{"DST_ENDIANISM",   24,1    },  /*,"Destination Endianism: Indicates what the destination endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):24, default(0), access(RW)*/
	{"SUBUNIT_ID",      20,4    },  /*,, default(0), access(RW)*/
	{"XDMA_GAP",        16,4    },  /*,"Between bursts (meaning the larger of the 2 burst sizes) the context is \"locked\" XDMA_GAP value XSI bus clocks., bit(s):19:16, default(0), access(RW)*/
	{"XBURST_SZ",       12,4    },  /*,"The DMA will transfer data to the Global Agent in bursts of this value., bit(s):15:12, default(0), access(RW)*/
	{"BURST_SZ",        8,4     },  /*,"The DMA will transfer data to the Local Agent in bursts of this value., bit(s):11:8, default(0), access(RW)*/
	{"READ_EN",         7,1     },  /*,"The DMA will read data from the global address space and write it into the local address space., bit(s):7, default(0), access(RW)*/
	{"SRC_ADDR_MODE",   5,2     },  /*,"Source Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):6:5, default(0), access(RW)*/
	{"SRC_LINK_LIST",   4,1     },  /*,"Source Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):4, default(0), access(RW)*/
	{"WRITE_EN",        3,1     },  /*,"The DMA will read data from the local address space and write it into the global address space., bit(s):3, default(0), access(RW)*/
	{"DST_ADDR_MODE",   1,2     },  /*,"Destination Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):2:1, default(0), access(RW)*/
	{"DST_LINK_LIST",   0,1     },  /*,"Destination Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):0, default(0), access(RW)*/
    {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_SRCDMA_START_ALIAS_REG[] =
{
     { "SRCDMA_ALIAS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_SRCDMA_BOT_REG[] =
{
     { "SRCDMA_BOT",         2, 30  }, /* Source Buffer Bottom.  32-bit aligned address marking the bottom of a circular-source-buffer.*/
     { "SRC_CIRBUF_SHARE",   0, 2  },  /* Source Circular-Buffer Pointer-Sharing Counter.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_SRCDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_DSTDMA_BOT_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_DSTDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_02_DSTDMA_SIZE_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
static const struct EAS_RegBits g_csr_DMA_03_CUR_DESCR_REG[] =
{
     { "CURDESC",        0, 32  },   /* Current DMA descriptor for Linked List Mode Only.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_NEXT_DESCR_REG[] =
{
     { "NEXTDESC",                  2, 30  }, /* Next Descriptor Address.*/
     { "DEST_CIRBUF_PTR_ENABLE",    1,1},
     { "SRC_CIRBUF_PTR_ENABLE",     0,1},
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_SRCDMA_START_REG[] =
{
     { "SRCDMA_START",         0, 32  }, /* This is also the current address pointer into the source buffer (read-pointer).*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_DSTDMA_START_REG[] =
{
     { "DSTDMA_START",         0, 32  }, /* This is also the current address pointer into the destination buffer (write-pointer).  .*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_SRCDMA_SIZE_REG[] =
{
     { "SRCDMA_SIZE",         0, 32  }, /* Total size of the block of data (in bytes) to be read from the source location.  This register is also updated by hardware as the DMA transfers data */
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_FLAGS_MODE_REG[] =
{
	{"ACTIVE_DMA",      31,1    },   /*1: DMA context is active (has been started but has not finished). 0: DMA context is not active., bit(s):31, default(0), access(RO) */
	{"SRC_INT",         30,1    },  /*Interrupt when the current (active context) transfer has finished (source byte counter reaches zero) or when in circular-buffer addressing mode the circular buffer is empty.  1: enable interrupt 0: do not interrupt, bit(s):30, default(0), access(RW)"*/
	{"DST_INT",         29,1    },  /*Interrupt when the current (active context) transfer has finished (destination byte counter reaches zero) or when in circular-buffer addressing mode and the circular buffer is full. 1: enable interrupt 0: do not interrupt, bit(s):29, default(0), access(RW)"*/
	{"TERM",            28,1    },  /*Do not fetch the next descriptor when the current (active context) transfer has finished (byte counter reaches zero). 1: terminate 0: go read next descriptor , bit(s):28, default(0), access(RW) */
	{"RD_SWAP_ENDIAN",  27,1    },  /*Read Swap Endianism: This bit control whether the data on a DMA \"read\" (a transfer from global address space to local address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):27, default(0), access(RW)*/
	{"WR_SWAP_ENDIAN",  26,1    },  /*Write Swap Endianism: This bit controls whether the data on a DMA \"write\" (a transfer from local address space to global address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):26, default(0), access(RW)*/
	{"SRC_ENDIANISM",   25,1    },  /*Source Endianism: Indicates what the source endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):25, default(0), access(RW)*/
	{"DST_ENDIANISM",   24,1    },  /*,"Destination Endianism: Indicates what the destination endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):24, default(0), access(RW)*/
	{"SUBUNIT_ID",      20,4    },  /*,, default(0), access(RW)*/
	{"XDMA_GAP",        16,4    },  /*,"Between bursts (meaning the larger of the 2 burst sizes) the context is \"locked\" XDMA_GAP value XSI bus clocks., bit(s):19:16, default(0), access(RW)*/
	{"XBURST_SZ",       12,4    },  /*,"The DMA will transfer data to the Global Agent in bursts of this value., bit(s):15:12, default(0), access(RW)*/
	{"BURST_SZ",        8,4     },  /*,"The DMA will transfer data to the Local Agent in bursts of this value., bit(s):11:8, default(0), access(RW)*/
	{"READ_EN",         7,1     },  /*,"The DMA will read data from the global address space and write it into the local address space., bit(s):7, default(0), access(RW)*/
	{"SRC_ADDR_MODE",   5,2     },  /*,"Source Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):6:5, default(0), access(RW)*/
	{"SRC_LINK_LIST",   4,1     },  /*,"Source Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):4, default(0), access(RW)*/
	{"WRITE_EN",        3,1     },  /*,"The DMA will read data from the local address space and write it into the global address space., bit(s):3, default(0), access(RW)*/
	{"DST_ADDR_MODE",   1,2     },  /*,"Destination Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):2:1, default(0), access(RW)*/
	{"DST_LINK_LIST",   0,1     },  /*,"Destination Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):0, default(0), access(RW)*/
    {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_SRCDMA_START_ALIAS_REG[] =
{
     { "SRCDMA_ALIAS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_SRCDMA_BOT_REG[] =
{
     { "SRCDMA_BOT",         2, 30  }, /* Source Buffer Bottom.  32-bit aligned address marking the bottom of a circular-source-buffer.*/
     { "SRC_CIRBUF_SHARE",   0, 2  },  /* Source Circular-Buffer Pointer-Sharing Counter.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_SRCDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_DSTDMA_BOT_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_DSTDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_03_DSTDMA_SIZE_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
static const struct EAS_RegBits g_csr_DMA_04_CUR_DESCR_REG[] =
{
     { "CURDESC",        0, 32  },   /* Current DMA descriptor for Linked List Mode Only.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_NEXT_DESCR_REG[] =
{
     { "NEXTDESC",                  2, 30  }, /* Next Descriptor Address.*/
     { "DEST_CIRBUF_PTR_ENABLE",    1,1},
     { "SRC_CIRBUF_PTR_ENABLE",     0,1},
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_SRCDMA_START_REG[] =
{
     { "SRCDMA_START",         0, 32  }, /* This is also the current address pointer into the source buffer (read-pointer).*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_DSTDMA_START_REG[] =
{
     { "DSTDMA_START",         0, 32  }, /* This is also the current address pointer into the destination buffer (write-pointer).  .*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_SRCDMA_SIZE_REG[] =
{
     { "SRCDMA_SIZE",         0, 32  }, /* Total size of the block of data (in bytes) to be read from the source location.  This register is also updated by hardware as the DMA transfers data */
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_FLAGS_MODE_REG[] =
{
	{"ACTIVE_DMA",      31,1    },   /*1: DMA context is active (has been started but has not finished). 0: DMA context is not active., bit(s):31, default(0), access(RO) */
	{"SRC_INT",         30,1    },  /*Interrupt when the current (active context) transfer has finished (source byte counter reaches zero) or when in circular-buffer addressing mode the circular buffer is empty.  1: enable interrupt 0: do not interrupt, bit(s):30, default(0), access(RW)"*/
	{"DST_INT",         29,1    },  /*Interrupt when the current (active context) transfer has finished (destination byte counter reaches zero) or when in circular-buffer addressing mode and the circular buffer is full. 1: enable interrupt 0: do not interrupt, bit(s):29, default(0), access(RW)"*/
	{"TERM",            28,1    },  /*Do not fetch the next descriptor when the current (active context) transfer has finished (byte counter reaches zero). 1: terminate 0: go read next descriptor , bit(s):28, default(0), access(RW) */
	{"RD_SWAP_ENDIAN",  27,1    },  /*Read Swap Endianism: This bit control whether the data on a DMA \"read\" (a transfer from global address space to local address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):27, default(0), access(RW)*/
	{"WR_SWAP_ENDIAN",  26,1    },  /*Write Swap Endianism: This bit controls whether the data on a DMA \"write\" (a transfer from local address space to global address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):26, default(0), access(RW)*/
	{"SRC_ENDIANISM",   25,1    },  /*Source Endianism: Indicates what the source endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):25, default(0), access(RW)*/
	{"DST_ENDIANISM",   24,1    },  /*,"Destination Endianism: Indicates what the destination endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):24, default(0), access(RW)*/
	{"SUBUNIT_ID",      20,4    },  /*,, default(0), access(RW)*/
	{"XDMA_GAP",        16,4    },  /*,"Between bursts (meaning the larger of the 2 burst sizes) the context is \"locked\" XDMA_GAP value XSI bus clocks., bit(s):19:16, default(0), access(RW)*/
	{"XBURST_SZ",       12,4    },  /*,"The DMA will transfer data to the Global Agent in bursts of this value., bit(s):15:12, default(0), access(RW)*/
	{"BURST_SZ",        8,4     },  /*,"The DMA will transfer data to the Local Agent in bursts of this value., bit(s):11:8, default(0), access(RW)*/
	{"READ_EN",         7,1     },  /*,"The DMA will read data from the global address space and write it into the local address space., bit(s):7, default(0), access(RW)*/
	{"SRC_ADDR_MODE",   5,2     },  /*,"Source Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):6:5, default(0), access(RW)*/
	{"SRC_LINK_LIST",   4,1     },  /*,"Source Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):4, default(0), access(RW)*/
	{"WRITE_EN",        3,1     },  /*,"The DMA will read data from the local address space and write it into the global address space., bit(s):3, default(0), access(RW)*/
	{"DST_ADDR_MODE",   1,2     },  /*,"Destination Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):2:1, default(0), access(RW)*/
	{"DST_LINK_LIST",   0,1     },  /*,"Destination Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):0, default(0), access(RW)*/
    {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_SRCDMA_START_ALIAS_REG[] =
{
     { "SRCDMA_ALIAS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_SRCDMA_BOT_REG[] =
{
     { "SRCDMA_BOT",         2, 30  }, /* Source Buffer Bottom.  32-bit aligned address marking the bottom of a circular-source-buffer.*/
     { "SRC_CIRBUF_SHARE",   0, 2  },  /* Source Circular-Buffer Pointer-Sharing Counter.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_SRCDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_DSTDMA_BOT_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_DSTDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_04_DSTDMA_SIZE_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
static const struct EAS_RegBits g_csr_DMA_05_CUR_DESCR_REG[] =
{
     { "CURDESC",        0, 32  },   /* Current DMA descriptor for Linked List Mode Only.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_NEXT_DESCR_REG[] =
{
     { "NEXTDESC",                  2, 30  }, /* Next Descriptor Address.*/
     { "DEST_CIRBUF_PTR_ENABLE",    1,1},
     { "SRC_CIRBUF_PTR_ENABLE",     0,1},
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_SRCDMA_START_REG[] =
{
     { "SRCDMA_START",         0, 32  }, /* This is also the current address pointer into the source buffer (read-pointer).*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_DSTDMA_START_REG[] =
{
     { "DSTDMA_START",         0, 32  }, /* This is also the current address pointer into the destination buffer (write-pointer).  .*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_SRCDMA_SIZE_REG[] =
{
     { "SRCDMA_SIZE",         0, 32  }, /* Total size of the block of data (in bytes) to be read from the source location.  This register is also updated by hardware as the DMA transfers data */
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_FLAGS_MODE_REG[] =
{
	{"ACTIVE_DMA",      31,1    },   /*1: DMA context is active (has been started but has not finished). 0: DMA context is not active., bit(s):31, default(0), access(RO) */
	{"SRC_INT",         30,1    },  /*Interrupt when the current (active context) transfer has finished (source byte counter reaches zero) or when in circular-buffer addressing mode the circular buffer is empty.  1: enable interrupt 0: do not interrupt, bit(s):30, default(0), access(RW)"*/
	{"DST_INT",         29,1    },  /*Interrupt when the current (active context) transfer has finished (destination byte counter reaches zero) or when in circular-buffer addressing mode and the circular buffer is full. 1: enable interrupt 0: do not interrupt, bit(s):29, default(0), access(RW)"*/
	{"TERM",            28,1    },  /*Do not fetch the next descriptor when the current (active context) transfer has finished (byte counter reaches zero). 1: terminate 0: go read next descriptor , bit(s):28, default(0), access(RW) */
	{"RD_SWAP_ENDIAN",  27,1    },  /*Read Swap Endianism: This bit control whether the data on a DMA \"read\" (a transfer from global address space to local address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):27, default(0), access(RW)*/
	{"WR_SWAP_ENDIAN",  26,1    },  /*Write Swap Endianism: This bit controls whether the data on a DMA \"write\" (a transfer from local address space to global address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):26, default(0), access(RW)*/
	{"SRC_ENDIANISM",   25,1    },  /*Source Endianism: Indicates what the source endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):25, default(0), access(RW)*/
	{"DST_ENDIANISM",   24,1    },  /*,"Destination Endianism: Indicates what the destination endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):24, default(0), access(RW)*/
	{"SUBUNIT_ID",      20,4    },  /*,, default(0), access(RW)*/
	{"XDMA_GAP",        16,4    },  /*,"Between bursts (meaning the larger of the 2 burst sizes) the context is \"locked\" XDMA_GAP value XSI bus clocks., bit(s):19:16, default(0), access(RW)*/
	{"XBURST_SZ",       12,4    },  /*,"The DMA will transfer data to the Global Agent in bursts of this value., bit(s):15:12, default(0), access(RW)*/
	{"BURST_SZ",        8,4     },  /*,"The DMA will transfer data to the Local Agent in bursts of this value., bit(s):11:8, default(0), access(RW)*/
	{"READ_EN",         7,1     },  /*,"The DMA will read data from the global address space and write it into the local address space., bit(s):7, default(0), access(RW)*/
	{"SRC_ADDR_MODE",   5,2     },  /*,"Source Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):6:5, default(0), access(RW)*/
	{"SRC_LINK_LIST",   4,1     },  /*,"Source Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):4, default(0), access(RW)*/
	{"WRITE_EN",        3,1     },  /*,"The DMA will read data from the local address space and write it into the global address space., bit(s):3, default(0), access(RW)*/
	{"DST_ADDR_MODE",   1,2     },  /*,"Destination Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):2:1, default(0), access(RW)*/
	{"DST_LINK_LIST",   0,1     },  /*,"Destination Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):0, default(0), access(RW)*/
    {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_SRCDMA_START_ALIAS_REG[] =
{
     { "SRCDMA_ALIAS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_SRCDMA_BOT_REG[] =
{
     { "SRCDMA_BOT",         2, 30  }, /* Source Buffer Bottom.  32-bit aligned address marking the bottom of a circular-source-buffer.*/
     { "SRC_CIRBUF_SHARE",   0, 2  },  /* Source Circular-Buffer Pointer-Sharing Counter.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_SRCDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_DSTDMA_BOT_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_DSTDMA_TOP_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
static const struct EAS_RegBits g_csr_DMA_05_DSTDMA_SIZE_REG[] =
{
     { "ALL_BITS",         0, 32  }, /* Fill this out later as needed.*/
     {NULL}
};
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */


/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
//SAMPLE CODE:
//static const struct EAS_RegBits g_csr_gen3_tsi_INTERRUPT[] =
//{
//        {"reserved3",          25, 7, "Reserved", NULL},
//    {"COMPARE_SYS",        24, 1, "The running value in System Time counter matched the desired compare setting", NULL },
//        {"reserved2",          18, 6, "Reserved", NULL},
//    {"CAPTURE_SYT2",       17, 1, "The valid timestamp was captured in System Time capture register 2 (for received packets on Ethernet)", NULL },
//    {"CAPTURE_SYT1",       16, 1, "The valid timestamp was captured in System Time capture register 1 (for transmitted packets on Ethernet)", NULL},
//        {"reserved1",          14, 2, "Reserved", NULL},
//    {"COMPARE_6",          13, 1, "The running value in STC counter of Channel 6 matched the desired compare setting", NULL },
//    {"COMPARE_5",          12, 1, "The running value in STC counter of Channel 5 matched the desired compare setting", NULL },
//    {"COMPARE_4",          11, 1, "The running value in STC counter of Channel 4 matched the desired compare setting", NULL },
//    {"COMPARE_3",          10, 1, "The running value in STC counter of Channel 3 matched the desired compare setting", NULL },
//    {"COMPARE_2",           9, 1, "The running value in STC counter of Channel 2 matched the desired compare setting", NULL },
//    {"COMPARE_1",           8, 1, "The running value in STC counter of Channel 1 matched the desired compare setting", NULL },
//        {"reserved0",           0, 8, "Reserved", NULL},
//    { NULL,0,0,"",NULL }    /* NULL Terminated */
//};
//

#define GEN3_MSPOD_GLOBAL   0x000
#define GEN3_MSPOD_RX       0x080
#define GEN3_MSPOD_TX       0x0C0
#define GEN3_1394_OUT       0x100
#define GEN3_1394_IN        0x140
#define GEN3_P2P_DMA        0x180
#define GEN3_GFX_DMA        0x1C0


/****** Local Register definitions *****/

static const struct EAS_Register g_csr_gen3_MSPOD[] =
{
	{"MS_HIF_CNTL",     GEN3_MSPOD_GLOBAL + 0x00,     NULL,       "MS-CableCARD Host Interface Control Register" },
	{"MS_HIF_STAT",     GEN3_MSPOD_GLOBAL + 0x04,     NULL,       "MS-CableCARD Host Interface Status Register" },
	{"MS_HIF_IER",      GEN3_MSPOD_GLOBAL + 0x08,     NULL,       "MS-CableCARD Host Interface Interrupt Enable Register" },
	{"MS_HIF_ISR",      GEN3_MSPOD_GLOBAL + 0x0C,     NULL,       "MS-CableCARD Host Interface Interrupt Status Register" },
//	{"RESERVED_10",     GEN3_MSPOD_GLOBAL + 0x10,     NULL,       "Reserved" },
//	{"RESERVED_14",     GEN3_MSPOD_GLOBAL + 0x14,     NULL,       "Reserved" },
	{"MS_HIF_RXDROP",   GEN3_MSPOD_GLOBAL + 0x18,     NULL,       "MS-CableCARD Host Interface Rx Drops" },
	{"CDMA_1394_IER",   GEN3_MSPOD_GLOBAL + 0x20,     g_csr_CDMA_1394_INT_ENABLE_REG,       "UDMA 1394 Interface Interrupt Enable Register" },
	{"CDMA_1394_ISR",   GEN3_MSPOD_GLOBAL + 0x24,     g_csr_CDMA_1394_INT_STATUS_REG,       "UDMA 1394 Interface Interrupt Status Register" },
	{"CDMA_P2P_IER",    GEN3_MSPOD_GLOBAL + 0x28,     NULL,       "UDMA P2P Interrupt Enable Register" },
	{"CDMA_P2P_ISR",    GEN3_MSPOD_GLOBAL + 0x2C,     NULL,       "UDMA P2P Interrupt Status Register" },

//  DMA has 6 sets of identical registers corresponding to 6 contexts. Each context occupies 40H register space as assigned below:
//  Context 0 (MSPOD receive):      80H -> BFH ################################################################################
//	{"MSPOD_RX_RESERVED_00",     GEN3_MSPOD_RX + 0x00,     NULL,       "RESERVED" },
//	{"MSPOD_RX_RESERVED_04",     GEN3_MSPOD_RX + 0x04,     NULL,       "RESERVED" },
	{"MSPOD_RX_CURR_DESCR",      GEN3_MSPOD_RX + 0x08,     g_csr_DMA_00_CUR_DESCR_REG,         "OFFSET 0x08  | Current Descriptor Address Pointer" },
	{"MSPOD_RX_NEXT_DESCR",      GEN3_MSPOD_RX + 0x0C,     g_csr_DMA_00_NEXT_DESCR_REG,        "OFFSET 0x0C  | Next Descriptor Address Pointer" },
	{"MSPOD_RX_SRCDMA_START",    GEN3_MSPOD_RX + 0x10,     g_csr_DMA_00_SRCDMA_START_REG,      "OFFSET 0x10  | Start Address of the Source DMA buffer" },
	{"MSPOD_RX_DSTDMA_START",    GEN3_MSPOD_RX + 0x14,     g_csr_DMA_00_DSTDMA_START_REG,      "OFFSET 0x14  | Start Address of the Source DMA buffer" },
	{"MSPOD_RX_SRCDMA_SIZE",     GEN3_MSPOD_RX + 0x18,     g_csr_DMA_00_DSTDMA_START_REG,      "OFFSET 0x18  | Num of data bytes to be read from the source location" },
	{"MSPOD_RX_FLAGS_MODE",      GEN3_MSPOD_RX + 0x1C,     g_csr_DMA_00_FLAGS_MODE_REG,        "OFFSET 0x1C  | Miscellaneous Control/Status" },
	{"MSPOD_RX_SRCDMA_START_A",  GEN3_MSPOD_RX + 0x20,     g_csr_DMA_00_SRCDMA_START_ALIAS_REG,"An alias of SRCDMA_START" },
	{"MSPOD_RX_SRCDMA_BOT",      GEN3_MSPOD_RX + 0x24,     g_csr_DMA_00_SRCDMA_BOT_REG,        "OFFSET 0x24  | Bottom-address of the source circular-buffer" },
	{"MSPOD_RX_SRCDMA_TOP",      GEN3_MSPOD_RX + 0x28,     g_csr_DMA_00_SRCDMA_TOP_REG,        "OFFSET 0x28  | Top-address of the source circular-buffer" },
	{"MSPOD_RX_DSTDMA_BOT",      GEN3_MSPOD_RX + 0x2C,     g_csr_DMA_00_DSTDMA_BOT_REG,        "OFFSET 0x2C  | Bottom-address of the destination circular-buffer" },
	{"MSPOD_RX_DSTDMA_TOP",      GEN3_MSPOD_RX + 0x30,     g_csr_DMA_00_DSTDMA_BOT_REG,        "OFFSET 0x30  | Top-address of the destination circular-buffer" },
	{"MSPOD_RX_DSTDMA_SIZE",     GEN3_MSPOD_RX + 0x34,     g_csr_DMA_00_DSTDMA_SIZE_REG,       "OFFSET 0x34  | Num of data bytes to be read from the destination location" },
//	{"MSPOD_RX_RESERVED_38",     GEN3_MSPOD_RX + 0x38,     NULL,       "RESERVED" },
//	{"MSPOD_RX_RESERVED_3C",     GEN3_MSPOD_RX + 0x3C,     NULL,       "RESERVED" },

//  Context 1 (MSPOD transmit):    C0H -> FFH ################################################################################
//	{"MSPOD_TX_RESERVED_00",     GEN3_MSPOD_TX + 0x00,     NULL,       "RESERVED" },
//	{"MSPOD_TX_RESERVED_04",     GEN3_MSPOD_TX + 0x04,     NULL,       "RESERVED" },
	{"MSPOD_TX_CURR_DESCR",      GEN3_MSPOD_TX + 0x08,     g_csr_DMA_01_CUR_DESCR_REG,         "OFFSET 0x08  | Current Descriptor Address Pointer" },
	{"MSPOD_TX_NEXT_DESCR",      GEN3_MSPOD_TX + 0x0C,     g_csr_DMA_01_NEXT_DESCR_REG,        "OFFSET 0x0C  | Next Descriptor Address Pointer" },
	{"MSPOD_TX_SRCDMA_START",    GEN3_MSPOD_TX + 0x10,     g_csr_DMA_01_SRCDMA_START_REG,      "OFFSET 0x10  | Start Address of the Source DMA buffer" },
	{"MSPOD_TX_DSTDMA_START",    GEN3_MSPOD_TX + 0x14,     g_csr_DMA_01_DSTDMA_START_REG,      "OFFSET 0x14  | Start Address of the Source DMA buffer" },
	{"MSPOD_TX_SRCDMA_SIZE",     GEN3_MSPOD_TX + 0x18,     g_csr_DMA_01_DSTDMA_START_REG,      "OFFSET 0x18  | Num of data bytes to be read from the source location" },
	{"MSPOD_TX_FLAGS_MODE",      GEN3_MSPOD_TX + 0x1C,     g_csr_DMA_01_FLAGS_MODE_REG,        "OFFSET 0x1C  | Miscellaneous Control/Status" },
	{"MSPOD_TX_SRCDMA_START_A",  GEN3_MSPOD_TX + 0x20,     g_csr_DMA_01_SRCDMA_START_ALIAS_REG,"An alias of SRCDMA_START" },
	{"MSPOD_TX_SRCDMA_BOT",      GEN3_MSPOD_TX + 0x24,     g_csr_DMA_01_SRCDMA_BOT_REG,        "OFFSET 0x24  | Bottom-address of the source circular-buffer" },
	{"MSPOD_TX_SRCDMA_TOP",      GEN3_MSPOD_TX + 0x28,     g_csr_DMA_01_SRCDMA_TOP_REG,        "OFFSET 0x28  | Top-address of the source circular-buffer" },
	{"MSPOD_TX_DSTDMA_BOT",      GEN3_MSPOD_TX + 0x2C,     g_csr_DMA_01_DSTDMA_BOT_REG,        "OFFSET 0x2C  | Bottom-address of the destination circular-buffer" },
	{"MSPOD_TX_DSTDMA_TOP",      GEN3_MSPOD_TX + 0x30,     g_csr_DMA_01_DSTDMA_BOT_REG,        "OFFSET 0x30  | Top-address of the destination circular-buffer" },
	{"MSPOD_TX_DSTDMA_SIZE",     GEN3_MSPOD_TX + 0x34,     g_csr_DMA_01_DSTDMA_SIZE_REG,       "OFFSET 0x34  | Num of data bytes to be read from the destination location" },
//	{"MSPOD_TX_RESERVED_38",     GEN3_MSPOD_TX + 0x38,     NULL,       "RESERVED" },
//	{"MSPOD_TX_RESERVED_3C",     GEN3_MSPOD_TX + 0x3C,     NULL,       "RESERVED" },

//  Context 2 (1394 out):           100H -> 13FH ################################################################################
//	{"1394_OUT_RESERVED_00",     GEN3_1394_OUT + 0x00,     NULL,       "RESERVED" },
//	{"1394_OUT_RESERVED_04",     GEN3_1394_OUT + 0x04,     NULL,       "RESERVED" },
	{"1394_OUT_CURR_DESCR",      GEN3_1394_OUT + 0x08,     g_csr_DMA_02_CUR_DESCR_REG,       	"OFFSET 0x08  | Current Descriptor Address Pointer" },
	{"1394_OUT_NEXT_DESCR",      GEN3_1394_OUT + 0x0C,     g_csr_DMA_02_NEXT_DESCR_REG,       	"OFFSET 0x0C  | Next Descriptor Address Pointer" },
	{"1394_OUT_SRCDMA_START",    GEN3_1394_OUT + 0x10,     g_csr_DMA_02_SRCDMA_START_REG,       "OFFSET 0x10  | Start Address of the Source DMA buffer" },
	{"1394_OUT_DSTDMA_START",    GEN3_1394_OUT + 0x14,     g_csr_DMA_02_DSTDMA_START_REG,       "OFFSET 0x14  | Start Address of the Source DMA buffer" },
	{"1394_OUT_SRCDMA_SIZE",     GEN3_1394_OUT + 0x18,     g_csr_DMA_02_DSTDMA_START_REG,       "OFFSET 0x18  | Num of data bytes to be read from the source location" },
	{"1394_OUT_FLAGS_MODE",      GEN3_1394_OUT + 0x1C,     g_csr_DMA_02_FLAGS_MODE_REG,       	"OFFSET 0x1C  | Miscellaneous Control/Status" },
	{"1394_OUT_SRCDMA_START_A",  GEN3_1394_OUT + 0x20,     g_csr_DMA_02_SRCDMA_START_ALIAS_REG, "OFFSET 0x20  | An alias of SRCDMA_START" },
	{"1394_OUT_SRCDMA_BOT",      GEN3_1394_OUT + 0x24,     g_csr_DMA_02_SRCDMA_BOT_REG,       	"OFFSET 0x24  | Bottom-address of the source circular-buffer" },
	{"1394_OUT_SRCDMA_TOP",      GEN3_1394_OUT + 0x28,     g_csr_DMA_02_SRCDMA_TOP_REG,       	"OFFSET 0x28  | Top-address of the source circular-buffer" },
	{"1394_OUT_DSTDMA_BOT",      GEN3_1394_OUT + 0x2C,     g_csr_DMA_02_DSTDMA_BOT_REG,       	"OFFSET 0x2C  | Bottom-address of the destination circular-buffer" },
	{"1394_OUT_DSTDMA_TOP",      GEN3_1394_OUT + 0x30,     g_csr_DMA_02_DSTDMA_BOT_REG,       	"OFFSET 0x30  | Top-address of the destination circular-buffer" },
	{"1394_OUT_DSTDMA_SIZE",     GEN3_1394_OUT + 0x34,     g_csr_DMA_02_DSTDMA_SIZE_REG,       	"OFFSET 0x34  | Num of data bytes to be read from the destination location" },
//	{"1394_OUT_RESERVED_38",     GEN3_1394_OUT + 0x38,     NULL,       "RESERVED" },
//	{"1394_OUT_RESERVED_3C",     GEN3_1394_OUT + 0x3C,     NULL,       "RESERVED" },

//  Context 3 (1394 in):                 140H -> 17FH  ################################################################################
//	{"1394_IN_RESERVED_00",     GEN3_1394_IN + 0x00,     NULL,       "RESERVED" },
//	{"1394_IN_RESERVED_04",     GEN3_1394_IN + 0x04,     NULL,       "RESERVED" },
	{"1394_IN_CURR_DESCR",      GEN3_1394_IN + 0x08,     g_csr_DMA_03_CUR_DESCR_REG,       	"OFFSET 0x08  | Current Descriptor Address Pointer" },
	{"1394_IN_NEXT_DESCR",      GEN3_1394_IN + 0x0C,     g_csr_DMA_03_NEXT_DESCR_REG,       	"OFFSET 0x0C  | Next Descriptor Address Pointer" },
	{"1394_IN_SRCDMA_START",    GEN3_1394_IN + 0x10,     g_csr_DMA_03_SRCDMA_START_REG,       	"OFFSET 0x10  | Start Address of the Source DMA buffer" },
	{"1394_IN_DSTDMA_START",    GEN3_1394_IN + 0x14,     g_csr_DMA_03_DSTDMA_START_REG,       	"OFFSET 0x14  | Start Address of the Source DMA buffer" },
	{"1394_IN_SRCDMA_SIZE",     GEN3_1394_IN + 0x18,     g_csr_DMA_03_DSTDMA_START_REG,       	"OFFSET 0x18  | Num of data bytes to be read from the source location" },
	{"1394_IN_FLAGS_MODE",      GEN3_1394_IN + 0x1C,     g_csr_DMA_03_FLAGS_MODE_REG,       	"OFFSET 0x1C  | Miscellaneous Control/Status" },
	{"1394_IN_SRCDMA_START_A",  GEN3_1394_IN + 0x20,     g_csr_DMA_03_SRCDMA_START_ALIAS_REG,   "OFFSET 0x20  | An alias of SRCDMA_START" },
	{"1394_IN_SRCDMA_BOT",      GEN3_1394_IN + 0x24,     g_csr_DMA_03_SRCDMA_BOT_REG,       	"OFFSET 0x24  | Bottom-address of the source circular-buffer" },
	{"1394_IN_SRCDMA_TOP",      GEN3_1394_IN + 0x28,     g_csr_DMA_03_SRCDMA_TOP_REG,       	"OFFSET 0x28  | Top-address of the source circular-buffer" },
	{"1394_IN_DSTDMA_BOT",      GEN3_1394_IN + 0x2C,     g_csr_DMA_03_DSTDMA_BOT_REG,       	"OFFSET 0x2C  | Bottom-address of the destination circular-buffer" },
	{"1394_IN_DSTDMA_TOP",      GEN3_1394_IN + 0x30,     g_csr_DMA_03_DSTDMA_BOT_REG,       	"OFFSET 0x30  | Top-address of the destination circular-buffer" },
	{"1394_IN_DSTDMA_SIZE",     GEN3_1394_IN + 0x34,     g_csr_DMA_03_DSTDMA_SIZE_REG,       	"OFFSET 0x34  | Num of data bytes to be read from the destination location" },
//	{"1394_IN_RESERVED_38",     GEN3_1394_IN + 0x38,     NULL,       "RESERVED" },
//	{"1394_IN_RESERVED_3C",     GEN3_1394_IN + 0x3C,     NULL,       "RESERVED" },

//  Context 4 (P2P DMA):             180H -> 1BFH  ################################################################################
//	{"P2P_RESERVED_00",     	GEN3_P2P_DMA + 0x00,     NULL,       "RESERVED" },
//	{"P2P_RESERVED_04",     	GEN3_P2P_DMA + 0x04,     NULL,       "RESERVED" },
	{"P2P_CURR_DESCR",      	GEN3_P2P_DMA + 0x08,     g_csr_DMA_04_CUR_DESCR_REG,       	"OFFSET 0x08  | Current Descriptor Address Pointer" },
	{"P2P_NEXT_DESCR",      	GEN3_P2P_DMA + 0x0C,     g_csr_DMA_04_NEXT_DESCR_REG,       	"OFFSET 0x0C  | Next Descriptor Address Pointer" },
	{"P2P_SRCDMA_START",    	GEN3_P2P_DMA + 0x10,     g_csr_DMA_04_SRCDMA_START_REG,       "OFFSET 0x10  | Start Address of the Source DMA buffer" },
	{"P2P_DSTDMA_START",    	GEN3_P2P_DMA + 0x14,     g_csr_DMA_04_DSTDMA_START_REG,       "OFFSET 0x14  | Start Address of the Source DMA buffer" },
	{"P2P_SRCDMA_SIZE",     	GEN3_P2P_DMA + 0x18,     g_csr_DMA_04_DSTDMA_START_REG,      	"OFFSET 0x18  | Num of data bytes to be read from the source location" },
	{"P2P_FLAGS_MODE",      	GEN3_P2P_DMA + 0x1C,     g_csr_DMA_04_FLAGS_MODE_REG,       	"OFFSET 0x1C  | Miscellaneous Control/Status" },
	{"P2P_SRCDMA_START_A",  	GEN3_P2P_DMA + 0x20,     g_csr_DMA_04_SRCDMA_START_ALIAS_REG,  "OFFSET 0x20  | An alias of SRCDMA_START" },
	{"P2P_SRCDMA_BOT",      	GEN3_P2P_DMA + 0x24,     g_csr_DMA_04_SRCDMA_BOT_REG,       	"OFFSET 0x24  | Bottom-address of the source circular-buffer" },
	{"P2P_SRCDMA_TOP",      	GEN3_P2P_DMA + 0x28,     g_csr_DMA_04_SRCDMA_TOP_REG,       	"OFFSET 0x28  | Top-address of the source circular-buffer" },
	{"P2P_DSTDMA_BOT",      	GEN3_P2P_DMA + 0x2C,     g_csr_DMA_04_DSTDMA_BOT_REG,       	"OFFSET 0x2C  | Bottom-address of the destination circular-buffer" },
	{"P2P_DSTDMA_TOP",      	GEN3_P2P_DMA + 0x30,     g_csr_DMA_04_DSTDMA_BOT_REG,       	"OFFSET 0x30  | Top-address of the destination circular-buffer" },
	{"P2P_DSTDMA_SIZE",     	GEN3_P2P_DMA + 0x34,     g_csr_DMA_04_DSTDMA_SIZE_REG,       	"OFFSET 0x34  | Num of data bytes to be read from the destination location" },
//	{"P2P_RESERVED_38",     	GEN3_P2P_DMA + 0x38,     NULL,       "RESERVED" },
//	{"P2P_RESERVED_3C",     	GEN3_P2P_DMA + 0x3C,     NULL,       "RESERVED" },

//  Context 5 (GFX DMA):            1C0H -> 1FFH  ################################################################################
//	{"GFX_DMA_RESERVED_00",     GEN3_GFX_DMA + 0x00,     NULL,       "RESERVED" },
//	{"GFX_DMA_RESERVED_04",     GEN3_GFX_DMA + 0x04,     NULL,       "RESERVED" },
	{"GFX_DMA_CURR_DESCR",      GEN3_GFX_DMA + 0x08,     g_csr_DMA_05_CUR_DESCR_REG,       	"OFFSET 0x08  | Current Descriptor Address Pointer" },
	{"GFX_DMA_NEXT_DESCR",      GEN3_GFX_DMA + 0x0C,     g_csr_DMA_05_NEXT_DESCR_REG,       	"OFFSET 0x0C  | Next Descriptor Address Pointer" },
	{"GFX_DMA_SRCDMA_START",    GEN3_GFX_DMA + 0x10,     g_csr_DMA_05_SRCDMA_START_REG,       "OFFSET 0x10  | Start Address of the Source DMA buffer" },
	{"GFX_DMA_DSTDMA_START",    GEN3_GFX_DMA + 0x14,     g_csr_DMA_05_DSTDMA_START_REG,       "OFFSET 0x14  | Start Address of the Source DMA buffer" },
	{"GFX_DMA_SRCDMA_SIZE",     GEN3_GFX_DMA + 0x18,     g_csr_DMA_05_DSTDMA_START_REG,       "OFFSET 0x18  | Num of data bytes to be read from the source location" },
	{"GFX_DMA_FLAGS_MODE",      GEN3_GFX_DMA + 0x1C,     g_csr_DMA_05_FLAGS_MODE_REG,       	"OFFSET 0x1C  | Miscellaneous Control/Status" },
	{"GFX_DMA_SRCDMA_START_A",  GEN3_GFX_DMA + 0x20,     g_csr_DMA_05_SRCDMA_START_ALIAS_REG, "OFFSET 0x20  | An alias of SRCDMA_START" },
	{"GFX_DMA_SRCDMA_BOT",      GEN3_GFX_DMA + 0x24,     g_csr_DMA_05_SRCDMA_BOT_REG,       	"OFFSET 0x24  | Bottom-address of the source circular-buffer" },
	{"GFX_DMA_SRCDMA_TOP",      GEN3_GFX_DMA + 0x28,     g_csr_DMA_05_SRCDMA_TOP_REG,       	"OFFSET 0x28  | Top-address of the source circular-buffer" },
	{"GFX_DMA_DSTDMA_BOT",      GEN3_GFX_DMA + 0x2C,     g_csr_DMA_05_DSTDMA_BOT_REG,       	"OFFSET 0x2C  | Bottom-address of the destination circular-buffer" },
	{"GFX_DMA_DSTDMA_TOP",      GEN3_GFX_DMA + 0x30,     g_csr_DMA_05_DSTDMA_BOT_REG,       	"OFFSET 0x30  | Top-address of the destination circular-buffer" },
	{"GFX_DMA_DSTDMA_SIZE",     GEN3_GFX_DMA + 0x34,     g_csr_DMA_05_DSTDMA_SIZE_REG,       	"OFFSET 0x34  | Num of data bytes to be read from the destination location" },
//	{"GFX_DMA_RESERVED_38",     GEN3_GFX_DMA + 0x38,     NULL,       "RESERVED" },
//	{"GFX_DMA_RESERVED_3C",     GEN3_GFX_DMA + 0x3C,     NULL,       "RESERVED" },

	{NULL,0,NULL,"",NULL } /* NULL Terminated */
};
#endif /* !SVEN_INTERNAL_BUILD */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */
/* ---------------------------------------------------------------------------------- */

static const struct SVEN_Module_EventSpecific g_gen3_mspod_specific_events[] =
{
    { "INIT", 1, "\tMSPOD Initialized!", NULL },  //init event
    { "WRITE_START", 2, "\tBuffer len = %d; Extended Channel = %d; Hardware Header = 0x%x; Padding = 0x%x; Kernel Transmission = 0x%x; ", NULL },  //write start
    { "WRITE_END", 3, "\tMSPOD Write End", NULL },  //write end
    { "READ_START", 4, "\tTimeout in ms = %d; Network Transmission = %d; Read Full = %d ", NULL },  //read start
    { "READ_END", 5, "\tBuffers left =%d", NULL },  //read end
    { "VNI_WRITE_START", 6, "\tBuffer len = %d; Extended Channel = %d; Hardware Header = 0x%x; Padding = 0x%x; Kernel Transmission = 0x%x;", NULL },  //write start
    { "VNI_WRITE_END", 7, "\tVNI_MSPOD Write End", NULL },  //write end
    { "VNI_READ_START", 8, "\tVNI_MSPOD Read Start", NULL },  //read start
    { "VNI_READ_END", 9, "\tVNI_MSPOD Read End", NULL },  //read end
    { "ISR", 10, "\tISR", NULL },  //ISR routine
    { "IR_DETECT", 11, "\tIR bit detected", NULL },  //IR bit detected
    { "TX_TIMEOUT", 12, "\tTransmit timeout", NULL },  //Transmit timeout
    { "RX_TIMEOUT", 13, "\tReceive timeout", NULL },  //Receive timeout
    { "CTU_FAILURE", 14, "\tCopy to user failure", NULL },  //Copy to user failure
    { "RX_NOTIFIED", 16, "\tRx ISR notification received", NULL },  //Rx ISR notification received
    { "RX_ISR_START", 17, "\tData available = %d; Data len = %d; Extended Channel = %d; Hardware Header = 0x%x ", NULL },  //Rx ISR received
    { "RX_ISR_END", 18, "\tDone with Rx ISR ", NULL },  //Done with Rx ISR
    { "RX_NETWORK", 19, "\tNetwork Data received", NULL },  //Network Data received
    { "CLOSE_START", 20, "\tClose has started", NULL },  //Close has started
    { "OPEN_START", 21, "\tOpen has started", NULL },  //Open has started 
    { "OPEN_END", 22, "\tOpen has finished", NULL },  //Open has finished  
    { "CLOSE_END", 23, "\tClose has finished", NULL },  //Close has finished
    { "SET_FLOW_ID", 24, "\tSet flow ID called", NULL },  //Set flow ID called  
    { "GET_FLOW_ID", 25, "\tGet flow ID called", NULL },  //Get flow ID called
    { "SCTL_ENABLE", 26, "\tSCTL Enable Called", NULL },  //SCTL Enable called
    { "HOST_RESET", 27, "\tHost Reset Called", NULL },  //Host Reset called
    { "TX_ISR", 28, "\tTransmit Interrupt", NULL },  //ISR routine  
    { "START_OF_DATA", 29, "\tUnexpected start of data", NULL },  //IR bit detected
    { "OVERFLOW", 30, "\tUnexpected Overflow", NULL },  //IR bit detected   
    { "WRITE_LOCK", 31, "\tMSPOD Write Lock", NULL },  //write end 
    { "IOCTL_START", 32, "\tMSPOD Write Lock", NULL },  //write end 
    { "IOCTL_END", 33, "\tMSPOD Write Lock", NULL },  //write end 
    { NULL, 0, "", NULL }
};

static const struct ModuleReverseDefs g_gen3_mspod_sven_module =
{
    "GEN3_MSPOD",
    SVEN_module_GEN3_MSPOD,
    0x0000C000,						/* TODO: fill in actual range*/
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen3_MSPOD,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "MSPOD: Third Generation Multi-Stream Host IF",
    g_gen3_mspod_specific_events,
    NULL /* extension list */
};
