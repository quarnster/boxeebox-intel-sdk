/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_unit.h"
#endif

static const struct EAS_RegBits g_csr_vdc_UPCONFIG [] = {
  { "reserved_31_18",   18,   14},  /*  */
  { "Chroma_Key_Enab",  17,    1},  /*  */
  { "GAMMA_BYPASS",     16,    1},  /*  */
  { "reserved_15_7",     7,    9},  /* Reserved */
  { "CBCR_ISGN",         6,    1},  /* 0:CbCr range 0-1023;  1:CbCr range -512 to 511  */
  { "CSC_EN",            5,    1},  /* Color Space conversion 0:Disable CSC (default), 1:Enable CSC */
  { "reserved_4_0",      0,    1},  /* Reserved */
  { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_vdc_UPCOMD [] = {
  { "SCALING_EN",       31,    1},  /* */
  { "reserved_30_28",   28,    3},  /* */
  { "CLKEN",            27,    1},  /* */
  { "MSB_SHDW_EN",      26,    1},  /* */
  { "LINE_DOUBLE",      25,    1},  /* */
  { "PXL_DOUBLE",       24,    1},  /* */
  { "CONST_ALPHA",      16,    8},  /* */
  { "reserved_15",      15,    1},  /* Reserved */
  { "VIDEO_FORMAT",     10,    5},  /* b00000 = pp YCbCr 4:2:2 8bit; b00001 = pp YCbCr 4:2:2 10bit*/
  { "SYNCFETCH_PARITY",  9,    1},  /* Reserved Must be 0 */
  { "FLIP_INV_FIELD",    8,    1},  /* Reserved Must be 0 */
  { "SYNCFETCH_ENBL",    7,    1},  /* Reserved Must be 0 */
  { "IGNORE_FLIP_MODE",  6,    1},  /* Reserved Must be 0 */
  { "reserved_5",        5,    1},  /* Reserved */
  { "REQ_LEN_256",       4,    1},  /*  */
  { "TG_SEL",            3,    1},  /* 0=TG0 (primary TG driving HDMI); 1=TG1 (TG driving NTSC/PAL encoder)*/
  { "LGCY_IMODE_EN",     2,    1},  /* Reserved Must be 0 */
  { "ACT_F",             1,    1},  /* Reserved Must be 0 */
  { "UP_ENBL",           0,    1},  /* Universal plane Enable */
  { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_vdc_POFF [] = {
  { "reserved_31_27",   27,    5},  /*  */
  { "CbCr_OFF",         16,   10}, /* Universal plane CbCr pixel offset */
  { "reserved_15_11",   11,    5}, /* Reserved */
  { "YRGB_OFF",          0,   10}, /* Universal plane Y/RGB pixel offset */
  { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_vdc_STRIDE [] = {
  { "reserved_31",      31,    1},  /*  */
  { "CbCr_STRIDE",      16,   15}, /* Universal plane CbCr Stride */
  { "IPHASE",           15,    1}, /* One if pixels start in odd location */
  { "YRGB_STRIDE",       0,   15}, /* Universal plane Y/RGB Stride */
  { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_vdc_PIPEACONFIG [] = {
  { "Pipe_Enable",      31,    1},  /*  */
  { "reserved_30_29",   29,    2},  /*  */
  { "Frame_start_delay",27,    2},  /*  */
  { "reserved_26",      26,    1},  /*  */
  { "Force_Border",     25,    1},  /*  */
  { "reserved_24",      24,    1},  /*  */
  { "Interlaced_mode",  21,    3},  /*  */
  { "tg0_comp_en",      20,    1},  /*  */
  { "Planes_off",       19,    1},  /*  */
  { "reserved_18_2",     2,   17},  /*  */
  { "Gamma_en",          1,    1},  /*  */
  { "PAC_DITHER_ENABLE", 0,    1},  /*  */
  { NULL }    /* NULL terminator */
};

static const struct EAS_RegBits g_csr_vdc_PIPEASTAT [] = {
  { "FIFO_A_Underrun",  31,    1},  /*  */
  { "reserved_30",      30,    1},  /*  */
  { "CRC_Error_en",     29,    1},  /*  */
  { "CRC_Done_en",      28,    1},  /*  */
  { "reserved_27_26",   26,    2},  /*  */
  { "Vertical_Sync_en", 25,    1},  /*  */
  { "Vertical_Blank_en",24,    1},  /*  */
  { "reserved_23_22",   22,    2},  /*  */
  { "Odd_Field_en",     21,    1},  /*  */
  { "Even_Field_en",    20,    1},  /*  */
  { "reserved_19",      19,    1},  /*  */
  { "reserved_18",      18,    1},  /*  */
  { "Framestart_en",    17,    1},  /*  */
  { "reserved_16_14",   14,    3},  /*  */
  { "CRC_Error",        13,    1},  /*  */
  { "CRC_Done",         12,    1},  /*  */
  { "reserved_11_10",   10,    2},  /*  */
  { "Vertical_Sync",     9,    1},  /*  */
  { "Vertical_Blank",    8,    1},  /*  */
  { "reserved_7_6",      6,    2},  /*  */
  { "Odd_Field",         5,    1},  /*  */
  { "Even_Field",        4,    1},  /*  */
  { "reserved_3",        3,    1},  /*  */
  { "reserved_2",        2,    1},  /*  */
  { "Framestart",        1,    1},  /*  */
  { "reserved_0",        0,    1},  /*  */
  { NULL }    /* NULL terminator */
};

static const struct EAS_Register g_csr_gen3_vdc[]= {
  /* Universal Pixel Plane 0 */
  {"UPCONFIG_0",      0x30164, g_csr_vdc_UPCONFIG, "UPP 0 Configuration",  NULL},
  {"UPCOMD_0",        0x30168, g_csr_vdc_UPCOMD,   "UPP 0 Command",        NULL},
  {"UPFLIPMODE_0",    0x3016c, NULL,            "UPP 0 Flip Mode",         NULL},
  {"UPFLIPDIS_0",     0x3000c, NULL,            "UPP 0 Flip Disable",      NULL},
  {"UPBLCONFIG_0",    0x30178, NULL,            "UPP 0 Blender Config",    NULL},
  {"UPBUF_YRGB_F0_0", 0x30100, NULL,            "UPP 0 Y/RGB field 0",     NULL},
  {"UPBUF_YRGB_F1_0", 0x30104, NULL,            "UPP 0 Y/RGB field 1",     NULL},
  {"UPBUF_CBCR_F0_0", 0x30108, NULL,            "UPP 0 CbCr  field 0",     NULL},
  {"UPBUF_CBCR_F1_0", 0x3010c, NULL,            "UPP 0 CbCr  field 1",     NULL},
  {"UPBUF_POFF_0",    0x30064, g_csr_vdc_POFF,  "UPP 0 Pixel Offset",      NULL},
  {"UP_STRIDE_0",     0x30118, g_csr_vdc_STRIDE,"UPP 0 Video Stride",      NULL},
  {"UPDWINPOS_0",     0x3012c, NULL,            "UPP 0 Destination Position", NULL},
  {"UPDWINSZ_0",      0x30130, NULL,            "UPP 0 Destination Size",  NULL},
  {"UPSWIDTH_0",      0x30134, NULL,            "UPP 0 Source Width",      NULL},
  {"UPSHEIGHT_0",     0x3013c, NULL,            "UPP 0 Source Height",     NULL},
  {"UPLCKEY_Y_0",     0x30140, NULL,            "UPP 0 L/C Keying Y/G",    NULL},
  {"UPLCKEY_CB_0",    0x30144, NULL,            "UPP 0 L/C Keying Cb/B",   NULL},
  {"UPLCKEY_CR_0",    0x30148, NULL,            "UPP 0 L/C Keying Cr/R",   NULL},
  {"UPCSCPC_0",       0x30200, NULL,            "UPP 0 CSC Clamp",         NULL},
  {"UPCSCYGOFF_0",    0x30204, NULL,            "UPP 0 CSC Y/G Offset",    NULL},
  {"UPCSCCBOFF_0",    0x30208, NULL,            "UPP 0 CSC Cb/B Offset",   NULL},
  {"UPCSCCROFF_0",    0x3020c, NULL,            "UPP 0 CSC Cr/R Offset",   NULL},
  {"UPCSC_C01_0",     0x30210, NULL,            "UPP 0 CSC Coefficient01", NULL},
  {"UPCSC_C23_0",     0x30214, NULL,            "UPP 0 CSC Coefficient23", NULL},
  {"UPCSC_C45_0",     0x30218, NULL,            "UPP 0 CSC Coefficient45", NULL},
  {"UPCSC_C67_0",     0x3021c, NULL,            "UPP 0 CSC Coefficient67", NULL},
  {"UPCSC_C8_0",      0x30220, NULL,            "UPP 0 CSC Coefficient8",  NULL},
  {"UPVGAMLUT_0",     0x30900, NULL,            "UPP 0 Gamma Correction",  NULL},
  {"DUPSTA_0",        0x30008, NULL,            "UPP 0 Status",            NULL},
  {"UPFDROP_0",       0x30170, NULL,            "UPP 0 Frame Drop Counter", NULL},
  {"UPFREPEAT_0",     0x30174, NULL,            "UPP 0 Frame Repeat Counter", NULL},

  /* Universal Pixel Plane 1 */
  {"UPCONFIG_1",      0x31164, g_csr_vdc_UPCONFIG, "UPP 1 Configuration",  NULL},
  {"UPCOMD_1",        0x31168, g_csr_vdc_UPCOMD,   "UPP 1 Command",        NULL},
  {"UPFLIPMODE_1",    0x3116c, NULL,            "UPP 1 Flip Mode",         NULL},
  {"UPFLIPDIS_1",     0x3100c, NULL,            "UPP 1 Flip Disable",      NULL},
  {"UPBLCONFIG_1",    0x31178, NULL,            "UPP 1 Blender Config",    NULL},
  {"UPBUF_YRGB_F0_1", 0x31100, NULL,            "UPP 1 Y/RGB field 0",     NULL},
  {"UPBUF_YRGB_F1_1", 0x31104, NULL,            "UPP 1 Y/RGB field 1",     NULL},
  {"UPBUF_CBCR_F0_1", 0x31108, NULL,            "UPP 1 CbCr  field 0",     NULL},
  {"UPBUF_CBCR_F1_1", 0x3110c, NULL,            "UPP 1 CbCr  field 1",     NULL},
  {"UPBUF_POFF_1",    0x31064, g_csr_vdc_POFF,  "UPP 1 Pixel Offset",      NULL},
  {"UP_STRIDE_1",     0x31118, g_csr_vdc_STRIDE,"UPP 1 Video Stride",      NULL},
  {"UPDWINPOS_1",     0x3112c, NULL,            "UPP 1 Destination Position", NULL},
  {"UPDWINSZ_1",      0x31130, NULL,            "UPP 1 Destination Size",  NULL},
  {"UPSWIDTH_1",      0x31134, NULL,            "UPP 1 Source Width",      NULL},
  {"UPSHEIGHT_1",     0x3113c, NULL,            "UPP 1 Source Height",     NULL},
  {"UPLCKEY_Y_1",     0x31140, NULL,            "UPP 1 L/C Keying Y/G",    NULL},
  {"UPLCKEY_CB_1",    0x31144, NULL,            "UPP 1 L/C Keying Cb/B",   NULL},
  {"UPLCKEY_CR_1",    0x31148, NULL,            "UPP 1 L/C Keying Cr/R",   NULL},
  {"UPCSCPC_1",       0x31200, NULL,            "UPP 1 CSC Clamp",         NULL},
  {"UPCSCYGOFF_1",    0x31204, NULL,            "UPP 1 CSC Y/G Offset",    NULL},
  {"UPCSCCBOFF_1",    0x31208, NULL,            "UPP 1 CSC Cb/B Offset",   NULL},
  {"UPCSCCROFF_1",    0x3120c, NULL,            "UPP 1 CSC Cr/R Offset",   NULL},
  {"UPCSC_C01_1",     0x31210, NULL,            "UPP 1 CSC Coefficient01", NULL},
  {"UPCSC_C23_1",     0x31214, NULL,            "UPP 1 CSC Coefficient23", NULL},
  {"UPCSC_C45_1",     0x31218, NULL,            "UPP 1 CSC Coefficient45", NULL},
  {"UPCSC_C67_1",     0x3121c, NULL,            "UPP 1 CSC Coefficient67", NULL},
  {"UPCSC_C8_1",      0x31220, NULL,            "UPP 1 CSC Coefficient8",  NULL},
  {"UPVGAMLUT_1",     0x31900, NULL,            "UPP 1 Gamma Correction",  NULL},
  {"DUPSTA_1",        0x31008, NULL,            "UPP 1 Status",            NULL},
  {"UPFDROP_1",       0x31170, NULL,            "UPP 1 Frame Drop Counter", NULL},
  {"UPFREPEAT_1",     0x31174, NULL,            "UPP 1 Frame Repeat Counter", NULL},

  /* Universal Pixel Plane 2 */
  {"UPCONFIG_2", 0x32164, g_csr_vdc_UPCONFIG,   "UPP 2 Configuration",     NULL},
  {"UPCOMD_2", 0x32168, g_csr_vdc_UPCOMD,       "UPP 2 Command",           NULL},
  {"UPFLIPMODE_2", 0x3216c, NULL,               "UPP 2 Flip Mode",         NULL},
  {"UPFLIPDIS_2", 0x3200c, NULL,                "UPP 2 Flip Disable",      NULL},
  {"UPBLCONFIG_2", 0x32178, NULL,               "UPP 2 Blender Config",    NULL},
  {"UPBUF_YRGB_F0_2", 0x32100, NULL,            "UPP 2 Y/RGB field 0",     NULL},
  {"UPBUF_YRGB_F1_2", 0x32104, NULL,            "UPP 2 Y/RGB field 1",     NULL},
  {"UPBUF_CBCR_F0_2", 0x32108, NULL,            "UPP 2 CbCr  field 0",     NULL},
  {"UPBUF_CBCR_F1_2", 0x3210c, NULL,            "UPP 2 CbCr  field 1",     NULL},
  {"UPBUF_POFF_2", 0x32064, g_csr_vdc_POFF,     "UPP 2 Pixel Offset",      NULL},
  {"UP_STRIDE_2", 0x32118, g_csr_vdc_STRIDE,    "UPP 2 Video Stride",      NULL},
  {"UPDWINPOS_2", 0x3212c, NULL,                "UPP 2 Destination Position", NULL},
  {"UPDWINSZ_2", 0x32130, NULL,                 "UPP 2 Destination Size",  NULL},
  {"UPSWIDTH_2", 0x32134, NULL,                 "UPP 2 Source Width",      NULL},
  {"UPSHEIGHT_2", 0x3213c, NULL,                "UPP 2 Source Height",     NULL},
  {"UPLCKEY_Y_2", 0x32140, NULL,                "UPP 2 L/C Keying Y/G",    NULL},
  {"UPLCKEY_CB_2", 0x32144, NULL,               "UPP 2 L/C Keying Cb/B",   NULL},
  {"UPLCKEY_CR_2", 0x32148, NULL,               "UPP 2 L/C Keying Cr/R",   NULL},
  {"UPCSCPC_2", 0x32200, NULL,                  "UPP 2 CSC Clamp",         NULL},
  {"UPCSCYGOFF_2", 0x32204, NULL,               "UPP 2 CSC Y/G Offset",    NULL},
  {"UPCSCCBOFF_2", 0x32208, NULL,               "UPP 2 CSC Cb/B Offset",   NULL},
  {"UPCSCCROFF_2", 0x3220c, NULL,               "UPP 2 CSC Cr/R Offset",   NULL},
  {"UPCSC_C10_2", 0x32210, NULL,                "UPP 2 CSC Coefficient01", NULL},
  {"UPCSC_C23_2", 0x32214, NULL,                "UPP 2 CSC Coefficient23", NULL},
  {"UPCSC_C45_2", 0x32218, NULL,                "UPP 2 CSC Coefficient45", NULL},
  {"UPCSC_C67_2", 0x3221c, NULL,                "UPP 2 CSC Coefficient67", NULL},
  {"UPCSC_C8_2", 0x32220, NULL,                 "UPP 2 CSC Coefficient8",  NULL},
  {"UPVGAMLUT_2", 0x32900, NULL,                "UPP 2 Gamma Correction",  NULL},
  {"DUPVSTA_2", 0x32008, NULL,                  "UPP 2 Status",            NULL},
  {"UPFDROP_2", 0x32170, NULL,                  "UPP 2 Frame Drop Counter", NULL},
  {"UPFREPEAT_2", 0x32174, NULL,                "UPP 2 Frame Repeat Counter", NULL},

  /* Universal Pixel Plane 3 */
  {"UPCONFIG_3", 0x33164, g_csr_vdc_UPCONFIG,   "UPP 3 Configuration",     NULL},
  {"UPCOMD_3", 0x33168, g_csr_vdc_UPCOMD,       "UPP 3 Command",           NULL},
  {"UPFLIPMODE_3", 0x3316c, NULL,               "UPP 3 Flip Mode",         NULL},
  {"UPFLIPDIS_3", 0x3300c, NULL,                "UPP 3 Flip Disable",      NULL},
  {"UPBLCONFIG_3", 0x33178, NULL,               "UPP 3 Blender Config",    NULL},
  {"UPBUF_YRGB_F0_3", 0x33100, NULL,            "UPP 3 Y/RGB field 0",     NULL},
  {"UPBUF_YRGB_F1_3", 0x33104, NULL,            "UPP 3 Y/RGB field 1",     NULL},
  {"UPBUF_CBCR_F0_3", 0x33108, NULL,            "UPP 3 CbCr  field 0",     NULL},
  {"UPBUF_CBCR_F1_3", 0x3310c, NULL,            "UPP 3 CbCr  field 1",     NULL},
  {"UPBUF_POFF_3", 0x33064, g_csr_vdc_POFF,     "UPP 3 Pixel Offset",      NULL},
  {"UP_STRIDE_3", 0x33118, g_csr_vdc_STRIDE,    "UPP 3 Video Stride",      NULL},
  {"UPDWINPOS_3", 0x3312c, NULL,                "UPP 3 Destination Position", NULL},
  {"UPDWINSZ_3", 0x33130, NULL,                 "UPP 3 Destination Size",  NULL},
  {"UPSWIDTH_3", 0x33134, NULL,                 "UPP 3 Source Width",      NULL},
  {"UPSHEIGHT_3", 0x3313c, NULL,                "UPP 3 Source Height",     NULL},
  {"UPLCKEY_Y_3", 0x33140, NULL,                "UPP 3 L/C Keying Y/G",    NULL},
  {"UPLCKEY_CB_3", 0x33144, NULL,               "UPP 3 L/C Keying Cb/B",   NULL},
  {"UPLCKEY_CR_3", 0x33148, NULL,               "UPP 3 L/C Keying Cr/R",   NULL},
  {"UPCSCPC_3", 0x33200, NULL,                  "UPP 3 CSC Clamp",         NULL},
  {"UPCSCYGOFF_3", 0x33204, NULL,               "UPP 3 CSC Y/G Offset",    NULL},
  {"UPCSCCBOFF_3", 0x33208, NULL,               "UPP 3 CSC Cb/B Offset",   NULL},
  {"UPCSCCROFF_3", 0x3320c, NULL,               "UPP 3 CSC Cr/R Offset",   NULL},
  {"UPCSC_C01_3", 0x33210, NULL,                "UPP 3 CSC Coefficient01", NULL},
  {"UPCSC_C23_3", 0x33214, NULL,                "UPP 3 CSC Coefficient23", NULL},
  {"UPCSC_C45_3", 0x33218, NULL,                "UPP 3 CSC Coefficient45", NULL},
  {"UPCSC_C67_3", 0x3321c, NULL,                "UPP 3 CSC Coefficient67", NULL},
  {"UPCSC_C8_3", 0x33220, NULL,                 "UPP 3 CSC Coefficient8",  NULL},
  {"UPVGAMLUT_3", 0x33900, NULL,                "UPP 3 Gamma Correction",  NULL},
  {"DUPSTA_3",  0x33008, NULL,                  "UPP 3 Status",            NULL},
  {"UPFDROP_3", 0x33170, NULL,                  "UPP 3 Frame Drop Counter", NULL},
  {"UPFREPEAT_3", 0x33174, NULL,                "UPP 3 Frame Repeat Counter", NULL},

  {"IAPCOMD_0",         0x10168, NULL,        "IAP 0 Command", NULL},
  {"IAPFLIPMODE_0",     0x1016C, NULL,        "IAP 0 ", NULL}, 
  {"IAPFLIPDIS_0",      0x1000C, NULL,        "IAP 0 ", NULL},
  {"IAPBLCONFIG_0",     0x10178, NULL,        "IAP 0 ", NULL},   
  {"IAPBUF_F0_0",       0x10100, NULL,        "IAP 0 ", NULL},  
  {"IAPBUF_F1_0",       0x10104, NULL,        "IAP 0 ", NULL},  
  {"IAPBUF_POFF_0",     0x10064, NULL,        "IAP 0 ", NULL}, 
  {"IAP_STRIDE_0",      0x10118, NULL,        "IAP 0 ", NULL}, 
  {"IAPDWINPOS_0",      0x1012C, NULL,        "IAP 0 ", NULL}, 
  {"IAPDWINSZ_0",       0x10130, NULL,        "IAP 0 ", NULL}, 
  {"IAPSWIDTH_0",       0x10134, NULL,        "IAP 0 ", NULL}, 
  {"IAPSHEIGHT_0",      0x1013C, NULL,        "IAP 0 ", NULL}, 
  {"IAPCLUT_0",         0x10400, NULL,        "IAP 0 ", NULL}, 
  {"DIAPVSTA_0",        0x10008, NULL,        "IAP 0 ", NULL},  
  {"IAPFDROP_0",        0x10170, NULL,        "IAP 0 ", NULL}, 
  {"IAPFREPEAT_0",      0x10174, NULL,        "IAP 0 ", NULL}, 

  {"IAPCOMD_1",         0x11168, NULL,        "IAP 1 Command", NULL},
  {"IAPFLIPMODE_1",     0x1116C, NULL,        "IAP 1 ", NULL}, 
  {"IAPFLIPDIS_1",      0x1100C, NULL,        "IAP 1 ", NULL},
  {"IAPBLCONFIG_1",     0x11178, NULL,        "IAP 1 ", NULL},   
  {"IAPBUF_F0_1",       0x11100, NULL,        "IAP 1 ", NULL},  
  {"IAPBUF_F1_1",       0x11104, NULL,        "IAP 1 ", NULL},  
  {"IAPBUF_POFF_1",     0x11064, NULL,        "IAP 1 ", NULL}, 
  {"IAP_STRIDE_1",      0x11118, NULL,        "IAP 1 ", NULL}, 
  {"IAPDWINPOS_1",      0x1112C, NULL,        "IAP 1 ", NULL}, 
  {"IAPDWINSZ_1",       0x11130, NULL,        "IAP 1 ", NULL}, 
  {"IAPSWIDTH_1",       0x11134, NULL,        "IAP 1 ", NULL}, 
  {"IAPSHEIGHT_1",      0x1113C, NULL,        "IAP 1 ", NULL}, 
  {"IAPCLUT_1",         0x11400, NULL,        "IAP 1 ", NULL}, 
  {"DIAPVSTA_1",        0x11008, NULL,        "IAP 1 ", NULL},  
  {"IAPFDROP_1",        0x11170, NULL,        "IAP 1 ", NULL}, 
  {"IAPFREPEAT_1",      0x11174, NULL,        "IAP 1 ", NULL}, 

  {"WBPCONFIG", 0x40000, NULL,                "WrBkPl Config", NULL}, 
  {"WBPBUF_Y_F0", 0x40100, NULL,              "WrBkPl ", NULL},  
  {"WBPBUF_CBCR_F0", 0x40108, NULL,           "WrBkPl ", NULL},
  {"WBPBUF_CBCR_F1", 0x4010C, NULL,           "WrBkPl ", NULL},
  {"WBP_STRIDE", 0x40118, NULL,               "WrBkPl ", NULL},
  {"WBP_PRNGSR", 0x40120, NULL,               "WrBkPl ", NULL},
  {"WBPHS_H", 0x41000, NULL,                  "WrBkPl ", NULL},
  {"WBPHS_W", 0x41004, NULL,                  "WrBkPl ", NULL},
  {"WBPHS_NBP", 0x41024, NULL,                "WrBkPl ", NULL},  
  {"WBPHS_ISF", 0x41044, NULL,                "WrBkPl ", NULL},  
  {"WBPHS_PC", 0x41048, NULL,                 "WrBkPl ", NULL}, 
  {"WBPHS_YPM", 0x41200, NULL,                "WrBkPl ", NULL},  
  {"WBPHS_CPM", 0x41300, NULL,                "WrBkPl ", NULL},  
  {"WBPVS_H", 0x42000, NULL,                  "WrBkPl ", NULL},
  {"WBPVS_W", 0x42004, NULL,                  "WrBkPl ", NULL},
  {"WBPVS_ISF", 0x42044, NULL,                "WrBkPl ", NULL},  
  {"WBPVS_PC", 0x42048, NULL,                 "WrBkPl ", NULL}, 
  {"WBPHS_PM", 0x42200, NULL,                 "WrBkPl ", NULL}, 
  {"WBPSTA", 0x43000, NULL,                   "WrBkPl ", NULL},

  {"BLCFG_P0SEL",    0x50000, NULL,           "Blender Pipe0 Select", NULL},  
  {"BLCFG_P1SEL",    0x50004, NULL,           "Blender Pipe1 Select", NULL},  
  {"CANVSCLR_0",    0x50008, NULL,            "Canvas Color0", NULL},  
  {"CANVSCLR_1",    0x5000C, NULL,            "Canvas Color1", NULL},  

  {"PACONFIG",    0x61140, NULL,              "Pipe A Output Config",    NULL},
  {"HTOTAL_A",    0x60000, NULL,              "Pipe A Horiz Total",      NULL},
  {"HBLANK_A",    0x60004, NULL,              "Pipe A Horiz Blank",      NULL},
  {"HSYNC_A",     0x60008, NULL,              "Pipe A Horiz Sync",       NULL},
  {"VTOTAL_A",    0x6000C, NULL,              "Pipe A Vert  Total",      NULL},
  {"VBLANK_A",    0x60010, NULL,              "Pipe A Vert  Blank",      NULL},
  {"VSYNC_A",     0x60014, NULL,              "Pipe A Vert  Sync",       NULL},
  {"VSYNCSHIFT_A",0x60028, NULL,              "Pipe A Vert  Sync Shift", NULL},
  {"PIPEASRC",    0x6001C, NULL,              "Pipe A Source Image Size", NULL},
  {"BCLRPAT_A",    0x60020, NULL,             "Pipe A Border Color Pattern", NULL},
  {"PAC_PRNGSR",    0x60030, NULL,            "Pipe A component PRNG Shift", NULL},
  /* Pipe A Gamma Correction 0x60900 - 0x60D07 */
  {"PAGAMLUT0",    0x60900, NULL,             "Pipe A Gamma Correction 0",  NULL}, 
  {"PAGAMLUT1",    0x60904, NULL,             "Pipe A Gamma Correction 1...", NULL}, 

  {"PIPEACONF",    0x70008, g_csr_vdc_PIPEACONFIG, "Pipe A Config", NULL}, 
  {"PIPEASTAT",    0x70024, g_csr_vdc_PIPEASTAT,   "Pipe A Display Status", NULL},

  {"PIPEBDE",      0x71008, NULL,             "Pipe B Dither Enable", NULL}, 
  {"BB_PRNGSR",    0x71000, NULL,             "Pipe B PRNG Shift",   NULL}, 
  { NULL,0,NULL,NULL,NULL }    /* NULL terminator */
};

static const struct SVEN_Module_EventSpecific g_GEN3_VDC_specific_events[] =
{
    { NULL, 0, "", NULL }
};

static const struct ModuleReverseDefs g_GEN3_VDC_sven_module =
{
    "GEN3_VDC",
    SVEN_module_GEN3_VDC,
    64*1024,
#ifdef SVEN_INTERNAL_BUILD
    g_csr_gen3_vdc,
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "VDC: VDC (GEN3)",
    g_GEN3_VDC_specific_events,
    NULL /* extension list */
};

