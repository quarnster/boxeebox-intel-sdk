/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef _CSR_GEN3_AUD_IO_C
#define _CSR_GEN3_AUD_IO_C "csr_gen3_aud_io.c"

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif


/* Audio Subsystem Memory Allocation and Registers

	The audio registers are allocated from the base address AU_AUX_BASE in the following manner:
	AU_AUX_BASE = <AU_MBAR>80000H (IA Viewpoint)
	AU_AUX_BASE+0000h- AU_AUX_BASE+0FFFh

 	Audio Configuration and Control registers
 	AU_AUX_BASE+1000h - AU_AUX_BASE+1FFF

 	DMA Contexts and Control Structures

	AU_AUX_BASE+2000h - AU_AUX_BASE+2FFF
 	I2S/SPDIF Output Channels

	AU_AUX_BASE+3000h - AU_AUX_BASE+3FFF
 	I2S Audio Capture Interfaces
 */

#ifdef SVEN_INTERNAL_BUILD

#define GEN3_AUD_IO_BASE 0x00000
#define DMA0_OFFSET 0x00
#define DMA1_OFFSET 0x40
#define DMA2_OFFSET 0x80
#define DMA3_OFFSET 0xC0

#define UNDEFINDED_SYMBOL "UNDEFINED"
#define RESERVED_SYMBOL "RESERVED"
#define UNDETERMINED_SIZE (-1)


//Common Control Register bit breakouts

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_CSR[] =
{//Configuration and Status Register
	{UNDEFINDED_SYMBOL"_31_20",20,12,", bit(s):31:20, default(), access()",NULL},
	{"DTS_ENABLE",19,1,"DTS_ENABLE Fuse value, bit(s):19, default(0b), access(R0)",NULL},
	{RESERVED_SYMBOL"_18_8",8,11,"Reserved, bit(s):18:8, default(0h), access(RV)",NULL},
	{UNDEFINDED_SYMBOL"_7_4",4,4,", bit(s):7:4, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_3",3,1,", bit(s):3, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_2",2,1,", bit(s):2, default(), access()",NULL},
	{"SWRST",1,1,"Software Reset. When asserted, active low, drives reset to all dependent blocks, except DSP processor., bit(s):1, default(0b), access(RW)",NULL},
	{"CLKEN",0,1,"Clock Enable. When asserted, active high, enables the clock to dependent blocks., bit(s):0, default(1b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_ISRX[] =
{//ISRX-IA32 Interrupt Status Register
	{UNDEFINDED_SYMBOL"_31",31,1,", bit(s):31, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_30",30,1,", bit(s):30, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_29",29,1,", bit(s):29, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_28",28,1,", bit(s):28, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_27",27,1,", bit(s):27, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_26",26,1,", bit(s):26, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_25",25,1,", bit(s):25, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_24",24,1,", bit(s):24, default(), access()",NULL},
	{"TX2_INT_PEND_CPU",23,1,"TX2 interrupt pending to CPU, bit(s):23, default(0b), access(RWC)",NULL},
	{"TX1_INT_PEND_CPU",22,1,"TX1 Interrupt pending to CPU, bit(s):22, default(0b), access(RWC)",NULL},
	{"TX0_INT_PEND_CPU",21,1,"TX0 Interrupt pending to CPU, bit(s):21, default(0b), access(RWC)",NULL},
	{UNDEFINDED_SYMBOL"_20",20,1,", bit(s):20, default(), access()",NULL},
	{"RX0_INT_PEND_CPU",19,1,"RX0 interrupt pending to CPU, bit(s):19, default(0b), access(RWC)",NULL},
	{UNDEFINDED_SYMBOL"_18",18,1,", bit(s):18, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_17",17,1,", bit(s):17, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_16",16,1,", bit(s):16, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_15",15,1,", bit(s):15, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_14",14,1,", bit(s):14, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_13",13,1,", bit(s):13, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_12",12,1,", bit(s):12, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_11",11,1,", bit(s):11, default(), access()",NULL},
	{"DMA3_DES",10,1,"DMA3 Destination  Interrupt pending to CPU, bit(s):10, default(0b), access(RWC)",NULL},
	{"DMA3_SRC",9,1,"DMA3 Source Interrupt pending to CPU, bit(s):9, default(0b), access(RWC)",NULL},
	{"DMA2_DES",8,1,"DMA2 Destination  Interrupt pending to CPU, bit(s):8, default(0b), access(RWC)",NULL},
	{"DMA2_SRC",7,1,"DMA2 Source Interrupt pending to CPU, bit(s):7, default(0b), access(RWC)",NULL},
	{"DMA1_DES",6,1,"DMA1 Destination  Interrupt pending to CPU, bit(s):6, default(0b), access(RWC)",NULL},
	{"DMA1_SRC",5,1,"DMA1 Source Interrupt pending to CPU, bit(s):5, default(0b), access(RWC)",NULL},
	{"DMA0_DES",4,1,"DMA0 Destination  Interrupt pending to CPU, bit(s):4, default(0b), access(RWC)",NULL},
	{"DMA0_SRC",3,1,"DMA0 Source Interrupt pending to CPU, bit(s):3, default(0b), access(RWC)",NULL},
	{UNDEFINDED_SYMBOL"_2",2,1,", bit(s):2, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_1",1,1,", bit(s):1, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_0",0,1,", bit(s):0, default(), access()",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};  // ISRX

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_IMRX[] =
{//IMRX Interrupt Mask Register for IA CPU
	{RESERVED_SYMBOL"_31",31,1,"Reserved, bit(s):31, default(0h), access(RV)",NULL},
	{UNDEFINDED_SYMBOL"_30",30,1,", bit(s):30, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_29",29,1,", bit(s):29, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_28",28,1,", bit(s):28, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_27",27,1,", bit(s):27, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_26",26,1,", bit(s):26, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_25",25,1,", bit(s):25, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_24",24,1,", bit(s):24, default(), access()",NULL},
	{"TX2_INT_EN_IA",23,1,"TX2 interrupt enable to IA, bit(s):23, default(0b), access(RW)",NULL},
	{"TX1_INT_EN_IA",22,1,"TX1 Interrupt enable to IA, bit(s):22, default(0b), access(RW)",NULL},
	{"TX0_INT_EN_IA",21,1,"TX0 Interrupt Enable to IA, bit(s):21, default(0b), access(RW)",NULL},
	{UNDEFINDED_SYMBOL"_20",20,1,", bit(s):20, default(), access()",NULL},
	{"RX0_INT_EN_IA",19,1,"RX0 Interrupt Enable to IA, 1: Enables interrupt from the RX channel 0, '0' - Disables., bit(s):19, default(0b), access(RW)",NULL},
	{UNDEFINDED_SYMBOL"_18",18,1,", bit(s):18, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_17",17,1,", bit(s):17, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_16",16,1,", bit(s):16, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_15",15,1,", bit(s):15, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_14",14,1,", bit(s):14, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_13",13,1,", bit(s):13, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_12",12,1,", bit(s):12, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_11",11,1,", bit(s):11, default(), access()",NULL},
	{"DMA3_DES",10,1,"DMA3 destination  Interrupt Enable to IA, bit(s):10, default(0b), access(RW)",NULL},
	{"DMA3_SRC",9,1,"DMA 3 source interrupt Enable to IA, bit(s):9, default(0b), access(RW)",NULL},
	{"DMA2_DES",8,1,"DMA2 destination  Interrupt Enable to IA CPU, bit(s):8, default(0b), access(RW)",NULL},
	{"DMA2_SRC",7,1,"DMA2 source interrupt enable to IA CPU, bit(s):7, default(0b), access(RW)",NULL},
	{"DMA1_DES",6,1,"DMA1 destination  Interrupt Enable to IA CPU, bit(s):6, default(0b), access(RW)",NULL},
	{"DMA1_SRC",5,1,"DMA 1 source interrupt enable to IA CPU, bit(s):5, default(0b), access(RW)",NULL},
	{"DMA0_DES",4,1,"DMA0  destination  Interrupt Enable to IA CPU, 1:  Enables interrupt from the DMA channel 0, '0' - Disables., bit(s):4, default(0b), access(RW)",NULL},
	{"DMA0_SRC",3,1,"DMA0 source interrupt enable to IA CPU, bit(s):3, default(0b), access(RW)",NULL},
	{UNDEFINDED_SYMBOL"_2",2,1,", bit(s):2, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_1",1,1,", bit(s):1, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_0",0,1,", bit(s):0, default(), access()",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};//IMRX


static const struct EAS_RegBits g_gen3_easbb_AUD_IO_CGR[] =
{//CGR-Clock Gating Config Register
	{RESERVED_SYMBOL"_31_13",13,19,"Reserved, bit(s):31:13, default(00000000h), access(RO)",NULL},
	{"SPDIF_CLK_RATE",12,1,"SPDIF Clock update rate.  0: SPDIF measured clock is updated every 192 stereo samples. This is the default mode of operation, '1' : SPDIF measured clock is updated every stereo sample., bit(s):12, default(0b), access(RW)",NULL},
	{"I2SC0_WS_SELECT",11,1,"Select WS output coming off falling edge of bitclock for I2Sc1 interface. Used only when using internally generated bitclock, bit(s):11, default(0b), access(RW)",NULL},
	{"I2SC1_WS_SELECT",10,1,"Select WS_output coming off falling edge of bitclock for I2Sc0 interface. Used only when using internally generated bitclock., bit(s):10, default(0b), access(RW)",NULL},
	{"I2S2_CLK_INV",9,1,"Invert I2S2 bitclock output( 1: invert bitclock going out of chip; 0: no inversion on bitclock), bit(s):9, default(0b), access(RW)",NULL},
	{"I2S1_CLK_INV",8,1,"Invert I2S1 bitclock output( 1: invert bitclock going out of chip; 0: no inversion on bitclock), bit(s):8, default(0b), access(RW)",NULL},
	{"I2S0_CLK_INV",7,1,"Invert I2S0 bitclock output ( 1: invert bitclock going out of chip; 0: no inversion on bitclock), bit(s):7, default(0b), access(RW)",NULL},
	{UNDEFINDED_SYMBOL"_6",6,1,", bit(s):6, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_5",5,1,", bit(s):5, default(), access()",NULL},
	{"TX2_CLK_EN",4,1,"Enable Clock gating for TX 2 channel( 1: Enable; 0: Disable), bit(s):4, default(0b), access(RW)",NULL},
	{"TX1_CLK_EN",3,1,"Enable Clock gating for TX1 Channel( 1: Enable; 0: Disable), bit(s):3, default(0b), access(RW)",NULL},
	{"TX0_CLK_EN",2,1,"Enable Clock gating for TX0  channel  ( 1: Enable; 0: Disable), bit(s):2, default(0b), access(RW)",NULL},
	{UNDEFINDED_SYMBOL"_1",1,1,", bit(s):1, default(), access()",NULL},
	{"RX0_CLK_EN",0,1,"Enable Clock gating for RX0 channel (1: Enable; 0: Disable), bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};//CGR

//DMA Memory Allocation and Register bit breakouts

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_NEXT_DESCR[] =
{
	{"WRITEABLE",31,30,"1: NEXT_DESCR register is 4 byte aligned., bit(s):31:2, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_1",1,1,", always 0, bit(s):1, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_0",0,1,", always 0, bit(s):0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_SRCDMA_BOT[] =
{
	{"WRITEABLE",31,30,"1: SRCDMA_BOT register is 4 byte aligned., bit(s):31:2, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_1",1,1,", always 0, bit(s):1, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_0",0,1,", always 0, bit(s):0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_SRCDMA_TOP[] =
{
	{"WRITEABLE",31,30,"1: SRCDMA_TOP register is 4 byte aligned., bit(s):31:2, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_1",1,1,", always 0, bit(s):1, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_0",0,1,", always 0, bit(s):0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_DSTDMA_BOT[] =
{
	{"WRITEABLE",31,30,"1: DSTDMA_BOT register is 4 byte aligned., bit(s):31:2, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_1",1,1,", always 0, bit(s):1, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_0",0,1,", always 0, bit(s):0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_DSTDMA_TOP[] =
{
	{"WRITEABLE",31,30,"1: DSTDMA_TOP register is 4 byte aligned., bit(s):31:2, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_1",1,1,", always 0, bit(s):1, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_0",0,1,", always 0, bit(s):0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_FLAGS_MODE[] =
{
	{"ACTIVE_DMA",31,1,"1: DMA context is active (has been started but has not finished). 0: DMA context is not active., bit(s):31, default(0), access(RO)",NULL},
	{"SRC_INT",30,1,"Interrupt when the current (active context) transfer has finished (source byte counter reaches zero) or when in circular-buffer addressing mode the circular buffer is empty.  1: enable interrupt 0: do not interrupt, bit(s):30, default(0), access(RW)",NULL},
	{"DST_INT",29,1,"Interrupt when the current (active context) transfer has finished (destination byte counter reaches zero) or when in circular-buffer addressing mode and the circular buffer is full. 1: enable interrupt 0: do not interrupt, bit(s):29, default(0), access(RW)",NULL},
	{"TERM",28,1,"Do not fetch the next descriptor when the current (active context) transfer has finished (byte counter reaches zero). 1: terminate 0: go read next descriptor , bit(s):28, default(0), access(RW)",NULL},
	{"RD_SWAP_ENDIAN",27,1,"Read Swap Endianism: This bit control whether the data on a DMA \"read\" (a transfer from global address space to local address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):27, default(0), access(RW)",NULL},
	{"WR_SWAP_ENDIAN",26,1,"Write Swap Endianism: This bit controls whether the data on a DMA \"write\" (a transfer from local address space to global address space) is endian swapped.   1: Swap Endianism,  0: Don\'t Swap Endianism., bit(s):26, default(0), access(RW)",NULL},
	{"SRC_ENDIANISM",25,1,"Source Endianism: Indicates what the source endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):25, default(0), access(RW)",NULL},
	{"DST_ENDIANISM",24,1,"Destination Endianism: Indicates what the destination endianism is and is used by hardware to generate the appropriate byte enables for non-32bit aligned accesses. 1: Big Endianism,  0: Little Endianism., bit(s):24, default(0), access(RW)",NULL},
	{"SUBUNIT_ID",20,4,"This field is not required to be programmed for Audio. , bit(s):23:20, default(0), access(RW)",NULL},
	{"XDMA_GAP",16,4,"Between bursts (meaning the larger of the 2 burst sizes) the context is \"locked\" XDMA_GAP value XSI bus clocks., bit(s):19:16, default(0), access(RW)",NULL},
	{"XBURST_SZ",12,4,"The DMA will transfer data to the Global Agent in bursts of this value., bit(s):15:12, default(0), access(RW)",NULL},
	{"BURST_SZ",8,4,"The DMA will transfer data to the Local Agent in bursts of this value., bit(s):11:8, default(0), access(RW)",NULL},
	{"READ_EN",7,1,"The DMA will read data from the global address space and write it into the local address space., bit(s):7, default(0), access(RW)",NULL},
	{"SRC_ADDR_MODE",5,2,"Source Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):6:5, default(0), access(RW)",NULL},
	{"SRC_LINK_LIST",4,1,"Source Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):4, default(0), access(RW)",NULL},
	{"WRITE_EN",3,1,"The DMA will read data from the local address space and write it into the global address space., bit(s):3, default(0), access(RW)",NULL},
	{"DST_ADDR_MODE",1,2,"Destination Addressing Mode: 00 Linear, 01 Circular, 10 Fixed, 11 Reserved., bit(s):2:1, default(0), access(RW)",NULL},
	{"DST_LINK_LIST",0,1,"Destination Link List Enable: 0: Linked-list mode disabled. 1: Linked-list mode enabled., bit(s):0, default(0), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};



//I2S Interface Memory Mapping and Registers

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_RX0SACR0[]=
{
	{RESERVED_SYMBOL"_31_7",7,25,"Reserved, bit(s):31:7, default(0), access(RO)",NULL},
	{UNDEFINDED_SYMBOL"_6_5",5,2,", bit(s):6:5 , default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_4",4,1,", bit(s):4, default(), access()",NULL},
	{"RST_FIFO",3,1,"Resets FIFOs logic and all registers, except this register (SACR0):0: Not reset 1: Reset is Active Other Registers, bit(s):3, default(0b), access(RW)",NULL},
	{"BIT_CLK_SRC",2,1,"This bit specifies input/output direction of BITCLK: 0: Input. BITCLK is driven by an external source1: Output. BITCLK generated internally and driven out to the DAC, bit(s):2, default(0H), access(RW)",NULL},
	{RESERVED_SYMBOL"_1",1,1,"Reserved , bit(s):1, default(0b), access(RV)",NULL},
	{"RX_ENABLE",0,1,"Enable RX function: 0: RX channel is disabled 1: RX channel is enabled, bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_RX0SACR1[]=
{
	{RESERVED_SYMBOL"_31_21",21,11,"Reserved, bit(s):31:21, default(0), access(RO)",NULL},
	{"TIMESTAMP_FILTER_EN",20,1,"Timestamp Filter Enable, bit(s):20, default(1), access(RW)",NULL},
	{"DMA_CONTEXT",17,3,"DMA Context Number. Specifies the DMA context number allocated to this I2S channel. The software must set up this field differently for each I2S channel to avoid unpredictable behavior. 000: Context 0 001: Context 1 010:  Context 2 011: Context 3., bit(s):19:17, default(00h), access(RW)",NULL},
	{"TIMESTAMP_FIFO_THRSH",15,2,"Timestamp FIFO Threshold, bit(s):16:15, default(0h), access(RW)",NULL},
	{RESERVED_SYMBOL"_14_10",10,5,"Reserved, bit(s):14:10, default(0h), access(RV)",NULL},
	{"STORAGE_MODE",8,2,"Data storage Mode: 01: Stereo Mode  10: Left-Channel Mono 11: Right-Channel Mono 00: Invalid value., bit(s):9:8, default(0h), access(RW)",NULL},
   {RESERVED_SYMBOL"_7",7,1,"Reserved, bit(s):7, default(0b), access(RV)",NULL},
	{RESERVED_SYMBOL"_6_5",5,2,"Reserved , bit(s):6:5, default(00b), access(RW)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_3",3,1,"Reserved, bit(s):3, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_2",2,1,"Reserved, bit(s):2, default(0b), access(RV)",NULL},
	{UNDEFINDED_SYMBOL"_1",1,1,", bit(s):1, default(0), access()",NULL},
	{"ALT_MODE",0,1,"Specify Alternate Mode (I2S or MSB-Justified) Operation_ 0: Select I2S Operation Mode 1: Select MSB-Justified Operation Mode, bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_RX0SASR0[]=
{
	{RESERVED_SYMBOL"_31_13",13,19,"Reserved, bit(s):31:13, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_12",12,1,"Reserved, bit(s):12, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_11",11,1,"Reserved, bit(s):11, default(0), access(RO)",NULL},
	{"TIMESTAMP_FIFO_LEVEL",8,3,"Timestamp FIFO level. The number of entries currently stored in the Timestamp and Buffer Address Pointer FIFOs (SATS and SABAP), bit(s):10:8, default(00b), access(RO)",NULL},
	{"I2S_CNTL_CLEAN_SHUTDOWN",7,1,"I2S Controller Clean Shutdown. When this value is \'1\', the I2SC is in the process of clean shutdown. When this value is \'1\', no writes ot the I2SC registers are allowed. When this bit is \'0\' and SACR0.ENB bit value is \'0\', then the unit is shutdown. When this bit is \'0\' and SACR0.ENB bit value is \'1\', then the I2SC is in enabled mode.When \'0\' is written to SACR0.ENB, I2SOFF will be \'1\' until all the data in the transmit FIFO is transmitted to CODEC and all the data in receive FIFO is read by the DMA., bit(s):7, default(0b), access(RO)",NULL},
	{"RX_FIFO_OVERRUN",6,1,"Receive FIFO Overrun:0: Receive FIFO has not experienced an overrun. 1: I2S attempted data write to full Receive FIFO (Interruptible) - Can interrupt processor if bit6 of Serial Audio Interrupt Mask Register is set. - Cleared by writing a \'1\' to bit6 of Serial Audio Interrupt Clear Register., bit(s):6, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_5",5,1,"Reserved, bit(s):5, default(0b), access(RO)",NULL},
	{"RX_FIFO_SVC_REQ",4,1,"Receive FIFO Service Request: 0: Receive FIFO level below RFL threshold, or I2S disabled 1: Receive FIFO level is at or above RFL threshold. - Can interrupt processor if bit4 of Serial Audio Interrupt Mask Register is set. - Cleared automatically when # of Receive FIFO entries < (RFTH + 1), bit(s):4, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_3",3,1,"Reserved, bit(s):3, default(0b), access(RO)",NULL},
	{"RX_BUSY",2,1,"RX Busy:0: RX channel is idle or disabled 1: RX channel currently receiving a frame , bit(s):2, default(0b), access(RO)",NULL},
	{"RX_FIFO_NOT_EMPTY",1,1,"Receive FIFO not empty: 0: Receive FIFO is empty 1: Receive FIFO is not empty, bit(s):1, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_0",0,1,"Reserved, bit(s):0, default(0b), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_RX0SAIMR[]=
{
	{RESERVED_SYMBOL"_31_18",18,14,"Reserved, bit(s):31:18, default(0), access(RO)",NULL},
	{UNDEFINDED_SYMBOL"_17",17,1,", bit(s):17, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_16",16,1,", bit(s):16, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_15",15,1,", bit(s):15, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_14",14,1,", bit(s):14, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_13",13,1,", bit(s):13, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_12",12,1,", bit(s):12, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_11",11,1,", bit(s):11, default(), access()",NULL},
	{"I2S_FRAME_INT_EN",10,1,"Enable I2S Frame interrupt (valid for I2S and S/PDIF), bit(s):10, default(0b), access(RW)",NULL},
	{UNDEFINDED_SYMBOL"_9",9,1,", bit(s):9, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_8",8,1,", bit(s):8, default(), access()",NULL},
	{"TIMESTAMP_FIFO_SVC_REQ_INT_EN",7,1,"Enable Timestamp FIFO Service Request Interrupt, bit(s):7, default(0b), access(RW)",NULL},
	{"RX_FIFO_OVERRUN_INT_EN",6,1,"Enable Receive FIFO Overrun condition based interrupt (valid only in input mode), bit(s):6, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_5",5,1,"Reserved, bit(s):5, default(0), access(RW)",NULL},
	{"RX_FIFO_SVC_REQ_INT_EN",4,1,"Enable Receive FIFO Service Request based interrupt  (valid only in input mode) , bit(s):4, default(0b), access(RW)",NULL},
	{UNDEFINDED_SYMBOL"_3",3,1,", bit(s):3, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_2",2,1,", bit(s):2, default(), access()",NULL},
	{RESERVED_SYMBOL"_1_0",0,2,"Reserved, bit(s):1:0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_RX0SAISR[]=
{
	{RESERVED_SYMBOL"_31_14",14,18,"Reserved, bit(s):31:14, default(0), access(RO)",NULL},
	{UNDEFINDED_SYMBOL"_13",13,1,", bit(s):13, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_12",12,1,", bit(s):12, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_11",11,1,", bit(s):11, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_10",10,1,", bit(s):10, default(), access()",NULL},
	{"TIMESTAMP_FIFO_SVC_REQ_INT",9,1,"Timestamp FIFO Service Request Interrupt. 0: FIFO level below TSFL threshold from SACR1, or I2S disabled 1: FIFO level is at or above the TSFL threshold in SACR1. Cleared automatically when # of FIFO entries < (TSTH + 1), bit(s):9, default(0b), access(RO)",NULL},
	{"CLEAR_FIFO_UNDERUN_INT",8,1,"Clear Receive FIFO overrun Interrupt and ROR status bit in SASR0. Writing a \'1\' to this location clears the interrupt and SASR0 bit 6, bit(s):8, default(0b), access(RWC)",NULL},
	{UNDEFINDED_SYMBOL"_7",7,1,", bit(s):7, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_6",6,1,", bit(s):6, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_5",5,1,", bit(s):5, default(), access()",NULL},
	{"I2S_FRAME_INT",4,1,"I2S Frame interrupt (valid for I2S and S/PDIF) -This interrupt is asserted when a programmable (N) number of samples have been  received by the RX logic. This is asserted when RXFRAME_SIZE -1 stereo samples have been received by the RX logic in the case of I2S or when RXFRAME_SIZE -1 samples have been received by the RX logic  Writing a \'1\' clears this bit., bit(s):4, default(0b), access(RWC)",NULL},
	{UNDEFINDED_SYMBOL"_3",3,1,", bit(s):3, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_2",2,1,", bit(s):2, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_1",1,1,", bit(s):1, default(), access()",NULL},
	{UNDEFINDED_SYMBOL"_0",0,1,", bit(s):0, default(), access()",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_RX0SADIV[]=
{
	{RESERVED_SYMBOL"_31_7",7,25,"Reserved, bit(s):31:7, default(0), access(RO)",NULL},
	{"AUD_CLK_DIV",0,7,"Audio Clock Divider, bit(s):6:0, default(00h), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_RX0SAFTH[]=
{
	{RESERVED_SYMBOL"_31_16",16,16,"Reserved, bit(s):31:16, default(0h), access(RW)",NULL},
	{"RX_UPPER_FIFO_THRSH",0,16,"Upper FIFO Threshold of Receive Channel in words, bit(s):15:0, default(0000h), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_RX0SAFL[]=
{
	{RESERVED_SYMBOL"_31_8",8,24,"Reserved, bit(s):31:8, default(0), access(RO)",NULL},
	{"RX_FIFO_LEVEL",0,8,"FIFO Level of Receive Channel. The number of words that are currently stored in the FIFO. , bit(s):7:0, default(00h), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_RX0SADESC[]=
{
	{"RX_FRAME_DESCRIPTOR",16,16,"16-bit Frame Descriptor. , bit(s):31:16, default(0000h), access(RW)",NULL},
	{"RX_FRAME_SIZE",0,16,"RXFRAME_SIZE: This value will be used to determine the size of the audio frame and how often the header info is inserted into the data stream. Normally, the audio encoding algorithm will define how many audio samples will comprise one audio block. For example, when MPEG-1 layer 2 or layer 3 is encoded, the software will set this field to 1152(decimal). Note: For I2S this refers to the number of Stereo Samples while for SPDIF this refers to just the number of Samples. , bit(s):15:0, default(0000h), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX0SACR0[]=
{
	{RESERVED_SYMBOL"_31",31,1,"Reserved, bit(s):31, default(0H), access(RW)",NULL},
	{RESERVED_SYMBOL"_30",30,1,"Reserved, bit(s):30, default(0H), access(RO)",NULL},
	{RESERVED_SYMBOL"_29_6",6,24,"Reserved, bit(s):29:6, default(0), access(RO)",NULL},
	{"TX0_OUTPUT_SEL",5,2,"Select outputs 00: 7.1 I2S output 01: stereo I2S output 0 10: not used  11: S/PDIF output, bit(s):6:5, default(00b), access(RW)",NULL},
	{UNDEFINDED_SYMBOL"_4",4,1,", bit(s):4, default(), access()",NULL},
	{"TX0_FIFO_RESET",3,1,"Resets FIFOs logic and all registers, except this register (SACR0): 0: Not reset 1: Reset is Active Other Registers , bit(s):3, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_2",2,1,"Reserved , bit(s):2, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_1",1,1,"Reserved, bit(s):1, default(0b), access(RO)",NULL},
	{"TX0_ENABLE",0,1,"EnableTX function: 0: TX channel is disabled 1: TX channel is enabled, bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX0SACR1[]=
{
	{"TX0_SPDIF_VALIDITY",31,1,"SPDIF validity bit, bit(s):31, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_30_20",20,11,"Reserved, bit(s):30:20, default(000h), access(RO)",NULL},
	{"TX0_DMA_CONTEXT",17,3,"DMA Context Number. Specifies the DMA context number allocated to this I2S channel. The software must set up this field differently for each I2S interface to avoid unpredictable behavior. 000: Context 0 001: Context 1 010: Context 2 011: Context 3., bit(s):19:17, default(00b), access(RW)",NULL},
	{RESERVED_SYMBOL"_16",16,1,"Reserved , bit(s):16, default(0b), access(RO)",NULL},
	{"TX0_I2S_PIN2",14,2,"Disable I2S Transmit Data Pin 2: 00: Transmit Data Pin 2, Both Channels are Enabled 01: Transmit Data Pin 2, Left Channel is Enabled; Right  channel output will be 0-filled 10: Transmit Data Pin 2, Right channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 2 is Disabled, bit(s):15:14, default(00b), access(RW)",NULL},
	{"TX0_I2S_PIN1",12,2,"Disable I2S Transmit Data Pin 1: 00: Transmit Data Pin 1, Both Channels are Enabled 01: Transmit Data Pin 1, Left  Channel is Enabled; Right channel output will be 0-filled 10: Transmit Data Pin 1, Right  Channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 1 is Disabled, bit(s):13:12, default(00b), access(RW)",NULL},
	{"TX0_I2S_PIN0",10,2,"Disable I2S Transmit Data Pin 0: 00: Transmit Data Pin 0, Both Channels are Enabled 01: Transmit Data Pin 0, Left  Channel is Enabled; Right channel output will be 0-filled 10: Transmit Data Pin 0, Right  Channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 0 is Disabled, bit(s):11:10, default(0H), access(RW)",NULL},
	{"TX0_MODE",8,2,"Data storage Mode: 00: 7.1 Data 01: Stereo Mode 10: Left-Channel Mono 11: Right-Channel Mono, bit(s):9:8, default(00b), access(RW)",NULL},
	{"TX0_SAMPLE_SIZE",7,1,"Data Sample Size 0: 16-bit data sample 1: 24-bit data sample, bit(s):7, default(0b), access(RW)",NULL},
	{"TX0_I2S_PIN3",5,2,"Disable I2S Transmit Data Pin 3: 00: Transmit Data Pin 3, Both Channels are Enabled 01: Transmit Data Pin 3, Left Channel is Enabled; Right  channel output will be 0-filled 10: Transmit Data Pin 3, Right channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 3 is Disabled, bit(s):6:5, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_3",3,1,"Reserved, bit(s):3, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_2",2,1,"Reserved, bit(s):2, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_1",1,1,"Reserved, bit(s):1, default(0), access(RO)",NULL},
	{"TX0_ALT_MODE",0,1,"Specify Alternate Mode (I2S or MSB-Justified) Operation: 0: Select I2S Operation Mode 1: Select MSB-Justified Operation Mode, bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX0SASR0[]=
{
	{RESERVED_SYMBOL"_31_8",8,24,"Reserved, bit(s):31:8, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_10_8",8,3,"Reserved, bit(s):10:8, default(0), access(RO)",NULL},
	{"I2S_CNTL_CLEAN_SHUTDOWN",7,1,"I2S Controller Clean Shutdown. When this value is \'1\', the I2SC is in the process of clean shutdown. When this value is \'1\', no writes ot the I2SC registers are allowed. When this bit is \'0\' and SACR0.ENB bit value is \'0\', then the unit is shutdown. When this bit is \'0\' and SACR0.ENB bit value is \'1\', then the I2SC is in enabled mode. When \'0\' is written to SACR0.ENB, I2SOFF will be \'1\' until all the data in the transmit FIFO is transmitted to CODEC and all the data in receive FIFO is read by the DMA., bit(s):7, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_6",6,1,"Reserved, bit(s):6, default(0), access(RO)",NULL},
	{"TX0_FIFO_UNDERRUN",5,1,"Transmit FIFO Underrun: 0: Transmit FIFO has not experienced an underrun.1: I2S attempted data read from an empty Transmit FIFO - Can interrupt processor if bit5 of Serial Audio Interrupt Mask Register is set. - Cleared by writing a \'1\' to bit5 of Serial Audio Interrupt Clear Register., bit(s):5, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RO)",NULL},
	{"TX0_FIFO_SVC_REQ",3,1,"Transmit FIFO Service Request: 0: Transmit FIFO level exceeds TFL threshold, or I2S disabled 1: Transmit FIFO level is at or below TFL threshold - Can interrupt processor if bit3 of Serial Audio Interrupt Mask Register is set. - Cleared automatically when # of Transmit FIFO entries >= (TFTH + 1), bit(s):3, default(0b), access(RO)",NULL},
	{"TX0_BUSY",2,1,"TX Busy: 0: TX is idle or disabled 1:TX currently transmitting a frame , bit(s):2, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_1",1,1,"Reserved, bit(s):1, default(0), access(RO)",NULL},
	{"TX0_FIFO_NOT_EMPTY",0,1,"Transmit FIFO not full 0: Transmit FIFO is full 1: Transmit FIFO is not full, bit(s):0, default(1b), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX0SAIMR[]=
{
	{RESERVED_SYMBOL"_31_9",9,23,"Reserved, bit(s):31:9, default(0), access(RO)",NULL},
	{"TX0_SPDIF_BCLK_COMPLETE_INT_EN",8,1,"Enable S/PDIF Block complete interrupt, bit(s):8, default(0b), access(RO)",NULL},
	{"TX0_FIFO_UNDERRUN_INT_EN",5,1,"Enable Transmit FIFO under-run condition based interrupt, bit(s):5, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RO)",NULL},
	{"TX0_FIFO_SVC_REQ_INT_EN",3,1,"Enable Transmit FIFO service request based interrupt, bit(s):3, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_2_0",0,3,"Reserved, bit(s):2:0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX0SAISR[]=
{
	{RESERVED_SYMBOL"_31_9",9,23,"Reserved, bit(s):31:9, default(0), access(RO)",NULL},
	{"TX0_SPDIF_BLK_COMPLETE_INT",8,1," SPDIF Block Transmit Complete Interrupt. Writing a \'1\' to this location clears the interrupt., bit(s):8, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_7_6",6,2,"Reserved, bit(s):7:6, default(0), access(RO)",NULL},
	{"TX0_CLEAR_FIFO_UNDERRUN_INT",5,1,"Clear Transmit FIFO underrun interrupt and TUR status bit SASR0. Writing a \'1\' to this location clears the interrupt and SASR0 bit 5, bit(s):5, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_3",3,1,"Reserved , bit(s):3, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_2_0",0,3,"Reserved, bit(s):2:0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX0SADIV[]=
{
	{UNDEFINDED_SYMBOL"_31_7",7,25,"Reserved, bit(s):31:7, default(0), access(RO)",NULL},
	{"TX0_AUD_CLK_DIV",0,7,"Audio Clock Divider, bit(s):6:0, default(06h), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX0SAFTH[]=
{
	{RESERVED_SYMBOL"_31_16",16,16,"Reserved, bit(s):31:16, default(0), access(RW)",NULL},
	{"TX0_LOWER_FIFO_THRSH",0,16,"Lower FIFO Threshold of Transmit Channel in words, bit(s):15:0, default(0000h), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX0SAFL[]=
{
	{RESERVED_SYMBOL"_31_8",8,24,"Reserved, bit(s):31:8, default(0), access(RO)",NULL},
	{"TX0_FIFO_LEVEL",0,8,"FIFO Level of Transmit Channel. The number of words that are currently stored in the FIFO. , bit(s):7:0, default(000h), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX0SASUDC[]=
{
	{RESERVED_SYMBOL"_31_1",1,31,"Reserved, bit(s):31:1, default(0), access(RV)",NULL},
	{"TX0_LOAD_SASUD_TO_SPDIF",0,1,"Load the User Data registers (SASUD0 - SASUD11)into buffer for insertion into S/PDIF data stream. This bit will be automatically reset to \\'0\\'., bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TXSASCS1[]=
{
	{RESERVED_SYMBOL"_31_8",8,24,"Reserved, bit(s):31:8, default(0), access(R0)",NULL},
	{"WRITABLE",0,8,"TX0SASCS1 - S/PDIF transmit channel status Register. Channel Status bits 40:32 (40 bits only), bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX0SASCSC[]=
{
	{RESERVED_SYMBOL"_31_1",1,31,"Reserved, bit(s):31:1, default(0), access(RV)",NULL},
	{"TX0_LOAD_CNTL_STAT_REG",0,1,"Load the Control Status registers (TX0SASCS0 - TX0SASCS5)into buffer for insertion into S/PDIF data stream. This bit will be automatically reset to \'0\'. , bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX1SACR0[]=
{
	{RESERVED_SYMBOL"_31",31,1,"Reserved, bit(s):31, default(0H), access(RW)",NULL},
	{RESERVED_SYMBOL"_30",30,1,"Reserved, bit(s):30, default(0H), access(RO)",NULL},
	{RESERVED_SYMBOL"_29_6",6,24,"Reserved, bit(s):29:6, default(0), access(RO)",NULL},
	{"TX1_OUTPUT_SEL",5,2,"Select outputs 00: 7.1 I2S output 01: stereo I2S output 0 10: not used  11: S/PDIF output, bit(s):6:5, default(00b), access(RW)",NULL},
	{UNDEFINDED_SYMBOL"_4",4,1,", bit(s):4, default(), access()",NULL},
	{"TX1_FIFO_RESET",3,1,"Resets FIFOs logic and all registers, except this register (SACR0): 0: Not reset 1: Reset is Active Other Registers , bit(s):3, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_2",2,1,"Reserved , bit(s):2, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_1",1,1,"Reserved, bit(s):1, default(0b), access(RO)",NULL},
	{"TX1_ENABLE",0,1,"EnableTX function: 0: TX channel is disabled 1: TX channel is enabled, bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX1SACR1[]=
{
	{"TX1_SPDIF_VALIDITY",31,1,"SPDIF validity bit, bit(s):31, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_30_20",20,11,"Reserved, bit(s):30:20, default(000h), access(RO)",NULL},
	{"TX1_DMA_CONTEXT",17,3,"DMA Context Number. Specifies the DMA context number allocated to this I2S channel. The software must set up this field differently for each I2S interface to avoid unpredictable behavior. 000: Context 0 001: Context 1 010: Context 2 011: Context 3., bit(s):19:17, default(00b), access(RW)",NULL},
	{RESERVED_SYMBOL"_16",16,1,"Reserved , bit(s):16, default(0b), access(RO)",NULL},
	{"TX1_I2S_PIN2",14,2,"Disable I2S Transmit Data Pin 2: 00: Transmit Data Pin 2, Both Channels are Enabled 01: Transmit Data Pin 2, Left Channel is Enabled; Right  channel output will be 0-filled 10: Transmit Data Pin 2, Right channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 2 is Disabled, bit(s):15:14, default(00b), access(RW)",NULL},
	{"TX1_I2S_PIN1",12,2,"Disable I2S Transmit Data Pin 1: 00: Transmit Data Pin 1, Both Channels are Enabled 01: Transmit Data Pin 1, Left  Channel is Enabled; Right channel output will be 0-filled 10: Transmit Data Pin 1, Right  Channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 1 is Disabled, bit(s):13:12, default(00b), access(RW)",NULL},
	{"TX1_I2S_PIN0",10,2,"Disable I2S Transmit Data Pin 0: 00: Transmit Data Pin 0, Both Channels are Enabled 01: Transmit Data Pin 0, Left  Channel is Enabled; Right channel output will be 0-filled 10: Transmit Data Pin 0, Right  Channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 0 is Disabled, bit(s):11:10, default(0H), access(RW)",NULL},
	{"TX1_MODE",8,2,"Data storage Mode: 00: 7.1 Data 01: Stereo Mode 10: Left-Channel Mono 11: Right-Channel Mono, bit(s):9:8, default(00b), access(RW)",NULL},
	{"TX1_SAMPLE_SIZE",7,1,"Data Sample Size 0: 16-bit data sample 1: 24-bit data sample, bit(s):7, default(0b), access(RW)",NULL},
	{"TX1_I2S_PIN3",5,2,"Disable I2S Transmit Data Pin 3: 00: Transmit Data Pin 3, Both Channels are Enabled 01: Transmit Data Pin 3, Left Channel is Enabled; Right  channel output will be 0-filled 10: Transmit Data Pin 3, Right channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 3 is Disabled, bit(s):6:5, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_3",3,1,"Reserved, bit(s):3, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_2",2,1,"Reserved, bit(s):2, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_1",1,1,"Reserved, bit(s):1, default(0), access(RO)",NULL},
	{"TX1_ALT_MODE",0,1,"Specify Alternate Mode (I2S or MSB-Justified) Operation: 0: Select I2S Operation Mode 1: Select MSB-Justified Operation Mode, bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX1SASR0[]=
{
	{RESERVED_SYMBOL"_31_8",8,24,"Reserved, bit(s):31:8, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_10_8",8,3,"Reserved, bit(s):10:8, default(0), access(RO)",NULL},
	{"I2S_CNTL_CLEAN_SHUTDOWN",7,1,"I2S Controller Clean Shutdown. When this value is \'1\', the I2SC is in the process of clean shutdown. When this value is \'1\', no writes ot the I2SC registers are allowed. When this bit is \'0\' and SACR0.ENB bit value is \'0\', then the unit is shutdown. When this bit is \'0\' and SACR0.ENB bit value is \'1\', then the I2SC is in enabled mode. When \'0\' is written to SACR0.ENB, I2SOFF will be \'1\' until all the data in the transmit FIFO is transmitted to CODEC and all the data in receive FIFO is read by the DMA., bit(s):7, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_6",6,1,"Reserved, bit(s):6, default(0), access(RO)",NULL},
	{"TX1_FIFO_UNDERRUN",5,1,"Transmit FIFO Underrun: 0: Transmit FIFO has not experienced an underrun.1: I2S attempted data read from an empty Transmit FIFO - Can interrupt processor if bit5 of Serial Audio Interrupt Mask Register is set. - Cleared by writing a \'1\' to bit5 of Serial Audio Interrupt Clear Register., bit(s):5, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RO)",NULL},
	{"TX1_FIFO_SVC_REQ",3,1,"Transmit FIFO Service Request: 0: Transmit FIFO level exceeds TFL threshold, or I2S disabled 1: Transmit FIFO level is at or below TFL threshold - Can interrupt processor if bit3 of Serial Audio Interrupt Mask Register is set. - Cleared automatically when # of Transmit FIFO entries >= (TFTH + 1), bit(s):3, default(0b), access(RO)",NULL},
	{"TX1_BUSY",2,1,"TX Busy: 0: TX is idle or disabled 1:TX currently transmitting a frame , bit(s):2, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_1",1,1,"Reserved, bit(s):1, default(0), access(RO)",NULL},
	{"TX1_FIFO_NOT_EMPTY",0,1,"Transmit FIFO not full 0: Transmit FIFO is full 1: Transmit FIFO is not full, bit(s):0, default(1b), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX1SAIMR[]=
{
	{RESERVED_SYMBOL"_31_9",9,23,"Reserved, bit(s):31:9, default(0), access(RO)",NULL},
	{"TX1_SPDIF_BCLK_COMPLETE_INT_EN",8,1,"Enable S/PDIF Block complete interrupt, bit(s):8, default(0b), access(RO)",NULL},
	{"TX1_FIFO_UNDERRUN_INT_EN",5,1,"Enable Transmit FIFO under-run condition based interrupt, bit(s):5, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RO)",NULL},
	{"TX1_FIFO_SVC_REQ_INT_EN",3,1,"Enable Transmit FIFO service request based interrupt, bit(s):3, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_2_0",0,3,"Reserved, bit(s):2:0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX1SAISR[]=
{
	{RESERVED_SYMBOL"_31_9",9,23,"Reserved, bit(s):31:9, default(0), access(RO)",NULL},
	{"TX1_SPDIF_BLK_COMPLETE_INT",8,1," SPDIF Block Transmit Complete Interrupt. Writing a \'1\' to this location clears the interrupt., bit(s):8, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_7_6",6,2,"Reserved, bit(s):7:6, default(0), access(RO)",NULL},
	{"TX1_CLEAR_FIFO_UNDERRUN_INT",5,1,"Clear Transmit FIFO underrun interrupt and TUR status bit SASR0. Writing a \'1\' to this location clears the interrupt and SASR0 bit 5, bit(s):5, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_3",3,1,"Reserved , bit(s):3, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_2_0",0,3,"Reserved, bit(s):2:0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX1SADIV[]=
{
	{UNDEFINDED_SYMBOL"_31_7",7,25,"Reserved, bit(s):31:7, default(0), access(RO)",NULL},
	{"TX1_AUD_CLK_DIV",0,7,"Audio Clock Divider, bit(s):6:0, default(06h), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX1SAFTH[]=
{
	{RESERVED_SYMBOL"_31_16",16,16,"Reserved, bit(s):31:16, default(0), access(RW)",NULL},
	{"TX1_LOWER_FIFO_THRSH",0,16,"Lower FIFO Threshold of Transmit Channel in words, bit(s):15:0, default(0000h), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX1SAFL[]=
{
	{RESERVED_SYMBOL"_31_8",8,24,"Reserved, bit(s):31:8, default(0), access(RO)",NULL},
	{"TX1_FIFO_LEVEL",0,8,"FIFO Level of Transmit Channel. The number of words that are currently stored in the FIFO. , bit(s):7:0, default(000h), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX1SASUDC[]=
{
	{RESERVED_SYMBOL"_31_1",1,31,"Reserved, bit(s):31:1, default(0), access(RV)",NULL},
	{"TX1_LOAD_SASUD_TO_SPDIF",0,1,"Load the User Data registers (SASUD0 - SASUD11)into buffer for insertion into S/PDIF data stream. This bit will be automatically reset to \\'0\\'., bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX1SASCSC[]=
{
	{RESERVED_SYMBOL"_31_1",1,31,"Reserved, bit(s):31:1, default(0), access(RV)",NULL},
	{"TX1_LOAD_CNTL_STAT_REG",0,1,"Load the Control Status registers (TX1SASCS0 - TX1SASCS5)into buffer for insertion into S/PDIF data stream. This bit will be automatically reset to \'0\'. , bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX2SACR0[]=
{
	{RESERVED_SYMBOL"_31",31,1,"Reserved, bit(s):31, default(0H), access(RW)",NULL},
	{RESERVED_SYMBOL"_30",30,1,"Reserved, bit(s):30, default(0H), access(RO)",NULL},
	{RESERVED_SYMBOL"_29_6",6,24,"Reserved, bit(s):29:6, default(0), access(RO)",NULL},
	{"TX2_OUTPUT_SEL",5,2,"Select outputs 00: 7.1 I2S output 01: stereo I2S output 0 10: not used  11: S/PDIF output, bit(s):6:5, default(00b), access(RW)",NULL},
	{UNDEFINDED_SYMBOL"_4",4,1,", bit(s):4, default(), access()",NULL},
	{"TX2_FIFO_RESET",3,1,"Resets FIFOs logic and all registers, except this register (SACR0): 0: Not reset 1: Reset is Active Other Registers , bit(s):3, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_2",2,1,"Reserved , bit(s):2, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_1",1,1,"Reserved, bit(s):1, default(0b), access(RO)",NULL},
	{"TX2_ENABLE",0,1,"EnableTX function: 0: TX channel is disabled 1: TX channel is enabled, bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX2SACR1[]=
{
	{"TX2_SPDIF_VALIDITY",31,1,"SPDIF validity bit, bit(s):31, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_30_20",20,11,"Reserved, bit(s):30:20, default(000h), access(RO)",NULL},
	{"TX2_DMA_CONTEXT",17,3,"DMA Context Number. Specifies the DMA context number allocated to this I2S channel. The software must set up this field differently for each I2S interface to avoid unpredictable behavior. 000: Context 0 001: Context 1 010: Context 2 011: Context 3., bit(s):19:17, default(00b), access(RW)",NULL},
	{RESERVED_SYMBOL"_16",16,1,"Reserved , bit(s):16, default(0b), access(RO)",NULL},
	{"TX2_I2S_PIN2",14,2,"Disable I2S Transmit Data Pin 2: 00: Transmit Data Pin 2, Both Channels are Enabled 01: Transmit Data Pin 2, Left Channel is Enabled; Right  channel output will be 0-filled 10: Transmit Data Pin 2, Right channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 2 is Disabled, bit(s):15:14, default(00b), access(RW)",NULL},
	{"TX2_I2S_PIN1",12,2,"Disable I2S Transmit Data Pin 1: 00: Transmit Data Pin 1, Both Channels are Enabled 01: Transmit Data Pin 1, Left  Channel is Enabled; Right channel output will be 0-filled 10: Transmit Data Pin 1, Right  Channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 1 is Disabled, bit(s):13:12, default(00b), access(RW)",NULL},
	{"TX2_I2S_PIN0",10,2,"Disable I2S Transmit Data Pin 0: 00: Transmit Data Pin 0, Both Channels are Enabled 01: Transmit Data Pin 0, Left  Channel is Enabled; Right channel output will be 0-filled 10: Transmit Data Pin 0, Right  Channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 0 is Disabled, bit(s):11:10, default(0H), access(RW)",NULL},
	{"TX2_MODE",8,2,"Data storage Mode: 00: 7.1 Data 01: Stereo Mode 10: Left-Channel Mono 11: Right-Channel Mono, bit(s):9:8, default(00b), access(RW)",NULL},
	{"TX2_SAMPLE_SIZE",7,1,"Data Sample Size 0: 16-bit data sample 1: 24-bit data sample, bit(s):7, default(0b), access(RW)",NULL},
	{"TX2_I2S_PIN3",5,2,"Disable I2S Transmit Data Pin 3: 00: Transmit Data Pin 3, Both Channels are Enabled 01: Transmit Data Pin 3, Left Channel is Enabled; Right  channel output will be 0-filled 10: Transmit Data Pin 3, Right channel is Enabled; Left  channel output will be 0-filled 11: Transmit Data Pin 3 is Disabled, bit(s):6:5, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_3",3,1,"Reserved, bit(s):3, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_2",2,1,"Reserved, bit(s):2, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_1",1,1,"Reserved, bit(s):1, default(0), access(RO)",NULL},
	{"TX2_ALT_MODE",0,1,"Specify Alternate Mode (I2S or MSB-Justified) Operation: 0: Select I2S Operation Mode 1: Select MSB-Justified Operation Mode, bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX2SASR0[]=
{
	{RESERVED_SYMBOL"_31_8",8,24,"Reserved, bit(s):31:8, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_10_8",8,3,"Reserved, bit(s):10:8, default(0), access(RO)",NULL},
	{"I2S_CNTL_CLEAN_SHUTDOWN",7,1,"I2S Controller Clean Shutdown. When this value is \'1\', the I2SC is in the process of clean shutdown. When this value is \'1\', no writes ot the I2SC registers are allowed. When this bit is \'0\' and SACR0.ENB bit value is \'0\', then the unit is shutdown. When this bit is \'0\' and SACR0.ENB bit value is \'1\', then the I2SC is in enabled mode. When \'0\' is written to SACR0.ENB, I2SOFF will be \'1\' until all the data in the transmit FIFO is transmitted to CODEC and all the data in receive FIFO is read by the DMA., bit(s):7, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_6",6,1,"Reserved, bit(s):6, default(0), access(RO)",NULL},
	{"TX2_FIFO_UNDERRUN",5,1,"Transmit FIFO Underrun: 0: Transmit FIFO has not experienced an underrun.1: I2S attempted data read from an empty Transmit FIFO - Can interrupt processor if bit5 of Serial Audio Interrupt Mask Register is set. - Cleared by writing a \'1\' to bit5 of Serial Audio Interrupt Clear Register., bit(s):5, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RO)",NULL},
	{"TX2_FIFO_SVC_REQ",3,1,"Transmit FIFO Service Request: 0: Transmit FIFO level exceeds TFL threshold, or I2S disabled 1: Transmit FIFO level is at or below TFL threshold - Can interrupt processor if bit3 of Serial Audio Interrupt Mask Register is set. - Cleared automatically when # of Transmit FIFO entries >= (TFTH + 1), bit(s):3, default(0b), access(RO)",NULL},
	{"TX2_BUSY",2,1,"TX Busy: 0: TX is idle or disabled 1:TX currently transmitting a frame , bit(s):2, default(0b), access(RO)",NULL},
	{RESERVED_SYMBOL"_1",1,1,"Reserved, bit(s):1, default(0), access(RO)",NULL},
	{"TX2_FIFO_NOT_EMPTY",0,1,"Transmit FIFO not full 0: Transmit FIFO is full 1: Transmit FIFO is not full, bit(s):0, default(1b), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX2SAIMR[]=
{
	{RESERVED_SYMBOL"_31_9",9,23,"Reserved, bit(s):31:9, default(0), access(RO)",NULL},
	{"TX2_SPDIF_BCLK_COMPLETE_INT_EN",8,1,"Enable S/PDIF Block complete interrupt, bit(s):8, default(0b), access(RO)",NULL},
	{"TX2_FIFO_UNDERRUN_INT_EN",5,1,"Enable Transmit FIFO under-run condition based interrupt, bit(s):5, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RO)",NULL},
	{"TX2_FIFO_SVC_REQ_INT_EN",3,1,"Enable Transmit FIFO service request based interrupt, bit(s):3, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_2_0",0,3,"Reserved, bit(s):2:0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX2SAISR[]=
{
	{RESERVED_SYMBOL"_31_9",9,23,"Reserved, bit(s):31:9, default(0), access(RO)",NULL},
	{"TX2_SPDIF_BLK_COMPLETE_INT",8,1," SPDIF Block Transmit Complete Interrupt. Writing a \'1\' to this location clears the interrupt., bit(s):8, default(0), access(RW)",NULL},
	{RESERVED_SYMBOL"_7_6",6,2,"Reserved, bit(s):7:6, default(0), access(RO)",NULL},
	{"TX2_CLEAR_FIFO_UNDERRUN_INT",5,1,"Clear Transmit FIFO underrun interrupt and TUR status bit SASR0. Writing a \'1\' to this location clears the interrupt and SASR0 bit 5, bit(s):5, default(0b), access(RW)",NULL},
	{RESERVED_SYMBOL"_4",4,1,"Reserved, bit(s):4, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_3",3,1,"Reserved , bit(s):3, default(0), access(RO)",NULL},
	{RESERVED_SYMBOL"_2_0",0,3,"Reserved, bit(s):2:0, default(0), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX2SADIV[]=
{
	{UNDEFINDED_SYMBOL"_31_7",7,25,"Reserved, bit(s):31:7, default(0), access(RO)",NULL},
	{"TX2_AUD_CLK_DIV",0,7,"Audio Clock Divider, bit(s):6:0, default(06h), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX2SAFTH[]=
{
	{RESERVED_SYMBOL"_31_16",16,16,"Reserved, bit(s):31:16, default(0), access(RW)",NULL},
	{"TX2_LOWER_FIFO_THRSH",0,16,"Lower FIFO Threshold of Transmit Channel in words, bit(s):15:0, default(0000h), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX2SAFL[]=
{
	{RESERVED_SYMBOL"_31_8",8,24,"Reserved, bit(s):31:8, default(0), access(RO)",NULL},
	{"TX2_FIFO_LEVEL",0,8,"FIFO Level of Transmit Channel. The number of words that are currently stored in the FIFO. , bit(s):7:0, default(000h), access(RO)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX2SASUDC[]=
{
	{RESERVED_SYMBOL"_31_1",1,31,"Reserved, bit(s):31:1, default(0), access(RV)",NULL},
	{"TX2_LOAD_SASUD_TO_SPDIF",0,1,"Load the User Data registers (SASUD0 - SASUD11)into buffer for insertion into S/PDIF data stream. This bit will be automatically reset to \\'0\\'., bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

static const struct EAS_RegBits g_gen3_easbb_AUD_IO_TX2SASCSC[]=
{
	{RESERVED_SYMBOL"_31_1",1,31,"Reserved, bit(s):31:1, default(0), access(RV)",NULL},
	{"TX2_LOAD_CNTL_STAT_REG",0,1,"Load the Control Status registers (TX2SASCS0 - TX2SASCS5)into buffer for insertion into S/PDIF data stream. This bit will be automatically reset to \'0\'. , bit(s):0, default(0b), access(RW)",NULL},
	CSR_BB_NULL_TERM()   /* NULL Terminated */
};

//Audio IO Subsystem Register Maps

static const struct EAS_Register g_gen3_easr_AUD_IO_SUBSYSTEM[] =
{//Audio Subsystem Register Maps
   	//Common Control Registers
	{"CSR", GEN3_AUD_IO_BASE+0x0000, g_gen3_easbb_AUD_IO_CSR, "CSR - Configuration and Status Register. This register controls clock and reset of the block, various configurations of the block and reflects general status of the block.",NULL}, /* default(00000001h) */
	{"ISRX", GEN3_AUD_IO_BASE+0x0004, g_gen3_easbb_AUD_IO_ISRX, "ISRX - IA32 Interrupt Status Register. This register reflects status of an interrupted mapped event. ",NULL}, /* default(00000000h) */
	{"IMRX", GEN3_AUD_IO_BASE+0x000C, g_gen3_easbb_AUD_IO_IMRX, "IMRX - IA32 Interrupt Mask Register. This register enables/disables interrupts. ",NULL}, /* default(00000000h) */
	{"CGR", GEN3_AUD_IO_BASE+0x002C, g_gen3_easbb_AUD_IO_CGR, "CGR - Clock Gating config register",NULL}, /* default(00000000h) */

	//DMA0 Memory Allocation and Registers
	{"DMA0_CURR_DESCR", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x1008, NULL, "DMA0_CURR_DESCR - Current Descriptor Address, [31:2]. 32-bit aligned BI address pointing to the current DMA descriptor (linked-list mode only). default(0000_0000), access(RO)",NULL},
	{"DMA0_NEXT_DESCR", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x100C, g_gen3_easbb_AUD_IO_NEXT_DESCR, "DMA0_NEXT_DESCR - Next Descriptor Address [31:2]. 32-bit aligned BI address pointing to the next DMA descriptor (linked-list mode only). default(0000_0000), access(RW)",NULL},
	{"DMA0_SRCDMA_START", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x1010, NULL, "DMA0_SRCDMA_START - Start address of the Source DMA buffer in the BI address space. This is also the current pointer into the source buffer. Bits [31:0] set the physical start address. When local address is defined as SRCDMA_START, only bits 14:2 are meaningful and point to the register in local address space. default(0000_0000), access(RW)",NULL},
	{"DMA0_DSTDMA_START", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x1014, NULL, "DMA0_DSTDMA_START - Start address of the Destination DMA buffer in the BI address space. This is also the current pointer into the destination buffer. Bits [31:0] set the physical start address. When local address is defined as DSTDMA_START, only bits 14:2 are meaningful and point to the register in local address space. default(0000_0000), access(RW)",NULL},
	{"DMA0_SRCDMA_SIZE", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x1018, NULL, "DMA0_SRCDMA_SIZE - Size of the block of data (in bytes) to fetched from the source location. When Store-and-Forward Mode is used, the register has to hold the total number (sum) of bytes in source and destination buffers associated with current descriptor. NOTE: Once the transfer starts, the SIZE value gets decremented by the number of data transferred and this field will reflect the current value. This field gets updated continuously when the transfer of data occurs.  default(0000_0000), access(RW)",NULL},
	{"DMA0_FLAGS_MODE", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x101C, g_gen3_easbb_AUD_IO_FLAGS_MODE, "DMA0_FLAGS_MODE - Miscellaneous Control/Status: Flags, Modes, Quality of Service, and Addresses (see description below for details). This register is used to start a DMA context. A context is started when a valid configuration is written into this register (the other registers of this context must be properly configured as well - FLAGS_MODE is written to last). default(0000_0000), access(RW)",NULL},
	{"DMA0_SRCDMA_STARTA", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x1020, NULL, "DMA0_SRCDMA_STARTA - This is the alias of Source DMA Start Register SRCDMA_START default(0000_0000), access(RW)",NULL},
	{"DMA0_SRCDMA_BOT", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x1024, g_gen3_easbb_AUD_IO_SRCDMA_BOT, "DMA0_SRCDMA_BOT - Address of the bottom of the DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer bottom (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA0_SRCDMA_TOP", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x1028, g_gen3_easbb_AUD_IO_SRCDMA_TOP, "DMA0_SRCDMA_TOP - Address of the top of the DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer top (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA0_DSTDMA_BOT", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x102C, g_gen3_easbb_AUD_IO_DSTDMA_BOT, "DMA0_DSTDMA_BOT - Address of the bottom of the Destination DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer bottom (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA0_DSTDMA_TOP", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x1030, g_gen3_easbb_AUD_IO_DSTDMA_TOP, "DMA0_DSTDMA_TOP - Address of the top of the Destination DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer top (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA0_DSTDMA_SIZE", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x1034, NULL, "DMA0_DSTDMA_SIZE - Size of the block of data (in bytes) to be sent to the destination location. NOTE: Once the transfer starts, the SIZE value gets decremented by the number of data transferred and this field will reflect the current value. This field gets updated continuously when the transfer of data occurs. default(0000_0000), access(RW)",NULL},
	{"DMA0_SRCDMA_STOP", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x1038, NULL, "DMA0_SRCDMA_STOP - Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space. Bits [31:0] set the physical stop address. default(0000_0000), access(RW)",NULL},
	{"DMA0_DSTDMA_STOP", GEN3_AUD_IO_BASE+DMA0_OFFSET+0x103C, NULL, "DMA0_DSTDMA_STOP - Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space. Bits [31:0] set the physical stop address. default(0000_0000), access(RW)",NULL},
	//DMA1 Memory Allocation and Registers
	{"DMA1_CURR_DESCR", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x1008, NULL, "DMA1_CURR_DESCR - Current Descriptor Address, [31:2]. 32-bit aligned BI address pointing to the current DMA descriptor (linked-list mode only). default(0000_0000), access(RO)",NULL},
	{"DMA1_NEXT_DESCR", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x100C, g_gen3_easbb_AUD_IO_NEXT_DESCR, "DMA1_NEXT_DESCR - Next Descriptor Address [31:2]. 32-bit aligned BI address pointing to the next DMA descriptor (linked-list mode only). default(0000_0000), access(RW)",NULL},
	{"DMA1_SRCDMA_START", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x1010, NULL, "DMA1_SRCDMA_START - Start address of the Source DMA buffer in the BI address space. This is also the current pointer into the source buffer. Bits [31:0] set the physical start address. When local address is defined as SRCDMA_START, only bits 14:2 are meaningful and point to the register in local address space. default(0000_0000), access(RW)",NULL},
	{"DMA1_DSTDMA_START", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x1014, NULL, "DMA1_DSTDMA_START - Start address of the Destination DMA buffer in the BI address space. This is also the current pointer into the destination buffer. Bits [31:0] set the physical start address. When local address is defined as DSTDMA_START, only bits 14:2 are meaningful and point to the register in local address space. default(0000_0000), access(RW)",NULL},
	{"DMA1_SRCDMA_SIZE", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x1018, NULL, "DMA1_SRCDMA_SIZE - Size of the block of data (in bytes) to fetched from the source location. When Store-and-Forward Mode is used, the register has to hold the total number (sum) of bytes in source and destination buffers associated with current descriptor. NOTE: Once the transfer starts, the SIZE value gets decremented by the number of data transferred and this field will reflect the current value. This field gets updated continuously when the transfer of data occurs.  default(0000_0000), access(RW)",NULL},
	{"DMA1_FLAGS_MODE", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x101C, g_gen3_easbb_AUD_IO_FLAGS_MODE, "DMA1_FLAGS_MODE - Miscellaneous Control/Status: Flags, Modes, Quality of Service, and Addresses (see description below for details). This register is used to start a DMA context. A context is started when a valid configuration is written into this register (the other registers of this context must be properly configured as well - FLAGS_MODE is written to last). default(0000_0000), access(RW)",NULL},
	{"DMA1_SRCDMA_STARTA", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x1020, NULL, "DMA1_SRCDMA_STARTA - This is the alias of Source DMA Start Register SRCDMA_START default(0000_0000), access(RW)",NULL},
	{"DMA1_SRCDMA_BOT", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x1024, g_gen3_easbb_AUD_IO_SRCDMA_BOT, "DMA1_SRCDMA_BOT - Address of the bottom of the DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer bottom (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA1_SRCDMA_TOP", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x1028, g_gen3_easbb_AUD_IO_SRCDMA_TOP, "DMA1_SRCDMA_TOP - Address of the top of the DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer top (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA1_DSTDMA_BOT", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x102C, g_gen3_easbb_AUD_IO_DSTDMA_BOT, "DMA1_DSTDMA_BOT - Address of the bottom of the Destination DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer bottom (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA1_DSTDMA_TOP", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x1030, g_gen3_easbb_AUD_IO_DSTDMA_TOP, "DMA1_DSTDMA_TOP - Address of the top of the Destination DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer top (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA1_DSTDMA_SIZE", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x1034, NULL, "DMA1_DSTDMA_SIZE - Size of the block of data (in bytes) to be sent to the destination location. NOTE: Once the transfer starts, the SIZE value gets decremented by the number of data transferred and this field will reflect the current value. This field gets updated continuously when the transfer of data occurs. default(0000_0000), access(RW)",NULL},
	{"DMA1_SRCDMA_STOP", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x1038, NULL, "DMA1_SRCDMA_STOP - Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space. Bits [31:0] set the physical stop address. default(0000_0000), access(RW)",NULL},
	{"DMA1_DSTDMA_STOP", GEN3_AUD_IO_BASE+DMA1_OFFSET+0x103C, NULL, "DMA1_DSTDMA_STOP - Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space. Bits [31:0] set the physical stop address. default(0000_0000), access(RW)",NULL},
	//DMA2 Memory Allocation and Registers
	{"DMA2_CURR_DESCR", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x1008, NULL, "DMA2_CURR_DESCR - Current Descriptor Address, [31:2]. 32-bit aligned BI address pointing to the current DMA descriptor (linked-list mode only). default(0000_0000), access(RO)",NULL},
	{"DMA2_NEXT_DESCR", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x100C, g_gen3_easbb_AUD_IO_NEXT_DESCR, "DMA2_NEXT_DESCR - Next Descriptor Address [31:2]. 32-bit aligned BI address pointing to the next DMA descriptor (linked-list mode only). default(0000_0000), access(RW)",NULL},
	{"DMA2_SRCDMA_START", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x1010, NULL, "DMA2_SRCDMA_START - Start address of the Source DMA buffer in the BI address space. This is also the current pointer into the source buffer. Bits [31:0] set the physical start address. When local address is defined as SRCDMA_START, only bits 14:2 are meaningful and point to the register in local address space. default(0000_0000), access(RW)",NULL},
	{"DMA2_DSTDMA_START", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x1014, NULL, "DMA2_DSTDMA_START - Start address of the Destination DMA buffer in the BI address space. This is also the current pointer into the destination buffer. Bits [31:0] set the physical start address. When local address is defined as DSTDMA_START, only bits 14:2 are meaningful and point to the register in local address space. default(0000_0000), access(RW)",NULL},
	{"DMA2_SRCDMA_SIZE", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x1018, NULL, "DMA2_SRCDMA_SIZE - Size of the block of data (in bytes) to fetched from the source location. When Store-and-Forward Mode is used, the register has to hold the total number (sum) of bytes in source and destination buffers associated with current descriptor. NOTE: Once the transfer starts, the SIZE value gets decremented by the number of data transferred and this field will reflect the current value. This field gets updated continuously when the transfer of data occurs.  default(0000_0000), access(RW)",NULL},
	{"DMA2_FLAGS_MODE", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x101C, g_gen3_easbb_AUD_IO_FLAGS_MODE, "DMA2_FLAGS_MODE - Miscellaneous Control/Status: Flags, Modes, Quality of Service, and Addresses (see description below for details). This register is used to start a DMA context. A context is started when a valid configuration is written into this register (the other registers of this context must be properly configured as well - FLAGS_MODE is written to last). default(0000_0000), access(RW)",NULL},
	{"DMA2_SRCDMA_STARTA", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x1020, NULL, "DMA2_SRCDMA_STARTA - This is the alias of Source DMA Start Register SRCDMA_START default(0000_0000), access(RW)",NULL},
	{"DMA2_SRCDMA_BOT", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x1024, g_gen3_easbb_AUD_IO_SRCDMA_BOT, "DMA2_SRCDMA_BOT - Address of the bottom of the DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer bottom (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA2_SRCDMA_TOP", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x1028, g_gen3_easbb_AUD_IO_SRCDMA_TOP, "DMA2_SRCDMA_TOP - Address of the top of the DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer top (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA2_DSTDMA_BOT", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x102C, g_gen3_easbb_AUD_IO_DSTDMA_BOT, "DMA2_DSTDMA_BOT - Address of the bottom of the Destination DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer bottom (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA2_DSTDMA_TOP", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x1030, g_gen3_easbb_AUD_IO_DSTDMA_TOP, "DMA2_DSTDMA_TOP - Address of the top of the Destination DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer top (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA2_DSTDMA_SIZE", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x1034, NULL, "DMA2_DSTDMA_SIZE - Size of the block of data (in bytes) to be sent to the destination location. NOTE: Once the transfer starts, the SIZE value gets decremented by the number of data transferred and this field will reflect the current value. This field gets updated continuously when the transfer of data occurs. default(0000_0000), access(RW)",NULL},
	{"DMA2_SRCDMA_STOP", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x1038, NULL, "DMA2_SRCDMA_STOP - Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space. Bits [31:0] set the physical stop address. default(0000_0000), access(RW)",NULL},
	{"DMA2_DSTDMA_STOP", GEN3_AUD_IO_BASE+DMA2_OFFSET+0x103C, NULL, "DMA2_DSTDMA_STOP - Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space. Bits [31:0] set the physical stop address. default(0000_0000), access(RW)",NULL},
	//DMA3 Memory Allocation and Registers
	{"DMA3_CURR_DESCR", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x1008, NULL, "DMA3_CURR_DESCR - Current Descriptor Address, [31:2]. 32-bit aligned BI address pointing to the current DMA descriptor (linked-list mode only). default(0000_0000), access(RO)",NULL},
	{"DMA3_NEXT_DESCR", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x100C, g_gen3_easbb_AUD_IO_NEXT_DESCR, "DMA3_NEXT_DESCR - Next Descriptor Address [31:2]. 32-bit aligned BI address pointing to the next DMA descriptor (linked-list mode only). default(0000_0000), access(RW)",NULL},
	{"DMA3_SRCDMA_START", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x1010, NULL, "DMA3_SRCDMA_START - Start address of the Source DMA buffer in the BI address space. This is also the current pointer into the source buffer. Bits [31:0] set the physical start address. When local address is defined as SRCDMA_START, only bits 14:2 are meaningful and point to the register in local address space. default(0000_0000), access(RW)",NULL},
	{"DMA3_DSTDMA_START", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x1014, NULL, "DMA3_DSTDMA_START - Start address of the Destination DMA buffer in the BI address space. This is also the current pointer into the destination buffer. Bits [31:0] set the physical start address. When local address is defined as DSTDMA_START, only bits 14:2 are meaningful and point to the register in local address space. default(0000_0000), access(RW)",NULL},
	{"DMA3_SRCDMA_SIZE", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x1018, NULL, "DMA3_SRCDMA_SIZE - Size of the block of data (in bytes) to fetched from the source location. When Store-and-Forward Mode is used, the register has to hold the total number (sum) of bytes in source and destination buffers associated with current descriptor. NOTE: Once the transfer starts, the SIZE value gets decremented by the number of data transferred and this field will reflect the current value. This field gets updated continuously when the transfer of data occurs.  default(0000_0000), access(RW)",NULL},
	{"DMA3_FLAGS_MODE", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x101C, g_gen3_easbb_AUD_IO_FLAGS_MODE, "DMA3_FLAGS_MODE - Miscellaneous Control/Status: Flags, Modes, Quality of Service, and Addresses (see description below for details). This register is used to start a DMA context. A context is started when a valid configuration is written into this register (the other registers of this context must be properly configured as well - FLAGS_MODE is written to last). default(0000_0000), access(RW)",NULL},
	{"DMA3_SRCDMA_STARTA", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x1020, NULL, "DMA3_SRCDMA_STARTA - This is the alias of Source DMA Start Register SRCDMA_START default(0000_0000), access(RW)",NULL},
	{"DMA3_SRCDMA_BOT", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x1024, g_gen3_easbb_AUD_IO_SRCDMA_BOT, "DMA3_SRCDMA_BOT - Address of the bottom of the DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer bottom (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA3_SRCDMA_TOP", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x1028, g_gen3_easbb_AUD_IO_SRCDMA_TOP, "DMA3_SRCDMA_TOP - Address of the top of the DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer top (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA3_DSTDMA_BOT", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x102C, g_gen3_easbb_AUD_IO_DSTDMA_BOT, "DMA3_DSTDMA_BOT - Address of the bottom of the Destination DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer bottom (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA3_DSTDMA_TOP", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x1030, g_gen3_easbb_AUD_IO_DSTDMA_TOP, "DMA3_DSTDMA_TOP - Address of the top of the Destination DMA buffer (used for circular buffer modes only). Bits 31:2 set the physical address of buffer top (must be 32-bit aligned). default(0000_0000), access(RW)",NULL},
	{"DMA3_DSTDMA_SIZE", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x1034, NULL, "DMA3_DSTDMA_SIZE - Size of the block of data (in bytes) to be sent to the destination location. NOTE: Once the transfer starts, the SIZE value gets decremented by the number of data transferred and this field will reflect the current value. This field gets updated continuously when the transfer of data occurs. default(0000_0000), access(RW)",NULL},
	{"DMA3_SRCDMA_STOP", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x1038, NULL, "DMA3_SRCDMA_STOP - Stop address of the Source DMA buffer (used for circular buffer modes only) in the BI address space. Bits [31:0] set the physical stop address. default(0000_0000), access(RW)",NULL},
	{"DMA3_DSTDMA_STOP", GEN3_AUD_IO_BASE+DMA3_OFFSET+0x103C, NULL, "DMA3_DSTDMA_STOP - Stop address of the Destination DMA buffer (used for circular buffer modes only) in the BI address space. Bits [31:0] set the physical stop address. default(0000_0000), access(RW)",NULL},
	//I2S Interface Memory Mapping and Registers
 	//RX0
	{"RX0SACR0", GEN3_AUD_IO_BASE+0x3000, g_gen3_easbb_AUD_IO_RX0SACR0, "RX0SACR0 - Global Control Register",NULL}, /* default(00000000h) */
	{"RX0SACR1", GEN3_AUD_IO_BASE+0x3004, g_gen3_easbb_AUD_IO_RX0SACR1, "RX0SACR1 - Serial Audio I2S/MSB-Justified Control Register",NULL}, /* default(00010000h) */
	{"RX0SASR0", GEN3_AUD_IO_BASE+0x3008, g_gen3_easbb_AUD_IO_RX0SASR0, "RX0SASR0 - Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL}, /* default(00000000h) */
	{"RX0SAIMR", GEN3_AUD_IO_BASE+0x300C, g_gen3_easbb_AUD_IO_RX0SAIMR, "RX0SAIMR - Serial Audio Interrupt Mask Register",NULL}, /* default(00000000h) */
	{"RX0SAISR", GEN3_AUD_IO_BASE+0x3010, g_gen3_easbb_AUD_IO_RX0SAISR, "RX0SAISR - Serial Audio Interrupt Status Register",NULL}, /* default(00000000h) */
	{"RX0SADIV", GEN3_AUD_IO_BASE+0x3014, g_gen3_easbb_AUD_IO_RX0SADIV, "RX0SADIV - Audio Clock Divider Register",NULL}, /* default(00000006h) */
	{"RX0SARR", GEN3_AUD_IO_BASE+0x3018, NULL, "RX0SARR - Serial Audio Receive Register",NULL}, /* default(00000000h) */
	{"RX0SAFTH", GEN3_AUD_IO_BASE+0x301C, g_gen3_easbb_AUD_IO_RX0SAFTH, "RX0SAFTH - Serial Audio FIFO Threshold Register",NULL}, /* default(00000000h) */
	{"RX0SAFL", GEN3_AUD_IO_BASE+0x3020, g_gen3_easbb_AUD_IO_RX0SAFL, "RX0SAFL - Serial Audio FIFO Level Register",NULL}, /* default(00000000h) */
	{"RX0SADESC", GEN3_AUD_IO_BASE+0x3024, g_gen3_easbb_AUD_IO_RX0SADESC, "RX0SADESC - Audio capture Block size Register",NULL}, /* default(00000000h) */
	{"RX0SATS", GEN3_AUD_IO_BASE+0x3028, NULL, "RX0SATS - Audio Capture block timestamp ",NULL}, /* default(00000000h) */
	{"RX0SABAP", GEN3_AUD_IO_BASE+0x302C, NULL, "RX0SABAP - Audio Sample block buffer pointer",NULL}, /* default(00000000h) */
	{"RX0SACUDR", GEN3_AUD_IO_BASE+0x3030, NULL, "RX0SACUDR - Audio Capture User Data bit FIFO ",NULL}, /* default(00000000h) */
	{"RX0SACSR", GEN3_AUD_IO_BASE+0x3034, NULL, "RX0SACSR - Audio Capture Channel Status bit FIFO",NULL}, /* default(00000000h) */
	{"RX0SAVR", GEN3_AUD_IO_BASE+0x3038, NULL, "RX0SAVR - Audio Capture Validity bit FIFO",NULL}, /* default(00000000h) */
	{"RX0SPDBP", GEN3_AUD_IO_BASE+0x303C, NULL, "RX0SPDBP - Audio Capture SPDIF Block address Pointer FIFO",NULL}, /* default(00000000h) */
	//TX0
	{"TX0SACR0", GEN3_AUD_IO_BASE+0x2000, g_gen3_easbb_AUD_IO_TX0SACR0, "TX0SACR0 - Global Control Register",NULL}, /* default(00000000h) */
	{"TX0SACR1", GEN3_AUD_IO_BASE+0x2004, g_gen3_easbb_AUD_IO_TX0SACR1, "TX0SACR1 - Serial Audio I2S/MSB-Justified Control Register",NULL}, /* default(00000000h) */
	{"TX0SASR0", GEN3_AUD_IO_BASE+0x2008, g_gen3_easbb_AUD_IO_TX0SASR0, "TX0SASR0 - Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL}, /* default(00001001h) */
	{"TX0SAIMR", GEN3_AUD_IO_BASE+0x200C, g_gen3_easbb_AUD_IO_TX0SAIMR, "TX0SAIMR - Serial Audio Interrupt Mask Register",NULL}, /* default(00000000h) */
	{"TX0SAISR", GEN3_AUD_IO_BASE+0x2010, g_gen3_easbb_AUD_IO_TX0SAISR, "TX0SAISR - Serial Audio Interrupt Status Register",NULL}, /* default(00000000h) */
	{"TX0SADIV", GEN3_AUD_IO_BASE+0x2014, g_gen3_easbb_AUD_IO_TX0SADIV, "TX0SADIV - Audio Clock Divider Register",NULL}, /* default(00000006h) */
	{"TX0SATR", GEN3_AUD_IO_BASE+0x2018, NULL, "TX0SATR - Serial Audio Transmit Register",NULL}, /* default(00000000h) */
	{"TX0SAFTH", GEN3_AUD_IO_BASE+0x201C, g_gen3_easbb_AUD_IO_TX0SAFTH, "TX0SAFTH - Serial Audio FIFO Threshold Register",NULL}, /* default(00000000h) */
	{"TX0SAFL", GEN3_AUD_IO_BASE+0x2020, g_gen3_easbb_AUD_IO_TX0SAFL, "TX0SAFL - Serial Audio FIFO Level Register",NULL}, /* default(00000000h) */
	{"TX0SASUD0",  GEN3_AUD_IO_BASE+0x2040, NULL,  "TX0SASUD0 -  S/PDIF transmit user data bits 31:0 (for SASUD0) - bytes 0-3 (transmitted first) ",NULL}, /* default(00000000h) */
	{"TX0SASUD1",  GEN3_AUD_IO_BASE+0x2044, NULL,  "TX0SASUD1 -  S/PDIF transmit user data bits 63:32 (for SASUD1)",NULL}, /* default(00000000h) */
	{"TX0SASUD2",  GEN3_AUD_IO_BASE+0x2048, NULL,  "TX0SASUD2 -  S/PDIF transmit user data bits 96:64 (for SASUD2)",NULL}, /* default(00000000h) */
	{"TX0SASUD3",  GEN3_AUD_IO_BASE+0x204C, NULL,  "TX0SASUD3 -  S/PDIF transmit user data bits 127:97 (for SASUD3)",NULL}, /* default(00000000h) */
	{"TX0SASUD4",  GEN3_AUD_IO_BASE+0x2050, NULL,  "TX0SASUD4 -  S/PDIF transmit user data bits 159 :128 (for SASUD4)",NULL}, /* default(00000000h) */
	{"TX0SASUD5",  GEN3_AUD_IO_BASE+0x2054, NULL,  "TX0SASUD5 -  S/PDIF transmit user data bits 191:160 (for SASUD5)",NULL}, /* default(00000000h) */
	{"TX0SASUD6",  GEN3_AUD_IO_BASE+0x2058, NULL,  "TX0SASUD6 -  S/PDIF transmit user data bits 223:191 (for SASUD6)",NULL}, /* default(00000000h) */
	{"TX0SASUD7",  GEN3_AUD_IO_BASE+0x205C, NULL,  "TX0SASUD7 -  S/PDIF transmit user data bits 255:224 (for SASUD7)",NULL}, /* default(00000000h) */
	{"TX0SASUD8",  GEN3_AUD_IO_BASE+0x2060, NULL,  "TX0SASUD8 -  S/PDIF transmit user data bits 287:256 (for SASUD8)",NULL}, /* default(00000000h) */
	{"TX0SASUD9",  GEN3_AUD_IO_BASE+0x2064, NULL,  "TX0SASUD9 -  S/PDIF transmit user data bits 319:288 (for SASUD9)",NULL}, /* default(00000000h) */
	{"TX0SASUD10", GEN3_AUD_IO_BASE+0x2068, NULL, "TX0SASUD10 - S/PDIF transmit user data bits 351:320 (for SASUD10)",NULL}, /* default(00000000h) */
	{"TX0SASUD11", GEN3_AUD_IO_BASE+0x206C, NULL, "TX0SASUD11 - S/PDIF transmit user data bits 383:352 (for SASUD11) - transmitted last          ",NULL}, /* default(00000000h) */
	{"TX0SASUDC", GEN3_AUD_IO_BASE+0x2070, g_gen3_easbb_AUD_IO_TX0SASUDC, "TX0SASUDC - S/PDIF transmit user data control Register",NULL}, /* default(00000000h) */
	{"TX0SASCS0", GEN3_AUD_IO_BASE+0x2080, NULL, "TX0SASCS0 - S/PDIF transmit channel status Register. Channel Status bits 31:0 (for SASCS0) - bytes 0-3 (Transmitted first)",NULL}, /* default(00000000h) */
	{"TX0SASCS1", GEN3_AUD_IO_BASE+0x2084, g_gen3_easbb_AUD_IO_TXSASCS1, "TX0SASCS1 - S/PDIF transmit channel status Register. Channel Status bits 63:32 (for SASCS1)",NULL}, /* default(00000000h) */
	{"TX0SASCSC", GEN3_AUD_IO_BASE+0x208C, g_gen3_easbb_AUD_IO_TX0SASCSC, "TX0SASCSC - S/PDIF transmit Channel status ctrl Register",NULL}, /* default(00000000h) */
	//TX1
	{"TX1SACR0", GEN3_AUD_IO_BASE+0x2100, g_gen3_easbb_AUD_IO_TX1SACR0, "TX1SACR0 - Global Control Register",NULL}, /* default(00000000h) */
	{"TX1SACR1", GEN3_AUD_IO_BASE+0x2104, g_gen3_easbb_AUD_IO_TX1SACR1, "TX1SACR1 - Serial Audio I2S/MSB-Justified Control Register",NULL}, /* default(00000000h) */
	{"TX1SASR0", GEN3_AUD_IO_BASE+0x2108, g_gen3_easbb_AUD_IO_TX1SASR0, "TX1SASR0 - Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL}, /* default(00001001h) */
	{"TX1SAIMR", GEN3_AUD_IO_BASE+0x210C, g_gen3_easbb_AUD_IO_TX1SAIMR, "TX1SAIMR - Serial Audio Interrupt Mask Register",NULL}, /* default(00000000h) */
	{"TX1SAISR", GEN3_AUD_IO_BASE+0x2110, g_gen3_easbb_AUD_IO_TX1SAISR, "TX1SAISR - Serial Audio Interrupt Status Register",NULL}, /* default(00000000h) */
	{"TX1SADIV", GEN3_AUD_IO_BASE+0x2114, g_gen3_easbb_AUD_IO_TX1SADIV, "TX1SADIV - Audio Clock Divider Register",NULL}, /* default(00000006h) */
	{"TX1SATR", GEN3_AUD_IO_BASE+0x2118, NULL, "TX1SATR - Serial Audio Transmit Register",NULL}, /* default(00000000h) */
	{"TX1SAFTH", GEN3_AUD_IO_BASE+0x211C, g_gen3_easbb_AUD_IO_TX1SAFTH, "TX1SAFTH - Serial Audio FIFO Threshold Register",NULL}, /* default(00000000h) */
	{"TX1SAFL", GEN3_AUD_IO_BASE+0x2120, g_gen3_easbb_AUD_IO_TX1SAFL, "TX1SAFL - Serial Audio FIFO Level Register",NULL}, /* default(00000000h) */
	{"TX1SASUD0",  GEN3_AUD_IO_BASE+0x2040, NULL,  "TX1SASUD0 -  S/PDIF transmit user data bits 31:0 (for SASUD0) - bytes 0-3 (transmitted first) ",NULL}, /* default(00000000h) */
	{"TX1SASUD1",  GEN3_AUD_IO_BASE+0x2044, NULL,  "TX1SASUD1 -  S/PDIF transmit user data bits 63:32 (for SASUD1)",NULL}, /* default(00000000h) */
	{"TX1SASUD2",  GEN3_AUD_IO_BASE+0x2048, NULL,  "TX1SASUD2 -  S/PDIF transmit user data bits 96:64 (for SASUD2)",NULL}, /* default(00000000h) */
	{"TX1SASUD3",  GEN3_AUD_IO_BASE+0x204C, NULL,  "TX1SASUD3 -  S/PDIF transmit user data bits 127:97 (for SASUD3)",NULL}, /* default(00000000h) */
	{"TX1SASUD4",  GEN3_AUD_IO_BASE+0x2050, NULL,  "TX1SASUD4 -  S/PDIF transmit user data bits 159 :128 (for SASUD4)",NULL}, /* default(00000000h) */
	{"TX1SASUD5",  GEN3_AUD_IO_BASE+0x2054, NULL,  "TX1SASUD5 -  S/PDIF transmit user data bits 191:160 (for SASUD5)",NULL}, /* default(00000000h) */
	{"TX1SASUD6",  GEN3_AUD_IO_BASE+0x2058, NULL,  "TX1SASUD6 -  S/PDIF transmit user data bits 223:191 (for SASUD6)",NULL}, /* default(00000000h) */
	{"TX1SASUD7",  GEN3_AUD_IO_BASE+0x205C, NULL,  "TX1SASUD7 -  S/PDIF transmit user data bits 255:224 (for SASUD7)",NULL}, /* default(00000000h) */
	{"TX1SASUD8",  GEN3_AUD_IO_BASE+0x2060, NULL,  "TX1SASUD8 -  S/PDIF transmit user data bits 287:256 (for SASUD8)",NULL}, /* default(00000000h) */
	{"TX1SASUD9",  GEN3_AUD_IO_BASE+0x2064, NULL,  "TX1SASUD9 -  S/PDIF transmit user data bits 319:288 (for SASUD9)",NULL}, /* default(00000000h) */
	{"TX1SASUD10", GEN3_AUD_IO_BASE+0x2068, NULL, "TX1SASUD10 - S/PDIF transmit user data bits 351:320 (for SASUD10)",NULL}, /* default(00000000h) */
	{"TX1SASUD11", GEN3_AUD_IO_BASE+0x206C, NULL, "TX1SASUD11 - S/PDIF transmit user data bits 383:352 (for SASUD11) - transmitted last          ",NULL}, /* default(00000000h) */
	{"TX1SASUDC", GEN3_AUD_IO_BASE+0x2170, g_gen3_easbb_AUD_IO_TX1SASUDC, "TX1SASUDC - S/PDIF transmit user data control Register",NULL}, /* default(00000000h) */
	{"TX1SASCS0", GEN3_AUD_IO_BASE+0x2180, NULL, "TX1SASCS0 - S/PDIF transmit channel status Register. Channel Status bits 31:0 (for SASCS0) - bytes 0-3 (Transmitted first)",NULL}, /* default(00000000h) */
	{"TX1SASCS1", GEN3_AUD_IO_BASE+0x2184, g_gen3_easbb_AUD_IO_TXSASCS1, "TX1SASCS1 - S/PDIF transmit channel status Register. Channel Status bits 63:32 (for SASCS1)",NULL}, /* default(00000000h) */
	{"TX1SASCSC", GEN3_AUD_IO_BASE+0x218C, g_gen3_easbb_AUD_IO_TX1SASCSC, "TX1SASCSC - S/PDIF transmit Channel status ctrl Register",NULL}, /* default(00000000h) */
	//TX2
	{"TX2SACR0", GEN3_AUD_IO_BASE+0x2200, g_gen3_easbb_AUD_IO_TX2SACR0, "TX2SACR0 - Global Control Register",NULL}, /* default(00000000h) */
	{"TX2SACR1", GEN3_AUD_IO_BASE+0x2204, g_gen3_easbb_AUD_IO_TX2SACR1, "TX2SACR1 - Serial Audio I2S/MSB-Justified Control Register",NULL}, /* default(00000000h) */
	{"TX2SASR0", GEN3_AUD_IO_BASE+0x2208, g_gen3_easbb_AUD_IO_TX2SASR0, "TX2SASR0 - Serial Audio I2S/MSB-Justified Interface and FIFO Status Register",NULL}, /* default(00001001h) */
	{"TX2SAIMR", GEN3_AUD_IO_BASE+0x220C, g_gen3_easbb_AUD_IO_TX2SAIMR, "TX2SAIMR - Serial Audio Interrupt Mask Register",NULL}, /* default(00000000h) */
	{"TX2SAISR", GEN3_AUD_IO_BASE+0x2210, g_gen3_easbb_AUD_IO_TX2SAISR, "TX2SAISR - Serial Audio Interrupt Status Register",NULL}, /* default(00000000h) */
	{"TX2SADIV", GEN3_AUD_IO_BASE+0x2214, g_gen3_easbb_AUD_IO_TX2SADIV, "TX2SADIV - Audio Clock Divider Register",NULL}, /* default(00000006h) */
	{"TX2SATR", GEN3_AUD_IO_BASE+0x2218, NULL, "TX2SATR - Serial Audio Transmit Register",NULL}, /* default(00000000h) */
	{"TX2SAFTH", GEN3_AUD_IO_BASE+0x221C, g_gen3_easbb_AUD_IO_TX2SAFTH, "TX2SAFTH - Serial Audio FIFO Threshold Register",NULL}, /* default(00000000h) */
	{"TX2SAFL", GEN3_AUD_IO_BASE+0x2220, g_gen3_easbb_AUD_IO_TX2SAFL, "TX2SAFL - Serial Audio FIFO Level Register",NULL}, /* default(00000000h) */
	{"TX2SASUD0",  GEN3_AUD_IO_BASE+0x2040, NULL,  "TX2SASUD0 -  S/PDIF transmit user data bits 31:0 (for SASUD0) - bytes 0-3 (transmitted first) ",NULL}, /* default(00000000h) */
	{"TX2SASUD1",  GEN3_AUD_IO_BASE+0x2044, NULL,  "TX2SASUD1 -  S/PDIF transmit user data bits 63:32 (for SASUD1)",NULL}, /* default(00000000h) */
	{"TX2SASUD2",  GEN3_AUD_IO_BASE+0x2048, NULL,  "TX2SASUD2 -  S/PDIF transmit user data bits 96:64 (for SASUD2)",NULL}, /* default(00000000h) */
	{"TX2SASUD3",  GEN3_AUD_IO_BASE+0x204C, NULL,  "TX2SASUD3 -  S/PDIF transmit user data bits 127:97 (for SASUD3)",NULL}, /* default(00000000h) */
	{"TX2SASUD4",  GEN3_AUD_IO_BASE+0x2050, NULL,  "TX2SASUD4 -  S/PDIF transmit user data bits 159 :128 (for SASUD4)",NULL}, /* default(00000000h) */
	{"TX2SASUD5",  GEN3_AUD_IO_BASE+0x2054, NULL,  "TX2SASUD5 -  S/PDIF transmit user data bits 191:160 (for SASUD5)",NULL}, /* default(00000000h) */
	{"TX2SASUD6",  GEN3_AUD_IO_BASE+0x2058, NULL,  "TX2SASUD6 -  S/PDIF transmit user data bits 223:191 (for SASUD6)",NULL}, /* default(00000000h) */
	{"TX2SASUD7",  GEN3_AUD_IO_BASE+0x205C, NULL,  "TX2SASUD7 -  S/PDIF transmit user data bits 255:224 (for SASUD7)",NULL}, /* default(00000000h) */
	{"TX2SASUD8",  GEN3_AUD_IO_BASE+0x2060, NULL,  "TX2SASUD8 -  S/PDIF transmit user data bits 287:256 (for SASUD8)",NULL}, /* default(00000000h) */
	{"TX2SASUD9",  GEN3_AUD_IO_BASE+0x2064, NULL,  "TX2SASUD9 -  S/PDIF transmit user data bits 319:288 (for SASUD9)",NULL}, /* default(00000000h) */
	{"TX2SASUD10", GEN3_AUD_IO_BASE+0x2068, NULL, "TX2SASUD10 - S/PDIF transmit user data bits 351:320 (for SASUD10)",NULL}, /* default(00000000h) */
	{"TX2SASUD11", GEN3_AUD_IO_BASE+0x206C, NULL, "TX2SASUD11 - S/PDIF transmit user data bits 383:352 (for SASUD11) - transmitted last          ",NULL}, /* default(00000000h) */
	{"TX2SASUDC", GEN3_AUD_IO_BASE+0x2270, g_gen3_easbb_AUD_IO_TX2SASUDC, "TX2SASUDC - S/PDIF transmit user data control Register",NULL}, /* default(00000000h) */
	{"TX2SASCS0", GEN3_AUD_IO_BASE+0x2280, NULL, "TX2SASCS0 - S/PDIF transmit channel status Register. Channel Status bits 31:0 (for SASCS0) - bytes 0-3 (Transmitted first)",NULL}, /* default(00000000h) */
	{"TX2SASCS1", GEN3_AUD_IO_BASE+0x2284, g_gen3_easbb_AUD_IO_TXSASCS1, "TX2SASCS1 - S/PDIF transmit channel status Register. Channel Status bits 63:32 (for SASCS1)",NULL}, /* default(00000000h) */
	{"TX2SASCSC", GEN3_AUD_IO_BASE+0x228C, g_gen3_easbb_AUD_IO_TX2SASCSC, "TX2SASCSC - S/PDIF transmit Channel status ctrl Register",NULL}, /* default(00000000h) */

	//End - NULL terminate	svn
   	CSR_NULL_TERM()
};//Audio IO Subsystem
#endif /* SVEN_INTERNAL_BUILD */


/*  Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_gen3_AUD_IO_specific_events[] =
{
     /*APM reserved events 1 -20*/
    { "APM_INPUT_PORT_ADD", 1, " Input SMD handle: 0x%x, Input Port Handle: 0x%x, timed input?: %d, atc_input_h: %d", NULL },
    { "APM_OUTPUT_PORT_ADD", 2, " input_smd_h: 0x%x, Input Port Handle: 0x%x", NULL },
    { "APM_DECODER_CODEC_CHANGED", 3, " Processor Handle: 0x%x, Old Dec Algo: 0x%x, New Dec Algo: 0x%x", NULL },
    { "APM_DECODER_SETUP", 4, " Proc Handle: 0x%x, Decoder configured codec: 0x%x", NULL },
    { "APM_INPUT_RECONFIG", 5, " Proc Handle: 0x%x, Old Format: 0x%x, New Format: 0x%x", NULL },
    { "APM_SET_PCM_FORMAT", 6, " Proc Handle: 0x%x, sample_size: %d, sample_rate: %d, chan_config: 0x%x, chan_count: %d", NULL },
    { "APM_SET_OOB_BUF_ATTR", 7, " input_smd_h: 0x%x, pts: 0x%x%08x, sample_rate: %d, sample_size: %d, chan_count: %d", NULL },
    { "APM_RENDER_SETUP", 8, " HW_ID: 0x%x, format: %d, ch_config: %d, sample_size: %d, sample_rate: %d, prefill_ms: %d", NULL },
    { "APM_SET_STATE", 9, " Proc Handle: %d, input_smd_h: %d, Old state: %d, New state %d", NULL },
    { "APM_NEWSEGMENT", 10, " input_smd_h: %d, start: 0x%x, stop: 0x%x, local_pres_time: 0x%x, req_rate: %d, our_cur_rate: %d", NULL },
    { "APM_ADVANCE_TO_PTS", 11, " Proc Handle: %d, input_smd_h: %d, our local_start_pts: 0x%x%08x, new req_adv_to_pts: 0x%x%08x", NULL },
    { "APM_INPUT_SET_PLAY_RATE", 12, " Proc Handle: %d, input_smd_h: %d, current rate: %d linear_time_to_play: 0x%x%08x", NULL },
    { "APM_INPUT_DEQUEUE", 13, " proc_h: %d, input_h: %d, is_timed_stream: %d, buf_size: %d, PTS: 0x%x%08x ", NULL },
    { "APM_POST_ATC_PIPE_RECONFIG", 14, " proc_h: %d, forced_reconfig: %d, input_count: %d, output_count: %d", NULL },
    { "APM_FLUSH", 15, " proc_h: %d, input_smd_h: %d", NULL },
    { "APM_INPUT_DEQUEUE_FAILED", 16, " proc_h: %d, input_h: %d, is_timed_stream: %d, format: %d, has_passthr_stream: %d", NULL },
    { "APM_OUTPUT_PORT_WRITE_FAILED", 17, " Proc Handle: %d, Output handle: %d, Output Port Handle: %d, Result: %d ", NULL },
    { "APM_OUTPUT_PORT_IN_DEQUEUE_FAILED", 18, " Proc Handle: %d, Output Handle: %d, Output Port Handle: %d, Input Queue Handle: %d, Result: %d", NULL },
    { "APM_HANDLE_PTS", 19, " scaled_pts: 0x%x%08x, smd_base_time: 0x%x%08x, apm_base_time: 0x%x%08x", NULL },
    { "APM_INPUT_AD", 20, " input_id: %d, ad_valid: %d, fade: %d, pan: %d", NULL },
    { "APM_PTS_LATE", 21, " last_scaled_pts: 0x%x%08x, smd_base_time: 0x%x%08x, curr_time: 0x%x%08x", NULL },
    { "APM_SCALE_PTS", 22, " Stream_PTS: 0x%x%08x, linear_time: 0x%x%08x, scaled_time_pts: 0x%x%08x", NULL },
    { "APM_CAPTURE_PTS_ASSOCIATION", 23, " sync_state: %d, sync_offset: %d, data_type: %u, subdata_type: %u, data type dependent info: %u, burst_payload_error: %d", NULL },
    { "APM_OUTPUT_PORT_TIMING_INFO", 24, " Format: %d, Original PTS: 0x%x, Local PTS: 0x%x, local PTS delta: %d ", NULL },

      /*CORE reserved events 25 - 32*/
     { "CORE_NORMALIZE_SAMPLES", 25, " Norm_smpl_rate: %d, rend_smpl_rate: %d, in_smpl_cnt: 0x%x%08x, out_smpl_cnt: 0x%x%08x", NULL },

     /*ATC reserved events 33 -64*/
    { "ATC_SET_TIME_PERIOD", 33, " atc_h: %d, stream_h: %d, time_ms: %d", NULL },
    { "ATC_SET_BASE_TIME", 34, " atc_h: %d, stream_h: %d, base_time: 0x%x%08x", NULL },
    { "ATC_SET_CLOCK", 35, " atc_h: %d, stream_h: %d, clock_h: %d, chunk_size_ms: %d ", NULL },
    { "ATC_PTS_CLOCK_COMPARE", 36, " atc_h: %d, stream_h: %d, PTS: 0x%x%08x, pts_clock_diff: %d", NULL },
    { "ATC_SEND_SILENCE_BUFFER", 37, " atc_h: %d, stream_h: %d, buffer_level: %d", NULL },
    { "ATC_PRE_BUFFER_CHOP", 38, " chunk_size: %d, copy_size: %d, in_level: %d, out_level: %d, new_in_base: 0x%x, new_out_base: 0x%x", NULL },
    { "ATC_POST_BUFFER_CHOP", 39, " atc_h: %d, stream_h: %d, out_buf_ready?: %d, in_bytes_copied: %d, out_level: %d, input_buf_bytes_left: %d\n", NULL },
    { "ATC_CLOCK_ALARM", 40, " stream_h: %d, out_buf_level: %d, buffer_render_time_stamp:0x%x%08x, render_sampl_count:0x%x%08x", NULL },
    { "ATC_FILL_SILENCE", 41, " atc_h: %d, stream_h: %d, in_buf_level: %d, copy_size: %d, out_buf_level: %d ", NULL },
    { "ATC_INPUT_DEQUEUE", 42, " atc_h: %d, stream_h: %d, in_buf_level: %d, PTS:0x%x%08x, Timed_mode: %d ", NULL },
    { "ATC_TIME_STAMP", 43, " stream_h: %d, ticks_til_rndr: %d, smpls_till_rndr: 0x%x%08x , render_time_stamp:0x%x%08x ", NULL },
    { "ATC_GET_BASE_NUMBERS", 44, " atc_h: %d, stream_h: %d, base_sample_count:0x%x%08x, atc_base_time:0x%x%08x ", NULL },
    { "ATC_PTS_LATE", 45, " stream_h: %d, PTS:0x%x%08x, smple_cnt_drift:0x%x%08x, first_frame?: %d ", NULL },
    { "ATC_PTS_EARLY", 46, " stream_h: %d, PTS:0x%x%08x, smple_cnt_drift:0x%x%08x ", NULL },
    { "ATC_PAD_SILENCE", 47, " buffer level after pad: %d, curr_chunk_size: %d, desired pad:%d actual pad:%d ", NULL },
    { "ATC_FIRST_PTS_NOT_FOUND", 48, " atc_h: %d, stream_h: %d, in_buf_level: %d, PTS:0x%x%08x, Timed_mode: %d ", NULL },
    { "ATC_SET_STATE", 49, " atc_h: %d, stream_h h: %d, Old state: %d, New state %d", NULL },
    { "ATC_PTS_LATE_FFWD", 50, " stream_h:%d, smpl_cnt_drift: 0x%x%08x, smpls_to_drop_in_ffwd: %d, (smpls_to_drop_in_ffwd / 2): %d", NULL },
    { "ATC_PTS_EARLY_FFWD", 51, " stream_h:%d, smpl_cnt_drift: 0x%x%08x, smpls_to_drop_in_ffwd: %d, (smpls_to_drop_in_ffwd / 2): %d, silence_bytes_pad: %d", NULL },
    { "ATC_DROPPED_SAMPLES", 52, " req_num_smple_to_drp:%d, actual_num_smpls_drpd: %d, bytes_dropped: %d, out_buf_level: %d", NULL },
    { "ATC_SET_NEW_ALARM_CLOCK", 53, " default_clock:%d, primary_clock: %d, timer_clock: %d, prev_timer_clock: %d, alarm_intrvl_ticks: %d ticks_since_last_alarm: %d", NULL },
    { "ATC_AFTER_EVENT_WAIT", 54, " Triggered Event:%d, Num Events: %d", NULL },
    { "ATC_CALC_FIRST_FRAME", 55, " stream_h: %d, render_delay_ticks: %d, ticks_till_render: %d , render_time_stamp:0x%x%08x,  total_sample_delay: 0x%x", NULL },
    { "ATC_INVALID_METADATA", 56, " stream_h: %d, tags_present: %d, buffer_level: %d, sample_rate: %d, sample_size: %d, channel_count: %d", NULL },
    { "ATC_INPUT_METADATA", 57, " new_chunk_size: %d, ch_config: 0x%x, buffer_level: %d, sample_rate: %d, sample_size: %d, ch_count: %d", NULL },
    { "ATC_RESET_STREAM", 58, " atc_h: %d, stream_h h: %d", NULL },
    { "ATC_SILENCE_TOP_OFF_ERROR", 59, " atc_h: %d, stream_h h: %d, line num: %d, curr_chnk_sz: %d output_buf_level: %d ", NULL },
    { "ATC_CLOCK_DRIFT_DETECT", 60, " actual_dif: %d, abs(actual_dif): %d curr_time: 0x%x%08x, last_time: 0x%x%08x", NULL },
    { "ATC_SET_TIMING_ACCURACY", 61, " atc_h: %d, stream_h: %d, allowed_ms_drift_ahead: %d, allowed_ms_drift_behind: %d", NULL },
    { "ATC_UNDERRUN_DETECTED", 62, " stream_h: %d, sample_drift: %d, sample_rate: %d, underrun_event_h: %d, underrun_amt: %d", NULL },
    { "ATC_DISCARDED_BUFFER", 63, " atc_h: %d, stream_h: %d, in_buf_level: %d, PTS:0x%x%08x, Timed_mode: %d ", NULL },
    { "ATC_NEWSEGMENT", 64, " input_smd_h: %d, start: 0x%x, stop: 0x%x, local_pres_time: 0x%x, req_rate: %d, our_cur_rate: %d", NULL },
    { "ATC_SCALE_PTS", 65, " Stream_PTS: 0x%x%08x, linear_time: 0x%x%08x, scaled_time_pts: 0x%x%08x", NULL },
    { "ATC_INPUT_DEQUEUE_FAILED", 66, " atc_h: %d, stream_h: %d, Timed_mode: %d ", NULL },
    { "ATC_OUTPUT_ENQUEUE_FAILED", 67, " atc_h: %d,  stream_h: %d, out_buf_level: %d, buffer_render_time_stamp:0x%x%08x, Timed_mode: %d", NULL },
    { "ATC_OUTPUT_ATEMPT_LATE", 68, " stream_h: %d, curr_time_rts_dif: %d, clock_accrcy_dif: %d, curr_rend_time: %d, rts: %d, orig_rend_time: %d", NULL },
    { "ATC_PTS_EARLY_DISCONTINUITY_DISCARD", 69, " stream_h: %d, level: %d, smple_cnt_drift: %d, early_smple_cnt_threshld:%d, scaled_PTS:0x%x%08x ", NULL },
    { "ATC_RENDER_DRIFT_DETECTED", 70, " atc_h: %d, stream_h: %d, drift: %d, prev_render_time: %d, curr_render_time:%d, render_exists?:%d ", NULL },
    { "ATC_STOP_TIME_CHECK", 71, " buffer_level: %d, bytes_discrd: %d curr_buffer_time: 0x%x, data_in_ticks: 0x%x, buffer_end_time: 0x%x, stop: 0x%x ", NULL },
    { "ATC_SET_SLAVE_CLOCK", 72, " atc_h: %d, stream_h: %d, clock_h: %d, chunk_size_ms: %d ", NULL },
    { "ATC_ADJUST_SLAVE_CLOCK", 73, " atc_h: %d, stream_h: %d, PTS:0x%x%08x, base_sample_count:0x%x%08x ", NULL },
    { "ATC_SET_PTS_MODE", 74, " atc_h: %d, stream_h: %d, pts_mode: %d ", NULL },
    { "ATC_OUT_OF_SEGMENT_DROP", 75, " atc_h: %d, stream_h: %d, PTS:0x%x%08x, segment.start:0x%x, segment.stop:0x%x ", NULL },
    { "ATC_START_OF_SEGMENT_FOUND", 76, " atc_h: %d, stream_h: %d  PTS:0x%x%08x, segment.start:0x%x, segment.stop:0x%x ", NULL },
    { "ATC_INPUT_CLOCK_DRIFT_DETECT", 77, " stream_h: %d, cumulative_sample_drift: %d sample_drift_per_chunk: %d, minimal_adjust: %d cumulative_sample_correction: %d", NULL },
    { "ATC_DISCONTINUITY_UPDATE", 78, " discnt action: %d, discnt offset: %d, out_buf_level: %d, silence_bytes: %d, chunk size: %d, last_buffer_ended_in_silence: %d", NULL },
    { "ATC_DISCONTINUITY_SILENCE_FILL", 79, " prev_discnt action: %d, prev_discnt offset: %d, out_buf_level: %d, silence_bytes: %d, chunk size: %d, last_buffer_ended_in_silence: %d", NULL },

     /*RENDER reserved events 97 -128*/
     { "RENDER_STARTED", 97, " HW ID: 0x%x, prefill bytes: %d, prefill bytes max: %d, prefill ms: %d", NULL },
     { "RENDER_PUSH_BUFFER", 98, " HW ID: 0x%x, Buffer ID: %d, Buffer Size: %d", NULL },
     { "RENDER_PULL_BUFFER", 99, " HW ID: 0x%x, Buffer ID: %d, Buffer Size: %d, Total bytes rendered: 0x%x%08x", NULL },
     { "RENDER_BUFFER_EMPTY_CALLBACK", 100, " HW ID: 0x%x", NULL },
     { "RENDER_BUFFER_DONE", 101, " HW ID: 0x%x, Done Buffer ID: %d, Samples Rendered: 0x%x%08x, Chunk_size: %d", NULL },
     { "RENDER_SAFE_TO_CLOSE_CALLBACK", 102, " HW ID: 0x%x, Buffer Count: %d", NULL },
     { "RENDER_ADDED_SILENCE", 103, " HW ID: 0x%x, Buffer ID: %d, Buffer Level: %d", NULL },
     { "RENDER_DEQUEUE", 104, " HW ID: 0x%x, Buf Size: %d, Local PTS:0x%x%08x, render_time_stamp:0x%x%08x", NULL },
     { "RENDER_BUFFER_DONE_TIMING_INFO", 105, " Clock Time:0x%x%08x, Original PTS:0x%x%08x, Local PTS:0x%x%08x", NULL },
     { "RENDER_CLOCK_ACCURACY", 106, " Clock accuracy error: %d ", NULL },
     { "RENDER_TIME_STAMP_LATE", 107, " HW ID: 0x%x, Buffer time slot: 0x%x%08x, Render time slot: 0x%x%08x, diff: %d", NULL },
     { "RENDER_TRY_TO_PLAY", 108, " HW ID: 0x%x, Buf Size: %d, Buffer time slot:0x%x%08x, Render time slot: 0x%x%08x", NULL },
     { "RENDER_DEQUEUE_FAILED", 109, " HW ID: 0x%x, dequeue result: %d, Queue handle: %d", NULL },
     { "RENDER_BEHIND_NOTIFY_ATC", 110, " HW ID: 0x%x", NULL },
     { "RENDER_SAMPLE_COUNT_RESYNC", 111, " HW ID: 0x%x, Original sample count: 0x%x%08x, Adjusted sample count: 0x%x%08x", NULL },
     { "RENDER_CHUNK_SIZE_MISMATCH", 112, " Input buffer: smpl_rate %d, smpl_size %d, ch_cnt %d | Render: smpl_rate %d, smpl_size %d, ch_cnt %d", NULL },
     { "RENDER_TIME_STAMP_EARLY", 113, " HW ID: 0x%x, Buffer time slot: 0x%x%08x, Render time slot: 0x%x%08x, diff: %d", NULL },
     { "RENDER_CLOCK_RECOVERY", 114, " HW ID: 0x%x, Render clock : 0x%x%08x, ATC clock: 0x%x%08x, diff: %d", NULL },
     

     /* RENDER HAL events reserved events 129 -160*/
     { "HAL_RENDER_NODE_CLEAN_UP", 129, " DMA: %d, Buffer ID: %d, Node Count: %d", NULL },
     { "HAL_RENDER_LL_INTERUPT", 130, " DMA: %d, Curr Nd: 0x%x, Flags: 0x%x, Cnt: %d, Level_Cnt: %d", NULL },
     { "HAL_RENDER_BUFFER_ADD", 131, " DMA: %d, Curr Nd: 0x%x, Next Nd: 0x%x, DMA Active? %d, New Node: 0x%x, Node Count: %d", NULL },
     { "HAL_RENDER_BUFFER_ADD_FAILED", 132, " DMA: %d, Curr Nd: 0x%x, Next Nd: 0x%x, DMA Active? %d, New Node: 0x%x, Node Count: %d", NULL },

     /*PSM reserved events 161 -192*/
     { "PSM_WAITING_FOR_IO_EVENT", 161, " ", NULL },
     { "PSM_INPUT_JOB_SENT", 162, " wl: %d, pipe_type: %d, buffer_count: %d", NULL },
     { "PSM_INPUT_JOB_SEND_ERROR", 163, " wl: %d, pipe_type: %d, buffer_count: %d", NULL },
     { "PSM_INPUT_JOB_QUEUE_FULL", 164, " wl: %d, pipe_type: %d, buffer_count: %d", NULL },      
     { "PSM_INPUT_JOB_NONE", 165, " wl: %d, pipe_type: %d", NULL },
     { "PSM_INPUT_JOB_DEQUEUED", 166, " wl: %d, pipe_type: %d, buffer_count: %d", NULL },      
     { "PSM_OUTPUT_JOB_RECEIVED", 167, " wl: %d, pipe_type: %d, buffer_count: %d", NULL },
     { "PSM_OUTPUT_JOB_RECEIVE_ERROR", 168, " wl: %d, pipe_type: %d", NULL },
     { "PSM_OUTPUT_QUEUE_FULL", 169, " wl: %d, queue_handle: %d, enqueue result: %d start_to_stop: %d", NULL },
     { "PSM_OUTPUT_JOB_NONE", 170, " wl: %d, pipe_type: %d", NULL },
	{ "PSM_OUTPUT_BUFFER_ENQUEUED", 171, " wl: %d, pts: 0x%x%08x, ch_num: %d sample_rate: %d sample_size: %d ", NULL},
	{ "PSM_INPUT_JOB_ALLIGN_TS", 172, " wl: %d, Latest_TS: 0x%x, TS0: 0x%x, TS1: 0x%x, TS2: 0x%x, TS3: 0x%x ", NULL},

     /*DSP reserved events 193 - 215*/
     { "DSP_IPCD_INTR", 193, " wl: %d, message: %d, data: %d", NULL },
     { "DSP_IPCX_INTR", 194, " wl: %d, message: %d, data: %d", NULL },
     { "DSP_WRITE_INPUT_JOB", 195, " wl: %d, cur_input_job_handle: %d, cur_input_job_valid: %d", NULL },
     { "DSP_READ_OUTPUT_JOB", 196, " wl: %d, cur_output_job_handle: %d, cur_output_job_valid: %d", NULL },
      { "DSP_JOB_DESC", 197, " handle: %d, valid: %d, wl_handle: %d, buffer_count: %d", NULL },
      { "DSP_HTOD_MESSAGE", 198, " wl: %d, message: %d, data: %d, wait_for_response: %d", NULL },
      { "DSP_HTOD_MESSAGE_DSP_BUSY", 199, " wl: %d, message: %d, data: %d, wait_for_response: %d ipcx: 0x%x", NULL },
      { "DSP_HTOD_MESSAGE_DSP_NO_RESPONSE", 200, " wl: %d, message: %d, data: %d, wait_for_response: %d ipcx: 0x%x", NULL },
      { "DSP_HTOD_MESSAGE_DSP_RETURNED_ERROR", 201, " wl: %d, message: %d, data: %d, wait_for_response: %d ret_val: %d", NULL },
      { "DSP_HTOD_MESSAGE_DSP_SENT_ERROR", 201, " wl: %d, message: %d, data: %d", NULL },

    /*ALSA Shim Events 215 - 225*/
    {"ALSA_SHIM_PREPARE", 215, " Buf bytes:%d, Per bytes:%d, Pre bytes:%d, Rate:%d, Format:%d, nChan:%d", NULL},
    {"ALSA_SHIM_TRIGGER", 216, " Trigger Command: %d", NULL},
    {"ALSA_SHIM_POINTER", 217, " Read Pointer Offset: %d", NULL},
    {"ALSA_SHIM_ACK",     218, " Write Pointer Offset: %d", NULL},
    {"ALSA_SHIM_COPY",    219, " Copy %d bytes from %p to %p", NULL},

     /*Capture Events 226 - 240 */
     { "CAPTURE_STARTED", 226, " HW ID: 0x%x, prefill bytes: %d, prefill bytes max: %d, prefill ms: %d", NULL },
     { "CAPTURE_ADD_BUFFER", 227, " HW ID: 0x%x, Buffer ID: %d, Buffer Size: %d, Total bytes captured: 0x%x%08x", NULL },
     { "CAPTURE_LATENCY", 228, " HW ID: 0x%x, set_max: %d, total: %d, atc_in: %d, atc_out: %d, render_in: %d", NULL },
     { "CAPTURE_BUFFER_DISCARD", 229, " HW ID: 0x%x, Buffer ID: %d, Buffer level: %d, cause: %d", NULL },
     { "CAPTURE_BUFFER_EMPTY", 230, " HW ID: 0x%x", NULL },
     { "CAPTURE_BUFFER_DONE", 231, " HW ID: 0x%x, Done Buffer ID: %d, Samples Captured: 0x%x%08x, Chunk_size: %d", NULL },
     { "CAPTURE_SAFE_TO_CLOSE", 232, " HW ID: 0x%x, Buffer Count: %d", NULL },
     { "CAPTURE_DEV_STATE", 233, " HW ID: 0x%x, dev_state: %d", NULL },
     { "CAPTURE_CLOCK_RECOVERY", 234, " HW ID: 0x%x, Capture clock: 0x%x%08x, ATC clock: 0x%x%08x, diff: %d",NULL },
     
     
     /*Capture HAL Events 241 - 250 */
     { "HAL_CAPTURE_NODE_CLEAN_UP", 241, " DMA: %d, Buffer ID: %d, Node Count: %d", NULL },
     { "HAL_CAPTURE_LL_INTERUPT", 242, " DMA: %d, Curr Nd: 0x%x, Flags: 0x%x, Cnt: %d, Level_Cnt: %d", NULL },
     { "HAL_CAPTURE_BUFFER_ADD", 243, " DMA: %d, Curr Nd: 0x%x, Next Nd: 0x%x, DMA Active? %d, New Node: 0x%x, Node Count: %d", NULL },
     { "HAL_CAPTURE_BUFFER_ADD_FAILED", 244, " DMA: %d, Curr Nd: 0x%x, Next Nd: 0x%x, DMA Active? %d, New Node: 0x%x, Node Count: %d", NULL },


     /* FREE 250 - 255*/

    { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_gen3_AUD_IO_sven_module =
{
    "GEN3_AUD_IO",               /* Module Name */
    SVEN_module_GEN3_AUD_IO,     /* Module ID> */
    1024*1024,                  /* Memory size of register space */
#ifdef SVEN_INTERNAL_BUILD
    g_gen3_easr_AUD_IO_SUBSYSTEM,     /* What is the latest HW version to use? */
#else
    NULL,
#endif /* !SVEN_INTERNAL_BUILD */
    "AUDIO: AUD_IO (Intel(r) Media Processor CE 31xx)",      /* TODO: Get a better text string */
    g_gen3_AUD_IO_specific_events, /* TODO-Later: Define important events specific to my module */
    NULL /* extension list */
};
#endif


