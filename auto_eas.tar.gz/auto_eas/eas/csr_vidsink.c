/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif

#ifdef SVEN_INTERNAL_BUILD
/* NO Registers for the mvc remux as it is entirely a software component */
static const struct EAS_Register g_csr_VIDSINK[] =
{
   { NULL,0,NULL,"",NULL }   /* NULL Terminated */
};
#endif /* INTERNAL_BUILD */

/*   Use the below structure for creating trackable high level events versus
 *  register access.  Example of event is interrupt occured.
 */
static const struct SVEN_Module_EventSpecific g_VIDSINK_specific_events[] =
{

   /* VIDSINK instance opened */
   { "OPEN",                   1, "   ID: %d", NULL },

   /* VIDSINK instance closed */
   { "CLOSE",                  2, "   ID:%d", NULL },

   /* Set vidsink state */
   { "SET_STATE",              3, "   ID:%d, Old_State:%d -> New_State:%d", NULL },

   /* Set base time */
   { "BASE_TIME",              4, "   base_time:%x%x", NULL },

   /* Set play rate */
   { "PLAY_RATE",              5, "   linear_ch_time:%x%x, rate:%d", NULL },

   /* Flush */
   { "FLUSH",                  6, "   tail:%d, head:%d, disp:%d", NULL },

   /* Set global scaling params */
   { "SET_GLOBAL_SCALE",       7, "   dest_w:%d, dest_h:%d, dest_x:%d, dest_y:%d, crop_en:%d, scale_policy:%d", NULL },

   /* Paused animation is requested */
   { "PAUSE_ANIM",             8, "   buf_id:%d", NULL },

   /* push frame to vidpproc */
   { "PUSH_FRAME",             9, "   buf_id:%d, dest_w:%d, dest_h:%d, dest_x:%d, dest_y:%d, crop_en:%d", NULL },

   /* Add into frame queue */
   { "ADD_QUEUE",              10, "  head:%d, tail:%d, disp:%d, pts=%x%x", NULL },

   /* Remove last frame from queue */
   { "REMOVE_QUEUE",           11, "  head:%d, tail:%d, disp:%d, pts=%x%x", NULL },

   /* De-reference frame */
   { "DEREF_FRAME",            12, "   buf_id:%d", NULL },

   /* DPE input empty */
   { "DPE_EMPTY",              13, "   frm_by_frm:%d", NULL },

   /* Vsync Event */
   { "VSYNC",                  14, "   ", NULL },

   /* Input buffer avaliable */
   { "INPUT_AVAL",             15, "   buf_id:%d, frm_by_frm:%d, global:%d", NULL },

   /* DPE input full */
   { "DPE_FULL",               16, "   frm_by_frm:%d", NULL },
   
   /* Re-send queue frames */
   { "RESEND_QUEUE_FRAMES",    19, "  total:%d, head:%d, tail:%d, disp:%d", NULL },

   /* Get disply frame */
   { "GET_DISP_FRM",           20, "   buffer_id:%d, head:%d, tail:%d, disp:%d, pts:%x%x", NULL },

   /* Input tag is present on the buffer */
   { "TAG_PRESENT",            29, "   buffer_id:%d, start:%d, stop:%d", NULL },

   /* Resend tag */
   { "TAG_RESEND",             30, "   start:%d, stop:%d", NULL },

   /* Pause */
   { "PAUSE",                31, "    ", NULL },

   /* Pause */
   { "PLAY",              32, "    ", NULL },

   /* Queue status */
   { "QUEUE_STATUS",   33, "           head:%d, tail:%d, disp:%d, indx:%d, pts=%x%x", NULL },

   /* Wrong PTS */
   { "WRONG_PTS",       34, "    ", NULL },

   /* Input event received */
   { "IN_EVENT_RCV",       35, "   frm_by_frm:%d", NULL },

   /* Flush non disp frames */
   { "FLUSH_NON_DISP",    36, "   ID:%d", NULL },
   
   { NULL, 0, NULL, NULL }
};

static const struct ModuleReverseDefs g_VIDSINK_sven_module =
{
   "SW_VIDSINK",                  /*  */
   SVEN_module_VIDSINK,         /* Find your module in <sven_module.h> */
   0,                          /* Size of MMRs */
#ifdef SVEN_INTERNAL_BUILD
   g_csr_VIDSINK,               /*  */
#else
   NULL,                       /* What is the latest HW version to use? */
#endif
   "VIDSINK: VIDSINK",/* Get a better text string */
   g_VIDSINK_specific_events,   /* Define important events specific to my module */
   NULL                        /* extension list */
};
