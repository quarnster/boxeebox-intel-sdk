/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#ifndef SVEN_MODULE_H
#include "sven_module.h"
#endif


/* External Routine in sven_modules.c */
/* =========================================================================*/
const struct ModuleReverseDefs *svenreverse_GetModuleTables(
    enum SVEN_Module             module );
extern const struct ModuleReverseDefs *svenreverse_GetModuleTables_ByName(
    const char                  *module_name );

/* =========================================================================*/
static const char *create_reserved_regbits_name(
    char        *name_buf,
    int          regbits_lsb,
    int          regbits_width )
{
    if ( 1 == regbits_width )
    {
        sprintf( name_buf, "RSVD_%d", regbits_lsb );
    }
    else
    {
        sprintf( name_buf, "RSVD_%d_%d", (regbits_lsb+regbits_width-1), regbits_lsb );
    }

    return( (const char *)name_buf );
}

static int dump_csr_include_regbit_lsbs(
	FILE								*fp,
	const struct EAS_Register			*reg,
	const char							*unit_prefix )
{
	int									 err = 0;
	const struct EAS_RegBits			*regbits;

	regbits = reg->reg_bits;

	while ( NULL != regbits->regbits_name )
	{
        const char      *bitsname;
        char             rsvd_bitsname[64];

        if ( '\0' != regbits->regbits_name[0] )
        {
            bitsname = regbits->regbits_name;
        }
        else
        {
            bitsname = create_reserved_regbits_name( rsvd_bitsname, regbits->regbits_lsb_pos, regbits->regbits_width );
        }

		fprintf( fp, "\t#define BLSB_%s_%s_%s\t%d\n",
			unit_prefix,
			reg->reg_name,
			bitsname,
			regbits->regbits_lsb_pos );

		regbits++;
	}

	return( err );
}

static int dump_csr_include_regbit_widths(
	FILE								*fp,
	const struct EAS_Register			*reg,
	const char							*unit_prefix )
{
	int									 err = 0;
	const struct EAS_RegBits			*regbits;

	regbits = reg->reg_bits;

	while ( NULL != regbits->regbits_name )
	{
        const char      *bitsname;
        char             rsvd_bitsname[64];

        if ( '\0' != regbits->regbits_name[0] )
        {
            bitsname = regbits->regbits_name;
        }
        else
        {
            bitsname = create_reserved_regbits_name( rsvd_bitsname, regbits->regbits_lsb_pos, regbits->regbits_width );
        }

		fprintf( fp, "\t#define BWID_%s_%s_%s\t%d\n",
			unit_prefix,
			reg->reg_name,
			bitsname,
			regbits->regbits_width );

		regbits++;
	}

	return( err );
}

static int dump_csr_include_regbit_masks(
	FILE								*fp,
	const struct EAS_Register			*reg,
	const char							*unit_prefix )
{
	int									 err = 0;
	const struct EAS_RegBits			*regbits;

	regbits = reg->reg_bits;

	while ( NULL != regbits->regbits_name )
	{
        const char      *bitsname;
        char             rsvd_bitsname[64];

        if ( '\0' != regbits->regbits_name[0] )
        {
            bitsname = regbits->regbits_name;
        }
        else
        {
            bitsname = create_reserved_regbits_name( rsvd_bitsname, regbits->regbits_lsb_pos, regbits->regbits_width );
        }

		if ( 1 == regbits->regbits_width )
		{
			fprintf( fp, "\t#define BMSK_%s_%s_%s\t(1<<%d) /* == 0x%08x: %s */\n",
				unit_prefix,
				reg->reg_name,
				bitsname,
				regbits->regbits_lsb_pos,
				(((1<<regbits->regbits_width)-1)<<regbits->regbits_lsb_pos),
                (regbits->regbits_comment ? regbits->regbits_comment : "") );
		}
		else
		{
#if 1
			fprintf( fp, "\t#define BMSK_%s_%s_%s\t0x%08x /* %s */\n",
				unit_prefix,
				reg->reg_name,
				bitsname,
				(((1<<regbits->regbits_width)-1)<<regbits->regbits_lsb_pos),
                (regbits->regbits_comment ? regbits->regbits_comment : "") );
#else
			fprintf( fp, "\t#define BMSK_%s_%s_%s\t(((1<<%d)-1)<<%d) /* == 0x%08x: %s */\n",
				unit_prefix,
				reg->reg_name,
				bitsname,
				regbits->regbits_width,
				regbits->regbits_lsb_pos,
				(((1<<regbits->regbits_width)-1)<<regbits->regbits_lsb_pos),
                (regbits->regbits_comment ? regbits->regbits_comment : "") );
#endif
		}

		regbits++;
	}

	return( err );
}
static int dump_csr_include_regbit_BITFIELD(
	FILE								*fp,
	const struct EAS_Register			*reg,
	const char							*unit_prefix )
{
	int									 err = 0;
	const struct EAS_RegBits			*regbits;

	regbits = reg->reg_bits;

	while ( NULL != regbits->regbits_name )
	{
		
        fprintf( fp, "\t#define BITFIELD_%s_%s_%s\t 0x%04x, %d, %d, 0x%08x\n",
			unit_prefix,
			reg->reg_name,
			regbits->regbits_name,
			reg->reg_offset,
			regbits->regbits_lsb_pos,
			regbits->regbits_width,
			(((1<<regbits->regbits_width)-1)<<regbits->regbits_lsb_pos) );

		regbits++;
	}

	return( err );
}

#if 0
static int dump_csr_include_reg_bits(
	FILE								*fp,
	const struct EAS_Register			*reg,
	const char							*unit_prefix,
	unsigned int						 flags )
{
	int									 err = 0;
	const struct EAS_RegBits			*regbits;

	regbits = reg->reg_bits;

	while ( NULL != regbits->regbits_name )
	{
        const char      *bitsname;
        char             rsvd_bitsname[64];

        if ( '\0' != regbits->regbits_name[0] )
        {
            bitsname = regbits->regbits_name;
        }
        else
        {
            bitsname = create_reserved_regbits_name( rsvd_bitsname, regbits->regbits_lsb_pos, regbits->regbits_width );
        }

		if ( (1<<1) & flags )
		{
			fprintf( fp, "\t#define BLSB_%s_%s_%s\t%d\n",
				unit_prefix,
				reg->reg_name,
				bitsname,
				regbits->regbits_lsb_pos );
		}


		if ( (1<<2) & flags )
		{
			fprintf( fp, "\t#define BWID_%s_%s_%s\t%d\n",
				unit_prefix,
				reg->reg_name,
				bitsname,
				regbits->regbits_width );
		}

		if ( (1<<3) & flags )
		{
		    if ( 1 == regbits->regbits_width )
		    {
			    fprintf( fp, "\t#define BMSK_%s_%s_%s\t(1<<%d) /* == 0x%08x */\n",
				    unit_prefix,
				    reg->reg_name,
				    bitsname,
				    regbits->regbits_lsb_pos,
				    (((1<<regbits->regbits_width)-1)<<regbits->regbits_lsb_pos) );
		    }
		    else
		    {
			    fprintf( fp, "\t#define BMSK_%s_%s_%s\t(((1<<%d)-1)<<%d) /* == 0x%08x */\n",
				    unit_prefix,
				    reg->reg_name,
				    bitsname,
				    regbits->regbits_width,
				    regbits->regbits_lsb_pos,
				    (((1<<regbits->regbits_width)-1)<<regbits->regbits_lsb_pos) );
		    }
		}

		regbits++;
	}

	return( err );
}
#endif

static int dump_csr_include_reg_offsets(
	FILE								*fp,
	const struct EAS_Register			*reg,
	const char							*unit_prefix,
	unsigned int						 flags )
{
	int									 err = 0;

    if ( NULL == reg )  return(0);

	while ( NULL != reg->reg_name )
	{
		fprintf( fp, "#define ROFF_%s_%s\t0x%x /* %s */ \n",
			unit_prefix,
			reg->reg_name,
			reg->reg_offset,
            reg->reg_comment ? reg->reg_comment : "" );
        fprintf( fp, "\t#define BITFIELD_%s_%s\t 0x%04x, 0, 32, 0xffffffff  /* roff, lsb, width, mask */\n",
			unit_prefix,
			reg->reg_name,
			reg->reg_offset );

		if ( NULL != reg->reg_bits )
		{
            if ( 1 & flags ) {
			    fprintf( fp, "\t/* Register Bit LSB Positions for %s_%s */\n", unit_prefix, reg->reg_name );
			    dump_csr_include_regbit_lsbs(fp,reg,unit_prefix);
            }
            if ( 2 & flags ) {
			    fprintf( fp, "\t/* Register Bit Widths for %s_%s */\n", unit_prefix, reg->reg_name );
			    dump_csr_include_regbit_widths(fp,reg,unit_prefix);
            }
            if ( 4 & flags ) {
    			fprintf( fp, "\t/* Register Bit MASKS for %s_%s */\n", unit_prefix, reg->reg_name );
			    dump_csr_include_regbit_masks(fp,reg,unit_prefix);
            }
            if ( 8 & flags ) {
    			fprintf( fp, "\t/* Register BITFIELD for %s_%s - roff, lsb, width, mask */\n", unit_prefix, reg->reg_name );
			    dump_csr_include_regbit_BITFIELD(fp,reg,unit_prefix);
            }
		}

		reg++;
	}

	return( err );
}

static int dump_csr_event_specific(
	FILE								*fp,
	const struct SVEN_Module_EventSpecific	*mes,
	const char							*unit_prefix )
{
	int									 err = 0;

	while ( NULL != mes->mes_name )
	{
		fprintf( fp, "#define SVEN_MODULE_EVENT_%s_%s\t0x%x\n",
			unit_prefix,
			mes->mes_name,
			(unsigned int) mes->mes_subtype );

		mes++;
	}

	return( err );
}

static int csr_name_is_valid(
    const char      *name )
{
    int             i = 0;

    while ( '\0' != name[i] )
    {
        if ( '_' == name[i] )
        {
        }
        else if (
            isspace(name[i]) ||
            ispunct(name[i]) ||
           !isprint(name[i]) )
        {
            return(0);
        }

        i++;
    }

    return(1);
}

static int sanity_check_csr_regs(
	FILE								*fp,
	const struct EAS_Register			*reg,
	const char							*unit_prefix )
{
	int									 err = 0;

    if ( NULL == reg )  return(0);
    
	while ( NULL != reg->reg_name )
	{
        if ( !csr_name_is_valid( reg->reg_name ) )
        {
		    fprintf( fp, "ERR: Register name %s:\"%s\" cannot be #define because of invalid chars in the name\n",
			    unit_prefix, reg->reg_name );

            err++;
        }


		if ( NULL != reg->reg_bits )
		{
	        const struct EAS_RegBits			*regbits;

	        regbits = reg->reg_bits;

	        while ( NULL != regbits->regbits_name )
	        {
                if ( !csr_name_is_valid( regbits->regbits_name ) )
                {
			        fprintf( fp, "ERR: Register Bitfield %s:%s:\"%s\" cannot be #define because of invalid chars in the name\n",
				        unit_prefix, reg->reg_name, regbits->regbits_name );

                    err++;
                }

                regbits++;
            }
		}

		reg++;
	}

	return( err );
}

static int sanity_check_csr_event_specific(
	FILE								*fp,
	const struct SVEN_Module_EventSpecific	*mes,
	const char							*unit_prefix )
{
    int         err = 0;

	while ( NULL != mes->mes_name )
	{
        if ( !csr_name_is_valid( mes->mes_name ) )
        {
		    fprintf( fp, "ERR: Unit Specific Event %s:\"%s\" cannot be #define because of invalid chars in the name\n",
			    unit_prefix, mes->mes_name );

            err++;
        }

		mes++;
	}

    return( err );
}

static int sanity_check_csr_duplicated_names(
	FILE								*fp,
	const struct EAS_Register			*reg,
	const char							*unit_prefix )
{
    int         err = 0;

    if ( NULL == reg )  return(0);

	while ( NULL != reg->reg_name )
	{
	    const struct EAS_Register			*freg;

        /* "forward" register */
        freg = reg+1;
	    while ( NULL != freg->reg_name )
	    {
            if ( !strcasecmp( reg->reg_name, freg->reg_name ) )
            {
		        fprintf( fp, "ERR: Duplicated Register Name %s:\"%s\"\n",
			        unit_prefix, reg->reg_name );

                err++;
                break;
            }

            freg++;
        }

		if ( NULL != reg->reg_bits )
		{
	        const struct EAS_RegBits			*regbits;

	        regbits = reg->reg_bits;

	        while ( NULL != regbits->regbits_name )
	        {
                /* ALL "Reserved" bitfields are zero length strings */
                if ( '\0' != regbits->regbits_name[0] )
                {
	                const struct EAS_RegBits			*fregbits;

                    /* "forward" regbits */
	                fregbits = regbits+1;
	                while ( NULL != fregbits->regbits_name )
	                {
                        if ( !strcasecmp( regbits->regbits_name, fregbits->regbits_name ) )
                        {
		                    fprintf( fp, "ERR: Duplicated Register Bitfield Name %s:\"%s\".\"%s\"\n",
			                    unit_prefix, reg->reg_name, regbits->regbits_name );

                            err++;
                            break;
                        }

                        fregbits++;
                    }
                }

                regbits++;
            }
        }
		reg++;
	}

    return( err );
}

static const char *bsd_license_txt = 
"/*\n"
"\n"
"  This file is provided under a dual BSD/GPLv2 license.  When using or \n"
"  redistributing this file, you may do so under either license.\n"
"\n"
"  GPL LICENSE SUMMARY\n"
"\n"
"  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.\n"
"\n"
"  This program is free software; you can redistribute it and/or modify \n"
"  it under the terms of version 2 of the GNU General Public License as\n"
"  published by the Free Software Foundation.\n"
"\n"
"  This program is distributed in the hope that it will be useful, but \n"
"  WITHOUT ANY WARRANTY; without even the implied warranty of \n"
"  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU \n"
"  General Public License for more details.\n"
"\n"
"  You should have received a copy of the GNU General Public License \n"
"  along with this program; if not, write to the Free Software \n"
"  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.\n"
"  The full GNU General Public License is included in this distribution \n"
"  in the file called LICENSE.GPL.\n"
"\n"
"  Contact Information:\n"
"    Intel Corporation\n"
"    2200 Mission College Blvd.\n"
"    Santa Clara, CA  97052\n"
"\n"
"  BSD LICENSE \n"
"\n"
"  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.\n"
"  All rights reserved.\n"
"\n"
"  Redistribution and use in source and binary forms, with or without \n"
"  modification, are permitted provided that the following conditions \n"
"  are met:\n"
"\n"
"    * Redistributions of source code must retain the above copyright \n"
"      notice, this list of conditions and the following disclaimer.\n"
"    * Redistributions in binary form must reproduce the above copyright \n"
"      notice, this list of conditions and the following disclaimer in \n"
"      the documentation and/or other materials provided with the \n"
"      distribution.\n"
"    * Neither the name of Intel Corporation nor the names of its \n"
"      contributors may be used to endorse or promote products derived \n"
"      from this software without specific prior written permission.\n"
"\n"
"  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS \n"
"  \"AS IS\" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT \n"
"  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR \n"
"  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT \n"
"  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, \n"
"  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT \n"
"  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, \n"
"  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY \n"
"  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT \n"
"  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE \n"
"  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.\n"
"\n"
"*/\n";

static int dump_csr_include_file(
	FILE								*fp,
	const struct ModuleReverseDefs		*mrd,
	const char							*unit_prefix,
    int                                  deprecated )
{
    if ( !sanity_check_csr_regs( fp, mrd->mrd_regdefs, unit_prefix ) &&
         !sanity_check_csr_event_specific( fp, mrd->mrd_event_specific, unit_prefix  ) &&
         !sanity_check_csr_duplicated_names( fp, mrd->mrd_regdefs, unit_prefix ) )
    {
	    fprintf( fp, "#ifndef %s_REGOFFS_H\n", unit_prefix );
	    fprintf( fp, "#define %s_REGOFFS_H 1\n", unit_prefix );

	    if ( deprecated ) fprintf( fp, "#warning including deprecated file %s_REGOFFS_H please use sanitized filename\n", unit_prefix );

	    fprintf( fp, "%s", bsd_license_txt );
        
	    fprintf( fp, "\n\n");
	    fprintf( fp, "/* Module %s CSR Definitions */\n", unit_prefix );
	    fprintf( fp, "/* WARNING: This file is Machine Generated using sven_csr.c */\n");
	    fprintf( fp, "\n\n");

	    dump_csr_include_reg_offsets( fp,
	       mrd->mrd_regdefs,
	       unit_prefix,
	       0xf );

	    fprintf( fp, "\n\n");
	    fprintf( fp, "/* Module %s SPECIFIC SVEN Events */\n", unit_prefix );
	    fprintf( fp, "\n\n");

	    dump_csr_event_specific( fp,
		    mrd->mrd_event_specific,
		    unit_prefix );

	    fprintf( fp, "\n\n");

	    fprintf( fp, "#endif /* %s_REGOFFS_H */\n", unit_prefix );
    }
    else
    {
        return(1);  /* names not sane */
    }

	return(0);
}

static int dump_csr_xml_file(
	FILE								*fp,
	const struct ModuleReverseDefs		*mrd,
	const char							*unit_prefix )
{
    if ( !sanity_check_csr_regs( fp, mrd->mrd_regdefs, unit_prefix ) &&
         !sanity_check_csr_event_specific( fp, mrd->mrd_event_specific, unit_prefix  ) &&
         !sanity_check_csr_duplicated_names( fp, mrd->mrd_regdefs, unit_prefix ) )
    {
        if ( NULL != mrd->mrd_regdefs )
        {
            extern void DumpXML_ModuleReverse(
	            FILE                            *fp,
	            const struct ModuleReverseDefs	*mrd );

            DumpXML_ModuleReverse( fp, mrd );
        }
    }
    else
    {
        return(1);  /* names not sane */
    }

	return(0);
}

static const char *skip_platform_prefix( const char *module_name )
{
    const char  *cp;

    cp = module_name;

    /* Skip to just past First Underscore to generate #defines */
    while ( '\0' != *cp++ )
    {
        if ( '_' == *cp )   /* found the underscore */
        {
            cp++;   /* step past it then... */
            break;
        }
    }

    return(cp);
}

static int sven_validate_enum(
    enum SVEN_Module         module,
    const char              *modulename )
{
    int                              err = 0;
    const struct ModuleReverseDefs  *mrd;

    if ( NULL != (mrd = svenreverse_GetModuleTables(module)) )
    {
        if ( strcasecmp( modulename, mrd->mrd_name ) )
        {
            err = 1;
            printf( "ERR: Module %d \"%s\" does not match expected \"%s\" \n",
                module, mrd->mrd_name, modulename  );
        }
    }

    return(err);
}

int main(
	int		 argc,
	char	*argv[] )
{

	int			err = 0;
    int         print_usage = 1;
    int         print_avail_modules = 0;
    int         validate_avail_modules = 0;

	if ( argc > 1 )
	{
        const struct ModuleReverseDefs  *mrd;

        if ( NULL != (mrd = svenreverse_GetModuleTables_ByName( argv[1] )) )
        {
            int              i;
            const char      *cp;
            char             module_define_name[64];

            i = 0;

            cp = skip_platform_prefix( argv[1] );
            while ( '\0' != *cp )
            {   /* convert the module to upper case */
                module_define_name[i++] = toupper(*cp++);
            }
            module_define_name[i] = '\0';

            /* Dump the file out */
            if ( (argc > 2) && !strcasecmp( argv[2], "XML" ) )
            {
    			err = dump_csr_xml_file( stdout, mrd, module_define_name );
            }
            else
            {
                int             deprecated = 0;

                if ( (argc > 2) && !strcasecmp( argv[2], "deprecated" ) )
                {
                    deprecated = 1;
                }

    			err = dump_csr_include_file( stdout, mrd, module_define_name, deprecated );
            }

            if ( !err )
            {
                print_usage = 0;
            }
        }
        else if ( !strcasecmp( argv[1], "modules" ) )
        {
            print_avail_modules = 1;
            print_usage = 0;
        }
        else if ( !strcasecmp( argv[1], "validate" ) )
        {
            validate_avail_modules = 1;
            print_usage = 1;
        }
   	}

    if ( print_usage )
	{
        char                *cp;
        enum SVEN_Module     module;
        static char          modules_available[2048];

        cp = modules_available;
        modules_available[0] = '\0';
        cp += sprintf( cp, "modules|validate|" );

        for ( module = 0; module < SVEN_module_MAX; module++ )
        {
            const struct ModuleReverseDefs  *mrd;

            if ( NULL != (mrd = svenreverse_GetModuleTables(module)) )
            {
                if ( NULL != mrd->mrd_name )
                {
                    cp += sprintf(cp,"%s|",mrd->mrd_name);
                }
            }
        }

		printf( "usage: %s [%s]\n", argv[0], modules_available );
	}

    if ( print_avail_modules || validate_avail_modules )
	{
        enum SVEN_Module     module;

        /* Validate enum SVEN_Module with internal tables */
        if ( validate_avail_modules )
        {
            printf("Validate Module Enumeration:\n");
            err += sven_validate_enum( SVEN_module_invalid,		 "invalid"		);
            err += sven_validate_enum( SVEN_module_CPU,          "CPU");
            err += sven_validate_enum( SVEN_module_GEN1_AUDIO,    "GEN1_AUDIO");
            err += sven_validate_enum( SVEN_module_GEN1_PREFILT,  "GEN1_TSP");
            err += sven_validate_enum( SVEN_module_GEN1_MPEG2E,   "GEN1_MPEG2E");
            err += sven_validate_enum( SVEN_module_GEN1_VCAP,     "GEN1_VCAP");
            err += sven_validate_enum( SVEN_module_GEN1_PMU,      "GEN1_PMU");
            err += sven_validate_enum( SVEN_module_TBE_AVI,      "TBE_AVI");
            err += sven_validate_enum( SVEN_module_TEST_APP,     "TEST_APP");
            err += sven_validate_enum( SVEN_module_GEN1_ADI, 	 "GEN1_ADI");
            err += sven_validate_enum( SVEN_module_GEN1_TSDEMUX,	 "GEN1_TSDEMUX");
            err += sven_validate_enum( SVEN_module_GEN1_VDC,	 	 "GEN1_VDC");
            err += sven_validate_enum( SVEN_module_GEN1_MPG2VD,	 "GEN1_MPG2VD");
            err += sven_validate_enum( SVEN_module_GEN1_EXPBUS,	 "GEN1_EXPBUS");
            err += sven_validate_enum( SVEN_module_GEN1_UEE,	 	 "GEN1_UEE");
            err += sven_validate_enum( SVEN_module_GEN1_I2C,	 	 "GEN1_I2C");
            err += sven_validate_enum( SVEN_module_GEN1_UART,	 "GEN1_UART");
            err += sven_validate_enum( SVEN_module_GEN1_GFX,	 	 "GEN1_GFX");
    	    err += sven_validate_enum( SVEN_module_GEN1_MCU,	 	 "GEN1_MCU");
    	    err += sven_validate_enum( SVEN_module_GEN1_XAB_VID,  "GEN1_XAB_VID");
    	    err += sven_validate_enum( SVEN_module_GEN1_XAB_APER, "GEN1_XAB_APER");
    	    err += sven_validate_enum( SVEN_module_GEN1_XAB_XPORT,"GEN1_XAB_XPORT");
    	    err += sven_validate_enum( SVEN_module_SMD_CORE,     "SW_SMD_CORE");
            err += sven_validate_enum( SVEN_module_GEN3_AUD_IO,    "GEN3_AUD_IO" );
            if ( err ) printf("Validate Module Enumeration: FAIL, %d errors\n", err );
            else       printf("Validate Module Enumeration: PASS\n");
        }

        if ( print_avail_modules )
        {
            printf("Available SVEN Module definitions:\n");
        }
        else if ( validate_avail_modules )
        {
            printf("Validate Module \"reverse\" Definitions:\n");
        }

        for ( module = 0; module < SVEN_module_MAX; module++ )
        {
            const struct ModuleReverseDefs  *mrd;

            if ( NULL != (mrd = svenreverse_GetModuleTables(module)) )
            {
                if ( NULL != mrd->mrd_name )
                {
                    if ( print_avail_modules )
                    {
                        printf( "Module %2d: %-12s - \"%s\"\n",
                            mrd->mrd_module, mrd->mrd_name,
                            (NULL == mrd->mrd_comment) ? "(no comment)" : mrd->mrd_comment );
                    }

                    if ( validate_avail_modules )
                    {
                        const char      *unit_prefix;

                        unit_prefix = skip_platform_prefix( mrd->mrd_name );

                        printf( "Module %2d: %-12s - \"%s\" ",
                            mrd->mrd_module, mrd->mrd_name,
                            (NULL == mrd->mrd_comment) ? "(no comment)" : mrd->mrd_comment );

                        if ( sanity_check_csr_regs( stdout, mrd->mrd_regdefs, unit_prefix ) ||
                             sanity_check_csr_event_specific( stdout, mrd->mrd_event_specific, unit_prefix  ) ||
                             sanity_check_csr_duplicated_names( stdout, mrd->mrd_regdefs, unit_prefix ) )
                        {
                            err = 1;
                        }
                        else printf( "OK\n" );
                    }
                }
            }
        }
	}

	return(err);
}


