/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdarg.h>

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

void
PushPopPrint(FILE *fp, int Flag, char *Name, char *Attribute)
{
	static int SP = 0;
	static char SName[256][64];

	switch (Flag) {
	case 0: // pop
		SP--;
		fprintf(fp, "%*s</%s>\n", SP*3, "", SName[SP]);
		break;
	case 1: // PUSH
		fprintf(fp, "%*s<%s%s%s>\n", SP*3, "", Name, Attribute == NULL ? "" : " ", Attribute ? Attribute : "");
		strcpy(SName[SP++], Name);
		break;
	case 2:
		fprintf(fp, "%*s", SP*3, "");
		while (*Name) {
			if (*Name >= ' ' && *Name < 127 &&
				*Name != '\'' && *Name != '`') {
				putc(*Name, fp);
			}
			Name++;
		}
		putc('\n', fp);
		break;
	}
}

void
PushXML(FILE *fp, char *Name, char *Attribute)
{
	PushPopPrint(fp, 1, Name, Attribute);	
}

void
PopXML(FILE *fp)
{
	PushPopPrint(fp, 0, NULL, NULL);	
}

PrintXML(FILE *fp, const char *ptr, ...)
{
	char Buffer[32*1024];
	va_list list;

	va_start(list, ptr);
	vsnprintf(Buffer, sizeof(Buffer), ptr, list);
	va_end(list);

	PushPopPrint(fp, 2, Buffer, NULL);
}

void
DumpRegisterBits(
	FILE *fp,
	const struct EAS_RegBits *Reg
	)
{
	int tab[64];
	int cnt = 0;
	int idx = 0;

	// sort the bitfield table by min bit offset first
	while (Reg[cnt].regbits_name != NULL) {
		if (cnt == 0) {
			tab[0] = 0;
		} else {
			idx = cnt;
			while (idx > 0 && Reg[cnt].regbits_lsb_pos < Reg[tab[idx-1]].regbits_lsb_pos) {
				tab[idx] = tab[idx-1];
				idx--;
			}
			tab[idx] = cnt;
		}
		cnt++;
	}

	idx = 0;
	while (idx < cnt) {
		unsigned char *Help;
		PushXML(fp, "bit", NULL);

		PushXML(fp, "def", "arch=\"1.0\"");
		PrintXML(fp, "<ip owner=\"1.0\" level=\"1.0\" team=\"1\"/>");

		PrintXML(fp, "<name>%s</name>", Reg[tab[idx]].regbits_name);
		
		Help = (unsigned char *) ((Reg[tab[idx]].regbits_comment == NULL ||
			    Reg[tab[idx]].regbits_comment[0] == 0) ? "%s" : Reg[tab[idx]].regbits_comment);

#define NUM_START 0x91
#define NUM_END 0x92
#define NUM_SEPERATOR 0x96

//		PrintXML(fp, "<desc>%s</desc>", ((Help[0] == (unsigned char)NUM_START) ? "%s" : Help) );
        if ( NUM_START == Help[0] )
    		PrintXML(fp, "<desc>%s</desc>", "%s" );
        else
    		PrintXML(fp, "<desc>%s</desc>", Help );
		
		PopXML(fp);

		PrintXML(fp, "<begin>%d</begin>", Reg[tab[idx]].regbits_lsb_pos);
		PrintXML(fp, "<end>%d</end>", Reg[tab[idx]].regbits_lsb_pos + Reg[tab[idx]].regbits_width - 1);

		if (Help[0] == NUM_START) {
			// create the fixes value list
			unsigned char Buffer[4096];

			strcpy(Buffer, Help);
			Help = Buffer;
			PrintXML(fp, "<type>fixed</type>");
			while (*Help && *Help == NUM_START) {
				char *Next;
				char *Number = Help + 1;
				Help = strchr(Help, NUM_END);
				if (Help == NULL ||
					Help[1] != ' ' ||
					(Help[2] != '-' && Help[2] != NUM_SEPERATOR) ||
					Help[3] != ' ') {
					printf("error\n");
					exit(-1);
				}
				*Help = 0;
				Help += 4;

				Next = strchr(Help, ';');
				if (Next == NULL) {
					Next = Help + strlen(Help); // we are now on the NULL byte
				} else {
					*Next = 0;
					Next += 2;
				}

				PrintXML(fp, "<fixed value=\"%s\" help=\"%s = %s\"/>", Number, Number, Help);
				Help = Next;
			}
		} else {
			switch (Reg[tab[idx]].regbits_width) {
			case 1:
				PrintXML(fp, "<type>fixed</type>");
				PrintXML(fp, "<fixed value=\"0\" help=\"0 = false\"/>");
				PrintXML(fp, "<fixed value=\"1\" help=\"1 = TRUE\"/>");
				break;
			case 2:
				PrintXML(fp, "<type>fixed</type>");
				PrintXML(fp, "<fixed value=\"0\" help=\"0 = ZERO\"/>");
				PrintXML(fp, "<fixed value=\"1\" help=\"1 = ONE\"/>");
				PrintXML(fp, "<fixed value=\"2\" help=\"2 = TWO\"/>");
				PrintXML(fp, "<fixed value=\"3\" help=\"3 = THREE\"/>");
				break;
			case 3:
				PrintXML(fp, "<type>fixed</type>");
				PrintXML(fp, "<fixed value=\"0\" help=\"0 = \"/>");
				PrintXML(fp, "<fixed value=\"1\" help=\"1 = \"/>");
				PrintXML(fp, "<fixed value=\"2\" help=\"2 = \"/>");
				PrintXML(fp, "<fixed value=\"3\" help=\"3 = \"/>");
				PrintXML(fp, "<fixed value=\"4\" help=\"4 = \"/>");
				PrintXML(fp, "<fixed value=\"5\" help=\"5 = \"/>");
				PrintXML(fp, "<fixed value=\"6\" help=\"6 = \"/>");
				PrintXML(fp, "<fixed value=\"7\" help=\"7 = \"/>");
				break;
			default:
				PrintXML(fp, "<type>any</type>");
			}
		}
		PopXML(fp);

		idx++;
	}
}

void
DumpHelp(FILE *fp, const char *name, const char *descr)
{
	static int HelpMax;
	static int HelpCnt;
	static char **Text;

	if (HelpMax == HelpCnt) {
		HelpMax += 256;
		Text = (char **) realloc(Text, sizeof (Text[0]) * HelpMax * 2);
	}

	if (fp == NULL) {
		Text[2*HelpCnt+0] = (char *) name;
		Text[2*HelpCnt+1] = (char *) descr;
		HelpCnt++;
	} else {
		while (HelpCnt-- > 0) {
			char buf[1024];
			snprintf(buf, sizeof(buf), "name=\"ORA_%s_HLP\" references=\"1\"", Text[2*HelpCnt]);
			PushXML(fp, "rhp", buf);
			PrintXML(fp, "<![CDATA[%s]]>", Text[2*HelpCnt+1]);

			PopXML(fp);
		}
	}
}

const struct EAS_Register *
DumpRegisters(
	FILE *fp,
	unsigned long base, 
	long OffsetEndRange, 
	const struct EAS_Register *Reg)
{
	while (Reg->reg_name != NULL) {
		const char *help;

		PushXML(fp, "reg", NULL);
		// dump register description
		PushXML(fp, "def", "arch=\"1.0\"");
		PrintXML(fp, "<ip owner=\"1.0\" level=\"1.0\" team=\"1\"/>");
		PrintXML(fp, "<name>ORA_%s</name>", Reg->reg_name);
		help = (Reg->reg_comment == NULL ||  Reg->reg_comment[0] == 0)? "Missing Register description" : Reg->reg_comment;

	    PrintXML(fp, "<desc>%s</desc>", help);
		PrintXML(fp, "<access>TYPE(MMR);ACCESS(0x%08lx)</access>", base + Reg->reg_offset);
		PrintXML(fp, "<xdb type=\"2\" xtype=\"0\" bitmask=\"ffffffff\" isrhpbit=\"true\">SYSREG_32BIT</xdb>");
		PrintXML(fp, "<rhp name=\"ORA_%s_HLP\"/>", Reg->reg_name);

		DumpHelp(NULL, Reg->reg_name, help);

		PopXML(fp);

		// dump bitfield
		if (Reg->reg_bits) {
			DumpRegisterBits(fp, Reg->reg_bits);
		} else {
			// create an artificial bifield section
				
			PushXML(fp, "bit", NULL);

			PushXML(fp, "def", "arch=\"1.0\"");
			PrintXML(fp, "<ip owner=\"1.0\" level=\"1.0\" team=\"1\"/>");

			PrintXML(fp, "<name>ORA_%s_%s</name>", Reg->reg_name, Reg->reg_name);
			
			PrintXML(fp, "<desc>%s</desc>", help);
			PopXML(fp);

			PrintXML(fp, "<begin>%d</begin>", 0);
			PrintXML(fp, "<end>%d</end>", 31);
			PrintXML(fp, "<type>any</type>");
			PopXML(fp);
		}

		PopXML(fp);
		Reg++;
		if (Reg->reg_offset > OffsetEndRange) return Reg;
	}

	return NULL;
}

// main XML dump function
void DumpXML_ModuleReverse(
	FILE                            *fp,
	const struct ModuleReverseDefs	*mrd )
{
	int                          Count = 0;
    const struct EAS_Register   *reg;
	int                          FileCount = 1;

    reg = mrd->mrd_regdefs;

	do {
		char Buffer[256];

		if (reg->reg_offset >= Count * 0x1000 && 
			reg->reg_offset < Count * 0x1000 + 0x1000) {
			
			fprintf(fp, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				"<!-- this file is an automated generated XML file-->\n");
			PushXML(fp, "subsystem", NULL);
			PushXML(fp, "def", "cpu=\"11.1;14.0\"");
			PrintXML(fp, "<ip owner=\"1.0\" level=\"1.0\" team=\"1\"/>");

			PrintXML(fp, "<name>%s_%d</name>", mrd->mrd_name, FileCount );
			PopXML(fp);

			// now dump all registers
			reg = DumpRegisters(fp, 0x8000,(Count+1)*0x1000 - 1, reg);

			PushXML(fp, "rhps", NULL);
			DumpHelp(fp, NULL, NULL);
			PopXML(fp);
			PopXML(fp);
		}
		Count++;
	} while (reg != NULL);
}

#if 0
void
DumpXML()
{
	const struct EAS_Register *List = g_gen2_AUDIO_sven_module.mrd_regdefs;
	int Count = 0;
	int FileCount = 1;
    FILE *fp;

	do {
		char Buffer[256];

		if (List->reg_offset >= Count * 0x1000 && 
			List->reg_offset < Count * 0x1000 + 0x1000) {
			sprintf(Buffer, "p:/or/or_audio%d.xml", FileCount);
			fp = fopen(Buffer, "w");
			
			fprintf(fp, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
				"<!-- this file is an automated generated XML file-->\n");
			PushXML(fp, "subsystem", NULL);
			PushXML(fp, "def", "cpu=\"11.1;14.0\"");
			PrintXML(fp, "<ip owner=\"1.0\" level=\"1.0\" team=\"1\"/>");

			PrintXML(fp, "<name>%s_%d</name>", g_gen2_AUDIO_sven_module.mrd_name, FileCount);
			PopXML(fp);

			// now dump all registers
			List = DumpRegisters(fp, 0x8000,(Count+1)*0x1000 - 1, List);

			PushXML(fp, "rhps", NULL);
			DumpHelp(fp, NULL, NULL);
			PopXML(fp);
			PopXML(fp);
			fclose(fp);
			FileCount++;
		}
		Count++;
	} while (List != NULL);
}

#endif
