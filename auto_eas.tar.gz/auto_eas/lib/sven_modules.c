/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
    Intel Corporation
    2200 Mission College Blvd.
    Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifndef _CSR_DEFS_H
#include "csr_defs.h"
#endif

#include "vr/csr_vr_audio.c"
#include "gen2/csr_gen2_mpg2e.c"
#include "gen2/csr_gen2_audio.c"
#include "vr/csr_vr_chap.c"
#include "vr/csr_vr_dpe.c"
#include "vr/csr_vr_expbus.c"
#include "vr/csr_vr_gpu.c"
#include "vr/csr_vr_gpio.c"
#include "vr/csr_vr_hdmi.c"
#include "vr/csr_vr_i2c0.c"
#include "vr/csr_vr_i2c1.c"
#include "vr/csr_vr_i2c2.c"
#include "vr/csr_vr_mch.c"
#include "vr/csr_vr_mpg2vd.c"
#include "vr/csr_vr_tsd.c"
#include "vr/csr_vr_tsp.c"
#include "vr/csr_vr_uee.c"
#include "vr/csr_vr_vcap.c"
#include "vr/csr_vr_vdc.c"
#include "gen2/csr_gen2_tsp.c"
#include "gen2/csr_gen2_pmu.c"
#include "gen2/csr_gen2_vcap.c"
#include "csr_tbe_avi.c"
#include "csr_tbe_avo.c"
#include "vr/csr_vr_spi.c"
#include "gen2/csr_gen2_h264vd.c"
#include "gen2/csr_gen2_omar.c"
#include "gen2/csr_gen2_adi.c"
#include "gen2/csr_gen2_tsd.c"
#include "gen2/csr_gen2_vdc.c"
#include "gen2/csr_gen2_mpg2vd.c"
#include "gen2/csr_gen2_expbus.c"
#include "gen2/csr_gen2_uee.c"
#include "gen2/csr_gen2_i2c.c"
#include "gen2/csr_gen2_uart.c"
#include "gen2/csr_gen2_gfx.c"
#include "csr_vidrend.c"
#include "csr_bufmon.c"
#include "csr_remux.c"
#include "csr_mux.c"
#include "csr_encoder.c"
#include "gen2/csr_gen2_mcu.c"
#include "gen2/csr_gen2_xab.c"
#include "csr_smd_core.c"
#include "ce31xx/csr_ce31xx_aud_dsp0.c"
#include "ce31xx/csr_ce31xx_aud_dsp1.c"
#include "ce31xx/csr_ce31xx_aud_io.c"
#include "ce31xx/csr_ce31xx_gfx.c"
#include "ce31xx/csr_ce31xx_dfx.c"
#include "ce31xx/csr_ce31xx_cru.c"
#include "ce31xx/csr_ce31xx_gpio.c"
#include "ce31xx/csr_ce31xx_dpe.c"
#include "ce31xx/csr_ce31xx_hdmi_tx.c"
#include "ce31xx/csr_ce31xx_sec.c"
#include "ce31xx/csr_ce31xx_tve.c"
#include "ce31xx/csr_ce31xx_tsout.c"
#include "ce31xx/csr_ce31xx_vdc.c"
#include "ce31xx/csr_ce31xx_mfd.c"
//#include "ce31xx/csr_ce31xx_prefilt.c"
#include "ce31xx/csr_ce31xx_tsi.c"
#include "ce31xx/csr_ce31xx_mspod.c"
#include "ce31xx/csr_ce31xx_demux.c"
#include "csr_ipclib.c"
#include "ce42xx/csr_gen4_mfd.c"
//#include "ce42xx/csr_gen4_mfd_sv.c"
#include "ce42xx/csr_gen4_gv.c"
#include "ce42xx/csr_gen4_meu.c"
#include "ce42xx/csr_gen4_hdvcap.c"
#include "ce42xx/csr_gen4_aud_io.c"
#include "ce42xx/csr_gen4_dpe.c"
#include "ce42xx/csr_gen41_cru.c"
#include "ce42xx/csr_gen42_cru.c"
#include "csr_app_events.c"
#include "gen5/csr_gen5_tsi.c"
#include "gen5/csr_gen5_dpe.c"
#include "gen5/csr_gen5_cru.c"
#include "csr_vidsink.c"
#include "csr_ces.c"
#include "csr_hdmi_rx_ext.c"

/* WARNING:  Array Positions MUST EXACTLY MATCH enum SVEN Module */

/** Global table of Reverse defs */
static const struct ModuleReverseDefs   *g_mrds[SVEN_module_MAX] = {
    NULL,                               //  SVEN_module_invalid,
    NULL,                               //  SVEN_module_CPU,
    &g_MCH_sven_module,                 //  SVEN_module_GEN2_MCH,
    &g_GPU_sven_module,                 //  SVEN_module_GEN2_GPU,
    &g_GEN2_MPG2VD_sven_module,         //  SVEN_module_GEN2_MPG2VD,
    &g_TSP_sven_module,                 //  SVEN_module_GEN2_PREFILT,
    &g_TSD_sven_module,                 //  SVEN_module_GEN2_TSDEMUX,
    &g_vcap_sven_module,                //  SVEN_module_GEN2_VCAP,
    &g_hdmi_sven_module,                //  SVEN_module_GEN2_HDMI,
    &g_AUDIO_sven_module,               //  SVEN_module_GEN2_AUDIO,
    &g_CHAP_sven_module,                //  SVEN_module_GEN2_CHAP,
    &g_VDC_sven_module,                 //  SVEN_module_GEN2_VDC,
    &g_GEN2_DPE_sven_module,            //  SVEN_module_GEN2_DPE,
    &g_UEE_sven_module,                 //  SVEN_module_GEN2_UEE,
    &g_EXPBUS_sven_module,              //  SVEN_module_GEN2_EXBUS,
    NULL,                               //  SVEN_module_GEN2_UART0,
    NULL,                               //  SVEN_module_GEN2_UART1,
    &g_GPIO_sven_module,                //  SVEN_module_GEN2_GPIO,
    &g_I2C0_sven_module,                //  SVEN_module_GEN2_I2C0,
    &g_I2C1_sven_module,                //  SVEN_module_GEN2_I2C1,
    &g_I2C2_sven_module,                //  SVEN_module_GEN2_I2C2,
    NULL,                               //  SVEN_module_GEN2_SC0,
    NULL,                               //  SVEN_module_GEN2_SC1,
    &g_vr_SPI_sven_module,              //  SVEN_module_GEN2_SPI,
    NULL,                               //  SVEN_module_GEN2_MSPOD,
    NULL,                               //  SVEN_module_GEN2_FW_TSDEMUX,
    &g_gen1_AUDIO_sven_module,          //  SVEN_module_GEN1_AUDIO,
    &g_GEN1_TSP_sven_module,            //  SVEN_module_GEN1_PREFILT,
    &g_GEN1_MPEG2E_sven_module,         //  SVEN_module_GEN1_MPEG2E,
    &g_gen1_vcap_sven_module,           //  SVEN_module_GEN1_VCAP,
    &g_GEN1_PMU_sven_module,            //  SVEN_module_GEN1_PMU,
    &g_TBE_AVI_sven_module,             //  SVEN_module_TBE_AVI,
    &g_TBE_AVO_sven_module,             //  SVEN_module_TBE_AVO,
    NULL,                               //  SVEN_module_TEST_APP,
    &g_GEN1_H264VD_sven_module,         //  SVEN_module_GEN1_H264VD,
    &g_omar_sven_module,                //  SVEN_module_GEN1PLUS_OMAR,
    &g_GEN1_ADI_sven_module,            //  SVEN_module_GEN1_ADI,
    &g_GEN1_TSD_sven_module,            //  SVEN_module_GEN1_TSDEMUX,
    &g_GEN1_VDC_sven_module,            //  SVEN_module_GEN1_VDC,
    &g_GEN1_MPG2VD_sven_module,         //  SVEN_module_GEN1_MPG2VD,
    &g_GEN1_EXPBUS_sven_module,         //  SVEN_module_GEN1_EXPBUS,
    &g_GEN1_UEE_sven_module,            //  SVEN_module_GEN1_UEE,
    &g_GEN1_I2C_sven_module,            //  SVEN_module_GEN1_I2C,
    &g_GEN1_UART_sven_module,           //  SVEN_module_GEN1_UART,
    &g_GEN1_GFX_sven_module,            //  SVEN_module_GEN1_GFX,
    &g_VIDREND_sven_module,             //  SVEN_module_VIDREND,
    &g_gen1_mcu_sven_module,            //  SVEN_module_GEN1_MCU,
    &g_gen1_xab_vid_sven_module,        //  SVEN_module_GEN1_XAB_VID,
    &g_gen1_xab_aper_sven_module,       //  SVEN_module_GEN1_XAB_APER,
    &g_gen1_xab_xport_sven_module,      //  SVEN_module_GEN1_XAB_XPORT,
    NULL,                               //  SVEN_module_GEN1_VCMH,
    NULL,                               //  SVEN_module_GEN1_XAB_MEM,
    &g_omar_cw_sven_module,             //  SVEN_module_GEN1PLUS_OMAR_CW,
    &g_SMD_CORE_sven_module,            //  SVEN_module_SMD_CORE,
    &g_GST_PLUGIN_sven_module,          //  SVEN_module_GST_PLUGIN,
    &g_gen3_AUD_DSP0_sven_module,       //  SVEN_module_GEN3_AUD_DSP0,
    &g_GEN3_DPE_sven_module,            //  SVEN_module_GEN3_DPE,
    &g_GEN3_TSD_sven_module,            //  SVEN_module_GEN3_DEMUX,
    &g_gen3_HDMI_TX_sven_module,        //  SVEN_module_GEN3_HDMI_TX,
    &g_GEN3_VDC_sven_module,            //  SVEN_module_GEN3_VDC,
    &g_GEN3_GFX_sven_module,            //  SVEN_module_GEN3_GFX,
    NULL,                               //  SVEN_module_GEN3_COMPOSITOR,
    &g_GEN3_MFD_sven_module,            //  SVEN_module_GEN3_MFD,
    &g_sec_sven_module,                 //  SVEN_module_GEN3_SEC,
    NULL,                               //  SVEN_module_GEN3_OMAR,
    &g_gen3_AUD_IO_sven_module,         //  SVEN_module_GEN3_AUD_IO,
    NULL,                               //  SVEN_module_GEN3_PMU,
    &g_gen3_AUD_DSP1_sven_module,       //  SVEN_module_GEN3_AUD_DSP1,
    NULL,                               //  SVEN_module_GEN3_UART,
    &g_gen3_GPIO_sven_module,           //  SVEN_module_GEN3_GPIO,
    NULL,                               //  SVEN_module_GEN3_I2C,
    NULL,                               //  SVEN_module_GEN3_GPU_GMH,
    &g_gen3_tsi_sven_module,             //  SVEN_module_GEN3_PREFILT,
    NULL,                               //  SVEN_module_GEN3_SRAM,
    NULL,                               //  SVEN_module_GEN3_EXP,
    NULL,                               //  SVEN_module_GEN3_EXP_WIN,
    NULL,                               //  SVEN_module_GEN3_SCARD,
    NULL,                               //  SVEN_module_GEN3_SPI,
    &g_gen3_mspod_sven_module,           //  SVEN_module_GEN3_MSPOD,
    NULL,                               //  SVEN_module_GEN3_IR,
    &g_gen3_dfx_sven_module,            //  SVEN_module_GEN3_DFX,
    NULL,                               //  SVEN_module_GEN3_GBE,
    NULL,                               //  SVEN_module_GEN3_GBE_MDIO,
    &g_gen3_cru_sven_module,            //  SVEN_module_GEN3_CRU,
    NULL,                               //  SVEN_module_GEN3_USB,
    NULL,                               //  SVEN_module_GEN3_SATA,
    &g_GEN3_TVE_sven_module,            //  SVEN_module_GEN3_TVE,
    &g_IPCLIB_sven_module,              //  SVEN_module_IPCLIB,
    &g_gen3_TSOUT_sven_module,          //  SVEN_module_GEN3_TSOUT,
    &g_BUFMON_sven_module,              //  SVEN_module_BUFMON,
    &g_GEN4_MFD_sven_module,            //  SVEN_module_GEN4_MFD
    &g_GEN4_GV_sven_module,             //  SVEN_module_GEN4_GV
    NULL,                               //  SVEN_module_GEN4_NAND_DEV
    NULL,                               //  SVEN_module_GEN4_NAND_CSR
    &g_GEN4_MEU_sven_module,            //  SVEN_module_GEN4_MEU
    &g_gen4_hdvcap_sven_module,         //  SVEN_module_GEN4_HDVCAP
    &g_APP_EVENTS_sven_module,          //  SVEN_module_APP_EVENTS
    &g_gen4_AUD_IO_sven_module,         //  SVEN_module_GEN4_AUD_IO,
    &g_GEN4_DPE_sven_module,            //  SVEN_module_GEN4_DPE,
    &g_REMUX_sven_module,               //  SVEN_module_REMUX,
    &g_gen5_tsi_sven_module,            //  SVEN_module_GEN5_PREFILT,
    &g_GEN5_DPE_sven_module,            //  SVEN_module_GEN5_DPE,
    &g_VIDSINK_sven_module,             //  SVEN_module_VIDSINK,
    &g_ce4100_cru_sven_module,          //  SVEN_module_CE4100_CRU,
    &g_ce4200_cru_sven_module,          //  SVEN_module_CE4200_CRU,	
    &g_ce5xxx_cru_sven_module,          //  SVEN_module_CE5XXX_CRU,	
    &g_CES_sven_module,                 //  SVEN_module_CES
    &g_hdmi_rx_ext_sven_module,         //  SVEN_module_HDMI_RX_EXT,
    &g_MUX_sven_module,                 //  SVEN_module_MUX,
    &g_ENCODER_sven_module              //  SVEN_module_ENCODER,

};


/* -------------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------------- */
static char internal_toupper( char ch )
{
    if ( (ch >= 'a') && (ch <= 'z') )
        return( ch + ('A' - 'a') );
    return(ch);
}

static int strcasecmp( const char *stra, const char *strb )
{
    int         i;
    i = 0;

    while ( internal_toupper(stra[i]) == internal_toupper(strb[i]) )
    {
        /* End-of-string for both */
        if ( ('\0' == stra[i]) && ('\0' == strb[i]) )
        {
            return(0);
        }
        i++;
    }
    return(1);  /* FAIL */
}

////////////////////////////////////////////////////////////////////////////////
///
/// @brief      Get the latest ModuleReverseDefs for a designated module
///
/// @param   module  : one of the enum SVEN_Module values
/// @returns  struct ModuleReverseDefs * or NULL
///
////////////////////////////////////////////////////////////////////////////////
const struct ModuleReverseDefs *svenreverse_GetModuleTables(
    enum SVEN_Module            module )
{
    if ( (module > 0) && (module < SVEN_module_MAX) )
    {
        return( g_mrds[module] );
    }

    return( NULL );
}

////////////////////////////////////////////////////////////////////////////////
///
/// @brief      Get the latest ModuleReverseDefs for a designated module
///
/// @param   module_name  : The null terminated name of the module (e.g. "GEN2_HDMI")
/// @returns  struct ModuleReverseDefs * or NULL
///
////////////////////////////////////////////////////////////////////////////////
const struct ModuleReverseDefs *svenreverse_GetModuleTables_ByName(
    const char                  *module_name )
{
    int                              module;

        for ( module = 0; module < SVEN_module_MAX; module++ )
            {
            if ( g_mrds[module] && !strcasecmp( g_mrds[module]->mrd_name, module_name ) )
            {
            return( g_mrds[module] );
             }
        }

    return NULL;
}
