//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//-----------------------------------------------------------------------------

#ifndef __VBD_INT_H_
#define __VBD_INT_H_

/* This file contains data structures needed internally only, but which must
 * be shared between VBD and other software components.
 */

#include "vbd.h"

/* VBD commands */
typedef enum
{
    VBD_FLIP=1,
    VBD_CALLBACK,
    VBD_FLIP_BLACK_FRAME,
    VBD_CC_RESET,
    VBD_PLANE_RESERVE,
    VBD_PLANE_UNRESERVE,
    VBD_ADJUST_VBLANK_LINES,
    VBD_DISPLAY_CALLBACK,
    VBD_GET_PLANES_DISPLAY_ID,
    VBD_PLANE_SET_CSC_ADJUST,
    VBD_POST_BLEND_SET_CSC_ADJUST,
} vbd_command_t;


/* Argument for VBD_GET_PLANES_DISPLAY_ID */
typedef struct
{
    gdl_plane_id_t   plane_id;
    gdl_display_id_t display_id;
} vbd_get_disp_id_t;

/* Arguments for VBD_FLIP */
typedef struct
{
    gdl_plane_id_t  plane_id;
    gdl_boolean_t   disable;    // If GDL_TRUE disable plane (flip_data invalid)
    vbd_flip_data_t flip_data;
} vbd_flip_args_t;

/* Arguments for VBD_CALLBACK */
typedef struct
{
    vbd_callback_t  callback;
    void *          cookie;
} vbd_callback_args_t;


/* Arguments for VBD_DISPLAY_CALLBACK */
typedef struct
{
    gdl_display_id_t    display_id;
    vbd_disp_callback_t callback;
    void *              cookie;
} vbd_disp_callback_args_t;


/* Arguments for VBD_ADJUST_VBLANK_LINES */
typedef struct
{
    int n_lines;
} vbd_adjust_vblank_t;


/* Arguments for VBD_PLANE_SET_CSC_ADJUST */
typedef struct
{
   gdl_csc_t csc_adjustment;
} vbd_plane_set_csc_adjust_t;


/* Arguments for VBD_POST_BLEND_SET_CSC_ADJUST */
typedef struct
{
    gdl_display_id_t display_id;
    gdl_csc_t        csc_adjustment;
} vbd_post_blend_set_csc_adjust_t;

/* Structure to marshal command data */
typedef struct
{
    unsigned int   command;
    gdl_plane_id_t plane_id;
    union
    {
        vbd_flip_args_t                 flip_args;
        vbd_callback_args_t             callback_args;
        vbd_disp_callback_args_t        disp_callback_args;
        vbd_adjust_vblank_t             adjust_vblank_args;
        vbd_get_disp_id_t               get_display_id_args;
        vbd_plane_set_csc_adjust_t      plane_csc_args;
        vbd_post_blend_set_csc_adjust_t post_blend_csc_args;
    } args;
} vbd_data_t;

/* ROLL THE VERSION NUMBER EVERY TIME THE INTERFACE CHANGES SO THAT COMPONENTS
 * BUILT AGAINST OLDER VERSIONS WILL NOT LOAD SUCCESSFULLY.
 */
#define VBD_HANDLER vbd_handler_v14
extern gdl_ret_t VBD_HANDLER(vbd_data_t * vbd_data);

/* Server function that processes VBD commands. */
gdl_ret_t VBD_Entry(vbd_data_t* cmd);

#endif /* __VBD_INT_H_ */
