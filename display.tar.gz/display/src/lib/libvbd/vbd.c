//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2005-2011  Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2005-2011  Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

#include "vbd.h"
#include "vbd_int.h"

typedef void* LPVOID;
#define call_driver(data) VBD_HANDLER(data)


gdl_ret_t vbd_flip( gdl_plane_id_t plane_id, vbd_flip_data_t *data )
{
    vbd_data_t vbd_data;

    vbd_data.command    = VBD_FLIP;
    vbd_data.plane_id   = plane_id;
    if (data)
    {
        vbd_data.args.flip_args.disable     = GDL_FALSE;
        vbd_data.args.flip_args.flip_data   = *data;
    }
    else
    {
        vbd_data.args.flip_args.disable     = GDL_TRUE;
    }
    
    return call_driver(&vbd_data);
}


gdl_ret_t vbd_set_disp_callback(gdl_display_id_t    display_id,
                                vbd_disp_callback_t callback,
                                void *              cookie)
{
    vbd_data_t vbd_data;
    
    vbd_data.command                            = VBD_DISPLAY_CALLBACK;
    vbd_data.args.disp_callback_args.display_id = display_id;
    vbd_data.args.disp_callback_args.callback   = callback;
    vbd_data.args.disp_callback_args.cookie     = cookie;

    return call_driver(&vbd_data);
}

gdl_ret_t vbd_set_callback(vbd_callback_t callback, void *cookie)
{
    vbd_data_t vbd_data;

    vbd_data.command                        = VBD_CALLBACK;
    vbd_data.args.callback_args.callback    = callback;
    vbd_data.args.callback_args.cookie      = cookie;
    
    return call_driver(&vbd_data);
}


gdl_ret_t vbd_flip_black_frame(gdl_plane_id_t plane_id)
{
    vbd_data_t vbd_data;

    vbd_data.command    = VBD_FLIP_BLACK_FRAME;
    vbd_data.plane_id   = plane_id;

    return call_driver(&vbd_data);
}


gdl_ret_t vbd_closed_caption_reset( gdl_plane_id_t plane_id )
{
    vbd_data_t vbd_data;

    vbd_data.command    = VBD_CC_RESET;
    vbd_data.plane_id   = plane_id;
    return call_driver(&vbd_data);
}

gdl_ret_t vbd_plane_reserve (gdl_plane_id_t plane_id)
{
    vbd_data_t vbd_data;

    vbd_data.command    = VBD_PLANE_RESERVE;
    vbd_data.plane_id   = plane_id;

    return call_driver(&vbd_data);
}

gdl_ret_t vbd_plane_unreserve (gdl_plane_id_t plane_id)
{
    vbd_data_t vbd_data;

    vbd_data.command    = VBD_PLANE_UNRESERVE;
    vbd_data.plane_id   = plane_id;

    return call_driver(&vbd_data);
}

gdl_ret_t vbd_adjust_vblank_lines( int n_lines )
{
    vbd_data_t vbd_data;

    vbd_data.command                         = VBD_ADJUST_VBLANK_LINES;
    vbd_data.args.adjust_vblank_args.n_lines = n_lines;

    return call_driver(&vbd_data);
}

gdl_ret_t vbd_get_planes_display_id(gdl_plane_id_t     plane_id, 
                                    gdl_display_id_t * display_id)
{
    vbd_data_t vbd_data;
    gdl_ret_t  rc;

    if (display_id == 0)
    {
        rc = GDL_ERR_NULL_ARG;
        goto exit;
    }

    vbd_data.command = VBD_GET_PLANES_DISPLAY_ID;
    vbd_data.args.get_display_id_args.plane_id = plane_id;
    
    rc = call_driver(&vbd_data);
    if (rc != GDL_SUCCESS)
    {
        goto exit;
    }

    *display_id = vbd_data.args.get_display_id_args.display_id;
    
exit:
    return rc;
}

gdl_ret_t vbd_plane_set_csc_adjust(gdl_plane_id_t plane_id,
                                   gdl_csc_t *    csc_adjustment)
{
    vbd_data_t vbd_data;

    vbd_data.command  = VBD_PLANE_SET_CSC_ADJUST;
    vbd_data.plane_id = plane_id;
    vbd_data.args.plane_csc_args.csc_adjustment = *csc_adjustment;
    
    return call_driver(&vbd_data);   
}


gdl_ret_t vbd_post_blend_set_csc_adjust(gdl_display_id_t display_id,
                                        gdl_csc_t *      csc_adjustment)
{
    vbd_data_t vbd_data;

    vbd_data.command = VBD_POST_BLEND_SET_CSC_ADJUST;
    vbd_data.args.post_blend_csc_args.display_id     = display_id;
    vbd_data.args.post_blend_csc_args.csc_adjustment = *csc_adjustment;

    return call_driver(&vbd_data);
}




