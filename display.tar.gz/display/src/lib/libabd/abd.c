//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2007-2011  Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2007-2011  Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

#include "abd_int.h"

//------------------------------------------------------------------------------
// abd_open()
//------------------------------------------------------------------------------
gdl_ret_t abd_open(gdl_hdmi_audio_device_id_t id, void ** handle)
{
    abd_command_t cmd;
    
    // Prepare and submit command
    cmd.id = ABD_OPEN;
    cmd.data._open.h  = handle;
    cmd.data._open.id = id;
    return ABD_HANDLER(&cmd);
}

//------------------------------------------------------------------------------
// abd_close()
//------------------------------------------------------------------------------
gdl_ret_t abd_close(void * handle)
{
    abd_command_t cmd;
    
    // Prepare and submit command
    cmd.id = ABD_CLOSE;
    cmd.h  = handle;
    return ABD_HANDLER(&cmd);
}

//------------------------------------------------------------------------------
// abd_set_event_callback()
//------------------------------------------------------------------------------
gdl_ret_t abd_set_event_callback(void               * handle,
                                 gdl_hdmi_event_cb_t  event_callback,
                                 void               * user_data)
{
    abd_command_t cmd;
    
    // Prepare and submit command
    cmd.id = ABD_SET_EVENT_CB;
    cmd.h  = handle;
    cmd.data._set_event_cb.user_data      = user_data;
    cmd.data._set_event_cb.event_callback = event_callback;
    return ABD_HANDLER(&cmd);
}

//------------------------------------------------------------------------------
// abd_set_format()
//------------------------------------------------------------------------------
gdl_ret_t abd_set_format(void                       * handle,
                         gdl_hdmi_audio_fmt_t         format,
                         unsigned int                 num_channels,
                         gdl_hdmi_audio_fs_t          sample_rate,
                         gdl_hdmi_audio_ss_t          sample_size,
                         gdl_hdmi_audio_speaker_map_t speaker_map)
{
    abd_command_t cmd;
    
    // Prepare and submit command
    cmd.id = ABD_SET_FORMAT;
    cmd.h  = handle;
    cmd.data._set_format.format       = format;
    cmd.data._set_format.num_channels = num_channels;
    cmd.data._set_format.sample_rate  = sample_rate;
    cmd.data._set_format.sample_size  = sample_size;
    cmd.data._set_format.speaker_map  = speaker_map;
    return ABD_HANDLER(&cmd);
}

//------------------------------------------------------------------------------
// abd_start()
//------------------------------------------------------------------------------
gdl_ret_t abd_start(void * handle)
{
    abd_command_t cmd;
    
    // Prepare and submit command
    cmd.id = ABD_START;
    cmd.h  = handle;
    return ABD_HANDLER(&cmd);
}

//------------------------------------------------------------------------------
// abd_stop()
//------------------------------------------------------------------------------
gdl_ret_t abd_stop(void * handle, gdl_boolean_t sync)
{
    abd_command_t cmd;
    
    // Prepare and submit command
    cmd.id = ABD_STOP;
    cmd.h  = handle;
    cmd.data._stop.sync = sync;
    return ABD_HANDLER(&cmd);
}

//------------------------------------------------------------------------------
// abd_reset()
//------------------------------------------------------------------------------
gdl_ret_t abd_reset(void * handle)
{
    abd_command_t cmd;
    
    // Prepare and submit command
    cmd.id = ABD_RESET;
    cmd.h  = handle;
    return ABD_HANDLER(&cmd);
}

//------------------------------------------------------------------------------
// abd_write()
//------------------------------------------------------------------------------
gdl_ret_t abd_write(void         * handle,
                    unsigned int   samples,
                    unsigned int   silence,
                    unsigned int   size,
                    unsigned int   id)
{
    abd_command_t cmd;
    
    // Prepare and submit command
    cmd.id = ABD_WRITE;
    cmd.h  = handle;
    cmd.data._write.samples = samples;
    cmd.data._write.silence = silence;
    cmd.data._write.size    = size;
    cmd.data._write.id      = id;
    return ABD_HANDLER(&cmd);
}

//------------------------------------------------------------------------------
// abd_set_channel_status()
//------------------------------------------------------------------------------
gdl_ret_t abd_set_channel_status(void * handle, unsigned int lsw, unsigned int msw)
{
    abd_command_t cmd;
    
    // Prepare and submit command
    cmd.id = ABD_SET_CHANNEL_STATUS;
    cmd.h  = handle;
    cmd.data._channel_status.lsw = &lsw;
    cmd.data._channel_status.msw = &msw;
    return ABD_HANDLER(&cmd);
}

//------------------------------------------------------------------------------
// abd_get_channel_status()
//------------------------------------------------------------------------------
gdl_ret_t abd_get_channel_status(void * handle, unsigned int * lsw, unsigned int * msw)
{
    abd_command_t cmd;
    
    // Prepare and submit command
    cmd.id = ABD_GET_CHANNEL_STATUS;
    cmd.h  = handle;
    cmd.data._channel_status.lsw = lsw;
    cmd.data._channel_status.msw = msw;    
    return ABD_HANDLER(&cmd);
}
