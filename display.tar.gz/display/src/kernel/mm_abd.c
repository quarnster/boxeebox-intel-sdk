/*-----------------------------------------------------------------------------
 * This file is provided under a dual BSD/GPLv2 license.  When using or 
 * redistributing this file, you may do so under either license.
 *
 * GPL LICENSE SUMMARY
 *
 * Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify 
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but 
 * WITHOUT ANY WARRANTY; without even the implied warranty of 
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License 
 * along with this program; if not, write to the Free Software 
 * Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 * The full GNU General Public License is included in this distribution 
 * in the file called LICENSE.GPL.
 *
 * Contact Information:
 *      Intel Corporation
 *      2200 Mission College Blvd.
 *      Santa Clara, CA  97052
 *
 * BSD LICENSE 
 *
 * Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without 
 * modification, are permitted provided that the following conditions 
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright 
 *     notice, this list of conditions and the following disclaimer.
 *   - Redistributions in binary form must reproduce the above copyright 
 *     notice, this list of conditions and the following disclaimer in 
 *     the documentation and/or other materials provided with the 
 *     distribution.
 *   - Neither the name of Intel Corporation nor the names of its 
 *     contributors may be used to endorse or promote products derived 
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *---------------------------------------------------------------------------*/

#include "osal.h"

#include "common.h"
#include "mm_common.h"
#include "abd_int.h"

//------------------------------------------------------------------------------
// File Description: Kernel-side audio backdoor layer
//------------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Helper macros and shortcuts
//------------------------------------------------------------------------------
typedef gdl_hdmi_event_cb_t abd_cb_t;

//------------------------------------------------------------------------------
// Different ABD configuration stages and related macros
//------------------------------------------------------------------------------
typedef enum
{
    ABD_USE_STAGE_CLOSED = 0,
    ABD_USE_STAGE_OPENED,
    ABD_USE_STAGE_CB,
    ABD_USE_STAGE_FORMAT,
    ABD_USE_STAGE_PLAYBACK,
    ABD_USE_STAGE_STOP_NEEDED,
    ABD_USE_STAGE_STOP_IN_PROGRESS,
} abd_use_stage_t;

#define STAGE_EQUAL(bi, s, rc, error, label) \
    VERIFY(bi->use_stage == s, rc, error, label)

#define STAGE_GE(bi, s, rc, error, label) \
    VERIFY(bi->use_stage >= s, rc, error, label)

#define STAGE_IN(bi, s1, s2, rc, error, label) \
    VERIFY((bi->use_stage >= s1) && (bi->use_stage <= s2), rc, error, label)

#define STAGE_UPDATE(bi, s) \
    bi->use_stage = s

//------------------------------------------------------------------------------
// This structure describes circular buffer details
//------------------------------------------------------------------------------
typedef struct
{
    abd_cb_t            cb;        // Pointer to callback routine
    void *              cb_args;   // Pointer to callback routine arguments
    abd_use_stage_t     use_stage; // ABD use stage
    struct semaphore    protect;   // ABD thread safety primitive
} buffer_info_t;

//------------------------------------------------------------------------------
// This global holds buffer information
//------------------------------------------------------------------------------
buffer_info_t g_buffer = { 0, 0, 0, };

//------------------------------------------------------------------------------
// __id_to_buffer()
//------------------------------------------------------------------------------
static buffer_info_t * __id_to_buffer(gdl_hdmi_audio_device_id_t id)
{
    return (id == GDL_HDMI_AUDIO_ID_0) ? &g_buffer : NULL;
}

//------------------------------------------------------------------------------
// This routine submits audio requests into the request queue
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_queue(gdl_hdmi_audio_ctrl_t * ctrl, gdl_boolean_t sync)
{
    return mm_queue_backdoor_job( BACKDOOR_Q_VBD, ctrl, JOB_TYPE_ABD, sync);
}

//------------------------------------------------------------------------------
// mm_abd_start()
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_start(buffer_info_t * bi)
{
    gdl_ret_t             rc   = GDL_SUCCESS;
    gdl_hdmi_audio_ctrl_t ctrl = { .cmd_id = GDL_HDMI_AUDIO_START };
    
    // Make sure things are right
    VERIFY(bi != NULL, rc, GDL_ERR_INTERNAL, exit);
    STAGE_EQUAL(bi, ABD_USE_STAGE_FORMAT, rc, GDL_ERR_FAILED, exit);
    
    // Prepare and submit request
    rc = mm_abd_queue(&ctrl, GDL_TRUE);
    VERIFY_QUICK(rc == GDL_SUCCESS, exit);
    
    // Update ABD use stage
    STAGE_UPDATE(bi, ABD_USE_STAGE_PLAYBACK);
    
exit:
    return rc;
}

//------------------------------------------------------------------------------
// mm_abd_stop()
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_stop(buffer_info_t * bi, gdl_boolean_t sync)
{
    gdl_ret_t             rc   = GDL_SUCCESS;
    gdl_hdmi_audio_ctrl_t ctrl = { .cmd_id = GDL_HDMI_AUDIO_STOP,  };
    
    // Make sure things are right
    VERIFY(bi != NULL, rc, GDL_ERR_INTERNAL, exit);

    // If an async stop is requested while playback is not ongoing, be sure to call stop_done callback in case audio is waiting
    if (!sync && (bi->use_stage == ABD_USE_STAGE_CB || bi->use_stage == ABD_USE_STAGE_FORMAT))
    {
        bi->cb(bi->cb_args, GDL_HDMI_AUDIO_EVENT_STOP_DONE, 0);    
        goto exit;
    }

    STAGE_IN(bi, ABD_USE_STAGE_CB, ABD_USE_STAGE_STOP_NEEDED, rc, GDL_ERR_FAILED, exit);
    
    // Update ABD use stage
    STAGE_UPDATE(bi, ABD_USE_STAGE_STOP_IN_PROGRESS);
    
    // Submit request [save return code, but proceed even if stop failed]
    ctrl.data._stop.sync = sync;
    rc = mm_abd_queue(&ctrl, sync);
    
    // Indicate stop completion if appropriate
    if (sync)
    {
        STAGE_UPDATE(bi, ABD_USE_STAGE_FORMAT);
    }
    
exit:
    return rc;
}

//------------------------------------------------------------------------------
// mm_abd_reset() 
// Performs a synchronous stop but doesn't have as many state restrictions.
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_reset(buffer_info_t * bi)
{
    gdl_ret_t             rc   = GDL_SUCCESS;
    gdl_hdmi_audio_ctrl_t ctrl = { .cmd_id = GDL_HDMI_AUDIO_STOP,  };
    
    // Make sure things are right
    VERIFY(bi != NULL, rc, GDL_ERR_INTERNAL, exit);
    // Need to be at least open to call this reset
    STAGE_GE(bi, ABD_USE_STAGE_OPENED, rc, GDL_ERR_FAILED, exit);

    // If in the middle of playback, call a synchronous stop
    if(bi->use_stage >= ABD_USE_STAGE_PLAYBACK)
    {
        // Submit a synchronous stop request 
        ctrl.data._stop.sync = GDL_TRUE;
        rc = mm_abd_queue(&ctrl, GDL_TRUE);
    }
    
    // If the stop was successful or no stop was needed
    if(rc == GDL_SUCCESS)
    {
        STAGE_UPDATE(bi, ABD_USE_STAGE_OPENED);
    }
    
exit:
    return rc;
}

//------------------------------------------------------------------------------
// This routine is called by main driver on every event
//------------------------------------------------------------------------------
gdl_ret_t mm_abd_event(unsigned int data, unsigned int event)
{
    buffer_info_t * bi = __id_to_buffer(GDL_HDMI_AUDIO_ID_0);
    gdl_ret_t       rc = GDL_SUCCESS;
    
    // Make sure things are right
    VERIFY(bi && bi->cb, rc, GDL_ERR_INTERNAL, exit);
    
    switch (event)
    {
    
    // DMA ran out of sample and stopped
    case KERN_HDMI_DMA_UNDERRUN:
        STAGE_EQUAL(bi, ABD_USE_STAGE_PLAYBACK, rc, GDL_ERR_FAILED, exit);
        STAGE_UPDATE(bi, ABD_USE_STAGE_STOP_NEEDED);
        GDL_PRINT("HDMI audio under-run\n");
        bi->cb(bi->cb_args, GDL_HDMI_AUDIO_EVENT_EMPTY, data);
        break;
    
    // DMA has been stopped on purpose
    case KERN_HDMI_DMA_STOP:
        STAGE_EQUAL(bi, ABD_USE_STAGE_STOP_IN_PROGRESS, rc, GDL_ERR_FAILED, exit);
        STAGE_UPDATE(bi, ABD_USE_STAGE_FORMAT);
        bi->cb(bi->cb_args, GDL_HDMI_AUDIO_EVENT_STOP_DONE, data);
        break;
    
    // DMA has processed another data chunk.. beware that from the time
    // the request is initiated from user space by the time it gets here
    // the ABD stage could have changed
    case KERN_HDMI_DMA_READ:
        switch (bi->use_stage)
        {
        case ABD_USE_STAGE_PLAYBACK:
            bi->cb(bi->cb_args, GDL_HDMI_AUDIO_EVENT_TRANSFER_DONE, data);
            break;
        case ABD_USE_STAGE_STOP_IN_PROGRESS:
            bi->cb(bi->cb_args, GDL_HDMI_AUDIO_EVENT_CLEAN_UP, data);
            break;
        default:
            printk("HDMI audio read callback done at the wrong time\n");
            break;
        }
        break;
    
    // Buffer has not been fetched by DMA
    case KERN_HDMI_DMA_CLEAN_UP:
        STAGE_EQUAL(bi, ABD_USE_STAGE_STOP_IN_PROGRESS, rc, GDL_ERR_FAILED, exit);
        bi->cb(bi->cb_args, GDL_HDMI_AUDIO_EVENT_CLEAN_UP, data);
        break;
    
    // Buffer has been rejected by DMA
    case KERN_HDMI_DMA_REJECT:
        bi->cb(bi->cb_args, GDL_HDMI_AUDIO_EVENT_REJECT, data);
        break;
    
    default:
        GDL_ERROR("Unknown DMA event\n");
        rc = GDL_ERR_NO_HW_SUPPORT;
        break;
    }
    
exit:
    return rc;
}

//------------------------------------------------------------------------------
// mm_abd_set_event_callback()
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_set_event_callback(buffer_info_t * bi,
                                           abd_cb_t        event_callback,
                                           void          * user_data)
{
    gdl_ret_t rc = GDL_SUCCESS;
    
    // Make sure things are right
    VERIFY(bi != NULL, rc, GDL_ERR_INTERNAL, exit);
    STAGE_IN(bi, ABD_USE_STAGE_OPENED, ABD_USE_STAGE_FORMAT, rc, GDL_ERR_FAILED, exit);
    
    // Valid callback pointer must be provided
    VERIFY(event_callback != NULL, rc, GDL_ERR_NULL_ARG, exit);
    
    // Save callback pointer
    bi->cb      = event_callback;
    bi->cb_args = user_data;
    
    // Update ABD use stage
    STAGE_UPDATE(bi, ABD_USE_STAGE_CB);
    
exit:
    return rc;
}

//------------------------------------------------------------------------------
// mm_abd_set_format()
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_set_format(buffer_info_t              * bi,
                                   gdl_hdmi_audio_fmt_t         format,
                                   unsigned int                 num_channels,
                                   gdl_hdmi_audio_fs_t          sample_rate,
                                   gdl_hdmi_audio_ss_t          sample_size,
                                   gdl_hdmi_audio_speaker_map_t speaker_map)
{
    gdl_ret_t             rc   = GDL_SUCCESS;
    gdl_hdmi_audio_ctrl_t ctrl = { .cmd_id = GDL_HDMI_AUDIO_SET_FORMAT };
    
    // Make sure things are right
    VERIFY(bi != NULL, rc, GDL_ERR_INTERNAL, exit);
    STAGE_IN(bi, ABD_USE_STAGE_OPENED, ABD_USE_STAGE_FORMAT, rc, GDL_ERR_FAILED, exit);
    
    // Prepare and submit request
    ctrl.data._set_config.fmt = format;
    ctrl.data._set_config.ch  = num_channels;
    ctrl.data._set_config.fs  = sample_rate;
    ctrl.data._set_config.ss  = sample_size;
    ctrl.data._set_config.map = speaker_map;
    rc = mm_abd_queue(&ctrl, GDL_TRUE);
    VERIFY_QUICK(rc == GDL_SUCCESS, exit);
    
    // Update ABD use stage
    STAGE_UPDATE(bi, ABD_USE_STAGE_FORMAT);
    
exit:
    return rc;
}

//------------------------------------------------------------------------------
// mm_abd_write()
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_write(buffer_info_t * bi,
                              unsigned int    samples,
                              unsigned int    silence,
                              unsigned int    size,
                              unsigned int    id)
{
    gdl_ret_t             rc   = GDL_SUCCESS;
    gdl_boolean_t         sync = GDL_TRUE;
    gdl_hdmi_audio_ctrl_t ctrl = { .cmd_id = GDL_HDMI_AUDIO_WRITE };
    
    // Make sure things are right
    VERIFY(bi != NULL, rc, GDL_ERR_INTERNAL, exit);
    STAGE_IN(bi, ABD_USE_STAGE_FORMAT, ABD_USE_STAGE_PLAYBACK, rc, GDL_ERR_FAILED, exit);
    
    // Check input location
    VERIFY(samples && silence, rc, GDL_ERR_NULL_ARG, exit);
    
    // Init locals
    sync = bi->use_stage == ABD_USE_STAGE_FORMAT;
    
    // Submit write information to the main driver
    ctrl.data._write.size    = size;
    ctrl.data._write.samples = samples;
    ctrl.data._write.silence = silence;
    ctrl.data._write.id      = id;
    ctrl.data._write.sync    = sync;
    rc = mm_abd_queue(&ctrl, sync);
    
exit:        
    return rc;
}

//------------------------------------------------------------------------------
// mm_abd_open()
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_open(gdl_hdmi_audio_device_id_t id, void ** handle)
{
    gdl_ret_t       rc = GDL_SUCCESS;
    buffer_info_t * bi = NULL;
    
    // Make sure requested device is valid
    bi = __id_to_buffer(id);
    VERIFY(bi != NULL, rc, GDL_ERR_FAILED, exit);
    
    // Make sure handle points to a valid location
    VERIFY(handle != NULL, rc, GDL_ERR_NULL_ARG, exit);
    
    // Make sure ABD is not already opened
    STAGE_EQUAL(bi, ABD_USE_STAGE_CLOSED, rc, GDL_ERR_FAILED, exit);
    
    // Initialize / reset the rest of buffer descriptor
    bi->cb          = NULL;
    bi->cb_args     = NULL;
    
    // Init sync primitive
    sema_init(&bi->protect, 1);
    
    // Mark ABD as opened
    STAGE_UPDATE(bi, ABD_USE_STAGE_OPENED);
    
    // Fill in handle
    *handle = (void*) id;
    
exit:
    return rc;
}

//------------------------------------------------------------------------------
// mm_abd_close()
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_close(buffer_info_t * bi)
{
    gdl_ret_t rc = GDL_SUCCESS;
    
    // Make sure things are right
    VERIFY(bi != NULL, rc, GDL_ERR_INTERNAL, exit);
    STAGE_IN(bi, ABD_USE_STAGE_OPENED, ABD_USE_STAGE_FORMAT, rc, GDL_ERR_FAILED, exit);
    
    // Mark ABD as unused
    STAGE_UPDATE(bi, ABD_USE_STAGE_CLOSED);
    
exit:
    return rc;
}

//------------------------------------------------------------------------------
// mm_abd_set_channel_status()
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_set_channel_status(buffer_info_t * bi,
                                           unsigned int  * lsw,
                                           unsigned int  * msw)
{
    gdl_ret_t             rc   = GDL_SUCCESS;
    gdl_hdmi_audio_ctrl_t ctrl = { .cmd_id = GDL_HDMI_AUDIO_SET_CHANNEL_STATUS };
    
    // Make sure things are right
    VERIFY(bi != NULL, rc, GDL_ERR_INTERNAL, exit);
    VERIFY(lsw && msw, rc, GDL_ERR_NULL_ARG, exit);
    STAGE_GE(bi, ABD_USE_STAGE_FORMAT, rc, GDL_ERR_FAILED, exit);
    
    // Submit channel status info to the main driver
    ctrl.data._channel_status.lsw = *lsw;
    ctrl.data._channel_status.msw = *msw;
    rc = mm_abd_queue(&ctrl, GDL_TRUE);
    
exit:
    return rc;
}

//------------------------------------------------------------------------------
// mm_abd_get_channel_status()
//------------------------------------------------------------------------------
static gdl_ret_t mm_abd_get_channel_status(buffer_info_t * bi,
                                           unsigned int  * lsw,
                                           unsigned int  * msw)
{
    gdl_ret_t             rc   = GDL_SUCCESS;
    gdl_hdmi_audio_ctrl_t ctrl = { .cmd_id = GDL_HDMI_AUDIO_GET_CHANNEL_STATUS };
    
    // Make sure things are right
    VERIFY(bi, rc, GDL_ERR_INTERNAL, exit);
    VERIFY(lsw && msw, rc, GDL_ERR_NULL_ARG, exit);
    STAGE_GE(bi, ABD_USE_STAGE_FORMAT, rc, GDL_ERR_FAILED, exit);

    rc = mm_abd_queue(&ctrl, GDL_TRUE);

    // Return channel status info to the audio driver
    *lsw = ctrl.data._channel_status.lsw;
    *msw = ctrl.data._channel_status.msw;
 
exit:
    return rc;
}

//------------------------------------------------------------------------------
// ABD interface point; Note that open call was left non thread-safe on purpose.
// This should not cause any issues under normal conditions.
//------------------------------------------------------------------------------
gdl_ret_t ABD_HANDLER(abd_command_t * cmd)
{
    gdl_ret_t       rc = GDL_SUCCESS;
    buffer_info_t * bi = NULL;
    
    // Safety check
    VERIFY(cmd != NULL, rc, GDL_ERR_INTERNAL, exit);
    
    // Make sure we are not being called from interrupt context
    if (unlikely(in_atomic()))
    {
        GDL_ERROR("ABD can not be called from interrupt context!!!\n");
        rc = GDL_ERR_SCHED_IN_ATOMIC;
        goto exit;
    }
    
    // Check handle and convert it to the buffer descriptor
    if (cmd->id != ABD_OPEN)
    {
        bi = __id_to_buffer((gdl_hdmi_audio_device_id_t) cmd->h);
        VERIFY(bi != NULL, rc, GDL_ERR_HANDLE, exit);
        VERIFY(!down_interruptible(&bi->protect), rc, GDL_ERR_INTERNAL, exit);
    }
    
    // Command specific processing
    switch (cmd->id)
    {
    case ABD_OPEN:
        rc = mm_abd_open(cmd->data._open.id, cmd->data._open.h);
        break;
    
    case ABD_CLOSE:
        rc = mm_abd_close(bi);
        break;
    
    case ABD_SET_EVENT_CB:
        rc = mm_abd_set_event_callback(bi,
                                       cmd->data._set_event_cb.event_callback,
                                       cmd->data._set_event_cb.user_data);
        break;
        
    case ABD_SET_FORMAT:
        rc = mm_abd_set_format(bi,
                               cmd->data._set_format.format,
                               cmd->data._set_format.num_channels,
                               cmd->data._set_format.sample_rate,
                               cmd->data._set_format.sample_size,
                               cmd->data._set_format.speaker_map);
        break;
        
    case ABD_START:
        rc = mm_abd_start(bi);
        break;
        
    case ABD_STOP:
        rc = mm_abd_stop(bi, cmd->data._stop.sync);
        break;

    case ABD_RESET:
        rc = mm_abd_reset(bi);
        break;
        
    case ABD_WRITE:
        rc = mm_abd_write(bi,
                          cmd->data._write.samples,
                          cmd->data._write.silence,
                          cmd->data._write.size,
                          cmd->data._write.id);
        break;
    
    case ABD_SET_CHANNEL_STATUS:
        rc = mm_abd_set_channel_status(bi,
                                       cmd->data._channel_status.lsw,
                                       cmd->data._channel_status.msw);
        break;
    
    case ABD_GET_CHANNEL_STATUS:
        rc = mm_abd_get_channel_status(bi,
                                       cmd->data._channel_status.lsw,
                                       cmd->data._channel_status.msw);
        break;
    
    default:
        rc = GDL_ERR_INVAL;
        break;
    }
    
    // Release concurrency control primitive
    if (cmd->id != ABD_OPEN)
    {
        up(&bi->protect);
    }
    
exit:
    return rc;
}

//----------------------------------------------------------------------------
// Exported Symbols
//----------------------------------------------------------------------------
EXPORT_SYMBOL(ABD_HANDLER);
