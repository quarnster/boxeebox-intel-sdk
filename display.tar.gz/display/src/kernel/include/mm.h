//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

#ifndef __MM_H__
#define __MM_H__

#define GDL_TRANS_ID_NONE -1
#define GDL_IOC_MAGIC 'G'

#include "vdc_hal_types.h"

//----------------------------------------------------------------------------
// Signal numbers sent from kernel space to userspace
//----------------------------------------------------------------------------
typedef enum
{ 
    MM_SIG_NONE,

    MM_SIG_FRAMESTART_PIPE_A,
    MM_SIG_VBLANK_PIPE_A,
    MM_SIG_VSYNC_PIPE_A,
    MM_SIG_FRAMESTART_PIPE_B,
    MM_SIG_VBLANK_PIPE_B,
    MM_SIG_VSYNC_PIPE_B,
    MM_SIG_WBP_FRAMEDONE,

    MM_SIG_LAST_SIG
} mm_signal_t;

//----------------------------------------------------------------------------
// Structure used for irq registration
//----------------------------------------------------------------------------
typedef struct _irq_registration_t
{
    int          irq_number;
    int          irq_token;
    unsigned int mask;
    int          signal;
    unsigned int isr_address;
    unsigned int isr_page;
} irq_registration_t;

//----------------------------------------------------------------------------
// Status codes for use with KERN_SERVER_SET_STATUS
//----------------------------------------------------------------------------
typedef enum
{
    MM_STATUS_RUNNING,
    MM_STATUS_SUSPENDED,
    MM_STATUS_DEAD
} mm_status_t;

//----------------------------------------------------------------------------
// km_service_t
//
// Kernel module services enumeration
//----------------------------------------------------------------------------
//----------------------------------------------------------------------------
// About    KERN_WAIT_FOR_VBI_PROCESSING
//          KERN_FRAMESTART_PROCESSED
//
// In the timeline below, FS represents the Pipe A Framestart HW event, and IH
// indicates invocation of the display driver Framestart interrupt handler.
// 
//     <-- "NO-FLIP" INTERVAL-->
//
//     <--- 1 ms --->
//     -------+-----+----------+--
//            |     |          |
//           FS     IH       server
//                         (vbi_thread)
//                          handles FS
// 
// At Framestart, HW copies shadow registers (including plane buffer pointers)
// into actual registers.  The surfaces represented by these pointers are
// reported to the programmer through the "FLIP" (shadow register surface) and
// "DISPLAYED_SURFACE" (active register surface) plane attributes.  To report
// these attributes correctly, GDL flip routines set the FLIP attribute, and
// (on every Framestart) the server's vbi_thread_handler copies the FLIP
// attribute value to the DISPLAYED_SURFACE attribute.  Correct reporting of
// these attributes is essential to graphics/DirectFB, so new flips MUST NOT
// overwrite the FLIP attribute between the FS interrupt and the server's
// completion of this copy.
// 
// For this reason we implement a "no flip" interval. GDL flip functions invoke
// the KERN_WAIT_FOR_VBI_PROCESSING service before touching plane data
// structures. The service blocks the caller if either of the following are true:
// 
//  - We are within 1ms of the next expected Framestart. This arbitrary period
//    is hoped to be long enough for any GDL operation begun before the start
//    of the period to complete before the FS interrupt handler is invoked.
//
//  - We have had a Framestart interrupt but the server has not yet reported
//    (via KERN_FRAMESTART_PROCESSED) completion of Framestart handling
//    (attribute copying) since the last Framestart.
//
// VBD flips are not subject to this constraint, as GDL surfaces are not used
// (SMD provides its own buffers); the FLIP/DISPLAYED_SURFACE attributes
// are not relevant on planes in use for video.
// 
// In general, use of this service by functions in the GDL removes contention
// between those functions and the vbi_thread, because the vbi_thread will be
// asleep for most of the time outside this interval.
//----------------------------------------------------------------------------
typedef enum
{
    KERN_TRANS_GET,                 //  0
    KERN_TRANS_SET,                 //  1
    KERN_WAIT_FOR_EVENT,            //  2
    KERN_GET_POLARITY_PIPE_A,       //  3
    KERN_GET_POLARITY_PIPE_B,       //  4
    KERN_ENABLE_INTERRUPTS,         //  5
    KERN_DISABLE_INTERRUPTS,        //  6
    KERN_GET_BACKDOOR_JOB,          //  7
    KERN_SET_BACKDOOR_JOB,          //  8
    KERN_SERVER_SET_STATUS,         //  9
    KERN_GET_CONNECTIONS,           // 10
    KERN_GET_IRQ,                   // 11
    KERN_GET_VERSION,               // 12
    KERN_REGISTER_IRQ,              // 13
    KERN_UNREGISTER_IRQ,            // 14
    KERN_HDMI_DMA_READ,             // 15
    KERN_HDMI_DMA_UNDERRUN,         // 16
    KERN_HDMI_DMA_REJECT,           // 17
    KERN_HDMI_DMA_STOP,             // 18
    KERN_WOE_ADD,                   // 19
    KERN_WOE_DELETE,                // 20
    KERN_WAIT_FOR_VBI_PROCESSING,   // 21
    KERN_FRAMESTART_PROCESSED,      // 22
    KERN_PID_ALIVE,                 // 23
    KERN_FLUSH_CACHE,               // 24
    KERN_SAFE_REG_WRITE,            // 25
    KERN_ENABLE_SW_LRID_TOGGLE,     // 26
    KERN_DISABLE_SW_LRID_TOGGLE,    // 27
    KERN_HDMI_DMA_CLEAN_UP,         // 28
    KERN_CHECK_MEM_REGION,          // 29
} km_service_t;


//----------------------------------------------------------------------------
// mm_sw_lrid_info_t
//
// Structure for passing data to KERN_ENABLE_SW_LRID_TOGGLE. Structure is used
// for specifying gpio number and whether polarity is inverted to
// software-controlled LRID toggling. 
//----------------------------------------------------------------------------
typedef struct
{
    unsigned int  gpio;
    gdl_boolean_t invert_polarity;
} mm_sw_lrid_info_t;

//----------------------------------------------------------------------------
// mm_mem_region_check_t
//
// Structure for passing data for KERN_CHECK_MEM_REGION. Structure is used
// for querying whether a memory region specified by physical address
// "addr" and size "size" can be mapped, attached as heap or used for
// surface creation.
//
// Fields:
// addr    - Phys address of the beginning of the memory region
// size    - Size in bytes for the memory region
// allowed - Filled by KERN_CHECK_MEM_REGION
//----------------------------------------------------------------------------
typedef struct
{
    unsigned int  addr;
    unsigned int  size;
    gdl_boolean_t allowed;   
} mm_chk_mem_region_t;

#define MAX_SAFE_REG_WRITES 2

//----------------------------------------------------------------------------
// mm_safe_reg_write_t
//
// Structure for passing data to KERN_SAFE_REG_WRITE kernel service.
// Structure is used for specifying VDC registers and values that need
// to be written into those registers.
//
// Fields:
// reg[]       - Array of VDC registers specified as offsets from VDC base
// value[]     - Values to write into specified registers
// keep_mask[] - Masks specifying which parts of register values to keep
// num_entries - Total number of (reg/value/kee_mask) tuples.
//----------------------------------------------------------------------------
typedef struct 
{
    gdl_uint32 reg[MAX_SAFE_REG_WRITES];      
    gdl_uint32 value[MAX_SAFE_REG_WRITES];    
    gdl_uint32 keep_mask[MAX_SAFE_REG_WRITES];
    gdl_uint32 num_entries;                  
} mm_safe_reg_write_t;


//----------------------------------------------------------------------------
// mm_pid_state_t
//
// Structure for checking whether process is alive or not. Structure is
// used during KERN_PID_ALIVE service call
//----------------------------------------------------------------------------
typedef struct mm_pid_state_t
{
    gdl_uint32    pid;
    gdl_boolean_t alive;
} mm_pid_state_t;

//----------------------------------------------------------------------------
// gdl_trans_type_t
//
// Transaction type which specifies for which component job is scheduled
//----------------------------------------------------------------------------
typedef enum gdl_trans_type_t
{
    GFX_TRANS,
    VDC_TRANS,
    PD_TRANS,
} gdl_trans_type_t;


//----------------------------------------------------------------------------
// mm_capability_t
//
// OR-able list of capabilities of the caller.
//----------------------------------------------------------------------------
typedef enum
{
    MM_CAP_SYS_RAWIO  = 0x1,  // MAPS to CAP_SYS_RAWIO
} mm_capability_t;

// List of all supported capabilities
#define MM_CAPS_ALL (MM_CAP_SYS_RAWIO)

//----------------------------------------------------------------------------
// gdl_trans_data_t
//
// Structure used when receiving data based on the transaction id
//----------------------------------------------------------------------------
typedef struct gdl_trans_data_t
{
    int              trans_id; // Transaction id
    gdl_trans_type_t type;     // Transaction type: specifies which subsystem handles it
    int              shm_id;   // Shared memory id: payload
    unsigned int     pid;      // PID of the client
    unsigned int     uid;      // UID of the client
    unsigned int     sys_caps; // Effective caller capabilities - OR-ed
                               // mm_capility_t flags
} gdl_trans_data_t;


//----------------------------------------------------------------------------
// gdl_trans_status_t
//
// Status of the transaction
//----------------------------------------------------------------------------
typedef enum gdl_trans_status_t
{
    GDL_TRANS_NEW,
    GDL_TRANS_COMPLETE,
    GDL_TRANS_WORKING,
    GDL_TRANS_ABORTED
} gdl_trans_status_t;

//----------------------------------------------------------------------------
// backdoor_job_status_t
//----------------------------------------------------------------------------
typedef enum
{
    BACKDOOR_JOB_NEW,
    BACKDOOR_JOB_COMPLETE,
    BACKDOOR_JOB_WORKING
} backdoor_job_status_t;

//----------------------------------------------------------------------------
// This enumeration lists all possible job types
//----------------------------------------------------------------------------
typedef enum
{
    JOB_TYPE_VBD,   // Video job
    JOB_TYPE_ABD,   // Audio job
    JOB_TYPE_MM,    // Kernel module job
} backdoor_job_type_t;

//----------------------------------------------------------------------------
// This constant sets maximum size of data that can be submitted with the job
//----------------------------------------------------------------------------
#define MAX_JOB_DATA_SIZE 128

//----------------------------------------------------------------------------
// backdoor_job_t
//
// Backdoor job structure used for handling backdoor jobs
//----------------------------------------------------------------------------
typedef struct
{
    int                     job_id;                  // Job ID
    backdoor_job_type_t     job_type;                // Job type
    char                    data[MAX_JOB_DATA_SIZE]; // Payload
    backdoor_job_status_t   job_status;              // Job status
    gdl_ret_t               rc;                      // Return code
} backdoor_job_t;

//----------------------------------------------------------------------------
// internal_cmd_t
//
// Internal commands sent by kernel module to server
//----------------------------------------------------------------------------
typedef enum
{
    INTERN_CMD_CLIENT_INIT,   // Notify about client initialization
    INTERN_CMD_CLIENT_DEINIT, // Notify about client deinitialization
    INTERN_CMD_IRQ,           // Notify about interrupt
    INTERN_CMD_DUMP_MEMINFO,  // Dump memory info into a file
} internal_cmd_t;


#define PROCFS_MEM_FILENAME_SIZE 80

//----------------------------------------------------------------------------
// internal_job_t
//
// A backdoor job initiated by the kernel module itself (as opposed to on behalf
// of the clients of the VBD or ABD interfaces).
//----------------------------------------------------------------------------
typedef struct
{
    internal_cmd_t cmd;
    union 
    {
        //INTERN_CMD_CLIENT_INIT, INTERN_CMD_CLIENT_DEINIT
        unsigned int    pid;

        // INTERN_CMD_IRQ
        struct
        {
            mm_signal_t signal;
            gdl_uint32  isr;
        } irq;

        // INTERN_CMD_DUMP_MEMINFO
        unsigned char file_name[PROCFS_MEM_FILENAME_SIZE];
    } data;
} internal_job_t;

//Maximum number of registers that may be written at once
//326 values are enough to write the PB1 Gamma LUT on CE5300
#define MM_WOE_MAX_REGISTER_COUNT 326

// Interface structure used for adding new
// event to the woe queue and retrieving back id
typedef struct mm_woe_t
{
    unsigned int          id;          // ID returned here upon registration
    vdc_interrupt_event_t event;       // Event on which to write register

    unsigned int          length;      // Number of registers to write
    unsigned int          regs[MM_WOE_MAX_REGISTER_COUNT];
                                       // Register offsets from VDC base
    unsigned int          values[MM_WOE_MAX_REGISTER_COUNT];
                                       // Values to write to the registers
    unsigned int          keep_mask;   // Mask of bits to keep in all registers
                                       // ~mask bits will be cleared
                                       // and contents OR-ed with value   
    gdl_boolean_t         persistent;  // If false, delete this event after it
                                       // has been triggered
} mm_woe_t;


#endif /* __MM_H__ */
