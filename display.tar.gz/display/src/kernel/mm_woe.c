//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2008-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2008-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
//----------------------------------------------------------------------------
// This module supports the "Write on Event" service, which allows the server
// daemon to specify values that should be written to specified registers on
// specified events (interrupts).
//
// The original motivation for this service is the need for top and bottom
// fields to use different initial phase values for the UPP scaler when the
// display is in an interlaced mode. The UPP scaler does not provide separate
// registers for this purpose, so we must reprogram phase register on the fly.
//
// Additional events may eventually be supported as the need arises.
//----------------------------------------------------------------------------

#include <linux/list.h>
#include "mm_common.h"
#include "common.h"
        
//All VDC_EVENT_* entries which may occur on Pipe B
#define PIPE_B_EVENTS \
    (VDC_EVENT_VSYNC_PIPE_B     | VDC_EVENT_VBLANK_PIPE_B       | \
     VDC_EVENT_TOP_FIELD_PIPE_B | VDC_EVENT_BOTTOM_FIELD_PIPE_B | \
     VDC_EVENT_FRAMESTART_PIPE_B)

// Spinlock to protect addition/removal of woe nodes 
static spinlock_t  woe_queue_spinlock;
//Spinlock to protect storing/clearing/using of woe_events variable
static spinlock_t  woe_events_spinlock; 

static unsigned long irq_save_flags_queue;
static unsigned long irq_save_flags_events;

//VDC device structure
extern vdc_t vdc_dev;

void mm_woe_lock_queue(void)
{
    spin_lock_irqsave(&woe_queue_spinlock, irq_save_flags_queue);
}

void mm_woe_unlock_queue(void)
{
    spin_unlock_irqrestore(&woe_queue_spinlock, irq_save_flags_queue);
}

void mm_woe_lock_events(void)
{
    spin_lock_irqsave(&woe_events_spinlock, irq_save_flags_events);
}

void mm_woe_unlock_events(void)
{
    spin_unlock_irqrestore(&woe_events_spinlock, irq_save_flags_events);
}

static unsigned int g_woe_id = 0;

// Head of linked list of registers to write
static struct list_head woe_queue;

//Tasklet which exectues the actual WOE events on the queue
static struct tasklet_struct woe_tasklet;

//Events that the tasklet should process
static unsigned int woe_events;

//----------------------------------------------------------------------------
// INTERNAL/HELPER FUNCTIONS
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// __mm_woe_process_entry
//
// Write all of the registers specified in a woe node
//----------------------------------------------------------------------------
void __mm_woe_process_entry(mm_woe_node_t *node)
{
    unsigned int reg_val;
    unsigned int reg_addr;
    unsigned int i;

    for (i = 0; i < node->data.length; i++)
    {
        reg_addr = node->data.regs[i];
        reg_val  = vdc_dev.io_read(0, vdc_dev.io_address, reg_addr);
        reg_val  = reg_val & node->data.keep_mask;
        reg_val  = reg_val | (node->data.values[i] & ~(node->data.keep_mask));
        vdc_dev.io_write(0, vdc_dev.io_address, reg_addr, reg_val);
    }
}
    
//----------------------------------------------------------------------------
// __mm_woe_process_event_tasklet
//
// Tasklet which runs in soft interrupt context and processes all 
// events currently in the queue
//----------------------------------------------------------------------------
void __mm_woe_process_event_tasklet(unsigned long data)
{
    mm_woe_node_t *cursor;
    mm_woe_node_t *next;
    unsigned int   events; 
    
    //Capture the events we are supposed to process, and then clear them
    //mm_woe_process_events() may now update the events were seen while we are 
    //processing the queue
    mm_woe_lock_events();
    events = woe_events;
    woe_events = 0;
    mm_woe_unlock_events();

    mm_woe_lock_queue();

    list_for_each_entry_safe(cursor, next, &woe_queue, list)
    {
        if ((cursor->data.event & events) == cursor->data.event)
        {
            __mm_woe_process_entry(cursor);

            if (cursor->data.persistent == GDL_FALSE)
            {
                list_del(&cursor->list);
                OS_FREE(cursor);
            }
        }
    }

    mm_woe_unlock_queue();
}

//----------------------------------------------------------------------------
// INTERFACE FUNCTIONS
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// mm_woe_add
//
// Adds a new element to the write-on-event queue. Function is to be called upon
// KERN_WOE_ADD service request
//
// Arguments:
// [in] data : New element to add to write-on-event queue
// [out]  id : Return handle corresponding to the new element here
//----------------------------------------------------------------------------
gdl_ret_t mm_woe_add(mm_woe_t * data, unsigned int * id)
{
    mm_woe_node_t    *new_node;
    gdl_ret_t        rc = GDL_SUCCESS;

    if ((data == NULL)
    ||  (id   == NULL))
    {
        GDL_ERROR("Input arguments are null\n");
        rc = GDL_ERR_NULL_ARG;
        goto end;
    }

    if (data->length > MM_WOE_MAX_REGISTER_COUNT)
    {
        GDL_ERROR("WOE can only write maximum of %d registers at a time\n", 
                  MM_WOE_MAX_REGISTER_COUNT);
        rc = GDL_ERR_INVAL;
        goto end;
    }

    new_node = OS_ALLOC(sizeof(mm_woe_node_t));

    if (new_node == NULL)
    {
        GDL_ERROR("Unable to allocate memory\n");
        rc = GDL_ERR_NO_MEMORY;
        goto end;
    }

    memcpy(&new_node->data, data, sizeof(mm_woe_t));

    mm_woe_lock_queue();

    g_woe_id++;
    new_node->id = g_woe_id;

    list_add_tail(&new_node->list, &woe_queue);

    mm_woe_unlock_queue();

    // Return unique id for this entry to the caller
    *id = new_node->id;

end:
    return rc;
}


//----------------------------------------------------------------------------
// mm_woe_delete
//
// Deletes a write-on-event entry from the queue
// Function is to be called upon KERN_WOE_DELETE service request
// 
// Arguments:
// [in] id : Handle previously returned by mm_woe_add()
//----------------------------------------------------------------------------
gdl_ret_t mm_woe_delete(unsigned int id)
{
    gdl_ret_t      rc       = GDL_ERR_FAILED;
    mm_woe_node_t  *cursor;

    mm_woe_lock_queue();

    list_for_each_entry(cursor, &woe_queue, list)
    {
        if (cursor->id == id)
        {
            list_del(&cursor->list);
            OS_FREE(cursor);

            rc = GDL_SUCCESS;
            break;
        }
    }

    mm_woe_unlock_queue(); 
    return rc;   
}

//----------------------------------------------------------------------------
// mm_woe_process_events
// 
// Queue events to be processed by the BH handler tasklet. This function
// should be called by the TH interrupt handler, and it may be called at any
// time
//
// Arguments:
// [in] pipe   : The pipe that these events occurred on
// [in] events : VDC_EVENT_* values which have occurred
//----------------------------------------------------------------------------
gdl_ret_t mm_woe_process_events(vdc_pipe_t pipe, unsigned int events)
{
    if (pipe == VDC_PIPE_A)
    {
        //Mask off any Pipe B events which occurred
        events &= ~PIPE_B_EVENTS;
    }
    else
    {
        //Mask off any Pipe A events which occurred
        events &= PIPE_B_EVENTS;
    }

    //Our tasklet may get scheduled more than once before it actually executes
    //(It will only execute once however)
    //To make sure we don't miss any events, store all events seen since the
    //last time the tasklet executed. We must also lock to make sure that we are
    //not adding events when the tasklet begins executing and resets woe_events
    mm_woe_lock_events();
    woe_events |= events;
    mm_woe_unlock_events();

    //Schedule the tasklet to be executed before any "normal" priority tasklets
    //in the system, this should help the delay between the framestart interrupt
    //and when the tasklet executes
    tasklet_hi_schedule(&woe_tasklet);

    return GDL_SUCCESS;
}

//----------------------------------------------------------------------------
// mm_woe_init
//
// Initializes write-on-event system. Initializes the queue to be empty
// and sets global id tracker to 0
//----------------------------------------------------------------------------
gdl_ret_t mm_woe_init(void)
{
    INIT_LIST_HEAD(&woe_queue);

    g_woe_id = 0;

    spin_lock_init(&woe_queue_spinlock);
    spin_lock_init(&woe_events_spinlock);

    tasklet_init(&woe_tasklet, __mm_woe_process_event_tasklet, 0);

    return GDL_SUCCESS;
}


//----------------------------------------------------------------------------
// mm_woe_deinit
//
// Deinitializes write-on-event system by deleting all elements from the queue
//----------------------------------------------------------------------------
gdl_ret_t mm_woe_deinit(void)
{
    mm_woe_node_t *cursor;
    mm_woe_node_t *next;
    
    list_for_each_entry_safe(cursor, next, &woe_queue, list)
    {
        list_del(&cursor->list);
        OS_FREE(cursor);
    }
    
    return GDL_SUCCESS;
}

//----------------------------------------------------------------------------
// mm_woe_enable
//
// Re-enable the tasklet. If it was scheduled prior to calling mm_woe_disable,
// then the tasklet will still be scheduled to execute
//----------------------------------------------------------------------------
gdl_ret_t mm_woe_enable(void)
{
    tasklet_enable(&woe_tasklet);

    return GDL_SUCCESS;
}

//----------------------------------------------------------------------------
// mm_woe_disable
//
// When this function returns, the tasklet is not executing and will not be
// called again until enabled and scheduled through mm_woe_process_events
//----------------------------------------------------------------------------
gdl_ret_t mm_woe_disable(void)
{
    tasklet_disable(&woe_tasklet);

    return GDL_SUCCESS;
}

