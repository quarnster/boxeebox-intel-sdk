//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// File Description:
//    Regular job queue
//
//  File contains implementation of job queues.
//  Job is a transaction between client and a daemon through daemon.
//  Daemon is in a blocked state waiting for a new job to be put on a queue.
//  Client initiates a transaction by sending transaction data.
//  Data is copied into a 'job' and entered into a queue.
//  Client wakes up all waiting threads (daemon) and goes to sleep.
//  Daemon gets new job with its ID (transaction id) and exits the module.
//  Daemon works on a job and calls module with that transaction id to send
//      data back.
//  Client is woken up and data is copied back to the client.
//----------------------------------------------------------------------------

#include "osal.h"

#include "mm_common.h"
#include "common.h"

extern int g_server_status;

//----------------------------------------------------------------------------
// Wait queue used for regular (non-vbd) jobs
//----------------------------------------------------------------------------
DECLARE_WAIT_QUEUE_HEAD(mm_job_wait_queue);

//----------------------------------------------------------------------------
// Head and tail of the job link list
//----------------------------------------------------------------------------
static mm_job_t *mm_job_head = NULL;
static mm_job_t *mm_job_tail = NULL;

static os_sema_t queue_lock;

//----------------------------------------------------------------------------
// mm_add_job_to_list
//
// Adds job to the list of jobs. Jobs are stored in fifo manner.
//
// Arguments:
// [in] new_job : Pointer to a new job
//
// Returns: GDL_SUCCESS on success, failure otherwise
//----------------------------------------------------------------------------
static gdl_ret_t mm_add_job_to_list(mm_job_t *new_job)
{
    os_sema_get(&queue_lock);

    new_job->next = NULL;
    if (mm_job_head == NULL)
    {
        mm_job_head = new_job;
        mm_job_tail = new_job;
        new_job->param.trans_id = 0;
    }
    else
    {
        new_job->param.trans_id = mm_job_tail->param.trans_id + 1;
        mm_job_tail->next = new_job;
        mm_job_tail = new_job;
    }

    os_sema_put(&queue_lock);
    return GDL_SUCCESS;
}


//----------------------------------------------------------------------------
// mm_delete_job_from_list
//
// Deletes job from the link-list of jobs based on the id passed.
//
// Arguments:
// [in] id : Id of a job to delete
//
// Returns: GDL_SUCCESS on success, GDL_ERR_FAILED on failure
//----------------------------------------------------------------------------
static gdl_ret_t mm_delete_job_from_list(int id)
{
    gdl_ret_t  ret = GDL_ERR_INTERNAL;
    mm_job_t * tmp_job;
    mm_job_t * saved_job;

    os_sema_get(&queue_lock);
    tmp_job = mm_job_head;
    saved_job = mm_job_head;

    while (tmp_job != NULL)
    {
        if (tmp_job->param.trans_id == id)
        {
            if (tmp_job == mm_job_head)
            {
                mm_job_head = tmp_job->next;
            }
            else if (tmp_job == mm_job_tail)
            {
                mm_job_tail = saved_job;
            }

            saved_job->next = tmp_job->next;

            OS_FREE(tmp_job);

            ret = GDL_SUCCESS;
            break;
        }
        saved_job = tmp_job;
        tmp_job = tmp_job->next;
    }

    os_sema_put(&queue_lock);
    return ret;
}


//----------------------------------------------------------------------------
// mm_purge_job_list
//
// Deletes all jobs from the list of jobs
//----------------------------------------------------------------------------
static void mm_purge_job_list(void)
{
    mm_job_t *saved_job;
    mm_job_t *tmp_job;

    os_sema_get(&queue_lock);
    tmp_job = mm_job_head;
    
    while (tmp_job != NULL)
    {
        saved_job = tmp_job;
        tmp_job = tmp_job->next;
        OS_FREE(saved_job);
    } 
    os_sema_put(&queue_lock);
}


//----------------------------------------------------------------------------
// mm_abort_all_jobs
//----------------------------------------------------------------------------
void mm_abort_all_jobs(void)
{
    mm_job_t *job;

    os_sema_get(&queue_lock);
    job = mm_job_head;
    
    while (job != NULL)
    {
        job->status = GDL_TRANS_ABORTED;
        job = job->next;
    } 
    os_sema_put(&queue_lock);

    // Wake up processes waiting for their jobs
    wake_up_all(&mm_job_wait_queue);
}


//----------------------------------------------------------------------------
// mm_get_job_from_list
//
// Retrieves job based on the job id passed.
//
// Arguments:
// [in] id : Job id to find
//
// Returns: job as mm_job_t structure or NULL if job was not found
//----------------------------------------------------------------------------
static mm_job_t* mm_get_job_from_list(int id)
{
    mm_job_t *tmp_job;

    os_sema_get(&queue_lock);
    tmp_job = mm_job_head;

    while (tmp_job != NULL)
    {
        if (tmp_job->param.trans_id == id)
        {
            break;
        }
        tmp_job = tmp_job->next;
    }

    os_sema_put(&queue_lock);
    return tmp_job;
}


//----------------------------------------------------------------------------
// mm_create_new_job
//
// Creates new job and fills it with passed data
//
// Arguments:
// [in] tr_type : Transaction type
// [in] tr_shmid: Shared memory id of where data for the job lives
//
// Returns: New job as 'mm_job_t' structure
//----------------------------------------------------------------------------
static mm_job_t *mm_create_new_job(int tr_type, int tr_shmid)
{
    mm_job_t *   job;
    unsigned int caps = 0x0;

    job = OS_ALLOC(sizeof(mm_job_t));

    if (NULL == job)
    {
        GDL_ERROR("Failed to allocate memory for new job\n");
        goto EXIT;
    }
    memset(job, 0x0, sizeof(mm_job_t));


    job->param.shm_id = tr_shmid;
    job->param.type   = tr_type;
    job->param.pid    = current->tgid;
    job->param.uid    = mm_uid_filtering_enabled() ? __mm_current_uid() : 0;
    job->status       = GDL_TRANS_NEW;

    // Fill in capabilities supported by teh caller
    if (mm_capabilities_enforced())
    {
        if (capable(CAP_SYS_RAWIO))  caps |= MM_CAP_SYS_RAWIO;
    }
    else
    {
        caps = MM_CAPS_ALL;
    }

    job->param.sys_caps = caps;
    

EXIT:
    return job;
}


//----------------------------------------------------------------------------
// mm_get_new_job
//
// Copies contents of a new job into the transaction.  If job is not available
// (queue empty) caller is put to sleep till the new job appears on the queue.
//
// Arguments:
//   [out] arg: Transaction data. job is copied into this structure
//----------------------------------------------------------------------------
static gdl_ret_t mm_get_new_job(gdl_trans_data_t * arg)
{
    gdl_ret_t ret = GDL_SUCCESS;

    if (NULL == arg)
    {
        ret = GDL_ERR_NULL_ARG;
        goto EXIT;
    }
               
    // Daemon waits till new job is on the queue
    if (wait_event_interruptible(
                mm_job_wait_queue,
                mm_job_head && (mm_job_head->status == GDL_TRANS_NEW)))
    {
        //Interrupt occurred (application was killed)
        ret = GDL_ERR_INTERNAL;
        goto EXIT;
    }

    os_sema_get(&queue_lock);
    
    // Make sure that state did not change after daemon woke 
    // but before it was able to lock semaphore
    if (mm_job_head == NULL)
    {
        ret = GDL_ERR_INTERNAL;
        goto CLEANUP;
    }

    if (mm_job_head->status != GDL_TRANS_NEW)
    {
        ret = GDL_ERR_INTERNAL;
        goto CLEANUP;
    }

    //Job is marked as being worked on
    mm_job_head->status = GDL_TRANS_WORKING;

    // Daemon wakes up and data is copied to daemon
    if (copy_to_user(&arg->type,     &mm_job_head->param.type,     sizeof(int))
    ||  copy_to_user(&arg->trans_id, &mm_job_head->param.trans_id, sizeof(int))
    ||  copy_to_user(&arg->shm_id,   &mm_job_head->param.shm_id,   sizeof(int))
    ||  copy_to_user(&arg->pid,      &mm_job_head->param.pid,      sizeof(int))
    ||  copy_to_user(&arg->sys_caps, &mm_job_head->param.sys_caps, sizeof(int))
    ||  copy_to_user(&arg->uid,      &mm_job_head->param.uid,      sizeof(int)))
    {
        GDL_ERROR("copy_to_user failed\n");
        ret = GDL_ERR_INVAL_PTR;
    }
CLEANUP:
    os_sema_put(&queue_lock);

EXIT:
    return ret;
}


//----------------------------------------------------------------------------
// mm_process_new_job
//
// Creates new job based on a transaction data and processes it.
// Once job is entered into a queue, client is put to sleep till the daemon
// finishes executing the job from the queue and only then client is woken up.
//
// Arguments:
//  [in] trans_arg : Transaction data
//----------------------------------------------------------------------------
static gdl_ret_t mm_process_new_job(gdl_trans_data_t * trans_arg)
{
    gdl_ret_t ret = GDL_SUCCESS;
    int       tr_shmid;
    int       tr_type;

    mm_job_t *new_job = NULL;

    if (NULL == trans_arg)
    {
        ret = GDL_ERR_NULL_ARG;
        goto EXIT;
    }

    __get_user(tr_type, &trans_arg->type);
    __get_user(tr_shmid, &trans_arg->shm_id);

    // Create new job
    new_job = mm_create_new_job(tr_type, tr_shmid);

    if (NULL == new_job)
    {
        ret = GDL_ERR_NO_MEMORY;
        GDL_ERROR("Unable to create new job\n");
        goto EXIT;
    }

    // Add new job to the list of jobs
    mm_add_job_to_list(new_job);

    // Client wakes up daemon and sleeps till job is complete
    wake_up(&mm_job_wait_queue);

    // Body of if statement entered if client was killed
    if (wait_event_timeout(mm_job_wait_queue,
                           (new_job->status == GDL_TRANS_COMPLETE) ||
                           (new_job->status == GDL_TRANS_ABORTED ),
                           MM_MS_TO_JIFFIES(5000)) == 0)
    {
        // If job has not finished in 5 seconds - abort it
        os_sema_get(&queue_lock);
        new_job->status = GDL_TRANS_ABORTED;
        os_sema_put(&queue_lock);
        GDL_ERROR("Client job timed out\n");
        ret = GDL_ERR_TIMEOUT;
    }
  
    // Remove job from the queue
    if (mm_delete_job_from_list(new_job->param.trans_id) != GDL_SUCCESS)
    {
        GDL_ERROR("Failed to remove job from the queue\n");
    }

    // Wake up daemon
    wake_up(&mm_job_wait_queue);

EXIT:
    return ret;
}


//----------------------------------------------------------------------------
// mm_finish_job
//
// Finilizes the job by marking it as complete. Wakes up ayone waiting
// for completion of the job.
//
// Arguments:
// [in] trans_arg : Transaction data
//
// Returns: GDL_SUCCESS on success, error otherwise
//----------------------------------------------------------------------------
static gdl_ret_t mm_finish_job(gdl_trans_data_t * trans_arg)
{
    int tr_id;
    mm_job_t *current_job = NULL;
    int ret = 0;
        
    if (NULL == trans_arg)
    {
        ret = GDL_ERR_NULL_ARG;
        goto EXIT;
    }

    __get_user(tr_id, &trans_arg->trans_id);   
        
    // Daemon sends transaction complete and we unblock the client who waits
    // for transaction to be over.
    current_job = mm_get_job_from_list(tr_id);
                 
    //Job was deleted - it is ok if client exited already
    if (NULL == current_job)
    {
        ret = GDL_ERR_INTERNAL;
        goto EXIT;
    }

    // Set job to be complete
    current_job->status = GDL_TRANS_COMPLETE;

    // wake up processes waiting for jobs to be complete
    wake_up_all(&mm_job_wait_queue);

EXIT:
    return ret;
}


//----------------------------------------------------------------------------
// mm_handle_job
//----------------------------------------------------------------------------
gdl_ret_t mm_handle_job(km_service_t cmd, gdl_trans_data_t * trans_arg)
{
    gdl_ret_t ret = GDL_ERR_INTERNAL;
    int       tr_id;

    if (trans_arg == NULL)
    {
        GDL_ERROR("Transaction data is null\n");
        ret = GDL_ERR_NULL_ARG;
        goto EXIT;
    }

    __get_user(tr_id, &trans_arg->trans_id);

    switch (cmd)
    {
    case KERN_TRANS_GET:
       if (tr_id == GDL_TRANS_ID_NONE)
       {
            //daemon gets new job or waits until one is available and size is
            //returned 
            ret = mm_get_new_job(trans_arg);
       }
       else
       {
            //This section does not get called since daemon does not know
            //transaction id
            ret = GDL_ERR_INTERNAL;
            goto EXIT;
       }

        break;
    case KERN_TRANS_SET:
        if (tr_id == GDL_TRANS_ID_NONE)
        {
            if ( mm_server_alive())
            {
                //client sends new job for process
                //returns to client when new job is processed
                ret = mm_process_new_job(trans_arg);
            }
            else
            {
                ret = GDL_ERR_INTERNAL;
                goto EXIT;
            }
        }
        else
        {
            //Daemon finishes job and marks job as finished
            ret = mm_finish_job(trans_arg);
        }
        break;
    default:
        ret = GDL_ERR_INTERNAL;
        goto EXIT;
        break;
    }

EXIT:
    return ret;
}

//----------------------------------------------------------------------------
// mm_init_job_queue
//----------------------------------------------------------------------------
gdl_ret_t mm_init_job_queue (void)
{
    os_sema_init(&queue_lock,1);
    mm_job_head = NULL;
    mm_job_tail = NULL;
    return GDL_SUCCESS;
}

//----------------------------------------------------------------------------
// mm_cleanup_job_queue
//----------------------------------------------------------------------------
void mm_cleanup_job_queue(void)
{
    mm_purge_job_list();
    mm_job_head = NULL;
    mm_job_tail = NULL;
    os_sema_destroy(&queue_lock);
}
