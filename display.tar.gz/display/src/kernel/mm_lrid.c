//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright 2010-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright 2010-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// File Description:
//
// Implements LRID toggling service which is used for frame sequential
// stereo video modes
//----------------------------------------------------------------------------
#include "osal.h"
#include "idl.h"
#include "idl_gpio.h"
#include "thread_utils.h"
#include "gen_timer.h"
#include "common.h"
#include "mm_common.h"

#define GPIO_UNASSIGNED -1

// Note: On CE4200-A gpio 78 can be used to test gpio function
static mm_sw_lrid_info_t g_lrid_info;

static os_thread_t gpio_thread;

// Current polarity
static gdl_polarity_t g_lrid_polarity;

// Wait queue for gpio thread to sleep on
DECLARE_WAIT_QUEUE_HEAD(mm_gpio_wait_queue);

// Global that controls whether gpio thread should exit or not upon the wakeup
static gdl_boolean_t exit_gpio_thread = GDL_TRUE;



//----------------------------------------------------------------------------
// __gpio_thread_fn
//
// Thread runs continuously until it is killed (by setting exit_gpio_thread
// global to GDL_TRUE). 
// Thread alternates between toggling gpio line to on/off state on every
// wake-up.
//
// LRID/gpio must be toggled as a reponse to VSYNC interrupt. Due to
// idl_gpio_xxx() functions taking a semaphore, they cannot be called from
// an interrupt context. Instead, on every VSYNC this thread is woken up
// by a call to mm_lrid_trigger() function.
//----------------------------------------------------------------------------
static void * __gpio_thread_fn(void * data)
{
    gdl_boolean_t gpio_on = GDL_TRUE;

    while (1)
    {
        interruptible_sleep_on(&mm_gpio_wait_queue);
        
        if (exit_gpio_thread == GDL_TRUE)
        {
            return 0;
        }        


        gpio_on = (gpio_on == GDL_TRUE) ? GDL_FALSE : GDL_TRUE;

        
        if (g_lrid_info.invert_polarity)
        {
            g_lrid_polarity = (gpio_on == GDL_TRUE) ? GDL_POLARITY_FRAME
                                                    : GDL_POLARITY_FRAME_RIGHT;
        }
        else
        {
            g_lrid_polarity = (gpio_on == GDL_FALSE) ? GDL_POLARITY_FRAME
                                                     : GDL_POLARITY_FRAME_RIGHT;
        }

        // Sleep for 1 millisecond before triggering LRID
        gt_sleep_100us(10);

        if (idl_gpio_set_line(g_lrid_info.gpio, gpio_on) != IDL_SUCCESS)
        {
            GDL_ERROR("Failed to toggle line %d to %s\n",
                      g_lrid_info.gpio, (gpio_on == GDL_TRUE) ? "on" : "off");
        }
        
    }
       
    return 0;
}



//----------------------------------------------------------------------------
// mm_lrid_trigger
//
// Function that triggers gpio toggling by waking up __gpio_thread_fn thread
//
// NOTE: This function is called from interrupt context!
//----------------------------------------------------------------------------
gdl_ret_t mm_lrid_trigger(void)
{
    wake_up(&mm_gpio_wait_queue);
    return GDL_SUCCESS;
}


//----------------------------------------------------------------------------
// mm_lrid_enable
//
// Enables LRID toggling service. Creates new prioritized thread that toggles
// between LEFT and RIGHT IDs; Toggling is implemented via GPIO signaling
//----------------------------------------------------------------------------
gdl_ret_t mm_lrid_enable(mm_sw_lrid_info_t * lrid_info)
{
    gdl_ret_t rc = GDL_SUCCESS;
    static gdl_boolean_t first_time = GDL_TRUE;

    // On the first enable 
    if (first_time == GDL_TRUE)
    {
        // Initialize service for lrid gpio toggling for frame sequential modes
        rc = mm_lrid_init(lrid_info);
        if (rc != GDL_SUCCESS)
        {
            GDL_ERROR("LRID service failed to initialize\n");
            goto end;
        }

        first_time = GDL_FALSE;
    }

    if (g_lrid_info.gpio == GPIO_UNASSIGNED)
    {
        GDL_ERROR("Cannot enable GPIO toggling\n");
        rc = GDL_ERR_FAILED;
        goto end;
    }

    exit_gpio_thread = GDL_FALSE;
    g_lrid_polarity  = GDL_POLARITY_FRAME;

    if (OSAL_SUCCESS != create_prioritized_thread(&gpio_thread,
                                                  __gpio_thread_fn,
                                                  0,
                                                  0,
                                                  "DisplayLRID"))
    {
        GDL_ERROR("Failed to create DisplayLRID thread\n");
        rc = GDL_ERR_FAILED;
        goto end;
    }


end:
    return rc;
}

//----------------------------------------------------------------------------
// mm_lrid_get_polarity
//
// Returns current polarity
//----------------------------------------------------------------------------
gdl_polarity_t mm_lrid_get_polarity(void)
{
    return g_lrid_polarity;
}


//----------------------------------------------------------------------------
// mm_lrid_disable
//
// Disables LRID toggling service.
//----------------------------------------------------------------------------
gdl_ret_t mm_lrid_disable(void)
{
    g_lrid_polarity  = GDL_POLARITY_FRAME;

    // Only kill the thread and wait for it, if it is currently running
    if (exit_gpio_thread == GDL_FALSE)
    {
        // Setting exit_gpio_thread to GDL_TRUE will force thread to exit
        // once it wakes up    
        exit_gpio_thread = GDL_TRUE;
        wake_up(&mm_gpio_wait_queue);

        // Blocks until thread is destroyed
        os_thread_wait(&gpio_thread, 1);
        os_thread_destroy(&gpio_thread);
    }

    return GDL_SUCCESS;
}



//----------------------------------------------------------------------------
// mm_lrid_init
//
// Initializes LRID toggling service (used for frame sequential video modes)
// but does not enable it.
//
// Initialization consists of reading GPIO number from the configuration file
// and configuring gpio line.
//----------------------------------------------------------------------------
gdl_ret_t mm_lrid_init(mm_sw_lrid_info_t * lrid_info)
{
    gdl_ret_t rc = GDL_SUCCESS;
    idl_result_t idl_rc;

    
    idl_rc = idl_gpio_init();

    // GPIO unit might be already initialized by someone else in which case
    // IDL_ALREADY_INITIALIZED error will be returned. In such case we don't treat
    // it as an error
    if ((idl_rc != IDL_SUCCESS)
    &&  (idl_rc != IDL_ALREADY_INITIALIZED))
    {
        GDL_ERROR("Failed at idl_gpio_init(); rc=0x%x\n", idl_rc);
        g_lrid_info.gpio = GPIO_UNASSIGNED;
        rc = GDL_ERR_FAILED;
        goto end;
    }
    

    // Configure gpio line to be an 'output gpio'
    if (idl_gpio_line_config(lrid_info->gpio, IDL_GPIO_OUTPUT) != IDL_SUCCESS)
    {
        GDL_ERROR("Failed to configure gpio line %d\n", lrid_info->gpio);
        g_lrid_info.gpio = GPIO_UNASSIGNED;
        rc = GDL_ERR_FAILED;
        goto end;
    }

    g_lrid_info = *lrid_info;
    
end:
    return rc;
}
