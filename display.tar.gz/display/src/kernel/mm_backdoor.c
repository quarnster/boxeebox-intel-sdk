//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//---------------------------------------------------------------------------

//----------------------------------------------------------------------------
// File Description: Daemon backdoor job access interface.
//    
// This functionality has evolved over time and the term "backdoor" is somewhat
// dated. Essentially, a "backdoor job" is a task or notification, queued for
// retrieval/processing by the user-space daemon, that did *not* originate from
// an application via the GDL API.  There are currently 3 kinds of backdoor
// jobs:
// 
// - VBD jobs originate with the SMD vidrend component and come to us through
//   the kernel level VBD API.
// - ABD jobs originate with the audio driver, and come to us through the
//   kernel level ABD API.
// - Internal jobs originate within the kernel module itself.
// 
// All of these types of jobs go on the vbd_job_queue, so all have equal
// priority and will be processed by the daemon in the order they are queued.
// 
// WITH ONE EXCEPTION:
// The internal job (see internal_job_t) subtype INTERN_JOB_IRQ is used to queue
// notifications of interrupts.  It has its own queue (irq_job_queue) so that
// the daemon can use a higher priority thread to retrieve these notifications
// (and they will be processed before other internal jobs).
//----------------------------------------------------------------------------

#include "common.h"
#include "mm_common.h"
#include "vbd_int.h"
#include "gdl_pd.h"

//----------------------------------------------------------------------------
// Backdoor job queues
//----------------------------------------------------------------------------
#define MM_BACKDOOR_JOB_QUEUE_SIZE  100

typedef struct
{
    spinlock_t          lock;

    wait_queue_head_t   waitqueue;
    wait_queue_head_t   caller_waitqueue;

    //------------------------------------------------------------------------
    // Array of jobs used for circular job list. Array cannot be dynamic due
    // jobs being added at interrupt time, where some memory allocations are
    // not allowed.
    //------------------------------------------------------------------------
    int                 last;    // Offset of last job added
    int                 first;   // Offset of urrent job
    backdoor_job_t      jobs[MM_BACKDOOR_JOB_QUEUE_SIZE];
} backdoor_job_queue_t;

static backdoor_job_queue_t  vbd_job_queue;
static backdoor_job_queue_t  irq_job_queue;


//----------------------------------------------------------------------------
// Utility: translate a queue id to a pointer to the queue.
//----------------------------------------------------------------------------
static gdl_ret_t get_queue(backdoor_job_queue_id_t  qid,
                           backdoor_job_queue_t  ** q)
{
    gdl_ret_t rc    = GDL_SUCCESS;

    switch (qid)
    {
    case BACKDOOR_Q_VBD:
        *q = &vbd_job_queue;
        break;
    case BACKDOOR_Q_IRQ:
        *q = &irq_job_queue;
        break;
    default:
        GDL_ERROR("Invalid queue id (%d)\n", qid);
        rc = GDL_ERR_INTERNAL;
        break;
    }

    return rc;
}

//----------------------------------------------------------------------------
// mm_queue_backdoor_job
//
// Queue a new job. Function will only be invoked from kernel-space 
// so we can use memcpy.
//----------------------------------------------------------------------------
gdl_ret_t mm_queue_backdoor_job(    backdoor_job_queue_id_t qid,
                                    void *                  data,
                                    backdoor_job_type_t     job_type,
                                    gdl_boolean_t           rc_needed)
{
    gdl_ret_t               rc = GDL_SUCCESS;
    unsigned long           lock_flags;
    int                     cur = 0;
    int                     s_ret;
    unsigned int            data_size;
    backdoor_job_queue_t   *q;
    static unsigned long    last_print_time = 0;

    if (!mm_server_alive())
    {
        rc = GDL_ERR_FAILED;
        goto EXIT;
    }

    if (GDL_SUCCESS != (rc = get_queue(qid, &q)))
    {
        goto EXIT;
    }

    switch (job_type)
    {
    case JOB_TYPE_VBD:
        data_size = sizeof(vbd_data_t);
        break;
    case JOB_TYPE_ABD:
        data_size = sizeof(gdl_hdmi_audio_ctrl_t);
        break;
    case JOB_TYPE_MM:
        data_size = sizeof(internal_job_t);
        break;
    default:
        GDL_ERROR("Invalid job type (%d)\n", job_type);
        rc = GDL_ERR_INTERNAL;
        goto EXIT;
    }

    // Make sure submitted data fits into the job slot
    if (MAX_JOB_DATA_SIZE < data_size)
    {
        GDL_ERROR("Not enough space in the job slot\n");
        rc = GDL_ERR_INTERNAL;
        goto EXIT;
    }

    if (mm_server_get_status() == MM_STATUS_SUSPENDED)
    {
        GDL_ERROR("Jobs not allowed in power suspended state\n");
        rc = GDL_ERR_SUSPENDED;
        goto EXIT;
    }

    spin_lock_irqsave(&q->lock, lock_flags);

    // Make sure we have room for additional job
    if (((q->last + 1) % MM_BACKDOOR_JOB_QUEUE_SIZE) == q->first)
    {
        rc = GDL_ERR_BUSY;
    }
    else
    {
        // Copy passed 'data' into q->jobs[q->last].data,
        // increment tail ('q->last') offset.
        q->jobs[q->last].job_status = BACKDOOR_JOB_NEW;
        q->jobs[q->last].job_type   = job_type;
        q->jobs[q->last].job_id     = q->last;
        memcpy(&(q->jobs[q->last].data), data, data_size);

        // Save current index
        cur     = q->last;
        q->last = (q->last + 1) % MM_BACKDOOR_JOB_QUEUE_SIZE;
    }

    spin_unlock_irqrestore(&q->lock, lock_flags);

    // Wake up daemon / server
    wake_up(&q->waitqueue);
    
    // Bypass the rest if job was not added
    if (rc != GDL_SUCCESS)
    {
        // Print this error message no more than once a second
        if( (jiffies - last_print_time) * 1000 / HZ > 1000 )
        {
            GDL_ERROR("Job queue <%d> full.. rejecting <%d>\n", qid, job_type);
            last_print_time = jiffies;            
        }
        goto EXIT;
    }

    // If it is not a flip command or an interrupt notification,
    // wait for return code/values
    if (rc_needed)
    {
        // Prevent sleep to occur if we are in interrupt context
        if (unlikely(in_atomic()))
        {
            GDL_ERROR("Wait requested in interrupt context\n");
            rc = GDL_ERR_SCHED_IN_ATOMIC;
            goto EXIT;
        }

        //ABD jobs should wait forever, other jobs can time out
        if(job_type != JOB_TYPE_ABD)
        {
            // Put caller to sleep into mm_backdoor_caller_queue
            s_ret = wait_event_timeout(
                               q->caller_waitqueue, 
                               q->jobs[cur].job_status == BACKDOOR_JOB_COMPLETE,
                               MM_MS_TO_JIFFIES(1000));

            // Check if request timed out or some other error occured
            if (s_ret <= 0)
            {
                GDL_ERROR("Backdoor job timed out!\n");
                rc = (s_ret == 0) ? GDL_ERR_TIMEOUT : GDL_ERR_INTERNAL;
                goto EXIT;
            }
        }
        else
        {
            s_ret = 0;
            wait_event(
                q->caller_waitqueue, 
                q->jobs[cur].job_status == BACKDOOR_JOB_COMPLETE);           
        }

        // Copy data back to the caller
        memcpy(data, &q->jobs[cur].data, data_size);
        rc = q->jobs[cur].rc;
    }
EXIT:
    return rc;
}



//----------------------------------------------------------------------------
// mm_set_backdoor_job
// 
// Process acknowledgement by daemon that job is complete.
//----------------------------------------------------------------------------
gdl_ret_t mm_set_backdoor_job(backdoor_job_queue_id_t   qid,
                              backdoor_job_t *          job)
{
    int       i;
    int       job_id    = job->job_id;
    gdl_ret_t rc        = GDL_ERR_INTERNAL;
    backdoor_job_queue_t   *q;

    if (GDL_SUCCESS != (rc = get_queue(qid, &q)))
    {
        goto EXIT;
    }

    // Search for a job id that matches one we are marking
    for (i=0; i<MM_BACKDOOR_JOB_QUEUE_SIZE; i++)
    {
        if (q->jobs[i].job_id == job_id)
        {
            if (copy_from_user(&q->jobs[i], job, sizeof(backdoor_job_t)))
            {
                GDL_ERROR("copy_from_user failed\n");
                goto EXIT;
            }
            q->jobs[i].job_status = BACKDOOR_JOB_COMPLETE;
            rc = GDL_SUCCESS;

            wake_up(&q->caller_waitqueue);
            break;
        }
    }

    if (rc != GDL_SUCCESS)
    {
       GDL_ERROR("job (id=%d) not found in queue\n", job_id);
    }
EXIT:
    return rc;
}


//----------------------------------------------------------------------------
// mm_get_backdoor_job
// 
// Block calling (daemon) thread until next job is available.
//----------------------------------------------------------------------------
gdl_ret_t mm_get_backdoor_job(backdoor_job_queue_id_t   qid,
                              backdoor_job_t *          job)
{
    gdl_ret_t               rc = GDL_SUCCESS;
    backdoor_job_queue_t   *q;

    if (GDL_SUCCESS != (rc = get_queue(qid, &q)))
    {
        goto EXIT;
    }

    if (job == NULL)
    {   
        rc = GDL_ERR_NULL_ARG;
        goto EXIT;
    }

    if (unlikely(in_atomic()))
    {
        GDL_ERROR("Scheduling while atomic\n");
        rc = GDL_ERR_SCHED_IN_ATOMIC;
        goto EXIT;
    }
    
    if (wait_event_interruptible(q->waitqueue, (q->first != q->last)))
    {
        rc = GDL_ERR_INTERNAL;
        goto EXIT;
    }

    // Copy job to server
    if (copy_to_user(job, &q->jobs[q->first], sizeof(backdoor_job_t)))
    {
        GDL_ERROR("copy_to_user failed\n");
        rc = GDL_ERR_INVAL_PTR;
        goto EXIT;
    }

    q->jobs[q->first].job_status = BACKDOOR_JOB_WORKING;
    q->first = (q->first + 1) % MM_BACKDOOR_JOB_QUEUE_SIZE;

    rc = GDL_SUCCESS;
EXIT:
    return rc;
}


//----------------------------------------------------------------------------
// mm_init_backdoor_queue
//----------------------------------------------------------------------------
static void init_queue(backdoor_job_queue_t *q)
{
    memset(q, 0x0, sizeof(backdoor_job_queue_t));
    q->last = q->first = 0;
    init_waitqueue_head(&q->waitqueue);
    init_waitqueue_head(&q->caller_waitqueue);
    spin_lock_init(&q->lock);
}

//----------------------------------------------------------------------------
// mm_init_backdoor_queue
//----------------------------------------------------------------------------
gdl_ret_t mm_init_backdoor_queues(void)
{
    init_queue(&vbd_job_queue);
    init_queue(&irq_job_queue);

    return GDL_SUCCESS;
}

//----------------------------------------------------------------------------
// mm_cleanup_backdoor_queues
//----------------------------------------------------------------------------
void mm_cleanup_backdoor_queues(void)
{
}
