//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// File Description:
//    Main kernel module file. Contains handlers for ioctl/mmap calls
//----------------------------------------------------------------------------

#ifndef CONFIG_PCI
#error "Kernel PCI support is required"
#endif

#include <linux/version.h>
#include <asm/uaccess.h>
#include <linux/fs.h> // Needed by unlocked ioctl
#include <linux/pci.h>
#include <linux/moduleparam.h>
#include <linux/sched.h>
#include <linux/proc_fs.h>

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,30)
#include <linux/pid.h>
#endif

#include "platform_config.h"
#include "platform_config_paths.h"
#include "common.h"
#include "gdl_version.h"
#include "mm_common.h"
#include "abd_int.h"
#include "pci.h"


MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("Intel Corporation, (C) 2006-2011 - All Rights Reserved");

// MOD_NAME and MOD_NAME_TRACK are used to register device.
// Devices with those names will be found in /proc/devices 
#define MOD_NAME        "gdl"
#define MOD_NAME_TRACK  "gdl_track"

//VDC device structures which are referenced by other files
os_pci_dev_t pci_dev;
vdc_t        vdc_dev;

static int connections          = 0; // Number of clients connected to mm
static int major_number         = 0;
static int major_number_track   = 0;

static int gdl_mm_version = MAKE_GDL_VERSION(GDL_VERSION_MAJOR, 
                                             GDL_VERSION_MINOR, 
                                             GDL_VERSION_HOTFIX);

static mm_status_t g_server_status = MM_STATUS_DEAD;

// Semaphore to protect backdoor queue from overflowing if
// many applications init/deinit at once.
static struct semaphore mm_job_lock;

// Entries for /proc/gdl and /proc/gdl/memory
static struct proc_dir_entry * mm_proc_mem;
static struct proc_dir_entry * mm_proc_dir;

// Load-time argument that can be used to disable mmap region checks
static int strict_mmaps  = 1;

// Load-time argument to enable stricter security through uid filtering
// Enabled by default
static int uid_filtering = 0;

// Load-time argument that can be used to enforce capability checks
// Disabled by default
static int enforce_caps  = 1;

module_param(strict_mmaps, uint, 0);
module_param(uid_filtering, uint, 0);
module_param(enforce_caps, uint, 0);


int __mm_current_uid(void)
{
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,35)
    return current->uid;
#else
    return current->cred->uid;
#endif
}

//----------------------------------------------------------------------------
// Returns whether user-id filtering is enabled or not
//----------------------------------------------------------------------------
int mm_uid_filtering_enabled(void)
{
    return uid_filtering;
}

//----------------------------------------------------------------------------
// mm_capabilities_enforced
//
// Returns whether capability checks are enforced or not
//----------------------------------------------------------------------------
gdl_boolean_t mm_capabilities_enforced(void)
{
    return enforce_caps;
}

//----------------------------------------------------------------------------
// Handler for writing to a procfs file. Upon write to /proc/gdl/memory
// a job will be submitted to server to dump all memory-related data into
// a filename specified by user in 'buffer'.
//----------------------------------------------------------------------------
static int mm_write_proc_func(struct file * file, 
                              const char  * buffer, 
                              unsigned long count, 
                              void *        data)
{
    unsigned int   size_to_copy;
    internal_job_t job;
    int i;
    gdl_ret_t      rc;

    size_to_copy = count;

    if (size_to_copy > PROCFS_MEM_FILENAME_SIZE)
    {
        GDL_ERROR("Specified path exceeds %d char limit\n",
                  PROCFS_MEM_FILENAME_SIZE);
        return -1;
    }

    // If capabilities are enforced, CAP_SYS_RAWIO is required for mem dump
    // otherwise if uid_filtering is enabled, root UID is required for mem dump
    if ((mm_capabilities_enforced() && !capable(CAP_SYS_RAWIO))
    ||  (mm_uid_filtering_enabled() && (__mm_current_uid() != 0)))
    {
        GDL_ERROR("Insufficient permissions\n");
        return -EPERM;
    }

    job.cmd = INTERN_CMD_DUMP_MEMINFO;
    memset(job.data.file_name, 0x0, PROCFS_MEM_FILENAME_SIZE);

    if (copy_from_user(job.data.file_name, buffer, size_to_copy))
    {
        GDL_ERROR("failed to copy data\n");
        return -1;
    }

    down(&mm_job_lock);
    // Filename that is sent to us will most likely contain '\n' character
    // For example in cases when echo "filename" > /proc/gdl/memory is
    // used. Replace end of line chars with null
    for (i=0; i<size_to_copy; i++)
    {
        if ((job.data.file_name[i] == '\n')
        ||  (job.data.file_name[i] == '\r'))
        {
            job.data.file_name[i] = '\0';
            break;
        }
    }


    rc = mm_queue_backdoor_job(BACKDOOR_Q_VBD, &job, JOB_TYPE_MM, GDL_TRUE);
    
    up(&mm_job_lock);

    if (rc != GDL_SUCCESS)
    {
        return -1;
    }
    
    return size_to_copy;
}

//----------------------------------------------------------------------------
// Initialize proc filesystem
//----------------------------------------------------------------------------
static int mm_procfs_init(void)
{
    mm_proc_dir = 0;
    mm_proc_mem = 0;

    mm_proc_dir = proc_mkdir("gdl",0);
    if (mm_proc_dir == 0)
    {
        GDL_ERROR("/proc/gdl/ creation failed\n");
        return -1;
    }

    mm_proc_mem = create_proc_entry("memory",
                                    S_IFREG|S_IRWXU|S_IRWXG|S_IRWXO,
                                    mm_proc_dir);

    if (mm_proc_mem == 0)
    {
        GDL_ERROR("/proc/gdl/memory creation failed\n");
        remove_proc_entry("gdl", 0);
        mm_proc_dir = 0;
        return -1;
    }

    mm_proc_mem->read_proc  = 0;
    mm_proc_mem->write_proc = mm_write_proc_func;
    mm_proc_mem->data       = 0;

    return 0;
}


//----------------------------------------------------------------------------
// De-initialize proc filesystem
//----------------------------------------------------------------------------
static int mm_procfs_deinit(void)
{
    if (mm_proc_dir != 0)
    {
        if (mm_proc_mem != 0)
        {
            remove_proc_entry("memory", mm_proc_dir);
            mm_proc_mem = 0;
        }

        remove_proc_entry("gdl", 0);
        mm_proc_dir = 0;
    }

    return 0;
}

//----------------------------------------------------------------------------
// Register read/write functions which are accessible from vdc_dev structure
//----------------------------------------------------------------------------
unsigned int mm_reg_read(void      *handle, 
                         gdl_uint32 base, 
                         gdl_uint32 reg)
{
    return *((volatile unsigned int*)(base+reg));
}


void mm_reg_write(void      *handle, 
                  gdl_uint32 base, 
                  gdl_uint32 reg, 
                  gdl_uint32 value)
{
    *((volatile unsigned int *)(base + reg)) = value;
}

//----------------------------------------------------------------------------
// mm_server_set_status
//
// Sets status of the server
//----------------------------------------------------------------------------
static gdl_ret_t mm_server_set_status(mm_status_t status)
{
    g_server_status = status;

    // Server no longer processes jobs, hence mark all jobs in the queue as 
    // completed and wake up all waiting processes
    if (status == MM_STATUS_DEAD)
    {
        mm_abort_all_jobs();
    }

    return GDL_SUCCESS;
}

//----------------------------------------------------------------------------
// mm_server_get_status
//
// Gets status of the server
//----------------------------------------------------------------------------
mm_status_t mm_server_get_status(void)
{
    return g_server_status;
}


//----------------------------------------------------------------------------
// mm_server_alive
//
// Returns 1 if server is alive, 0 otherwise.
//----------------------------------------------------------------------------
int mm_server_alive(void)
{
    return !(g_server_status == MM_STATUS_DEAD);
}

//----------------------------------------------------------------------------
// mm_is_pid_alive
//
// Checks whether process with id 'pid_state->pid' is alive or not
//----------------------------------------------------------------------------
static void mm_is_pid_alive(mm_pid_state_t * pid_state)
{
    struct task_struct * task;

    pid_state->alive = GDL_FALSE;
#if LINUX_VERSION_CODE < KERNEL_VERSION(2,6,28)
    task = find_task_by_pid(pid_state->pid);
#elif LINUX_VERSION_CODE < KERNEL_VERSION(2,6,31)
    task = find_task_by_vpid(pid_state->pid);
#else
    task = pid_task(find_get_pid(pid_state->pid), PIDTYPE_PID);
#endif
    
    if (task && (task->state != TASK_DEAD))
    {
        pid_state->alive = GDL_TRUE;
    }
}

// Structure for describing memory region that can be mmap()-ed
typedef struct mm_allowed_mem_t 
{
    unsigned int addr; // base physical address
    unsigned int size; // region size in bytes
} mm_allowed_mem_t;

static mm_allowed_mem_t allowed_mmaps[2];
static int allowed_mmaps_nr;

#define DISP_MEM_NODE CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".display."
#define SMD_MEM_NODE  CONFIG_PATH_PLATFORM_MEMORY_LAYOUT ".smd_frame_buffers."

//----------------------------------------------------------------------------
// __fill_allowed_mmap_regions
//
// Fills a list of allowed memory regions that can be mapped by the  callers 
// of this modules mmap() handler.
//----------------------------------------------------------------------------
static void __fill_allowed_mmap_regions(void)
{
    unsigned int base, size;

    if (config_get_int(0, DISP_MEM_NODE "base", &base) == CONFIG_SUCCESS &&
        config_get_int(0, DISP_MEM_NODE "size", &size) == CONFIG_SUCCESS) {
        allowed_mmaps[allowed_mmaps_nr].addr = base;
        allowed_mmaps[allowed_mmaps_nr++].size = size;
    }

    if (config_get_int(0, SMD_MEM_NODE "base", &base) == CONFIG_SUCCESS &&
        config_get_int(0, SMD_MEM_NODE "size", &size) == CONFIG_SUCCESS) {
        allowed_mmaps[allowed_mmaps_nr].addr = base;
        allowed_mmaps[allowed_mmaps_nr++].size = size;
    }
}

//----------------------------------------------------------------------------
// mm_mem_region_allowed
//
// Checks whether passed region (described by addr and size) can be used
// for surface-related operations
//
// This function will perform an actual check only if module was loaded 
// with "strict_mmaps=1" argument (default).
//----------------------------------------------------------------------------
static int mm_mem_region_allowed(unsigned int addr, unsigned int size)
{
    int                i;
    unsigned int       mmap_allowed;
    mm_allowed_mem_t * region;

    if (strict_mmaps == 0)
    {
        mmap_allowed = 1;
    }
    else
    {
        mmap_allowed = 0;

        // Go through all 'allowed' mmap regions and check whether current
        // request falls into any of those regions
        for (i=0; i < allowed_mmaps_nr; i++)
        {
            region = &allowed_mmaps[i];
            if ((addr        >= region->addr)
            &&  (addr + size <= region->addr + region->size))
            {
                mmap_allowed = 1;
                break;
            }
        }    
    }
    
    return mmap_allowed;
}


//----------------------------------------------------------------------------
// fop_open_track
//
// Tracks number of clients connected to minimal module and sends server
// notification about process opening /dev/gdl/track file
//----------------------------------------------------------------------------
int fop_open_track(struct inode * _inode, struct file * _file)
{
    internal_job_t job;

    // Semaphore protects backdoor queue from having too many jobs at once
    // Wait for job to finish before submitting next one.
    down(&mm_job_lock);
    job.cmd = INTERN_CMD_CLIENT_INIT;
    job.data.pid = current->tgid;
    
    mm_queue_backdoor_job(BACKDOOR_Q_VBD, &job, JOB_TYPE_MM, GDL_TRUE);
    connections++;
    up(&mm_job_lock);
    return 0;
}

//----------------------------------------------------------------------------
// fop_release_track
//
// Tracks number of clients connected to minimal module and sends server
// notification about process closing /dev/gdl/track file 
//----------------------------------------------------------------------------
int fop_release_track(struct inode * _inode, struct file * _file)
{
    internal_job_t job;
    
    // Wait for job on server to finish before submitting new one.
    down(&mm_job_lock);
    job.cmd      = INTERN_CMD_CLIENT_DEINIT;
    job.data.pid = current->tgid;

    mm_queue_backdoor_job(BACKDOOR_Q_VBD, &job, JOB_TYPE_MM, GDL_TRUE);     
    connections--;
    up(&mm_job_lock);
    return 0;
}


//----------------------------------------------------------------------------
// ioctl handler
//----------------------------------------------------------------------------
int fop_ioctl( struct inode*  inode,
               struct file*   filep,
               unsigned int   packed_cmd,
               unsigned long  arg )
{
    gdl_ret_t             ret = GDL_SUCCESS;
    int                   polarity;
    vdc_interrupt_event_t event;
    irq_registration_t    irq_reg;
    mm_woe_t              *woe_data;
    mm_pid_state_t        pid_state;
    mm_safe_reg_write_t   reg_write;
    mm_chk_mem_region_t   mem_region;
    unsigned int          woe_id;
    unsigned int          cmd;
    gdl_display_id_t      disp_id;
    mm_sw_lrid_info_t     lrid_info;

    cmd = _IOC_NR(packed_cmd);

    if ((mm_capabilities_enforced() && !capable(CAP_SYS_RAWIO))
    ||  (mm_uid_filtering_enabled() && (__mm_current_uid() != 0)))
    {
        switch (cmd)
        {
        // List of ioctls that does not require "elevated" privileges
        case KERN_TRANS_SET:
        case KERN_GET_POLARITY_PIPE_A:
        case KERN_GET_POLARITY_PIPE_B:
        case KERN_GET_VERSION:
        case KERN_WAIT_FOR_EVENT:
            break;
        default:
            GDL_ERROR("Insufficient privileges to execute ioctl\n");
            return -EPERM;
            break;
        }
    }


    switch (cmd)
    {
    case KERN_TRANS_GET:
    case KERN_TRANS_SET:
        ret = mm_handle_job(cmd, (gdl_trans_data_t*)arg);
        break;

    case KERN_WAIT_FOR_EVENT:
        if (copy_from_user(&event,
                           (vdc_interrupt_event_t*)arg,
                           sizeof(vdc_interrupt_event_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_WAIT_FOR_EVENT: Copy from user failed\n");
            break;
        }

        ret = mm_wait_for_event(event, MM_INTERRUPT_TIMEOUT);
        break;

    case KERN_GET_POLARITY_PIPE_A:
        polarity = mm_get_polarity_pipe_a();
        ret = copy_to_user((int*)arg, &polarity, sizeof(int));
        break;

    case KERN_GET_POLARITY_PIPE_B:
        polarity = mm_get_polarity_pipe_b();
        ret = copy_to_user((int*)arg, &polarity, sizeof(int));
        break;

    case KERN_ENABLE_INTERRUPTS:
        mm_init_interrupts();
        mm_woe_enable();
        break;

    case KERN_DISABLE_INTERRUPTS:
        mm_cleanup_interrupts();
        mm_woe_disable();
        break;

    case KERN_GET_BACKDOOR_JOB:
        ret = mm_get_backdoor_job(BACKDOOR_Q_VBD, (backdoor_job_t*)arg);
        break;

    case KERN_SET_BACKDOOR_JOB:
        ret = mm_set_backdoor_job(BACKDOOR_Q_VBD, (backdoor_job_t*)arg);
        break;

    case KERN_GET_IRQ:
        ret = mm_get_backdoor_job(BACKDOOR_Q_IRQ, (backdoor_job_t*)arg);
        break;

    case KERN_GET_CONNECTIONS:
        ret = copy_to_user((int*)arg, &connections, sizeof(int));
        break;

    case KERN_SERVER_SET_STATUS:
        ret = mm_server_set_status((int)arg);
        break;

    case KERN_GET_VERSION:
        if (copy_to_user((int*)arg, &gdl_mm_version, sizeof(int)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_GET_VERSION: copy to user failed\n");
        }
        break;

    case KERN_REGISTER_IRQ:
        if (copy_from_user(&irq_reg, 
                           (irq_registration_t*)arg, 
                           sizeof(irq_registration_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_REGISTER_IRQ: copy from user failed\n");
            break;
        }

        ret = mm_register_irq_client(&irq_reg);
        break;

    case KERN_UNREGISTER_IRQ:
        if (copy_from_user(&irq_reg, 
                           (irq_registration_t*)arg, 
                           sizeof(irq_registration_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_UNREGISTER_IRQ: copy from user failed\n");
            break;
        }

        ret = mm_unregister_irq_client(&irq_reg);
        break;

    case KERN_HDMI_DMA_READ:
    case KERN_HDMI_DMA_UNDERRUN:
    case KERN_HDMI_DMA_CLEAN_UP:
    case KERN_HDMI_DMA_REJECT:
    case KERN_HDMI_DMA_STOP:
        mm_abd_event((unsigned int)arg, cmd);
        ret = GDL_SUCCESS;
        break;

    case KERN_WOE_ADD:
        woe_data = kmalloc(sizeof(*woe_data), GFP_KERNEL);
        if (unlikely(!woe_data)) {
            GDL_ERROR("KERN_WOE_ADD: no memory\n");
            ret = GDL_ERR_NO_MEMORY;
            break;
        }

        if (copy_from_user(woe_data,
                           (mm_woe_t*)arg,
                           sizeof(mm_woe_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_WOE_ADD: copy from user failed\n");
            kfree(woe_data);
            break;
        }
 
        ret = mm_woe_add(woe_data, &woe_id);
        if (ret == GDL_SUCCESS)
        {
            woe_data->id = woe_id;
        }
 
        if (copy_to_user((mm_woe_t*)arg, woe_data, sizeof(mm_woe_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_WOE_ADD: Copy to user failed\n");
        }
        kfree(woe_data);
        break;

    case KERN_WOE_DELETE:
        if (copy_from_user(&woe_id, (unsigned int*)arg, sizeof(int)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_WOE_DELETE: copy from user failed\n");
            break;
        }
        ret = mm_woe_delete(woe_id);
        break;

    case KERN_FRAMESTART_PROCESSED:
        if (copy_from_user(&disp_id,
                           (gdl_display_id_t*)arg,
                           sizeof(gdl_display_id_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_FRAMESTART_PROCESSED: copy from user failed\n");
            break;
        }

        mm_framestart_processed(disp_id);
        break;

    case KERN_WAIT_FOR_VBI_PROCESSING:
        if (copy_from_user(&disp_id, 
                           (gdl_display_id_t*)arg,
                           sizeof(gdl_display_id_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_WAIT_FOR_VBI_PROCESSING: copy from user failed\n");
            break;
        }        

        // Block process until server has processed framestart
        mm_wait_for_vbi_processing(disp_id);
        break;

    case KERN_PID_ALIVE:
        if (copy_from_user(&pid_state,
                           (mm_pid_state_t*)arg,
                           sizeof(mm_pid_state_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_PID_ALIVE: copy from user failed\n");
            break;
        }

        mm_is_pid_alive(&pid_state);

        if (copy_to_user((mm_pid_state_t*)arg,
                         &pid_state,
                         sizeof(mm_pid_state_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_PID_ALIVE: copy to user failed\n");
            break;
        }
        break;

    case KERN_FLUSH_CACHE:
        // Invalidate all cache
        wbinvd();
        break;

    case KERN_SAFE_REG_WRITE:
        if (copy_from_user(&reg_write,
                           (mm_safe_reg_write_t*)arg,
                           sizeof(mm_safe_reg_write_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_SAFE_REG_WRITE: copy from user failed\n");
            break;
        }

        mm_safe_reg_write(&reg_write);
   
        break;

    case KERN_ENABLE_SW_LRID_TOGGLE:
        if (copy_from_user(&lrid_info,
                           (mm_sw_lrid_info_t*)arg,
                           sizeof(mm_sw_lrid_info_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_ENABLE_SW_LRID_TOGGLE: copy from user failed\n");
        }

        ret = mm_lrid_enable(&lrid_info);
        break;

    case KERN_DISABLE_SW_LRID_TOGGLE:
        ret = mm_lrid_disable();
        break;

    case KERN_CHECK_MEM_REGION:
        if (copy_from_user(&mem_region,
                           (mm_chk_mem_region_t*)arg,
                           sizeof(mm_chk_mem_region_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_CHECK_MEM_REGION: copy from user failed\n");
            break;
        }
                  
        mem_region.allowed = GDL_FALSE;
        if (mm_mem_region_allowed(mem_region.addr, mem_region.size))
        {
            mem_region.allowed = GDL_TRUE;
        }
         
        if (copy_to_user((mm_chk_mem_region_t*)arg,
                         &mem_region,
                         sizeof(mm_chk_mem_region_t)))
        {
            ret = GDL_ERR_INVAL_PTR;
            GDL_ERROR("KERN_CHECK_MEM_REGION: copy to user failed\n");
            break;
        }
        break;

    default:
        GDL_ERROR("Unhandled ioctl: %d\n",cmd);
        ret = GDL_ERR_INVAL_IOCTL;
        break;
    }

    return ret;
}

//------------------------------------------------------------------------------
// Unlocked ioctl handler => ioctl that does not use big kernel lock
//------------------------------------------------------------------------------
long fop_unlocked_ioctl(struct file  * filep,
                        unsigned int   cmd,
                        unsigned long  arg)
{
    return fop_ioctl(filep->f_dentry->d_inode, filep, cmd, arg);
}


//----------------------------------------------------------------------------
// fop_mmap
//
// Provides memory map service for /dev/gdl/0 node
//----------------------------------------------------------------------------
static int fop_mmap(struct file *f, struct vm_area_struct *vma)
{
    unsigned int addr;
    unsigned int size;

    addr = vma->vm_pgoff << PAGE_SHIFT;
    size = vma->vm_end - vma->vm_start;

    if (!mm_mem_region_allowed(addr, size))
    {
        GDL_ERROR("Mapping of [addr=0x%x, size=%d] not allowed\n",
                  addr, size);
        return -EPERM;
    }

    vma->vm_flags |= VM_LOCKED;

    if (f->f_flags & O_SYNC)
    {
        vma->vm_page_prot  = pgprot_noncached(vma->vm_page_prot);
    }

    if (remap_pfn_range(vma,
                        vma->vm_start,
                        vma->vm_pgoff,
                        vma->vm_end - vma->vm_start,
                        vma->vm_page_prot))
     {
        return -EAGAIN;
     }
    
    return 0;
}

//----------------------------------------------------------------------------
// Standard linux file operations
//----------------------------------------------------------------------------
static struct file_operations fops =
{
    owner:          THIS_MODULE,

    #ifdef HAVE_UNLOCKED_IOCTL
    unlocked_ioctl: fop_unlocked_ioctl,
    #else
    ioctl:          fop_ioctl,
    #endif
    
    mmap:           fop_mmap,
};

static struct file_operations fops_tracking =
{
    owner:      THIS_MODULE,
    open:       fop_open_track,
    release:    fop_release_track,
};


//----------------------------------------------------------------------------
// mm_cleanup
//
// Module cleanup
//----------------------------------------------------------------------------
static void mm_cleanup(void)
{
    unregister_chrdev(major_number,MOD_NAME);
    unregister_chrdev(major_number_track,MOD_NAME_TRACK);


    mm_cleanup_irq_clients();
    mm_cleanup_interrupts();
    mm_cleanup_job_queue();
    mm_cleanup_backdoor_queues();
    mm_woe_deinit();
    mm_procfs_deinit();
   
    if (vdc_dev.io_address != 0)
    {
        OS_UNMAP_IO_FROM_MEM((void*)vdc_dev.io_address, VDC_PCI_LENGTH); 
    }

    OS_PCI_FREE_DEVICE(pci_dev);
}


//----------------------------------------------------------------------------
// mm_init
//
// Module initialization
//----------------------------------------------------------------------------
static int __init mm_init(void) 
{
    int           ret = 0;
    unsigned int  phys_addr;
    unsigned char rev;

#ifndef HAVE_UNLOCKED_IOCTL
    GDL_PRINT("warning: unlocked ioctl unavailable\n");
#endif

    // Check load-time arguments
    if ((strict_mmaps != 0) 
    &&  (strict_mmaps != 1))
    {
        GDL_ERROR("strict_mmaps argument must be set to either 0 or 1\n");
        ret = -ENODEV;
        goto EXIT;
    }

    if ((uid_filtering != 0)
    &&  (uid_filtering != 1))
    {
        GDL_ERROR("uid_filtering argument must be set to either 0 or 1\n");
        ret = -ENODEV;
        goto EXIT;
    }

    if ((enforce_caps != 0)
    &&  (enforce_caps != 1))
    {
        GDL_ERROR("enforce_caps argument must be set to either 0 or 1\n");
        ret = -ENODEV;
        goto EXIT;
    }


    // Cap enforcement and uid filtering cannot be enabled at the same time
    if ((uid_filtering == 1)
    &&  (enforce_caps  == 1))
    {
        GDL_ERROR("uid_filtering and enforce_caps cannot be both enabled\n");
        ret = -ENODEV;
        goto EXIT;
    }

    major_number = register_chrdev(0, MOD_NAME, &fops);
    major_number_track = register_chrdev(0, MOD_NAME_TRACK, &fops_tracking);

    if (major_number < 0 || major_number_track < 0) 
    {
        GDL_ERROR("Unable to register either %s or %s device\n",
                   MOD_NAME, MOD_NAME_TRACK);
        ret = -ENODEV;
        goto EXIT;
    }
    
    sema_init(&mm_job_lock,1);

    // Generate list of allowed memory regions that can be mmap()-ed
    __fill_allowed_mmap_regions();
    if (!allowed_mmaps_nr)
        printk(KERN_WARNING "gdl_mm: no mmap regions\n");

    //Get access to device registers
    OS_PCI_FIND_FIRST_DEVICE( PCI_VENDOR_INTEL, PCI_DEVICE_VDC, &pci_dev );
    OS_PCI_READ_CONFIG_32(pci_dev,(4*PCI_RESOURCE_REGISTERS)+16,&phys_addr);

    vdc_dev.uhandle    = 0;
    vdc_dev.io_read    = mm_reg_read;
    vdc_dev.io_write   = mm_reg_write;
    vdc_dev.log_entry  = 0;
    vdc_dev.log_exit   = 0;
    vdc_dev.io_address =(gdl_uint32)
                        OS_MAP_IO_TO_MEM_NOCACHE(phys_addr, PCI_LENGTH_VDC);
    OS_PCI_READ_CONFIG_8(pci_dev, 8, &rev);

    vdc_dev.revision = rev;

    if (vdc_dev.io_address == 0)
    {
        GDL_ERROR("VDC register mapping failed\n");
        ret = GDL_ERR_MMAP;
        goto EXIT;
    }

    mm_init_job_queue();
    mm_init_backdoor_queues();

    //Must init woe before interrupts so that the queue is initialized
    mm_woe_init();

    if (mm_init_interrupts() != GDL_SUCCESS)
    {
        GDL_ERROR("Interrupt initialization failed\n");
        ret = -1;
        goto CLEANUP;
    }

    // Initialize irq registration service
    mm_init_irq_clients();

    if (mm_procfs_init() != 0)
    {
        GDL_ERROR("Failed to create /proc/gdl/ entries\n");
        ret = -ENODEV;
        goto CLEANUP;
    }

CLEANUP:
    if (ret < 0)
    {
        mm_cleanup();
    }
EXIT:
    return ret;
}

//----------------------------------------------------------------------------
// Register module init and exit functions
//----------------------------------------------------------------------------
module_init(mm_init);
module_exit(mm_cleanup);
