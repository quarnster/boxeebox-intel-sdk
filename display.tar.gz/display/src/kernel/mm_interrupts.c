//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   - Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// File Description:
//    Interrupt-related functionality
//----------------------------------------------------------------------------

#include <linux/version.h>
#include <asm/siginfo.h>

#include "osal.h"

#include "common.h"
#include "mm_common.h"
#include "pci.h"
#include "vdc_hal_interrupts.h"
#include "vbd_int.h"

//VDC device structures
extern os_pci_dev_t pci_dev;
extern vdc_t        vdc_dev;

extern vbd_callback_args_t vbd_callback_args;

extern vbd_disp_callback_args_t vbd_disp_callback_args[2];

static unsigned long    irq_dev = 0;
static unsigned         vdc_irq = 0;
static gdl_boolean_t    irq_requested = GDL_FALSE;

static gdl_polarity_t   polarity_pipe_a = 0;
static gdl_polarity_t   polarity_pipe_b = 0;

#define MM_VDC_NAME "Intel Media Processor display driver"

//----------------------------------------------------------------------------
// Array of clients registered for different irqs
//----------------------------------------------------------------------------
#define NUM_IRQ_CLIENTS 10
#define MAGIC_IRQ_NUMBER 5555
#define FREE_IRQ -1
static irq_registration_t irq_clients[NUM_IRQ_CLIENTS+1];

//----------------------------------------------------------------------------
// Macro to traverse list of all clinets
//----------------------------------------------------------------------------
#define FOR_EACH_CLIENT(list, cli)                              \
    for(cli = list; cli->irq_number != MAGIC_IRQ_NUMBER; cli++)

//----------------------------------------------------------------------------
// Macro to traverse list of clinets on specified IRQ
//----------------------------------------------------------------------------
#define FOR_EACH_CLIENT_ON_IRQ(list, cli, irq)                  \
    for(cli = list; cli->irq_number != MAGIC_IRQ_NUMBER; cli++) \
        if (cli->irq_number == irq)

//----------------------------------------------------------------------------
// WAIT QUEUES FOR VBLANK, VSYNC AND FRAMESTART INTERRUPTS
//----------------------------------------------------------------------------
DECLARE_WAIT_QUEUE_HEAD(q_pipe_a_vsync);
DECLARE_WAIT_QUEUE_HEAD(q_pipe_a_vblank);
DECLARE_WAIT_QUEUE_HEAD(q_pipe_a_framestart);

DECLARE_WAIT_QUEUE_HEAD(q_pipe_b_vsync);
DECLARE_WAIT_QUEUE_HEAD(q_pipe_b_vblank);
DECLARE_WAIT_QUEUE_HEAD(q_pipe_b_framestart);

DECLARE_WAIT_QUEUE_HEAD(q_wbp_framedone);

//------------------------------------------------------------------------------
// INTERUPT EVENTS THAT CAN BE WAITED FOR
//------------------------------------------------------------------------------
typedef struct
{
    vdc_interrupt_event_t event;      // Interrupt event
    mm_signal_t           signal;     // Signal sent to server on event [if any]
    void *                wait_queue; // Wait queue released on event
    unsigned long long    num_events; // Number of events that occured since 
                                      // interrupts got enabled
} mm_wait_event_t;

static mm_wait_event_t wait_events[] =
{
    {VDC_EVENT_VBLANK_PIPE_A,    MM_SIG_NONE,             &q_pipe_a_vblank    ,0},
    {VDC_EVENT_VSYNC_PIPE_A,     MM_SIG_NONE,             &q_pipe_a_vsync     ,0},
    {VDC_EVENT_FRAMESTART_PIPE_A,MM_SIG_FRAMESTART_PIPE_A,&q_pipe_a_framestart,0},
    {VDC_EVENT_VBLANK_PIPE_B,    MM_SIG_NONE,             &q_pipe_b_vblank    ,0},
    {VDC_EVENT_VSYNC_PIPE_B,     MM_SIG_NONE,             &q_pipe_b_vsync     ,0},
    {VDC_EVENT_FRAMESTART_PIPE_B,MM_SIG_FRAMESTART_PIPE_B,&q_pipe_b_framestart,0},
    {VDC_EVENT_WBP_FRAMEDONE,    MM_SIG_NONE,             &q_wbp_framedone    ,0},
    {0,                          MM_SIG_NONE,             NULL }  // EOL
};


//----------------------------------------------------------------------------
//                          VBI PROCESSING
//----------------------------------------------------------------------------

// Queue of clients waiting for VBI processing to be complete
DECLARE_WAIT_QUEUE_HEAD(q_vbi_processed);

// GDL_FALSE => Last framestart on PIPE_A not yet processed by server
static gdl_boolean_t    vbi_processed_pipe_a = GDL_FALSE;

// GDL_FALSE => Last framestart on PIPE_B not yet processed by server
static gdl_boolean_t    vbi_processed_pipe_b = GDL_FALSE;

// Time stamp of the last Pipe A Framestart
static struct timeval   pipeA_framestart_last;

// Time stamp of the last Pipe B Framestart
static struct timeval   pipeB_framestart_last;

// Time delta between successive Pipe A Framestarts
static int              pipeA_framestart_timediff;

// Time delta between successive Pipe B Framestarts
static int              pipeB_framestart_timediff;

//----------------------------------------------------------------------------
// mm_wait_for_event
//----------------------------------------------------------------------------
gdl_ret_t mm_wait_for_event(vdc_interrupt_event_t event, int timeout)
{
    gdl_ret_t           ret         = GDL_SUCCESS;
    int                 jf_timeout  = MM_MS_TO_JIFFIES(timeout);
    mm_wait_event_t *   p;
    unsigned long long  cur_num_events;

    if (unlikely(in_atomic()))
    {
        GDL_ERROR("Scheduling while atomic\n");
        ret = GDL_ERR_SCHED_IN_ATOMIC;
        goto EXIT;
    }

    for (p = wait_events; 1; p++)
    {
        if (p->wait_queue == NULL)
        {
            ret = GDL_ERR_INTERNAL;
            GDL_ERROR("No wait support for interrupt %d\n", event);
            goto EXIT;
        }

        if (event == p->event)
        {
            cur_num_events = p->num_events;

            interruptible_sleep_on_timeout(p->wait_queue, jf_timeout);

            // If number of events didnt change during us being asleep
            // then it means that hardware didnt generate an event
            if (cur_num_events == p->num_events)
            {
                ret = GDL_ERR_TIMEOUT;
                goto EXIT;
            }
            break;
        }
    }

EXIT:
    return ret;
}


//----------------------------------------------------------------------------
// mm_safe_reg_write
//
// Implementation of KERN_SAFE_REG_WRITE service.
//
// This function attempts to provide ability for 'atomic' writes into
// multiple registers. Atomic writes here mean that all specified writes
// will occur prior to framestart interrupt.
//
// Service is needed for cases when multiple hardware registers must be
// updated prior to framestart.
//
// NOTE: This function is only used on CE4200-Astep. No need to support
// mm_safe_reg_write for both PIPE_A and PIPE_B; pipe_a support is sufficient
//----------------------------------------------------------------------------
void mm_safe_reg_write(mm_safe_reg_write_t * data)
{
    unsigned long tmp_flags;
    unsigned int reg_val;
    int i;
    struct timeval tv;
    int timediff;
    spinlock_t lock;

    spin_lock_init(&lock);

    // If there is less than 1 ms remainign until next vblank, we want to
    // block caller until vblank passes before programming registers.
    //
    // Spinlocks are used to disable preemption/interrupts to ensure that
    // we won't get scheduled out between our check and time that we write
    // into registers.
    
    spin_lock_irqsave(&lock, tmp_flags);

    do_gettimeofday(&tv);
    
    timediff = (tv.tv_sec  - pipeA_framestart_last.tv_sec) * 1000000
             + (tv.tv_usec - pipeA_framestart_last.tv_usec);


    if (timediff > (pipeA_framestart_timediff-1000))
    {
        spin_unlock_irqrestore(&lock, tmp_flags);
        mm_wait_for_event(VDC_EVENT_FRAMESTART_PIPE_A, MM_INTERRUPT_TIMEOUT);
        spin_lock_irqsave(&lock, tmp_flags);
    }
    
    for (i=0; i<data->num_entries; i++)
    {
        reg_val = mm_reg_read(0, vdc_dev.io_address, data->reg[i]);
        reg_val = reg_val & data->keep_mask[i];
        reg_val = reg_val | (data->value[i] & ~(data->keep_mask[i]));
        mm_reg_write(0, vdc_dev.io_address, data->reg[i], reg_val);
        
    }

    spin_unlock_irqrestore(&lock, tmp_flags);  
}


//----------------------------------------------------------------------------
// mm_wait_for_vbi_processing
//
// If there is less than 1ms left before the next expected invocation of the
// Framestart interrupt handler, block the caller until the server reports it
// has processed the Framestart interrupt.
//----------------------------------------------------------------------------
void mm_wait_for_vbi_processing(gdl_display_id_t display_id)
{
    struct           timeval tv;
    int              timediff;
    struct timeval * base_framestart;
    int              base_timediff;
    int              event;

    switch (display_id)
    {
    case GDL_DISPLAY_ID_0:
        base_framestart = &pipeA_framestart_last;
        base_timediff   = pipeA_framestart_timediff;
        event           = VDC_EVENT_FRAMESTART_PIPE_A;
        break;
    case GDL_DISPLAY_ID_1:
        base_framestart = &pipeB_framestart_last; 
        base_timediff   = pipeB_framestart_timediff;
        event           = VDC_EVENT_FRAMESTART_PIPE_B;
        break;
    default:
        GDL_ERROR("Unknown display id\n");
        return;
    }
    // Step 1.
    // If expected time remaining before next Framestart < 1ms (1000 uS), then
    // wait for next Framestart.

    do_gettimeofday(&tv);
    
    timediff = (tv.tv_sec - base_framestart->tv_sec) * 1000000 +
               (tv.tv_usec - base_framestart->tv_usec);

    if (timediff > (base_timediff-1000))
    {
        mm_wait_for_event(event, MM_INTERRUPT_TIMEOUT);
    }

    // Step 2.
    // Block until server signals that Framestart has been processed.
    // NOTE: without a timeout this function will block
    // indefinitely if the pipe is shut down
    if (display_id == GDL_DISPLAY_ID_0)
    {
        wait_event_interruptible_timeout(
                                q_vbi_processed,
                                vbi_processed_pipe_a == GDL_TRUE,
                                MM_INTERRUPT_TIMEOUT);
    }
    else
    {
        wait_event_interruptible_timeout(
                                q_vbi_processed,
                                vbi_processed_pipe_b == GDL_TRUE,
                                MM_INTERRUPT_TIMEOUT);
    }
}


//----------------------------------------------------------------------------
// Record pending processing of framestart by server.
//----------------------------------------------------------------------------
static void mm_framestart_process_pending(gdl_display_id_t disp_id)
{
    switch (disp_id)
    {
    case GDL_DISPLAY_ID_0: vbi_processed_pipe_a = GDL_FALSE; break;
    case GDL_DISPLAY_ID_1: vbi_processed_pipe_b = GDL_FALSE; break;
    default: GDL_ERROR("Unknown display id %d\n", disp_id); break;
    }
}

//----------------------------------------------------------------------------
// Record server report of completion of framestart processing, conditionally
// wake everyone waiting for completion of vbi processing
//----------------------------------------------------------------------------
void mm_framestart_processed(gdl_display_id_t disp_id)
{
    switch (disp_id)
    {
    case GDL_DISPLAY_ID_0: vbi_processed_pipe_a = GDL_TRUE; break;
    case GDL_DISPLAY_ID_1: vbi_processed_pipe_b = GDL_TRUE; break;
    default: GDL_ERROR("Unknown display id %d\n", disp_id); break;
    }

    wake_up_all(&q_vbi_processed);
}

//----------------------------------------------------------------------------
// notify_server
//
// Sends gdl_server signal passed
//----------------------------------------------------------------------------
static void notify_server(mm_signal_t signal, unsigned int isr)
{
    internal_job_t  job;

    job.cmd             = INTERN_CMD_IRQ;
    job.data.irq.signal = signal;
    job.data.irq.isr    = isr;

    mm_queue_backdoor_job(BACKDOOR_Q_IRQ, &job, JOB_TYPE_MM, GDL_FALSE);
}


//----------------------------------------------------------------------------
// int_handler
//
// Interrupt handler - top half.
//----------------------------------------------------------------------------
static irqreturn_t int_handler(int irq, void *data)
{
    // Pipe interrupts occur in this order:
    //
    // - VBLANK          : once per frame/field, on rising edge of vblank signal
    // - TOP/BOTTOM FIELD: on alternate front porches (in interlaced modes only)
    // - FRAMESTART      : once per frame/field, during front porch
    // - VSYNC           : once per frame/field, on rising edge of vsync signal
    //
    // NOTE: front porch is interval between rising edge of vblank, rising edge
    // of vsync.
    //
    // Top/bottom field polarities are detected on the corresponding interrupts,
    // indicating that field in question is now on display.
    //
    // No interrupt explicitly indicates that a new frame has finished getting
    // on-screen, but if VBLANK and FRAMESTART are seen with no intervening
    // field interrupt we can assume it. We set the following variables to
    // GDL_POLARITY_FRAME at VBLANK, override them at FIELD interrupts, and
    // store them at FRAMESTART.
    static int tentative_polarity_a  = 0;
    static int tentative_polarity_b  = 0;
	//Track all events that have occurred since VBLANK for processing during
	//FRAMESTART (similar to polarity)
    static int events_since_vblank_a = 0;
    static int events_since_vblank_b = 0;

    mm_wait_event_t *   p;
    unsigned int        pending = 0;
    struct timeval      tv_now;

    //------------------
    // Retrieve mask of pending interrupts, and ack them
    //------------------
    vdc_interrupts_get(&vdc_dev, &pending);
    if (!pending)
    {
        return IRQ_HANDLED;
    }

    vdc_interrupts_ack(&vdc_dev, pending);

    events_since_vblank_a |= pending;
    events_since_vblank_b |= pending;

    //------------------
    // PIPE A INTERRUPTS
    //------------------
    if (pending & VDC_EVENT_VBLANK_PIPE_A)
    {
        // Will be overridden if a field interrupt occurs before next framestart
        // In non-frame_sequential modes GDL_POLARITY_FRAME will be returned
        // In frame-sequential modes either GDL_POLARITY_FRAME or
        // GDL_POLARITY_FRAME_RIGHT will be returned.
        tentative_polarity_a = mm_lrid_get_polarity();

        //Clear all events we have seen from the last vblank, except for
        //ones that may have come with this vblank
        events_since_vblank_a = pending;
    }

    if (pending & VDC_EVENT_TOP_FIELD_PIPE_A)
    {
        polarity_pipe_a = tentative_polarity_a = GDL_POLARITY_FIELD_TOP;
    }
    else if (pending & VDC_EVENT_BOTTOM_FIELD_PIPE_A)
    {
        polarity_pipe_a = tentative_polarity_a = GDL_POLARITY_FIELD_BOTTOM;
    }


    // Note: 6 events below can come at the same time as 
    // VDC_EVENT_TOP_FIELD_PIPE_A/VDC_EVENT_BOTTOM_FIELD_PIPE_A. We want 6
    // events below to override top/bottom field events. Events below are
    // generated for Frame packing 1 plane mode when 3d hardware assist is
    // enabled. Those events are mutually exclusive
    if (pending & VDC_EVENT_TOP_LEFT_FIELD_PIPE_A)
    {
        polarity_pipe_a = tentative_polarity_a = GDL_POLARITY_FIELD_TOP;
    }
    else if (pending & VDC_EVENT_TOP_RIGHT_FIELD_PIPE_A)
    {
        polarity_pipe_a = tentative_polarity_a = GDL_POLARITY_FIELD_RIGHT_TOP;
    }
    else if (pending & VDC_EVENT_BOTTOM_LEFT_FIELD_PIPE_A)
    {
        polarity_pipe_a = tentative_polarity_a = GDL_POLARITY_FIELD_BOTTOM;
    }
    else if (pending & VDC_EVENT_BOTTOM_RIGHT_FIELD_PIPE_A)
    {
        polarity_pipe_a = tentative_polarity_a = GDL_POLARITY_FIELD_RIGHT_BOTTOM;
    }
    else if (pending & VDC_EVENT_RIGHT_FRAME_PIPE_A)
    {
        polarity_pipe_a = tentative_polarity_a = GDL_POLARITY_FRAME_RIGHT;
    }
    else if (pending & VDC_EVENT_LEFT_FRAME_PIPE_A)
    {
        polarity_pipe_a = tentative_polarity_a = GDL_POLARITY_FRAME;
    }



    if (pending & VDC_EVENT_FRAMESTART_PIPE_A)
    {
        // PIPEACONF BIT0 must be reprogrammed with an existing value for 
        // vblank adjustment changes to take effect. This must happen during
        // a blanking period
        vdc_pipea_retrigger(&vdc_dev);

        polarity_pipe_a = tentative_polarity_a;

        //Process WOE events in a BH handler
        mm_woe_process_events(VDC_PIPE_A, events_since_vblank_a);

        // Calculate time between consecutive framestart interrupts
        // This needs to be done over and over since time between vblanks
        // can change upon change of mode
        do_gettimeofday(&tv_now);

        pipeA_framestart_timediff =
            (tv_now.tv_sec - pipeA_framestart_last.tv_sec)*1000000
            + (tv_now.tv_usec - pipeA_framestart_last.tv_usec);

        mm_framestart_process_pending(GDL_DISPLAY_ID_0);

        pipeA_framestart_last = tv_now;
    }

    if (pending & VDC_EVENT_VSYNC_PIPE_A)
    {
        // If VBD callback was registered with us, invoke it.
        if (vbd_callback_args.callback)
        {
            vbd_callback_args.callback(vbd_callback_args.cookie, polarity_pipe_a);
        }

        // If VBD callback was registered for PIPE_A, invoke it
        if (vbd_disp_callback_args[0].callback)
        {
            vbd_disp_callback_args[0].callback(
                                        vbd_disp_callback_args[0].display_id,
                                        vbd_disp_callback_args[0].cookie,
                                        polarity_pipe_a);
        }

        // Trigger frame sequential lrid-gpio toggle on every vsync.
        // In non-frame sequential modes this is a no-op pretty much
        mm_lrid_trigger();
    }

    //--------------------------------------------------------------
    // PIPE B INTERRUPTS
    //--------------------------------------------------------------
    if (pending & VDC_EVENT_VBLANK_PIPE_B)
    {
        // Will be overridden if a field interrupt occurs before next framestart
        tentative_polarity_b = GDL_POLARITY_FRAME;
        
        events_since_vblank_b = pending;
    }

    if (pending & VDC_EVENT_TOP_FIELD_PIPE_B)
    {
        polarity_pipe_b = tentative_polarity_b = GDL_POLARITY_FIELD_TOP;
    }

    if (pending & VDC_EVENT_BOTTOM_FIELD_PIPE_B)
    {
        polarity_pipe_b = tentative_polarity_b = GDL_POLARITY_FIELD_BOTTOM;
    }

    if (pending & VDC_EVENT_FRAMESTART_PIPE_B)
    {
        polarity_pipe_b = tentative_polarity_b;

        do_gettimeofday(&tv_now);

        // Calculate time between consecutive framestart interrupts
        // This needs to be done over and over since time between vblanks
        // can change upon change of mode
        pipeB_framestart_timediff =
              (tv_now.tv_sec - pipeB_framestart_last.tv_sec)*1000000
            + (tv_now.tv_usec - pipeB_framestart_last.tv_usec);

        mm_framestart_process_pending(GDL_DISPLAY_ID_1);

        pipeB_framestart_last = tv_now;

        //Process WOE events in a BH handler
        mm_woe_process_events(VDC_PIPE_B, events_since_vblank_b);

        // If VBD callback was registered for PIPE_B, invoke it
        if (vbd_disp_callback_args[1].callback)
        {
            vbd_disp_callback_args[1].callback(
                                        vbd_disp_callback_args[1].display_id,
                                        vbd_disp_callback_args[1].cookie,
                                        polarity_pipe_b);
        }
    }

    if (pending & VDC_EVENT_FIFO_UNDERFLOW)
    {
        //GDL_ERROR("VDC FIFO Underflow occurred\n");
    }

    //--------------------------------------------------------------
    // WAKE PROCESSES WAITING FOR SPECIFIC EVENTS
    //--------------------------------------------------------------
    for (p = wait_events; p->wait_queue != NULL; p++ )
    {
        if (pending & p->event)
        {
            if (p->signal != MM_SIG_NONE)
            {
                notify_server(p->signal, pending);
            }

            p->num_events++;
            wake_up_all(p->wait_queue);
        }
    }

    return IRQ_HANDLED;
}


//-----------------------------------------------------------------------------
// misc_irq_handler
//
// IRQ handler for irq numbers passed during KERN_REGISTER_IRQ service call
// TODO: Add mask to specify what portion of ISR to read
//-----------------------------------------------------------------------------
static irqreturn_t misc_irq_handler(int irq, void *data)
{
    irq_registration_t *cli;
    unsigned int        isr_value;

    // Search for irq passed and notify server with appropriate signal
    FOR_EACH_CLIENT_ON_IRQ(irq_clients, cli, irq)
    {
        isr_value = 0xFFFFFFFF;

        // Deal with ISR if appropriate
        if (cli->isr_address)
        {
            isr_value = *((volatile unsigned int*) cli->isr_address);
            *((volatile unsigned int*) cli->isr_address) = isr_value & cli->mask;
        }

        // Consider only interrupts of interest
        if (isr_value & cli->mask)
        {
            notify_server(cli->signal, isr_value & cli->mask);
        }
    }

    return IRQ_HANDLED;
}


//----------------------------------------------------------------------------
// mm_init_interrupts
//----------------------------------------------------------------------------
gdl_ret_t mm_init_interrupts()
{
    gdl_ret_t   ret = GDL_ERR_FAILED;

    // Only register for IRQ once.
    if (irq_requested == GDL_FALSE)
    {
        // Required in HyperThreading enabled environment in order for
        // pal_get_irq() and os_pci_get_interrupt() to get correct irq number
        // in both kernel and user modes.
        //
        // Does not affect non-HT environment.
        os_pci_enable_device(PCI_VENDOR_INTEL, PCI_DEVICE_VDC);
        os_pci_enable_device(PCI_VENDOR_INTEL, PCI_DEVICE_HDMI);
    
        os_pci_get_interrupt(pci_dev, &vdc_irq); 

        if (request_irq(vdc_irq,
                        int_handler,
                        IRQF_DISABLED | IRQF_SHARED,
                        MM_VDC_NAME,
                        &irq_dev))
        {
            GDL_ERROR("request_irq(%u) failed\n", vdc_irq);
            ret = GDL_ERR_FAILED;
            goto EXIT;
        }
        irq_requested = GDL_TRUE;
    }

    // Set interrupt mask.  
    // On VSYNC interrupts VBD callback is called.
    // FRAMESTART interrupt is needed to be able to notify server
    // in time about udpate of double-buffered registers
    vdc_interrupts_set(&vdc_dev,  VDC_INT_VSYNC_PIPE_A
                                | VDC_INT_VSYNC_PIPE_B
                                | VDC_INT_FRAMESTART_PIPE_A
                                | VDC_INT_FRAMESTART_PIPE_B);
    
    ret = GDL_SUCCESS;
EXIT:
    // if any error occurred - release interrupts
    if (ret != GDL_SUCCESS)
    {
        mm_cleanup_interrupts();
    }

    return ret;
}


//----------------------------------------------------------------------------
// mm_cleanup_interrupts
//----------------------------------------------------------------------------
void mm_cleanup_interrupts(void)
{
    if (irq_requested == GDL_TRUE)
    {
        // Clear mask in VDC to no longer trigger IRQ line
        vdc_interrupts_set(&vdc_dev, 0);

        free_irq(vdc_irq, &irq_dev);
        irq_requested = GDL_FALSE;
    }
}


//----------------------------------------------------------------------------
// mm_get_polarity_pipe_a
//----------------------------------------------------------------------------
gdl_polarity_t mm_get_polarity_pipe_a(void)
{
    return polarity_pipe_a;
}


//----------------------------------------------------------------------------
// mm_get_polarity_pipe_b
//----------------------------------------------------------------------------
gdl_polarity_t mm_get_polarity_pipe_b(void)
{
    return polarity_pipe_b;
}


//-----------------------------------------------------------------------------
// mm_init_irq_clients
//-----------------------------------------------------------------------------
void mm_init_irq_clients(void)
{
    int i;

    // Mark all entries as free
    for (i = 0; i < NUM_IRQ_CLIENTS; i++)
    {
        irq_clients[i].irq_number = FREE_IRQ;
    }

    // Mark last entry as final
    irq_clients[NUM_IRQ_CLIENTS].irq_number = MAGIC_IRQ_NUMBER;
}

//-----------------------------------------------------------------------------
// Unregister all IRQs on which we previously registered.
//-----------------------------------------------------------------------------
void mm_cleanup_irq_clients(void)
{
    irq_registration_t * cli;
    
    FOR_EACH_CLIENT(irq_clients, cli)
    {
        if (cli->irq_number != FREE_IRQ)
        {
            free_irq(cli->irq_number, &cli->irq_token);
            if (cli->isr_page)
            {
                OS_UNMAP_IO_FROM_MEM((void*)cli->isr_page, PAGE_SIZE);
                cli->isr_address = 0;
                cli->isr_page    = 0;
            }
            cli->irq_number = FREE_IRQ;
        }
    }
}

//-----------------------------------------------------------------------------
// Save IRQ number, associated signal and register for that IRQ with kernel
//-----------------------------------------------------------------------------
gdl_ret_t mm_register_irq_client(irq_registration_t * reg)
{
    gdl_ret_t            rc = GDL_SUCCESS;
    irq_registration_t * cli;

    FOR_EACH_CLIENT_ON_IRQ(irq_clients, cli, FREE_IRQ)
    {
        if (request_irq(reg->irq_number,
                        misc_irq_handler,
                        IRQF_DISABLED | IRQF_SHARED,
                        MM_VDC_NAME,
                        &cli->irq_token))
        {
            GDL_ERROR("Failed to register for irq %d\n",reg->irq_number);
            rc = GDL_ERR_FAILED;
            break;
        }

        cli->irq_number = reg->irq_number;
        cli->signal     = reg->signal;
        cli->mask       = reg->mask;

        // Optional ISR handling requested
        if (reg->isr_address)
        {
            // Map the whole page
            cli->isr_page = (unsigned int) ioremap(reg->isr_address & PAGE_MASK,
                                                   PAGE_SIZE);
            
            // Compute virtual address of actual register
            cli->isr_address = cli->isr_page + (reg->isr_address & ~PAGE_MASK);

            // Free IRQ if mapping failed
            if (!cli->isr_page)
            {
                free_irq(reg->irq_number, &cli->irq_token);
                cli->isr_address = 0;
                cli->irq_number  = FREE_IRQ;
            }
        }

        break;
    }

    return rc;
}

//-----------------------------------------------------------------------------
// Unregisters passed IRQ by removing it from array of registered IRQs and
// unregistering IRQ from kernel
//-----------------------------------------------------------------------------
gdl_ret_t mm_unregister_irq_client(irq_registration_t * reg)
{
    irq_registration_t * cli;
    gdl_ret_t            rc = GDL_ERR_FAILED;

    FOR_EACH_CLIENT_ON_IRQ(irq_clients, cli, reg->irq_number)
    {
        if (cli->signal == reg->signal)
        {
            free_irq(reg->irq_number, &cli->irq_token);

            if (cli->isr_page)
            {
                OS_UNMAP_IO_FROM_MEM((void*)cli->isr_page, PAGE_SIZE);
                cli->isr_address = 0;
                cli->isr_page    = 0;
            }

            cli->irq_number = FREE_IRQ;
            rc = GDL_SUCCESS;
            break;
        }
    }

    return rc;
}
