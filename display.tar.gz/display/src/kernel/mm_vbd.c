//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//---------------------------------------------------------------------------

//----------------------------------------------------------------------------
// File Description:
//    VBD job queue implementation
//----------------------------------------------------------------------------

#include <linux/module.h>

#include "common.h"
#include "mm_common.h"
#include "vbd_int.h"


// Global to store vbd callback arguments (function and cookie)
vbd_callback_args_t vbd_callback_args = {0,0};

// Global to store vbd display callback arguments for both pipes.
// index=0 - PIPE_A
// index=1 - PIPE_B
vbd_disp_callback_args_t vbd_disp_callback_args[2]  = 
{
    {0, 0, 0},
    {0, 0, 0}
};


//----------------------------------------------------------------------------
// mm_vbd_register_callback
//
// Registers callback for vbd. Called when VBD_CALLBACK command is
// sent to VBD_HANDLER.
//----------------------------------------------------------------------------
static gdl_ret_t mm_vbd_register_callback(vbd_callback_args_t  * args)
{
    vbd_callback_args.callback = args->callback;
    vbd_callback_args.cookie   = args->cookie;
    return GDL_SUCCESS;
}

//----------------------------------------------------------------------------
// mm_vbd_register_disp_callback
//
// Registers callback for vbd on specified pipe. Called when 
// VBD_DISPLAY_CALLBACK command is sent to VBD_HANDLER
//----------------------------------------------------------------------------
static gdl_ret_t mm_vbd_register_disp_callback(vbd_disp_callback_args_t * args)
{
    int       index = 0;
    gdl_ret_t rc    = GDL_SUCCESS;

    if (args == NULL)
    {
        GDL_ERROR("Args is NULL\n");
        rc = GDL_ERR_NULL_ARG;
        goto exit;
    }

    switch (args->display_id)
    {
    case GDL_DISPLAY_ID_0: index = 0; break;
    case GDL_DISPLAY_ID_1: index = 1; break;
    default: 
        GDL_ERROR("Incorrect display_id provided (%d)\n", args->display_id);
        rc = GDL_ERR_DISPLAY;
        goto exit;
    }

    vbd_disp_callback_args[index].display_id = args->display_id;
    vbd_disp_callback_args[index].callback   = args->callback;
    vbd_disp_callback_args[index].cookie     = args->cookie;

exit:
    return rc;
}


//----------------------------------------------------------------------------
// Kernel-level VBD_HANDLER
//----------------------------------------------------------------------------
gdl_ret_t VBD_HANDLER(vbd_data_t * vbd_data)
{
    gdl_ret_t       rc;
    gdl_boolean_t   need_rc = GDL_TRUE; // Wait for result from server

    if(NULL == vbd_data)
    {
        GDL_ERROR("vbd_handler():  Bad argument\n");
        rc = GDL_ERR_INTERNAL;
        goto exit;
    }

    switch (vbd_data->command)
    {
    case VBD_CALLBACK:
        // Command is processed locally
        rc = mm_vbd_register_callback(&vbd_data->args.callback_args);
        break;

    case VBD_DISPLAY_CALLBACK:
        // Command is processed locally
        rc = mm_vbd_register_disp_callback(&vbd_data->args.disp_callback_args);
        break;
    
    case VBD_FLIP:
    case VBD_FLIP_BLACK_FRAME:
    case VBD_CC_RESET:
    case VBD_ADJUST_VBLANK_LINES:
    case VBD_PLANE_SET_CSC_ADJUST:
    case VBD_POST_BLEND_SET_CSC_ADJUST:
        need_rc = GDL_FALSE; // Do NOT wait for result from server
        // FALL THROUGH TO DEFAULT
    default:
        rc = mm_queue_backdoor_job(BACKDOOR_Q_VBD, vbd_data, JOB_TYPE_VBD, need_rc);
        break;
    }

exit:
    return rc;
}

//----------------------------------------------------------------------------
// Exported Symbols
//----------------------------------------------------------------------------
EXPORT_SYMBOL(VBD_HANDLER);
