//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// File Description:
//    common structures/functions/includes for kernel module
//----------------------------------------------------------------------------

#ifndef _MM_COMMON_H_
#define _MM_COMMON_H_

#include "osal.h"
#include "gdl_types.h"
#include "mm.h"

// Milliseconds (1/1000 of second) to jiffies
#define MM_MS_TO_JIFFIES(time_ms) ((HZ*time_ms)/1000)

// Return current pipe polarity
gdl_polarity_t mm_get_polarity_pipe_a(void);
gdl_polarity_t mm_get_polarity_pipe_b(void);

// Block until either passed interrupt event occurs or timeout occurs.
// [in] mm_interrupt : Interrupt event to wait for
// [in] timeout      : Timeout in ms
gdl_ret_t mm_wait_for_event(vdc_interrupt_event_t event, int timeout);

// If we are in or about to enter the VBI, block caller until server has
// processed the Framestart interrupt on the specified display.
void mm_wait_for_vbi_processing(gdl_display_id_t display_id);

// Record server completion of framestart processing on specified display
void mm_framestart_processed(gdl_display_id_t display_id);

// Return 1 if server is alive, 0 otherwise.
int mm_server_alive(void);

//Get the running status of the server
mm_status_t mm_server_get_status(void);

unsigned int mm_reg_read(void *handle, gdl_uint32 base, gdl_uint32 reg);
void mm_reg_write(void *handle, gdl_uint32 base, gdl_uint32 reg, gdl_uint32 value);


//----------------------------------------------------------------------------
// GDL JOB QUEUES
//----------------------------------------------------------------------------

typedef struct mm_job_t
{
    gdl_trans_data_t    param;  // transaction data
    gdl_trans_status_t  status; // transaction status
    struct mm_job_t *   next;   // Next job in queue
} mm_job_t;


// Initialize GDL job queue
gdl_ret_t mm_init_job_queue (void);

// Finalize/clean up GDL job queue
void mm_cleanup_job_queue (void);

// Set or get a transaction
// Arguments:
// [in]     cmd : command/service to perform. Only supports KERN_TRANS_GET and
//               KERN_TRANS_SET
// [in/out] trans_arg : transaction data
gdl_ret_t mm_handle_job(km_service_t cmd, gdl_trans_data_t * trans_arg);

// Terminate all jobs by marking them as aborted and waking up anyone
// waiting for job completion
void mm_abort_all_jobs(void);


//----------------------------------------------------------------------------
// BACKDOOR JOB QUEUES
//----------------------------------------------------------------------------
typedef enum
{
    BACKDOOR_Q_VBD,
    BACKDOOR_Q_IRQ,
} backdoor_job_queue_id_t;

// Initialize all backdoor job queues
gdl_ret_t mm_init_backdoor_queues(void);

// Finalize/Clean up all backdoor job queues
void mm_cleanup_backdoor_queues(void);

// Get a job from a backdoor queue. Block on empty queue until job is available
// [in]  qid: Queue from which to take job.
// [out] job: Backdoor job taken from the queue
gdl_ret_t mm_get_backdoor_job(  backdoor_job_queue_id_t qid,
                                backdoor_job_t *        job);

// Add backdoor job to the queue. Wakes up anyone waiting for new jobs
// [in] qid: Queue from which to take job.
// [in] job: Backdoor job to be added to the queue
gdl_ret_t mm_set_backdoor_job(  backdoor_job_queue_id_t qid,
                                backdoor_job_t *        job);

// Add job to backdoor queue
gdl_ret_t mm_queue_backdoor_job(backdoor_job_queue_id_t qid,
                                void *                  data,
                                backdoor_job_type_t     job_type,
                                gdl_boolean_t           rc_needed);


//----------------------------------------------------------------------------
// WRITE-ON-EVENT OPERATIONS
//----------------------------------------------------------------------------

// An element in the write-on-event list
typedef struct mm_woe_node_t
{
    struct list_head       list;
    unsigned int           id;
    mm_woe_t               data;
} mm_woe_node_t;


// Initialize write-on-event system
gdl_ret_t mm_woe_init(void);

// Deinitialize write-on-event system
gdl_ret_t mm_woe_deinit(void);

// Delete element from write-on-event list
// This is 'atomic' function - no need to mm_woe_lock prior to calling it
gdl_ret_t mm_woe_delete(unsigned int id);

// Add element to write-on-event list
// This is 'atomic' function - no need to mm_woe_lock prior to calling it
gdl_ret_t mm_woe_add(mm_woe_t * data, unsigned int * id);

// Schedule to process all WOE events in a BH handler at a later time
gdl_ret_t mm_woe_process_events(vdc_pipe_t pipe, unsigned int events);

// Lock/unlock write-on-event system. Used to ensure that operations will be
// atomic. Note that mm_woe_add and mm_woe_delete lock/unlock internally.
void mm_woe_lock(void);
void mm_woe_unlock(void);

//Re-enable tasklet to execute
gdl_ret_t mm_woe_enable(void);
//Disable tasklet from executing, and wait until it is not running
gdl_ret_t mm_woe_disable(void);


//----------------------------------------------------------------------------
// INTERRUPTS
//----------------------------------------------------------------------------

// Initialize interrupts
gdl_ret_t mm_init_interrupts(void);

// Finalize/clean up interrupts
void mm_cleanup_interrupts(void);

// Initialize interrupt clients
void mm_init_irq_clients(void);

// Clean up interrupt registration system
void mm_cleanup_irq_clients(void);

// Save IRQ number, associated signal and registers for that IRQ with kernel
gdl_ret_t mm_register_irq_client(irq_registration_t * reg);

// Unregister passed IRQ by removing it from array of registered 
// IRQs and unregistering IRQ from kernel
gdl_ret_t mm_unregister_irq_client(irq_registration_t * reg);

//Enable interrupt notifications
void mm_enable_interrupts(void);

//Disable interrupt notifications
void mm_disable_interrupts(void);

// Handler for KERN_SAFE_REG_WRITE service
void mm_safe_reg_write(mm_safe_reg_write_t * data);


//----------------------------------------------------------------------------
// LRID handlng for frame sequential stereo video modes
//----------------------------------------------------------------------------
gdl_ret_t mm_lrid_enable(mm_sw_lrid_info_t * lrid_info);
gdl_ret_t mm_lrid_disable(void);
gdl_ret_t mm_lrid_init(mm_sw_lrid_info_t * lrid_info);
gdl_ret_t mm_lrid_trigger(void);
gdl_polarity_t mm_lrid_get_polarity(void);
int mm_uid_filtering_enabled(void);
gdl_boolean_t mm_capabilities_enforced(void);
int __mm_current_uid(void);
#endif /* _MM_COMMON_H_ */
