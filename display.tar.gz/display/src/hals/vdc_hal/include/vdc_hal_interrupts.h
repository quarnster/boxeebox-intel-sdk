//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// File Description:
//    Interrupt API
//----------------------------------------------------------------------------

#ifndef __VDC_HAL_INTERRUPTS_H__
#define __VDC_HAL_INTERRUPTS_H__

#include "vdc_hal_types.h"

//-----------------------------------------------------------------------------
// vdc_pipea_retrigger
//
// Rewriting the existing value into PIPEACONF will retrigger internal 
// counter updates. This function needs to be called after vblank is adjusted
// on the fly.
//-----------------------------------------------------------------------------
gdl_ret_t vdc_pipea_retrigger(vdc_t * dev);

//-----------------------------------------------------------------------------
// vdc_interrupts_set
//
// Method allows to set interrupt mask. Setting interrupt mask specifies which
// events will trigger interrupt line Setting mask to 0x0 will disable all
// interrupts
//
// Arguments:
// [in]  plane_id : Plane identification
// [in]  mask     : OR-ed combination of vdc_interrupt_t
//                  flags
//-----------------------------------------------------------------------------
gdl_ret_t vdc_interrupts_set(vdc_t *    dev,
                             gdl_uint32 mask);

//-----------------------------------------------------------------------------
// vdc_interrupts_get
//
// Method allows to query which interrupt events are currently pending.
//
// Arguments:
// [in]  plane_id : Plane identification
// [out] pending  : OR-ed combination of vdc_interrupt_event_t
//                  flags
//-----------------------------------------------------------------------------
gdl_ret_t vdc_interrupts_get(vdc_t *      dev,
                             gdl_uint32 * pending);

//-----------------------------------------------------------------------------
// vdc_interrupts_ack
//
// Acknowledges interrupts based on the mask provided.
//
// Arguments:
// [in] mask : OR-ed combination of vdc_interrupt_event_t flags
//-----------------------------------------------------------------------------
gdl_ret_t vdc_interrupts_ack(vdc_t *    dev,
                             gdl_uint32 acked_interrupts);

//-----------------------------------------------------------------------------
// These registers are defined separately because they are needed for the
// GDL minimal module, whose source is distributed
//-----------------------------------------------------------------------------
#define REG_DIAPSTA_BASE    0x10008
#define REG_IAP_M1_OFFSET   0xF000
#define REG_IAP_0_OFFSET    0x0000
#define REG_IAP_1_OFFSET    0x1000

#define REG_DUPSTA_BASE     0x30008
#define REG_UPP_M1_OFFSET   0xF000
#define REG_UPP_0_OFFSET    0x0000
#define REG_UPP_1_OFFSET    0x1000
#define REG_UPP_2_OFFSET    0x2000
#define REG_UPP_3_OFFSET    0x3000

#define REG_WBPSTA          0x40004

#define REG_PIPEASTAT       0x70024
#define REG_PIPEBSTAT       0x68554

#define REG_PIPEACONF       0x70008

#define REG_3DOUT_FORMAT1   0x7000C
#endif /* __VDC_HAL_INTERRUPTS_H__ */
