//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

#include "gdl_types.h"

#ifndef __VDC_HAL_TYPES_H__
#define __VDC_HAL_TYPES_H__

//----------------------------------------------------------------------------
// Known VDC PCI device revisions
// 
// These symbolic names are assigned just to make it easy to find places in the
// code that are conditioned on different revisions
//----------------------------------------------------------------------------
typedef enum
{
    VDC_PCI_REV_CE3100      = 0,
    VDC_PCI_REV_CE4100_A0   = 1,
    VDC_PCI_REV_CE4100_B012 = 2,
    VDC_PCI_REV_CE4200_A0   = 3,
    VDC_PCI_REV_CE4200_B0   = 4,
    VDC_PCI_REV_CE5300_A0   = 6,
} vdc_dev_pci_rev_t;


//-------------------------------------------------------
// VDC types
//-------------------------------------------------------
// Plane type enumeration
typedef enum
{
    VDC_PLANE_TYPE_UPP = 1,
    VDC_PLANE_TYPE_IAP,
    VDC_PLANE_TYPE_WBP,
    VDC_PLANE_TYPE_INVAL,
} vdc_plane_type_t;

// Plane identification
typedef enum
{
    VDC_PLANE_ID_UNDEFINED  = 0x100,
    VDC_PLANE_ID_UPP_m1,
    VDC_PLANE_ID_UPP_0,
    VDC_PLANE_ID_UPP_1,
    VDC_PLANE_ID_UPP_2,
    VDC_PLANE_ID_UPP_3,
    VDC_PLANE_ID_IAP_m1,
    VDC_PLANE_ID_IAP_0,
    VDC_PLANE_ID_IAP_1,
    VDC_PLANE_ID_WBP,
} vdc_plane_id_t;

// Pipe identification
typedef enum
{
    VDC_PIPE_A,
    VDC_PIPE_B,
    VDC_PIPE_UNDEFINED,
} vdc_pipe_t;

// Blender selection
typedef enum
{
    VDC_BLENDER_BLm2,
    VDC_BLENDER_BLm1,
    VDC_BLENDER_BL0,
    VDC_BLENDER_BL1,
    VDC_BLENDER_BL2,
    VDC_BLENDER_BL3,
    VDC_BLENDER_BL4,
    VDC_BLENDER_BL5,
    VDC_BLENDER_TG0, 
    VDC_BLENDER_TG1, 
} vdc_blender_t;

//Pipe timings structure
typedef struct
{
    gdl_uint32 htotal;
    gdl_uint32 hactive;     // Active pixels - 1
    gdl_uint32 hblank_end;
    gdl_uint32 hblank_start;
    gdl_uint32 hsync_end;
    gdl_uint32 hsync_start;
    gdl_uint32 vtotal;
    gdl_uint32 vactive;      // Active lines - 1
    gdl_uint32 vblank_end;
    gdl_uint32 vblank_start;
    gdl_uint32 vsync_end;
    gdl_uint32 vsync_start;
    gdl_uint32 vsync_shift; //Sync shift
} vdc_pipe_timings_t;

typedef enum
{
    VDC_PIPE_PROGRESSIVE,
    VDC_PIPE_INTERLACED,
    VDC_PIPE_INTERLACED_LEGACY,
    VDC_PIPE_INTERLACED_FIELD0,
} vdc_pipe_mode_t;

//OR-able interrupts that can be enabled/disabled
typedef enum
{
    VDC_INT_CRC_ERR              = 0x00000001,
    VDC_INT_CRC_DONE             = 0x00000002,
    VDC_INT_VSYNC_PIPE_A         = 0x00000004,
    VDC_INT_VBLANK_PIPE_A        = 0x00000008,
    VDC_INT_TOP_FIELD_PIPE_A     = 0x00000010,
    VDC_INT_BOTTOM_FIELD_PIPE_A  = 0x00000020,
    VDC_INT_FRAMESTART_PIPE_A    = 0x00000040,

    VDC_INT_UPP_0_FLIP           = 0x00000080,
    VDC_INT_UPP_1_FLIP           = 0x00000100,
    VDC_INT_UPP_2_FLIP           = 0x00000200,
    VDC_INT_UPP_3_FLIP           = 0x00000400,
    VDC_INT_UPP_4_FLIP           = 0x00000800,
    VDC_INT_UPP_M1_FLIP          = 0x00001000,

    VDC_INT_IAP_0_FLIP           = 0x00010000,
    VDC_INT_IAP_1_FLIP           = 0x00020000,

    VDC_INT_WBP_FLIP             = 0x00040000,
    VDC_INT_WBP_FRAMEDONE        = 0x00080000,

    VDC_INT_VSYNC_PIPE_B         = 0x00100000,
    VDC_INT_VBLANK_PIPE_B        = 0x00200000,
    VDC_INT_TOP_FIELD_PIPE_B     = 0x00400000,
    VDC_INT_BOTTOM_FIELD_PIPE_B  = 0x00800000,
    VDC_INT_FRAMESTART_PIPE_B    = 0x01000000
} vdc_interrupt_t;

// OR-able interrupt events that can be checked
// when interrupt occurs
typedef enum
{
    VDC_EVENT_CRC_ERR             = 0x00000001,
    VDC_EVENT_CRC_DONE            = 0x00000002,
    VDC_EVENT_VSYNC_PIPE_A        = 0x00000004,
    VDC_EVENT_VBLANK_PIPE_A       = 0x00000008,
    VDC_EVENT_TOP_FIELD_PIPE_A    = 0x00000010,
    VDC_EVENT_BOTTOM_FIELD_PIPE_A = 0x00000020,
    VDC_EVENT_FRAMESTART_PIPE_A   = 0x00000040,
    VDC_EVENT_FIFO_UNDERFLOW      = 0x00000080,

    VDC_EVENT_UPP_0_FLIP          = 0x00000100,
    VDC_EVENT_UPP_1_FLIP          = 0x00000200,
    VDC_EVENT_UPP_2_FLIP          = 0x00000400,
    VDC_EVENT_UPP_3_FLIP          = 0x00000800,
    VDC_EVENT_UPP_4_FLIP          = 0x00001000,
    VDC_EVENT_UPP_M1_FLIP         = 0x00002000,

    VDC_EVENT_IAP_0_FLIP          = 0x00010000,
    VDC_EVENT_IAP_1_FLIP          = 0x00020000,
    VDC_EVENT_WBP_FLIP            = 0x00040000,
    VDC_EVENT_WBP_FRAMEDONE       = 0x00080000,

    VDC_EVENT_VSYNC_PIPE_B        = 0x00100000,
    VDC_EVENT_VBLANK_PIPE_B       = 0x00200000,
    VDC_EVENT_TOP_FIELD_PIPE_B    = 0x00400000,
    VDC_EVENT_BOTTOM_FIELD_PIPE_B = 0x00800000,
    VDC_EVENT_FRAMESTART_PIPE_B   = 0x01000000,

    VDC_EVENT_TOP_LEFT_FIELD_PIPE_A     = 0x02000000,
    VDC_EVENT_TOP_RIGHT_FIELD_PIPE_A    = 0x04000000,
    VDC_EVENT_BOTTOM_LEFT_FIELD_PIPE_A  = 0x08000000,
    VDC_EVENT_BOTTOM_RIGHT_FIELD_PIPE_A = 0x10000000,
    
    VDC_EVENT_LEFT_FRAME_PIPE_A         = 0x20000000,
    VDC_EVENT_RIGHT_FRAME_PIPE_A        = 0x40000000,
} vdc_interrupt_event_t;

// Gamma correction points structure used for setting up gamma
// correction curve (for pipe gamma and inverse universal plane
// gamma)
typedef struct
{
    gdl_uint16     r_v;
    gdl_uint16     g_y;
    gdl_uint16     b_u;
    gdl_boolean_t  changed;
} vdc_gamma_point_t;

//Container used to pass gamma tables around
typedef struct
{
    //Total entries in the points array if we want to write the entire thing
    gdl_uint32         num_entries; 
    vdc_gamma_point_t *points;
} vdc_gamma_table_t;

//All possible different locations of gamma LUTs
typedef enum
{
    VDC_GAMMA_UNDEFINED,     //End of list marker
    VDC_GAMMA_UPP,
    VDC_GAMMA_PIPE_A,
    VDC_GAMMA_PIPE_B,
    VDC_GAMMA_PIPE_A_PB2,
    VDC_GAMMA_PIPE_A_PB1 = VDC_GAMMA_PIPE_A,
} vdc_gamma_position_t;

// Palette entry used in vdc_palette_t type
typedef struct
{
    gdl_uint8 alpha;
    gdl_uint8 r_cr;
    gdl_uint8 g_y;
    gdl_uint8 b_cb;
} vdc_palette_entry_t;


// VDC palette structure used to pass IAP color lookup table.
typedef struct
{
    vdc_palette_entry_t data[256];
    gdl_uint32          length;
} vdc_palette_t;

//Blender input selector
typedef enum
{
    VDC_BLENDER_LEFT_INPUT,
    VDC_BLENDER_RIGHT_INPUT,
} vdc_blender_input_t;

//Buffer information
typedef struct
{
    physaddr_t    f0_y_rgb_ptr;  // TOP field, y/rgb ptr
    physaddr_t    f0_uv_ptr;     // TOP field, uv ptr
    physaddr_t    f1_y_rgb_ptr;  // BOTTOM field, y/rgb ptr
    physaddr_t    f1_uv_ptr;     // BOTTOM field, uv ptr
    gdl_uint32    y_rgb_stride;  // Y/RGB stride
    gdl_uint32    uv_stride;     // UV stride
    gdl_point_t   pan;           // Pan&scan information
    gdl_boolean_t progressive;   // GDL_TRUE iff content is progressive (full frame)
    gdl_boolean_t invert_fields; // Whether to invert fields
} vdc_buffer_info_t;


// Destination encoder(s) for pipe
// Only used for PIPE_B
typedef enum
{
    VDC_PIPE_DEST_ENC0,
    VDC_PIPE_DEST_ENC1,
    VDC_PIPE_DEST_ENC0_ENC1,
} vdc_pipe_dest_t;

// EVO output format
typedef enum
{
    VDC_EVO_16_BIT,
    VDC_EVO_8_BIT,
} vdc_evo_format_t;

//----------------------------------------------------------------------------
// VDC structure
//----------------------------------------------------------------------------
typedef struct vdc_t
{
    vdc_dev_pci_rev_t revision;

    //Base of registers
    unsigned int    io_address;
    unsigned int    mem_size;

    //Configurations
    // SVBI vertical and horizontal offsets
    unsigned int    svbi_vert_offset;
    unsigned int    svbi_horiz_offset;

    // Cached buffer info for each plane
    // Array is indexed by using __vdc_plane_id_to_buff_index() function
    // which returns index based on 'vdc_plane_id' passed to it
    // Need space for all UPPs, all IAPs and a writeback plane
    vdc_buffer_info_t cached_buff_info[GDL_MAX_UPPS + GDL_MAX_IAPS + 1]; 

    // VDC plane ids used for pipe_b output and reserved by SVBI
    vdc_plane_id_t  vdc_upp_wbp_id;
    vdc_plane_id_t  vdc_svbi_plane_id;

    //Handle to be passed to io_read/io_write, log_entry/exit/custom 
    void     * uhandle;

    gdl_uint32 (*io_read )  (void *     handle, 
                             gdl_uint32 address, 
                             gdl_uint32 reg);

    void       (*io_write)  (void *     handle, 
                             gdl_uint32 address, 
                             gdl_uint32 reg, 
                             gdl_uint32 value);

    void       (*log_entry) (void * handle, const char * s);
    void       (*log_exit)  (void * handle, const char * s);
    void       (*log_custom)(void * handle, const char * s);
} vdc_t;

#endif /* __VDC_HAL_TYPES_H__ */
