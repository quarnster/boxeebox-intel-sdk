//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or 
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify 
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but 
// WITHOUT ANY WARRANTY; without even the implied warranty of 
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License 
// along with this program; if not, write to the Free Software 
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution 
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE 
//
// Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without 
// modification, are permitted provided that the following conditions 
// are met:
//
//   - Redistributions of source code must retain the above copyright 
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright 
//     notice, this list of conditions and the following disclaimer in 
//     the documentation and/or other materials provided with the 
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its 
//     contributors may be used to endorse or promote products derived 
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

#ifndef __VDC_HAL_COMMON_H__
#define __VDC_HAL_COMMON_H__

#include "common.h"
#include "vdc_hal_types.h"

typedef struct
{
    vdc_plane_type_t    type;
    void *              regs;
    gdl_uint32          offset;
} vdc_plane_t;

vdc_plane_t *vdc_get_plane(vdc_plane_id_t plane_id);

#ifndef NULL
#define NULL ((void*)(0))
#endif

#undef VERIFY_QUICK
#define VERIFY_QUICK(exp, label)        \
            if (!(exp))                 \
            {                           \
                LOG_CUSTOM("Failed");   \
                goto label;             \
            }

#define VERIFY_DEVICE(rc, label)                                     \
if (dev == NULL || dev->io_read == NULL || dev->io_write == NULL)    \
{                                                                    \
    rc = GDL_ERR_NULL_ARG;                                           \
    LOG_CUSTOM("Fatal ERROR: VDC device is null or read/write is null"); \
    goto label;                                                      \
}

#define IOW(reg, val) dev->io_write(dev->uhandle, dev->io_address, reg, val)

#define IOR(reg) dev->io_read(dev->uhandle, dev->io_address, reg) 

#define LOG_ENTRY \
(dev!=NULL && dev->log_entry!=NULL) ? dev->log_entry(dev->uhandle,__FUNCTION__):0;

#define LOG_EXIT  \
(dev!=NULL && dev->log_exit!=NULL) ? dev->log_exit(dev->uhandle,__FUNCTION__):0;

#define LOG_CUSTOM(s) \
(dev != NULL && dev->log_custom != NULL) ? dev->log_custom(dev->uhandle, s) : 0;

#define MASK_1_BIT   0x00000001
#define MASK_2_BITS  0x00000003
#define MASK_3_BITS  0x00000007
#define MASK_4_BITS  0x0000000f
#define MASK_5_BITS  0x0000001f
#define MASK_6_BITS  0x0000003f
#define MASK_7_BITS  0x0000007f
#define MASK_8_BITS  0x000000ff
#define MASK_9_BITS  0x000001ff
#define MASK_10_BITS 0x000003ff
#define MASK_11_BITS 0x000007ff
#define MASK_12_BITS 0x00000fff
#define MASK_13_BITS 0x00001fff
#define MASK_14_BITS 0x00003fff
#define MASK_15_BITS 0x00007fff
#define MASK_16_BITS 0x0000ffff
#define MASK_17_BITS 0x0001ffff
#define MASK_18_BITS 0x0003ffff
#define MASK_19_BITS 0x0007ffff
#define MASK_20_BITS 0x000fffff
#define MASK_21_BITS 0x001fffff
#define MASK_22_BITS 0x003fffff
#define MASK_23_BITS 0x007fffff
#define MASK_24_BITS 0x00ffffff
#define MASK_25_BITS 0x01ffffff
#define MASK_26_BITS 0x03ffffff
#define MASK_27_BITS 0x07ffffff
#define MASK_28_BITS 0x0fffffff
#define MASK_29_BITS 0x1fffffff
#define MASK_30_BITS 0x3fffffff
#define MASK_31_BITS 0x7fffffff
#define MASK_32_BITS 0xffffffff

#define UNSUPPORTED_SOC(rev, rc, label) \
if (dev->revision == rev)               \
{                                       \
    rc = GDL_ERR_NO_HW_SUPPORT;         \
    goto label;                         \
}

#endif
