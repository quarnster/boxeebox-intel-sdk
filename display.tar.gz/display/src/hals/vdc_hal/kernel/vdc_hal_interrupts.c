//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE
//
// Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   - Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// File Description:
//    Interrupt API implementation
//----------------------------------------------------------------------------
#include "vdc_hal_common.h"
#include "vdc_hal_interrupts.h"


//-----------------------------------------------------------------------------
// vdc_pipea_retrigger
//
// Rewriting the existing value into PIPEACONF will retrigger internal 
// counter updates. This function needs to be called after vblank is adjusted
// on the fly.
//-----------------------------------------------------------------------------
gdl_ret_t vdc_pipea_retrigger(vdc_t * dev)
{
    IOW(REG_PIPEACONF, IOR(REG_PIPEACONF));
    return GDL_SUCCESS;
}


//-----------------------------------------------------------------------------
// vdc_interrupts_set
//
// Method for setting interrupt mask. Set bits specify events that will
// trigger the interrupt line. Setting mask to 0x0 disables all interrupts.
//
// Arguments:
// [in]  plane_id : Plane identification
// [in]  mask     : OR-ed combination of vdc_interrupt_t flags
//-----------------------------------------------------------------------------
gdl_ret_t vdc_interrupts_set(vdc_t *    dev,
                             gdl_uint32 mask)
{
    gdl_uint32 val_up0, val_up1, val_up2, val_up3;
    gdl_uint32 val_upm1;
    gdl_uint32 val_iap0, val_iap1;
    gdl_uint32 val_wbp;
    gdl_uint32 val_pipea;
    gdl_uint32 val_pipeb;

    gdl_uint32 reg_upp0 = REG_DUPSTA_BASE + REG_UPP_0_OFFSET;
    gdl_uint32 reg_upp1 = REG_DUPSTA_BASE + REG_UPP_1_OFFSET;
    gdl_uint32 reg_upp2 = REG_DUPSTA_BASE + REG_UPP_2_OFFSET;
    gdl_uint32 reg_upp3 = REG_DUPSTA_BASE + REG_UPP_3_OFFSET;
    gdl_uint32 reg_uppm1= REG_DUPSTA_BASE + REG_UPP_M1_OFFSET;
    gdl_uint32 reg_iap0 = REG_DIAPSTA_BASE + REG_IAP_0_OFFSET;
    gdl_uint32 reg_iap1 = REG_DIAPSTA_BASE + REG_IAP_1_OFFSET;

    gdl_ret_t rc = GDL_SUCCESS;

    LOG_ENTRY;
    VERIFY_DEVICE(rc, EXIT);

    // Read registers and clear all interrupt bits

    val_up0  = IOR(reg_upp0)      & ~BIT30;
    val_up1  = IOR(reg_upp1)      & ~BIT30;
    val_up2  = IOR(reg_upp2)      & ~BIT30;
    val_up3  = IOR(reg_upp3)      & ~BIT30;
    val_upm1 = IOR(reg_uppm1)     & ~BIT30;
    val_iap0 = IOR(reg_iap0)      & ~BIT30;
    val_iap1 = IOR(reg_iap1)      & ~BIT30;
    val_wbp  = IOR(REG_WBPSTA)    & ~(BIT1 | BIT3);
    val_pipea= IOR(REG_PIPEASTAT) & ~(BIT29|BIT28|BIT25|BIT24|BIT21|BIT20|BIT17);
    val_pipeb= IOR(REG_PIPEBSTAT) & ~(BIT21|BIT20|BIT19|BIT18|BIT17);

    // Set interrupt bits for events specified by passed mask

    if (mask & VDC_INT_CRC_ERR)             { val_pipea |= BIT29; }
    if (mask & VDC_INT_CRC_DONE)            { val_pipea |= BIT28; }
    if (mask & VDC_INT_VSYNC_PIPE_A)        { val_pipea |= BIT25; }
    if (mask & VDC_INT_VBLANK_PIPE_A)       { val_pipea |= BIT24; }
    if (mask & VDC_INT_TOP_FIELD_PIPE_A)    { val_pipea |= BIT21; }
    if (mask & VDC_INT_BOTTOM_FIELD_PIPE_A) { val_pipea |= BIT20; }
    if (mask & VDC_INT_FRAMESTART_PIPE_A)   { val_pipea |= BIT17; }

    if (mask & VDC_INT_VSYNC_PIPE_B)        { val_pipeb |= BIT21; }
    if (mask & VDC_INT_VBLANK_PIPE_B)       { val_pipeb |= BIT20; }
    if (mask & VDC_INT_TOP_FIELD_PIPE_B)    { val_pipeb |= BIT19; }
    if (mask & VDC_INT_BOTTOM_FIELD_PIPE_B) { val_pipeb |= BIT18; }
    if (mask & VDC_INT_FRAMESTART_PIPE_B)   { val_pipeb |= BIT17; }

    if (mask & VDC_INT_UPP_0_FLIP)          { val_up0   |= BIT30; }
    if (mask & VDC_INT_UPP_1_FLIP)          { val_up1   |= BIT30; }
    if (mask & VDC_INT_UPP_2_FLIP)          { val_up2   |= BIT30; }
    if (mask & VDC_INT_UPP_3_FLIP)          { val_up3   |= BIT30; }
    if (mask & VDC_INT_UPP_M1_FLIP)         { val_upm1  |= BIT30; }
    if (mask & VDC_INT_IAP_0_FLIP)          { val_iap0  |= BIT30; }
    if (mask & VDC_INT_IAP_1_FLIP)          { val_iap1  |= BIT30; }
    if (mask & VDC_INT_WBP_FLIP)            { val_wbp   |= BIT1;  }
    if (mask & VDC_INT_WBP_FRAMEDONE)       { val_wbp   |= BIT3;  }

    // Write updated register values

    IOW(reg_upp0, val_up0);
    IOW(reg_upp1, val_up1);
    IOW(reg_upp2, val_up2);
    IOW(reg_upp3, val_up3);
    IOW(reg_uppm1,val_upm1);

    IOW(reg_iap0, val_iap0);
    IOW(reg_iap1, val_iap1);

    IOW(REG_PIPEASTAT, val_pipea);
    IOW(REG_PIPEBSTAT, val_pipeb);

    IOW(REG_WBPSTA, val_wbp);

EXIT:
    LOG_EXIT;
    return rc;
}


//-----------------------------------------------------------------------------
// vdc_interrupts_get
//
// Method for querying pending interrupt events.
//
// Arguments:
// [in]  plane_id : Plane identification
// [out] pending  : OR-ed combination of vdc_interrupt_event_t flags
//-----------------------------------------------------------------------------
gdl_ret_t vdc_interrupts_get(vdc_t *      dev,
                             gdl_uint32 * pending)
{
    gdl_ret_t rc = GDL_SUCCESS;
    gdl_uint32 val_up0, val_up1, val_up2, val_up3;
    gdl_uint32 val_upm1;
    gdl_uint32 val_iap0, val_iap1;
    gdl_uint32 val_wbp;
    gdl_uint32 val_pipea;
    gdl_uint32 val_pipeb;
    gdl_uint32 val;

    LOG_ENTRY;
    VERIFY_DEVICE(rc, EXIT);
    VERIFY(pending != NULL, rc, GDL_ERR_NULL_ARG, EXIT);

    // Clear pending mask

    *pending = 0;

    // Read all interrupt status registers

    val_up0 = IOR(REG_DUPSTA_BASE + REG_UPP_0_OFFSET);
    val_up1 = IOR(REG_DUPSTA_BASE + REG_UPP_1_OFFSET);
    val_up2 = IOR(REG_DUPSTA_BASE + REG_UPP_2_OFFSET);
    val_up3 = IOR(REG_DUPSTA_BASE + REG_UPP_3_OFFSET);
    val_upm1= IOR(REG_DUPSTA_BASE + REG_UPP_M1_OFFSET);

    val_iap0 = IOR(REG_DIAPSTA_BASE + REG_IAP_0_OFFSET);
    val_iap1 = IOR(REG_DIAPSTA_BASE + REG_IAP_1_OFFSET);

    val_wbp = IOR(REG_WBPSTA);

    val_pipea = IOR(REG_PIPEASTAT);
    val_pipeb = IOR(REG_PIPEBSTAT);

    // Set bit in pending mask for each interrupt detected

    if (val_up0 & BIT29)   *pending |= VDC_EVENT_UPP_0_FLIP;
    if (val_up1 & BIT29)   *pending |= VDC_EVENT_UPP_1_FLIP;
    if (val_up2 & BIT29)   *pending |= VDC_EVENT_UPP_2_FLIP;
    if (val_up3 & BIT29)   *pending |= VDC_EVENT_UPP_3_FLIP;
    if (val_upm1 & BIT29)  *pending |= VDC_EVENT_UPP_M1_FLIP;

    if (val_iap0 & BIT29)  *pending |= VDC_EVENT_IAP_0_FLIP;
    if (val_iap1 & BIT29)  *pending |= VDC_EVENT_IAP_1_FLIP;

    if (val_wbp & BIT0)    *pending |= VDC_EVENT_WBP_FLIP;
    if (val_wbp & BIT2)    *pending |= VDC_EVENT_WBP_FRAMEDONE;

    if (val_pipea & BIT31) *pending |= VDC_EVENT_FIFO_UNDERFLOW;
    if (val_pipea & BIT13) *pending |= VDC_EVENT_CRC_ERR;
    if (val_pipea & BIT12) *pending |= VDC_EVENT_CRC_DONE;

    if (val_pipea & BIT9)  *pending |= VDC_EVENT_VSYNC_PIPE_A;
    if (val_pipea & BIT8)  *pending |= VDC_EVENT_VBLANK_PIPE_A;
    if (val_pipea & BIT5)  *pending |= VDC_EVENT_TOP_FIELD_PIPE_A;
    if (val_pipea & BIT4)  *pending |= VDC_EVENT_BOTTOM_FIELD_PIPE_A;
    if (val_pipea & BIT1)  *pending |= VDC_EVENT_FRAMESTART_PIPE_A;

    if (val_pipeb & BIT4)  *pending |= VDC_EVENT_VSYNC_PIPE_B;
    if (val_pipeb & BIT3)  *pending |= VDC_EVENT_VBLANK_PIPE_B;
    if (val_pipeb & BIT2)  *pending |= VDC_EVENT_TOP_FIELD_PIPE_B;
    if (val_pipeb & BIT1)  *pending |= VDC_EVENT_BOTTOM_FIELD_PIPE_B;
    if (val_pipeb & BIT0)  *pending |= VDC_EVENT_FRAMESTART_PIPE_B;


    // If HW 3D assist is enabled and we are on CE4200-B0 or above, only then look
    // at BIT6 and BIT7 of PIPEASTAT register
    if ((dev->revision >= VDC_PCI_REV_CE4200_B0)
    &&  (IOR(REG_3DOUT_FORMAT1) & BIT4))    // BIT4 set if hw 3d assist is on
    {

        val = (val_pipea & (BIT6 | BIT7)) >> 6;

        // Bits 6 and 7 of PIPEASTAT register are interpreted differently
        // depending on whether we are in a progressive or interlaced modes
        // 
        // In interlaced modes BIT23 of PIPEACONF is set
        //
        if (IOR(REG_PIPEACONF) & BIT23)
        {
            // Note: In pending flags, we specify what is currently being
            // scanned out; bits tell us what has just been displayed
            //
            // In interlaced frame packing mode fields go out in this order:
            // TOP_left  ==  EVEN_left
            // TOP_right ==  EVEN_right
            // BOT_left  ==  ODD_left
            // BOT_right ==  ODD_right
            //
            switch (val)
            {
            case 0: *pending |= VDC_EVENT_BOTTOM_RIGHT_FIELD_PIPE_A; break;
            case 1: *pending |= VDC_EVENT_TOP_LEFT_FIELD_PIPE_A;     break;
            case 2: *pending |= VDC_EVENT_TOP_RIGHT_FIELD_PIPE_A;    break;
            case 3: *pending |= VDC_EVENT_BOTTOM_LEFT_FIELD_PIPE_A;  break;
            default:
                break;
            }
        }
        else
        {
            // Progressive mode
            switch (val)
            {
            case 0: *pending |= VDC_EVENT_RIGHT_FRAME_PIPE_A; break;
            case 1: *pending |= VDC_EVENT_LEFT_FRAME_PIPE_A;  break;
            default:
                break;
            }
        }
    }
    
EXIT:
    LOG_EXIT;
    return rc;
}


//-----------------------------------------------------------------------------
// vdc_interrupts_ack
//
// Acknowledges interrupts based on the mask provided.
//
// Arguments:
// [in] mask : OR-ed combination of vdc_interrupt_event_t flags
//-----------------------------------------------------------------------------
gdl_ret_t vdc_interrupts_ack(vdc_t *    dev,
                             gdl_uint32 mask)
{
    gdl_uint32 reg_upp0 = REG_DUPSTA_BASE  + REG_UPP_0_OFFSET;
    gdl_uint32 reg_upp1 = REG_DUPSTA_BASE  + REG_UPP_1_OFFSET;
    gdl_uint32 reg_upp2 = REG_DUPSTA_BASE  + REG_UPP_2_OFFSET;
    gdl_uint32 reg_upp3 = REG_DUPSTA_BASE  + REG_UPP_3_OFFSET;
    gdl_uint32 reg_uppm1= REG_DUPSTA_BASE  + REG_UPP_M1_OFFSET;
    gdl_uint32 reg_iap0 = REG_DIAPSTA_BASE + REG_IAP_0_OFFSET;
    gdl_uint32 reg_iap1 = REG_DIAPSTA_BASE + REG_IAP_1_OFFSET;

    gdl_uint32 wbp_mask;
    gdl_uint32 pipea_mask;
    gdl_uint32 pipeb_mask;

    gdl_ret_t rc = GDL_SUCCESS;

    LOG_ENTRY;
    VERIFY_DEVICE(rc, EXIT);

    wbp_mask   = 0x0;
    pipea_mask = 0x0;
    pipeb_mask = 0x0;

    //PLANES

    if (mask & VDC_EVENT_UPP_0_FLIP) { IOW(reg_upp0, IOR(reg_upp0) | BIT29); }
    if (mask & VDC_EVENT_UPP_1_FLIP) { IOW(reg_upp1, IOR(reg_upp1) | BIT29); }
    if (mask & VDC_EVENT_UPP_2_FLIP) { IOW(reg_upp2, IOR(reg_upp2) | BIT29); }
    if (mask & VDC_EVENT_UPP_3_FLIP) { IOW(reg_upp3, IOR(reg_upp3) | BIT29); }
    if (mask & VDC_EVENT_UPP_M1_FLIP){ IOW(reg_uppm1, IOR(reg_uppm1) | BIT29);}

    if (mask & VDC_EVENT_IAP_0_FLIP) { IOW(reg_iap0, IOR(reg_iap0) | BIT29); }
    if (mask & VDC_EVENT_IAP_1_FLIP) { IOW(reg_iap1, IOR(reg_iap1) | BIT29); }

    if (mask & VDC_EVENT_WBP_FLIP)      wbp_mask |= BIT0;
    if (mask & VDC_EVENT_WBP_FRAMEDONE) wbp_mask |= BIT2;

    if (wbp_mask != 0x0)
    {
        // Writing 1 to any bit resets it.
        // Need to write only to bits specified in mask
        gdl_uint32 wbp_val = IOR(REG_WBPSTA) & ~(BIT0|BIT2);
        IOW(REG_WBPSTA, wbp_val | wbp_mask);
    }

    //PIPE A

    if (mask & VDC_EVENT_FIFO_UNDERFLOW)      pipea_mask |= BIT31;
    if (mask & VDC_EVENT_CRC_ERR)             pipea_mask |= BIT13;
    if (mask & VDC_EVENT_CRC_DONE)            pipea_mask |= BIT12;
    if (mask & VDC_EVENT_VSYNC_PIPE_A)        pipea_mask |= BIT9;
    if (mask & VDC_EVENT_VBLANK_PIPE_A)       pipea_mask |= BIT8;
    if (mask & VDC_EVENT_TOP_FIELD_PIPE_A)    pipea_mask |= BIT5;
    if (mask & VDC_EVENT_BOTTOM_FIELD_PIPE_A) pipea_mask |= BIT4;
    if (mask & VDC_EVENT_FRAMESTART_PIPE_A)   pipea_mask |= BIT1;

    if (pipea_mask != 0x0)
    {
        //Writing 1 to any status bit resets it
        //Need to write only to bits specified in mask
        gdl_uint32 pipea_val = IOR(REG_PIPEASTAT)
                             & ~(BIT31|BIT13|BIT12|BIT9|BIT8|BIT5|BIT4|BIT1);
        IOW(REG_PIPEASTAT, pipea_val | pipea_mask);
    }

    //PIPE B

    if (mask & VDC_EVENT_VSYNC_PIPE_B)        pipeb_mask |= BIT4;
    if (mask & VDC_EVENT_VBLANK_PIPE_B)       pipeb_mask |= BIT3;
    if (mask & VDC_EVENT_TOP_FIELD_PIPE_B)    pipeb_mask |= BIT2;
    if (mask & VDC_EVENT_BOTTOM_FIELD_PIPE_B) pipeb_mask |= BIT1;
    if (mask & VDC_EVENT_FRAMESTART_PIPE_B)   pipeb_mask |= BIT0;

    if (pipeb_mask != 0x0)
    {
        //Writing 1 to any status bit resets it
        //Need to write only to bits specified in mask
        gdl_uint32 pipeb_val = IOR(REG_PIPEBSTAT) & ~(BIT4|BIT3|BIT2|BIT1|BIT0);
        IOW(REG_PIPEBSTAT, pipeb_val | pipeb_mask);
    }

EXIT:
    LOG_EXIT;
    return rc;
}
