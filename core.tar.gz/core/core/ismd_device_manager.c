/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



/*
 * ismd_device_manager.c implements the Device Manager subcomponent of the SMD
 * Core driver.  This subcomponent is responsible for generating system-wide
 * unique device handles and for managing the registration and execution of
 * the SMD Common functions for close, flush, set_state, set_clock, and 
 * set_stream_base_time.
 */

#include "osal.h"
#include "ismd_global_defs.h"
#include "smd_core_local_defs.h"
#include "ismd_core.h"
#include "ismd_core_protected.h"


#ifndef DEVICE_MANAGER_TRACE
   #define DEVICE_MANAGER_TRACE(dev, action, result)
#endif

#ifndef DEVICE_MANAGER_LOG_MSG
   #define DEVICE_MANAGER_LOG_MSG(level, format...)
   //#define DEVICE_MANAGER_LOG_MSG ISMD_LOG_MSG
#endif


/* Maximum number of devices suppored by the system. */
#define MAX_DEV_CONTEXTS 128


/* Structure for the internal context associated with a device handle */
typedef struct device_context_s {
   struct device_context_s *next;      /* Next node in the list. */
   ismd_dev_t               handle;    /* Handle value. */
   bool                     in_use;    /* Flag for in-use or free */
   uint32_t                 user_data; /* Module-assigned context information. */
   ismd_dev_ops_t           ops;       /* Module-assigned device operations. */
   os_mutex_t                lock;      /* Lock for thread synchronization. */
} device_context_t;


/* Structure for the list of free device contexts. */
typedef struct device_list_s {
   device_context_t *head;
   device_context_t *tail;
   os_mutex_t lock;
} context_list_t;


/******************************* Local Data **********************************/


/* Statically allocated pool of device contexts. */
static device_context_t device_contexts[MAX_DEV_CONTEXTS];

/* List of the unallocated device contexts. */
static context_list_t device_free_list;



/********************* Local Functions Declarations **************************/

static device_context_t *lookup_device( ismd_dev_t handle );
static device_context_t *lookup_and_lock_device( ismd_dev_t handle );
static void lock_device( device_context_t *context );
static void unlock_device( device_context_t *context );
static void init_device_context( device_context_t *context );
static void list_init( context_list_t *list );
static void list_deinit( context_list_t *list);
static void device_list_add( context_list_t   *list, 
                             device_context_t *context );
static device_context_t *device_list_remove( context_list_t *list );


/* ****************************************************************************
 * SMD Core Private Function Definitions. These functions are callable by 
 * only the SMD Core itself.
 */


/* 
 * Initialize the Device Manager.  Allocate all resources needed by the 
 * Device manager.  Must be called before any other Device Manager APIs 
 * are called (i.e. module init, library load, etc.).
 */
ismd_result_t ismd_device_manager_init( void )
{
   ismd_dev_t handle;
   device_context_t *context;
   osal_result os_result;
   ismd_result_t result = ISMD_SUCCESS;

   list_init( &device_free_list ); 

   /*
    * For every statically allocated context, initialize it an add it 
    * to the free list.
    */
   for ( handle = 0; handle < MAX_DEV_CONTEXTS; handle++ ) {
      context = lookup_device( handle ); 
      /* No need to check for NULL because this can't fail. */

      os_result = os_mutex_init( &context->lock );

      /* 
       * We're going to assert the success of the semaphore initialization 
       * because if it fails, it means the OSAL is unstable and we probably 
       * can't trust any of the semaphore functions.
       */
      OS_ASSERT( os_result == OSAL_SUCCESS );

      init_device_context( context );
      context->handle = handle;
      device_list_add( &device_free_list, context );
   }

   return ( result );
}


/* 
 * Deinitialize the Device Manager.  Frees all resources allocated by the 
 * device manager.  Should be called during module-exit or library-unload.
 */
ismd_result_t ismd_device_manager_deinit( void )
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_dev_t handle;
   device_context_t *context;

   for ( handle = 0; handle < MAX_DEV_CONTEXTS; handle++ ) {
      ismd_dev_handle_free( handle );
      context = lookup_device( handle );
      os_mutex_destroy( &context->lock );
   }

   list_deinit( &device_free_list );

   return ( result );
}


/* ****************************************************************************
 * SMD Protected Function Definitions. These functions are documented in 
 * ismd_core_protected.h and only other SMD modules are allowed call them.
 */


ismd_result_t ismd_dev_handle_alloc( ismd_dev_ops_t dev_ops,
                                     ismd_dev_t    *handle )
{
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;
   device_context_t *context;

   /* Get an unallocated context from the free list. */
   context = device_list_remove( &device_free_list );

   if ( context != NULL ) {
      lock_device( context );

      /* We should never get a context from the free list that's already in-use. */
      OS_ASSERT( !context->in_use );

      context->in_use            = true;
      context->ops.close         = dev_ops.close;
      context->ops.flush         = dev_ops.flush;
      context->ops.set_state     = dev_ops.set_state;
      context->ops.set_clock     = dev_ops.set_clock;
      context->ops.set_base_time = dev_ops.set_base_time;
      context->ops.set_play_rate = dev_ops.set_play_rate;
      context->ops.set_underrun_event = dev_ops.set_underrun_event;
      context->ops.get_underrun_amount = dev_ops.get_underrun_amount;
      context->ops.get_state     = dev_ops.get_state;
      context->ops.get_base_time = dev_ops.get_base_time;
      context->ops.get_play_rate = dev_ops.get_play_rate;
      context->ops.set_slave_clock = dev_ops.set_slave_clock;
      *handle = context->handle;
      result = ISMD_SUCCESS;
      DEVICE_MANAGER_TRACE( context->handle, ISMD_CORE_TRACE_DEVICE_ALLOC, result);
      DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_handle_alloc() : allocated device handle %d.\n", context->handle );
      unlock_device( context );
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_handle_alloc() : out of resources.\n" );
   }

   return ( result );
}


ismd_result_t ismd_dev_handle_free( ismd_dev_t handle )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      init_device_context( context );
      result = ISMD_SUCCESS;
      DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_FREE, result);
      DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_handle_free() : freed device handle %d.\n", handle );
      unlock_device( context );
      /* Put the now-free context onto the free list. */
      device_list_add( &device_free_list, context );
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_handle_free() : invalid device handle %d.\n", handle );
   }

   return result;
}


ismd_result_t ismd_dev_set_user_data( ismd_dev_t handle, 
                                      uint32_t   user_data )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      context->user_data = user_data;
      result = ISMD_SUCCESS;
      DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_SET_USER_DATA, result);
      DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_set_user_data() : device %d user data = %d.\n", handle, user_data );
      unlock_device( context );
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_user_data() : invalid device handle %d.\n", handle );
   }

   return result;
}


ismd_result_t ismd_dev_get_user_data( ismd_dev_t handle, 
                                      uint32_t  *user_data )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   
   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      *user_data = context->user_data;
      result = ISMD_SUCCESS;
      DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_GET_USER_DATA, result);
      DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_get_user_data() : device %d user data = %d.\n", handle, *user_data );
      unlock_device( context );
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_get_user_data() : invalid device handle %d.\n", handle );
   }

   return result;
}


/* ****************************************************************************
 * SMD Public API Function Definitions. These functions are documented in 
 * ismd_core.h and may be called by user/client applications or other SMD 
 * modules.
 */

ismd_result_t ismd_dev_close( ismd_dev_t handle )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_close_func_t close_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      close_func = context->ops.close;
      unlock_device( context );
      if ( close_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_close() : calling close function 0x%08X for device handle %d.\n", (uint32_t)(close_func), handle );
         result = close_func( handle );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_close() : no close function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_close() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_CLOSE, result);

   return ( result );
}


ismd_result_t ismd_dev_flush( ismd_dev_t   handle  )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_flush_func_t flush_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      flush_func = context->ops.flush;
      unlock_device( context );
      if ( flush_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_flush() : calling flush function 0x%08X for device handle %d.\n", (uint32_t)(flush_func), handle );
         result = flush_func( handle);//hh remove another two parameters:, true, ISMD_EVENT_HANDLE_INVALID 
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_flush() : no flush function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_flush() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_FLUSH, result);

   return ( result );
}


ismd_result_t ismd_dev_set_state( ismd_dev_t        handle, 
                                  ismd_dev_state_t  state )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_set_state_func_t set_state_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      set_state_func = context->ops.set_state;
      unlock_device( context );
      if ( set_state_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_set_state() : calling set_state function 0x%08X for device handle %d.\n", (uint32_t)(set_state_func), handle );
         result = set_state_func( handle, state );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_state() : no set_state function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_state() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_SET_STATE, result);

   return ( result );
}

ismd_result_t ismd_dev_get_state( ismd_dev_t        handle, 
                                  ismd_dev_state_t  *state )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_get_state_func_t get_state_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      get_state_func = context->ops.get_state;
      unlock_device( context );
      if ( get_state_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_get_state() : calling get_state function 0x%08X for device handle %d.\n", (uint32_t)(get_state_func), handle );
         result = get_state_func( handle, state );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_get_state() : no get_state function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_get_state() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_SET_STATE, result);

   return ( result );
}

ismd_result_t ismd_dev_set_clock( ismd_dev_t   handle, 
                                  ismd_clock_t clock )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_set_clock_func_t set_clock_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      set_clock_func = context->ops.set_clock;
      unlock_device( context ); 
	  if ( set_clock_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_set_clock() : calling set_clock function 0x%08X for device handle %d.\n", (uint32_t)(set_clock_func), handle );
         result = set_clock_func( handle, clock );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_clock() : no set_clock function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
      
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_clock() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_SET_CLOCK, result);

   return ( result );
}

ismd_result_t ismd_dev_set_slave_clock( ismd_dev_t   handle, 
                                               ismd_clock_t clock )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_set_slave_clock_func_t set_slave_clock_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      set_slave_clock_func = context->ops.set_slave_clock;
      unlock_device( context ); 
	  if ( set_slave_clock_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_set_slave_clock() : calling set_slave_clock function 0x%08X for device handle %d.\n", (uint32_t)(set_slave_clock_func), handle );
         result = set_slave_clock_func( handle, clock );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_slave_clock() : no set_slave_clock function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
      
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_slave_clock() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_SET_SLAVE_CLOCK, result);

   return ( result );
}

ismd_result_t ismd_dev_set_stream_base_time( ismd_dev_t  handle, 
                                             ismd_time_t time )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_set_base_time_func_t set_base_time_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      set_base_time_func = context->ops.set_base_time;
	  unlock_device( context );
      if ( set_base_time_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_set_base_time() : calling set_base_time function 0x%08X for device handle %d.\n", (uint32_t)(set_base_time_func), handle );
         result = set_base_time_func( handle, time );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_base_time() : no set_base_time function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
      

   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_base_time() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_SET_BASE_TIME, result);

   return ( result );
}

ismd_result_t ismd_dev_get_stream_base_time( ismd_dev_t  handle, 
                                             ismd_time_t *time )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_get_base_time_func_t get_base_time_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      get_base_time_func = context->ops.get_base_time;
	  unlock_device( context );
      if ( get_base_time_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_get_base_time() : calling get_base_time function 0x%08X for device handle %d.\n", (uint32_t)(get_base_time_func), handle );
         result = get_base_time_func( handle, time );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_get_base_time() : no get_base_time function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
      

   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_get_base_time() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE( handle, ISMD_CORE_TRACE_DEVICE_SET_BASE_TIME, result);

   return ( result );
}

ismd_result_t ismd_dev_set_play_rate(ismd_dev_t handle, 
                                     ismd_pts_t current_linear_time,
                                     int        rate)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_set_play_rate_func_t set_play_rate_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      set_play_rate_func = context->ops.set_play_rate;
	   unlock_device( context );
      if (set_play_rate_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_set_play_rate() : calling set_play_rate function 0x%08X for device handle %d.\n", (uint32_t)(set_play_rate_func), handle );
         result = set_play_rate_func( handle, current_linear_time, rate );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_play_rate() : no set_play_rate function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_play_rate() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE(handle, ISMD_CORE_TRACE_DEVICE_SET_PLAY_RATE, result);

   return (result);
} // ismd_dev_set_play_rate

ismd_result_t ismd_dev_get_play_rate(ismd_dev_t handle, 
                                     int        *rate)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_get_play_rate_func_t get_play_rate_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      get_play_rate_func = context->ops.get_play_rate;
	   unlock_device( context );
      if (get_play_rate_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_get_play_rate() : calling get_play_rate function 0x%08X for device handle %d.\n", (uint32_t)(get_play_rate_func), handle );
         result = get_play_rate_func( handle, rate );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_get_play_rate() : no get_play_rate function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_get_play_rate() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE(handle, ISMD_CORE_TRACE_DEVICE_SET_PLAY_RATE, result);

   return (result);
} // ismd_dev_get_play_rate

ismd_result_t ismd_dev_set_underrun_event(ismd_dev_t handle, 
                                          ismd_event_t underrun_event)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_set_underrun_event_func_t set_underrun_event_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      set_underrun_event_func = context->ops.set_underrun_event;
      unlock_device( context );
      if (set_underrun_event_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_set_underrun_event() : calling set_underrun_event function 0x%08X for device handle %d.\n", (uint32_t)(set_underrun_event_func), handle );
         result = set_underrun_event_func( handle, underrun_event );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_underrun_event() : no set_underrun_event function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_set_underrun_event() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE(handle, ISMD_CORE_TRACE_DEVICE_SET_UNDERRUN_EVENT, result);

   return (result);
}

ismd_result_t ismd_dev_get_underrun_amount(ismd_dev_t handle, 
                                           ismd_time_t *underrun_amount)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   device_context_t *context;
   ismd_dev_get_underrun_amount_func_t get_underrun_amount_func;

   context = lookup_and_lock_device( handle );
   if ( context != NULL ) {
      get_underrun_amount_func = context->ops.get_underrun_amount;
      unlock_device( context );
      if (get_underrun_amount_func != NULL ) {
         DEVICE_MANAGER_LOG_MSG( 3, "ismd_dev_get_underrun_amount() : calling get_underrun_amount function 0x%08X for device handle %d.\n", (uint32_t)(get_underrun_amount_func), handle );
         result = get_underrun_amount_func( handle, underrun_amount );
      }
      else {
         DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_get_underrun_amount() : no get_underrun_amount function registered for device handle %d.\n", handle );
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      }
   }
   else {
      DEVICE_MANAGER_LOG_MSG( 2, "ismd_dev_get_underrun_amount() : invalid device handle %d.\n", handle );
   }

   DEVICE_MANAGER_TRACE(handle, ISMD_CORE_TRACE_DEVICE_GET_UNDERRUN_AMOUNT, result);

   return (result);
}




/* ****************************************************************************
 * Device Manager local function definitions. These functions are unique helper 
 * functions for the device manager.
 */


/*
 * Lookup a device handle.  Given a device handle, return a pointer to its 
 * context structure.  If the device handle is not valid, the function return 
 * value is NULL.
 */
static device_context_t *lookup_device( ismd_dev_t handle )
{
   device_context_t *context = NULL;

   if ( handle >= 0 && handle < MAX_DEV_CONTEXTS ) {
      context = &(device_contexts[handle]);
   }

   return ( context );
}


/*
 * Lookup a device handle and lock it's context.  Given a device handle, return 
 * a pointer to its context structure and lock the structure.  If the device 
 * handle is not valid or not in_use, no lock is performed and the function 
 * return value is NULL.
 */
static device_context_t *lookup_and_lock_device( ismd_dev_t handle )
{
   device_context_t *context;

   context = lookup_device( handle );
   if ( context != NULL ) {
      lock_device( context );
      if ( !(context->in_use) ) {
         unlock_device( context );
         context = NULL;
      }
   }

   return ( context );
}


/*
 * Lock a device context.
 */
static void lock_device( device_context_t *context )
{
   os_mutex_lock( &(context->lock) );
}


/*
 * Unlock a device context.
 */
static void unlock_device( device_context_t *context )
{
   os_mutex_unlock( &(context->lock) );
}


/*
 * Initialize a device context.
 */
static void init_device_context( device_context_t *context )
{
   context->in_use            = false;
   context->user_data         = 0;
   context->ops.close         = NULL;
   context->ops.flush         = NULL;
   context->ops.set_state     = NULL;
   context->ops.set_clock     = NULL;
   context->ops.set_base_time = NULL;
   context->ops.set_play_rate = NULL;
   context->ops.set_underrun_event  = NULL;
   context->ops.get_underrun_amount = NULL;
   context->ops.get_state     = NULL;
   context->ops.get_base_time = NULL;
   context->ops.get_play_rate = NULL;
   context->ops.set_slave_clock = NULL;
}


/*
 * Initialize the list of free device contexts.
 */
static void list_init( context_list_t *list )
{
   osal_result os_result;
   
   list->head = NULL;
   list->tail = NULL;

   os_result = os_mutex_init( &(list->lock) );

   /* 
    * We're going to assert the success of the semaphore initialization 
    * because if it fails, it means the OSAL is unstable and we probably 
    * can't trust any of the semaphore functions.
    */
   OS_ASSERT( os_result == OSAL_SUCCESS );
}


/*
 * Deinitialize the list of free device contexts.
 */
static void list_deinit( context_list_t *list )
{
   os_mutex_destroy( &(list->lock) );
}


/*
 * Add a device context to the end of the list of free device contexts.
 */
static void device_list_add( context_list_t *list, device_context_t *context )
{
   os_mutex_lock( &(list->lock) );

   /* We should never try to add an allocated context to the free list */
   OS_ASSERT( !(context->in_use) );

   if ( list->tail == NULL ) {
      list->head = context;
   }
   else {
      (list->tail)->next = context;
   }

   list->tail = context;
   context->next = NULL;

   os_mutex_unlock( &(list->lock) );
}


/*
 * Remove the device context at the front of the list of free device contexts. 
 */
static device_context_t *device_list_remove( context_list_t *list )
{
   device_context_t *context;

   os_mutex_lock( &(list->lock) );

   context = list->head;

   if ( context != NULL ) {
      list->head = context->next;

      if ( list->head == NULL ) {
         list->tail = NULL;
      }
   }

   os_mutex_unlock( &(list->lock) );   

   return ( context );
}
