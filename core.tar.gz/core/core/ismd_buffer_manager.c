/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core.h"
#include "ismd_core_protected.h"
#include "smd_core_local_defs.h"
#include "ismd_msg.h"
#include "phash.h"

#define ISMD_BUFFER_SIZE_NONE  0      /*  0 Bytes (for allocating descriptors only) */
#define ISMD_BUFFER_SIZE_TYPE1 0x0400 /*  1K Bytes, used by TSD/App for PSI */
#define ISMD_BUFFER_SIZE_TYPE2 0x2000 /*  8K Bytes, used by TSD/Audio */
#define ISMD_BUFFER_SIZE_TYPE3 0x10000 /* 64K Bytes, used internally by Audio */
#define ISMD_BUFFER_SIZE_TYPE4 0x8000 /* 32K Bytes, used by TSD/Video decoders */
#define ISMD_BUFFER_SIZE_ALL   -1     /* All other buffer sizes. */
#define ISMD_BUFFER_ENABLE_SVEN       /* Comment out to disable SVEN messages */
#define TYPICAL_BUF_SIZE_RANGE_MIN 0X400
#define TYPICAL_BUF_SIZE_RANGE_MAX 0x800000 
#define IGNORE_PMR_MODE 0

extern int ismd_debug_level;

#define ISPWROF2(n) ( (n!=0) && !(n&(n-1)) )
#define FREE_LIST_KEY(pmr, type, size) ( (pmr<<27) | ((type<<23) & 0x07800000) | (size & 0x007fffff) ) 
#ifdef ISMD_BUFFER_ENABLE_SVEN
   #define SMD_BUFFER_SVEN_EVENT(msg, a1, a2, a3, a4, a5, a6) smd_core_send_sven_event(SMD_CORE_DEBUG_UNIT_BUFFER, msg, a1, a2, a3, a4, a5, a6)
#else
   #define SMD_BUFFER_SVEN_EVENT(msg, a1, a2, a3, a4, a5, a6) // Do nothing
#endif

#ifdef __KERNEL__
   #define CURRENT_THREAD_ID current->tgid
#else
   #define CURRENT_THREAD_ID 0
#endif

/* Define structure to track all of the physical mappings that were made during init. */
/* This is used to clean up those mappings on de-init */
#define MAX_ALLOWED_LAYOUT_ENTRIES 128
typedef struct {
   void *virt_base;
   size_t size;
   bool used;
} core_virt_mapping_t;
core_virt_mapping_t core_mappings[MAX_ALLOWED_LAYOUT_ENTRIES];

typedef struct {
    ismd_buffer_descriptor_t *head;
    ismd_buffer_descriptor_t *tail;
    uint8_t lock[sizeof(os_mutex_t)]; /* This should be defined as "os_mutex_t lock;" but this definition allows a static initializer. */
    ismd_buffer_type_t        type;
    int                       size;
    int                       pmr;
} ismd_buffer_list_t;



static
ismd_buffer_list_t free_buffer_lists[PHASHRANGE];

ismd_buffer_list_t alias_buffer_list =
{NULL, NULL, {0}, ISMD_BUFFER_TYPE_INVALID, ISMD_BUFFER_SIZE_NONE, ISMD_PMR_NONE };


#define PACK_BUFFER_HANDLE(packed_handle, base_handle, version_id)               \
   ((packed_handle) = ((base_handle) | ((version_id) << 16)))

#define INC_BUFFER_VER(packed_handle)                                            \
{                                                                                \
   unsigned int base_handle, version_id;                                         \
   UNPACK_BUFFER_HANDLE(packed_handle, base_handle, version_id);                 \
   version_id = (version_id + 1) & 0xFFFF;                                       \
   PACK_BUFFER_HANDLE(packed_handle, base_handle, version_id);                   \
}

static int track_buffer_size = -1;

static bool ismd_buffer_manager_initialized = false;

/* Association table for aliased buffers.  For each aliased buffer, stores the handle of the buffer used to create the alias */
/* This is inefficient as it doesn't need to be so large, but making it this size makes indexing into the table really simple
   (use the alias buffer id as an index) */
static ismd_buffer_handle_t alias_association_table[ISMD_MAX_BUFFER_DESCRIPTORS];

/* Variables used to know which buffer IDs belong to the aliased buffer list. */
static unsigned int index_of_first_alias_buffer = 0xffffffff;
static unsigned int index_of_last_alias_buffer = 0xffffffff;


ismd_buffer_descriptor_t buffer_descriptors[ISMD_MAX_BUFFER_DESCRIPTORS];

// used to track core statistics globally.
ismd_core_statistics_t g_core_statistics;

ismd_result_t ismd_buffer_reclaim( void *context, ismd_buffer_descriptor_t *buffer  );


static void buffer_list_lock( ismd_buffer_list_t *list );
static void buffer_list_unlock( ismd_buffer_list_t *list );
static ismd_buffer_list_t *find_buffer_list(unsigned int buffer_id, ismd_buffer_type_t type, int size, unsigned int pmr );
static ismd_result_t track_virtual_mapping(void *base, size_t size);
static void free_all_virtual_mappings(void);


#define TRACK_BUFFER(operation,descriptor,cond) if ((cond) && ((descriptor)->phys.size==track_buffer_size)) OS_INFO("%s:%d\n", (operation), (descriptor)->unique_id)

static ismd_result_t ismd_process_memory_layout( void );

#define ALLOC_ERROR_EVENT_COUNT 16

static ismd_event_t alloc_error_events[ALLOC_ERROR_EVENT_COUNT];
  
#define MAX_TYPES    6
#define MAX_SIZE     0x400000
#define MINIMUM_SIZE 0x400
#define MAX_PMRS     10
#define CUSTOM_BUFFER_SIZE 0xffffffff


static ismd_result_t
init_buffer_list( ismd_buffer_list_t *buf_list )
{
   ismd_result_t result = ISMD_SUCCESS;
   
   if( buf_list != NULL )
   {
      buf_list->head = NULL;
      buf_list->tail = NULL;
      OS_MEMSET( buf_list->lock, 0, sizeof(os_mutex_t) );
      buf_list->type = ISMD_BUFFER_TYPE_INVALID;
      buf_list->size = ISMD_BUFFER_SIZE_ALL;
      buf_list->pmr  = ISMD_PMR_NONE;
      
      os_mutex_init( (os_mutex_t *)buf_list->lock);
   }
   else
   {
      result = ISMD_ERROR_NULL_POINTER;
      ISMD_LOG_MSG( 0, "Pointer to buffer list is NULL\n");
   }
   
   return result;
}


/* 
   1. Generate a set of (32 bit) keys to be used in looking up buffer lists.
      Finding a buffer list depends upon:
        - pmr
        - type
        - size
   2. Use each key to generate (hash) an array index into free_buffer_lists[]
   3. Initialize the buffer list at each array index
*/
static
void init_free_buffer_index( void )
{
   
   unsigned int bsize=0, btype=1;
   int pmr = -1;
   unsigned int key=0;      
   int count=0;
   unsigned int free_list_index;
   ismd_buffer_list_t *buf_list = NULL;   

  
   // The initial values of pmr = -1, type = 1 and size = 0 represent a special
   // key not represented in the nested loops below, so we make it here
      
   key = FREE_LIST_KEY( pmr, btype, bsize ) ;
   if( PHASHRANGE < ( free_list_index = phash( key )) )
   {
      ISMD_LOG_MSG( 0, "Error: key %08X yeilds an illegal index: %08X\n",key, free_list_index );
   }
   else
   {
      
      buf_list = &free_buffer_lists[free_list_index];                   
      init_buffer_list( buf_list );  
      buf_list->type = btype;
      buf_list->size = bsize;
      buf_list->pmr  = pmr;
      count++;
   }
    
               
   // For each combination of pmr, type and size, generate a 32 bit key
   for( pmr=-1; pmr<MAX_PMRS; pmr++ )
   {
      for( btype=1; btype<MAX_TYPES; btype++ )
      {

         for( bsize=MINIMUM_SIZE; bsize<=MAX_SIZE; bsize<<=1 )
         {       

            if( bsize == MAX_SIZE )
            {
               // Build a special key with size not a power of 2, that signifies the
               // "catch all" bucket that will hold any custom (user defined) buffer sizes.
               // There will be one such bucket for each pmr/type combination.
               bsize = CUSTOM_BUFFER_SIZE;
            }
        
           
            key = FREE_LIST_KEY( pmr, btype, bsize ) ;
            if( PHASHRANGE < ( free_list_index = phash( key )) )
            {
               ISMD_LOG_MSG( 0, "Error: key %08X yeilds an illegal index: %08X\n",key, free_list_index );
            }
            else
            {
             
               buf_list = &free_buffer_lists[free_list_index];                   
               init_buffer_list( buf_list );  
               buf_list->type = btype;
               buf_list->size = bsize;
               buf_list->pmr  = pmr;
               count++;
            }
         }           
      }
   }   
   
   ISMD_LOG_MSG( 0,"Initialized %d buffer lists. \n", count );      
}

ismd_result_t ismd_buffer_manager_init(void)
{
   ismd_result_t             result = ISMD_SUCCESS;
   ismd_buffer_descriptor_t *buffer_desc = NULL;
   ismd_buffer_descriptor_t *prev = NULL;
   ismd_buffer_list_t       *buffer_list;
   int i;

   ISMD_LOG_MSG( 4, "ismd_buffer_manager_init(): entering function.\n" );

   if ( ismd_buffer_manager_initialized == true ) {
      result = ISMD_ERROR_ALREADY_INITIALIZED;
      ISMD_LOG_MSG( 1, "ismd_buffer_manager_init(): warning: buffer manager already initialized.\n" );
   }
   else {

      /*
       * Initialize module glolbals.
       */
      ismd_buffer_manager_initialized = true;
      
      // Initialize buffer lists
      init_free_buffer_index();      

      alias_buffer_list.head = NULL;
      alias_buffer_list.tail = NULL;

      index_of_first_alias_buffer = 0xffffffff;
      index_of_last_alias_buffer = 0xffffffff;

      /* clear the allocation error events */
      {
         unsigned event_num;
         for (event_num = 0; event_num < ALLOC_ERROR_EVENT_COUNT; event_num++) {
            alloc_error_events[event_num] = ISMD_EVENT_HANDLE_INVALID;
         }
      }

      /*
       * Initialize all of the available buffer descriptors and build a linked
       * list of free buffer descriptors.
       * Passing in -1 for the buffer number because we don't have one
       */
      buffer_list = find_buffer_list( ISMD_BUFFER_HANDLE_INVALID, ISMD_BUFFER_TYPE_PHYS, 0, ISMD_PMR_NONE);
      prev = NULL;
      for ( i = 0; i < ISMD_MAX_BUFFER_DESCRIPTORS; i++ ) {
         buffer_desc = &(buffer_descriptors[i]);

         buffer_desc->buffer_type      = ISMD_BUFFER_TYPE_PHYS;
         buffer_desc->phys.base        = 0;
         buffer_desc->phys.size        = 0;
         buffer_desc->phys.level       = 0;
         buffer_desc->phys.next_node   = NULL;

         buffer_desc->unique_id        = i;
         buffer_desc->next             = NULL;
         buffer_desc->reference_count  = 0;
         buffer_desc->release_function = (ismd_release_func_t)ismd_buffer_reclaim;
         buffer_desc->release_context  = NULL;
         buffer_desc->state            = ISMD_BUFFER_STATE_FREE;
         buffer_desc->tags_present     = 0;
         buffer_desc->pmr              = ISMD_PMR_NONE;

         if (prev == NULL) {
            buffer_list->head = buffer_desc;
         }
         else {
            prev->next = buffer_desc;
         }
         prev = buffer_desc;
      }
      buffer_list->tail = buffer_desc;

      g_core_statistics.fb_stats.total_fb_regions     = 0;
      g_core_statistics.fb_stats.allocated_fb_regions = 0;
      g_core_statistics.fb_stats.fb_regions_size      = 0;

      result = ismd_frame_buffer_init();
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "ismd_buffer_manager_init(): warning: ismd_frame_buffer_init returned %d.\n", result );
      } else {
         result = ismd_buffer_tags_init();
         if (result != ISMD_SUCCESS) {
            ISMD_LOG_MSG( 1, "ismd_buffer_manager_init(): warning: ismd_buffer_tags_init returned %d.\n", result );
         }
      }

      result = ismd_process_memory_layout();

      if (result == ISMD_SUCCESS) {

         /* Now populate the list of aliased buffer descriptors */
         os_mutex_init( (os_mutex_t *)&(alias_buffer_list.lock) );
         alias_buffer_list.type = ISMD_BUFFER_TYPE_INVALID;
         alias_buffer_list.size = ISMD_BUFFER_SIZE_NONE;

         buffer_list = &alias_buffer_list;
         prev = NULL;

         for ( i = 0; i < ISMD_MAX_ALIAS_BUFFERS; i++ ) {

            /* Allocate a descriptor with zero-size buffer. */
            result = ismd_buffer_alloc_typed_pmr_direct( ISMD_BUFFER_TYPE_PHYS, 0, &buffer_desc, ISMD_PMR_NONE );
            if ( result == ISMD_SUCCESS ) {
               if (index_of_first_alias_buffer == 0xffffffff) {
                  index_of_first_alias_buffer = BUFFER_HANDLE_INDEX(buffer_desc->unique_id);
               }

               /* Modify the descriptor with invalid information. */
               buffer_desc->buffer_type    = ISMD_BUFFER_TYPE_INVALID;
               buffer_desc->phys.base      = 0;
               buffer_desc->phys.size      = ISMD_BUFFER_SIZE_NONE;
               buffer_desc->phys.level     = 0;
               buffer_desc->phys.next_node = NULL;
               buffer_desc->virt.base      = 0;
               buffer_desc->pmr            = ISMD_PMR_NONE;
               if (prev == NULL) {
                  alias_buffer_list.head = buffer_desc;
               }
               else {
                  prev->next = buffer_desc;
               }
               prev = buffer_desc;
            }
         }
         alias_buffer_list.tail = buffer_desc;
         index_of_last_alias_buffer = BUFFER_HANDLE_INDEX(buffer_desc->unique_id);
      } else {
         ismd_buffer_manager_deinit();
      }
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_manager_init(): exiting function.\n" );
   return ( result );
}


ismd_result_t ismd_buffer_manager_deinit(void) {
   ismd_result_t             result = ISMD_SUCCESS;

   ismd_buffer_manager_initialized = false;

   ismd_frame_buffer_deinit();
   ismd_buffer_tags_deinit();

   free_all_virtual_mappings();

   // TODO: Free the locks

   return ( result );
}

// this is a client-exposed interface.
// See function header comment in ismd_core.h
ismd_result_t ismd_core_get_statistics(ismd_core_statistics_t *stat )
{
   ismd_result_t  result = ISMD_SUCCESS;
   if (stat == NULL) {
      result = ISMD_ERROR_NULL_POINTER;
   } else {
      OS_MEMCPY(stat, &g_core_statistics, sizeof(ismd_core_statistics_t));
   }
   return result;
}

ismd_result_t 
ismd_buffer_create_internal( ismd_physical_address_t physical_address,
                                  ismd_buffer_type_t      type,
                                  int                     size,
                                  int                     pmr,
                                  void                   *kernel_virt_address)
{

   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_buffer_descriptor_t *buffer_desc;

   ISMD_LOG_MSG( 4, "ismd_buffer_create_internal() : entering function.\r\n" );

   if ( ismd_buffer_manager_initialized == false ) {
      result = ISMD_ERROR_UNSPECIFIED;
   }
   else {
      /* Allocate a descriptor with zero-size buffer. */
      result = ismd_buffer_alloc_typed_pmr_direct( ISMD_BUFFER_TYPE_PHYS, 0, &buffer_desc, ISMD_PMR_NONE );
      if ( result == ISMD_SUCCESS ) {

         /* Modify the descriptor with the new physical buffer information. */
         buffer_desc->buffer_type    = type;
         buffer_desc->phys.base      = physical_address;
         buffer_desc->phys.size      = size;
         buffer_desc->phys.level     = 0;
         buffer_desc->phys.next_node = NULL;
         buffer_desc->pmr            = pmr;

         buffer_desc->virt.base      = kernel_virt_address;

         ISMD_LOG_MSG( 3, "ismd_buffer_create() : created buf %d, phys=0x%08X, virt=0x%08X, type=%d size=%d pmr=%d.\r\n",
                       buffer_desc->unique_id,
                       physical_address,
                       (uint32_t)kernel_virt_address,
                       type,
                       size,
                       pmr );
                       

         // Track total fb regions for core_statistics
         if(ISMD_BUFFER_TYPE_VIDEO_FRAME_REGION == buffer_desc->buffer_type) {
            g_core_statistics.fb_stats.total_fb_regions++;
            g_core_statistics.fb_stats.allocated_fb_regions++;  // inc because we are about to call free...
         }

         /* Return the buffer to the free list with it's new type, address and size. */
         result = ismd_buffer_free( buffer_desc->unique_id );
      }
   }

   TRACK_BUFFER( "create", buffer_desc, result==ISMD_SUCCESS );

   ISMD_LOG_MSG( 4, "ismd_buffer_create() : exiting function.\r\n" );

   return (result);
}

ismd_result_t ismd_buffer_create( ismd_physical_address_t physical_address,
                                  ismd_buffer_type_t      type,
                                  int                     size,
                                  void                   *kernel_virt_address)
{
   return ismd_buffer_create_internal( physical_address, type, size, ISMD_PMR_NONE, kernel_virt_address );
   
}

ismd_result_t ismd_buffer_create_multiple( ismd_buffer_type_t      buffer_type,
                                           unsigned int            buffer_size,
                                           int                     pmr,
                                           ismd_physical_address_t physical_address,
                                           unsigned int            region_size )
{
   ismd_result_t result = ISMD_SUCCESS;
   void *virt_base;
   ismd_physical_address_t physical_base;


   ISMD_LOG_MSG( 4, "ismd_buffer_create_multiple() : entering function.\r\n" );

   if ( ismd_buffer_manager_initialized == false ) {
      result = ISMD_ERROR_UNSPECIFIED;
   } else {

      physical_base = physical_address;

      if ( buffer_type == ISMD_BUFFER_TYPE_PHYS_CACHED ) {
         virt_base = OS_MAP_IO_TO_MEM_CACHE(physical_address, region_size);
      }
      else {
         virt_base = OS_MAP_IO_TO_MEM_NOCACHE(physical_address, region_size);
      }
      if ( virt_base == NULL ) {
         ISMD_LOG_MSG( 4, "ismd_buffer_create_multiple(): error: unable to map buffer.\r\n" );
         result = ISMD_ERROR_NO_RESOURCES;
      }
      else {
         track_virtual_mapping(virt_base, region_size);

         while ( region_size >= buffer_size ) {

            result = ismd_buffer_create_internal( physical_address,
                                         buffer_type,
                                         (int)buffer_size,
                                         pmr,
                                         (uint8_t *)virt_base + (physical_address - physical_base));

            if ( result != ISMD_SUCCESS ) {
               break;
            }

            physical_address += (uint32_t)buffer_size;
            region_size -= buffer_size;
         }
      }
   }

   if ( ISMD_SUCCESS != result ) {
      OS_PRINT("%s:%s:%d: result %d\n", __FILE__, __func__, __LINE__, result );
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_create_multiple() : exiting function.\r\n" );

   return ( result );

}

// called by the buffer manager to indicate a buffer allocation failed
static void
ismd_signal_alloc_error(void) {
   unsigned event_num;
   ismd_event_t event;
   for (event_num = 0; event_num < ALLOC_ERROR_EVENT_COUNT; event_num++) {
      event = alloc_error_events[event_num];
      if (ISMD_EVENT_HANDLE_INVALID != event) {

         /* erase event on failure to prevent repeated errors */
         if (ISMD_SUCCESS != ismd_event_strobe(event)) {
            alloc_error_events[event_num] = ISMD_EVENT_HANDLE_INVALID;
         }
      }
   }
}

/* This does direct pointer allocation, and cannot be used across marshalling 
 * boundaries but is faster for local core access as it does not need to copy 
 * the descriptor.
 */
ismd_result_t ismd_buffer_alloc_typed_direct( ismd_buffer_type_t         type,
                                              size_t                     size,
                                              ismd_buffer_descriptor_t **buffer_descriptor)
{

   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;

   ISMD_LOG_MSG( 4, "ismd_buffer_alloc_typed_direct(): entering function.\n" );
   
   result = ismd_buffer_alloc_typed_pmr_direct(type, size, buffer_descriptor, ISMD_PMR_NONE);

   return ( result );

}


ismd_result_t ismd_buffer_alloc_typed_pmr_direct( ismd_buffer_type_t         type,
                                                  size_t                     size,
                                                  ismd_buffer_descriptor_t **buffer_descriptor,
                                                  int                        pmr )
{

   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;
   ismd_buffer_descriptor_t *temp;
   ismd_buffer_descriptor_t *prev;
   ismd_buffer_list_t       *buffer_list;

   ISMD_LOG_MSG( 4, "ismd_buffer_alloc_typed_pmr_direct(): entering function.\n" );

   if ( ismd_buffer_manager_initialized == false ) {
      result = ISMD_ERROR_UNSPECIFIED;
   } else {

      /* Search for the list of appropriate-size buffers. */
      /* Passing in an invalid buffer number (-1) because we don't know the buffer number) */

      buffer_list = find_buffer_list(ISMD_BUFFER_HANDLE_INVALID, type, size, pmr );    
      OS_ASSERT(buffer_list != NULL);

      buffer_list_lock( buffer_list );

      prev = NULL;
      temp = buffer_list->head;
      while ( temp != NULL ) {

          if(type == ISMD_BUFFER_TYPE_ALIAS && 
             temp->phys.size == (int)size) {
                break;             
          } else {
             if ( temp->phys.size == (int)size &&
                temp->pmr == pmr && temp->buffer_type == type ) {
                break;
             }
          }
          prev = temp;
          temp = temp->next;
      }   

      // Remove the newly found descriptor from the free list
      if ( temp != NULL ) {
         if ( prev == NULL ) {
            buffer_list->head = temp->next;
         }
         else {
            prev->next = temp->next;
         }
         if ( buffer_list->head == NULL ) {
            buffer_list->tail = NULL;
         }
         else if ( buffer_list->tail == temp ) {
            buffer_list->tail = prev;
         }

         temp->next = NULL;
         temp->reference_count = 1;
         temp->release_function = (ismd_release_func_t)ismd_buffer_reclaim;
         temp->release_context = NULL;
         temp->state = ISMD_BUFFER_STATE_ALLOCATED;

         // Clear the buffer's attributes
         OS_MEMSET(temp->attributes, 0, sizeof(temp->attributes));

         INC_BUFFER_VER(temp->unique_id); // Increment the version number, so handles are never recycled.

         *buffer_descriptor = temp;

         result = ISMD_SUCCESS;

         SMD_BUFFER_SVEN_EVENT( SVEN_EV_SMDCore_Buf_Alloc,
                                temp->unique_id,
                                temp->phys.size,
                                temp->phys.base,
                                (unsigned int) temp->virt.base,
                                CURRENT_THREAD_ID,
                                0 );

         ISMD_LOG_MSG( 3, "ismd_buffer_alloc_typed_pmr_direct() : allocated buffer descriptor %d, type=%d, size=%d\n",
                       temp->unique_id,
                       temp->buffer_type,
                       temp->phys.size );

         // Track allocated fb regions for core_statistics
         if(ISMD_BUFFER_TYPE_VIDEO_FRAME_REGION == type) {
            g_core_statistics.fb_stats.allocated_fb_regions++;
         }
      }
      else {
         ismd_signal_alloc_error();
         ISMD_LOG_MSG( 1, "ismd_buffer_alloc_typed_pmr_direct() : no buffers available with type=%d and size=%d and pmr=%d.\n", type, size, pmr);
         SMD_BUFFER_SVEN_EVENT( SVEN_EV_SMDCore_Buf_Unavail,
                                type,
                                size,
                                0,
                                0,0,0);
      }

      buffer_list_unlock( buffer_list );

      TRACK_BUFFER( "alloc", *buffer_descriptor, result==ISMD_SUCCESS );
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_alloc_typed_pmr_direct(): exiting function.\n" );

   return ( result );

}

ismd_result_t ismd_buffer_alloc_typed( ismd_buffer_type_t         type,
                                       size_t                     size,
                                       int                        pmr,                                       
                                       ismd_buffer_handle_t      *buffer)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_descriptor_t *buffer_desc;

   if (buffer == NULL) {
      result = ISMD_ERROR_NULL_POINTER;
   } else {
      
      result = ismd_buffer_alloc_typed_pmr_direct(type, size, &buffer_desc, pmr);
      if (result == ISMD_SUCCESS) {
         *buffer = buffer_desc->unique_id;
      }
   }

   return result;
}

ismd_result_t ismd_buffer_alloc( size_t                     size,
                                 ismd_buffer_handle_t      *buffer )
{
   return ismd_buffer_alloc_typed(ISMD_BUFFER_TYPE_PHYS, size, ISMD_PMR_NONE, buffer );
}


/*
Buffer aliasing - another independant descriptor for the same memory.
Adds to the ref count of the original so it doesn't get freed until
the alias is freed.  uses a lookup table so the original buffer can
be dereferenced when the alias is freed.
*/
ismd_result_t ismd_buffer_alias_subset(
                                       ismd_buffer_handle_t    buffer_to_alias,
                                       size_t                  start_offset,
                                       size_t                  size,
                                       ismd_buffer_handle_t   *alias_buffer) {
   ismd_buffer_descriptor_t *buffer_to_alias_buffer_desc;
   ismd_buffer_descriptor_t *alias_buffer_desc;
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_list_t *buffer_to_alias_buffer_list;

   ISMD_LOG_MSG( 4, "%s() : entering function.\r\n", __FUNCTION__);

   if ( ismd_buffer_manager_initialized == false ) {
      result = ISMD_ERROR_UNSPECIFIED;
   } else {

      result = ismd_buffer_find_descriptor(buffer_to_alias, &buffer_to_alias_buffer_desc);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "%s() : Error: Could not find buffer %d.\r\n", __FUNCTION__, buffer_to_alias );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else if (buffer_to_alias_buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
         ISMD_LOG_MSG( 1, "%s() : Error: buffer %d is not in allocated state.\r\n", __FUNCTION__, buffer_to_alias );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else if (alias_buffer == NULL) {
         ISMD_LOG_MSG( 1, "%s() : Error: alias buffer handle is NULL.\r\n", __FUNCTION__);
         result = ISMD_ERROR_NULL_POINTER;
      } else if (start_offset + size > (size_t)buffer_to_alias_buffer_desc->phys.size) {
         ISMD_LOG_MSG( 1, "%s() : Error: start_offset + size exceeds the original buffer's size.\r\n", __FUNCTION__);
         result = ISMD_ERROR_NULL_POINTER;
      } else {
         TRACK_BUFFER( "alias", buffer_to_alias_buffer_desc, true );

         /* Allocate an alias buffer from the alias buffer list */
         result = ismd_buffer_alloc_typed_pmr_direct(ISMD_BUFFER_TYPE_ALIAS, ISMD_BUFFER_SIZE_NONE, &alias_buffer_desc, ISMD_PMR_NONE);
         if (result != ISMD_SUCCESS) {
            ISMD_LOG_MSG( 1, "%s() : Error: Could not allocate alias buffer.\r\n", __FUNCTION__ );
         } else {
            *alias_buffer = alias_buffer_desc->unique_id;

            /* add a reference to the buffer being aliased */
            buffer_to_alias_buffer_list = find_buffer_list(BUFFER_HANDLE_INDEX(buffer_to_alias_buffer_desc->unique_id),
                                                           buffer_to_alias_buffer_desc->buffer_type,
                                                           buffer_to_alias_buffer_desc->phys.size,
                                                           buffer_to_alias_buffer_desc->pmr);
            buffer_list_lock( buffer_to_alias_buffer_list );
            buffer_to_alias_buffer_desc->reference_count++;
            buffer_list_unlock( buffer_to_alias_buffer_list );

            /* For the alias buffer, note which buffer it was created with (for de-referencing on free) */
            if (BUFFER_HANDLE_INDEX(alias_buffer_desc->unique_id) <
                ISMD_MAX_BUFFER_DESCRIPTORS) {
            alias_association_table[BUFFER_HANDLE_INDEX(alias_buffer_desc->unique_id)] = buffer_to_alias;
            } else {
                /* index into alias_association_table out of range */
                OS_ASSERT(false);
            }

            /* Copy the original buffer descriptor over top of the aliased one, except for the id */
            /* Clear the buffer tags from the aliased buffer */
            buffer_list_lock( &alias_buffer_list );
            OS_MEMCPY(alias_buffer_desc, buffer_to_alias_buffer_desc, sizeof(ismd_buffer_descriptor_t));

            // Update the values...
            if (start_offset > (size_t)buffer_to_alias_buffer_desc->phys.level)
            {
                alias_buffer_desc->phys.level = 0; // alias starts past end of source data
            }
            else if ((start_offset + size) > (size_t)buffer_to_alias_buffer_desc->phys.level)
            {
                alias_buffer_desc->phys.level = buffer_to_alias_buffer_desc->phys.level - start_offset; // alias ends past end of source data
            }
            else
            {
                alias_buffer_desc->phys.level = size; // Alias fully contained in the source buffer
            }

            alias_buffer_desc->unique_id = *alias_buffer;
            alias_buffer_desc->tags_present = 0; /* tags are not copied with memcpy, so make sure this is not set */
            alias_buffer_desc->reference_count = 1;
            alias_buffer_desc->virt.base += start_offset;
            alias_buffer_desc->phys.base += start_offset;
            alias_buffer_desc->phys.size = size;
            buffer_list_unlock( &alias_buffer_list );
         }
      }
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_alias() : exiting function.\r\n" );
   return result;
}

/*
Wrapper of the buffer alias functionality, exposing the simpler API that does
not require knowing the buffer size but does not expose control over obtaining
a sub-region of the buffer.
*/
ismd_result_t ismd_buffer_alias(ismd_buffer_handle_t    buffer_to_alias,
                                ismd_buffer_handle_t   *alias_buffer) {
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_descriptor_t *buffer_to_alias_buffer_desc;

   ISMD_LOG_MSG( 4, "%s() : entering function.\r\n", __FUNCTION__ );

   if ( ismd_buffer_manager_initialized == false ) {
      result = ISMD_ERROR_UNSPECIFIED;
   } else {
      // Need to look up the size of the original buffer to pass into
      // the subset function.
      result = ismd_buffer_find_descriptor(buffer_to_alias, &buffer_to_alias_buffer_desc);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "%s() : Error: Could not find buffer %d.\r\n", __FUNCTION__, buffer_to_alias);
         result = ISMD_ERROR_INVALID_HANDLE;
      } else {
         result = ismd_buffer_alias_subset(buffer_to_alias, 0, buffer_to_alias_buffer_desc->phys.size, alias_buffer);
      }
   }

   ISMD_LOG_MSG( 4, "%s() : exiting function.\r\n", __FUNCTION__ );
   return result;
}

ismd_result_t ismd_buffer_add_reference( ismd_buffer_handle_t buffer )
{
   ismd_buffer_descriptor_t *buffer_desc;
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_list_t *buffer_list;

   ISMD_LOG_MSG( 4, "ismd_buffer_add_reference() : entering function.\r\n" );

   if ( ismd_buffer_manager_initialized == false ) {
      result = ISMD_ERROR_UNSPECIFIED;
   } else {

      result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "ismd_buffer_add_reference() : Error: Could not find buffer %d.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
         ISMD_LOG_MSG( 1, "ismd_buffer_add_reference() : Error: buffer %d is not in allocated state.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else {
         int               refcount;
         TRACK_BUFFER( "add ref", buffer_desc, true );

         buffer_list = find_buffer_list(BUFFER_HANDLE_INDEX(buffer_desc->unique_id), buffer_desc->buffer_type, buffer_desc->phys.size,  buffer_desc->pmr );
         buffer_list_lock( buffer_list );
         buffer_desc->reference_count++;
         refcount = buffer_desc->reference_count;
         buffer_list_unlock( buffer_list );

         SMD_BUFFER_SVEN_EVENT ( SVEN_EV_SMDCore_Buf_AddRef,
                                 buffer_desc->unique_id,
                                 buffer_desc->phys.size,
                                 buffer_desc->phys.base,
                                (unsigned int) buffer_desc->virt.base,
                                 0, refcount );

      }
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_add_reference() : exiting function.\r\n" );

   return result;
}

ismd_result_t ismd_buffer_dereference_pvt( ismd_buffer_handle_t buffer, int *ref_count )
{
   ismd_buffer_descriptor_t *buffer_desc;
   ismd_buffer_list_t *buffer_list;
   ismd_result_t result = ISMD_SUCCESS;

   if ( ismd_buffer_manager_initialized == false ) {
      ISMD_LOG_MSG( 1, "ismd_buffer_dereference() : Error: Buffer manager not initialized.\r\n");
      result = ISMD_ERROR_UNSPECIFIED;
   } else {

      result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "ismd_buffer_dereference() : Error: Could not find buffer %d.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
         ISMD_LOG_MSG( 1, "ismd_buffer_dereference() : Error: buffer %d is not in allocated state.  buffer type %d.\r\n",
            buffer, buffer_desc->buffer_type );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else {
         buffer_list = find_buffer_list(BUFFER_HANDLE_INDEX(buffer_desc->unique_id), buffer_desc->buffer_type, buffer_desc->phys.size, buffer_desc->pmr );
         buffer_list_lock( buffer_list );
         result = ismd_buffer_dereference_internal(buffer);
         *ref_count = buffer_desc->reference_count;
         buffer_list_unlock( buffer_list );
      }
   }

   return ( result );
}

/* outer implementation of dereference - does some parameter checking,
locks the buffer list, and calls the inner implementation. */
ismd_result_t ismd_buffer_dereference( ismd_buffer_handle_t buffer )
{
   ismd_result_t result = ISMD_SUCCESS;
   int ref_count;

   result = ismd_buffer_dereference_pvt( buffer, &ref_count );

   return ( result );
}


/* actual implementation of dereference - note that this does not lock,
it assumes the appropriate buffer list is locked before it's called */
ismd_result_t ismd_buffer_dereference_internal( ismd_buffer_handle_t buffer )
{
   ismd_buffer_descriptor_t *buffer_desc;
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_list_t *buffer_list;

   ISMD_LOG_MSG( 4, "ismd_buffer_dereference_internal() : entering function.\r\n" );

   OS_ASSERT(ismd_buffer_manager_initialized);
   result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
   OS_ASSERT(result == ISMD_SUCCESS);
   OS_ASSERT(buffer_desc->state == ISMD_BUFFER_STATE_ALLOCATED);

   TRACK_BUFFER( "deref", buffer_desc, true );

   if ( buffer_desc->reference_count > 0 ) {

      buffer_list = find_buffer_list(BUFFER_HANDLE_INDEX(buffer_desc->unique_id), buffer_desc->buffer_type, buffer_desc->phys.size, buffer_desc->pmr );
      buffer_desc->reference_count--;

      SMD_BUFFER_SVEN_EVENT(  SVEN_EV_SMDCore_Buf_DeRef,
                              buffer_desc->unique_id,
                              buffer_desc->phys.size,
                              buffer_desc->phys.base,
                             (unsigned int) buffer_desc->virt.base,
                              0, buffer_desc->reference_count );

      if ( buffer_desc->reference_count == 0 ) {

         if ( buffer_desc->release_function != NULL ) {
            ISMD_LOG_MSG( 3, "ismd_buffer_dereference_internal(): calling release function 0x%08X for buffer %d\r\n",
                          (uint32_t)(buffer_desc->release_function),
                          buffer_desc->unique_id );
            result = (buffer_desc->release_function)(buffer_desc->release_context, buffer_desc);
         }
         else {
            ISMD_LOG_MSG( 2, "ismd_buffer_dereference_internal(): warning: release function is NULL for buffer %d.\r\n",
                          buffer_desc->unique_id );
         }
      }
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_buffer_dereference_internal(): warning: attempted to dereference a buffer %d with 0 reference count.\n", buffer_desc->unique_id );
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_dereference_internal() : exiting function.\n" );

   return ( result );

}

/* outer implementation of free - does some parameter checking,
locks the buffer list, and calls the inner implementation. */
ismd_result_t ismd_buffer_free( ismd_buffer_handle_t buffer )
{
   ismd_buffer_descriptor_t *buffer_desc;
   ismd_buffer_list_t *buffer_list;
   ismd_result_t result = ISMD_SUCCESS;

   if ( ismd_buffer_manager_initialized == false ) {
      ISMD_LOG_MSG( 1, "ismd_buffer_free() : Error: Buffer manager not initialized.\r\n");
      result = ISMD_ERROR_UNSPECIFIED;
   } else {
      result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "ismd_buffer_free() : Error: Could not find buffer %d.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
         ISMD_LOG_MSG( 1, "ismd_buffer_free() : Error: buffer %d is not in allocated state.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else {
         buffer_list = find_buffer_list(BUFFER_HANDLE_INDEX(buffer_desc->unique_id), buffer_desc->buffer_type, buffer_desc->phys.size, buffer_desc->pmr );
         buffer_list_lock( buffer_list );
         result = ismd_buffer_free_internal(buffer);
         buffer_list_unlock( buffer_list );
      }
   }

   return ( result );
}


/* actual implementation of free - note that this does not lock,
it assumes the appropriate buffer list is locked before it's called */
ismd_result_t ismd_buffer_free_internal( ismd_buffer_handle_t buffer )
{
   ismd_buffer_descriptor_t *buffer_desc;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   ISMD_LOG_MSG( 4, "ismd_buffer_free_internal() : entering function.\r\n" );

   OS_ASSERT(ismd_buffer_manager_initialized);
   result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
   OS_ASSERT(result == ISMD_SUCCESS);
   OS_ASSERT(buffer_desc->state == ISMD_BUFFER_STATE_ALLOCATED);

   buffer_desc->reference_count = 0;

   SMD_BUFFER_SVEN_EVENT(  SVEN_EV_SMDCore_Buf_Free,
                           buffer_desc->unique_id,
                           buffer_desc->phys.size,
                           buffer_desc->phys.base,
                          (unsigned int) buffer_desc->virt.base,
                           0, 0 );

   result = ismd_buffer_reclaim( NULL, buffer_desc );

   ISMD_LOG_MSG( 4, "ismd_buffer_free_internal() : exiting function.\n" );

   return ( result );
}

static ismd_result_t ismd_alias_buffer_reclaim (ismd_buffer_descriptor_t *alias_buffer_desc) {
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_list_t *original_buffer_list;
   ismd_buffer_descriptor_t *original_buffer_desc;

   ISMD_LOG_MSG( 4, "ismd_alias_buffer_reclaim() : entering function.\r\n" );

   ISMD_LOG_MSG( 3, "ismd_alias_buffer_reclaim() : reclaiming buffer descriptor %d, type=%d, size=%d.\r\n", alias_buffer_desc->unique_id, alias_buffer_desc->buffer_type, alias_buffer_desc->phys.size );

   result = ismd_tag_detach_all(alias_buffer_desc->unique_id);
   OS_ASSERT(result == ISMD_SUCCESS);

   alias_buffer_desc->next             = NULL;
   alias_buffer_desc->release_function = (ismd_release_func_t)ismd_buffer_reclaim;
   alias_buffer_desc->release_context  = NULL;
   alias_buffer_desc->state            = ISMD_BUFFER_STATE_FREE;
   alias_buffer_desc->buffer_type      = ISMD_BUFFER_TYPE_INVALID;
   alias_buffer_desc->phys.base        = 0;
   alias_buffer_desc->phys.size        = ISMD_BUFFER_SIZE_NONE;
   alias_buffer_desc->phys.level       = 0;
   alias_buffer_desc->phys.next_node   = NULL;
   alias_buffer_desc->virt.base        = 0;
   alias_buffer_desc->data_type        = 0;
   alias_buffer_desc->pmr              = ISMD_PMR_NONE;

   if ( alias_buffer_list.tail == NULL ) {
      alias_buffer_list.head = alias_buffer_desc;
   }
   else {
      if (alias_buffer_list.tail == alias_buffer_desc) {
         // Emergency check, should not get here.  This does not catch all cases that cause a problem when freeing a freed buffer.
         ISMD_LOG_MSG( 1, "ismd_alias_buffer_reclaim() : reclaiming buffer descriptor that was already reclaimed\n");
      } else {
         (alias_buffer_list.tail)->next = alias_buffer_desc;
      }
   }
   alias_buffer_list.tail = alias_buffer_desc;

   /* dereference the buffer that this was an alias for */
   /* Calling the locking version except in one case - we are dereferencing another anias buffer.
      The alias buffer list is currently locked so trying to lock in that case will cause a deadlock.*/
   if (BUFFER_HANDLE_INDEX(alias_buffer_desc->unique_id) <
       ISMD_MAX_BUFFER_DESCRIPTORS) {
      result = ismd_buffer_find_descriptor(alias_association_table[BUFFER_HANDLE_INDEX(alias_buffer_desc->unique_id)], &original_buffer_desc);
      original_buffer_list = find_buffer_list(BUFFER_HANDLE_INDEX(original_buffer_desc->unique_id), original_buffer_desc->buffer_type, original_buffer_desc->phys.size, original_buffer_desc->pmr);
      if (original_buffer_list == &alias_buffer_list) {
         result = ismd_buffer_dereference_internal(alias_association_table[BUFFER_HANDLE_INDEX(alias_buffer_desc->unique_id)]);
      } else {
         result = ismd_buffer_dereference(alias_association_table[BUFFER_HANDLE_INDEX(alias_buffer_desc->unique_id)]);
      }
      OS_ASSERT(result == ISMD_SUCCESS); // If this fails, the original buffer was freed before the alias was, flag the error.
      alias_association_table[BUFFER_HANDLE_INDEX(alias_buffer_desc->unique_id)] = 0;
   } else {
      /* index into alias_association_table out of range */
      OS_ASSERT(false);
   }

   ISMD_LOG_MSG( 4, "ismd_alias_buffer_reclaim() : exiting function.\r\n" );

   return result;
}


ismd_result_t ismd_buffer_reclaim( void *context, ismd_buffer_descriptor_t *buffer_desc  )
{
   ismd_buffer_list_t       *buffer_list;
   ismd_result_t             result = ISMD_SUCCESS;
   ismd_event_t              reclaim_event;

   (void)context; /* Avoid compiler warning for unused parameter. */

   ISMD_LOG_MSG( 4, "ismd_buffer_reclaim() : entering function.\r\n" );

   /* First check if the reclaim event tag is set.  If it is, set the event and remove the tag. */
   if (buffer_desc->tags_present) {
      result = ismd_tag_get_reclaim_event(buffer_desc->unique_id, &reclaim_event);
      if (result == ISMD_SUCCESS && reclaim_event != ISMD_EVENT_HANDLE_INVALID) {
         if (!active_smd_event(reclaim_event)) {
            ISMD_LOG_MSG( 1, "ismd_buffer_reclaim() : Warning: reclaim event set but not an active event.\r\n" );
         } else {
            result = ismd_event_strobe(reclaim_event);
            ismd_tag_set_reclaim_event(buffer_desc->unique_id, ISMD_EVENT_HANDLE_INVALID); /* Don't care about return code */
         }
      } else {
         result = ISMD_SUCCESS; /* Not an error, just no reclaim event */
      }
   }

   if (result != ISMD_SUCCESS) {
      /* Do nothing */
   }

   /* Now check for an aliased buffer.  If it is, handle it separately */
   /* Note - aliased frame buffers will not get freed through the FBM -
      they aren't really frame buffers and do not really represent FBM resources */
   else if ((BUFFER_HANDLE_INDEX(buffer_desc->unique_id) >= index_of_first_alias_buffer) &&
       (BUFFER_HANDLE_INDEX(buffer_desc->unique_id)  <= index_of_last_alias_buffer)) {
      result = ismd_alias_buffer_reclaim(buffer_desc);
   }

   /* If this is a frame buffer, we need to call the frame buffer manager to
      handle freeing it */
   else if (buffer_desc->buffer_type == ISMD_BUFFER_TYPE_VIDEO_FRAME) {
      result = ismd_frame_buffer_free(buffer_desc);

      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "ismd_buffer_reclaim() : error : ismd_frame_buffer_free returned %d.\r\n", result );
      }

   } else {

      /* Search for the list of appropriate-size buffers. */
      buffer_list = find_buffer_list(BUFFER_HANDLE_INDEX(buffer_desc->unique_id), buffer_desc->buffer_type, buffer_desc->phys.size, buffer_desc->pmr);
      ISMD_LOG_MSG( 3, "ismd_buffer_reclaim() : reclaiming buffer descriptor %d, type=%d, size=%d.\r\n", buffer_desc->unique_id, buffer_desc->buffer_type, buffer_desc->phys.size );

      SMD_BUFFER_SVEN_EVENT(  SVEN_EV_SMDCore_Buf_Release,
                              buffer_desc->unique_id,
                              buffer_desc->phys.size,
                              buffer_desc->phys.base,
                             (unsigned int) buffer_desc->virt.base,
                              0, 0 );

      // Track allocated fb regions for core_statistics
      if(ISMD_BUFFER_TYPE_VIDEO_FRAME_REGION == buffer_desc->buffer_type) {
         g_core_statistics.fb_stats.allocated_fb_regions--;
      }

      result = ismd_tag_detach_all(buffer_desc->unique_id);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "ismd_buffer_reclaim() : ismd_tag_detach_all failed on buffer descriptor %d, type=%d, size=%d.\r\n", buffer_desc->unique_id, buffer_desc->buffer_type, buffer_desc->phys.size );
      }
      OS_ASSERT(result == ISMD_SUCCESS);

      buffer_desc->next             = NULL;
      buffer_desc->release_function = (ismd_release_func_t)ismd_buffer_reclaim;
      buffer_desc->release_context  = NULL;
      buffer_desc->state            = ISMD_BUFFER_STATE_FREE;
      buffer_desc->phys.level       = 0;
      buffer_desc->phys.next_node   = NULL;
      buffer_desc->data_type        = 0;

      if ( buffer_list->tail == NULL ) {
         buffer_list->head = buffer_desc;
      }
      else {
         if (buffer_list->tail == buffer_desc) {
            // Emergency check, should not get here.  This does not catch all cases that cause a problem when freeing a freed buffer.
            ISMD_LOG_MSG( 1, "ismd_buffer_reclaim() : reclaiming buffer descriptor that was already reclaimed\n");
         } else {
            (buffer_list->tail)->next = buffer_desc;
         }
      }
      buffer_list->tail = buffer_desc;

      TRACK_BUFFER( "free", buffer_desc, true );

      ISMD_LOG_MSG( 4, "ismd_buffer_reclaim() : exiting function.\n" );
   }

   return (result);
}


ismd_result_t ismd_buffer_get_level( ismd_buffer_handle_t buffer, int *level)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_phys_buf_node_t *node;
   ismd_buffer_descriptor_t *buffer_desc;
   int local_level = 0;

   ISMD_LOG_MSG( 4, "ismd_buffer_get_level() : entering function.\r\n" );
   if ( ismd_buffer_manager_initialized == false ) {
      result = ISMD_ERROR_UNSPECIFIED;
   } else {

      result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "ismd_buffer_get_level() : Error: Could not find buffer %d.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else  if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
         ISMD_LOG_MSG( 1, "ismd_buffer_get_level() : Error: buffer %d is not in allocated state.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else {


         if ( (buffer_desc->buffer_type == ISMD_BUFFER_TYPE_PHYS)        || 
              (buffer_desc->buffer_type == ISMD_BUFFER_TYPE_PHYS_CACHED) || 
              (buffer_desc->buffer_type == ISMD_BUFFER_TYPE_PHYS_EXT_MAP) ) {
            local_level = buffer_desc->phys.level;
            node = buffer_desc->phys.next_node;
            while ( node != NULL ) {
               local_level += node->level;
               node = node->next_node;
            }
         }
         else {
            ISMD_LOG_MSG( 1, "ismd_buffer_get_level() : Error: Can't get level of this buffer type.\r\n");
            result = ISMD_ERROR_OPERATION_FAILED;
         }
      }

      if (result == ISMD_SUCCESS) {
         if (level == NULL) {
            result = ISMD_ERROR_NULL_POINTER;
         } else {
            *level = local_level;
         }
      }
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_get_level() : exiting function.\r\n" );

   return ( result );
}


static void buffer_list_lock( ismd_buffer_list_t *list )
{
   os_mutex_lock( (os_mutex_t *)&(list->lock) );
}



static void buffer_list_unlock( ismd_buffer_list_t *list )
{
   os_mutex_unlock( (os_mutex_t *)&(list->lock) );
}


/* Find the buffer list that contains buffers of the specified size, type and pmr. */
static ismd_buffer_list_t *find_buffer_list(unsigned int buffer_id, ismd_buffer_type_t type, int size, unsigned int pmr )
{
   ismd_buffer_list_t *buffer_list = free_buffer_lists;
   unsigned int free_list_key=0, free_list_index=0;
 
  
   if ((buffer_id != (unsigned int)ISMD_BUFFER_HANDLE_INVALID)  &&
       (buffer_id >= index_of_first_alias_buffer) &&
       (buffer_id <= index_of_last_alias_buffer)) {

      /* This is an aliased buffer.  Ignore the buffer type, the list is the aliased list */
      buffer_list = &alias_buffer_list;
   } else if (type == ISMD_BUFFER_TYPE_ALIAS){

      /* Type requested is aliased, use aliased list */
      buffer_list = &alias_buffer_list;
   } else {

      /* For frame buffers, lock the list of type phys and size 0 */
      if (type == ISMD_BUFFER_TYPE_VIDEO_FRAME) {
         type = ISMD_BUFFER_TYPE_PHYS;
         size = 0;
      }
  
      /* Need to look at size before we try to hash a key. If the size is a custom size
         build a special key. All custom sizes go in a list together for each pmr/type
         combination 
      */   
      if( ISPWROF2( size ) && size>=TYPICAL_BUF_SIZE_RANGE_MIN && size< TYPICAL_BUF_SIZE_RANGE_MAX)
      {
         free_list_key = FREE_LIST_KEY(pmr, type, size) ;
      }       
      else 
      {
         free_list_key = FREE_LIST_KEY(pmr, type, CUSTOM_BUFFER_SIZE) ;           

      }
          
      free_list_index = phash( free_list_key );      
      buffer_list = &free_buffer_lists[free_list_index];

   }
  
   return ( buffer_list );
}


ismd_result_t ismd_buffer_track_size( int size )
{
   track_buffer_size = size;
   return (ISMD_SUCCESS);
}

ismd_result_t ismd_buffer_read_desc( ismd_buffer_handle_t      buffer,
                                     ismd_buffer_descriptor_t *desc)
{
   ismd_buffer_descriptor_t *buffer_desc;
   ismd_result_t result = ISMD_SUCCESS;

   ISMD_LOG_MSG( 4, "ismd_buffer_read_desc() : entering function.\r\n" );
   if ( ismd_buffer_manager_initialized == false ) {
      result = ISMD_ERROR_UNSPECIFIED;
   } else {

      result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "ismd_buffer_read_desc() : Error: Could not find buffer %d.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else  if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
         ISMD_LOG_MSG( 1, "ismd_buffer_read_desc() : Error: buffer %d is not in allocated state.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else {

         if (desc == NULL) {
            ISMD_LOG_MSG( 1, "ismd_buffer_read_desc() : Error: Null descriptor handle supplied.\r\n");
            result = ISMD_ERROR_INVALID_HANDLE;
         } else {
            OS_MEMCPY(desc, buffer_desc, sizeof(ismd_buffer_descriptor_t));
         }
      }
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_read_desc() : exiting function.\r\n" );

   return result;
}


ismd_result_t ismd_buffer_update_desc( ismd_buffer_handle_t      buffer,
                                       ismd_buffer_descriptor_t *desc )
{
   ismd_buffer_descriptor_t *buffer_desc;
   ismd_buffer_list_t *buffer_list;
   ismd_result_t result = ISMD_SUCCESS;

   ismd_buffer_type_t         backed_up_type;
   ismd_physical_address_t    backed_up_phys_base;
   int                        backed_up_phys_size;
   void                      *backed_up_virt_base;
   ismd_buffer_id_t           backed_up_id;
   ismd_buffer_descriptor_t  *backed_up_next;
   int                        backed_up_reference_count;
   int                        backed_up_state;
   int                        backed_up_tags_present;
   int                        backed_up_pmr;

   ISMD_LOG_MSG( 4, "ismd_buffer_update_desc() : entering function.\r\n" );
   if ( ismd_buffer_manager_initialized == false ) {
      result = ISMD_ERROR_UNSPECIFIED;
   } else if (desc == NULL) {
      ISMD_LOG_MSG( 1, "ismd_buffer_update_desc() : Error: Null descriptor handle supplied.\r\n");
      result = ISMD_ERROR_NULL_POINTER;
   } else {

      result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "ismd_buffer_update_desc() : Error: Could not find buffer %d.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
         ISMD_LOG_MSG( 1, "ismd_buffer_update_desc() : Error: buffer %d is not in allocated state.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else if ( desc->phys.level > buffer_desc->phys.size ) {
         ISMD_LOG_MSG( 1, "ismd_buffer_update_desc() : Error: buffer %d phys.level=%d cannot be greater than phys.size=%d.\r\n", buffer, desc->phys.level, buffer_desc->phys.size );
         result = ISMD_ERROR_INVALID_REQUEST;
      } else {
         buffer_list = find_buffer_list(ISMD_BUFFER_HANDLE_INVALID, buffer_desc->buffer_type, buffer_desc->phys.size, buffer_desc->pmr );
         buffer_list_lock( buffer_list );

         /* Back up non-changeable parts of the buffer descriptor */
         backed_up_type             = buffer_desc->buffer_type;
         backed_up_phys_base        = buffer_desc->phys.base;
         backed_up_phys_size        = buffer_desc->phys.size;
         backed_up_virt_base        = buffer_desc->virt.base;
         backed_up_id               = buffer_desc->unique_id;
         backed_up_next             = buffer_desc->next;
         backed_up_reference_count  = buffer_desc->reference_count;
         backed_up_state            = buffer_desc->state;
         backed_up_tags_present     = buffer_desc->tags_present;
         backed_up_pmr              = buffer_desc->pmr;

         /* Update buffer descriptor */
         OS_MEMCPY(buffer_desc, desc, sizeof(ismd_buffer_descriptor_t));

         if (   (buffer_desc->buffer_type       != backed_up_type)
             || (buffer_desc->phys.base         != backed_up_phys_base)
             || (buffer_desc->phys.size         != backed_up_phys_size)
             || (buffer_desc->virt.base         != backed_up_virt_base)
             || (buffer_desc->unique_id         != backed_up_id)
             || (buffer_desc->next              != backed_up_next)
             || (buffer_desc->reference_count   != backed_up_reference_count)
             || (buffer_desc->state             != backed_up_state)
             || (buffer_desc->tags_present      != backed_up_tags_present)
             || (buffer_desc->pmr               != backed_up_pmr)
             ) {
            ISMD_LOG_MSG( 1, "ismd_buffer_update_desc() : Warning: attempting to update a protected field - blocked.\r\n");
         }

         /* restore backed up values */
         buffer_desc->buffer_type      = backed_up_type;
         buffer_desc->phys.base        = backed_up_phys_base;
         buffer_desc->phys.size        = backed_up_phys_size;
         buffer_desc->virt.base        = backed_up_virt_base;
         buffer_desc->unique_id        = backed_up_id;
         buffer_desc->next             = backed_up_next;
         buffer_desc->reference_count  = backed_up_reference_count;
         buffer_desc->state            = backed_up_state;
         buffer_desc->tags_present     = backed_up_tags_present;
         buffer_desc->pmr              = backed_up_pmr;

         buffer_list_unlock( buffer_list );
      }
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_update_desc() : exiting function.\r\n" );

   return result;
}

/* Internal function to quickly find pointer to descriptor.  Cannot be used
 * across marshalling boundaries.
 */
ismd_result_t ismd_buffer_find_descriptor( ismd_buffer_id_t id,
                                           ismd_buffer_descriptor_t **buffer )
{
   ismd_result_t result = ISMD_SUCCESS;
   int buf_num, buf_version;

   UNPACK_BUFFER_HANDLE(id, buf_num, buf_version);


   ISMD_LOG_MSG( 4, "ismd_buffer_find_descriptor() : entering function.\r\n" );

   if ( (buf_num >= 0) && (buf_num < ISMD_MAX_BUFFER_DESCRIPTORS) ) {
      *buffer = &(buffer_descriptors[buf_num]);

      if ((*buffer)->unique_id != id) { // check both packed handles, should match
         ISMD_LOG_MSG( 1, "ismd_buffer_find_descriptor() : Stale buffer handle.\r\n" );
         result = ISMD_ERROR_INVALID_HANDLE;
      }
   }
   else {
      ISMD_LOG_MSG( 1, "ismd_buffer_find_descriptor() : invalid buffer ID.\r\n" );
      result = ISMD_ERROR_NOT_FOUND;
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_find_descriptor() : exiting function.\n" );

   return (result);
}


ismd_result_t ismd_buffer_reassign_base_address(ismd_buffer_handle_t buffer,
                                                ismd_physical_address_t base_address)
{
   ismd_buffer_descriptor_t *buffer_desc;
   ismd_result_t result = ISMD_SUCCESS;

   ISMD_LOG_MSG( 4, "ismd_buffer_reassign_base_address() : entering function.\r\n" );
   if ( ismd_buffer_manager_initialized == false ) {
      result = ISMD_ERROR_UNSPECIFIED;
   } else {

      result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG( 1, "ismd_buffer_reassign_base_address() : Error: Could not find buffer %d.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else  if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
         ISMD_LOG_MSG( 1, "ismd_buffer_reassign_base_address() : Error: buffer %d is not in allocated state.\r\n", buffer );
         result = ISMD_ERROR_INVALID_HANDLE;
      } else {
         buffer_desc->phys.base = base_address;
      }
   }

   ISMD_LOG_MSG( 4, "ismd_buffer_read_desc() : exiting function.\r\n" );

   return result;
}


typedef struct _memory_region_link_t {
   struct _memory_region_link_t *next;
   unsigned int base_addr;
   unsigned int size;
} memory_region_link_t;


static void add_to_list_sorted (memory_region_link_t **list_head, memory_region_link_t *new_link) {
   memory_region_link_t *prev_ptr = NULL;
   memory_region_link_t *curr_ptr = *list_head;

   if (*list_head == NULL) {
      *list_head = new_link;
   }

   else {
      while ((curr_ptr != NULL) && (new_link->base_addr >= curr_ptr->base_addr)) {
         prev_ptr = curr_ptr;
         curr_ptr = curr_ptr->next;
      }

      if (prev_ptr) {
         prev_ptr->next = new_link;
      }
      new_link->next = curr_ptr;
   }
}




static ismd_result_t check_memory_layout(config_ref_t layout_node) {
   ismd_result_t     result         = ISMD_SUCCESS;
   config_result_t   config_ret     = CONFIG_SUCCESS;
   config_ref_t      child_node     = ROOT_NODE;
   unsigned int address, block_size, region_size;
   memory_region_link_t *list_head = NULL;
   memory_region_link_t *new_link;
   memory_region_link_t *curr_memory_region;
   memory_region_link_t *next_memory_region;
   char name[64];

   // Make a sorted linked-list from all of the "smd_buffers" and "smd_frame_buffers"
   config_ret = config_node_first_child(layout_node, &child_node);
   while (config_ret == CONFIG_SUCCESS) {

      config_ret = config_node_get_name(child_node, name, sizeof(name));
      DEVH_ASSERT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_BUFFER], config_ret == CONFIG_SUCCESS);

      if ((OS_MEMCMP(name, "smd_buffers", 11) == 0) || (OS_MEMCMP(name, "smd_frame_buffers", 17) == 0)) {

         config_ret = config_get_int(child_node, "base", (int *)(&address));
         DEVH_ASSERT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_BUFFER], config_ret == CONFIG_SUCCESS);

         config_ret = config_get_int(child_node, "size", (int *)(&region_size));
         DEVH_ASSERT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_BUFFER], config_ret == CONFIG_SUCCESS);

         if (OS_MEMCMP(name, "smd_frame_buffers", 17) == 0) {
            block_size = SYSTEM_STRIDE * FRAME_REGION_BLOCK_HEIGHT;
         } else {
            config_ret = config_get_int(child_node, "buf_size", (int *)(&block_size));
            if (config_ret != CONFIG_SUCCESS) {
               block_size = region_size;
               config_ret = CONFIG_SUCCESS;
            }
         }

         new_link = OS_ALLOC(sizeof(memory_region_link_t));
         DEVH_ASSERT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_BUFFER], new_link != NULL);

         new_link->next = NULL;
         new_link->base_addr = address;
         new_link->size = region_size;

         add_to_list_sorted(&list_head, new_link);

      }

      config_ret = config_node_next_sibling(child_node, &child_node);
   }

   // Check the memory in the sorted linked-list for overlaps.
   if (!ALLOW_OVERLAP) {
      curr_memory_region = list_head;
      while (curr_memory_region != NULL && curr_memory_region->next != NULL) {
         next_memory_region = curr_memory_region->next;

         DEVH_ASSERT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_BUFFER],
            (curr_memory_region->base_addr + curr_memory_region->size) <= next_memory_region->base_addr);

         curr_memory_region = next_memory_region;
      }
   }

   // Can check other things here, like gaps and regions that are not multiples of their chunk sizes.

   // Free the linked-list
   curr_memory_region = list_head;
   while (curr_memory_region != NULL) {
      next_memory_region = curr_memory_region->next;
      OS_FREE(curr_memory_region);
      curr_memory_region = next_memory_region;
   }

   return result;
}



static ismd_result_t ismd_process_memory_layout( void ) {
   ismd_result_t     result         = ISMD_SUCCESS;
   config_result_t   config_ret     = CONFIG_SUCCESS;
   config_ref_t      layout_node    = ROOT_NODE;
   config_ref_t      child_node     = ROOT_NODE;
   unsigned int address, block_size, region_size, pmr;
   int cached = false;
   ismd_buffer_type_t buffer_type;
   char name[64];

   ISMD_LOG_MSG( 4, "ismd_process_memory_layout() : entering function.\r\n" );

   // Find the memory layout node (platform.memory.layout)
   config_ret = config_node_find(ROOT_NODE, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT, &layout_node);
   DEVH_ASSERT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_BUFFER], config_ret == CONFIG_SUCCESS);

   result = check_memory_layout(layout_node);

   // Convert the layout to our local structure.
   // Go through each entry in the layout and get the properties.
   if (result == ISMD_SUCCESS) {

      config_ret = config_node_first_child(layout_node, &child_node);

      while (config_ret == CONFIG_SUCCESS) {

         config_ret = config_node_get_name(child_node, name, sizeof(name));
         DEVH_ASSERT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_BUFFER], config_ret == CONFIG_SUCCESS);

         if ((OS_MEMCMP(name, "smd_buffers", 11) == 0) || (OS_MEMCMP(name, "smd_frame_buffers", 17) == 0)) {
            config_ret = config_get_int(child_node, "base", (int *)(&address));
            DEVH_ASSERT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_BUFFER], config_ret == CONFIG_SUCCESS);

            config_ret = config_get_int(child_node, "size", (int *)(&region_size));
            DEVH_ASSERT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_BUFFER], config_ret == CONFIG_SUCCESS);
            
            if( IGNORE_PMR_MODE ) {
               pmr = ISMD_PMR_NONE;
            }
            else {
               config_ret = config_get_int(child_node, "pmr", (int *)(&pmr));
               if(config_ret != CONFIG_SUCCESS) {
                  pmr = ISMD_PMR_NONE;
               }
            }

            /* Determine if the buffer should be cached.  */
            /* First, check for: cached = 1 */
            cached = false;
            config_ret = config_get_int(child_node, "cached", &cached);
            /* Next, check for: cached = "true", cached = "yes", or cached = "1" */
            //if ( config_ret != CONFIG_SUCCESS ) {
            //   char cached_str[10+1] = "false";
            //   config_ret = config_get_str(child_node, "cached", cached_str, 10);
            //   if ( config_ret == CONFIG_SUCCESS ) {
            //      if ( (strcmp(cached, "true") == 0) ||
            //           (strcmp(cached, "yes")  == 0) ||
            //           (strcmp(cached, "1")    == 0) ) {
            //         cached = true;
            //      }
            //   }
            //}

            if (OS_MEMCMP(name, "smd_frame_buffers", 17) == 0) {
               block_size = SYSTEM_STRIDE * FRAME_REGION_BLOCK_HEIGHT;
               buffer_type = ISMD_BUFFER_TYPE_VIDEO_FRAME_REGION;
               g_core_statistics.fb_stats.fb_regions_size = block_size;
            } else {
               config_ret = config_get_int(child_node, "buf_size", (int *)(&block_size));
               if (config_ret != CONFIG_SUCCESS) {
                  block_size = region_size;
                  config_ret = CONFIG_SUCCESS;
               }
               if ( cached ) {
                  buffer_type = ISMD_BUFFER_TYPE_PHYS_CACHED;
               }
               else {
                  buffer_type = ISMD_BUFFER_TYPE_PHYS;
               }
            }

            ISMD_LOG_MSG( 4, "\r\nProcessing memory_layout descriptor.\r\n" );
            ISMD_LOG_MSG( 4, "      buffer type      = 0x%X.\r\n"  , buffer_type );
            ISMD_LOG_MSG( 4, "      block size       = 0x%X.\r\n"  , block_size );
            ISMD_LOG_MSG( 4, "      physical address = 0x%08X.\r\n", address    );
            ISMD_LOG_MSG( 4, "      pmr              = %d.\r\n", pmr    );            
            ISMD_LOG_MSG( 4, "      region size      = 0x%08X.\r\n", region_size);

            result = ismd_buffer_create_multiple( buffer_type,
                                                  block_size != 0 ? block_size : region_size,
                                                  pmr,
                                                  address,
                                                  region_size );
         } else {
            ISMD_LOG_MSG( 3, "ismd_process_memory_layout() : Found non-ISMD memory node %s, skipping.\n", name);
         }

         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 0, "ERROR: SMD Core ran out of buffer descriptors!  Does the layout have a lot of buffers?  Increasing ISMD_MAX_BUFFER_DESCRIPTORS in the code may help\r\n" );
            break;
         }

         config_ret = config_node_next_sibling(child_node, &child_node);
      }
   }

   ISMD_LOG_MSG( 4, "ismd_process_memory_layout() : exiting function.\n" );

   return result;
}

static ismd_result_t track_virtual_mapping(void *base, size_t size) {
   int mapping_num = 0;
   ismd_result_t result = ISMD_SUCCESS;
   while (mapping_num < MAX_ALLOWED_LAYOUT_ENTRIES) {
      if (core_mappings[mapping_num].used == false) {
         core_mappings[mapping_num].used = true;
         core_mappings[mapping_num].virt_base = base;
         core_mappings[mapping_num].size = size;
         break;
      }
      mapping_num++;
   }

   if (mapping_num == MAX_ALLOWED_LAYOUT_ENTRIES) {
      ISMD_LOG_MSG( 1, "Warning: SMD Core can't track this many regions!\r\n" );
      result = ISMD_ERROR_NO_RESOURCES;
   }

   return result;
}

static void free_all_virtual_mappings(void) {
   int mapping_num = 0;
   while (mapping_num < MAX_ALLOWED_LAYOUT_ENTRIES) {
      if (core_mappings[mapping_num].used) {
         OS_UNMAP_IO_FROM_MEM(core_mappings[mapping_num].virt_base, core_mappings[mapping_num].size);
         core_mappings[mapping_num].used = false;
      }
      mapping_num++;
   }
}

ismd_result_t
ismd_register_buffer_alloc_fail_event(ismd_event_t event) {
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;
   unsigned event_num;
   bool duplicate = false;
   unsigned first_free_index = ALLOC_ERROR_EVENT_COUNT;

   /** Do not allow ISMD_EVENT_HANDLE_INVALID */
   if (ISMD_EVENT_HANDLE_INVALID == event) {
      result = ISMD_ERROR_INVALID_PARAMETER;
   }

   /** Scan all event slots - check for duplicate events and a free slot */
   else {
      for (event_num = 0; event_num < ALLOC_ERROR_EVENT_COUNT; event_num++) {
         if (event == alloc_error_events[event_num]) {
            duplicate = true;
            break;
         }
         if ((first_free_index == ALLOC_ERROR_EVENT_COUNT) &&
             (ISMD_EVENT_HANDLE_INVALID == alloc_error_events[event_num])) {
            first_free_index = event_num;
         }
      }
      if (duplicate) {
         result = ISMD_ERROR_INVALID_REQUEST;
      } else if (first_free_index < ALLOC_ERROR_EVENT_COUNT) {
         result = ISMD_SUCCESS;
         alloc_error_events[first_free_index] = event;
      }
   }
   return result;
}


ismd_result_t
ismd_unregister_buffer_alloc_fail_event(ismd_event_t event) {
   unsigned event_num = 0;

   /* erase first match, if there is one */
   for (event_num = 0; event_num < ALLOC_ERROR_EVENT_COUNT; event_num++) {
      if (alloc_error_events[event_num] == event) {
         alloc_error_events[event_num] = ISMD_EVENT_HANDLE_INVALID;
         break;
      }
   }
   return ISMD_SUCCESS;
}
