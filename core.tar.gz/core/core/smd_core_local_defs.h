/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#ifndef __SMD_LOCAL_DEFS_H__
#define __SMD_LOCAL_DEFS_H__


#include "ismd_global_defs.h"
#include <osal.h>
#include <sven_devh.h>
#include <sven_event.h>
#include <sven_event_type.h>


ismd_result_t ismd_buffer_manager_init( void );
ismd_result_t ismd_clock_manager_init( void );
ismd_result_t ismd_device_manager_init( void );
ismd_result_t ismd_event_manager_init( void );
ismd_result_t ismd_port_manager_init( void );
ismd_result_t ismd_queue_manager_init( void );
ismd_result_t ismd_message_manager_init( void );

ismd_result_t ismd_message_manager_deinit( void );
ismd_result_t ismd_buffer_manager_deinit( void );
ismd_result_t ismd_clock_manager_deinit( void );

/* Print a message only if the severity level of the message is less than the current debug verbosity level */
#define ISMD_LOG_MSG(level, format...)  if( (level) <= ismd_debug_level ) OS_INFO(format)

/* Utility/Debug functions for reading and writing device registers. */
uint32_t ismd_read_register( ismd_physical_address_t address );
void ismd_write_register( ismd_physical_address_t address, uint32_t value );
void ismd_and_register( ismd_physical_address_t address, uint32_t value );
void ismd_or_register( ismd_physical_address_t address, uint32_t value );



extern ismd_verbosity_level_t logging_verbosity_level;

extern int ismd_debug_level;

typedef enum {
   SMD_CORE_DEBUG_UNIT_GENERIC = 0,
   SMD_CORE_DEBUG_UNIT_PORT = 1,
   SMD_CORE_DEBUG_UNIT_QUEUE = 2,
   SMD_CORE_DEBUG_UNIT_BUFFER = 3,
   SMD_CORE_DEBUG_UNIT_CLOCK = 4,
   SMD_CORE_DEBUG_UNIT_MESSAGE = 5,
   SMD_CORE_DEBUG_UNIT_MAX = 6
} smd_debug_unit_type_t;

extern os_devhandle_t *smd_dbg_devh[SMD_CORE_DEBUG_UNIT_MAX];

/** Transmit a SVEN debug event.
 */
void smd_core_send_sven_event(
    smd_debug_unit_type_t    smd_core_unit,
    enum SVEN_EV_SMDCore_t   subtype,
    int                      payload0,
    int                      payload1,
    int                      payload2,
    int                      payload3,
    int                      payload4,
    int                      payload5 );

/** Transmit a SVEN debug event.  Used to send port name.
 */
void smd_core_send_sven_event_named(
    smd_debug_unit_type_t    smd_core_unit,
    enum SVEN_EV_SMDCore_t   subtype,
    int                      id,
    char *                   name,
    int                      name_length);


#define SMD_DEBUG_SUPPORT 1
#ifdef SMD_DEBUG_SUPPORT
#define ismd_log(min_verbosity, ...) \
	do { \
		if (min_verbosity <= ismd_debug_level) { \
			OS_PRINT("%s: ", __FUNCTION__); \
			OS_PRINT(__VA_ARGS__); \
		} \
	} while (0)
#else
#define ismd_log(args...) do{}while(0)
#endif


/* TODO: Move to a sven header file? */
typedef enum {
	ISMD_CORE_TRACE_DEVICE_ALLOC         = 1,
	ISMD_CORE_TRACE_DEVICE_FREE          = 2,
	ISMD_CORE_TRACE_DEVICE_SET_USER_DATA = 3,
	ISMD_CORE_TRACE_DEVICE_GET_USER_DATA = 4,
	ISMD_CORE_TRACE_DEVICE_CLOSE         = 5,
	ISMD_CORE_TRACE_DEVICE_FLUSH         = 6,
	ISMD_CORE_TRACE_DEVICE_SET_STATE     = 7,
	ISMD_CORE_TRACE_DEVICE_SET_CLOCK     = 8,
	ISMD_CORE_TRACE_DEVICE_SET_BASE_TIME = 9,
	ISMD_CORE_TRACE_DEVICE_SET_PLAY_RATE = 10,
   ISMD_CORE_TRACE_DEVICE_SET_UNDERRUN_EVENT = 11,
   ISMD_CORE_TRACE_DEVICE_GET_UNDERRUN_amount = 12,
   ISMD_CORE_TRACE_DEVICE_SET_SLAVE_CLOCK = 13
} device_manager_action_t;



/**
ismd_buffer_create_multiple creates multiple new SMD physical buffer from a
block of physical memory and add those new buffers to the SMD core's pool
of available buffers.  This function can be used to dynamically add memory
to the SMD Core.  Note that once the memory is added the the SMD Core's pool,
it cannot be removed.

@param[in]  buffer_size : size of the individual buffers to create.
@param[in]  physical_address : the physical address of the region.
@param[in]  region_size : size of the region of memory that will be
cut up into smaller-size buffers.
@param[in]  pmr : the protected memory region associated with these buffers.

@retval ISMD_SUCCESS : The buffer was successfully created.
@retval ISMD_ERROR_NO_RESOURCES :  The SMD Core did not have enough free
buffer descriptors to assign to the new buffer.
*/
ismd_result_t ismd_buffer_create_multiple( ismd_buffer_type_t      buffer_type,
                                           unsigned int            buffer_size,
                                           int                     pmr,                                           
                                           ismd_physical_address_t physical_address,
                                           unsigned int            region_size );

#define ISMD_MAX_BUFFER_DESCRIPTORS 5000
#define ISMD_MAX_ALIAS_BUFFERS      256

/* Internal (not locked) versions of buffer deallocation */
ismd_result_t ismd_buffer_dereference_internal( ismd_buffer_handle_t buffer );
ismd_result_t ismd_buffer_free_internal( ismd_buffer_handle_t buffer );

ismd_result_t ismd_frame_buffer_init(void);
ismd_result_t ismd_frame_buffer_deinit(void);
ismd_result_t ismd_frame_buffer_free(ismd_buffer_descriptor_t *buffer);
ismd_result_t ismd_buffer_tags_init(void);
ismd_result_t ismd_buffer_tags_deinit(void);
ismd_result_t ismd_tag_detach_all (ismd_buffer_handle_t  buffer);

/**
Shortcut for buffer allocation that does not require a descriptor copy.
*/
ismd_result_t ismd_buffer_create_internal( ismd_physical_address_t physical_address,
                                  ismd_buffer_type_t      type,
                                  int                     size,
                                  int                     pmr,                                  
                                  void                   *kernel_virt_address);

/*
 * The buffer handles contain both the buffer index and the buffer version.
 * This macro will unpack the handle.
 */
#define UNPACK_BUFFER_HANDLE(packed_handle, base_handle, version_id)             \
   ((base_handle) = ((packed_handle) & 0xFFFF));                                 \
   ((version_id) = (((unsigned int)(packed_handle) >> 16) & 0xFFFF))

#define BUFFER_HANDLE_INDEX(packed_handle) ((packed_handle) & 0xFFFF)
#define BUFFER_HANDLE_VERSION(packed_handle)  (((unsigned int)(packed_handle) >> 16) & 0xFFFF)

/*
 * In order to help with decision-making and error checking,
 * each buffer has a state.
 */
typedef enum {
   ISMD_BUFFER_STATE_INVALID   = 0,
   ISMD_BUFFER_STATE_FREE      = 0x5A5A5A5A,  /* free and can be allocated */
   ISMD_BUFFER_STATE_ALLOCATED = 0x7FE5AFEE   /* Allocated */
} ismd_buffer_state_t;

/*
 * Defines some hard-coded tag type that the tag outer functions use.
 */
typedef enum {
   ISMD_BUFFER_TAG_TYPE_NEWSEGMENT = 0,
   ISMD_BUFFER_TAG_TYPE_EOS,
   ISMD_BUFFER_TAG_TYPE_DYN_ATTRS,
   ISMD_BUFFER_TAG_CLIENT_ID,
   ISMD_BUFFER_TAG_RECLAIM_EVENT,
   ISMD_BUFFER_TAG_NUM_TYPES,
   ISMD_BUFFER_TAG_MAX				// This one MUST be last in the list
} ismd_tag_type_t;


/**
Determine if an event handle is valid and currently allocated.  This is intented
for use by the clock manager and port manager.
*/
bool valid_smd_event( ismd_event_t event );
bool active_smd_event( ismd_event_t event );


#endif /* __SMD_LOCAL_DEFS_H__ */
