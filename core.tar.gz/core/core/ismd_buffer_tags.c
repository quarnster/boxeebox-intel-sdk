/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2006-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/**
 * @file
 * Capability is needed so that metadata can be associated with individual buffers.
 * There are two mechanisms that are used to this: The buffer descriptor itself has an "attributes" field that can carry use-case specific data and there is function-based mechanism for attaching standardized event-related buffer tags.
 * In general, the attributes field is used to track data-type specific attributes of the buffer such as ES attributes of frame buffer attributes.  The attributes field is generally filled in for every buffer.
 *
 * The function-based mechanism is used to track "events" in the stream like the end of the clip, the start of a new segment or play rate, or points in the stream that the application is interested in knowing when they get to a specific point in the pipeline.
 *
 * Buffer tags are used for the function-based mechanism, which are only needed when something is to change in the stream (such as play rate or media format) without the stream being flushed or otherwise emptied.
 * Take, for example, the end of the stream.
 * The application wants to wait until the last sample of the stream has been rendered before it shuts the pipeline down.
 * There needs to be a way to say "this input buffer is the last one" and then get notified when the video frame that contained in that input buffer has been displayed.
 * Another example is a mid-stream video codec change without flushing the pipeline.  The decoder cannot be reconfigured out of band as there is no way to know exactly when the first byte of the new format reaches the decoder.
 * There needs to be a way to attach a flag to the buffer that says "the format changes to xxxx starting with this buffer" so the decoder can reconfigure itself at the right exact moment.
 */


#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core.h"
#include "ismd_core_protected.h"
#include "smd_core_local_defs.h"
#include "ismd_core.h"


// These defines are for internal use only - the inner mechanism behind storing
// tags uses these but not the externally visible API.

#define ISMD_MAX_TAG_SIZE  (64*sizeof(int))

#define ISMD_TAGS_PER_BUFFER    (5)   ///< How many tags can be associated to a
                                      ///<    single buffer.  This is used to
                                      ///<    determine the size of the static tag
                                      ///<    array for each buffer.
typedef struct {
   int  type;                         ///< Type of the tag.  This is not
                                      ///<    interpreted by the core, it is used
                                      ///<    as a lookup key.
   char data[ISMD_MAX_TAG_SIZE];      ///< Data associated with the tag.
}  ismd_buffer_tag_t;


typedef struct {
   bool                       in_use; ///< If this tag is in use (not empty),
                                      ///<    this is true.
   ismd_buffer_tag_t          tag;    ///< The actual tag.
} ismd_buffer_tag_storage_t;


typedef struct {
   ismd_buffer_tag_storage_t tags[ISMD_MAX_BUFFER_DESCRIPTORS][ISMD_TAGS_PER_BUFFER];
} ismd_buffer_tag_context_t;

static bool buffer_tags_initialized = false;
static ismd_buffer_tag_context_t tag_context;


////////////////////////////////////////
// Internal functions
////////////////////////////////////////


//****************************************************************************
// NAME:
//      find_free_tag_storage
//
// SYNOPSIS:
//      result = find_free_tag_storage(int buffer_num,
//                                     ismd_buffer_tag_storage_t **tag_storage,
//                                     int type)
//          buffer_num         - tags array index
//          **tag_storage      - pointer to pointer that points to the located
//                               tag storage area
//          type               - tag storage type
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_RESOURCES if no free tag storage area is available
//      ISMD_ERROR_INVALID_PARAMETER some parameter out of range
//
// DESCRIPTION:
//      This function scans the array of tags based on the buffer_num
//      provided.  It will set *tag_storage to point to the first tag
//      storage area in the array with a matching type (thus overwriting
//      the tag).
//****************************************************************************
static ismd_result_t
find_free_tag_storage(int buffer_num,
                      ismd_buffer_tag_storage_t **tag_storage,
                      int type)
{
   ismd_result_t result = ISMD_SUCCESS;
   bool tag_found = false;
   int tag_num;

   if ((buffer_num < 0) || (buffer_num >= ISMD_MAX_BUFFER_DESCRIPTORS)) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer_num %d invalid.\r\n", __func__, buffer_num);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else if ((type < 0) || (type >= ISMD_BUFFER_TAG_MAX)) {
      ISMD_LOG_MSG(1, "%s() : Error: type %d invalid.\r\n", __func__, type);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else {
      for (tag_num = 0; tag_num < ISMD_TAGS_PER_BUFFER; tag_num++) {
         if (tag_context.tags[buffer_num][tag_num].in_use) {
            if (tag_context.tags[buffer_num][tag_num].tag.type == type) {
               *tag_storage = &(tag_context.tags[buffer_num][tag_num]);
               tag_found = true;
               break;
            }
         } else {
            *tag_storage = &(tag_context.tags[buffer_num][tag_num]);
            tag_found = true;
            break;
         }
      }

      if (!tag_found) {
         result = ISMD_ERROR_NO_RESOURCES;
      }
   }

   return result;
}

//****************************************************************************
// NAME:
//      find_tag_storage
//
// SYNOPSIS:
//      result = find_tag_storage(int buffer_num,
//                                int *id,
//                                int type,
//                                ismd_buffer_tag_storage_t **tag_storage)
//          buffer_num    - tags array index
//			*id           - pointer to tag id (used as index into tag storage
//                          area array)
//          type          - tag storage type
//          **tag_storage - pointer to pointer that points to the located
//                          tag storage area
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_DATA_AVAILABLE if no tag of this type in use
//      ISMD_ERROR_INVALID_PARAMETER some parameter out of range
//
// DESCRIPTION:
//      This function locates a particular tag type in the array of tag
//      storage areas indicated by the buffer_num index.  The *id that is
//      passed in by the caller is used as the starting index in the tag
//      storage area array for begining the search.  If a tag that is in use
//      and has the specified type is located, the *tag_storage pointer is
//      set to point to it.  Also, the *id (tag array index) is set.
//****************************************************************************
static ismd_result_t
find_tag_storage(int buffer_num, int *id, int type,
                 ismd_buffer_tag_storage_t **tag_storage)
{
   ismd_result_t result = ISMD_SUCCESS;
   bool tag_found = false;
   int tag_num;

   if ((buffer_num < 0) || (buffer_num >= ISMD_MAX_BUFFER_DESCRIPTORS)) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer_num %d invalid.\r\n", __func__, buffer_num );
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else if ((type < 0) || (type >= ISMD_BUFFER_TAG_MAX)) {
      ISMD_LOG_MSG(1, "%s() : Error: type %d invalid.\r\n", __func__, type);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else if ((*id < 0) || (*id >= ISMD_TAGS_PER_BUFFER)) {
      ISMD_LOG_MSG(1, "%s() : Error: id %d invalid.\r\n", __func__, *id);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else {
      for (tag_num = *id; tag_num < ISMD_TAGS_PER_BUFFER; tag_num++) {
         if (tag_context.tags[buffer_num][tag_num].in_use) {
            if (tag_context.tags[buffer_num][tag_num].tag.type == type) {
               *tag_storage = &(tag_context.tags[buffer_num][tag_num]);
               *id = tag_num;
               tag_found = true;
               break;
            }
         }
      }

      if (!tag_found) {
         result = ISMD_ERROR_NO_DATA_AVAILABLE;
      }
   }

   return result;
}

//****************************************************************************
// NAME:
//      find_tag_storage_untyped
//
// SYNOPSIS:
//      result = find_tag_storage_untyped(int buffer_num,
//                                     int *id,
//                                     ismd_buffer_tag_storage_t **tag_storage)
//          buffer_num    - tags array index
//			*id           - pointer to tag id (used as index into tag storage
//                          area array)
//          **tag_storage - pointer to pointer that points to the located
//                          tag storage area
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_DATA_AVAILABLE if no tag of this type in use
//      ISMD_ERROR_INVALID_PARAMETER some parameter out of range
//
// DESCRIPTION:
//      This function locates the first "in use" tag in the array of tags
//      indicated by the buffer_num index.  The *id that is passed in by the
//      caller is used as the starting index in the tags array for begining
//      the search.  If a tag that is in use is located, the *tag_storage
//      pointer is set to point to it.  Also, the *id (tag array index) is
//      set.
//****************************************************************************
static ismd_result_t
find_tag_storage_untyped(int buffer_num, int *id,
                         ismd_buffer_tag_storage_t **tag_storage)
{
   ismd_result_t result = ISMD_SUCCESS;
   bool tag_found = false;
   int tag_num;

   if ((buffer_num < 0) || (buffer_num >= ISMD_MAX_BUFFER_DESCRIPTORS)) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer_num %d invalid.\r\n", __func__, buffer_num);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else if ((*id < 0) || (*id >= ISMD_TAGS_PER_BUFFER)) {
      ISMD_LOG_MSG(1, "%s() : Error: id %d invalid.\r\n", __func__, *id);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else {
      for (tag_num = *id; tag_num < ISMD_TAGS_PER_BUFFER; tag_num++) {
         if (tag_context.tags[buffer_num][tag_num].in_use) {
            *tag_storage = &(tag_context.tags[buffer_num][tag_num]);
            *id = tag_num;
            tag_found = true;
            break;
         }
      }

      if (!tag_found) {
         result = ISMD_ERROR_NO_DATA_AVAILABLE;
      }
   }

   return result;
}

//****************************************************************************
// NAME:
//      find_tag_storage_except_type
//
// SYNOPSIS:
//      result = find_tag_storage_except_type(int buffer_num,
//                                     int *id,
//                                     int type,
//                                     ismd_buffer_tag_storage_t **tag_storage)
//          buffer_num    - tags array index
//			*id           - pointer to tag id (used as index into tag storage
//                          area array)
//          type          - tag type
//          **tag_storage - pointer to pointer that points to the located
//                          tag storage area
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_DATA_AVAILABLE if no tag of this type in use
//      ISMD_ERROR_INVALID_PARAMETER some parameter out of range
//
// DESCRIPTION:
//      This function locates the first "in use" tag in the array of tags
//      indicated by the buffer_num index that does NOT match the type passed
//      in by the caller.  The *id that is passed in by the caller is used as
//      the starting index in the tags array for begining the search.  If a
//      tag that is in use is located and that tag's type is NOT a match for
//      the type specified by the caller, the *tag_storage pointer is set to
//      point to it.  Also, the *id (tag array index) is set.
//****************************************************************************
static ismd_result_t
find_tag_storage_except_type(int buffer_num, int *id, int type,
                             ismd_buffer_tag_storage_t **tag_storage)
{
   ismd_result_t result = ISMD_SUCCESS;
   bool tag_found = false;
   int tag_num;

   if ((buffer_num < 0) || (buffer_num >= ISMD_MAX_BUFFER_DESCRIPTORS)) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer_num %d invalid.\r\n", __func__, buffer_num);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else if ((*id < 0) || (*id >= ISMD_TAGS_PER_BUFFER)) {
      ISMD_LOG_MSG(1, "%s() : Error: id %d invalid.\r\n", __func__, *id);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else if ((type < 0) || (type >= ISMD_BUFFER_TAG_MAX)) {
      ISMD_LOG_MSG(1, "%s() : Error: type %d invalid.\r\n", __func__, type);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else {
      for (tag_num = *id; tag_num < ISMD_TAGS_PER_BUFFER; tag_num++) {
         if (tag_context.tags[buffer_num][tag_num].in_use) {
            if (tag_context.tags[buffer_num][tag_num].tag.type != type) {
               *tag_storage = &(tag_context.tags[buffer_num][tag_num]);
               *id = tag_num;
               tag_found = true;
               break;
            }
         }
      }

      if (!tag_found) {
         result = ISMD_ERROR_NO_DATA_AVAILABLE;
      }
   }

   return result;
}


/*
Commenting out because:
	1) it's not being used and
	2) we need to hide the warnings

Not deleting it because it might be useful still and I don't feel like
trying to find it later in some other branch.
-Keith

static ismd_result_t detach_tag(int buffer_num, int id) {
   ismd_result_t result = ISMD_SUCCESS;

   if (tag_context.tags[buffer_num][id].in_use) {
      tag_context.tags[buffer_num][id].in_use = false;
   } else {
      result = ISMD_ERROR_INVALID_REQUEST;
   }

   return result;
}
*/

/*
Commenting out because
	1) it's not being used
	2) we need to hide the warnings

Not deleting it because it might be useful still and I don't feel like
trying to find it later in some other branch.
-Keith

static bool tags_in_buffer(int buffer_num) {
   bool tag_found = false;
   int tag_num;

   for (tag_num = 0; tag_num < ISMD_TAGS_PER_BUFFER; tag_num++) {
      if (tag_context.tags[buffer_num][tag_num].in_use == true) {
         tag_found = true;
         break;
      }
   }

   return tag_found;
}
*/


//****************************************************************************
// NAME:
//      ismd_tag_read
//
// SYNOPSIS:
//      result = ismd_tag_read(ismd_buffer_handle_t buffer,
//                             int type,
//                             int *id,
//                             ismd_buffer_tag_t *tag)
//          buffer - buffer handle
//          type   - tag type
//          id     - array index where search for tag should begin
//          *tag   - pointer to buffer tag
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_INVALID_HANDLE if buffer is not a valid handle
//      ISMD_ERROR_INVALID_PARAMETER if id is not in the valid range
//      ISMD_ERROR_NO_DATA_AVAILABLE if a tag matching the specified type
//                                   cannot be located
//
// DESCRIPTION:
//      This gets the first tag of the specified type associated with the
//      buffer after id.  If there are multiple tags, the id can be used
//      to iterate.
//
//      The id can be used in the detach function.
//      This does not lock the buffer.  It is assumed that if locking is needed
//      then the caller will handle it.
//****************************************************************************
static ismd_result_t
ismd_tag_read (ismd_buffer_handle_t  buffer,
               int                   type,
               int                  *id,
               ismd_buffer_tag_t    *tag)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_descriptor_t *buffer_desc;
   int buffer_num, version;
   ismd_buffer_tag_storage_t *tag_storage;

   ISMD_LOG_MSG(4, "%s() : entering function.\r\n", __func__);

   OS_ASSERT(buffer_tags_initialized);

   result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
   if (result != ISMD_SUCCESS) {
      ISMD_LOG_MSG(1, "%s() : Error: Could not find buffer %d.\r\n", __func__, buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer %d is not in allocated state.\r\n", __func__, buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if (*id < 0 || *id > ISMD_TAGS_PER_BUFFER) {
      ISMD_LOG_MSG(1, "%s() : Error: id %d invalid.\r\n", __func__, *id);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else if ((type < 0) || (type >= ISMD_BUFFER_TAG_MAX)) {
      ISMD_LOG_MSG(1, "%s() : Error: type %d invalid.\r\n", __func__, type);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else {

      if (!buffer_desc->tags_present) {
         result = ISMD_ERROR_NO_DATA_AVAILABLE;
      } else {

         UNPACK_BUFFER_HANDLE(buffer, buffer_num, version);

         result = find_tag_storage(buffer_num, id, type, &tag_storage);
         if (result == ISMD_SUCCESS) {
            OS_MEMCPY(tag, &(tag_storage->tag), sizeof(*tag));
         }
      }
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return result;
}


/*
Commenting out because:
	1) it's not being used
	2) we need to hide the warnings
Not deleting it because it might be useful still and I don't feel like
trying to find it later in some other branch.
-Keith

// Might clear the has_tags flag in the buffer descriptor.
// You can still use get_next after this, the IDs of other tags will
// not change.
// This does not lock the buffer.  It is assumed that if locking is needed
// then the caller will handle it.
static ismd_result_t ismd_tag_detach (
                        ismd_buffer_handle_t  buffer,
                        int                   id) {
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_descriptor_t *buffer_desc;
   int buffer_num, version;

   ISMD_LOG_MSG(4, "%s() : entering function.\r\n", __func__);

   OS_ASSERT(buffer_tags_initialized);

   result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
   if (result != ISMD_SUCCESS) {
      ISMD_LOG_MSG(1, "%s() : Error: Could not find buffer %d.\r\n", __func__, buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer %d is not in allocated state.\r\n", __func__, buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if (id < 0 || id > ISMD_TAGS_PER_BUFFER) {
      ISMD_LOG_MSG(1, "%s() : Error: id %d invalid.\r\n", __func__, id);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else {

      UNPACK_BUFFER_HANDLE(buffer, buffer_num, version);

      result = detach_tag(buffer_num, id);

      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG(1, "%s() : Tag %d does not exist on buffer %d.\r\n", id, __func__, buffer);
      } else {
         if (!tags_in_buffer(buffer_num)) {
            buffer_desc->tags_present = 0;
         }
      }
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return result;
}
*/


//****************************************************************************
// NAME:
//      ismd_tag_append_all
//
// SYNOPSIS:
//      result = ismd_tag_append_all(ismd_buffer_handle_t from_buffer,
//                                   ismd_buffer_handle_t to_buffer,
//                                   bool skip_type,
//                                   int type_to_skip)
//          from_buffer        - buffer handle for source tags
//          to_buffer          - buffer handle for destination tags
//          skip_type          - true  > don't copy tags of a specified type
//                               false > copy all tags
//          type_to_skip       - if skip_type is true, don't copy tags of this
//                               type
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_INVALID_HANDLE if the from_buffer or to_buffer are invalid
//      ISMD_ERROR_NO_RESOURCES if no free tag storage area is available
//      ISMD_ERROR_INVALID_PARAMETER some parameter out of range
//
// DESCRIPTION:
//      This function copies the tags from the from_buffer to the to_buffer
//      area.  There is a provision for skipping certain tag types if the
//      skip_type flag is set to 'true'.  The type to skip is specified by
//      the caller.  This does not lock the buffer.  It is assumed that if
//      locking is needed, the the caller will handle it.
//****************************************************************************
static ismd_result_t
ismd_tag_append_all (ismd_buffer_handle_t  from_buffer,
                     ismd_buffer_handle_t  to_buffer,
                     bool                  skip_type,
                     int                   type_to_skip,
                     bool                 *copied_any_tags)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_descriptor_t *from_buffer_desc = NULL;
   ismd_buffer_descriptor_t *to_buffer_desc = NULL;
   ismd_buffer_tag_storage_t *from_tag_storage = NULL;
   ismd_buffer_tag_storage_t *to_tag_storage = NULL;

   *copied_any_tags = false;

   ISMD_LOG_MSG(4, "%s() : entering function.\r\n", __func__);

   OS_ASSERT(buffer_tags_initialized);

   if ((result = ismd_buffer_find_descriptor(from_buffer, &from_buffer_desc)) != ISMD_SUCCESS) {
      ISMD_LOG_MSG(1, "%s() : Error: Could not find buffer %d.\r\n", __func__, from_buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if ((result = ismd_buffer_find_descriptor(to_buffer, &to_buffer_desc)) != ISMD_SUCCESS) {
      ISMD_LOG_MSG(1, "%s() : Error: Could not find buffer %d.\r\n", __func__, to_buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if (from_buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer %d is not in allocated state.\r\n", __func__, from_buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if (to_buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer %d is not in allocated state.\r\n", __func__, to_buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if ((type_to_skip < 0) || (type_to_skip >= ISMD_BUFFER_TAG_MAX)) {
      ISMD_LOG_MSG(1, "%s() : Error: type_to_skip %d is not in allocated state.\r\n", __func__, type_to_skip);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else {

      int  from_buffer_num, to_buffer_num, version;
      int  tag_num = 0;
      bool real_error = false;;

      UNPACK_BUFFER_HANDLE(from_buffer, from_buffer_num, version);
      UNPACK_BUFFER_HANDLE(to_buffer, to_buffer_num, version);

      while (result == ISMD_SUCCESS) {

         if (skip_type) {
            result = find_tag_storage_except_type(from_buffer_num, &tag_num, type_to_skip, &from_tag_storage);
         } else {
            result = find_tag_storage_untyped(from_buffer_num, &tag_num, &from_tag_storage);
         }
         tag_num++; // increment so next search does not start in same place and find same tag again.

         if (result == ISMD_SUCCESS) {
            result = find_free_tag_storage(to_buffer_num, &to_tag_storage, from_tag_storage->tag.type);
            if (result != ISMD_SUCCESS) {
               ISMD_LOG_MSG(1, "%s() : Error: No space on destination buffer %d.\r\n", __func__, to_buffer);
               real_error = true;
            } else {
               OS_MEMCPY(&(to_tag_storage->tag), &(from_tag_storage->tag), sizeof(to_tag_storage->tag));
               to_tag_storage->in_use = true;
               to_buffer_desc->tags_present = 1;
               *copied_any_tags = true;
            }
         }
      }

      if (!real_error) {
         result = ISMD_SUCCESS;
      }
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return result;
}


////////////////////////////////////////
// Exposed functions
////////////////////////////////////////

//****************************************************************************
// NAME:
//      ismd_buffer_tags_init
//
// SYNOPSIS:
//      result = ismd_buffer_tags_init(void)
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_ALREADY_INITIALIZED if the tag array has already been
//                                     initialized
//
// DESCRIPTION:
//      This function initializes the buffer tags by traversing the two
//      dimensional array of tags and setting the in_use flag to false
//      for each tag.
//****************************************************************************
ismd_result_t
ismd_buffer_tags_init(void)
{
   ismd_result_t result = ISMD_SUCCESS;
   int           buf_num, tag_num;

   ISMD_LOG_MSG(4, "%s(): entering function.\n", __func__);

   // Fail if already initialized.
   if (buffer_tags_initialized) {
      result = ISMD_ERROR_ALREADY_INITIALIZED;
      ISMD_LOG_MSG(2, "%s(): Warning: Tag manager already initialized.\n", __func__);
   } else {
      buffer_tags_initialized = true;

      // Set all tags to not in use
      for (buf_num = 0; buf_num < ISMD_MAX_BUFFER_DESCRIPTORS; buf_num++) {
         for (tag_num = 0; tag_num < ISMD_TAGS_PER_BUFFER; tag_num++) {
            tag_context.tags[buf_num][tag_num].in_use = false;
         }
      }
   }

   if (result == ISMD_SUCCESS) {
      ISMD_LOG_MSG(2, "Tag manager initiailzed successfully.\n");
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return result;
}


//****************************************************************************
// NAME:
//      ismd_buffer_tags_deinit
//
// SYNOPSIS:
//      result = ismd_buffer_tags_deinit(void)
//
// RETURNS:
//      ISMD_SUCCESS if successful
//
// DESCRIPTION:
//      This function simply sets the global buffer_tags_initialized flag
//      to false.
//****************************************************************************
ismd_result_t
ismd_buffer_tags_deinit(void)
{
   ismd_result_t result = ISMD_SUCCESS;

   // TODO: Do a more thorough de-init here

   buffer_tags_initialized = false;
   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_buffer
//
// SYNOPSIS:
//      result = ismd_tag_buffer(ismd_buffer_handle_t buffer,
//                               ismd_buffer_tag_t tag)
//          buffer             - buffer handle
//          tag                - tag to be stored
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//      ISMD_ERROR_NO_RESOURCES if no tag area available to store this tag
//
// DESCRIPTION:
//      This function locates a tag storage area for storing this tag
//      passed in by the caller.  When the storage area is located, the
//      data from tag is copied there and the tag storage area is marked
//      as "in use".  If no storage area is available, an error is returned.
//****************************************************************************
static ismd_result_t
ismd_tag_buffer (ismd_buffer_handle_t  buffer,
                 ismd_buffer_tag_t     tag)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_descriptor_t *buffer_desc;
   int buffer_num, version;
   ismd_buffer_tag_storage_t *tag_storage;

   ISMD_LOG_MSG(4, "%s() : entering function.\r\n", __func__);

   OS_ASSERT(buffer_tags_initialized);

   result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
   if (result != ISMD_SUCCESS) {
      ISMD_LOG_MSG(1, "%s() : Error: Could not find buffer %d.\r\n", __func__, buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer %d is not in allocated state.\r\n", __func__, buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else {

      UNPACK_BUFFER_HANDLE(buffer, buffer_num, version);

      result = find_free_tag_storage(buffer_num, &tag_storage, tag.type);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG(1, "%s() : Could not find any free tags on buffer %d.\r\n", __func__, buffer);
      } else {
         tag_storage->in_use = true;
         OS_MEMCPY(&(tag_storage->tag), &tag, sizeof(tag_storage->tag));
         buffer_desc->tags_present = 1;
      }
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_detach_all
//
// SYNOPSIS:
//      result = ismd_tag_detach_all(ismd_buffer_handle_t buffer)
//          buffer - buffer handle
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//
// DESCRIPTION:
//      This function traverses the array of tag storage areas associated
//      with the specified buffer handle and clears all the "in_use" flags.
//      This does not lock the buffer.  It is assumed that if locking is
//      needed, the the caller will handle it.
//****************************************************************************
ismd_result_t
ismd_tag_detach_all(ismd_buffer_handle_t  buffer)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_descriptor_t *buffer_desc;
   int buffer_num, version;
   int tag_num;

   ISMD_LOG_MSG(4, "%s() : entering function.\r\n", __func__);

   OS_ASSERT(buffer_tags_initialized);

   result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
   if (result != ISMD_SUCCESS) {
      ISMD_LOG_MSG(1, "%s() : Error: Could not find buffer %d.\r\n", __func__, buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if (buffer_desc->state != ISMD_BUFFER_STATE_ALLOCATED) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer %d is not in allocated state.\r\n", __func__, buffer);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else {

      UNPACK_BUFFER_HANDLE(buffer, buffer_num, version);

      if (buffer_num < ISMD_MAX_BUFFER_DESCRIPTORS) {
         for (tag_num = 0; tag_num < ISMD_TAGS_PER_BUFFER; tag_num++) {
            tag_context.tags[buffer_num][tag_num].in_use = false;
         }
         buffer_desc->tags_present = 0;
      } else {
         OS_ASSERT(false);
      }
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_set_newsegment
//
// SYNOPSIS:
//      result = ismd_tag_set_newsegment(ismd_buffer_handle_t buffer,
//                                       ismd_newsegment_tag_t newsegment_data)
//          buffer          - buffer handle
//          newsegment_data - the newsegment tag data
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_RESOURCES if no free tag storage area is available
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//
// DESCRIPTION:
//      This function will store the newsegment tag in the specified buffer.
//****************************************************************************
ismd_result_t
ismd_tag_set_newsegment(ismd_buffer_handle_t       buffer,
                        ismd_newsegment_tag_t      newsegment_data)
{
   ismd_result_t     result = ISMD_SUCCESS;

   //This is for backwards compatibility after segment_position field
   //added to ismd_newsegment_tag_t. Existing applications may still use
   //ismd_tag_set_newsegment to set NS tag, but the segment_position field
   //will be set to invalid automatically here.
   newsegment_data.segment_position = ISMD_NO_PTS;

   result = ismd_tag_set_newsegment_position(buffer, newsegment_data);

   return result;
}

//****************************************************************************
// NAME:
//      ismd_tag_set_newsegment_position
//
// SYNOPSIS:
//      result = ismd_tag_set_newsegment_position(ismd_buffer_handle_t buffer,
//                                       ismd_newsegment_tag_t newsegment_data)
//          buffer          - buffer handle
//          newsegment_data - the newsegment tag data
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_RESOURCES if no free tag storage area is available
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//
// DESCRIPTION:
//      This function will store the newsegment tag in the specified buffer.
//****************************************************************************
ismd_result_t
ismd_tag_set_newsegment_position(ismd_buffer_handle_t       buffer,
                        ismd_newsegment_tag_t      newsegment_data)
{
   ismd_result_t     result = ISMD_SUCCESS;
   ismd_buffer_tag_t tag;

   tag.type = ISMD_BUFFER_TAG_TYPE_NEWSEGMENT;

   OS_ASSERT(sizeof(ismd_newsegment_tag_t) <= ISMD_MAX_TAG_SIZE);
   OS_MEMCPY(tag.data, &newsegment_data, sizeof(tag.data));

   result = ismd_tag_buffer(buffer, tag);

   return result;
}

//****************************************************************************
// NAME:
//      ismd_tag_get_newsegment
//
// SYNOPSIS:
//      result = ismd_tag_get_newsegment(ismd_buffer_handle_t buffer,
//                                       ismd_newsegment_tag_t *newsegment_data)
//          buffer           - buffer handle
//          *newsegment_data - the newsegment tag data
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_DATA_AVAILABLE if no newsegment tag could be located
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//      ISMD_ERROR_NULL_POINTER if the newsegment_data is a null pointer
//
// DESCRIPTION:
//      This function will locate the newsegment tag in the specified buffer.
//****************************************************************************
ismd_result_t
ismd_tag_get_newsegment(ismd_buffer_handle_t       buffer,
                        ismd_newsegment_tag_t     *newsegment_data)
{
   ismd_result_t     result = ISMD_SUCCESS;
   ismd_buffer_tag_t tag;
   int               tag_id = 0;

   if (newsegment_data == NULL) {
      ISMD_LOG_MSG(1, "%s() : Error: newsegment_data pointer is NULL.\r\n", __func__);
      result = ISMD_ERROR_NULL_POINTER;
   } else {
      result = ismd_tag_read(buffer, ISMD_BUFFER_TAG_TYPE_NEWSEGMENT, &tag_id, &tag);
      if (result == ISMD_SUCCESS) {
         OS_MEMCPY(newsegment_data, tag.data, sizeof(*newsegment_data));
      }
   }
   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_set_eos
//
// SYNOPSIS:
//      result = ismd_tag_set_eos(ismd_buffer_handle_t buffer)
//          buffer          - buffer handle
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_RESOURCES if no free tag storage area is available
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//
// DESCRIPTION:
//      This function will insert an EOS tag in the specified buffer
//****************************************************************************
ismd_result_t
ismd_tag_set_eos(ismd_buffer_handle_t buffer)
{
   ismd_result_t     result = ISMD_SUCCESS;
   ismd_buffer_tag_t tag;

   tag.type = ISMD_BUFFER_TAG_TYPE_EOS;

   // Don't care about the data, there is none for EOS
   result = ismd_tag_buffer(buffer, tag);

   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_get_eos
//
// SYNOPSIS:
//      result = ismd_tag_get_eos(ismd_buffer_handle_t buffer);
//          buffer          - buffer handle
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_DATA_AVAILABLE if no EOS tag could be located
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//
// DESCRIPTION:
//      This function will locate an EOS tag in the specified buffer.
//****************************************************************************
ismd_result_t
ismd_tag_get_eos(ismd_buffer_handle_t buffer)
{
   ismd_result_t     result = ISMD_SUCCESS;
   ismd_buffer_tag_t tag;
   int               tag_id = 0;

   result = ismd_tag_read(buffer, ISMD_BUFFER_TAG_TYPE_EOS, &tag_id, &tag);
   // Don't care about the data, there is none for EOS

   return result;
}

//****************************************************************************
// NAME:
//      ismd_tag_set_dyn_attrs
//
// SYNOPSIS:
//      result = ismd_tag_set_dyn_attrs(ismd_buffer_handle_t buffer,
//                                      ismd_dyn_input_buf_tag_t attrs)
//          buffer - buffer handle
//          attrs  - dynamic attributes tag data
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_RESOURCES if no free tag storage area is available
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//
// DESCRIPTION:
//      This function will store the dynamic attributes tag in the specified
//      buffer.
//****************************************************************************
ismd_result_t
ismd_tag_set_dyn_attrs(ismd_buffer_handle_t       buffer,
                       ismd_dyn_input_buf_tag_t   attrs )
{
   ismd_result_t     result = ISMD_SUCCESS;
   ismd_buffer_tag_t tag;

   tag.type = ISMD_BUFFER_TAG_TYPE_DYN_ATTRS;

   OS_ASSERT(sizeof(ismd_dyn_input_buf_tag_t) <= ISMD_MAX_TAG_SIZE);
   OS_MEMCPY(tag.data, &attrs, sizeof(tag.data));

   result = ismd_tag_buffer(buffer, tag);

   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_get_dyn_attrs
//
// SYNOPSIS:
//      result = ismd_tag_get_dyn_attrs(ismd_buffer_handle_t buffer,
//                                      ismd_dyn_input_buf_tag_t attrs)
//          buffer - buffer handle
//          *attrs - pointer to dynamic attributes tag data storage area
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_DATA_AVAILABLE if no dynamic attributes tag is found
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//      ISMD_ERROR_NULL_POINTER if the pointer where to store the dynamic
//                              attributes data is null
//
// DESCRIPTION:
//      This function will locate the dynamic attributes tag and store the
//      data at the area pointed to by *attrs.
//****************************************************************************
ismd_result_t
ismd_tag_get_dyn_attrs(ismd_buffer_handle_t       buffer,
                       ismd_dyn_input_buf_tag_t  *attrs )
{
   ismd_result_t     result = ISMD_SUCCESS;
   ismd_buffer_tag_t tag;
   int               tag_id = 0;

   if (attrs == NULL) {
      ISMD_LOG_MSG(1, "%s() : Error: attrs pointer is NULL.\r\n", __func__);
      result = ISMD_ERROR_NULL_POINTER;
   } else {
      result = ismd_tag_read(buffer, ISMD_BUFFER_TAG_TYPE_DYN_ATTRS, &tag_id, &tag);
      if (result == ISMD_SUCCESS) {
         OS_MEMCPY(attrs, tag.data, sizeof(*attrs));
      }
   }

   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_set_client_id
//
// SYNOPSIS:
//      result = ismd_tag_set_client_id(ismd_buffer_handle_t buffer,
//                                      int id)
//          buffer - buffer handle
//          id     - the client ID
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_RESOURCES if no free tag storage area is available
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//      ISMD_ERROR_INVALID_PARAMETER some parameter out of range
//
// DESCRIPTION:
//      This function will store a new client ID tag in the specified buffer.
//****************************************************************************
ismd_result_t
ismd_tag_set_client_id(ismd_buffer_handle_t       buffer,
                       int                        id)
{
   ismd_result_t     result = ISMD_SUCCESS;
   ismd_buffer_tag_t tag;

   tag.type = ISMD_BUFFER_TAG_CLIENT_ID;

   OS_ASSERT(sizeof(int) <= ISMD_MAX_TAG_SIZE);
   OS_MEMCPY(tag.data, &id, sizeof(id));

   result = ismd_tag_buffer(buffer, tag);

   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_get_client_id
//
// SYNOPSIS:
//      result = ismd_tag_get_client_id(ismd_buffer_handle_t buffer,
//                                      int *id)
//          buffer - buffer handle
//          id     - the client ID pointer
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_DATA_AVAILABLE if no client ID tag is located
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//      ISMD_ERROR_INVALID_PARAMETER some parameter out of range
//
// DESCRIPTION:
//      This function will locate a client ID tag in the specified buffer
//      and store the ID at the area pointed to by *id.
//****************************************************************************
ismd_result_t
ismd_tag_get_client_id(ismd_buffer_handle_t       buffer,
                       int                       *id)
{
   ismd_result_t     result = ISMD_SUCCESS;
   ismd_buffer_tag_t tag;
   int               tag_id = 0;

   if (id == NULL) {
      ISMD_LOG_MSG(1, "%s() : Error: id pointer is NULL.\r\n", __func__);
      result = ISMD_ERROR_NULL_POINTER;
   } else {
      result = ismd_tag_read(buffer, ISMD_BUFFER_TAG_CLIENT_ID, &tag_id, &tag);
      if (result == ISMD_SUCCESS) {
		  OS_MEMCPY(id, tag.data, sizeof(*id));
      }
   }

   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_set_reclaim_event
//
// SYNOPSIS:
//      result = ismd_tag_set_reclaim_event(ismd_buffer_handle_t buffer,
//                                          ismd_event_t event)
//          buffer - buffer handle
//          event  - the event
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_RESOURCES if no free tag storage area is available
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//
// DESCRIPTION:
//      This function will store a new reclaim event tag in the specified
//      buffer.
//****************************************************************************
ismd_result_t
ismd_tag_set_reclaim_event(ismd_buffer_handle_t       buffer,
                           ismd_event_t               event)
{
   ismd_result_t     result = ISMD_SUCCESS;
   ismd_buffer_tag_t tag;

   if ((event != ISMD_EVENT_HANDLE_INVALID) && !active_smd_event(event)) {
      ISMD_LOG_MSG(1, "%s() : Error: invalid event supplied.\r\n", __func__);
      result = ISMD_ERROR_INVALID_HANDLE;
   } else {

      tag.type = ISMD_BUFFER_TAG_RECLAIM_EVENT;

      OS_ASSERT(sizeof(ismd_event_t) <= ISMD_MAX_TAG_SIZE);
      OS_MEMCPY(tag.data, &event, sizeof(event));

      result = ismd_tag_buffer(buffer, tag);
   }

   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_get_reclaim_event
//
// SYNOPSIS:
//      result = ismd_tag_get_reclaim_event(ismd_buffer_handle_t buffer,
//                                          ismd_event_t *event)
//          buffer - buffer handle
//          *event - pointer the event area
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_DATA_AVAILABLE if no reclaim event tag is located
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//
// DESCRIPTION:
//      This function will locate a reclaim event and store the event data
//      at the area pointed to by event.
//****************************************************************************
ismd_result_t
ismd_tag_get_reclaim_event (ismd_buffer_handle_t       buffer,
                            ismd_event_t              *event)
{
   ismd_result_t     result = ISMD_SUCCESS;
   ismd_buffer_tag_t tag;
   int               tag_id = 0;

   if (event == NULL) {
      ISMD_LOG_MSG(1, "%s() : Error: event pointer is NULL.\r\n", __func__);
      result = ISMD_ERROR_NULL_POINTER;
   } else {
      result = ismd_tag_read(buffer, ISMD_BUFFER_TAG_RECLAIM_EVENT, &tag_id, &tag);
      if (result == ISMD_SUCCESS) {
         OS_MEMCPY(event, tag.data, sizeof(*event));
      }
   }

   return result;
}


//****************************************************************************
// NAME:
//      ismd_tag_copy_all
//
// SYNOPSIS:
//      result = ismd_tag_copy_all(ismd_buffer_handle_t from_buffer,
//                                 ismd_buffer_handlt_t to_buffer)
//          from_buffer - source buffer handle
//          to_buffer   - destination buffer handle
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_RESOURCES if no free tag storage area is available
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//
// DESCRIPTION:
//      This function will copy all tags from one buffer to another.
//****************************************************************************
ismd_result_t
ismd_tag_copy_all (ismd_buffer_handle_t  from_buffer,
                   ismd_buffer_handle_t  to_buffer)
{
   bool unused_param;
   return ismd_tag_append_all(from_buffer, to_buffer, false, ISMD_BUFFER_TAG_NUM_TYPES, &unused_param); // setting not to skip any tags
}


//****************************************************************************
// NAME:
//      ismd_tag_copy_all_except_eos
//
// SYNOPSIS:
//      result = ismd_tag_copy_all_except_eos(ismd_buffer_handle_t from_buffer,
//                                            ismd_buffer_handlt_t to_buffer)
//          from_buffer - source buffer handle
//          to_buffer   - destination buffer handle
//
// RETURNS:
//      ISMD_SUCCESS if successful
//      ISMD_ERROR_NO_RESOURCES if no free tag storage area is available
//      ISMD_ERROR_INVALID_HANDLE if the buffer handle is invalid
//
// DESCRIPTION:
//      This function will copy all tags from one buffer to another except
//      for the EOS tags.
//****************************************************************************
ismd_result_t
ismd_tag_copy_all_except_eos (ismd_buffer_handle_t  from_buffer,
                              ismd_buffer_handle_t  to_buffer,
                              bool                 *copied_any_tags)
{
   return ismd_tag_append_all(from_buffer, to_buffer, true, ISMD_BUFFER_TAG_TYPE_EOS, copied_any_tags); // skip EOS tag
}
