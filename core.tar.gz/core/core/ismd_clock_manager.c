/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

/* smd_clock_manager.c implements the Clock Synchronization Manager */

#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core.h"
#include "smd_core_local_defs.h"
#include "ismd_core_protected.h"
#include "ismd_msg.h"
#include "gen3_clock.h"

/*
 * Define this if we want clock functions to be callable from top-half ISR functions.
 * Note that this feature requires that the Clock Manager has permissions to disable
 * interrupts (e.g. it is built for Linux Kernel mode).
 *
 * Also note this this is required to eliminate nasty priority inversion issues
 * in the clock.  Consider when a low-priority app thread calls a clock API and
 * locks it with a semaphore.  No one else can access that clock until the low
 * priority thread can run again.  Using the "top half safe" version eliminates
 * this problem because it turns off interrupts instead of using a semaphore.
 */
#define CLOCKS_ARE_TOP_HALF_SAFE

#define ISMD_CLOCKS_MAX                 64
#define ISMD_CLOCK_TYPES_MAX            32
#define ISMD_CLOCK_ALARMS_MAX           32

#define EVENT_STROBE_DELAY 0 // trigger immediately

#define VALIDATE_CLK_TYPE(type) ((type) > 0 && (type) < ISMD_CLOCK_TYPES_MAX)

typedef enum {
   ISMD_CLOCK_STATE_FREE      = 1,
   ISMD_CLOCK_STATE_ALLOCATED = 2
} clock_status_t;

typedef enum {
   ISMD_CLOCK_EVENT_STATE_FREE      = 1,
   ISMD_CLOCK_EVENT_STATE_ALLOCATED = 2,
} clock_alarm_state_t;

struct clock_context_t;

typedef struct clock_alarm_struct {
   ismd_time_t                scheduled_time;
   ismd_time_t                periodic_rate;
   ismd_event_t               async_event;
   struct clock_alarm_struct *next;
   bool                       triggered;
   ismd_clock_alarm_t         handle;
   struct clock_context_struct  *clock_context;
   clock_alarm_state_t        state;
} clock_alarm_context_t;

typedef struct clock_time_discontinuity_struct {
   ismd_event_t               async_event;
   ismd_time_t                threshold;
   ismd_clock_alarm_t         alarm_handle;
   ismd_clock_time_info_t     timeinfo;
} clock_time_discontinuity_t;

typedef struct clock_context_struct{
   int                     type;
   int                     instance;
   int                     signal;
   ismd_clock_dev_t        clock_dev_handle;
   clock_status_t          state;
   clock_alarm_context_t  *scheduled_alarms;
   clock_alarm_context_t   alarms[ISMD_CLOCK_ALARMS_MAX];
   ismd_clock_alarm_t      last_handle;
#ifdef CLOCKS_ARE_TOP_HALF_SAFE
   os_irqlock_t            lock;
   os_irqlock_local_t      irqlocal;
#else
   os_mutex_t               lock;
#endif
   bool                    primary;
   int64_t                 adjustment_value;
   clock_time_discontinuity_t time_discont;
} clock_context_t;

// A global lock used when it is necessary to disable interrupts
os_irqlock_t               clock_irq_lock;

// The IRQ locks are never nested, so it is safe to use a global
// variable.
os_irqlock_local_t         irqglobal;


int clock_debug_level =0;
static bool primary_clock_is_free = true;
os_mutex_t clock_global_lock;
#define DEBUG_PRINT(d, p...)  if(clock_debug_level >= d) OS_PRINT(p)


static clock_context_t clocks[ISMD_CLOCKS_MAX];
static ismd_clock_dev_ops_t clock_device_ops[ISMD_CLOCK_TYPES_MAX];


static void init_clock( clock_context_t *clock );
static clock_context_t *lookup_clock( ismd_clock_t handle );
static ismd_result_t lookup_and_lock_clock( ismd_clock_t clock_handle, clock_context_t **clock );
static bool lookup_clock_alarm_handle( ismd_clock_alarm_t      alarm_handle,
                                       clock_context_t        *clock,
                                       clock_alarm_context_t **clock_alarm);
static void init_clock_alarm( clock_alarm_context_t *clock_alarm , clock_context_t *clock);
static bool clock_is_allocated( clock_context_t *clock );
static void clock_lock( clock_context_t *clock );
static void clock_unlock( clock_context_t *clock );

static ismd_result_t schedule_next_alarm( clock_context_t *clock );
static ismd_result_t cancel_prev_alarm( clock_context_t *clock );

static bool alloc_alarm( clock_context_t        *clock,
                         clock_alarm_context_t **clock_alarm,
                         ismd_clock_alarm_t     *alarm_handle );

static void insert_alarm( clock_context_t       *clock,
                          clock_alarm_context_t *clock_alarm );
static void delete_alarm( clock_context_t       *clock,
                          clock_alarm_context_t *clock_alarm );

static void clock_manager_callback( void *param );

static void copy_device_ops(ismd_clock_dev_ops_t *dest_ops, ismd_clock_dev_ops_t *src_ops);
static ismd_result_t clock_add_alarm_to_strobe_event(clock_context_t *clock, ismd_event_t event);
static ismd_result_t clock_adjust_freq_internal(clock_context_t *clock, 
                                                int             adjustment); 
static ismd_result_t clock_set_freq_internal(clock_context_t *clock, 
                                             int             offset); 

//static void clock_alarm_cleanup( clock_context_t *clock );

void wrapper_clock_device_init(void);
void wrapper_clock_device_deinit( void );

/* Init clock power management functions */
ismd_result_t ismd_clock_pm_init(void);
/* Deinit clock power management functions */
void ismd_clock_pm_deinit(void);
/* Determine if power suspend is going or finished */
bool clock_check_suspending(void);

ismd_result_t ismd_clock_manager_init(void)
{
   ismd_result_t result = ISMD_SUCCESS;
   clock_context_t *clock;
   ismd_clock_t handle;
   int osal_result;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_manager_init(): entering function.\n" );
   osal_result = os_mutex_init( &clock_global_lock );
   OS_ASSERT( osal_result == OSAL_SUCCESS );
   
   for ( handle = 0; handle < ISMD_CLOCKS_MAX; handle++ ) {

      clock = lookup_clock( handle );
 
#ifdef CLOCKS_ARE_TOP_HALF_SAFE 
      os_irqlock_init(&clock->lock);
#else
      osal_result = os_mutex_init( &clock->lock );
#endif
      OS_ASSERT( osal_result == OSAL_SUCCESS );
      init_clock( clock );
   }

   for ( handle = 0; handle < ISMD_CLOCK_TYPES_MAX; handle++ ) {
      clk_dev_ops = &clock_device_ops[handle];
      clk_dev_ops->allocate              = NULL;
      clk_dev_ops->free                  = NULL;
      clk_dev_ops->get_time              = NULL;
      clk_dev_ops->get_last_vsync_time   = NULL;
      clk_dev_ops->trigger_software_event= NULL;
      clk_dev_ops->get_last_trigger_time = NULL;
      clk_dev_ops->set_time              = NULL;
      clk_dev_ops->adjust_time           = NULL;
      clk_dev_ops->schedule_alarm        = NULL;
      clk_dev_ops->cancel_alarm          = NULL;
      clk_dev_ops->set_alarm_handler     = NULL;
      clk_dev_ops->set_source            = NULL;
      clk_dev_ops->set_vsync_pipe        = NULL;
      clk_dev_ops->adjust_frequency      = NULL;
      clk_dev_ops->set_frequency         = NULL;
      clk_dev_ops->set_timestamp_trigger_source = NULL;
      clk_dev_ops->make_primary          = NULL;
      clk_dev_ops->reset_primary         = NULL;
      clk_dev_ops->clock_route           = NULL;
   }

   if (result == ISMD_SUCCESS) {
      os_irqlock_init(&clock_irq_lock);
   }

   wrapper_clock_device_init();
   ismd_clock_pm_init();
   ISMD_LOG_MSG( 2, "ismd_clock_manager_init(): exiting function.\n" );

   return ( result );
}

ismd_result_t ismd_clock_manager_deinit(void)
{
   ismd_result_t result = ISMD_SUCCESS;
   clock_context_t       *clock;
   ismd_clock_t           handle;

   ISMD_LOG_MSG( 4, "%s(): entering function.\n", __func__ );
   ismd_clock_pm_deinit();
   wrapper_clock_device_deinit();

   for ( handle = 0; handle < ISMD_CLOCKS_MAX; handle++ ) {
      clock = lookup_clock( handle );
#ifdef CLOCKS_ARE_TOP_HALF_SAFE 
      os_irqlock_destroy(&clock->lock);
#else
      os_mutex_destroy(&clock->lock);
#endif
   }

   if (result == ISMD_SUCCESS) {
      os_irqlock_destroy(&clock_irq_lock);
	  os_mutex_destroy(&clock_global_lock);
   }

   ISMD_LOG_MSG( 4, "%s(): exiting function.\n", __func__ );

   return ( result );
}

ismd_result_t ismd_clock_alloc( int           type,
                                ismd_clock_t *handle )
{
   ismd_clock_t            i;
   clock_context_t        *clock = NULL;
   ismd_result_t           result = ISMD_ERROR_NO_RESOURCES;
   ismd_clock_t            temp_handle = ISMD_CLOCK_HANDLE_INVALID;
   ismd_clock_dev_t        clock_dev_handle = ISMD_CLOCK_DEV_HANDLE_INVALID;
   ismd_clock_dev_ops_t   *clk_dev_ops;


   ISMD_LOG_MSG( 5, "ismd_clock_alloc(): entering function.\n" );

   if (!VALIDATE_CLK_TYPE(type)) {
      ISMD_LOG_MSG( 0, "ismd_clock_alloc(): invalid clock type %d.\n", type );
      return ISMD_ERROR_INVALID_PARAMETER;
   }

   clk_dev_ops = &clock_device_ops[type];
   if ( (clk_dev_ops->allocate == NULL) || (clk_dev_ops->free == NULL) ) {
      ISMD_LOG_MSG( 0, "ismd_clock_alloc(): clock device not registered.\n" );
      result = ISMD_ERROR_INVALID_PARAMETER;
   }
   else if ( (result = clk_dev_ops->allocate(type, &clock_dev_handle)) != ISMD_SUCCESS ) {
      ISMD_LOG_MSG( 2, "ismd_clock_alloc(): clock_device_ops.allocate() failed return code %d.\n", result );
   }
   else {
      result = ISMD_ERROR_NO_RESOURCES;

      for ( i = 0; i < ISMD_CLOCKS_MAX; i++ ) {
         clock = lookup_clock( i );
         if (clock != NULL) {
            clock_lock( clock );
            if ( clock_check_suspending()) {
               result = ISMD_ERROR_SUSPENDED;
               i = ISMD_CLOCKS_MAX; /* exit for-loop on next iteration.  */
            } else if ( !clock_is_allocated(clock) ) {
               clock->state = ISMD_CLOCK_STATE_ALLOCATED;
               temp_handle = i;
               i = ISMD_CLOCKS_MAX; /* exit for-loop on next iteration.  */
               result = ISMD_SUCCESS;
               ISMD_LOG_MSG( 3, "ismd_clock_alloc(): allocated clock %d.\n", *handle );
            }
            clock_unlock( clock );
         }
      }
   }

   if (clock != NULL) {
      if ( (result == ISMD_SUCCESS) && (clk_dev_ops->set_alarm_handler != NULL) ) {
         result = clk_dev_ops->set_alarm_handler(clock_dev_handle, clock_manager_callback);        
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_alloc(): clock_device_ops.set_alarm_handler() failed return code %d.\n", result );
         }
      }

      /* If any action failed, then cleanup all of the allocated resources. */
      if ( result != ISMD_SUCCESS ) {
         /* Not much we can do if any of these functions fail. */
         if ( clock_dev_handle != ISMD_CLOCK_DEV_HANDLE_INVALID ) {
            clk_dev_ops->free(clock_dev_handle);
         }
         if ( temp_handle != ISMD_CLOCK_HANDLE_INVALID ) {
            ismd_clock_free(temp_handle);
         }
      }
      else {
         clock->clock_dev_handle = clock_dev_handle;
         clock->type             = type;
         *handle = temp_handle;
         smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_CLOCK,
                                   SVEN_EV_SMDCore_Clock_Alloc,
                                   0,
                                   clock->clock_dev_handle,
                                   0,
                                   clock->type,
                                   *handle,
                                   result );

         /* ML: Work around to make all fixed clocks tied to the VCXO */
         if (clock->type == ISMD_CLOCK_TYPE_FIXED) {
            result = clock_device_ops->make_primary( clock->clock_dev_handle );
            if (result != ISMD_SUCCESS) {
               ISMD_LOG_MSG (0, "Error linking Fixed Clock to VCXO\n");
            }
         }
         /* ML: End Work around */
      }
   }

   ISMD_LOG_MSG( 4, "ismd_clock_alloc(): exiting function.\n" );

   return ( result );
}



ismd_result_t ismd_clock_free( ismd_clock_t handle )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_free(): entering function.\n" );

   //Reset Primary
   result = ismd_clock_reset_primary(handle);
   if(result != ISMD_SUCCESS) {
      ISMD_LOG_MSG( 2, "ismd_clock_free(): error: device reset_primary function returned %d.\n", result );
   }

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      if(clock->type == ISMD_CLOCK_TYPE_SW_CONTROLLED) {
         result = clock_set_freq_internal(clock, 0);
      }
      clock->state = ISMD_CLOCK_STATE_FREE;
      clk_dev_ops = &clock_device_ops[clock->type];
      if ( clk_dev_ops->cancel_alarm != NULL ) {
      clk_dev_ops->cancel_alarm( clock->clock_dev_handle );
      }

      clk_dev_ops->free( clock->clock_dev_handle );

      //Put the clock in initialized state
      init_clock( clock );
      result = ISMD_SUCCESS;
      ISMD_LOG_MSG( 3, "ismd_clock_free(): freed clock %d.\n", handle );
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_free(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_free(): exiting function.\n" );

   return ( result );
}



ismd_result_t ismd_clock_get_type( ismd_clock_t handle,
                                   int         *type )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;

   ISMD_LOG_MSG( 4, "ismd_clock_get_type(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      *type = clock->type;
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_get_type(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_get_type(): exiting function.\n" );

   return ( result );
}


/* For now, we register the same clock device operation functions for every clock. */
ismd_result_t ismd_clock_register_clock( ismd_clock_dev_ops_t *clock_descriptor )
{
   ismd_result_t result = ISMD_SUCCESS;

   ISMD_LOG_MSG( 4, "ismd_clock_register_clock(): entering function.\n" );

   if (clock_descriptor == NULL) {
      ISMD_LOG_MSG( 1, "ismd_clock_register_clock_type(): error: bad clock descriptor %d.\n", result );
      return ISMD_ERROR_INVALID_PARAMETER;
   }

   // defualt operations
   copy_device_ops(&clock_device_ops[0], clock_descriptor);

   copy_device_ops(&clock_device_ops[ISMD_CLOCK_TYPE_FIXED], clock_descriptor);
   copy_device_ops(&clock_device_ops[ISMD_CLOCK_TYPE_SW_CONTROLLED], clock_descriptor);

   ISMD_LOG_MSG( 4, "ismd_clock_register_clock(): exiting function.\n" );

   return ( result );
}

ismd_result_t ismd_clock_register_clock_type( int type, ismd_clock_dev_ops_t *clock_descriptor )
{
   ismd_result_t result = ISMD_SUCCESS;

   ISMD_LOG_MSG( 4, "ismd_clock_register_clock(): entering function.\n" );

   if (!VALIDATE_CLK_TYPE(type)) {
      ISMD_LOG_MSG( 0, "ismd_clock_alloc(): invalid clock type %d.\n", type );
      return ISMD_ERROR_INVALID_PARAMETER;
   }

   copy_device_ops(&clock_device_ops[type], clock_descriptor);

   ISMD_LOG_MSG( 4, "ismd_clock_register_clock(): exiting function.\n" );

   return ( result );
}

ismd_result_t ismd_clock_get_time( ismd_clock_t handle,
                                   ismd_time_t *time )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_time_t device_time;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_get_time(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->get_time == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_get_time(): error: clock device get time operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->get_time( clock->clock_dev_handle, &device_time );
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_get_time(): device get_time function returned %d.\n", result );
         }
         else {
            *time = device_time;
            smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_CLOCK,
                                      SVEN_EV_SMDCore_Clock_Get,
                                      handle,
                                      clock->clock_dev_handle,
                                      0,
                                      clock->type,
                                      (int) device_time,
                                      result );
         }
      }
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_get_time(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_get_time(): exiting function.\n" );

   return ( result );
}

ismd_result_t ismd_clock_trigger_software_event( ismd_clock_t handle)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_trigger_software_event(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->trigger_software_event== NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_trigger_software_event(): error: clock device get time operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->trigger_software_event( clock->clock_dev_handle);
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_trigger_software_event(): device trigger_software_event function returned %d.\n", result );
         }
      }
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_trigger_software_event(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_trigger_software_event(): exiting function.\n" );
   return ( result );
}


ismd_result_t ismd_clock_get_last_trigger_time( ismd_clock_t handle,
                                   ismd_time_t *time )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_time_t device_time;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_get_last_trigger_time(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->get_last_trigger_time == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_get_last_trigger_time(): error: clock device get time operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->get_last_trigger_time( clock->clock_dev_handle, &device_time );
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_get_last_trigger_time(): device get_last_trigger_time function returned %d.\n", result );
         }
         else {
            *time = device_time;
            smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_CLOCK,
                                      SVEN_EV_SMDCore_Clock_LastTrigTime,
                                      handle,
                                      clock->clock_dev_handle,
                                      0,
                                      clock->type,
                                      (int) device_time,
                                      result );
         }
      }
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_get_last_trigger_time(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_get_last_trigger_time(): exiting function.\n" );

   return ( result );
}



ismd_result_t ismd_clock_get_time_th_safe( ismd_clock_t handle,
                                   ismd_time_t *time )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_time_t device_time;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_get_time_th_safe(): entering function.\n" );

   clock = lookup_clock( handle );

   /* Th SAFE */
   if ( clock != NULL ) {
       os_irqlock_acquire(&clock_irq_lock, &irqglobal);

      if ( !clock_is_allocated(clock) || clock_check_suspending() ) {
          os_irqlock_release(&clock_irq_lock, &irqglobal);
         clock = NULL;
      }
   }
   /***********/

   if ( clock != NULL ) {
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->get_time == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_get_time_th_safe(): error: clock device get time operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->get_time( clock->clock_dev_handle, &device_time );
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_get_time_th_safe(): device get_time function returned %d.\n", result );
         }
         else {
            *time = device_time;
            smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_CLOCK,
                                      SVEN_EV_SMDCore_Clock_Get,
                                      handle,
                                      clock->clock_dev_handle,
                                      0,
                                      clock->type,
                                      (int) device_time,
                                      result );
         }
      }
      os_irqlock_release(&clock_irq_lock, &irqglobal);
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_get_time_th_safe(): invalid handle %d.\n", handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_get_time_th_safe(): exiting function.\n" );

   return ( result );
}





ismd_result_t ismd_clock_get_last_vsync_time( ismd_clock_t handle, ismd_time_t *time )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_time_t device_time;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_get_last_vsync_time(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->get_last_vsync_time == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_get_last_vsync_time(): error: clock device get time operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->get_last_vsync_time( clock->clock_dev_handle, &device_time );
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_get_last_vsync_time(): device get_last_vsync_time function returned %d.\n", result );
         }
         else {
            *time = device_time;
            smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_CLOCK,
                                      SVEN_EV_SMDCore_Clock_Get,
                                      handle,
                                      clock->clock_dev_handle,
                                      0,
                                      clock->type,
                                      (int) device_time,
                                      result );
         }
      }
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_get_last_vsync_time(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_get_last_vsync_time(): exiting function.\n" );

   return ( result );
}



/*Top Half Safe get_last_vsync_time */


ismd_result_t ismd_clock_get_last_vsync_time_th_safe( ismd_clock_t handle, ismd_time_t *time )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_time_t device_time;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_get_last_vsync_time_th_safe(): entering function.\n" );

   clock = lookup_clock( handle );

   /* Th SAFE */
   if ( clock != NULL ) {
      os_irqlock_acquire(&clock_irq_lock, &irqglobal);

      if ( !clock_is_allocated(clock) || clock_check_suspending()) {
         os_irqlock_release(&clock_irq_lock, &irqglobal);
         clock = NULL;
      }
   }
   /***********/

   if ( clock != NULL ) {
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->get_last_vsync_time == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG(0, "ismd_clock_get_last_vsync_time_th_safe(): error: clock device get time operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->get_last_vsync_time( clock->clock_dev_handle, &device_time );
         DEBUG_PRINT(2,"\n clock : %d th safe vsync : %llu", clock->clock_dev_handle, device_time);
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_get_last_vsync_time_th_safe(): device get_last_vsync_time_th_safe function returned %d.\n", result );
         }
         else {
            *time = device_time;
            smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_CLOCK,
                                      SVEN_EV_SMDCore_Clock_Get,
                                      handle,
                                      clock->clock_dev_handle,
                                      0,
                                      clock->type,
                                      (int) device_time,
                                      result );
         }
      }
      os_irqlock_release(&clock_irq_lock, &irqglobal);
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_get_last_vsync_time_th_safe(): invalid handle %d.\n", handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_get_last_vsync_time_th_safe(): exiting function.\n" );

   return ( result );
}




ismd_result_t ismd_clock_set_vsync_pipe( ismd_clock_t handle,
                                   int pipe )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_clock_dev_ops_t *clk_dev_ops;

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->set_vsync_pipe == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         DEBUG_PRINT( 0, "ismd_clock_set_vsync_pipe(): error: clock device set vsync pipe operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->set_vsync_pipe( clock->clock_dev_handle, pipe );
         if ( result != ISMD_SUCCESS ) {
            DEBUG_PRINT( 0, "ismd_clock_set_vsync_pipe(): error: device set_vsync_pipe function returned %d.\n", result );
         }
         else {
            DEBUG_PRINT( 2, "ismd_clock_set_vsync_pipe(): set clock %d vsync pipe to %d.\n", handle, pipe );
         }
      }
      clock_unlock( clock );
   }
   else {
      DEBUG_PRINT( 2, "ismd_clock_set_vsync_pipe(): fail result %d handle %d.\n", result, handle );
   }


   return ( result );
}



ismd_result_t ismd_clock_set_timestamp_trigger_source( ismd_clock_t handle,
                                                       int src )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_clock_dev_ops_t *clk_dev_ops;

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->set_timestamp_trigger_source == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         DEBUG_PRINT( 0, "ismd_clock_set_timestamp_trigger_source(): error: clock device set timestamp trigger source operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->set_timestamp_trigger_source( clock->clock_dev_handle, src );

         if ( result != ISMD_SUCCESS ) {
            DEBUG_PRINT( 0, "ismd_clock_set_timestamp_trigger_source(): error: device set_timestamp_trigger_source function returned %d.\n", result );
         }
         else {
            DEBUG_PRINT( 2, "ismd_clock_set_timestamp_trigger_source(): set clock %d  to src %d.\n", handle, src );
         }
      }
      clock_unlock( clock );
   }
   else {
      DEBUG_PRINT( 2, "ismd_clock_set_timestamp_trigger_source(): fail result %d handle %d.\n", result, handle );
   }
   return ( result );
}


ismd_result_t ismd_clock_set_time( ismd_clock_t handle,
                                   ismd_time_t  time )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_clock_dev_ops_t *clk_dev_ops;
   ismd_time_t curr_time;
   bool discontinuity_detected;
   ismd_clock_time_info_t timeinfo;
   ismd_event_t event_to_strobe = ISMD_EVENT_HANDLE_INVALID;
   bool event_strobed = false;

   ISMD_LOG_MSG( 2, "ismd_clock_set_time(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->set_time == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_set_time(): error: clock device set time operation not supported.\n" );
      }
      else if (time != ISMD_NO_PTS) {
         /* detect time discontinuity */
         discontinuity_detected = false;
         timeinfo = clock->time_discont.timeinfo;
         if (clk_dev_ops->get_time != NULL &&
            clk_dev_ops->get_time( clock->clock_dev_handle, &curr_time ) == ISMD_SUCCESS) {

            if ((clock->time_discont.threshold != 0 && clock->time_discont.threshold != ISMD_NO_PTS) &&
                ((time > curr_time && time > curr_time + clock->time_discont.threshold) ||
                (time < curr_time && time + clock->time_discont.threshold < curr_time))) {
               // time jump detected
               discontinuity_detected = true;
               timeinfo.set_timestamp_before_discontinuity = timeinfo.most_recent_set_timestamp;
               timeinfo.clock_time_of_set_timestamp_before_discontinuity = timeinfo.clock_time_of_most_recent_set_timestamp;
               timeinfo.clock_time_before_discontinuity = curr_time;
               timeinfo.set_timestamp_causing_discontinuity = time;
               timeinfo.clock_time_at_discontinuity = time;
               timeinfo.time_discontinuity_count++;

               if (clock->time_discont.async_event != ISMD_EVENT_HANDLE_INVALID) {
                  ISMD_LOG_MSG( 3, "ismd_clock_set_time(): strobing time jump event %d.\n", clock->time_discont.async_event);
                  event_to_strobe = clock->time_discont.async_event;
               }
            }
            timeinfo.current_time = time;
            timeinfo.second_recent_set_timestamp = timeinfo.most_recent_set_timestamp;
            timeinfo.most_recent_set_timestamp = time;
            timeinfo.clock_time_of_most_recent_set_timestamp = curr_time;
         }

         result = clk_dev_ops->set_time( clock->clock_dev_handle, time );
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_set_time(): error: device set_time function returned %d.\n", result );
         }
         else {
            // only update time info when set_time succeeded.
            clock->time_discont.timeinfo = timeinfo;

            // Handling the event strobe in an alarm callback
            // to let ismd_clock_set_time keep top half safe.
            if (event_to_strobe != ISMD_EVENT_HANDLE_INVALID) {
               result = clock_add_alarm_to_strobe_event(clock, event_to_strobe);
               if (result == ISMD_SUCCESS) {
                  event_strobed = true;
               }
            }

            // Update alarms only for wrapper clock.
            // If time jump event has been strobed, no need to update alarms,
            // because an fake alarm is used for strobing the event.
            if (clock->type == ISMD_CLOCK_TYPE_WRAPPER && !event_strobed) {
               cancel_prev_alarm( clock );

               if (clock->scheduled_alarms != NULL) {
                  result = schedule_next_alarm( clock );
               }
            }

            ISMD_LOG_MSG( 2, "ismd_clock_set_time(): set clock %d time to %lld.\n", handle, time );
         }
      } else {
         // Just return invalid parameter if set time to ISMD_NO_PTS
         ISMD_LOG_MSG( 2, "ismd_clock_set_time(): set clock %d time to ISMD_NO_PTS. Skipped.\n", handle );
         result = ISMD_ERROR_INVALID_PARAMETER;
      }
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_set_time(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_set_time(): exiting function.\n" );
   return ( result );
}

ismd_result_t ismd_clock_adjust_time( ismd_clock_t handle,
                                      int64_t  adjustment )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   clock_alarm_context_t *clock_alarm = NULL;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 2, "ismd_clock_adjust_time(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->adjust_time == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_adjust_time(): error: clock device adjust time operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->adjust_time( clock->clock_dev_handle, adjustment );
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_adjust_time(): error: device adjust_time function returned %d.\n", result );
         }
         else {
            clock->adjustment_value += adjustment;

            cancel_prev_alarm( clock );

            //Adjust the periodic alarms, so they continue to happen at a real periodic rate.
            clock_alarm = clock->scheduled_alarms;
            while ( clock_alarm != NULL ) {

               //If we have a period alarm, adjust the next scheduled time to go off.
               if ( clock_alarm->periodic_rate != 0 ) {
                  clock_alarm->scheduled_time += adjustment;
               }
               clock_alarm = clock_alarm->next;
            }
            if (clock->scheduled_alarms != NULL) {
               result = schedule_next_alarm( clock );
            }

            ISMD_LOG_MSG( 2, "ismd_clock_adjust_time(): adjust clock %d time by %lld.\n", handle, adjustment );
         }
      }
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_adjust_time(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_adjust_time(): exiting function.\n" );
   return ( result );
}

ismd_result_t ismd_clock_adjust_phase( ismd_clock_t handle,
                                      int64_t  adjustment )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 2, "ismd_clock_adjust_phase(): entering function.\n" );
   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->adjust_time == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_adjust_phase(): error: clock device adjust time operation not supported.\n" );
      }
      else {
         cancel_prev_alarm( clock );
         result = clk_dev_ops->adjust_time( clock->clock_dev_handle, adjustment);
     	 if ( result != ISMD_SUCCESS ) {
	        ISMD_LOG_MSG( 1, "ismd_clock_adjust_phase(): error: device adjust_phase function returned %d.\n", result );
	     } 
		 else {
		    ISMD_LOG_MSG( 2, "ismd_clock_adjust_phase(): adjust clock %d time by %lld.\n", handle, adjustment );
	     }
         schedule_next_alarm( clock );
      }
      clock_unlock( clock );
   }   
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_adjust_phase(): fail result %d handle %d.\n", result, handle );
   }
   ISMD_LOG_MSG( 4, "ismd_clock_adjust_phase(): exiting function.\n" );
   return ( result );
}


ismd_result_t ismd_clock_get_time_adjust_value( ismd_clock_t handle,
                                      int64_t  *adjustment )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;

   ISMD_LOG_MSG( 2, "ismd_clock_get_time_adjust_value(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      *adjustment = clock->adjustment_value;
      clock_unlock( clock );
      result = ISMD_SUCCESS;
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_get_time_adjust_value(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_get_time_adjust_value(): exiting function.\n" );
   return ( result );
}

ismd_result_t ismd_clock_alarm_schedule( ismd_clock_t        clock_handle,
                                         ismd_time_t         start_time,
                                         ismd_time_t         interval,
                                         ismd_event_t        async_event,
                                         ismd_clock_alarm_t *alarm_handle )
{
   ismd_result_t          result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t       *clock;
   clock_alarm_context_t *clock_alarm;
   ismd_time_t curr_time;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_alarm_schedule(): entering function.\n" );

   result = lookup_and_lock_clock( clock_handle, &clock );
   if ( ISMD_SUCCESS == result) {  

      clk_dev_ops = &clock_device_ops[clock->type];
      if ( (clk_dev_ops->schedule_alarm == NULL) || (clk_dev_ops->cancel_alarm == NULL) ) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_alarm_schedule(): error: clock device schedule_alarm operation not supported.\n" );
      }
      else if ( !alloc_alarm(clock, &clock_alarm, alarm_handle) ) {
         result = ISMD_ERROR_NO_RESOURCES;
      }
      else {

         if(interval!=0) {

            clk_dev_ops->get_time( clock->clock_dev_handle, &curr_time );
            ISMD_LOG_MSG(4, "\n Alarm time : %llu  Curr_time : %llu", start_time, curr_time);
            if ( start_time >= curr_time ) {
               clock_alarm->scheduled_time = start_time;
               ISMD_LOG_MSG(4, "\n Alarm time : %llu  > Curr_time : %llu", start_time, curr_time);
            }
            else {
               clock_alarm->scheduled_time = curr_time - OSAL_MOD64(curr_time - start_time, interval) ;
               ISMD_LOG_MSG(4, "\n Alarm time : %llu  < Curr_time : %llu : new_sched : %llu", start_time, curr_time, clock_alarm->scheduled_time);

            }
         }
         else  {
            clock_alarm->scheduled_time = start_time;
         }

         clock_alarm->periodic_rate  = interval;
         clock_alarm->async_event    = async_event;
         clock_alarm->next           = NULL;
         clock_alarm->state          = ISMD_CLOCK_EVENT_STATE_ALLOCATED;
         clock_alarm->triggered      = false;

         ISMD_LOG_MSG( 3, "ismd_clock_alarm_schedule(): created new alarm, time = 0x%llX, interval = 0x%llX.\n", start_time, interval );

         cancel_prev_alarm( clock );
         insert_alarm(clock, clock_alarm);
         result = schedule_next_alarm( clock );
      }
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_alarm_schedule(): fail result %d handle %d.\n", result, clock_handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_alarm_schedule(): exiting function.\n" );
   return ( result );
}


ismd_result_t ismd_clock_alarm_cancel( ismd_clock_t       clock_handle,
                                       ismd_clock_alarm_t alarm_handle )
{
   ismd_result_t          result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t       *clock;
   clock_alarm_context_t *clock_alarm;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_alarm_cancel(): entering function.\n" );

   result = lookup_and_lock_clock( clock_handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if ( clk_dev_ops->cancel_alarm == NULL ) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_alarm_cancel(): error: clock device cancel_alarm operation not supported.\n" );
      }
      else if ( !lookup_clock_alarm_handle(alarm_handle, clock, &clock_alarm) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
         ISMD_LOG_MSG( 2, "ismd_clock_alarm_cancel(): invalid alarm handle %d.\n", alarm_handle );
      }
      else  {
         result = cancel_prev_alarm( clock );
         delete_alarm(clock, clock_alarm);
         init_clock_alarm( clock_alarm , clock);
         schedule_next_alarm( clock );
         ISMD_LOG_MSG( 3, "ismd_clock_alarm_cancel(): clock %d alarm %d canceled.\n", clock_handle, alarm_handle );
      }
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_alarm_cancel(): fail result %d handle %d.\n", result, clock_handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_alarm_cancel(): exiting function.\n" );

   return (result);
}



ismd_result_t ismd_clock_adjust_freq( ismd_clock_t handle,
                                      int          adjustment )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;

   ISMD_LOG_MSG( 4, "ismd_clock_adjust_freq(): entering function.\n" );
   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  

      result = clock_adjust_freq_internal(clock, adjustment);
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_adjust_freq(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_adjust_freq(): exiting function.\n" );
   return ( result );
}



ismd_result_t 
ismd_clock_adjust_freq_th_safe( ismd_clock_t handle,
                                int          adjustment )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;

   ISMD_LOG_MSG( 4, "ismd_clock_adjust_freq(): entering function.\n" );
   clock = lookup_clock( handle );

   /* Th SAFE */
   if ( clock != NULL ) {
      os_irqlock_acquire(&clock_irq_lock, &irqglobal);

      if ( !clock_is_allocated(clock) || clock_check_suspending()) {
         os_irqlock_release(&clock_irq_lock, &irqglobal);
         clock = NULL;
      }
   }
   /***********/
   if ( clock != NULL ) {
      result = clock_adjust_freq_internal(clock, adjustment);
      os_irqlock_release(&clock_irq_lock, &irqglobal);
   }

   ISMD_LOG_MSG( 4, "ismd_clock_adjust_freq(): exiting function.\n" );
   return ( result );
}



/* Internal function which calls the clock driver to adjust the clock frequency.  This 
function assumes that caller already possess the lock to the given clock context.  */
static ismd_result_t 
clock_adjust_freq_internal(clock_context_t *clock, 
                           int             adjustment) 
{
   ismd_result_t  result = ISMD_ERROR_UNSPECIFIED;
   ismd_clock_dev_ops_t *clk_dev_ops;

   clk_dev_ops = &clock_device_ops[clock->type];
   if (clock_device_ops->adjust_frequency == NULL) {
      result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      ISMD_LOG_MSG( 2, "ismd_clock_adjust_freq(): error: clock device adjust_frequency operation not supported.\n" );
   }
   else if (clock->type != ISMD_CLOCK_TYPE_SW_CONTROLLED) {
      result = ISMD_ERROR_INVALID_REQUEST;
      ISMD_LOG_MSG( 0, "Invalid request for clock type : %d\n", clock->type );
   } else {     
      result = clock_device_ops->adjust_frequency( clock->clock_dev_handle, adjustment );
      if ( (result != ISMD_SUCCESS ) || (result != ISMD_ERROR_OUT_OF_RANGE)) {
         ISMD_LOG_MSG( 2, "ismd_clock_adjust_freq(): error: device adjust_freq function returned %d.\n", result );
      }
      else {
         smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_CLOCK,
                                   SVEN_EV_SMDCore_Clock_Adjust,
                                   clock->instance,
                                   clock->clock_dev_handle,
                                   0,
                                   clock->type,
                                   adjustment,
                                   result );
         result = ISMD_SUCCESS;   
         ISMD_LOG_MSG( 3, "ismd_clock_adjust_freq(): adjusted clock %d frequency by %d ppm.\n", clock->instance, adjustment );
      }
   }
   return result;
}


ismd_result_t 
ismd_clock_set_freq( ismd_clock_t handle,
                     int          offset )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;

   ISMD_LOG_MSG( 4, "ismd_clock_set_freq(): entering function.\n" );
   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  

      result = clock_set_freq_internal(clock, offset);
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_set_freq(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_set_freq(): exiting function.\n" );
   return ( result );
}




ismd_result_t 
ismd_clock_set_freq_th_safe( ismd_clock_t handle,
                             int          offset )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;

   ISMD_LOG_MSG( 4, "ismd_clock_set_freq(): entering function.\n" );
   clock = lookup_clock( handle );

   /* Th SAFE */
   if ( clock != NULL ) {
      os_irqlock_acquire(&clock_irq_lock, &irqglobal);

      if ( !clock_is_allocated(clock) || clock_check_suspending() ) {
         os_irqlock_release(&clock_irq_lock, &irqglobal);
         clock = NULL;
      }
   }
   /***********/
   if ( clock != NULL ) {
      result = clock_set_freq_internal(clock, offset);
      os_irqlock_release(&clock_irq_lock, &irqglobal);
   }

   ISMD_LOG_MSG( 4, "ismd_clock_set_freq(): exiting function.\n" );
   return ( result );
}



/* Internal function which calls the clock driver to adjust the clock frequency.  This 
function assumes that caller already possess the lock to the given clock context.  */
static ismd_result_t 
clock_set_freq_internal(clock_context_t *clock, 
                        int             offset) 
{
   ismd_result_t  result = ISMD_ERROR_UNSPECIFIED;
   ismd_clock_dev_ops_t *clk_dev_ops;

   clk_dev_ops = &clock_device_ops[clock->type];
   
   if (clock_device_ops->set_frequency == NULL) {
      result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      ISMD_LOG_MSG( 2, "ismd_clock_set_freq(): error: clock device set_frequency operation not supported.\n" );
   }
   else if (clock->type != ISMD_CLOCK_TYPE_SW_CONTROLLED) {
      result = ISMD_ERROR_INVALID_REQUEST;
      ISMD_LOG_MSG( 0, "Invalid request for clock type : %d\n", clock->type );
   } else {     
      result = clock_device_ops->set_frequency( clock->clock_dev_handle, offset );
      if ( (result != ISMD_SUCCESS ) || (result != ISMD_ERROR_OUT_OF_RANGE)) {
         ISMD_LOG_MSG( 2, "ismd_clock_set_freq(): error: device set_freq function returned %d.\n", result );
      }
      else {
         smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_CLOCK,
                                   SVEN_EV_SMDCore_Clock_SetFreq,
                                   clock->instance,
                                   clock->clock_dev_handle,
                                   0,
                                   clock->type,
                                   offset,
                                   result );
         result = ISMD_SUCCESS;   
         ISMD_LOG_MSG( 3, "ismd_clock_set_freq(): adjusted clock %d frequency by %d ppm.\n", clock->instance, offset );
      }
   }
   return result;
}



/*
 * Make this clock the clock that drives the audio and video renderers.
 */
ismd_result_t ismd_clock_make_primary( ismd_clock_t handle )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_make_primary(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];

      if (clk_dev_ops->make_primary == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_make_primary(): error: clock device make_primary operation not supported.\n" );
      } else {
         switch (clock->type) {
		 
		 case ISMD_CLOCK_TYPE_SW_CONTROLLED :
            os_mutex_lock(&clock_global_lock); 
		    if(primary_clock_is_free) {
		       result = clk_dev_ops->make_primary( clock->clock_dev_handle );
               if ( result != ISMD_SUCCESS ) {
                  ISMD_LOG_MSG( 2, "ismd_clock_make_primary(): error: device make_primary function returned %d.\n", result );
			      clock->primary = false;
               } else { 
			      clock->signal = ISMD_CLOCK_SIGNAL_VCXO;
                  clock->primary=true;			   	   				
				  primary_clock_is_free = false;
			   }			   
			} else {
			   result = ISMD_ERROR_NO_RESOURCES;
			}
			os_mutex_unlock(&clock_global_lock); 
		    break;
		 
		 case ISMD_CLOCK_TYPE_FIXED :
            result = clk_dev_ops->make_primary( clock->clock_dev_handle );
            if ( result != ISMD_SUCCESS ) {
               ISMD_LOG_MSG( 2, "ismd_clock_make_primary(): error: device make_primary function returned %d.\n", result );
			   clock->primary = false;
            } else { 
			   clock->signal = ISMD_CLOCK_SIGNAL_VCXO;
			   clock->primary = true;
			}		 
            break;
         default :
            ISMD_LOG_MSG( 2, "ismd_clock_make_primary(): Invalid request.\n");		 
			result = ISMD_ERROR_INVALID_REQUEST;
		 }		         
      }
	  clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 1, "ismd_clock_alarm_cancel(): fail result %d handle %d.\n", result, handle );
   }
   ISMD_LOG_MSG( 4, "ismd_clock_make_primary(): exiting function.\n" );
   return ( result );
}


ismd_result_t ismd_clock_reset_primary( ismd_clock_t handle )
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_reset_primary(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  

      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->reset_primary == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_reset_primary(): error: clock device reset_primary operation not supported.\n" );
      }
      else if(!clock->primary) {
          result = ISMD_SUCCESS;
          clock_unlock(clock);
          return(result);
      }

      result = clk_dev_ops->reset_primary( clock->clock_dev_handle );
      if ( result != ISMD_SUCCESS ) {
         ISMD_LOG_MSG( 2, "ismd_clock_reset_primary(): error: device reset_primary function returned %d.\n", result );
      }
      else {
         clock->primary = false;
		 clock->signal  = ISMD_CLOCK_SIGNAL_LOCAL_DDS;
		 if(clock->type == ISMD_CLOCK_TYPE_SW_CONTROLLED) {
            os_mutex_lock(&clock_global_lock); 
		    primary_clock_is_free = true;
			os_mutex_unlock(&clock_global_lock);
		 }
         ISMD_LOG_MSG( 3, "ismd_clock_reset_primary(): clock %d is now not the primary clock.\n", handle );

         /* ML: Work around to make all fixed clocks tied to the VCXO */
         if (clock->type == ISMD_CLOCK_TYPE_FIXED) {
            result = clock_device_ops->make_primary( clock->clock_dev_handle );
            if (result != ISMD_SUCCESS) {
               ISMD_LOG_MSG (0, "Error linking Fixed Clock to VCXO\n");
            }
         }
         /* ML: End Work Around */

      }
      clock_unlock( clock );
   }
   ISMD_LOG_MSG( 4, "ismd_clock_reset_primary(): exiting function.\n" );
   return ( result );
}


ismd_result_t 
ismd_clock_get_info(ismd_clock_t handle, ismd_clock_info_t *info) {
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;

   ISMD_LOG_MSG( 4, "ismd_clock_get_info(): entering function.\n" );

   if(info != NULL) {
      result = lookup_and_lock_clock( handle, &clock );
      if ( ISMD_SUCCESS == result) {  
         info->signal = clock->signal;
         info->type   = clock->type;	  
	     result = ISMD_SUCCESS;
         clock_unlock( clock );
      } else {
         ISMD_LOG_MSG( 2, "ismd_clock_get_info(): fail result %d handle %d.\n", result, handle );
      }
   } else { 
      result = ISMD_ERROR_NULL_POINTER;
   }	  
   ISMD_LOG_MSG( 4, "ismd_clock_get_info(): exiting function.\n" );
   return ( result );
}
ismd_result_t ismd_clock_get_primary( ismd_clock_t *handle )
{
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;
   clock_context_t *clock;
   int i;

   ISMD_LOG_MSG( 4, "ismd_clock_get_primary(): entering function.\n" );

   for ( i = 0; i < ISMD_CLOCKS_MAX; i++ ) {
      clock = lookup_clock( i );
      if (clock != NULL) {
         clock_lock( clock );
         if ( !clock_check_suspending() ) {
            if ( clock_is_allocated(clock) && clock->primary) {
               *handle = i;
               result = ISMD_SUCCESS;
               i = ISMD_CLOCKS_MAX; /* exit for-loop on next iteration.  */
               ISMD_LOG_MSG( 3, "ismd_clock_get_primary(): allocated clock %d.\n", *handle );
            }
         } else {
            result = ISMD_ERROR_SUSPENDED;
         }
         clock_unlock( clock );
      }
   }

   ISMD_LOG_MSG( 4, "ismd_clock_get_primary(): exiting function.\n" );
   return ( result );
}

ismd_result_t ismd_clock_route( ismd_clock_t handle,
                                int destination)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_route(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->clock_route == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_route(): error: clock device clock route operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->clock_route( clock->clock_dev_handle, destination);
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_route(): device clock_route function returned %d.\n", result );
         }
      }
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_route(): fail result %d handle %d.\n", result, handle );
   }
   ISMD_LOG_MSG( 4, "ismd_clock_route(): exiting function.\n" );
   return ( result );
}

ismd_result_t ismd_clock_set_source(ismd_clock_t handle,
                                    int          source)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;
   ismd_clock_dev_ops_t *clk_dev_ops;

   ISMD_LOG_MSG( 4, "ismd_clock_set_source(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clk_dev_ops = &clock_device_ops[clock->type];
      if (clk_dev_ops->set_source == NULL) {
         result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
         ISMD_LOG_MSG( 2, "ismd_clock_set_source(): error: clock device clock set_source operation not supported.\n" );
      }
      else {
         result = clk_dev_ops->set_source( clock->clock_dev_handle, source);
         if ( result != ISMD_SUCCESS ) {
            ISMD_LOG_MSG( 2, "ismd_clock_set_source(): device clock_set_source function returned %d.\n", result );
         }
      }
      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_set_source(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_set_source(): exiting function.\n" );
   return ( result );
}

ismd_result_t ismd_clock_set_time_discontinuity_event(ismd_clock_t handle,
                                             ismd_event_t event,
                                             ismd_time_t  threshold)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;

   ISMD_LOG_MSG( 4, "ismd_clock_set_time_discontinuity_event(): entering function.\n" );

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      clock->time_discont.async_event = event;
      clock->time_discont.threshold = threshold;
      clock_unlock( clock );
      result = ISMD_SUCCESS;
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_set_time_discontinuity_event(): fail result %d handle %d.\n", result, handle );
   }

   ISMD_LOG_MSG( 4, "ismd_clock_set_time_discontinuity_event(): exiting function.\n" );
   return ( result );
}
 
ismd_result_t ismd_clock_get_time_info(ismd_clock_t handle,
                                       ismd_clock_time_info_t *time_info)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_context_t *clock;

   ISMD_LOG_MSG( 4, "ismd_clock_get_time_info(): entering function.\n" );

   if (time_info == NULL) {
      ISMD_LOG_MSG( 0, "ismd_clock_get_time_info(): NULL parameterd.\n");
      return ISMD_ERROR_INVALID_PARAMETER;
   }

   result = lookup_and_lock_clock( handle, &clock );
   if ( ISMD_SUCCESS == result) {  
      *time_info = clock->time_discont.timeinfo;

      clock_unlock( clock );
   }
   else {
      ISMD_LOG_MSG( 2, "ismd_clock_get_time_info(): fail result %d handle %d.\n", result, handle );
   }

   result = ismd_clock_get_time(handle, &time_info->current_time);

   ISMD_LOG_MSG( 4, "ismd_clock_get_time_info(): exiting function.\n" );
   return ( result );
}

// Call this function in unlocked context.
ismd_result_t ismd_clock_device_set_power_state(icepm_state_t requested_state)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   ismd_clock_dev_ops_t *clk_dev_ops;
   clk_dev_ops = &clock_device_ops[ISMD_CLOCK_TYPE_FIXED];
   if (clk_dev_ops->set_power_state == NULL) {
      result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
   } else {
      result = clk_dev_ops->set_power_state(requested_state);
   }
   return result;   
}

static clock_context_t *lookup_clock( ismd_clock_t clock_handle )
{
   clock_context_t *clock_context = NULL;

   if ( (clock_handle >= 0) && (clock_handle < ISMD_CLOCKS_MAX) ) {
      clock_context = &(clocks[clock_handle]);
   }
   return ( clock_context );
}


static ismd_result_t lookup_and_lock_clock( ismd_clock_t clock_handle, clock_context_t **clock )
{
   ismd_result_t result = ISMD_SUCCESS;
   clock_context_t *clock_context;

   clock_context = lookup_clock( clock_handle );
   if ( clock_context != NULL ) {
      clock_lock( clock_context );
      if ( !clock_is_allocated(clock_context) ) {
         clock_unlock( clock_context );
         clock_context = NULL;
         result = ISMD_ERROR_INVALID_HANDLE;
      } else if ( clock_check_suspending() ) {
         clock_unlock( clock_context );
         clock_context = NULL;
         result = ISMD_ERROR_SUSPENDED;
      }
   } else {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   *clock = clock_context;
   return result;
}


static bool lookup_clock_alarm_handle( ismd_clock_alarm_t      alarm_handle,
                                       clock_context_t        *clock,
                                       clock_alarm_context_t **clock_alarm)
{
   bool result = false;
   ismd_clock_alarm_t i;

   for ( i = 0; i < ISMD_CLOCK_ALARMS_MAX; i++ ) {
      if ( (clock->alarms[i].handle == alarm_handle) &&
           (clock->alarms[i].state == ISMD_CLOCK_EVENT_STATE_ALLOCATED) ) {
         *clock_alarm = &(clock->alarms[i]);
         result = true;
         break;
      }
   }

   return ( result );
}


static bool clock_is_allocated( clock_context_t *clock )
{
   bool result = false;
   if ( clock->state != ISMD_CLOCK_STATE_FREE ) {
      result = true;
   }
   return ( result );
}



static void clock_lock( clock_context_t *clock )
{
#ifndef CLOCKS_ARE_TOP_HALF_SAFE
   os_mutex_lock( &(clock->lock) );
#else
   os_irqlock_acquire(&clock->lock, &clock->irqlocal);
#endif
}


static void clock_unlock( clock_context_t *clock )
{
#ifndef CLOCKS_ARE_TOP_HALF_SAFE
   os_mutex_unlock( &(clock->lock) );
#else
   os_irqlock_release(&clock->lock, &clock->irqlocal);
#endif
}

void lock_all_clocks(void)
{
   int handle;
   clock_context_t *clock;

#ifndef CLOCKS_ARE_TOP_HALF_SAFE
   for ( handle = 0; handle < ISMD_CLOCKS_MAX; handle++ ) {
      clock = &(clocks[handle]); 
      os_mutex_lock( &(clock->lock) );
   }
   /* lock the spin lock since it can be acquired by th_safe functions */
   os_irqlock_acquire(&clock_irq_lock, &irqglobal);

#else
   (void)handle;
   (void)clock;
   os_irqlock_acquire(&clock_irq_lock, &irqglobal);
#endif
}


void unlock_all_clocks(void)
{
   int handle;
   clock_context_t *clock;

#ifndef CLOCKS_ARE_TOP_HALF_SAFE   

   os_irqlock_release(&clock_irq_lock, &irqglobal);
   for ( handle = ISMD_CLOCKS_MAX - 1; handle >= 0; handle-- ) {
      clock = &(clocks[handle]); 
      os_mutex_unlock( &(clock->lock) );
   }
#else
   (void)handle;
   (void)clock;
   os_irqlock_release(&clock_irq_lock, &irqglobal);
#endif
}

static void init_clock( clock_context_t *clock )
{
   int i;

   clock->state            = ISMD_CLOCK_STATE_FREE;
   clock->type             = ISMD_CLOCK_TYPE_INVALID;
   clock->clock_dev_handle = ISMD_CLOCK_DEV_HANDLE_INVALID;
   clock->scheduled_alarms = NULL;
   clock->last_handle      = 0;
   clock->primary          = false;
   clock->adjustment_value = 0;
   clock->signal           = ISMD_CLOCK_SIGNAL_LOCAL_DDS;

   for ( i = 0; i < ISMD_CLOCK_ALARMS_MAX; i++ ) {
      init_clock_alarm( &(clock->alarms[i]), clock  );
   }

   clock->time_discont.async_event = ISMD_EVENT_HANDLE_INVALID;
   clock->time_discont.threshold = 0;
   clock->time_discont.alarm_handle = ISMD_CLOCK_ALARM_HANDLE_INVALID;
   clock->time_discont.timeinfo.current_time = ISMD_NO_PTS;
   clock->time_discont.timeinfo.second_recent_set_timestamp = ISMD_NO_PTS;
   clock->time_discont.timeinfo.most_recent_set_timestamp = ISMD_NO_PTS;
   clock->time_discont.timeinfo.clock_time_of_most_recent_set_timestamp = ISMD_NO_PTS;
   clock->time_discont.timeinfo.set_timestamp_before_discontinuity = ISMD_NO_PTS;
   clock->time_discont.timeinfo.clock_time_of_set_timestamp_before_discontinuity = ISMD_NO_PTS;
   clock->time_discont.timeinfo.clock_time_before_discontinuity = ISMD_NO_PTS;
   clock->time_discont.timeinfo.set_timestamp_causing_discontinuity = ISMD_NO_PTS;
   clock->time_discont.timeinfo.clock_time_at_discontinuity = ISMD_NO_PTS;
   clock->time_discont.timeinfo.time_discontinuity_count = 0;
}


static void init_clock_alarm( clock_alarm_context_t *clock_alarm , clock_context_t *clock )
{
   clock_alarm->async_event       = ISMD_EVENT_HANDLE_INVALID;
   clock_alarm->next              = NULL;
   clock_alarm->periodic_rate     = (uint64_t)0;
   clock_alarm->scheduled_time    = (uint64_t)0;
   clock_alarm->triggered         = false;
   clock_alarm->handle            = ISMD_CLOCK_ALARM_HANDLE_INVALID;
   clock_alarm->state             = ISMD_CLOCK_EVENT_STATE_FREE;
   clock_alarm->handle            = ISMD_CLOCK_ALARM_HANDLE_INVALID;
   clock_alarm->clock_context     = clock;
}


static bool alloc_alarm( clock_context_t        *clock,
                         clock_alarm_context_t **clock_alarm,
                         ismd_clock_alarm_t     *alarm_handle )
{
   bool result = false;
   int i;
   for ( i = 0; i < ISMD_CLOCK_ALARMS_MAX; i++ ) {
      if ( clock->alarms[i].state == ISMD_CLOCK_EVENT_STATE_FREE ) {
         clock->alarms[i].state = ISMD_CLOCK_EVENT_STATE_ALLOCATED;
         clock->last_handle++;
         clock->alarms[i].handle = clock->last_handle;
         result = true;
         *clock_alarm = &(clock->alarms[i]);
         *alarm_handle = clock->alarms[i].handle;
         ISMD_LOG_MSG( 4, "alloc_alarm(): allocated alarm %d, handle = %d.\n", i, clock->alarms[i].handle );
         break;
      }
   }
   return ( result );
}


static ismd_result_t schedule_next_alarm( clock_context_t *clock )
{
   ismd_result_t result = ISMD_ERROR_NOT_FOUND;
   clock_alarm_context_t *clock_alarm;

   clock_alarm = clock->scheduled_alarms;
   if ( clock_alarm != NULL ) {
      ISMD_LOG_MSG( 4, "schedule_next_alarm(): scheduling alarm handle %d at time %llx.\n", clock_alarm->handle, clock_alarm->scheduled_time );
      result = clock_device_ops[clock->type].schedule_alarm( clock->clock_dev_handle,
                                                clock_alarm,
                                                clock_alarm->scheduled_time );
      if ( result != ISMD_SUCCESS ) {
         ISMD_LOG_MSG( 2, "schedule_next_alarm(): device schedule_alarm function returned %d.\n", result );
      }
   }
   else {
      ISMD_LOG_MSG( 4, "schedule_next_alarm(): no alarms waiting to be scheduled.\n" );
   }
   return ( result );
}


static ismd_result_t cancel_prev_alarm( clock_context_t *clock )
{
   ISMD_LOG_MSG( 4, "cancel_prev_alarm(): canceling current alarm on clock device %d.\n", clock->clock_dev_handle );
   return ( clock_device_ops[clock->type].cancel_alarm(clock->clock_dev_handle) );
}


static void insert_alarm( clock_context_t       *clock,
                          clock_alarm_context_t *clock_alarm )
{
   clock_alarm_context_t *prev_alarm;

   /*
    * The queue is sorted by time.  The alarm with the lowest time is at the
    * head of the queue.  Here we want to find the right place to insert the
    * new alarm.
    */

   ISMD_LOG_MSG( 4, "insert_alarm(): inserting new alarm into queue, time=%llx\n", clock_alarm->scheduled_time );

   prev_alarm = NULL;
   clock_alarm->next = clock->scheduled_alarms;
   while ( clock_alarm->next != NULL ) {
      if ( clock_alarm->scheduled_time < (clock_alarm->next)->scheduled_time ) {
         break;
      }
      prev_alarm = clock_alarm->next;
      clock_alarm->next = (clock_alarm->next)->next;
   }

   /* Update the previous alarm's "next" pointer to point at the new alarm. */
   if ( prev_alarm != NULL ) {
      prev_alarm->next = clock_alarm;
   }
   else {
      clock->scheduled_alarms = clock_alarm;
   }

}


/* Remove an alarm from the queue of scheduled alarms. */
static void delete_alarm( clock_context_t       *clock,
                          clock_alarm_context_t *clock_alarm )
{
   clock_alarm_context_t  *prev_alarm;
   clock_alarm_context_t  *curr_alarm;

   prev_alarm = NULL;
   curr_alarm = clock->scheduled_alarms;
   while ( curr_alarm != NULL ) {
      if ( curr_alarm == clock_alarm ) {
         break;
      }
      prev_alarm = curr_alarm;
      curr_alarm = curr_alarm->next;
   }

   if ( curr_alarm == NULL ) {
      ISMD_LOG_MSG( 3, "delete_alarm(): clock alarm not found.\n" );
   }
   else {
      ISMD_LOG_MSG( 4, "delete_alarm(): deleting clock alarm with time=%llx\n", clock_alarm->scheduled_time );
      /* Update the previous alarm's "next" pointer to point at the following alarm. */
      if ( prev_alarm == NULL ) {
         clock->scheduled_alarms = curr_alarm->next;
      }
      else {
         prev_alarm->next = curr_alarm->next;
      }
   }
}


/*
 * Clock callback function, called by the clock device when the currently
 * scheduled alarm occurs.
 */
static void clock_manager_callback( void *param )
{
   clock_alarm_context_t *clock_alarm = (clock_alarm_context_t *)param;
   clock_context_t *clock = clock_alarm->clock_context;
   ismd_event_t event_to_strobe = ISMD_EVENT_HANDLE_INVALID;

   ISMD_LOG_MSG( 4, "clock_manager_callback(): entering function.\n" );

   clock_lock(clock);
   if(clock_is_allocated(clock)  && clock->scheduled_alarms==clock_alarm) {
      clock_alarm = clock->scheduled_alarms;

      OS_ASSERT( clock_alarm != NULL ); /* This means an alarm sounded while none were scheduled! */

      ISMD_LOG_MSG( 3, "clock_manager_callback(): strobing event %d.\n", clock_alarm->async_event );
      event_to_strobe = clock_alarm->async_event;

      /* Remove the alarm from the scheduled list. */
      delete_alarm( clock, clock_alarm );

      /* If the alarm was a one-shot, then initialize it so it can be re-used. */
      if (clock_alarm->periodic_rate == 0) {
         init_clock_alarm(clock_alarm, clock);
      }
      /* Otherwise, the alarm is periodic, so we need to re-schedule it. */
      else {
         clock_alarm->scheduled_time += clock_alarm->periodic_rate;
         insert_alarm( clock, clock_alarm );
      }

      schedule_next_alarm( clock );
   }
   clock_unlock(clock);

   // Handling the event strobe outside of the "locked" section
   // Since it can block.
   if (event_to_strobe != ISMD_EVENT_HANDLE_INVALID) {
      ismd_event_strobe(event_to_strobe);
   }

   ISMD_LOG_MSG( 4, "clock_manager_callback(): exiting function.\n" );

   return;
}

static void copy_device_ops(ismd_clock_dev_ops_t *dest_ops, ismd_clock_dev_ops_t *src_ops)
{
   OS_ASSERT(dest_ops != NULL);
   OS_ASSERT(src_ops != NULL);

   dest_ops->allocate                  = src_ops->allocate;
   dest_ops->free                      = src_ops->free;
   dest_ops->get_time                  = src_ops->get_time;
   dest_ops->get_last_vsync_time       = src_ops->get_last_vsync_time;
   dest_ops->trigger_software_event    = src_ops->trigger_software_event;
   dest_ops->get_last_trigger_time     = src_ops->get_last_trigger_time;
   dest_ops->set_time                  = src_ops->set_time;
   dest_ops->adjust_time               = src_ops->adjust_time;
   dest_ops->schedule_alarm            = src_ops->schedule_alarm;
   dest_ops->cancel_alarm              = src_ops->cancel_alarm;
   dest_ops->set_alarm_handler         = src_ops->set_alarm_handler;
   dest_ops->set_source                = src_ops->set_source;
   dest_ops->set_vsync_pipe            = src_ops->set_vsync_pipe;
   dest_ops->adjust_frequency          = src_ops->adjust_frequency;
   dest_ops->make_primary              = src_ops->make_primary;
   dest_ops->reset_primary             = src_ops->reset_primary;
   dest_ops->set_timestamp_trigger_source = src_ops->set_timestamp_trigger_source;
   dest_ops->clock_route               = src_ops->clock_route;
   dest_ops->set_frequency             = src_ops->set_frequency;  
   dest_ops->set_power_state           = src_ops->set_power_state;  
}

// call this function in locked context
ismd_result_t clock_add_alarm_to_strobe_event(clock_context_t *clock, ismd_event_t event)
{
   ismd_result_t          result = ISMD_ERROR_INVALID_HANDLE;
   clock_alarm_context_t *clock_alarm;
   ismd_time_t curr_time;
   ismd_time_t start_time;
   ismd_clock_dev_ops_t *clk_dev_ops;

   clk_dev_ops = &clock_device_ops[clock->type];
   if ( (clk_dev_ops->schedule_alarm == NULL) || (clk_dev_ops->cancel_alarm == NULL) ) {
      result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
      ISMD_LOG_MSG( 2, "clock_strobe_event(): error: clock device schedule_alarm operation not supported.\n" );
   }
   else if ( !alloc_alarm(clock, &clock_alarm, &clock->time_discont.alarm_handle) ) {
      result = ISMD_ERROR_NO_RESOURCES;
   }
   else {

      clk_dev_ops->get_time( clock->clock_dev_handle, &curr_time );
      start_time = curr_time + EVENT_STROBE_DELAY;
      ISMD_LOG_MSG(4, "\n Alarm time : %llu  Curr_time : %llu", start_time, curr_time);

      clock_alarm->scheduled_time = start_time;
      clock_alarm->periodic_rate  = 0;
      clock_alarm->async_event    = event;
      clock_alarm->next           = NULL;
      clock_alarm->state          = ISMD_CLOCK_EVENT_STATE_ALLOCATED;
      clock_alarm->triggered      = false;

      ISMD_LOG_MSG( 3, "clock_strobe_event(): created new alarm, time = 0x%llX, interval = 0x%llX.\n", start_time, 0LL);

      cancel_prev_alarm( clock );
      insert_alarm(clock, clock_alarm);
      result = schedule_next_alarm( clock );
   }

   return result;
}

#if 0
/*
 * clock_alarm_cleanup is currently not used, but we may need to use it again
 * if we find performance issues with scheduling clock_alarms inside of the
 * callback function.  If this happens we may need create a
 * "clock_cleanup_thread" which is triggered by the callback function to
 * clean up and re-schedule clock alarms.  That thread can just wait for
 * an event to trigger and call this function.
 */

static void clock_alarm_cleanup( clock_context_t *clock ) {

   clock_alarm_context_t *clock_alarm;

   /* Cancel any previously-scheduled alarm. */
   cancel_prev_alarm( clock );

   clock_alarm = clock->scheduled_alarms;
   while ( clock_alarm != NULL ) {

      ISMD_LOG_MSG( 4, "clock_alarm_cleanup(): scanning alarm handle %d.\n", clock_alarm->handle );

      if ( clock_alarm->triggered == true ) {

         ISMD_LOG_MSG( 4, "clock_alarm_cleanup(): clock alarm %d triggered, time=0x%llx, async_event=%d.\n",
                       clock_alarm->handle,
                       clock_alarm->scheduled_time,
                       clock_alarm->async_event );

         /* Remove the alarm from the list. */
         delete_alarm( clock, clock_alarm );

         /* If it's a one-shot alarm, then clear it so it can be re-used. */
         if (clock_alarm->periodic_rate == 0) {
            init_clock_alarm(clock_alarm);
         }
         /* Otherwise, it's a periodic alarm, so reschedule it. */
         else {
            ISMD_LOG_MSG( 4, "clock_alarm_cleanup(): rescheduling alarm handle %d\n", clock_alarm->handle );

            clock_alarm->triggered = false;
            clock_alarm->scheduled_time += clock_alarm->periodic_rate;
            insert_alarm( clock, clock_alarm);
         }
         clock_alarm = clock->scheduled_alarms;
      }
      else {
         clock_alarm = clock_alarm->next;
      }
   }

   /* Schedule the alarm at the head of the list */
   schedule_next_alarm( clock );

   return;
}

#endif


