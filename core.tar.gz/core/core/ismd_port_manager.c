/*  

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

/* ismd_port_manager implements the Port Manager */

/*
 * SYNCHRONIZATION:
 * =========================================
 * Given that ports need to be thread-safe, each has a lock.  There are
 * two complex cases to consider when using connected ports, however, 
 * because deadlock becomes possible (we are dealing with two locks).
 *
 * The act of connecting ports requires locks on both ports, since the data
 * structures of both must be read and modified.  Deadlock can happen here
 * if two clients try to connect the ports at the same time and the order
 * of the ports is different in each call.  One call will lock one port and
 * if the timing is right, the other will lock the other port.  Both clients
 * are waiting for the other lock which the other client has and they wait
 * forever. This in itself is not too bad, as the connect function can 
 * internally arrange the order of locking so that the producer port is always
 * locked first.
 *
 * The more complex case comes up when writing to or reading from a pair of 
 * connected ports.  Since writing to or reading from a connected port triggers
 * operations on its peer (via queue callbacks), both ports must be locked to
 * prevent race conditions with other operations using the peer port.  This can
 * result in deadlock if one client writes to a connected port while another
 * reads from its peer port.  It is not practical to change the order of locking
 * in this case because in order to get the peer port (to lock it first) we
 * need to access this port's data structures which requires this port to be 
 * locked: the port supplied as an argument to the function must be locked
 * before its peer is.
 *
 * In order to solve this, a new lock is created to represent a "connection"
 * This connection lock is owned by one of the ports and both ports in a 
 * connection have a pointer to it - set up during connect.  The locking order
 * for operations on a connected port is always port lock, then connection lock.
 * The connection lock is always obtained last and thus deadlocks are avoided.
 *
 *
 *           port1                                 port2
 *   ______________________               ______________________
 *  |lock  &connection_lock|             |lock  &connection_lock|
 *  |______________________|             |______________________|
 *                         ..          ..
 *                            ..    ..
 *                         connection lock
 *               (actually exists in one of the ports)
 *
 * If a read happens on port 2 above, at the same time a write happens on port
 * 1, the reader will get port 2's lock and then try for the connection lock.
 * The writer will get port 1's lock and then try for the connection lock.
 * One of them will be successful in getting the connection lock and the other 
 * will wait, so there is never a deadlock.  
 *
 * It is important that all operations use the connection lock, even if they 
 * really just need to access on port - otherwise it's possible to have race 
 * conditions again.  For this reason, the port_lock() and port_unlock() 
 * functions always get the port's lock and the lock pointed to by the port's 
 * connection lock pointer.  Before ports are connected, this pointer points to
 * the extra lock that exists in the port (so there is a bit of redundant 
 * locking here) and after connection this pointer points to the extra lock in
 * the output port.
 *
 * A global lock exists for the setup and tear down routines: alloc, free,
 * connect, and disconnect.  
 *
 * Adding this global lock removed the needs for the port locking order.
 *
 * CALLBACKS:
 * =========================================
 * As the HLD explains, eahc port has an ISMD queue inside of it.  Each ISMD
 * queue has two callback functions (one for each end).  The ports rely on these
 * callback functions to implement the connect and event functionalities.
 *
 * There are three callback functions implemented and used in this code:
 *  - port_connect_pull()
 *  - port_connect_push()
 *  - port_set_event()
 *
 * The first two callbacks are used for connected ports.  port_connect_pull()
 * is registered to the input of the input port's queue - this will pull a
 * buffer from the output port's queue when the input port needs a buffer.
 * port_connect_push() is registered to the output side of the output port's
 * queue - this will push a buffer to the input port's queue when the output
 * port has a buffer to push.  The functionality of these callbacks is shown 
 * below:
 *                             (port_connect_push)
 *                               __push buffers__ 
 *           output port        |                |   input port
 *    ...._____________________/\              _\/____________________....
 *          queue_push_callback  |            |queue_pull_callback
 *          (port_connect_push)  |            |(port_connect_pull)
 *    ...._______________________|            |_______________________....
 *                             \/               /\
 *                              |_pull buffers__|
 *                             (port_connect_pull)
 *
 * This way, whenever something happens to either queue, a buffer will either
 * be pulled or pushed through the connection without needing an extra context.
 *
 * Now, either one or both ends of a port must be connected to a non-core
 * client, such as an ISMD driver or a client application.  It is possible for
 * these entities to simply poll on whether the port can accept or produce
 * buffers in a loop, but a much better solution is for them to use events to
 * trigger port operations.  Each port supports two events - an input and an
 * output event.  When events are used, the port uses the queue callbacks to
 * call a function to trigger these events.
 *
 *       input end of port                          output end of port
 *       _____________________....           ...._____________________
 *      |queue_pull_callback                       queue_push_callback|
 *      | (port_set_event)                           (port_set_event) |
 *      |________|____________....           ....___________|_________|
 *               |                                          |
 *  <____________|                                          |_____________>
 *    set event                                                set event
 *
 *
 * Note that the diagram above may be shoing two ports (if they're connected)
 * or both sides of a single port if no connection is used.
 *
 * Finally, a full diagram for two connected ports is shown below:
 *
 *                             
 *                               __push buffers__ 
 *             output port      |                |     input port
 *        _____________________/\              _\/____________________
 *       |                       |            |                       |
 *       |input end    output end|            |input end    output end|
 *       |_______|_______________|            |_______________|_______|
 *               |             \/               /\            |
 *  <____________|              |_pull buffers__|             |_____________>
 *    set event                                                  set event
 *
 *
 *
 * The rest of the code in here is pretty straightforward assuming that the
 * reader is familiar with the ISMD Port Manager HLD.
 */


#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core.h"
#include "ismd_core_protected.h"
#include "smd_core_local_defs.h"
#include "ismd_msg.h"


/*
 * There defines specify the maximum number of resources exist.  Using static 
 * memory prevents us from the performance hit and possible bugs associated with
 * using dynamically-allocated memory.
 */
 // TODO: What's the right number for this
#define ISMD_MAX_PORTS 100           // Should always be smaller than 16,384

#define ISMD_MAX_PORT_CONNECTION 2 //for T-Port, or any other split at the pipeline.

/*
 * Default settings associated with the named port functionality.
 */
#define INVALID_VIRTUAL_PORT_ID -1
#define DEFAULT_PORT_NAME "unnamed_port"

os_mutex_t global_connection_lock;

typedef os_mutex_t ismd_port_lock_t;

/*
 * In order to help with decision-making and error checking, 
 * each port has a state.
 */
typedef enum {
   ISMD_PORT_STATE_INVALID   = 0,   /* Only used during the init of the port (when the port is not locked) */
   ISMD_PORT_STATE_FREE      = 1,
   ISMD_PORT_STATE_ALLOCATED = 2,   /* Not connected in this state */
   ISMD_PORT_STATE_CONNECTED = 3    /* Connected state implies allocated as well. */
} ismd_port_state_t;

typedef struct {
   ismd_event_t         event;
   ismd_queue_event_t   event_mask;
} ismd_port_event_t;


typedef struct ismd_port_struct {
     ismd_port_type_t         port_type;            /* Type of port (e.g. input or output) */
     ismd_port_attributes_t   attributes;           /* Flags that specify attributes of the port (a bitwise-or of values from ismd_port_attributes_t). */
   volatile ismd_port_state_t state;                /* Current state of this port.  See port_alloc_named why it is volatile*/
     ismd_queue_handle_t      queue_handle;         /* Handle to a queue associated with this port. */
     struct ismd_port_struct *connection[ISMD_MAX_PORT_CONNECTION];   /* an array of Pointers to the ports that this port is connected to, if in connected state. */
     int                      num_connections;     
     ismd_port_event_t        input_event;
     ismd_port_event_t        output_event;
     ismd_port_lock_t         port_lock;
     ismd_port_lock_t         connection_lock;      /* See discussion at top of file about how the locking works */
     ismd_port_lock_t        *connection_lock_ptr;
     bool                     tip_pending_inputs[ISMD_MAX_PORT_CONNECTION];  /* indicates the input ports that are still waiting to get the buffer at the tip of the output port*/

     int                      virtual_port_id;
     char                     name[SMD_PORT_NAME_LENGTH];
     ismd_port_handle_t       connection_handle[ISMD_MAX_PORT_CONNECTION];    /* Only for SVEN */
     uint16_t                 version_id;           /* Used to prevent using stale handles */
     uint16_t                 port_num;             /* Used for debug only.  Index of ismd_ports array. */
} ismd_port_t;


ismd_port_t ismd_ports[ISMD_MAX_PORTS];


static ismd_result_t init_port( ismd_port_t        *port, 
                                ismd_port_type_t    port_type, 
                                ismd_port_config_t *port_config );
static bool valid_port_handle( ismd_port_handle_t handle );
static bool lookup_port_unversioned( ismd_port_handle_t handle, ismd_port_t **port );
static bool lookup_port( ismd_port_handle_t handle, ismd_port_t **port );
static bool valid_port_type( ismd_port_type_t type );
static bool valid_port_attributes( ismd_port_attributes_t port_attributes );
static void port_lock( ismd_port_t *port );
static void port_unlock( ismd_port_t *port );
static bool is_multiple_connections(ismd_port_t *output_port);
static int which_output_index(ismd_port_t *input_port);
static bool is_other_inputs_pending(ismd_port_t *input_port, ismd_port_t *output_port);
static void update_all_tip_pending_inputs(ismd_port_t *outpurt_port);
static ismd_result_t push_buffer_to_inputs(ismd_port_t *output_port, int except_index, ismd_buffer_handle_t buffer);
static ismd_result_t pass_tip_buffer_and_push_it(ismd_port_t *output_port, 
                                                 int caller_index, ismd_buffer_handle_t *buffer);



#define PACK_PORT_HANDLE(packed_handle, base_handle, version_id) \
   ((packed_handle) = ((base_handle) | ((version_id) << 16)))

#define UNPACK_PORT_HANDLE(packed_handle, base_handle, version_id) \
   ((base_handle) = ((packed_handle) & 0xFFFF)); \
   ((version_id) = (((unsigned int)(packed_handle) >> 16) & 0xFFFF))

/*
 * These two functions are queue callbacks used for connected ports.
 * The pull function is used when the input port's queue needs a buffer.  It 
 * pulls a buffer from the connected output port's queue.
 * The push function is used when the output port's queue has a buffer.  It 
 * pushes a buffer to the connected input port's queue.
 */
static ismd_result_t port_connect_pull( void                      *context, 
                                        ismd_queue_event_t         queue_event, 
                                        ismd_buffer_handle_t      *buffer );

static ismd_result_t port_connect_push( void                     *context, 
                                        ismd_queue_event_t        queue_event, 
                                        ismd_buffer_handle_t      buffer );

static ismd_result_t port_set_event_output( void                     *context, 
                                            ismd_queue_event_t        queue_event, 
                                            ismd_buffer_handle_t      buffer );
static ismd_result_t port_set_event_input( void                     *context, 
                                           ismd_queue_event_t        queue_event, 
                                           ismd_buffer_handle_t     *buffer );


/* ismd_port_manager_init should be called only once during the SMD Core driver initialization. */
/* This needs to be called before the other port functions are called. */
ismd_result_t ismd_port_manager_init(void)
{
   ismd_result_t      result = ISMD_SUCCESS;
   ismd_port_handle_t handle;
   ismd_port_t       *port;
   int                osal_result;
   int                index;

   ISMD_LOG_MSG( 4, "ismd_port_manager_init(): entering function.\n" );

   osal_result = os_mutex_init( &global_connection_lock );
   if ( osal_result != OSAL_SUCCESS ) {
      ISMD_LOG_MSG( 1, "ismd_port_manager.c : ismd_port_manager_init() : ERROR : os_mutex_init returned %d.\n", osal_result );
      result = ISMD_ERROR_UNSPECIFIED;
   } else {

      for ( handle = 0; handle < ISMD_MAX_PORTS; handle++ ) {
         if ( !lookup_port_unversioned( handle, &port ) ) {
            ISMD_LOG_MSG( 1, "ismd_port_manager.c : ismd_port_manager_init() : internal error searching for uninitialized ports.\n" );
            result = ISMD_ERROR_UNSPECIFIED;
            break;
         }

         osal_result = os_mutex_init( &(port->connection_lock) );
         if ( osal_result != OSAL_SUCCESS ) {
            ISMD_LOG_MSG( 1, "ismd_port_manager.c : ismd_port_manager_init() : ERROR : os_mutex_init returned %d.\n", osal_result );
            result = ISMD_ERROR_UNSPECIFIED;
            break;
         }
         osal_result = os_mutex_init( &(port->port_lock) );
         if ( osal_result != OSAL_SUCCESS ) {
            ISMD_LOG_MSG( 1, "ismd_port_manager.c : ismd_port_manager_init() : ERROR : os_mutex_init returned %d.\n", osal_result );
            result = ISMD_ERROR_UNSPECIFIED;
            break;
         }

         port->connection_lock_ptr     = &(port->connection_lock);
         port->port_type               = ISMD_PORT_TYPE_INVALID;

         for (index=0; index<ISMD_MAX_PORT_CONNECTION ; index++){
            port->connection[index]          = NULL;
            port->tip_pending_inputs[index]  = false;
         }

         port->num_connections         = 0;
         port->attributes              = 0;
         port->queue_handle            = ISMD_QUEUE_HANDLE_INVALID;
         port->input_event.event       = ISMD_EVENT_HANDLE_INVALID;
         port->input_event.event_mask  = ISMD_QUEUE_EVENT_NONE;
         port->output_event.event      = ISMD_EVENT_HANDLE_INVALID;
         port->output_event.event_mask = ISMD_QUEUE_EVENT_NONE;
         port->version_id              = 0;
         port->state                   = ISMD_PORT_STATE_FREE;
         port->port_num                = handle;                     // For debug only.
      }
   }
   ISMD_LOG_MSG( 4, "ismd_port_manager_init(): exiting function.\n" );

   return result;
}


ismd_result_t ismd_port_alloc( ismd_port_type_t    port_type, 
                               ismd_port_config_t *port_config, 
                               ismd_port_handle_t *port_handle )
{
   ismd_result_t      result = ISMD_ERROR_NO_RESOURCES;
   ismd_port_handle_t port_num = ISMD_PORT_HANDLE_INVALID;
   ismd_port_t       *port = NULL;

   DEVH_FUNC_ENTERED(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);

   if ( port_config == NULL ||
        !valid_port_type(port_type) ||
        !valid_port_attributes(port_config->attributes) ||
        (port_config->max_depth < 0) ) {
      result = ISMD_ERROR_INVALID_PARAMETER;
      smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_PORT,
                                 SVEN_EV_SMDCore_Port_Alloc,
                                 port_num, 0,result,0, 0, 0 );
      ISMD_LOG_MSG(1, "ismd_port_alloc_named(): ERROR: port_config is NULL or port type invalid or port attributes invalid or max depth < 1\n");
   } else if ((port_handle == NULL)) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      os_mutex_lock( &global_connection_lock );   // Because port free manipulates connection pointers in two ports do a global lock.
      /*
       * Find an unused port
       */
      for ( port_num = 0; port_num < ISMD_MAX_PORTS; port_num++ ) {
         lookup_port_unversioned( port_num, &port );

         ISMD_LOG_MSG( 4, "ismd_port_alloc_named() : scanning port %d, state = %d\n", port_num, port->state );
         if ( port->state == ISMD_PORT_STATE_FREE ) {
            // Port is volatily free.  Lets lock it so that we can thread safely know it is free.
            port_lock( port );

            if ( port->state == ISMD_PORT_STATE_FREE ) {       // We check port->state twice so needs to be marked volatile.
               /* Init handled by another function */
               result = init_port( port, port_type, port_config );
               if ( result == ISMD_SUCCESS ) {
                  port->version_id++;
                  PACK_PORT_HANDLE(*port_handle, port_num, port->version_id);
                  ISMD_LOG_MSG( 3, "ismd_port_alloc_named() : allocated port %d\n", *port_handle );

               }

               smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_PORT,
                                         SVEN_EV_SMDCore_Port_Alloc,
                                         port_num,
                                         port->queue_handle,
                                         result, 
                                         0, 0, 0 );
               port_num = ISMD_MAX_PORTS; /* break out of loop */
            }
            port_unlock( port );
         }
      }
      os_mutex_unlock( &global_connection_lock );
   }

   DEVH_FUNC_EXIT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);

   return ( result );
}

ismd_result_t ismd_port_alloc_named( ismd_port_type_t    port_type, 
                                     ismd_port_config_t *port_config, 
                                     char *              name, 
                                     int                 name_length, 
                                     int                 virtual_port_id, 
                                     ismd_port_handle_t *port_handle )
{
   ismd_result_t result;

   result = ismd_port_alloc(port_type,port_config,port_handle);

   if ( ISMD_SUCCESS == result ) {
      result = ismd_port_set_name( * port_handle, name, name_length, virtual_port_id );
   }

   return ( result );
}



ismd_result_t ismd_port_set_name( ismd_port_handle_t port_handle,
                                  char *             name, 
                                  int                name_length, 
                                  int                virtual_port_id )
{
   char queue_name[SMD_PORT_NAME_LENGTH];
   char queue_name_suffix[] = "Q";
   int  queue_name_length = 0;
   ismd_result_t result = ISMD_SUCCESS;
   ismd_port_t  *port = NULL;

   DEVH_FUNC_ENTERED(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);

   if ( !lookup_port(port_handle, &port) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   } else {
      port_lock( port );
      if ( virtual_port_id > 0 ) {
         port->virtual_port_id = virtual_port_id;
      }
      if ( NULL != name && name_length > 0 ) {
         OS_MEMCPY( port->name, 
                    name, 
                    name_length < SMD_PORT_NAME_LENGTH ? name_length : SMD_PORT_NAME_LENGTH );
         smd_core_send_sven_event_named(
                                   SMD_CORE_DEBUG_UNIT_PORT,
                                   SVEN_EV_SMDCore_Port_SetName,
                                   port->port_num,
                                   name,
                                   name_length );
            // Set the queue name
            // Change the name to "<name>Q" when naming the associated queue.
         strncpy(queue_name, name, SMD_PORT_NAME_LENGTH-sizeof(queue_name_suffix));
         strncat(queue_name, queue_name_suffix, SMD_PORT_NAME_LENGTH-sizeof(name));

         queue_name_length = name_length + sizeof(queue_name_suffix);
         queue_name_length = (queue_name_length > SMD_PORT_NAME_LENGTH) ? SMD_PORT_NAME_LENGTH : queue_name_length;

         result = ismd_queue_set_name(port->queue_handle,queue_name,queue_name_length,virtual_port_id);
      }
      port_unlock( port );
   }

   DEVH_FUNC_EXIT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);
   return ( result );
}


/*
 * It is legal to free a connected port.  If this is done, the ports need to
 * be disconnected in this function.
 */
ismd_result_t ismd_port_free( ismd_port_handle_t port_handle )
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_port_t  *port;
   ismd_port_t  *input_port;
   ismd_port_t  *output_port;
   int index = 0;

   DEVH_FUNC_ENTERED(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);

   os_mutex_lock( &global_connection_lock );   // Because we manipulate connection pointers in two ports do a global lock.

   if ( !lookup_port(port_handle, &port) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
         // Don't do a port_lock() because we want to lock the second port if there is a connection
      os_mutex_lock( &(port->port_lock));

      if ( port->state == ISMD_PORT_STATE_FREE ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else { /* If the port is connected to another port ... */
         
         /* If this is an output port - need to disconnect all connections   */

         if ( port->port_type == ISMD_PORT_TYPE_OUTPUT ) {
            for (index = 0 ; index < ISMD_MAX_PORT_CONNECTION ; index++) {
               if ( NULL != port->connection[index] ) {
                  input_port = port->connection[index];
                  // Need to lock both ports (output+input) in this case
                  os_mutex_lock(&(input_port->port_lock));

                  ismd_queue_disconnect_output( port->queue_handle );
                  ismd_queue_disconnect_input( input_port->queue_handle );
                  /* Change the connection lock pointer to point to the local lock */
                  input_port->connection_lock_ptr = &(input_port->connection_lock);

                  // disconnect the other port 
                  // the other port must be input port -> it's connection[0] connect to "our" port
                  input_port->connection[0] = NULL;
                  input_port->num_connections --;

                  // reset the relevant tip_pending_inputs
                  port->tip_pending_inputs[index] = false; 

                  os_mutex_unlock(&(input_port->port_lock));

                  /* disconnect this port */
                  port->connection[index] = NULL;
                  port->num_connections --;
               }  //end if ( NULL != port->connection[index] )
            } // end for

         }  // end if ( port->port_type == ISMD_PORT_TYPE_OUTPUT )

         /* If this is input port - only one connection is possible - connection[0] */

         else if ( port->port_type == ISMD_PORT_TYPE_INPUT ) {
            
            if ( NULL != port->connection[0] ) {
               output_port = port->connection[0];

               // Need to lock both ports (output+input) in this case
               os_mutex_lock( &(output_port->port_lock) );

               ismd_queue_disconnect_output( output_port->queue_handle );
               ismd_queue_disconnect_input( port->queue_handle );
               /* Change the connection lock pointer to point to the local lock */
               port->connection_lock_ptr = &(port->connection_lock);

               // disconnect the other port
               // but first check which output port connection, is connected to our port
               // i.e for which "index" : port->connection[0]->connection[index] == "our" port 
               index = which_output_index(port);
               OS_ASSERT(index != -1);

               output_port->connection[index] = NULL; 
               output_port->num_connections--;

               os_mutex_unlock( &(output_port->port_lock) );

               /* disconnect this port */
               port->connection[0] = NULL;
               port->num_connections --;

            }  //end if ( NULL != port->connection[0] )
         }  // end if ( port->port_type == ISMD_PORT_TYPE_INPUT )

         OS_ASSERT((port->port_type == ISMD_PORT_TYPE_INPUT) || (port->port_type == ISMD_PORT_TYPE_OUTPUT));

         if (port->output_event.event != ISMD_EVENT_HANDLE_INVALID) {
            ismd_event_strobe(port->output_event.event); // signal, because we're shutting it off
         }
         if (port->input_event.event != ISMD_EVENT_HANDLE_INVALID) {
            ismd_event_strobe(port->input_event.event); // signal, because we're shutting it off
         }

         port->state = ISMD_PORT_STATE_FREE;
         result = ismd_queue_free( port->queue_handle );

         smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_PORT,
                                   SVEN_EV_SMDCore_Port_Free,
                                   port_handle,
                                   0,0,0,0,0 );

         ISMD_LOG_MSG( 3, "ismd_port_free() : freed port %d\n", port_handle );
      }
      os_mutex_unlock( &(port->port_lock));
   }

   os_mutex_unlock( &global_connection_lock );

   DEVH_FUNC_EXIT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);

   return ( result );
}


ismd_result_t ismd_port_connect( ismd_port_handle_t port0,
                                 ismd_port_handle_t port1 )
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_port_t *input_port;
   ismd_port_t *output_port;
   ismd_port_t *test_port;
   ismd_port_handle_t input_port_handle = ISMD_PORT_HANDLE_INVALID, output_port_handle = ISMD_PORT_HANDLE_INVALID;
   ismd_queue_status_t  status_input, status_output;
   int index; // index for which input port connection the output port will connected

   DEVH_FUNC_ENTERED(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);

   os_mutex_lock( &global_connection_lock );   // Because we manipulate connection pointers in two ports do a global lock.

   if (port0 == port1) { // hopefully no one actually tries to do such a thing...
      result = ISMD_ERROR_INVALID_REQUEST;
   }

   /* Figure out which port is the input port and which is the output port */
   else if (!lookup_port(port0, &test_port)) {
      result = ISMD_ERROR_INVALID_HANDLE;
   } else {
      if (test_port->port_type == ISMD_PORT_TYPE_INPUT) {
         input_port_handle = port0;
         output_port_handle = port1;
      } else {

         /* It looks like port 0 is not the input port */
         input_port_handle = port1;
         output_port_handle = port0;
      }
   }

   if ( !lookup_port(input_port_handle, &input_port) || 
        !lookup_port(output_port_handle, &output_port) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }

   if (result == ISMD_SUCCESS) {
      os_mutex_lock( &(output_port->port_lock) );
      os_mutex_lock( &(input_port->port_lock) );

      result = ismd_queue_get_status (input_port->queue_handle, &status_input);
      if (result == ISMD_SUCCESS) {
         result = ismd_queue_get_status (output_port->queue_handle, &status_output);
      }

      if (result == ISMD_SUCCESS) {
         if ( input_port->state == ISMD_PORT_STATE_FREE || 
              output_port->state == ISMD_PORT_STATE_FREE ) {
            result = ISMD_ERROR_INVALID_HANDLE;
            ISMD_LOG_MSG( 2, "ismd_port_connect() : error : invalid handle.\n" );
         }
         else if ( input_port->port_type != ISMD_PORT_TYPE_INPUT || 
                   output_port->port_type != ISMD_PORT_TYPE_OUTPUT) {
            result = ISMD_ERROR_INVALID_PARAMETER;
            ISMD_LOG_MSG( 2, "ismd_port_connect() : error : invalid parameter.\n" );
         }
         else if ( input_port->connection[0] != NULL ||   // input port can be connected only at connection[0]
                   output_port->num_connections == ISMD_MAX_PORT_CONNECTION ) {   // e.g all output connections already connected
            result = ISMD_ERROR_PORT_BUSY;
            ISMD_LOG_MSG( 2, "ismd_port_connect() : error : port already connected.\n" );
         }
         //At lease one port should have buffer pool
         else if ( status_input.max_depth == 0 && 
                   status_output.max_depth == 0) {
             result = ISMD_ERROR_INVALID_REQUEST;
             ISMD_LOG_MSG( 2, "ismd_port_connect() : error : neither port has any buffer pool inside.\n" );
         }
         else {
            /* Finally, we can do the real work! */

            // check which output port connection is free:
            index = 0;
            while ((output_port->connection[index] != NULL) && ( index < ISMD_MAX_PORT_CONNECTION)) {
               index++ ; 
            }
   
            /* FIXME: need to check status and cleanup after each of these function calls */
            result = ismd_queue_disconnect_input( input_port->queue_handle );
            if (result != ISMD_SUCCESS) {
               ISMD_LOG_MSG( 1, "Error during queue disconnect input, result: %d\n", result);
            } else {
               if (input_port->input_event.event != ISMD_EVENT_HANDLE_INVALID) {
                  ismd_event_strobe(input_port->input_event.event); // signal, because we're shutting it off
               }
               input_port->input_event.event = ISMD_EVENT_HANDLE_INVALID;
               input_port->input_event.event_mask = ISMD_QUEUE_EVENT_NONE;
               result = ismd_queue_connect_input( input_port->queue_handle, 
                                                  (ismd_producer_func_t)port_connect_pull, 
                                                  (void *)(input_port),  
                                                  ISMD_QUEUE_WATERMARK_NONE );
            }
         
            if (result != ISMD_SUCCESS) {
               ISMD_LOG_MSG( 1, "Error in port manager connect, result: %d\n", result);
            } else {
               result = ismd_queue_disconnect_output( output_port->queue_handle );
            }
            
            if (result != ISMD_SUCCESS) {
               ISMD_LOG_MSG( 1, "Error during queue disconnect output, result: %d\n", result);
            } else {
               if (output_port->output_event.event != ISMD_EVENT_HANDLE_INVALID) {
                  ismd_event_strobe(output_port->output_event.event); // signal, because we're shutting it off
               }
               output_port->output_event.event = ISMD_EVENT_HANDLE_INVALID;
               output_port->output_event.event_mask = ISMD_QUEUE_EVENT_NONE;
               result = ismd_queue_connect_output( output_port->queue_handle, 
                                                   (ismd_consumer_func_t)port_connect_push, 
                                                   (void *)(output_port),   
                                                   ISMD_QUEUE_WATERMARK_NONE );
            }

            if (result != ISMD_SUCCESS) {
               ismd_queue_disconnect_input( input_port->queue_handle );
               ismd_queue_disconnect_output( output_port->queue_handle );
            } else {
               input_port->connection[0] = output_port;
               input_port->connection_handle[0] = output_port_handle;
               input_port->num_connections++;
   
               output_port->connection[index] = input_port;
               output_port->connection_handle[index] = input_port_handle;
               output_port->tip_pending_inputs[index] = true;
               output_port->num_connections++;              

               input_port->connection_lock_ptr = &(output_port->connection_lock);
               ISMD_LOG_MSG( 3, "ismd_port_connect() : connected port %d to port %d.\n", 
                             output_port_handle, 
                             input_port_handle );

               smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_PORT,
                                         SVEN_EV_SMDCore_Port_Connect,
                                         input_port_handle,
                                         output_port_handle,
                                         0, 0, 0, 0 );
            }
         }
      }
      os_mutex_unlock( &(input_port->port_lock) );
      os_mutex_unlock( &(output_port->port_lock) );
   }

   os_mutex_unlock( &global_connection_lock );   // Because we manipulate connection pointers in two ports do a global lock.

   DEVH_FUNC_EXIT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);

   return ( result );
}



ismd_result_t ismd_port_disconnect(ismd_port_handle_t port)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_port_t *input_port;
   ismd_port_t *output_port;
   ismd_port_t *test_port;
   int index = 0;

   DEVH_FUNC_ENTERED(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);

   os_mutex_lock( &global_connection_lock );   // Because we manipulate connection pointers in two ports do a global lock.

   /* find the output port.  It might be the port supplied or it might be connected to the supplied port */
   if (!lookup_port(port, &test_port)) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }else if (test_port->num_connections == 0) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }

   if (result == ISMD_SUCCESS) {
      if (test_port->port_type == ISMD_PORT_TYPE_OUTPUT) { 
         output_port = test_port; 

         os_mutex_lock( &(output_port->port_lock) );

         index = 0;
         while(index < ISMD_MAX_PORT_CONNECTION ) {
            if (output_port->connection[index] != NULL) {

               input_port = output_port->connection[index];

               if ( output_port->port_type != ISMD_PORT_TYPE_OUTPUT ) {
                  result = ISMD_ERROR_INVALID_PARAMETER;
               }
               else if ( input_port == NULL ) {
                  result = ISMD_ERROR_OPERATION_FAILED;
               }
               else {
                  os_mutex_lock( &(input_port->port_lock) );

                  if ( input_port->connection[0] != output_port ) {
                     result = ISMD_ERROR_OPERATION_FAILED;
                     ISMD_LOG_MSG( 1, "Port disconnect: sanity check failed.  Port connection error.\n");
                  }
                  else {
                     result = ismd_queue_disconnect_input( input_port->queue_handle );
                     if ( result == ISMD_SUCCESS ) {
                        result = ismd_queue_disconnect_output( output_port->queue_handle );
                     }

                     smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_PORT,
                                               SVEN_EV_SMDCore_Port_Disconnect,
                                               input_port->connection_handle[0],
                                               output_port->connection_handle[index],
                                               0, 0, 0, 0 );

                     input_port->connection_lock_ptr = &(input_port->connection_lock);
                     input_port->connection[0] = NULL;
                     input_port->connection_handle[0] = 0;
                     input_port->num_connections --;

                     output_port->connection[index] = NULL;
                     output_port->connection_handle[index] = 0;
                     output_port->num_connections--;
                     
                     // reset the relevant tip_pending_inputs
                     output_port->tip_pending_inputs[index] = false;
                  }
                  os_mutex_unlock( &(input_port->port_lock) );
               }
            }// end if (output_port->connection[index])
            index ++ ;
         } //end while
         os_mutex_unlock( &(output_port->port_lock) );
            
         
         } else if (test_port->port_type == ISMD_PORT_TYPE_INPUT) {    // input port -> only one connection is posible - connection[0]
            input_port = test_port;
            if (input_port->connection[0]) {
               output_port = input_port->connection[0]; 
            } else {
               result = ISMD_ERROR_OPERATION_FAILED;
            }

            if (result == ISMD_SUCCESS) { 
               os_mutex_lock( &(output_port->port_lock) );
               
               if ( output_port->port_type != ISMD_PORT_TYPE_OUTPUT ) {
                  result = ISMD_ERROR_INVALID_PARAMETER;
               }
               else {
                  os_mutex_lock( &(input_port->port_lock) );

                  /* check which output connections conected to "our" input port*/
                  index = which_output_index(input_port);
                  OS_ASSERT(index != -1);

                  if ((index == ISMD_MAX_PORT_CONNECTION) || (output_port->connection[index] != input_port)) {
                     result = ISMD_ERROR_OPERATION_FAILED;
                     ISMD_LOG_MSG( 1, "Port disconnect: sanity check failed.  Port connection error.\n");
                  }
                  else {
                     result = ismd_queue_disconnect_input( input_port->queue_handle );
                     if ( result == ISMD_SUCCESS ) { 
                        
                        // disconnect the output queue only if there is no more input connection to it:
                        if( ! is_multiple_connections(output_port)) { // there are no more connections to the output port
                           result = ismd_queue_disconnect_output( output_port->queue_handle );
                        }
                     }

                     smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_PORT,
                                               SVEN_EV_SMDCore_Port_Disconnect,
                                               input_port->connection_handle[0],
                                               output_port->connection_handle[index],
                                               0, 0, 0, 0 );

                     input_port->connection_lock_ptr = &(input_port->connection_lock);
                     input_port->connection[0] = NULL;
                     input_port->connection_handle[0] = 0;
                     input_port->num_connections--;

                     output_port->connection[index] = NULL;
                     output_port->connection_handle[index] = 0;
                     output_port->num_connections--;
                     
                     // reset the relevant tip_pending_inputs
                     output_port->tip_pending_inputs[index] = false;
                  }
                  os_mutex_unlock( &(input_port->port_lock) );
               }

               os_mutex_unlock( &(output_port->port_lock) );
            } //end if (result == ISMD_SUCCESS)  
         }

         OS_ASSERT( (test_port->port_type == ISMD_PORT_TYPE_INPUT) || (test_port->port_type == ISMD_PORT_TYPE_OUTPUT) );
   }

   os_mutex_unlock( &global_connection_lock );   // Because we manipulate connection pointers in two ports do a global lock.

   DEVH_FUNC_EXIT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);

   return ( result );
}


ismd_result_t ismd_port_write( ismd_port_handle_t        port, 
                               ismd_buffer_handle_t      buffer )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_port_t *port_handle;
   ismd_buffer_descriptor_t *buffer_desc;
   ismd_queue_status_t  status;

   ISMD_LOG_MSG( 4, "ismd_port_write() : entering function.\n" );

   result = ismd_buffer_find_descriptor(buffer, &buffer_desc);
   if (result != ISMD_SUCCESS) {
      ISMD_LOG_MSG( 1, "ismd_port_write() : Error: Could not find buffer %d.\r\n", buffer );
      result = ISMD_ERROR_INVALID_HANDLE;
   } else {

      if ( !lookup_port(port, &port_handle) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {
         port_lock( port_handle );
         result = ismd_queue_get_status (port_handle->queue_handle, &status);

         if ( port_handle->state == ISMD_PORT_STATE_FREE ) {
            result = ISMD_ERROR_INVALID_HANDLE;
         }
         else if ( (port_handle->port_type == ISMD_PORT_TYPE_INPUT) && 
                   (port_handle->connection[0] != NULL) ) {
            result = ISMD_ERROR_PORT_BUSY;
         }
         //Port should have buffer pool
         else if ( (status.max_depth == 0) 
            && (port_handle->num_connections == 0)) {
            result = ISMD_ERROR_INVALID_REQUEST;
         }
         else {
            result = ismd_queue_enqueue( port_handle->queue_handle, buffer_desc );
         }
         port_unlock( port_handle );
      }
   }
   
   ISMD_LOG_MSG( 4, "ismd_port_write() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_port_read( ismd_port_handle_t         port, 
                              ismd_buffer_handle_t      *buffer )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_port_t *port_handle;
   ismd_buffer_descriptor_t *buffer_desc;
   ismd_queue_status_t  status;

   ISMD_LOG_MSG( 4, "ismd_port_read() : entering function.\n" );

   if ( !lookup_port(port, &port_handle) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      port_lock( port_handle );
      result = ismd_queue_get_status (port_handle->queue_handle, &status);

      if ( port_handle->state == ISMD_PORT_STATE_FREE ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else if ( (port_handle->port_type == ISMD_PORT_TYPE_OUTPUT) && 
                (port_handle->num_connections > 0) ) {
         result = ISMD_ERROR_PORT_BUSY;
      }
      //Port should have buffer pool
      else if ( (status.max_depth == 0) 
             && (port_handle->num_connections == 0)) {
         result = ISMD_ERROR_INVALID_REQUEST;
      }
      else {
         result = ismd_queue_dequeue( port_handle->queue_handle, &buffer_desc );
      }
      port_unlock( port_handle );
   }

   if (result == ISMD_SUCCESS) {
      *buffer = buffer_desc->unique_id;
   }

   ISMD_LOG_MSG( 4, "ismd_port_read() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_port_get_descriptor( ismd_port_handle_t  handle, 
                                        ismd_port_descriptor_t *port_descriptor )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_port_t *port;
   ismd_queue_status_t queue_status;

   ISMD_LOG_MSG( 4, "ismd_port_get_descriptor() : entering function.\n" );

   if ( !lookup_port(handle, &port) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      port_lock( port );
      if ( port->state == ISMD_PORT_STATE_FREE ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {
         result = ismd_queue_get_status( port->queue_handle, &queue_status );
         if ( result == ISMD_SUCCESS ) {
            port_descriptor->port_type = port->port_type;
            if ( port->port_type == ISMD_PORT_TYPE_INPUT ) {
               port_descriptor->event = port->output_event.event;
               port_descriptor->event_mask = port->output_event.event_mask;
               port_descriptor->watermark = queue_status.high_watermark;
            }
            else {
               port_descriptor->event = port->input_event.event;
               port_descriptor->event_mask = port->input_event.event_mask;
               port_descriptor->watermark = queue_status.low_watermark;
            }
            port_descriptor->attributes      = port->attributes;
            port_descriptor->max_depth       = queue_status.max_depth;
            port_descriptor->cur_depth_bytes = queue_status.cur_depth_bytes;
            port_descriptor->cur_depth_bufs  = queue_status.cur_depth_bufs;
            result = ISMD_SUCCESS;
         }
      }
      port_unlock( port );
   }

   ISMD_LOG_MSG( 4, "ismd_port_get_descriptor() : exiting function.\n" );

   return ( result );
}

ismd_result_t ismd_port_get_status( ismd_port_handle_t  handle, 
                                    ismd_port_status_t  *status)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_queue_status_t queue_status;
   ismd_port_t *port;

   ISMD_LOG_MSG( 4, "ismd_port_get_status() : entering function.\n" );

   if (status == NULL) {
      ISMD_LOG_MSG( 1, "ismd_port_get_status() : Failure: status supplied as NULL.\n" );
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else {
      if ( !lookup_port(handle, &port) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {
         port_lock( port );
         if ( port->state == ISMD_PORT_STATE_FREE ) {
            result = ISMD_ERROR_INVALID_HANDLE;
         }
         result = ismd_queue_get_status( port->queue_handle, &queue_status );
         if ( result == ISMD_SUCCESS ) {
            status->max_depth = queue_status.max_depth;
            status->cur_depth = queue_status.cur_depth_bufs;
            if ( port->port_type == ISMD_PORT_TYPE_INPUT ) {
               status->watermark = queue_status.low_watermark;
            } else {
               status->watermark = queue_status.high_watermark;
            }
         }
         
         port_unlock( port );
      }
   }

   ISMD_LOG_MSG( 4, "ismd_port_get_status() : exiting function.\n" );

   return ( result );
}

ismd_result_t ismd_port_set_watermark( ismd_port_handle_t  handle, 
                                       int watermark)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_status_t queue_status;
   ismd_queue_config_t queue_config;
   ismd_port_t *port;

   ISMD_LOG_MSG( 4, "ismd_port_set_watermark() : entering function.\n" );

   if ( !lookup_port(handle, &port) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      port_lock( port );
      if ( port->state == ISMD_PORT_STATE_FREE ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {
         result = ismd_queue_get_status( port->queue_handle, &queue_status );
         if ( result == ISMD_SUCCESS ) {
            queue_config.consumer_context = queue_status.consumer_context;
            queue_config.consumer_func    = queue_status.consumer_func;
            queue_config.high_watermark   = queue_status.high_watermark;
            queue_config.producer_context = queue_status.producer_context;
            queue_config.producer_func    = queue_status.producer_func;
            queue_config.low_watermark    = queue_status.low_watermark;
            queue_config.max_depth        = queue_status.max_depth;
            if ( port->port_type == ISMD_PORT_TYPE_INPUT ) {
               queue_config.low_watermark  = watermark;
            }
            else {
               queue_config.high_watermark = watermark;
            }
            result = ismd_queue_set_config( port->queue_handle, &queue_config );
         }
      }
      port_unlock( port );
   }

   ISMD_LOG_MSG( 4, "ismd_port_set_watermark() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_port_set_config( ismd_port_handle_t handle, 
                                    ismd_port_config_t *port_config )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_result_t temp_result;
   ismd_queue_status_t queue_status;
   ismd_queue_config_t queue_config;
   ismd_port_t *port;
   ismd_port_t *opposite_port;
   ismd_queue_status_t opposite_port_queue_status;
   int index = 0;

   ISMD_LOG_MSG(4, "ismd_port_set_config() : entering function.\n");

   if (port_config == NULL) {
      ISMD_LOG_MSG(1, "ismd_port_set_config(): ERROR: NULL config supplied\n");
      result = ISMD_ERROR_INVALID_PARAMETER;

   } else if (!valid_port_attributes(port_config->attributes) || (port_config->max_depth < 0)) {
      result = ISMD_ERROR_INVALID_PARAMETER;

   } else if (!lookup_port(handle, &port)) {
      result = ISMD_ERROR_INVALID_HANDLE;

   } else if ((port_config->event != ISMD_EVENT_HANDLE_INVALID) && !active_smd_event(port_config->event)) {
      result = ISMD_ERROR_INVALID_HANDLE;

   } else {
      result = ISMD_SUCCESS;
      port_lock(port);

      if (port->state == ISMD_PORT_STATE_FREE) {
         result = ISMD_ERROR_INVALID_HANDLE;

      } else {
         // It's illegal to have 2 0-depth ports connected, prevent someone from
         //      creating this situation after connection-time.

         // If 0-depth, and connected, check other port.
         if (port_config->max_depth == 0) {
            index = 0 ;
            while (index < ISMD_MAX_PORT_CONNECTION) {
               if ( port->connection[index] != NULL) {
                  opposite_port = port->connection[index];
                  temp_result = ismd_queue_get_status(opposite_port->queue_handle, &opposite_port_queue_status);
                  OS_ASSERT(temp_result == ISMD_SUCCESS);

                  // Since this port has 0-depth, the connect port cannot have 0-depth, else error.
                  if (opposite_port_queue_status.max_depth == 0) {
                     result = ISMD_ERROR_INVALID_REQUEST;
                  }
               }
               index++ ;
            } //end while
         } //end (port_config->max_depth == 0)

         // We passed all of the error checking, now do the work.
         if (result == ISMD_SUCCESS) {

            temp_result = ismd_queue_get_status(port->queue_handle, &queue_status);
            OS_ASSERT(temp_result == ISMD_SUCCESS);

            if (port->port_type == ISMD_PORT_TYPE_INPUT) {

               // Unregister the previous event and store the new one.
               port->output_event.event = port_config->event;
               port->output_event.event_mask = port_config->event_mask;

               // Input port, so configuring the output end (driver end).
               queue_config.consumer_context = (void *)&port->output_event;
               queue_config.consumer_func = port_set_event_output;
               queue_config.high_watermark = port_config->watermark;

               // Leave input end variables alone.
               queue_config.producer_context = queue_status.producer_context;
               queue_config.producer_func = queue_status.producer_func;
               queue_config.low_watermark = queue_status.low_watermark;
               
            } else {
               // Unregister the previous event and store the new one.
               port->input_event.event        = port_config->event;
               port->input_event.event_mask   = port_config->event_mask;

               // Output port, so configuring the input end (driver end).
               queue_config.producer_context = (void *)&port->input_event;
               queue_config.producer_func = port_set_event_input;
               queue_config.low_watermark = port_config->watermark;
               
               // Leave output end variables alone.
               queue_config.consumer_context = queue_status.consumer_context;
               queue_config.consumer_func = queue_status.consumer_func;
               queue_config.high_watermark = queue_status.high_watermark;
            }

            // Set the new queue depth.
            queue_config.max_depth = port_config->max_depth;

            // Commit changes or die trying.
            result = ismd_queue_set_config(port->queue_handle, &queue_config);
         }
      }

      port_unlock(port);
   }

   ISMD_LOG_MSG(4, "ismd_port_set_config() : exiting function.\n");

   return (result);
}


ismd_result_t ismd_port_attach( ismd_port_handle_t   handle, 
                                ismd_event_t         event,
                                ismd_queue_event_t   event_mask,
                                int                  watermark )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_port_t *port;
   ismd_port_event_t temp_event;
   ismd_queue_status_t  status;

   ISMD_LOG_MSG( 4, "ismd_port_attach() : entering function.\n" );

   if ( !lookup_port(handle, &port) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if ((event != ISMD_EVENT_HANDLE_INVALID) && !active_smd_event(event)) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      port_lock( port );
      result = ismd_queue_get_status (port->queue_handle, &status);
      if ( port->state == ISMD_PORT_STATE_FREE ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      //Port should have buffer pool
      else if ( status.max_depth == 0) {
         result = ISMD_ERROR_INVALID_REQUEST;
      }
      else if ( port->port_type == ISMD_PORT_TYPE_INPUT ) {
         
         if(port->connection[0] != NULL) {
            result = ISMD_ERROR_PORT_BUSY;
         } else {
            /* make backup, in case next function fails */
            OS_MEMCPY(&temp_event, &port->input_event, sizeof(ismd_port_event_t));
            port->input_event.event = event;
            port->input_event.event_mask = event_mask;
            
            result = ismd_queue_connect_input(  port->queue_handle,
                                                port_set_event_input,
                                                (void *)&port->input_event,
                                                watermark );

            /* restore original settings in case of failure */
            if (result != ISMD_SUCCESS) {
               OS_MEMCPY(&port->input_event, &temp_event, sizeof(ismd_port_event_t));
            }
         }
      }
      else {  // OUTPUT
          
         if(port->num_connections > 0) {
            result = ISMD_ERROR_PORT_BUSY;
         } else {
         
            /* make backup, in case next function fails */
            OS_MEMCPY(&temp_event, &port->output_event, sizeof(ismd_port_event_t));
            port->output_event.event = event;
            port->output_event.event_mask = event_mask;
            
            result = ismd_queue_connect_output( port->queue_handle,
                                                port_set_event_output,
                                                (void *)&port->output_event,
                                                watermark );

            /* restore original settings in case of failure */
            if (result != ISMD_SUCCESS) {
               OS_MEMCPY(&port->output_event, &temp_event, sizeof(ismd_port_event_t));
               }
         }
      }
      port_unlock( port );
   }

   ISMD_LOG_MSG( 4, "ismd_port_attach() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_port_detach( ismd_port_handle_t handle )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_port_t *port;

   ISMD_LOG_MSG( 4, "ismd_port_detach() : entering function.\n" );

   if ( !lookup_port(handle, &port) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      port_lock( port );

      if ( port->state == ISMD_PORT_STATE_FREE ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else if ( port->num_connections > 0) {     
         result = ISMD_ERROR_PORT_BUSY;
      } 
      else if (port->port_type == ISMD_PORT_TYPE_INPUT ) {
         result = ismd_queue_disconnect_input(port->queue_handle);
         port->input_event.event        = ISMD_EVENT_HANDLE_INVALID;
         port->input_event.event_mask   = ISMD_QUEUE_EVENT_NONE;
      } 
      else {
         result = ismd_queue_disconnect_output(port->queue_handle);
         port->output_event.event       = ISMD_EVENT_HANDLE_INVALID;
         port->output_event.event_mask  = ISMD_QUEUE_EVENT_NONE;
      }
      port_unlock( port );
   }

   ISMD_LOG_MSG( 4, "ismd_port_detach() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_port_flush( ismd_port_handle_t handle )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_port_t *port;

   ISMD_LOG_MSG( 4, "ismd_port_flush() : entering function.\n" );

   if ( !lookup_port(handle, &port) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      port_lock( port );
      if ( port->state == ISMD_PORT_STATE_FREE ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {
         result = ismd_queue_flush( port->queue_handle );
      }
      port_unlock( port );
   }

   ISMD_LOG_MSG( 4, "ismd_port_flush() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_port_lookahead( ismd_port_handle_t         handle, 
                                   int                        position,
                                   ismd_buffer_handle_t      *buffer )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_port_t *port;
   ismd_buffer_descriptor_t *buffer_desc;

   ISMD_LOG_MSG( 4, "ismd_port_look_ahead() : entering function.\n" );
   
   if ( !lookup_port(handle, &port) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {

      port_lock( port );
      if ( port->state == ISMD_PORT_STATE_FREE ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else if ( (port->port_type == ISMD_PORT_TYPE_OUTPUT) && 
                ( port->num_connections > 0) ) {
         result = ISMD_ERROR_PORT_BUSY;
      }
      else {
         result = ismd_queue_lookahead( port->queue_handle, position, &buffer_desc );
      }
      port_unlock( port );
   }

   if (result == ISMD_SUCCESS) {
      *buffer = buffer_desc->unique_id;
   }

   ISMD_LOG_MSG( 4, "ismd_port_look_ahead() : exiting function.\n" );

   return ( result );
}


static ismd_result_t init_port( ismd_port_t        *port, 
                                ismd_port_type_t    port_type, 
                                ismd_port_config_t *port_config)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   int index = 0;

   DEVH_FUNC_ENTERED(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);

   if ((port_config->event != ISMD_EVENT_HANDLE_INVALID) && !active_smd_event(port_config->event)) {
      result = ISMD_ERROR_INVALID_HANDLE;
   } else {


      port->port_type                = port_type;
      port->attributes               = port_config->attributes;
      port->state                    = ISMD_PORT_STATE_ALLOCATED;
      
      for (index=0; index <ISMD_MAX_PORT_CONNECTION ; index++) {
         port->connection[index]           = NULL;
         port->tip_pending_inputs[index]   = false;
      }

      port->num_connections = 0;
      port->queue_handle             = ISMD_QUEUE_HANDLE_INVALID;
      port->connection_lock_ptr      = &(port->connection_lock);
      port->input_event.event        = ISMD_EVENT_HANDLE_INVALID;
      port->input_event.event_mask   = ISMD_QUEUE_EVENT_NONE;
      port->output_event.event       = ISMD_EVENT_HANDLE_INVALID;
      port->output_event.event_mask  = ISMD_QUEUE_EVENT_NONE;
      if (port->port_type == ISMD_PORT_TYPE_INPUT) {
         port->output_event.event      = port_config->event;
         port->output_event.event_mask = port_config->event_mask;
      } else {
         port->input_event.event       = port_config->event;
         port->input_event.event_mask  = port_config->event_mask;
      }

      result = ismd_queue_alloc( port->attributes & ISMD_PORT_QUEUE_MAX_DEPTH_BUFFERS ? 
                                          ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS :
                                          ISMD_QUEUE_TYPE_VARSIZE_BUFFERS, 
                                       port_config->max_depth, 
                                       &(port->queue_handle) );
      if ( result == ISMD_SUCCESS ) {
         if ( port->port_type == ISMD_PORT_TYPE_INPUT ) {
            result = ismd_queue_connect_output( port->queue_handle,
                                                port_set_event_output,
                                                (void *)&port->output_event,
                                                port_config->watermark );
         }
         else {
            result = ismd_queue_connect_input( port->queue_handle,
                                               port_set_event_input,
                                               (void *)&port->input_event,
                                               port_config->watermark );
         }
      }

      if ( result != ISMD_SUCCESS ) {
         ismd_queue_free( port->queue_handle );
      }
   }

   if (result != ISMD_SUCCESS) {
      port->state = ISMD_PORT_STATE_FREE;
   }

   DEVH_FUNC_EXIT(smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT]);
   return ( result );
}


static bool valid_port_handle( ismd_port_handle_t handle )
{
	bool result = false;

	if ( (handle >= 0) && (handle < ISMD_MAX_PORTS) ) {
		result = true;
	} else {
        DEVH_WARN( smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT], "invalid port handle" );
    }
	return ( result );
}


static bool valid_port_type( ismd_port_type_t type )
{
   bool result = false;

   if ( (type == ISMD_PORT_TYPE_INPUT ) || 
        (type == ISMD_PORT_TYPE_OUTPUT ) ) {
      result = true;
   } else {
      DEVH_WARN( smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT ], "invalid port type" );
   }

   return ( result );
}


static bool valid_port_attributes( uint32_t port_attributes )
{

   bool result = false;

   if ( (port_attributes & 
        ~(ISMD_PORT_QUEUE_ON | 
          ISMD_PORT_QUEUE_MAX_DEPTH_BUFFERS | 
          ISMD_PORT_QUEUE_DISCONNECT_DISCARD)) == 0 ) {
      result = true;
   } else {
      DEVH_WARN( smd_dbg_devh[SMD_CORE_DEBUG_UNIT_PORT ], "invalid port attrs" );
   }

   /* Block max depth in bytes */
   if ((port_attributes & ISMD_PORT_QUEUE_MAX_DEPTH_BUFFERS) == 0) {
      result = false;
   }

   /* Queueing must be on */
   if ((port_attributes & ISMD_PORT_QUEUE_ON) == 0) {
      result = false;
   }

   /* Only available mode is disconnect block, discard is not implemented */
   if ((port_attributes & ISMD_PORT_QUEUE_DISCONNECT_DISCARD) != 0) {
      result = false;
   }

   return ( result );
}


static bool lookup_port_unversioned( ismd_port_handle_t handle, ismd_port_t **port )
{
	bool result = false;

   if ( valid_port_handle(handle) ) {
      *port =	&(ismd_ports[handle]);
      result = true;
	}
	return ( result );
}

static bool lookup_port( ismd_port_handle_t handle, ismd_port_t **port )
{
   
   int port_num, port_version;
   bool result = false;

   UNPACK_PORT_HANDLE(handle, port_num, port_version);

   if ( valid_port_handle(port_num) ) {
      *port =  &(ismd_ports[port_num]);
      
      if ((*port)->version_id == port_version) {
         result = true;
      }
   }
   return ( result );
}


static void port_lock( ismd_port_t *port )
{
   os_mutex_lock( &(port->port_lock) );
   os_mutex_lock( port->connection_lock_ptr );
}


static void port_unlock( ismd_port_t *port )
{
   os_mutex_unlock( port->connection_lock_ptr );
   os_mutex_unlock( &(port->port_lock) );
}

static bool is_multiple_connections(ismd_port_t *output_port)   
{
   return (output_port->num_connections > 1);
}

static int which_output_index(ismd_port_t *input_port)
{
   ismd_port_t *output_port = input_port->connection[0];
   int index = 0;
   while (index < ISMD_MAX_PORT_CONNECTION) {
      if (output_port->connection[index] == input_port) {
         return index;
      }
      index ++;
   }
   return ( -1 );
}

static bool is_other_inputs_pending(ismd_port_t *input_port, ismd_port_t *output_port)
{
   int index = 0;
   while (index < ISMD_MAX_PORT_CONNECTION) {
      if ((output_port->connection[index] != NULL) &&
         (output_port->connection[index]->port_num != input_port->port_num) && 
         (output_port->tip_pending_inputs[index] == true)){
            return true;
      }
      index ++ ;
   }
   return false;
}

static void update_all_tip_pending_inputs(ismd_port_t *outpurt_port)
{
   int index = 0;
   while (index < ISMD_MAX_PORT_CONNECTION) {
      if (outpurt_port->connection[index] != NULL) {
         outpurt_port->tip_pending_inputs[index] = true;
      }
      index ++ ;
   }
}

// push the buffer to all the pending connected inputs 
// except of the input that at except_index index of the output connection array, 
// if it -1 push to all inputs.
static ismd_result_t push_buffer_to_inputs(ismd_port_t *output_port, int except_index, ismd_buffer_handle_t buffer)
{
   ismd_result_t result = ISMD_ERROR_NO_SPACE_AVAILABLE;
   ismd_result_t temp_result = ISMD_SUCCESS;
   int index = 0;
   ismd_buffer_descriptor_t *desc;
   bool add_reference_needed = false;

  result = ismd_buffer_find_descriptor(buffer, &desc);
 
  if (result == ISMD_SUCCESS) {

    // push the buffer to all the inputs except the "except_index"
    while (index < ISMD_MAX_PORT_CONNECTION) {

       result = ISMD_SUCCESS;
       add_reference_needed = false;

          if ((output_port->connection[index] != NULL) && 
             (output_port->tip_pending_inputs[index] == true) &&
             (index != except_index)) { 

                // if there is other input which pending to this buffer - need to call ismd_buffer_add_reference
                if(is_other_inputs_pending(output_port->connection[index], output_port)) {
                   result = ismd_buffer_add_reference(buffer);
                   add_reference_needed = true;
                }

                // "push" this buffer to the relevant input port     
                if (result == ISMD_SUCCESS) {
                   result = ismd_queue_enqueue( output_port->connection[index]->queue_handle, desc );
       
                   // if success - update the tip_pending_inputs flag
                   if (result == ISMD_SUCCESS) {
                      output_port->tip_pending_inputs[index] = false;
                   } else { 
                      temp_result = result;
                      if (add_reference_needed){
                         result = ismd_buffer_dereference(buffer); 
                      }
                   }
                } else {
                   temp_result = result;
                }
          }
          index ++;
       } //end while 

    // if temp_result != ISMD_SUCCESS the "push" failed, and we cant dequeue the tip buffer at the output port
    if (temp_result != ISMD_SUCCESS){
       return ( temp_result );
    }

    // if we are here - we success to push the buffer to all the inputs:
    // if pull called this function - we need to dequeue it and update the tip_pending_inputs flags.
    // if push called this function (except_index == -1) we need to update all tip_pending_inputs flags, but not dequeue the buffer (other function will do it)

    if (except_index != -1) {   // pull caled this function 
          result = ismd_queue_dequeue( output_port->queue_handle, &desc );
          if(result == ISMD_SUCCESS) {
             update_all_tip_pending_inputs(output_port);
          } else {
             return ( result );
          }
    } else {  // push called this function
       update_all_tip_pending_inputs(output_port);
    }

  }
   return ( result );
 }

static ismd_result_t pass_tip_buffer_and_push_it(ismd_port_t *output_port, int caller_index, ismd_buffer_handle_t *buffer)
{
   ismd_buffer_descriptor_t *queue_last_buffer;
   ismd_result_t result = ISMD_SUCCESS;

   result = ismd_queue_lookahead(output_port->queue_handle, 1, &queue_last_buffer );

   if (result == ISMD_SUCCESS) {
      // pass the buffer to the caller input port:
      if(is_other_inputs_pending(output_port->connection[caller_index], output_port)) {
         result = ismd_buffer_add_reference(queue_last_buffer->unique_id);
      }
      *buffer = queue_last_buffer->unique_id;  
      output_port->tip_pending_inputs[caller_index] = false;   
     
      if (result == ISMD_SUCCESS) {
         push_buffer_to_inputs(output_port, caller_index, queue_last_buffer->unique_id); 
      }
   }
         
   return ( result );
}

static ismd_result_t port_connect_pull( void               *context, 
                                 ismd_queue_event_t         queue_event, 
                                 ismd_buffer_handle_t      *buffer )
{
   ismd_buffer_descriptor_t *desc;
   ismd_result_t result = ISMD_ERROR_NO_DATA_AVAILABLE;
   ismd_port_t *input_port = (ismd_port_t *)context; // the input port which called this function
   ismd_port_t *output_port = input_port->connection[0];
   int caller_index = 0;     // the index at the output port connection array of the input port which called this function
   bool is_multiple_connection_to_output = false;
   bool other_input_pending = false; // indicate if there is other input port which connected to the same output, and pending to the tip buffer. 
#if 0  // temporary, when case 3 (see below) retern ERROR
   ismd_buffer_descriptor_t *last_buffer;
#endif

   (void)queue_event; // suppress warning about unused parameter

   // check to which index at the output port connection array is belong to the input port which called this function.
   caller_index = which_output_index(input_port);
   OS_ASSERT(caller_index != -1);

   // check if it is T-port connection or single one.
   is_multiple_connection_to_output = is_multiple_connections(output_port);

   // if there is only single input to the output port:
   // dequeue the buffer from output port queue, "return" the buffer (for the input port which called pull), 
   // and update the tip_pending_inputs flag.
   
   if (! is_multiple_connection_to_output)
   {
      result = ismd_queue_dequeue( output_port->queue_handle, &desc );
      if (result == ISMD_SUCCESS) {
         *buffer = desc->unique_id;
         output_port->tip_pending_inputs[caller_index] = true;
      }
      return ( result );
   }

   // [we are now definitely at T-port connection]

  // check if there is other input port which connected to the same output port, and pending to the tip buffer.
  other_input_pending = is_other_inputs_pending(input_port, output_port);

  // because we always update the tip_pending_inputs flags, we never get the situation of all ports doent pending to the tip buffer:
  OS_ASSERT(! ((output_port->tip_pending_inputs[caller_index] == false ) && (!other_input_pending)));

  // now there are 3 cases:

  // case 1: the input which called to PULL didn't read the tip buffer at the output port queue yet, 
  //          but all the other inputs which connected to the same output port read it.
  //          --> call ismd_queue_dequeue, return the buffer and update all tip_pending_inputs at the output port.

  if ((output_port->tip_pending_inputs[caller_index] == true ) && (! other_input_pending)) {
      
      result = ismd_queue_dequeue( output_port->queue_handle, &desc );
      
      if (result == ISMD_SUCCESS) {
         *buffer = desc->unique_id;
         update_all_tip_pending_inputs(output_port);
      }
      return ( result );
   }

  // case 2: the input port which called to pull didn't read the last buffer at the output port queue yet, 
  //         and there is other inputs which is connected to the same output port that didnt read it yet.
  //         so we need to pass this buffer to the input port which called this function, and if so - return success afther
  //         tring "push" this buffer to the other inputs

  if ((output_port->tip_pending_inputs[caller_index] == true ) && (other_input_pending)) {

      result = pass_tip_buffer_and_push_it(output_port, caller_index, buffer);

      return ( result );
  }

  // case 3: the input port which called to pull read the last buffer at the output port queue yet, 
  //         but other inputs which is connected to the same output port didnt read it yet.
  //         so we need to try "push" the last buffer to the other inputs, and then (if it success) - dequeue this buffer,
  //         update the tip_pending_inputs , pass the next buffer (now it is the tip one) to the input port
  //         which called pull and "push" this buffer to as many input ports (which connected to this output port) as we can

   if ((output_port->tip_pending_inputs[caller_index] == false ) && (other_input_pending)) {
# if 1  // temporary, blocked this case - is the only way it works...
      
      return ISMD_ERROR_NO_DATA_AVAILABLE;
#else 

      // push the last buffer to all the pending input ports which connected to the same output port 
      // except the input that called this function 
      result = ismd_queue_lookahead(output_port->queue_handle, 1, &last_buffer );
      if (result == ISMD_SUCCESS) {
         result = push_buffer_to_inputs(output_port, caller_index, last_buffer->unique_id);

         if (result == ISMD_SUCCESS){  // the tip buffer was pushed to all the inputs, dequeue, and the tip_pending_inputs was updated
            // now we need to pass the "new" tip buffer to the input that called "pull" and push this buffer to all other connections inputs.

            result = pass_tip_buffer_and_push_it(output_port, caller_index, buffer);
         }
      }
      return ( result );
#endif
   } // end case 3 

   return ( result );

 }  //end port_connect_pull


static ismd_result_t port_connect_push( void              *context, 
                                 ismd_queue_event_t        queue_event, 
                                 ismd_buffer_handle_t      buffer )
{
   ismd_port_t *output_port = (ismd_port_t *)context;

   (void)queue_event; // suppress warning about unused parameter

   // push the buffer to all pending connected inputs:

   return(push_buffer_to_inputs(output_port, -1, buffer));

}


static ismd_result_t port_set_event_output(    void                     *context, 
                                               ismd_queue_event_t        queue_event, 
                                               ismd_buffer_handle_t      buffer ) {
   ismd_port_event_t *port_event = (ismd_port_event_t *)context;
   (void) buffer;
   
   if ((queue_event != ISMD_QUEUE_EVENT_NONE) && (port_event->event_mask != ISMD_QUEUE_EVENT_NONE)) {
      if (
          (port_event->event_mask & ISMD_QUEUE_EVENT_ALWAYS) ||
          ((port_event->event_mask & queue_event) != 0)
         ) {
         ismd_event_strobe(port_event->event);
      }
   }


   return ISMD_ERROR_NO_SPACE_AVAILABLE; // Do not change the state of the queue
}

static ismd_result_t port_set_event_input(     void                     *context, 
                                               ismd_queue_event_t        queue_event, 
                                               ismd_buffer_handle_t     *buffer ) {
   ismd_port_event_t *port_event = (ismd_port_event_t *)context;
   (void) buffer;
   
   if ((queue_event != ISMD_QUEUE_EVENT_NONE) && (port_event->event_mask != ISMD_QUEUE_EVENT_NONE)) {
      if (
          (port_event->event_mask & ISMD_QUEUE_EVENT_ALWAYS) ||
          ((port_event->event_mask & queue_event) != 0)
         ) {
         ismd_event_strobe(port_event->event);
      }
   }


   return ISMD_ERROR_NO_DATA_AVAILABLE; // Do not change the state of the queue
}

