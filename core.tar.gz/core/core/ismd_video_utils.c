/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2006-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "osal.h"
#include "ismd_global_defs.h"
#include "smd_core_local_defs.h"


/**
Describes the structure of a sample plane (for a frame buffer) of a specific pixel format.
*/
typedef struct ismd_pixel_format_plane_info_t{
   int order;
   int width_num;
   int width_denom;
   int height_num;
   int height_denom;
}ismd_pixel_format_plane_info_t;

#define MAX_PLANE_COUNT 3

/**
Describes the structure of a the sample planes of a specific pixel format.
*/
typedef struct ismd_pixel_format_info_t{
   ismd_pixel_format_plane_info_t plane[MAX_PLANE_COUNT]; /* mappingt to frame attributes pointers: y = 0, u = 1, v = 2 */
}ismd_pixel_format_info_t;

const ismd_pixel_format_info_t ismd_pixel_format_info[ISMD_PF_COUNT] = {
    /* ISMD_PF_ARGB_32      */ 
    {{
       {1, 4, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1} }},          
    
    /* ISMD_PF_RGB_32,      */ 
    {{ 
       {1, 4, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_RGB_24,      */ 
    {{
       {1, 3, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_ARGB_16_1555 */ 
    {{
       {1, 2, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_ARGB_16_4444 */ 
    {{
       {1, 2, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_RGB_16,      */ 
    {{
       {1, 2, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_RGB_15,      */ 
    {{
       {1, 2, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_RGB_8        */ 
    {{
       {1, 1, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          
    
    /* ISMD_PF_ARGB_8       */ 
    {{
       {1, 1, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          
    
    /* ISMD_PF_YUY2         */ 
    {{
       {1, 2, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_UYVY         */ 
    {{
       {1, 2, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          
    
    /* ISMD_PF_YVYU         */ 
    {{
       {1, 2, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          
    
    /* ISMD_PF_VYUY         */ 
    {{
       {1, 2, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_YV12         */ 
    {{
       {1, 1, 1, 1, 1},
       {3, 1, 2, 1, 2},
       {2, 1, 2, 1, 2}, }},          

    /* ISMD_PF_YVU9         */ 
    {{
       {1, 1, 1, 1, 1},
       {3, 1, 4, 1, 4},
       {2, 1, 4, 1, 4}, }},          

    /* ISMD_PF_I420/IYUV    */ 
    {{
       {1, 1, 1, 1, 1},
       {2, 1, 2, 1, 2},
       {3, 1, 2, 1, 2}, }},          

    /* ISMD_PF_I422         */ 
    {{
       {1, 1, 1, 1, 1},
       {2, 1, 1, 1, 2},
       {3, 1, 1, 1, 2}, }},          

    /* ISMD_PF_YV16         */ 
    {{
       {1, 1, 1, 1, 1},
       {3, 1, 1, 1, 2},
       {2, 1, 1, 1, 2}, }},          

    /* ISMD_PF_NV12         */ 
    {{
       {1, 1, 1, 1, 1},
       {2, 1, 1, 1, 2},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_NV15         */ 
    {{
       {1, 10, 8, 1, 1},
       {2, 10, 8, 1, 2},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_NV16         */ 
    {{
       {1, 1, 1, 1, 1},
       {2, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_NV20         */ 
    {{
       {1, 10, 8, 1, 1},
       {2, 10, 8, 1, 1},
       {0, 1, 1, 1, 1}, }},          

    /* ISMD_PF_A8,          */ 
    {{
       {1, 1, 1, 1, 1},
       {0, 1, 1, 1, 1},
       {0, 1, 1, 1, 1}, }}
};


/**
Initalize the attributes of a new frame buffer with meaningful defaults. This 
should be used instead of using zero fills or uninitalized buffers to ensure 
that all fields have meaningful data.

@retval ISMD_SUCCESS : the attributes were initalized.
*/
ismd_result_t ismd_init_frame_attributes(
   ismd_frame_attributes_t *attr
)
{
   OS_MEMSET(attr, 0, sizeof(ismd_frame_attributes_t));
   return ISMD_SUCCESS;
}

/**
Get the allocation width and height required to allocate a given frame and the 
buffer stride to be used with the a buffer allocated with the settings.

@param format[in] the pixel format of the buffer to be allocated
@param system_stride[in] the current system stride
@param pixel_width[in] the width of the buffer in pixels
@param pixel_height[in] the height of the buffer in pixels
@param buffer_stride[out] the stride that should be used when accessing the buffer
@param alloc_width[out] the width that should be used when allocating the buffer
@param alloc_height[out] the height that should be used when allocating the buffer

@retval ISMD_SUCCESS : the buffer parameters were computed.
*/
ismd_result_t ismd_get_frame_alloc_size(
      ismd_pixel_format_t format,
      int system_stride,
      int pixel_width,
      int pixel_height,
      int *buffer_stride,
      int *alloc_width,
      int *alloc_height
)
{
   ismd_pixel_format_info_t format_info = ismd_pixel_format_info[format];
   int line_byte_width = 0;
   int row_count = 0;
   int plane;
   int temp;
   for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
      if(format_info.plane[plane].order > 0){
         temp = (pixel_width * format_info.plane[plane].width_num) / format_info.plane[plane].width_denom;
         if(temp > line_byte_width){
            line_byte_width = temp;
         }
         temp = (pixel_height * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom;
         row_count += temp;
      }
   }
   if(line_byte_width > system_stride){
      *buffer_stride = system_stride * 2;
      *alloc_height = row_count * 2;
      *alloc_width = system_stride;
   } else {
      *buffer_stride = system_stride;
      *alloc_height = row_count;
      *alloc_width = line_byte_width;
   }
   return ISMD_SUCCESS;
}


/**
Get the allocation width and height required to allocate a given frame and the 
buffer stride to be used with the a buffer allocated with the settings.

Also gets the width and height of the entire allocated buffer in pixels.

@param format[in] the pixel format of the buffer to be allocated
@param system_stride[in] the current system stride
@param image_pixel_width[in] the width of one view of the buffer in pixels
@param image_pixel_height[in] the height of one view of the buffer in pixels
@param frame_pixel_width[out] the total width of the buffer in pixels
@param frame_pixel_height[out] the total height of the buffer in pixels
@param buffer_stride[out] the stride that should be used when accessing the buffer
@param alloc_width[out] the width that should be used when allocating the buffer
@param alloc_height[out] the height that should be used when allocating the buffer

@retval ISMD_SUCCESS : the buffer parameters were computed.
*/
ismd_result_t ismd_get_frame_alloc_size_side_by_side(
      ismd_pixel_format_t format,
      int system_stride,
      int image_pixel_width,
      int image_pixel_height,
      int *frame_pixel_width,
      int *frame_pixel_height,
      int *buffer_stride,
      int *alloc_width,
      int *alloc_height
)
{
   ismd_pixel_format_info_t format_info = ismd_pixel_format_info[format];
   int line_byte_width = 0;
   int row_count = 0;
   int plane;
   int temp;
   image_pixel_width *= 2;
   for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
      if(format_info.plane[plane].order > 0){
         temp = (image_pixel_width * format_info.plane[plane].width_num) / format_info.plane[plane].width_denom;
         if(temp > line_byte_width){
            line_byte_width = temp;
         }
         temp = (image_pixel_height * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom;
         row_count += temp;
      }
   }
   *frame_pixel_width = image_pixel_width;
   *frame_pixel_height = image_pixel_height;
   if(line_byte_width > system_stride){
      *buffer_stride = system_stride * 2;
      *alloc_height = row_count * 2;
      *alloc_width = system_stride;
   } else {
      *buffer_stride = system_stride;
      *alloc_height = row_count;
      *alloc_width = line_byte_width;
   }
   return ISMD_SUCCESS;
}

/**
Get the allocation width and height required to allocate a given frame and the 
buffer stride to be used with the a buffer allocated with the settings.

Also gets the width and height of the entire allocated buffer in pixels.

@param format[in] the pixel format of the buffer to be allocated
@param system_stride[in] the current system stride
@param image_pixel_width[in] the width of one view of the buffer in pixels
@param image_pixel_height[in] the height of one view of the buffer in pixels
@param frame_pixel_width[out] the total width of the buffer in pixels
@param frame_pixel_height[out] the total height of the buffer in pixels
@param buffer_stride[out] the stride that should be used when accessing the buffer
@param alloc_width[out] the width that should be used when allocating the buffer
@param alloc_height[out] the height that should be used when allocating the buffer

@retval ISMD_SUCCESS : the buffer parameters were computed.
*/
ismd_result_t ismd_get_frame_alloc_size_over_under(
      ismd_pixel_format_t format,
      int system_stride,
      int image_pixel_width,
      int image_pixel_height,
      int *frame_pixel_width,
      int *frame_pixel_height,
      int *buffer_stride,
      int *alloc_width,
      int *alloc_height
)
{
   ismd_pixel_format_info_t format_info = ismd_pixel_format_info[format];
   int line_byte_width = 0;
   int row_count = 0;
   int plane;
   int temp;
   image_pixel_height *= 2;
   for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
      if(format_info.plane[plane].order > 0){
         temp = (image_pixel_width * format_info.plane[plane].width_num) / format_info.plane[plane].width_denom;
         if(temp > line_byte_width){
            line_byte_width = temp;
         }
         temp = (image_pixel_height * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom;
         row_count += temp;
      }
   }
   *frame_pixel_width = image_pixel_width;
   *frame_pixel_height = image_pixel_height;
   if(line_byte_width > system_stride){
      *buffer_stride = system_stride * 2;
      *alloc_height = row_count * 2;
      *alloc_width = system_stride;
   } else {
      *buffer_stride = system_stride;
      *alloc_height = row_count;
      *alloc_width = line_byte_width;
   }
   return ISMD_SUCCESS;
}

/**
Get the allocation width and height required to allocate a given frame and the 
buffer stride to be used with the a buffer allocated with the settings.

Also gets the width and height of the entire allocated buffer in pixels.

this function allows the caller to specify arbitary active blanking for increased 
compatibility.

@param format[in] the pixel format of the buffer to be allocated
@param system_stride[in] the current system stride
@param image_pixel_width[in] the width of one view of the buffer in pixels
@param image_pixel_height[in] the height of one view of the buffer in pixels
@param polarity[in] the polarity of the buffer 
@param vblank_1[in] The number of lines in the first active blanking section 
@param vblank_2[in] The number of lines in the second active blanking section (only used for interlaced buffers)
@param frame_pixel_width[out] the total width of the buffer in pixels
@param frame_pixel_height[out] the total height of the buffer in pixels
@param buffer_stride[out] the stride that should be used when accessing the buffer
@param alloc_width[out] the width that should be used when allocating the buffer
@param alloc_height[out] the height that should be used when allocating the buffer

@retval ISMD_SUCCESS : the buffer parameters were computed.
*/
ismd_result_t ismd_get_frame_alloc_size_frame_packing_adv(
      ismd_pixel_format_t format,
      int system_stride,
      int image_pixel_width,
      int image_pixel_height,
      ismd_frame_polarity_t polarity,
      int vblank_1,
      int vblank_2,
      int *frame_pixel_width,
      int *frame_pixel_height,
      int *buffer_stride,
      int *alloc_width,
      int *alloc_height
)
{
   ismd_pixel_format_info_t format_info = ismd_pixel_format_info[format];
   int line_byte_width = 0;
   int row_count = 0;
   int plane;
   int temp;
   image_pixel_height *= 2;

   if(ISMD_POLARITY_FRAME == polarity){
      image_pixel_height += vblank_1;
   } else {
      image_pixel_height += (vblank_1 * 2) + vblank_2;
   }
   for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
      if(format_info.plane[plane].order > 0){
         temp = (image_pixel_width * format_info.plane[plane].width_num) / format_info.plane[plane].width_denom;
         if(temp > line_byte_width){
            line_byte_width = temp;
         }
         temp = (image_pixel_height * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom;
         row_count += temp;
      }
   }
   *frame_pixel_width = image_pixel_width;
   *frame_pixel_height = image_pixel_height;
   if(line_byte_width > system_stride){
      *buffer_stride = system_stride * 2;
      *alloc_height = row_count * 2;
      *alloc_width = system_stride;
   } else {
      *buffer_stride = system_stride;
      *alloc_height = row_count;
      *alloc_width = line_byte_width;
   }
   return ISMD_SUCCESS;
}

/**
Get the allocation width and height required to allocate a given frame and the 
buffer stride to be used with the a buffer allocated with the settings.

Also gets the width and height of the entire allocated buffer in pixels.

This function supports only 1080i/p and 720p.
it uses the values in the HDMI 1.4 specification of:
format  vblank
        1    2
----------------
1080p   45 
720p    30
1080i   22   23

@param format[in] the pixel format of the buffer to be allocated
@param system_stride[in] the current system stride
@param image_pixel_width[in] the width of one view of the buffer in pixels
@param image_pixel_height[in] the height of one view of the buffer in pixels
@param polarity[in] the polarity of the buffer 
@param frame_pixel_width[out] the total width of the buffer in pixels
@param frame_pixel_height[out] the total height of the buffer in pixels
@param buffer_stride[out] the stride that should be used when accessing the buffer
@param alloc_width[out] the width that should be used when allocating the buffer
@param alloc_height[out] the height that should be used when allocating the buffer

@retval ISMD_SUCCESS : the buffer parameters were computed.
*/
ismd_result_t ismd_get_frame_alloc_size_frame_packing(
      ismd_pixel_format_t format,
      int system_stride,
      int image_pixel_width,
      int image_pixel_height,
      ismd_frame_polarity_t polarity,
      int *frame_pixel_width,
      int *frame_pixel_height,
      int *buffer_stride,
      int *alloc_width,
      int *alloc_height
)
{
   //HDMI 1.4 spec:
   //   45 line active blanking section for 1080p progressive 
   //   30 line active blanking section for 720p progressive
   //   
   //   23 / 22 / 23 line active blanking sections for interlaced
   //
   // this code only works with common 1080i/p and 720p input,
   // for advanced support use ismd_get_frame_alloc_size_frame_packing_adv

   int vblank_1 = 45;
   int vblank_2 = 0;
   if(ISMD_POLARITY_FRAME == polarity){
      if(image_pixel_height == 720){
         vblank_1 = 30;
      }
   } else {
      vblank_1 = 23;
      vblank_2 = 22;
   }

   return ismd_get_frame_alloc_size_frame_packing_adv(
      format,
      system_stride,
      image_pixel_width,
      image_pixel_height,
      polarity,
      vblank_1,
      vblank_2,
      frame_pixel_width,
      frame_pixel_height,
      buffer_stride,
      alloc_width,
      alloc_height
   );
}



/**
Get the allocation width and height required to allocate a given frame and the 
buffer stride to be used with the a buffer allocated with the settings.

Also gets the width and height of the entire allocated buffer in pixels.

@param format[in] the pixel format of the buffer to be allocated
@param system_stride[in] the current system stride
@param image_pixel_width[in] the width of one view of the buffer in pixels
@param image_pixel_height[in] the height of one view of the buffer in pixels
@param frame_pixel_width[out] the total width of the buffer in pixels
@param frame_pixel_height[out] the total height of the buffer in pixels
@param buffer_stride[out] the stride that should be used when accessing the buffer
@param alloc_width[out] the width that should be used when allocating the buffer
@param alloc_height[out] the height that should be used when allocating the buffer

@retval ISMD_SUCCESS : the buffer parameters were computed.
*/
ismd_result_t ismd_get_frame_alloc_size_line_alternative(
      ismd_pixel_format_t format,
      int system_stride,
      int image_pixel_width,
      int image_pixel_height,
      int *frame_pixel_width,
      int *frame_pixel_height,
      int *buffer_stride,
      int *alloc_width,
      int *alloc_height
)
{
   ismd_pixel_format_info_t format_info = ismd_pixel_format_info[format];
   int line_byte_width = 0;
   int row_count = 0;
   int plane;
   int temp;
   image_pixel_height *= 2;
   for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
      if(format_info.plane[plane].order > 0){
         temp = (image_pixel_width * format_info.plane[plane].width_num) / format_info.plane[plane].width_denom;
         if(temp > line_byte_width){
            line_byte_width = temp;
         }
         temp = (image_pixel_height * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom;
         row_count += temp;
      }
   }
   *frame_pixel_width = image_pixel_width;
   *frame_pixel_height = image_pixel_height;
   if(line_byte_width > system_stride){
      *buffer_stride = system_stride * 2;
      *alloc_height = row_count * 2;
      *alloc_width = system_stride;
   } else {
      *buffer_stride = system_stride;
      *alloc_height = row_count;
      *alloc_width = line_byte_width;
   }
   return ISMD_SUCCESS;
}

/**
Set the pointers, stride, and polarity of a frame attributes 
structure to describe a single 2D frame from a buffer containing a 2D frame.

This should only only be called on previoulsy inialized attributes.

@param attr[in,out] the frame attributes structure to be filed in
@param pixel_width[in] the width in pixels of the frame that will be represented. 
                       (note: for side formats like side-by-side half this should 
                       be the halved size)
@param pixel_height[in] the height in pixels of the frame that will be represented. 
                       (note: for side formats like over-under using half vertical 
                       scaling this 
                       should be the halved size)
@param buffer_stride[in] the stride of the underlying buffer data. this may be 
                         SYSTEM_STRIDE, or may be a multiple of SYSTEM_STRIDE 
                         when stride folding is used.
@param format[in] the format of the pixels in the buffer, including sample placement 
                  and bit depth, as represented by the ismd_pixel_format_t enumeration
@param polarity[in] the polarity of the buffer that will be read. Note that 
                    some stereo formats are processed significantly differently 
                    for progressive and interlaced cases. as represented by the 
                    ismd_frame_polarity_t enumeration

@retval ISMD_SUCCESS : the gemoetry was written to the attributes.
*/
ismd_result_t ismd_set_frame_geometry(
   ismd_frame_attributes_t *attr,
   int pixel_width,
   int pixel_height,
   int buffer_stride,
   ismd_pixel_format_t format,
   ismd_frame_polarity_t polarity
){
   int plane_index;
   int plane;
   ismd_physical_address_t cur_addr = 0;
   ismd_physical_address_t top_addr[MAX_PLANE_COUNT];
   ismd_physical_address_t bottom_addr[MAX_PLANE_COUNT];
   int stride = buffer_stride;
   ismd_pixel_format_info_t format_info = ismd_pixel_format_info[format];
   int data_width[MAX_PLANE_COUNT];
   int data_height[MAX_PLANE_COUNT];

   for(plane = 0; plane < MAX_PLANE_COUNT; plane++){
      top_addr[plane] = 0;
      bottom_addr[plane] = 0;
      data_width[plane]  = (pixel_width  * format_info.plane[plane].width_num)  / format_info.plane[plane].width_denom;
      data_height[plane] = (pixel_height * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom;
   }

   for(plane_index = 1; plane_index<(MAX_PLANE_COUNT+1); plane_index++){
      for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
         if(format_info.plane[plane].order == plane_index){
            top_addr[plane] = cur_addr;
            bottom_addr[plane] = cur_addr + buffer_stride;
            cur_addr += data_height[plane] * buffer_stride;
         }
      }
   }

   if(ISMD_POLARITY_FRAME != polarity){
      stride *= 2;
   }

   attr->y = top_addr[0];
   attr->u = top_addr[1];
   attr->v = top_addr[2];
   attr->bottom_y = bottom_addr[0];
   attr->bottom_u = bottom_addr[1];
   attr->bottom_v = bottom_addr[2];
   attr->scanline_stride = stride;
   attr->separated_fields = true;
   attr->cont_size.width = pixel_width,
   attr->cont_size.height = pixel_height,
   attr->dest_size.width = pixel_width,
   attr->dest_size.height = pixel_height,

   attr->pixel_format = format;
   attr->polarity = polarity;

   return ISMD_SUCCESS;
}

/**
Set the pointers, stride, and polarity of a frame attributes 
structure to describe one view of a 3D frame in Side-by-Side format

This should only only be called on previoulsy inialized attributes.

@param attr[in,out] the frame attributes structure to be filed in
@param pixel_width[in] the width in pixels of the frame that will be represented. 
                       (note: for side formats like side-by-side half this should 
                       be the halved size)
@param pixel_height[in] the height in pixels of the frame that will be represented. 
                       (note: for side formats like over-under using half vertical 
                       scaling this 
                       should be the halved size)
@param buffer_stride[in] the stride of the underlying buffer data. this may be 
                         SYSTEM_STRIDE, or may be a multiple of SYSTEM_STRIDE 
                         when stride folding is used.
@param format[in] the format of the pixels in the buffer, including sample placement 
                  and bit depth, as represented by the ismd_pixel_format_t enumeration
@param polarity[in] the polarity of the buffer that will be read. Note that 
                    some stereo formats are processed significantly differently 
                    for progressive and interlaced cases. as represented by the 
                    ismd_frame_polarity_t enumeration
@param angle[in] The angle of the view to be used in the target attributes. 
                 For stereo frames two views may be packed into one buffer. This 
                 parameter indicates which view is desired.
                 as represented by the ismd_video_angle_t enumeration

@retval ISMD_SUCCESS : the gemoetry was written to the attributes.
*/
ismd_result_t ismd_set_frame_geometry_side_by_side(
   ismd_frame_attributes_t *attr,
   int pixel_width,
   int pixel_height,
   int buffer_stride,
   ismd_pixel_format_t format,
   ismd_frame_polarity_t polarity,   
   ismd_video_angle_t angle
){
   int plane_index;
   int plane;
   ismd_physical_address_t cur_addr = 0;
   ismd_physical_address_t top_addr[MAX_PLANE_COUNT];
   ismd_physical_address_t bottom_addr[MAX_PLANE_COUNT];
   int stride = buffer_stride;
   ismd_pixel_format_info_t format_info = ismd_pixel_format_info[format];
   int data_width[MAX_PLANE_COUNT];
   int data_height[MAX_PLANE_COUNT];
   for(plane = 0; plane < MAX_PLANE_COUNT; plane++){
      top_addr[plane] = 0;
      bottom_addr[plane] = 0;
      data_width[plane]  = (pixel_width  * format_info.plane[plane].width_num)  / format_info.plane[plane].width_denom;
      data_height[plane] = (pixel_height * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom;
   }

   for(plane_index = 1; plane_index<(MAX_PLANE_COUNT+1); plane_index++){
      for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
         if(format_info.plane[plane].order == plane_index){
            top_addr[plane] = cur_addr;
            bottom_addr[plane] = cur_addr + buffer_stride;
            cur_addr += data_height[plane] * buffer_stride;
         }
      }
   }

   if(ISMD_VIDEO_ANGLE_RIGHT_EYE == angle){
      for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
         if(format_info.plane[plane].order > 0){
            top_addr[plane] += data_width[plane];
            bottom_addr[plane] += data_width[plane];
         }
      }
   }

   if(ISMD_POLARITY_FRAME != polarity){
      stride *= 2;
   }

   attr->y = top_addr[0];
   attr->u = top_addr[1];
   attr->v = top_addr[2];
   attr->bottom_y = bottom_addr[0];
   attr->bottom_u = bottom_addr[1];
   attr->bottom_v = bottom_addr[2];
   attr->scanline_stride = stride;
   attr->separated_fields = true;
   attr->cont_size.width = pixel_width;
   attr->cont_size.height = pixel_height;
   attr->pixel_format = format;
   attr->polarity = polarity;

   return ISMD_SUCCESS;
}

/**
Set the pointers, stride, and polarity of a frame attributes 
structure to describe one view of a 3D frame in Over/Under (aka Top/Bottom) format

This should only only be called on previoulsy inialized attributes.

@param attr[in,out] the frame attributes structure to be filed in
@param pixel_width[in] the width in pixels of the frame that will be represented. 
                       (note: for side formats like side-by-side half this should 
                       be the halved size)
@param pixel_height[in] the height in pixels of the frame that will be represented. 
                       (note: for side formats like over-under using half vertical 
                       scaling this 
                       should be the halved size)
@param buffer_stride[in] the stride of the underlying buffer data. this may be 
                         SYSTEM_STRIDE, or may be a multiple of SYSTEM_STRIDE 
                         when stride folding is used.
@param format[in] the format of the pixels in the buffer, including sample placement 
                  and bit depth, as represented by the ismd_pixel_format_t enumeration
@param polarity[in] the polarity of the buffer that will be read. Note that 
                    some stereo formats are processed significantly differently 
                    for progressive and interlaced cases. as represented by the 
                    ismd_frame_polarity_t enumeration
@param angle[in] The angle of the view to be used in the target attributes. 
                 For stereo frames two views may be packed into one buffer. This 
                 parameter indicates which view is desired.
                 as represented by the ismd_video_angle_t enumeration

@retval ISMD_SUCCESS : the gemoetry was written to the attributes.
*/
ismd_result_t ismd_set_frame_geometry_over_under(
   ismd_frame_attributes_t *attr,
   int pixel_width,
   int pixel_height,
   int buffer_stride,
   ismd_pixel_format_t format,
   ismd_frame_polarity_t polarity,   
   ismd_video_angle_t angle
){
   int plane_index;
   int plane;
   ismd_physical_address_t cur_addr = 0;
   ismd_physical_address_t top_addr[MAX_PLANE_COUNT];
   ismd_physical_address_t bottom_addr[MAX_PLANE_COUNT];
   int stride = buffer_stride;
   ismd_pixel_format_info_t format_info = ismd_pixel_format_info[format];
   int data_width[MAX_PLANE_COUNT];
   int data_height[MAX_PLANE_COUNT];
   for(plane = 0; plane < MAX_PLANE_COUNT; plane++){
      top_addr[plane] = 0;
      bottom_addr[plane] = 0;
      data_width[plane]  = (pixel_width  * format_info.plane[plane].width_num)  / format_info.plane[plane].width_denom;
      data_height[plane] = (pixel_height * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom;
   }

   for(plane_index = 1; plane_index<(MAX_PLANE_COUNT+1); plane_index++){
      for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
         if(format_info.plane[plane].order == plane_index){
            top_addr[plane] = cur_addr;
            bottom_addr[plane] = cur_addr + buffer_stride;
            cur_addr += data_height[plane] * 2 * buffer_stride;
         }
      }
   }

   if(ISMD_VIDEO_ANGLE_RIGHT_EYE == angle){
      for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
         if(format_info.plane[plane].order > 0){
            top_addr[plane] += buffer_stride * data_height[plane];
            bottom_addr[plane] += buffer_stride * data_height[plane];
         }
      }
   }

   if(ISMD_POLARITY_FRAME != polarity){
      stride *= 2;
   }

   attr->y = top_addr[0];
   attr->u = top_addr[1];
   attr->v = top_addr[2];
   attr->bottom_y = bottom_addr[0];
   attr->bottom_u = bottom_addr[1];
   attr->bottom_v = bottom_addr[2];
   attr->scanline_stride = stride;
   attr->separated_fields = true;
   attr->cont_size.width = pixel_width,
   attr->cont_size.height = pixel_height,
   attr->pixel_format = format;
   attr->polarity = polarity;

   return ISMD_SUCCESS;
}

/**
Set the pointers, stride, and polarity of a frame attributes 
structure to describe one view of a 3D frame in Frame Packing format

This should only only be called on previoulsy inialized attributes.


this function allows the caller to specify arbitary active blanking for increased 
compatibility.

@param attr[in,out] the frame attributes structure to be filed in
@param pixel_width[in] the width in pixels of the frame that will be represented. 
                       (note: for side formats like side-by-side half this should 
                       be the halved size)
@param pixel_height[in] the height in pixels of the frame that will be represented. 
                       (note: for side formats like over-under using half vertical 
                       scaling this 
                       should be the halved size)
@param buffer_stride[in] the stride of the underlying buffer data. this may be 
                         SYSTEM_STRIDE, or may be a multiple of SYSTEM_STRIDE 
                         when stride folding is used.
@param format[in] the format of the pixels in the buffer, including sample placement 
                  and bit depth, as represented by the ismd_pixel_format_t enumeration
@param polarity[in] the polarity of the buffer that will be read. Note that 
                    some stereo formats are processed significantly differently 
                    for progressive and interlaced cases. as represented by the 
                    ismd_frame_polarity_t enumeration
@param angle[in] The angle of the view to be used in the target attributes. 
                 For stereo frames two views may be packed into one buffer. This 
                 parameter indicates which view is desired.
                 as represented by the ismd_video_angle_t enumeration
@param vblank_1[in] The number of lines in the first active blanking section 
@param vblank_2[in] The number of lines in the second active blanking section (only used for interlaced buffers)

@retval ISMD_SUCCESS : the gemoetry was written to the attributes.
*/
ismd_result_t ismd_set_frame_geometry_frame_packing_adv(
   ismd_frame_attributes_t *attr,
   int pixel_width,
   int pixel_height,
   int buffer_stride,
   ismd_pixel_format_t format,
   ismd_frame_polarity_t polarity,   
   ismd_video_angle_t angle,
   int vblank_1,
   int vblank_2
){
   int plane_index;
   int plane;
   ismd_physical_address_t cur_addr = 0;
   ismd_physical_address_t top_addr[MAX_PLANE_COUNT];
   ismd_physical_address_t bottom_addr[MAX_PLANE_COUNT];
   int stride = buffer_stride;
   ismd_pixel_format_info_t format_info = ismd_pixel_format_info[format];
   int data_width[MAX_PLANE_COUNT];
   int data_height[MAX_PLANE_COUNT];
   for(plane = 0; plane < MAX_PLANE_COUNT; plane++){
      top_addr[plane] = 0;
      bottom_addr[plane] = 0;
      data_width[plane]  = (pixel_width  * format_info.plane[plane].width_num)  / format_info.plane[plane].width_denom;
      data_height[plane] = (pixel_height * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom;
   }

   if(ISMD_POLARITY_FRAME == polarity){
      for(plane_index = 1; plane_index<(MAX_PLANE_COUNT+1); plane_index++){
         for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
            if(format_info.plane[plane].order == plane_index){
               top_addr[plane] = cur_addr;
               cur_addr += (data_height[plane]) * buffer_stride;

               cur_addr += ((vblank_1 * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom) * buffer_stride;

               if(ISMD_VIDEO_ANGLE_RIGHT_EYE == angle){
                  top_addr[plane] = cur_addr;
               }
               cur_addr += (data_height[plane]) * buffer_stride;
            }
         }
      }
   } else {
      for(plane_index = 1; plane_index<(MAX_PLANE_COUNT+1); plane_index++){
         for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
            if(format_info.plane[plane].order == plane_index){
               top_addr[plane] = cur_addr;
               cur_addr += (data_height[plane]/2) * buffer_stride;

               cur_addr += ((vblank_1 * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom) * buffer_stride;

               if(ISMD_VIDEO_ANGLE_RIGHT_EYE == angle){
                  top_addr[plane] = cur_addr;
               }
               cur_addr += (data_height[plane]/2) * buffer_stride;

               cur_addr += ((vblank_2 * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom) * buffer_stride;

               bottom_addr[plane] = cur_addr;
               cur_addr += (data_height[plane]/2) * buffer_stride;

               cur_addr += ((vblank_1 * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom) * buffer_stride;

               if(ISMD_VIDEO_ANGLE_RIGHT_EYE == angle){
                  bottom_addr[plane] = cur_addr;
               }
               cur_addr += (data_height[plane]/2) * buffer_stride;

            }
         }
      }
   }

   attr->y = top_addr[0];
   attr->u = top_addr[1];
   attr->v = top_addr[2];
   attr->bottom_y = bottom_addr[0];
   attr->bottom_u = bottom_addr[1];
   attr->bottom_v = bottom_addr[2];
   attr->scanline_stride = stride;
   attr->separated_fields = true;
   attr->cont_size.width = pixel_width,
   attr->cont_size.height = pixel_height,
   attr->pixel_format = format;
   attr->polarity = polarity;

   return ISMD_SUCCESS;
}

/**
Set the pointers, stride, and polarity of a frame attributes 
structure to describe one view of a 3D frame in Frame Packing format

This should only only be called on previoulsy inialized attributes.

This function supports only 1080i/p and 720p.
it uses the values in the HDMI 1.4 specification of:
format  vblank
        1    2
----------------
1080p   45 
720p    30
1080i   23   22


@param attr[in,out] the frame attributes structure to be filed in
@param pixel_width[in] the width in pixels of the frame that will be represented. 
                       (note: for side formats like side-by-side half this should 
                       be the halved size)
@param pixel_height[in] the height in pixels of the frame that will be represented. 
                       (note: for side formats like over-under using half vertical 
                       scaling this 
                       should be the halved size)
@param buffer_stride[in] the stride of the underlying buffer data. this may be 
                         SYSTEM_STRIDE, or may be a multiple of SYSTEM_STRIDE 
                         when stride folding is used.
@param format[in] the format of the pixels in the buffer, including sample placement 
                  and bit depth, as represented by the ismd_pixel_format_t enumeration
@param polarity[in] the polarity of the buffer that will be read. Note that 
                    some stereo formats are processed significantly differently 
                    for progressive and interlaced cases. as represented by the 
                    ismd_frame_polarity_t enumeration
@param angle[in] The angle of the view to be used in the target attributes. 
                 For stereo frames two views may be packed into one buffer. This 
                 parameter indicates which view is desired.
                 as represented by the ismd_video_angle_t enumeration

@retval ISMD_SUCCESS : the gemoetry was written to the attributes.
*/
ismd_result_t ismd_set_frame_geometry_frame_packing(
   ismd_frame_attributes_t *attr,
   int pixel_width,
   int pixel_height,
   int buffer_stride,
   ismd_pixel_format_t format,
   ismd_frame_polarity_t polarity,   
   ismd_video_angle_t angle
){

   //HDMI 1.4 spec:
   //   45 line active blanking section for 1080p progressive 
   //   30 line active blanking section for 720p progressive
   //   
   //   23 / 22 / 23 line active blanking sections for interlaced
   //
   // this code only works with common 1080i/p and 720p input,
   // for advanced support use ismd_get_frame_alloc_size_frame_packing_adv

   int vblank_1 = 45;
   int vblank_2 = 0;
   if(ISMD_POLARITY_FRAME == polarity){
      if(pixel_height == 720){
         vblank_1 = 30;
      }
   } else {
      vblank_1 = 23;
      vblank_2 = 22;
   }
   return ismd_set_frame_geometry_frame_packing_adv(
      attr,
      pixel_width,
      pixel_height,
      buffer_stride,
      format,
      polarity,   
      angle,
      vblank_1,
      vblank_2
   );
}

/**
Set the pointers, stride, and polarity of a frame attributes 
structure to describe one view of a 3D frame in Line Alternative format.

This should only only be called on previoulsy inialized attributes.

@param attr[in,out] the frame attributes structure to be filed in
@param pixel_width[in] the width in pixels of the frame that will be represented. 
                       (note: for side formats like side-by-side half this should 
                       be the halved size)
@param pixel_height[in] the height in pixels of the frame that will be represented. 
                       (note: for side formats like over-under using half vertical 
                       scaling this 
                       should be the halved size)
@param buffer_stride[in] the stride of the underlying buffer data. this may be 
                         SYSTEM_STRIDE, or may be a multiple of SYSTEM_STRIDE 
                         when stride folding is used.
@param format[in] the format of the pixels in the buffer, including sample placement 
                  and bit depth, as represented by the ismd_pixel_format_t enumeration
@param polarity[in] the polarity of the buffer that will be read. Note that 
                    some stereo formats are processed significantly differently 
                    for progressive and interlaced cases. as represented by the 
                    ismd_frame_polarity_t enumeration
@param angle[in] The angle of the view to be used in the target attributes. 
                 For stereo frames two views may be packed into one buffer. This 
                 parameter indicates which view is desired.
                 as represented by the ismd_video_angle_t enumeration

@retval ISMD_SUCCESS : the gemoetry was written to the attributes.
*/
ismd_result_t ismd_set_frame_geometry_line_alternative(
   ismd_frame_attributes_t *attr,
   int pixel_width,
   int pixel_height,
   int buffer_stride,
   ismd_pixel_format_t format,
   ismd_frame_polarity_t polarity,   
   ismd_video_angle_t angle
){
   int plane_index;
   int plane;
   ismd_physical_address_t cur_addr = 0;
   ismd_physical_address_t top_addr[MAX_PLANE_COUNT];
   ismd_physical_address_t bottom_addr[MAX_PLANE_COUNT];
   int stride = buffer_stride;
   ismd_pixel_format_info_t format_info = ismd_pixel_format_info[format];
   int data_width[MAX_PLANE_COUNT];
   int data_height[MAX_PLANE_COUNT];
   for(plane = 0; plane < MAX_PLANE_COUNT; plane++){
      top_addr[plane] = 0;
      bottom_addr[plane] = 0;
      data_width[plane]  = (pixel_width  * format_info.plane[plane].width_num)  / format_info.plane[plane].width_denom;
      data_height[plane] = (pixel_height * format_info.plane[plane].height_num) / format_info.plane[plane].height_denom;
   }

   if(ISMD_POLARITY_FRAME == polarity){
      for(plane_index = 1; plane_index<(MAX_PLANE_COUNT+1); plane_index++){
         for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
            if(format_info.plane[plane].order == plane_index){
               top_addr[plane] = cur_addr;
               cur_addr += 2 * (data_height[plane]) * buffer_stride;
            }
         }
      }

      if(ISMD_VIDEO_ANGLE_RIGHT_EYE == angle){
         for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
            top_addr[plane] += buffer_stride;
         }
      }
      stride *= 2;
   } else {
      for(plane_index = 1; plane_index<(MAX_PLANE_COUNT+1); plane_index++){
         for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
            if(format_info.plane[plane].order == plane_index){
               top_addr[plane] = cur_addr;
               bottom_addr[plane] = cur_addr + buffer_stride;
               cur_addr += 2 * (data_height[plane]) * buffer_stride;
            }
         }
      }

      if(ISMD_VIDEO_ANGLE_RIGHT_EYE == angle){
         for(plane = 0; plane<MAX_PLANE_COUNT; plane++){
            top_addr[plane] += 2 * buffer_stride;
         }
      }
      stride *= 4;
   }

   attr->y = top_addr[0];
   attr->u = top_addr[1];
   attr->v = top_addr[2];
   attr->bottom_y = bottom_addr[0];
   attr->bottom_u = bottom_addr[1];
   attr->bottom_v = bottom_addr[2];
   attr->scanline_stride = stride;
   attr->separated_fields = true;
   attr->cont_size.width = pixel_width,
   attr->cont_size.height = pixel_height,
   attr->pixel_format = format;
   attr->polarity = polarity;
   return ISMD_SUCCESS;
}
