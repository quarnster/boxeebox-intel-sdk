/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2006-2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#ifdef __KERNEL__
// for kmalloc and KMALLOC_MAX_SIZE used in query_largest_available_block()
#include "linux/slab.h"
#endif //def __KERNEL__

#include "smd_core_local_defs.h"
#include "ismd_core.h"

#define CRITICAL_ERROR_EVENT_COUNT 16

int ismd_debug_level = 1;

static ismd_event_t critical_error_events[CRITICAL_ERROR_EVENT_COUNT];

ismd_verbosity_level_t logging_verbosity_level;

static bool valid_verbosity_level( ismd_verbosity_level_t level );

os_devhandle_t *smd_dbg_devh[SMD_CORE_DEBUG_UNIT_MAX];

void smd_core_send_sven_event(
    smd_debug_unit_type_t    smd_core_unit,
    enum SVEN_EV_SMDCore_t   subtype,
    int                      payload0,
    int                      payload1,
    int                      payload2,
    int                      payload3,
    int                      payload4,
    int                      payload5 )
{
    os_devhandle_t *devh = NULL;

    /* Get the debug device handle to write through */
    if ( smd_core_unit < SMD_CORE_DEBUG_UNIT_MAX )  /* enum is unsigned */
    {
        devh = smd_dbg_devh[smd_core_unit];
    }

    if ( NULL != devh )
    {
        /* No disable bits set */
        if ( devh_IsEventHotEnabled(devh,SVENHeader_DISABLE_SMD) )
        {
            struct SVENEvent        ev;

            /* Initialize the tag */
            ev.se_et.et_module = SVEN_module_SMD_CORE;
            ev.se_et.et_unit = smd_core_unit;
            ev.se_et.et_type = SVEN_event_type_smd;
            ev.se_et.et_subtype = subtype;

            ev.u.se_uint[0] = payload0;
            ev.u.se_uint[1] = payload1;
            ev.u.se_uint[2] = payload2;
            ev.u.se_uint[3] = payload3;
            ev.u.se_uint[4] = payload4;
            ev.u.se_uint[5] = payload5;

            devh_SVEN_WriteEvent( devh, &ev );
        }
    }
}



void smd_core_send_sven_event_named(
    smd_debug_unit_type_t    smd_core_unit,
    enum SVEN_EV_SMDCore_t   subtype,
    int                      id,
    char *                   name,
    int                      name_length)
{
    os_devhandle_t *devh = NULL;

    /* Get the debug device handle to write through */
    if ( smd_core_unit < SMD_CORE_DEBUG_UNIT_MAX )  /* enum is unsigned */
    {
        devh = smd_dbg_devh[smd_core_unit];
    }

    if ( NULL != devh )
    {
        /* No disable bits set */
        if ( devh_IsEventHotEnabled(devh,SVENHeader_DISABLE_SMD) )
        {
            struct SVENEvent        ev;

            /* Initialize the tag */
            ev.se_et.et_module = SVEN_module_SMD_CORE;
            ev.se_et.et_unit = smd_core_unit;
            ev.se_et.et_type = SVEN_event_type_smd;
            ev.se_et.et_subtype = subtype;

            ev.u.smd.setname.id = id;
            //ev.u.smd.setname.name = name;
            OS_MEMCPY( ev.u.smd.setname.name,
                       name,
                       name_length < SVEN_EVENT_PAYLOAD_NUM_UCHARS_SMD ? name_length : SVEN_EVENT_PAYLOAD_NUM_UCHARS_SMD );
            if ( name_length < SVEN_EVENT_PAYLOAD_NUM_UCHARS_SMD ) {      // Null terminate string.
               ev.u.smd.setname.name[name_length] = 0;
            } else {
               ev.u.smd.setname.name[SVEN_EVENT_PAYLOAD_NUM_UCHARS_SMD-1] = 0;
            }
            devh_SVEN_WriteEvent( devh, &ev );
        }
    }
}



ismd_result_t ismd_core_init(void) {

   /* Create a SVEN Handle for debug unit types */
   {
      int     unit;
      for ( unit = 0; unit < SMD_CORE_DEBUG_UNIT_MAX; unit++ ) {
         smd_dbg_devh[unit] = devhandle_factory( NULL );
         if ( smd_dbg_devh[unit] != NULL ) {
            devh_SVEN_SetModuleUnit( smd_dbg_devh[unit], SVEN_module_SMD_CORE, unit );
         }
      }
   }

   /* clear the critical error events */
   {
      unsigned event_num;
      for (event_num = 0; event_num < CRITICAL_ERROR_EVENT_COUNT; event_num++) {
         critical_error_events[event_num] = ISMD_EVENT_HANDLE_INVALID;
      }
   }


   OS_ASSERT(ismd_buffer_manager_init() == ISMD_SUCCESS);
   ismd_event_manager_init();
   ismd_clock_manager_init();
   ismd_queue_manager_init();
   ismd_port_manager_init();
   ismd_device_manager_init();
   ismd_message_manager_init();

   return ( ISMD_SUCCESS );
}


ismd_result_t ismd_core_deinit(void)
{
    ismd_result_t result = ISMD_SUCCESS;

    logging_verbosity_level = ISMD_LOG_VERBOSITY_OFF;

    ismd_buffer_manager_deinit();
    ismd_message_manager_deinit();
    ismd_clock_manager_deinit();
    //TODO: De-init the other components.


    return (result);
}


ismd_result_t ismd_set_logging_verbosity_level( ismd_verbosity_level_t level )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   if ( valid_verbosity_level(level) ) {
      logging_verbosity_level = level;
   }
   else {
      result = ISMD_ERROR_INVALID_VERBOSITY_LEVEL;
   }

   return (result);
}


ismd_result_t ismd_set_debug_message_level( int debug_level )
{
    /*
     * FIXME:  put code in here to check for a valid debug level.
     * Not a high priority since it's just for debug support and
     * will work if it's used properly.
     */
    ismd_debug_level = debug_level;
    return ( ISMD_SUCCESS ) ;
}


static bool valid_verbosity_level( ismd_verbosity_level_t level )
{
    bool result = false;
    if ( /* ( level >= ISMD_LOG_VERBOSITY_OFF    ) && */
         ( level <= ISMD_LOG_VERBOSITY_LEVEL_4) ) {
        result = true;
    }
    return ( result );
}


uint32_t ismd_read_register( ismd_physical_address_t address )
{
   uint32_t value = 0;
   uint32_t *reg = (uint32_t *) OS_MAP_IO_TO_MEM_NOCACHE( address, sizeof(uint32_t) );

   if ( reg != NULL ) {
      value = *reg;
      OS_UNMAP_IO_FROM_MEM( (void *)reg, sizeof(uint32_t) );
   }
   else {
      ISMD_LOG_MSG( 1, "ismd_read_register: unable to map register address 0x%08X.\r\n", address );
   }

   return ( value );
}


void ismd_write_register( ismd_physical_address_t address, uint32_t value )
{
   uint32_t *reg = (uint32_t *) OS_MAP_IO_TO_MEM_NOCACHE( address, sizeof(uint32_t) );

   if ( reg != NULL ) {
      *reg = value;
      OS_UNMAP_IO_FROM_MEM( (void *)reg, sizeof(uint32_t) );
   }
   else {
      ISMD_LOG_MSG( 1, "ismd_write_register: unable to map register address 0x%08X.\r\n", address );
   }
}


void ismd_and_register( ismd_physical_address_t address, uint32_t value )
{
   uint32_t *reg = (uint32_t *) OS_MAP_IO_TO_MEM_NOCACHE( address, sizeof(uint32_t) );
   if ( reg != NULL ) {
      *reg |= value;
      OS_UNMAP_IO_FROM_MEM( (void *)reg, sizeof(uint32_t) );
   }
   else {
      ISMD_LOG_MSG( 1, "ismd_and_register: unable to map register address 0x%08X.\r\n", address );
   }
}


void ismd_or_register( ismd_physical_address_t address, uint32_t value )
{
   uint32_t *reg = (uint32_t *) OS_MAP_IO_TO_MEM_NOCACHE( address, sizeof(uint32_t) );
   if ( reg != NULL ) {
      *reg &= value;
      OS_UNMAP_IO_FROM_MEM( (void *)reg, sizeof(uint32_t) );
   }
   else {
      ISMD_LOG_MSG( 1, "ismd_or_register: unable to map register address 0x%08X.\r\n", address );
   }
}

ismd_result_t ismd_convert_segment_time_to_stream_position(ismd_pts_t  segment_time,
                                                       ismd_pts_t  segment_start,
                                                       ismd_pts_t  segment_stop,
                                                       int        rate,
                                                       int        applied_rate,
                                                       ismd_pts_t  segment_position,
                                                       ismd_pts_t  *stream_position)
{
   ismd_result_t result = ISMD_SUCCESS;
   int abs_applied_rate = (applied_rate < 0) ? ((-1) * applied_rate) : (applied_rate);

   if(rate > 0 && segment_start != ISMD_NO_PTS && segment_position != ISMD_NO_PTS &&
         segment_time != ISMD_NO_PTS && applied_rate != 0) {
      *stream_position = ((segment_time - segment_start)*((abs_applied_rate<<10)/ISMD_NORMAL_PLAY_RATE))>>10;
      *stream_position += segment_position;
   } else if(rate < 0 && segment_stop != ISMD_NO_PTS && segment_position != ISMD_NO_PTS &&
         segment_time != ISMD_NO_PTS && applied_rate != 0) {
      *stream_position = segment_position;
      *stream_position -= ((segment_stop - segment_time)*((abs_applied_rate<<10)/ISMD_NORMAL_PLAY_RATE))>>10;
   } else {
      *stream_position = ISMD_NO_PTS;
   }

   return result;
}


ismd_result_t ismd_convert_media_time_to_stream_time(ismd_pts_t  media_time,
                                                     ismd_pts_t  media_base_time,
                                                     ismd_pts_t  local_presentation_base_time,
                                                     ismd_pts_t  local_rate_change_time,
                                                     ismd_pts_t  play_rate_change_time,
                                                     int         rate,
                                                     ismd_pts_t  *unscaled_stream_time,
                                                     ismd_pts_t  *stream_time)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_pts_t stream_rate_change_offset;
   ismd_pts_t scaled_stream_offset;
   int abs_rate = (rate < 0) ? ((-1) * rate) : (rate);

   *unscaled_stream_time = (media_time - media_base_time) + local_presentation_base_time;

   stream_rate_change_offset = *unscaled_stream_time - local_rate_change_time;

   // Scale stream rate change offset, if required
   scaled_stream_offset = stream_rate_change_offset;
   if(abs_rate != ISMD_NORMAL_PLAY_RATE)
   {
      // Division of 64bit pts with rate directly causes kernel error on driver load
      scaled_stream_offset = (stream_rate_change_offset * ((ISMD_NORMAL_PLAY_RATE << 10) / abs_rate)) >> 10;
   }

   *stream_time = scaled_stream_offset + play_rate_change_time;

   //Don't let it roll over to a huge number.
   if(((int64_t)(*stream_time) < 0) || ((int64_t)(*unscaled_stream_time) < 0)){
      *stream_time = 0;
      *unscaled_stream_time = 0;
   }

   return result;
} // ismd_convert_media_time_to_stream_time


ismd_result_t ismd_convert_segment_time_to_linear_time(ismd_pts_t  segment_time,
                                                       ismd_pts_t  segment_start,
                                                       ismd_pts_t  segment_stop,
                                                       int        rate,
                                                       ismd_pts_t  segment_linear_start,
                                                       ismd_pts_t  *linear_time)
{
   ismd_result_t result = ISMD_SUCCESS;

   if(rate < 0)
   {
      *linear_time = (segment_stop - segment_time) + segment_linear_start;
   }
   else
   {
      *linear_time = (segment_time - segment_start) + segment_linear_start;
   }

   //Don't let it roll over to a huge number..
   if((int64_t)(*linear_time) < 0){
      result = ISMD_ERROR_OUT_OF_RANGE;
      *linear_time = 0;
   }

   return result;
} // ismd_convert_media_time_to_stream_time

ismd_result_t ismd_convert_linear_time_to_scaled_time(ismd_pts_t  linear_time,
                                                      ismd_pts_t  linear_rate_change_time,
                                                      ismd_pts_t  scaled_rate_change_time,
                                                      int         rate,
                                                      ismd_pts_t  *scaled_time)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_pts_t stream_rate_change_offset;
   ismd_pts_t scaled_stream_offset;
   int abs_rate = (rate < 0) ? ((-1) * rate) : (rate);

   // Fix HSD2754150
   if(linear_time < linear_rate_change_time) {
      *scaled_time = 0;
      result = ISMD_ERROR_OUT_OF_RANGE;
   return result;
   }

   stream_rate_change_offset = linear_time - linear_rate_change_time;

   // Scale stream rate change offset, if required
   scaled_stream_offset = stream_rate_change_offset;
   if(abs_rate != ISMD_NORMAL_PLAY_RATE)
   {
      // Division of 64bit pts with rate directly causes kernel error on driver load
      scaled_stream_offset = (stream_rate_change_offset * ((ISMD_NORMAL_PLAY_RATE << 10) / abs_rate)) >> 10;
   }

   *scaled_time = scaled_stream_offset + scaled_rate_change_time;

   //Don't let it roll over to a huge number.
   if((int64_t)(*scaled_time) < 0){
      *scaled_time = 0;
      result = ISMD_ERROR_OUT_OF_RANGE;
   }

   return result;
} // ismd_convert_linear_time_to_scaled_time

// Call kmalloc with KMALLOC_MAX_SIZE, if it succeeds return that size and kfree
// if it fails, divide by two and try again until size is (min kmalloc size of 32)
// if size 32 fails return 0
size_t ismd_core_query_largest_available_block(void)
{
   size_t largest_size = 0;

#ifdef __KERNEL__
   void * mem_ptr      = NULL;
   size_t size         = KMALLOC_MAX_SIZE;

   mem_ptr = kmalloc(size, GFP_KERNEL);

   // if the kmalloc didn't work...
   while(mem_ptr == NULL && size >= 32)
   {
      //try a smaller size
      size = size >> 1;

      mem_ptr = kmalloc(size, GFP_KERNEL);
   }

   if(mem_ptr != NULL)
   {
      kfree(mem_ptr);
      largest_size = size;
   }

#else // __KERNEL__ is not defined
   // Note, only kmalloc is guarenteed to return continuous blocks, so if we
   // are compiled for user_space (not likely) just return the PAGE_SIZE.
   largest_size = 4096; //PAGE_SIZE;
#endif //def __KERNEL__

   return largest_size;
}

// called by drivers to indicate critical error (FW not responding, etc...)
void
ismd_signal_critical_error(void) {
   unsigned event_num;
   ismd_event_t event;
   for (event_num = 0; event_num < CRITICAL_ERROR_EVENT_COUNT; event_num++) {
      event = critical_error_events[event_num];
      if (ISMD_EVENT_HANDLE_INVALID != event) {

         /* erase event on failure to prevent repeated errors */
         if (ISMD_SUCCESS != ismd_event_strobe(event)) {
            critical_error_events[event_num] = ISMD_EVENT_HANDLE_INVALID;
         }
      }
   }
}

ismd_result_t
ismd_register_critical_error_event(ismd_event_t event) {
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;
   unsigned event_num;
   bool duplicate = false;
   unsigned first_free_index = CRITICAL_ERROR_EVENT_COUNT;

   /** Do not allow ISMD_EVENT_HANDLE_INVALID */
   if (ISMD_EVENT_HANDLE_INVALID == event) {
      result = ISMD_ERROR_INVALID_PARAMETER;
   }

   /** Scan all event slots - check for duplicate events and a free slot */
   else {
      for (event_num = 0; event_num < CRITICAL_ERROR_EVENT_COUNT; event_num++) {
         if (event == critical_error_events[event_num]) {
            duplicate = true;
            break;
         }
         if ((first_free_index == CRITICAL_ERROR_EVENT_COUNT) &&
             (ISMD_EVENT_HANDLE_INVALID == critical_error_events[event_num])) {
            first_free_index = event_num;
         }
      }
      if (duplicate) {
         result = ISMD_ERROR_INVALID_REQUEST;
      } else if (first_free_index < CRITICAL_ERROR_EVENT_COUNT) {
         result = ISMD_SUCCESS;
         critical_error_events[first_free_index] = event;
      }
   }
   return result;
}

ismd_result_t
ismd_unregister_critical_error_event(ismd_event_t event) {
   unsigned event_num = 0;

   /* erase first match, if there is one */
   for (event_num = 0; event_num < CRITICAL_ERROR_EVENT_COUNT; event_num++) {
      if (critical_error_events[event_num] == event) {
         critical_error_events[event_num] = ISMD_EVENT_HANDLE_INVALID;
         break;
      }
   }
   return ISMD_SUCCESS;
}
