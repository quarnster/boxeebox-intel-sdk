/* 
  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2010-2011  Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2010-2011  Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


/* 
 ismd_clock_wrapper.c implements the SMD Clock Wrapper driver.  The 
 clock wrapper driver has the following functions.

   1. Provide a wrapper for the clock driver to support multiple virtual
      software clocking based on one hardware clock.
   2. Provide a STC clock with is driven by PCR/PTS.
*/

#include "osal.h"
#include "thread_utils.h"
#include "ismd_msg.h"
#include "ismd_global_defs.h"
#include "ismd_core_protected.h"
#include "ismd_core.h"



//#define CLK_DBG_LVL 3

/* Print a message only if the severity level of the message is less than the current debug verbosity level */
#ifdef CLK_DBG_LVL
#define CLK_LOG_MSG(level, format...) do { if( (level) <= CLK_DBG_LVL ) {OS_PRINT(format); }} while(0)
#define CLK_FUNC_ENTER() do { CLK_LOG_MSG(4, "%s: entering function.\n", __FUNCTION__); } while(0)
#define CLK_FUNC_EXIT() do { CLK_LOG_MSG(4, "%s: exiting function.\n", __FUNCTION__); } while(0)
#else
#define CLK_FUNC_ENTER()
#define CLK_FUNC_EXIT()
#define CLK_LOG_MSG(level, format...)
#endif


#define NORMALIZED_CLOCK_RATE 1000000

#define MAX_NUM_WRAPPER_CLOCKS (ISMD_EVENT_LIST_MAX-1)
#define valid_wrapper_clock_dev(clock) (((clock) >= 0) && ((clock) < MAX_NUM_WRAPPER_CLOCKS))

#define valid_wrapper_clock_type(type) ((type) == ISMD_CLOCK_TYPE_WRAPPER)

typedef struct  {
   bool                           free;
   bool                           alarm_set;
   ismd_clock_dev_callback_func_t alarm_callback;
   void                          *alarm_context;
   void                          *scheduled_alarm_context;
   ismd_clock_alarm_t             alarm_handle;
   ismd_event_t                   alarm_event;
   ismd_clock_t                   base_clock;

   ismd_time_t                    base_time; // the clock counter of the base clock when wrapped clock time is set or adjusted
   ismd_time_t                    base_stc;  // the initial (or adjusted) counter of the wrapped clock set by application
   int                            rate; // clock play rate normalized to NORMALIZED_CLOCK_RATE
} wrapper_clock_context_t;


static wrapper_clock_context_t wrapper_clocks[MAX_NUM_WRAPPER_CLOCKS];

static ismd_event_list_t alarm_event_list;
static ismd_clock_dev_t alarm_clock_list[ISMD_EVENT_LIST_MAX]; // only first (ISMD_EVENT_LIST_MAX-1) wrapper clocks support alarm
static int alarm_event_count = 0;
static ismd_event_t alloc_free_event = ISMD_EVENT_HANDLE_INVALID;

static os_thread_t alarm_thread;
static bool alarm_thread_created = false;
static bool alarm_thread_running = false;


/*
 * The clock driver expects that the higher-level software (i.e. the SMD 
 * Core Clock Manager) will provide synchronization for all clock devices.  
 * However, during clock device allocation, the higher-level software does 
 * not know which clock device to synchronize.  Therefore, the clock driver 
 * will protect all allocate and free calls.
 */
static os_mutex_t alloc_free_sema;

static void* wrapper_clock_alarm_thread_func(void *user_data);

static void init_wrapper_clock_dev( ismd_clock_dev_t clock );


ismd_result_t wrapper_clock_alloc( int               type,
                           ismd_clock_dev_t *clock );

ismd_result_t wrapper_clock_free( ismd_clock_dev_t clock );

ismd_result_t wrapper_clock_get_time( ismd_clock_dev_t clock,
                                 ismd_time_t     *time);

ismd_result_t wrapper_clock_set_time( ismd_clock_dev_t clock,
                                ismd_time_t      time );

ismd_result_t wrapper_clock_adjust_time( ismd_clock_dev_t clock,
                                 int64_t      adjustment );

ismd_result_t wrapper_clock_get_last_trigger_time( ismd_clock_dev_t clock,
                                          ismd_time_t     *time);

ismd_result_t wrapper_clock_ack_last_trigger_time( ismd_clock_dev_t clock);


ismd_result_t wrapper_clock_schedule_alarm( ismd_clock_dev_t clock,
                                    void *clock_alarm,
                                       ismd_time_t      time);

ismd_result_t wrapper_clock_cancel_alarm( ismd_clock_dev_t clock );

ismd_result_t wrapper_clock_set_alarm_handler( ismd_clock_dev_t               clock,
                                          ismd_clock_dev_callback_func_t callback);

ismd_result_t wrapper_clock_set_timestamp_trigger_source( ismd_clock_dev_t clock,
                                                  int source );

ismd_result_t wrapper_clock_set_clock_source( ismd_clock_dev_t clock,
                                                  int source );

ismd_result_t wrapper_clock_adjust_frequency( ismd_clock_dev_t clock,
                                         int adjustment );

ismd_result_t wrapper_clock_make_primary( ismd_clock_dev_t clock );

ismd_result_t wrapper_clock_reset_primary( ismd_clock_dev_t clock );

ismd_result_t wrapper_clock_route(ismd_clock_dev_t clock, int destination );

ismd_result_t wrapper_clock_get_last_vsync_time(ismd_clock_dev_t clock, ismd_time_t *time);

ismd_result_t wrapper_clock_set_vsync_pipe( ismd_clock_dev_t clock, int pipe);

ismd_result_t wrapper_clock_trigger_software_event(ismd_clock_dev_t clock);



void wrapper_clock_device_init(void)
{
   ismd_clock_dev_t clock;
   ismd_clock_dev_ops_t clock_ops;
   int event_index;
   ismd_result_t result;

   CLK_FUNC_ENTER();

   os_mutex_init( &alloc_free_sema );

   /* init each clock's context data */
   for ( clock = 0; clock < MAX_NUM_WRAPPER_CLOCKS; clock++ ) {
      init_wrapper_clock_dev( clock );
   }

   clock_ops.allocate                  = wrapper_clock_alloc;
   clock_ops.free                      = wrapper_clock_free;
   clock_ops.get_time                  = wrapper_clock_get_time;
   clock_ops.get_last_vsync_time       = wrapper_clock_get_last_vsync_time;    
   clock_ops.set_time                  = wrapper_clock_set_time;
   clock_ops.adjust_time               = wrapper_clock_adjust_time;
   clock_ops.set_vsync_pipe            = wrapper_clock_set_vsync_pipe;    
   clock_ops.get_last_trigger_time     = wrapper_clock_get_last_trigger_time;
   clock_ops.schedule_alarm            = wrapper_clock_schedule_alarm;
   clock_ops.cancel_alarm              = wrapper_clock_cancel_alarm;
   clock_ops.set_alarm_handler         = wrapper_clock_set_alarm_handler;
   clock_ops.set_source                = wrapper_clock_set_clock_source;
   clock_ops.set_timestamp_trigger_source    = wrapper_clock_set_timestamp_trigger_source;
   clock_ops.adjust_frequency          = wrapper_clock_adjust_frequency;
   clock_ops.make_primary              = wrapper_clock_make_primary;
   clock_ops.reset_primary             = wrapper_clock_reset_primary;
   clock_ops.trigger_software_event    = wrapper_clock_trigger_software_event;
   clock_ops.clock_route               = wrapper_clock_route;

   /* Register the clock driver with the SMD Core. */
   result = ismd_clock_register_clock_type( ISMD_CLOCK_TYPE_WRAPPER, &clock_ops );
   if (result != ISMD_SUCCESS) {
      // Nothing can be done except printing a error message
      OS_PRINT("wrapper_clock_device_init(): register_clock_type %d failed: %d.\n", ISMD_CLOCK_TYPE_WRAPPER, result);
   }

   alarm_event_count = 0;
   alloc_free_event = ISMD_EVENT_HANDLE_INVALID;
   alarm_thread_created = false;
   alarm_thread_running = false;
   for (event_index = 0; event_index <ISMD_EVENT_LIST_MAX; event_index++) {
      alarm_event_list[event_index] = ISMD_EVENT_HANDLE_INVALID;
      alarm_clock_list[event_index] = ISMD_CLOCK_DEV_HANDLE_INVALID;
   }

   CLK_FUNC_EXIT();
   return;
}


void wrapper_clock_device_deinit( void )
{
   ismd_clock_dev_t clock;
   ismd_clock_dev_ops_t clock_ops;
   int event_index;
   ismd_result_t result;

   CLK_FUNC_ENTER();

   clock_ops.allocate                  = NULL;
   clock_ops.free                      = NULL;
   clock_ops.get_time                  = NULL;
   clock_ops.set_time                  = NULL;
   clock_ops.adjust_time               = NULL;
   clock_ops.get_last_trigger_time     = NULL;
   clock_ops.get_last_vsync_time       = NULL;
   clock_ops.set_vsync_pipe            = NULL;
   clock_ops.schedule_alarm            = NULL;
   clock_ops.cancel_alarm              = NULL;
   clock_ops.set_alarm_handler         = NULL;
   clock_ops.set_source                = NULL;
   clock_ops.set_timestamp_trigger_source= NULL;
   clock_ops.adjust_frequency          = NULL;
   clock_ops.make_primary              = NULL;
   clock_ops.reset_primary             = NULL;
   clock_ops.trigger_software_event    = NULL;
   clock_ops.clock_route               = NULL;
   
   /* Un-register the clock driver from the SMD Core. */
   result = ismd_clock_register_clock_type( ISMD_CLOCK_TYPE_WRAPPER, &clock_ops );
   if (result != ISMD_SUCCESS) {
      // Nothing can be done except printing a error message
      OS_PRINT("wrapper_clock_device_init(): register_clock_type %d failed: %d.\n", ISMD_CLOCK_TYPE_WRAPPER, result);
   }

   if (alarm_thread_created) {
      alarm_thread_running = false;
      // wake up alarm thread exit
      if (alloc_free_event != ISMD_EVENT_HANDLE_INVALID) {
         ismd_event_strobe(alloc_free_event);
      }
      os_thread_wait(&alarm_thread, 1);
      os_thread_destroy(&alarm_thread);
      alarm_thread_created = false;

      // free un-freed alarm events
      for ( clock = 0; clock < MAX_NUM_WRAPPER_CLOCKS; clock++ ) {
         if (wrapper_clocks[clock].alarm_event != ISMD_EVENT_HANDLE_INVALID) {
            ismd_event_free(wrapper_clocks[clock].alarm_event);
            wrapper_clocks[clock].alarm_event = ISMD_EVENT_HANDLE_INVALID;
         }
      }
   }
   
   for (event_index = 0; event_index <ISMD_EVENT_LIST_MAX; event_index++) {
      alarm_event_list[event_index] = ISMD_EVENT_HANDLE_INVALID;
      alarm_clock_list[event_index] = ISMD_CLOCK_DEV_HANDLE_INVALID;
   }
   if (alloc_free_event != ISMD_EVENT_HANDLE_INVALID) {
      ismd_event_free(alloc_free_event);
      alloc_free_event = ISMD_EVENT_HANDLE_INVALID;
   }
   alarm_event_count = 0;

   for ( clock = 0; clock < MAX_NUM_WRAPPER_CLOCKS; clock++ ) {
      init_wrapper_clock_dev( clock );
   }

   os_mutex_destroy( &alloc_free_sema );
   CLK_FUNC_EXIT();
   return;

}


ismd_result_t wrapper_clock_alloc( int               type, 
                           ismd_clock_dev_t *clock )
{
   ismd_clock_dev_t temp_clock;
   osal_result osal_ret;
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;

   CLK_FUNC_ENTER();

   if ( !valid_wrapper_clock_type(type) ) {
      OS_PRINT("wrapper_clock_alloc(): invalid clock type %d.\n", type );
      result = ISMD_ERROR_INVALID_PARAMETER;
   }
   else {
      os_mutex_lock( &alloc_free_sema );
      for ( temp_clock = 0; temp_clock < MAX_NUM_WRAPPER_CLOCKS; temp_clock++ ) {
         if ( wrapper_clocks[temp_clock].free ) {
               wrapper_clocks[temp_clock].free = false;

               // Creating the alarm event and thread in the first call to event alloc instead of in
               // the init function can save a event and a thread in case no application uses wrapper clock.

               // Initialize alarm events
               if (alloc_free_event == ISMD_EVENT_HANDLE_INVALID) {
                  result = ismd_event_alloc(&alloc_free_event);
                  if (result != ISMD_SUCCESS) {
                     OS_PRINT(" Unable to create wrapper clock alloc/free event=%d.\n", result);
                  }
                  // the first slot is always for alloc_free_event;
                  alarm_event_list[0] = alloc_free_event;
                  alarm_clock_list[0] = ISMD_CLOCK_DEV_HANDLE_INVALID;
                  alarm_event_count = 1;
               }
               
               // Create alarm event waiting thread
               if (!alarm_thread_created) {
                  alarm_thread_running = true;
                  osal_ret = create_prioritized_thread(&alarm_thread,
                                                       wrapper_clock_alarm_thread_func,
                                                       NULL,
                                                       0,
                                                       "Core_WrapperClock");
                  if (osal_ret != OSAL_SUCCESS) {
                     alarm_thread_running = false;
                     OS_PRINT(" Unable to create wrapper clock alarm thread=%d.\n", osal_ret);
                  } else {
                     alarm_thread_created = true;
                  }
               }
               
               // create alarm event for base clock
               // it is possible that the alram_event is already created
               if (wrapper_clocks[temp_clock].alarm_event == ISMD_EVENT_HANDLE_INVALID) {
                  if (alarm_event_count >= ISMD_EVENT_LIST_MAX) {
                     OS_PRINT("wrapper_clock_alloc: WARNING: exceed max alarm event number. Alarm not supported by this clock instance.\n");
                  } else {
                     result = ismd_event_alloc(&wrapper_clocks[temp_clock].alarm_event);
                     if (result != ISMD_SUCCESS) {
                        OS_PRINT(" Unable to create wrapper clock alarm event=%d.\n", result);
                     } else {
                        alarm_event_count++;
                        
                        // wake up alarm thread to update alarm event list
                        if (alloc_free_event != ISMD_EVENT_HANDLE_INVALID) {
                           ismd_event_strobe(alloc_free_event);
                        }
                     }
                  }
               }
               *clock = temp_clock;
               result = ISMD_SUCCESS;
               break;
         }
      }
      os_mutex_unlock( &alloc_free_sema );
   }
      
   CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_free( ismd_clock_dev_t clock )
{
   ismd_event_t alarm_event;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   os_mutex_lock( &alloc_free_sema );

   alarm_event = wrapper_clocks[clock].alarm_event;
   init_wrapper_clock_dev( clock );
   
   // Don't free the event herer to avoid conficting with event wait.
   // Free it in the alarm_thread.
   if (alarm_event != ISMD_EVENT_HANDLE_INVALID) {
      // store alarm event and free it in alarm_thread
      wrapper_clocks[clock].alarm_event = alarm_event;
      
      // wake up alarm thread to update alarm event list
      if (alloc_free_event != ISMD_EVENT_HANDLE_INVALID) {
         ismd_event_strobe(alloc_free_event);
      }
   }
   result = ISMD_SUCCESS;
   
   os_mutex_unlock( &alloc_free_sema );

   CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_get_time( ismd_clock_dev_t clock, 
                              ismd_time_t     *time)
{
   wrapper_clock_context_t *context;
   ismd_time_t curr_time;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   context = &wrapper_clocks[clock];
   if (context->base_stc != ISMD_NO_PTS && context->base_time != ISMD_NO_PTS &&
       context->base_clock != ISMD_CLOCK_HANDLE_INVALID &&
       ismd_clock_get_time(context->base_clock, &curr_time) == ISMD_SUCCESS) {

      CLK_LOG_MSG(3, "wrapper_clock_get_time: time=%lld, base_time=%lld, base_stc=%lld, rate=%d\n",
         curr_time, context->base_time, context->base_stc, context->rate);
      if (context->rate == NORMALIZED_CLOCK_RATE) {
         *time = context->base_stc + curr_time - context->base_time;
      } else if (context->rate > 0) {
         *time = context->base_stc + OSAL_DIV64((curr_time - context->base_time) * context->rate, NORMALIZED_CLOCK_RATE);
      } else {
         *time = context->base_stc - OSAL_DIV64((curr_time - context->base_time) * (-context->rate), NORMALIZED_CLOCK_RATE);
      }
   } else {
      *time = 0; // always return 0 if not available
   }
   result = ISMD_SUCCESS; // always return success

   CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_set_vsync_pipe( ismd_clock_dev_t clock, 
                              int pipe) 
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
   
   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   result = ismd_clock_set_vsync_pipe(wrapper_clocks[clock].base_clock, pipe);

  CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_get_last_vsync_time( ismd_clock_dev_t clock, 
                              ismd_time_t     *time)
{
   wrapper_clock_context_t *context;
   ismd_time_t curr_time;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   context = &wrapper_clocks[clock];
   if (context->base_stc != ISMD_NO_PTS && context->base_time != ISMD_NO_PTS &&
       context->base_clock != ISMD_CLOCK_HANDLE_INVALID &&
       ismd_clock_get_last_vsync_time(context->base_clock, &curr_time) == ISMD_SUCCESS) {

      CLK_LOG_MSG(3, "wrapper_clock_get_last_vsync_time: base clock vsyn time=%lld, base_time=%lld, base_stc=%lld, rate=%d\n",
         curr_time, context->base_time, context->base_stc, context->rate);
      if (context->rate == NORMALIZED_CLOCK_RATE) {
         *time = context->base_stc + curr_time - context->base_time;
      } else if (context->rate > 0) {
         *time = context->base_stc + OSAL_DIV64((curr_time - context->base_time) * context->rate, NORMALIZED_CLOCK_RATE);
      } else {
         *time = context->base_stc - OSAL_DIV64((curr_time - context->base_time) * (-context->rate), NORMALIZED_CLOCK_RATE);
      }
   } else {
      *time = 0; // always return 0 if not available
   }
   
   result = ISMD_SUCCESS; 

   CLK_FUNC_EXIT();

   return ( result );
}

ismd_result_t wrapper_clock_trigger_software_event( ismd_clock_dev_t clock)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   result = ismd_clock_trigger_software_event(wrapper_clocks[clock].base_clock);

   CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_get_last_trigger_time( ismd_clock_dev_t clock, 
                              ismd_time_t     *time)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   result = ismd_clock_get_last_trigger_time(wrapper_clocks[clock].base_clock, time);

   CLK_FUNC_EXIT();

   return ( result );
}



ismd_result_t wrapper_clock_set_time( ismd_clock_dev_t clock, 
                              ismd_time_t      time ) 
{
   wrapper_clock_context_t *context;
   ismd_time_t curr_time;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();


   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   context = &wrapper_clocks[clock];
   if (context->base_clock != ISMD_CLOCK_HANDLE_INVALID && 
       ismd_clock_get_time(context->base_clock, &curr_time) == ISMD_SUCCESS) {

      context->base_stc = time;
      context->base_time = curr_time;
   }
   result = ISMD_SUCCESS; // always return success

   CLK_FUNC_EXIT();

   return ( result );
}

ismd_result_t wrapper_clock_adjust_time( ismd_clock_dev_t clock, 
                                 int64_t      adjustment ) 
{
   wrapper_clock_context_t *context;
   ismd_time_t curr_time;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   context = &wrapper_clocks[clock];
   if (context->base_stc != ISMD_NO_PTS && context->base_time != ISMD_NO_PTS &&
       context->base_clock != ISMD_CLOCK_HANDLE_INVALID &&
       ismd_clock_get_time(context->base_clock, &curr_time) == ISMD_SUCCESS) {

      context->base_stc += adjustment;
      context->base_time = curr_time;
   }
   result = ISMD_SUCCESS; // always return success

   CLK_FUNC_EXIT();

   return ( result );
}

ismd_result_t wrapper_clock_schedule_alarm( ismd_clock_dev_t clock,
                                    void *clock_alarm,
                                    ismd_time_t      time ) 
{
   wrapper_clock_context_t *context;
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   context = &wrapper_clocks[clock];
   CLK_LOG_MSG(3, "wrapper_clock_schedule_alarm: alarm_set=%d, alarm_thread_created=%d, alarm_event=%d, ", context->alarm_set, alarm_thread_created, context->alarm_event);
   CLK_LOG_MSG(3, "time=%lld, base_time=%lld, base_stc=%lld, rate=%d\n", time, context->base_time, context->base_stc, context->rate);
   if ( !context->alarm_set ) {
      context->alarm_set = true;
      context->scheduled_alarm_context = clock_alarm;

      if (alarm_thread_created && context->alarm_event != ISMD_EVENT_HANDLE_INVALID && context->rate != 0) {
         // map time to base clock time domain and set alarm
         if (context->rate == NORMALIZED_CLOCK_RATE) {
            time = context->base_time + time - context->base_stc;
         } else if (context->rate > 0) {
            time = context->base_time + OSAL_DIV64((time - context->base_stc) * NORMALIZED_CLOCK_RATE, context->rate);
         } else {
            time = context->base_time - OSAL_DIV64((time - context->base_stc) * NORMALIZED_CLOCK_RATE, (-context->rate));
         }
         CLK_LOG_MSG(3, "wrapper_clock_schedule_alarm: virtual time=%lld, clock_alarm=%p\n", time, clock_alarm);
         result = ismd_clock_alarm_schedule(context->base_clock, time, 0, context->alarm_event, &context->alarm_handle);
      }
   }

   CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_cancel_alarm( ismd_clock_dev_t clock )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   if ( wrapper_clocks[clock].alarm_set ) {
      result = ismd_clock_alarm_cancel(wrapper_clocks[clock].base_clock, wrapper_clocks[clock].alarm_handle);
      wrapper_clocks[clock].alarm_set = false;
   } else {
      result = ISMD_SUCCESS;
   }

   CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_set_alarm_handler( ismd_clock_dev_t               clock,
                                           ismd_clock_dev_callback_func_t callback)
{
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );
   OS_ASSERT( callback != NULL );

   if ( !wrapper_clocks[clock].alarm_set ) {
      wrapper_clocks[clock].alarm_callback = callback;
      result = ISMD_SUCCESS;
   }

   CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_set_clock_source( ismd_clock_dev_t clock, 
                                int              source )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   wrapper_clocks[clock].base_clock = (ismd_clock_t)source;
   result = ISMD_SUCCESS;

   CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_set_timestamp_trigger_source( ismd_clock_dev_t clock, 
                                                int source )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   result = ismd_clock_set_timestamp_trigger_source(wrapper_clocks[clock].base_clock, source);

   CLK_FUNC_EXIT();

   return ( result );
}

ismd_result_t wrapper_clock_adjust_frequency( ismd_clock_dev_t clock,
                                      int adjustment)
{
   wrapper_clock_context_t *context;
   ismd_time_t curr_time;
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   context = &wrapper_clocks[clock];
   if (context->base_stc != ISMD_NO_PTS && context->base_time != ISMD_NO_PTS &&
       context->base_clock != ISMD_CLOCK_HANDLE_INVALID &&
       ismd_clock_get_time(context->base_clock, &curr_time) == ISMD_SUCCESS) {

      CLK_LOG_MSG(3, "wrapper_clock_adjust_frequency: time=%lld, base_time=%lld, base_stc=%lld, rate=%d\n",
         curr_time, context->base_time, context->base_stc, context->rate);
      if (context->rate == NORMALIZED_CLOCK_RATE) {
         context->base_stc += (curr_time - context->base_time);
      } else if (context->rate > 0) {
         context->base_stc += OSAL_DIV64((curr_time - context->base_time) * context->rate, NORMALIZED_CLOCK_RATE);
      } else {
         context->base_stc -= OSAL_DIV64((curr_time - context->base_time) * (-context->rate), NORMALIZED_CLOCK_RATE);
      }
      context->rate += adjustment;
      context->base_time = curr_time;
   }
   result = ISMD_SUCCESS; // always return success
   
   CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_route( ismd_clock_dev_t clock , int destination)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   result = ismd_clock_route(wrapper_clocks[clock].base_clock, destination);

   CLK_FUNC_EXIT();

   return ( result );
}


ismd_result_t wrapper_clock_make_primary( ismd_clock_dev_t clock )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   result = ismd_clock_make_primary(wrapper_clocks[clock].base_clock);

   CLK_FUNC_EXIT();

   return ( result );
}



ismd_result_t wrapper_clock_reset_primary( ismd_clock_dev_t clock )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;

   CLK_FUNC_ENTER();

   OS_ASSERT( valid_wrapper_clock_dev(clock) );
   OS_ASSERT( wrapper_clocks[clock].free == false );

   result = ismd_clock_reset_primary(wrapper_clocks[clock].base_clock);

   CLK_FUNC_EXIT();

   return ( result );
}

static void* wrapper_clock_alarm_thread_func( void *user_data)
{
   ismd_clock_dev_t clock;
   wrapper_clock_context_t *context;
   int event_index;
   ismd_event_t triggered_event = ISMD_EVENT_HANDLE_INVALID;
   ismd_result_t result = ISMD_SUCCESS;

   CLK_FUNC_ENTER();
   
   (void)user_data;

   // wait for the event notification from the alarm of base clock
   while (alarm_thread_running) {
      CLK_LOG_MSG(3, "ismd_event_wait_multiple: %d\n", alarm_event_count);
      result = ismd_event_wait_multiple(alarm_event_list, alarm_event_count, ISMD_TIMEOUT_NONE, &triggered_event);
      if (result != ISMD_SUCCESS) {
         OS_PRINT("wrapper_clock_alarm_thread_func: wait for alarm event failed %d\n", result);
         if (result != ISMD_ERROR_TIMEOUT && result != ISMD_ERROR_NOT_DONE) {
            OS_PRINT("wrapper_clock_alarm_thread_func: FAILURE: thread exited.\n");
            // Real error, need to shut down
            break;
         }
      } else {
         if (triggered_event == alarm_event_list[0]) {
            // update alarm event list
            os_mutex_lock( &alloc_free_sema );
            for ( event_index = 1, clock  = 0; event_index < ISMD_EVENT_LIST_MAX && clock < MAX_NUM_WRAPPER_CLOCKS; clock++ ) {
               if (wrapper_clocks[clock].alarm_event != ISMD_EVENT_HANDLE_INVALID) {
                  if ( wrapper_clocks[clock].free) {
                     // free the event of a freed clock. The event may not be freed when freeing a clock to avoid conficting with event wait.
                     CLK_LOG_MSG(3, "wrapper_clock_alarm_thread_func: delayed free event: %d\n", wrapper_clocks[clock].alarm_event);
                     ismd_event_free(wrapper_clocks[clock].alarm_event);
                     wrapper_clocks[clock].alarm_event = ISMD_EVENT_HANDLE_INVALID;
                     alarm_event_count--;
                  } else {
                     alarm_event_list[event_index] = wrapper_clocks[clock].alarm_event;
                     alarm_clock_list[event_index] = clock;
                     event_index++;
                  }
               }
            }
            OS_ASSERT(alarm_event_count == event_index);
            os_mutex_unlock( &alloc_free_sema );
         } else {
            // base clock triggered alarm event, so call alarm callback
            for (event_index = 1; event_index < alarm_event_count; event_index++) {
               if (triggered_event == alarm_event_list[event_index] && alarm_clock_list[event_index] < MAX_NUM_WRAPPER_CLOCKS) {
                  context = &wrapper_clocks[alarm_clock_list[event_index]];

                  // call alarm callback
                  if ( context->alarm_callback != NULL && context->alarm_set && !context->free ) {
                     context->alarm_set = false;
                     context->alarm_callback( context->scheduled_alarm_context );
                  }
                  break;
               }
            }
         }

         ismd_event_acknowledge(triggered_event);
      }
   }

   CLK_FUNC_EXIT();

   return NULL;
}

static void init_wrapper_clock_dev( ismd_clock_dev_t clock )
{
   wrapper_clocks[clock].free            = true;
   wrapper_clocks[clock].alarm_set       = false;
   wrapper_clocks[clock].alarm_callback  = NULL;
   wrapper_clocks[clock].alarm_context   = NULL;
   wrapper_clocks[clock].scheduled_alarm_context   = NULL;
   wrapper_clocks[clock].alarm_handle    = ISMD_CLOCK_ALARM_HANDLE_INVALID;
   wrapper_clocks[clock].alarm_event     = ISMD_EVENT_HANDLE_INVALID;
   wrapper_clocks[clock].base_clock      = ISMD_CLOCK_HANDLE_INVALID;
   wrapper_clocks[clock].base_time       = ISMD_NO_PTS;
   wrapper_clocks[clock].base_stc        = ISMD_NO_PTS;
   wrapper_clocks[clock].rate            = NORMALIZED_CLOCK_RATE; // 1X speed

   return;
}
