/* Perfect hash definitions */
#ifndef PHASH_DEFS
#include "phash_defs.h"
#endif /* PHASH_DEFS */
#ifndef PHASH
#define PHASH

extern ub2 tab[];
#define PHASHLEN 0x100  /* length of hash mapping table */
#define PHASHNKEYS 716  /* How many keys were hashed */
#define PHASHRANGE 1024  /* Range any input might map to */
#define PHASHSALT 0x4c5c8c9f /* internal, initialize normal hash */

ub4 phash( ub4 );

#endif  /* PHASH */

