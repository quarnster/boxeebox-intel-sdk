/*  

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

//TODO 1. Deal with the case where user may freed an event without unmask, 
//     but we are still strobe here. Event manager should detect this situation 
//     if this event not re-allocated by other client

#include "osal.h"
#include "ismd_global_defs.h"
#include "smd_core_local_defs.h"
#include "ismd_core.h"
#include "ismd_msg.h"


#ifndef MESSAGE_MANAGER_LOG_MSG
#define MESSAGE_MANAGER_LOG_MSG ISMD_LOG_MSG
#endif

#define MESSAGE_MASK_MAX         ((1<<ISMD_MESSAGE_TYPE_MAX)-1)
#define SUBSCRIBER_NODE_NUM      (ISMD_MESSAGE_CONTEXT_MAX*ISMD_MESSAGE_TYPE_MAX*ISMD_MESSAGE_MAX_SUBSCRIBERS_PER_MESSAGE)

typedef struct
{
   int used;                    /*whether this node is used*/
   ismd_event_t event;          /* subscriber's event handle, which will be strobed when message ready */
   os_list_head_t node;         /* list node used to link this subscriber to a subscriber's list */
} subscriber_node_t;

typedef struct
{
   uint32_t count;              /*how many times this message has occured */
   uint64_t data;               /*currently, only 8 bytes message specific data supported */
   /*
    * translation of the data depends on specific message type
    */
   os_list_head_t subscribers;  /*a list for subscribers */
} message_node_t;

typedef struct
{
   int used;
   os_lock_t lock;              /*sychronization lock used for this message context */
   message_node_t messages[ISMD_MESSAGE_TYPE_MAX];
} message_context_t;

message_context_t message_contexts[ISMD_MESSAGE_CONTEXT_MAX];

subscriber_node_t subscriber_nodes[SUBSCRIBER_NODE_NUM];
//lock used to protect subscriber_nodes array.
os_lock_t subscriber_nodes_lock;

static subscriber_node_t *
get_subscriber_node(void)
{
   subscriber_node_t *subscriber_node = NULL;
   int i;

   os_lock(subscriber_nodes_lock);
   for(i=0; i<SUBSCRIBER_NODE_NUM; i++) {
      if(!subscriber_nodes[i].used) {
         subscriber_nodes[i].used = 1;
         subscriber_node = &subscriber_nodes[i];
         OS_INIT_LIST_HEAD((&subscriber_node->node));
         break;
      }
   }
   os_unlock(subscriber_nodes_lock);

   return subscriber_node;
}

static void 
put_subscriber_node(subscriber_node_t *subscriber_node)
{
   //need not a lock
   subscriber_node->used = 0;
}

static inline void 
validate_pointer (volatile int *ptr)
{
   *ptr;
}

static void 
message_unsubscribe (message_context_t * context, ismd_event_t event)
{
   int i;
   os_list_head_t *pos = NULL, *n = NULL;
   subscriber_node_t *subscriber;

   os_lock (context->lock);
   for (i = 0; i < ISMD_MESSAGE_TYPE_MAX; i++) {
      OS_LIST_FOR_EACH_SAFE (pos, n, &context->messages[i].subscribers) {
         subscriber = OS_LIST_ENTRY (pos, subscriber_node_t, node);
         if (subscriber->event == event) {
            OS_LIST_DEL (pos);
            put_subscriber_node(subscriber);
            MESSAGE_MANAGER_LOG_MSG (4,
                                     "%s() :unsubscribe event %d from context: %d, type: %d,  \n",
                                     __func__, event, (int) context, i);
            /*
             * Should not break here. Although we do not recommend 
             * * subscribe same event several times to one context, 
             * * there is no constraint on this.
             */
            //break;
         }
      }
   }
   os_unlock (context->lock);
}

static ismd_result_t 
message_subscribe (message_context_t * context, ismd_event_t event, uint32_t mask)
{
   int i;
   subscriber_node_t *subscriber;
   ismd_result_t result = ISMD_SUCCESS;

   os_lock (context->lock);
   for (i = 0; i < ISMD_MESSAGE_TYPE_MAX; i++) {
      if (mask & (1 << i)) {
         subscriber = get_subscriber_node();
         if(!subscriber) {
            result = ISMD_ERROR_NO_RESOURCES;
            break;
         }
         subscriber->event = event;
         OS_LIST_ADD_TAIL (&subscriber->node, &context->messages[i].subscribers);
      }
   }
   os_unlock (context->lock);
   return result;
}

static void 
context_init (message_context_t * context)
{
   int j;
   message_node_t *message;

   for (j = 0; j < ISMD_MESSAGE_TYPE_MAX; j++) {
      message = &context->messages[j];
      message->count = 0;
      OS_INIT_LIST_HEAD ((&message->subscribers));
   }
}


ismd_result_t 
ismd_message_context_free (ismd_message_context_t context_id)
{
   ismd_result_t result = ISMD_SUCCESS;
   message_node_t *message;
   os_list_head_t *pos = NULL, *n = NULL;
   subscriber_node_t *subscriber;
   message_context_t *context;
   int j;

   if (context_id >= ISMD_MESSAGE_CONTEXT_MAX)
      return ISMD_ERROR_INVALID_PARAMETER;

   context = &message_contexts[context_id];

   if (!context->used)
      return ISMD_ERROR_INVALID_PARAMETER;

   os_lock (context->lock);
   for (j = 0; j < ISMD_MESSAGE_TYPE_MAX; j++) {
      message = &context->messages[j];
      OS_LIST_FOR_EACH_SAFE (pos, n, &message->subscribers) {
         subscriber = OS_LIST_ENTRY (pos, subscriber_node_t, node);
         OS_LIST_DEL (pos);
         put_subscriber_node(subscriber);
      }
   }
   context->used = 0;
   os_unlock (context->lock);

   return result;
}


/* 
 * Initialize the Message Manager and allocated all resources required 
 * by the message manager.  Must be called before any other message 
 * Manager functions are called or the results of those function calls 
 * will be unpredictable.
 */
ismd_result_t 
ismd_message_manager_init (void)
{
   int i;
   ismd_result_t result = ISMD_SUCCESS;

   for (i = 0; i < ISMD_MESSAGE_CONTEXT_MAX; i++) {
      message_contexts[i].used = 0;
      /*
       * This lock need to be created on initialization.
       * *For it is also used to protect the alloc/free
       * *of context. Do not destroy it on context free.
       */
      message_contexts[i].lock = os_create_lock ();
   }

   subscriber_nodes_lock = os_create_lock();
   for (i = 0; i < SUBSCRIBER_NODE_NUM; i++) {
      subscriber_nodes[i].used = 0;
   }

   return result;
}

 /*
  * Deinitialize the Message Manager and free all resources required 
  * by the message manager.  No message Manager functions may be called after this call
  * or the results of those function calls will be unpredictable.
  */
ismd_result_t 
ismd_message_manager_deinit (void)
{
   int i;

   for (i = 0; i < ISMD_MESSAGE_CONTEXT_MAX; i++) {
      if (message_contexts[i].used) {
         ismd_message_context_free (i);
         os_destroy_lock (message_contexts[i].lock);
      }
   }
   os_destroy_lock(subscriber_nodes_lock);
   return ISMD_SUCCESS;
}

ismd_result_t 
ismd_message_context_alloc (ismd_message_context_t * context_id)
{
   int i;
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;
   message_context_t *context = NULL;

   validate_pointer ((int *) context_id);

   for (i = 0; i < ISMD_MESSAGE_CONTEXT_MAX; i++) {
      os_lock (message_contexts[i].lock);
      if (message_contexts[i].used == 0) {
         context = &message_contexts[i];
         context_init (context);
         context->used = 1;
         result = ISMD_SUCCESS;
         os_unlock (message_contexts[i].lock);
         break;
      }
      os_unlock (message_contexts[i].lock);
   }

   *context_id = i;
   return result;
}

ismd_result_t
ismd_message_write (ismd_message_context_t context_id, uint32_t type, uint32_t count, uint64_t data)
{
   message_node_t *message;
   os_list_head_t *pos = NULL;
   subscriber_node_t *subscriber;
   message_context_t *context;
   ismd_result_t result;

   if (context_id >= ISMD_MESSAGE_CONTEXT_MAX || type >= ISMD_MESSAGE_TYPE_MAX || count == 0)
      return ISMD_ERROR_INVALID_PARAMETER;

   context = &message_contexts[context_id];

   if (!context->used)
      return ISMD_ERROR_INVALID_PARAMETER;

   message = &context->messages[type];

   os_lock (context->lock);
   message->count += count;
   //only the most recent message data are remembered.
   message->data = data;
   //wake up listeners(if there are)
   OS_LIST_FOR_EACH (pos, &message->subscribers) {
      subscriber = OS_LIST_ENTRY (pos, subscriber_node_t, node);
      result = ismd_event_strobe (subscriber->event);
      OS_ASSERT (ISMD_SUCCESS == result);
      MESSAGE_MANAGER_LOG_MSG (4, "%s() :context: %u, type: %u,  strobe event %d.\n", __func__,
                               context_id, type, subscriber->event);
   }
   os_unlock (context->lock);

   return ISMD_SUCCESS;
}

ismd_result_t
ismd_message_set_mask (ismd_message_context_t context_id, ismd_event_t event, uint32_t mask)
{
   message_context_t *context;
   ismd_result_t result = ISMD_SUCCESS;

   if (context_id >= ISMD_MESSAGE_CONTEXT_MAX || ((mask & ~MESSAGE_MASK_MAX) != 0))
      return ISMD_ERROR_INVALID_PARAMETER;

   context = &message_contexts[context_id];

   if (!context->used)
      return ISMD_ERROR_INVALID_PARAMETER;

   if (mask) {
      result = message_subscribe (context, event, mask);
      /* On subscribe failure, this event may have been partially subscribed
       * to some message types. Unsubscribe those case to make the subscribe
       * operation totally failure to keep resource integrity. From application
       * perspective, when this function(ismd_message_set_mask) returned with
       * ISMD_ERROR_NO_RESOURCE, the true effect is as if this function has never
       * been called.
       */
      if(result == ISMD_ERROR_NO_RESOURCES) {
         message_unsubscribe(context, event);
      }
   } else {
      message_unsubscribe (context, event);
   }
   return result;
}

//Judge whether an event has been subscribed to a message
//Note! This function will not lock the message's subscriber list
//Assume caller to hold this lock before calling this.
static bool 
event_is_subscriber_of_message(message_node_t *message_node, ismd_event_t event)
{
   os_list_head_t *pos = NULL;
   subscriber_node_t *subscriber;

   OS_LIST_FOR_EACH(pos, &message_node->subscribers) {
      subscriber = OS_LIST_ENTRY (pos, subscriber_node_t, node);
      if(subscriber->event == event)
         return true;
   }
   return false;
}

ismd_result_t
ismd_message_read (ismd_message_context_t context_id,ismd_event_t event, int reset_flag,
                   ismd_message_array_t * message)
{
   unsigned int i, item_read = 0;
   message_node_t *message_node;
   message_context_t *context;

   validate_pointer ((int *) message);
   if (context_id >= ISMD_MESSAGE_CONTEXT_MAX)
      return ISMD_ERROR_INVALID_PARAMETER;

   context = &message_contexts[context_id];

   if (!context->used)
      return ISMD_ERROR_INVALID_PARAMETER;

   os_lock (context->lock);
   for (i = 0; i < ISMD_MESSAGE_TYPE_MAX; i++) {
      /*
       * Auto api can only support a fixed size array as parameter,
       * * so user message info can not be variable size. Comment out
       * * the following 2 lines if auto api enhanced to support nicer
       * * interface
       */
#if 0
      if (item_read >= message->num_of_items)
         break;
#endif

      //Would like to return only messages client caring about.
      message_node = &context->messages[i];
      if(event != ISMD_EVENT_HANDLE_INVALID && !event_is_subscriber_of_message(message_node, event))
         continue;

      /*
       * If one message is consumed (read with reset flag as 1), other clients 
       * * can not get the message data.
       */
      if (message_node->count != 0) {
         message->info[item_read].type = i;
         message->info[item_read].count = message_node->count;
         message->info[item_read].data = message_node->data;
         item_read++;
         if (reset_flag) {
            message_node->count = 0;
         }
      }
   }
   os_unlock (context->lock);
   message->num_of_items = item_read;

   return ISMD_SUCCESS;
}
