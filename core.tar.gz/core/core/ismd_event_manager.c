/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "osal.h"
#include "ismd_global_defs.h"
#include "smd_core_local_defs.h"
#include "ismd_core.h"
#include "ismd_msg.h"

#ifndef EVENT_MANAGER_TRACE
   #define EVENT_MANGER_TRACE(event, name, action, result)
#endif

#ifndef EVENT_MANAGER_LOG_MSG
   //#define EVENT_MANAGER_LOG_MSG(level, format...)
   #define EVENT_MANAGER_LOG_MSG ISMD_LOG_MSG
#endif


/*
 * TODO:  What is a reasonable number of events to support?
 */
#define ISMD_MAX_EVENTS 256


typedef enum {
   ISMD_EVENT_STATE_INVALID      = 0, /* For catching bugs, don't use. */
   ISMD_EVENT_STATE_FREE         = 1, /* Not currently in-use */
   ISMD_EVENT_STATE_IN_USE       = 2, /* Currently in-use and active */
   ISMD_EVENT_STATE_DELAYED_FREE = 3  /* Currently in-use, but in the process of being freed */
} ismd_event_status_t;


/*
 * wait_context_t is used to support ismd_event_wait_multiple().  Each
 * event_context contains a wait_context, but each event may actually use the
 * wait_context of another event.  This effectively links events together so
 * that one thread can wait on many events at the same time.
 */
typedef struct {
   bool       waiting;      /* Is there currently a thread waiting on the event? */
   os_event_t wait_event;   /* OSAL event that is the basis for SMD events. */
} wait_context_t;


#define DEFAULT_EVENT_NAME "un-named event          "

/* TODO:  move to ismd_core.h */
typedef char ismd_event_name_t[24];


typedef struct event_context_s {
   struct event_context_s *next;         /* for creating lists of contexts. */
   ismd_event_t            handle;       /* The current handle for this context. */
   os_mutex_t               lock;         /* synchronization lock for this context. */
   ismd_event_name_t       name;         /* human-readable name for the event, for debug */
   ismd_event_status_t     status;       /* The event context is currently status or free, or shutting down */
   bool                    triggered;    /* The state of the event source. */
   int                     latch;        /* The state of the event notifier. Always > 1 if the event is triggered. */
   wait_context_t          wait_context; /* The status of the waiting thread and the supporting OSAL event */
   wait_context_t         *wait_ptr;     /* Pointer to the actual wait_context for the event.  For ismd_event_wait,
                                          * this points to wait_context above, but for ismd_event_wait_multipe,
                                          * this may point to the wait_context of another event.
                                          */
} event_context_t;

/* Structure for the list of free event contexts. */
typedef struct context_list_s {
   event_context_t *head;
   event_context_t *tail;
   os_mutex_t lock;
} context_list_t;


event_context_t events[ISMD_MAX_EVENTS];

/*
 * List of the unallocated event contexts.  The list is used in
 * ismd_event_alloc and ismd_event_free.  It makes the process
 * of allocating an event an "order 1" algorithm.
 */
static context_list_t event_free_list;


static event_context_t *lookup_event( ismd_event_t handle );
static event_context_t *lookup_and_lock_event( ismd_event_t handle );
static void event_init( event_context_t  *event_context );
static void event_deinit( event_context_t *event_context );
static void event_lock( event_context_t *event_context );
static void event_unlock( event_context_t *event_context );
static bool event_is_in_use( event_context_t *event_context );
static bool valid_event_handle( ismd_event_t event_handle );
static ismd_result_t event_wait( event_context_t *event_context,
                                 unsigned int     timeout );
static ismd_result_t link_events( ismd_event_list_t *events,
                                  int                num_events,
                                  event_context_t  **primary_event_context,
                                  ismd_event_t      *triggerd_event );
static ismd_result_t unlink_events( ismd_event_list_t *events,
                                    int                num_events,
                                    ismd_event_t      *triggerd_event );
static bool event_wakeup( event_context_t *event_context );
static bool thread_is_already_waiting( event_context_t *event_context,
                                              event_context_t *primary_event_context );
static void list_init( context_list_t *list );
static event_context_t *list_remove( context_list_t *list );
static void event_list_add( context_list_t  *list,
                      event_context_t *context );
static void list_deinit( context_list_t *list );



/***************************************************************
 *  SMD Core Private Functions:
 *
 *  The following function may be called only by the SMD Core.
 ***************************************************************/


/*
 * Initialize the Event Manager and allocated all resources required
 * by the event manager.  Must be called before any other Event
 * Manager functions are called or the results of those function calls
 * will be unpredictable.
 */
ismd_result_t
ismd_event_manager_init(void)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_event_t event_handle;
   event_context_t *event_context;
   int osal_result;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   list_init(&event_free_list);

   for ( event_handle = 0; event_handle < ISMD_MAX_EVENTS; event_handle++ ) {

      event_context = lookup_event( event_handle );

      osal_result = os_mutex_init( &(event_context->lock) );
      OS_ASSERT( osal_result == OSAL_SUCCESS );

      event_context->handle = event_handle;
      event_context->status = ISMD_EVENT_STATE_FREE;
      event_list_add( &event_free_list, event_context );
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return (result);
}


/*
 * Deinitialized the Event Manager and free all resources associated
 * with the Event Manager.  No Event Manager functions may be called
 * after calling this function or the results of those functions will
 * be unpredictable.
 */
ismd_result_t
ismd_event_manager_deinit(void)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_event_t event_handle;
   event_context_t *event_context;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   for ( event_handle = 0; event_handle < ISMD_MAX_EVENTS; event_handle++ ) {
      event_context = lookup_event( event_handle );
      os_mutex_destroy( &(event_context->lock) );
   }

   list_deinit( &event_free_list );

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return (result);
}


bool
valid_smd_event(ismd_event_t event)
{
   bool result = false;

   if ( lookup_event(event) != NULL ) {
      result = true;
   }

   return ( result );
}


bool
active_smd_event(ismd_event_t event)
{
   bool result = false;
   event_context_t *event_context;

   event_context = lookup_and_lock_event( event );
   if ( event_context != NULL ) {
      result = true;
      event_unlock( event_context );
   }

   return ( result );
}


/***************************************************************
 *  SMD Public Functions:
 *
 *  The following function may be called by any application or
 *  SMD module.
 ***************************************************************/

/*
 * TODO:  Track all events allocated from user space and free them
 * when a user-space connection is broken.
 */
ismd_result_t
ismd_event_alloc(ismd_event_t *event)
{
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;
   ismd_event_t event_handle = ISMD_EVENT_HANDLE_INVALID;
   event_context_t *event_context;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   if ( 0 == (void *)event ) {
      OS_INFO("error:%s:%s:%d: event address =0\n", __FILE__, __func__, __LINE__);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else {
      /* Get an unallocated context from the free list. */
      event_context = list_remove( &event_free_list );

      if ( event_context != NULL ) {
         event_lock( event_context );

         OS_ASSERT( event_context->status == ISMD_EVENT_STATE_FREE );

         event_init( event_context );
         event_handle = event_context->handle;
         *event = event_handle;
         result = ISMD_SUCCESS;
         EVENT_MANGER_TRACE(event_handle, event_context->name, ISMD_CORE_TRACE_EVENT_ALLOC, result);
         EVENT_MANAGER_LOG_MSG(3, "%s() : allocated event %d.\n", __func__, event_handle );
         event_unlock( event_context );
      }
      else {
         EVENT_MANAGER_LOG_MSG(3, "%s() : out of resources.\n", __func__);
      }
   }
   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return ( result );
}

ismd_result_t
ismd_event_free(ismd_event_t event)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   event_context_t *event_context;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   event_context = lookup_and_lock_event( event );
   if ( event_context != NULL ) {

      /*
       * Attempt to wake up any thread currently waiting on the event.  If no
       * thread was waiting, we can initialze and free the event right now.
       */
      if ( !event_wakeup(event_context) ) {
         event_deinit( event_context );
         event_list_add( &event_free_list, event_context );
         EVENT_MANAGER_LOG_MSG(4, "%s(): freed event %d.\n", __func__, event );
      }

      /*
       * Otherwise, we need to perform a "delayed free" operation which
       * will free the event after the thread waiting on it wakes up.
       */
      else {
         event_context->status = ISMD_EVENT_STATE_DELAYED_FREE;
         EVENT_MANAGER_LOG_MSG(4, "%s(): delayed free of event %d.\n", __func__, event );
      }

      result = ISMD_SUCCESS;

      EVENT_MANGER_TRACE(event, event_context->name, ISMD_CORE_TRACE_EVENT_FREE, result);

      event_unlock( event_context );
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return ( result );
}


ismd_result_t
ismd_event_wait(ismd_event_t event,
                unsigned int timeout)
{
   ismd_result_t result;
   ismd_event_list_t list;
   ismd_event_t local_event;
   list[0] = event;
   result = ismd_event_wait_multiple( list, 1, timeout, &local_event );
   return ( result );
}


ismd_result_t
ismd_event_wait_multiple(ismd_event_t       event_list[ISMD_EVENT_LIST_MAX],
                         int                num_events,
                         unsigned int       timeout,
                         ismd_event_t      *triggered_event)
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_result_t unlink_result;
   event_context_t *primary_event_context = NULL;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   if ( (num_events < 1) || (num_events > ISMD_EVENT_LIST_MAX) ) {
      result = ISMD_ERROR_INVALID_PARAMETER;
   }
   else {
      /* Link all of the events together so we can wait on them as a single event. */
      result = link_events( (ismd_event_list_t *)event_list, num_events, &primary_event_context, triggered_event );

      /* If the link-up was successful... */
      if ( result == ISMD_ERROR_ALREADY_INITIALIZED ) {
         result = ISMD_SUCCESS;
      }
      else if ( result == ISMD_SUCCESS ) {
         /* Wait for the event to occur. */
         if (primary_event_context != NULL) {
            result = event_wait( primary_event_context, timeout );
         }
         else {
            OS_ASSERT(false);
         }

         /* Now, unlink the events again. */
         unlink_result = unlink_events( (ismd_event_list_t *)event_list, num_events, triggered_event );

         /* If unlink was not successful...  */
         if ( unlink_result != ISMD_SUCCESS ) {
            /* return the result of the unlink. */
            result = unlink_result;
         }
      }

      if ( result == ISMD_SUCCESS ) {
         EVENT_MANGER_TRACE(*triggered_event, events[*triggered_event].name, ISMD_CORE_TRACE_EVENT_WAKEUP, result);
      }
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return ( result );
}


ismd_result_t
ismd_event_set(ismd_event_t event)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   event_context_t *event_context;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   event_context = lookup_and_lock_event( event );
   if ( event_context != NULL ) {
      event_context->triggered = true;
      event_context->latch = 1;
      event_wakeup( event_context );
      result = ISMD_SUCCESS;
      EVENT_MANGER_TRACE(event, event_context->name, ISMD_CORE_TRACE_EVENT_SET, result);
      EVENT_MANAGER_LOG_MSG(4, "%s(): set event %d.\n", __func__, event );
      event_unlock( event_context );
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return ( result );
}


ismd_result_t
ismd_event_reset(ismd_event_t event)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   event_context_t *event_context;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   event_context = lookup_and_lock_event( event );
   if ( event_context != NULL ) {
      event_context->triggered = false;
      result = ISMD_SUCCESS;
      EVENT_MANGER_TRACE(event, event_context->name, ISMD_CORE_TRACE_EVENT_RESET, result);
      EVENT_MANAGER_LOG_MSG(4, "%s(): resetting event %d.\n", __func__ , event );
      event_unlock( event_context );
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return ( result );
}


static ismd_result_t
strobe_event_internal(event_context_t *event_context, ismd_event_t event)
{
   ismd_result_t result = ISMD_SUCCESS;

   event_context->latch++;
   event_wakeup( event_context );
   result = ISMD_SUCCESS;
   EVENT_MANGER_TRACE(event, event_context->name, ISMD_CORE_TRACE_EVENT_STROBE, result);
   EVENT_MANAGER_LOG_MSG(4, "%s(): strobed event %d.\n", __func__, event);

   return result;
}

ismd_result_t
ismd_event_strobe(ismd_event_t event)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   event_context_t *event_context;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   event_context = lookup_and_lock_event( event );
   if ( event_context != NULL ) {
      result = strobe_event_internal(event_context, event);
      event_unlock( event_context );
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return ( result );
}

ismd_result_t
ismd_event_strobe_nonblocking(ismd_event_t event)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   event_context_t *event_context;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   event_context = lookup_event( event );
   if ( event_is_in_use(event_context) ) {
      result = strobe_event_internal(event_context, event);
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return ( result );
}


ismd_result_t
ismd_event_acknowledge(ismd_event_t event)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   event_context_t *event_context;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   event_context = lookup_and_lock_event( event );
   if ( event_context != NULL ) {
      if ( event_context->triggered ) {
         event_context->latch = 1;
      }
      else {
         event_context->latch = event_context->latch > 1 ? 1 : 0;
      }
      event_unlock( event_context );
      result = ISMD_SUCCESS;
      EVENT_MANGER_TRACE(event, event_context->name, ISMD_CORE_TRACE_EVENT_ACKNOWLEDGE, result);
      EVENT_MANAGER_LOG_MSG(4, "%s(): acknowledged event %d.\n", __func__, event);
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return ( result );
}


ismd_result_t
ismd_event_set_name(ismd_event_t event, ismd_event_name_t name)
{
   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   event_context_t *event_context;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   event_context = lookup_and_lock_event( event );
   if ( event_context != NULL ) {
      OS_MEMCPY( event_context->name, name, sizeof(ismd_event_name_t) );
      result = ISMD_SUCCESS;
      EVENT_MANGER_TRACE(event, event_context->name, ISMD_CORE_TRACE_EVENT_SET_NAME, result);
      EVENT_MANAGER_LOG_MSG(4, "%s(): assigned name %s to event %d.\n", __func__, name, event );
      event_unlock( event_context );
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return ( result );
}


/***************************************************************
 *  SMD Event Manager Private Functions:
 *
 *  The following function are helper functions for the SMD
 *  Core Event Manager.  These function may be called only by
 *  other Event Manager functions.
 ***************************************************************/

/*
 * Lookup an event handle.  If the handle is valid, then return
 * a pointer to it's associated context structure.
 */
static event_context_t *
lookup_event(ismd_event_t handle)
{
   event_context_t *event_context = NULL;

   if ( valid_event_handle(handle) ) {
      event_context = &(events[handle]);
   }
   return ( event_context );
}


/*
 * Lookup an event handle.  If the handle is valid, then lock the event's
 * associated context structure and return a pointer to the structure.
 *
 * NOTE: The event is only locked if it is actually in use.
 */
static event_context_t *
lookup_and_lock_event(ismd_event_t handle)
{
   event_context_t *event_context;

   event_context = lookup_event( handle );
   if ( event_context != NULL ) {
      event_lock( event_context );
      if ( !event_is_in_use(event_context) ) {
         event_unlock( event_context );
         event_context = NULL;
      }
   }

   return ( event_context );
}


/*
 * Initialize the specifed event to it's default values.
 */
static void
event_init(event_context_t  *event_context)
{
   event_context->status              = ISMD_EVENT_STATE_IN_USE;
   OS_MEMCPY( event_context->name, DEFAULT_EVENT_NAME, sizeof(ismd_event_name_t) );
   event_context->triggered           = false;
   event_context->latch               = 0;
   event_context->wait_ptr            = &(event_context->wait_context);
   (event_context->wait_ptr)->waiting = false;
   os_event_create( &((event_context->wait_ptr)->wait_event), false );

   return;
}


/*
 * Deinitialize the specifed event context and free any resources
 * allocated to the event.
 */
static void
event_deinit(event_context_t *event_context)
{
   event_context->wait_ptr            = &(event_context->wait_context);
   (event_context->wait_ptr)->waiting = false;
   os_event_destroy( &((event_context->wait_ptr)->wait_event) );
   event_context->triggered           = false;
   event_context->latch               = 0;
   OS_MEMCPY( event_context->name, DEFAULT_EVENT_NAME, sizeof(ismd_event_name_t) );
   event_context->status              = ISMD_EVENT_STATE_FREE;

   return;
}


/*
 * Lock the specifed event context so that other threads can't
 * access it.
 */
static void
event_lock(event_context_t *event_context)
{
   os_mutex_lock( &(event_context->lock) );
}


/*
 * Unlock the specifed event context so that other threads
 * can access it again.
 */
static void
event_unlock(event_context_t *event_context)
{
   os_mutex_unlock( &(event_context->lock) );
}


/*
 * valid_event_handle determines if an event handle is within the range
 * of supported event handles.
 */
static bool
valid_event_handle(ismd_event_t event_handle)
{
   bool result = false;

   if ( (event_handle >= 0) && (event_handle < ISMD_MAX_EVENTS) ) {
      result = true;
   }

   return ( result );
}


/*
 * Determine if an event is currently in-use. Note that there
 * are more states than just "in_use" and "free."
 */
static bool
event_is_in_use(event_context_t *event_context)
{
   bool result = false;

   if ( event_context->status == ISMD_EVENT_STATE_IN_USE ) {
      result = true;
   }

   return ( result );
}


/*
 * If a thread is waiting on the specified event, then wake up the thread.
 * Returns true if the wakeup is actually performed.
 *
 * NOTE: The event should be LOCKED before calling this function.
 */
static bool
event_wakeup(event_context_t *event_context)
{
   bool result = false;
   if ( (event_context->wait_ptr)->waiting ) {
      os_event_set( &((event_context->wait_ptr)->wait_event) );
      result = true;
      EVENT_MANAGER_LOG_MSG(4, "%s(): waking up client of event %d.\n", __func__, event_context->handle );
   }
   return ( result );
}


/*
 * Determine if a thread is already waiting on an event.  This is a bit
 * tricky for the case of muliple events linked together depending on
 * whether we're currently in the process of linking them or not.
 *
 * NOTE: The event should be LOCKED before calling this function.
 */
static bool
thread_is_already_waiting(event_context_t *event_context,
                          event_context_t *primary_event_context)
{
   bool result = false; /* Assume the event is not currently waiting. */

   /* If there is no primary-event... */
   if ( primary_event_context == NULL ) {
      /* If a thread is currently waiting on the event... */
      if ( (event_context->wait_ptr)->waiting ) {
         /* The event is already waiting. */
         result = true;
      }
   }

   /* Otherwise, if the event is not already linked to the primary event... */
   else if ( event_context->wait_ptr != &(primary_event_context->wait_context) ) {

      /* If a thread is currently waiting on the event... */
      if ( (event_context->wait_ptr)->waiting ) {
         /* The event is already waiting. */
         result = true;
      }
   }

   return ( result );
}


/*
 * Link a list of events to together so that we can effectively do a single
 * wait operation that waits for the logical-OR of the states of every event
 * in the list.
 */
static ismd_result_t
link_events(ismd_event_list_t *event_list,
            int                num_events,
            event_context_t  **primary_event_context,
            ismd_event_t      *triggered_event)
{

   ismd_result_t result = ISMD_SUCCESS;
   event_context_t *event_context;
   int i;

   EVENT_MANAGER_LOG_MSG(4, "%s(): entering function.\n", __func__);

   *primary_event_context = NULL;
   /* For each event in the list ... */
   for ( i = 0; (i < num_events) && (result == ISMD_SUCCESS); i++ ) {

      /* Get a pointer to the event's context structure. */
      event_context = lookup_and_lock_event( (*event_list)[i] );
      if ( event_context != NULL ) {

         /* If a client thread is already waiting on the event... */
         if ( thread_is_already_waiting(event_context, *primary_event_context) ) {
            /* Only one thread at a time is allowed to wait on an event */
            result = ISMD_ERROR_EVENT_BUSY;
         }
         /* If the event is currently latched... */
         else if ( event_context->latch > 0 ) {
            /* There's no need to link the events because we don't have to wait. */
            EVENT_MANAGER_LOG_MSG(4, "%s(): event %d already set.\n", __func__, (*event_list)[i] );
            event_context->latch = 1;
            os_event_reset(&((event_context->wait_ptr)->wait_event));
            *triggered_event = (*event_list)[i];
            result = ISMD_ERROR_ALREADY_INITIALIZED;
         }
         else {
            /* If no primary event exists, the first event in the list becomes the primary. */
            if ( *primary_event_context == NULL ) {
               *primary_event_context = event_context;
            }

            /* Link this event to the primary event */
            event_context->wait_ptr = &((*primary_event_context)->wait_context);
            (event_context->wait_ptr)->waiting = true;
            EVENT_MANGER_TRACE((*event_list)[i], event_context->name, ISMD_CORE_TRACE_EVENT_START_WAIT, result);
         }
         event_unlock( event_context );
      }
      else { /* The event handle is not currently active (may have been freed). */
         result = ISMD_ERROR_INVALID_HANDLE;
      }
   }

   /*
    * If the link process was aborted, then unlink any events that we just
    * linked.  Note that we unlink them in reverse order so the primary event
    * is the last to unlink.
    */
   if ( result != ISMD_SUCCESS ) {

      /*
       * When result != ISMD_SUCCESS, that means that an failure occurred
       * during the link process.  When an failure occurs during the link
       * process "i" was indexing position (m-1) in the example below.
       * Then "i" was incremented again because it is post incremented at
       * the end of each pass through the for-loop.
       *
       * i:    0     1          m-2   m-1     m
       *    +-----+-----+     +-----+------+-----+
       *    |  E  | E+1 | ... | E+n | fail |     |
       *    +-----+-----+     +-----+------+-----+
       *                         ^     ^      ^
       *                         |     |      |
       *                         |     |      +--- "i" is currently here
       *                         |     +--- "i" indexed this position when
       *                         |          the failure occurred.
       *                         +--- This is the position of the last good
       *                              event inserted in the list.
       *
       * As can be seen in the example, we need to subtract 2 from "i" so
       * is will index the position of the last good event that was inserted
       * in the list.
       */
      for( i -= 2; i >= 0; i-- ) {
         event_context = lookup_and_lock_event( (*event_list)[i] );
         if ( event_context != NULL ) {
            event_context->wait_ptr = &(event_context->wait_context);
            (event_context->wait_ptr)->waiting = false;
            EVENT_MANGER_TRACE((*event_list)[i], event_context->name, ISMD_CORE_TRACE_EVENT_STOP_WAIT, result);
            event_unlock( event_context );
         }
      }
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return ( result );
}


/*
 * Unlink a list of events that were linked together with link_events.
 * For convenience, we also return the handle to the first event in the
 * list that has already triggered.
 */
static ismd_result_t
unlink_events(ismd_event_list_t *event_list,
              int                num_events,
              ismd_event_t      *triggered_event)
{

   ismd_result_t result = ISMD_SUCCESS;
   event_context_t *event_context;
   int i;

   for ( i = num_events - 1; i >= 0; i-- ) {

      /*
       * Don't use the lookup_and_lock_context() function here because
       * that function excludes events in the delayed-free state.
       */
      event_context = &(events[(*event_list)[i]]);
      event_lock( event_context );

      /*
       * Unlink the individual event from the primary event.  Note that
       * we do this in reverse order so that the primary event is the
       * last event to unlink.  This prevents any other client from
       * attempting to wait on one of the events before it is unlinked.
       */
      event_context->wait_ptr = &(event_context->wait_context);
      (event_context->wait_ptr)->waiting = false;
      EVENT_MANGER_TRACE((*event_list)[i], event_context->name, ISMD_CORE_TRACE_EVENT_STOP_WAIT, result);
      os_event_reset(&((event_context->wait_ptr)->wait_event));

      if ( event_context->latch > 0 ) {
         /*
          * If the event is latched, set the latch value to 1.  This is
          * important so that we won't miss strobes that occur between now
          * and the time the client calls ismd_event_acknowledge.
          */
         event_context->latch = 1;

         /*
          * Return the handle of the highest-priority event that triggered.
          * Here again, this code takes advantage of traversing the list in
          * reverse order because the highest-pritory events are at the
          * beginning of the list.
          */
         if ( result == ISMD_SUCCESS ) {
            *triggered_event = (*event_list)[i];
         }
      }

      /*
       * If somebody attempted to free one of the events while they were
       * we need to finish freeing the event and report to the client that
       * one of the events was deleted.
       */
      if ( event_context->status == ISMD_EVENT_STATE_DELAYED_FREE ) {
         event_deinit( event_context ); /* Finish freeing the event */
         event_list_add( &event_free_list, event_context );
         result = ISMD_ERROR_OBJECT_DELETED;
         EVENT_MANGER_TRACE(event, event_context->name, ISMD_CORE_TRACE_EVENT_FREE, result);
         EVENT_MANAGER_LOG_MSG(4, "%s(): freed event %d.\n", __func__, (*event_list)[i] );
      }

      event_unlock( event_context );
   }

   return ( result );
}

/*
 * Put the current thread to sleep until the specified event--or any event
 * that is linked to it--either triggers or times out.
 */
static ismd_result_t
event_wait(event_context_t *event_context,
           unsigned int     timeout)
{
   ismd_result_t result;
   osal_result os_result;

   os_result = os_event_wait( &((event_context->wait_ptr)->wait_event),
                              (timeout == ISMD_TIMEOUT_NONE) ? EVENT_NO_TIMEOUT : (unsigned long) timeout );
   if ( os_result == OSAL_SUCCESS ) {
       result = ISMD_SUCCESS;
   }
   else if ( os_result == OSAL_TIMEOUT ) {
      result = ISMD_ERROR_TIMEOUT;
   }
   else if ( os_result == OSAL_NOT_DONE ) {
      result = ISMD_ERROR_NOT_DONE;
   }
   else { /* Some internal OSAL error occurred. */
      result = ISMD_ERROR_UNSPECIFIED;
   }

   EVENT_MANAGER_LOG_MSG(4, "%s(): returning %d.\n", __func__, result );

   return ( result );
}

/*
 * TODO:  Move these list manipulation functions to a
 * common place in the SMD Core so they can be shared
 * within the Core.
 */

/*
 * Initialize the list of free event contexts.
 */
static void
list_init(context_list_t *list)
{
   int osal_result;

   list->head = NULL;
   list->tail = NULL;

   osal_result = os_mutex_init( &list->lock );

   /*
    * We're going to assert the success of the semaphore initialization
    * because if it fails, it means the OSAL is unstable and we probably
    * can't trust any of the semaphore functions.
    */
   OS_ASSERT( osal_result == OSAL_SUCCESS );
}


/*
 * Deinitialize the list of free event contexts.
 */
static void
list_deinit(context_list_t *list)
{
   os_mutex_destroy( &(list->lock) );
}


/*
 * Add an event context to the end of the list of free event contexts.
 */
static void
event_list_add(context_list_t  *list,
               event_context_t *context)
{
   os_mutex_lock( &(list->lock) );

   if ( list->tail == NULL ) {
      list->head = context;
   }
   else {
      (list->tail)->next = context;
   }

   list->tail = context;
   context->next = NULL;

   os_mutex_unlock( &(list->lock) );
}


/*
 * Remove the event context at the front of the list of free event contexts.
 */
static event_context_t *
list_remove(context_list_t *list)
{
   event_context_t *context;

   os_mutex_lock( &(list->lock) );

   context = list->head;

   if ( context != NULL ) {
      list->head = context->next;

      if ( list->head == NULL ) {
         list->tail = NULL;
      }
   }

   os_mutex_unlock( &(list->lock) );

   return ( context );
}
