/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

/* ismd_device_manager implements the Device Manager */

#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core.h"
#include "ismd_core_protected.h"
#include "smd_core_local_defs.h"

// TODO: What's the right number for these
#define ISMD_MAX_QUEUES (100+51) // Should be slightly bigger than ISMD_MAX_PORTS  100+5
#define ISMD_MAX_LINKS  ((ISMD_MAX_QUEUES)*16) 

#define ISMD_DEBUG_NAME_LENGTH 50
#define INVALID_VIRTUAL_QUEUE_ID -1
#define DEFAULT_QUEUE_NAME "unnamed_queue"

typedef enum {
   ISMD_QUEUE_STATUS_INVALID   = 0,
   ISMD_QUEUE_STATUS_FREE      = 1,
   ISMD_QUEUE_STATUS_ALLOCATED = 2
} ismd_queue_state_t;


typedef os_mutex_t ismd_queue_lock_t;


/* 
 * Each queue has a linked-list of buffers.  It is possible to use buffers to
 * make a linked-list, but doing this prevents having a buffer concurrently in
 * two different queues.  To workaround this, each link in the queue is a 
 * dedicated structure that points to the associated buffer.
 */
typedef struct _queue_link_t {
   struct _queue_link_t     *next;
   ismd_buffer_descriptor_t *buf;
} ismd_queue_link_t;


typedef struct {
   ismd_queue_type_t         type;             /* Type of queue. */
   ismd_producer_func_t      producer_func;    /* Function to call when the queue need to try to fill itself. */
   void                     *producer_context; /* User-supplied context information for the output callback. */
   ismd_consumer_func_t      consumer_func;    /* Function to call when the queue need to try to empty itself. */
   void                     *consumer_context; /* User-supplied context information for the input callback. */
   int                       max_depth;        /* Maximum depth of the queue, queue will refuse data if depth would become larger than this amount */
   int                       cur_depth_bufs;   /* Current depth of queue in buffers. This is just the number of buffer descriptors in the queue. */
   int                       cur_depth_bytes;  /* Current depth of queue in bytes. This is the sum of the "level" field of all buffer descriptors in the queue. */
   int                       high_watermark;   /* Queue depth when a high-watermark event is generated.  The action taken depends on whether the queue is attached to an input port or an output port and wether the port is connected to another port. */
   int                       low_watermark;    /* Queue depth when a low-watermark event is generated.  The action taken depends on whether the queue is attached to an input port or an output port and wether the port is connected to another port. */
   ismd_queue_state_t        status;           /* Current status of this queue. */
   ismd_queue_link_t        *free_links;
   ismd_queue_link_t        *list_head;
   ismd_queue_link_t        *list_tail;
   ismd_queue_lock_t         lock;

   int                       virtual_queue_id;             /* used to associate queue id from SMD queue to debug console ids */
   char                      name[ISMD_DEBUG_NAME_LENGTH]; /* queue name. */
   ismd_queue_handle_t       user_handle;                  /* just for SVEN Debug */
} ismd_queue_t;



/*
 * The queue links are allocated by the queues as they are created.  This 
 * structure tracks the state of the allocation.
 */
typedef struct {
   ismd_queue_link_t  link_array[ISMD_MAX_LINKS];
   ismd_queue_link_t *free_link_head;
   ismd_queue_lock_t  lock;
} ismd_link_allocator_state_t;


/* 
 * For now, we suport only a fixed number of queues. However, the code should be 
 * modular enough to make implementation of a dynamic allocation scheme a 
 * straight-forward task.
 */
ismd_queue_t                ismd_queues[ISMD_MAX_QUEUES];
ismd_link_allocator_state_t link_allocator_state;

static bool init_queue( ismd_queue_t *queue, ismd_queue_type_t type, int max_depth );
static bool lookup_queue( ismd_queue_handle_t handle, ismd_queue_t **queue );
static bool valid_queue_handle( ismd_queue_handle_t handle );
static bool active_queue( ismd_queue_t *queue );
static bool valid_queue_type( ismd_queue_type_t type );
static bool valid_queue_watermark( ismd_queue_t *queue, int watermark, bool high_watermark);
static void queue_lock( ismd_queue_t *queue );
static void queue_unlock( ismd_queue_t *queue );
static ismd_result_t queue_push( ismd_queue_t *queue, ismd_queue_event_t queue_event );
static ismd_result_t queue_pull( ismd_queue_t *queue, ismd_queue_event_t queue_event );
static ismd_result_t queue_flush( ismd_queue_t *queue );
static ismd_queue_link_t *allocate_link(ismd_link_allocator_state_t *allocator_state);
static void free_link(ismd_queue_link_t *link, ismd_link_allocator_state_t *allocator_state);
static ismd_result_t add_or_remove_links(ismd_queue_t *queue, int size_difference);

ismd_result_t ismd_queue_manager_init(void)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_queue_handle_t handle;
   unsigned int link_num;
   ismd_queue_t *queue;
   int osal_result;

   ISMD_LOG_MSG( 4, "ismd_queue_manager_init(): entering function.\n" );

   /* Initialize the free links */
   osal_result = os_mutex_init( &(link_allocator_state.lock) );
   if ( osal_result != OSAL_SUCCESS ) {
      ISMD_LOG_MSG( 1, "ismd_queue_manager.c : ismd_queue_manager_init() : ERROR : os_mutex_init returned %d.\n", osal_result );
      result = ISMD_ERROR_UNSPECIFIED;
   } else {
      for (link_num = 0; link_num < ISMD_MAX_LINKS; link_num++) {
         link_allocator_state.link_array[link_num].next = &(link_allocator_state.link_array[link_num+1]);
         link_allocator_state.link_array[link_num].buf = NULL;
      }
      link_allocator_state.link_array[ISMD_MAX_LINKS-1].next = NULL;
      link_allocator_state.free_link_head = &(link_allocator_state.link_array[0]);

      /* Initialize each queue */
      for ( handle = 0; handle < ISMD_MAX_QUEUES; handle++ ) {
         lookup_queue( handle, &queue );

         osal_result = os_mutex_init( &(queue->lock) );
         if ( osal_result != OSAL_SUCCESS ) {
            ISMD_LOG_MSG( 1, "ismd_queue_manager.c : ismd_queue_manager_init() : ERROR : os_mutex_init returned %d.\n", osal_result );
            result = ISMD_ERROR_UNSPECIFIED;
            break;
         }
         /* setting max depth to 0 here, so init_queue does not see a change in
          * depth. */
         queue->max_depth = 0;
         queue->free_links = NULL;
         init_queue( queue, 0, 0 );
         queue->status = ISMD_QUEUE_STATUS_FREE;
      }
   }

   ISMD_LOG_MSG( 4, "ismd_queue_manager_init(): exiting function.\n" );

   return (ISMD_SUCCESS);
}


ismd_result_t ismd_queue_alloc( ismd_queue_type_t    type, 
                                int                  max_depth,
                                ismd_queue_handle_t *queue_handle )
{
   ismd_queue_handle_t handle;
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;
   ismd_queue_t *queue;

   if ( !valid_queue_type(type) ) {
      result = ISMD_ERROR_INVALID_PARAMETER;
      DEVH_INVALID_PARAM( smd_dbg_devh[SMD_CORE_DEBUG_UNIT_QUEUE] );
   }
   else if ( max_depth < 0 ) {
      result = ISMD_ERROR_INVALID_PARAMETER;
      DEVH_INVALID_PARAM( smd_dbg_devh[SMD_CORE_DEBUG_UNIT_QUEUE] );
   }
   else {
      for ( handle = 0; handle < ISMD_MAX_QUEUES; handle++ ) {
         lookup_queue( handle, &queue );
         queue_lock( queue );

         if ( !active_queue(queue) ) {
            init_queue( queue, type, max_depth );
            queue->status = ISMD_QUEUE_STATUS_ALLOCATED;
            *queue_handle = handle;
            result = ISMD_SUCCESS;

            /* This is the new stuff added for SVEN debug */
            queue->user_handle = handle;


            smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_QUEUE,
                                      SVEN_EV_SMDCore_Queue_Alloc,
                                      handle,
                                      type,
                                      max_depth,
                                      0, 0, 0 );

            /* exit this loop without using a break statement (simplifies unlocking the queues) */
            handle = ISMD_MAX_QUEUES; 
         }
         queue_unlock( queue );
      }

      if ( result != ISMD_SUCCESS ) {
         DEVH_WARN( smd_dbg_devh[SMD_CORE_DEBUG_UNIT_QUEUE], "no SMD queues left" );
      }
   }

   ISMD_LOG_MSG( 4, "ismd_queue_alloc(): exiting function.\n" );

   return ( result );
}


/*
 * Brian Welch:  FIXME:  There is no need for both a user-assigned name and 
 * virtual ID, especially since there is no requirement for either of them 
 * to be unique.  Unforutnately, the addition of the name and virtual_queue_id 
 * parameters to this function bypassed normal check-in and review procedures...
 */
ismd_result_t ismd_queue_alloc_named( ismd_queue_type_t    type, 
                                      int                  max_depth, 
                                      char *               name, 
                                      int                  name_length, 
                                      int                  virtual_queue_id, 
                                      ismd_queue_handle_t *queue_handle )
{
   ismd_result_t result = ISMD_ERROR_NO_RESOURCES;

   result = ismd_queue_alloc( type, max_depth, queue_handle );
   if ( ISMD_SUCCESS == result ) {
      result = ismd_queue_set_name(*queue_handle, name, name_length, virtual_queue_id);
   }

   return ( result );
}



ismd_result_t ismd_queue_set_name( ismd_queue_handle_t  handle,
                                   char *               name, 
                                   int                  name_length, 
                                   int                  virtual_queue_id)
{
   ismd_result_t result = ISMD_SUCCESS;
   ismd_queue_t *queue;

   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   } else {
      queue_lock( queue );
      if ( virtual_queue_id > 0 ) {
         queue->virtual_queue_id = virtual_queue_id;
         smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_QUEUE,
                                   SVEN_EV_SMDCore_Viz_Queue_Associate,
                                   handle,
                                   virtual_queue_id,
                                   0, 0, 0, 0 );
      }
      if ( name_length > 0 ) {
         OS_MEMCPY( queue->name, 
                    name, 
                    (name_length < ISMD_DEBUG_NAME_LENGTH) ? name_length : ISMD_DEBUG_NAME_LENGTH );
         smd_core_send_sven_event_named(
                                   SMD_CORE_DEBUG_UNIT_QUEUE,
                                   SVEN_EV_SMDCore_Queue_SetName,
                                   handle,
                                   name,
                                   name_length );
      }
      queue_unlock( queue );
   }

   return ( result );
}



ismd_result_t ismd_queue_free( ismd_queue_handle_t handle )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_t *queue;

   ISMD_LOG_MSG( 4, "ismd_queue_free(): entering function.\n" );

   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      queue_lock( queue );

      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {
         queue_flush( queue );
         init_queue( queue, 0, 0 );
         queue->status = ISMD_QUEUE_STATUS_FREE;
         result = ISMD_SUCCESS;

         smd_core_send_sven_event(
            SMD_CORE_DEBUG_UNIT_QUEUE,
            SVEN_EV_SMDCore_Queue_Free,
            handle,
            0, 0, 0, 0, 0 );

         ISMD_LOG_MSG( 3, "ismd_queue_free() : freed queue %d\n", handle );
      }
      queue_unlock( queue );
   }

   ISMD_LOG_MSG( 4, "ismd_queue_free(): exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_queue_connect_input( ismd_queue_handle_t  handle,
                                        ismd_producer_func_t producer_func,
                                        void                *producer_context,
                                        int                  low_watermark )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_t *queue;

   ISMD_LOG_MSG( 4, "ismd_queue_connect_input() : entering function.\n" );

   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      queue_lock( queue );
      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else if ( !valid_queue_watermark( queue, low_watermark, false) ) {
         result = ISMD_ERROR_INVALID_PARAMETER;
      } 
      
      else { 
         if ( queue->producer_func != NULL ) {
            result = ISMD_ERROR_QUEUE_BUSY;
         }
         else {
            ISMD_LOG_MSG( 3, "ismd_queue_connect_input() : connecting to queue %d, callback = 0x%08X\n", 
                          handle, 
                          (uint32_t)producer_func );
            queue->producer_context = producer_context;
            queue->low_watermark    = low_watermark;
            queue->producer_func    = producer_func;
            result = ISMD_SUCCESS;
         }
      }
      queue_unlock( queue );
   }

   ISMD_LOG_MSG( 4, "ismd_queue_connect_input() : exiting function.\n" );
   return ( result );
}


ismd_result_t ismd_queue_connect_output( ismd_queue_handle_t  handle,
                                         ismd_consumer_func_t consumer_func,
                                         void                *consumer_context,
                                         int                  high_watermark )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_t *queue;

   ISMD_LOG_MSG( 4, "ismd_queue_connect_output() : entering function.\n" );

   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      queue_lock( queue );
      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else if ( !valid_queue_watermark(queue, high_watermark, true) ) {
         result = ISMD_ERROR_INVALID_PARAMETER;
      }
      else {
         if ( queue->consumer_func != NULL ) {
            result = ISMD_ERROR_QUEUE_BUSY;
         }
         else {
            ISMD_LOG_MSG( 3, "ismd_queue_connect_output() : connecting to queue %d, callback = 0x%08X\n", 
                          handle, 
                          (uint32_t)consumer_func );

            queue->consumer_context = consumer_context;
            queue->high_watermark   = high_watermark;
            queue->consumer_func    = consumer_func;
            result = ISMD_SUCCESS;
         }
      }
      queue_unlock( queue );
   }

   ISMD_LOG_MSG( 4, "ismd_queue_connect_output() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_queue_disconnect_input( ismd_queue_handle_t handle )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_t *queue;

   ISMD_LOG_MSG( 4, "ismd_queue_disconnect_input() : entering function.\n" );

   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      queue_lock( queue );
      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {
         ISMD_LOG_MSG( 3, "ismd_queue_disconnect_input() : disconnecting from queue %d\n", handle );
         queue->producer_func    = NULL;
         queue->producer_context = NULL;
         queue->low_watermark    = ISMD_QUEUE_WATERMARK_NONE;
         result = ISMD_SUCCESS;
      }
      queue_unlock( queue );
   }

   ISMD_LOG_MSG( 4, "ismd_queue_disconnect_input() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_queue_disconnect_output( ismd_queue_handle_t handle )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_t *queue;
   
   ISMD_LOG_MSG( 4, "ismd_queue_disconnect_output() : entering function.\n" );

   if ( !lookup_queue(handle, &queue) ) {
       result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      queue_lock( queue );
      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {
         ISMD_LOG_MSG( 3, "ismd_queue_disconnect_output() : disconnecting from queue %d\n", handle );
         queue->consumer_func    = NULL;
         queue->consumer_context = NULL;
         queue->high_watermark   = ISMD_QUEUE_WATERMARK_NONE;
         result = ISMD_SUCCESS;
      }
      queue_unlock( queue );
   }

   ISMD_LOG_MSG( 4, "ismd_queue_disconnect_output() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_queue_enqueue( ismd_queue_handle_t       handle, 
                                  ismd_buffer_descriptor_t *buffer )
{
   ismd_result_t result = ISMD_ERROR_NO_SPACE_AVAILABLE;
   ismd_queue_event_t queue_event = ISMD_QUEUE_EVENT_NONE;
   ismd_queue_t *queue;
   int *cur_depth;
   int buf_size;
   int buf_level = 0;
   int prev_depth;
   bool push_attempted = false;

   ISMD_LOG_MSG( 4, "ismd_queue_enqueue() : entering function, queue=%d.\n", handle );

   if ( (buffer->buffer_type != ISMD_BUFFER_TYPE_PHYS)  && \
      (buffer->buffer_type != ISMD_BUFFER_TYPE_VIDEO_FRAME) && \
      (buffer->buffer_type != ISMD_BUFFER_TYPE_PHYS_CACHED) && \
      (buffer->buffer_type != ISMD_BUFFER_TYPE_PHYS_EXT_MAP) ) {
      ISMD_LOG_MSG( 1, "ismd_queue_enqueue() : attempt to enqueue invalid buffer type %d.\n", buffer->buffer_type );
      DEVH_WARN( smd_dbg_devh[SMD_CORE_DEBUG_UNIT_QUEUE], "invalid buffer type" );
      result = ISMD_ERROR_FEATURE_NOT_SUPPORTED;
   } else 
   if (buffer->state != ISMD_BUFFER_STATE_ALLOCATED) {
      ISMD_LOG_MSG( 1, "ismd_queue_enqueue() : Error: buffer %d is not in allocated state.\r\n", buffer->unique_id );
      result = ISMD_ERROR_INVALID_HANDLE;
   } else if ( !lookup_queue(handle, &queue) ) {
      ISMD_LOG_MSG( 1, "ismd_queue_enqueue() : invalid queue handle %d.\n", handle );
      DEVH_WARN( smd_dbg_devh[SMD_CORE_DEBUG_UNIT_QUEUE], "invalid queue handle" );
      result = ISMD_ERROR_INVALID_HANDLE;
   } else {
      /* Lock the queue so nobody else messes with it until we're done. */
      queue_lock( queue );

      /* Check if the queue is active. */
      if ( !active_queue(queue) ) {
         ISMD_LOG_MSG( 2, "ismd_queue_enqueue() : stale queue handle %d.\n", handle );
         DEVH_WARN( smd_dbg_devh[SMD_CORE_DEBUG_UNIT_QUEUE], "stale queue handle" );
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {

         ISMD_LOG_MSG( 4, "ismd_queue_enqueue() : depth before enqueue = %d bufs/%d bytes.\n", 
                       queue->cur_depth_bufs, 
                       queue->cur_depth_bytes );

         if (buffer->buffer_type != ISMD_BUFFER_TYPE_VIDEO_FRAME) {
            ismd_buffer_get_level( buffer->unique_id, &buf_level );
         } else {
            buf_level = 1; // Frame buffers do not have a level.
         }

         /* Setup some shortcuts based on the queue type. */
         if ( queue->type == ISMD_QUEUE_TYPE_VARSIZE_BUFFERS ) {
            prev_depth = queue->cur_depth_bytes;
            cur_depth  = &(queue->cur_depth_bytes);
            buf_size = buf_level;
         }
         else {
            prev_depth = queue->cur_depth_bufs;
            cur_depth  = &(queue->cur_depth_bufs);
            buf_size   = 1;
         }

         /*
         * Handle the case where the queue is empty. Here we want to push 
         * the new buffer directly to the consumer without going through 
         * the queue.
         */
         if ( queue->cur_depth_bufs == 0 ) {
            if ( queue->consumer_func != NULL ) {
               ISMD_LOG_MSG( 4, "ismd_queue_enqueue() : queue %d is empty, pushing buffer %d to consumer callback...", handle, buffer->unique_id );
               /* Recognize that FULL, NOT_EMPTY and HIGH_WATERMARK are conditions which can exist simultaniously. */
               queue_event = ISMD_QUEUE_EVENT_NOT_EMPTY;
               if (1 >= queue->max_depth) {
                  queue_event |= ISMD_QUEUE_EVENT_FULL;
               }
               if ((ISMD_QUEUE_WATERMARK_NONE != queue->high_watermark) &&
                   (1 >= queue->high_watermark)) {
                  queue_event |= ISMD_QUEUE_EVENT_HIGH_WATERMARK;
               }
               result = (* (queue->consumer_func))(queue->consumer_context, queue_event, buffer->unique_id);

               push_attempted = true;
               ISMD_LOG_MSG( 4, "push %s.\n", result == ISMD_SUCCESS ? "succeeded" : "failed" );
            }
         }

         /*
          * Handle the case where the queue is full.  Here we will push the 
          * buffer at the head of the queue to the consumer.  This is not 
          * required, but it allows a "push model" where the producer can 
          * always try to push frames (i.e. by polling) and the consumer 
          * can always rely on callbacks to wake it up.
          */
         else if ( *cur_depth >= queue->max_depth ) {
            queue_push( queue, ISMD_QUEUE_EVENT_FULL );
         }

         /*
          * Handle the normal case where the queue has room to hold the new 
          * buffer.
          */
         if ( (*cur_depth < queue->max_depth) && (result != ISMD_SUCCESS) ) {

            ismd_queue_link_t *link = queue->free_links;
            queue->free_links = link->next;
            link->buf = buffer;

            if ( queue->list_head == NULL ) { /* If the queue is empty... */
               /* Update the head pointer to point at the new buffer. */
               queue->list_head = link;
            }
            else { /* ... the queue is not empty */
               /* Update the previous tail buffer to point at the new buffer. */
               (queue->list_tail)->next = link;
            }

            /* The new buffer is always the new tail, so update the tail pointer to */
            /* point at this buffer and also invalidate the buffer's next pointer.  */
            queue->list_tail = link;
            link->next = NULL;

            /* Update the current queue depth. */
            queue->cur_depth_bufs += 1;
            queue->cur_depth_bytes += buf_level;


            /* Check if the queue depth just now increased to a level at-or-above the maximum queue depth. */
            if ( (*cur_depth >= queue->max_depth) &&
                 (prev_depth < queue->max_depth) ) {
               queue_event |= ISMD_QUEUE_EVENT_FULL;
            }

            /* Check if the queue depth just crossed the high-watermark level. */
            if ( queue->high_watermark != ISMD_QUEUE_WATERMARK_NONE ) {
               if ( (*cur_depth >= queue->high_watermark) &&
                    (prev_depth < queue->high_watermark) ) {
                  queue_event |= ISMD_QUEUE_EVENT_HIGH_WATERMARK;
               }
            }

            ISMD_LOG_MSG( 3, "ismd_queue_enqueue() : enqueued buffer %d to queue %d, queue depth=%d bufs, %d bytes.\n", 
                          buffer->unique_id, 
                          handle, 
                          queue->cur_depth_bufs, 
                          queue->cur_depth_bytes );

            result = ISMD_SUCCESS;

            /* If a queue event occurred, we try to push a buffer to the consumer. */
            if (!push_attempted ) {
               queue_push( queue, queue_event );
               /* Note that we don't care about the return value from the push since */
               /* the enqueue operation itself has already succeeded at this point.  */
            }
         }
      }

      ISMD_LOG_MSG( 4, "ismd_queue_enqueue() : depth after enqueue = %d bufs/%d bytes.\n", 
                    queue->cur_depth_bufs, 
                    queue->cur_depth_bytes );

      /* Unlock the queue because we're done manipulating it. */
      queue_unlock( queue );
   }
   
   if ( result == ISMD_SUCCESS ) {
      smd_core_send_sven_event(
         SMD_CORE_DEBUG_UNIT_QUEUE,
         SVEN_EV_SMDCore_Queue_Write,
         handle,
         queue->cur_depth_bufs, /* tot_buffers */
         queue->cur_depth_bytes,/* tot_bytes */
         1,                     /* xact_buffers */
         buf_level,             /* xact_bytes */
         buffer->unique_id );
   }

   ISMD_LOG_MSG( 4, "ismd_queue_enqueue() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_queue_dequeue( ismd_queue_handle_t        handle, 
                                  ismd_buffer_descriptor_t **buffer )
{
   ismd_result_t result = ISMD_ERROR_NO_DATA_AVAILABLE;
   ismd_queue_event_t queue_event = ISMD_QUEUE_EVENT_NONE;
   ismd_queue_t *queue;
   int buf_size;
   int buf_level = 0;
   int prev_depth;
   int *cur_depth;
   ismd_buffer_handle_t buffer_id;

   ISMD_LOG_MSG( 4, "ismd_queue_dequeue() : entering function, queue=%d.\n", handle );
   
   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {

      /* Lock the queue so nobody else messes with it until we're done. */
      queue_lock(queue);

      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {

         ISMD_LOG_MSG( 4, "ismd_queue_dequeue() : depth before dequeue = %d bufs/%d bytes.\n", 
                       queue->cur_depth_bufs, 
                       queue->cur_depth_bytes );
      /*
          * Handle the case where the queue is empty.  Here we want to bypass 
          * the queue, pull a buffer directly from the producer and return 
          * it to the caller.  This allows the consumer and producer to 
          * operated in "pull mode" where the consumer continuously attempts to 
          * reads from the queue and the producer can always depend on callbacks 
          * to wake it up and retrieve buffers.
          */
         if ( queue->cur_depth_bufs == 0 ) {
            ISMD_LOG_MSG( 4, "ismd_queue_dequeue() : queue %d is empty.\n", handle );

            if ( queue->producer_func != NULL ) {
               ISMD_LOG_MSG( 4, "ismd_queue_dequeue() : pulling buffer from producer function 0x%08X\n", 
                            (uint32_t)(queue->producer_func) );
               result = (* (queue->producer_func))(queue->producer_context, ISMD_QUEUE_EVENT_EMPTY, &buffer_id);
               if (result == ISMD_SUCCESS) {
                  result = ismd_buffer_find_descriptor(buffer_id, buffer);
               }
               ISMD_LOG_MSG( 4, "pull %s.\n", result == ISMD_SUCCESS ? "succeeded" : "failed" );
            }
         }

         /*
          * Handle the normal case where the queue is not empty, here we just 
          * pull a buffer out of the queue and return it to the caller.
          */
         else {
            ismd_queue_link_t *link = queue->list_head;
            queue->list_head = link->next;

            /* Get the buffer at the head of the queue. */
            *buffer = link->buf;

            link->buf = NULL;
            link->next = queue->free_links;
            queue->free_links = link;

            if ((*buffer)->buffer_type != ISMD_BUFFER_TYPE_VIDEO_FRAME) {
               ismd_buffer_get_level( (*buffer)->unique_id, &buf_level );
            } else {
               buf_level = 1; // Frame buffers do not have a level.
            }

            /* Setup some shortcuts based on the queue type. */
            if ( queue->type == ISMD_QUEUE_TYPE_VARSIZE_BUFFERS ) {
               prev_depth = queue->cur_depth_bytes;
               cur_depth  = &(queue->cur_depth_bytes);
               buf_size   = buf_level;
            }
            else {
               prev_depth = queue->cur_depth_bufs;
               cur_depth  = &(queue->cur_depth_bufs);
               buf_size   = 1;
            }


            /* If the queue is now empty, then update the tail pointer. */
            if ( queue->list_head == NULL ) {
               queue->list_tail = NULL;
               queue_event |= ISMD_QUEUE_EVENT_EMPTY;
            }

            /* Update the current queue depth. */
            queue->cur_depth_bytes -= buf_level;
            queue->cur_depth_bufs--;

            /* Check if the buffer just went from full to not full. */
            if ( (*cur_depth < queue->max_depth) &&
                 (prev_depth >= queue->max_depth) ) {
               queue_event |= ISMD_QUEUE_EVENT_NOT_FULL;
            }
            /* Check if the buffer depth just crossed the low-watermark. */
            if ( queue->low_watermark != ISMD_QUEUE_WATERMARK_NONE ) {
               if ( (*cur_depth <= queue->low_watermark) && 
                    (prev_depth > queue->low_watermark) ) {
                  queue_event |= ISMD_QUEUE_EVENT_LOW_WATERMARK;
               }
            }

            ISMD_LOG_MSG( 3, "ismd_queue_dequeue() : dequeued buffer %d from queue %d.\n", 
                          (*buffer)->unique_id, 
                          handle );

            result = ISMD_SUCCESS;
         }

      /*
          * Handle the case where the max depth is 0.	Always just bypass 
          * the queue, pull a buffer directly from the producer and return 
          * it to the caller. No pull to queue at all. 
          */
        if ( queue->max_depth != 0) {
             queue_pull( queue, queue_event );
             /* Note that we don't care about the return value from the pull since */
             /* the dequeue operation itself has already succeeded at this point.  */
        }

         ISMD_LOG_MSG( 4, "ismd_queue_dequeue() : depth after dequeue = %d bufs/%d bytes.\n", 
                       queue->cur_depth_bufs, 
                       queue->cur_depth_bytes );

      }

      /* Unlock the queue. */
      queue_unlock(queue);

   }

   if ( result == ISMD_SUCCESS ) {
      smd_core_send_sven_event(
          SMD_CORE_DEBUG_UNIT_QUEUE,
          SVEN_EV_SMDCore_Queue_Read,
          handle,
          queue->cur_depth_bufs, /* tot_buffers */
          queue->cur_depth_bytes,/* tot_bytes */
          1,                     /* xact_buffers */
          buf_level,             /* xact_bytes */
          (*buffer)->unique_id );
   }

   ISMD_LOG_MSG( 4, "ismd_queue_dequeue() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_queue_get_status( ismd_queue_handle_t  handle, 
                                     ismd_queue_status_t *status )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_t *queue;

   ISMD_LOG_MSG( 4, "ismd_queue_get_status() : entering function.\n" );

   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      queue_lock( queue );
      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {
         status->type             = queue->type;             
         status->producer_func    = queue->producer_func;
         status->producer_context = queue->producer_context;
         status->consumer_func    = queue->consumer_func;
         status->consumer_context = queue->consumer_context;
         status->max_depth        = queue->max_depth;
         status->cur_depth_bufs   = queue->cur_depth_bufs;
         status->cur_depth_bytes  = queue->cur_depth_bytes;
         status->high_watermark   = queue->high_watermark;
         status->low_watermark    = queue->low_watermark;
         result = ISMD_SUCCESS;
      }
      queue_unlock( queue );
   }
   
   ISMD_LOG_MSG( 4, "ismd_queue_get_status() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_queue_get_config( ismd_queue_handle_t  handle, 
                                     ismd_queue_config_t *config )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_t *queue;

   ISMD_LOG_MSG( 4, "ismd_queue_get_config() : entering function.\n" );

   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      queue_lock( queue );
      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {           
         config->producer_func    = queue->producer_func;
         config->producer_context = queue->producer_context;
         config->consumer_func    = queue->consumer_func;
         config->consumer_context = queue->consumer_context;
         config->max_depth        = queue->max_depth;
         config->high_watermark   = queue->high_watermark;
         config->low_watermark    = queue->low_watermark;
         result = ISMD_SUCCESS;
      }
      queue_unlock( queue );
   }
   
   ISMD_LOG_MSG( 4, "ismd_queue_get_config() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_queue_set_config( ismd_queue_handle_t  handle, 
                                     ismd_queue_config_t *config )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_t *queue;

   ISMD_LOG_MSG( 4, "ismd_queue_set_config() : entering function.\n" );

   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      queue_lock( queue );
      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else if ( !valid_queue_watermark(queue, config->high_watermark, true) ||
                !valid_queue_watermark(queue, config->low_watermark, false) ) {
         result = ISMD_ERROR_INVALID_PARAMETER;
      }
      else {
         if (config->max_depth < queue->cur_depth_bufs) {
            ISMD_LOG_MSG( 1, "ismd_queue_set_config() : Can't set depth to less than current level.\n" );
            result = ISMD_ERROR_OPERATION_FAILED;
         } else {
         
            result = add_or_remove_links(queue, config->max_depth - queue->max_depth);
            if (result == ISMD_SUCCESS) {
               queue->producer_func    = config->producer_func   ;
               queue->producer_context = config->producer_context;
               queue->consumer_func    = config->consumer_func   ;
               queue->consumer_context = config->consumer_context;
               queue->max_depth        = config->max_depth       ;
               queue->high_watermark   = config->high_watermark  ;
               queue->low_watermark    = config->low_watermark   ;
               result = ISMD_SUCCESS;

               smd_core_send_sven_event(
                  SMD_CORE_DEBUG_UNIT_QUEUE,
                  SVEN_EV_SMDCore_Queue_SetConfig,
                  handle,
                  queue->max_depth,      /* max_buffers */
                  0,                     /* max_bytes */
                  queue->high_watermark, /* xact_buffers */
                  queue->low_watermark,  /* low_watermark */
                  0 );
            }
         }
      }
      queue_unlock( queue );
   }
   
   ISMD_LOG_MSG( 4, "ismd_queue_set_config() : exiting function.\n" );

   return ( result );
}


ismd_result_t ismd_queue_flush( ismd_queue_handle_t handle )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_t *queue;

   ISMD_LOG_MSG( 4, "ismd_queue_flush() : entering function.\n" );

   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      smd_core_send_sven_event(
            SMD_CORE_DEBUG_UNIT_QUEUE,
            SVEN_EV_SMDCore_Queue_Flush,
            handle,
            queue->cur_depth_bufs, /* tot_buffers */
            queue->cur_depth_bytes,/* tot_bytes */
            0,                     /* xact_buffers */
            0,                     /* xact_bytes */
            0 );

      queue_lock( queue );
      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else {
         result = queue_flush( queue );
      }
      queue_unlock(queue);
   }

   ISMD_LOG_MSG( 4, "ismd_queue_flush() : exiting function.\n" );

   return ( result );
}


static ismd_result_t queue_flush( ismd_queue_t *queue )
{
   ismd_result_t result;
   ismd_result_t overall_result = ISMD_SUCCESS;
   ismd_queue_link_t *link;

   while ( queue->list_head != NULL ) {
      link = queue->list_head;
      queue->list_head = link->next;
      result = ismd_buffer_dereference( link->buf->unique_id );
      if ( overall_result == ISMD_SUCCESS ) {
         overall_result = result;
      }
      link->buf = NULL;
      link->next = queue->free_links;
      queue->free_links = link;
   }
   queue->cur_depth_bufs  = 0;
   queue->cur_depth_bytes = 0;
   queue->list_tail = NULL;

   return overall_result;
}


ismd_result_t ismd_queue_lookahead( ismd_queue_handle_t        handle, 
                                    int                        buffer_depth, 
                                    ismd_buffer_descriptor_t **buffer )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   ismd_queue_link_t *temp;
   ismd_queue_t *queue;

   ISMD_LOG_MSG( 4, "ismd_queue_lookahead() : entering function.\n" );

   if ( !lookup_queue(handle, &queue) ) {
      result = ISMD_ERROR_INVALID_HANDLE;
   }
   else {
      queue_lock(queue);
      if ( !active_queue(queue) ) {
         result = ISMD_ERROR_INVALID_HANDLE;
      }
      else if ( buffer_depth <= 0 ) {
         result = ISMD_ERROR_INVALID_PARAMETER;
      }
      else if ( buffer_depth > queue->cur_depth_bufs ) {
         result = ISMD_ERROR_NO_DATA_AVAILABLE;
      }
      else {
         ISMD_LOG_MSG( 4, "ismd_queue_lookahead() : queue %d: current depth=%d, lookahead depth=%d\n", 
                       handle, 
                       queue->cur_depth_bufs, 
                       buffer_depth  );
         temp = queue->list_head;
         while ( --buffer_depth > 0 ) {
            temp = temp->next;
         }
         *buffer = temp->buf;
         result = ISMD_SUCCESS;
      }
      queue_unlock(queue);
   }

   ISMD_LOG_MSG( 4, "ismd_queue_lookahead() : exiting function.\n" );

   return ( result );
}

static ismd_result_t add_or_remove_links(ismd_queue_t *queue, int size_difference) {
   ismd_result_t result = ISMD_SUCCESS;
   ismd_queue_link_t *link;
   
   /* Init/modify the list of free links */
   if (size_difference > 0) {
      while (size_difference--) {
         link = allocate_link(&link_allocator_state);
         if (!link) {
            ISMD_LOG_MSG( 1, "add_or_remove_links() : Out of links!.\n" );
            result = ISMD_ERROR_NO_RESOURCES;
            break;
         } else {
            link->next = queue->free_links;
            queue->free_links = link;
         }
      }
   } else if (size_difference < 0) {
      while (size_difference++) {
         link = queue->free_links;
         if (link == NULL) {
            ISMD_LOG_MSG( 1, "add_or_remove_links() : Unexpected NULL pointer!.\n" );
            result = ISMD_ERROR_NO_RESOURCES;
            break;
         }
         queue->free_links = queue->free_links->next;
         free_link(link, &link_allocator_state);
      }
   }
   
   return result;
}


/* This assumes the queue has already been flushed */
bool init_queue( ismd_queue_t *queue, ismd_queue_type_t type, int max_depth )
{
   bool result = true;

   if (add_or_remove_links(queue, max_depth - queue->max_depth) != ISMD_SUCCESS) {
      result = false;
   } else {
      queue->type             = type;
      queue->producer_func    = NULL;
      queue->producer_context = NULL;
      queue->consumer_func    = NULL;
      queue->consumer_context = NULL;
      queue->max_depth        = max_depth;
      queue->cur_depth_bufs   = 0;
      queue->cur_depth_bytes  = 0;
      queue->high_watermark   = ISMD_QUEUE_WATERMARK_NONE;
      queue->low_watermark    = ISMD_QUEUE_WATERMARK_NONE;
      queue->list_head        = NULL;
      queue->list_tail        = NULL;
      queue->name[0]          = 0;
      queue->virtual_queue_id = 0;
      //queue->status           = ISMD_QUEUE_STATUS_FREE;
   }

   return ( result );
}


/* 
 * lookup_queue takes a queue handle and if the handle is valid, returns a 
 * pointer to the queue structure associated with that handle.  The queue may 
 * or may not be currently in-use.  If the handle is not valid, the function 
 * return value is false.
 */
static bool lookup_queue( ismd_queue_handle_t handle, ismd_queue_t **queue )
{
   bool result = false;

   if ( valid_queue_handle(handle) ) {
      *queue = &(ismd_queues[handle]);
      result = true;
   }
   return ( result );
}

/*
 * valid_queue_handle determines if a queue handle is within the range
 * of valid queue handles.
 */
static bool valid_queue_handle( ismd_queue_handle_t handle )
{
   bool result = false;
   if ( (handle >= 0) && (handle < ISMD_MAX_QUEUES) ) {
      result = true;
   }
   else DEVH_WARN( smd_dbg_devh[SMD_CORE_DEBUG_UNIT_QUEUE], "Invalid Queue Handle" );

   return ( result );
}


/* 
 * active_queue determines if a queue is currently in-use.
 */
static bool active_queue( ismd_queue_t *queue )
{
   bool result = false;

   if ( queue->status != ISMD_QUEUE_STATUS_FREE ) {
      result = true;
   }
   return ( result );
}


/*
 * valid_queue_type determines whether a queue type is valid or not.
 */
static bool valid_queue_type( ismd_queue_type_t type )
{
   bool result = false;

   if ( (type == ISMD_QUEUE_TYPE_FIXSIZE_BUFFERS) ||
        (type == ISMD_QUEUE_TYPE_VARSIZE_BUFFERS) ) {
      result = true;
   }
   return ( result );
}

/*
 * valid_queue_watermark determines whether a watermark value is valid
 * for a particular queue.
 */
static bool valid_queue_watermark( ismd_queue_t *queue, int watermark, bool high_watermark)
{
   bool result = false;

   if ( watermark == ISMD_QUEUE_WATERMARK_NONE ) {
      result = true;
   }
   else if ( (watermark >= 0) && (watermark <= queue->max_depth) ) {
      result = true;
   } 
     
   if (high_watermark && watermark == 0) {
      result = false;
   }
   
   if (!high_watermark && (watermark == queue->max_depth)) {
      result = false;
   }

   return ( result );
}


static void queue_lock( ismd_queue_t *queue )
{
   os_mutex_lock( &(queue->lock) );
}


static void queue_unlock( ismd_queue_t *queue )
{
   os_mutex_unlock( &(queue->lock) );
}


/*
 * Push the buffer at the head of the queue to the consumer.
 * Assumes queue is currently locked.
 */
static ismd_result_t queue_push( ismd_queue_t      *queue, 
                                 ismd_queue_event_t queue_event )
{
   ismd_result_t result = ISMD_ERROR_NO_SPACE_AVAILABLE;
   int save_level;
   ismd_queue_link_t *link;

   if ( (queue->consumer_func != NULL) && (queue->list_head != NULL) ) {
      ISMD_LOG_MSG( 3, "queue_push() : pushing buffer %d to consumer callback 0x%08X, event=%d...",
                    (queue->list_head->buf)->unique_id,
                    (uint32_t)(queue->consumer_func), 
                    queue_event );
      /* 
       * save some information from the buffer descriptor because after 
       * the callback function returns, we can't guarantee the contents 
       * of the descriptor hasn't changed.
       */
      if (queue->list_head->buf->buffer_type != ISMD_BUFFER_TYPE_VIDEO_FRAME) {
         ismd_buffer_get_level( queue->list_head->buf->unique_id, &save_level );
      } else {
         save_level = 1; // Frame buffers do not have a level.
      }

      smd_core_send_sven_event(
         SMD_CORE_DEBUG_UNIT_QUEUE,
         SVEN_EV_SMDCore_Queue_Push,
         queue->user_handle,    /* queue id */
         queue->cur_depth_bufs, /* tot_buffers */
         queue->cur_depth_bytes,/* tot_bytes */
         1,                     /* xact_buffers */
         save_level,            /* xact_bytes */
         queue->list_head->buf->unique_id );

      result = (* (queue->consumer_func))(queue->consumer_context, queue_event, queue->list_head->buf->unique_id);
      if ( result == ISMD_SUCCESS ) {
         /* pop link from queue */
         link = queue->list_head;
         link->buf = NULL;
         queue->list_head = link->next;
         
         /* push link to free list */
         link->next = queue->free_links;
         queue->free_links = link;
         
         if (queue->list_head == NULL) {
            queue->list_tail = NULL;
         }
         queue->cur_depth_bytes -= save_level;
         queue->cur_depth_bufs --;
      }
      ISMD_LOG_MSG( 3, "Push %s.\n", result == ISMD_SUCCESS ? "succeeded" : "failed" );
   }

   return ( result );
}


static ismd_result_t queue_pull( ismd_queue_t      *queue, 
                                 ismd_queue_event_t queue_event )
{
   /* Pulls a buffer from the producer and places it at the tail of the queue. */
   /* Assumes queue is currently locked and not full. */

   ismd_result_t result = ISMD_ERROR_NO_DATA_AVAILABLE;
   ismd_buffer_descriptor_t *buffer;
   ismd_buffer_handle_t buffer_id;
   ismd_queue_link_t *link;

   if ( queue->producer_func != NULL ) {
      ISMD_LOG_MSG( 3, "queue_pull() : pulling buffer from consumer callback 0x%08X, event=%d...",
                    (uint32_t)(queue->producer_func), 
                    queue_event );
      result = (* (queue->producer_func))(queue->producer_context, queue_event, &buffer_id);
      if ( result == ISMD_SUCCESS ) {
         result = ismd_buffer_find_descriptor(buffer_id, &buffer);
      }
      
      if ( result == ISMD_SUCCESS ) {

         int        buffer_level;

         /* pop link from free list and initialize it */
         link = queue->free_links;
         queue->free_links = link->next;
         link->buf = buffer;

         if ( queue->list_head == NULL ) {
            queue->list_head = link;
         }
         else {
            (queue->list_tail)->next = link;
         }
         queue->list_tail = link;
         link->next = NULL;

         if (buffer->buffer_type != ISMD_BUFFER_TYPE_VIDEO_FRAME) {
            ismd_buffer_get_level( buffer->unique_id, &buffer_level );
         } else {
            buffer_level = 1; // Frame buffers do not have a level.
         }

         smd_core_send_sven_event(
             SMD_CORE_DEBUG_UNIT_QUEUE,
             SVEN_EV_SMDCore_Queue_Pull,
             queue->user_handle,    /* queue id */
             queue->cur_depth_bufs, /* tot_buffers */
             queue->cur_depth_bytes,/* tot_bytes */
             1,                     /* xact_buffers */
             buffer_level,          /* xact_bytes */
             buffer->unique_id );

         queue->cur_depth_bytes += buffer_level;
         queue->cur_depth_bufs++;

         ISMD_LOG_MSG( 3, "Pull of buffer %d succeeded.\n", buffer->unique_id );
      }
      else {
         ISMD_LOG_MSG( 3, "Pull failed\n" );
      }
   }

   return ( result );
}

static ismd_queue_link_t *allocate_link(ismd_link_allocator_state_t *allocator_state)
{
   ismd_queue_link_t *ret;
   
   os_mutex_lock( &(allocator_state->lock) );

   ret = allocator_state->free_link_head;
   if (allocator_state->free_link_head) {
      allocator_state->free_link_head = allocator_state->free_link_head->next;
   }
   
   os_mutex_unlock( &(allocator_state->lock) );
   
   return ret;
}

static void free_link(ismd_queue_link_t *link, ismd_link_allocator_state_t *allocator_state)
{
   os_mutex_lock( &(allocator_state->lock) );

   link->next = allocator_state->free_link_head;
   allocator_state->free_link_head = link;
   
   os_mutex_unlock( &(allocator_state->lock) );
}
