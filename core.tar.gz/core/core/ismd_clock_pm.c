/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
   Intel Corporation

   2200 Mission College Blvd.
   Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

/** 
<H3>Power Management</H3>

This file contains the implementation of the clock power management. 
The basic idea is that 
when suspending, stop clock ISR thread and save clock registers,
when resuming, create ISR and then restore clock registers.
*/

/** @{ */

#include "ismd_global_defs.h"
#include "ismd_core.h"
#include "osal.h"
#include "intel_ce_pm.h"

/******************************************************************************
* Defines
******************************************************************************/
#ifdef __KERNEL__
   /**
   @brief <H3></H3>
     Define for clock power management to use intel_ce_pm component
   */
   #define CLOCK_POWER_MANAGEMENT
#endif

/**
@brief <H3></H3>
 String as power management device name, should keep consitent as intel_ce_pm component.
*/
#define DEVICE_NAME "ismdclock"


/******************************************************************************
* Definitions of global data
******************************************************************************/
/**
@brief <H3></H3>
   Current power state of the hardware device.
*/
static icepm_state_t pm_power_state;

#ifdef CLOCK_POWER_MANAGEMENT
      /**
      @brief <H3></H3>
        Pointers to functions that implement the power management operations. 
      */
      static icepm_functions_t pm_functions; 
#endif

/**
@brief <H3></H3>
  Flag to indicate suspend is going but not finished yet.
*/
static bool pm_is_suspending;


void lock_all_clocks(void);
void unlock_all_clocks(void);

/* Set power state for clock device*/
ismd_result_t ismd_clock_device_set_power_state(icepm_state_t state);


/*! @name Power Management. */

//-----------------------------------------------------------------------------
/**
@brief <H3>Description:</H3>
Determine if the clock hardware device is currently suspended.  

@param[in]      : void

@retval true    : the device is suspend.
@retval false   : the device is not suspend.

<H3>Algorithm:</H3>
*/
bool 
clock_suspended(void)
{
   bool result = false;

   //----------------------------------
   /** Check if power state is D0 */   
   if ( pm_power_state != ICEPM_D0 ) {
      result = true;
   }

   return result;
}

//-----------------------------------------------------------------------------
/**
@brief <H3>Description:</H3>
Determine if power suspend is going or finished

@param[in]      : void

@retval true    : going or finished.
@retval false   : neither going nor finished

<H3>Algorithm:</H3>
*/
bool 
clock_check_suspending(void)
{
   //----------------------------------
   /** check the flag value */   
   return pm_is_suspending || clock_suspended();
}

//-----------------------------------------------------------------------------
/**
@brief <H3>Description:</H3>
Suspend clock functions before clock hardware power off

@param[in]               : void

@retval ISMD_SUCCESS     : Suspend successfully.
@retval <anything else>  : Suspend failed.

*/
static ismd_result_t 
clock_set_hardware_power_state_suspend(void)
{
   ismd_result_t result = ISMD_SUCCESS;

   pm_is_suspending = true;
   /* release locks since suspend will wait for ISR thread to stop*/
   unlock_all_clocks();

   /* Suspend clock device*/
   result = ismd_clock_device_set_power_state(ICEPM_D3);

   lock_all_clocks();
   pm_is_suspending = false;

   return result;
}

//-----------------------------------------------------------------------------
/**
@brief <H3>Description:</H3>
Resume clock functions after clock hardware power on

@param[in]               : void

@retval ISMD_SUCCESS     : Resume successfully.
@retval <anything else>  : Resume failed.

<H3>Algorithm:</H3>
*/
static ismd_result_t 
clock_set_hardware_power_state_resume(void)
{
   ismd_result_t result = ISMD_SUCCESS;

   /* release locks since resume will create the ISR thread*/
   unlock_all_clocks();

   /* Resume clock device */
   result = ismd_clock_device_set_power_state(ICEPM_D0);

   lock_all_clocks();
   
   return result;
}

//-----------------------------------------------------------------------------
/**
@brief <H3>Description:</H3>
Internal function of both suspend and resume.

@param[in] requested_state       : Power state to set, only D0 and D3 
                                   can be handled currently.

@retval ISMD_SUCCESS             : set power state  successfully.
@retval <anything else>          : failed to set power state.

<H3>Algorithm:</H3>
*/
ismd_result_t
ismd_clock_set_power_state( icepm_state_t requested_state )
{
   ismd_result_t result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

   lock_all_clocks();
   /** If we're already in the requested state, there's nothing to do. */
   if ( pm_power_state == requested_state ) {
      result = ISMD_SUCCESS;
   } else {
      /** Attempt to change to the new power state. */
      switch (requested_state) {
         /** If going to D3 state. */
         case ICEPM_D3:
            result = clock_set_hardware_power_state_suspend();
            
            if (ISMD_SUCCESS == result) {
               pm_power_state = requested_state;

               #ifdef CLOCK_POWER_MANAGEMENT            
                  //----------------------------------
                  /** ++ Set hardware power state */         
                  {
                     icepm_ret_t icepm_result;
   
                     icepm_result = icepm_set_power_state(DEVICE_NAME, 
                                                         requested_state);
                     if(ICEPM_OK != icepm_result) {
                       result = ISMD_ERROR_OPERATION_FAILED;
                     }
                     OS_ASSERT(ICEPM_OK == icepm_result);
                  }
              #endif

            }
            break;

         //----------------------------------
         /** If going to D0 state. */
         case ICEPM_D0:           

            #ifdef CLOCK_POWER_MANAGEMENT            
               //----------------------------------
               /** ++ Set hardware power state to start */ 
               {
                  icepm_ret_t icepm_result;
   
                  icepm_result = icepm_set_power_state(DEVICE_NAME, 
                                                       requested_state);
                  if (ICEPM_OK != icepm_result) {
                     result = ISMD_ERROR_OPERATION_FAILED;
                  }    
                  OS_ASSERT(ICEPM_OK == icepm_result);
               }
            #endif
            
            result = clock_set_hardware_power_state_resume();

            if (ISMD_SUCCESS == result) {
               pm_power_state = requested_state;
            }
            break;

         default:
            result = ISMD_ERROR_INVALID_PARAMETER;
            break;
      }
   }

   unlock_all_clocks();

   return result;
}

#ifdef CLOCK_POWER_MANAGEMENT
   //-----------------------------------------------------------------------------
   /**
   @brief <H3>Description:</H3>
   The suspend function we register with the power management driver.
   It gets called whenever the system requests a change in the suspended state.
   
   @param[in] dev       : pci device , currently ignored.
   @param[in] state     : Power state to set, currently ignored.
   
   @retval 0            : successfully.
   @retval -EBUSY       : failed
   
   <H3>Algorithm:</H3>
   */
   int 
   ismd_clock_suspend( struct pci_dev *dev, pm_message_t state )
   {
      int result = -EBUSY; 
      ismd_result_t smd_result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   
      /** set clock power state to D3. */      
      smd_result = ismd_clock_set_power_state( ICEPM_D3 );
      if ( smd_result == ISMD_SUCCESS ) {
         result = 0;
      }
      return result;
   }
      
      
   /**
   @brief <H3>Description:</H3>
   The resume function we register with the power management driver. 
   It gets called whenever the system requests a change in the resumed state. 
   
   
   @param[in] dev       : pci device , currently ignored.
   
   @retval 0            : successfully.
   @retval -EBUSY       : failed
   
   <H3>Algorithm:</H3>
   */
   int 
   ismd_clock_resume( struct pci_dev *dev)
   {
      int result = -EBUSY;
      ismd_result_t smd_result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
   
      /** set clock power state to D0. */   
      smd_result = ismd_clock_set_power_state( ICEPM_D0 );
      if ( smd_result == ISMD_SUCCESS ) {
         result = 0;
      }
   
      return result;
   }

   //-----------------------------------------------------------------------------
   /**
   @brief <H3>Description:</H3>
   Test api to put the device to suspend state
   
   @param[in]                          : void

   @retval ISMD_SUCCESS                : Suspend successfully.
   @retval ISMD_ERROR_OPERATION_FAILED : Suspend failed
   
   <H3>Algorithm:</H3>
   */
   ismd_result_t 
   ismd_clock_suspend_test(void)
   {
      int pm_ret;
      ismd_result_t result = ISMD_SUCCESS;
      struct pci_dev *dev = NULL;
      pm_message_t state;
      
      //----------------------------------
      /** Suspend the clock device */
      pm_ret = ismd_clock_suspend(dev, state);
      if(pm_ret == 0) {
         result = ISMD_SUCCESS;
      } else {
         result = ISMD_ERROR_OPERATION_FAILED;
      }
      return result;
   }
   
   //-----------------------------------------------------------------------------
   /**
   @brief <H3>Description:</H3>
   Test api to resume the device from suspend state

   @param[in]                          : void   

   @retval ISMD_SUCCESS                : Resume successfully.
   @retval ISMD_ERROR_OPERATION_FAILED : Resume failed
   
   <H3>Algorithm:</H3>
   */
   ismd_result_t 
   ismd_clock_resume_test(void)
   {
      int pm_ret;
      ismd_result_t result = ISMD_SUCCESS;

      //----------------------------------
      /** Resume the clock device */
      pm_ret = ismd_clock_resume(NULL);
      if(pm_ret == 0) {
         result = ISMD_SUCCESS;
      } else {
         result = ISMD_ERROR_OPERATION_FAILED;
      }
      return result;
   }

#endif



//-----------------------------------------------------------------------------
/**
@brief <H3>Description:</H3>
This function initializes the power management function and register callback to icepm

@param[in]                        : void

@retval ISMD_SUCCESS              : Initialization successful
@retval <anything else>           : Initialization failed

<H3>Algorithm:</H3>
*/
ismd_result_t
ismd_clock_pm_init (void) 
{
   ismd_result_t result = ISMD_SUCCESS;

   /** Set the power state to "full on"*/
   pm_power_state = ICEPM_D0;
   pm_is_suspending = false;

   #ifdef CLOCK_POWER_MANAGEMENT
   {   
      icepm_ret_t icepm_result = ICEPM_OK;
      /** Register this module with the power management driver. */
      pm_functions.suspend = ismd_clock_suspend;
      pm_functions.resume  = ismd_clock_resume;
      icepm_result = icepm_device_register( DEVICE_NAME, 
                      &pm_functions );
      
      if ( icepm_result != ICEPM_OK ) {
         result = ISMD_ERROR_OPERATION_FAILED;
      }
   }
   #endif

   return result;
}


//-----------------------------------------------------------------------------
/**
@brief <H3>Description:</H3>
This function deinitializes the power management function.
Unregister callback to icepm

@param[in] : void

@retval void

<H3>Algorithm:</H3>
*/
void
ismd_clock_pm_deinit(void) 
{
   #ifdef CLOCK_POWER_MANAGEMENT
      //----------------------------------
      /** Unregister this module with from power management driver. */
      icepm_device_unregister( DEVICE_NAME );
   #endif
}

/*@}*/

