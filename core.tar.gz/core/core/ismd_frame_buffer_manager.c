/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2006-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core.h"
#include "ismd_core_protected.h"
#include "smd_core_local_defs.h"
#include "ismd_core.h"

static int system_stride = 2048; // 2048 is the default stride value, the actual value will be read from platform_config during ismd_frame_buffer_init

#define WIDTH_SHIFT	16	        // number of bits to shift width when storing in or extracting from size
#define HEIGHT_MASK	(0xFFFF)	// bit mask to apply to height when extracting from size

   /// @file
   /// Memory management strategy:
   ///
   /// All available frame buffer memory is split up into regions.  Each region is
   /// a fixed size "page" of memory that can be split up into individual frame
   /// buffers.  All regions are the same size, and the size is currently defined
   /// as system_stride*2176  (2176 gives enough lines to handle a 1080P
   /// 4:2:2 buffer) <br>
   /// memory map:   <pre>
   ///           __________
   ///       top|  frame  | <- this will be split into frame regions
   ///          |  frame  | <- this will be split into frame regions
   ///          |non-frame|
   ///          |  frame  | <- this will be split into frame regions
   ///          |    OS   |
   ///          |____OS___|
   /// </pre>
   /// The actual splitting of the frame memory in the layout into the regions
   /// is handled inside of the ismd buffer manager, this code just asks for
   /// regions when it needs them.
   ///
   /// Once a frame buffer region is acquired from the buffer manager, it is split up into
   /// a series of chunks, all the same size. 
   /// For ISMD_FRAME_ALLOCATION_TYPE_NORMAL type, the region is split into chunks which
   /// have the same size with one specified buffer.
   /// For ISMD_FRAME_ALLOCATION_TYPE_INTERMEDIATE_YUV type, it is split into fixed size 
   /// chunks (1280x272). In this region, up to 16 chunks will be allocated to one buffer
   /// for full HD video. For 720x480 video, only need to allocate 4 chunks.
   /// For ISMD_FRAME_ALLOCATION_TYPE_INTERMEDIATE_MH type, it is split into fixed size
   /// chunks (1280x136). In this region, up to 8 chunks will be allocated to one buffer
   /// for full HD video. For 720x480 video, only need to allocate 2 chunks.
   ///
   /// region split up into 720x480 4:2:2 buffers in ISMD_FRAME_ALLOCATION_TYPE_NORMAL 
   /// type region:
   /// <pre>
   /// offset 0 ______________________________________________
   ///         |       |       |       |       |       |XXXXX|
   ///         | W=720 |       |       |       |       |XXXXX|
   ///         | H=960 |       |       |       |       |XXXXX|
   ///         |       |       |       |       |       |XXXXX|
   ///         |   1   |   2   |   3   |   4   |   5   |XXXXX|
   ///         |       |       |       |       |       |XXXXX|
   ///         |       |       |       |       |       |XXXXX|
   ///         |_______|_______|_______|_______|_______|XXXXX|
   ///         |       |       |       |       |       |XXXXX|
   ///         |       |       |       |       |       |XXXXX|height = 2176 lines
   ///         |       |       |       |       |       |XXXXX|
   ///         |       |       |       |       |       |XXXXX|
   ///         |   6   |   7   |   8   |   9   |  10   |XXXXX|
   ///         |       |       |       |       |       |XXXXX|
   ///         |       |       |       |       |       |XXXXX|
   ///         |_______|_______|_______|_______|_______|XXXXX|
   ///         |XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|
   ///         |XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX|
   ///                      stride = width = 2048
   /// </pre>
   /// The XXXX represents space that is wasted because the buffers don't fit
   /// perfectly into the dimensions of the region.  Also keep in mind that the
   /// picture isn't exactly like this as some padding may be inserted between
   /// buffers to try to keep them aligned to tile boundaries.
   ///
   /// The reason that all buffers
   /// within a single region are the same size is to minimize the chance of
   /// fragmentation.  These buffers are then allocated from this region until
   /// a new size is needed or the region is totally allocated, at which time a
   /// new region is allocated and split up.
   /// Once all buffers in a region have been freed, the region memory is
   /// released back to the ismd memory manager.

 // For doxygen formatting help see:
 // http://www.stack.nl/~dimitri/doxygen/htmlcmds.html

/// defines that determine the size of internal structures.
/// Making these smaller may prevent the code from handling lots of tiny buffers
/// in a huge memory region (with a large stride) and making these too large
/// takes up space.
#define MAX_REGIONS        (120) ///< How many regions can exist.  A region is
                                 ///<    created for each frame buffer memory
                                 ///<    obtained from the core.  At 4k
                                 ///<    per stride, these represent 8.5MB for
                                 ///<    each 2176 line regions
#define MAX_FRAMES_V       (40)  ///< Each region is split up into rows and
                                 ///<    columns of frame buffers.  There is an
                                 ///<    array to track the status of each element
                                 ///<    in this 2-D map, and this determines its
                                 ///<    size.
#define MAX_FRAMES_H       (40)  ///< The horizontal component of the array size
                                 ///<    mentioned in the above comment.

// The linear size of each block that the frame memory is carved into.
#define FRAME_REGION_BLOCK_SIZE (system_stride * FRAME_REGION_BLOCK_HEIGHT)

// The stride defined for motion history (MH) memory region.
// In YUV and MH memory region, allocate 20 bits for each pixel.
#define MEM_REGION_YUV_STRIDE  ((system_stride * 20 + 7) / 8) 
#define MEM_REGION_MH_STRIDE   ((system_stride * 20 + 7) / 8) 

// define the chunk size of YUV and MH buffer.
// For YUV buffer, memory region is split to 24 chunks.
// For MH buffer, memory region is split to 48 chunks.
#define MAX_YUV_BUFFER_HEIGHT  (1088)
#define YUV_CHUNK_HEIGHT       ((MAX_YUV_BUFFER_HEIGHT + 3) / 4)
#define YUV_CHUNK_WIDTH        ((MEM_REGION_YUV_STRIDE + 3) / 4)
#define MH_CHUNK_HEIGHT        ((MAX_YUV_BUFFER_HEIGHT + 7) / 8)
#define MH_CHUNK_WIDTH         ((MEM_REGION_MH_STRIDE + 3) / 4)

/// Each element in the array used to track which framebuffers of a region are used
/// have this structure.
typedef struct {
   bool                       in_use; ///< If this location is currently
                                      ///<    allocated, this will be true.
   ismd_buffer_descriptor_t  *buf;    ///< If this location is currently allocated,
                                      ///<    this will be the buffer descriptor
                                      ///<    for the frame buffer.
} alloc_map_element_t;



// Each region is represented by this structure.
typedef struct {
   bool                       in_use;           ///< Is this region structure
                                                ///<    currently in use.
   int                        context;          ///< Context this region belongs
                                                ///<    to.
   ismd_buffer_descriptor_t  *mem_descriptor;   ///< Describes the region's
                                                ///<    physical and virtual
                                                ///<    memory.  This is
                                                ///<    allocated from the ismd
                                                ///<    buffer manager.
   size_t                     frame_width;      ///< Width of frames this region
                                                ///<    is split up to handle.
   size_t                     frame_height;     ///< Height of frames this region
                                                ///<    is split up to handle.
   size_t                     allocated_width;  ///< Width of actual regions
                                                ///<    region is split into.
                                                ///<    This may be larger than
                                                ///<    the frame width if
                                                ///<    padding is needed.
   size_t                     allocated_height; ///< Height of actual regions
                                                ///<    region is split into.
                                                ///<    This may be larger than
                                                ///<    the frame height if
                                                ///<    padding is needed.
   unsigned int               buffers_v;        ///< How many vertical splits
                                                ///<    fit in the region.
   unsigned int               buffers_h;        ///< How many horizontal splits
                                                ///<    fit in the region.
   alloc_map_element_t        allocation_table[MAX_FRAMES_V][MAX_FRAMES_H];
   frame_allocation_type_t    type;             ///<Type this region belongs to.
} mem_region_t;

// Top level frame buffer manager context structure.
typedef struct {
   os_mutex_t      lock;                   ///< All accesses are mutexed.
   mem_region_t   regions[MAX_REGIONS];   ///< List of populated and non-populated
                                          ///<    region descriptors.
} fbm_context_t;
static fbm_context_t fbm_context;


// This indicates whether or not the frame buffer manager has been initialized.
static bool fbm_initialized = false;


   // There are three external tasks exposed here:
   //       * init (ismd_frame_buffer_init),
   //       * alloc (ismd_frame_buffer_alloc,
   //                ismd_frame_buffer_alloc_with_context),
   //       * and free (ismd_frame_buffer_free).
   // ismd_frame_buffer_init does not need to call any subroutines since it is
   // fairly simple.
   // ismd_frame_buffer_alloc, however, needs to call out several functions:
   //       * find region to allocate from (fbm_find_nonfull_region),
   //       * add new region (fbm_add_region),
   //       * and allocate buffer from region (fbm_alloc_from_region).
   // ismd_frame_buffer_free also uses a helper function:
   //       * free buffer from region (fbm_free_from_region)


// Prototypes for private local functions

/// Allocates an SMD frame buffer from the media buffer address (specified in the
/// \ref platform_config memory_layout).
/// This is a special variant of ismd_frame_buffer_alloc() that is
/// to be used if a frame buffer needs to be associated with a context.  A context
/// is a way to indicate that buffers from another context can't share the same
/// area of memory as buffers from this context.
/// The reason for doing this is to keep one context's buffers from mixing with
/// another stream's buffers, in order to avoid fragmentation.  
/// 
/// @retval ISMD_SUCCESS : the buffer was successfully allocated.
/// @retval ISMD_ERROR_NO_RESOURCES :  not enough resources existed to allocate
/// the buffer.
/// @retval ISMD_ERROR_OPERATION_FAILED : the frame buffer manager was not yet
/// initialized - ismd_core_init did not complete.
/// @retval ISMD_ERROR_INVALID_PARAMETER
static ismd_result_t ismd_typed_buffer_alloc_with_context(
                                       size_t                     width,
                                       size_t                     height,
                                       int                        context,
                                       ismd_buffer_handle_t      *buffer,
                                       frame_allocation_type_t    region_type);


/// Search all occupied frame buffer region descriptors for one that matches the
/// specified size and context.  For each one that is found, its allocation table
/// is checked to see if there are any openings.  The first region found with an
/// opening is returned.
/// If NULL is returned, then there are no regions with the specified size or all
/// regions with the specified size are full.
/// fbm_context must be locked before calling this function.
static mem_region_t *fbm_find_nonfull_region(size_t width, size_t height, int context,
                                   frame_allocation_type_t region_type);

                                    

/// This function will add a new frame buffer region descriptor to the list for the supplied
/// memory descriptor (ismd buffer descriptor) and specified frame buffer width
/// and height.  This performs the splitting of the region into chunks that
/// buffer allocaions will allocate from.  If the supplied region pointer is not
/// NULL then it will be initialized with the newly created region.
///
/// This can fail for several reasons:
///       * there are no more free region descriptors,
///       * the memory can't hold the specified sized-buffer,
///       * the memory is not aligned properly (stride and tile-aligned),
///       * the allocation table is not big enough,
static ismd_result_t fbm_add_region(ismd_buffer_descriptor_t *mem_descriptor,
                                    size_t width,  size_t height, int context,
                                    mem_region_t **region, 
                                    frame_allocation_type_t region_type);


/// This will allocate a frame buffer from the specified frame buffer region.  It is
/// supplied with the region descriptor to allocate from, a pointer to
/// the returned buffer descriptor, and a blank buffer descriptor to fill
/// in before returning.  If this succeeds, the buffer argument will
/// point to the new_desc argument after that buffer has been initialized
/// with the frame information.
/// The size of the buffer is determined by the buffer size indicated in the
/// region descriptor.
///
/// This can fail if:
///       * there is no room in the region to allocate a buffer
///         (allocation table is full).
static ismd_result_t fbm_alloc_from_region(mem_region_t *region,
                                           ismd_buffer_descriptor_t **buffer,
                                           ismd_buffer_descriptor_t *new_desc,
                                           size_t width, size_t height);

/// This function performs all operations necessary to find which frame buffer region
/// contains the buffer and to clear the entry in the region's allocation table
/// that this buffer used.  If the region's allocation table is empty after it is
/// modified, then the region is freed.
///
/// This can fail if:
///       * The supplied buffer could not be found in any region.
///       * There was an error with freeing the region's memory.
static ismd_result_t fbm_free_from_region(ismd_buffer_descriptor_t *buffer,
                                          fbm_context_t *context);


/// Searches all region descriptors and returns the first unused one.
static mem_region_t *fbm_find_empty_region(fbm_context_t *context);



/// Searches for an unused spot in the supplied frame buffer allocation table.  If an unused
/// spot is found, true is returned.  If there are no unused spots false is
/// returned.  If empty_r is non-NULL it will be initialized to the row of the
/// empty spot if there is an empty spot (-1 otherwise).  empty_c is treated like
/// empty_r but it represents the column coordinate.
static bool fbm_find_open_spot (unsigned int rows, unsigned int cols,
                                alloc_map_element_t table[][MAX_FRAMES_H],
                                unsigned int *empty_r, unsigned int *empty_c);


/// Searches for an unused spot in the supplied intermediate allocation table.  If an unused
/// spot is found, true is returned.  If there are no unused spots false is
/// returned.  If empty_r is non-NULL it will be initialized to the row of the
/// empty spot if there is an empty spot (-1 otherwise).  empty_c is treated like
/// empty_r but it represents the column coordinate.
static bool fbm_find_open_intermediate_spot (mem_region_t *region,
                                unsigned int *empty_r, unsigned int *empty_c,
                                unsigned int *row_count, unsigned int *col_count,
                                size_t width, size_t height);


/// Searches for the supplied buffer in the supplied frame buffer allocation table.  If the
/// buffer is found, the region containing the buffer is returned.  NULL is
/// returned if the buffer was not found in any region.
/// If table_r is non-NULL it will be initialized to the row of the buffer if
/// the buffer was found (-1 otherwise).  table_c is treated like
/// table_r but it represents the column coordinate.
static mem_region_t *fbm_find_buffer(ismd_buffer_descriptor_t *buffer,
                                     fbm_context_t *context,
                                     unsigned int *table_r,
                                     unsigned int *table_c);


/// Will return true if there are no used spots in the supplied allocation
/// table.  If any spot is used, false is returned.
static bool fbm_is_table_empty (unsigned int rows, unsigned int cols,
                                alloc_map_element_t table[][MAX_FRAMES_H]);

/// Frees the memory belonging to the region and marks the region descriptor as
/// unused.
static ismd_result_t fbm_free_region(mem_region_t *region);


/// Utilities used to get and release the lock for the fbm context.
static void fbm_context_lock(fbm_context_t *context);
static void fbm_context_unlock(fbm_context_t *context);


////////////////////
// exposed functions
////////////////////

/// Initialize the frame buffer manager.  This must be called before alloc or
/// free are called.  This is not meant to be exposed to any clients, but is
/// to be used internally to the ismd core.
/// This should be called by the ismd_buffer_manager_init function to initialize
/// this portion of the buffer manager.
/// This initializes the fbm's structures to an empty state and does not perform
/// any memory allocation.  The only resource allocated here is the lock for the
/// context structure.
///
/// This can fail if:
///       * The FBM is already initialized.
ismd_result_t
ismd_frame_buffer_init(void)
{
   ismd_result_t             result = ISMD_SUCCESS;
   int i;

   ISMD_LOG_MSG(4, "%s(): entering function.\n", __func__);

   system_stride = SYSTEM_STRIDE;
   // Fail if already initialized.
   if (fbm_initialized == true) {
      result = ISMD_ERROR_ALREADY_INITIALIZED;
      ISMD_LOG_MSG(2, "%s(): Warning: Frame buffer manager already initialized.\n", __func__);
   } else {
      fbm_initialized = true;

      // Create context lock.
      os_mutex_init( &(fbm_context.lock) );

      // All regions are not in use.
      for (i = 0; i < MAX_REGIONS; i++) {
         fbm_context.regions[i].in_use = false;
      }
   }

   if (result == ISMD_SUCCESS) {
      ISMD_LOG_MSG(2, "%s(): Info: Frame Buffer manager initiailzed successfully.\n", __func__);
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return (result);
}

// Simple de-init routine
ismd_result_t
ismd_frame_buffer_deinit(void)
{
   ismd_result_t             result = ISMD_SUCCESS;

   // TODO: Do a more thorough cleanup here.
   fbm_initialized = false;
   return (result);
}


// Buffer allocation - this is a client-exposed interface.
// See function header comment in ismd_core.h
ismd_result_t
ismd_frame_buffer_alloc(size_t width, size_t height,
                        ismd_buffer_handle_t *buffer)
{
   return ismd_frame_buffer_alloc_with_context(width, height, 0, buffer);
}

// Intermediate buffer allocation - this is a client-exposed interface.
// See function header comment in ismd_core_protected.h
ismd_result_t
ismd_intermediate_buffer_alloc(size_t width, size_t height,
                        ismd_buffer_handle_t *buffer, 
                        frame_allocation_type_t region_type)
{
   return ismd_typed_buffer_alloc_with_context(width, height, 0, buffer, region_type);
}

//#define ENABLE_FB_COUNT
#ifdef ENABLE_FB_COUNT
static unsigned fb_count = 0;
#endif

// Normal frame buffer allocation - this is a client-exposed interface.
// See function header comment in ismd_core.h
ismd_result_t
ismd_frame_buffer_alloc_with_context(size_t width, size_t height,
                                     int context,
                                     ismd_buffer_handle_t *buffer)
{
   return ismd_typed_buffer_alloc_with_context(width, height, context, buffer, ISMD_FRAME_ALLOCATION_TYPE_NORMAL);
}


// See documentation at function prototype.
static ismd_result_t
ismd_typed_buffer_alloc_with_context(size_t width, size_t height,
                                     int context,
                                     ismd_buffer_handle_t *buffer,
                                     frame_allocation_type_t region_type)
{
   ismd_result_t              result = ISMD_SUCCESS;
   mem_region_t              *region;
   ismd_buffer_descriptor_t  *new_region_mem;
   ismd_buffer_descriptor_t  *new_buf_desc = NULL;
   ismd_buffer_descriptor_t  *buffer_desc = NULL;

   ISMD_LOG_MSG(4, "%s(): entering function.\n", __func__);

   // check for bad params or lack of initialization.
   if ( width < 1 || height < 1 || !buffer) {
      ISMD_LOG_MSG( 1, "%s(): Error: Width or height is 0 or buffer is NULL\n", __func__);
      result = ISMD_ERROR_INVALID_PARAMETER;
   } else if (!fbm_initialized) {
      ISMD_LOG_MSG(1, "%s(): Error: Frame buffer manager not yet initialized\n", __func__);
      result = ISMD_ERROR_OPERATION_FAILED;
   } else {

      // Try and allocate a blank descriptor.  This descriptor will be
      // initialized with the frame buffer info (address, size) if allocation
      // succeeds and ultimately is what'll get returned to the client.
      result = ismd_buffer_alloc_typed_pmr_direct(ISMD_BUFFER_TYPE_PHYS, 0, &new_buf_desc, ISMD_PMR_NONE);
      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG(1, "%s(): Error: ismd_buffer_alloc_typed_pmr_direct failed for new descriptor\n", __func__);
         new_buf_desc = NULL;
      } else {
      // This next section is concerned with actually finding the frame
      // buffer memory to use for this new buffer, if there is any.

         fbm_context_lock(&fbm_context);

         // Look for a region of memory that has already been split into some chunks.
         region = fbm_find_nonfull_region(width, height, context, region_type);
         if (region == NULL) {

            // No specified type region with this size exists, or all of them are already
            // totally allocated to other frame buffers.  Try to create a new
            // region. 
            //TODO figure out which pmr this should be
            result = ismd_buffer_alloc_typed_pmr_direct(
                                          ISMD_BUFFER_TYPE_VIDEO_FRAME_REGION,
                                          FRAME_REGION_BLOCK_SIZE,
                                          &new_region_mem,
                                          ISMD_PMR_NONE);
            if (result != ISMD_SUCCESS) {
               ISMD_LOG_MSG(1, "%s(): Error: Could not allocate new memory region\n", __func__);
            } else {

               // Add the new memory as a region and save a pointer to it.
               result = fbm_add_region(new_region_mem, width, height, context, &region, region_type);
               if (result != ISMD_SUCCESS) {
                  ISMD_LOG_MSG(1, "%s(): Error: Could not add new memory region\n", __func__);
                  ismd_buffer_free(new_region_mem->unique_id);
               }
            }
         }

         // If we still do not have a region, it means that there were none
         // to begin with and our attempt to create a new one failed.
         if (region == NULL) {
            ISMD_LOG_MSG(1, "%s(): Error: Could not find or create memory region\n", __func__);
            result = ISMD_ERROR_NO_RESOURCES;
         } else {

            // Allocate the buffer from the region.
            result = fbm_alloc_from_region(region, &buffer_desc, new_buf_desc, width, height);
            if (result != ISMD_SUCCESS) {
               ISMD_LOG_MSG(1, "%s(): Error: fbm_alloc_from_region failed\n", __func__);
            }
         }
         fbm_context_unlock(&fbm_context);
      }
   }

   // Free the new buffer descriptor if things didn't go well.
   if ((result != ISMD_SUCCESS) && (new_buf_desc != NULL)) {
      ismd_buffer_free(new_buf_desc->unique_id);
   }

   if (result == ISMD_SUCCESS) {
      *buffer = buffer_desc->unique_id;
#ifdef ENABLE_FB_COUNT
      fb_count++;
      smd_core_send_sven_event( SMD_CORE_DEBUG_UNIT_BUFFER,
                                SVEN_EV_SMDCore_Buf_fb_count,
                                fb_count,
                                region,
                                0, 0, 0, 0xFB007AC0 );
#endif //def ENABLE_FB_COUNT
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return (result);
}


/// Free a frame buffer back to the frame buffer manager.
/// This is not meant to be exposed to any clients, but is
/// to be used internally to the ismd core.
/// Note that this function is supposed to be called from within a lock,
/// with the buffer list for size 0 being locked.
/// This will totally free a region if the buffer being freed is the last one
/// being used in the region.
///
/// This can fail if:
///       * The FBM is not initialized.
///       * The buffer could not be found in any region.
///       * There was an error when freeing the empty descriptor.
///       * There was an error when freeing the region memory.
ismd_result_t
ismd_frame_buffer_free(ismd_buffer_descriptor_t *buffer)
{
   ismd_result_t result = ISMD_SUCCESS;

   ISMD_LOG_MSG(4, "%s(): entering function.\n", __func__);

   // Fail if not initialized or wrong buffer type received.
   if (!fbm_initialized) {
      ISMD_LOG_MSG(1, "%s(): Error: FBM not yet initialized\n", __func__);
      result = ISMD_ERROR_OPERATION_FAILED;
   } else if (buffer->buffer_type != ISMD_BUFFER_TYPE_VIDEO_FRAME) {
      ISMD_LOG_MSG(1, "%s(): Error: Buffer is not a freme buffer\n", __func__);
      result = ISMD_ERROR_OPERATION_FAILED;
   } else if (buffer->state != ISMD_BUFFER_STATE_ALLOCATED) {
      ISMD_LOG_MSG(1, "%s() : Error: buffer %x is not in allocated state.\r\n", __func__, buffer->unique_id );
      result = ISMD_ERROR_INVALID_HANDLE;
   } else {

      // Do the actual removing of the buffer from the allocation table, and
      // possibly free the region if it's empty.
      fbm_context_lock(&fbm_context);
      result = fbm_free_from_region(buffer, &fbm_context);
      fbm_context_unlock(&fbm_context);

      if (result != ISMD_SUCCESS) {
         ISMD_LOG_MSG(1, "%s(): Error freeing buffer from region.\n", __func__);
      } else {

         /* Free the blank descriptor.  use the internal (non-locking) implementation
         because the buffer list was already locked by the calling function. */
         buffer->phys.size = 0;
         buffer->buffer_type = ISMD_BUFFER_TYPE_PHYS;
         ismd_buffer_free_internal(buffer->unique_id);
#ifdef ENABLE_FB_COUNT
         fb_count--;
#endif //def ENABLE_FB_COUNT
      }
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return (result);
}


//////////////////////////
// Local private functions
//////////////////////////


// See documentation at function prototype.
static mem_region_t *
fbm_find_nonfull_region(size_t width, size_t height, int context,
                                     frame_allocation_type_t region_type)
{
   int            desc_num;
   mem_region_t  *ret = NULL;
   mem_region_t  *region;

   ISMD_LOG_MSG(4, "%s(): entering function.\n", __func__);

   // Search each in use region descriptor - if the size and type matches then check if
   // there are any open spots in the allocation table.  If yes, use this
   // region.
   for (desc_num = 0; desc_num < MAX_REGIONS; desc_num++) {
      region = &fbm_context.regions[desc_num];

      if ((region->in_use) &&
          (region->context == context) &&
          (region->type == region_type)) {
         if ((region_type == ISMD_FRAME_ALLOCATION_TYPE_NORMAL)) {
            if ((region->frame_width == width) &&
                (region->frame_height == height)) {
               if (fbm_find_open_spot(region->buffers_v, region->buffers_h,
                                      region->allocation_table,
                                      NULL, NULL)) {
                  ret = region;
                  break;
               }
            }
         } else {
            if (fbm_find_open_intermediate_spot(region, NULL, NULL,
                                   NULL, NULL, width, height)) {
               ret = region;
               break;
            }
         }
      }
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return (ret);
}


// See documentation at function prototype.
static ismd_result_t
fbm_add_region(ismd_buffer_descriptor_t *mem_descriptor,
               size_t width, size_t height, int context,
               mem_region_t **region, frame_allocation_type_t region_type)
{
   unsigned int   region_height;
   unsigned int   region_starting_line, region_starting_col;
   unsigned int   allocation_height, allocation_width;
   unsigned int   num_buffers_v = 0, num_buffers_h = 0;
   unsigned int   row, col;
   unsigned int   region_stride;
   mem_region_t  *new_region = NULL;
   ismd_result_t  result = ISMD_SUCCESS;

   ISMD_LOG_MSG(4, "%s(): entering function.\n", __func__);

   // Set some region parameters according the region type.
   if (region_type == ISMD_FRAME_ALLOCATION_TYPE_INTERMEDIATE_YUV) {
      region_stride = MEM_REGION_YUV_STRIDE;
      allocation_height = YUV_CHUNK_HEIGHT;
      allocation_width = YUV_CHUNK_WIDTH;
   } else if (region_type == ISMD_FRAME_ALLOCATION_TYPE_INTERMEDIATE_MH) {
      region_stride = MEM_REGION_MH_STRIDE;
      allocation_height = MH_CHUNK_HEIGHT;
      allocation_width = MH_CHUNK_WIDTH;
   } else {
      region_stride = system_stride;
      allocation_height = height;
      allocation_width = width;
   }
      
   // Check that the memory region is of sufficient size.
   region_height = mem_descriptor->phys.size / region_stride;
   if ((height > region_height) || (width > region_stride)) {
      ISMD_LOG_MSG(1, "%s(): Supplied memory not big enough for specified size.\n", __func__);
      result = ISMD_ERROR_NO_RESOURCES;
   } else {

      // Check that the supplied buffer is aligned to a tile.
      // The horizontal line address of the buffer must be aligned to the top
      // of a tile, and the buffer should start at the beginning of that line.
      region_starting_line = mem_descriptor->phys.base / system_stride;
      region_starting_col  = mem_descriptor->phys.base % system_stride;
      if (((region_starting_line % TILE_V) != 0)  ||
           (region_starting_col != 0)) {
         ISMD_LOG_MSG(1, "%s(): Error: Region is not vertically aligned to a tile frame memory region in layout should be multiple of %d\n", __func__, (TILE_V * system_stride));
         result = ISMD_ERROR_OPERATION_FAILED;
      } else {

         // Calculate how big the allocations need to be - this may be larger
         // than the requested size if we need to add padding for alignment.
         num_buffers_v = region_height / allocation_height;
         if ( num_buffers_v > MAX_FRAMES_V ) {
            allocation_height = region_height / MAX_FRAMES_V;
            ISMD_LOG_MSG(2, "allocation_height increased to %d\n", allocation_height );
         }

         if (((allocation_height % TILE_V) != 0) && 
             (region_type == ISMD_FRAME_ALLOCATION_TYPE_NORMAL)) {
            allocation_height += TILE_V - (allocation_height % TILE_V);
         }

         num_buffers_h = region_stride / allocation_width;
         if ( num_buffers_h > MAX_FRAMES_H ) {
            allocation_width = region_stride / MAX_FRAMES_H;
            ISMD_LOG_MSG(2, "allocation_width increased to %d\n", allocation_width );
         }

         if ((allocation_width % TILE_H) != 0) {
            allocation_width += TILE_H - (allocation_width % TILE_H);
         }

         // calculate how many buffers will fit in this block.
         // This will be the dimensions of the allocation table.
         num_buffers_v = region_height / allocation_height;
         num_buffers_h = region_stride / allocation_width;

         // If the static allocation table maximum size can't handle the size
         // this region needs, abort.
         if ((num_buffers_v > MAX_FRAMES_V) || (num_buffers_h > MAX_FRAMES_H)) {
            ISMD_LOG_MSG(1, "%s:%s():%d: Error: allocation table cannot handle this block. %d %d %d %d \n",
               __FILE__, __func__, __LINE__, num_buffers_v, MAX_FRAMES_V, num_buffers_h, MAX_FRAMES_H );
            ISMD_LOG_MSG(1, "region_height %d, mem_descriptor->phys.size %d, system_stride %d\n",
               region_height, mem_descriptor->phys.size, region_stride );
            result = ISMD_ERROR_OPERATION_FAILED;
         }
      }

      // Now find a region descriptor and initialize it
      if (result == ISMD_SUCCESS) {
         new_region = fbm_find_empty_region(&fbm_context);
         if (new_region == NULL) {
            ISMD_LOG_MSG(1, "%s(): Error: no free region descriptors.\n", __func__);
            result = ISMD_ERROR_NO_RESOURCES;
         } else {
            new_region->in_use           = true;
            new_region->context          = context;
            new_region->mem_descriptor   = mem_descriptor;

            if (region_type == ISMD_FRAME_ALLOCATION_TYPE_NORMAL) {
               new_region->frame_width      = width;
               new_region->frame_height     = height;
            } else {
               // For intermediate mem region, frame_width and fram_height represent 
               // the region_stride and region_height.
               new_region->frame_width      = region_stride;
               new_region->frame_height     = region_height;
            }
            
            new_region->allocated_width  = allocation_width;
            new_region->allocated_height = allocation_height;
            new_region->buffers_v        = num_buffers_v;
            new_region->buffers_h        = num_buffers_h;
            new_region->type             = region_type;

            // Clear the allocation table.
            for (row = 0; row < num_buffers_v; row++) {
               for (col = 0; col < num_buffers_h; col++) {
                  new_region->allocation_table[row][col].in_use = false;
               }
            }
         }
      }
   }

   if (region != NULL) {
      *region = new_region;
   }

   if (result == ISMD_SUCCESS) {
      ISMD_LOG_MSG(2, "Created frame region %x-%x for %dx%d buffers context = %d, array_size = %dx%d\n",
                       mem_descriptor->phys.base,
                       mem_descriptor->phys.base + mem_descriptor->phys.size,
                       allocation_width, allocation_height,
                       context, num_buffers_v, num_buffers_h);
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return (result);
}


// See documentation at function prototype.
static ismd_result_t
fbm_alloc_from_region(mem_region_t *region,
                      ismd_buffer_descriptor_t **buffer,
                      ismd_buffer_descriptor_t *new_desc,
                      size_t width, size_t height)
{
   ismd_result_t result = ISMD_SUCCESS;
   unsigned int  row, col;
   unsigned int  row_count, col_count;
   unsigned int  i, j;
   unsigned int  region_stride;
   unsigned int  offset;
   bool          is_spot_available;

   ISMD_LOG_MSG(4, "%s(): entering function.\n", __func__);

   // Find spare chunks in the allocation table.
   if (region->type == ISMD_FRAME_ALLOCATION_TYPE_NORMAL) {
      is_spot_available = fbm_find_open_spot(region->buffers_v, region->buffers_h,
                                             region->allocation_table,
                                             &row, &col);
      row_count = col_count = 1;
      region_stride = system_stride;
   } else {
      is_spot_available = fbm_find_open_intermediate_spot(region, &row, &col,
                                             &row_count, &col_count, width, height);
      region_stride = region->frame_width;
   }
   
   if (is_spot_available) {
      // Mark the specified chunks for new buffer.
      for (j = 0; j < row_count; j++) {
         for (i = 0; i < col_count; i++) {
            region->allocation_table[row+j][col+i].in_use = true;
            region->allocation_table[row+j][col+i].buf = new_desc;
         }
      }

      // Fill in blank buffer attrs, like type, base addr and size, virt
      // pointer.  Calculating offset into region first to simplify things.
      offset = (row * (region_stride * region->allocated_height)) +
               (col * region->allocated_width);

      new_desc->phys.base = region->mem_descriptor->phys.base + offset;
      new_desc->virt.base = region->mem_descriptor->virt.base + offset;
      new_desc->buffer_type = ISMD_BUFFER_TYPE_VIDEO_FRAME;

      // Buffer size is stored in size field as both width and height.
      new_desc->phys.size = (width << WIDTH_SHIFT) |
                            (height & HEIGHT_MASK);


      *buffer = new_desc;

   } else {
      ISMD_LOG_MSG(1, "%s(): Error: allocation table has no openings\n", __func__);
      result = ISMD_ERROR_NO_RESOURCES;
   }

   if (result == ISMD_SUCCESS) {
      ISMD_LOG_MSG(3, "Allocated %dx%d frame buffer from region %x, context = %d",
                        width, height,
                        region->mem_descriptor->phys.base,
                        region->context);
      ISMD_LOG_MSG(3, "location %d,%d (offset %x), id %x\n",
                        row, col, offset, new_desc->unique_id);
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return (result);
}


// See documentation at function prototype.
static ismd_result_t
fbm_free_from_region(ismd_buffer_descriptor_t *buffer,
                     fbm_context_t *context)
{
   ismd_result_t  result = ISMD_SUCCESS;
   unsigned int   row, col;
   unsigned int   width, height;
   unsigned int   chunks_v, chunks_h;
   unsigned int   i, j;
   mem_region_t  *region;
   bool           region_empty = false;

   ISMD_LOG_MSG(4, "%s(): entering function.\n", __func__);

   // Find the region this buffer belongs to, and where in the allocation table
   // it exists.
   region = fbm_find_buffer(buffer, context, &row, &col);
   if (region == NULL) {
      ISMD_LOG_MSG(1, "%s(): Error: could not find buffer in any region.\n", __func__);
      result = ISMD_ERROR_INVALID_RESOURCE;
   } else {
      width  = buffer->phys.size >> WIDTH_SHIFT;
      height = buffer->phys.size & HEIGHT_MASK;

      // Caculate the horizontal and vertical chunks occupied by buffer.
      // For ISMD_FRAME_ALLOCATION_TYPE_NORMAL type, one buffer occupies one chunk.
      // For ISMD_FRAME_ALLOCATION_TYPE_INTERMEDIATE_YUV and 
      // ISMD_FRAME_ALLOCATION_TYPE_INTERMEDIATE_MH type, 
      // one buffer occupies several chunks.
      chunks_h = (width + region->allocated_width - 1) / region->allocated_width;
      chunks_v = (height + region->allocated_height - 1) / region->allocated_height;

      // Remove entry from allocation table
      for (j = 0; j < chunks_v; j++) {
         for (i = 0; i < chunks_h; i++) {
            region->allocation_table[row+j][col+i].in_use = false;
         }
      }

      ISMD_LOG_MSG(3, "Freed %dx%d frame buffer from region %x, context = %d",
                        width, height,
                        region->mem_descriptor->phys.base,
                        region->context);
      ISMD_LOG_MSG(3, "location %d,%d, id %x\n",
                        row, col, buffer->unique_id);

      // Check if the region is now empty.
      region_empty = fbm_is_table_empty(region->buffers_v, region->buffers_h,
                                        region->allocation_table);

      // If it's empty, free it.
      if (region_empty) {
         result = fbm_free_region(region);
         if (result != ISMD_SUCCESS) {
            ISMD_LOG_MSG(1, "%s(): Error: error with erturning region's memory.\n", __func__);
         }
      }
   }

   ISMD_LOG_MSG(4, "%s(): exiting function.\n", __func__);

   return (result);
}


// See documentation at function prototype.
static mem_region_t *
fbm_find_empty_region(fbm_context_t *context)
{
   int            desc_num;
   mem_region_t  *ret = NULL;

   for (desc_num = 0; desc_num < MAX_REGIONS; desc_num++) {
      if (context->regions[desc_num].in_use == false) {
         ret = &(context->regions[desc_num]);
         break;
      }
   }

   return (ret);
}


// See documentation at function prototype.
static bool
fbm_find_open_spot(unsigned int rows, unsigned int cols,
                   alloc_map_element_t table[][MAX_FRAMES_H],
                   unsigned int *empty_r, unsigned int *empty_c)
{
   unsigned int row = 0, col = 0;
   bool         ret = false;

   for (row = 0; row < rows; row++) {
      for (col = 0; col < cols; col++) {
         if (table[row][col].in_use == false) {
            ret = true;
            break;
         }
      }
      if (ret) {
         break;
      }
   }
   if (empty_r != NULL) {
      *empty_r = (ret) ? row : 0xFFFFFFFF;
   }
   if (empty_c != NULL) {
      *empty_c = (ret) ? col : 0xFFFFFFFF;
   }

   return (ret);
}


// See documentation at function prototype.
static bool
fbm_find_open_intermediate_spot(mem_region_t *region,
                   unsigned int *empty_r, unsigned int *empty_c,
                   unsigned int *row_count, unsigned int *col_count,
                   size_t width, size_t height)
{
   unsigned int row = 0, col = 0;
   unsigned int chunks_v, chunks_h;
   unsigned int i = 0, j = 0;
   bool         ret = false;

   // Caculate the number of chunks which will be allocated for intermediate buffer 
   // with specified width and height. 
   chunks_h = (width + region->allocated_width - 1) / region->allocated_width;
   chunks_v = (height + region->allocated_height - 1) / region->allocated_height;

   // Find consecutive open chunks for intermediate buffer with specified size
   for (row = 0; row < (region->buffers_v - chunks_v + 1); row++) {
      for (col = 0; col < (region->buffers_h - chunks_h + 1); col++) {
         if (region->allocation_table[row][col].in_use == false) {
            // If find one open chunk, then search the adjacent chunks to see 
            // if they are open too.
            for (j = 0; j < chunks_v; j++) {
               for (i = 0; i < chunks_h; i++) {
                  if (region->allocation_table[row+j][col+i].in_use == true) {
                     break;
                  }
               }

               if (i < chunks_h) {
                  break;
               }
            }

            if (i == chunks_h && j == chunks_v) {
               ret = true;
               break;
            }
         }
      }
      if (ret) {
         break;
      }
   }

   if (row_count != NULL) {
      *row_count = (ret) ? chunks_v : 0;
   }
   if (col_count != NULL) {
      *col_count = (ret) ? chunks_h : 0;
   }
   if (empty_r != NULL) {
      *empty_r = (ret) ? row : 0xFFFFFFFF;
   }
   if (empty_c != NULL) {
      *empty_c = (ret) ? col : 0xFFFFFFFF;
   }

   return (ret);
}


// See documentation at function prototype.
static mem_region_t *
fbm_find_buffer(ismd_buffer_descriptor_t *buffer,
                fbm_context_t *context,
                unsigned int *table_r,
                unsigned int *table_c)
{
   mem_region_t *region = NULL;
   unsigned int  desc_num;
   unsigned int  width, height;
   unsigned int  row = 0, col = 0;
   bool          found_buffer = false;

   width  = buffer->phys.size >> WIDTH_SHIFT;
   height = buffer->phys.size & HEIGHT_MASK;

   for (desc_num = 0; desc_num < MAX_REGIONS; desc_num++) {
      region = &context->regions[desc_num];

      if ((region->in_use) &&
          ((region->frame_width == width && region->frame_height == height) ||
          (region->type != ISMD_FRAME_ALLOCATION_TYPE_NORMAL))) {

         // It might be in this region.  Search the region's allocation table
         // for this descriptor.
         for (row = 0; row < region->buffers_v; row++) {
            for (col = 0; col < region->buffers_h; col++) {
               if (region->allocation_table[row][col].in_use && (region->allocation_table[row][col].buf == buffer)) {
                  found_buffer = true;
                  break;
               }
            }
            if (found_buffer) {
               break;
            }
         }
      }
      if (found_buffer) {
         break;
      }
   }

   if (table_r != NULL) {
      *table_r = (found_buffer) ? row : 0xFFFFFFFF;
   }
   if (table_c != NULL) {
      *table_c = (found_buffer) ? col : 0xFFFFFFFF;
   }

   if (!found_buffer) {
      return NULL;
   }

   return region;
}


// See documentation at function prototype.
static bool
fbm_is_table_empty(unsigned int rows, unsigned int cols,
                   alloc_map_element_t table[][MAX_FRAMES_H])
{
   bool              found_buffer = false;
   unsigned int      row, col;

   for (row = 0; (row < rows) && (!found_buffer); row++) {
      for (col = 0; col < cols; col++) {
         if (table[row][col].in_use) {
            found_buffer = true;
            break;
         }
      }
   }

   return (!found_buffer);
}


// See documentation at function prototype.
static ismd_result_t
fbm_free_region(mem_region_t *region)
{
   ismd_result_t result = ISMD_SUCCESS;

   ISMD_LOG_MSG(2, "Freeing frame memory region %x-%x for %dx%d buffers, context = %d.\n",
                     region->mem_descriptor->phys.base,
                     region->mem_descriptor->phys.base +
                     region->mem_descriptor->phys.size,
                     region->frame_width, region->frame_height,
                     region->context);

   /* Not using unlocked version, the buffer list for size 0
     is locked but the buffer list for frame memory chunks is not. */
   result = ismd_buffer_free(region->mem_descriptor->unique_id);
   if (result != ISMD_SUCCESS) {
      ISMD_LOG_MSG(1, "%s(): Error: error with returning region's memory.\n", __func__);
   } else {
      region->in_use = false;
   }

   return (result);
}


// See documentation at function prototype.
static void
fbm_context_lock(fbm_context_t *context)
{
   os_mutex_lock(&context->lock);
}


// See documentation at function prototype.
static void
fbm_context_unlock(fbm_context_t *context)
{
   os_mutex_unlock(&context->lock);
}
