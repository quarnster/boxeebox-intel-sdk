# Include in shell scripts to define NSPR variables

NSPR_VERSION=@NSPR_VERSION@
NSPR_LIB=-lnspr$NSPR_VERSION
NSPR_EXTRA_LIBS="@EXTRA_LIBS@"
