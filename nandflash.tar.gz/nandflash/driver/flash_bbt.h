/*
 * NAND Flash Controller Device Driver
 * Copyright (c) 2010, Intel Corporation and its suppliers.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms and conditions of the GNU General Public License,
 * version 2, as published by the Free Software Foundation.
 *
 * This program is distributed in the hope it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * this program; if not, write to the Free Software Foundation, Inc., 
 * 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

#include "ffsport.h"

#define GLOB_SBD_IOCTL_ERASE_RAW (0x9910)
#define GLOB_SBD_IOCTL_RD_BT (0x9911)
#define GLOB_SBD_IOCTL_CREATE_BT_DUMMY (0x9912)
#define GLOB_SBD_IOCTL_CREATE_BT_BYERASE (0x9913)
#define GLOB_SBD_IOCTL_CREATE_BT_BYMARKER (0x9914)
#define GLOB_SBD_IOCTL_ERASE_BYMARKER (0x9915)




typedef struct _boot_blocktable_info_tag
{
	byte bt_sig[4];//"GOOD" means a block table exist
	byte nSpareSkipByteInZone1;//Spare area skip byte value in zone 1, default 0
	byte nSpareSkipByteInZone0; //Spare area skip byte value in zone 0, default 0
	byte reserve3;
	byte btEntrySizeInBits;//default to be 0x8, means each block status is represented by 8 bits
	uint16 btEntryNum;//Block table entry number, equal to block number in boot partition
	uint16 btOffsetInBytes;//Block table page offset in byte
	uint16 md5OffsetInBytes;// Md5 hash page offset in byte
	uint16 md5SizeInBytes;//Size of md5 hash
} __attribute__ ((aligned(1), packed)) BOOT_BLOCKTABLE_INFO;

typedef struct _boot_block_table_io_cmd_tag
{
	byte btEntrySizeInBits;//default to be 0x8, means each block status is represented by 8 bits
	uint16 btEntryNum;//Block table entry number, equal to block number in boot partition
    ADDRESSTYPE 	AddrInRam;    // Source Address for Image in SRAM
}BOOT_BLOCKTABLE_IO_CMD;



uint32 GLOB_BBT_Init (void);
void GLOB_BBT_Release (void);
uint16 GLOB_BBT_NAND_Write_Page_Main(byte* read_data,BLOCKNODE block,PAGENUMTYPE page,PAGENUMTYPE page_count);
uint16 GLOB_BBT_NAND_Read_Page_Main(byte* read_data,BLOCKNODE block,PAGENUMTYPE page,PAGENUMTYPE page_count);
uint16 GLOB_BBT_Create_Block_Table_byInitalMarker(void);
uint16 GLOB_BBT_Create_Block_Table_byErase(void);
uint16 GLOB_BBT_Create_Block_Table_Dummy(uint16 wforce);
uint16 GLOB_BBT_Erase_Block_by_BBT(BLOCKNODE blocknum);
uint16 GLOB_BBT_Erase_Block_by_Marker(BLOCKNODE blocknum);//Erase the NAND block by look up intial bad block marker
uint16 GLOB_BBT_IO_Read_Block_Table(BOOT_BLOCKTABLE_IO_CMD* pbtInfo);


