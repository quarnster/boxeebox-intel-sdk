Nandflash is the linux driver for Denali nand flash controller, the driver
module name is spectra.ko after building. 

To build the driver, type the following command.

make all

To clean the driver, type the following command.

make clean

