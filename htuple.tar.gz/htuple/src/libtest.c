/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2008 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2006 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include <stdio.h>
#include <stdlib.h>
#include "htuple.h"

/* -------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------- */
void htuple_verbose_printf( htuple_t id, int level )
{
    const char          *name;
    unsigned int         child,i;
    struct htuple_Value  val;


    for ( i = 0; i < level; i++ )
        printf("  ");

    htuple_node_name( id, &name );
    htuple_node_get_value( id, &val );

    if ( HTUPLE_TYPE_STRING == val.type )
    {
        printf("\"%s\" = \"%s\" /* id %d type %d */\n", name, val.str, id, val.type );
    }
    else
    {
        printf("\"%s\" = 0x%x /* id %d type %d */\n", name, val.intval, id, val.type );
    }

    if ( 0 != (child = htuple_first_child( id )) )
    {
        for ( i = 0; i < level; i++ )
            printf("  ");
        printf("{\n");

        level++;

        do
        {
            htuple_verbose_printf( child, level );

            child = htuple_next_sibling(child);
        } while ( 0 != child );

        level--;

        for ( i = 0; i < level; i++ )
            printf("  ");
        printf("}\n");
    }
}

void htuple_dump( htuple_t id )
{
    const char          *name;
    unsigned int         child;
    struct htuple_Value  val;

    htuple_node_name( id, &name );
    htuple_node_get_value( id, &val );

    if ( HTUPLE_TYPE_STRING == val.type )
    {
        printf("\"%s\" = \"%s\"\n", name, val.str );
    }
    else
    {
        printf("\"%s\" = 0x%x\n", name, val.intval );
    }

    if ( 0 != (child = htuple_first_child( id )) )
    {
        printf("{ ");

        do
        {
            htuple_dump( child );

            child = htuple_next_sibling(child);
        } while ( 0 != child );

        printf("}\n");
    }
}

static void test_load_config_file( unsigned int id, const char *filename )
{
    FILE        *fp;

    if ( NULL != (fp = fopen(filename, "r")) )
    {
        char            *txt;
        long             txtlen;

        fseek( fp, 0, SEEK_END );
        txtlen = ftell(fp);
        rewind(fp);
        if ( NULL != (txt = malloc(txtlen+1)) )
        {
            if ( txtlen == fread( txt, 1, txtlen, fp ) )
            {
                /* unnecessary null term */ txt[txtlen] = '\0';

                htuple_parse_config_string( id, txt, txtlen );
            }

            free(txt);
        }

        fclose(fp);
    }
}

/** gcc -Wall -g -I ../../i686-linux-elf/include/ libtest.c -o ltest -L ../../i686-linux-elf/lib/ -lhtuple */

int main( int argc, const char *argv[] )
{
    int              err = 0;
    int              i;

    if ( argc > 1 )
    {
        for ( i = 1; i < argc; i++ )
        {
            test_load_config_file( 0, argv[i] );
        }
        htuple_verbose_printf( 0, 0 );
        htuple_dump( 0 );
    }

    return(err);
}
