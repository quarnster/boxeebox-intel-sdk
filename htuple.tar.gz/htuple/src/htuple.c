/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "htuple.h"
#ifdef __KERNEL__

#undef SELF_TEST
#include <linux/types.h>
#include <linux/slab.h>

#define DICT_CALLOC( size )           kcalloc( 1, size, GFP_KERNEL )
#define DICT_MALLOC( size )           kmalloc( size, GFP_KERNEL )
#define DICT_FREE( ptr )              kfree( ptr )
#define DICT_MEMCPY( to, from, size ) memcpy( to, from, size )

#else

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define DICT_CALLOC( size )           calloc( 1, size ) 
#define DICT_MALLOC( size )           malloc( size )
#define DICT_FREE( ptr )              free( ptr ) 
#define DICT_MEMCPY( to, from, size ) memcpy( to, from, size ) 

#endif

#define DICT_DELIMITER_CHAR '.'

/* -------------------------------------------------------------------------------- */
/* internal implementation */
/* -------------------------------------------------------------------------------- */
#ifdef SELF_TEST
    #define DICTIONARY_HASHTABLE_POW        4
#else
    #define DICTIONARY_HASHTABLE_POW        8
#endif

/** Bulletproof the code by checking parameters at the public API */
#define BULLETPROOF_PENALTY

#define DICTIONARY_HASHTABLE_SIZE       (1<<DICTIONARY_HASHTABLE_POW)
#define DICTIONARY_HASHTABLE_MASK       (DICTIONARY_HASHTABLE_SIZE - 1)

struct DictManager
{
    unsigned int             next_hash;
    struct DictNode         *hash[DICTIONARY_HASHTABLE_SIZE];
};

struct DictNode
{
    char                    *key;           /* this name of this tuple */
    unsigned int             hash;          /* hash (or ID) of this dictionary */

    struct htuple_Value      val;           /* value */

    struct DictNode         *parent;        /* parent dictionary */
    struct DictNode         *next_hash;     /* next dictionary in the hash chain */
    struct DictNode         *next_sibling;  /* next sibling of this dictionary */
    struct DictNode         *first_child;   /* the first child */
    unsigned int             next_child_num;/* the next child number for anonymous children */
};


/* -------------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------------- */
/* internal implementation: Single node parameters */
/* -------------------------------------------------------------------------------- */

static void dictnode_Delete(
    struct DictNode *dict )
{
    if ( NULL != dict )
    {
        if ( NULL != dict->key )
        {
            DICT_FREE( (void *)dict->key );
            dict->key = NULL;
        }
        if ( (HTUPLE_TYPE_STRING == dict->val.type) &&
             (NULL != dict->val.str) )
        {
            DICT_FREE( (void *)dict->val.str );
            dict->val.str = NULL;
        }

        DICT_FREE(dict);
    }
}

static __inline struct DictNode *dictnode_Create( void )
{
    struct DictNode     *dict;

    dict = DICT_CALLOC( sizeof(*dict) );

    return(dict);
}

static __inline int dictnode_SetName(
    struct DictNode *dict,
    const char      *key,
    unsigned int     keystrlen )
{
    char        *newkey;

    if ( NULL != (newkey = DICT_MALLOC( keystrlen+1 )) )
    {
        char      *oldkey;

        DICT_MEMCPY( newkey, key, keystrlen );
        newkey[keystrlen] = '\0';

        oldkey = dict->key;
        dict->key = newkey;

        if ( NULL != oldkey )
        {
            DICT_FREE(oldkey);
        }
        return(1);
    }
    return(0);
}

static unsigned int dict_str_to_uint( 
    const char      *p,
    unsigned int     len )
{
    unsigned int        retval = 0;
    unsigned int        i;

    /* begins with "0x" */
    if ( (len > 2) && ('0' == p[0]) && ('x' == p[1]) )
    {
        i = 2;
        while ( i < len )
        {
            if ( (p[i] >= '0') && (p[i] <= '9') )
            {
                retval <<= 4;   retval += (int)(p[i] - '0');
            }
            else if ( (p[i] >= 'a') && (p[i] <= 'f') )
            {
                retval <<= 4;   retval += (int)(p[i] - 'a') + 10;
            }
            else if ( (p[i] >= 'A') && (p[i] <= 'F') )
            {
                retval <<= 4;   retval += (int)(p[i] - 'A') + 10;
            }
            else
            {
                break;
            }
            i++;
        }
    }
    else
    {
        int     neg = 0;

        i = 0;

        if ( '-' == p[0] )
        {
            neg = 1;
            i++;
        }

        while ( i < len )
        {
            if ( (p[i] >= '0') && (p[i] <= '9') )
            {
                retval *= 10;   retval += (int)(p[i] - '0');
            }
            else
            {
                break;
            }
            i++;
        }

        if ( neg )
        {
            retval = -retval;
        }
    }

    return(retval);
}

static int dictnode_SetValueString(
    struct DictNode *dict,
    const char      *value,
    unsigned int     valuestrlen )
{
    char        *newval;

    if ( NULL != (newval = DICT_MALLOC( valuestrlen+1 )) )
    {
        char      *oldval = NULL;

        DICT_MEMCPY( newval, value, valuestrlen );
        newval[valuestrlen] = '\0';

        if ( (HTUPLE_TYPE_STRING == dict->val.type) &&
             (NULL != dict->val.str) )
            oldval = dict->val.str;

        dict->val.type = HTUPLE_TYPE_STRING;
        dict->val.str = newval;

        if ( NULL != oldval )
        {
            DICT_FREE(oldval);
        }
        return(1);
    }
    return(0);
}

static __inline int dictnode_SetValueInt(
    struct DictNode *dict,
    unsigned int     value )
{
    char      *oldval = NULL;

    if ( (HTUPLE_TYPE_STRING == dict->val.type) &&
         (NULL != dict->val.str) )
        oldval = dict->val.str;

    dict->val.type = HTUPLE_TYPE_INT;
    dict->val.intval = value;
    
    if ( NULL != oldval )
    {
        DICT_FREE(oldval);
    }

    return( 1 );
}

static struct DictNode *dictnode_CreateString(
    const char      *key,
    unsigned int     keystrlen,
    const char      *value,
    unsigned int     valuestrlen )
{
    struct DictNode     *dict;

    if ( NULL != (dict = dictnode_Create()) )
    {
        int          ok = 0;

        if ( dictnode_SetName( dict, key, keystrlen ) )
        {
            if ( dictnode_SetValueString( dict, value, valuestrlen ) )
            {
                ok = 1;
            }
        }
        
        if ( !ok )
        {
            dictnode_Delete(dict);
            dict = NULL;
        }
    }
    return(dict);
}

static struct DictNode *dictnode_CreateInt(
    const char      *key,
    unsigned int     keystrlen,
    unsigned int     value )
{
    struct DictNode     *dict;

    if ( NULL != (dict = dictnode_Create() ) )
    {
        int          ok = 0;

        if ( dictnode_SetName( dict, key, keystrlen ) )
        {
            if ( dictnode_SetValueInt( dict, value ) )
            {
                ok = 1;
            }
        }
        
        if ( !ok )
        {
            dictnode_Delete(dict);
            dict = NULL;
        }
    }
    return(dict);
}

/* -------------------------------------------------------------------------------- */
/* internal implementation: Global Hashing to correlate IDs */
/* -------------------------------------------------------------------------------- */
static struct DictNode *dm_FindHash( 
    struct DictManager  *dm,
    unsigned int         hash )
{
    struct DictNode *dict;

    dict = dm->hash[ hash & DICTIONARY_HASHTABLE_MASK ];

    while ( NULL != dict )
    {
        if ( dict->hash == hash )
        {
            return( dict );
        }
        dict = dict->next_hash;
    }

    return( NULL );
}

static unsigned int dm_GetNextHash(
    struct DictManager  *dm )
{
    unsigned int    hash;

    while ( 1 )
    {
        hash = ++dm->next_hash;       /* should use atomic increment */

        /* hash does not already exist */
        if ( NULL == dm_FindHash( dm, hash ) )
        {
            /* we have a unique ID, break */
            break;
        }
    }

    return(hash);
}

static unsigned int dm_AddToHash( 
    struct DictManager  *dm,
    struct DictNode     *dict )
{
    dict->hash = dm_GetNextHash(dm);

    /* insert at the head of the hash chain */
    dict->next_hash = dm->hash[ dict->hash & DICTIONARY_HASHTABLE_MASK ];
    dm->hash[ dict->hash & DICTIONARY_HASHTABLE_MASK ] = dict;

    return( dict->hash );
}

static void dm_RemoveFromHash( 
    struct DictManager  *dm,
    struct DictNode     *dict )
{
    struct DictNode  **pdict;

    /* point to first item in the hash chain */
    pdict = &dm->hash[dict->hash & DICTIONARY_HASHTABLE_MASK];

    while ( NULL != *pdict )
    {
        /* if this points to the dictionary we're removing */
        if ( *pdict == dict )
        {
            /* Link over this entry */
            *pdict = dict->next_hash;
            break;
        }
        else
        {
            /* Go to next */
            pdict = &(*pdict)->next_hash;
        }
    }
}

static void dm_Delete(
    struct DictManager *dm )
{
    if ( NULL != dm )
    {
        unsigned int         hash;

        for ( hash = 0; hash < DICTIONARY_HASHTABLE_SIZE; hash++ )
        {
            struct DictNode  *dict;

            /* continuously remove first item in hash chain */
            while ( NULL != (dict = dm->hash[hash]) )
            {
                /* remove it from the hash chain */
                dm->hash[hash] = dict->next_hash;

                dictnode_Delete( dict );
            }
        }

        DICT_FREE(dm);
    }
}

static void dm_DeleteSubtree(
    struct DictManager  *dm,
    struct DictNode     *dict )
{
    struct DictNode     *parent;

    while ( NULL != dict->first_child )
    {
        dm_DeleteSubtree( dm, dict->first_child );
    }

    /* remove me from my parent's "child" list */
    if ( NULL != (parent = dict->parent) )
    {
        struct DictNode     **pprev;

        pprev = &parent->first_child;

        while ( NULL != *pprev )
        {
            /* if this predecessor points to me */
            if ( *pprev == dict )
            {
                /* UNLINK: point over me to my next sibling */
                *pprev = dict->next_sibling;
                break;
            }
            /* link to next sibling in parent's list */
            pprev = &(*pprev)->next_sibling;
        }
    }

    dm_RemoveFromHash(dm,dict);

    dictnode_Delete(dict);
}

static int dm_Initialize(
    struct DictManager *dm )
{
    struct DictNode *dict;

    if ( NULL != (dict = dictnode_CreateInt( "", 0, 0 )) )
    {
        dm->next_hash = -1;   /* force dict_GetNextHash() to return zero */

        dm_AddToHash( dm, dict );

        return(1);
    }
    return(0);
}

static struct DictManager *dm_Create( void )
{
    struct DictManager *dm;

    if ( NULL != (dm = DICT_CALLOC( sizeof(*dm))) )
    {
        if ( ! dm_Initialize(dm) )
        {
            DICT_FREE(dm);
            dm = NULL;
        }
    }

    return(dm);
}

#ifdef SELF_TEST
static void dict_debug_PrintHashChains(
    struct DictManager  *dm )
{
    int             i;

    for ( i = 0; i < DICTIONARY_HASHTABLE_SIZE; i++ )
    {
        struct DictNode *dict;

        printf("g_dm.hash[ %4d ]: ", i );

        if ( NULL != (dict = dm->hash[i]) )
        {
            do
            {
                if ( HTUPLE_TYPE_STRING == dict->val.type )
                    printf("(%3d, \"%s\" \"%s\")", dict->hash, dict->key, dict->val.str );
                else
                    printf("(%3d, \"%s\" 0x%x)", dict->hash, dict->key, dict->val.intval );

                dict = dict->next_hash;
            } while ( NULL != dict );
            printf("\n");
        }
        else
        {
            printf("<empty>\n");
        }
    }
}
#endif

/* -------------------------------------------------------------------------------- */
/* internal implementation: Parent-Child */
/* -------------------------------------------------------------------------------- */
static void dict_AddChild( 
    struct DictNode *dict,
    struct DictNode *child )
{
    struct DictNode *prev;

    child->parent = dict;
    child->next_sibling = NULL;

    /* insert at tail of "children" list */
    if ( NULL != (prev = dict->first_child) )
    {
        while ( NULL != prev->next_sibling )
        {
            prev = prev->next_sibling;
        }

        prev->next_sibling = child;
    }
    else
    {
        /* first child of this node */
        dict->first_child = child;
    }
}

static struct DictNode *dict_FindChild(
    struct DictNode *dict,
    const char      *key,
    unsigned int     keystrlen )
{
    struct DictNode *child;

    /* insert at tail of "children" list */
    if ( NULL != (child = dict->first_child) )
    {
        do
        {
            unsigned int     i;
            const char      *sibkey;

            /* get the name of this child */
            sibkey = child->key;

            /* perform exact string comparison */
            for ( i = 0; i < keystrlen; i++ )
            {
                if ( ('\0' == sibkey[i]) ||
                     (key[i] != sibkey[i]) )
                {
                    break;
                }
            }
            /* make sure search candidate is not a longer string, ensure */
            if ( (i == keystrlen) && ('\0' == sibkey[keystrlen]) )
            {
                break;
            }

            /* try the next one */
            child = child->next_sibling;
        } while ( NULL != child );
    }

    return( child );
}

static struct DictNode *dict_CreateChildString(
    struct DictManager *dm,
    struct DictNode *dict,
    const char      *key,
    unsigned int     keystrlen,
    const char      *value,
    unsigned int     valuestrlen )
{
    struct DictNode *child;

    /* If the child doesn't already exist */
    if ( NULL == (child = dict_FindChild(dict,key,keystrlen)) )
    {
        if ( NULL != (child = dictnode_CreateString( key, keystrlen, value, valuestrlen )) )
        {
            dm_AddToHash( dm, child );
            dict_AddChild( dict, child );
        }
    }
    else
    {
        dictnode_SetValueString( dict, value, valuestrlen );
    }

    return(child);
}

static struct DictNode *dict_CreateChildInt(
    struct DictManager *dm,
    struct DictNode *dict,
    const char      *key,
    unsigned int     keystrlen,
    unsigned int     value )
{
    struct DictNode *child;

    /* If the child doesn't already exist */
    if ( NULL == (child = dict_FindChild(dict,key,keystrlen)) )
    {
        if ( NULL != (child = dictnode_CreateInt( key, keystrlen, value )) )
        {
            dm_AddToHash( dm, child );
            dict_AddChild( dict, child );
        }
    }
    else
    {
        dictnode_SetValueInt( dict, value );
    }

    return(child);
}

/* -------------------------------------------------------------------------------- */
/* internal implementation: Heirarchical Search */
/* -------------------------------------------------------------------------------- */

#ifdef SELF_TEST
static void dict_debug_Print(
    struct DictNode *dict )
{
    if ( HTUPLE_TYPE_STRING == dict->val.type )
        printf("(%3d, \"%s\" %d \"%s\")", dict->hash, dict->key, dict->val.type, dict->val.str );
    else
        printf("(%3d, \"%s\" %d 0x%x)", dict->hash, dict->key, dict->val.type, dict->val.intval );
}

static void dict_debug_PrintHeirarchy(
    struct DictNode *dict,
    int              level )
{
    struct DictNode *child;
    int              i;

    for ( i = 0; i < level; i++ )
        printf("  ");

    dict_debug_Print( dict );

    if ( NULL != (child = dict->first_child) )
    {
        do
        {
            dict_debug_PrintHeirarchy(child,level+1);

            child = child->next_sibling;
        } while ( NULL != child );
    }
}

static void dict_debug_PrintTree(
    struct DictNode *dict,
    int              level )
{
    struct DictNode *child;
    int              i;

    for ( i = 0; i < level; i++ )
        printf("  ");

    if ( HTUPLE_TYPE_STRING == dict->val.type )
        printf("\"%s\" = \"%s\"\n", dict->key, dict->val.str );
    else
        printf("\"%s\" = 0x%x\n", dict->key, dict->val.intval );

    if ( NULL != (child = dict->first_child) )
    {
        for ( i = 0; i < level; i++ )
            printf("  ");
        printf("{\n");

        do
        {
            dict_debug_PrintTree(child,level+1);

            child = child->next_sibling;
        } while ( NULL != child );

        for ( i = 0; i < level; i++ )
            printf("  ");
        printf("}\n");
    }
}
#endif

static struct DictNode *dict_CreateDeepString(
    struct DictManager *dm,
    struct DictNode *dict,
    const char      *key,
    unsigned int     keystrlen,
    const char      *value,
    unsigned int     valuestrlen )
{
    struct DictNode *child;
    unsigned int     token_len;

    for ( token_len = 0; token_len < keystrlen; token_len++ )
    {
        if ( (DICT_DELIMITER_CHAR == key[token_len]) ||
             ('\0' == key[token_len]) )
        {
            break;
        }
    }

    /* Find/Create a node at this level and recurse */
    child = dict_FindChild(dict,key,token_len);

    /* This is a step in the heirarchy */
    if ( DICT_DELIMITER_CHAR == key[token_len] )
    {
        /* Create a child directory (integer) */
        if ( NULL == child )
            child = dict_CreateChildInt( dm, dict, key, token_len, 0 );

        if ( NULL != child )
        {
            token_len += 1; /* skip over the delimiter */

            return( dict_CreateDeepString( dm, child,
                key + token_len,
                keystrlen - token_len,
                value,
                valuestrlen ) );
        }
    }
    else if ( NULL != child )   /* leaf node already exists */
    {
        dictnode_SetValueString( child, value, valuestrlen );
    }
    else /* need to create the leaf node */
    {
        child = dict_CreateChildString( dm, dict, key, token_len, value, valuestrlen );
    }

    return(child);
}

static struct DictNode *dict_CreateDeepInt(
    struct DictManager *dm,
    struct DictNode *dict,
    const char      *key,
    unsigned int     keystrlen,
    unsigned int     value )
{
    struct DictNode *child;
    unsigned int     token_len;

    for ( token_len = 0; token_len < keystrlen; token_len++ )
    {
        if ( (DICT_DELIMITER_CHAR == key[token_len]) ||
             ('\0' == key[token_len]) )
        {
            break;
        }
    }

    /* Find/Create a node at this level and recurse */
    child = dict_FindChild(dict,key,token_len);

    /* This is a step in the heirarchy */
    if ( DICT_DELIMITER_CHAR == key[token_len] )
    {
        /* Create a child directory (integer) */
        if ( NULL == child )
            child = dict_CreateChildInt( dm, dict, key, token_len, 0 );

        if ( NULL != child )
        {
            token_len += 1; /* skip over the delimiter */

            return( dict_CreateDeepInt( dm, child,
                key + token_len,
                keystrlen - token_len,
                value ) );
        }
    }
    else if ( NULL != child )   /* leaf node already exists */
    {
        dictnode_SetValueInt( child, value );
    }
    else /* need to create the leaf node */
    {
        child = dict_CreateChildInt( dm, dict, key, token_len, value );
    }
    
    return(child);
}

static struct DictNode *dict_FindDeepChild(
    struct DictNode *dict,
    const char      *key,
    unsigned int     keystrlen )
{
    while( 1 )
    {
        unsigned int     token_len;

        for ( token_len = 0; token_len < keystrlen; token_len++ )
        {
            if ( (DICT_DELIMITER_CHAR == key[token_len]) ||
                 ('\0' == key[token_len]) )
            {
                break;
            }
        }

        /* zoom to child */
        if ( NULL != (dict = dict_FindChild(dict,key,token_len)) )
        {
            /* This path is a step in the heirarchy */
            if ( DICT_DELIMITER_CHAR == key[token_len] )
            {
                token_len += 1; /* skip over the delimiter */

                /* find next "name" position */
                key += token_len;
                keystrlen -= token_len;
                /* continue down the heirarchy */
            }
            else
            {
                break;  /* we're at the leaf node, whether FindChiled failed or not */
            }
        }
        else
        {
            break;
        }
    }

    return( dict );
}

/* -------------------------------------------------------------------------------- */
/* Utility Function, dictionary syntax parser */
/* -------------------------------------------------------------------------------- */
static int dm_parse_config_string(
    struct DictManager  *dm,
    struct DictNode     *dict,
    const char          *cfg,
    unsigned int         cfglen )
{
    int              cur_depth;
    const char      *key,*value;
    int              keylen,valuelen;
    unsigned int     tok_begin;
    struct DictNode *last_created;

    #define          DICT_PARSER_MAX_DICT_DEPTH  32
    struct DictNode *dict_stack[DICT_PARSER_MAX_DICT_DEPTH];

#ifdef SELF_TEST
    #define DEBUG_TOKEN     0
    #define DEBUG_PUSH_POP  0
    #define DEBUG_CREATE    0
    #define DEBUG_COMMENTS  0
    //static char g_token[4 * 1024];
   memset( dict_stack, 0, sizeof(dict_stack) );
#endif

    #define DM_WHITESPACE( ch ) \
        ( (' '  == ch) || ('\t' == ch) || ('\n' == ch) || ('\r' == ch) )
    
    /* reset these values */
    key = value = NULL;
    keylen = valuelen = -1;
    tok_begin = 0;
    last_created = dict;

    cur_depth = 0;
    dict_stack[cur_depth++] = dict;

    while ( tok_begin < cfglen )
    {
        if ( !DM_WHITESPACE(cfg[tok_begin]) )
        {
            unsigned int        tok_end;
            int                 tok_is_quoted;

            tok_end = tok_begin + 1;

            if ( '\"' == cfg[tok_begin] )
            {
                tok_is_quoted = 1;

                while( (tok_end < cfglen) )
                {
                    if ( '\"' == cfg[tok_end++] )
                    {
                        break;  /* just past the quote */
                    }
                }
            }
            else if ( ('{' == cfg[tok_begin]) ||
                      ('}' == cfg[tok_begin]) )
            {
               /* brackets are treated as single-char tokens regardless of surrounding characters
                * do not search for end-of-token (below loop)
                */
            }
            else
            {
                tok_is_quoted = 0;

                while( (tok_end < cfglen) && !DM_WHITESPACE(cfg[tok_end]) )
                {
                    /* Treat all brackets as end-of-token
                     */
                    if ( ('{' == cfg[tok_end]) ||
                         ('}' == cfg[tok_end]) )
                    {
                       break;
                    }

                    tok_end++;
                }
            }

            if ( tok_end <= cfglen )
            {
                int         tok_len;

                tok_len = (int)tok_end - (int)tok_begin;

            #ifdef SELF_TEST
                #if DEBUG_TOKEN
                memcpy( g_token, &cfg[tok_begin], tok_len ); g_token[tok_len] = '\0';
                printf("token = %s\n", g_token );
                #endif
            #endif

                if ( '\"' == cfg[tok_begin] )   /* begins with a quote */
                {
                    /* tok_begin is on the leading quote
                     * tok_end is just past the trailing quote
                     * tok_len includes both quotes.
                     *
                     * DO NOT adjust tok_end because we need to skip
                     * past the trailing quote at the end.
                     *
                     */
                    ++tok_begin;
                    tok_len -= 2;
                }
                else if ( (tok_len > 1) && ('/' == cfg[tok_begin]) )
                {
                    /* is this a C++ comment (to end of line) */
                    if ( '/' == cfg[tok_begin+1] )
                    {
                        tok_end = tok_begin + 2;
                        while( (tok_end < cfglen) )
                        {
                            if ( '\n' == cfg[tok_end++] )
                            {
                                break;  /* just past the newline */
                            }
                        }
                        #ifdef SELF_TEST
                            #if DEBUG_COMMENTS
                            memcpy( g_token, &cfg[tok_begin], tok_len ); g_token[tok_len] = '\0';
                            printf("CPP comment = %s len %d\n", g_token, tok_len );
                            #endif
                        #endif
                        tok_len = -1;   /* force comment ignore */
                    }
                    else if ( '*'== cfg[tok_begin+1] )  /* "C" comment */
                    {
                        tok_end = tok_begin + 2;
                        while( (tok_end < cfglen) )
                        {
                            if ( '/' == cfg[tok_end++] )
                            {
                                if ( (tok_end - tok_begin) >= 4 )   /**/
                                {
                                    if ( '*' == cfg[tok_end-2] )
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                        tok_len = -1;   /* force comment ignore */
                    }
                }

                if ( tok_len >= 0 ) /* can be empty string */
                {
                    if ( (1 == tok_len) && ('{' == cfg[tok_begin]) )
                    {
                        if ( NULL != key )  /* we've got a dictionary to create without a value */
                        {
                            #ifdef SELF_TEST
                                #if DEBUG_CREATE
                                memcpy( g_token, key, keylen ); g_token[keylen] = '\0';
                                printf( "create_dir: \"%s\"\n", g_token );
                                #endif
                            #endif
                            /* Find a pre-existing child */
                            if ( NULL == (last_created = 
                                 dict_FindDeepChild( dict, key, keylen )) )
                            {
                               if ( NULL == (last_created = 
                                    dict_CreateDeepInt( dm, dict, key, keylen, 0 )) )
                               {
                                   return( HTUPLE_ERR_LOW_RESOURCES ); /* warning, early return */
                               }
                            }

                            key = value = NULL;
                        }
                        else if ( (NULL != last_created) && (dict != last_created) )
                        //else if ( NULL != last_created )
                        {
                            /* reuse this dictionary */
                        }
                        else    /* generic open bracket, un-named, create a unique name */
                        {
                            char        dname[16];

                            sprintf( dname, "%d", dict->next_child_num++ );

                            #ifdef SELF_TEST
                                #if DEBUG_CREATE
                                printf( "create_###: \"%s\"\n", dname );
                                #endif
                            #endif

                            if ( NULL == (last_created = 
                                 dict_CreateDeepInt( dm, dict, dname, strlen(dname), 0 )) )
                            {
                                return( HTUPLE_ERR_LOW_RESOURCES ); /* warning, early return */
                            }
                        }

                        #ifdef SELF_TEST
                            #if DEBUG_PUSH_POP
                            printf("push %d: ", cur_depth );  dict_debug_Print(last_created);
                            #endif
                        #endif

                        dict_stack[cur_depth++] = dict;

                        if ( cur_depth >= DICT_PARSER_MAX_DICT_DEPTH )
                        {
                            return( HTUPLE_ERR_INVALID_PARAM ); /* warning, early return */
                        }
                            
                        dict = last_created;
                    }
                    else if ( (1 == tok_len) && ('}' == cfg[tok_begin]) )
                    {
                        if ( cur_depth > 0 )
                        {
                            #ifdef SELF_TEST
                                #if DEBUG_PUSH_POP
                                printf("pop %d: ", cur_depth );  dict_debug_Print(dict);
                                #endif
                            #endif
                            dict = dict_stack[--cur_depth];
                            last_created = dict;
                        }
                    }
                    else
                    {
                        if ( NULL == key )  /* no key set yet */
                        {
                            key = &cfg[tok_begin];
                            keylen = tok_len;
                        }
                        else
                        {
                            /* found an equals sign between key and value */
                            if ( (1 == tok_len) && ('=' == cfg[tok_begin]) )
                            {
                                /* ignore it */
                            }
                            else
                            {
                                int             make_string = 0;
                                unsigned int    intval;

                                value = &cfg[tok_begin];
                                valuelen = tok_len;
                                intval = dict_str_to_uint(value, valuelen);

                                #ifdef SELF_TEST
                                    #if DEBUG_CREATE
                                    memcpy( g_token, key, keylen ); g_token[keylen] = '\0';
                                    printf( "create_string: \"%s\" = ", g_token );
                                    memcpy( g_token, value, valuelen ); g_token[valuelen] = '\0';
                                    printf( "\"%s\"\n", g_token );
                                    #endif
                                #endif
                                if ( tok_is_quoted )
                                {
                                    make_string = 1;
                                }
                                else if ( 0 == intval ) /* if we got zero, double check this */
                                {
                                    /* starts with a decimal number, remember hexadecimal is specified
                                     * as "0x" so that works too
                                     */
                                    if ( ((value[0] >= '0')&&(value[0] <= '9')) )
                                    {
                                    }
                                    else
                                    {
                                        make_string = 1;
                                    }
                                }

                                if ( make_string )
                                {
                                    if ( NULL == (last_created = 
                                         dict_CreateDeepString( dm, dict, key, keylen, value, valuelen )) )
                                    {
                                        return( HTUPLE_ERR_LOW_RESOURCES ); /* warning, early return */
                                    }
                                }
                                else
                                {
                                    if ( NULL == (last_created = 
                                         dict_CreateDeepInt( dm, dict, key, keylen, intval )) )
                                    {
                                        return( HTUPLE_ERR_LOW_RESOURCES ); /* warning, early return */
                                    }
                                }
                                /* reset these to get the next tuple */
                                key = value = NULL;
                            }
                        }
                    }
                }
            }

            tok_begin = tok_end;
        }
        else
        {
            tok_begin++;
        }
    }

    return( HTUPLE_ERR_NONE );
}

/* -------------------------------------------------------------------------------- */
/* PUBLIC API */
/* -------------------------------------------------------------------------------- */

static struct DictManager  *g_dm;

int htuple_initialize( void )
{
    if ( NULL == g_dm ) /* TODO: Need thread safety here */
    {
        g_dm = dm_Create();
    }
    return( NULL != g_dm );
}

int htuple_deinitialize( void )
{
    if ( NULL != g_dm )
    {
        dm_Delete( g_dm );
        g_dm = NULL;
    }
    return(1);
}

htuple_t htuple_find_child(
    htuple_t      id,
    const char   *name,
    unsigned int  namelen )
{
    struct DictNode *dict;

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {   /* Look for it */
        if ( NULL != (dict = dict_FindDeepChild(dict,name,namelen)) )
        {
            id = dict->hash;

        } else id = 0;

    } else id = 0;

    return(id);
}

htuple_t htuple_first_child(
    htuple_t      id )
{
    struct DictNode *dict;

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {
        if ( NULL != (dict = dict->first_child) )
        {
            id = dict->hash;
        } else id = 0;
    } else id = 0;
    return( id );
}

htuple_t htuple_next_sibling(
    htuple_t      id )
{
    struct DictNode *dict;

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {
        if ( NULL != (dict = dict->next_sibling) )
        {
            id = dict->hash;
        } else id = 0;
    } else id = 0;
    return( id );
}

int htuple_node_name(
    htuple_t      id,
    const char   **pname )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *dict;

#ifdef BULLETPROOF_PENALTY
    if ( NULL == pname )
        return( HTUPLE_ERR_INVALID_PARAM );
#endif

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {
        *pname = dict->key;
    } else err = HTUPLE_ERR_BAD_HANDLE;
    
    return(err);
}

int htuple_node_get_value(
    htuple_t      id,
    struct htuple_Value *pval )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *dict;

#ifdef BULLETPROOF_PENALTY
    if ( NULL == pval )
        return( HTUPLE_ERR_INVALID_PARAM );
#endif

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {
        *pval = dict->val;
    } else err = HTUPLE_ERR_BAD_HANDLE;
    
    return(err);
}

int htuple_node_int_value(
    htuple_t      id,
    unsigned int *pval )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *dict;

#ifdef BULLETPROOF_PENALTY
    if ( NULL == pval )
        return( HTUPLE_ERR_INVALID_PARAM );
#endif

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {
        if ( HTUPLE_TYPE_INT == dict->val.type )
            *pval = dict->val.intval;
        else
            err = HTUPLE_ERR_BAD_TYPE;
    } else err = HTUPLE_ERR_BAD_HANDLE;
    
    return(err);
}
int htuple_node_str_value(
    htuple_t      id,
    const char   **pval )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *dict;

#ifdef BULLETPROOF_PENALTY
    if ( NULL == pval )
        return( HTUPLE_ERR_INVALID_PARAM );
#endif

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {
        if ( HTUPLE_TYPE_STRING == dict->val.type )
        {
            *pval = dict->val.str;
        }
        else
        {
            err = HTUPLE_ERR_BAD_TYPE;
            *pval = "ERR";
        }
    } else err = HTUPLE_ERR_BAD_HANDLE;
    
    return(err);
}

int htuple_get_int_value(
    htuple_t      id,
    const char   *valname,
    unsigned int  valnamelen,
    unsigned int *pval )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *dict;

#ifdef BULLETPROOF_PENALTY
    if ( (NULL == valname) || (NULL == pval) )
        return( HTUPLE_ERR_INVALID_PARAM );
#endif

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {   /* Look for it */
        if ( NULL != (dict = dict_FindDeepChild(dict,valname,valnamelen)) )
        {
            if ( HTUPLE_TYPE_INT == dict->val.type )
                *pval = dict->val.intval;
            else
                err = HTUPLE_ERR_BAD_TYPE;
        } else err = HTUPLE_ERR_NOT_FOUND;
    } else err = HTUPLE_ERR_BAD_HANDLE;
    
    return(err);
}

int htuple_get_str_value(
    htuple_t      id,
    const char   *valname,
    unsigned int  valnamelen,
    const char   **pval )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *dict;

#ifdef BULLETPROOF_PENALTY
    if ( (NULL == valname) || (NULL == pval) )
        return( HTUPLE_ERR_INVALID_PARAM );
#endif

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {   /* Look for it */
        if ( NULL != (dict = dict_FindDeepChild(dict,valname,valnamelen)) )
        {
            if ( HTUPLE_TYPE_STRING == dict->val.type )
            {
                *pval = dict->val.str;
            }
            else
            {
                err = HTUPLE_ERR_BAD_TYPE;
                *pval = "ERR";
            }
        } else err = HTUPLE_ERR_NOT_FOUND;
    } else err = HTUPLE_ERR_BAD_HANDLE;
    
    return(err);
}

int htuple_set_int_value(
    htuple_t      id,
    const char   *valname,
    unsigned int  valnamelen,
    unsigned int  value )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *dict;

#ifdef BULLETPROOF_PENALTY
    if ( NULL == valname )
        return( HTUPLE_ERR_INVALID_PARAM );
#endif

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {   /* Look for it */
        if ( NULL != (dict = dict_CreateDeepInt( g_dm, dict,valname,valnamelen,value)) )
        {
        } else err = HTUPLE_ERR_LOW_RESOURCES;
    } else err = HTUPLE_ERR_BAD_HANDLE;
    
    return(err);
}

int htuple_set_str_value(
    htuple_t      id,
    const char   *valname,
    unsigned int  valnamelen,
    const char   *value,
    unsigned int  valuestrlen )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *dict;

#ifdef BULLETPROOF_PENALTY
    if ( (NULL == valname) || (NULL == value) )
        return( HTUPLE_ERR_INVALID_PARAM );
#endif

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {   /* Look for it */
        if ( NULL != (dict = dict_CreateDeepString( g_dm, dict,valname,valnamelen,value,valuestrlen)) )
        {
        } else err = HTUPLE_ERR_LOW_RESOURCES;
    } else err = HTUPLE_ERR_BAD_HANDLE;
    
    return(err);
}

int htuple_parse_config_string(
    htuple_t      id,
    const char   *cfg,
    unsigned int  cfglen )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *dict;

#ifdef BULLETPROOF_PENALTY
    if ( NULL == cfg )
        return( HTUPLE_ERR_INVALID_PARAM );
#endif

    if ( NULL != (dict = dm_FindHash( g_dm, id )) )
    {
        err = dm_parse_config_string( g_dm, dict, cfg, cfglen );
    } else err = HTUPLE_ERR_BAD_HANDLE;
    
    return(err);
}

/* -------------------------------------------------------------------------------- */

int htuple_create_private_tree(
    htuple_t     *pprivate_id )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *child;

#ifdef BULLETPROOF_PENALTY
    if ( NULL == pprivate_id )
        return( HTUPLE_ERR_INVALID_PARAM );
#endif

    if ( NULL != (child = dictnode_CreateInt( "private", 7, 0 )) )
    {
        /* assign to hash table */
        *pprivate_id = dm_AddToHash( g_dm, child );

        /* do not assign a parent, this subtree cannot be found by traversal */

    } else err = HTUPLE_ERR_BAD_HANDLE;

    return(err);
}

int htuple_delete_private_tree(
    htuple_t      private_id )
{
    int              err = HTUPLE_ERR_NONE;
    struct DictNode *dict;

    if ( 0 == private_id )  /* cannot delete root node */
        return( HTUPLE_ERR_BAD_HANDLE );
    
    if ( NULL != (dict = dm_FindHash( g_dm, private_id )) )
    {
        dm_DeleteSubtree( g_dm, dict );

    } else err = HTUPLE_ERR_BAD_HANDLE;
    
    return(err);
}


#ifndef SELF_TEST
#ifndef __KERNEL__
/* Shared code library initialization hacks */
__attribute__((constructor)) static void htuple_usermode_lib_init(void)
{
    htuple_initialize();
}
 __attribute__((destructor)) static void htuple_usermode_lib_deinit(void)
{
    /* DO NOT CALL DEINIT: All memory will be freed for this process when it is torn down */
}
#endif
#endif

#ifdef SELF_TEST
#define HTUPLE_MAX_ERR (HTUPLE_ERR_INVALID_PARAM+1)

static const char *htuple_err_string[HTUPLE_MAX_ERR] = {
    "NONE         ",
    "BAD_HANDLE   ",
    "BAD_TYPE     ",
    "LOW_RESOURCES",
    "NOT_FOUND    ",
    "INVALID_PARAM"
};
const char *htuple_err_str( int err )
{
    if ( (err >= 0) && (err < HTUPLE_MAX_ERR) )
    {
        return ( htuple_err_string[err] );
    }
    return("undefined err");
}

static void self_debug_verbose( struct DictNode *root )
{
    printf("======================================\n");
    //dict_debug_PrintHashChains( g_dm );
    //dict_debug_PrintHeirarchy( root, 0 );
    dict_debug_PrintTree( root, 0 );
}

static void print_htuple( unsigned int id )
{
    const char          *name;
    struct htuple_Value  val;
    int                  err;

    if ( 0 != (err = htuple_node_name( id, &name )))      printf("err %d: htuple_node_name(%d)\n", err, id );
    if ( 0 != (err = htuple_node_get_value( id, &val )))  printf("err %d: htuple_node_get_value(%d)\n", err, id );

    if ( HTUPLE_TYPE_STRING == val.type )
    {
        printf("[%d: \"%s\" = \"%s\"]\n", id, name, val.str );
    }
    else
    {
        printf("[%d: \"%s\" = 0x%x]\n", id, name, val.intval );
    }
}

/* -------------------------------------------------------------------------------- */
/* -------------------------------------------------------------------------------- */
#define NUM_TEST_CONFIG_STRINGS     4
static const char *g_config_strings[NUM_TEST_CONFIG_STRINGS] = {
    "test0 = 0"
    
    ,

    "test2 = 7\n"
    "test2.base = \"green\"\n"
    
    ,

    "dict0 = 3\n"
    "{\n"
    "   a = \"one\"\n"
    "   b = \"two\"\n"
    "   { kev = 4  bart = \"red\" }\n"
    "   c = \"three\"\n"
    "   hexnum_0 = 0x89abcdef0\n"
    "   hexnum_1 = 0x012345678\n"
    "}\n"

    ,

    "dict0 = 3\n"
    "{\n"
    "   anonymous {\n"
    "      {\n"
    "         t1 = \"uno\"\n"
    "         t2 = \"dos\"\n"
    "      }\n"
    "      {\n"
    "         t1 = \"tres\"\n"
    "         t2 = \"quattro\"\n"
    "      }\n"
    "   }\n"
    "   control.sub_1 = \"red\"     { a = 0x01 b = 0x02 } \n"
    "   control.sub_2               { a = 0x11 b = 0x12 } \n"
    "   deep.htuple.test.deep_1 = \"red\"{ a = 0x21 b = 0x22 } \n"
    "   deep.htuple.test.deep_2          { a = 0x31 b = 0x32 } \n"
    "   shallow.test_1 = \"green\" \n"
    "   shallow.test_2 = \"blue\" \n"
    "   deeper.single.test_1 = \"purple\" \n"
    "   deeper.single.test_2 = \"yellow\" \n"
    "   deeper.second.test_1 = \"mauve\" \n"
    "   deeper.second.test_2 = \"squash\" \n"
    "   deeper { { test_1 = 0x100 { beep = \"now\" } } { test_1 = 0x101 } }\n"
    "   recurse.test1 {\n"
    "      foo {\n"
    "         bar 1\n"
    "         control.sub_1 = \"red\"     { a = 0x41 b = 0x42 } \n"
    "         control.sub_2               { a = 0x51 b = 0x52 } \n"
    "      }\n"
    "   }\n"
    "   finish_dict0 = \"done\" \n"
    "}\n"
    "dict0.recurse.test1.foo.control.sub_1.a = 0xbb\n"
    "dict0.recurse.test1.foo.control.sub_2.a { baz 2 kar 3 }\n"
};

void htuple_verbose_printf( htuple_t id, int level )
{
    const char          *name;
    unsigned int         child,i;
    struct htuple_Value  val;


    for ( i = 0; i < level; i++ )
        printf("  ");

    htuple_node_name( id, &name );
    htuple_node_get_value( id, &val );

    if ( HTUPLE_TYPE_STRING == val.type )
    {
        printf("\"%s\" = \"%s\" /* id %d type %d */\n", name, val.str, id, val.type );
    }
    else
    {
        printf("\"%s\" = 0x%x /* id %d type %d */\n", name, val.intval, id, val.type );
    }

    if ( 0 != (child = htuple_first_child( id )) )
    {
        for ( i = 0; i < level; i++ )
            printf("  ");
        printf("{\n");

        level++;

        do
        {
            htuple_verbose_printf( child, level );

            child = htuple_next_sibling(child);
        } while ( 0 != child );

        level--;

        for ( i = 0; i < level; i++ )
            printf("  ");
        printf("}\n");
    }
}

void htuple_dump( htuple_t id )
{
    const char          *name;
    unsigned int         child;
    struct htuple_Value  val;

    htuple_node_name( id, &name );
    htuple_node_get_value( id, &val );

    if ( HTUPLE_TYPE_STRING == val.type )
    {
        printf("\"%s\" = \"%s\"\n", name, val.str );
    }
    else
    {
        printf("\"%s\" = 0x%x\n", name, val.intval );
    }

    if ( 0 != (child = htuple_first_child( id )) )
    {
        printf("{ ");

        do
        {
            htuple_dump( child );

            child = htuple_next_sibling(child);
        } while ( 0 != child );

        printf("}\n");
    }
}

static int test_config_string( unsigned int id, unsigned int n )
{
    int              err = 2;
    if ( n < NUM_TEST_CONFIG_STRINGS )
    {
        int     len;
        len = strlen(g_config_strings[n]);
        err = htuple_parse_config_string( id, g_config_strings[n], len );
    }
    return(err);
}

static void test_load_config_file( unsigned int id, const char *filename )
{
    FILE        *fp;

    if ( NULL != (fp = fopen(filename, "r")) )
    {
        char            *txt;
        long             txtlen;

        fseek( fp, 0, SEEK_END );
        txtlen = ftell(fp);
        rewind(fp);
        if ( NULL != (txt = malloc(txtlen+1)) )
        {
            if ( txtlen == fread( txt, 1, txtlen, fp ) )
            {
                /* unnecessary null term */ txt[txtlen] = '\0';

                htuple_parse_config_string( id, txt, txtlen );
            }

            free(txt);
        }

        fclose(fp);
    }
}

static int htuple_validate_int_value( 
    htuple_t         id,
    const char       *path,
    int              val )
{
   int         err = 0;
   int         tuple_val;

   err = htuple_get_int_value( id, path, strlen(path), &tuple_val );
   if ( ! err )
   {
      if ( val != tuple_val )
      {
         err = HTUPLE_ERR_INVALID_PARAM;
         printf("FAIL: htuple_validate_int_value( %d, \"%s\", 0x%x ) != %d\n", id, path, val, tuple_val );
      }
      else
      {
         printf("PASS: htuple_validate_int_value( %d, \"%s\", 0x%x )\n", id, path, val );
      }
   }
   else
   {
      printf("FAIL: htuple_validate_int_value( %d, \"%s\", 0x%x ) err \"%s\"\n", id, path, val, htuple_err_str(err) );
   }

   return(err);
}

static int htuple_validate_str_value( 
    htuple_t         id,
    const char       *path,
    const char       *val )
{
   int          err = 0;
   const char  *tuple_val;

   err = htuple_get_str_value( id, path, strlen(path), &tuple_val );
   if ( ! err )
   {
      if ( strcmp(val,tuple_val) )
      {
         err = HTUPLE_ERR_INVALID_PARAM;
         printf("FAIL: htuple_validate_str_value( %d, \"%s\", \"%s\" ) != \"%s\"\n", id, path, val, tuple_val );
      }
      else
      {
         printf("PASS: htuple_validate_str_value( %d, \"%s\", \"%s\" )\n", id, path, val );
      }
   }
   else
   {
      printf("FAIL: htuple_validate_str_value( %d, \"%s\", \"%s\" ) err \"%s\"\n", id, path, val, htuple_err_str(err) );
   }
   return(err);
}

static const char *htuple_validate_string = 
    "dict0 = 3\n"
    "{\n"
    "   anonymous {\n"
    "      {\n"
    "         t1 = \"uno\"\n"
    "         t2 = \"dos\"\n"
    "      }\n"
    "      {\n"
    "         t1 = \"tres\"\n"
    "         t2 = \"quattro\"\n"
    "      }\n"
    "   }\n"
    "   control.sub_1 = \"red\"     { a = 0x01 b = 0x02 } \n"
    "   control.sub_2               { a = 0x11 b = 0x12 } \n"
    "   deep.htuple.test.deep_1 = \"red\"{ a = 0x21 b = 0x22 } \n"
    "   deep.htuple.test.deep_2          { a = 0x31 b = 0x32 } \n"
    "   shallow.test_1 = \"green\" \n"
    "   shallow.test_2 = \"blue\" \n"
    "   deeper.single.test_1 = \"purple\" \n"
    "   deeper.single.test_2 = \"yellow\" \n"
    "   deeper.second.test_1 = \"mauve\" \n"
    "   deeper.second.test_2 = \"squash\" \n"
    "   deeper { { test_1 = 0x100 { beep = \"now\" } } { test_1 = 0x101 } }\n"
    "   recurse.test1 {\n"
    "      foo {\n"
    "         bar 1\n"
    "         control.sub_1 = \"red\"     { a = 0x41 b = 0x42 } \n"
    "         control.sub_2               { a = 0x51 b = 0x52 } \n"
    "      }\n"
    "   }\n"
    "   delete_me_test {\n"
    "      deleted_entry_1 = \"green\"\n"
    "      deleted_entry_2 = \"red\"\n"
    "   }\n"
    "   finish_dict0 = \"done\" \n"
    "}\n"
    "dict0.recurse.test1.foo.control.sub_1.a = 0xbb\n"
    "dict0.recurse.test1.foo.control.sub_2.a { baz 2 kar 3 }\n"
    "non_whitespace_open{ toad 7 }\n"
    "non_whitespace_open_2{toad{frog 6}}\n"
    "non_whitespace_open_3.foo{ beep 9 }\n"
    ;

static int htuple_validate_parser(
    htuple_t         id )
{
   int         err = 0;

   do
   {
      printf("htuple_validate_parser()\n");

      err = htuple_parse_config_string( id, htuple_validate_string, strlen(htuple_validate_string) );
      if ( !err )
      {
         printf("htuple_parse_config_string(%d)... ok\n", id );
      }
      else
      {
         printf("FAIL: htuple_parse_config_string(%d) failed \"%s\"\n", id, htuple_err_str(err) );
         break;
      }

      if ( 0 != (err = htuple_validate_str_value( id, "dict0.anonymous.0.t1", "uno" )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.anonymous.0.t2", "dos" )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.anonymous.1.t1", "tres" )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.anonymous.1.t2", "quattro" )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.control.sub_1", "red" )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.control.sub_1.a", 0x01 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.control.sub_1.b", 0x02 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.control.sub_2.a", 0x11 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.control.sub_2.b", 0x12 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.deep.htuple.test.deep_1.a", 0x21 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.deep.htuple.test.deep_1.b", 0x22 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.deep.htuple.test.deep_2.a", 0x31 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.deep.htuple.test.deep_2.b", 0x32 )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.shallow.test_1", "green" )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.shallow.test_2", "blue" )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.deeper.single.test_1", "purple" )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.deeper.single.test_2", "yellow" )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.deeper.second.test_1", "mauve" )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.deeper.second.test_2", "squash" )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.deeper.0.test_1", 0x100 )) )
         break;
      if ( 0 != (err = htuple_validate_str_value( id, "dict0.deeper.0.test_1.beep", "now" )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.deeper.1.test_1", 0x101 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.recurse.test1.foo.bar", 1 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.recurse.test1.foo.control.sub_1.b", 0x42 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.recurse.test1.foo.control.sub_2.a", 0x51 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.recurse.test1.foo.control.sub_2.b", 0x52 )) )
         break;
      /* note this was overwritten as parsing continued */
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.recurse.test1.foo.control.sub_1.a", 0xbb )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.recurse.test1.foo.control.sub_2.a.baz", 2 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "dict0.recurse.test1.foo.control.sub_2.a.kar", 3 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "non_whitespace_open.toad", 7 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "non_whitespace_open_2.toad.frog", 6 )) )
         break;
      if ( 0 != (err = htuple_validate_int_value( id, "non_whitespace_open_3.foo.beep", 9 )) )
         break;

      /* delete test */
      {
        unsigned int         delete_id;
        const char          *node_name_to_delete = "dict0.delete_me_test";

        if ( 0 != (delete_id = htuple_find_child( id, node_name_to_delete, strlen(node_name_to_delete) )) )
        {
            /* delete this node */
           htuple_delete_private_tree( delete_id );

           /* try to find the same node again */
           if ( 0 != (delete_id = htuple_find_child( id, node_name_to_delete, strlen(node_name_to_delete) )) )
           {
             err = 1;
             printf("ERR: node just deleted should not be found again\n");
           }
           else
           {
             printf("PASS: delete_private_tree() is clean\n");
           }
        }
        else
        {
         err = 1;
         printf("ERR: cannot find node to delete: \"%s\"\n", node_name_to_delete );
        }
      }

   } while( 0 );
   
   if ( 0 == err )
   {
      printf("PASS: htuple_validate_parser()\n");
   }
   else
   {
      printf("FAIL: htuple_validate_parser()\n\n");
      htuple_verbose_printf( id, 0 );
   }

   return(err);
}

int main( int argc, const char *argv[] )
{
   int              err = 0;
   htuple_t         private_id;
   struct DictNode *root;
   int              i;

   htuple_initialize();
   root = dm_FindHash( g_dm, 0 );

   if ( argc > 1 )
   {
      for ( i = 1; i < argc; i++ )
      {
         test_load_config_file( 0, argv[i] );
      }
      htuple_verbose_printf( 0, 0 );
      //htuple_dump( 0 );
      //self_debug_verbose( root );
   }
   else
   {
      err = htuple_validate_parser(0);
      if ( !err )
      {
         printf("private tree test...\n");

         if ( 0 == (err = htuple_create_private_tree( &private_id )) )
         {
            err = htuple_validate_parser( private_id );

            printf("htuple_delete_private_tree()\n" );
            htuple_delete_private_tree( private_id );
            printf("done\n" );
         }

         //htuple_verbose_printf( 0, 0 );
         //dict_debug_PrintHashChains( g_dm );
      }

      return(err);
   }

#if 0
    printf("private tree test...\n");
    if ( 0 == (err = htuple_create_private_tree( &private_id )) )
    {
        printf("htuple_create_private_tree() = %d\n", private_id );

        htuple_verbose_printf( private_id, 0 );

        printf("test_config_string(2)\n" );

        test_config_string( private_id, 2 );

        htuple_verbose_printf( private_id, 0 );

        printf("htuple_delete_private_tree()\n" );

        htuple_delete_private_tree( private_id );

        printf("done\n" );

        printf("test_config_string(1)\n" );

        err = test_config_string( private_id, 1 );

        printf("test_config_string(1) = %d %s\n", err, htuple_err_str(err) );

        //dict_debug_PrintHashChains( g_dm );
    }
    else printf("ERR: htuple_create_private_tree() returns %d\n", err );
#endif

    htuple_set_int_value( 0, "end.test0", 9, 0xabcd );
    htuple_set_int_value( 0, "end.test1", 9, 0x0123 );
    htuple_verbose_printf( 0, 0 );
    //dict_debug_PrintHashChains( g_dm );

    
    i = 0x100;

#if 0
#if 0
    htuple_set_int_value( 0, "01.23456789abcdefghijklmnopqrstuvwxyz", 5, 0x100 );
    self_debug_verbose( root );
    htuple_set_int_value( 0, "01.23456789abcdefghijklmnopqrstuvwxyz", 6, 0x101 );
    self_debug_verbose( root );
    htuple_set_int_value( 0, "01.23456789abcdefghijklmnopqrstuvwxyz", 6, 0x101 );
    self_debug_verbose( root );
#else

    self_debug_verbose( root );
    htuple_set_int_value( 0, "test0", 5, ++i );
    
    self_debug_verbose( root );

    htuple_set_int_value( 0, "test1", 5, ++i );
    htuple_set_int_value( 0, "test2", 5, ++i );
    htuple_set_int_value( 0, "test3", 3, ++i );
    htuple_set_int_value( 0, "test4", 5, ++i );
    htuple_set_int_value( 0, "test2x", 6, ++i );

    htuple_set_int_value( 0, "abcdef", 4, ++i );
    htuple_set_int_value( 0, "abcdef", 3, ++i );
    htuple_set_int_value( 0, "abcdef", 5, ++i );

    self_debug_verbose( root );

    htuple_set_int_value( 0, "deep0.test0", 11, ++i );

    self_debug_verbose( root );

    htuple_set_int_value( 0, "deep1.test0", 11, ++i );
    htuple_set_int_value( 0, "deep1.test1", 11, ++i );
    htuple_set_int_value( 0, "deep1.test2", 11, ++i );
    htuple_set_int_value( 0, "deep1.test3", 11, ++i );

    self_debug_verbose( root );

    htuple_set_str_value( 0, "deep2.test0", 11, "a", 1 );
    htuple_set_str_value( 0, "deep2.test1", 11, "b", 1 );
    htuple_set_str_value( 0, "deep2.test2", 11, "cde", 3 );

    self_debug_verbose( root );

    {
        unsigned int         id;

        if ( 0 != (id = htuple_find_child( 0, "abcd", 4 )) )
            print_htuple(id);
        if ( 0 != (id = htuple_find_child( 0, "abc", 3 )) )
            print_htuple(id);
        if ( 0 != (id = htuple_find_child( 0, "abcde", 5 )) )
            print_htuple(id);
    }
#endif
#endif

    return(err);
}
#endif
