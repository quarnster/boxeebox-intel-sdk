/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
   Intel Corporation

   2200 Mission College Blvd.
   Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

#include <stdio.h>

#include <pal.h>
#include <sven_module.h>

struct RegisterBankDescriptor
{
    const char              *rbd_name;     /* Unit Name */
    int                      rbd_module;    /* enum SVEN_Module */
    unsigned long            rbd_phys_addr; /* Default Physical address of unit (or zero if dynamic) */
    unsigned short           rbd_pci_vid;  /* PCI Vendor ID */
    unsigned short           rbd_pci_did;  /* PCI Device ID */
    int                      rbd_pci_bus;  /* PCI Config: Bus */
    int                      rbd_pci_dev;  /* PCI Config: Device */
    int                      rbd_pci_fun;  /* PCI Config: Function */
    int                      rbd_pci_bar;  /* PCI Config: BaseAddress Number */
    unsigned long            rbd_size;     /* Size (in bytes) of registers */
    int                      rbd_unit;     /* UKnit number (SVEN) */
    int                      rbd_pal_dev_id; /* UKnit number (SVEN) */
};

#define SVEN_module_CE31XX_invalid      SVEN_module_invalid
#define SVEN_module_CE31XX_AUD_DSP      SVEN_module_CE31XX_AUD_DSP0

#define CE31XX_DECLARE_UNIT_BAR( unit, base, base_end, pci_did, dev, func, bar, sven_module, sven_unit, pal_dev_id ) \
    { #unit , SVEN_module_CE31XX_##sven_module, ((base)&0x1fffffff), 0x8086, pci_did, 0, dev, func, bar, ((base_end)+1)-(base), sven_unit, pal_dev_id }

/* Taken From CE31XX_NorthBridge_and_Legacy_EAS by Pat Brouillette 2007-05-01 */
static const struct RegisterBankDescriptor g_devio_regbanks_PostSi[] =
{
CE31XX_DECLARE_UNIT_BAR( GFX,	   0xFC000000,	0xFCFFFFFF,	0x2E5B,	2,	0,	0,	GFX,        0, GFX_0 ),
CE31XX_DECLARE_UNIT_BAR( GPU_GMH,  0xFFFFAF00,	0xFFFFAFFF,	0x2E5B,	2,	0,	1,	GPU_GMH,    0, GPU_GMH ),
CE31XX_DECLARE_UNIT_BAR( CE,	   0xFF940000,	0xFF94FFFF,	0xFFFF,	2,	1,	0,	COMPOSITOR, 0, COMPOSITOR ),
CE31XX_DECLARE_UNIT_BAR( MFD_DEC,  0xFF9A0000,	0xFF9AFFFF,	0x2E5C,	3,	0,	0,	MFD,        0, MFD ),
CE31XX_DECLARE_UNIT_BAR( TS_PF,	   0xFF900000,	0xFF91FFFF,	0x2E5D,	4,	0,	0,	PREFILT,    0, TRANSPORT_PREFILTER_0 ), /* WARNING */
CE31XX_DECLARE_UNIT_BAR( TS_DMX,   0xFF920000,	0xFF93FFFF,	0x2E5E,	4,	1,	0,	DEMUX,      0, DEMUX_0 ),
CE31XX_DECLARE_UNIT_BAR( AU_DSP,   0xFFD00000,	0xFFD7FFFF,	0x2E5F,	6,	0,	0,	AUD_DSP,    0, TDSP_0 ),
CE31XX_DECLARE_UNIT_BAR( AU_DSP,   0xFFD80000,	0xFFDFFFFF,	0x2E5F,	6,	1,	0,	AUD_DSP,    1, TDSP_1 ),
CE31XX_DECLARE_UNIT_BAR( AU_IF,	   0xFFA80000,	0xFFA8FFFF,	0x2E60,	6,	2,	0,	AUD_IO,     0, AUDIO_0 ),
CE31XX_DECLARE_UNIT_BAR( VDC,	   0xFFB00000,	0xFFB0FFFF,	0x2E61,	8,	0,	0,	VDC,        0, VDC_0 ),
CE31XX_DECLARE_UNIT_BAR( DPE,	   0xFF960000,	0xFF96FFFF,	0x2E62,	8,	1,	0,	DPE,        0, DPE ),
CE31XX_DECLARE_UNIT_BAR( HDMI_TX,  0xFF950000,	0xFF95FFFF,	0x2E63,	8,	2,	0,	HDMI_TX,    0, HDMI_TX ),
CE31XX_DECLARE_UNIT_BAR( SEC,	   0xFFC00000,	0xFFCFFFFF,	0x2E64,	9,	0,	0,	SEC,        0, SEC ),
CE31XX_DECLARE_UNIT_BAR( SRAM,	   0xFF830000,	0xFF83FFFF,	0x2E64,	9,	0,	1,	SRAM,       0, SRAM ),
CE31XX_DECLARE_UNIT_BAR( EXP_CSR,  0xFFFE8000,	0xFFFE80FF,	0x2E65,	10,	0,	0,	EXP,        0, EXP ),
CE31XX_DECLARE_UNIT_BAR( EXP_WIN,  0xE0000000,	0xEFFFFFFF,	0x2E65,	10,	0,	1,	EXP_WIN,    0, EXP_WIN ),
CE31XX_DECLARE_UNIT_BAR( UART0,    0xFFFE0200,	0xFFFE02FF,	0x2E66,	11,	0,	0,	UART,       0, UART_0 ),
CE31XX_DECLARE_UNIT_BAR( UART1,    0xFFFE0300,	0xFFFE03FF,	0x2E66,	11,	0,	1,	UART,       1, UART_1 ),
CE31XX_DECLARE_UNIT_BAR( GPIO,	   0xFFFE0400,	0xFFFE04FF,	0x2E67,	11,	1,	0,	GPIO,       0, GPIO_0 ),
CE31XX_DECLARE_UNIT_BAR( I2C0,	   0xFFFE0500,	0xFFFE05FF,	0x2E68,	11,	2,	0,	I2C,        0, I2C_0 ),
CE31XX_DECLARE_UNIT_BAR( I2C1,	   0xFFFE0600,	0xFFFE06FF,	0x2E68,	11,	2,	1,	I2C,        1, I2C_1 ),
CE31XX_DECLARE_UNIT_BAR( I2C2,	   0xFFFE0700,	0xFFFE07FF,	0x2E68,	11,	2,	2,	I2C,        2, I2C_2 ),
CE31XX_DECLARE_UNIT_BAR( SC0,	   0xFFFE0800,	0xFFFE08FF,	0x2E69,	11,	3,	0,	SCARD,      0, SCARD_0 ),
CE31XX_DECLARE_UNIT_BAR( SC1,	   0xFFFE0900,	0xFFFE09FF,	0x2E69,	11,	3,	1,	SCARD,      1, SCARD_1 ),
CE31XX_DECLARE_UNIT_BAR( SPI,	   0xFFFE0A00,	0xFFFE0AFF,	0x2E6A,	11,	4,	0,	SPI,        0, SPI ),
CE31XX_DECLARE_UNIT_BAR( MSPOD,	   0xFF970000,	0xFF97FFFF,	0x2E6B,	11,	5,	0,	MSPOD,      0, MSPOD ),
CE31XX_DECLARE_UNIT_BAR( IR,	   0xFFFE0000,	0xFFFE00FF,	0x2E6C,	11,	6,	0,	IR,         0, IR ),
CE31XX_DECLARE_UNIT_BAR( DFX,	   0xFF8F0000,	0xFF8FFFFF,	0x2E6D,	11,	7,	0,	DFX,        0, DFX ),
CE31XX_DECLARE_UNIT_BAR( GBE,      0xFF860000,	0xFF87FFFF,	0x2E6E,	12,	0,	0,	GBE,        0, GBE ),
CE31XX_DECLARE_UNIT_BAR( GBE_MDIO, 0xFFFE0D00,	0xFFFE0DFF,	0x2E6E,	12,	0,	1,	GBE_MDIO,   0, GBE_MDIO ),
CE31XX_DECLARE_UNIT_BAR( CRU,      0xFFFE0D00,	0xFFFE0DFF,	0x2E6F,	12,	1,	0,	CRU,        0, CRU ),
CE31XX_DECLARE_UNIT_BAR( USB0,	   0xFF810000,	0xFF81FFFF,	0x2E70,	13,	0,	0,	USB,        0, USB_0 ),
CE31XX_DECLARE_UNIT_BAR( USB1,	   0xFF820000,	0xFF82FFFF,	0x2E70,	13,	1,	0,	USB,        1, USB_1 ),
CE31XX_DECLARE_UNIT_BAR( SATA,	   0xFF800000,	0xFF80FFFF,	0x2E71,	14,	0,	0,	SATA,       0, SATA_0 ),
   { NULL,0,0,0,0,0,0,0,0,0 }    /* NULL Terminator */
};

#if 0
static const struct RegisterBankDescriptor g_devio_regbanks_FairOaks[] =
{
CE31XX_DECLARE_UNIT_BAR( HDMI_TX,	        0,	(64*1024),	0x2E63,	8,	2,	0,	HDMI_TX ),
   { NULL,0,0,0,0,0,0,0,0,0 }    /* NULL Terminator */
};

#ifdef X86_PLATFORM_DETECTION_CODE
   const struct RegisterBankDescriptor    *rbd = NULL;
   uint32_t                                media_base_pa;
   
   // Running PostSilicon, northbridge
   if ( NULL != (pcidev = pci_find_device(0x8086,0x2e5a,NULL)))
     {
       rbd = g_devio_regbanks_PostSi;
       OS_PCI_READ_CONFIG_32(pcidev,0x10+(2<<2),&media_base_pa) );
     }
   // This is the MAV card on SLE
   else if ( NULL != (pcidev = pci_find_device(0x8086,0x1127,NULL)))
     {
       /* Unit offsets are relative to */
       rbd = g_devio_regbanks_PostSi;
       OS_PCI_READ_CONFIG_32(pcidev,0x10+(2<<2),&media_base_pa) );
     }
   // This is the Zolo-PCI card
   else if ( NULL != (pcidev = pci_find_device(0x8086,0xffff,NULL)))
     {
       /* Unit offsets are relative to */
       rbd = g_devio_regbanks_FairOaks;
       OS_PCI_READ_CONFIG_32(pcidev,0x10+(2<<2),&media_base_pa) );
     }
   // This is the HDMI Proto type card
   else if ( NULL != (pcidev = pci_find_device(0x8086,0x2e63,NULL)))
     {
       /* Unit offsets are relative to */
       rbd = g_devio_regbanks_FairOaks;
       OS_PCI_READ_CONFIG_32(pcidev,0x10+(2<<2),&media_base_pa) );
     }
   else
     {
       OS_PRINT("ERROR: Platform Detect Failure\n");
     }
#endif
#endif

/* To Compile:
 * gcc -Wall -I ../include -I ../../sven/include/ gen3_unit_check.c -o check
 */


int main( int argc, char *argv[] )
{
    int             i = 0;
    const struct RegisterBankDescriptor   *rbd = g_devio_regbanks_PostSi;
    
    while ( NULL != rbd[i].rbd_name )
    {
        printf(" %10s: PA: 0x%08x, SIZE: 0x%08x SVEN_Module:%3d SVEN_Unit:%d PAL_Dev_id:%3d\n", 
            rbd[i].rbd_name,
            (int) rbd[i].rbd_phys_addr,
            (int) rbd[i].rbd_size,
            (int) rbd[i].rbd_module,
            (int) rbd[i].rbd_unit,
            (int) rbd[i].rbd_pal_dev_id );

#if 0
        int     j;
        for ( j = 0; j < i; j++ )
        {
            if ( rbd[i]
        }
#endif
    
        i++;
    }
    
    return(0);
}
