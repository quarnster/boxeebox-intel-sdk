/*==========================================================================
  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
   Intel Corporation

   2200 Mission College Blvd.
   Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
=========================================================================*/

#include <linux/sched.h>
#include <linux/version.h>
#include "osal.h"
#include "pal.h"

#include <linux/pci.h>

extern int pic_mode;
extern int pal_get_dev_irq_bit(int device_key);
static volatile unsigned int *pic_regs;
#define PIC_CTRL_REG_OFFSET 32
#define PIC_STATUS_REG_OFFSET 33


//! Maps the Interrupt controller register set
int init_interrupts(void)
{
    int ret = 1; 
		
    if(pic_mode){
        os_pci_dev_t pcidev;
        unsigned physaddr = 0;

        if(os_pci_device_from_address(&pcidev, 0, 0, 1) != OSAL_SUCCESS){
            physaddr = 0xb0000000;
            OS_INFO("cannot find pci device 0:0:1, assuming BAR 0x%x\n",
                    physaddr);
            OS_ASSERT(false);
        } else if(os_pci_read_config_32(pcidev, 0x10, &physaddr) != OSAL_SUCCESS){
            OS_INFO("cannot read 0:0:1's BAR\n");
            ret = 0;
            goto pci_release;
        }
        pic_regs = OS_MAP_IO_TO_MEM_NOCACHE(physaddr, 4096);
pci_release:
        os_pci_free_device(pcidev);
    }
    return ret;
}

//! Unmaps the Interrupt controller register set   
void cleanup_interrupts(void)
{
    if(pic_mode && pic_regs){
        OS_UNMAP_IO_FROM_MEM(pic_regs, 4096);
    }
}

typedef struct _linux_int {
    int                     irq;
    void *                  data;
    wait_queue_head_t       wait_queue_head;
    struct task_struct *    task;
    bool                    pending;
    bool                    stop;
    unsigned int            devicekey;
    os_interrupt_t          irqhandle;
    os_interrupt_handler_t *handler;
} linux_int_t;


static int get_dev_irq_bit(int device_key)
{
   return (pal_get_dev_irq_bit(device_key));
}

// Check if the interrupt is for this device.  Mask it off if it is and return
// true.  If not, do nothing and return false.
bool check_and_disable_device_irq(int irq, int device_key)
{
    int devbit = get_dev_irq_bit(device_key);

    if(!pic_mode || devbit == 32){
        disable_irq(irq);
        return true;
    }

    // if there is an interrupt on this device, mask it
    if(pic_regs[PIC_STATUS_REG_OFFSET] & (1 << devbit)){
#ifdef CONFIG_X86_IO_APIC
        unsigned long flags;
        struct irq_desc *desc = irq_to_desc(irq);
        spin_lock_irqsave(&desc->lock, flags);
        desc->chip->mask(irq);
        spin_unlock_irqrestore(&desc->lock, flags);
#else
        pic_regs[PIC_CTRL_REG_OFFSET] |= (1 << devbit);
        // extra read to force the previous write to be flushed to HW
        (void)pic_regs[PIC_CTRL_REG_OFFSET];
#endif
        return true;
    }
    return false;
}


// re-enable interrupts from this device
void enable_device_irq(int irq, int device_key)
{
    unsigned long   flags;
    int             devbit = get_dev_irq_bit(device_key);

    if(!pic_mode || devbit == 32){
        enable_irq(irq);
    } else {
#ifdef CONFIG_X86_IO_APIC
        struct irq_desc *desc = irq_to_desc(irq);
        spin_lock_irqsave(&desc->lock, flags);
        desc->chip->unmask(irq);
        spin_unlock_irqrestore(&desc->lock, flags);
#else
        OS_DISABLE_INTERRUPTS(flags);
        pic_regs[PIC_CTRL_REG_OFFSET] &= ~(1 << devbit);
        OS_ENABLE_INTERRUPTS(flags);
#endif
    }
}


int kthread_wrapper(void *data)
{
    DEFINE_WAIT(wait);
    linux_int_t *   linux_int = (linux_int_t *)data;
    struct          sched_param prio = {MAX_RT_PRIO - 1};

    // set the priority of the kernel thread
    if(sched_setscheduler(current, SCHED_FIFO, &prio)){
        OS_PRINT("Couldn't set scheduler priority to %d!\n", prio.sched_priority);
    }

    while(0 == kthread_should_stop()) {
        // Return type is void
        prepare_to_wait(&linux_int->wait_queue_head, &wait, TASK_INTERRUPTIBLE);
        if(false == linux_int->pending) {
            schedule();
        }
        // Return type is void
        finish_wait(&linux_int->wait_queue_head, &wait);
        
        OS_DEBUG("Kernel thread woken up\n");
        // what do we do with signals
        // signal_pending(..) etc

        if(true == linux_int->pending) {
            // Call the handler and then re-enable the IRQ
            linux_int->handler(linux_int->data);
        
            // Reset the pending status
            linux_int->pending = false;
            enable_device_irq(linux_int->irq, linux_int->devicekey);
        }

        // check if we are being asked to stop
        // done in while loop
    }
    OS_DEBUG("thread wrapper returning\n");

    return 1;
}


void linux_interrupt_handler(void *data)
{
    linux_int_t *linux_int = (linux_int_t *)data;

    if(check_and_disable_device_irq(linux_int->irq, linux_int->devicekey)){
        linux_int->pending = true;

        // Wake up kernel thread
        wake_up_interruptible(&linux_int->wait_queue_head);
    }
}

#define MIN(a, b) ((a) < (b) ? (a):(b))

os_interrupt_t pal_acquire_interrupt(   int                     irq,
                                        int                     device_key,
                                        char *                  driver_name,
                                        os_interrupt_handler_t *handler,
                                        void *                  data)
{
    int             ret;
    char            kthread_name[80];
    int             name_len = 0;
    linux_int_t *   linux_int = (linux_int_t *)OS_ALLOC(sizeof(linux_int_t));

    if(!linux_int) {
        OS_ERROR("No memory for interrupt.\n");
        return NULL;
    }

    if(get_dev_irq_bit(device_key) == 32){
        OS_ERROR("bad device key? %d\n", device_key);
        os_backtrace();
    }

    OS_MEMSET(linux_int, 0, sizeof(linux_int_t));
    linux_int->irq      = irq;
    linux_int->data     = data;
    linux_int->handler  = handler;
    linux_int->pending  = false;
    linux_int->devicekey= device_key;

    if(driver_name != NULL) {
        name_len = MIN((strlen(driver_name)+1), sizeof(kthread_name));
        strncpy(kthread_name, driver_name, name_len);
        kthread_name[name_len - 1]='\0';
    } else {
        sprintf(kthread_name, "pal irq %d thread\n", irq);
    }

    init_waitqueue_head(&linux_int->wait_queue_head);
    linux_int->task = kthread_run(  kthread_wrapper,
                                    (void *)linux_int,
                                    "%s",
                                    kthread_name);

    if (IS_ERR(linux_int->task)) {
        OS_ERROR("kthread_run failed\n");
        OS_FREE(linux_int);
        linux_int = NULL;
    } else {
        OS_DEBUG("kthread_run succeeded\n");
    }      

    if(linux_int){
        ret = os_register_top_half( irq,
                                    &linux_int->irqhandle,
                                    &linux_interrupt_handler,
                                    (void *)linux_int,
                                    driver_name);

        if(ret) {
            OS_ERROR("Request IRQ returned %d for irq %d\n", ret, irq);
            kthread_stop(linux_int->task);
            OS_FREE(linux_int);
            return NULL;
        }
    }

    OS_DEBUG("Installed handler: %p for interrupt %d\n", (void*)handler, irq);

    return (os_interrupt_t)linux_int;
}


void pal_release_interrupt(os_interrupt_t interrupt)
{
    linux_int_t *linux_int = (linux_int_t *)interrupt;

    if(!linux_int) {
        OS_ERROR("parameter interrupt is NULL\n");
        return;
    }
        
    // Free the IRQ, this will ensure that the interrupt is disabled.
    // Return type is void
    OS_DEBUG("Freeing IRQ..");
    os_unregister_top_half(&linux_int->irqhandle);
    //
    // this is a hack until the priority of the interrupt thread is fixed
    linux_int->pending = false;
    OS_DEBUG("IRQ freed\n");
    
    // wakes up the thread, sets kthread_should_stop() to true, and waits for
    // thread to exit
    if( -EINTR == kthread_stop(linux_int->task)) {
        OS_ERROR("Error in kthread_stop\n");
    }
    OS_FREE(linux_int);
}
