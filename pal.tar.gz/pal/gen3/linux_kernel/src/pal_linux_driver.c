/*==========================================================================
  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
   Intel Corporation

   2200 Mission College Blvd.
   Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.



 =========================================================================*/

#include "osal.h"

#include "pal.h"
#include "pal_interrupt.h"
#include "pal_linux_compile.h"
#include <linux/proc_fs.h>

extern  int init_interrupts(void);
extern void cleanup_interrupts(void);
extern int pal_read_proc(char *buf, char **start, off_t offset,
                   int count, int *eof, void *data);
				   
extern pal_soc_info_t platform_info;				   
				   
struct RegisterBankDescriptor;
extern const struct RegisterBankDescriptor *pal_get_rbd_table( int *rbd_size );

#ifdef COMP_VER
#define xstringify(s) stringify(s)
#define stringify(s) #s
MODULE_VERSION(xstringify(COMP_VER));
char *version_string = "#@# pal_linux.ko " xstringify(COMP_VER) " " __DATE__ " " __TIME__;
#else
MODULE_VERSION("pal_linux  (" LINUX_COMPILE_BY "@" LINUX_COMPILE_HOST 
                                    ") (" LINUX_COMPILER ") " UTS_VERSION "\n");
char *version_string = "#@# pal_linux.ko 0.0.0.0000 <- COMP_VER undefined> " __DATE__ " " __TIME__;
#endif


/* These are predefined macros that specify different parameters
 * for our driver */ 
MODULE_AUTHOR("Intel Corporation, (C) 2005-2008 - All Rights Reserved");
MODULE_DESCRIPTION("Platform Abstraction Layer (PAL)");
MODULE_SUPPORTED_DEVICE("Intel Media Processors");
MODULE_LICENSE("Dual BSD/GPL");

//pic_mode: default 1: use A/V interrupt controller to mask interrupts if possible
int pic_mode = 1;

module_param(pic_mode,int,1);

#define PAL_PROC_FS_FNAME "socinfo"


/**
This function is called at module initialization time
@param[in] none
@retval 0: On Success
@retval xxx: On failure
*/
static int __init pal_init_module(void)
{
   // After reset reading from Bus 0, Dev 0, Func 0 will return:
   // A0 - 0b00000000, B0 - 0b00000010, B1 - 0b00000011
   //
   // BUT(!)... if anyone writes to Bus 0, Dev 31, Func 0, subsequent reads
   // of Bus 0, Dev 0, Func 0 will return:
   // A0 - 0b00000000, B0 - 0b00000100, B1 - 0b00000101
   //
   // So in the interest of ensuring that we get a consistant value, we will
   // write to Bus 0, Dev 31, Func 0 before we read Bus 0, Dev 0, Func 0 for
   // the purpose of determining the chipset ID.
   //
   // NOTE: The write only has to happen one time.  After the first write we
   //       don't need to do it anymore.
  
   os_pci_dev_t dev;
 
   OS_PRINT( "PAL driver init...\n");

   if ( os_pci_device_from_address(&dev, 0, 31, 0) != OSAL_SUCCESS ) {
      OS_INFO( "Unable to access PCI bus 0 device 31 function 0.\n" );
   }
   else if ( os_pci_write_config_8(dev, 0x08, 0) != OSAL_SUCCESS ) {
      OS_INFO( "Unable to write control reg.\n" );
   }


  if(0 == init_interrupts())
        return -ENOMEM;
  OS_PRINT("PIC mode = %d\n", pic_mode);
  
  OS_PRINT( "Device: ");
  if( pal_get_soc_info( &platform_info ) == PAL_SUCCESS ) {

    switch ( platform_info.name ) {
      case SOC_NAME_CE3100:
		OS_PRINT( "CE3100 \n" );
		break;
      case SOC_NAME_CE4100:
		OS_PRINT( "CE4100 \n" );
		break;		
	  case SOC_NAME_CE4200:
		OS_PRINT( "CE4200 \n" );
		break;
   	  case SOC_NAME_CE5300:
		OS_PRINT( "CE5300 \n" );
		break;
      default:
		OS_PRINT( "Unrecognized \n" );
		break;
    }

    switch ( platform_info.stepping )  {
      case SOC_STEPPING_A0:
		OS_PRINT( "Stepping: A0 \n" );
		break;
      case SOC_STEPPING_B0:
		OS_PRINT( "Stepping: B0 \n" );
		break;
      case SOC_STEPPING_B1:
		OS_PRINT( "Stepping: B1 \n" );
		break;
      case SOC_STEPPING_B2:
		OS_PRINT( "Stepping: B2 \n" );
		break;
      case SOC_STEPPING_C0:
		OS_PRINT( "Stepping: C0 \n" );
		break;
      case SOC_STEPPING_C1:
		OS_PRINT( "Stepping: C1 \n" );
		break;
      default:
		OS_PRINT( "Stepping: Unrecognized \n" );
		break;
    } 
  }
  else {
    OS_PRINT( "Unable to determine deivce ID Call to pal_get_soc_info failed.\n");
  }
  
// Set up the /proc fs entry to provide SOC family info to user mode
  create_proc_read_entry(PAL_PROC_FS_FNAME, 0 ,
			NULL, pal_read_proc,
			NULL ); 

  return 0;
}

/**
This function is called at module unload
@param[in] none
@retval none
*/
static void __exit pal_cleanup_module(void)
{
	//Tear down the /proc fs entry
	remove_proc_entry( PAL_PROC_FS_FNAME, NULL );
    cleanup_interrupts();
}



module_init(pal_init_module);
module_exit(pal_cleanup_module);

EXPORT_SYMBOL(pal_get_irq);
EXPORT_SYMBOL(pal_get_base_and_irq);
EXPORT_SYMBOL(pal_get_rbd_table);
EXPORT_SYMBOL(pal_acquire_interrupt);
EXPORT_SYMBOL(pal_release_interrupt);
EXPORT_SYMBOL(pal_get_chipset_id);
EXPORT_SYMBOL(pal_flush_chipset_cache);
EXPORT_SYMBOL(pal_get_soc_info);
