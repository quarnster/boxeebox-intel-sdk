/*
  This file is provided under a BSD license.  When using or
  redistributing this file, you may do so under this license.

  BSD LICENSE

  Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

#include <osal.h>
#include "pal.h"
#include "pal_interrupt.h"
#include <sven_module.h>


#define MAGIC_IRQ_NUMBER 3
#define PAL_DETECT_OVERWRITES_BASE_ADDRESSES 1

extern pal_soc_info_t platform_info;

enum Temp_SVEN_Module
{
    SVEN_module_CE5300_H264VE =100,
    SVEN_module_CE5300_TS_DMX2 ,
    SVEN_module_CE5300_SPI_S ,
    SVEN_module_CE5300_GFX2D ,
    SVEN_module_CE5300_SPI_F ,
    SVEN_module_CE5300_PWM,
    SVEN_module_CE5300_HDMI_RX ,
    SVEN_module_CE5300_GVSPARC_D ,
    SVEN_module_CE5300_EPU ,
    SVEN_module_CE5300_EMMC_HOST ,
    SVEN_module_CE5300_MAX
};


struct RegisterBankDescriptor
{
    const char *rbd_name; /* Unit Name */
    int rbd_module; /* enum SVEN_Module */
    unsigned long rbd_phys_addr; /* Default Physical address of unit (or zero if dynamic) */
    unsigned short rbd_pci_vid; /* PCI Vendor ID */
    unsigned short rbd_pci_did; /* PCI Device ID */
    unsigned int rbd_pci_bus; /* PCI Config: Bus */
    unsigned int rbd_pci_dev; /* PCI Config: Device */
    unsigned int rbd_pci_fun; /* PCI Config: Function */
    unsigned int rbd_pci_bar; /* PCI Config: BaseAddress Number */
    unsigned long rbd_size; /* Size (in bytes) of registers */
    int rbd_unit; /* UKnit number (SVEN) */
    int rbd_pal_dev_id; /* UKnit number (SVEN) */
};

#define SVEN_module_CE31XX_invalid SVEN_module_invalid
#define SVEN_module_CE31XX_AUD_DSP SVEN_module_CE31XX_AUD_DSP0

#define CE31XX_DECLARE_UNIT_BAR( unit, base, base_end, pci_vid, pci_did, dev, func, bar, sven_module, sven_unit, pal_dev_id ) { #unit , SVEN_module_GEN3_##sven_module, ((base)&0x1fffffff), pci_vid, pci_did, 0, dev, func, bar, ((base_end)+1)-(base), sven_unit, pal_dev_id }


#define GEN4_DECLARE_UNIT_BAR( unit, base, base_end, pci_vid, pci_did, dev, func, bar, sven_module, sven_unit, pal_dev_id ) { #unit , SVEN_module_GEN4_##sven_module, ((base)&0x1fffffff), pci_vid, pci_did, 0, dev, func, bar, ((base_end)+1)-(base), sven_unit, pal_dev_id }

#define CE5300_DECLARE_UNIT_BAR( unit, base, base_end, pci_vid, pci_did, dev, func, bar, sven_module, sven_unit, pal_dev_id ) { #unit , SVEN_module_CE5300_##sven_module, ((base)&0x1fffffff), pci_vid, pci_did, 0, dev, func, bar, ((base_end)+1)-(base), sven_unit, pal_dev_id }


/* Taken From CE31XX_NorthBridge_and_Legacy_EAS by Pat Brouillette 2007-05-01 */
static struct RegisterBankDescriptor g_devio_regbanks_PostSi_Gen3[] =
{
CE31XX_DECLARE_UNIT_BAR( GFX, 0xFC000000, 0xFCFFFFFF, 0x8086, 0x2E5B, 2, 0, 0, GFX, 0, GFX_0 ),
CE31XX_DECLARE_UNIT_BAR( GPU_GMH, 0xFFFFAF00, 0xFFFFAFFF, 0x8086, 0x2E5B, 2, 0, 1, GPU_GMH, 0, GPU_GMH ),
CE31XX_DECLARE_UNIT_BAR( CE, 0xFF940000, 0xFF94FFFF, 0x8086,0xFFFF, 2, 1, 0, COMPOSITOR, 0, COMPOSITOR ),
CE31XX_DECLARE_UNIT_BAR( MFD_DEC, 0xFF9A0000, 0xFF9AFFFF, 0x8086,0x2E5C, 3, 0, 0, MFD, 0, MFD ),
CE31XX_DECLARE_UNIT_BAR( PREFILT, 0xFF900000, 0xFF91FFFF, 0x8086,0x2E5D, 4, 0, 0, PREFILT, 0, TRANSPORT_PREFILTER_0 ), /* WARNING */
CE31XX_DECLARE_UNIT_BAR( DEMUX, 0xFF920000, 0xFF93FFFF, 0x8086,0x2E5E, 4, 1, 0, DEMUX, 0, DEMUX_0 ),
CE31XX_DECLARE_UNIT_BAR( AU_DSP0, 0xFFD00000, 0xFFD7FFFF, 0x8086,0x2E5F, 6, 0, 0, AUD_DSP0, 0, TDSP_0 ),
CE31XX_DECLARE_UNIT_BAR( AU_DSP1, 0xFFD80000, 0xFFDFFFFF, 0x8086,0x2E5F, 6, 1, 0, AUD_DSP1, 0, TDSP_1 ),
CE31XX_DECLARE_UNIT_BAR( AU_IF, 0xFFA80000, 0xFFA8FFFF, 0x8086,0x2E60, 6, 2, 0, AUD_IO, 0, AUDIO_0 ),
CE31XX_DECLARE_UNIT_BAR( VDC, 0xFFB00000, 0xFFB8FFFF, 0x8086,0x2E61, 8, 0, 0, VDC, 0, VDC_0 ),
CE31XX_DECLARE_UNIT_BAR( DPE, 0xFF960000, 0xFF96FFFF, 0x8086,0x2E62, 8, 1, 0, DPE, 0, DPE ),
CE31XX_DECLARE_UNIT_BAR( HDMI_TX, 0xFF950000, 0xFF95FFFF, 0x8086,0x2E63, 8, 2, 0, HDMI_TX, 0, HDMI_TX ),
CE31XX_DECLARE_UNIT_BAR( SEC, 0xFFC00000, 0xFFCFFFFF, 0x8086,0x2E64, 9, 0, 0, SEC, 0, SEC ),
CE31XX_DECLARE_UNIT_BAR( SRAM, 0xFF830000, 0xFF83FFFF, 0x8086,0x2E64, 9, 0, 1, SRAM, 0, SRAM ),
CE31XX_DECLARE_UNIT_BAR( EXP_CSR, 0xFFFE8000, 0xFFFE80FF, 0x8086,0x2E65, 10, 0, 0, EXP, 0, EXP ),
CE31XX_DECLARE_UNIT_BAR( EXP_WIN, 0xE0000000, 0xEFFFFFFF, 0x8086,0x2E65, 10, 0, 1, EXP_WIN, 0, EXP_WIN ),
CE31XX_DECLARE_UNIT_BAR( UART0, 0xFFFE0200, 0xFFFE02FF, 0x8086,0x2E66, 11, 0, 0, UART, 0, UART_0 ),
CE31XX_DECLARE_UNIT_BAR( UART1, 0xFFFE0300, 0xFFFE03FF, 0x8086,0x2E66, 11, 0, 1, UART, 1, UART_1 ),
CE31XX_DECLARE_UNIT_BAR( GPIO, 0xFFFE0400, 0xFFFE04FF, 0x8086, 0x2E67, 11, 1, 0, GPIO, 0, GPIO_0 ),
CE31XX_DECLARE_UNIT_BAR( I2C0, 0xFFFE0500, 0xFFFE05FF, 0x8086, 0x2E68, 11, 2, 0, I2C, 0, I2C_0 ),
CE31XX_DECLARE_UNIT_BAR( I2C1, 0xFFFE0600, 0xFFFE06FF, 0x8086, 0x2E68, 11, 2, 1, I2C, 1, I2C_1 ),
CE31XX_DECLARE_UNIT_BAR( I2C2, 0xFFFE0700, 0xFFFE07FF, 0x8086, 0x2E68, 11, 2, 2, I2C, 2, I2C_2 ),
CE31XX_DECLARE_UNIT_BAR( SC0, 0xFFFE0800, 0xFFFE08FF, 0x8086, 0x2E69, 11, 3, 0, SCARD, 0, SCARD_0 ),
CE31XX_DECLARE_UNIT_BAR( SC1, 0xFFFE0900, 0xFFFE09FF, 0x8086, 0x2E69, 11, 3, 1, SCARD, 1, SCARD_1 ),
CE31XX_DECLARE_UNIT_BAR( SPI, 0xFFFE0A00, 0xFFFE0AFF, 0x8086, 0x2E6A, 11, 4, 0, SPI, 0, SPI ),
CE31XX_DECLARE_UNIT_BAR( MSPOD, 0xFF970000, 0xFF97FFFF, 0x8086, 0x2E6B, 11, 5, 0, MSPOD, 0, MSPOD ),
CE31XX_DECLARE_UNIT_BAR( IR, 0xFFFE0000, 0xFFFE00FF, 0x8086, 0x2E6C, 11, 6, 0, IR, 0, IR ),
CE31XX_DECLARE_UNIT_BAR( DFX, 0xFF8F0000, 0xFF8FFFFF, 0x8086, 0x2E6D, 11, 7, 0, DFX, 0, DFX ),
CE31XX_DECLARE_UNIT_BAR( GBE, 0xFF860000, 0xFF87FFFF, 0x8086, 0x2E6E, 12, 0, 0, GBE, 0, GBE ),
CE31XX_DECLARE_UNIT_BAR( GBE_MDIO, 0xFFFE0D00, 0xFFFE0DFF, 0x8086, 0x2E6E, 12, 0, 1, GBE_MDIO, 0, GBE_MDIO ),
CE31XX_DECLARE_UNIT_BAR( CRU, 0xFFFE1000, 0xFFFE13FF, 0x8086, 0x2E6F, 12, 1, 0, CRU, 0, CRU ),
CE31XX_DECLARE_UNIT_BAR( USB0, 0xFF810100, 0xFF81FFFF, 0x192E, 0x0101, 13, 0, 0, USB, 0, USB_0 ),
CE31XX_DECLARE_UNIT_BAR( USB1, 0xFF820100, 0xFF82FFFF, 0x192E, 0x0101, 13, 1, 0, USB, 1, USB_1 ),
CE31XX_DECLARE_UNIT_BAR( SATA, 0xFF800000, 0xFF80FFFF, 0x8086, 0x2E71, 14, 0, 0, SATA, 0, SATA_0 ),
   { NULL,0,0,0,0,0,0,0,0,0,0,0 } /* NULL Terminator */
};

// Note: This rbd table currently represents both ce4100 and ce4200
static struct RegisterBankDescriptor g_devio_regbanks_PostSi_Gen4[] =
{
CE31XX_DECLARE_UNIT_BAR( GFX, 0xFC000000, 0xFCFFFFFF, 0x8086, 0x2E5B, 2, 0, 0, GFX, 0, GFX_0 ),
CE31XX_DECLARE_UNIT_BAR( GPU_GMH, 0xFFFFAF00, 0xFFFFAFFF, 0x8086, 0x2E5B, 2, 0, 1, GPU_GMH, 0, GPU_GMH ),
CE31XX_DECLARE_UNIT_BAR( CE, 0xFF940000, 0xFF94FFFF, 0x8086, 0xFFFF, 2, 1, 0, COMPOSITOR, 0, COMPOSITOR ),
CE31XX_DECLARE_UNIT_BAR( MFD_DEC, 0xFF9A0000, 0xFF9AFFFF, 0x8086, 0x2E5C, 3, 0, 0, MFD, 0, MFD ),
CE31XX_DECLARE_UNIT_BAR( PREFILT, 0xFF900000, 0xFF91FFFF, 0x8086, 0x2E5D, 4, 0, 0, PREFILT, 0, TRANSPORT_PREFILTER_0 ), /* WARNING */
CE31XX_DECLARE_UNIT_BAR( DEMUX, 0xFF920000, 0xFF93FFFF, 0x8086, 0x2E5E, 4, 1, 0, DEMUX, 0, DEMUX_0 ),
CE31XX_DECLARE_UNIT_BAR( AU_DSP0, 0xFFD00000, 0xFFD7FFFF, 0x8086, 0x2E5F, 6, 0, 0, AUD_DSP0, 0, TDSP_0 ),
CE31XX_DECLARE_UNIT_BAR( AU_DSP1, 0xFFD80000, 0xFFDFFFFF, 0x8086, 0x2E5F, 6, 1, 0, AUD_DSP1, 0, TDSP_1 ),
CE31XX_DECLARE_UNIT_BAR( AU_IF, 0xFFA80000, 0xFFA8FFFF, 0x8086, 0x2E60, 6, 2, 0, AUD_IO, 0, AUDIO_0 ),
CE31XX_DECLARE_UNIT_BAR( VDC, 0xFFB00000, 0xFFB8FFFF, 0x8086, 0x2E61, 8, 0, 0, VDC, 0, VDC_0 ),
CE31XX_DECLARE_UNIT_BAR( DPE, 0xFF960000, 0xFF96FFFF, 0x8086, 0x2E62, 8, 1, 0, DPE, 0, DPE ),
CE31XX_DECLARE_UNIT_BAR( HDMI_TX, 0xFF950000, 0xFF95FFFF, 0x8086, 0x2E63, 8, 2, 0, HDMI_TX, 0, HDMI_TX ),
CE31XX_DECLARE_UNIT_BAR( SEC, 0xFFC00000, 0xFFCFFFFF, 0x8086, 0x2E64, 9, 0, 0, SEC, 0, SEC ),
CE31XX_DECLARE_UNIT_BAR( SRAM, 0xFF830000, 0xFF83FFFF, 0x8086, 0x2E64, 9, 0, 1, SRAM, 0, SRAM ),
CE31XX_DECLARE_UNIT_BAR( EXP_CSR, 0xFFFE8000, 0xFFFE80FF, 0x8086, 0x2E65, 10, 0, 0, EXP, 0, EXP ),
CE31XX_DECLARE_UNIT_BAR( EXP_WIN, 0xE0000000, 0xEFFFFFFF, 0x8086, 0x2E65, 10, 0, 1, EXP_WIN, 0, EXP_WIN ),
CE31XX_DECLARE_UNIT_BAR( UART0, 0xFFFE0200, 0xFFFE02FF, 0x8086, 0x2E66, 11, 0, 0, UART, 0, UART_0 ),
CE31XX_DECLARE_UNIT_BAR( UART1, 0xFFFE0300, 0xFFFE03FF, 0x8086, 0x2E66, 11, 0, 1, UART, 1, UART_1 ),
CE31XX_DECLARE_UNIT_BAR( GPIO, 0xFFFE0400, 0xFFFE04FF, 0x8086, 0x2E67, 11, 1, 0, GPIO, 0, GPIO_0 ),
CE31XX_DECLARE_UNIT_BAR( I2C0, 0xFFFE0500, 0xFFFE05FF, 0x8086, 0x2E68, 11, 2, 0, I2C, 0, I2C_0 ),
CE31XX_DECLARE_UNIT_BAR( I2C1, 0xFFFE0600, 0xFFFE06FF, 0x8086, 0x2E68, 11, 2, 1, I2C, 1, I2C_1 ),
CE31XX_DECLARE_UNIT_BAR( I2C2, 0xFFFE0700, 0xFFFE07FF, 0x8086, 0x2E68, 11, 2, 2, I2C, 2, I2C_2 ),
CE31XX_DECLARE_UNIT_BAR( SC0, 0xFFFE0800, 0xFFFE08FF, 0x8086, 0x2E69, 11, 3, 0, SCARD, 0, SCARD_0 ),
CE31XX_DECLARE_UNIT_BAR( SC1, 0xFFFE0900, 0xFFFE09FF, 0x8086, 0x2E69, 11, 3, 1, SCARD, 1, SCARD_1 ),
CE31XX_DECLARE_UNIT_BAR( SPI, 0xFFFE0A00, 0xFFFE0AFF, 0x8086, 0x2E6A, 11, 4, 0, SPI, 0, SPI ),
CE31XX_DECLARE_UNIT_BAR( MSPOD, 0xFF970000, 0xFF97FFFF, 0x8086, 0x2E6B, 11, 5, 0, MSPOD, 0, MSPOD ),
CE31XX_DECLARE_UNIT_BAR( IR, 0xFFFE0000, 0xFFFE00FF, 0x8086, 0x2E6C, 11, 6, 0, IR, 0, IR ),
CE31XX_DECLARE_UNIT_BAR( DFX, 0xFF8F0000, 0xFF8FFFFF, 0x8086, 0x2E6D, 11, 7, 0, DFX, 0, DFX ),
CE31XX_DECLARE_UNIT_BAR( GBE, 0xFF860000, 0xFF87FFFF, 0x8086, 0x2E6E, 12, 0, 0, GBE, 0, GBE ),
CE31XX_DECLARE_UNIT_BAR( GBE_MDIO, 0xFFFE0D00, 0xFFFE0DFF, 0x8086, 0x2E6E, 12, 0, 1, GBE_MDIO, 0, GBE_MDIO ),
CE31XX_DECLARE_UNIT_BAR( CRU, 0xFFFE1000, 0xFFFE13FF, 0x8086, 0x2E6F, 12, 1, 0, CRU, 0, CRU ),
CE31XX_DECLARE_UNIT_BAR( USB0, 0xFF810100, 0xFF81FFFF, 0x192E, 0x0101, 13, 0, 0, USB, 0, USB_0 ),
CE31XX_DECLARE_UNIT_BAR( USB1, 0xFF820100, 0xFF82FFFF, 0x192E, 0x0101, 13, 1, 0, USB, 1, USB_1 ),
CE31XX_DECLARE_UNIT_BAR( SATA, 0xFF800000, 0xFF80FFFF, 0x8086, 0x2E71, 14, 0, 0, SATA, 0, SATA_0 ),

GEN4_DECLARE_UNIT_BAR( GV, 0xFFF20000, 0xFFF3FFFF, 0x8086, 0x0703, 17, 0, 0, GV, 0, GV ),
GEN4_DECLARE_UNIT_BAR( MEUCSR, 0xFF940000, 0xFF94FFFF, 0x8086, 0x0702, 16, 0, 0, MEU, 0, MEU_CSR ),
GEN4_DECLARE_UNIT_BAR( MEUREG0, 0xF0000000, 0xF3FFFFFF, 0x8086, 0x0702, 16, 0, 1, MEU, 0, MEU_REG0 ),
GEN4_DECLARE_UNIT_BAR( MEUREG1, 0xF4000000, 0xF7FFFFFF, 0x8086, 0x0702, 16, 0, 2, MEU, 0, MEU_REG1 ),
GEN4_DECLARE_UNIT_BAR( HDVCAP, 0xFFFFA000, 0xFFFFA3FF, 0x8086, 0x2E63, 18, 0, 0, HDVCAP, 0, HDVCAP ),
GEN4_DECLARE_UNIT_BAR( NAND_DEV, 0xFFF00000, 0xFFF0FFFF, 0x8086, 0x0701, 15, 0, 0, NAND_DEV, 0, NAND_DEV ),
GEN4_DECLARE_UNIT_BAR( NAND_CSR, 0xFFF10000, 0xFFF1FFFF, 0x8086, 0x0701, 15, 0, 0, NAND_CSR, 0, NAND_CSR ),
   { NULL,0,0,0,0,0,0,0,0,0,0,0 } /* NULL Terminator */
};

// Note: This rbd table currently represents for Gen5
static struct RegisterBankDescriptor g_devio_regbanks_PostSi_Gen5[] =
{
CE31XX_DECLARE_UNIT_BAR( GFX, 0xFC000000, 0xFCFFFFFF, 0x8086, 0x089B, 2, 0, 0, GFX, 0, GFX_0 ),
CE31XX_DECLARE_UNIT_BAR( GPU_GMH, 0xFFFFAF00, 0xFFFFAFFF, 0x8086, 0x089B, 2, 0, 1, GPU_GMH, 0, GPU_GMH ),

CE31XX_DECLARE_UNIT_BAR( MFD_MFVDP, 0xFF9A4000, 0xFF9A7FFF, 0x8086, 0x2E5C, 3, 0, 0, MFD, 0, MFD ),
CE31XX_DECLARE_UNIT_BAR( MFD_H264VDP, 0xFF9A1000, 0xFF9A1FFF, 0x8086, 0x2E5C, 3, 0, 1, MFD, 1, H264VDP ),
CE31XX_DECLARE_UNIT_BAR( MFD_VC1VDP, 0xFF9A2000, 0xFF9A2FFF, 0x8086, 0x2E5C, 3, 0, 2, MFD, 2, VC1VDP ),
CE31XX_DECLARE_UNIT_BAR( MFD_MPG2VDP, 0xFF930000, 0xFF9A3FFF, 0x8086, 0x2E5C, 3, 0, 3, MFD, 3, MPG2VDP ),

CE31XX_DECLARE_UNIT_BAR( PREFILT, 0xFF900000, 0xFF91FFFF, 0x8086, 0x2E5D, 4, 0, 0, PREFILT, 0, TRANSPORT_PREFILTER_0 ), /* WARNING */

CE31XX_DECLARE_UNIT_BAR( AU_DSP0, 0xFFD00000, 0xFFD7FFFF, 0x8086, 0x2E5F, 6, 0, 0, AUD_DSP0, 0, TDSP_0 ),
CE31XX_DECLARE_UNIT_BAR( AU_DSP1, 0xFFD80000, 0xFFDFFFFF, 0x8086, 0x2E5F, 6, 1, 0, AUD_DSP1, 0, TDSP_1 ),
CE31XX_DECLARE_UNIT_BAR( AU_IF, 0xFFA80000, 0xFFA8FFFF, 0x8086, 0x2E60, 6, 2, 0, AUD_IO, 0, AUDIO_0 ),

CE31XX_DECLARE_UNIT_BAR( VDC, 0xFFB00000, 0xFFB8FFFF, 0x8086, 0x2E61, 8, 0, 0, VDC, 0, VDC_0 ),
CE31XX_DECLARE_UNIT_BAR( DPE, 0xFF960000, 0xFF96FFFF, 0x8086, 0x2E62, 8, 1, 0, DPE, 0, DPE ),
CE31XX_DECLARE_UNIT_BAR( HDMI_TX, 0xFF950000, 0xFF95FFFF, 0x8086, 0x2E63, 8, 2, 0, HDMI_TX, 0, HDMI_TX ),

CE31XX_DECLARE_UNIT_BAR( SEC, 0xFFC00000, 0xFFCFFFFF, 0x8086, 0x2E64, 9, 0, 0, SEC, 0, SEC ),
CE31XX_DECLARE_UNIT_BAR( SRAM, 0xFF830000, 0xFF83FFFF, 0x8086, 0x2E64, 9, 0, 1, SRAM, 0, SRAM ),

CE31XX_DECLARE_UNIT_BAR( EXP_CSR, 0xFFFE8000, 0xFFFE80FF, 0x8086, 0x2E65, 10, 0, 0, EXP, 0, EXP ),
CE31XX_DECLARE_UNIT_BAR( EXP_WIN, 0xE0000000, 0xEFFFFFFF, 0x8086, 0x2E65, 10, 0, 1, EXP_WIN, 0, EXP_WIN ),

CE31XX_DECLARE_UNIT_BAR( UART0, 0xFFFE0200, 0xFFFE02FF, 0x8086, 0x2E66, 11, 0, 0, UART, 0, UART_0 ),
CE31XX_DECLARE_UNIT_BAR( UART1, 0xFFFE0300, 0xFFFE03FF, 0x8086, 0x2E66, 11, 0, 1, UART, 1, UART_1 ),
CE31XX_DECLARE_UNIT_BAR( UART3, 0xFFFE0B00, 0xFFFE0BFF, 0x8086, 0x2E66, 11, 0, 2, UART, 2, UART_3),

CE31XX_DECLARE_UNIT_BAR( GPIO, 0xFFFE0400, 0xFFFE04FF, 0x8086, 0x2E67, 11, 1, 0, GPIO, 0, GPIO_0 ),

CE31XX_DECLARE_UNIT_BAR( I2C0, 0xFFFE0500, 0xFFFE05FF, 0x8086, 0x2E68, 11, 2, 0, I2C, 0, I2C_0 ),
CE31XX_DECLARE_UNIT_BAR( I2C1, 0xFFFE0600, 0xFFFE06FF, 0x8086, 0x2E68, 11, 2, 1, I2C, 1, I2C_1 ),
CE31XX_DECLARE_UNIT_BAR( I2C2, 0xFFFE0700, 0xFFFE07FF, 0x8086, 0x2E68, 11, 2, 2, I2C, 2, I2C_2 ),
CE31XX_DECLARE_UNIT_BAR( I2C3, 0xFFFE0E00, 0xFFFE0EFF, 0x8086, 0x2E68, 11, 2, 3, I2C, 3, I2C_3 ),


CE31XX_DECLARE_UNIT_BAR( SC0, 0xFFFE0800, 0xFFFE08FF, 0x8086, 0x2E69, 11, 3, 0, SCARD, 0, SCARD_0 ),
CE31XX_DECLARE_UNIT_BAR( SC1, 0xFFFE0900, 0xFFFE09FF, 0x8086, 0x2E69, 11, 3, 1, SCARD, 1, SCARD_1 ),

CE31XX_DECLARE_UNIT_BAR( SPI, 0xFFFE0A00, 0xFFFE0AFF, 0x8086, 0x2E6A, 11, 4, 0, SPI, 0, SPI ),

CE31XX_DECLARE_UNIT_BAR( MSPOD, 0xFF970000, 0xFF97FFFF, 0x8086, 0x2E6B, 11, 5, 0, MSPOD, 0, MSPOD ),

CE5300_DECLARE_UNIT_BAR( PWM, 0xFFFE0F00, 0xFFFE0FFF, 0x8086, 0x089F, 11, 6, 0, PWM, 0, PWM ),

CE31XX_DECLARE_UNIT_BAR( DFx, 0xFF8F0000, 0xFF8FFFFF, 0x8086, 0x2E6D, 11, 7, 0, DFX, 0, DFX ),

CE31XX_DECLARE_UNIT_BAR( GBE, 0xFF860000, 0xFF87FFFF, 0x8086, 0x2E6E, 12, 0, 0, GBE, 0, GBE ),
CE31XX_DECLARE_UNIT_BAR( GBE_MDIO, 0xFFFE0D00, 0xFFFE0DFF, 0x8086, 0x2E6E, 12, 0, 1, GBE_MDIO, 0, GBE_MDIO ),

CE31XX_DECLARE_UNIT_BAR( CRU, 0xFFFE1000, 0xFFFE13FF, 0x8086, 0x2E6F, 12, 1, 0, CRU, 0, CRU ),

CE31XX_DECLARE_UNIT_BAR( USB0, 0xFF810100, 0xFF81FFFF, 0x192E, 0x0101, 13, 0, 0, USB, 0, USB_0 ),
CE31XX_DECLARE_UNIT_BAR( USB1, 0xFF820100, 0xFF82FFFF, 0x192E, 0x0101, 13, 1, 0, USB, 1, USB_1 ),
CE31XX_DECLARE_UNIT_BAR( USB2, 0xFF880100, 0xFF88FFFF, 0x192E, 0x0101, 13, 2, 0, USB, 2, USB_2 ),



GEN4_DECLARE_UNIT_BAR( MEUCSR, 0xFF940000, 0xFF94FFFF, 0x8086, 0x0702, 16, 0, 0, MEU, 0, MEU_CSR ),
GEN4_DECLARE_UNIT_BAR( MEUREG0, 0xF0000000, 0xF3FFFFFF, 0x8086, 0x0702, 16, 0, 1, MEU, 0, MEU_REG0 ),
GEN4_DECLARE_UNIT_BAR( MEUREG1, 0xF4000000, 0xF7FFFFFF, 0x8086, 0x0702, 16, 0, 2, MEU, 0, MEU_REG1 ),

GEN4_DECLARE_UNIT_BAR( GV, 0xFFF20000, 0xFFF3FFFF, 0x8086, 0x0703, 17, 0, 0, GV, 0, GV ),


GEN4_DECLARE_UNIT_BAR( HDVCAP, 0xFFFFA000, 0xFFFFA3FF, 0x8086, 0x0704, 18, 0, 0, HDVCAP, 0, HDVCAP ),

CE5300_DECLARE_UNIT_BAR( H264VE, 0xFFFFA400, 0xFFFFA7FF, 0x8086, 0x0706, 19, 0, 0, H264VE, 0, H264VE ),

CE5300_DECLARE_UNIT_BAR( TS_DMX2, 0xFFE00000, 0xFFEFFFFF, 0x8086, 0x0705, 20, 0, 0, TS_DMX2, 0, TS_DMX2 ),

CE5300_DECLARE_UNIT_BAR( SPI_S, 0xFFFE0c00, 0xFFFE0cFF, 0x8086, 0x0707, 21, 0, 0, SPI_S, 0, SPI_S ),

CE5300_DECLARE_UNIT_BAR( GFX2D, 0xFFAC0000, 0xFFAFFFFF, 0x8086, 0x070A, 22, 0, 0, GFX2D, 0, GFX2D ),
CE5300_DECLARE_UNIT_BAR( GFX2D_CSR, 0xFFAB0000, 0xFFABFFFF, 0x8086, 0x070A, 22, 0, 1, GFX2D, 1, GFX2D_CSR ),

CE5300_DECLARE_UNIT_BAR( SPI_F_CSR0, 0xFFFE0100, 0xFFFE01FF, 0x8086, 0x08A0, 23, 0, 0, SPI_F, 0, SPI_F_CSR0 ),
CE5300_DECLARE_UNIT_BAR( SPI_F_WIN, 0xF8000000, 0xFFBFFFFF, 0x8086, 0x08A0, 23, 0, 1, SPI_F, 1, SPI_F_WIN ),
CE5300_DECLARE_UNIT_BAR( SPI_F_CSR1, 0xFFFE0000, 0xFFFE0FF, 0x8086, 0x08A0, 23, 0, 2, SPI_F, 2, SPI_F_CSR1 ),

CE5300_DECLARE_UNIT_BAR( HDMI_RX, 0xFFA90000, 0xFFA9FFFF, 0x8086, 0x089E, 24, 0, 0, HDMI_RX, 0, HDMI_RX ),

CE5300_DECLARE_UNIT_BAR( GVSPARC_D, 0xFFF40000, 0xFFF5FFFF, 0x8086, 0x089D, 25, 0, 0, GVSPARC_D, 0, GVSPARC_D ),

CE5300_DECLARE_UNIT_BAR( EPU, 0xFF8A0000, 0xFF8AFFFF, 0x8086, 0x089C, 26, 0, 0, EPU, 0, EPU ),

CE5300_DECLARE_UNIT_BAR( EMMC_HOST, 0xFFF00000, 0xFFF000FF, 0x8086, 0x070B, 27, 0, 0, EMMC_HOST, 0, EMMC_HOST ),
CE5300_DECLARE_UNIT_BAR( EMMC_AUX, 0xFFF00100, 0xFFF001FF, 0x8086, 0x070B, 27, 0, 1, EMMC_HOST, 1, EMMC_AUX ),

   { NULL,0,0,0,0,0,0,0,0,0,0,0 } /* NULL Terminator */
};
/**
 * @brief         Identify the current platform
 *
 * This function is similar in nature to pal_get_chipset_id
 * which may be deprecated in the future.
 *
 * @param        info    : Area to receive id data
 * @returns      pal_result_t
 */
pal_result_t
pal_get_soc_info(pal_soc_info_t *info)
{
   pal_result_t result = PAL_FAILURE;
   os_pci_dev_t pci_dev;
   unsigned int Device_ID_Vendor_ID;
   unsigned char Revision_ID;
   if(NULL == info)
   {
      OS_INFO( "%s: Input parameter is invalid.\n",__FUNCTION__ );
      return PAL_FAILURE;
   }
   if ( os_pci_device_from_address(&pci_dev, 0, 0, 0) != OSAL_SUCCESS ) {
      OS_INFO( "%s: Unable to access PCI bus 0 device 0 function 0.\n",__FUNCTION__ );
      result = PAL_FAILURE;
   }
   else if ( os_pci_read_config_32(pci_dev, 0x00, &Device_ID_Vendor_ID) != OSAL_SUCCESS ) {
      OS_INFO( "Unable to read Device ID and Vendor ID.\n" );
      result = PAL_FAILURE;
   }
   else if ( os_pci_read_config_8(pci_dev, 0x08, &Revision_ID) != OSAL_SUCCESS ) {
      OS_INFO( "Unable to read Revision ID.\n" );
      result = PAL_FAILURE;
   }
   else {
      /* Is this a Generation 3 Intel Consumer Electronics SOC? */
      if ( Device_ID_Vendor_ID == 0x2E508086 ) {
         info->name = SOC_NAME_CE3100;
         switch ( Revision_ID ) {
            case 0: /* Stepping A-0 */
               info->generation = SOC_GENERATION_3;
               info->stepping = SOC_STEPPING_A0;
               result = PAL_SUCCESS;
               break;
            case 4: /* Stepping B-0 */
               info->generation = SOC_GENERATION_3;
               info->stepping = SOC_STEPPING_B0;
               result = PAL_SUCCESS;
               break;
            case 5: /* Stepping B-1 */
               info->generation = SOC_GENERATION_3;
               info->stepping = SOC_STEPPING_B1;
               result = PAL_SUCCESS;
               break;
            default: /* Unknown Stepping. */
               OS_INFO( "Unknown Revision ID: 0x%02X\n", Revision_ID );
               info->generation = SOC_GENERATION_3;
               info->stepping = SOC_STEPPING_XX;
               result = PAL_FAILURE;
               break;
         }
      }
      /* Is this a Generation 4 Intel Consumer Electronics SOC? */
      else if ( Device_ID_Vendor_ID == 0x07088086 ) {
         info->name = SOC_NAME_CE4100;
         switch ( Revision_ID ) {
            case 0: /* Stepping A-0 */
               info->generation = SOC_GENERATION_4;
               info->stepping = SOC_STEPPING_A0;
               result = PAL_SUCCESS;
               break;
            case 4: /* Stepping B-0 */
               info->generation = SOC_GENERATION_4;
               info->stepping = SOC_STEPPING_B0;
               result = PAL_SUCCESS;
               break;
            case 5: /* Stepping B-1 */
               info->generation = SOC_GENERATION_4;
               info->stepping = SOC_STEPPING_B1;
               result = PAL_SUCCESS;
               break;
            case 6: /* Stepping B-2 */
               info->generation = SOC_GENERATION_4;
               info->stepping = SOC_STEPPING_B2;
               result = PAL_SUCCESS;
               break;
            case 8: /* Stepping C-0 */
               info->generation = SOC_GENERATION_4;
               info->stepping = SOC_STEPPING_C0;
               result = PAL_SUCCESS;
               break;
            case 9: /* Stepping C-1 */
               info->generation = SOC_GENERATION_4;
               info->stepping = SOC_STEPPING_C1;
               result = PAL_SUCCESS;
               break;
            default: /* Unknown Stepping. */
               OS_INFO( "Unknown Revision ID: 0x%02X\n", Revision_ID );
               info->generation = SOC_GENERATION_4;
               info->stepping = SOC_STEPPING_XX;
               result = PAL_FAILURE;
               break;
         }
      }
      /* Is this a Generation 5 Intel Consumer Electronics SOC? */
      else if ( Device_ID_Vendor_ID == 0x07098086 ) {
         info->name = SOC_NAME_CE4200;
         switch ( Revision_ID ) {
            case 0: /* Stepping A-0 */
               info->generation = SOC_GENERATION_5;
               info->stepping = SOC_STEPPING_A0;
               result = PAL_SUCCESS;
               break;
            case 4: /* Stepping B-0 */
               info->generation = SOC_GENERATION_5;
               info->stepping = SOC_STEPPING_B0;
               result = PAL_SUCCESS;
               break;
            case 5: /* Stepping B-1 */
               info->generation = SOC_GENERATION_5;
               info->stepping = SOC_STEPPING_B1;
               result = PAL_SUCCESS;
               break;
            case 8: /* Stepping C-0 */
               info->generation = SOC_GENERATION_5;
               info->stepping = SOC_STEPPING_C0;
               result = PAL_SUCCESS;
               break;
            default: /* Unknown Stepping. */
               OS_INFO( "Unknown Revision ID: 0x%02X\n", Revision_ID );
               info->generation = SOC_GENERATION_5;
               info->stepping = SOC_STEPPING_XX;
               result = PAL_FAILURE;
               break;
         }
      }
      /* Is this a Generation 5300 Intel Consumer Electronics SOC? */
      else if ( Device_ID_Vendor_ID == 0x0C408086 ) {
         info->name = SOC_NAME_CE5300;
         switch ( Revision_ID ) {
            case 0: /* Stepping A-0 */
               info->generation = SOC_GENERATION_5300;
               info->stepping = SOC_STEPPING_A0;
               result = PAL_SUCCESS;
               break;
            case 2: /* Stepping B-0 */
               info->generation = SOC_GENERATION_5300;
               info->stepping = SOC_STEPPING_B0;
               result = PAL_SUCCESS;
               break;
            default: /* Unknown Stepping. */
               OS_INFO( "Unknown Revision ID: 0x%02X\n", Revision_ID );
               info->generation = SOC_GENERATION_5300;
               info->stepping = SOC_STEPPING_XX;
               result = PAL_FAILURE;
               break;
         }
      }
      else {
         OS_INFO( "Unknown Device ID:Vendor ID   0x%08X\n", Device_ID_Vendor_ID );
         OS_INFO( "                  Revision ID %d\n", Revision_ID );
         result = PAL_FAILURE;
      }
   }
   return ( result );
}
/**
 * @brief        Get the RBD for the current platform
 *
 * @param         none    : none
 *
 * @returns      RegisterBankDescriptor *. NULL upon failure.
 *
 * @see ipc_mq_write_from_pos
 *
 */
static const struct RegisterBankDescriptor *
pal_detect_platform(void)
{
    static int platform_detect_attempted = 0;
    static struct RegisterBankDescriptor *platform_rbd = NULL;
    static uint32_t platform_media_base_pa = 0;
    static uint32_t platform_media_base_mask = 0x1fffffff;
    if ( ! platform_detect_attempted )
    {
     os_pci_dev_t pcidev;
        // Running PostSilicon, northbridge
        if ( OSAL_SUCCESS == OS_PCI_FIND_FIRST_DEVICE(0x8086,0x2e5a,&pcidev) )
        {
            uint16_t membase;
            platform_rbd = g_devio_regbanks_PostSi_Gen3;
            OS_PCI_READ_CONFIG_16(pcidev,0x20,&membase);
            platform_media_base_pa = (uint32_t)membase << 16;
        }
        else if ( OSAL_SUCCESS == OS_PCI_FIND_FIRST_DEVICE(0x8086,0x0C40,&pcidev) )
        {
         // Note: We first use the Host Bridge to identify the new generation CE processor,
         // then to get the membase fromt he AV bridge.
            uint16_t membase;
            if ( OSAL_SUCCESS == OS_PCI_FIND_FIRST_DEVICE(0x8086,0x0700,&pcidev) ) {
                  platform_rbd = g_devio_regbanks_PostSi_Gen5;
                  OS_PCI_READ_CONFIG_16(pcidev,0x20,&membase);
                  platform_media_base_pa = (uint32_t)membase << 16;
              }
            else {
                  platform_rbd = g_devio_regbanks_PostSi_Gen3;
                  platform_media_base_pa = 0xc0000000;
                  OS_INFO("Error: Platform Detect Failure, assuming 0xc0000000\n");
              }
        }
 else if ( OSAL_SUCCESS == OS_PCI_FIND_FIRST_DEVICE(0x8086,0x0700,&pcidev) )
        {
         // Note: We are using the same rbd table to represent both ce4100 and ce4200 
  // because the device ID is the same
            uint16_t membase;
            platform_rbd = g_devio_regbanks_PostSi_Gen4;
            OS_PCI_READ_CONFIG_16(pcidev,0x20,&membase);
            platform_media_base_pa = (uint32_t)membase << 16;
        }
        else
        {
            platform_rbd = g_devio_regbanks_PostSi_Gen3;
            platform_media_base_pa = 0xc0000000;
            OS_INFO("Error: Platform Detect Failure, assuming 0xc0000000\n");
        }
    #ifdef PAL_DETECT_OVERWRITES_BASE_ADDRESSES
        if ( 0 != platform_media_base_pa )
        {
            int i = 0;
            /* Set the real physical addresses for the media devices */
            while ( NULL != platform_rbd[i].rbd_name )
            {
                /* WARNING, no arbitration */
                platform_rbd[i].rbd_phys_addr = platform_media_base_pa +
                    (platform_rbd[i].rbd_phys_addr & platform_media_base_mask );
                i++;
            }
        }
    #endif
        platform_detect_attempted = 1;
    }
    return( platform_rbd );
}
/**
 * @brief         Provides RBD of current platform
 *
 * Uses pal_detect_platform() to obtain the RBD
 * Evaluates the RBD and provides its location and
 * size to the caller.
 *
 * @param         rbd_size  : Location to receive RBD size
 *
 * @returns      RegisterBankDescriptor *
 *
 */
const struct RegisterBankDescriptor *
pal_get_rbd_table( int *rbd_size )
{
   const struct RegisterBankDescriptor *rbd;
   rbd = pal_detect_platform();
   *rbd_size = sizeof( *rbd );
   return( rbd );
}
/**
 * @brief         Retrieve the PCI base address and interrupt assingnment of a device
 *
 * @param         dev         : Descriptor for PCI device in question
 * @param         pal_info    : Address of area to receive base address and intr
 *
 * @returns      PAL_SUCCESS or PAL_FAILURE
 *
 */
pal_result_t
pal_get_base_and_irq(pal_dev_id_t dev, pal_info_t **pal_info)
{
    const struct RegisterBankDescriptor *rbd;
    int found_it = 0;
    if(!pal_info){
        return PAL_FAILURE;
    }
    rbd = pal_detect_platform();
 if (rbd == NULL)
 {
  return(PAL_FAILURE);
 }
    while ( NULL != rbd->rbd_name )
    {
        if ( rbd->rbd_pal_dev_id == (int) dev )
        {
            os_pci_dev_t pcidev;
            (*pal_info)->irq_num = 0;
            // see if we can find the device's PCI handle and get its IRQ
         if (os_pci_find_first_device(rbd->rbd_pci_vid, rbd->rbd_pci_did, &pcidev) == OSAL_SUCCESS)
            {
                do {
                    unsigned int bus, dev, func, irq = 0;
                    func = -1;
                    os_pci_get_device_address(pcidev, &bus, &dev, &func);
                    if(func == rbd->rbd_pci_fun){
                        os_pci_get_interrupt(pcidev, &irq);
                        (*pal_info)->irq_num = irq;
                        break;
                    }
                } while(os_pci_find_next_device(pcidev, &pcidev) == OSAL_SUCCESS);
                if((*pal_info)->irq_num <= 0 || (*pal_info)->irq_num >= 64){
                    (*pal_info)->irq_num = MAGIC_IRQ_NUMBER;
                    OS_PRINT("IRQ == 0!, assuming correct value is %d\n", (*pal_info)->irq_num);
                    OS_ASSERT(false);
                }
            } else {
                OS_PRINT("Guessing IRQ number\n");
                (*pal_info)->irq_num = MAGIC_IRQ_NUMBER;
                OS_ASSERT(false);
            }
        #ifdef PAL_DETECT_OVERWRITES_BASE_ADDRESSES
            (*pal_info)->base_addr0 = rbd->rbd_phys_addr;
        #else
            (*pal_info)->base_addr0 = rbd->rbd_phys_addr + media_base_pa;
        #endif
            found_it = 1;
            break;
        }
        rbd++;
    }
    if ( ! found_it )
    {
        OS_DEBUG("pal_get_base_and_irq: invalid device\n");
        return PAL_FAILURE;
    }
   return PAL_SUCCESS;
}
/**
 * @brief    Return the IRQ number of a given device
 *
 *
 * @param    dev_id    : Device in question
 * @param    p_irq     : Location to receive IRQ number
 *
 * @returns  pal_result_t
 *
 * Note: This function is added for backwards compatability with
   older versions of PAL, should only be used with gen2 devices
 *
 */
pal_result_t
pal_get_irq(pal_dev_id_t dev_id, unsigned long *p_irq)
{
   pal_info_t *pal_info;
   pal_result_t pal_status;
   if(NULL == p_irq)
   {
      OS_INFO( "%s: Input parameter is invalid.\n",__FUNCTION__ );
      return PAL_FAILURE;
   }
   pal_info = (pal_info_t *)OS_ALLOC(sizeof(pal_info_t));
   if (pal_info == NULL)
   {
      return PAL_FAILURE;
   }
   pal_status = pal_get_base_and_irq(dev_id, &pal_info);
   if (pal_status != PAL_SUCCESS)
   {
      OS_PRINT("could not get irq number from PAL\n");
      OS_FREE(pal_info);
      return PAL_FAILURE;
   }
   *p_irq = pal_info->irq_num;
   OS_FREE(pal_info);
   return PAL_SUCCESS;
}
/**
 * @brief  Retrieve a unique identifier for the chipset.
 *
 * Used by drivers to identify their H/W environment
 *
 * @param     chipset_id    : Address to receive unique id info
 *
 * @returns      pal_result_t
 *
 *  Note that this ID is not the same as the x86 CPUID.  In Intel
 *  SOCs, the CPUID applies only to the x86 core, this ID is for
 *  software to determine which version of the "un-core" is
 *  available.  Additionally, this function is not intended to
 *  provide information about what features are available via
 *  manufacturing fuse options.
 *
 * This function is deprecated in favor of pal_get_soc_info on which
 * it now relies. We simply translate the result into the older ID
 * value.
 */
pal_result_t
pal_get_chipset_id( pal_chipset_id_t *chipset_id )
{
   pal_result_t result = PAL_FAILURE;
   pal_soc_info_t soc_info;
   if(NULL == chipset_id)
   {
      OS_INFO( "%s: Input parameter is invalid.\n",__FUNCTION__ );
      return PAL_FAILURE;
   }
   if ( (result = pal_get_soc_info(&soc_info)) != PAL_SUCCESS ) {
      OS_INFO( "Unable to determine chipset ID.\n" );
   }
   else {
         switch ( soc_info.name ) {
            case SOC_NAME_CE3100:
     {
               switch( soc_info.stepping ) {
           case SOC_STEPPING_A0:
        *chipset_id = INTEL_CE_SOC_GEN3_A0;
             break;
    case SOC_STEPPING_A1: // No gen3 A0 device ever saw the light of day, so we report A1 and A0 as A0
         *chipset_id = INTEL_CE_SOC_GEN3_A0;
             break;
    case SOC_STEPPING_B0:
         *chipset_id = INTEL_CE_SOC_GEN3_B0;
             break;
    case SOC_STEPPING_B1:
         *chipset_id = INTEL_CE_SOC_GEN3_B1;
             break;
    default: // Should never get here
        OS_ASSERT(0);
         break;
        }
            }
               break;
            case SOC_NAME_CE4100:
            {
        switch( soc_info.stepping ) {
           case SOC_STEPPING_A0:
         *chipset_id = INTEL_CE_SOC_GEN4_A0;
             break;
           case SOC_STEPPING_A1:
         *chipset_id = INTEL_CE_SOC_GEN4_A1;
             break;
           case SOC_STEPPING_B0:
         *chipset_id = INTEL_CE_SOC_GEN4_B0;
             break;
           case SOC_STEPPING_B1:
         *chipset_id = INTEL_CE_SOC_GEN4_B1;
             break;
           case SOC_STEPPING_B2:
         *chipset_id = INTEL_CE_SOC_GEN4_B2;
             break;
           case SOC_STEPPING_C0:
         *chipset_id = INTEL_CE_SOC_GEN4_C0;
                    break;
           case SOC_STEPPING_C1:
         *chipset_id = INTEL_CE_SOC_GEN4_C1;
             break;
       default: // Should never get here
         OS_ASSERT(0);
             break;
  }
       }
               break;
            case SOC_NAME_CE4200:
            {
              switch( soc_info.stepping ) {
                 case SOC_STEPPING_A0:
                      *chipset_id = INTEL_CE_SOC_GEN5_A0;
                      break;
                 case SOC_STEPPING_A1:
                      *chipset_id = INTEL_CE_SOC_GEN5_A1;
                      break;
                 case SOC_STEPPING_B0:
                      *chipset_id = INTEL_CE_SOC_GEN5_B0;
                      break;
                 case SOC_STEPPING_B1:
                      *chipset_id = INTEL_CE_SOC_GEN5_B1;
                      break;
                 case SOC_STEPPING_C0:
                      *chipset_id = INTEL_CE_SOC_GEN5_C0;
                      break;
                 default: // Should never get here
                     OS_ASSERT(0);
                 break;
               }
             }
              break;
            case SOC_NAME_CE5300:
     {
       switch( soc_info.stepping ) {
        case SOC_STEPPING_A0:
             *chipset_id = INTEL_CE_SOC_CE5300_A0;
             break;
               case SOC_STEPPING_A1:
               *chipset_id = INTEL_CE_SOC_CE5300_A1;
      break;
        case SOC_STEPPING_B0:
             *chipset_id = INTEL_CE_SOC_CE5300_B0;
      break;
        case SOC_STEPPING_B1:
             *chipset_id = INTEL_CE_SOC_CE5300_B1;
      break;
        default: // Should never get here
             OS_ASSERT(0);
      break;
       }
     }
               break;
            default: /* Unknown device */
      OS_ASSERT(0);
               break;
         }
      }
   return ( result );
}
/**
 * @brief    Handle a read of our proc fs file
 *
 *
 * @param   buf    : Pointer to user buffer
 * @param   start  : Unused here.
 * @param   offset : Offset of requested data. Unused here
 * @param   count  : Amount of data requested. Unused here
 * @param   eof    : Flag indicating no more data available
 * @param   data   : Driver specific area. Unused here
 *
 * @returns number of bytes read
 *
 * @see linux/proc_fs.h
 */
int
pal_read_proc(char *buf, char **start, off_t offset,
                  int count, int *eof, void *data)
{
   pal_soc_info_t soc_info;
   int len = 0;
   // Avoid (4) gcc unused param warnings
   start=start;
   offset=offset;
   count=count;
   data=data;
   if( PAL_SUCCESS != pal_get_soc_info(&soc_info) ) {
      OS_INFO( "pal_read_proc: Failed to read soc info\n");
   }
   else {
      len += sprintf(buf+len, ":"); // First delimiter
      switch( soc_info.generation ) {
            case SOC_GENERATION_3:
               len += sprintf(buf+len, "SOC_GENERATION_3");
            break;
            case SOC_GENERATION_4:
               len += sprintf(buf+len, "SOC_GENERATION_4");
            break;
            case SOC_GENERATION_5:
               len += sprintf(buf+len, "SOC_GENERATION_5");
            break;
            case SOC_GENERATION_5300:
               len += sprintf(buf+len, "SOC_GENERATION_5300");
            break;
            default:
               len += sprintf(buf+len, "SOC_GENERATION_UNKNOWN");
            break;
      }
      len += sprintf(buf+len, ":");
      len += sprintf(buf+len, "%2.2d",soc_info.generation);
      len += sprintf(buf+len, ":");
      switch( soc_info.name ) {
         case SOC_NAME_CE3100:
            len += sprintf(buf+len, "SOC_NAME_CE3100");
         break;
         case SOC_NAME_CE4100:
            len += sprintf(buf+len, "SOC_NAME_CE4100");
         break;
         case SOC_NAME_CE4200:
            len += sprintf(buf+len, "SOC_NAME_CE4200");
         break;
          case SOC_NAME_CE5300:
            len += sprintf(buf+len, "SOC_NAME_CE5300");
         break;
         default:
            len += sprintf(buf+len, "SOC_NAME_UNKNOWN");
         break;
      }
      len += sprintf(buf+len, ":");
      len += sprintf(buf+len, "%2.2d",soc_info.name);
      len += sprintf(buf+len, ":");
   }
   *eof = 1;
   return len;
}
int pal_get_dev_irq_bit(int device_key)
{
   switch ( platform_info.name ) {
     case SOC_NAME_CE3100:
     case SOC_NAME_CE4100:
     case SOC_NAME_CE4200:
          switch(device_key){
          case GPU_GMH:
              return 0;
          case GV:
              return 1;
          case MFD:
              return 2;
          case CRU:
              return 3;
          case PREFILTER_0:
              return 4;
          case DEMUX_0:
              return 5;
          case TDSP_0:
              return 6;
          case TDSP_1:
              return 7;
          case AUDIO_0:
              return 8;
          case VDC_0:
              return 9;
          case DPE:
              return 10;
          case HDMI_TX:
              return 11;
          case SEC:
              return 12;
          case EXP:
          case EXP_WIN:
              return 13;
          case UART_0:
          case UART_1:
              return 14;
          case GPIO_0:
          case GPIO_1:
          case GPIO_2:
          case GPIO_3:
          case GPIO_4:
          case GPIO_5:
          case GPIO_6:
          case GPIO_7:
          case GPIO_8:
          case GPIO_9:
          case GPIO_10:
          case GPIO_11:
              return 15;
          case I2C_0:
          case I2C_1:
          case I2C_2:
              return 16;
          case SCARD_0:
          case SCARD_1:
              return 17;
          case SPI:
              return 18;
          case MSPOD:
              return 19;
          case DFX:
              return 25;
          default:
              //OS_INFO("unknown device id %d\n", device_key);
              return 32;
          }
     case SOC_NAME_CE5300:
         switch(device_key){
          case GPU_GMH:
              return 0;
          case GVSPARC_D:
          case MFD:
              return 2;
          case CRU:
              return 3;
          case PREFILTER_0:
              return 4;
          case DEMUX_0:
              return 5;
          case TDSP_0:
              return 6;
          case TDSP_1:
              return 7;
          case AUDIO_0:
              return 8;
          case VDC_0:
              return 9;
          case DPE:
              return 10;
          case HDMI_TX:
              return 11;
          case SEC:
              return 12;
          case EMMC_HOST:
              return 13;
          case UART_0:
              return 14;
          case GPIO_0:
          case GPIO_1:
          case GPIO_2:
          case GPIO_3:
          case GPIO_4:
          case GPIO_5:
          case GPIO_6:
          case GPIO_7:
          case GPIO_8:
          case GPIO_9:
          case GPIO_10:
          case GPIO_11:
              return 15;
          case I2C_0:
          case I2C_1:
          case I2C_2:
          case I2C_3:
              return 16;
          case SCARD_0:
          case SCARD_1:
              return 17;
          case SPI:
          case SPI_S:
              return 18;
          case MSPOD:
              return 19;
          case GFX2D:
              return 20;
          case GBE:
              return 21;
          case USB_0:
          case USB_2:
             return 22;
          case SATA_0:
            return 23;
          case USB_1:
            return 24;
          case SATA_1:
            return 26;
          case UART_1:
          case UART_3:
            return 27;
          case HDVCAP:
          case HDMI_RX:
            return 28;
          case H264VE:
          case EPU:
          case GV:
            return 29;
          case PWM:
            return 31;
          default:
              //OS_INFO("unknown device id %d\n", device_key);
              return 32;
      }
     default:
      return 32;
    }
   return 32;
}
