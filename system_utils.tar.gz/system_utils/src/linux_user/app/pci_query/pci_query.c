/* 

This file is provided under a dual BSD/GPLv2 license.  When using or 
redistributing this file, you may do so under either license.

GPL LICENSE SUMMARY

Copyright(c) 2009 Intel Corporation. All rights reserved.

This program is free software; you can redistribute it and/or modify 
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program; if not, write to the Free Software 
Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
The full GNU General Public License is included in this distribution 
in the file called LICENSE.GPL.

Contact Information:
   Intel Corporation
   2200 Mission College Blvd.
   Santa Clara, CA  97052

BSD LICENSE 

Copyright(c) 2008-2009 Intel Corporation. All rights reserved.
All rights reserved.

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions 
are met:

   * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
   * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include <stdio.h>     /* for printf */
#include <stdlib.h>    /* for exit */
#include <string.h>    /* for memset */
#include <getopt.h>
#include "osal.h"

#define xstringify(s) stringify(s)
#define stringify(s) #s
#ifdef COMP_VER
char *pci_query_version_string="#@# pci_query " xstringify(COMP_VER) " " __DATE__ " " __TIME__;
#else
char *pci_query_version_string="#@# pci_query 0.0.0.0000 <- COMP_VER undefined> " __DATE__ " " __TIME__;
#endif

#define FIND_OPTION 1
#define READ_OPTION 2
#define SINGLE_BYTE_XFR 0
#define FOUR_BYTE_XFR 1
#define PCI_BUS(a)  ((a & 0x7FFF0000) >> 16)
#define PCI_DEV(a)  ((a & 0x0000F800) >> 11)
#define PCI_FUNC(a) ((a & 0x00000700) >> 8)

enum {
   VID_ARG = 0,    // PCI Vendor ID
      DID_ARG,        // PCI Device ID
      RID_ARG,        // PCI Revision ID
      BUS_ARG,        // PCI Bus number
      DEV_ARG,        // PCI Device number
      FNC_ARG,        // PCI Function number
      OFS_ARG,        // PCI Config space read offset
      SIZ_ARG,        // PCI read size
      DV2_ARG,        // Short form "BUS:DEV:FUNC"
      ARG_COUNT       // Number of options
};
char *const token[] = {
   [VID_ARG]   = "ven_id",
      [DID_ARG]   = "dev_id",
      [RID_ARG]   = "rev_id",
      [BUS_ARG]   = "bus_num",
      [DEV_ARG]   = "dev_num",
      [FNC_ARG]   = "func_num",
      [OFS_ARG]   = "offset",
      [SIZ_ARG]   = "size",
      [DV2_ARG]   = "dev_addr",
      NULL
};

static struct option long_options[] = {
   {"find", required_argument, 0, FIND_OPTION},
   {"read", required_argument, 0, READ_OPTION},
   {0, 0, 0, 0}
};

unsigned int arg_values[ARG_COUNT];
bool arg_present[ARG_COUNT];

typedef osal_result (*rdfunc)(os_pci_dev_t, int, void *);


/**
   * @brief         Check PCI search results
   *
   * @param[in]         pcidev    : Device found by search
   *
   * @returns      true if result is within any user supplied 
   *               constraint false if it does not

*/
static
bool check_intermediate( os_pci_dev_t pcidev ) {
   unsigned int slot;
   bool result = true;
   
   if( OSAL_SUCCESS != os_pci_get_slot_address( pcidev, &slot ) )
      return false;
   
   if( arg_present[BUS_ARG] && arg_values[BUS_ARG] > PCI_BUS(slot) ) 
      result = false;
   if( arg_present[DEV_ARG] && arg_values[DEV_ARG] > PCI_DEV(slot) )
      result = false;
   if( arg_present[FNC_ARG] && arg_values[FNC_ARG] > PCI_FUNC(slot) )
      result = false;
   
   return result;
}

/**
         * @brief         Read a block of PCI config space
         *
         * @param         buf       : Pointer to receiving buffer
         * @param         pcidev    : Describes PCI device to be accessed
         * @param         offset    : Byte offest into config space at which to begin
         * @param         length    : Number of bytes to be read
         *
         * @returns      int Number of bytes read or -1 
         *
*/
static 
int rd_blk_config( unsigned char *buf, os_pci_dev_t pcidev, int offset, int length ) {
   
   int remain = length;
   int count = 0;
   int offs = offset;
   unsigned char *caller_buf = buf;
   int xfr_select = SINGLE_BYTE_XFR;
   int incr = 1;
   rdfunc xfr_func[2] = {(rdfunc)os_pci_read_config_8, (rdfunc)os_pci_read_config_32};
   
   if( ! buf )
      return -1;
   
   
   // Begin with single byte or four byte reads
   if( remain % 4 == 0 ) {
      xfr_select = FOUR_BYTE_XFR;
      incr = 4;   
   }   
   
   
   // Get to a four byte boundry
   while( remain > 0 ) {
      
      if( OSAL_SUCCESS != (xfr_func[xfr_select])(pcidev,offs,caller_buf) ) {
         remain = 0;
      }
      else { 
         offs += incr;
         count += incr;
         caller_buf += incr;  
         remain = length - count;
         OS_DEBUG("rd_blk_config: %s byte read. %d remain\n", xfr_select == 0 ? "Single":"Four",remain );
      }
      
      if( xfr_select == 0 && (remain % 4 == 0)  ) {
         xfr_select = FOUR_BYTE_XFR;
         incr = 4;
      }
   }      
   
   OS_DEBUG("rd_blk_config: Total bytes read: %d\n ", count );
   return count;
}


/**
               * @brief         Print the bus:device:function to stdout
               *
               * @param[in]     pcidev    : Device to be printed
               *
               * @returns       osal_result_t
*/
osal_result
print_device_addr( os_pci_dev_t pcidev ) {
   unsigned int slot;
   if( OSAL_SUCCESS == os_pci_get_slot_address( pcidev, &slot ) )
      printf("0x%04x:0x%04x:0x%04x",PCI_BUS(slot), PCI_DEV(slot), PCI_FUNC(slot));
   else
      fprintf(stderr,"print_device_addr: Failed to acquire slot address\n");
}

/**
                     * @brief         Print the usage message to stdout
                     *
                     * @param         None    : Nothing
                     *
                     * @returns       Nothing
*/
static
void print_usage() {
   printf("\tUsage:\n");
   printf("\tpci_query -find ven_id=NNNN,dev_id=NNNN,<bus_num=NNNN>,<dev_num=NNNN>,<func_num=NNNN> \n");
   
   printf("\tpci_query -read bus_num=NNNN,dev_num=NNNN,func_num=NNNN,offset=NNNN,size=NNNN\n\n");
   
   printf("\tpci_query -read bus_addr=NN:NN:NN,offset=NNNN,size=NNNN\n\n");
   
   printf("\tWhere NN:NN:NN is the PCI bus address BUS:DEVICE:FUNCTION.\n");
   printf("\tWhere NNNN is a hexidecimal number with or without a leading \"0x\".\n");
   printf("\t<> indicates an optional argument\n");
}



int
main(int argc, char **argv)
{
   int c;
   int res;
   int args=0;               // Number of option args seen
   int errfnd = 0;
   char *subopts;
   char *value;
   int option_index = 0;
   osal_result result;
   bool found = false;
   os_pci_dev_t pci_device;
   os_pci_dev_t pci_dev_next;
   unsigned char *tmpptr1,*tmpptr2,*tmpptr3;
   int n;
   
   
   memset(arg_values, 0, sizeof(arg_values) );
   memset(arg_values, 0, sizeof(arg_present) );
   
   while (1) {
      c = getopt_long_only(argc, argv, "-hH",
                           long_options, &option_index);
      
      OS_DEBUG("Option index: %d\n",option_index );
      
      if (c == -1) {
         OS_DEBUG("Done.\n");
         break;
      }
      else {
         
         if (optarg) {
            OS_DEBUG("option %d %s\n", option_index, long_options[option_index].name);
            subopts = optarg;
            // Gather all of the args (sub options) for the current option
            while (*subopts != '\0' && !errfnd) {
               res = getsubopt(&subopts, token, &value);
               OS_DEBUG("getsubopt result: %d\n",res);
               switch ( res ) {
               case VID_ARG:
               case DID_ARG:
               case RID_ARG:
               case BUS_ARG:
               case DEV_ARG:
               case FNC_ARG:
               case OFS_ARG:
               case SIZ_ARG:
                  sscanf(value,"%x",&arg_values[res]);
                  OS_DEBUG("Argument: %s  Input: %s Numeric: 0x%x\n",token[res], value,       arg_values[res]);
                  args++;
                  arg_present[res] = true;                     
                  break;
                  
               case DV2_ARG:  // Short form "BUS:DEVICE:FUNCTION" of device addr 
                  args++;
                  arg_present[res] = true; 
                  OS_DEBUG("DV2_ARG: \n");
                     // Place values from this short form arg into
                     // the corresponding BUS, DEV and FNC indexes
                     // in the values array.
                  if( NULL != (tmpptr1=strtok(value,":")) )
                     if( NULL != (tmpptr2=strtok(NULL,":")) )
                        if( NULL != (tmpptr3=strtok(NULL,":")) ) {
                           sscanf( tmpptr1, "%2.2x", arg_values[BUS_ARG] );
                           sscanf( tmpptr2, "%2.2x", arg_values[DEV_ARG] );
                           sscanf( tmpptr3, "%2.2x", arg_values[FNC_ARG] );
                        }
                  break;
                  
               case -1:
                  OS_DEBUG("-1 sub option %s \n", value);
                  break;
                  
               default:
                  fprintf(stderr, "No match found "
                          "for token: /%s/\n", value);
                  errfnd = 1;
                  break;
               }  //switch
            }     //  while
            OS_DEBUG("We have left the subopt loop!! Arg count: %d\n",args);
         }  // if optarg
      } // c != -1
      
      // Ensure that there is nothing left on the cmd line      
      if (optind < argc)  {
         fprintf(stderr,"Malformed command line.\n");
         break;
      }
      
      // Command line parsing is complete
      // Now formulate a command using the option and its arguments
      // Check that required args are present then perform the work
      switch (c) {
         
      case 'h':
      case 'H':
         print_usage();
         break;
         
      case FIND_OPTION:
               // Do we have the two basic args required for a search?
         OS_DEBUG("Beginning FIND_OPTION execution....\n");
         if( arg_present[VID_ARG] && arg_present[DID_ARG] ) {
            OS_DEBUG("os_pci_find_first_device(VID: %x DID: %x PCI_DEV: %x\n",arg_values[VID_ARG],arg_values[DID_ARG],&pci_device);
            result = os_pci_find_first_device(arg_values[VID_ARG],arg_values[DID_ARG], &pci_device);
            
                  // Our initial search was successfull
                  // Are we only interested in results past a certain bus address?
            if( arg_present[BUS_ARG] ) {
               
                     // Check to see if our initial search result meets the
                     // criteria from the user
               if ( found = check_intermediate( pci_device ) ) {
                  OS_DEBUG(" Found device on the first attempt.\n");
               }
               
                     //  The bus address of our successfull search result
                     //  was outside the constraint from the user. 
                     //  Search for the next instance of the device
               else {
                  found = false;
                  do {
                     if( OSAL_SUCCESS == os_pci_find_next_device( pci_device, &pci_dev_next )  ) {
                        found = check_intermediate( pci_dev_next );
                     }
                     else {
                        found = false;
                        break;
                     }
                     pci_device = pci_dev_next;
                  }  while ( ! found );
               }  
               
            }        // Handle a constrained search
            
            else { // No search constraint from the user. We're done
               if( result == OSAL_SUCCESS )
                  found = true;
               else
                  found = false;
               
               OS_DEBUG("Global search result: %s\n",(result==OSAL_SUCCESS) ? "SUCCESS":"FAILED");
            }
            
            if( found ) {
               print_device_addr( pci_device );
               result = OSAL_SUCCESS;
            }
         }   // VID AND DID are present
         else {
            fprintf(stderr, "Error: missing Vendor ID or Device ID.\n");
         }
         
         break;
         
      case READ_OPTION:
         OS_DEBUG("Beginning READ_OPTION execution....\n");
         
         if( ( args == 5 && ! arg_present[DV2_ARG] ) || 
             ( args == 3 && arg_present[DV2_ARG] ) ){
                
                tmpptr1 = OS_ALLOC(256);
                memset(tmpptr1, 0, 256 );
                
                if( OSAL_SUCCESS != os_pci_device_from_address( &pci_device,
                   arg_values[BUS_ARG],
                   arg_values[DEV_ARG],
                   arg_values[FNC_ARG]) ) {
                      fprintf(stderr,"READ: No such bus:function:device\n");              
                   }
                else {
                   rd_blk_config( tmpptr1, pci_device, arg_values[OFS_ARG], arg_values[SIZ_ARG] );
                        //Print the buffer for the user on stdout
                   for(n=0,tmpptr2=tmpptr1; n < arg_values[SIZ_ARG]; n++, tmpptr2++) {
                      printf("%1.1x ",*tmpptr2);
                           // Format for debug only
                      if( n > 0 && n % 16 == 0 )
                         OS_DEBUG("\n");
                   }
                   result = OSAL_SUCCESS;
                }            
                OS_FREE( tmpptr1 );
             }     // Args == 5
         else {
            fprintf(stderr,"READ: Insufficient arguments...\n");
         }
         break;
         
      case '?':
         break;
         
      default:
         fprintf(stderr,"?? getopt returned character code 0%o ??\n", c);
         break;  
         
      } //switch
      
   }    // outside while
   
   if( result != OSAL_SUCCESS )
      exit(EXIT_FAILURE);
   
   OS_DEBUG("pci_query - SUCCESS\n");
   exit(EXIT_SUCCESS);
   
}


