/* 

This file is provided under a dual BSD/GPLv2 license.  When using or 
redistributing this file, you may do so under either license.

GPL LICENSE SUMMARY

Copyright(c) 2008-2009 Intel Corporation. All rights reserved.

This program is free software; you can redistribute it and/or modify 
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
General Public License for more details.

You should have received a copy of the GNU General Public License 
along with this program; if not, write to the Free Software 
Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
The full GNU General Public License is included in this distribution 
in the file called LICENSE.GPL.

Contact Information:
   Intel Corporation
   2200 Mission College Blvd.
   Santa Clara, CA  97052

BSD LICENSE 

Copyright(c) 2008-2009 Intel Corporation. All rights reserved.
All rights reserved.

Redistribution and use in source and binary forms, with or without 
modification, are permitted provided that the following conditions 
are met:

   * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
   * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
   * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
#include <stdio.h>     
#include <stdlib.h>    
#include <string.h>
#include "pal_soc_info.h"

#define xstringify(s) stringify(s)
#define stringify(s) #s
#ifdef COMP_VER
char *get_soc_info_utility_version_string="#@# get_soc_info_utility " xstringify(COMP_VER) " " __DATE__ " " __TIME__;
#else
char *get_soc_info_utility_version_string="#@# get_soc_info_utility 0.0.0.0000 <- COMP_VER undefined> " __DATE__ " " __TIME__;
#endif

enum {
   name_item=0,
   gen_item
} _item;

enum {
   string_form=0,
   numeric_form
} _form;


static int form = 0;
static int item = 0;

static int
parse_args( int argc, char **argv ) {
   
   int result=0;
   
   if( argc != 3 )
      result = -1;
   else {
      
      if ( strcasecmp (argv[1], "NAME") == 0 ) {
         item = name_item;       
      }
      else if ( strcasecmp (argv[1], "GEN") == 0 )  { 
         item = gen_item;     
      }
      else {
         result = -1;
      }
      
      if ( strcasecmp (argv[2], "STRING") == 0 ) {
         form = string_form;       
      }
      else if ( strcasecmp (argv[2], "NUMERIC") == 0 )  { 
         form = numeric_form;     
      }
      else {
         result = -1;
      }
   } // argc == 3
   
   return result;
}

int
main(int argc, char **argv) {
   
   soc_user_info_t soc_version;
   int result = 0;
   
   
   if( parse_args(argc, argv) != 0 ) {
      printf("Insufficient arguments...\n");
      exit(-1);  
   }    
   
   
   if (system_utils_get_soc_info( &soc_version ) != 0 ) {
      printf("Failed\n");
      result = -1;
   }
   else {  
      
      switch( item ) {
      case name_item:
         if( form == string_form ) {
            printf("%s",soc_version.name);                
         }
         else {
            printf("%2.2d",soc_version.name_enum);                 
         }
         break;
         
      case gen_item:
         if( form == string_form ) {
            printf("%s",soc_version.generation);                
         }
         else {
            printf("%2.2d",soc_version.gen_enum);                
         }            
         break;
         
      default:
         printf("Unknown item\n");
         break;
         
      } //     Switch
      
      result = 0;
   }
   
   exit(result);
}
