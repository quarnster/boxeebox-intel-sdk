/*----------------------------------------------------------------------
 * File Name:      thread_utils.c 
 *---------------------------------------------------------------------*/

 /*
  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
   Intel Corporation

   2200 Mission College Blvd.
   Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

#include "osal.h"
#include "platform_config.h"
#include "platform_config_paths.h"
#include "thread_utils.h"

#define CONFIG_PATH_THREADS CONFIG_PATH_PLATFORM_ROOT ".software.threads"

/****************************************************************************
* Get the value of a thread's priority from the platform_config file.
* This should be in the key platform.software.threads.name.priority
****************************************************************************/
bool get_platform_config_thread_priority( char *name, 
                                          int  *priority )
{
   config_ref_t ref_node;

   if ((CONFIG_SUCCESS == config_node_find(ROOT_NODE, CONFIG_PATH_THREADS, &ref_node))
   &&  (CONFIG_SUCCESS == config_node_find(ref_node, name, &ref_node))
   &&  (CONFIG_SUCCESS == config_get_int(ref_node, "priority", priority)) ){
      return true;
   }

   return false;
}


/****************************************************************************
* See thread_utils.h for complete documentation.
****************************************************************************/
osal_result 
create_prioritized_thread( os_thread_t * thread, 
                           void *        (* func)(void *), 
                           void *        arg, 
                           unsigned      flags, 
                           char *        name  )
{
   return create_prioritized_group_thread(thread, func, arg, flags, name, name);
}


/****************************************************************************
* See thread_utils.h for complete documentation.
****************************************************************************/
osal_result 
create_prioritized_group_thread( os_thread_t *      thread, 
                                 void *             (* func)(void *), 
                                 void *             arg, 
                                 unsigned           flags, 
                                 char *             thread_name, 
                                 const char * const group_name )
{
   int          priority;
   osal_result  osal_res;

   if ( !get_platform_config_thread_priority(group_name, &priority) ) {
      OS_ERROR("\nEntry %s.%s.priority not found in platform_config database\n",
               CONFIG_PATH_THREADS,
               group_name );
      return OSAL_NOT_FOUND;
   }

   // Priority 0 is treated as non-realtime. All others are realtime.
   if (priority != 0)
   {
       flags |= OS_THREAD_REALTIME;
   }

   osal_res = os_thread_create(thread, func, arg, priority, flags, thread_name);

   if ( osal_res != OSAL_SUCCESS ) {
      OS_ERROR("\n os_thread_create(%p, %p, %p, %d, %d, %s) returned %d \n",
               (void* )thread,
               (void* )func,
               (void* )arg,
               priority,
               flags,
               thread_name,
               osal_res );
   }

   return osal_res;
}
