/*----------------------------------------------------------------------
 * File Name:      x86_cache.c 
 *----------------------------------------------------------------------
  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:
   Intel Corporation

   2200 Mission College Blvd.
   Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */
#include <stdint.h>
#include "osal.h"
#define CACHE_LINE_SIZE 64

/****************************************************************************
* NAME
* 		cache_flush_buffer
*
* SYNOPSIS
*		#include <x86_cache.h>
*
*		void cache_flush_buffer(void *bufptr, int size);
*
* DESCRIPTION
*		The cache_flush_buffer() function will flush the X86 cache lines
*		associated with a memory range beginning at bufptr and ending at
*		(bufptr + size).  bufptr is a pointer to the start of the buffer's
*       linear address.
*
* RETURN VALUE
*		void
*
****************************************************************************/
void cache_flush_buffer(void *bufptr, int size)
{
	/*************************************************************************
    * Make sure we have a valid size.
    * size is going to be used like an array index so decrement by 1.
    *************************************************************************/
	if (size <= 0)
		return;
	else
		size -=1;

   // Align to cache line boundries by expanding VA range
   {
      /* How far is the first byte of the buffer from the beginning of the cache line? */
      int alignment_fixup = (int)bufptr & (CACHE_LINE_SIZE - 1);

      /* Adjust bufptr to the beginning of the first cache line in the buffer. */
      bufptr = (void*)((int)bufptr - alignment_fixup);

      /* Adjust size to the end of the last cache line in the buffer. */
      size += alignment_fixup;
      //OS_INFO("Fixup value = %d, Modified Target = %p\n",  alignment_fixup, bufptr);
   }

	asm(
		"movl %0, %%edi			#bufptr\n\t"
		"movl %1, %%ecx 		#size\n\t"

		"mfence\n\t"
	"next:\n\t"
		"clflush (%%edi, %%ecx)	#flush the cache line\n\t"

		"subl $64, %%ecx		#decrement size by a cache-line\n\t"
		"jge next\n\t"
		"mfence\n\t"
		:
		:"g"(bufptr),
		 "g"(size)
		:"edi", "ecx"
	);

	return;
}
