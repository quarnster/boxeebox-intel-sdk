/*----------------------------------------------------------------------
 * File Name:      thread_utils.c
 *---------------------------------------------------------------------*/

 /*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
   Intel Corporation

   2200 Mission College Blvd.
   Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2005-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

 */

#include "osal.h"
#include "platform_config.h"
#include "platform_config_paths.h"


/****************************************************************************
* NAME
* 		create_prioritized_thread
*
* SYNOPSIS
*     #include "osal.h"
*		#include "thread_utils.h"
*
* osal_result
* create_prioritized_thread( os_thread_t * thread,
*                            void *        (* func)(void *),
*                            void *        arg,
*                            unsigned      flags,
*                            char *        name  )
*
* DESCRIPTION
*		create_prioritized_thread() searches for the entry
*     platform.software.threads.name in the platform_config registry database.
*     If the entry is found, the specified priority is read from the database
*     and the a new realtime thread is created with the specified name and
*     priority.
*
*     Parameter descriptions can be found in the OSAL documentation for
*     os_thread_create().
*
* RETURN VALUE
*		osal_result - return values are the same as os_thread_create with one
*     exception.  If the platform_config priority entry for the thread is not
*     found the function returns OSAL_NOT_FOUND.
*
****************************************************************************/
osal_result
create_prioritized_thread( os_thread_t * thread,
                           void *        (* func)(void *),
                           void *        arg,
                           unsigned      flags,
                           char *        name  );


/****************************************************************************
* NAME
* 		create_prioritized_group_thread
*
* SYNOPSIS
*     #include "osal.h"
*		#include "thread_utils.h"
*
* osal_result
* create_prioritized_group_thread( os_thread_t *        thread,
*                                  void *               (* func)(void *),
*                                  void *               arg,
*                                  unsigned             flags,
*                                  char *               thread_name,
*                                  const char * const   group_name )
*
* DESCRIPTION
*		create_prioritized_group_thread() searches for the the entry
*     platform.software.threads.group_name in the platform_config registry
*     database.  If the entry is found, the specified priority is read from
*     the database and the a new realtime thread is created with the
*     specified thread_name and priority.  This function allows a specific
*     name to be given to a group of threads and is useful when an arbitrary
*     number of thread instances may be created.
*
*     Parameter descriptions can be found in the OSAL documentation for
*     os_thread_create().
*
* RETURN VALUE
*		osal_result - return values are the same as os_thread_create with one
*     exception.  If the platform_config priority entry for the thread is not
*     found the function returns OSAL_NOT_FOUND.
*
****************************************************************************/
osal_result
create_prioritized_group_thread( os_thread_t *      thread,
                                 void *             (* func)(void *),
                                 void *             arg,
                                 unsigned           flags,
                                 char *             thread_name,
                                 const char * const group_name );
