/*
 * A Hands-On Course in GStreamer Development
 * Copyright 2006 Fluendo, S.L. (http://www.fluendo.com/)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */ 
#include "kb-helper.h"
#define BUF_SIZE 256

static GIOChannel *ioc;

gboolean handle_kb_input (GIOChannel *ioc, GIOCondition cond,
    KBCallback kb_func)
{
  GIOStatus status;
  gsize count = BUF_SIZE-1;
  gchar buf[BUF_SIZE];
  cond = cond;

  while (g_io_channel_get_flags (ioc) & G_IO_FLAG_IS_READABLE && count > 0) {
    status = g_io_channel_read_chars (ioc, buf, count, &count, NULL);
    switch (status) {
      case G_IO_STATUS_NORMAL:
        if (count > 0) {
          buf[count] = '\0'; /* Add null terminator */
          kb_func (buf);
        }
        break;
      case G_IO_STATUS_ERROR:
        g_critical ("Error: Reading keyboard input");
        return FALSE;
      case G_IO_STATUS_EOF:
      case G_IO_STATUS_AGAIN:
      default:
        break;
    }
  }

  return TRUE;
}

void set_kb_input_handler (KBCallback kb_func)
{
  ioc = g_io_channel_unix_new (STDIN_FILENO);
  g_return_if_fail (ioc != NULL);
  
  /* Turn on non-blocking */
  g_io_channel_set_flags (ioc, 
      (GIOFlags)(g_io_channel_get_flags (ioc) | G_IO_FLAG_NONBLOCK), NULL);
  g_io_add_watch (ioc, G_IO_IN, (GIOFunc) (handle_kb_input), (void *)kb_func);
}

static struct termios save_termios;
static gboolean termios_set = FALSE;

void set_kb_mode (gboolean canonical)
{
  const gint fd = STDIN_FILENO;
  struct termios buf;

  if (!isatty (fd))
    return;

  if (canonical) {
    if (!termios_set)
      return; /* Non-canonical mode was never set */
    if (tcsetattr (fd, TCSAFLUSH, &save_termios) < 0) {
      g_warning ("Could not restore terminal state.");
      return;
    }
    g_io_channel_set_flags (ioc, 
      (GIOFlags)(g_io_channel_get_flags (ioc) & ~G_IO_FLAG_NONBLOCK), NULL);
  }
  else {
    if (tcgetattr (fd, &save_termios) < 0) {
      g_warning ("Could not save terminal state.");
      return;
    }
    termios_set = TRUE;

    buf = save_termios;
    buf.c_lflag &= ~(ECHO|ICANON|IEXTEN);
      /* Echo off, canonical mode off, extended input processing off,
       * signal chars off */

    if (tcsetattr (fd, TCSAFLUSH, &buf) < 0) {
      g_warning ("Could not set terminal state.");
      return;
    }
  }
}


