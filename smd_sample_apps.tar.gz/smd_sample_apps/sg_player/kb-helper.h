/*
 * A Hands-On Course in GStreamer Development
 * Copyright 2006 Fluendo, S.L. (http://www.fluendo.com/)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
#ifndef __KB_HELPER_H__
#define __KB_HELPER_H__

#include <glib.h>
#include <unistd.h>
#include <string.h>
#include <termios.h>

typedef void (*KBCallback) (gchar * input);

#define KB_KEY_UP "\033\133\101"
#define KB_KEY_DOWN "\033\133\102"
#define KB_KEY_RIGHT "\033\133\103"
#define KB_KEY_LEFT "\033\133\104"

void set_kb_input_handler(KBCallback kb_func);
void set_kb_mode(gboolean canonical);

#endif /* __KB_HELPER_H__ */
