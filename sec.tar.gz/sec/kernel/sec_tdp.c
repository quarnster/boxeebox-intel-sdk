/*-----------------------------------------------------------------------------
 * This file is provided under a dual BSD/GPLv2 license.  When using or
 * redistributing this file, you may do so under either license.
 *
 * GPL LICENSE SUMMARY
 *
 * Copyright(c) 2008-2011 Intel Corporation. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 * The full GNU General Public License is included in this distribution
 * in the file called LICENSE.GPL.
 *
 * Contact Information:
 *      Intel Corporation
 *      2200 Mission College Blvd.
 *      Santa Clara, CA  97052
 *
 * BSD LICENSE
 *
 * Copyright(c) 2008-2011 Intel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *   - Neither the name of Intel Corporation nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *---------------------------------------------------------------------------*/
#include <linux/pci.h>
#include <linux/list.h>
#include <linux/firmware.h>
#include <linux/kobject.h>
#include <linux/types.h>
#include <linux/sysfs.h>
#include <linux/device.h>
#include <linux/kmod.h>
#include <linux/kernel.h>


#include "osal.h"
#include "sec_kernel.h"
#include "sec_kernel_types.h"
#include "sec_hal.h"
#include "sec_fw.h"
#include "sec_pci.h"
#include "sec_tdp.h"
#include "platform_config.h"
#include "platform_config_paths.h"

/* Global definition used at system initialization*/
static pmr_t pmr_defs[MAX_NUM_PMRS];
static int pmr_count;

/*
   Retrieve the pmr settings from the platform config tree.
   The size of the pmrs area must be large enough to hold
   a number of pmr_t  structs. The number is SOC specific.
   Currently the number is 16 for CE4100, CE4200 and CE5300.
   The pmrs array will be filled to maximum. Invalid entries
   will contain a pmr_type field of -1 (pmr_invalid).
   Upon error, the contents of the callers pmr array is unknown
   and security initialization must prevent the system from 
   initializing successfully.
   Returns:
   0  - Protected memory must be disabled.
   1  - Protected memory must be enabled.
   -1 - Error
*/   
// need to update this function after integration with SMD
static int get_pmr_info( pmr_t *pmrs )
{

    int retval                 = 0;
    config_result_t config_ret = CONFIG_SUCCESS;   
    config_ref_t pmr_node, child_node;

    OS_ASSERT( NULL != pmrs );
    if( CONFIG_SUCCESS == config_node_find( ROOT_NODE, CONFIG_PATH_PLATFORM_PMR_INFO, &pmr_node ) )
    {
        int i = 0;
        unsigned int pmr_start_pa = 0;
        unsigned int pmr_size = 0;
        int pmr_type = 0;
        char pmr_name[64];
        unsigned int pmr_sta = 0;
        
        // Initialize the pmr array
        memset((void *)&pmrs[0], 0, 16 *sizeof(pmr_t));

        for(i=0;i<MAX_NUM_PMRS;i++)
            pmrs[i].pmr_type=-1;

        config_ret = config_node_first_child(pmr_node, &child_node);
        i=0; 
        while ( config_ret == CONFIG_SUCCESS  && i < MAX_NUM_PMRS ) 
        {
            if( CONFIG_SUCCESS != (config_ret = config_node_get_name(child_node, pmr_name, sizeof(pmr_name))) )
            {
                retval = -1;
                SEC_ERROR( "Failed to find the name of this pmr.\n" );
                break;
            }
            if( CONFIG_SUCCESS != (config_ret = config_get_int(child_node, "base_pa", (int *)(&pmr_start_pa))) )
            {
                retval = -1;
                SEC_ERROR( "Failed to find the base_pa of this pmr.\n" );
                break;
            }            
            if( CONFIG_SUCCESS != (config_ret = config_get_int(child_node, "size", (int *)(&pmr_size))) )
            {
                retval = -1;  
                SEC_ERROR( "Failed to find the size of this pmr.\n" );
                break;
            }   
            if( CONFIG_SUCCESS != (config_ret = config_get_int(child_node, "type", (int *)(&pmr_type))) )
            {
                retval = -1; 
                SEC_ERROR( "Failed to find the type of this pmr.\n" );
                break;
            } 
            if( CONFIG_SUCCESS != (config_ret = config_get_int(child_node, "sta", (int *)(&pmr_sta))) )
            {
                retval = -1; 
                SEC_ERROR( "Failed to find the sta of this pmr.\n" );
                break;
            }
  
            pmrs[pmr_type].pmr_type=pmr_type;            
            pmrs[pmr_type].start_pa=pmr_start_pa;            
            pmrs[pmr_type].size=pmr_size;            
            pmrs[pmr_type].sta=pmr_sta;
            strcpy( pmrs[pmr_type].name, pmr_name );            
            i++;
            config_ret = config_node_next_sibling(child_node, &child_node);
        }
        if(i>0 && retval != -1)
        {
            retval = 1;
        }
    }   
    return retval;
}

// function to call the platform_config reader
// returns the number of pmr enabled
// in case of fail returns -1
int sec_get_pmr()
{
   int i,retval;
   pmr_count =0;
   retval = get_pmr_info(pmr_defs);
   if(retval==0)  
   {
       goto exit;
   }
   else if(retval<0)
   {
       pmr_count = -1;
       goto exit;
   }
   for(i=0;i<MAX_NUM_PMRS;i++)
   {
       if(pmr_defs[i].pmr_type != -1)
       {
           if(pmr_defs[i].size<=0)
           {
               pmr_count = -1;
               goto exit;
           }
           else
              pmr_count++;
       }
   }
exit:  
   printk("pmr_count=%d\n",pmr_count); 
   return pmr_count;
}

// Writes configuration to MCU exposed PCI bars
// using 2 I/O address MCU_DATA_REG and MCU_CTRL_REG

static sec_result_t msgbus_write(os_pci_dev_t pci_dev, int port, uint32_t reg, uint32_t val)
{
    sec_result_t ret = SEC_SUCCESS;

    if ( os_pci_write_config_32(pci_dev, MCU_DATA_REG, val) != OSAL_SUCCESS ) 
    {
        ret = SEC_PCI_DEVICE_ACCESS_ERROR;
    }
    else if ( os_pci_write_config_32(pci_dev, MCU_CTRL_REG, 0xe00000f0|(port<<16) |(reg<<8)) != OSAL_SUCCESS ) 
    {
      ret = SEC_PCI_DEVICE_ACCESS_ERROR;
    }
    return ret;
}

// Reads configuration form MCU exposed PCI bars
// using 2 I/O address MCU_DATA_REG and MCU_CTRL_REG

static sec_result_t msgbus_read(os_pci_dev_t pci_dev, int port, uint32_t reg, uint32_t* val)
{
    sec_result_t ret = SEC_SUCCESS;

    if ( os_pci_write_config_32(pci_dev, MCU_CTRL_REG, 0xd00000f0| (port<<16) | (reg<<8)) != OSAL_SUCCESS ) 
    {
        ret = SEC_PCI_DEVICE_ACCESS_ERROR;
    }
    else if ( os_pci_read_config_32(pci_dev, MCU_DATA_REG, val) != OSAL_SUCCESS ) 
    {
      ret = SEC_PCI_DEVICE_ACCESS_ERROR;
    }
    return ret;
}

// Configures the MCU PMR registers 
// writes the end address,size and start adress
// size should be at 1 MB boundary
//MCU exposes two I/O address to read/write the configuration
sec_result_t sec_init_lock_pmr()
{
    sec_result_t ret = SEC_SUCCESS;
    //Read the PMRs from platform config here
    //The PMRs are 1MB granularity
    uint32_t pmr_entry;
    uint32_t i;
    uint32_t size;
    uint32_t upper_bound;
    uint32_t lower_bound;
    uint32_t pmr_start = (uint32_t)PMR_START;
    uint32_t one_mb = 1<<20;
    os_pci_dev_t pci_dev;

    if ( os_pci_device_from_address(&pci_dev, 0, 0, 0) != OSAL_SUCCESS ) 
    {
        ret = SEC_PCI_DEVICE_ACCESS_ERROR;
        goto exit;
    }
    // read value from config
    for( i=0;i <MAX_NUM_PMRS ; i++)
    {
        pmr_entry=0;
        if(pmr_defs[i].pmr_type !=-1) 
        {
            lower_bound = pmr_defs[i].start_pa & 0xFFF00000;
            size = pmr_defs[i].size;
            if(pmr_defs[i].size & 0x000FFFFF)
            {
                printk(KERN_WARNING "Memory layout should be at 1Mb boundary\n");
                ret=SEC_TDP_INIT_FAILED;
                goto exit;
            }
            pmr_entry = lower_bound >> 16; //grab the MB units
            upper_bound = lower_bound + size - one_mb;
            pmr_entry = pmr_entry | upper_bound;
        }
        else
        {
            pmr_entry=INVALID_PMR_DEFAULT;
        }
        pmr_entry = pmr_entry | 0x01; //lock
        ret = msgbus_write(pci_dev,MSG_PORT_MCU, pmr_start +i , pmr_entry);
        if (SEC_SUCCESS != ret) 
        {
            goto exit;
        }
    }
    //Configure the snoop register for fastpath mode
    ret = msgbus_write(pci_dev,MSG_PORT_MCU_FASTPATH, FASTPATH_CONF1,FASTPATH_CONF_VAL1);
    ret = msgbus_write(pci_dev,MSG_PORT_MCU_FASTPATH, FASTPATH_CONF2,FASTPATH_CONF_VAL2);
    ret = msgbus_write(pci_dev,MSG_PORT_MCU_FASTPATH, FASTPATH_LOCK,0x01);
exit:
    os_pci_free_device( pci_dev );
    return ret;
}

// Configures the MCU attribute registers 
// writes the ORs of all the attribute assigned to PMR type
//MCU exposes two I/O address to read/write the configuration
//4 attribute registers are exposed to cover attribute of 16 PMR
//1st register for 1-4 PMR, 2nd for 5-8 PMR and so on
sec_result_t sec_init_lock_pmr_attr()
{
    sec_result_t ret = SEC_SUCCESS;
    uint32_t i, sta, attr_index, region_index, bit_location;
    uint32_t pmr_attr_start = (uint32_t)PMR_ATTR_START;
    uint32_t pmr_attr_lock;
    os_pci_dev_t pci_dev;
    uint32_t pmr_attr[NUM_ATTR_MATRIX];
    for(i=0; i<NUM_ATTR_MATRIX; i++)
    {
        pmr_attr[i] = 0;  
    }
    
    if(os_pci_device_from_address(&pci_dev, 0, 0, 0) != OSAL_SUCCESS )
    {
        ret = SEC_PCI_DEVICE_ACCESS_ERROR;
        goto exit;
    }
     
    for(i=0; i<MAX_NUM_PMRS; i++)
    {
        if(pmr_defs[i].pmr_type!=-1)
        {
            bit_location =0;
            sta = pmr_defs[i].sta;
            attr_index = pmr_defs[i].pmr_type/4;
            region_index = 1 << (pmr_defs[i].pmr_type%4);
            while(sta>0)
            {
                if(sta & 0x01)
                {
                    pmr_attr[attr_index] = pmr_attr[attr_index] | (region_index << (bit_location * 4)); 
                }
                sta = sta >>1;
                bit_location++;
            }
        }
    }
    //read the attr value from PMR and write to the bus
    for (i=0;i<NUM_ATTR_MATRIX;i++)
    {
        msgbus_write(pci_dev, MSG_PORT_MCU, pmr_attr_start + i, pmr_attr[i]);
    } 

    //lock the attr matrix
    ret = msgbus_read(pci_dev, MSG_PORT_MCU, PMR_ATTR_LOCK , &pmr_attr_lock);
    if (SEC_SUCCESS != ret)
    {
        goto exit;
    }

    pmr_attr_lock = pmr_attr_lock | 0x1F;
    ret = msgbus_write(pci_dev, MSG_PORT_MCU, PMR_ATTR_LOCK, pmr_attr_lock);
    if (SEC_SUCCESS != ret)
    {
        goto exit;
    }
exit:
    os_pci_free_device( pci_dev );
    return ret;
}

//TDP needs TDP FW module to be loaded before dependent units 
//start
//If TDP is enabled , driver need to load the TDP FW if not
//loaded by CEFDK
//After system initialization, this FW unloads itself

int sec_check_tdp_fw()
{
    int ret = -1;
    sec_result_t rc = SEC_SUCCESS;
    uint32_t module_id = SEC_TDP_MODULE_ID;
    uint32_t ver = SEC_FW_UNKNOWN_MODULE_VER;
    if(pmr_count <= 0)
    { 
        ret = PMR_DISABLED;
    }
    else
    {
        rc = sec_fw_get_ver_info_by_id(module_id, &ver); 
        if((rc == SEC_SUCCESS) && (ver != SEC_FW_UNKNOWN_MODULE_VER))
        {
            ret =PMR_ENABLED_FW_LOADED;
        }    
        else if(rc == SEC_INTERNAL_ERROR)
        {
            ret =PMR_ENABLED_FW_TB_LOADED;
        }
    }
    return ret;    
}

//To allow easy access to PMR configuration SEC contains 
// PMR configuration in SEC memory classification registers

sec_result_t sec_init_lock_sec_mem_region(sec_hal_t* sec_hal)
{
    sec_result_t ret = SEC_SUCCESS;
    uint32_t pmr_class_entry;
    uint32_t i;
    uint32_t size;
    uint32_t upper_bound;
    uint32_t lower_bound;

    for(i=0; i<MAX_NUM_PMRS; i++)
    {
        pmr_class_entry=0;
        if(pmr_defs[i].pmr_type !=-1)
        {

            lower_bound = pmr_defs[i].start_pa & 0xFFF00000;
            size = pmr_defs[i].size;
            if(pmr_defs[i].size & 0x000FFFFF)
            {
                printk(KERN_WARNING "Memory layout should be at 1Mb boundary\n");
                ret=SEC_TDP_INIT_FAILED;
                goto exit;
            }
            pmr_class_entry = lower_bound >> 12; //grab the MB units
            upper_bound = lower_bound + size;
            pmr_class_entry = pmr_class_entry | upper_bound;
            pmr_class_entry = pmr_class_entry | (pmr_defs[i].pmr_type<<1);
        }
        pmr_class_entry = pmr_class_entry | 0x01; //lock
        sec_hal_devh_WriteReg32(sec_hal , SEC_CLASS_REG_BASE + i*4, pmr_class_entry);
    }
exit:
    return ret;
}



#define PMR_ADDR_HEX_STRING_BYTE_LENGTH   8

int sec_kernel_load_peripheral_fw(char *fw_mod_file, void *pmr_dest_phys_addr)
{
   struct subprocess_info *sub_info;
   char *argv[4]= {NULL,NULL,NULL,NULL};
   static char *envp[] = {
                           "HOME=/",
                           "PATH=/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin:/scripts", NULL
                         };
   int retval = -1;
   uint32_t  pmr_dst_addr;
   unsigned char pmr_addr_str[PMR_ADDR_HEX_STRING_BYTE_LENGTH + 1]; //+ 1 null char

   if((fw_mod_file == NULL) || (pmr_dest_phys_addr == NULL))
   {
     printk("sec_kernel_load_peripheral_fw: Invalid arguments\n");
     return -701;
   }

   //convert the address to hex string and null terminate it to pass it as argv[2] to user app.
   pmr_dst_addr = (uint32_t) pmr_dest_phys_addr;
   sprintf(pmr_addr_str, "%08X", pmr_dst_addr);
   pmr_addr_str[PMR_ADDR_HEX_STRING_BYTE_LENGTH]=0;

   //printk(KERN_INFO "pmr_dest_phys_addr=0x%p\n",pmr_dest_phys_addr);
   //printk(KERN_INFO "pmr_dst_addr=0x%08X\n",pmr_dst_addr);
   //printk(KERN_INFO "pmr_addr_str=%s\n", pmr_addr_str);

   argv[0] = "/bin/tdp_load_peri_fw";
   argv[1] = fw_mod_file;
   argv[2] = pmr_addr_str;
   argv[3] = NULL;

   //printk(KERN_INFO "calling tdp app %s %s %s\n", argv[0], argv[1], argv[2]);
   printk(KERN_INFO "calling tdp app %s %s\n", argv[1], argv[2]);
   sub_info = call_usermodehelper_setup(argv[0], argv, envp, GFP_ATOMIC);

   if(sub_info == NULL)
     return -ENOMEM;

   retval = call_usermodehelper_exec(sub_info, UMH_WAIT_PROC);

   printk(KERN_INFO "tdp app return value = %d\n", retval );

   return retval;
}
EXPORT_SYMBOL(sec_kernel_load_peripheral_fw);
//EXPORT_SYMBOL_GPL(sec_kernel_load_peripheral_fw);

