/*-----------------------------------------------------------------------------
 * This file is provided under a dual BSD/GPLv2 license.  When using or
 * redistributing this file, you may do so under either license.
 *
 * GPL LICENSE SUMMARY
 *
 * Copyright(c) 2008-2011 Intel Corporation. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 * The full GNU General Public License is included in this distribution
 * in the file called LICENSE.GPL.
 *
 * Contact Information:
 *      Intel Corporation
 *      2200 Mission College Blvd.
 *      Santa Clara, CA  97052
 *
 * BSD LICENSE
 *
 * Copyright(c) 2008-2011 Intel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *   - Neither the name of Intel Corporation nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *---------------------------------------------------------------------------*/

#ifndef __SEC_TDP_H__
#define __SEC_TDP_H__

#include "sec_types.h"
#include "sec_hal.h"

extern struct pci_dev * sec_pci_dev;

#define MAX_NUM_PMRS            16
#define NUM_ATTR_MATRIX         4
#define SEC_TDP_MODULE_ID       0x4000

//MEU specific definitions
#define PCI_DEVICE_CE4100_MEU   0x0702 // MEU 
#define MEU_CSR_MBAR       0x10
#define MEU_ATU_SRC0_BASE  (0x50/4)  //Bits 31..12, /4 for dwords
#define MEU_ATU_DST0_BASE  (0x54/4)  //Bits 31..12, /4 for dwords
#define MEU_ATU_DST0_MASK  (0x58/4)
#define MEU_ATU_SRC1_BASE  (0x60/4)
#define MEU_ATU_DST1_BASE  (0x64/4)
#define MEU_ATU_DST1_MASK  (0x68/4)
#define MEU_CTRL           (0x08/4)

//PMR specific definitions

#define MSG_PORT_MCU                0x01
#define MSG_PORT_MCU_FASTPATH       0x00
#define PMR_START                   0xB0
#define PMR_ATTR_START              0xFC
#define PMR_ATTR_LOCK               0xF9
#define FASTPATH_CONF1              0x30
#define FASTPATH_CONF2              0x3E
#define FASTPATH_LOCK               0x31
#define MCU_CTRL_REG                0xD0
#define MCU_DATA_REG                0xD4
#define FASTPATH_CONF_VAL1          0x202820
#define FASTPATH_CONF_VAL2          0x02
#define INVALID_PMR_DEFAULT         0x0000FFF1 

//SEC classification register offset

#define SEC_CLASS_REG_BASE 0x0807C0

#define CONFIG_PATH_PLATFORM_MEDIA_BASE_ADDRESS "platform.memory.media_base_address"
#define CONFIG_PATH_PLATFORM_PMR_INFO  "platform.memory.pmr_info"

#define PMR_NM_SZ 64

/* Completely describe a Protected Memory Region */
typedef struct pmr_struct {
   unsigned int start_pa;     // Physical address of PMR
   unsigned int size;         // PMR size in bytes
   int          pmr_type;     // Region as described in spec
   char name[PMR_NM_SZ];      // Name used in memory layout configuration
   unsigned int sta;          // 32 bit flags describing Sec attr for the above region (described in spec)
                              // i.e. bit0==sta 0. 1 means sta 0 is active, 0 means sta 0 is not active
} pmr_t;


//-----------------------------------------------------------------------------
// F U N C T I O N S
//-----------------------------------------------------------------------------
int sec_get_pmr(void);
sec_result_t sec_init_lock_pmr(void);
sec_result_t sec_init_lock_pmr_attr(void);
sec_result_t sec_init_lock_sec_mem_region(sec_hal_t*);
int sec_check_tdp_fw(void);



#endif /* __SEC_TDP_H__ */
