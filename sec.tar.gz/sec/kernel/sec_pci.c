/*-----------------------------------------------------------------------------
 * This file is provided under a dual BSD/GPLv2 license.  When using or
 * redistributing this file, you may do so under either license.
 *
 * GPL LICENSE SUMMARY
 *
 * Copyright(c) 2008-2011 Intel Corporation. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of version 2 of the GNU General Public License as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 * The full GNU General Public License is included in this distribution
 * in the file called LICENSE.GPL.
 *
 * Contact Information:
 *      Intel Corporation
 *      2200 Mission College Blvd.
 *      Santa Clara, CA  97052
 *
 * BSD LICENSE
 *
 * Copyright(c) 2008-2011 Intel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *   - Neither the name of Intel Corporation nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *---------------------------------------------------------------------------*/

#include <linux/pci.h>

#include "sec_types.h"
#include "sec_kernel.h"
#include "sec_kernel_types.h"
#include "sec_common_types.h"

#include "sec_pm.h"

//-----------------------------------------------------------------------------
// D E B U G G I N G
//-----------------------------------------------------------------------------
/* Debugging related macros */
#ifdef SEC_PCI_DEBUG

#define SEC_PCI_DPRINT(str, ...)                                             \
    printk(KERN_INFO "%s:%s:%d " str, __FILE__, __func__, __LINE__,          \
           ##__VA_ARGS__)

#define SEC_PCI_TRACE() SEC_PCI_DPRINT("TRACE\n") 

#define SEC_PCI_LOAD_INFO_DPRINT(load_info_ptr)                              \
    SEC_PCI_DPRINT("Load Info: id: 0x%08x -- Path: %s\n",                    \
            load_info_ptr->module_id, load_info_ptr->image_path)

#define SEC_PCI_RET_TRACE()                                                  \
    SEC_PCI_DPRINT("Returning: %d\n", rc)

#else /* SEC_PCI_DEBUG */
#define SEC_PCI_DPRINT(str, ...)
#define SEC_PCI_TRACE()
#define SEC_PCI_LOAD_INFO_DPRINT(load_info_ptr)
#define SEC_PCI_RET_TRACE()
#endif /* SEC_PCI_DEBUG */

//-----------------------------------------------------------------------------
// G L O B A L S
//-----------------------------------------------------------------------------

/* PCI device info for the SEC */
static DEFINE_PCI_DEVICE_TABLE(sec_pci_dev_id) = {
    { PCI_DEVICE(PCI_VENDOR_INTEL, PCI_DEVICE_SEC) },
    {0} /* End of list */
};

struct pci_dev * sec_pci_dev = NULL;    // Stores addr of SEC PCI device

//-----------------------------------------------------------------------------
// sec_pci_probe
//
// This function is called whenever a PCI device is found that could be
// controlled by the SEC driver. At this time there can only be one, so that
// is all this driver supports.
// Return: 0 if this driver will control the device
//         Negative if this driver is not the correct one for this device
//-----------------------------------------------------------------------------
static int sec_pci_probe(struct pci_dev *dev, const struct pci_device_id * id)
{
    int rc = 0;

    SEC_PCI_DPRINT("Probe called: %d %d %d %d %d %d 0x%08X\n",
            id->vendor, id->device, id->subvendor, id->subdevice,
            id->class, id->class_mask, (unsigned int)(id->driver_data));

    /* Do some basic sanity checks */
    if (id->vendor != PCI_VENDOR_INTEL || id->device != PCI_DEVICE_SEC)
    {
        SEC_ERROR(
                "ERROR: Received a probe for a device we should be handling\n");
        rc = -1;
        goto exit;
    }
    if (sec_pci_dev != NULL)
    {
        SEC_ERROR("ERROR: Received a request to handle a second SEC unit\n");
        rc = -1;
        goto exit;
    }

    /* Increment the PCI device reference counter */
    pci_dev_get(dev);
    /* Save the device info so we can use it in the PM code */
    sec_pci_dev = dev;

exit:
    SEC_PCI_RET_TRACE();
    return rc;
}

//-----------------------------------------------------------------------------
// sec_pci_remove
//
// Handler for removing the PCI device. This should never happen, but just in
// case.
//-----------------------------------------------------------------------------
static void sec_pci_remove(struct pci_dev *dev)
{
    SEC_PCI_TRACE();
    
    if (dev != sec_pci_dev)
    {
        SEC_ERROR(
                "Received a remove request for a device we aren't tracking\n");
        goto exit;
    }

    pci_dev_put(dev);
    sec_pci_dev = NULL;
exit:
    return;
}

//-----------------------------------------------------------------------------
// Struct for our PCI device driver
//-----------------------------------------------------------------------------
static struct pci_driver sec_pci_driver = 
{
    .name = KBUILD_MODNAME,
    .id_table = sec_pci_dev_id,
    .probe = sec_pci_probe,
    .remove = sec_pci_remove,
    .suspend = sec_pm_suspend_handler,
    .resume = sec_pm_resume_handler,
};

//-----------------------------------------------------------------------------
// sec_register_pci_dev
//
// Registers the PCI device driver for sec.
//-----------------------------------------------------------------------------
int sec_register_pci_dev(void)
{
#ifdef SEC_PCI_DEBUG
    int rc = 0;
    SEC_PCI_TRACE();
    rc = pci_register_driver(&sec_pci_driver);
    SEC_PCI_RET_TRACE();
    return rc;
#else
    return pci_register_driver(&sec_pci_driver);
#endif /* SEC_PCI_DEBUG */
}

//-----------------------------------------------------------------------------
// sec_unregister_pci_dev
//
// Registers the PCI device driver for sec.
//-----------------------------------------------------------------------------
void sec_unregister_pci_dev(void)
{
    SEC_PCI_TRACE();
    pci_unregister_driver(&sec_pci_driver);
    SEC_PCI_TRACE();
}
