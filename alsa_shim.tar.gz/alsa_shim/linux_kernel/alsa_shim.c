/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/* File:
 *   alsa_shim.c
 *
 * Description:
 *   This file contains the source code for the alsa_shim driver.  This driver 
 *   is an interface between the ALSA framework and Intel's CE31xx audio 
 *   driver.  The purpose of the alsa_shim is to allow existing applications 
 *   that support ALSA to automatically support the Intel CE3100.
 */

#include "alsa_shim.h"

#ifndef MOD_NAME
#define MOD_NAME "alsa_shim.ko"
#endif

#ifdef COMP_VER
#define xstringify(s) stringify(s)
#define stringify(s) #s
MODULE_VERSION(xstringify(COMP_VER));
char *alsa_shim_version_string = "#@# alsa_shim.ko " xstringify(COMP_VER) " " __DATE__ " " __TIME__;
#else
char *alsa_shim_version_string = "#@# alsa_shim.ko 0.0.0.0000 <- COMP_VER undefined> " __DATE__ " " __TIME__;
#endif

typedef struct snd_pcm_runtime my_snd_pcm_runtime_t;


MODULE_AUTHOR( "Intel Corporation, (C) 2007-2009 - All Rights Reserved" );
MODULE_DESCRIPTION( "ALSA shim" );
MODULE_LICENSE("Dual BSD/GPL");
module_init( alsa_shim_init );
module_exit( alsa_shim_exit );

/* TODO: Allow setting these two variables via insmod parameters. */
static int alsa_shim_print_debug_level = ALSA_SHIM_SEVERITY_ERROR;
static int alsa_shim_sven_debug_level = ALSA_SHIM_SEVERITY_INFO;

static os_devhandle_t *alsa_devh;

// OPS structure - callback definition
static struct snd_pcm_ops alsa_shim_ops = {
   .open      = alsa_shim_open,
   .close     = alsa_shim_close,
   .ioctl     = snd_pcm_lib_ioctl,
   .hw_params = alsa_shim_hw_params,
   .hw_free   = alsa_shim_hw_free,
   .prepare   = alsa_shim_prepare,
   .trigger   = alsa_shim_trigger,
   .pointer   = alsa_shim_pointer,
   .ack       = alsa_shim_ack,
};

//! Sound card name
char *card_names[NUM_CARDS] = { "Intel CE3100/4100 Series" };
char *pcm_names[NUM_PCMS] = { "pcm_0" };

//! Sound Cards
static my_snd_card_t *card_list[NUM_CARDS];

//! default value of card index
static int card_index_val[SNDRV_CARDS] = SNDRV_DEFAULT_IDX;

//! Each entry in the array is the number of PCMs in the card
static int pcms_in_card[NUM_CARDS] = { NUM_PCMS };

/* Data structure maintained per PCM, available in the private_data
 * member of the PCM substream, each PCM has a single substream
 */
static ce31xx_t ce31xx[NUM_PCMS];

/* Define the CE31xx hardware constraints. */
static struct snd_pcm_hardware alsa_shim_hw = {
   .info             = SNDRV_PCM_INFO_MMAP | 
                       SNDRV_PCM_INFO_INTERLEAVED | 
                       SNDRV_PCM_INFO_BLOCK_TRANSFER |
                       SNDRV_PCM_INFO_MMAP_VALID,  
#if 0 
   // What we "should" be able to support.  Needs testing before we can enable.
   .formats          = SNDRV_PCM_FMTBIT_S16_LE | SNDRV_PCM_FMTBIT_S32_LE, 
   .rates            = SNDRV_PCM_RATE_8000_192000, 
   .rate_min         = 8000, 
   .rate_max         = 192000, 
   .channels_min     = 1, 
   .channels_max     = 8, 
#else  
   // Minimum Alsa support: 16-bit little-endian, 32kHz/44.1kHz/48kHz, Mono/Stereo
   .formats          = SNDRV_PCM_FMTBIT_S16_LE, 
   .rates            = SNDRV_PCM_RATE_32000 | 
                       SNDRV_PCM_RATE_44100 | 
                       SNDRV_PCM_RATE_48000, 
   .rate_min         = 32000, 
   .rate_max         = 48000, 
   .channels_min     = 1, 
   .channels_max     = 2, 
#endif
   .buffer_bytes_max = ALSA_BUF_SIZE, 
   .period_bytes_min = PERIOD_SIZE_MIN, 
   .period_bytes_max = PERIOD_SIZE_MAX, 
   .periods_min      = PERIODS_PER_BUFFER_MIN, 
   .periods_max      = PERIODS_PER_BUFFER_MAX,
   .fifo_size        = 0,
};


/* Function: 
 *   alsa_shim_init
 *
 * Description:
 *   This is driver initialization function called by the Linux OS when the 
 *   ALSA shim driver module is installed (insmod).
 *
 * Parameters: void
 *
 * Returns: int - the status of the initialization.  This is a Linux-specific
 *                error code.
 */
int __init
alsa_shim_init( void )
{
   my_snd_pcm_t *pcm;
   int           err = 0;
   int           card_idx = 0;
   int           pcm_idx  = 0;

   //Initializes SVEN by getting a SVEN device handle
   if ( !sven_init() ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_WARNING, "SVEN init failed" );
   }

   // Initialize all the cards this driver supports.
   for ( card_idx = 0; (card_idx < NUM_CARDS) && (err >= 0) ; card_idx++ ) {

 // If Alsa version 1.0.19 and higher
#if 1
      // Create a new sound card.
      err = snd_card_create( card_index_val[card_idx], 
                             card_names[card_idx], 
                             THIS_MODULE, 
                             0, /* TODO, we can optionally allocate a ce31xx_t structure here instead of using the ce31xx[] array. */
                             &(card_list[card_idx]) );
      if ( err < 0 ) {
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "snd_card_new:%d", err );
         break;
      }
#else // Alsa version 1.0.18 and lower
      // This makes it knows as a audio card.
      card_list[card_idx] = snd_card_new( card_index_val[card_idx], 
                                          card_names[card_idx], 
                                          THIS_MODULE, 
                                          0 );

      // If the last call failed, it will not be seen.
      if ( card_list[card_idx] == NULL ) {
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "snd_card_new:(NULL)" );
         err = -ENOMEM;
         break;
      }
#endif

      // Initialize all the PCMs for this card.
      for ( pcm_idx = 0; pcm_idx < pcms_in_card[card_idx]; pcm_idx++ ) {
         ce31xx[pcm_idx].card = card_list[card_idx];

         err = snd_pcm_new( ce31xx[pcm_idx].card, 
                            pcm_names[pcm_idx],   // PCM ID string
                            pcm_idx,              // Index of this PCM, zero based
                            1,                    // playback substreams
                            0,                    // capture substreams
                            &pcm );
         if ( err < 0 ) {
            ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "snd_pcm_new:%d", err );
            break;
         }
         strcpy( pcm->name, pcm_names[pcm_idx] );
         pcm->private_data = &ce31xx[pcm_idx];
         snd_pcm_set_ops( pcm, 
                          SNDRV_PCM_STREAM_PLAYBACK,   // We only do playback
                          &alsa_shim_ops );

         ce31xx[pcm_idx].pcm = pcm;

         err = snd_pcm_lib_preallocate_pages_for_all( pcm, 
                                                      SNDRV_DMA_TYPE_CONTINUOUS, 
                                                      snd_dma_continuous_data(GFP_KERNEL),
                                                      ALSA_BUF_SIZE,    // Size to preallocate
                                                      ALSA_BUF_SIZE );  // Max 
         if ( err < 0 ) {
            ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "snd_pcm_lib_preallocate_pages_for_all:%d", err );
            break;
         }
      }

      if ( err < 0 ) {
         break;
      }

      err = snd_card_register( card_list[card_idx] );
      if ( err < 0 ) {
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "snd_card_register:%d", err );
         break;
      }
   }

   return ( err );
}


/* Function: 
 *   alsa_shim_exit
 *
 * Description:
 *   This is the driver de-initialization function called by the Linux OS 
 *   when the ALSA shim driver is uninstalled (rmmod) 
 *
 * Parameters: void
 *
 * Returns: void
 */
void __exit
alsa_shim_exit( void )
{
   int card_idx = 0;
   int pcm_idx = 0;

   /* Free the SVEN dev handle */ 
   if ( alsa_devh != NULL ) {
      devh_Delete( alsa_devh );
      alsa_devh = NULL;
   }
   
   /* Free all of the cards and their resources */
   for ( card_idx = 0; card_idx < NUM_CARDS; card_idx++ ) {
      for ( pcm_idx = 0; pcm_idx < pcms_in_card[card_idx]; pcm_idx++ ) {
         if (ce31xx[pcm_idx].card == card_list[card_idx]) {
            snd_pcm_lib_preallocate_free_for_all( ce31xx[pcm_idx].pcm );
            (ce31xx[pcm_idx].pcm)->private_data = NULL;
         }
      }
      snd_card_free( card_list[card_idx] );
   }
 
   return;
}


/* Function: 
 *   alsa_shim_open
 *
 * Description:
 *   This is the open callback that is called from the Alsa framework when 
 *   ALSA wants to open a new PCM input to the hardware.  Here we open up 
 *   a new input to the SMD audio processor and we allocate all of the 
 *   resources we will need to use that input.
 *
 * Parameters:
 *   substream [in] - Pointer to the structures that contain both the ALSA
 *                    stream state and our hardware stream state.
 */
int 
alsa_shim_open( struct snd_pcm_substream *substream )
{
   ce31xx_t               *chip_data = (ce31xx_t *) substream->pcm->private_data;
   struct snd_pcm_runtime *runtime   = substream->runtime;
   int                     ret_code  = -EINVAL;
   osal_result             osal_res;

   ALSA_SHIM_ENTER;

   substream->private_data = chip_data;

   runtime->hw = alsa_shim_hw;

   init_chip_data( chip_data );

   /* Allocate a new input to the SMD global audio processor and attach to the input. */
   if ( smd_audio_input_alloc(chip_data) ) {

      /* Create a thread to monitor the audio processor input port. */
      chip_data->alsa_shim_thread_running = true;

      osal_res = create_prioritized_group_thread( &(chip_data->alsa_shim_mon_thread),
                                                  alsa_shim_monitor_thread, 
                                                  (void *)substream, 
                                                  0,
                                                  "Alsa_Shim_Mntr", 
                                                  "Alsa_Shim" );
      if ( osal_res != OSAL_SUCCESS ) {
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "create_prioritized_thread:%d", osal_res );
      }
      else {
         os_event_create( &(chip_data->alsa_shim_trigger_event), 0 );
         osal_res = create_prioritized_group_thread( &(chip_data->alsa_shim_rel_thread),
                                                     alsa_shim_proxy_thread, 
                                                     (void *)substream, 
                                                     0, 
                                                     "Alsa_Shim_Prxy",
                                                     "Alsa_Shim" );
         if ( osal_res != OSAL_SUCCESS ) {
            ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "create_prioritized_thread:%d", osal_res );
         }
         else {
            ret_code = 0;
         }
      }
   }

   ALSA_SHIM_EXIT;

   return ( ret_code );
}


/* Function: 
 *   alsa_shim_close
 *
 * Description:
 *   This is the close callback that is called from the Alsa framework.    
 *
 * Parameters:
 *   substream [in] - Pointer to the structures that contain both the ALSA
 *                    stream state and our hardware stream state.
 */
int
alsa_shim_close( my_snd_pcm_substream_t *substream )
{
   ce31xx_t     *chip_data = (ce31xx_t *)(substream->private_data);
   int           ret_code = 0;
   ismd_result_t ismd_ret;

   ALSA_SHIM_ENTER;

   /* Tell the port_monitor_thread to exit. */
   chip_data->alsa_shim_thread_running = false;

   /* In case the proxy_thread is waiting, wake it up. */
   os_event_set( &(chip_data->alsa_shim_trigger_event) );

   /* In case the port_monitor_thread is waiting, wake it up */
   ismd_ret = ismd_event_strobe( chip_data->thread_wakeup_event_handle );
   if ( ismd_ret != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_event_strobe:%d", ismd_ret );
   }

   /* Wait for the threads to exit. */
   os_thread_wait( &(chip_data->alsa_shim_rel_thread), 1 );
   os_thread_wait( &(chip_data->alsa_shim_mon_thread), 1 );

   smd_audio_input_free( chip_data );
   os_event_destroy( &(chip_data->alsa_shim_trigger_event) );

   init_chip_data( chip_data );

   ALSA_SHIM_EXIT;

   return ( ret_code );
}


/* Function: 
 *   alsa_shim_hw_params
 *
 * Description:
 *   This is the hw_params callback that is called from the ALSA framework 
 *   when ALSA has new hardware configuration parameters to apply to our 
 *   hardware.
 *
 * Parameters:
 *   substream [in] - Pointer to the structures that contain both the ALSA
 *                    stream state and our hardware stream state.
 */
int
alsa_shim_hw_params ( my_snd_pcm_substream_t *substream,
                      my_snd_pcm_hw_params_t *hw_params )
{
   my_snd_pcm_runtime_t *runtime  = substream->runtime;
   int                   ret_code = 0;

   ALSA_SHIM_ENTER;

   runtime->rate     = params_rate( hw_params );
   runtime->format   = params_format( hw_params );
   runtime->channels = params_channels( hw_params );

   ret_code = snd_pcm_lib_malloc_pages( substream, params_buffer_bytes(hw_params) );
   if ( ret_code < 0 ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "snd_pcm_lib_malloc_pages:%d", ret_code );
   }

   ALSA_SHIM_EXIT;
   
   return ( ret_code );
}


/* Function: 
 *   alsa_shim_free
 *
 * Description:
 *   This is the hw_free callback that is called from the ALSA framework 
 *   when we need to free shared resources.
 *
 * Parameters:
 *   substream [in] - Pointer to the structures that contain both the ALSA
 *                    stream state and our hardware stream state.
 */
int
alsa_shim_hw_free( my_snd_pcm_substream_t *substream )
{
   int ret_code = 0;

   ALSA_SHIM_ENTER;

   ret_code = snd_pcm_lib_free_pages( substream );
   if ( ret_code < 0 ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "snd_pcm_lib_free_pages:%d", ret_code );
   }

   ALSA_SHIM_EXIT;

   return ( ret_code );
}


/* Function: 
 *   alsa_shim_prepare
 *
 * Description:
 *   This is the prepare callback that is called from the Alsa framework 
 *   when ALSA wants us to get everything ready to play the PCM stream.
 *   After this function returns, ALSA can call "trigger" at any time.
 *   ALSA will call this function right before starting playback and 
 *   any time it needs to reset playback (e.g. underruns).
 *
 * Parameters:
 *   substream [in] - Pointer to the structures that contain both the ALSA
 *                    stream state and our hardware stream state.
 */
int
alsa_shim_prepare( my_snd_pcm_substream_t *substream )
{
   ce31xx_t                   *chip_data   = (ce31xx_t *)(substream->private_data);
   my_snd_pcm_runtime_t       *runtime     = substream->runtime;
   int                         ret_code    = -EINVAL;
   unsigned int                sample_rate = 0;
   int                         sample_size = 0;
   ismd_audio_channel_config_t chan_config = 0;
   ismd_result_t               ret;

   ALSA_SHIM_ENTER;

   /*
    * Here, we need to tell the audio driver the format of the PCM data 
    * we're going to feed to the audio input.  We allocated the input during 
    * the open callback, but at that time, we didn't know that format of 
    * the data.  We need to set the input format only once and it must be 
    * done before we set the input to the "play" state.
    */
   if ( !(chip_data->pcm_configured) ) {

      if ( map_sample_rate(runtime->rate, &sample_rate) && 
           map_sample_size(runtime->format, &sample_size) &&
           map_num_channels(runtime->channels, &chan_config) ) {

         ret = ismd_audio_input_set_pcm_format( chip_data->audio_processor_handle, 
                                                chip_data->audio_input_handle, 
                                                sample_size, 
                                                sample_rate, 
                                                chan_config );
         if ( ret != ISMD_SUCCESS ) {
            ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_audio_input_set_pcm_format:%d", ret );
         }
         else {
            chip_data->pcm_configured = true;
            if ( (ret = ismd_dev_set_state(chip_data->audio_input_handle, ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS ) {
               ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_dev_set_state:%d", ret );
            }
            else {
               ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_INFO, "PCM configured." );
               ret_code = 0;
            }
         }
      }

   } /* if ( !(chip_data->pcm_configured) ) */

   else {
      ret_code = 0;
   }

   chip_data->prepared_size = playback_bytes_avail( substream );
   chip_data->dma_read_offset = 0;
   chip_data->ms_per_smd_buf = 1000 / (runtime->rate / runtime->period_size);

   ALSA_SHIM_EVENT( SVEN_MODULE_EVENT_AUD_IO_ALSA_SHIM_PREPARE, 
                    snd_pcm_lib_buffer_bytes(substream), 
                    snd_pcm_lib_period_bytes(substream), 
                    chip_data->prepared_size, 
                    runtime->rate, 
                    runtime->format, 
                    runtime->channels );

   ALSA_SHIM_EXIT;

   return (ret_code);
}


/* 
 * Function: 
 *   alsa_shim_trigger
 *
 * Description:
 *   This is the Trigger callback that is called from the ALSA framework when 
 *   the stream state changes.  This function is atomic, so it cannot block or 
 *   call any functions that block.
 *
 * Parameters:
 *   substream [in] - Pointer to the structures that contain both the ALSA
 *                    stream state and our hardware stream state.
 */
int 
alsa_shim_trigger( struct snd_pcm_substream *substream,
                   int                       cmd )
{
   ce31xx_t *chip_data = (ce31xx_t *)(substream->private_data);
   int       ret_code  = 0;

   ALSA_SHIM_ENTER;

   switch ( cmd ) {
      case SNDRV_PCM_TRIGGER_START:
         chip_data->pcm_started = true;
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_INFO, "Trigger START\n");
         os_event_set( &(chip_data->alsa_shim_trigger_event) );
         break;

      case SNDRV_PCM_TRIGGER_STOP:
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_INFO, "Trigger STOP\n");
         chip_data->pcm_started = false;
         /* No need to set alsa_shim_trigger_event here. */
         break;

      default:
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_WARNING, "Invalid trigger command:%d", cmd );
         ret_code = -EINVAL;
         break;
   }

   ALSA_SHIM_EVENT( SVEN_MODULE_EVENT_AUD_IO_ALSA_SHIM_TRIGGER, 
                    cmd, 
                    0, 0, 0, 0, 0 );

   ALSA_SHIM_EXIT;
  
   return ( ret_code );
}


int
alsa_shim_mmap( my_snd_pcm_t *pcm )
{
   return ( 0 );
}


int
alsa_shim_munmap( my_snd_pcm_t *pcm )
{
   return ( 0 );
}


/* Function: 
 *   alsa_shim_pointer
 *
 * Description:
 *   This is the pointer callback that is called from the ALSA framework when 
 *   ALSA wants to query the position of the hardware read pointer within the 
 *   DMA area.  This function is atomic, so it cannot block or call any 
 *   functions that block.
 *
 * Parameters:
 *   substream [in] - Pointer to the structures that contain both the ALSA
 *                    stream state and our hardware stream state.
 */
snd_pcm_uframes_t 
alsa_shim_pointer ( my_snd_pcm_substream_t *substream )
{
   ce31xx_t         *chip_data = (ce31xx_t *)(substream->private_data);
   snd_pcm_uframes_t ret;

   ALSA_SHIM_ENTER;

   ret = bytes_to_frames( substream->runtime, chip_data->dma_read_offset );

   ALSA_SHIM_EVENT( SVEN_MODULE_EVENT_AUD_IO_ALSA_SHIM_POINTER, 
                    chip_data->dma_read_offset, 
                    0, 0, 0, 0, 0 );

   ALSA_SHIM_EXIT;

   return ( ret );
}


/* Function: 
 *   alsa_shim_ack
 *
 * Description:
 *   This is the pointer callback that is called from the ALSA framework when 
 *   ALSA updates its write pointer into the DMA area.  This function is 
 *   atomic, so it cannot block or call any functions that block.
 *
 * Parameters:
 *   substream [in] - Pointer to the structures that contain both the ALSA
 *                    stream state and our hardware stream state.
 */
int 
alsa_shim_ack( my_snd_pcm_substream_t *substream )
{
   ce31xx_t *chip_data = (ce31xx_t *)(substream->private_data);

   ALSA_SHIM_ENTER;

   chip_data->dma_write_offset = frames_to_bytes( substream->runtime, substream->runtime->control->appl_ptr );
   chip_data->ack_mode = true;

   ALSA_SHIM_EVENT( SVEN_MODULE_EVENT_AUD_IO_ALSA_SHIM_ACK, 
                    chip_data->dma_write_offset, 
                    0, 0, 0, 0, 0 );

   ALSA_SHIM_EXIT;

   return ( 0 );
}


/* Function: 
 *   playback_bytes_avail
 *
 * Description:
 *   Determines how much data (in bytes) is in the ALSA circular buffer.  This 
 *   function exists to workaround ALSA's inconsistent behavior.  When the 
 *   DMIX plugin is disabled, ALSA uses the ack callbacks to tell us the value 
 *   of it's write pointer.  When DMIX is enabled, we have direct access to 
 *   ALSA's write pointer (appl_ptr).
 *
 * Parameters:
 *   substream [in] - Pointer to the structures that contain both the ALSA
 *                    stream state and our hardware stream state.
 */
size_t 
playback_bytes_avail( struct snd_pcm_substream *substream )
{
   ce31xx_t *chip_data = (ce31xx_t *)(substream->private_data);
   size_t avail = 0;
   size_t free = 0;
   size_t buffer_size_bytes = snd_pcm_lib_buffer_bytes( substream );
   size_t read_offset = frames_to_bytes(substream->runtime, substream->runtime->hw_ptr_base);

   if ( chip_data->ack_mode ) {
      if (chip_data->dma_write_offset >= read_offset) {
         avail = chip_data->dma_write_offset - read_offset;
      }
      else {
         /*
          *dealing with wrap around issue:
          *Considering overflow, the result is: buffer_size_bytes - (read_offset + buffer_size_bytes - chip_data->dma_write_offset)
          */
         free = read_offset + buffer_size_bytes - chip_data->dma_write_offset;
         avail = buffer_size_bytes - free;
      }
   }
   else {
      avail = frames_to_bytes( substream->runtime, snd_pcm_playback_avail(substream->runtime) );
   }

   return ( avail );
}


/* Function: 
 *   alsa_shim_monitor_thread
 *
 * Description:
 *   Monitors both the SMD audio processor input port and the ALSA circular
 *   buffer write pointer and transfers data from the circular buffer to the 
 *   input port.
 *
 * Parameters:
 *   param [in] - Pointer to the structures that contain both the ALSA
 *                stream state and our hardware stream state.
 */
static void *
alsa_shim_monitor_thread( void *param )
{
   struct snd_pcm_substream *substream = (struct snd_pcm_substream *)(param);
   ce31xx_t                 *chip_data = (ce31xx_t *)(substream->private_data);
   ismd_buffer_descriptor_t *smd_buffer_desc = NULL;
   void                     *cached_buffer;
   size_t                    buffer_size_bytes;
   size_t                    period_size_bytes;
   size_t                    buffer_bytes_avail;

   ALSA_SHIM_ENTER;

   while ( chip_data->alsa_shim_thread_running ) {

      /* Wait for something interesting to happen. */
      if ( !smd_event_wait(chip_data->thread_wakeup_event_handle, ISMD_TIMEOUT_NONE) ) {
         /* If this wait fails, it is catastrophic to this thread, so exit the loop. */
         break;
      }

      /* If we woke up only to find out we're being shut down, then exit the loop. */
      if ( !(chip_data->alsa_shim_thread_running) ) {
         break;
      }

      /* Don't do anything unless the stream is started. */
      if ( !chip_data->pcm_started ) {
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_INFO, "Not Started!" );
         continue;
      }

      buffer_size_bytes  = snd_pcm_lib_buffer_bytes( substream );
      period_size_bytes  = snd_pcm_lib_period_bytes( substream );
      buffer_bytes_avail = playback_bytes_avail( substream );

      /* 
       * Figure out how much data to transfer.  Basically, it's 2 periods
       * worth of data if prepare was just called, or 1 period otherwise.
       */
      if ( chip_data->prepared_size != 0 ) {
         OS_ASSERT( (chip_data->prepared_size >= (period_size_bytes * 2)) || 
                    (buffer_bytes_avail       >= (period_size_bytes * 2)) );
         buffer_bytes_avail = period_size_bytes * 2;
         chip_data->prepared_size = 0;
      }
      else if ( buffer_bytes_avail > period_size_bytes ) {
         buffer_bytes_avail = period_size_bytes;
      }
      if (buffer_bytes_avail == 0 && !chip_data->ack_mode) { 
         buffer_bytes_avail = period_size_bytes;
      }

      /*
       * Transfer data from the ALSA circular buffer to the SMD buffers, and 
       * write the SMD buffers to the audio driver input port. 
       */
      while ( ((buffer_bytes_avail >= period_size_bytes) || (smd_buffer_desc != NULL)) && chip_data->pcm_started ) {

         if ( smd_buffer_desc == NULL ) {
            /* Attempt to allocate an SMD buffer. */
            if ( !smd_buffer_alloc(&smd_buffer_desc) ) {
               /* If the allocation fails, stop transferring data. */
               break;
            }
            else {
               /* Try to map the buffer as cached (speeds up memcpy by 300%). */
               cached_buffer = OS_MAP_IO_TO_MEM_CACHE( smd_buffer_desc->phys.base, period_size_bytes);

               /* Copy one period of data from the ALSA circular buffer to the SMD buffer. */
               if ( cached_buffer != NULL ) {
                  memcpy( cached_buffer, (substream->runtime)->dma_area + (chip_data->dma_read_offset % buffer_size_bytes), period_size_bytes );
                  /* Unmap the cached buffer so we don't get a virtual memory leak. */
                  OS_UNMAP_IO_FROM_MEM( cached_buffer, period_size_bytes );
               }
               else {
                  memcpy( smd_buffer_desc->virt.base, (substream->runtime)->dma_area + (chip_data->dma_read_offset % buffer_size_bytes), period_size_bytes );
               }

               ALSA_SHIM_EVENT( SVEN_MODULE_EVENT_AUD_IO_ALSA_SHIM_COPY, 
                                period_size_bytes, 
                                (int)((substream->runtime)->dma_area + (chip_data->dma_read_offset % buffer_size_bytes)), 
                                (int)(smd_buffer_desc->virt.base), 
                                0, 0, 0 );

               /* Update the level of data in the buffer. */
               smd_buffer_desc->phys.level = period_size_bytes;

               /* Update the "hardware" pointer. */
               chip_data->dma_read_offset += period_size_bytes;
               chip_data->dma_read_offset %= buffer_size_bytes;

               buffer_bytes_avail -= period_size_bytes;
            }
         }

         /* Attempt to write the buffer to the port.  If it fails, the port is full, so stop transferring data. */
         if ( !smd_port_write(chip_data->audio_input_port_handle, &smd_buffer_desc) ) {
            break;
         }
         else {
            /* If we wrote a buffer to the port, we want to notify ALSA that a period has elapsed */
            snd_pcm_period_elapsed( substream );
         }

      }

      /* Sleep for a half buffer's worth of time (may or may not be same as half period).
       * This keeps us from buffering up tons of data inside the audio driver when we 
       * start up a stream.
       * Note:  This is just a workaround for now and will need to be replaced with a 
       *        more deterministic mechanism.  Some possible solutions are:
       *        SMD clock alarms: may have drift if renderers use a different clock.
       *        Client/App tags: not yet implemented in SMD drivers.
       *        Reduce buffering-inside audio driver: Only reduces problem.
       */
      // No longer needed because buffering inside the driver has been reduced.
      //os_sleep( chip_data->ms_per_smd_buf / 2 );

   } /* while ( chip_data->alsa_shim_thread_running ) */

   /* If there's an SMD buffer still allocated, free it. */
   if ( smd_buffer_desc != NULL ) {
      ismd_buffer_dereference( smd_buffer_desc->unique_id );
   }

   /*
    * Send and end-of-stream tag to the audio driver, then wait for the 
    * driver to notify us that it received the eos tag.  This way we know 
    * the driver has played out all of the data we sent so far.
    */
   if ( send_eos_tag(chip_data) ) {
      smd_event_wait( chip_data->audio_eos_event_handle, ALSA_SHIM_WAIT_TIMEOUT_EOS );
   }

   ALSA_SHIM_EXIT;

   return ( NULL );
}


/* Function: 
 *   alsa_shim_proxy_thread
 *
 * Description:
 *   The alsa_shim_proxy_thread exists to translate between events that are 
 *   safe to trigger from atomic functions and events that are not.  The port 
 *   monitor thread needs to rely on SMD events (ismd_event_t), but 
 *   triggering those events is not safe from atomic functions.  This thread 
 *   waits on an OSAL event (os_event_t), which can be triggered from an 
 *   atomic function, then it triggers the SMD event.
 *
 * Parameters:
 *   substream [in] - Pointer to the structures that contain both the ALSA
 *                    stream state and our hardware stream state.
 */
static void *
alsa_shim_proxy_thread( void *substream )
{
   ce31xx_t *chip_data;

   ALSA_SHIM_ENTER;

   chip_data = (ce31xx_t *)(((struct snd_pcm_substream *)(substream))->private_data);

   while ( chip_data->alsa_shim_thread_running ) {

      os_event_wait( &(chip_data->alsa_shim_trigger_event), EVENT_NO_TIMEOUT );

      if ( chip_data->alsa_shim_thread_running ) {
         ismd_event_strobe( chip_data->thread_wakeup_event_handle );
      }

   }

   ALSA_SHIM_EXIT;

   return ( NULL );
}


/* Function: 
 *   smd_event_wait
 *
 * Description:
 *   Waits for an SMD event to trigger.
 * 
 * Parameters:
 *   smd_event [in] - Handle to SMD event to wait for.
 *   timeout [in]   - Maximum amount of time to wait for event to trigger.
 */
static bool 
smd_event_wait( ismd_event_t smd_event, 
                int          timeout )
{
   bool result = false;
   ismd_result_t ismd_ret;

   ALSA_SHIM_ENTER;

   if ( (ismd_ret = ismd_event_wait(smd_event, timeout)) != ISMD_SUCCESS ) {
      if ( (ismd_ret == ISMD_ERROR_TIMEOUT) && (timeout != ISMD_TIMEOUT_NONE) ) {
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_WARNING, "ismd_event_wait:timeout" );
      }
      else {
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_event_wait:%d", ismd_ret );
      }
   }
   else if ( (ismd_ret = ismd_event_acknowledge(smd_event)) != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_event_acknowledge:%d", ismd_ret );
   }
   else {
      result = true;
   }

   ALSA_SHIM_EXIT;
   
   return ( result );
}


/* Function: 
 *   smd_buffer_alloc
 *
 * Description:
 *   Allocates an SMD buffer of the size defined for the alsa_shim.
 * 
 * Parameters:
 *   buffer [out] - pointer to allocated buffer descriptor.  Will be
 *                  NULL if allocation fails.
 */
static bool 
smd_buffer_alloc( ismd_buffer_descriptor_t **buffer )
{
   bool result = false;
   ismd_result_t ismd_ret;

   ALSA_SHIM_ENTER;

   if ( (ismd_ret = ismd_buffer_alloc_typed_direct(ISMD_BUFFER_TYPE_PHYS, ISMD_BUFSIZE, buffer)) != ISMD_SUCCESS ) {
      *buffer = NULL;
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_buffer_alloc_typed_direct:%d", ismd_ret );
   }
   else {
      (*buffer)->phys.level = 0;
      result = true;
   }

   ALSA_SHIM_EXIT;

   return ( result );
}


/* Function: 
 *   smd_port_write
 *
 * Description:
 *   Writes an SMD buffer to an SMD port.
 * 
 * Parameters:
 *   port [in]       - Handle to SMD port
 *   buffer [in/out] - pointer to buffer descriptor.  Will be set to NULL
 *                     if port write is successful.
 */
static bool 
smd_port_write( ismd_port_handle_t         port, 
                ismd_buffer_descriptor_t **buffer )
{
   bool result = false;
   ismd_result_t ismd_ret;

   ALSA_SHIM_ENTER;

   if ( (ismd_ret = ismd_port_write(port, (*buffer)->unique_id)) == ISMD_SUCCESS ) {
      *buffer = NULL;
      result = true;
   }
   else if ( ismd_ret != ISMD_ERROR_NO_SPACE_AVAILABLE ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_port_write:%d", ismd_ret );
   }
   else {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_INFO, "ismd_port_write: no space" );
   }

   ALSA_SHIM_EXIT;

   return ( result );
}


static bool 
send_eos_tag( ce31xx_t *chip_data ) 
{
   bool ret = false;
   ismd_result_t result = ISMD_SUCCESS;
   ismd_buffer_descriptor_t *buffer = NULL;

   ALSA_SHIM_ENTER;

   /* Allocate a buffer to carry the EOS tag */
   if ( !smd_buffer_alloc(&buffer) != ISMD_SUCCESS ) {
      ret = false;
   }

   /* Set the EOS tag in the buffer. */
   else if ( (result = ismd_tag_set_eos(buffer->unique_id)) != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_tag_set_eos:%d", result);      
   }

   /* Attempt to write the buffer into the port. */
   else if ( smd_port_write(chip_data->audio_input_port_handle, &buffer) ) {
      /* Success. */
      ret = true;
   }

   /* The port was full, wait up to 100ms for it to drain and try again. */
   else { 
      smd_event_wait( chip_data->thread_wakeup_event_handle, 100 );

      if ( !smd_port_write(chip_data->audio_input_port_handle, &buffer) ) {
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "Can't send EOS!" );      
         ret = false;
      }
      else {
         /* Success. */
         ret = true;
      }
   }

   /* Free the buffer if there was a failure after we allocated it. */
   if ( buffer != NULL ) {
      ismd_buffer_dereference( buffer->unique_id );
   }

   ALSA_SHIM_EXIT;

   return ( ret );
}


/* Function: 
 *   map_sample_rate
 *
 * Description:
 *   Maps the stream's sample rate from the ALSA format to the audio driver's 
 *   format.    
 *
 * Parameters:
 *   alsa_sample_rate [in] - ALSA's sample rate.
 *   sample_rate [out]     - The audio driver's sample rate.
 */
static bool
map_sample_rate( int           alsa_sample_rate,
                 unsigned int *sample_rate )
{
   int result = true;
   
   switch ( alsa_sample_rate ) {
      case   8000:
      //case  11025:
      case  12000:
      case  16000:
      //case  22050:
      case  24000:
      case  32000:
      case  44100:
      case  48000:
      //case  64000:
      case  88200:
      case  96000:
      case 176400:
      case 192000:
         *sample_rate = alsa_sample_rate;
         break;

      default:
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "map_sample_rate:%d", alsa_sample_rate );
         result = false;
         break;
   }

   return ( result );
}


/* Function: 
 *   map_sample_size
 *
 * Description:
 *   Maps the sample size and endian-ness from the ALSA format to the audio 
 *   driver's format.    
 *
 * Parameters:
 *   alsa_format [in]  - ALSA's sample size.
 *   sample_size [out] - The audio driver's sample size.
 */
static bool 
map_sample_size( snd_pcm_format_t  alsa_format,
                 int              *sample_size )
{
   int result = true;

   switch ( alsa_format ) {
      /* 16-bit Little-endian */
      case SNDRV_PCM_FORMAT_S16_LE:
         *sample_size = 16;
         break;

      /* 24-bit packed into 3-bytes */
      case SNDRV_PCM_FORMAT_S24_3LE:
         *sample_size = 24;
         break;

      /* 32-bit or 24-bit left justified into 32-bits */
      case SNDRV_PCM_FORMAT_S32_LE:
         *sample_size = 32;
         break;

      default:
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "map_sample_size:%d", alsa_format );
         result = false;
         break;
   }
  
   return ( result );
}


/* Function: 
 *   map_num_channels
 *
 * Description:
 *   Maps the number of channels from ALSA to the audio driver's format.
 *
 * Parameters:
 *   alsa_num_channels [in]   - ALSA's channel count.
 *   audio_channel_type [out] - The audio driver's channel configuration.
 */
static bool
map_num_channels( int                          alsa_num_channels,
                  ismd_audio_channel_config_t *audio_channel_type )
{
   int result = true;

   switch ( alsa_num_channels ) {
      case 1: /* Mono */
         *audio_channel_type = AUDIO_CHAN_CONFIG_1_CH;
         break;

      case 2: /* Stereo */
         *audio_channel_type = AUDIO_CHAN_CONFIG_2_CH;
         break;

      case 6: /* 5.1 */
         *audio_channel_type = AUDIO_CHAN_CONFIG_6_CH;
         break;

      case 8: /* 7.1 */
         *audio_channel_type = AUDIO_CHAN_CONFIG_8_CH;
         break;

      default:
         ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "map_num_channels:%d", alsa_num_channels );
         result = false;
         break;
   }

   return ( result );
}


/* Function: 
 *   smd_audio_input_alloc
 *
 * Description:
 *   Allocates all SMD resources needed for us to use an input to the SMD 
 *   audio driver.
 * 
 * Parameters:
 *   chip_data [out] - pointer to chip_data structure which will hold the 
 *                     state holds the state of the resources to allocate.
 */
static bool 
smd_audio_input_alloc( ce31xx_t *chip_data )
{
   bool result = false;
   ismd_result_t ret;

   ALSA_SHIM_ENTER;

   /* Get a handle to the global audio processor. */
   if ( (ret = ismd_audio_open_global_processor(&(chip_data->audio_processor_handle))) != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_audio_open_processor:%d", ret );
   }

   /* Allocate a new untimed input and input port. */
   else if ( (ret = ismd_audio_add_input_port(chip_data->audio_processor_handle,
                                              false, /* untimed */
                                              &(chip_data->audio_input_handle),
                                              &(chip_data->audio_input_port_handle))) != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_audio_add_input_port:%d", ret );
   }

   /*  Set the data format of the new input. */
   else if ( (ret = ismd_audio_input_set_data_format(chip_data->audio_processor_handle,
                                                     chip_data->audio_input_handle,
                                                     ISMD_AUDIO_MEDIA_FMT_PCM)) != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR,"ismd_audio_input_set_data_format:%d", ret );
   }


   /* Allocate an event to use for notiifcations on the state of the audio input port. */  
   else if ( (ret = ismd_event_alloc( &(chip_data->thread_wakeup_event_handle))) != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_event_alloc:%d", ret );
   }

   /* Attach the event to the audio input port. */
   else if ( (ret = ismd_port_attach( chip_data->audio_input_port_handle, 
                                      chip_data->thread_wakeup_event_handle, 
                                      ISMD_QUEUE_EVENT_NOT_FULL | ISMD_QUEUE_EVENT_LOW_WATERMARK | ISMD_QUEUE_EVENT_EMPTY,
                                      2)) != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_port_attach:%d", ret );
   }

   /* Allocate a clock to drive this input. */
   //else if ( ret = ismd_clock_alloc( &(chip_data->audio_input_clock_handle))) != ISMD_SUCCESS ) {
   //   ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_clock_alloc:%d", ret );
   //}

   /* Assign the clock to the input. */
   //else if ( (ret = ismd_dev_set_clock(chip_data->audio_input_handle, chip_data->audio_input_clock_handle)) != ISMD_SUCCESS ) {
   //   ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_dev_set_clock:%d", ret );
   //}

   /* Get the event that notifies us when end-of-stream is reached on this input. */
   else if ( (ret = ismd_audio_input_get_notification_event(chip_data->audio_processor_handle,
                                                            chip_data->audio_input_handle,
                                                            ISMD_AUDIO_NOTIFY_STREAM_END,
                                                            &chip_data->audio_eos_event_handle)) != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_audio_input_get_notification_event:%d", ret );
   }

   else {
      result = true;
   }

   if ( (ret != ISMD_SUCCESS) && (chip_data->audio_processor_handle != AUDIO_INVALID_HANDLE) ) {
      ismd_audio_close_processor( chip_data->audio_processor_handle );
   }

   ALSA_SHIM_EXIT;

   return ( result );
}


/* Function: 
 *   smd_audio_input_free
 *
 * Description:
 *   Frees all SMD resources associated with an input to the audio driver.
 * 
 * Parameters:
 *   chip_data [in] - pointer to chip_data structure which holds the state
 *                    of all of the resources we want to free.
 */
static void 
smd_audio_input_free( ce31xx_t *chip_data )
{
   ismd_result_t ismd_ret;

   ALSA_SHIM_ENTER;

   ismd_ret = ismd_dev_set_state( chip_data->audio_input_handle, ISMD_DEV_STATE_STOP );
   if ( ismd_ret != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_dev_set_state:%d", ismd_ret );
   }

   ismd_ret = ismd_audio_remove_input( chip_data->audio_processor_handle, chip_data->audio_input_handle );
   if ( ismd_ret != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_audio_close_processor:%d", ismd_ret );
   }   

   ismd_ret = ismd_audio_close_processor( chip_data->audio_processor_handle );
   if ( ismd_ret != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_audio_close_processor:%d", ismd_ret );
   }

   ismd_ret = ismd_event_free( chip_data->thread_wakeup_event_handle );
   if ( ismd_ret != ISMD_SUCCESS ) {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_event_free:%d", ismd_ret );
   }

   //ismd_ret = ismd_clock_free( chip_data->audio_input_clock_handle );
   //if ( ismd_ret != ISMD_SUCCESS ) {
   //   ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_ERROR, "ismd_clock_free:%d", ismd_ret );
   //}

   ALSA_SHIM_EXIT;

   return;
}


/* Function: 
 *   init_chip_data
 *
 * Description:
 *   Initialize a ce31xx_t chip_data structure to it's default values.
 * 
 * Parameters:
 *   chip_data [out] - pointer to chip_data structure to initialize.
 */
static void 
init_chip_data( ce31xx_t *chip_data )
{
   chip_data->dma_read_offset          = 0;
   chip_data->dma_write_offset         = 0;
   chip_data->prepared_size            = 0;
   chip_data->ms_per_smd_buf           = 10;
   chip_data->ack_mode                 = false;
   chip_data->pcm_started              = false;
   chip_data->pcm_configured           = false;
   chip_data->audio_processor_handle   = AUDIO_INVALID_HANDLE; 
   chip_data->audio_input_handle       = AUDIO_INVALID_HANDLE;
   chip_data->audio_input_port_handle  = ISMD_PORT_HANDLE_INVALID;
   //chip_data->audio_input_clock_handle = ISMD_CLOCK_HANDLE_INVALID;
   //chip_data->thread_alarm_handle      = ISMD_CLOCK_HANDLE_INVALID;
   //chip_data->thread_alarm_scheduled   = false;
   chip_data->audio_eos_event_handle   = ISMD_EVENT_HANDLE_INVALID;
   chip_data->alsa_shim_thread_running = false;
   
   return;
}


/* Function: 
 *   sven_init
 *
 * Description:
 *   This is the function that initializes SVEN so the SHIM can use it.  It 
 *   allocates a SVEN device handle and configures the handle to use the 
 *   AUDIO_IO SVEN module.
 * 
 * Parameters:
 *   N/A
 */
static bool 
sven_init( void ) 
{
   bool result = false;

   /* 
    * We want to call the SVEN init module only if the handle is not NULL.  
    * If this fails, print an error and return an error code.
    */
   alsa_devh = devhandle_factory( NULL );
   if ( alsa_devh != NULL ) {
      devh_SVEN_SetModuleUnit( alsa_devh, SVEN_module_GEN3_AUD_IO, AUDIO_SVEN_DEGUG_UNIT_NUM);  
      result = true;
   }
   else {
      ALSA_SHIM_LOG( ALSA_SHIM_SEVERITY_WARNING, "devhandle_factory:(NULL)" );
   }

   return ( result );
}


/* Function: 
 *   sven_log
 *
 * Description:
 *   Logs a string using SVEN events.  Will divide the string up into multiple 
 *   sven events if necessary.  In general, strings should be as short as 
 *   possible.
 *
 * Parameters:
 *   severity [in] - This is the log level.
 *
 *   format[in] - This is a string with %d type data in it just like a printf
 *
 *   ... [in]   - This is the variable number of arguments like printf.
 */
static void 
sven_log( int severity, char *format, ... )
{
   char    buf[255];
   char    tmpbuf[MAX_SVEN_LEN + 1];
   int     split;
   int     i;
   va_list arglist;

   if (severity > alsa_shim_sven_debug_level) {
      return;
   }

   if (alsa_devh == NULL) {
      return;
   }

   if ( format[0] == '\0' ) {
      return;
   }

   /* 
    * We first get the data into a buffer so we can print it out. 
    * These lines below take care of getting the variable list into
    * the string 'buf'.  
    */
   va_start( arglist, format );
   vsprintf( buf, format, arglist );
   va_end( arglist );

   /* 
    * The final string is in 'buf' but we need to print it in 
    * multiple lines if it is greater than MAX_SVEN_LEN.  Split 
    * will tell us how many lines it will be.  We use the mod 
    * function just in case it is on a perfect alignment.  If 
    * so, we just print 'split' lines, otherwise add one since
    * there are some extra characters.  
    */
   split = ( strlen(buf) + (MAX_SVEN_LEN-1) ) / MAX_SVEN_LEN;

   /* 
    * Go through this loop for each line we need to print.  
    * Since we handle more than one type, we switch on that so
    * we can handle all in this one routine.  
    */   
   for ( i = 0; i < split; i++ ) {
      
      /*    For each line, we just adjust our pointer into the 
       * buffer.  If MAX_SVEN_LEN = 20, the first time, it is
       * 0, then 20, then 40, etc.  
       */
      strncpy( tmpbuf, &(buf[i*MAX_SVEN_LEN]), MAX_SVEN_LEN );

      switch ( severity ) {
         case ALSA_SHIM_SEVERITY_WARNING:
            DEVH_WARN(alsa_devh, tmpbuf);
            break;

         case ALSA_SHIM_SEVERITY_ERROR:
            DEVH_FATAL_ERROR(alsa_devh, tmpbuf);
            break;

         case ALSA_SHIM_SEVERITY_INFO:
            DEVH_DEBUG(alsa_devh, tmpbuf);
            break;

         default:
            DEVH_DEBUG(alsa_devh, tmpbuf);
            break;
      }

   }

   return;
}


