/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:
  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

/*
 * File Name: alsa_shim.h
 */


#include <linux/module.h>
#if 0
   #include <sound/driver.h>  // Contents of this file moved to <sound/core.h> in Linux Kernel 2.6.25
                              // Eventually, this file will be removed and cause an error, so code will
                              // be needed to include only when kernel version is 2.6.24 or below.
#endif
#include <sound/core.h>
#include <sound/control.h>
#include <sound/pcm.h>
#include <sound/pcm_params.h>
#include <sound/info.h>
#include <sound/initval.h>

#include "ismd_audio.h"    // This is Intel's audio driver's API.
#include "osal.h"
#include "sven_devh.h"
#include "ismd_core.h"
#include "ismd_core_protected.h"
#include "thread_utils.h"
#include <auto_eas/gen3_aud_io.h>


#define  NUM_PCMS  1  // Num of PCM streams supported by each card.
#define  NUM_CARDS 1  // Num of Cards supported by the ALSA shim.

#define KB (1024)
#define MB (1024*1024)

#define ISMD_BUFSIZE          (8*KB) // This size is specified in in the entry smd_buffers_ALSA config_databases/cm/memory_layout_512M.hcfg
#define PERIOD_SIZE_MIN       (2*KB)
#define PERIOD_SIZE_MAX       (2*KB)
#define PERIODS_PER_BUFFER_MIN 8
#define PERIODS_PER_BUFFER_MAX 8

/* ALSA_BUF_SIZE must be a multiple of PERIOD_SIZE_MAX. */
#define ALSA_BUF_SIZE (PERIOD_SIZE_MAX * PERIODS_PER_BUFFER_MAX)

/* Maximum time to wait after send end-of-stream to audio driver (in milliseconds) */
#define ALSA_SHIM_WAIT_TIMEOUT_EOS 2500

typedef struct snd_card my_snd_card_t;
typedef struct snd_pcm my_snd_pcm_t;
typedef struct snd_pcm_substream my_snd_pcm_substream_t;;
typedef struct snd_pcm_hw_params my_snd_pcm_hw_params_t;



/*    Corresponds to the chip record in the "Writing an ALSA driver" This data
 * structure is stored in the private_data member of the PCM substream and is
 * used to retrieve all the information that is required to call into the core
 * media driver functions in the common subdirectory.
 */
typedef struct {
   my_snd_card_t             *card;                       /* Pointer to card */
   my_snd_pcm_t              *pcm;                        /* Pointer to PCM */
   volatile size_t            dma_read_offset;            /* Offset of the Shim's read pointer from the beginning of the buffer.*/
   volatile size_t            dma_write_offset;           /* Offset of ALSA's write pointer from the beginning of the buffer (ack_mode=true only) */
   volatile size_t            prepared_size;              /* ALSA buffer level in previous prepare callback. */
   int                        ms_per_smd_buf;             /* Number of ms of data put into each SMD buffer. */
   volatile bool              ack_mode;                   /* Is the ack callback being called or not? */
   volatile bool              pcm_started;                /* Is the PCM stream started? */
   volatile bool              pcm_configured;             /* Have we called ismd_audio_input_set_pcm_format? */
   ismd_audio_processor_t     audio_processor_handle;     /* Handle to the audio driver's "global processor" */
   ismd_dev_t                 audio_input_handle;         /* Handle to the audio processor input used for this stream. */
   ismd_port_handle_t         audio_input_port_handle;    /* Handle to the SMD port that feeds the input. */
   //ismd_clock_t               audio_input_clock_handle;   /* Handle to the clock that drives the input. */
   //ismd_clock_alarm_t         thread_alarm_handle;
   //bool                       thread_alarm_scheduled;
   ismd_event_t               audio_eos_event_handle;     /* Handle to an event for end-of-stream notifications. */
   volatile bool              alsa_shim_thread_running;   /* Boolean to tell the thread when to exit. */
   os_thread_t                alsa_shim_mon_thread;       /* Thread to monitor the ALSA buffer. */
   os_event_t                 alsa_shim_trigger_event;
   os_thread_t                alsa_shim_rel_thread;       /* Thread to relay events from atomic functions to non-atomic functions. */
   ismd_event_t               thread_wakeup_event_handle; /* Event for notifying the thread when something interesting happens. */
} ce31xx_t;


int  __init alsa_shim_init( void );
void __exit alsa_shim_exit( void );

int alsa_shim_open( struct snd_pcm_substream * );
int alsa_shim_close( my_snd_pcm_substream_t * );

int alsa_shim_hw_params ( my_snd_pcm_substream_t *, my_snd_pcm_hw_params_t *);
int alsa_shim_hw_free (my_snd_pcm_substream_t *);

int alsa_shim_prepare (my_snd_pcm_substream_t *);
int alsa_shim_trigger ( struct snd_pcm_substream *, int);
snd_pcm_uframes_t alsa_shim_pointer( my_snd_pcm_substream_t *);
int alsa_shim_ack( my_snd_pcm_substream_t *substream );

int alsa_shim_mmap( my_snd_pcm_t * );
int alsa_shim_munmap( my_snd_pcm_t * );

size_t playback_bytes_avail( struct snd_pcm_substream *substream );
static void *alsa_shim_monitor_thread( void *param );
static void *alsa_shim_proxy_thread( void *substream );

static bool send_eos_tag( ce31xx_t *chip_data );
static void init_chip_data( ce31xx_t *chip_data );

static bool map_sample_rate( int , unsigned int * );
static bool map_sample_size( snd_pcm_format_t, int * );
static bool map_num_channels( int , ismd_audio_channel_config_t * );

static bool smd_audio_input_alloc( ce31xx_t *chip_data );
static void smd_audio_input_free( ce31xx_t *chip_data );
static bool smd_event_wait( ismd_event_t smd_event, int timeout );
static bool smd_buffer_alloc( ismd_buffer_descriptor_t **buffer );
static bool smd_port_write( ismd_port_handle_t port,  ismd_buffer_descriptor_t **buffer );

static bool sven_init( void );
static void sven_log( int severity, char *format, ... );


#define MAX_SVEN_LEN              23
#define AUDIO_SVEN_DEGUG_UNIT_NUM  8

#define ALSA_SHIM_SEVERITY_ALWAYS       0
#define ALSA_SHIM_SEVERITY_ERROR        1  /* Error (fatal) */
#define ALSA_SHIM_SEVERITY_WARNING      2  /* Warning (non-fatal) */
#define ALSA_SHIM_SEVERITY_INFO         3  /* Important Information */
#define ALSA_SHIM_SEVERITY_TRACE        4  /* Debug Trace */

#define ALSA_SHIM_LOG(severity, format, args...)           \
         if ( severity <= alsa_shim_print_debug_level ) {  \
            OS_PRINT( "%s:%s: ", __FILE__, __FUNCTION__ );   \
            OS_PRINT( format, ## args );                   \
            OS_PRINT( "\n" );                              \
         }                                                 \
         sven_log(severity, format, ## args)

#define ALSA_SHIM_ENTER                                                             \
   if (alsa_shim_print_debug_level >= ALSA_SHIM_SEVERITY_TRACE)                     \
      OS_PRINT( "+%s\n", __FUNCTION__ );                                       \
   if (NULL != alsa_devh && alsa_shim_sven_debug_level >= ALSA_SHIM_SEVERITY_TRACE) \
      DEVH_FUNC_ENTER(alsa_devh)

#define ALSA_SHIM_EXIT                                                              \
   if (alsa_shim_print_debug_level >= ALSA_SHIM_SEVERITY_TRACE)                     \
      OS_PRINT( "-%s\n", __FUNCTION__ );                                       \
   if (NULL != alsa_devh && alsa_shim_sven_debug_level >= ALSA_SHIM_SEVERITY_TRACE) \
      DEVH_FUNC_EXIT(alsa_devh)

#define ALSA_SHIM_EVENT(event, v1,v2,v3,v4,v5,v6) if (NULL != alsa_devh) devh_SVEN_WriteModuleEvent(alsa_devh, event, v1,v2,v3,v4,v5,v6)

