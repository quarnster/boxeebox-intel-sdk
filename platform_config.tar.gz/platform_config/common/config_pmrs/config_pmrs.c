/***********************************************************************
  This file is provided under a dual BSD/LGPLv2.1 license.  When using
  or redistributing this file, you may do so under either license.

  LGPL LICENSE SUMMARY

  Copyright(c) <2007-2011>. Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2.1 of the GNU Lesser General Public
  License as published by the Free Software Foundation.

  This library is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307
  USA. The full GNU Lesser General Public License is included in this
  distribution in the file called LICENSE.LGPL.

  Contact Information:
      Intel Corporation
      2200 Mission College Blvd.
      Santa Clara, CA  97052

  BSD LICENSE

  Copyright (c) <2007-2011>. Intel Corporation. All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    - Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    - Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    - Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

************************************************************************/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#ifdef VER
const char *platform_config_version_string = "#@# platform_config_app " VER;
#endif

//#define USE_OSAL 1
#ifdef USE_OSAL
#include "osal.h"
#else
#define OS_ASSERT assert
#define OS_MEMCMP memcmp
#define OS_MEMSET memset
#define OS_PRINT  printf
#endif


#include "platform_config.h"
#include "platform_config_paths.h"

// Control for debug messages
#define DEFAULT_LOCAL_DEBUG_LEVEL 0

static int verbosity_level = DEFAULT_LOCAL_DEBUG_LEVEL;
#define LOCAL_LOG_MSG(level, format...)   if( (level) <= verbosity_level ) OS_PRINT( format )

// Dump pmr information to the console after the memory layout file is processed
//#define ENABLE_GET_PMR_INFO 1

// Miscellaneous macros
#define ROUND_UP(n,a)           (((n)+((a)-1)) & ~((a)-1)) /* Round n up to the next multiple of a, which must be a power-of-2 */
#define ROUND_DOWN(n,a)         ((n) & ~((a)-1)) /* Round n down to the next multiple of a, which must be a power-of-2 */
#define MIN(x,y)                (((x) < (y)) ? (x) : (y))
#define MAX(x,y)                (((x) > (y)) ? (x) : (y))
#define IS_PWR_OF_2(n)          (((n) != 0) && (((n) & ((n)-1)) == 0)) /* Determine if a number is a power-of-2 */
#define LARGEST_PWR_OF_2(m)     ((m) & -(m)) /* Find the largest power-of-2 factor of a number */

#define CONFIG_PATH_PLATFORM_PMR_INFO  "platform.memory.pmr_info"

// Size constraints
#define MAX_MEM_LAYOUT_ENTRIES  256
#define MAX_LAYOUT_NAME_SZ       64
#define NUM_PMRS                 16
#define INITIAL_BASE_PA           0
#define DEFAULT_ALIGNMENT        16 /* Memory layout regions will default to an alignment of 16 bytes. */
#define DEFAULT_PMR_INDEX        -1
#define PMR_ALIGNMENT      0x100000 /* PMRs must be 1MB aligned. */


typedef struct mem_layout_struct {
   char                       name[MAX_LAYOUT_NAME_SZ];
   unsigned int               base_pa;       // Physical address of buffers
   unsigned int               size;          // Size in bytes
   int                        pmr_index;     // The PMR (see pmr_t) required by these buffers
   int                        alignment;     // Byte alignment required for these buffers  
   unsigned int               adjusted_size; // Size in memory after accounting for alignment restrictions, etc.
   struct mem_layout_struct * next;
   struct mem_layout_struct * prev;
} mem_layout_t;


// Internally used list node
typedef struct {
    mem_layout_t *head;
    mem_layout_t *tail;
} layout_list_t;


/* Completely describe a Protected Memory Region */
typedef struct pmr_struct {
   unsigned int base_pa;      // Physical address of PMR
   unsigned int size;         // PMR size in bytes
   int          type;         // Region as described in spec
   char         name[MAX_LAYOUT_NAME_SZ];  // Name used in memory layout configuration
   unsigned int sta;          // 32 bit flags describing Sec attr for the above region (described in spec)
                              // i.e. bit0==sta 0. 1 means sta 0 is active, 0 means sta 0 is not active
   layout_list_t layouts;     // Ordered list of structures from the memory layout file.
} pmr_t;



//****************************************************************************
// The code below should be removed.  This detail belongs in the HAL of the 
// component that actually writes the PMR registers (SEC?).

#define DISABLE_PMR         0
#define ENABLE_PMR_FULL     1
#define ENABLE_PMR_PARTIAL  2
#define ENABLE_PMR_DEFAULT  DISABLE_PMR

#define   STA_TSD_FW_CODE     0
#define   STA_FW_CODE         136
#define   STA_TSD_FW_DATA     0
#define   STA_FW_DATA         136
#define   STA_MPX_AV_STRM     0
#define   STA_CMP_VID         136
#define   STA_PROT_AUDIO      0
#define   STA_PIXELS          0
#define   STA_VID_WB          0
#define   STA_SEC             128


/* Determines the kind of PMR based on its intended use */
typedef enum pmr_enum {
   pmr_invalid = -1,
   tsd_fw_code = 0,
   sec         = 1,   
   tsd_fw_data = 2,
   pixels      = 3,   
   fw_code     = 4,
   fw_data     = 5,
   av_strm     = 6,
   cmp_vid     = 7,
   audio       = 8,
   vid_wbak    = 9
} pmr_use_t;

/*
   Two modes of operation are supported by this program.
      1. Full spec, aligns with the latest protected memory architecture
      2. Partial spec aligns with the early protected memory architecture
      
   The memory configuration files for each SOC will be different for these
   two cases.
   
   The last entry in this table is used to hold information about 
   all of the memory layout entries that have a pmr value of -1.
   Meaning that these buffers do not fall in the address range of
   any defined pmr. This address range will not be written back into
   platform config and will therefore not be visible to the SEC.
*/   
static pmr_t pmrs_full_spec[NUM_PMRS+1] = {
//   base,                size, type,        name,          sta,              layouts.head, layouts.tail
   { INITIAL_BASE_PA,     0,    tsd_fw_code, "TSD_FW_CODE", STA_TSD_FW_CODE,  {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    sec,         "SEC",         STA_SEC,          {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    tsd_fw_data, "TSD_FW_DATA", STA_TSD_FW_DATA,  {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    pixels,      "PIXELS",      STA_PIXELS,       {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    fw_code,     "FW_CODE",     STA_FW_CODE,      {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    fw_data,     "FW_DATA",     STA_FW_DATA,      {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    av_strm,     "AV_STRM",     STA_MPX_AV_STRM,  {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    cmp_vid,     "CMP_VIDEO",   STA_CMP_VID,      {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    audio,       "AUDIO",       STA_PROT_AUDIO,   {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    vid_wbak,    "VIDEO_WB",    0 ,               {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    pmr_invalid, "NONE",        0,                {NULL,        NULL} },
};

static pmr_t pmrs_partial_spec[NUM_PMRS+1] = {
//   base,                size, type,        name,          sta,              layouts.head, layouts.tail
   { INITIAL_BASE_PA,     0,    sec,         "SEC",         STA_SEC,          {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    fw_code,     "FW_CODE",     STA_FW_CODE,      {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    fw_data,     "FW_DATA",     STA_FW_DATA,      {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    cmp_vid,     "CMP_VIDEO",   STA_CMP_VID,      {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { 0,                   0,    0,           "",            0,                {NULL,        NULL} },
   { INITIAL_BASE_PA,     0,    pmr_invalid, "NONE",        0 ,               {NULL,        NULL} },
};

// End of code that should be removed.  See comments above.
//****************************************************************************


// Global PMRs description array.  This currently changes based on the enable_pmrs config setting.
static pmr_t *pmrs = NULL;

// Global that holds value read from platform.memory.enable_pmr
static int g_enable_pmr;

// Global that holds platform.memory.media_base_address
static unsigned int g_media_base_address;

// Holds data read from platform_config platform.memory.layout
static mem_layout_t mem_layout_table[MAX_MEM_LAYOUT_ENTRIES];


/* 
   Return a pointer to the pmr table entry for a given type.  If type is not 
   found, return a pointer to the "pmr_invalid" entry.

   Assumes that the global "pmrs" pointer has been set. 
 */
static pmr_t *lookup_pmr_by_type( int type )
{
   int index;
   
   for ( index = 0; index < NUM_PMRS; index++ ) {
      if ( pmrs[index].type == type ) {
         break;
      }
   }
   
   return &pmrs[index];
}   


/* Read the memory base address from platform config */
static config_result_t 
get_system_base_addr( unsigned int *new_base )
{
   config_result_t ret = CONFIG_SUCCESS;
   
   OS_ASSERT( NULL != new_base );
      
   ret = config_get_int( ROOT_NODE,
                         "platform.memory.media_base_address",
                         (int *)new_base );
   if ( CONFIG_SUCCESS != ret ) {
      LOCAL_LOG_MSG( 0, "Failed to retreive memory base address\n" );
   }
   else {
      LOCAL_LOG_MSG( 1, "platform.memory.media_base_address = 0x%08X\n", *new_base );
   }
   return ret;
}


/* 
   Get the value of the "enable_pmr" setting in platform_config, or the 
   default if it doesn't exist.  Also, configure the pmr-to-sta mapping 
   table correctly based on the value of enable_pmr.
 */
static int 
determine_pmr_mode( void )
{
   config_result_t config_ret;

   pmrs = pmrs_full_spec;

   // Read the enable_pmr setting.
   config_ret = config_get_int( ROOT_NODE, "platform.memory.enable_pmr", &g_enable_pmr );
   if ( CONFIG_SUCCESS != config_ret ) {
      LOCAL_LOG_MSG( 1, "Failed to find the enable_pmr setting. Using default of %d.\r\n", ENABLE_PMR_DEFAULT);
      g_enable_pmr = ENABLE_PMR_DEFAULT;
   }
   else {
      LOCAL_LOG_MSG( 1, "platform.memory.enable_pmr = %d.\r\n", g_enable_pmr );
   }

   switch ( g_enable_pmr ) {
      case DISABLE_PMR:
         break;
      case ENABLE_PMR_FULL:
         pmrs = pmrs_full_spec;
         break;
      case ENABLE_PMR_PARTIAL:
         pmrs = pmrs_partial_spec;
         break;
      default:
         LOCAL_LOG_MSG( 0, "Unknown enable_pmr setting %d. Using default of %d.\r\n", g_enable_pmr, ENABLE_PMR_DEFAULT );
         g_enable_pmr = ENABLE_PMR_DEFAULT;
         break;
   }

   return g_enable_pmr;
}


/*
  Update the base physical address of a memory layout entry in the config database.
 */
static config_result_t 
update_region_pa( mem_layout_t *region )
{
   config_ref_t    layout_node;
   config_result_t config_ret;

   config_ret = config_node_find( ROOT_NODE, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT, &layout_node ); 
   if ( config_ret == CONFIG_SUCCESS ) {
      config_ret = config_node_find( layout_node, region->name, &layout_node ); 
      if ( config_ret == CONFIG_SUCCESS ) {
         config_ret = config_set_int( layout_node, "base", (int)region->base_pa );
      }
   }

   return config_ret;
}


/* 
   Ensure that the alignment boundry for a given memory layout 
   region is valid.  Adjust the region boundary if the size is 
   not a multiple of the alignment.
 */
static void 
check_alignment_boundry( mem_layout_t *region )
{
   /* If the alignment was specified... */
   if ( region->alignment != 0 ) {
      /* If the specified alignment is not a power of 2, then it's invalid. */
      if ( !IS_PWR_OF_2(region->alignment) ) {
         LOCAL_LOG_MSG( 0, "WARNING: Buffer alignment not supported.  Alignment must be a power of 2." );
         region->alignment = 0;
      }
   }

   /* If the alignment was not specified or was invalid... */
   if ( region->alignment == 0 ) {
      /* Make the alignment the largest power of 2 where (DEFAULT_ALIGNMENT <= alignment <= PMR_ALIGNMENT) */
      region->alignment =  MAX( DEFAULT_ALIGNMENT, MIN(PMR_ALIGNMENT, LARGEST_PWR_OF_2(region->size)) );
   }

   /* Calculate the next boundary that is a multiple of the alignment. */
   region->adjusted_size = ROUND_UP( region->size, region->alignment );
}


/* 
   Walk through the config tree analyzing the memory layout entries and placing
   the results in the mem_layout_table.
   Output parameter count contains the number of memory layout entries processed.
*/   
static void 
pmr_process_memory_layout ( int *count ) 
{
   config_result_t config_ret     = CONFIG_SUCCESS;
   config_ref_t    layout_node    = ROOT_NODE;
   config_ref_t    child_node     = ROOT_NODE; 
   int             i              = 0;

   OS_ASSERT( count != NULL );

   OS_MEMSET( &mem_layout_table, 0, sizeof( mem_layout_table ) );

   /* Find the first memory layout node. */
   config_ret = config_node_find( ROOT_NODE, CONFIG_PATH_PLATFORM_MEMORY_LAYOUT, &layout_node );

   if ( config_ret == CONFIG_SUCCESS )  {
      config_ret = config_node_first_child( layout_node, &child_node );

      /* Iterate through all of the layout entries. */
      while ( (config_ret == CONFIG_SUCCESS) && (i < MAX_MEM_LAYOUT_ENTRIES) ) {
         /* Get the values of the name, base, size, pmr, and align fields. */
         config_ret = config_node_get_name( child_node, mem_layout_table[i].name, MAX_LAYOUT_NAME_SZ );
         mem_layout_table[i].name[MAX_LAYOUT_NAME_SZ-1] = '\0'; /* Just being cautious. */

         config_ret = config_get_int( child_node, "base",  (int *)&mem_layout_table[i].base_pa   );

         config_ret = config_get_int( child_node, "size",  (int *)&mem_layout_table[i].size      );
         if ( (config_ret != CONFIG_SUCCESS) || (mem_layout_table[i].size == 0) ) {
            LOCAL_LOG_MSG( 1, "WARNING:  Memory Layout entry '%s' has no size.\n", mem_layout_table[i].name );
            mem_layout_table[i].size = 0;
         }

         config_ret = config_get_int( child_node, "align", (int *)&mem_layout_table[i].alignment );

         config_ret = config_get_int( child_node, "pmr",   (int *)&mem_layout_table[i].pmr_index );
         if ( config_ret != CONFIG_SUCCESS ) {
            LOCAL_LOG_MSG( 1, "WARNING:  Memory Layout entry '%s' has no PMR.  Using default of %d.\n", mem_layout_table[i].name, DEFAULT_PMR_INDEX );
            mem_layout_table[i].pmr_index = DEFAULT_PMR_INDEX;
         }

         /* Calculate the best alignment and the adjusted_size based on that alignment. */
         check_alignment_boundry( &mem_layout_table[i] );

         LOCAL_LOG_MSG( 4, "Layout entry '%s':\r\n", mem_layout_table[i].name );
         LOCAL_LOG_MSG( 4, 
                        "  base=%08X, size=%08X, pmr=%2d, align=%08X, adj_size=%08X\r\n", 
                        mem_layout_table[i].base_pa, 
                        mem_layout_table[i].size, 
                        mem_layout_table[i].pmr_index, 
                        mem_layout_table[i].alignment,
                        mem_layout_table[i].adjusted_size );
         i++;
         config_ret = config_node_next_sibling(child_node, &child_node);         
      }

      *count = i;
   }

   LOCAL_LOG_MSG( 2, "Processed %d memory layout records\n", i );
}


/*
   Add a layout node to the list.  Keep the list sorted by alignment from 
   highest to lowest. 
 */
static void 
add_to_list( mem_layout_t **list_head, mem_layout_t *new_node)
{
   mem_layout_t *prev_ptr = NULL;
   mem_layout_t *curr_ptr = *list_head;

   while ( (curr_ptr != NULL) && 
           (new_node->alignment <= curr_ptr->alignment) ) {
      prev_ptr = curr_ptr;
      curr_ptr = curr_ptr->next;
   }

   if ( prev_ptr != NULL ) {
      prev_ptr->next = new_node;
   }
   else {
      *list_head = new_node;
   }
   new_node->next = curr_ptr;
}


/*
   Transfer a memory layout read from the config tree into the appropriate 
   PMR structure. 
*/
static void
add_layout_entry_to_pmr( mem_layout_t *layout_entry )
{
   pmr_t *pmr_ent = NULL;

   pmr_ent = lookup_pmr_by_type( layout_entry->pmr_index );

   assert( NULL != pmr_ent );
   assert( NULL != pmr_ent->name );

   LOCAL_LOG_MSG( 4, 
                  "Adding layout entry '%s' to pmr %d (%s); size=%X\n", 
                  layout_entry->name, 
                  layout_entry->pmr_index, 
                  pmr_ent->name, 
                  layout_entry->size );

   add_to_list( &pmr_ent->layouts.head, layout_entry );
}


/*
   Walk through the memory layout table and coalesce layout entries into their
   appropriate PMRs.
*/
static void 
configure_pmrs( int count ) 
{
   pmr_t *        curr_pmr    = NULL;
   mem_layout_t * curr_layout = NULL;
   unsigned int   pmr_base    = 0;
   int            i           = 0;
 
   LOCAL_LOG_MSG( 2, "Adding %d layout entries to pmrs\n", count );
   for ( i = 0; i < count; i++ ) {
      add_layout_entry_to_pmr( &mem_layout_table[i] );
   }

   // Establish the base address of the first PMR at the media base address.
   // PMRs are required to be on 1 MB boundries, so adjust the base
   // if neccessary
   pmr_base = ROUND_UP( g_media_base_address, PMR_ALIGNMENT );
   if ( pmr_base != g_media_base_address ) {
      LOCAL_LOG_MSG( 0, "WARNING: media_base_address not 1MB aligned. Adjusting to next 1MB boundry.\n" );
   }

   // Calculate the total size and base address for each PMR
   for ( i = 0; i < (NUM_PMRS + 1); i++ ) {
      curr_pmr = &pmrs[i];
      curr_pmr->size = 0;
      curr_pmr->base_pa = pmr_base;
      curr_layout = curr_pmr->layouts.head;

      // Walk the list of regions (layout entries)
      // adding each region size to this PMR size
      // and updating the region's base address.
      while ( curr_layout != NULL ) {
         LOCAL_LOG_MSG( 4, "Evaluating pmr: %s layout: %s\n", curr_pmr->name, curr_layout->name );
         curr_layout->base_pa = curr_pmr->base_pa + curr_pmr->size;
         curr_pmr->size += curr_layout->adjusted_size;
         
         /* Write the revised physical address of the region back to the memory_layout database. */
         update_region_pa( curr_layout );
         
         curr_layout = curr_layout->next;
      }
      
      LOCAL_LOG_MSG( 4, 
                     "PMR: %d (%s) base_pa: %08x size: %08x\r\n", 
                     curr_pmr->type, 
                     curr_pmr->name, 
                     curr_pmr->base_pa, 
                     curr_pmr->size );

      pmr_base = ROUND_UP( curr_pmr->base_pa + curr_pmr->size, PMR_ALIGNMENT );
   }
}


/* 
   Convert the pmr_t to a valid memory region layout entry
   as would appear in the memory layout file of platform config 
*/
static void 
convert_pmr_to_config_string( char *cfg_buf, pmr_t *pmr )
{
   // Format string for sprintf of pmr
   char *cfg_format = "%s { base_pa = 0x%08X  size = 0x%08X  type = %d name = \"%s\" sta = 0x%08X }" ;

   OS_ASSERT( NULL != cfg_buf );
   OS_ASSERT( NULL != pmr );

   sprintf( cfg_buf, cfg_format, pmr->name, pmr->base_pa, pmr->size, pmr->type, pmr->name, pmr->sta );

   LOCAL_LOG_MSG( 4, "Config Entry: %s\r\n", cfg_buf );
}


/*
  Write the PMR table into the platform config database.
*/    
static config_result_t 
output_pmrs( void )
{
   config_result_t conf_res             = CONFIG_SUCCESS;
   config_ref_t    pmr_info_id          = ROOT_NODE;
   pmr_t *         current              = NULL;
   int             i                    = 0;
   char            pmr_config_str[256];
   
   /* Create a new node in the database to for the PMR entries */
   if ( CONFIG_SUCCESS != (conf_res = config_set_int( ROOT_NODE, CONFIG_PATH_PLATFORM_PMR_INFO, 0 )) ) {
      LOCAL_LOG_MSG( 0, "ERR: could not create config database entry \"%s\"\n", CONFIG_PATH_PLATFORM_PMR_INFO );
   }
   else if ( CONFIG_SUCCESS != (conf_res = config_node_find( ROOT_NODE, CONFIG_PATH_PLATFORM_PMR_INFO, &pmr_info_id )) ) {
      LOCAL_LOG_MSG( 0, "ERR: could not find config database location \"%s\"\n", CONFIG_PATH_PLATFORM_PMR_INFO );
   }
   else {
      /* Write out the 16 PMR entries. */
      for ( i = 0; i < (NUM_PMRS + 1); i++ ) {
         current = &pmrs[i];

         /* Don't write out the "pmr_invalid" entry or empty entries.  */
         if ( (current->type != pmr_invalid) && (current->size != 0) ) {
            LOCAL_LOG_MSG( 4, "Outputting PMR %s: \r\n",current->name );
            OS_MEMSET( pmr_config_str, 0, sizeof( pmr_config_str ) );
            convert_pmr_to_config_string( pmr_config_str, current );
            conf_res = config_load( pmr_info_id, (const char *)pmr_config_str, strlen(pmr_config_str) );
            if( CONFIG_SUCCESS != conf_res )
            {
               LOCAL_LOG_MSG( 0, "Failed to write PMR config to platform_config. Error %d\n", conf_res );
            }
         }

         current++;
      }
   }
   
   // Report the hidden pmr that contains non-pmr physical address range
   LOCAL_LOG_MSG( 4, "\nAdresses that do not fall into any PMR: \n" );
   LOCAL_LOG_MSG( 4, " base physical address   = 0x%08X\n", pmrs[16].base_pa );
   LOCAL_LOG_MSG( 4, "                  size   = 0x%08X\n", pmrs[16].size );
   
   return conf_res;
}



// CODE to be integrated into SEC
/*
   Retrieve the pmr settings from the platform config tree.
   The size of the pmrs area must be large enough to hold
   a number of pmr_t  structs. The number is SOC specific.
   Currently the number is 16 for CE4100, CE4200 and CE5300.
   The pmrs array will be filled to maximum. Invalid entries
   will contain a type field of  0 and or a size of zero.
   Upon error, the contents of the callers pmr array is unknown
   and security initialization must prevent the system from 
   initializing successfully.
   Returns:
   0  - Protected memory must be disabled.
   1  - Protected memory must be enabled.
   -1 - Error
*/   
int 
get_pmr_info( pmr_t *pmrs )
{
   int retval                 = 0;
   config_result_t config_ret = CONFIG_SUCCESS;   
   config_ref_t    pmr_node   = ROOT_NODE;
   config_ref_t    child_node = ROOT_NODE;

   OS_ASSERT( NULL != pmrs );
   
   LOCAL_LOG_MSG( 2, "\n\nRetrieving PMRs from config path %s.\n",CONFIG_PATH_PLATFORM_PMR_INFO );
   
   config_ret = config_node_find( ROOT_NODE, CONFIG_PATH_PLATFORM_PMR_INFO, &pmr_node );
   if ( CONFIG_SUCCESS == config_ret )
   {
      int i = 0;
      unsigned int pmr_base_pa = 0;
      unsigned int pmr_size = 0;
      int          pmr_type = 0;
      unsigned int pmr_sta = 0;
      char         pmr_name[MAX_LAYOUT_NAME_SZ];
      pmr_t *pmrbuf = &pmrs[0];

      config_ret = config_node_first_child( pmr_node, &child_node );

      for ( i = 0; (config_ret == CONFIG_SUCCESS) && (i < NUM_PMRS); i++ )
      {

         config_ret = config_node_get_name( child_node, pmr_name, sizeof(pmr_name) );
         if( CONFIG_SUCCESS != config_ret )
         {
            LOCAL_LOG_MSG( 0, "Failed to find the name of this PMR.\n" );
            retval = -1;
            break;
         }

         config_ret = config_get_int( child_node, "base_pa", (int *)&pmr_base_pa );
         if ( CONFIG_SUCCESS != config_ret )
         {
            LOCAL_LOG_MSG( 0, "Failed to find the starting physical address of this PMR.\n" );
            retval = -1;
            break;
         }

         config_ret = config_get_int( child_node, "size", (int *)&pmr_size );
         if ( CONFIG_SUCCESS != config_ret )
         {
            LOCAL_LOG_MSG( 0, "Failed to find the size of this PMR.\n" );
            retval = -1;
            break;
         }

         config_ret = config_get_int( child_node, "type", (int *)&pmr_type );
         if ( CONFIG_SUCCESS != config_ret )
         {
            LOCAL_LOG_MSG( 0, "Failed to find the type of this PMR.\n" );
            retval = -1;
            break;
         }

         config_ret = config_get_int( child_node, "sta", (int *)&pmr_sta );
         if ( CONFIG_SUCCESS != config_ret )
         {
            LOCAL_LOG_MSG( 0, "Failed to find the pmr_sta of this PMR.\n" );
            retval = -1;
            break;
         }

         pmrbuf->base_pa = pmr_base_pa;
         pmrbuf->size    = pmr_size;
         pmrbuf->type    = pmr_type;
         pmrbuf->sta     = pmr_sta;
         strcpy( pmrbuf->name, pmr_name );

         LOCAL_LOG_MSG( 3, "\nPMR entry %s\n", pmr_name );
         LOCAL_LOG_MSG( 3, " base_pa = 0x%08X\n", pmrbuf->base_pa );
         LOCAL_LOG_MSG( 3, "    size = 0x%08X\n", pmrbuf->size );
         LOCAL_LOG_MSG( 3, "    type = %2d\n",    pmrbuf->type );
         LOCAL_LOG_MSG( 3, "     sta = 0x%08X\n", pmrbuf->sta );

         pmrbuf++;

         config_ret = config_node_next_sibling( child_node, &child_node );
      }

      LOCAL_LOG_MSG( 2, "Transferred %d PMR entries.\n", i );

   }

   return ( (retval == 0) ? g_enable_pmr : retval );
}


int 
process_mem_layout( void )
{
   int err              = 0;
   int mem_layout_count = 0;

   get_system_base_addr( &g_media_base_address );

   pmr_process_memory_layout( &mem_layout_count );
   configure_pmrs( mem_layout_count );
   err = output_pmrs();
   if ( err != CONFIG_SUCCESS ) {
      LOCAL_LOG_MSG( 0, "Error writing PMR entries to platform_config: %d\n", err );
   }

   else if ( verbosity_level >= 3 ) {
      pmr_t pmrs2[16];
      get_pmr_info( pmrs2 );
   }

   return err;
}


/* Print the command-line help instructions. */
void 
usage( char *app_name ) 
{
   LOCAL_LOG_MSG( 0, "\n"  );
   LOCAL_LOG_MSG( 0, "Usage:  %s [options]\n", app_name );
   LOCAL_LOG_MSG( 0, "\tOptions:\n"  );
   LOCAL_LOG_MSG( 0, "\t  -v=N : set verbosity level to N\n" );
   LOCAL_LOG_MSG( 0, "\t         0 <= N <= 4, default is 0\n" );
   LOCAL_LOG_MSG( 0, "\n"  );

   exit( -1 );
}


/* Super simplified command-line parsing. */
void 
parse_command_line_args( int    argc, 
                         char **argv )
{
   /* No options. */
   if ( argc < 2 ) {
      return;
   }

   /* Too many options. */
   else if ( argc > 2 ) {
      usage( argv[0] );
   }

   /* option "-v=N" */
   else if ( (argv[1][0] == '-') && 
             (argv[1][1] == 'v') && 
             (argv[1][2] == '=') ) {
      verbosity_level = atoi( &(argv[1][3]) );
      if ( (verbosity_level < 0) || 
           (verbosity_level > 4) ) {
         usage( argv[0] );
      }
   }
   else {
      usage( argv[0] );
   }
}


int 
main( int    argc, 
      char **argv )
{
   parse_command_line_args( argc, argv );

   if ( determine_pmr_mode() == DISABLE_PMR ) {
      LOCAL_LOG_MSG( 0, "PMRs not enabled.\n" );
   }
   else {
      process_mem_layout();
      LOCAL_LOG_MSG( 0, "Created PMRs from memory layout.\n" );
   }

   return 0;
}


