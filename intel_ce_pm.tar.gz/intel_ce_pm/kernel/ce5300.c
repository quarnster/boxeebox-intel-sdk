//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE
//
// Copyright(c) 2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   - Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
//                     POWER MANAGEMENT FOR CE5300
//------------------------------------------------------------------------------
#include <linux/string.h>

#include "osal.h"

#include "icepm_internal.h"
#include "interface.h"
#include "kernel.h"

#ifndef __BIT
#define __BIT(x) (1<<x)
#endif

//==============================================================================
//          P C I   V E N D O R   A N D   D E V I C E   I D s 
//==============================================================================

#define VENDOR_ID_INTEL 0x8086

// Single entry in a Linux PCI device ID table for an Intel device
#define iDEVICE(DEV_ID)    { PCI_DEVICE(VENDOR_ID_INTEL, DEV_ID)  }

// Linux Device ID table for a single Intel device.
#define iDEVICE_TABLE(DRIVER_NAME, DEV_ID) \
                static struct pci_device_id DRIVER_NAME##_idtab[] = \
                { \
                    iDEVICE(DEV_ID), \
                    { 0 } \
                };

static struct pci_device_id audio_idtab[] =
{
    iDEVICE(0x2E5F),   // AUDIO DSP 0/1
    iDEVICE(0x2E60),   // AUDIO IF
    { 0 }
};

// TODO:  audio_dac driver
//          and add it to CE4200 too for completeness

iDEVICE_TABLE(eMMC       , 0x070B)
iDEVICE_TABLE(epu        , 0x089C)
iDEVICE_TABLE(graphics   , 0x089B)
iDEVICE_TABLE(graphics_2D, 0x070A)
iDEVICE_TABLE(hdmi_rx_ce , 0x089E)
iDEVICE_TABLE(iosf       , 0x0C40)
iDEVICE_TABLE(ismdclock  , 0x2E6F)
iDEVICE_TABLE(nexp       , 0x2E65)
// Unlike some CE drivers that control more than one different PCI device, the
// PCIE driver controls 2 independent units of the same type. Separate
// suspend/resume calls are required for both.
iDEVICE_TABLE(pcie1      , 0x0101) // PCIe 1
iDEVICE_TABLE(pcie2      , 0x0202) // PCIe 2

iDEVICE_TABLE(picuart    , 0x070C)
iDEVICE_TABLE(pwm        , 0x089f)
iDEVICE_TABLE(sec        , 0x2E64)
iDEVICE_TABLE(tsd2       , 0x0705)
iDEVICE_TABLE(tsout      , 0x2E5D)
iDEVICE_TABLE(vidcap     , 0x0704)
iDEVICE_TABLE(vidpproc   , 0x2E62)
iDEVICE_TABLE(sata       , 0x2E71)

// Not an Intel device!
static struct pci_device_id usb_idtab[] =
{
    { PCI_DEVICE(0x192E, 0x0101)  },   // USB 0/1, 2/3
    { 0 }
};

//-----------------------------------------------------------------------------
// The relationship of the viddec/videnc/mux drivers is a bit ugly. On CE5300,
// - mux    relies on FW on GVsparcT (device 0x0703)
// - videnc relies on FW on GVsparcT (device 0x0703) + HW on device 0x0706
// - viddec relies on FW on GVsparcD+HW on device 0x089D
// 
// These are renamings and reassignments of devices from CE4200, and more than
// one driver is dependent on 0x0703.  We must register all 3 drivers so
// they'll all be invoked during STR.  So we pick only one device for videnc,
// and we pick it such that it doesn't conflict with mux.
// 
// The drivers themselves rely on a lower layer of SW (CES) to route their work
// transparently to the correct FW, and to unload FW only when all dependent
// drivers are suspended.
//-----------------------------------------------------------------------------

iDEVICE_TABLE(mux,    0x0703)   // MFD vsparc
iDEVICE_TABLE(viddec, 0x089D)   // GVSPARC   
iDEVICE_TABLE(videnc, 0x0706)   // H264 encoder


//==============================================================================
//        C L O C K   C O N T R O L   R E S O U R C E S
//==============================================================================

// Resources controlled through the clock_control component used to gate/reset
// the devices controlled by each driver.
//
// ORDER MATTERS: enabling/disabling are done in the order listed.

static clock_res_t adv7850_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t audio_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t eMMC_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t display_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t epu_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t graphics_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t graphics_2D_clocks[] =
{
    // TODO
    { NULL }
};
static clock_res_t hdmi_rx_ce_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t heron_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t iosf_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t ismdclock_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t mux_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t nexp_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t pcie1_clocks[] =
{
    { NULL } // Clocks are those of PCIE2, will be handled by that driver
};

static clock_res_t pcie2_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t picuart_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t pwm_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t sata_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t sec_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t sii9135_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t tsd2_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t tsout_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t tunerAPI_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t usb_clocks[] =
{ 
    // TODO
    { NULL }
};

static clock_res_t vidcap_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t viddec_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t videnc_clocks[] =
{
    // TODO
    { NULL }
};

static clock_res_t vidpproc_clocks[] =
{
    // TODO
    { NULL }
};

//==============================================================================
//  S U P P O R T E D   D R I V E R S   &   A C T I V E   P O W E R   M O D E S
//==============================================================================

// Dummy driver remove/probe functions referenced by DECL_DRIVER macro
static void drv_remove(struct pci_dev * dev)
{
    return;
}
static int drv_probe(struct pci_dev * dev, const struct pci_device_id *id)
{
    return 0;
}

// Declare/intialize pci_driver structures used to register CE drivers with
// Linux PCI device model and driver_t structures used by us to drive mode
// changes.
DECL_PCI_DRIVER(audio      , DRV_CE )   // pci_drv_audio,      drv_audio
DECL_PCI_DRIVER(eMMC       , 0      )   // pci_drv_eMMC,       drv_eMMC
DECL_PCI_DRIVER(epu        , DRV_CE )   // pci_drv_epu,        drv_epu
DECL_PCI_DRIVER(graphics   , DRV_CE )   // pci_drv_graphics,   drv_graphics
DECL_PCI_DRIVER(graphics_2D, DRV_CE )   // pci_drv_graphics_2D,drv_graphics_2D
DECL_PCI_DRIVER(hdmi_rx_ce , DRV_CE )   // pci_drv_hdmi_rx_ce, drv_hdmi_rx_ce
DECL_PCI_DRIVER(iosf       , 0      )   // pci_drv_iosf,       drv_iosf
DECL_PCI_DRIVER(ismdclock  , DRV_CE )   // pci_drv_ismdclock,  drv_ismdclock
DECL_PCI_DRIVER(mux        , DRV_CE )   // pci_drv_mux,        drv_mux,
DECL_PCI_DRIVER(nexp       , DRV_CE )   // pci_drv_nexp,       drv_nexp TODO: Linux driver?
DECL_PCI_DRIVER(pcie1      , 0      )   // pci_drv_pcie1,      drv_pcie1
DECL_PCI_DRIVER(pcie2      , 0      )   // pci_drv_pcie2,      drv_pcie2
DECL_PCI_DRIVER(picuart    , DRV_CE )   // pci_drv_picuart,    drv_picuart
DECL_PCI_DRIVER(pwm        , 0      )   // pci_drv_pwm,        drv_pwm
DECL_PCI_DRIVER(sata       , 0      )   // pci_drv_sata,       drv_sata
DECL_PCI_DRIVER(sec        , DRV_CE )   // pci_drv_sec,        drv_sec
DECL_PCI_DRIVER(tsd2       , DRV_CE )   // pci_drv_tsd2,       drv_tsd2
DECL_PCI_DRIVER(tsout      , DRV_CE )   // pci_drv_tsout,      drv_tsout
DECL_PCI_DRIVER(usb        , 0      )   // pci_drv_usb,        drv_usb
DECL_PCI_DRIVER(vidcap     , DRV_CE )   // pci_drv_vidcap,     drv_vidcap
DECL_PCI_DRIVER(viddec     , DRV_CE )   // pci_drv_viddec,     drv_viddec
DECL_PCI_DRIVER(videnc     , DRV_CE )   // pci_drv_videnc,     drv_videnc,
DECL_PCI_DRIVER(vidpproc   , DRV_CE )   // pci_drv_vidpproc,   drv_vidpproc

DECL_USERSPACE_DRIVER(display)          // pci_drv_display,    drv_display
DECL_USERSPACE_DRIVER(adv7850)          // pci_drv_adv7850,    drv_adv7850
DECL_USERSPACE_DRIVER(heron)            // pci_drv_heron,      drv_heron
DECL_USERSPACE_DRIVER(sii9135)          // pci_drv_sii9135,    drv_sii9135
DECL_USERSPACE_DRIVER(tunerAPI)         // pci_drv_tunerAPI,   drv_tunerAPI

// MODE_ON is defined in kernel.h
// TODO: add active power modes
#define  MODE_EOL      -1

typedef struct
{
    int         id;         // Mode number
    driver_t ** drivers;    // NULL-terminated array of affected drivers
    uint32_t    ssc;        // Value to be written to the PUnit's PM_SSC
                            //    register to enter this power state  
} pwrmode_t;

#ifdef TEST /******************************* TEST *****************************/

#define DRIVERS \
    &drv_graphics, \
    &drv_audio, \
    &drv_vidpproc, \
    &drv_viddec, \
    &drv_display

static driver_t * standby3_drivers[] =
{
    DRIVERS,
    NULL                // End of list
};

// NULL-terminated list of pointers to all supported drivers
static driver_t *all_drivers[] =
{
    DRIVERS,
    NULL                // End of list
};


static pwrmode_t modes[] =
{
    { MODE_ON,       all_drivers,      0                           },
    { MODE_EOL }    // EOL
};

#else /******************************** not TEST *****************************/


// ORDER MATTERS: drivers are suspended in order shown, resumed in reverse order
// NOTE: PCIe2 controls the clocking and reset; it MUST be listed after PCIe1;
//       This allows it to suspend after PCIe1, and resume before it


// Drivers affected by each standby mode
// Order matters, as described above.

// TODO: add power island tables for active power management?


// List of pointers to all supported drivers.
static driver_t *all_drivers[] =
{
    &drv_tunerAPI,
    &drv_heron,
    &drv_sii9135,
    &drv_adv7850,
    &drv_tsout,
    &drv_tsd2,
    &drv_sec,
    &drv_graphics_2D,
    &drv_graphics,
    &drv_hdmi_rx_ce,
    &drv_vidcap,
    &drv_audio,
    &drv_vidpproc,
    &drv_videnc,
    &drv_mux,
    &drv_viddec,
    &drv_display,
    &drv_pcie1,
    &drv_pcie2,
    &drv_eMMC,
    &drv_sata,
    &drv_usb,
    &drv_ismdclock,
    &drv_picuart,
    &drv_epu,
    &drv_nexp,
    &drv_pwm,
    &drv_iosf,
    NULL                // End of list
};


static pwrmode_t modes[] =
{
    { MODE_ON,       all_drivers,      0                           },
    { MODE_EOL }    // EOL
};

#endif /***********************************************************************/



//==============================================================================
//                  P U N I T   A C C E S S 
//==============================================================================

// P-Unit PCI device ID (vendor ID is VENDOR_ID_INTEL)
#define PUNIT_DEVICE_ID     0x070C

// Offset of BAR for PUnit "OSPM" register block in PUnit PCI config space.
// (offset PCI_OSPM_BAR_OFFSET from start of config space).
#define PCI_OSPM_BAR_OFFSET 0x14

// Value of the OSPM register block BAR read from PCI config space.  This is 
// a base I/O port number; OSPM block registers are accessed with "inl" and
// "outl" instructions at offsets relative to this I/O port.
static unsigned int    punit_ospm_bar;  

// P-Unit PCI revision ID, read from PCI config space.
static unsigned char   punit_revision;

// I/O ports used to access registers in the PUnit "OSPM" register block.
#define PM_STS  (punit_ospm_bar+0x00)
#define PM_CMD  (punit_ospm_bar+0x04)
#define PM_ICS  (punit_ospm_bar+0x08)
#define WAKESM  (punit_ospm_bar+0x10)
#define PM_SSC  (punit_ospm_bar+0x20)
#define PM_SSS  (punit_ospm_bar+0x30)


// Write a 32-bit value to a P-Unit register in I/O space
static __inline__
void pwrite(uint16_t reg, uint32_t val)
{
    asm("outl %%eax, %%dx"
        : // no output
        : "a"(val), "d"(reg)
        );
}

// Read a 32-bit value from a P-Unit register in I/O space
static __inline__
uint32_t pread(uint16_t reg)
{
    uint32_t ret;

    asm("inl %%dx, %%eax"
        : "=a"(ret)
        : "d"(reg)
        );

    return ret;
}


#ifdef TEST /******************************* TEST *****************************/
static void punit_mode(uint32_t ssc)
{
    PWR_DEBUG("Set power island config to 0x%08x\n", ssc);
}

static icepm_ret_t punit_init(void)
{
    return ICEPM_OK;
}

#else /******************************** not TEST *****************************/

// ssc: Value to be written to the PUnit's PM_SSC register
static
void punit_mode(uint32_t ssc)
{
    static uint32_t transaction_number = 0;
    uint32_t        reg;

    PWR_DEBUG("Set power island config to 0x%08x\n", ssc);

    // Clear and disable interrupts
    reg = pread(PM_ICS);
    reg &= 0xffffffcf;                  // Clear interrupt pending/enabled bits
    pwrite(PM_ICS, reg);

    // Clear all event status and mask off all future events
    //reg = pread(WAKESM);
    //reg &= __BIT(30)|__BIT(29)|__BIT(26)|__BIT(24)|__BIT(14)|__BIT(13)|__BIT(10)|__BIT(8);
                            // Preserve reserved bits, clear all others.
    //reg |= 0x9aff0000;      // Mask off all wake events
    //pwrite(WAKESM, reg);

    // Specify desired island configuration
    reg = pread(PM_SSC);
    reg &= 0xfffff003;                  // Preserve reserved bits
    reg |= ssc;                         // Set bits for island enable/disable
    pwrite(PM_SSC, reg);

    // Send command to PUnit
    reg = pread(PM_CMD);
    reg &= 0xfe000000;                  // Preserve reserved bits
    reg |= transaction_number << 21;    // Set cookie
    reg |= (1<<9) | __BIT(0);             // "Set config" command, IMMEDIATE mode
    pwrite(PM_CMD, reg);

    // Wait for command completion (TODO: interrupt-driven version?)
    do
    {
        reg = pread(PM_STS);
    } while ((reg & __BIT(8))                              // Punit still busy
    ||       (((reg >> 9) & 0xf) != transaction_number));// Didn't start yet?

    // Roll transaction number
    if (++transaction_number >= 16)
    {
        transaction_number = 0;
    }

    PWR_DEBUG("Completed setting power mode\n");
}


static
icepm_ret_t punit_init(void)
{
    icepm_ret_t     ret = ICEPM_ERR_INTERNAL;
    os_pci_dev_t    dev;
    unsigned        irq_num;

    // Enable pci device.
    // - Required in HyperThreading enabled environment in order for
    //   os_pci_get_interrupt() to get correct irq number.
    // - Does not affect non-HT environment.
    os_pci_enable_device(VENDOR_ID_INTEL, PUNIT_DEVICE_ID);


    // Access PUnit PCI config space and extract OSPM BAR, PCI revision ID,
    // and PUnit interrupt number.

    if (OSAL_SUCCESS != OS_PCI_FIND_FIRST_DEVICE(   VENDOR_ID_INTEL,
                                                    PUNIT_DEVICE_ID,
                                                    &dev))
    {
        PWR_ERROR("OS_PCI_FIND_FIRST_DEVICE failed\n");
        goto end;
    }

    if (OSAL_SUCCESS != OS_PCI_READ_CONFIG_32(  dev,
                                                PCI_OSPM_BAR_OFFSET,
                                                &punit_ospm_bar))
    {
        PWR_ERROR("OS_PCI_READ_CONFIG_32 failed\n");
        goto free_dev;
    }

    /* Low order bits are hardwired / reserved and need to be masked off */
    punit_ospm_bar &= 0x0000FFFC;


    if (OSAL_SUCCESS != OS_PCI_READ_CONFIG_8(dev, 8, &punit_revision))
    {
        PWR_ERROR("OS_PCI_READ_CONFIG_8 failed\n");
        goto free_dev;
    }

    os_pci_get_interrupt(dev, &irq_num); 

    PWR_DEBUG("**** bar=%u rev=0x%02x irq_num=%u\n",
              punit_ospm_bar,
              punit_revision & 0xff,
              irq_num);

    /* TODO -- interrupt-driven version?
    // Install interrupt handler; uninstall on shutdown
    if (request_irq(irq_num,
                    int_handler,
                    IRQF_DISABLED | IRQF_SHARED,
                    "Intel CE Power Mgmt",
                    &irq_dev))
    {
        PWR_ERROR("request_irq(%u) failed\n", irq_num);
        ret = ICEPM_ERR_FAILED;
        goto EXIT;
    }
    */

    ret = ICEPM_OK;

free_dev:
    OS_PCI_FREE_DEVICE(dev);
end:
    return ret;
}

#endif /*******************************************************************/

//=============================================================================
//   E X P O R T E D   V I A   S O C - S P E C I F I C   V E C T O R
//=============================================================================

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
static
icepm_ret_t set_mode(int mode_number)
{
    pwrmode_t * mode;
    icepm_ret_t ret         = ICEPM_OK;

    PWR_DEBUG("Enter mode '%d':\n", mode_number);

    // Look up power mode
    for (mode=modes; mode->id != mode_number ; mode++)
    {
        if (mode->id == MODE_EOL)
        {
            PWR_ERROR("Undefined power mode: %d\n", mode_number);
            ret = ICEPM_ERR_UNKNOWN_MODE;
            goto exit;
        }
    }

    // It is invalid for CE4200 to transition from one standby mode to another:
    // standby modes must always transition to ON.  Therefore we should always
    // be either entering or exiting "ON" state.
    // NOTE that the strcmp()s here are checking for names that are NOT 'ON'.
    if ((current_mode != MODE_ON) && (mode_number != MODE_ON))
    {
        ret = ICEPM_ERR_INVALID_TRANSITION;
        goto exit;
    }

    // Turn islands on BEFORE resuming drivers, but after suspending them
    if (mode_number == MODE_ON)
    {
        punit_mode(mode->ssc);
        ret = resume_all_drivers(mode->drivers);
    }
    else if ( ICEPM_OK == (ret = suspend_all_drivers(mode->drivers)) )
    {
        punit_mode(mode->ssc);
    }
exit:
    return ret;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

//  Exported vector
static vector_t functions = { all_drivers, set_mode };

//  No-op version of function vector, returned for unsupported steppings
//static driver_t *   drivers_nop[] = { NULL };
//static icepm_ret_t  set_mode_nop(int mode_num)   { return ICEPM_OK; }

//static vector_t     nops= { drivers_nop, set_mode_nop };


//=============================================================================
//                      E N T R Y   P O I N T
//=============================================================================

//-----------------------------------------------------------------------------
// ce5300_init
// Returns 0 on success, 1 on error
//-----------------------------------------------------------------------------
vector_t * ce5300_init(pal_soc_info_t *soc_info)
{
    vector_t *  ret     = NULL;    // Default to failure return
    driver_t ** drv_list;

    punit_init();

    for (drv_list = all_drivers; *drv_list != NULL; drv_list++)
    {
        driver_t *drv = *drv_list;

        // TODO: Extend for non-PCI kernel drivers?
        if ( IS_PCI(drv) )
        {
            drv->pci_dev = pci_get_device(  drv->pci_id[0].vendor,
                                            drv->pci_id[0].device,
                                            NULL);
            if (drv->pci_dev == NULL)
            {
                PWR_WARN("***PCI device 0x%04x:0x%04x not found\n",
                          drv->pci_id[0].vendor,
                          drv->pci_id[0].device);
            }
        }
    }

    current_mode = MODE_ON;
    ret = &functions;

#ifdef DEBUG
    {
        driver_t  **d;

        for (d=all_drivers; *d != NULL; d++)
        {
            clock_res_t  *clk;
            driver_t     *drv = *d;

            PWR_PRINT("DRIVER '%s':\n", drv->name);
            for (clk = drv->clocks; clk->name; clk++)
            {
                PWR_PRINT("     %s\n", clk->name );
            }
        }
    }
#endif /* DEBUG */
    return ret;
}
