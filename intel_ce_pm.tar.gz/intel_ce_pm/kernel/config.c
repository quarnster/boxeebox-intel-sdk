//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2009-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE
//
// Copyright(c) 2009-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   - Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

#ifdef __KERNEL__
    #include <linux/string.h>
#else
    #include <string.h>
#endif

#include "osal.h"
#include "platform_config.h"

#include "icepm_internal.h"

typedef struct
{
    char *  mode_name;
    int     mode_number;
} pwr_mode_t;

pwr_mode_t *modes = NULL;


//=============================================================================
//             CONFIG FILE PARSING AND DATA STRUCTURE CREATION
//=============================================================================

//-----------------------------------------------------------------------------
// get_node_name
//
// Allocate memory for a copy of the name of the specified config file node.
//
// Return a pointer to the copy on succeess, NULL on failure.
//-----------------------------------------------------------------------------
static
char * get_node_name(config_ref_t node)
{
    int             buf_len = 10;
    char *          buf;
    config_result_t ret;


    while (1)
    {
        buf = OS_ALLOC(buf_len);
        if ( buf == NULL )
        {
            PWR_ERROR("memory allocation failed\n");
            break;
        }

        // If the buffer is too short, config_node_get_name() just truncates the
        // returned name before 0-terminating it, with no indication that
        // anything was lost. Unless the length of the returned string is less
        // than the size of the buffer we passed, we can't know that we got the
        // entire string. So we call it repeatedly, with a larger buffer each
        // time, until that condition is met.
        ret = config_node_get_name(node, buf, buf_len);
        if (ret != CONFIG_SUCCESS)
        {
            PWR_ERROR("config_node_get_name failed (%d)\n", ret);
            OS_FREE(buf);
            buf = NULL;
            break;
        }

        buf[buf_len-1] = '\0';
        if (strlen(buf) < buf_len - 1)
        {
            // Got the full name
            break;
        }

        // Allocate a larger buffer
        OS_FREE(buf);
        buf_len += 10;
    }

    return buf;
}

//-----------------------------------------------------------------------------
// count_children
//
// Return count of number of entries below specified node of config file.
//-----------------------------------------------------------------------------
static
int count_children(config_ref_t base)
{
    config_ref_t    node;
    int             count = 0;

    if (CONFIG_SUCCESS == config_node_first_child(base, &node))
    {
        count++;
        while ( CONFIG_SUCCESS == config_node_next_sibling(node, &node))
        {
            count++;
        }
    }

    return count;
}

//=============================================================================
// Return the power mode number that was assigned to the specified mode name
// in the platform_config file.
//
// Return -1 if name not found.
//=============================================================================
int get_mode_number(char *name)
{
    pwr_mode_t *m;
    int         mode_num = -1;
    
    if ( modes != NULL )
    {
        for (m=modes; m->mode_name != NULL; m++)
        {
            if (!strcmp(m->mode_name, name))
            {
                mode_num = m->mode_number;
                break;
            }
        }
    }

    return mode_num;
}


//=============================================================================
// Free memory allocated for config file info. 
//=============================================================================
void free_config(void)
{
    pwr_mode_t *m;
    
    if ( modes )
    {
        for (m=modes; m->mode_name != NULL; m++)
        {
            OS_FREE(m->mode_name);
        }
        OS_FREE(modes);
        modes = NULL;
    }
}


//=============================================================================
// Read power modes from platform_config file.  Example entry defining power
// modes:
//
//      power {
//          modes {
//              ON = 1
//              STANDBY = 0
//          }
//      }
//
// Return 0 on success, 1 on failure
//=============================================================================
int read_config(void)
{
    int             n;
    config_ref_t    modes_root_node;
    config_ref_t    node;
    config_result_t cfg_ret;
    pwr_mode_t *    mode;
    int             rc      = 1;    // Assume failure


    // Open power management modes node in config file.
    cfg_ret = config_node_find(ROOT_NODE, MODEPATH, &modes_root_node);
    if (cfg_ret != CONFIG_SUCCESS)
    {
        PWR_ERROR("Can't find %s in config file (%d)\n", MODEPATH, cfg_ret);
        goto exit;
    }

    // Determine number of modes defined in the node
    n = count_children(modes_root_node);

    if (n == 0)
    {
        PWR_ERROR("No power modes defined in platform config file\n");
        goto exit;
    }

    // Allocate and clear memory for mode descriptors.
    //
    // Allocate an extra descriptor for list terminator. The mode_name pointer
    // in the last entry will be left NULL to inidicate EOL
    if (NULL == (modes = OS_ALLOC((n+1) * sizeof(pwr_mode_t))))
    {
        PWR_ERROR("No memory for power modes\n");
        goto exit;
    }

    OS_MEMSET(modes, 0, (n+1) * sizeof(pwr_mode_t));

    // Iterate through config file nodes, adding each power mode to our data
    // structure,
    
    for ( mode = modes, cfg_ret=config_node_first_child(modes_root_node, &node);
          cfg_ret == CONFIG_SUCCESS;
          mode++,       cfg_ret = config_node_next_sibling(node, &node)
        )
    {
        // Copy the config file node name as the name of the mode.
        mode->mode_name = get_node_name(node);
        if (mode->mode_name == NULL)
        {
            goto exit;
        }

        cfg_ret = config_node_get_int( node, &mode->mode_number );
        if (cfg_ret != CONFIG_SUCCESS)
        {
            PWR_ERROR("config_node_get_int failed (%d)\n", cfg_ret);
            goto exit;
        }
    }

    rc = 0; // Success
exit:
#ifdef DEBUG
    if (modes != NULL)
    {
        for (mode=modes; mode->mode_name != NULL; mode++)
        {
            PWR_DEBUG("%s = %d\n", mode->mode_name, mode->mode_number);
        }
    }
#endif
    return rc;
}
