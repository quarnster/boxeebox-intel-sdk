//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2009-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE
//
// Copyright(c) 2009-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   - Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

//----------------------------------------------------------------------------
// Internal header file to be included by all files in kernel module.
//----------------------------------------------------------------------------

#ifndef _COMMON_H_
#define _COMMON_H_

#include <linux/pci.h>
#include <linux/types.h>    // For pid_t

#include "pal.h"
#include "osal.h"
#include "clock_control.h"

#include "intel_ce_pm.h"
#include "interface.h"

extern int current_mode;

// Description of a resource (gating clock or reset line) accessed via the
// clock control component.
typedef struct
{
    char            *   name;   // Resource name, as ASCII string
    clock_control_resource_t
                        res;    // Resource name, as passed to clock control
    bool                is_reset;
                                // true iff this is a reset control, not a clock
                                //      control
    unsigned            enable; // Bit field value that enables resource
    unsigned            gate;   // Bit field value that disables resource
} clock_res_t;

// Initializer macros for a clock_ret_t
#define CLOCK(name, enable, gate) { #name, CLOCK_##name, false, enable, gate }
#define RESET(name, enable, gate) { #name, CLOCK_##name, true,  enable, gate }

typedef enum
{
    DRV_SUSPENDED   = (1<<0),   // 1: driver is suspended
                                // 0: driver is active

    DRV_RESET       = (1<<2),   // 1: device(s) in reset state, clocks gated
                                // 0: device(s) out of reset, clocks enabled

    DRV_USERSPACE   = (1<<4),   // 1: driver resides in user space
                                // 0: driver resides in kernel space

    DRV_PCI         = (1<<3),   // MEANINGLESS (ignored) FOR USERSPACE DRIVERS
                                // 1: this is a PCI driver
                                // 0: this is NOT a PCI driver

    DRV_CE          = (1<<5),   // 1: this is an Intel CE driver
                                // 1: this is a standard Linux driver
} drv_flags_t;


// TODO: break into base class and subclasses?
typedef struct
{
    char *              name;   // Name of driver/device
    unsigned            flags;
    clock_res_t       * clocks; // Device gating clocks and reset lines

    // Kernel PCI driver
    struct pci_device_id *pci_id;
                                // List of PCI vender/revision IDs of PCI
                                //   devices controlled by this driver
    struct pci_dev    * pci_dev;// PCI device structure retrieved from kernel
                                //    using the first entry on the driver's
                                //    pci_id list
    struct pci_driver * pci_drv;// PCI driver structure passed to the kernel to
                                //    register drivers for supported devices

    // User space driver
    pid_t               pid;    // Process ID. Non-zero iff the user space
                                //    driver has registered.
    os_event_t          waitq;  // User-space driver blocked on this while
                                //    waiting for suspend/resume notification
    uint32_t            rc;     // Completion code returned by driver in
                                //    response to suspend/resume notification.
                                //    0 => success, non-zero => failure.
} driver_t;

#define IS_SUSPENDED(drv)       ((drv->flags) & DRV_SUSPENDED)
#define IS_RESET(drv)           ((drv->flags) & DRV_RESET)
#define IS_PCI(drv)             ((drv->flags) & DRV_PCI)
#define IS_USERSPACE(drv)       ((drv->flags) & DRV_USERSPACE)
#define IS_CE(drv)              ((drv->flags) & DRV_CE)

#define MARK_SUSPENDED(drv)     (drv)->flags |= DRV_SUSPENDED
#define MARK_NOT_SUSPENDED(drv) (drv)->flags &= ~DRV_SUSPENDED

#define MARK_RESET(drv)         (drv)->flags |= DRV_RESET
#define MARK_NOT_RESET(drv)     (drv)->flags &= ~DRV_RESET

//=============================================================================
// Initialize pci_driver structures used to register CE drivers with the kernel,
// and driver_t structures to track drivers within our code.
//=============================================================================

#define DECL_PCI_DRIVER(NAME, FLAGS)            \
    static struct pci_driver pci_drv_##NAME =   \
{                                               \
        .name     = #NAME,                      \
        .id_table = NAME##_idtab,               \
        .suspend  = NULL,                       \
        .resume   = NULL,                       \
        .probe    = drv_probe,                  \
        .remove   = drv_remove                  \
    };                                          \
    static driver_t drv_##NAME =                \
    {                                           \
        .name     = #NAME,                      \
        .flags    = DRV_PCI | FLAGS,            \
        .clocks   = NAME##_clocks,              \
        .pid      = 0,                          \
        .pci_id   = NAME##_idtab,               \
        .pci_dev  = NULL,                       \
        .pci_drv  = &pci_drv_##NAME             \
    };

#define DECL_USERSPACE_DRIVER(NAME)             \
    static driver_t drv_##NAME =                \
    {                                           \
        .name     = #NAME,                      \
        .flags    = DRV_USERSPACE,              \
        .clocks   = NAME##_clocks,              \
        .pid      = 0,                          \
        .rc       = 0,                          \
    };

//=============================================================================
// Vector exported by the SOC-specific init() code
//=============================================================================
typedef struct
{
    driver_t **  drivers;        // NULL-terminated list of all drivers
    icepm_ret_t (*set_mode) (int mode_num);
} vector_t;

//==============================================================================
//          P O W E R   M O D E S
//==============================================================================
#define MODE_ON     0

//==============================================================================
// External functions
//==============================================================================
vector_t *  ce3100_4100_init(pal_soc_info_t *soc_info);
vector_t *  ce4200_init     (pal_soc_info_t *soc_info);
vector_t *  ce5300_init     (pal_soc_info_t *soc_info);

void        drv_error       (char *msg, driver_t *drv);
bool        valid_driver    (driver_t * drv);

icepm_ret_t suspend_ce_drivers  (driver_t **drv_list);
icepm_ret_t suspend_all_drivers (driver_t **drv_list);
icepm_ret_t resume_ce_drivers   (driver_t **drv_list);
icepm_ret_t resume_all_drivers  (driver_t **drv_list);


// platform_config file
int  read_config(void);
void free_config(void);
int  get_mode_number(char *name);

#endif // _COMMON_H_
