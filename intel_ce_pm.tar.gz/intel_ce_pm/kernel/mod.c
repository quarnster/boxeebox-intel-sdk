//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2009-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE
//
// Copyright(c) 2009-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   - Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

#include <linux/version.h>
#include <linux/moduleparam.h>
#include <asm/uaccess.h>
#include <linux/fs.h>               // Needed by unlocked ioctl
#include <linux/errno.h>
#include <linux/pci.h>
#include <linux/pci-intelce_pm.h>
            // Contains Intel CE kernel patches for functions:
            //      intel_pm_register_callback()
            //      suspend_devices_rooted()
            //      int resume_devices_rooted()
#include <linux/string.h>
#include <linux/suspend.h>          // For suspend/hibernate notifiers

#include "osal.h"
#include "clock_control.h"

#include "icepm_internal.h"
#include "interface.h"
#include "kernel.h"

MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("Intel Corporation, (C) 2009-2011 - All Rights Reserved");

#define MOD_NAME "intel_ce_pm"

// Shorthand to do a blocking write of a clock_control (cp_top) resource

#ifdef TEST
    #define CCW(_clock_,_value_) CLOCK_RET_OK
#else
    #define CCW(_clock_,_value_) clock_control_write(_clock_,_value_,CLOCK_TRUE)
#endif

static os_lock_t        cmd_mutex   = NULL;
static int              major_number= -1;
static vector_t *       soc;
static os_event_t       wait_for_user_space;
static icepm_event_t    g_event;


static int enable(driver_t *drv);
static int disable(driver_t *drv);

// Support for backing out driver suspensions if a driver in a list fails to
// suspend.  This dynamically-allocated array has the same number of entries
// as soc->drivers, for worst-case handling.  It is filled with pointers to
// drivers as they are successfully suspended.
//
// We need this array even though drivers are marked as suspended or resumed,
// because we don't want to resume any drivers that already suspended before
// this operation started. E.g., if power island 3 is already off and the
// current operation is to turn off power island 2, a suspend failure should
// not resume the drivers on power island 3.
static driver_t **      suspended_drivers = NULL;

#ifdef TEST
static int socname = -1;
static int socstep = -1;
module_param( socname, int, S_IRUGO );
module_param( socstep, int, S_IRUGO );
#endif

// Load-time argument.
//
// By default, failure of any driver to suspend aborts the suspending of a list
//      of drivers, causes already suspended drivers in the list to be resumed,
//      and power transition returns ICEPM_ERR_DEV_BUSY.
//
// If non-zero, remaining drivers are suspended anyway, no suspends are backed
//      out, and power transition returns ICEPM_ERR_INCOMPLETE.  This is mainly
//      good for testing driver suspend/resume when not all drivers are
//      PM-compliant (and will cause abort before the target driver is tested).
static unsigned ignore_suspend_failures = 0;
module_param(ignore_suspend_failures, uint, 0);

// Will be correctly initialized by <soc>_init() function
int current_mode = -1;

//-----------------------------------------------------------------------------
static
icepm_ret_t validate_version( unsigned version_major, unsigned version_minor)
{
    icepm_ret_t ret = ICEPM_OK;

    if ((ICEPM_HEADER_VERSION_MAJOR != version_major)
    ||  (ICEPM_HEADER_VERSION_MINOR  < version_minor))
    {
        PWR_ERROR("\n"
            "libicepm.so incompatible with intel_ce_pm.ko\n"
            "    libicepm header version: %d.%d\n"
            "    intel_ce_pm.ko header version: %d.%d\n",
            ICEPM_HEADER_VERSION_MAJOR, ICEPM_HEADER_VERSION_MINOR,
            version_major, version_minor
            );
        ret = ICEPM_ERR_INCOMPATIBLE;
    }

    return ret;
}


//-----------------------------------------------------------------------------
// get_drv
//
// Return pointer to descriptor for the specified driver.
// Return NULL if driver not defined.
//-----------------------------------------------------------------------------
static
driver_t * get_drv(char *driver_name)
{
    int i;

    for (i=0; soc->drivers[i]; i++)
    {
        if (!strcmp(soc->drivers[i]->name, driver_name))
        {
            break;
        }
    }

    return soc->drivers[i];
}

static
driver_t * get_drv_by_id(unsigned short vendor, unsigned short devid)
{
    int                     i;
    struct pci_device_id *  id;

    for (i=0; soc->drivers[i] != NULL; i++)
    {
        driver_t *drv = soc->drivers[i];

        if ( IS_PCI(drv) )
        {
            for (id = drv->pci_id; id->vendor != 0; id++ )
            {
                if ((id->vendor == vendor) && (id->device == devid))
                {
                    goto found;
                }
            }
        }
    }

found:
    return soc->drivers[i];
}


void drv_error( char *msg, driver_t *drv)
{
    if ( IS_PCI(drv) )
    {
        struct pci_device_id *id = &drv->pci_id[0];
        PWR_ERROR("%s %s (0x%x:0x%x)\n", msg,drv->name, id->vendor, id->device);
    }
    else
    {
        PWR_ERROR( "%s %s\n", msg, drv->name );
    }
}

//==============================================================================
//                 M O D E   C H A N G E  S U P P O R T
//==============================================================================

//-----------------------------------------------------------------------------
// Returns 0 on successful event handling.
//-----------------------------------------------------------------------------
static
int notify_user_space(driver_t *drv, icepm_event_t event)
{
    int ret;
    int ms;

    // Put the event where the blocked user space thread can find it, then
    // wake the thread.
    g_event = event;
    os_event_set(&(drv->waitq));

    // Wait for user thread to signal us back that event was processed.
    // Every 1 ms, check that the user space process is still alive, and
    // return to wait if it is.
    for (ms=0; (OSAL_TIMEOUT == os_event_wait(&wait_for_user_space, 1)); ms++)
    {
        if (drv->pid == 0)
        {
            PWR_DEBUG("Process no longer exists\n");
            ret = 0;
            goto exit;
        }
        if ((ms > 500)
        &&  (ms % 50 == 0))
        {
            PWR_WARN("Waiting %d ms (or so) for user space response\n", ms);
        }
    }

    os_event_reset(&wait_for_user_space);

    ret = drv->rc;
exit:
    return ret;
}


//-----------------------------------------------------------------------------
// Guarantee that all drivers on passed list are in reset state.
//-----------------------------------------------------------------------------
static
void reset_drivers(driver_t **drv_list)
{
    clock_res_t  *  clk;
    int             i;

    for (i=0; drv_list[i] != NULL; i++)
    {
        PWR_DEBUG("    reset(%s)...", drv_list[i]->name);
        for (clk = drv_list[i]->clocks; clk->name != NULL; clk++)
        {
            if ( clk->is_reset)
            {
                PWR_DEBUG(" %s", clk->name);
                if (CLOCK_RET_OK != CCW(clk->res, clk->gate))
                {
                    PWR_ERROR("clock_control_write(%s) failed", clk->name);
                }
            }
        }
        PWR_DEBUG("\n");
    }
}

static
bool is_registered(driver_t *drv)
{
    struct  pci_driver * pci_drv = drv->pci_dev->driver;
    bool    retval;
    
    if ((pci_drv->suspend && pci_drv->resume))
    {
        // Legacy registration
        retval = true;
    }
    else if (pci_drv->driver.pm
    &&       pci_drv->driver.pm->suspend
             && pci_drv->driver.pm->resume)
    {
        retval = true;  
    }
    else
    {
        retval = false;
    }
    return retval;
}


//-----------------------------------------------------------------------------
// Invoke the suspend functions of all drivers on the passed list (or just the
// CE drivers if the passed flag is set).
// 
// If one or more drivers can't be suspended, return an error code but process
// all the other drivers on the list.
//-----------------------------------------------------------------------------
static
icepm_ret_t suspend_drivers(driver_t **drv_list, bool only_ce_drivers)
{
    icepm_ret_t     ret         = ICEPM_OK;
    pm_message_t    pm_message  = { .event = PM_EVENT_SUSPEND };
    int             count       = 0;


    for ( ; *drv_list != NULL; drv_list++)
    {
        driver_t *drv = *drv_list;

        if ( IS_SUSPENDED(drv) )
        {
            // Already suspended. Nothing to do
            continue;
        }

        if ( only_ce_drivers && ! IS_USERSPACE(drv) && ! IS_CE(drv) )
        {
            continue;
        }

        if (drv->pci_dev && drv->pci_dev->driver)
        {
            // REGISTERED KERNEL-SPACE PCI DRIVER

            if ( !is_registered(drv) )
            {
                drv_error("Driver not power-management compliant", drv);
                ret = ICEPM_ERR_DEV_BUSY;
            }
            else
            {
                PWR_DEBUG("  SUSPEND %s\n", drv->name);
                // This call only valid for legacy registration
                //     if (pci_drv->suspend(drv->pci_dev, pm_message) != 0)

                if (suspend_devices_rooted(&(drv->pci_dev->dev),pm_message))
                {
                    drv_error("suspend failed for:", drv);
                    ret = ICEPM_ERR_DEV_BUSY;
                }
                // Any CE driver that successfully suspended called 
                // icepm_set_power_state(); any non-CE driver called
                // pci_set_power_state().  Either of those eventually resulted
                // in a call to our disable() function.
            }
        }
        else if ( drv->pid != 0 )
        {
            // REGISTERED USERSPACE DRIVER
            PWR_DEBUG("  SUSPEND USER SPACE DRIVER %s\n", drv->name);

            if (notify_user_space(drv, ICEPM_EVT_SUSPEND))
            {
                drv_error("suspend failed for user space driver:", drv);
                ret = ICEPM_ERR_DEV_BUSY;
            }
            else
            {
                disable(drv);
            }
        }
        else
        {
            // DRIVER NOT REGISTERED (not loaded or no driver for this device)
            PWR_DEBUG("  NO DRIVER LOADED (%s)\n", drv->name);
            disable(drv);
        }

        if (ret == ICEPM_OK)
        {
            PWR_DEBUG("    SUSPEND OK\n");
            MARK_SUSPENDED(drv);
            suspended_drivers[count++] = drv;
        }
        else if ( ignore_suspend_failures )
        {
            PWR_DEBUG("    SUSPEND FAILED\n");
            ret = ICEPM_ERR_INCOMPLETE;
            continue;
        }
        else
        {
            //------------------------------------------------------------------
            // Back out all drivers we just suspended
            //------------------------------------------------------------------
            PWR_DEBUG("    SUSPEND FAILED\n");
            PWR_DEBUG("****BACKOUT SUSPENDED DRIVERS\n");
            suspended_drivers[count] = NULL;

            // First make sure all devices really are in reset. We've promised
            // drivers that's the state they'll be in when resume() is called.
            reset_drivers(suspended_drivers);

            resume_all_drivers(suspended_drivers);
            goto exit;
        }
    }
exit:
    return ret;
}

icepm_ret_t suspend_ce_drivers(driver_t **drv_list)
{
    return suspend_drivers(drv_list, true);
}

icepm_ret_t suspend_all_drivers(driver_t **drv_list)
{
    return suspend_drivers(drv_list, false);
}

//-----------------------------------------------------------------------------
// Invoke the resume functions of all drivers on the passed list (or just the
// CE drivers if the passed flag is set).
//
// Drivers are listed in the order in which they should be suspended --
// they must be resumed in the opposite order.
//-----------------------------------------------------------------------------
static
icepm_ret_t resume_drivers(driver_t **drv_list, bool only_ce_drivers)
{
    icepm_ret_t         ret         = ICEPM_OK;
    int                 n_drivers;
    pm_message_t        pm_message = { .event = PM_EVENT_RESUME };


    //Find the end of the list, counting the number of entries.
    for (n_drivers=0; *drv_list != NULL; drv_list++)
    {
        n_drivers++;
    }

    // Process the list backwards
    for (drv_list--; n_drivers > 0; drv_list--, n_drivers--)
    {
        driver_t *drv = *drv_list;

        if ( ! IS_SUSPENDED(drv) )
        {
            // Not suspended. Nothing to do
            continue;
        }

        if ( only_ce_drivers && ! IS_USERSPACE(drv) && ! IS_CE(drv) )
        {
            continue;
        }

        if (drv->pci_dev && drv->pci_dev->driver)
        {
            // Registered kernel space PCI driver

            if ( !is_registered(drv) )
            {
                // Driver not PM-compliant. Could not have suspended. Ignore.
                continue;
            }

            PWR_DEBUG("  RESUME %s\n", drv->name);
            // This call only valid for legacy registration:
            //     if (pci_drv->resume(drv->pci_dev) != 0)
            if (resume_devices_rooted(&(drv->pci_dev->dev), pm_message) != 0)
            {
                // Should be no reason why a driver can't resume, so something
                // is seriously wrong.  But there's nothing we can do about it,
                // so give an error but continue processing the list.
                drv_error("resume failed for:", drv);
                ret = ICEPM_ERR_INCOMPLETE;
                continue;
            }
            // Any CE driver that successfully suspended called 
            // icepm_set_power_statea(); any non-CE driver called
            // pci_set_power_state().  Either of those eventually resulted
            // in a call to our enable() function.
        }
        else if ( drv->pid != 0 )
        {
            // Registered userspace driver
            PWR_DEBUG("  RESUME USER SPACE DRIVER %s\n", drv->name);
            enable(drv);
            if (notify_user_space(drv, ICEPM_EVT_RESUME))
            {
                disable(drv);
                drv_error("resume failed for user space driver:", drv);
                ret = ICEPM_ERR_INCOMPLETE;
                continue;
            }
        }
        else
        {
            // DRIVER NOT REGISTERED (not loaded or no driver for this device)
            PWR_DEBUG("  NO DRIVER LOADED (%s)\n", drv->name);
            enable(drv);
        }
        // TODO: extend for other busses?

        MARK_NOT_SUSPENDED(drv);
        PWR_DEBUG("    RESUME OK\n");
    }

    return ret;
}

icepm_ret_t resume_ce_drivers(driver_t **drv_list)
{
    return resume_drivers(drv_list, true);
}

icepm_ret_t resume_all_drivers(driver_t **drv_list)
{
    return resume_drivers(drv_list, false);
}

//==============================================================================
//                 D R I V E R   R E G I S T R A T I O N
//==============================================================================

//-----------------------------------------------------------------------------
// Driver *MUST* call icepm_unregister() before unloading.  Otherwise function
// pointers from pfunc will be left dangling.
//-----------------------------------------------------------------------------
static
icepm_ret_t _icepm_pci_register(char *drv_name, icepm_functions_t *pfunc)
{
    icepm_ret_t   ret = ICEPM_OK;
    driver_t *    drv;

    PWR_DEBUG("Register '%s'\n", drv_name);

    if (drv_name == NULL)
    {
        PWR_ERROR("NULL driver name passed\n");
        ret = ICEPM_ERR_NULL_PTR;
        goto exit;
    }

    drv = get_drv( drv_name );
    if ( drv == NULL )
    {
        PWR_WARN("No power management for '%s' on this chip\n", drv_name);
        goto exit;
    }

    if ( !IS_PCI(drv) )
    {
        PWR_ERROR("%s: not a PCI driver?\n", drv_name);
        ret = ICEPM_ERR_INTERNAL;
        goto exit;
    }

    if (drv->pci_dev == NULL)
    {
        // This should have been filled in by a call to pci_get_device()
        // during our initialization
        PWR_ERROR("%s: drv->pci_dev is NULL\n", drv_name);
        ret = ICEPM_ERR_INTERNAL;
        goto exit;
    }

    if (drv->pci_dev->driver != NULL)
    {
        // TODO: find the suspend/resume functions of the registered driver:
        // - if they NULL, patch in the passed ones
        // - if they are non-NULL, only warn if they are different from the
        //   patched ones
        PWR_WARN("%s: already registered\n", drv_name);
        // Don't make this an error -- sec driver has to register directly
        // with Linux device model before calling us, in order to load FW
        //ret = ICEPM_ERR_DEV_REGISTERED;
        goto exit;
    }

    if (! pfunc || ! pfunc->suspend || ! pfunc->resume)
    {
        PWR_ERROR("%s: Invalid function list registered\n", drv_name);
        ret = ICEPM_ERR_NULL_PTR;
        goto exit;
    }

    drv->pci_drv->suspend   = pfunc->suspend;
    drv->pci_drv->resume    = pfunc->resume;
    MARK_NOT_SUSPENDED(drv);

    if (pci_register_driver(drv->pci_drv) != 0)
    {
        PWR_ERROR("%s: PCI driver registration failed\n", drv_name);
        ret = ICEPM_ERR_FAIL;
        goto exit;
    }

exit:
    return ret;
}


//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
static
icepm_ret_t _icepm_pci_unregister(char *drv_name)
{
    icepm_ret_t rc  =   ICEPM_OK;
    driver_t *  drv;

    PWR_DEBUG("Unregister '%s'\n", drv_name);

    drv = get_drv( drv_name );

    if ( drv && !IS_PCI(drv) )
    {
        // Should never have been able to register
        drv_error( "Not a PCI driver", drv);
        rc = ICEPM_ERR_DRIVER_NOT_SUPPORTED;
        goto exit;
    }

    if (drv && drv->pci_dev && drv->pci_dev->driver)
    {
        pci_unregister_driver(drv->pci_dev->driver);
    }
exit:
    return rc;
}

static icepm_ret_t set_mode(char *mode_name)
{
    icepm_ret_t rc;
    int         mode_num = get_mode_number(mode_name);

    if (mode_num == -1)
    {
        PWR_ERROR(  "Power mode '%s' not defined in platform_config file\n",
                    mode_name
                    );
        rc = ICEPM_ERR_UNKNOWN_MODE;
    }
    else if (current_mode == mode_num)
    {
        // We are already in that mode -- nothing to do
        PWR_DEBUG("Already in mode '%s'\n", mode_name);
        rc = ICEPM_OK;
    }
    else
    {
        PWR_DEBUG("Enter mode '%s':\n", mode_name);
        rc = soc->set_mode(mode_num);

        // If the mode change was successful (or "partially" successful)
        // update the global
        if ((rc == ICEPM_OK) || (rc == ICEPM_ERR_INCOMPLETE))
        {
            // Save the current mode
            current_mode = mode_num;
        }
    }

    return rc;
}



//============================================================================
//              K E R N E L   L E V E L   I N T E R F A C E
//============================================================================

icepm_ret_t PWR_HANDLER(pwr_args_t *cmd)
{
    driver_t *  drv;
    pci_power_t pci_state;
    char      * name;
    icepm_ret_t rc = ICEPM_ERR_INTERNAL;


    if (NULL == cmd)
    {
        PWR_ERROR("NULL argument pointer passed\n");
        goto exit;
    }

    switch (cmd->command)
    {
    case PWR_CMD_REGISTER_DEVICE:
        // TODO: extend for non-PCI drivers?
        os_lock(cmd_mutex);
        rc = _icepm_pci_register(cmd->reg.drv_name, cmd->reg.pfunc);
        os_unlock(cmd_mutex);
        break;

    case PWR_CMD_UNREGISTER_DEVICE:
        // TODO: extend for non-PCI drivers?
        os_lock(cmd_mutex);
        rc = _icepm_pci_unregister(cmd->unreg.drv_name);
        os_unlock(cmd_mutex);
        break;

    case PWR_CMD_SET_MODE:
        os_lock(cmd_mutex);
        rc = set_mode(cmd->setmode.mode_name);
        os_unlock(cmd_mutex);
        break;

    case PWR_CMD_SET_PWR_STATE:
        // ***DON'T USE LOCK ***
        // 
        // Command will be sent from suspend()/resume() handlers in the course
        // of processing a SET_MODE command, and the lock will already be held.

        name = cmd->setpwrstate.drv_name;
        drv = get_drv(name);

        if ( (drv == NULL) || (drv->pci_dev == NULL) )
        {
            PWR_ERROR("Unknown driver (%s)\n", name);
            goto exit;
        }

        if ( !IS_PCI(drv) )
        {
            // TODO: extend for non-PCI drivers?
            PWR_ERROR("Non-PCI driver (%s)\n", name);
            goto exit;
        }
        
        switch (cmd->setpwrstate.state)
        {
        case ICEPM_D0: pci_state = PCI_D0;      break;
        case ICEPM_D1: pci_state = PCI_D1;      break;
        case ICEPM_D2: pci_state = PCI_D2;      break;
        case ICEPM_D3: pci_state = PCI_D3hot;   break;
        default:
             PWR_ERROR("Invalid power state (%d)\n", cmd->setpwrstate.state);
             goto exit;
        }

        // I'm intentionally ignoring the pci_set_power_state() return value: on
        // 2.6.28 it ALWAYS returns -EIO (-5) on transitions to D0, and 0 on
        // transitions to standby states.
        //
        // The reason for the former is that non of the CE PCI devices support
        // PCI config space PM registers; it doesn't really matter, we control
        // the power through the P-Unit. I don't understand the inconsistent
        // return of 0 in the case of standby modes.
        //
        // It looks like poor coding, and/or assumptions about devices supported
        // by other clients (ACPI?)
        //
        // See the code for pci_set_power_state() and pci_raw_set_power_state()
        // in the kernel's drivers/pci/pci.c file
        pci_set_power_state( drv->pci_dev, pci_state );

        rc = ICEPM_OK;
        break;

    default:
        PWR_ERROR("Unknown command (%d)\n", cmd->command);
        break;
    }

exit:
    return rc;
}

EXPORT_SYMBOL(PWR_HANDLER);


//============================================================================
//     L I N U X   F I L E   O P E R A T I O N S (USER-LEVEL INTERFACE)
//============================================================================

//----------------------------------------------------------------------------
// Allocate storage for and retrieve an ASCII string from user space.
// 
// Args:
// str [out]    return pointer to local copy here.
// address      the user space address of the string.
// length       length of string, including terminator ('\0').
//
// It is the caller's responsibility to free the memory when done with it.
//----------------------------------------------------------------------------
static
icepm_ret_t get_user_space_string(char **str, void *address, unsigned length)
{
    icepm_ret_t ret = ICEPM_OK;

    *str = OS_ALLOC(length);
    if (*str == NULL)
    {
        PWR_ERROR("Out of memory\n");
        ret = ICEPM_ERR_NOMEM;
    }
    else if (copy_from_user(*str, address, length))
    {
        PWR_ERROR("Copy from user failed\n");
        ret = ICEPM_ERR_INTERNAL;
    }

    return ret;
}

//----------------------------------------------------------------------------
// ioctl handler
//----------------------------------------------------------------------------

static int fop_ioctl(   struct inode * inode,
                        struct file *  filep,
                        unsigned int   cmd,
                        unsigned long  user_args )
{
    char *      name   = NULL;
    ioctl_arg_t args;
    driver_t *  drv;
    osal_result wait_ret;

    if (copy_from_user(&args, (void*)user_args, sizeof(args)))
    {
        PWR_ERROR("Copy from user failed\n");
        args.ret = ICEPM_ERR_FAIL;
        goto exit;
    }

    args.ret = validate_version( (unsigned) args.header_major,
                            (unsigned) args.header_minor);
    if (args.ret != ICEPM_OK)
    {
        goto exit;
    }

    switch (cmd)
    {
    case PWR_IOC_SETMODE:
        os_lock(cmd_mutex);
        args.ret = get_user_space_string(&name,
                                    args.name.buffer,
                                    args.name.length);
        if (args.ret == ICEPM_OK)
        {
            args.ret = set_mode(name);
        }
        os_unlock(cmd_mutex);
        break;

    case PWR_IOC_REGISTER:
        os_lock(cmd_mutex);
        args.ret = get_user_space_string(&name, args.name.buffer, args.name.length);
        if (args.ret == ICEPM_OK)
        {
            drv = get_drv(name);
            if (drv == NULL)
            {
                PWR_ERROR("Driver '%s' not recognized\n", name);
                args.ret = ICEPM_ERR_DRIVER_NOT_SUPPORTED;
                break;
            }
    
            filep->private_data = (void*)drv; // Save in file context
            os_event_create(&drv->waitq, 1);
    
            // Setting pid non-zero activates checking of this driver in
            // other threads -- only set it when registration complete
            drv->pid = current->tgid;
        }
        os_unlock(cmd_mutex);
        break;

    case PWR_IOC_UNREGISTER:
        os_lock(cmd_mutex);
        drv = (driver_t*)(filep->private_data);    // Restore context
        if (drv)
        {
            drv->pid = 0;
            filep->private_data = NULL;
            os_event_destroy(&drv->waitq);
        }
        os_unlock(cmd_mutex);
        break;

    case PWR_IOC_WAIT:
        // Don't take lock -- we are going to block
        drv = (driver_t*)(filep->private_data);    // Restore context
        if (drv == NULL)
        {
            PWR_ERROR("Driver not registered for notifications\n");
            args.ret = ICEPM_ERR_INTERNAL;
            break;
        }

        while (OSAL_TIMEOUT==(wait_ret=(os_event_wait(&drv->waitq, 100000000))))
        {
            ;
        }

        os_event_reset(&(drv->waitq));

        switch (wait_ret)
        {
        case OSAL_NOT_DONE: args.event = ICEPM_EVT_INTERRUPTED; break;
        case OSAL_SUCCESS:  args.event = g_event;               break;
        default:            args.event = ICEPM_EVT_ERROR;       break;
        }
        break;

    case PWR_IOC_DONE:
        // Don't need lock -- only one process will be notified (and send
        // this ioctl to acknowledge) and a time.  And it deadlocks if the 
        // notification was sent due to a call to icepm_set_mode(), which
        // already has the lock.
        drv = (driver_t*)(filep->private_data);    // Restore context
        if (drv == NULL)
        {
            PWR_ERROR("Driver not registered for notifications\n");
            args.ret = ICEPM_ERR_INTERNAL;
            break;
        }

        drv->rc = args.callback_rc;
        os_event_set( &wait_for_user_space );
        break;

    default:
        PWR_ERROR("Unknown ioctl: %d\n", cmd);
        args.ret = ICEPM_ERR_INTERNAL;
        break;
    }

exit:
    if (copy_to_user((void*)user_args, &args, sizeof(args)))
    {
        PWR_ERROR("Copy to user failed\n");
        args.ret = ICEPM_ERR_FAIL;
    }

    if (name)
    {
        OS_FREE(name);
    }

    return (args.ret == ICEPM_OK) ? 0 : -EINVAL;
}


//------------------------------------------------------------------------------
// Unlocked ioctl handler => ioctl that does not use big kernel lock
//------------------------------------------------------------------------------
long fop_unlocked_ioctl(struct file  * filep,
                        unsigned int   cmd,
                        unsigned long  arg)
{
    return fop_ioctl(filep->f_dentry->d_inode, filep, cmd, arg);
}


//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
int fop_release(struct inode *inode, struct file *file)
{
    if (file->private_data)
    {
        driver_t *drv = (driver_t *)(file->private_data);

        drv->pid = 0;
        os_event_set(&(drv->waitq));
        file->private_data = 0;
    }
    return 0;
}


//------------------------------------------------------------------------------
// File operation table.
//------------------------------------------------------------------------------
static struct file_operations fops =
{
    owner:          THIS_MODULE,
    release:        fop_release,
#ifdef HAVE_UNLOCKED_IOCTL
    unlocked_ioctl: fop_unlocked_ioctl,
#else
    ioctl:          fop_ioctl,
#endif
};

//============================================================================
// L I N U X   P C I   P O W E R   M A N A G E M E N T   C A L L B A C K S
//============================================================================

#if 0
    #define PRT_CALLBACK \
            printk( \
                "ICEPM: %s: 0x%04x/0x%04x (%s)\n", \
                __func__,  \
                dev->vendor, \
                dev->device, \
                dev->driver && dev->driver->name ? dev->driver->name : "");
#else
    #define PRT_CALLBACK
#endif

static bool pcicallback_is_manageable(struct pci_dev * dev)
{
    PRT_CALLBACK;
    return true;
}

//-----------------------------------------------------------------------------
// Per hardware designer (Craig Haymond):
//
//      On shut-down I don't think order really matters... but it's not so
//      simple to do device shut-down "properly". Any device that has a
//      physical I/O ("PHY")  on the chip (e.g., SATA, USB, PCIe, VDAC, HDMI
//      Tx/Rx) should really be handled with more sophistication:
//
//      - device driver should put I/Os related to device into lowest power
//        state (may be a combination of writes to both MAC/PHY).
//
//      - icepm should clock gate the device(s) but NOT RESET DEVICES/UNITS.
//        Reset would clear the signals between MAC and PHY, possibly causing
//        PHY to come out of low power state.
//
//      - If icepm tells Punit to enter a given power mode, Punit should
//          - turn-on firewalls (which hold the signals between MACs and PHYs
//            in the proper state to keep the PHY in it<92>s low power state)
//          - put devices into reset by writing to reset registers in cp_top
//-----------------------------------------------------------------------------
static
int disable(driver_t *drv)
{
    clock_control_ret_t ccret;
    clock_res_t  *      clk;
    int                 ret = 0;

    if(drv == NULL)
    {
        PWR_ERROR("PCI disable empty drv\n");
        ret = 1;
        goto exit;
    }

    PWR_DEBUG("    disable(%s)...", drv->name);

    if ( ! IS_RESET(drv) )
    {
        if ( IS_PCI(drv) )
        {
            if ((ret = pci_save_state(drv->pci_dev)) != 0)
            {
                PWR_ERROR("\npci_save_state error: %d\n", ret);
                goto exit;
            } 
        }

        for (clk = drv->clocks; clk->name != NULL; clk++)
        {
            if ( clk->is_reset)
            {
                // Let PUnit do resets
                continue;
            }

            PWR_DEBUG(" %s ", clk->name);

            ccret = CCW(clk->res, clk->gate);
            if (ccret != CLOCK_RET_OK)
            {
                PWR_ERROR("\nclock_control_write for '%s' failed (%d)\n",
                          clk->name,
                          ccret);
                ret = 1;
                goto exit;
            }
        }
        PWR_DEBUG("\n");
        MARK_RESET(drv);
    }

exit:
    return ret;
}


//-----------------------------------------------------------------------------
// Per hardware designer (Craig Haymond):
//
//    On wake-up, for all devices, you should
//      - enable clocks first,
//      - then take device out of reset
//-----------------------------------------------------------------------------
static
int enable(driver_t *drv)
{
    clock_control_ret_t ccret;
    clock_res_t  *      clk;
    int                 ret = 0;

    if(drv == NULL)
    {
        PWR_ERROR("PCI enable empty drv\n");
        ret = 1;
        goto exit;
    }

    PWR_DEBUG("    enable(%s)...", drv->name);

    if ( IS_RESET(drv) )
    {
        for (clk = drv->clocks; clk->name != NULL; clk++)
        {
            PWR_DEBUG(" %s ", clk->name);

            ccret = CCW(clk->res, clk->enable);
            if (ccret != CLOCK_RET_OK)
            {
                PWR_ERROR("\nclock_control_write for '%s' failed (%d)\n",
                          clk->name,
                          ccret);
                ret = 1;
                goto exit;
            }
        }
        PWR_DEBUG("\n");
        MARK_NOT_RESET(drv);

        if ( IS_PCI(drv) )
        {
            if((ret = pci_restore_state(drv->pci_dev)) != 0)
            {
                PWR_ERROR("pci_restore_state error: %d\n", ret);
                goto exit;
            } 
        }
    }

exit:
    return ret;
}

static int pcicallback_set_state(struct pci_dev * dev, pci_power_t state)
{
    driver_t *  drv;
    int         ret  = 0;  // assume success TODO: what are valid error returns?
    const char *  driver_name;

    PRT_CALLBACK;

    driver_name = (dev->driver && dev->driver->name)
                    ? dev->driver->name
                    : "No driver name";

    PWR_DEBUG(  "    pcicallback_set_state: 0x%04x/0x%04x (%s) -> ",
                dev->vendor, dev->device, driver_name);

    if ( ! dev->driver )
    {
        PWR_DEBUG("No driver, ignored\n");
        goto exit;
    }

    // Can't get driver by name here: non-CE drivers may come through callback,
    // and they might not use the same names as we do.
    drv = get_drv_by_id(dev->vendor, dev->device);
    
    if (drv == NULL)
    {
        // Not one of ours; ignore
        PWR_DEBUG("Unknown driver: %s\n", driver_name);
        goto exit;
    }

    if ( !IS_PCI(drv) )
    {
        // Should not have called us
        PWR_DEBUG("Not a PCI driver: %s\n", driver_name);
        goto exit;
    }

    switch (state)
    {
    case PCI_D0:
        PWR_DEBUG("D0\n");
        ret = enable(drv);
        break;
    case PCI_D1:
        PWR_DEBUG("D1\n");
        ret = disable(drv);
        break;
    case PCI_D2:
        PWR_DEBUG("D2\n");
        ret = disable(drv);
        break;
    case PCI_D3hot:
        PWR_DEBUG("D3\n");
        ret = disable(drv);
        break;
    default:
        PWR_ERROR("Unrecognized state: %u\n", state);
        ret = 1;
        break;
    }
exit:
    return ret;
}


static pci_power_t pcicallback_choose_state(struct pci_dev * dev)
{
    pci_power_t  ret;

    PRT_CALLBACK;

    // If the current mode is 'ON', return 'go-to-D3' (standby).
    // Otherwise we are are in a standby mode, return 'go-to-on' 
    // May have to change if we ever support standby->standby mode changes.
    ret = (current_mode == MODE_ON) ? PCI_D3hot : PCI_D0;

    PWR_DEBUG("     returning %d\n", ret)
    return ret;
}

static bool pcicallback_can_wakeup(struct pci_dev * dev)
{
    PRT_CALLBACK;
    return true;
}

static int pcicallback_sleep_wake(struct pci_dev * dev, bool enable)
{
    PRT_CALLBACK;
    return 0;
}

static struct intel_pm_pci_ops_t my_pci_pm_ops =
{
    .is_manageable = pcicallback_is_manageable,
    .set_state     = pcicallback_set_state,
    .choose_state  = pcicallback_choose_state,
    .can_wakeup    = pcicallback_can_wakeup,
    .sleep_wake    = pcicallback_sleep_wake,
};

//============================================================================
//   KERNEL "SUSPEND" (STR/STD) NOTIFIERS
//============================================================================

static int notification_handler(
            struct notifier_block * nb,     // Block that was used to register
            unsigned long           type,   // Notification type
            void *                  ignore) // Always NULL -- ignore
{
    icepm_ret_t     ret;

    switch (type)
    {
    case PM_SUSPEND_PREPARE:
        ret = suspend_ce_drivers(soc->drivers);
        break;

    case PM_POST_SUSPEND:
        // System just resumed or error occurred during suspend.
        // Kernel driver .resume() callbacks have been executed, tasks thawed.
        ret = resume_ce_drivers(soc->drivers);
        break;

    default:
        // Hibernation (suspend-to-disk) notifications.
        // Not supported for now.
        ret = ICEPM_ERR_INTERNAL;
    }
    
    return (ret == ICEPM_OK) ? 0 : 1;
}


static struct notifier_block nb =
{
    notification_handler,   // Notification handler
    0,                      // Ignored when registering
    1000 /* TODO */         // Notifier chain is sorted in descending
                            //   order of this value
};
static bool             registered_notifier = false;

//============================================================================
//   M O D U L E   I N I T   A N D   S H U T D O W N   C O D E
//============================================================================

//----------------------------------------------------------------------------
// cleanup
//
// Module cleanup
//----------------------------------------------------------------------------
static void cleanup(void)
{
    if (suspended_drivers)
    {
        OS_FREE(suspended_drivers);
        suspended_drivers = NULL;
    }

    if (registered_notifier)
    {
        unregister_pm_notifier(&nb);
        registered_notifier = false;
    }

    // TODO: wake all driver_t waitq's and set all driver_t pids to 0?

    os_event_destroy( &wait_for_user_space );

    if (major_number >= 0)
    {
        unregister_chrdev(major_number,MOD_NAME);
        major_number = -1;
    }
    
    if (soc)
    {
        int i;
    
        for (i=0; soc->drivers[i] != NULL ; i++)
        {
            driver_t *drv = soc->drivers[i];
            if ( drv->pci_dev != NULL)
            {
                // Registered PCI driver
                pci_dev_put(drv->pci_dev);
                drv->pci_dev = NULL;
            }
        }
    }

    free_config();

    if (cmd_mutex)
    {
        os_destroy_lock(cmd_mutex);
        cmd_mutex = NULL;
    }

    intel_pm_register_callback(0);
}

//----------------------------------------------------------------------------
// init
//
// Module initialization
//----------------------------------------------------------------------------
static int __init init(void)
{
    int             ret     = -EINVAL;
    pal_soc_info_t  soc_info;
    int             i;

    if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 28))
    {
        PWR_ERROR("*** Power Management not supported on this kernel\n");
        goto exit;
    }

    if (PAL_SUCCESS != pal_get_soc_info(&soc_info))
    {
        PWR_ERROR("Unable to retrieve SOC info from PAL\n");
        goto exit;
    }

    if (read_config() != 0)
    {
        goto exit;
    }

#ifdef TEST
    if (socname != -1){ soc_info.name     = socname; }
    if (socstep != -1){ soc_info.stepping = socstep; }
#endif
    
    switch ( soc_info.name )
    {
    case SOC_NAME_CE3100:
    case SOC_NAME_CE4100:
        soc = ce3100_4100_init( &soc_info );
        break;
    case SOC_NAME_CE4200:
        soc = ce4200_init( &soc_info );
        break;
    case SOC_NAME_CE5300:
        soc = ce5300_init( &soc_info );
        break;
    default:
        soc = NULL;
        PWR_ERROR("Unsupported SoC (%d)\n", soc_info.name );
        break;
    }

    if (soc == NULL)
    {
        goto exit;
    }

    // Count number of drivers and allocate a temp array for use in suspend
    // operations.
    for ( i=0; soc->drivers[i]; i++ )
    {
        ;
    }
    suspended_drivers = OS_ALLOC((i+1) * sizeof(driver_t *));
    if (suspended_drivers == NULL)
    {
        PWR_ERROR("Memory allocation failure\n");
        ret = -ENOMEM;
        goto exit;
    }


// HSD 227395, 228282
#if (LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 35))
    // Older versions of kernel did not track if a valid pci_save_state had
    // ever been done before the first call to pci_restore_state, and could
    // pick up garbage.  Make sure a valid save is done for every driver
    // we might try to resume.
    for ( i=0; soc->drivers[i]; i++ )
    {
        if ( IS_PCI(soc->drivers[i]) )
        {
            if ((ret = pci_save_state(soc->drivers[i]->pci_dev)) != 0)
            {
                PWR_ERROR("pci_save_state error: %d\n", ret);
            } 
        }
    }
#endif

    major_number = register_chrdev(0, MOD_NAME, &fops);
    if (major_number < 0)
    {
        PWR_ERROR("Unable to register device %s\n", MOD_NAME);
        ret = -ENODEV;
        goto exit;
    }

    if (NULL == (cmd_mutex = os_create_lock()))
    {
        goto exit;
    }

    os_event_create( &wait_for_user_space, 1 );

    if ( register_pm_notifier(&nb) ) // Kernel function, returns 0 on success
    {
        PWR_ERROR("register_pm_notifier failed\n");
        goto exit;
    }
    registered_notifier = true;

    intel_pm_register_callback(&my_pci_pm_ops);

    ret = 0;

exit:
    if (ret != 0)
    {
        cleanup();
    }
    return ret;
}
//----------------------------------------------------------------------------
// Register init and exit functions
//----------------------------------------------------------------------------
module_init(init);
module_exit(cleanup);
