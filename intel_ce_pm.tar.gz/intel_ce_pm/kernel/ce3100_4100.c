//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2009-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE
//
// Copyright(c) 2009-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   - Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

#include <linux/string.h>
#include "osal.h"

#include "icepm_internal.h"
#include "interface.h"
#include "kernel.h"

//-----------------------------------------------------------------------------
// Power management for CE3100/CE4100
//
// Power management for these SOCs is limited to clock gating of the units
// controlled by the following drivers:
//      - audio
//      - display
//      - graphics
//      - viddec
//      - vidpproc
//-----------------------------------------------------------------------------

//==============================================================================
//          P C I   V E N D O R   A N D   D E V I C E   I D s 
//==============================================================================
#define VENDOR_ID_INTEL     0x8086

static struct pci_device_id audio_idtab[] =
{
    { PCI_DEVICE(VENDOR_ID_INTEL, 0x2E5F)  },   // AUDIO DSP 0/1
    { PCI_DEVICE(VENDOR_ID_INTEL, 0x2E60)  },   // AUDIO IF
    { 0 }
};

static struct pci_device_id graphics_idtab[] =
{
    { PCI_DEVICE(VENDOR_ID_INTEL, 0x2E5B)  },   // SGX
    { 0 }
};

// NOTE: CE3100 does not have GVsparc, but it shouldn't hurt to register for it.
// Just put it last so we never consult it.
static struct pci_device_id viddec_idtab[] =
{
    { PCI_DEVICE(VENDOR_ID_INTEL, 0x2E5C)  },   // MFD
    { PCI_DEVICE(VENDOR_ID_INTEL, 0x0703)  },   // GVSPARC   
    { 0 }
};

static struct pci_device_id vidpproc_idtab[] =
{
    { PCI_DEVICE(VENDOR_ID_INTEL, 0x2E62)  },   // DPE
    { 0 }
};

//==============================================================================
//        C L O C K   C O N T R O L   R E S O U R C E S
//==============================================================================

// cp_top resources controlled through the clock_control component to
// gate/reset the devices controlled by each driver.
//
// ORDER MATTERS: enabling/disabling will be done in the order listed
//
// Note we declare the resets as CLOCKS, unlike on later SOC's. This is because
// the common code ignores resets when disabling, deferring them to the PUnit.
// CE3100/CE4100 have no PUnit, so we must do it.

static clock_res_t audio_clocks_ce3100[] =
{
    CLOCK( AU_DSP_CLK_EN,    1, 0 ),
    CLOCK( AU_IF_CLK_EN,     1, 0 ),
    CLOCK( AU_DSP0_RST,      1, 0 ),
    CLOCK( AU_DSP1_RST,      1, 0 ),
    CLOCK( AU_IF_RST,        1, 0 ),
    { NULL }
};

static clock_res_t audio_clocks[] = // For CE4100
{
    CLOCK( S_AU_DSP_CLK_EN,  1, 0 ),
    CLOCK( L_AU_DSP_CLK_EN,  1, 0 ),
    CLOCK( AU_DSP0_RST,      1, 0 ),
    CLOCK( AU_DSP1_RST,      1, 0 ),
    CLOCK( AU_IF_RST,        1, 0 ),
    { NULL }
};

static clock_res_t display_clocks_ce3100[] =
{
    CLOCK( DAC_ABC_CLK_EN,   1, 0 ),
    CLOCK( DAC_DEF_CLK_EN,   1, 0 ),
    CLOCK( MDVO_CLK_EN,      1, 0 ),
    CLOCK( VDC_CLK_EN,       1, 0 ),
    CLOCK( HDMI_RST,         1, 0 ),
    CLOCK( VDC_RST,          1, 0 ),
    { NULL }
};

static clock_res_t display_clocks[] =   // For CE4100
{
    CLOCK( VDC_DA_CLK_EN,    1, 0 ),
    CLOCK( VDC_DB_CLK_EN,    1, 0 ),
    CLOCK( VDC_MDVO_CLK_EN,  1, 0 ),
    CLOCK( VDC_CLK_EN,       1, 0 ),
    CLOCK( HDMI_RST,         1, 0 ),
    CLOCK( VDC_RST,          1, 0 ),
    { NULL }
};

static clock_res_t graphics_clocks[] =
{
    CLOCK( GFX_CLK_EN,       1, 0 ),
    CLOCK( GFX_RST,          1, 0 ),
    { NULL }
};

static clock_res_t viddec_clocks_ce3100[] =
{
    CLOCK( MFD_CLK_EN,       1, 0 ),
    CLOCK( MFD_RST,          1, 0 ),
    { NULL }
};

static clock_res_t viddec_clocks[] = // For CE4100
{
    CLOCK( RSB_MFD_CLK_EN,   1, 0 ),
    CLOCK( MPG4_MFD_CLK_EN,  1, 0 ),
    CLOCK( VC1_MFD_CLK_EN,   1, 0 ),
    CLOCK( H264_DEF640_CLK_EN, 1, 0 ),
    CLOCK( MFD_RST,          1, 0 ),
    { NULL }
};

static clock_res_t vidpproc_clocks[] =
{
    CLOCK( DPE_CLK_EN,       1, 0 ),
    CLOCK( DPE_RST,          1, 0 ),
    { NULL }
};



//==============================================================================
//                 S U P P O R T E D   D R I V E R S
//==============================================================================

// Dummy driver remove/probe functions referenced by DECL_DRIVER macro
static void drv_remove(struct pci_dev * dev)
{
    return;
}
static int drv_probe(struct pci_dev * dev, const struct pci_device_id *id)
{
    return 0;
}

// Declare/intialize pci_driver structures used to register CE drivers with
// Linux PCI device model and driver_t structures used by us to drive mode
// changes.
DECL_PCI_DRIVER(audio,      DRV_CE )    // pci_drv_audio,      drv_audio
DECL_PCI_DRIVER(graphics,   DRV_CE )    // pci_drv_graphics,   drv_graphics
DECL_PCI_DRIVER(viddec,     DRV_CE )    // pci_drv_viddec,     drv_viddec
DECL_PCI_DRIVER(vidpproc,   DRV_CE )    // pci_drv_vidpproc,   drv_vidproc

DECL_USERSPACE_DRIVER(display)          // pci_drv_display,    drv_display

// Complete list of supported drivers.
// ORDER MATTERS: drivers are suspended in order shown, resumed in reverse order
static driver_t *drivers[] =
{
    &drv_viddec,
    &drv_vidpproc,
    &drv_graphics,
    &drv_audio,
    &drv_display,
    NULL    // EOL
};


//==============================================================================
//          P O W E R   M O D E S
//==============================================================================

//MODE_ON is defined in kernel.h
#define MODE_STANDBY    1


//=============================================================================
//   E X P O R T E D   V I A   S O C - S P E C I F I C   V E C T O R
//=============================================================================

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
static
icepm_ret_t set_mode(int mode_number)
{
    icepm_ret_t         ret  = ICEPM_OK;

    PWR_DEBUG("Enter mode '%d':\n", mode_number);

    switch (mode_number)
    {
    case MODE_ON:
        ret = resume_all_drivers(drivers);
        break;
    case MODE_STANDBY:
        ret = suspend_all_drivers(drivers);
        break;
    default:
        PWR_ERROR("Undefined power mode: %d\n", mode_number);
        ret = ICEPM_ERR_UNKNOWN_MODE;
        goto exit;
    }
exit:
    return ret;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------

//  Exported vector
static vector_t functions = { drivers, set_mode };

//  No-op version of vector, returned for unsupported steppings
static driver_t *   drivers_nop[] = { NULL };
static icepm_ret_t  set_mode_nop(int mode_number)   { return ICEPM_OK;   }

static vector_t     nops = { drivers_nop, set_mode_nop };

//=============================================================================
//                      E N T R Y   P O I N T
//=============================================================================

//-----------------------------------------------------------------------------
// ce3100_4100_init
// Returns 0 on success, 1 on error
//-----------------------------------------------------------------------------
vector_t *ce3100_4100_init(pal_soc_info_t *soc_info)
{
    vector_t *      ret     = NULL;
    int             i;

    switch (soc_info->name)
    {
    case SOC_NAME_CE3100:
        drv_audio.clocks    = audio_clocks_ce3100;
        drv_display.clocks  = display_clocks_ce3100;
        drv_viddec.clocks   = viddec_clocks_ce3100;
        break;
    case SOC_NAME_CE4100:
        if (soc_info->stepping < SOC_STEPPING_B0)
        {
            // CE4100 A0 did not support clock gating
            PWR_WARN("*** Power management not supported before B0 stepping\n");
            ret = &nops;
            goto exit;
        }
        break;
    default:
        PWR_ERROR("Unrecognized SOC (name=%d)\n", soc_info->name);
        goto exit;
    }

    for (i=0; drivers[i]; i++)
    {
        // TODO: Extend for non-PCI kernel drivers?
        if ( IS_PCI(drivers[i]) )
        {
            drivers[i]->pci_dev = pci_get_device(drivers[i]->pci_id[0].vendor,
                                                 drivers[i]->pci_id[0].device,
                                                 NULL);

            if (drivers[i]->pci_dev == NULL)
            {
                PWR_WARN("***PCI device 0x%04x:0x%04x not found\n",
                          drivers[i]->pci_id[0].vendor,
                          drivers[i]->pci_id[0].device);
            }
        }
    }

    current_mode = MODE_ON;
    ret = &functions;
exit:

#ifdef DEBUG
    {
        driver_t  **d;

        for (d=drivers; *d != NULL; d++)
        {
            clock_res_t  *clk;
            driver_t     *drv = *d;

            PWR_PRINT("DRIVER '%s':\n", drv->name);
            for (clk = drv->clocks; clk->name; clk++)
            {
                PWR_PRINT("     %s\n", clk->name );
            }
        }
    }
#endif
    return ret;
}
