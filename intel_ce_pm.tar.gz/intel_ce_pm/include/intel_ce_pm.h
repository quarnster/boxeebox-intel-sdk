//-----------------------------------------------------------------------------
// This file is provided under a dual BSD/GPLv2 license.  When using or
// redistributing this file, you may do so under either license.
//
// GPL LICENSE SUMMARY
//
// Copyright(c) 2009-2011 Intel Corporation. All rights reserved.
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of version 2 of the GNU General Public License as
// published by the Free Software Foundation.
//
// This program is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
// General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
// The full GNU General Public License is included in this distribution
// in the file called LICENSE.GPL.
//
// Contact Information:
//      Intel Corporation
//      2200 Mission College Blvd.
//      Santa Clara, CA  97052
//
// BSD LICENSE
//
// Copyright(c) 2009-2011 Intel Corporation. All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions
// are met:
//
//   - Redistributions of source code must retain the above copyright
//     notice, this list of conditions and the following disclaimer.
//   - Redistributions in binary form must reproduce the above copyright
//     notice, this list of conditions and the following disclaimer in
//     the documentation and/or other materials provided with the
//     distribution.
//   - Neither the name of Intel Corporation nor the names of its
//     contributors may be used to endorse or promote products derived
//     from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------

//------------------------------------------------------------------------------
// Header file to be included by all clients (drivers and applications) of
// power manager.
//------------------------------------------------------------------------------

#ifndef _INTEL_CE_PM_H_
#define _INTEL_CE_PM_H_

#ifndef DOXYGEN_SKIP /* DOXYGEN_SKIP only defined when docs are generated */
#define ICEPM_HEADER_VERSION_MAJOR    1
#define ICEPM_HEADER_VERSION_MINOR    0
#endif


/**@defgroup pwr        Power Management
 *
 * The Intel CE Power Management API is used to change the current power
 * operational mode of the SOC.
 *
 * On the CE3100 and CE4100, this is done by gating the clocks of
 * certain on-chip devices and putting those devices into reset.
 *
 * The drivers for the affected devices must register with the power management
 * component so that they can receive notification before being placed into
 * reset and after being taken out of reset.  Drivers can only register with
 * kernel-level calls, and must be linked against libicepm_kernel.a.
 *
 * Changes in operational mode are normally requested by applications or
 * middleware.  Requests to change the current operational mode can be made
 * from either of:
 * - user space - the caller must be linked against libicepm_user.so.
 * - kernel space - the caller must be linked against libicepm_kernel.a.
 *
 * The supported operational modes and drivers are defined in the 
 * platform/power/operational_modes section of the platform configuration file
 * (found in /etc/plaform_config/<SOC-name>/).
 *
 */


/** @ingroup pwr
 *
 * Device power states passed by drivers to icepm_set_power_state().
 * At present, only ICEPM_D0 and ICEPM_D3 are valid.
 */
typedef enum
{
    ICEPM_D0,
    ICEPM_D1,
    ICEPM_D2,
    ICEPM_D3
} icepm_state_t;

/** @ingroup pwr
 *
 * Events that can be returned to user space drivers that register a callback
 */
typedef enum
{
    ICEPM_EVT_SUSPEND,      ///< Driver should suspend for power off
    ICEPM_EVT_RESUME,       ///< Driver should resume from power off
    ICEPM_EVT_INTERRUPTED,  ///< Notification wait interrupted by signal
    ICEPM_EVT_ERROR         ///< Internal error (shuold not occur)
} icepm_event_t;


/** @ingroup pwr
 *
 * Values that can be returned by functions in the power management API.
 */
typedef enum
{
    ICEPM_OK,
        ///< Function executed without error.
    ICEPM_ERR_INTERNAL,
        ///< "Should not occur" error.
    ICEPM_ERR_DEV_REGISTERED,
        ///< Attempt to register an already-registered driver.
    ICEPM_ERR_UNKNOWN_MODE,
        ///< Specified power mode not currently defined.
    ICEPM_ERR_INCOMPATIBLE,
        ///< Incompatible versions of library and kernel module are in use.
    ICEPM_ERR_NOMEM,
        ///< Memory allocation failed.
    ICEPM_ERR_MISSING_DEVICE,
        ///< User space library tried unsuccessfully to open /dev/intel_ce_pm.
    ICEPM_ERR_INCOMPLETE,
        ///< One or more device drivers could not be suspended or resumed.
        ///< The requested mode has been "partially" entered -- in the case of
        ///< power-lowering transition, devices controlled by the culpable
        ///< driver(s) are still active; in the case of a power-raising
        ///< transition, some expected devices are not active.
    ICEPM_ERR_NULL_PTR,
        ///< Null pointer passed for required argument.
    ICEPM_ERR_FAIL,
        ///< Call to external function failed.
    ICEPM_ERR_INVALID_TRANSITION,
        ///< Transition between current power state and requested power state
        ///< is not supported.
    ICEPM_ERR_DRIVER_NOT_SUPPORTED,
        ///< Attempt to register an unknown user space driver with intel_ce_pm. 
    ICEPM_ERR_DEV_BUSY
        ///< Driver could not be suspended.
} icepm_ret_t;
                

/** @ingroup pwr
 *
 * Change the current system power mode.
 *
 * @param [in] mode_name
 * The name of the target power mode.  A 0-terminated ASCII string matching
 * one of the operational modes defined in the platform configuration file.
 */
icepm_ret_t icepm_set_mode(char *mode_name);


#ifdef __KERNEL__
//------------------------------------------------------------------------------
// KERNEL SPACE DRIVER SUPPORT
//------------------------------------------------------------------------------

#include <linux/pci.h>

/** @ingroup pwr
 *
 * This data structure describes the vector of driver-implemented functions
 * that must be passed to the power-management component when a driver registers
 * for power management.
 *
 * Each driver must internally track whether it is in suspend state or active
 * state.  By default, (at initialization) drivers should be active.
 */
typedef struct {
     int (*suspend)( struct pci_dev *dev, pm_message_t state );
        /**<
         * When called, the driver should:
         * - Ignore the passed parameters.
         * - Immediately return a value of 0 if already in suspend state.
         * - If the driver has "active" device instances (e.g., if a decoder is
         *   in paused or playing state), fail by returning -EBUSY.
         * - Enter suspend state:
         *      - Reject (with an error return) any subsequent client requests.
         *      - Suspend threads, disable IRQs, disable hardware, etc., as
         *        necessary to completely prevent access to hardware.
         *      - Make sure all state needed to bring the device out of reset
         *        and back to the current state is stored in RAM.
         * - Wait for outstanding transactions to/from the device to complete.
         * - Call icepm_set_power_state( <drv name>, ICEPM_D3 ) to reduce
         *   power to the controlled devices.
         * - Return 0 to caller.
         */
     int (*resume )( struct pci_dev *dev );
        /**<
         * When called, the driver should:
         * - Ignore the passed parameters.
         * - Immediately return a value of 0 if already in active state.
         * - Call icepm_set_power_state( <drv name>, ICEPM_D0 ) to restore
         *   power to the controlled devices.
         * - Use the stored state information to bring the device from reset to
         *   the state it was in when the suspend() function was called.
         * - Resume threads, re-enable interrupt handlers, etc.
         * - Allow normal processing of subsequent client requests.
         * - If any error occurs after the call to icepm_set_power_state(),
         *   call icepm_set_power_state( <drv name>, ICEPM_D3 ) to return
         *   the controlled devices to low-power state.
         * - Return 0 to caller.
         */
} icepm_functions_t;


/** @ingroup pwr
  *
  * All Intel CE drivers affected by power management must call this function
  * as part of their loadable kernel module initialization.
  *
  * @param [in] drv_name 
  * The 0-terminated ASCII name of the driver that is registering, as it
  * appears in the 'power' section of the platform configuration file.
  *
  * @param [in] pfunc
  * A pointer to a vector table of the power management functions exported by
  * the driver.
  */
icepm_ret_t icepm_device_register( char *drv_name, icepm_functions_t *pfunc );

/** @ingroup pwr
 *
 * All Intel CE drivers affected by power management must call this function
 * prior to shutting down.
 *
 * @param [in] drv_name
 * The name with which the driver registered.
 */
icepm_ret_t icepm_device_unregister( char *drv_name );

/** @ingroup pwr
 *
 * All Intel CE drivers affected by power management must call this function
 * after successfully completing a driver power state transition.
 *
 * In particular,
 * - a successful completion of the driver's suspend() function should end with
 *   the call icepm_set_state(<driver name>, ICEPM_D3).
 * - a successful completion of the driver's resume() function should end with
 *   the call icepm_set_state(<driver name>, ICEPM_D0).
 *
 * @param [in] drv_name
 * The name with which the driver registered.
 *
 * @param [in] state
 * The new driver power state.
 */
icepm_ret_t icepm_set_power_state( char *drv_name, icepm_state_t state);

#else

//------------------------------------------------------------------------------
// USER SPACE DRIVER SUPPORT
//------------------------------------------------------------------------------


/** @ingroup pwr
 *
 * Signature of callback function registered by user space driver.
 *
 * The callback should take the necessary steps to handle the passed event, and
 * should return 0 on success, 1 on failure.  See the description of
 * #icepm_event_t for possible events.
 *
 * In the case of ICEPM_EVT_SUSPEND, the driver should quiesce operations and
 * save state. A failure return will pre-empt the pending transition to the
 * low-power state.
 *
 * In the case of ICEPM_EVT_RESUME, the system has already transitioned to the
 * powered-on state. The driver should do whatever is necessary to re-discover
 * its environment and re-initialize its hardware with saved state.
 *
 * The callback function is invoked asynchronously and should take the
 * necessary precautions to prevent contention for global data structures.
 *
 * Since suspend/resume calls to other drivers are delayed until the callback
 * function returns, it should complete its work and return as soon as possible.
 *
 * @param [in] event
 * Event of which the callback is being notified. See description of 
 * #icepm_event_t.
 *
 * @param [in] cookie
 * The cookie passed by the driver when it registered this callback function.
 */
typedef int (* icepm_callback_t)(icepm_event_t event, void *cookie);

/** @ingroup pwr
 *
 * Register a callback function to be invoked on power state changes.
 *
 * @param [in] func
 * A pointer to the callback function to be invoked when a power management
 * event occurs. If NULL, the current callback function is unregistered.
 *
 * @param [in] drv_name
 * A '\0'-terminated ASCII string identifying the driver.  The intel_ce_pm
 * component must specifically define and reserve a unique string for each
 * driver.
 *
 * @param [in] cookie
 * A pointer to any data structure that the driver would like to be passed
 * to the callback function when it is invoked.  May be NULL.
 */
icepm_ret_t icepm_register_callback( icepm_callback_t    func,
                                     char *              drv_name,
                                     void *              cookie);
#endif

#endif // _INTEL_CE_PM_H_
