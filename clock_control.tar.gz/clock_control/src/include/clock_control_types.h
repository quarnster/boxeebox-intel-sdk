/*----------------------------------------------------------------------------
 *    This file is provided under a dual BSD/GPLv2 license.  When using or 
 *    redistributing this file, you may do so under either license.
 *
 *    GPL LICENSE SUMMARY
 *
 *    Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
 *
 *    This program is free software; you can redistribute it and/or modify 
 *    it under the terms of version 2 of the GNU General Public License as
 *    published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful, but 
 *    WITHOUT ANY WARRANTY; without even the implied warranty of 
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
 *    General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License 
 *    along with this program; if not, write to the Free Software 
 *    Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 *    The full GNU General Public License is included in this distribution 
 *    in the file called LICENSE.GPL.
 *
 *    Contact Information:
 *
 *    Intel Corporation
 *    2200 Mission College Blvd.
 *    Santa Clara, CA  97052
 *
 *    BSD LICENSE
 *
 *    Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
 *    All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without 
 *    modification, are permitted provided that the following conditions 
 *    are met:
 *
 *      * Redistributions of source code must retain the above copyright 
 *        notice, this list of conditions and the following disclaimer.
 *      * Redistributions in binary form must reproduce the above copyright 
 *        notice, this list of conditions and the following disclaimer in 
 *        the documentation and/or other materials provided with the 
 *        distribution.
 *      * Neither the name of Intel Corporation nor the names of its 
 *        contributors may be used to endorse or promote products derived 
 *        from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 *    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 *    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *----------------------------------------------------------------------------*/

#ifndef CLOCK_CONTROL_TYPES_H
#define CLOCK_CONTROL_TYPES_H
 
/**
    This file contains the types that are used by clients of the clock_control
    component
*/

/// Boolean used for flags
typedef enum clock_control_bool_t 
{
    CLOCK_TRUE = 1,
    CLOCK_FALSE = 0
} clock_control_bool_t;

/// Return type for component APIs
typedef enum clock_control_ret_t
{
    /** Library completed requested action without issue */
    CLOCK_RET_OK                            = 0,

    /** The requested resource doesn't exist on the target SOC */
    CLOCK_ERROR_INVALID_RESOURCE            = -1,
    
    /** The write value specified is too large for the bitfield */
    CLOCK_ERROR_VALUE_OUT_OF_RANGE          = -2,
    
    /** The ioctl call to the device node failed */
    CLOCK_ERROR_IOCTL_FAILED                = -3,
    
    /** Could not open the device node. Has it been created */
    CLOCK_ERROR_DEV_NODE_OPEN_FAILED        = -4,
    
    /** The client was built against a version of the library incompatible with
     *  the currently loaded clock_control kernel module.
     */
    CLOCK_ERROR_API_MODULE_VERSION_MISMATCH = -5,
    
    /** The requested action would violate the bitfield's read-write policy. */
    CLOCK_ERROR_INVALID_READ_WRITE          = -6,
    
    /** A NULL pointer was passed by the client. */
    CLOCK_ERROR_POINTER_NULL                = -7,
    
    /** A request was made with blocking set to false and the resource was busy
     */
    CLOCK_BUSY                              = -8,
    
    /** The clock_control kernel module was not successfully loaded */
    CLOCK_ERROR_MODULE_NOT_INITIALIZED      = -9,
    
    /** Request failed due to platform specific logic */
    CLOCK_ERROR_PLATFORM                    = -10,
    
    /** I2C access to an externel clock failed. */
    CLOCK_ERROR_I2C                         = -11,
}clock_control_ret_t;

/// Bit flag identifying an external (I2C) resource from resource
#define CLOCK_EXTERNAL   0x80000000

// Generate a unique offset for CE5300 resources
// When linking existing resources to the new CE5300 names, the next resource
// must be set to UNIQUE
#define UNIQUE (__LINE__)

/// An enumeration of all of the available bit fields, grouped by register.
typedef enum clock_control_resource_t
{
    ///////////////////////////////////////////////////////////////////////////
    // Bit fields in external (off-chip -- I2C access) clock generator.
    // These enumerators are distinguished from on-chip resources by having
    // the CLOCK_EXTERNAL bit set.
    ///////////////////////////////////////////////////////////////////////////
#define EXT(x) (x | CLOCK_EXTERNAL)
                                        // CE3100 CE4100 CE4200
                                        //          B1     A0
    CLOCK_EXT_AUD_CLKX      = EXT(0),   //          X      X
    CLOCK_EXT_OE_AUD_CLK0   = EXT(1),   //          X      X
    CLOCK_EXT_OE_AUD_CLK1   = EXT(2),   //          X      X
    CLOCK_EXT_OE_AUD_CLK2   = EXT(3),   //          X      X
    CLOCK_EXT_OE_AUD_CLK3   = EXT(4),   //          X      X
    CLOCK_EXT_OE_VDC_CLK1   = EXT(5),   //          X      X
    CLOCK_EXT_OE_VDC_CLK2   = EXT(6),   //          X      X
    CLOCK_EXT_OE_VDC_MASTER = EXT(7),   //          X      X
    CLOCK_EXT_VDC_CLK1      = EXT(8),   //          X      X
    CLOCK_EXT_VDC_CLK2      = EXT(9),   //          X      X
#undef EXT

    ///////////////////////////////////////////////////////////////////////////
    // On-chip resources are numbered consecutively starting from 1.
    // CLOCK_RESOURCE_ENUM_END is used internally to terminate resource lists.
    /////////////////////////////////////////////////////////////////////////// 
    CLOCK_RESOURCE_ENUM_END = 0,

    // CP_CNTL_STS: Clock Control and Status Register
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_APLL_DDS_SEL,         //   X
    CLOCK_APLL_FREQ_SEL,        //   X
    CLOCK_AUDIO_PLL_DIV_RST,    //   X
    CLOCK_AUDIO_PLL_RESET,      //   X
    CLOCK_AU_REF_CLK_EN,        //   X
    CLOCK_AVPLL_CLK_OUT_SEL,    //   X
    CLOCK_AVPLL_DDS_SEL,        //   X   X    X    X   X
    CLOCK_DA_CLK_SEL,           //   X
    CLOCK_EXT_VIDEO_EN,         //   X
    CLOCK_FSB_SPEED,            //   X   X    X    X
    CLOCK_HDMI_COLOR_DEPTH,     //   X   X    X    X
    CLOCK_HDMI_PLL_DIV_RST,     //   X   X    X    X   X
    CLOCK_HDMI_PLL_RESET,       //   X   X    X    X   X
    CLOCK_HDMI_SRC_SEL,         //   X   X    X    X
    CLOCK_HDMI_TMDS_CLK_EN,     //   X   X    X    X
    CLOCK_HOST_CLK_EN,          //   X
    CLOCK_MDVO_CLK_SEL,         //   X
    CLOCK_PCIE0_CLK_OUT_DIS,    //            X    X
    CLOCK_PCIE1_CLK_OUT_DIS,    //            X    X
    CLOCK_RESET_OUT_CNTL,       //   X   X    X    X
    CLOCK_STATUS_MEM_SPEED,     //   X   X    X    X   X
    CLOCK_USB_RESET_DONE,       //   X   X    X    X

    // CP_L2_DIV_CTRL: Level 2 Divider Control Register -- CE3100 ONLY
    CLOCK_POD_MCLKO_DIV,
    CLOCK_1394_OCK_DIV,
    CLOCK_MDVO_DIV,
    CLOCK_CTM_MDVO_DIV,

    // CP_VDC_CLK_CTRL: Pixel clock control register
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_AU_CLK_SELECT,        //            X    X
    CLOCK_HDMI_148P35_EN,       //            X    X
    CLOCK_MCLK_OUT_EN,          //            X    X
    CLOCK_PXL_INT_CLK_SEL,      //        X   X    X
    CLOCK_VDC_DA_CFG,           //        X   X    X
    CLOCK_VDC_DA_CLK_EN,        //        X   X    X   X
    CLOCK_VDC_DB_CLK_EN,        //        X   X    X   X
    CLOCK_VDC_DIV_EN,           //        X
    CLOCK_VDC_MDVO_CFG,         //        X   X    X
    CLOCK_VDC_MDVO_CLK_EN,      //        X   X    X   X

    // CP_UNIT_RST: Unit Reset Register
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_AU_DSP0_RST,          //  X     X   X    X   X
    CLOCK_AU_DSP1_RST,          //  X     X   X    X   X
    CLOCK_AU_IF_RST,            //  X     X   X    X   X
    CLOCK_CRU_RST,              //  X     X   X    X   X
    CLOCK_DEMUX_RST,            //  X     X   X    X
    CLOCK_DFX_RST,              //  X     X   X    X   X
    CLOCK_DPE_RST,              //  X     X   X    X   X
    CLOCK_GBE_RST,              //  X     X   X    X   X
    CLOCK_GBLVSPARC_RST,        //        X   X    X
    CLOCK_GFX_RST,              //  X     X   X    X   X
    CLOCK_GFX2D_RST,            //                 X   X
    CLOCK_H264VE_RST,           //            X    X   X
    CLOCK_HDMI_RST,             //        X   X    X   X
    CLOCK_HDMI_I2C_RST,         //        X   X    X   X
    CLOCK_HDVCAP_RST,           //            X    X
    CLOCK_IR_RST,               //  X     X   X    X
    CLOCK_MEU_RST,              //        X
    CLOCK_MFD_RST,              //  X     X   X    X
    CLOCK_MSPOD_HIF_RST,        //  X
    CLOCK_NAND_RST,             //        X   X    X
    CLOCK_PCIE_RST,             //            X    X
    CLOCK_PF_RST,               //  X     X   X    X   X
    CLOCK_SATA_RST,             //  X     X   X    X   X
    CLOCK_SEC_RST,              //  X     X   X    X   X
    CLOCK_TSD_RST,              //            X    X   X
    CLOCK_USB_RST,              //  X     X   X    X   X
    CLOCK_USB_RST_CFG,          //            X    X
    CLOCK_USB_RST_SW,           //            X    X   
    CLOCK_VDC_RST,              //  X     X   X    X   X

    // CP_CLK_EN: Clock Enable Register -- CE3100 ONLY
    CLOCK_AU_DSP_CLK_EN,
    CLOCK_AU_IF_CLK_EN,
    CLOCK_DAC_ABC_CLK_EN,
    CLOCK_DAC_DEF_CLK_EN,
    // CLOCK_DEMUX_CLK_EN in CP_CLK_EN on CE3100 & 4100, otherwise CP_CLK_GATE
    CLOCK_DFXUNIT_CLK_EN,
    // CLOCK_DPE_CLK_EN in CP_CLK_EN on CE3100, otherwise CP_CLK_GATE. See below
    CLOCK_GBE_CLK_EN,
    // CLOCK_GFX_CLK_EN in CP_CLK_EN on CE3100, otherwise CP_CLK_GATE. See below
    CLOCK_MDVO_CLK_EN,
    CLOCK_MFD_CLK_EN,
    CLOCK_MSPOD_HIF_CLK_EN,
    CLOCK_OTP_CLK_EN,
    CLOCK_PCIE_CLK_EN,
    CLOCK_PF_CLK_EN,
    CLOCK_PUB_CLK_EN,
    // CLOCK_SATA_CLK_EN in CP_CLK_EN, on CE3100; otherwise CP_CLK_GATE
    CLOCK_SEC_CLK_EN,
    CLOCK_USB_CLK_EN,
    //CLOCK_VDC_CLK_EN in CP_CLK_EN on CE3100, otherwise CP_CLK_GATE. See below

    // CP_STRAP_STS_0: Strap Status 0 Register
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_CEFDK_BIOS_ID,        //        X   X    X   X
    CLOCK_CG_DIS,               //  X
    CLOCK_DIS_CPU_PWR_FEAT,     //  X
    CLOCK_DIS_LOW_PWR_BUS,      //  X
    CLOCK_FSB_DFX,              //  X     X   X    X   X
    //CLOCK_FSB_OVERRIDE in STS_0 on CE3100, STS_1 otherwise. See STS_1 below
    CLOCK_FUNC_TEST,            //  X
    CLOCK_FUSE_STRAP,           //  X
    CLOCK_HDMI_PLL_SFR_BYPASS,  //        X   X    X
    CLOCK_HDMI_PLL_SOURCE_SEL,  //        X   X    X
    CLOCK_HFPLL_EN,             //        X   X    X
    CLOCK_HFPLL_SEL,            //        X   X    X
    CLOCK_HPLL_BYP_SOURCE_SEL,  //        X   X    X   X
    CLOCK_IA_BYP_SOURCE_SEL,    //        X   X    X
    CLOCK_IA_CLK_DESKEW,        //  X
    CLOCK_MPLL_BYP_SOURCE_SEL,  //        X   X    X
    CLOCK_SEC_BOOT,             //  X     X   X    X   X
    CLOCK_SIM_FAST_RST,         //  X
    CLOCK_VDAC_CAL_EN,          //        X   X    X

    // CP_STRAP_STS_1: Strap Status 1 Register
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_27M_DIR_SEL,          //        X
    CLOCK_APLL_BYP_SEL,         //  X
    CLOCK_AVPLL_XTAL_BYP_SEL,   //  X
    CLOCK_BOOT_WIDTH,           //  X     X   X    X   X
    CLOCK_CPU_FREQ_SEL,         //  X
    CLOCK_DDR_SPEED,            //        X   X    X   X
    CLOCK_DPLL1_SRC_SEL,        //  X
    CLOCK_EXP_BOOT_ACCEL_DIS,   //  X     X   X    X   X
    CLOCK_FSB_OVERRIDE,         //  X     X   X    X
                                              // NOTE: in STS_0 on CE3100
                                              // NOTE: 2-bits until CE4200(1bit)
    CLOCK_FSB_RATIO_SEL,        //        X   X    X   X
    CLOCK_GBE_CLK_SRC_SEL,      //        X   X    X   X
    CLOCK_GIG_ETH_CLK_SRC_SEL,  //  X
    CLOCK_HPLL_BYP_SEL_0,       //  X
    CLOCK_HPLL_BYP_SEL_1,       //  X
    CLOCK_HPLL_XTAL_BYP_SEL,    //  X
    CLOCK_NAND_BOOT,            //  X     X   X    X
    CLOCK_NAND_EN,              //            X    X
    CLOCK_NAND_NUM_ADDR_CYC,    //        X   X    X
    CLOCK_PCIE_PLL_SRC_SEL,     //  X
    CLOCK_RESET_OUT_CFG,        //  X
    CLOCK_RST_OUT_CFG,          //        X   X    X   X
    CLOCK_SATA_PLL_SRC_SEL,     //  X
    CLOCK_STRAP_MEM_SPEED,      //  X
    CLOCK_TIMER_CLK_SRC_SEL,    //  X
    CLOCK_USB_PLL_SRC_SEL,      //  X

    // CP_STRAP_STS_2: Strap Status 2 Register
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_APLL_BYP_SRC_SEL,     //            X    X   X
    CLOCK_AVCAP_ENABLE,         //        X
    CLOCK_AVPLL_REF_CLK_SEL,    //            X    X
    CLOCK_DPLL_BYP_SRC_SEL,     //            X    X   X
    CLOCK_FPLL_MON_EN,          //            X    X   X
    CLOCK_INTEL_MANUFACTURING,  //            X    X   X
    CLOCK_JTAG_IO_HI_LO,        //        X   X    X
    CLOCK_OEM_DEBUG,            //            X    X   X
    CLOCK_PCIE_REF_CLK_SEL,     //            X    X
    CLOCK_PUNIT_STRAP0,         //            X    X
    CLOCK_PUNIT_STRAP1,         //            X    X
    CLOCK_PUNIT_STRAP2,         //            X    X
    CLOCK_PUNIT_STRAP3,         //            X    X
    CLOCK_PUNIT_STRAP4,         //            X    X
    CLOCK_PUNIT_STRAP5,         //            X    X
    CLOCK_SATA_REF_CLK_SEL,     //            X    X
    CLOCK_USB_REF_CLK_SEL,      //            X    X

    // CP_SSKPD: Sticky Scratchpad Register
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_SSKPD,                //   X    X   X    X   X

    // CP_CLK_INV: Clock Invert Register
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_1394_CLK_INV,         //  X
    CLOCK_AHB_INV,              //  X     X   X    X
    CLOCK_AHB_CLK_INV = CLOCK_AHB_INV,              // CE3100 name
    CLOCK_APB_INV,              //  X     X   X    X
    CLOCK_APB_CLK_INV = CLOCK_APB_INV,              // CE3100 name
    CLOCK_AU_DSP_CLK_INV,       //  X
    CLOCK_DDR1X_INV,            //        X   X    X
    CLOCK_DDR2X_INV,            //        X   X    X
    CLOCK_DDS_DREF_CLK_INV,     //  X
    CLOCK_DDS_HREF_INV,         //        X   X    X
    CLOCK_DEF640_INV,           //            X    X
    CLOCK_DEMUX_CLK_INV,        //  X
    CLOCK_DMX_INV,              //        X   X    X
    CLOCK_DPE_INV,              //  X     X   X    X
    CLOCK_DPE_CLK_INV=CLOCK_DPE_INV,                // CE3100 name
    CLOCK_DSP_INV,              //        X   X    X
    CLOCK_FSB4X_INV,            //        X   X    X
    CLOCK_FSB_INV,              //        X   X    X
    CLOCK_GBE_CLK_INV,          //  X         X    X
    CLOCK_GFX_INV,              //  X     X   X    X
    CLOCK_GFX_CLK_INV=CLOCK_GFX_INV,                // CE3100 name
    CLOCK_HDMI_TMDS_INV,        //        X   X    X
    CLOCK_I2C_INV,              //        X   X    X
    CLOCK_I2C_REF_CLK_INV,      //  X
    CLOCK_MDVO_CLK_INV,         //  X
    CLOCK_MFD_INV,              //  X     X   X    X
    CLOCK_MFD_CLK_INV=CLOCK_MFD_INV,                // CE3100 name
    CLOCK_MSPOD_D_CLK_INV,      //  X
    CLOCK_MSPOD_H_CLK_INV,      //  X
    CLOCK_NAND_INV,             //        X   X    X
    CLOCK_PBB_INV,              //        X   X    X
    CLOCK_PCIESATA_IO_CLK_INV,  //  X
    CLOCK_PMU_INV,              //        X   X    X
    CLOCK_PXP_INV,              //            X    X
    CLOCK_RTC_INV,              //        X
    CLOCK_SATA0RXCLK_INV,       //        X   X    X
    CLOCK_SATA0TXCLK_INV,       //        X   X    X
    CLOCK_SATA1RXCLK_INV,       //        X   X    X
    CLOCK_SATA1TXCLK_INV,       //        X   X    X
    CLOCK_SATA_CLK_INV,         //  X
    CLOCK_SATA_INV,             //        X   X    X
    CLOCK_SEC_INV,              //  X     X   X    X
    CLOCK_SEC_CLK_INV=CLOCK_SEC_INV,                // CE3100 name
    CLOCK_USB_CLK480_INV,       //        X
    CLOCK_USB_CLK_INV,          //  X
    CLOCK_USB_HSIOCLK480_INV,   //        X
    CLOCK_VDC_CLK_INV,          //  X
    CLOCK_VDC_DA_CLK_INV,       //  X
    CLOCK_VDC_DB_CLK_INV,       //  X
    CLOCK_VDC_INV,              //        X   X    X
    CLOCK_XSI_INV,              //        X   X    X

    // CP_PLL_ADDR              // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_PLL_ADDR,             //   X    X   X    X
    CLOCK_PLL_RW,               //            X    X
    CLOCK_PLL_START,            //            X    X

    // CP_PLL_DATA              // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_PLL_DATA,             //   X    X   X    X
 
    // CP_Chicken bit register  // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_CHICKEN,              //        X   X    X   X

    // CP_AV DDS Control register  3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_AV_DDS_CTRL,          //        X   X    X   X

    // CP_TIMER DDS Control register
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_TIMER_DDS_CTRL,       //        X   X    X   X

    // CP_RTC_DDS               // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_RTC_DDS_CTRL,         //        X   X    X   X

    // CP_CLK_GATE[0]           // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_AU_XSI_CLK_EN,        //            X    X   X
    CLOCK_DEMUX_XSI_CLK_EN,     //            X    X
    CLOCK_DPE_CLK_EN,           //   X    X   X    X   X  In CP_CLK_EN on CE3100
    CLOCK_DEMUX_CLK_EN,         //            X    X      In CP_CLK_EN on CE3100
    CLOCK_GBLVSPARC_XSI_CLK_EN, //            X    X
    CLOCK_GBE_DDS_HREF_CLK_EN,  //            X    X   X
    CLOCK_GBE_HCLK_EN,          //            X    X   X
    CLOCK_GBE_XSI_CLK_EN,       //            X    X   X
    CLOCK_GFX_CLK_EN,           //        X   X    X
    CLOCK_H264_DEF640_CLK_EN,   //        X   X    X   X
    CLOCK_H264VE_CLK_EN,        //            X    X   X
    CLOCK_HDVCAP_CLK_EN,        //            X    X   X
    CLOCK_L_AU_DSP_CLK_EN,      //        X   X    X   X
    CLOCK_MCU_CLK_EN,           //            X    X
    CLOCK_MPG4_MFD_CLK_EN,      //        X   X    X   X
    CLOCK_MSPOD_XSI_CLK_EN,     //            X    X   X
    CLOCK_ODLA_CLK_EN,          //            X    X
    CLOCK_OMAR_CLK_EN,          //            X    X
    CLOCK_PAD_GBE_IN_CLK_EN,    //            X    X   X
    CLOCK_PAD_GBE_REF_CLK_EN,   //            X    X   X
    CLOCK_PMU_CLK_EN,           //            X    X
    CLOCK_PREFILTER_XSI_ELK_EN, //            X    X   X
    CLOCK_RMII_REFCLK_50_CLK_EN,//            X    X   X
    CLOCK_RSB_MFD_CLK_EN,       //        X   X    X   X
    CLOCK_S_AU_DSP_CLK_EN,      //        X   X    X   X
    CLOCK_SATA_CLK_EN,          //            X    X   X
    CLOCK_TSD_CLK_EN,           //            X    X   X
    CLOCK_USB_CLK480_EN,        //            X    X
    CLOCK_USB_XSI_CLK_EN,       //            X    X   X
    CLOCK_VC1_MFD_CLK_EN,       //        X   X    X   X
    CLOCK_VDC_CLK_EN,           //        X   X    X   X
    CLOCK_VDC_XSI_CLK_EN,       //            X    X   X
 
    // CP_CLK_GATE1             // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_DATADEL0,             //                 X
    CLOCK_DATADEL1,             //                 X
    CLOCK_GFX2D_CLK_EN,         //                 X   X
    CLOCK_MEU_CLK_EN,           //                 X   X
    CLOCK_PCIE_BBCLK_EN,        //            X    X   X
    CLOCK_PCIE_LGCLK_EN,        //            X    X   X
    CLOCK_REFCLKDEL0,           //                 X
    CLOCK_REFCLKDEL1,           //                 X
    CLOCK_RXCLKDEL0,            //                 X
    CLOCK_RXCLKDEL1,            //                 X

    // CP_FREQ_SEL -- Not on CE3100
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_DEF640_CLK_FRQ_CHG,   //        X   X    X   X
    CLOCK_DPE_CLK_FRQ_CHG,      //        X   X    X   X
    CLOCK_DSP_CLK_FRQ_CHG,      //        X   X    X
    CLOCK_GFX_CLK_FRQ_CHG,      //        X   X    X
    CLOCK_MFD_CLK_FRQ_CHG,      //        X   X    X
    CLOCK_VDC_CLK_FRQ_CHG,      //            X    X   X

    // CP_PLL_VCODIS VCO Disable register
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_APLL_VCO_DIS,         //            X    X
    CLOCK_DPLL_VCO_DIS,         //            X    X
    CLOCK_HDMI_VCO_DIS,         //            X    X
    CLOCK_MPLL_VCO_DIS,         //            X    X

    // CP_ASYNC_AU_CTRL1 - Async Audio control register 1
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_ASYNC_EN,             //                 X
    CLOCK_APLL_BYPEN,           //                 X
    CLOCK_APLL_NDIV,            //                 X
    CLOCK_APLL_FBP2DIV,         //                 X
    CLOCK_AVPLL_FBP1DIV,        //                 X

    // CP_ASYNC_AU_CTRL2 - Async Audio control register 2
                                // 3100 4100 4200 4200 5300
                                //       B1   A0   B0  A0
    CLOCK_APLL_P2DIV,           //                 X
    CLOCK_AVPLL_P1DIV,          //                 X



    //-------------------------------------------------------------------
    //
    // CE5300 resources
    //
    // Many resource names and register locations have changed, however
    // these new names are linked to the corresponding existing resources
    // if they exist.
    //
    // ********
    // IMPORTANT: If a resource is linked to a pre-existing name,
    // the next resource must be set equal to UNIQUE
    // ********
    //
    // Resource names that are commented out already exist
    //
    //---------------------------------------------------
    
    // PCI_EX_CLK_CNTL        PCI Ex Clock Control register
    CLOCK_PCIE_PLL_EXT_REF_CLKBUFEN,
    CLOCK_PCIE_PLL_INT_REF_CLKBUFEN,
    CLOCK_BBRST_B,
    CLOCK_SBI_BB_RST_B,
    CLOCK_SBI_100_RST_CORE_B,
    CLOCK_PCIE_PHY_CMN_RESET,
    /*CLOCK_PCIE_BBCLK_EN,*/
    CLOCK_PCIE_IGCLK_EN                 = CLOCK_PCIE_LGCLK_EN,
    CLOCK_PCIE_PHY_CRI_CLK_SEL          = UNIQUE,

    // HDMI_TX_CLK_CNTL       HDMI TX Clock Control register
    CLOCK_HDMI_PLL_DIV_RESET,
    CLOCK_HDMI_TX_PLL_RESET,
    CLOCK_HDMI_TX_RST                   = CLOCK_HDMI_RST,
    CLOCK_HDMI_I2C_RESET                = CLOCK_HDMI_I2C_RST,

    // HDMI_RX_CLK_CNTL       HDMI RX Clock Control register
    CLOCK_HDMI_RX_I2C_RESET             = UNIQUE,
    CLOCK_HDMI_RX_PLL_DIV_RESET,
    CLOCK_HDMI_RX_PLL_RESET,
    CLOCK_HDMI_RX_CORE_CLK_EN,
    CLOCK_HDMI_RX_CORE_CLK_FREQ,
    CLOCK_HDMI_RX_RST,

    // AUDIO_DSP_CLK_CNTL     Audio DSP Control register   
    CLOCK_DSP_1_SRAM_CLK_GATE_BYPASS,
    CLOCK_DSP_0_SRAM_CLK_GATE_BYPASS,
    CLOCK_AU_DSP1_CLK_EN,
    CLOCK_AU_DSP0_CLK_EN,
    CLOCK_DSP1_CLK_FRQ,
    CLOCK_DSP0_CLK_FRQ,
    /*CLOCK_AU_DSP1_RST,
      CLOCK_AU_DSP0_RST,*/

    // AUDIO_IF_CLK_CNTL      Audio Interfaces Control register
    CLOCK_ADAC_RESET,
    CLOCK_MCLK1_OUT_EN,
    CLOCK_MCLK0_OUT_EN,
    /*CLOCK_AU_XSI_CLK_EN,
      CLOCK_AU_IF_RST*/
    
    // VDC_CLK_CNTL           VDC Clock Control register
    CLOCK_VDC_SRAM_CLK_GATE_BYPASS,
    CLOCK_VDC_SUB_UNIT_CLK_GATE_BYPASS,
    CLOCK_LVDS_CLK_EN,
    CLOCK_HDVCAP_TS_SEL,
    CLOCK_VMASTER_DDS_SEL,
    /*CLOCK_VDC_DB_CLK_EN,
    CLOCK_VDC_DA_CLK_EN,
    CLOCK_VDC_MDVO_CLK_EN,
    CLOCK_VDC_XSI_CLK_EN,
    CLOCK_VDC_CLK_EN,*/
    CLOCK_VDC_CLK_FRQ                   = CLOCK_VDC_CLK_FRQ_CHG,
    /*CLOCK_VDC_RST*/

    // DPE_CLK_CNTL           DPE Clock Control register
    CLOCK_DPE_SRAM_CLK_GATE_BYPASS      = UNIQUE,
    CLOCK_DPE_SUB_UNIT_CLK_GATE_BYPASS,
    /*CLOCK_DPE_CLK_EN,*/
    CLOCK_DPE_CLK_FRQ                   = CLOCK_DPE_CLK_FRQ_CHG,
    /*CLOCK_DPE_RST*/

    // MFD_CLK_CNTL           MFD Clock Control register
    CLOCK_VC1VDP_SRAM_CLK_GATE_BYPASS   = UNIQUE,
    CLOCK_MFVDP_SUBUNIT_CLK_GATE_BYPASS,
    CLOCK_MPG2VDP_CLK_EN,
    CLOCK_MFD_RSB_CLK_EN                = CLOCK_RSB_MFD_CLK_EN,
    CLOCK_MFVDP_CLK_EN                  = CLOCK_MPG4_MFD_CLK_EN,
    CLOCK_VC1VDP_CLK_EN                 = CLOCK_VC1_MFD_CLK_EN,
    /*CLOCK_H264_DEF640_CLK_EN,*/
    CLOCK_H264_DEF640_CLK_FRQ           = CLOCK_DEF640_CLK_FRQ_CHG,
    CLOCK_VC1VDP_CLK_FRQ = UNIQUE,
    CLOCK_MPG2VDP_CLK_FRQ,
    CLOCK_MFVDP_CLK_FRQ,
    CLOCK_H264DEC_RST,
    CLOCK_VC1VDP_RST,
    CLOCK_MPG2VDP_RST,
    CLOCK_MFVDP_RST,

    // H264ENC_CLK_CNTL       H264 Encoder Clock Control register
    /*CLOCK_H264VE_CLK_EN,*/
    CLOCK_H264VE_CLK_FRQ,
    /*CLOCK_H264VE_RST,*/

    // SCD_CLK_CNTL           Scene Change Detect Clock Control register
    CLOCK_EPU_CLK_EN,
    CLOCK_EPU_RST,

    // SGX_CLK_CNTL           SGX Clock Control register
    CLOCK_SGX_SRAM_CLK_GATE_BYPASS,
    CLOCK_SGX_CLK_EN,
    CLOCK_SGX_RST,

    // GFX2D_CLK_CNTL         GFX 2D Clock Control register
    CLOCK_GFX_2D_CLK_EN                 = CLOCK_GFX2D_CLK_EN,
    CLOCK_GFX_2D_RST                    = CLOCK_GFX2D_RST,

    // GBE_CLK_CNTL           GBE Clock Control register
    CLOCK_GBE_SRAM_CLK_GATE_BYPASS      = UNIQUE,
    CLOCK_INT_GBE_REF_CLK_EN,
    /*CLOCK_PAD_GBE_REF_CLK_EN,
    CLOCK_PAD_GBE_IN_CLK_EN,
    CLOCK_RMII_REFCLK_50_CLK_EN,
    CLOCK_GBE_XSI_CLK_EN,
    CLOCK_GBE_HCLK_EN,
    CLOCK_GBE_DDS_HREF_CLK_EN,
    CLOCK_GBE_RST*/

    // CRU_CLK_CNTL           CRU Clock Control register
    /*CLOCK_CRU_RST*/

    // USB_CLK_CNTL           USB Clock Control register
    CLOCK_USB_WIN_MODE,
    CLOCK_USB_UTMI_CLK_EN,
    /*CLOCK_USB_XSI_CLK_EN,*/
    CLOCK_USB_PHY_RST,                   
    /*CLOCK_USB_RST*/

    // SATA_CLK_CNTL          SATA Clock Control register
    CLOCK_SATA_PLL_REF_CLKBUF_EN,
    CLOCK_SATA_PHY_CMN_RESET,
    CLOCK_SATA_PLL_CLK_EN,
    CLOCK_SATA_PHY_CRI_CLK_SEL,
    /*CLOCK_SATA_CLK_EN,
    CLOCK_SATA_RST,*/

    // TS_CLK_CNTL            Transport Stream Clock Control register
    CLOCK_TSD_SRAM_CLK_GATE_BYPASS,
    CLOCK_TSD_SUB_UNIT_CLK_GATE_BYPASS,
    /*CLOCK_TSD_CLK_EN,*/
    CLOCK_TSD_CLK_FRQ,
    /*CLOCK_TSD_RST,*/

    // PF_CLK_CNTL            Pre-filter Stream Clock Control register
    CLOCK_PREFILTER_XSI_CLK_EN          = CLOCK_PREFILTER_XSI_ELK_EN,
    /*CLOCK_PF_RST*/

    // SEC_CLK_CNTL           SEC Clock Control register
    CLOCK_SEC_SRAM_CLK_GATE_BYPASS      = UNIQUE,
    /*CLOCK_SEC_CLK_EN,*/
    CLOCK_SEC_CLK_FRQ,
    /*CLOCK_SEC_RST*/

    // MEU_CLK_CNTL           MEU Clock Control register
    /*CLOCK_MEU_CLK_EN,*/
    CLOCK_MEU_CLK_FRQ,

    // MSPOD_CLK_CNTL         MSPOD Clock Control register
    /*CLOCK_MSPOD_XSI_CLK_EN,*/
    CLOCK_MSPOD_RST,

    // HDVCAP_CLK_CNTL        HDVCAP Clock Control register
    /*CLOCK_HDVCAP_CLK_EN,
    CLOCK_HDVCAP_RST*/

    // DFX_CLK_CNTL           DFX Clock Control register
    CLOCK_DFX_RESET                     = CLOCK_DFX_RST,

    // GLOBAL_CLK_CNTL        Global Clock Control register
    CLOCK_MCU_SUB_UNIT_CLK_GATE_BYPASS  = UNIQUE,
    CLOCK_CLK_27MHZ_OUT_EN,
    CLOCK_CLK_27MHZ_SRC_SEL,
    CLOCK_PSF_RESET,
    CLOCK_SIDEBAND_ROUTER_RESET,
    CLOCK_AHB_CLK_FRQ,
    CLOCK_HCLK_FRQ,
    CLOCK_IOSF_CLK_FRQ,
    CLOCK_XSI_CLK_FRQ,

    // CP_STRAPS_STS0       Strap Status register 0
    /*CLOCK_OEM_DEBUG,
    CLOCK_INTEL_MANUFACTURING,*/
    CLOCK_FSB_OBS_MODE                  = CLOCK_FSB_DFX,
    CLOCK_BOOT_PATH = UNIQUE,
    /*CLOCK_HPLL_BYP_SOURCE_SEL,*/
    CLOCK_DPLL_BYP_SOURCE_SEL           = CLOCK_DPLL_BYP_SRC_SEL,
    CLOCK_APLL_BYP_SOURCE_SEL           = CLOCK_APLL_BYP_SRC_SEL,
    CLOCK_HDMITX_BYP_SOURCE_SEL         = CLOCK_HDMI_PLL_SOURCE_SEL,
    /*CLOCK_FPLL_MON_EN,*/
    CLOCK_FPLL_VALID_ALT                = UNIQUE,
    CLOCK_DET_TEST_MODE,
    CLOCK_ISCLK_BYP_STRAP,
    CLOCK_SFR_VSRC_SEL_HDMI_TX,
    CLOCK_SFR_VSRC_SEL_HDMI_RX,
    CLOCK_SFR_VSRC_SEL,
    /*CLOCK_SEC_BOOT,
    CLOCK_CFDK_BIOS_ID,*/

    // CP_STRAPS_STS1         Strap Status register 1
    CLOCK_VID_MODE,
    CLOCK_RESET_OUT_CTRL                = CLOCK_RST_OUT_CFG,
    CLOCK_PCIE_LANE_REV                 = UNIQUE,
    CLOCK_PCIE_PORT_CFG,
    CLOCK_BOOT_ACCELERATION             = CLOCK_EXP_BOOT_ACCEL_DIS,
    CLOCK_RGMII_CLK_SRC_SEL             = UNIQUE,
    CLOCK_RMII_CLK_SRC_SEL,
    /*CLOCK_DDR_SPEED,
    CLOCK_BOOT_WIDTH,
    CLOCK_FSB_RATIO_SEL,*/

    // CP_SSKPD_GEN5          Sticky Scratchpad register
    /*CLOCK_SSKPD,*/

    // CP_CHICKEN_GEN5        Chicken Bit register
    CLOCK_CP_CHICKEN                    = CLOCK_CHICKEN,

    // CP_AV_DDS_CNTL         AV DDS Control register
    /*CLOCK_AV_DDS_CTRL,*/

    // CP_TIMER_DDS_CNTL      Timer DDS Control register
    /*CLOCK_TIMER_DDS_CTRL,*/

    // RTC_DDS_CNTL           RTC DDS Control register
    /*CLOCK_RTC_DDS_CTRL,*/

    // GLOBAL_VSPARC0_CNTL    Global VSPARC0 Clock Control register    
    CLOCK_GVT_SRAM_CLK_GATE_BYPASS      = UNIQUE,
    CLOCK_GVT_CLK_FRQ,
    CLOCK_GVT_CLK_EN,
    CLOCK_GVT_VSPARC_RST,

    // GLOBAL_VSPARC1_CNTL    Global VSPARC1 Clock Control register
    CLOCK_GVD_SRAM_CLK_GATE_BYPASS,
    CLOCK_GVD_CLK_FREQ,
    CLOCK_GVD_CLK_EN,
    CLOCK_GVD_VSPARC_RST,

    // PLL_RESET              PLL Reset register
    CLOCK_APLL_DIV_RST,
    CLOCK_APLL_VCO_RST,
    CLOCK_DPLL_DIV_RST,
    CLOCK_DPLL_VCO_RST,

    // POWER_ISLAND_CLK_GATE  Power Island Clock Gate register  
    CLOCK_PWR_ISLAND9_CLK_EN,
    CLOCK_PWR_ISLAND8_CLK_EN,
    CLOCK_PWR_ISLAND7_CLK_EN,
    CLOCK_PWR_ISLAND6_CLK_EN,
    CLOCK_PWR_ISLAND5_CLK_EN,
    CLOCK_PWR_ISLAND4_CLK_EN,
    CLOCK_PWR_ISLAND3_CLK_EN,
    CLOCK_PWR_ISLAND2_CLK_EN,

    // POWER_ISLAND_RESET     Power Island Reset Register
    CLOCK_PWR_ISLAND10_RESET,
    CLOCK_PWR_ISLAND9_RESET,
    CLOCK_PWR_ISLAND8_RESET,
    CLOCK_PWR_ISLAND7_RESET,
    CLOCK_PWR_ISLAND6_RESET,
    CLOCK_PWR_ISLAND5_RESET,
    CLOCK_PWR_ISLAND4_RESET,
    CLOCK_PWR_ISLAND3_RESET,
    CLOCK_PWR_ISLAND2_RESET,
} clock_control_resource_t;

#endif //CLOCK_TYPES_H
