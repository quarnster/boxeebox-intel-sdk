/*----------------------------------------------------------------------------
 *    This file is provided under a dual BSD/GPLv2 license.  When using or
 *    redistributing this file, you may do so under either license.
 *
 *    GPL LICENSE SUMMARY
 *
 *    Copyright(c) 2011 Intel Corporation. All rights reserved.
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of version 2 of the GNU General Public License as
 *    published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful, but
 *    WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 *    The full GNU General Public License is included in this distribution
 *    in the file called LICENSE.GPL.
 *
 *    Contact Information:
 *
 *    Intel Corporation
 *    2200 Mission College Blvd.
 *    Santa Clara, CA  97052
 *
 *    BSD LICENSE
 *
 *    Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
 *    All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions
 *    are met:
 *
 *      * Redistributions of source code must retain the above copyright
 *        notice, this list of conditions and the following disclaimer.
 *      * Redistributions in binary form must reproduce the above copyright
 *        notice, this list of conditions and the following disclaimer in
 *        the documentation and/or other materials provided with the
 *        distribution.
 *      * Neither the name of Intel Corporation nor the names of its
 *        contributors may be used to endorse or promote products derived
 *        from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *--------------------------------------------------------------------------*/

#include "osal.h"
#include "pal.h"
#include "idl.h"
#include "idl_i2c.h"
#include "platform_config.h"

#include "clock_control.h"
#include "clock_control_shared_types.h"
#include "clock_control_print.h"
#include "kernel.h"

int debug = 0;

//-----------------------------------------------------------------------------
// External clock resources (accessed via I2C).
// Bit positions and register addresses of these fields are read from
// platform_config.
//-----------------------------------------------------------------------------
cc_resource_info_t external_clock_resources[] =
{
    _RW(CLOCK_EXT_VDC_CLK2,         0,  1, 0 ),
    _RW(CLOCK_EXT_VDC_CLK1,         0,  1, 0 ),
    _RW(CLOCK_EXT_AUD_CLKX,         0,  2, 0 ),
    _RW(CLOCK_EXT_OE_AUD_CLK3,      0,  1, 0 ),
    _RW(CLOCK_EXT_OE_VDC_CLK1,      0,  1, 0 ),
    _RW(CLOCK_EXT_OE_VDC_CLK2,      0,  1, 0 ),
    _RW(CLOCK_EXT_OE_VDC_MASTER,    0,  1, 0 ),
    _RW(CLOCK_EXT_OE_AUD_CLK2,      0,  1, 0 ),
    _RW(CLOCK_EXT_OE_AUD_CLK1,      0,  1, 0 ),
    _RW(CLOCK_EXT_OE_AUD_CLK0,      0,  1, 0 ),

    _RO(CLOCK_RESOURCE_ENUM_END,    0,  0, 0 ), // END
};

cc_resource_info_t * find_external_resource(clock_control_resource_t resource)
{
    return find_resource(resource, external_clock_resources);
}


#ifndef SUPPORT_EXTERNAL_CLOCK

    void external_clock_cleanup(void)
    {
        return;
    }

    int external_clock_init(int dbg)
    {
        debug = dbg;
        return 1;
    }

    int external_clock_access(  cc_resource_info_t    * res,
                                clock_control_bool_t    read_flag,
                                unsigned int          * value,
                                unsigned int            mask
                                )
    {
        PRINT_ERROR( "External clock support not built into clock_control\n");
        return CLOCK_ERROR_INVALID_RESOURCE;
    }

#else

//------------------------------------------------------------------------------
// External clock unit
//------------------------------------------------------------------------------

// CLOCK_PATH is the base node in the platform config file where external
// clock definitions (1 or more) are stored as subnodes
#define CLOCK_PATH "platform.external_clock"

// I2C address composition macro / extraction macro
#define I2C_REG(addr, offset)   ((addr<<8) | offset)
#define I2C_REG_ADDR(address)   ((address >> 8) & 0xFF)
#define I2C_REG_OFFSET(address) (address & 0xFF)

static int g_i2c_bus = -1;


//------------------------------------------------------------------------------
// Helper to read an integer value from a platform config node and print an
// error on failure.
//
// Return 1 on success, 0 on failure
//------------------------------------------------------------------------------
static int get_config_value(config_ref_t node, char *name, unsigned int *result)
{
    int ret = 1;

    if (CONFIG_SUCCESS == config_get_int(node, name, result))
    {
        if (debug)
        {
            PRINT("%s=%d\n", name, *result);
        }
    }
    else
    {
        ret = 0;
        PRINT_ERROR("Can't read '%s' from platform_config\n", name);
    }
    return ret;
}


//------------------------------------------------------------------------------
// Helper to read an external clock bit position from a platform config node
// and use it to finish intialization of an external clock resource.
//
// Return 1 on success, 0 on failure
//------------------------------------------------------------------------------
static int get_ext_clock_bitpos(config_ref_t                node,
                                char *                      name,     
                                clock_control_resource_t    resource,
                                unsigned int                regaddr)
{
    int ret = 0;
    cc_resource_info_t *res = find_resource(resource, external_clock_resources);

    if (res == NULL)
    {
        PRINT_ERROR("Unknown clock resource 0x%08x\n", resource );
    }
    else if ( get_config_value(node, name, &res->bitpos) )
    {
        res->address = regaddr;
        ret = 1;
    }

    return ret;
}

//------------------------------------------------------------------------------
// Helper to read number of bits of an external clock field 
// from a platform config node
//
// Return 1 on success, 0 on failure
//------------------------------------------------------------------------------
static int get_ext_clock_numbits(config_ref_t                node,
                                 char *                      name,     
                                 clock_control_resource_t    resource)
{
    int ret = 0;
    cc_resource_info_t *res = find_resource(resource, external_clock_resources);

    if (res == NULL)
    {
        PRINT_ERROR("Unknown clock resource 0x%08x\n", resource );
    }
    else if ( get_config_value(node, name, &res->numbits) )
    {
        ret = 1;
    }

    return ret;
}

//------------------------------------------------------------------------------
// Read an external clock description from the specified node of the platform
// config file.
// 
// Return 1 on success, 0 on failure
//------------------------------------------------------------------------------
static int read_external_clock_table(config_ref_t node)
{
    unsigned int device_addr;
    unsigned int config_reg0_addr;
    unsigned int config_reg1_addr;

    return get_config_value(node, "device_addr",        &device_addr)
        && get_config_value(node, "config_reg0_addr",   &config_reg0_addr)
        && get_config_value(node, "config_reg1_addr",   &config_reg1_addr)
        && get_ext_clock_bitpos(   node,
                                   "aud_clk_freq_sel_offset",
                                   CLOCK_EXT_AUD_CLKX,
                                   I2C_REG(device_addr, config_reg0_addr))
        && get_ext_clock_numbits(   node,
                                   "aud_clk_freq_sel_width",
                                   CLOCK_EXT_AUD_CLKX)
        && get_ext_clock_bitpos(   node,
                                   "vdc_clk1_freq_sel_offset",
                                   CLOCK_EXT_VDC_CLK1,
                                   I2C_REG(device_addr, config_reg0_addr))
        && get_ext_clock_numbits(   node,
                                   "vdc_clk1_freq_sel_width",
                                   CLOCK_EXT_VDC_CLK1)
        && get_ext_clock_bitpos(   node,
                                   "vdc_clk2_freq_sel_offset",
                                   CLOCK_EXT_VDC_CLK2,
                                   I2C_REG(device_addr, config_reg0_addr))
        && get_ext_clock_numbits(   node,
                                   "vdc_clk2_freq_sel_width",
                                   CLOCK_EXT_VDC_CLK2)
        && get_ext_clock_bitpos(   node,
                                   "aud_clk0_enable_offset",
                                   CLOCK_EXT_OE_AUD_CLK0,
                                   I2C_REG(device_addr, config_reg1_addr))
        && get_ext_clock_bitpos(   node,
                                   "aud_clk1_enable_offset",
                                   CLOCK_EXT_OE_AUD_CLK1,
                                   I2C_REG(device_addr, config_reg1_addr))
        && get_ext_clock_bitpos(   node,
                                   "aud_clk2_enable_offset",
                                   CLOCK_EXT_OE_AUD_CLK2,
                                   I2C_REG(device_addr, config_reg1_addr))
        && get_ext_clock_bitpos(   node,
                                   "aud_clk3_enable_offset",
                                   CLOCK_EXT_OE_AUD_CLK3,
                                   I2C_REG(device_addr, config_reg1_addr))
        && get_ext_clock_bitpos(   node,
                                   "vdc_master_clk_enable_offset",
                                   CLOCK_EXT_OE_VDC_MASTER,
                                   I2C_REG(device_addr, config_reg1_addr))
        && get_ext_clock_bitpos(   node,
                                   "vdc_clk1_enable_offset",
                                   CLOCK_EXT_OE_VDC_CLK1,
                                   I2C_REG(device_addr, config_reg1_addr))
        && get_ext_clock_bitpos(   node,
                                   "vdc_clk2_enable_offset",
                                   CLOCK_EXT_OE_VDC_CLK2,
                                   I2C_REG(device_addr, config_reg1_addr));
}

//-----------------------------------------------------------------------------
// Use the information from 'clock_node', an external clock subnode in the
// platform config file, to probe for the clock described by the subnode.
//
// Returns 
//  1 if clock is present
//  0 if clock is not present
// -1 on error in platform config file
//-----------------------------------------------------------------------------
static int clock_is_present(config_ref_t clock_node)
{
    int             present         = 0;
    unsigned int    clock_addr;
    unsigned int    reg_addr;
    unsigned char   i2c_buf;

    if ( ! get_config_value(clock_node, "i2c_bus",          &g_i2c_bus)
    ||   ! get_config_value(clock_node, "device_addr",      &clock_addr)
    ||   ! get_config_value(clock_node, "config_reg0_addr", &reg_addr))
    {
        present = -1;
    }
    else if (IDL_SUCCESS == idl_i2c_read_sub_addr(
                            g_i2c_bus, clock_addr>>1, reg_addr, &i2c_buf, 1)) 
    {
        present = 1;
    }

    if ( present != 1 )
    {
        g_i2c_bus = -1;
    }
    return present;
}

//------------------------------------------------------------------------------
// I2C access function signature
//------------------------------------------------------------------------------
typedef idl_result_t (*i2c_access_t)( uint8_t    bus,
                                      uint16_t   addr,
                                      uint8_t    offset,
                                      uint8_t  * buffer,
                                      uint32_t   n );

//------------------------------------------------------------------------------
// Universal I2C access routine
//------------------------------------------------------------------------------
static clock_control_ret_t iox_i2c( i2c_access_t    foo,
                                    unsigned int    address,
                                    unsigned char * value)
{
    clock_control_ret_t rc     = CLOCK_RET_OK;
    unsigned int        addr   = I2C_REG_ADDR(address);
    unsigned int        offset = I2C_REG_OFFSET(address);

    if (foo(g_i2c_bus, addr>>1, offset, value, 1) != IDL_SUCCESS)
    {
        idl_i2c_reset(g_i2c_bus);
        rc = CLOCK_ERROR_I2C;
        goto exit;
    }

exit:
    return rc;
}

//-----------------------------------------------------------------------------
// Access external clock settings
//-----------------------------------------------------------------------------
int external_clock_access(  cc_resource_info_t    * res,
                            clock_control_bool_t    read_flag,
                            unsigned int          * value,
                            unsigned int            mask
                            )
{
    unsigned int        temp;
    clock_control_ret_t rc  = CLOCK_RET_OK;
    
    if (g_i2c_bus == -1)
    {
        PRINT_ERROR( "i2c bus was not defined in platform_config file\n");
        rc = CLOCK_ERROR_INVALID_RESOURCE;
        goto end;
    }

    // Read the register
    rc= iox_i2c(idl_i2c_read_sub_addr, res->address, (unsigned char*)&temp);
    if (rc != CLOCK_RET_OK)
    {
        PRINT_ERROR("I2C read failure\n");
        goto end;
    }

    if (read_flag)
    {
        // Return bit(s)
        *value = (temp & mask) >> (res->bitpos+1-res->numbits);
    }
    else
    {
        // Write bit(s)
        temp = (temp & ~mask) | (*value << (res->bitpos+1-res->numbits));

        rc = iox_i2c(   idl_i2c_write_sub_addr,
                        res->address,
                        (unsigned char*)&temp);

        if (rc != CLOCK_RET_OK)
        {
            PRINT_ERROR("I2C write failure\n");
            goto end;
        }
    }

end:
    return rc;
}

//-----------------------------------------------------------------------------
//-----------------------------------------------------------------------------
void external_clock_cleanup(void)
{
    if ( g_i2c_bus != -1)
    {
        idl_i2c_close();
        g_i2c_bus = -1;
    }
}


//-----------------------------------------------------------------------------
// If platform_config file contains an external clock section, read the
// described clocks and probe for them until one is found, then read its
// full description.
//
// Returns:
//  0 on error
//      Either the platform_config file had an error in it, or none of the
//      external clocks described in it could be detected.
//      g_i2c_bus is set to -1.
//  1 on success
//      Either there was no external clock described in the platform config file
//      (g_i2c_bus is set to -1) or a described external clock was detected
//      (g_i2c_bus is the bus to use to access it).
//-----------------------------------------------------------------------------
int external_clock_init(int dbg)
{
    int             rc;
    config_result_t cfg_ret;
    config_ref_t    clock_node;
    idl_result_t    idl_rc     = IDL_NOT_INITIALIZED;
    config_ref_t    clock_base_node;
    int             clock_found;
    char            buf[20];

    debug = dbg;

    // Open external clock node in platform config file, if it's there
    if (CONFIG_SUCCESS != config_node_find( ROOT_NODE,
                                            CLOCK_PATH,
                                            &clock_base_node))
    {
        if (debug)
        {
            PRINT("No external clock defined in platform_config\n");
        }
        rc = 1;
        goto exit;
    }

    // Initialize I2C logic, for access to external clock
    if (IDL_SUCCESS != (idl_rc = idl_i2c_open()))
    {
        PRINT_ERROR("Unable to initialize I2C for external clock\n");
        rc = 0;
        goto exit;
    }

    // Iterate through platform_config subnodes for different clocks,
    // trying each to see if clock chip is present.
    clock_found = 0;
    for ( cfg_ret =  config_node_first_child(clock_base_node, &clock_node);
          (cfg_ret == CONFIG_SUCCESS) && !clock_found;
          cfg_ret =  config_node_next_sibling(clock_node, &clock_node)
        )
    {
        if (CONFIG_SUCCESS != config_node_get_name( clock_node,
                                                    buf,
                                                    sizeof(buf)))
        {
            PRINT_ERROR("config_node_get_name failed\n");
            break;
        }

        // If the buffer is too short, config_node_get_name() truncates the
        // returned name before 0-terminating it, with no indication that
        // anything was lost. Doesn't matter much, this is just for debug.
        // But add an indicator to end of buffer just in case
        strcpy(&buf[sizeof(buf)-4], "...");

        PRINT("Probing external clock '%s'...\n", buf);
        clock_found = clock_is_present(clock_node);

        if (clock_found == 1)
        {
            PRINT("Clock '%s' found, reading configuration...\n", buf);
            if (! read_external_clock_table(clock_node))
            {
                clock_found = -1;
            }
        }
    }

    switch (clock_found)
    {
    case 0:     // No clock detected
    case -1:    // platform_config file error
        // In case of platform config error, message was already emitted
        if (clock_found == 0)
        {
            PRINT_ERROR("No known external clock detected\n");
        }
        idl_i2c_close();
        g_i2c_bus = -1;
        rc = 0;
        break;
    case 1:
        rc = 1;
        break;
    }

exit:
    return rc;
}

#endif  // SUPPORT_EXTERNAL_CLOCK defined
