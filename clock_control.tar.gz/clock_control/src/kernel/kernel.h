/*----------------------------------------------------------------------------
 *    This file is provided under a dual BSD/GPLv2 license.  When using or 
 *    redistributing this file, you may do so under either license.
 *
 *    GPL LICENSE SUMMARY
 *
 *    Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
 *
 *    This program is free software; you can redistribute it and/or modify 
 *    it under the terms of version 2 of the GNU General Public License as
 *    published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful, but 
 *    WITHOUT ANY WARRANTY; without even the implied warranty of 
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
 *    General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License 
 *    along with this program; if not, write to the Free Software 
 *    Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 *    The full GNU General Public License is included in this distribution 
 *    in the file called LICENSE.GPL.
 *
 *    Contact Information:
 *
 *    Intel Corporation
 *    2200 Mission College Blvd.
 *    Santa Clara, CA  97052
 *
 *    BSD LICENSE
 *
 *    Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
 *    All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without 
 *    modification, are permitted provided that the following conditions 
 *    are met:
 *
 *      * Redistributions of source code must retain the above copyright 
 *        notice, this list of conditions and the following disclaimer.
 *      * Redistributions in binary form must reproduce the above copyright 
 *        notice, this list of conditions and the following disclaimer in 
 *        the documentation and/or other materials provided with the 
 *        distribution.
 *      * Neither the name of Intel Corporation nor the names of its 
 *        contributors may be used to endorse or promote products derived 
 *        from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 *    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 *    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *----------------------------------------------------------------------------*/

#ifndef _KERNEL_H_
#define  _KERNEL_H_

#include "clock_control_types.h"
#include "clock_control_shared_types.h"

//------------------------------------------------------------------------------
// Resource data declaration macros
// NOTE:  'bitpos' is the bit number of the HIGH-ORDER ("leftmost") bit in the
//        field, where the low-order bit in the register is bit 0.
//------------------------------------------------------------------------------

// Read / Write Policies
#define READ_OK     1
#define WRITE_OK    2

// Read/Write resource
#define _RW(id, bitpos, numbits, reg_offset) \
                { id, #id, bitpos, numbits, READ_OK | WRITE_OK, reg_offset }

// Read-only resource
#define _RO(id, bitpos, numbits, reg_offset) \
                { id, #id, bitpos, numbits, READ_OK, reg_offset }

//------------------------------------------------------------------------------
// clock control resource descriptor
//------------------------------------------------------------------------------
typedef struct
{
    clock_control_resource_t id;// Resource ID of bit field
    char *          name;       // ASCII name string
    unsigned int    bitpos;     // Bit position in register of high-order bit
    unsigned int    numbits;    // Number of bits in field
    unsigned int    access;     // Access policy
    unsigned int    address;    // Register info
} cc_resource_info_t;


cc_resource_info_t * find_resource  (   clock_control_resource_t id,
                                        cc_resource_info_t *     pool);

//------------------------------------------------------------------------------
// External clock support
//------------------------------------------------------------------------------
extern cc_resource_info_t external_clock_resources[];


void external_clock_cleanup  (  void );

int  external_clock_init     (  int debug );

int  external_clock_access   (  cc_resource_info_t    * res,
                                clock_control_bool_t    read_flag,
                                unsigned int          * value,
                                unsigned int            mask
                                );

//------------------------------------------------------------------------------
// Pointers to mapping and unmapping routines
//------------------------------------------------------------------------------
typedef void   (*munmap_t) (void       * virt_addr, unsigned int size);
typedef void * (*mmap_t  ) (unsigned int phys_addr, unsigned int size);


//------------------------------------------------------------------------------
// io_access routines
//------------------------------------------------------------------------------
void *  device_connect  (   mmap_t f,
                            unsigned int phys_addr,
                            unsigned int size
                            );

void device_disconnect  (   void * h,
                            munmap_t f,
                            void * virt_addr,
                            unsigned int size
                            );

unsigned int ior        (   void *h,
                            unsigned int base,
                            unsigned int offset
                            );

void iow                (   void *h,
                            unsigned int base,
                            unsigned int offset,
                            unsigned int val
                            );

#endif // _KERNEL_H_
