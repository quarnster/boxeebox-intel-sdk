/*----------------------------------------------------------------------------
 *    This file is provided under a dual BSD/GPLv2 license.  When using or
 *    redistributing this file, you may do so under either license.
 *
 *    GPL LICENSE SUMMARY
 *
 *    Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of version 2 of the GNU General Public License as
 *    published by the Free Software Foundation.
 *
 *    This program is distributed in the hope that it will be useful, but
 *    WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 *    General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
 *    The full GNU General Public License is included in this distribution
 *    in the file called LICENSE.GPL.
 *
 *    Contact Information:
 *
 *    Intel Corporation
 *    2200 Mission College Blvd.
 *    Santa Clara, CA  97052
 *
 *    BSD LICENSE
 *
 *    Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
 *    All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without
 *    modification, are permitted provided that the following conditions
 *    are met:
 *
 *      * Redistributions of source code must retain the above copyright
 *        notice, this list of conditions and the following disclaimer.
 *      * Redistributions in binary form must reproduce the above copyright
 *        notice, this list of conditions and the following disclaimer in
 *        the documentation and/or other materials provided with the
 *        distribution.
 *      * Neither the name of Intel Corporation nor the names of its
 *        contributors may be used to endorse or promote products derived
 *        from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *----------------------------------------------------------------------------
 * File Description:
 *    Clock Control module file. Contains main resource access / selection logic
 *--------------------------------------------------------------------------*/

#include "osal.h"
#include "pal.h"

#include "clock_control.h"
#include "clock_control_shared_types.h"
#include "clock_control_print.h"
#include "kernel.h"

#ifndef CONFIG_PCI
#error "Kernel PCI support is required"
#endif

MODULE_LICENSE("Dual BSD/GPL");
MODULE_AUTHOR("Intel Corporation, (C) 2007-2010 - All Rights Reserved");

EXPORT_SYMBOL(_clock_control_read);
EXPORT_SYMBOL(_clock_control_write);

#define CC_VENDOR_ID 0x8086
#define CC_DEVICE_ID 0x2E52

// PCI revision ID of SOC clock unit.
static unsigned char revision;

//----------------------------------------------------------------------------
// Known Clock/Reset Unit PCI device revisions
// 
// These symbolic names are assigned just to make it easy to find places in the
// code that are conditioned on different revisions
//----------------------------------------------------------------------------
typedef enum
{
    CC_PCI_REV_CE3100     =  0,  // CE3100
    CC_PCI_REV_CE4100_B   =  1,  // CE4100 B0/B1 (A-step not supported)
    CC_PCI_REV_CE4200_A0  =  2,  // CE4200 A0
    CC_PCI_REV_CE4200_B0  =  3,  // CE4200 B0
    CC_PCI_REV_CE5300_A0  =  5,  // CE5300 A0
} vdc_dev_pci_rev_t;


//------------------------------------------------------------------------------
// LOAD TIME ARGUMENTS
//------------------------------------------------------------------------------
static int debug   = 0;
module_param(debug, uint, 0);


static int                  g_major     = -1;
static void               * g_io_handle = NULL;
static cc_resource_info_t * g_resources = NULL;
static os_sema_t            g_lock;

//------------------------------------------------------------------------------
// List of register offsets - note that not all registers are in all SoC's
//------------------------------------------------------------------------------
                                    // 3100 4100 4200 4200
                                    //       B1   A0   B0
#define REG_CP_CNTL_STS     0x00    //   X   X    X    X
#define REG_CP_L2_DIV_CTRL  0x04    //   X
#define REG_CP_VDC_CLK_CTRL 0x04    //       X    X    X
#define REG_CP_UNIT_RST     0x08    //   X   X    X    X
#define REG_CP_CLK_EN       0x0C    //   X
#define REG_CP_STRAP_STS_0  0x10    //   X   X    X    X
#define REG_CP_STRAP_STS_1  0x14    //   X   X    X    X
#define REG_CP_SSKPD        0x18    //   X   X    X    X
#define REG_CP_CLK_INV      0x1C    //   X   X    X    X
#define REG_CP_PLL_ADDR     0x20    //   X   X    X    X
#define REG_CP_PLL_DATA     0x24    //   X   X    X    X
#define REG_CP_CHICKEN      0x28    //   X   X    X    X
#define REG_CP_AV_DDS       0x2C    //       X    X    X
#define REG_CP_TIMER_DDS    0x30    //       X    X    X
#define REG_CP_STRAP_STS_2  0x34    //       X    X    X
#define REG_CP_RTC_DDS      0x38    //       X    X    X
#define REG_CP_CLK_GATE0    0x3C    //       X    X    X
#define REG_CP_FREQ_SEL     0x40    //       X    X    X
#define REG_CP_PLL_VCO_DIS  0x44    //            X    X
#define REG_CP_CLK_GATE1    0x48    //            X    X
#define CP_ASYNC_AU_CTRL1   0x50    //                 X
#define CP_ASYNC_AU_CTRL2   0x54    //                 X

//------------------------------------------------------------------------------
// List of register offsets in CE5300
//------------------------------------------------------------------------------

#define REG_PCI_EX_CLK_CNTL         0x00
#define REG_HDMI_TX_CLK_CNTL        0x04
#define REG_HDMI_RX_CLK_CNTL        0x08
#define REG_AUDIO_DSP_CLK_CNTL      0x0C
#define REG_AUDIO_IF_CLK_CNTL       0x10
#define REG_VDC_CLK_CNTL            0x14
#define REG_DPE_CLK_CNTL            0x18
#define REG_MFD_CLK_CNTL            0x1C
#define REG_H264ENC_CLK_CNTL        0x20
#define REG_SCD_CLK_CNTL            0x24
#define REG_SGX_CLK_CNTL            0x28
#define REG_GFX2D_CLK_CNTL          0x2C
#define REG_GBE_CLK_CNTL            0x30
#define REG_CRU_CLK_CNTL            0x34
#define REG_USB_CLK_CNTL            0x38
#define REG_SATA_CLK_CNTL           0x3C
#define REG_TS_CLK_CNTL             0x40
#define REG_PF_CLK_CNTL             0x44
#define REG_SEC_CLK_CNTL            0x48
#define REG_MEU_CLK_CNTL            0x4C
#define REG_MSPOD_CLK_CNTL          0x50
#define REG_HDVCAP_CLK_CNTL         0x58
#define REG_DFX_CLK_CNTL            0x5C
#define REG_GLOBAL_CLK_CNTL         0x60
#define REG_CP_STRAPS_STS0          0x64
#define REG_CP_STRAPS_STS1          0x68
#define REG_CP_SSKPD_GEN5           0x70
#define REG_CP_CHICKEN_GEN5         0x78
#define REG_CP_AV_DDS_CNTL          0x7C
#define REG_CP_TIMER_DDS_CNTL       0x80
#define REG_RTC_DDS_CNTL            0x84
#define REG_PLL_RESET               0x88
#define REG_GLOBAL_VSPARC0_CNTL     0x8C
#define REG_GLOBAL_VSPARC1_CNTL     0x90
#define REG_POWER_ISLAND_CLK_GATE   0x94
#define REG_POWER_ISLAND_RESET      0x98

// Number of bytes of register bank memory to map
#define REGISTERS_LENGTH    0x9B

//------------------------------------------------------------------------------
// CE3100 Resources
//------------------------------------------------------------------------------
static cc_resource_info_t resources_ce3100[] =
{
    _RW(CLOCK_AUDIO_PLL_DIV_RST,   25,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_PLL_DIV_RST,    24,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_AU_REF_CLK_EN,       23,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_TMDS_CLK_EN,    22,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_AUDIO_PLL_RESET,     21,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_PLL_RESET,      20,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HOST_CLK_EN,         19,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_EXT_VIDEO_EN,        18,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_AVPLL_DDS_SEL,       17,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_AVPLL_CLK_OUT_SEL,   16,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_APLL_DDS_SEL,        15,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_APLL_FREQ_SEL,       14,  1, REG_CP_CNTL_STS    ),
    _RO(CLOCK_STATUS_MEM_SPEED,    13,  2, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_COLOR_DEPTH,    11,  2, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_SRC_SEL,         9,  2, REG_CP_CNTL_STS    ),
    _RO(CLOCK_USB_RESET_DONE,       7,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_RESET_OUT_CNTL,       6,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_DA_CLK_SEL,           5,  2, REG_CP_CNTL_STS    ),
    _RW(CLOCK_MDVO_CLK_SEL,         3,  1, REG_CP_CNTL_STS    ),
    _RO(CLOCK_FSB_SPEED,            2,  3, REG_CP_CNTL_STS    ),

    _RW(CLOCK_POD_MCLKO_DIV,       23,  4, REG_CP_L2_DIV_CTRL ),
    _RW(CLOCK_1394_OCK_DIV,        15,  4, REG_CP_L2_DIV_CTRL ),
    _RW(CLOCK_MDVO_DIV,            11,  4, REG_CP_L2_DIV_CTRL ),
    _RW(CLOCK_CTM_MDVO_DIV,         7,  4, REG_CP_L2_DIV_CTRL ),

    _RW(CLOCK_IR_RST,              31,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DFX_RST,             27,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_DSP1_RST,         26,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_DSP0_RST,         25,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_IF_RST,           24,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DEMUX_RST,           21,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DPE_RST,             20,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GFX_RST,             19,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_HDMI_RST,            17,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_PF_RST,              16,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_MFD_RST,             15,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_VDC_RST,             13,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_MSPOD_HIF_RST,       12,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_SEC_RST,             11,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GBE_RST,              5,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_SATA_RST,             4,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_USB_RST,              3,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_CRU_RST,              1,  1, REG_CP_UNIT_RST    ),

    _RW(CLOCK_OTP_CLK_EN,          28,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_DFXUNIT_CLK_EN,      27,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_AU_DSP_CLK_EN,       25,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_AU_IF_CLK_EN,        24,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_PUB_CLK_EN,          23,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_DEMUX_CLK_EN,        21,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_DPE_CLK_EN,          20,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_GFX_CLK_EN,          19,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_PF_CLK_EN,           16,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_MFD_CLK_EN,          15,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_VDC_CLK_EN,          13,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_MSPOD_HIF_CLK_EN,    12,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_SEC_CLK_EN,          11,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_MDVO_CLK_EN,         10,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_DAC_ABC_CLK_EN,       9,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_DAC_DEF_CLK_EN,       8,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_GBE_CLK_EN,           5,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_SATA_CLK_EN,          4,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_USB_CLK_EN,           3,  1, REG_CP_CLK_EN      ),
    _RW(CLOCK_PCIE_CLK_EN,          2,  1, REG_CP_CLK_EN      ),

    _RO(CLOCK_SEC_BOOT,            20,  1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_DIS_CPU_PWR_FEAT,    19,  1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_DIS_LOW_PWR_BUS,     18,  1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_FUSE_STRAP,          17,  1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_FSB_DFX,             16,  3, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_FSB_OVERRIDE,        13,  2, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_CG_DIS,              11,  1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_IA_CLK_DESKEW,       10,  4, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_SIM_FAST_RST,         6,  1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_FUNC_TEST,            5,  1, REG_CP_STRAP_STS_0 ),

    _RO(CLOCK_GIG_ETH_CLK_SRC_SEL, 23,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_TIMER_CLK_SRC_SEL,   22,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_USB_PLL_SRC_SEL,     21,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_SATA_PLL_SRC_SEL,    20,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_PCIE_PLL_SRC_SEL,    19,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_DPLL1_SRC_SEL,       18,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_HPLL_XTAL_BYP_SEL,   17,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_HPLL_BYP_SEL_1,      16,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_RESET_OUT_CFG,       15,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_EXP_BOOT_ACCEL_DIS,  14,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_AVPLL_XTAL_BYP_SEL,  13,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_APLL_BYP_SEL,        12,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_HPLL_BYP_SEL_0,      11,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_NAND_BOOT,           10,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_BOOT_WIDTH,           8,  1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_STRAP_MEM_SPEED,      6,  2, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_CPU_FREQ_SEL,         4,  5, REG_CP_STRAP_STS_1 ),

    _RW(CLOCK_SSKPD,               31, 32, REG_CP_SSKPD       ),

    _RW(CLOCK_PCIESATA_IO_CLK_INV, 28,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_AU_DSP_CLK_INV,      24,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_AHB_CLK_INV,         23,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_APB_CLK_INV,         22,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DEMUX_CLK_INV,       21,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DPE_CLK_INV,         20,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_GFX_CLK_INV,         19,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_I2C_REF_CLK_INV,     16,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_MFD_CLK_INV,         15,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_VDC_CLK_INV,         13,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_MSPOD_H_CLK_INV,     12,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SEC_CLK_INV,         11,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_MDVO_CLK_INV,        10,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_VDC_DA_CLK_INV,       9,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_VDC_DB_CLK_INV,       8,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_1394_CLK_INV,         7,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_MSPOD_D_CLK_INV,      6,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_GBE_CLK_INV,          5,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA_CLK_INV,         4,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_USB_CLK_INV,          3,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DDS_DREF_CLK_INV,     2,  1, REG_CP_CLK_INV     ),

    _RW(CLOCK_PLL_ADDR,            31, 32, REG_CP_PLL_ADDR    ),

    _RW(CLOCK_PLL_DATA,            31, 32, REG_CP_PLL_DATA    ),

    _RO(CLOCK_RESOURCE_ENUM_END,    0,  0,                    ), // END
};

//------------------------------------------------------------------------------
// CE4100 B-Step Resources
//------------------------------------------------------------------------------
static cc_resource_info_t resources_ce4100_B[] =
{
    _RW(CLOCK_HDMI_PLL_DIV_RST,    24,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_TMDS_CLK_EN,    22,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_PLL_RESET,      20,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_AVPLL_DDS_SEL,       17,  1, REG_CP_CNTL_STS    ),
    _RO(CLOCK_STATUS_MEM_SPEED,    14,  3, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_COLOR_DEPTH,    11,  2, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_SRC_SEL,         9,  2, REG_CP_CNTL_STS    ),
    _RO(CLOCK_USB_RESET_DONE,       7,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_RESET_OUT_CNTL,       6,  1, REG_CP_CNTL_STS    ),
    _RO(CLOCK_FSB_SPEED,            1,  2, REG_CP_CNTL_STS    ),

    _RW(CLOCK_PXL_INT_CLK_SEL,      7,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_DIV_EN,           6,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_DB_CLK_EN,        5,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_DA_CLK_EN,        4,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_MDVO_CLK_EN,      3,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_DA_CFG,           2,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_MDVO_CFG,         1,  2, REG_CP_VDC_CLK_CTRL),

    _RW(CLOCK_IR_RST,              31,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DFX_RST,             27,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_DSP1_RST,         26,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_DSP0_RST,         25,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_IF_RST,           24,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DEMUX_RST,           21,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DPE_RST,             20,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GFX_RST,             19,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GBLVSPARC_RST,       18,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_HDMI_RST,            17,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_PF_RST,              16,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_MFD_RST,             15,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_VDC_RST,             13,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_NAND_RST,            12,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_SEC_RST,             11,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_HDMI_I2C_RST,         6,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GBE_RST,              5,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_SATA_RST,             4,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_USB_RST,              3,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_MEU_RST,              2,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_CRU_RST,              1,  1, REG_CP_UNIT_RST    ),

    _RO(CLOCK_VDAC_CAL_EN,          14, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_FSB_DFX,              13, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HDMI_PLL_SFR_BYPASS,  12, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HDMI_PLL_SOURCE_SEL,  11, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_MPLL_BYP_SOURCE_SEL,  10, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_IA_BYP_SOURCE_SEL,     9, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HPLL_BYP_SOURCE_SEL,   8, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_SEC_BOOT,              7, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HFPLL_SEL,             6, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HFPLL_EN,              5, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_CEFDK_BIOS_ID,         4, 5, REG_CP_STRAP_STS_0 ),

    _RO(CLOCK_RST_OUT_CFG,          15, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_EXP_BOOT_ACCEL_DIS,   14, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_27M_DIR_SEL,          13, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_GBE_CLK_SRC_SEL,      12, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_NAND_NUM_ADDR_CYC,    11, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_NAND_BOOT,            10, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_BOOT_WIDTH,            9, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_DDR_SPEED,             8, 3, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_FSB_OVERRIDE,          5, 2, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_FSB_RATIO_SEL,         3, 4, REG_CP_STRAP_STS_1 ),

    _RO(CLOCK_AVCAP_ENABLE,          8, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_JTAG_IO_HI_LO,         0, 1, REG_CP_STRAP_STS_2 ),

    _RW(CLOCK_SSKPD,               31, 32, REG_CP_SSKPD       ),

    _RW(CLOCK_SATA0RXCLK_INV,      27,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA0TXCLK_INV,      26,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA1RXCLK_INV,      25,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA1TXCLK_INV,      24,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_HDMI_TMDS_INV,       23,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_USB_CLK480_INV,      22,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_USB_HSIOCLK480_INV,  21,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DDR2X_INV,           20,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DDR1X_INV,           19,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_PMU_INV,             18,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_NAND_INV,            17,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DDS_HREF_INV,        16,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_RTC_INV,             15,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DPE_INV,             14,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_VDC_INV,             13,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SEC_INV,             12,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_MFD_INV,             11,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DSP_INV,             10,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_GFX_INV,              9,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_PBB_INV,              8,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_FSB4X_INV,            7,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_FSB_INV,              6,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_APB_INV,              5,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA_INV,             4,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_I2C_INV,              3,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_AHB_INV,              2,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DMX_INV,              1,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_XSI_INV,              0,  1, REG_CP_CLK_INV     ),

    _RW(CLOCK_PLL_ADDR,            31, 32, REG_CP_PLL_ADDR    ),

    _RW(CLOCK_PLL_DATA,            31, 32, REG_CP_PLL_DATA    ),

    _RW(CLOCK_CHICKEN,              7,  8, REG_CP_CHICKEN     ),

    _RW(CLOCK_AV_DDS_CTRL,         31, 32, REG_CP_AV_DDS      ),

    _RW(CLOCK_TIMER_DDS_CTRL,      31, 32, REG_CP_TIMER_DDS   ),

    _RW(CLOCK_RTC_DDS_CTRL,        31, 32, REG_CP_RTC_DDS     ),

    _RW(CLOCK_RSB_MFD_CLK_EN,       8,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_MPG4_MFD_CLK_EN,      7,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_VC1_MFD_CLK_EN,       6,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_H264_DEF640_CLK_EN,   5,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_S_AU_DSP_CLK_EN,      4,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_L_AU_DSP_CLK_EN,      3,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_VDC_CLK_EN,           2,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_DPE_CLK_EN,           1,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GFX_CLK_EN,           0,  1, REG_CP_CLK_GATE0   ),

    _RW(CLOCK_DSP_CLK_FRQ_CHG,     14,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_DPE_CLK_FRQ_CHG,     11,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_MFD_CLK_FRQ_CHG,      8,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_DEF640_CLK_FRQ_CHG,   5,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_GFX_CLK_FRQ_CHG,      2,  3, REG_CP_FREQ_SEL    ),

    _RO(CLOCK_RESOURCE_ENUM_END,    0,  0, 0                  ), // END
};

//------------------------------------------------------------------------------
// CE4200 A0 Resources
//------------------------------------------------------------------------------
static cc_resource_info_t resources_ce4200_A0[] =
{
    _RW(CLOCK_PCIE0_CLK_OUT_DIS,   26,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_PCIE1_CLK_OUT_DIS,   25,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_PLL_DIV_RST,    24,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_TMDS_CLK_EN,    22,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_PLL_RESET,      20,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_AVPLL_DDS_SEL,       17,  1, REG_CP_CNTL_STS    ),
    _RO(CLOCK_STATUS_MEM_SPEED,    14,  3, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_COLOR_DEPTH,    11,  2, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_SRC_SEL,         9,  2, REG_CP_CNTL_STS    ),
    _RO(CLOCK_USB_RESET_DONE,       7,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_RESET_OUT_CNTL,       6,  1, REG_CP_CNTL_STS    ),
    _RO(CLOCK_FSB_SPEED,            1,  2, REG_CP_CNTL_STS    ),

    _RW(CLOCK_MCLK_OUT_EN,         18,  4, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_AU_CLK_SELECT,       10,  3, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_PXL_INT_CLK_SEL,      7,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_HDMI_148P35_EN,       6,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_DB_CLK_EN,        5,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_DA_CLK_EN,        4,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_MDVO_CLK_EN,      3,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_DA_CFG,           2,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_MDVO_CFG,         1,  2, REG_CP_VDC_CLK_CTRL),

    _RW(CLOCK_IR_RST,              31,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_PCIE_RST,            29,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_H264VE_RST,          28,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DFX_RST,             27,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_DSP1_RST,         26,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_DSP0_RST,         25,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_IF_RST,           24,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_HDVCAP_RST,          22,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DEMUX_RST,           21,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DPE_RST,             20,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GFX_RST,             19,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GBLVSPARC_RST,       18,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_HDMI_RST,            17,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_PF_RST,              16,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_MFD_RST,             15,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_TSD_RST,             14,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_VDC_RST,             13,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_NAND_RST,            12,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_SEC_RST,             11,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_USB_RST_CFG,          8,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_USB_RST_SW,           7,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_HDMI_I2C_RST,         6,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GBE_RST,              5,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_SATA_RST,             4,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_USB_RST,              3,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_CRU_RST,              1,  1, REG_CP_UNIT_RST    ),

    _RO(CLOCK_VDAC_CAL_EN,         14, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_FSB_DFX,             13, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HDMI_PLL_SFR_BYPASS, 12, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HDMI_PLL_SOURCE_SEL, 11, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_MPLL_BYP_SOURCE_SEL, 10, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_IA_BYP_SOURCE_SEL,    9, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HPLL_BYP_SOURCE_SEL,  8, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_SEC_BOOT,             7, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HFPLL_SEL,            6, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HFPLL_EN,             5, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_CEFDK_BIOS_ID,        4, 5, REG_CP_STRAP_STS_0 ),

    _RO(CLOCK_RST_OUT_CFG,         15, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_EXP_BOOT_ACCEL_DIS,  14, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_NAND_EN,             13, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_GBE_CLK_SRC_SEL,     12, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_NAND_NUM_ADDR_CYC,   11, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_NAND_BOOT,           10, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_BOOT_WIDTH,           9, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_DDR_SPEED,            8, 3, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_FSB_OVERRIDE,         5, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_FSB_RATIO_SEL,        3, 4, REG_CP_STRAP_STS_1 ),

    _RO(CLOCK_PUNIT_STRAP5,        21, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PUNIT_STRAP4,        20, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PUNIT_STRAP3,        19, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PUNIT_STRAP2,        18, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PUNIT_STRAP1,        17, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PUNIT_STRAP0,        16, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_OEM_DEBUG,           13, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_INTEL_MANUFACTURING, 12, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_AVPLL_REF_CLK_SEL,   11, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PCIE_REF_CLK_SEL,    10, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_SATA_REF_CLK_SEL,     9, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_USB_REF_CLK_SEL,      8, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_DPLL_BYP_SRC_SEL,     3, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_APLL_BYP_SRC_SEL,     2, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_FPLL_MON_EN,          1, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_JTAG_IO_HI_LO,        0, 1, REG_CP_STRAP_STS_2 ),

    _RW(CLOCK_SSKPD,               31, 32, REG_CP_SSKPD       ),

    _RW(CLOCK_PXP_INV,             29,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_GBE_CLK_INV,         28,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA0RXCLK_INV,      27,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA0TXCLK_INV,      26,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA1RXCLK_INV,      25,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA1TXCLK_INV,      24,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_HDMI_TMDS_INV,       23,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DDR2X_INV,           20,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DDR1X_INV,           19,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_PMU_INV,             18,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_NAND_INV,            17,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DDS_HREF_INV,        16,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DEF640_INV,          15,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DPE_INV,             14,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_VDC_INV,             13,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SEC_INV,             12,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_MFD_INV,             11,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DSP_INV,             10,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_GFX_INV,              9,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_PBB_INV,              8,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_FSB4X_INV,            7,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_FSB_INV,              6,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_APB_INV,              5,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA_INV,             4,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_I2C_INV,              3,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_AHB_INV,              2,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DMX_INV,              1,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_XSI_INV,              0,  1, REG_CP_CLK_INV     ),

    _RW(CLOCK_PLL_START,           31,  1, REG_CP_PLL_ADDR    ),
    _RW(CLOCK_PLL_RW,              29,  1, REG_CP_PLL_ADDR    ),
    _RW(CLOCK_PLL_ADDR,             7,  8, REG_CP_PLL_ADDR    ),

    _RW(CLOCK_PLL_DATA,            31, 32, REG_CP_PLL_DATA    ),

    _RW(CLOCK_CHICKEN,              7,  8, REG_CP_CHICKEN     ),

    _RW(CLOCK_AV_DDS_CTRL,         31, 32, REG_CP_AV_DDS      ),

    _RW(CLOCK_TIMER_DDS_CTRL,      31, 32, REG_CP_TIMER_DDS   ),

    _RW(CLOCK_RTC_DDS_CTRL,        31, 32, REG_CP_RTC_DDS     ),

    _RW(CLOCK_VDC_CLK_EN,           31,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_MCU_CLK_EN,           30,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_VDC_XSI_CLK_EN,       29,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_USB_CLK480_EN,        28,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_USB_XSI_CLK_EN,       27,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_PREFILTER_XSI_ELK_EN, 26,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_AU_XSI_CLK_EN,        25,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_ODLA_CLK_EN,          24,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_HDVCAP_CLK_EN,        23,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_DEMUX_XSI_CLK_EN,     22,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_TSD_CLK_EN,           21,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_DEMUX_CLK_EN,         20,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_SATA_CLK_EN,          19,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_MSPOD_XSI_CLK_EN,     18,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GBLVSPARC_XSI_CLK_EN, 17,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_RSB_MFD_CLK_EN,       16,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_MPG4_MFD_CLK_EN,      15,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_VC1_MFD_CLK_EN,       14,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_H264_DEF640_CLK_EN,   13,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_S_AU_DSP_CLK_EN,      12,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_L_AU_DSP_CLK_EN,      11,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_DPE_CLK_EN,           10,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_H264VE_CLK_EN,         9,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GFX_CLK_EN,            8,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_PMU_CLK_EN,            7,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_OMAR_CLK_EN,           6,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_RMII_REFCLK_50_CLK_EN, 5,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_PAD_GBE_REF_CLK_EN,    4,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_PAD_GBE_IN_CLK_EN,     3,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GBE_XSI_CLK_EN,        2,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GBE_HCLK_EN,           1,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GBE_DDS_HREF_CLK_EN,   0,  1, REG_CP_CLK_GATE0   ),

    _RW(CLOCK_PCIE_LGCLK_EN,        1,  1, REG_CP_CLK_GATE1   ),
    _RW(CLOCK_PCIE_BBCLK_EN,        0,  1, REG_CP_CLK_GATE1   ),

    _RW(CLOCK_VDC_CLK_FRQ_CHG,     15,  1, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_DSP_CLK_FRQ_CHG,     14,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_DPE_CLK_FRQ_CHG,     11,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_MFD_CLK_FRQ_CHG,      8,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_DEF640_CLK_FRQ_CHG,   5,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_GFX_CLK_FRQ_CHG,      2,  3, REG_CP_FREQ_SEL    ),

    _RW(CLOCK_HDMI_VCO_DIS,         4,  1, REG_CP_PLL_VCO_DIS ),
    _RW(CLOCK_DPLL_VCO_DIS,         3,  1, REG_CP_PLL_VCO_DIS ),
    _RW(CLOCK_APLL_VCO_DIS,         2,  1, REG_CP_PLL_VCO_DIS ),
    _RW(CLOCK_MPLL_VCO_DIS,         1,  1, REG_CP_PLL_VCO_DIS ),

    _RO(CLOCK_RESOURCE_ENUM_END,    0,  0, 0                  ), // END
};

//------------------------------------------------------------------------------
// CE4200 B0 Resources (CE4200 A0 + fields in CP_ASYNC_AU_CTRL1, CP_ASYNC_AU_CTRL2)
//------------------------------------------------------------------------------
static cc_resource_info_t resources_ce4200_B0[] =
{
    _RW(CLOCK_PCIE0_CLK_OUT_DIS,   26,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_PCIE1_CLK_OUT_DIS,   25,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_PLL_DIV_RST,    24,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_TMDS_CLK_EN,    22,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_PLL_RESET,      20,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_AVPLL_DDS_SEL,       17,  1, REG_CP_CNTL_STS    ),
    _RO(CLOCK_STATUS_MEM_SPEED,    14,  3, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_COLOR_DEPTH,    11,  2, REG_CP_CNTL_STS    ),
    _RW(CLOCK_HDMI_SRC_SEL,         9,  2, REG_CP_CNTL_STS    ),
    _RO(CLOCK_USB_RESET_DONE,       7,  1, REG_CP_CNTL_STS    ),
    _RW(CLOCK_RESET_OUT_CNTL,       6,  1, REG_CP_CNTL_STS    ),
    _RO(CLOCK_FSB_SPEED,            1,  2, REG_CP_CNTL_STS    ),

    _RW(CLOCK_MCLK_OUT_EN,         18,  4, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_AU_CLK_SELECT,       10,  3, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_PXL_INT_CLK_SEL,      7,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_HDMI_148P35_EN,       6,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_DB_CLK_EN,        5,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_DA_CLK_EN,        4,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_MDVO_CLK_EN,      3,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_DA_CFG,           2,  1, REG_CP_VDC_CLK_CTRL),
    _RW(CLOCK_VDC_MDVO_CFG,         1,  2, REG_CP_VDC_CLK_CTRL),

    _RW(CLOCK_IR_RST,              31,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GFX2D_RST,           30,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_PCIE_RST,            29,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_H264VE_RST,          28,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DFX_RST,             27,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_DSP1_RST,         26,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_DSP0_RST,         25,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_AU_IF_RST,           24,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_HDVCAP_RST,          22,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DEMUX_RST,           21,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_DPE_RST,             20,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GFX_RST,             19,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GBLVSPARC_RST,       18,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_HDMI_RST,            17,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_PF_RST,              16,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_MFD_RST,             15,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_TSD_RST,             14,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_VDC_RST,             13,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_NAND_RST,            12,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_SEC_RST,             11,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_USB_RST_CFG,          8,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_USB_RST_SW,           7,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_HDMI_I2C_RST,         6,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_GBE_RST,              5,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_SATA_RST,             4,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_USB_RST,              3,  1, REG_CP_UNIT_RST    ),
    _RW(CLOCK_CRU_RST,              1,  1, REG_CP_UNIT_RST    ),

    _RO(CLOCK_VDAC_CAL_EN,         14, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_FSB_DFX,             13, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HDMI_PLL_SFR_BYPASS, 12, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HDMI_PLL_SOURCE_SEL, 11, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_MPLL_BYP_SOURCE_SEL, 10, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_IA_BYP_SOURCE_SEL,    9, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HPLL_BYP_SOURCE_SEL,  8, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_SEC_BOOT,             7, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HFPLL_SEL,            6, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_HFPLL_EN,             5, 1, REG_CP_STRAP_STS_0 ),
    _RO(CLOCK_CEFDK_BIOS_ID,        4, 5, REG_CP_STRAP_STS_0 ),

    _RO(CLOCK_RST_OUT_CFG,         15, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_EXP_BOOT_ACCEL_DIS,  14, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_NAND_EN,             13, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_GBE_CLK_SRC_SEL,     12, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_NAND_NUM_ADDR_CYC,   11, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_NAND_BOOT,           10, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_BOOT_WIDTH,           9, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_DDR_SPEED,            8, 3, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_FSB_OVERRIDE,         5, 1, REG_CP_STRAP_STS_1 ),
    _RO(CLOCK_FSB_RATIO_SEL,        3, 4, REG_CP_STRAP_STS_1 ),

    _RO(CLOCK_PUNIT_STRAP5,        21, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PUNIT_STRAP4,        20, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PUNIT_STRAP3,        19, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PUNIT_STRAP2,        18, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PUNIT_STRAP1,        17, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PUNIT_STRAP0,        16, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_OEM_DEBUG,           13, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_INTEL_MANUFACTURING, 12, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_AVPLL_REF_CLK_SEL,   11, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_PCIE_REF_CLK_SEL,    10, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_SATA_REF_CLK_SEL,     9, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_USB_REF_CLK_SEL,      8, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_DPLL_BYP_SRC_SEL,     3, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_APLL_BYP_SRC_SEL,     2, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_FPLL_MON_EN,          1, 1, REG_CP_STRAP_STS_2 ),
    _RO(CLOCK_JTAG_IO_HI_LO,        0, 1, REG_CP_STRAP_STS_2 ),

    _RW(CLOCK_SSKPD,               31, 32, REG_CP_SSKPD       ),

    _RW(CLOCK_PXP_INV,             29,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_GBE_CLK_INV,         28,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA0RXCLK_INV,      27,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA0TXCLK_INV,      26,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA1RXCLK_INV,      25,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA1TXCLK_INV,      24,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_HDMI_TMDS_INV,       23,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DDR2X_INV,           20,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DDR1X_INV,           19,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_PMU_INV,             18,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_NAND_INV,            17,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DDS_HREF_INV,        16,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DEF640_INV,          15,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DPE_INV,             14,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_VDC_INV,             13,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SEC_INV,             12,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_MFD_INV,             11,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DSP_INV,             10,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_GFX_INV,              9,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_PBB_INV,              8,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_FSB4X_INV,            7,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_FSB_INV,              6,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_APB_INV,              5,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_SATA_INV,             4,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_I2C_INV,              3,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_AHB_INV,              2,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_DMX_INV,              1,  1, REG_CP_CLK_INV     ),
    _RW(CLOCK_XSI_INV,              0,  1, REG_CP_CLK_INV     ),

    _RW(CLOCK_PLL_START,           31,  1, REG_CP_PLL_ADDR    ),
    _RW(CLOCK_PLL_RW,              29,  1, REG_CP_PLL_ADDR    ),
    _RW(CLOCK_PLL_ADDR,             7,  8, REG_CP_PLL_ADDR    ),

    _RW(CLOCK_PLL_DATA,            31, 32, REG_CP_PLL_DATA    ),

    _RW(CLOCK_CHICKEN,              7,  8, REG_CP_CHICKEN     ),

    _RW(CLOCK_AV_DDS_CTRL,         31, 32, REG_CP_AV_DDS      ),

    _RW(CLOCK_TIMER_DDS_CTRL,      31, 32, REG_CP_TIMER_DDS   ),

    _RW(CLOCK_RTC_DDS_CTRL,        31, 32, REG_CP_RTC_DDS     ),

    _RW(CLOCK_VDC_CLK_EN,           31,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_MCU_CLK_EN,           30,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_VDC_XSI_CLK_EN,       29,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_USB_CLK480_EN,        28,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_USB_XSI_CLK_EN,       27,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_PREFILTER_XSI_ELK_EN, 26,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_AU_XSI_CLK_EN,        25,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_ODLA_CLK_EN,          24,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_HDVCAP_CLK_EN,        23,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_DEMUX_XSI_CLK_EN,     22,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_TSD_CLK_EN,           21,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_DEMUX_CLK_EN,         20,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_SATA_CLK_EN,          19,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_MSPOD_XSI_CLK_EN,     18,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GBLVSPARC_XSI_CLK_EN, 17,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_RSB_MFD_CLK_EN,       16,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_MPG4_MFD_CLK_EN,      15,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_VC1_MFD_CLK_EN,       14,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_H264_DEF640_CLK_EN,   13,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_S_AU_DSP_CLK_EN,      12,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_L_AU_DSP_CLK_EN,      11,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_DPE_CLK_EN,           10,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_H264VE_CLK_EN,         9,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GFX_CLK_EN,            8,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_PMU_CLK_EN,            7,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_OMAR_CLK_EN,           6,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_RMII_REFCLK_50_CLK_EN, 5,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_PAD_GBE_REF_CLK_EN,    4,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_PAD_GBE_IN_CLK_EN,     3,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GBE_XSI_CLK_EN,        2,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GBE_HCLK_EN,           1,  1, REG_CP_CLK_GATE0   ),
    _RW(CLOCK_GBE_DDS_HREF_CLK_EN,   0,  1, REG_CP_CLK_GATE0   ),

    _RW(CLOCK_RXCLKDEL1,           25,  1, REG_CP_CLK_GATE1   ),
    _RW(CLOCK_RXCLKDEL0,           24,  1, REG_CP_CLK_GATE1   ),
    _RW(CLOCK_REFCLKDEL1,          21,  1, REG_CP_CLK_GATE1   ),
    _RW(CLOCK_REFCLKDEL0,          20,  1, REG_CP_CLK_GATE1   ),
    _RW(CLOCK_DATADEL1,            17,  1, REG_CP_CLK_GATE1   ),
    _RW(CLOCK_DATADEL0,            16,  1, REG_CP_CLK_GATE1   ),
    _RW(CLOCK_GFX2D_CLK_EN,         4,  1, REG_CP_CLK_GATE1   ),
    _RW(CLOCK_MEU_CLK_EN,           2,  1, REG_CP_CLK_GATE1   ),
    _RW(CLOCK_PCIE_LGCLK_EN,        1,  1, REG_CP_CLK_GATE1   ),
    _RW(CLOCK_PCIE_BBCLK_EN,        0,  1, REG_CP_CLK_GATE1   ),

    _RW(CLOCK_ASYNC_EN,            31,  1, CP_ASYNC_AU_CTRL1  ),
    _RW(CLOCK_APLL_BYPEN,          30,  1, CP_ASYNC_AU_CTRL1  ),
    _RW(CLOCK_APLL_NDIV,           19,  6, CP_ASYNC_AU_CTRL1  ),
    _RW(CLOCK_APLL_FBP2DIV,        13,  6, CP_ASYNC_AU_CTRL1  ),
    _RW(CLOCK_AVPLL_FBP1DIV,        7,  8, CP_ASYNC_AU_CTRL1  ),

    _RW(CLOCK_APLL_P2DIV,          17, 10, CP_ASYNC_AU_CTRL2  ),
    _RW(CLOCK_AVPLL_P1DIV,          7,  8, CP_ASYNC_AU_CTRL2  ),

    _RW(CLOCK_VDC_CLK_FRQ_CHG,     15,  1, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_DSP_CLK_FRQ_CHG,     14,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_DPE_CLK_FRQ_CHG,     11,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_MFD_CLK_FRQ_CHG,      8,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_DEF640_CLK_FRQ_CHG,   5,  3, REG_CP_FREQ_SEL    ),
    _RW(CLOCK_GFX_CLK_FRQ_CHG,      2,  3, REG_CP_FREQ_SEL    ),

    _RW(CLOCK_HDMI_VCO_DIS,         4,  1, REG_CP_PLL_VCO_DIS ),
    _RW(CLOCK_DPLL_VCO_DIS,         3,  1, REG_CP_PLL_VCO_DIS ),
    _RW(CLOCK_APLL_VCO_DIS,         2,  1, REG_CP_PLL_VCO_DIS ),
    _RW(CLOCK_MPLL_VCO_DIS,         1,  1, REG_CP_PLL_VCO_DIS ),

    _RO(CLOCK_RESOURCE_ENUM_END,    0,  0, 0                  ), // END
};

//------------------------------------------------------------------------------
// CE5300 A0 Resources 
//------------------------------------------------------------------------------
static cc_resource_info_t resources_ce5300_A0[] =
{
    _RW(CLOCK_PCIE_PLL_EXT_REF_CLKBUFEN,     10,  1, REG_PCI_EX_CLK_CNTL      ),
    _RW(CLOCK_PCIE_PLL_INT_REF_CLKBUFEN,      9,  1, REG_PCI_EX_CLK_CNTL      ),
    _RW(CLOCK_BBRST_B,                        8,  1, REG_PCI_EX_CLK_CNTL      ),
    _RW(CLOCK_SBI_BB_RST_B,                   7,  1, REG_PCI_EX_CLK_CNTL      ),
    _RW(CLOCK_SBI_100_RST_CORE_B,             6,  1, REG_PCI_EX_CLK_CNTL      ),
    _RW(CLOCK_PCIE_PHY_CMN_RESET,             5,  1, REG_PCI_EX_CLK_CNTL      ),
    _RW(CLOCK_PCIE_BBCLK_EN,                  4,  1, REG_PCI_EX_CLK_CNTL      ),
    _RW(CLOCK_PCIE_IGCLK_EN,                  3,  1, REG_PCI_EX_CLK_CNTL      ),
    _RW(CLOCK_PCIE_PHY_CRI_CLK_SEL,           2,  1, REG_PCI_EX_CLK_CNTL      ),

    _RW(CLOCK_HDMI_PLL_DIV_RESET,             9,  1, REG_HDMI_TX_CLK_CNTL     ),
    _RW(CLOCK_HDMI_TX_PLL_RESET,              7,  1, REG_HDMI_TX_CLK_CNTL     ),
    _RW(CLOCK_HDMI_TX_RST,                    1,  1, REG_HDMI_TX_CLK_CNTL     ),
    _RW(CLOCK_HDMI_I2C_RESET,                 0,  1, REG_HDMI_TX_CLK_CNTL     ),

    _RW(CLOCK_HDMI_RX_I2C_RESET,              8,  1, REG_HDMI_RX_CLK_CNTL     ),
    _RW(CLOCK_HDMI_RX_PLL_DIV_RESET,          7,  1, REG_HDMI_RX_CLK_CNTL     ),
    _RW(CLOCK_HDMI_RX_PLL_RESET,              6,  1, REG_HDMI_RX_CLK_CNTL     ),
    _RW(CLOCK_HDMI_RX_CORE_CLK_EN,            5,  1, REG_HDMI_RX_CLK_CNTL     ),
    _RW(CLOCK_HDMI_RX_CORE_CLK_FREQ,          4,  4, REG_HDMI_RX_CLK_CNTL     ),
    _RW(CLOCK_HDMI_RX_RST,                    0,  1, REG_HDMI_RX_CLK_CNTL     ),

    _RW(CLOCK_DSP_1_SRAM_CLK_GATE_BYPASS,    15,  1, REG_AUDIO_DSP_CLK_CNTL   ),
    _RW(CLOCK_DSP_0_SRAM_CLK_GATE_BYPASS,    14,  1, REG_AUDIO_DSP_CLK_CNTL   ),
    _RW(CLOCK_AU_DSP1_CLK_EN,                13,  1, REG_AUDIO_DSP_CLK_CNTL   ),
    _RW(CLOCK_AU_DSP0_CLK_EN,                12,  1, REG_AUDIO_DSP_CLK_CNTL   ),
    _RW(CLOCK_DSP1_CLK_FRQ,                  11,  5, REG_AUDIO_DSP_CLK_CNTL   ),
    _RW(CLOCK_DSP0_CLK_FRQ,                   6,  5, REG_AUDIO_DSP_CLK_CNTL   ),
    _RW(CLOCK_AU_DSP1_RST,                    1,  1, REG_AUDIO_DSP_CLK_CNTL   ),
    _RW(CLOCK_AU_DSP0_RST,                    0,  1, REG_AUDIO_DSP_CLK_CNTL   ),

    _RW(CLOCK_ADAC_RESET,                     4,  1, REG_AUDIO_IF_CLK_CNTL    ),
    _RW(CLOCK_MCLK1_OUT_EN,                   3,  1, REG_AUDIO_IF_CLK_CNTL    ),
    _RW(CLOCK_MCLK0_OUT_EN,                   2,  1, REG_AUDIO_IF_CLK_CNTL    ),
    _RW(CLOCK_AU_XSI_CLK_EN,                  1,  1, REG_AUDIO_IF_CLK_CNTL    ),
    _RW(CLOCK_AU_IF_RST,                      0,  1, REG_AUDIO_IF_CLK_CNTL    ),

    _RW(CLOCK_VDC_SRAM_CLK_GATE_BYPASS,      15,  1, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_VDC_SUB_UNIT_CLK_GATE_BYPASS,  14,  1, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_LVDS_CLK_EN,                   13,  1, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_HDVCAP_TS_SEL,                 12,  1, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_VMASTER_DDS_SEL,               11,  1, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_VDC_DB_CLK_EN,                  9,  1, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_VDC_DA_CLK_EN,                  8,  1, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_VDC_MDVO_CLK_EN,                7,  1, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_VDC_XSI_CLK_EN,                 6,  1, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_VDC_CLK_EN,                     5,  1, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_VDC_CLK_FRQ,                    4,  4, REG_VDC_CLK_CNTL         ),
    _RW(CLOCK_VDC_RST,                        0,  1, REG_VDC_CLK_CNTL         ),

    _RW(CLOCK_DPE_SRAM_CLK_GATE_BYPASS,       7,  1, REG_DPE_CLK_CNTL         ),
    _RW(CLOCK_DPE_SUB_UNIT_CLK_GATE_BYPASS,   6,  1, REG_DPE_CLK_CNTL         ),
    _RW(CLOCK_DPE_CLK_EN,                     5,  1, REG_DPE_CLK_CNTL         ),
    _RW(CLOCK_DPE_CLK_FRQ,                    4,  4, REG_DPE_CLK_CNTL         ),
    _RW(CLOCK_DPE_RST,                        0,  1, REG_DPE_CLK_CNTL         ),

    _RW(CLOCK_VC1VDP_SRAM_CLK_GATE_BYPASS,   27,  1, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_MFVDP_SUBUNIT_CLK_GATE_BYPASS, 26,  1, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_MPG2VDP_CLK_EN,                25,  1, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_MFD_RSB_CLK_EN,                24,  1, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_MFVDP_CLK_EN,                  23,  1, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_VC1VDP_CLK_EN,                 22,  1, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_H264_DEF640_CLK_EN,            21,  1, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_H264_DEF640_CLK_FRQ,           20,  4, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_VC1VDP_CLK_FRQ,                16,  4, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_MPG2VDP_CLK_FRQ,               12,  4, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_MFVDP_CLK_FRQ,                  8,  4, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_H264DEC_RST,                    3,  1, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_VC1VDP_RST,                     2,  1, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_MPG2VDP_RST,                    1,  1, REG_MFD_CLK_CNTL         ),
    _RW(CLOCK_MFVDP_RST,                      0,  1, REG_MFD_CLK_CNTL         ),

    _RW(CLOCK_H264VE_CLK_EN,                  5,  1, REG_H264ENC_CLK_CNTL     ),
    _RW(CLOCK_H264VE_CLK_FRQ,                 4,  4, REG_H264ENC_CLK_CNTL     ),
    _RW(CLOCK_H264VE_RST,                     0,  1, REG_H264ENC_CLK_CNTL     ),

    _RW(CLOCK_EPU_CLK_EN,                     1,  1, REG_SCD_CLK_CNTL         ),
    _RW(CLOCK_EPU_RST,                        0,  1, REG_SCD_CLK_CNTL         ),

    _RW(CLOCK_SGX_SRAM_CLK_GATE_BYPASS,       2,  1, REG_SGX_CLK_CNTL         ),
    _RW(CLOCK_SGX_CLK_EN,                     1,  1, REG_SGX_CLK_CNTL         ),
    _RW(CLOCK_SGX_RST,                        0,  1, REG_SGX_CLK_CNTL         ),

    _RW(CLOCK_GFX_2D_CLK_EN,                  6,  1, REG_GFX2D_CLK_CNTL       ),
    _RW(CLOCK_GFX_2D_RST,                     0,  1, REG_GFX2D_CLK_CNTL       ),

    _RW(CLOCK_GBE_SRAM_CLK_GATE_BYPASS,       8,  1, REG_GBE_CLK_CNTL         ),
    _RW(CLOCK_INT_GBE_REF_CLK_EN,             7,  1, REG_GBE_CLK_CNTL         ),
    _RW(CLOCK_PAD_GBE_REF_CLK_EN,             6,  1, REG_GBE_CLK_CNTL         ),
    _RW(CLOCK_PAD_GBE_IN_CLK_EN,              5,  1, REG_GBE_CLK_CNTL         ),
    _RW(CLOCK_RMII_REFCLK_50_CLK_EN,          4,  1, REG_GBE_CLK_CNTL         ),
    _RW(CLOCK_GBE_XSI_CLK_EN,                 3,  1, REG_GBE_CLK_CNTL         ),
    _RW(CLOCK_GBE_HCLK_EN,                    2,  1, REG_GBE_CLK_CNTL         ),
    _RW(CLOCK_GBE_DDS_HREF_CLK_EN,            1,  1, REG_GBE_CLK_CNTL         ),
    _RW(CLOCK_GBE_RST,                        0,  1, REG_GBE_CLK_CNTL         ),

    _RW(CLOCK_CRU_RST,                        0,  1, REG_CRU_CLK_CNTL         ),

    _RW(CLOCK_USB_WIN_MODE,                   6,  1, REG_USB_CLK_CNTL         ),
    _RW(CLOCK_USB_UTMI_CLK_EN,                4,  1, REG_USB_CLK_CNTL         ),
    _RW(CLOCK_USB_XSI_CLK_EN,                 3,  1, REG_USB_CLK_CNTL         ),
    _RW(CLOCK_USB_PHY_RST,                    1,  1, REG_USB_CLK_CNTL         ),
    _RW(CLOCK_USB_RST,                        0,  1, REG_USB_CLK_CNTL         ),

    _RW(CLOCK_SATA_PLL_REF_CLKBUF_EN,         5,  1, REG_SATA_CLK_CNTL        ),
    _RW(CLOCK_SATA_PHY_CMN_RESET,             4,  1, REG_SATA_CLK_CNTL        ),
    _RW(CLOCK_SATA_PLL_CLK_EN,                3,  1, REG_SATA_CLK_CNTL        ),
    _RW(CLOCK_SATA_PHY_CRI_CLK_SEL,           2,  1, REG_SATA_CLK_CNTL        ),
    _RW(CLOCK_SATA_CLK_EN,                    1,  1, REG_SATA_CLK_CNTL        ),
    _RW(CLOCK_SATA_RST,                       0,  1, REG_SATA_CLK_CNTL        ),

    _RW(CLOCK_TSD_SRAM_CLK_GATE_BYPASS,       7,  1, REG_TS_CLK_CNTL          ),
    _RW(CLOCK_TSD_SUB_UNIT_CLK_GATE_BYPASS,   6,  1, REG_TS_CLK_CNTL          ),
    _RW(CLOCK_TSD_CLK_EN,                     5,  1, REG_TS_CLK_CNTL          ),
    _RW(CLOCK_TSD_CLK_FRQ,                    4,  4, REG_TS_CLK_CNTL          ),
    _RW(CLOCK_TSD_RST,                        0,  1, REG_TS_CLK_CNTL          ),

    _RW(CLOCK_PREFILTER_XSI_CLK_EN,           1,  1, REG_PF_CLK_CNTL          ),
    _RW(CLOCK_PF_RST,                         0,  1, REG_PF_CLK_CNTL          ),

    _RW(CLOCK_SEC_SRAM_CLK_GATE_BYPASS,       6,  1, REG_SEC_CLK_CNTL         ),
    _RW(CLOCK_SEC_CLK_EN,                     5,  1, REG_SEC_CLK_CNTL         ),
    _RW(CLOCK_SEC_CLK_FRQ,                    4,  4, REG_SEC_CLK_CNTL         ),
    _RW(CLOCK_SEC_RST,                        0,  1, REG_SEC_CLK_CNTL         ),

    _RW(CLOCK_MEU_CLK_EN,                     5,  1, REG_MEU_CLK_CNTL         ),
    _RW(CLOCK_MEU_CLK_FRQ,                    4,  4, REG_MEU_CLK_CNTL         ),

    _RW(CLOCK_MSPOD_XSI_CLK_EN,               1,  1, REG_MSPOD_CLK_CNTL       ),
    _RW(CLOCK_MSPOD_RST,                      0,  1, REG_MSPOD_CLK_CNTL       ),

    _RW(CLOCK_HDVCAP_CLK_EN,                  1,  1, REG_HDVCAP_CLK_CNTL      ),
    _RW(CLOCK_HDVCAP_RST,                     0,  1, REG_HDVCAP_CLK_CNTL      ),

    _RW(CLOCK_DFX_RESET,                      3,  1, REG_DFX_CLK_CNTL         ),

    _RW(CLOCK_MCU_SUB_UNIT_CLK_GATE_BYPASS,  31,  1, REG_GLOBAL_CLK_CNTL      ),
    _RW(CLOCK_CLK_27MHZ_OUT_EN,              30,  1, REG_GLOBAL_CLK_CNTL      ),
    _RW(CLOCK_CLK_27MHZ_SRC_SEL ,            29,  1, REG_GLOBAL_CLK_CNTL      ),
    _RW(CLOCK_PSF_RESET,                     28,  6, REG_GLOBAL_CLK_CNTL      ),
    _RW(CLOCK_SIDEBAND_ROUTER_RESET,         22,  7, REG_GLOBAL_CLK_CNTL      ),
    _RW(CLOCK_AHB_CLK_FRQ,                   15,  4, REG_GLOBAL_CLK_CNTL      ),
    _RW(CLOCK_HCLK_FRQ,                      11,  4, REG_GLOBAL_CLK_CNTL      ),
    _RW(CLOCK_IOSF_CLK_FRQ,                   7,  4, REG_GLOBAL_CLK_CNTL      ),
    _RW(CLOCK_XSI_CLK_FRQ,                    3,  4, REG_GLOBAL_CLK_CNTL      ),

    _RO(CLOCK_OEM_DEBUG,                     21,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_INTEL_MANUFACTURING,           20,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_FSB_OBS_MODE,                  19,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_BOOT_PATH,                     18,  2, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_HPLL_BYP_SOURCE_SEL,           16,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_DPLL_BYP_SOURCE_SEL,           15,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_APLL_BYP_SOURCE_SEL,           14,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_HDMITX_BYP_SOURCE_SEL,         13,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_FPLL_MON_EN,                   12,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_FPLL_VALID_ALT,                11,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_DET_TEST_MODE,                 10,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_ISCLK_BYP_STRAP,                9,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_SFR_VSRC_SEL_HDMI_TX,           8,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_SFR_VSRC_SEL_HDMI_RX,           7,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_SFR_VSRC_SEL,                   6,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_SEC_BOOT,                       5,  1, REG_CP_STRAPS_STS0       ),
    _RO(CLOCK_CEFDK_BIOS_ID,                  4,  5, REG_CP_STRAPS_STS0       ),

    _RO(CLOCK_VID_MODE,                      14,  1, REG_CP_STRAPS_STS1       ),
    _RO(CLOCK_RESET_OUT_CTRL,                13,  1, REG_CP_STRAPS_STS1       ),
    _RO(CLOCK_PCIE_LANE_REV,                 12,  1, REG_CP_STRAPS_STS1       ),
    _RO(CLOCK_PCIE_PORT_CFG,                 11,  1, REG_CP_STRAPS_STS1       ),
    _RO(CLOCK_BOOT_ACCELERATION,             10,  1, REG_CP_STRAPS_STS1       ),
    _RO(CLOCK_RGMII_CLK_SRC_SEL,              9,  1, REG_CP_STRAPS_STS1       ),
    _RO(CLOCK_RMII_CLK_SRC_SEL,               8,  1, REG_CP_STRAPS_STS1       ),
    _RO(CLOCK_DDR_SPEED,                      7,  3, REG_CP_STRAPS_STS1       ),
    _RO(CLOCK_BOOT_WIDTH,                     4,  1, REG_CP_STRAPS_STS1       ),
    _RO(CLOCK_FSB_RATIO_SEL,                  3,  4, REG_CP_STRAPS_STS1       ),

    _RW(CLOCK_SSKPD,                         31, 32, REG_CP_SSKPD_GEN5        ),

    _RW(CLOCK_CP_CHICKEN,                     7,  8, REG_CP_CHICKEN_GEN5      ),

    _RW(CLOCK_AV_DDS_CTRL,                   31, 32, REG_CP_AV_DDS_CNTL       ),

    _RW(CLOCK_TIMER_DDS_CTRL,                31, 32, REG_CP_TIMER_DDS_CNTL    ),

    _RW(CLOCK_RTC_DDS_CTRL,                  31, 32, REG_RTC_DDS_CNTL         ),

    _RW(CLOCK_GVT_SRAM_CLK_GATE_BYPASS,       6,  1, REG_GLOBAL_VSPARC0_CNTL  ),
    _RW(CLOCK_GVT_CLK_FRQ,                    5,  4, REG_GLOBAL_VSPARC0_CNTL  ),
    _RW(CLOCK_GVT_CLK_EN,                     1,  1, REG_GLOBAL_VSPARC0_CNTL  ),
    _RW(CLOCK_GVT_VSPARC_RST,                 0,  1, REG_GLOBAL_VSPARC0_CNTL  ),

    _RW(CLOCK_GVD_SRAM_CLK_GATE_BYPASS,       6,  1, REG_GLOBAL_VSPARC1_CNTL  ),
    _RW(CLOCK_GVD_CLK_FREQ,                   5,  4, REG_GLOBAL_VSPARC1_CNTL  ),
    _RW(CLOCK_GVD_CLK_EN,                     1,  1, REG_GLOBAL_VSPARC1_CNTL  ),
    _RW(CLOCK_GVD_VSPARC_RST,                 0,  1, REG_GLOBAL_VSPARC1_CNTL  ),

    _RW(CLOCK_APLL_DIV_RST,                   5,  1, REG_PLL_RESET            ),
    _RW(CLOCK_APLL_VCO_RST,                   4,  1, REG_PLL_RESET            ),
    _RW(CLOCK_DPLL_DIV_RST,                   3,  1, REG_PLL_RESET            ),
    _RW(CLOCK_DPLL_VCO_RST,                   2,  1, REG_PLL_RESET            ),

    _RW(CLOCK_PWR_ISLAND9_CLK_EN,             9,  1, REG_POWER_ISLAND_CLK_GATE),
    _RW(CLOCK_PWR_ISLAND8_CLK_EN,             8,  1, REG_POWER_ISLAND_CLK_GATE),
    _RW(CLOCK_PWR_ISLAND7_CLK_EN,             7,  1, REG_POWER_ISLAND_CLK_GATE),
    _RW(CLOCK_PWR_ISLAND6_CLK_EN,             6,  1, REG_POWER_ISLAND_CLK_GATE),
    _RW(CLOCK_PWR_ISLAND5_CLK_EN,             5,  1, REG_POWER_ISLAND_CLK_GATE),
    _RW(CLOCK_PWR_ISLAND4_CLK_EN,             4,  1, REG_POWER_ISLAND_CLK_GATE),
    _RW(CLOCK_PWR_ISLAND3_CLK_EN,             3,  1, REG_POWER_ISLAND_CLK_GATE),
    _RW(CLOCK_PWR_ISLAND2_CLK_EN,             2,  1, REG_POWER_ISLAND_CLK_GATE),

    _RW(CLOCK_PWR_ISLAND10_RESET,            10,  1, REG_POWER_ISLAND_RESET   ),
    _RW(CLOCK_PWR_ISLAND9_RESET,              9,  1, REG_POWER_ISLAND_RESET   ),
    _RW(CLOCK_PWR_ISLAND8_RESET,              8,  1, REG_POWER_ISLAND_RESET   ),
    _RW(CLOCK_PWR_ISLAND7_RESET,              7,  1, REG_POWER_ISLAND_RESET   ),
    _RW(CLOCK_PWR_ISLAND6_RESET,              6,  1, REG_POWER_ISLAND_RESET   ),
    _RW(CLOCK_PWR_ISLAND5_RESET,              5,  1, REG_POWER_ISLAND_RESET   ),
    _RW(CLOCK_PWR_ISLAND4_RESET,              4,  1, REG_POWER_ISLAND_RESET   ),
    _RW(CLOCK_PWR_ISLAND3_RESET,              3,  1, REG_POWER_ISLAND_RESET   ),
    _RW(CLOCK_PWR_ISLAND2_RESET,              2,  1, REG_POWER_ISLAND_RESET   ),
};


//------------------------------------------------------------------------------
// Find a resource in a pool of resources
//------------------------------------------------------------------------------
cc_resource_info_t * find_resource( clock_control_resource_t id,
                                    cc_resource_info_t *     pool)
{

    while(pool->id != CLOCK_RESOURCE_ENUM_END && pool->id != id)
    {
        pool++;
    }
    return (pool->id == id) ? pool : NULL;
}


//-----------------------------------------------------------------------------
// Generic resource access routine
//-----------------------------------------------------------------------------
static
clock_control_ret_t _cc_access_resource(unsigned int               version,
                                        clock_control_resource_t   resource,
                                        unsigned int             * value,
                                        clock_control_bool_t       read_flag,
                                        clock_control_bool_t       block_flag)
{
    cc_resource_info_t *res = NULL;
    clock_control_ret_t rc  = CLOCK_RET_OK;
    unsigned int        temp, mask;

    // Non-zero => resource is external to SOC, accessed via I2C
    int  is_external = resource & CLOCK_EXTERNAL;

    // Check version
    if (CC_VERSION != version)
    {
        PRINT_ERROR("Version mismatch\n");
        rc = CLOCK_ERROR_API_MODULE_VERSION_MISMATCH;
        goto end;
    }

    // Check buffer pointer
    if (!value)
    {
        PRINT_ERROR("%s buffer is NULL\n", read_flag ? "Output" : "Input");
        rc = CLOCK_ERROR_POINTER_NULL;
        goto end;
    }

    // Get info on requested resource
    res = find_resource(resource, is_external ? external_clock_resources
                                              : g_resources);
    if (res == NULL)
    {
        PRINT_ERROR("Requested resource [%d] not found\n", resource);
        rc = CLOCK_ERROR_INVALID_RESOURCE;
        goto end;
    }

    // Print request info [if necessary]
    if (debug && !read_flag)
    {
        PRINT("W 0x%.8x => %s\n", *value, res->name);
    }

    // Verify if read is allowed from this location
    if( read_flag && !(res->access & READ_OK) )
    {
        PRINT_ERROR("Attempt to read a write only resource\n");
        rc = CLOCK_ERROR_INVALID_READ_WRITE;
        goto end;
    }

    // Verify if write is allowed to this location
    if( !read_flag && !(res->access & WRITE_OK) )
    {
        PRINT_ERROR("Attempt to write a read only resource\n");
        rc = CLOCK_ERROR_INVALID_READ_WRITE;
        goto end;
    }

    mask = 0xFFFFFFFF >> (32 - res->numbits);

    // If this is a write, ensure that the passed in value is within range.
    // Mask currently contains the maximum value for the bit field.
    if ((read_flag == CLOCK_FALSE) && (*value > mask) )
    {
        PRINT_ERROR("Value to write is out of range\n");
        rc = CLOCK_ERROR_VALUE_OUT_OF_RANGE;
        goto end;
    }

    // Shift the mask into the right bit position
    mask <<= (res->bitpos+1)-res->numbits;

    if (block_flag)
    {
        // Lock resource, blocking until available if necessary
        os_sema_get(&g_lock);
    }
    else
    {
        // Lock resource, fail if it's not immediately available
        if (os_sema_tryget(&g_lock) != 0)
        {
            rc = CLOCK_BUSY;
            goto end;
        }
    }

    if (is_external)
    {
        if ( CLOCK_RET_OK != external_clock_access(res, read_flag, value, mask))
        {
            goto unlock;
        }
    }
    else
    {
        // Read the register
        temp = ior(g_io_handle, (unsigned int)g_io_handle, res->address);

        if (read_flag)
        {
            // Return bit(s)
            *value = (temp & mask) >> (res->bitpos+1-res->numbits);
        }
        else
        {
            // Write bit(s)
            temp = (temp & ~mask) | (*value << (res->bitpos+1-res->numbits));
            iow(g_io_handle, (unsigned int)g_io_handle, res->address, temp);
        }
    }

    // Print request info [if necessary]
    if (debug && read_flag)
    {
        PRINT("R 0x%.8x <= %s\n", *value, res->name);
    }

unlock:
    os_sema_put(&g_lock);

end:
    return rc;
}

//-----------------------------------------------------------------------------
// Ioctl handler
//-----------------------------------------------------------------------------
static long cc_ioctl(struct file   *filep, // Ignored
                     unsigned int   cmd,   // Library version
                     unsigned long  arg  ) // User space request data address 
{
    clock_control_ret_t   rc = CLOCK_RET_OK;
    clock_control_ioctl_t info;

    // Check version
    if(cmd != CC_VERSION)
    {
        PRINT_ERROR("Library/Module version mismatch\n");
        rc = CLOCK_ERROR_API_MODULE_VERSION_MISMATCH;
        goto end;
    }

    // Make a copy of the Ioctl structure from userspace
    if(copy_from_user(&info, (void*)arg, sizeof(clock_control_ioctl_t)))
    {
        PRINT_ERROR("Copy from user space failed\n");
        rc = CLOCK_ERROR_IOCTL_FAILED;
        goto end;
    }

    // Call the function to get/set the required bit field
    rc = _cc_access_resource(   cmd,
                                info.Resource,
                                &info.Value,
                                info.Read_Flag,
                                info.Block_Flag);

    // Copy the value back to user space
    if(copy_to_user((void*)arg, &info, sizeof(clock_control_ioctl_t)))
    {
        PRINT_ERROR("Copy to user space failed\n");
        rc = CLOCK_ERROR_IOCTL_FAILED;
        goto end;
    }

end:
    return rc;
}

//----------------------------------------------------------------------------
// Standard linux file operations
//----------------------------------------------------------------------------
static struct file_operations fops =
{
    owner:          THIS_MODULE,
    unlocked_ioctl: cc_ioctl,
};

//------------------------------------------------------------------------------
// Wrapper of OSAL memory mapping macro
//------------------------------------------------------------------------------
static void * local_mmap(unsigned int phys_addr, unsigned int size)
{
    return OS_MAP_IO_TO_MEM_NOCACHE(phys_addr, size);
}

//------------------------------------------------------------------------------
// Wrapper of OSAL memory unmapping macro
//------------------------------------------------------------------------------
static void local_munmap(void * virt_addr, unsigned int size)
{
    OS_UNMAP_IO_FROM_MEM(virt_addr, size);
}


//-----------------------------------------------------------------------------
// Module initilization function called when the kernel module is inserted.
//-----------------------------------------------------------------------------
static int __init cc_init(void)
{
    int             rc         = -ENODEV;  // Assume failure
    unsigned int    BAR        = 0;
    os_pci_dev_t    cc_dev     = NULL;

    // Register the Clock Control device
    if ((g_major = register_chrdev(0, CLOCK_KERNEL_MODULE_NAME, &fops)) < 0)
    {
        PRINT_ERROR("Unable to register device\n");
        goto end;
    }

    if (OSAL_SUCCESS != os_pci_find_first_device(CC_VENDOR_ID,
                                                 CC_DEVICE_ID,
                                                 &cc_dev))
    {
        PRINT_ERROR("Couldn't find PCI device\n");
        goto end;
    }

    if (OSAL_SUCCESS != os_pci_read_config_8(cc_dev, 8, &revision))
    {
        PRINT_ERROR("Couldn't read clock device revision id\n");
        goto end;
    }

    if ( ! external_clock_init(debug) )
    {
        // Error has already been emitted
        goto end;
    }

    // Choose resource list based on HW device revision
    switch (revision)
    {
    case CC_PCI_REV_CE3100:
        {
            // CE4100 A0, which is no longer supported, had incorrect rev id:
            // 0, same as CE3100.  Check the chip ID to make sure this is not
            // one of those.  
            pal_soc_info_t  soc_info;
            if (PAL_SUCCESS != pal_get_soc_info(&soc_info))
            {
                PRINT_ERROR("Unable to retrieve SOC info from PAL\n");
                goto end;
            }
            if (soc_info.name == SOC_NAME_CE4100)
            {
                PRINT_ERROR("CE4100 A-step is no longer supported\n");
                goto end;
            }
        }
        g_resources = resources_ce3100;
        break;

    case CC_PCI_REV_CE4100_B:  // CE4100 B0/B1
        g_resources = resources_ce4100_B;
        break;

    case CC_PCI_REV_CE4200_A0:
        g_resources = resources_ce4200_A0;
        break;

    case CC_PCI_REV_CE4200_B0:
        g_resources = resources_ce4200_B0;
        break;
    
    case CC_PCI_REV_CE5300_A0:
        g_resources = resources_ce5300_A0;
        break;

    default:
        PRINT_ERROR("Unsupported PCI revision (%d)\n", revision);
        goto end;
    }

    if (OSAL_SUCCESS != os_pci_read_config_32(cc_dev, 16, &BAR))
    {
        PRINT_ERROR("Couldn't read PCI BAR\n");
        goto end;
    }

    if (!(g_io_handle = device_connect(local_mmap, BAR, REGISTERS_LENGTH)))
    {
        PRINT_ERROR("Couldn't map registers\n");
        goto end;
    }

    os_sema_init(&g_lock,1);
    rc = 0;     // SUCCESS

end:
    if (cc_dev)
    {
        os_pci_free_device(cc_dev);
    }

    if (rc != 0)
    {
        if (g_major >= 0)           // Was device registered successfully?
        {
            unregister_chrdev(g_major,CLOCK_KERNEL_MODULE_NAME);
        }
    }

    return rc;
}


//------------------------------------------------------------------------------
// Read Clock Resource API call
//------------------------------------------------------------------------------
clock_control_ret_t _clock_control_read(unsigned int               version,
                                        clock_control_resource_t   resource, 
                                        unsigned int             * value,
                                        clock_control_bool_t       block)
{
    return _cc_access_resource(version, resource, value, CLOCK_TRUE, block);
}


//------------------------------------------------------------------------------
// Write Clock Resource API call
//------------------------------------------------------------------------------
clock_control_ret_t _clock_control_write(unsigned int             version,
                                         clock_control_resource_t resource, 
                                         unsigned int             value,
                                         clock_control_bool_t     block)
{
    return _cc_access_resource(version, resource, &value, CLOCK_FALSE, block);
}


//-----------------------------------------------------------------------------
// Module cleanup function called when removed from the kernel.
//-----------------------------------------------------------------------------
static void __exit cc_cleanup(void)
{
    external_clock_cleanup();
    unregister_chrdev(g_major, CLOCK_KERNEL_MODULE_NAME);
    device_disconnect(g_io_handle, local_munmap, g_io_handle, REGISTERS_LENGTH);
    os_sema_destroy(&g_lock);
}

//----------------------------------------------------------------------------
// Register module init and exit functions
//----------------------------------------------------------------------------
module_init(cc_init);
module_exit(cc_cleanup);
