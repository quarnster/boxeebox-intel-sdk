/*----------------------------------------------------------------------------
 *    BSD LICENSE
 *
 *    Copyright(c) 2007-2011 Intel Corporation. All rights reserved.
 *    All rights reserved.
 *
 *    Redistribution and use in source and binary forms, with or without 
 *    modification, are permitted provided that the following conditions 
 *    are met:
 *
 *      * Redistributions of source code must retain the above copyright 
 *        notice, this list of conditions and the following disclaimer.
 *      * Redistributions in binary form must reproduce the above copyright 
 *        notice, this list of conditions and the following disclaimer in 
 *        the documentation and/or other materials provided with the 
 *        distribution.
 *      * Neither the name of Intel Corporation nor the names of its 
 *        contributors may be used to endorse or promote products derived 
 *        from this software without specific prior written permission.
 *
 *    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *    "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *    LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
 *    A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *    OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *    SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *    LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 *    DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
 *    THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *    (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *    OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *----------------------------------------------------------------------------*/

 //---------------------------------------------------------------------------
 // Clock Control Library file. Manages requests from user space. Marshalls
 // arguments and submits them to the kernel module.
 //---------------------------------------------------------------------------

#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>

#include "clock_control.h"
#include "clock_control_shared_types.h"
#include "clock_control_print.h"


//------------------------------------------------------------------------------
// Generic resource access routine
//------------------------------------------------------------------------------
static
clock_control_ret_t cc_access_resource(unsigned int               version,
                                       clock_control_resource_t   resource,
                                       unsigned int             * value,
                                       clock_control_bool_t       read_flag,
                                       clock_control_bool_t       block_flag)
{
    int                   fd;
    clock_control_ret_t   rc;
    clock_control_ioctl_t ioctl_info;
    char                  error_msg[256];

    // Check version
    if (CC_VERSION != version)
    {
        PRINT_ERROR("Version mismatch\n");
        rc = CLOCK_ERROR_API_MODULE_VERSION_MISMATCH;
        goto end;
    }

    // Make sure input buffer is OK
    if (!value)
    {
        PRINT_ERROR("Null pointer given for input / output buffer\n");
        rc = CLOCK_ERROR_POINTER_NULL;
        goto end;
    }

    // Marshall request data
    ioctl_info.Read_Flag  = read_flag;
    ioctl_info.Block_Flag = block_flag;
    ioctl_info.Resource   = resource;
    ioctl_info.Value      = *value;

    // Open the device node
    fd = open( "/dev/" CLOCK_KERNEL_MODULE_NAME, O_RDONLY);

    // Act depending on the outcome
    if(fd < 0)
    {
        strerror_r(errno, error_msg, sizeof(error_msg));
        PRINT_ERROR("Can't open /dev/%s; %s\n",
                    CLOCK_KERNEL_MODULE_NAME,
                    error_msg);
        rc = CLOCK_ERROR_DEV_NODE_OPEN_FAILED;
    }
    else
    {
        rc = ioctl(fd, version, (unsigned long) &ioctl_info);

        if (rc != CLOCK_RET_OK)
        {
            strerror_r(errno, error_msg, sizeof(error_msg));
            PRINT_ERROR("ioctl failed; %s\n", error_msg);
        }
        else
        {
            *value = ioctl_info.Value;
        }

        // Close the device node
        close(fd);
    }

end:
    return rc;
}

//------------------------------------------------------------------------------
// Read Clock Resource API call
//------------------------------------------------------------------------------
clock_control_ret_t _clock_control_read(unsigned int               version,
                                        clock_control_resource_t   resource, 
                                        unsigned int             * value,
                                        clock_control_bool_t       block)
{
    return cc_access_resource(version, resource, value, CLOCK_TRUE, block);
}

//------------------------------------------------------------------------------
// Write Clock Resource API call
//------------------------------------------------------------------------------
clock_control_ret_t _clock_control_write(unsigned int             version,
                                         clock_control_resource_t resource, 
                                         unsigned int             value,
                                         clock_control_bool_t     block)
{
    return cc_access_resource(version, resource, &value, CLOCK_FALSE, block);
}
