This component supports access to an external clock, as defined in the
platform_config file.  This support creates a dependency on the IDL I2C driver,
which must be loaded first.

An external clock is only needed on CE4100. To build without external clock
support (and eliminate the runtime dependency on idl i2c), comment out the
definition of SUPPORT_EXTERNAL_CLOCK in Makefile.include.
