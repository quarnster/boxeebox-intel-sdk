#!/bin/bash

#  GPL LICENSE SUMMARY
#
#  Copyright(c) 2005-2010 Intel Corporation. All rights reserved.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of version 2 of the GNU General Public License as
#  published by the Free Software Foundation.
#
#  This program is distributed in the hope that it will be useful, but
#  WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
#  The full GNU General Public License is included in this distribution
#  in the file called LICENSE.GPL.
#
#  Contact Information:
#    Intel Corporation
#    2200 Mission College Blvd.
#    Santa Clara, CA  97052

if [ ! -d $BUILD_DEST/kernel ]; then
    mkdir -p $BUILD_DEST/kernel
fi

KERNEL_GIT=${INTEL_SDK_KERNEL_GIT:-ssh://gtv-git.corp.google.com:29418/kernel.git}
KERNEL_DIR=linux-2.6.35
KERNEL_DEV_PACKAGE=${KERNEL_DIR}-dev.tar.gz
KERNEL_HEADER_PACKAGE=${KERNEL_DIR}-header.tar.gz

if [ ! -d ${KERNEL_DIR}/.git ]; then
  git clone -n ${KERNEL_GIT} ${KERNEL_DIR} &&
    (cd $KERNEL_DIR; git checkout ${INTEL_SDK_KERNEL_GIT_BRANCH:-master})
  if [ $? != 0 ]; then
    echo "Error: git clone ${KERNEL_GIT} failed!"
    exit 1
  fi
fi

echo "Compiling kernel..."

if [ "x"$HT_ENABLED == "x1" ]; then
	make -C ${KERNEL_DIR} ${INTEL_SDK_KERNEL_HT_CONFIG:-m4_ht_defconfig} ARCH=i386 || exit 1
else
	make -C ${KERNEL_DIR} ${INTEL_SDK_KERNEL_CONFIG:-m4_defconfig} ARCH=i386 || exit 1
fi
make -C ${KERNEL_DIR} ${SDK_MAKEFLAGS} ARCH=i386 || exit 1

if cmp ${KERNEL_DIR}/arch/x86/boot/bzImage $PWD/bzImage
then
	if [ ! -e $BUILD_DEST/kernel/${KERNEL_HEADER_PACKAGE} ];then
		pushd ${KERNEL_DIR}/usr/include
		echo "Packaging kernel header files..."
		tar --exclude=.svn -czf $BUILD_DEST/kernel/${KERNEL_HEADER_PACKAGE} * || exit 1
		popd
	fi
	if [ ! -e $BUILD_DEST/kernel/${KERNEL_DEV_PACKAGE} ];then
		echo "Packaging kernel dev files..."
		tar --exclude=.svn -czf $BUILD_DEST/kernel/${KERNEL_DEV_PACKAGE} ${KERNEL_DIR} || exit 1
	fi

	if [ ! -d $BUILD_DEST/kernel/${KERNEL_DIR} ];then
		pushd $BUILD_DEST/kernel
		echo "Untar kernel dev files to $BUILD_DEST/kernel , please wait ..."
		tar -xzf ${KERNEL_DEV_PACKAGE} || exit 1
		popd
	fi
else
	cp -f ${KERNEL_DIR}/arch/x86/boot/bzImage $PWD || exit 1
	make -C ${KERNEL_DIR} headers_install || exit 1

	echo "Packaging kernel header files..."
	pushd ${KERNEL_DIR}/usr/include
	tar --exclude=.svn -czf $BUILD_DEST/kernel/${KERNEL_HEADER_PACKAGE} * || exit 1
	popd

	echo "Packaging kernel dev files..."
	tar --exclude=.svn,.git -czf $BUILD_DEST/kernel/${KERNEL_DEV_PACKAGE} ${KERNEL_DIR} || exit 1

	pushd $BUILD_DEST/kernel
	echo "Untar kernel dev files to $BUILD_DEST/kernel , please wait ..."
	tar -xzf ${KERNEL_DEV_PACKAGE} || exit 1
	popd
fi
