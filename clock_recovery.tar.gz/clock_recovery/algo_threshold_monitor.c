/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009  Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009  Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "algo_threshold_monitor.h"
#include "osal.h"
#include "clock_recovery_local_defs.h"
#include "sven_event_type.h"
#include "sven.h"


//#define SELF_TEST
#define ENABLE_SVEN

#ifdef SELF_TEST
#include <stdio.h>
//#include <stdlib.h>
#endif



void softpll_init(
    SoftPLL  *spll )
{
    spll->state = SOFTPLL_FreeRun;
    spll->in_tuple_pos = 0;
    spll->ppm_userdata = NULL;
    spll->error_untrackable = false;
    spll->ppm_saturate = 15;
    spll->clock_locked = false;
}

static void softpll_set_dds_ppm(
    SoftPLL  *spll,
    int              ppm )
{
    if(spll->ppm_userdata == NULL) 
    {
       OS_INFO("Clock Recovery Algo struct handle is NULL\n");
       OS_INFO("Not adjusting the clock. Pls set valid algo using clock_sync_set_algorithm().\n");
    }
    else
    {
       (*spll->set_dds_ppm)( spll->ppm_userdata, ppm  );
    }
}


/* Add a new PCR to the SoftPLL, for tracking.
 */
void softpll_append_sample(
    SoftPLL  *spll,
    int              pcr,
    int              stc )
{
    int                 discontinuity_detected = 0;

    /* Add it */
    spll->in_tuple[ spll->in_tuple_pos ].pcr = pcr; /* high jitter PCR */
    spll->in_tuple[ spll->in_tuple_pos ].stc = stc; /* Wall Clock at PCR capture */
    spll->in_tuple_pos++;


    /* Dump out a SVEN Event with this PCR */
   #ifdef ENABLE_SVEN
    {
      int i,dt;
      /* write out all PCRs and STCs during startup */
      i = spll->in_tuple_pos - 1;
      if ((SOFTPLL_FreeRun == spll->state) || (SOFTPLL_Setup == spll->state) )
         {
            dt = spll->in_tuple[0].pcr - spll->in_tuple[0].stc;
         }
      else
         {
            dt = spll->stc_dt;
         }


       smd_core_send_sven_event(dbg_devh,
                                 SVEN_EV_SMDCore_SoftPLL_PCR_Arrive,
                                 spll->in_tuple[i].pcr,
                                 spll->in_tuple[i].stc,
                                 (spll->in_tuple[i].pcr - dt) - spll->in_tuple[i].stc,
                                 i,
                                 spll->state,
                                 0 );
     }

    #endif

    if ( SOFTPLL_TUPLE_GROUP_SIZE == spll->in_tuple_pos)
    {
        spll->in_tuple_pos = 0;     /* Change state */

        if ( SOFTPLL_FreeRun == spll->state )
        {
            int         i,minpos;
            int         clockd;

            OS_PRINT("\nFree Run");
            /* calculate initial offset */
            minpos = 0;
            /*clockd = First PCR & STC offset */
            clockd = spll->in_tuple[0].pcr - spll->in_tuple[0].stc;

            #ifdef SELF_TEST
            //printf("\n0: [%08x %08x] %d\n", spll->in_tuple[0].pcr, spll->in_tuple[0].stc, clockd );
            #endif

            /* find lowest jitter */
            for ( i = 1; i < SOFTPLL_TUPLE_GROUP_SIZE; i++ )
            {
                int     dt;

                dt = (spll->in_tuple[i].pcr - clockd) -
                      spll->in_tuple[i].stc;

                if ( (dt > SOFTPLL_DISCONTINUITY_THRESHHOLD) ||
                     (dt < -SOFTPLL_DISCONTINUITY_THRESHHOLD) )
                {
                    //OS_PRINT("\n Free run : dt exceeds discontinuity threshold");
                    discontinuity_detected = 1;
                    break;
                }
                else if ( dt < 0 ) /* less than before */
                {
                    /* This will tell, how much the current pair is off compared to the first PCR sample in the 64 sample chunk */
                    clockd += dt;
                    minpos = i;

                    #ifdef SELF_TEST
                    //printf("%d: [%08x %08x] %d **\n", i, spll->in_tuple[i].pcr, spll->in_tuple[i].stc, clockd );
                    #endif
                }
                else
                {
                    #ifdef SELF_TEST
                    //printf("%d: [%08x %08x] %d\n", i, spll->in_tuple[i].pcr, spll->in_tuple[i].stc, dt );
                    #endif
                }
            }

            if ( !discontinuity_detected )
            {
                spll->state = SOFTPLL_Acquiring;
                //OS_PRINT("\n changed to SOFTPLL_Acquiring");
                spll->stc_dt = clockd;

                /* Clock at start */
                spll->start.pcr = spll->in_tuple[minpos].pcr;
                spll->start.stc = spll->in_tuple[minpos].stc;
                spll->start_dpcr = 0;
                spll->start_ppm = SOFTPLL_UNITY_PPM;

                /* State at last clock correction */
                spll->correct.stc = spll->in_tuple[minpos].stc;
                spll->correct_dpcr = 3000;
                spll->correct_ppm = SOFTPLL_UNITY_PPM;

                #ifdef SELF_TEST
                //printf("%d: {%08x %08x} %d\n", minpos, spll->start.pcr, spll->start.stc, spll->stc_dt );
                #endif
            }
         }
        else if ( SOFTPLL_Acquiring == spll->state )
        {
            int         i,minpos,mindpcr, temp;

            /*
             *  ^
             *  |
             * P|
             * C|                            * *
             * R|                           *
             *  |                       *
             * t|                *  *
             * i|           *
             * m|              *
             * e|     *    *
             *  |    *
             *  *
             *  |
             *--+-------------------------------------->
             *  |  (STC at PCR Arrival, zero jitter)
             *  |
             *
             */


            /* calculate initial offset */
            minpos = 0;
            mindpcr = (spll->in_tuple[0].pcr - spll->stc_dt) - spll->in_tuple[0].stc;


            #ifdef SELF_TEST
            //printf("\n0: [%08x %08x] %d\n", spll->in_tuple[0].pcr, spll->in_tuple[0].stc, clockd );
            #endif

            /* find lowest jitter */
            for ( i = 1; i < SOFTPLL_TUPLE_GROUP_SIZE; i++ )
            {
                int     dpcr;

                /* Iteratively find the min PCR-STC difference from the 64 sample (PCR - STC pairs) burst */
                dpcr = (spll->in_tuple[i].pcr - spll->stc_dt) -
                      spll->in_tuple[i].stc;

                if ( (dpcr > SOFTPLL_DISCONTINUITY_THRESHHOLD) ||
                     (dpcr < -SOFTPLL_DISCONTINUITY_THRESHHOLD) )
                {
                    discontinuity_detected = 1;
                    break;
                }
                else if ( abs(dpcr) < abs(mindpcr) ) /* less than before */
                {
                    minpos = i;
                    mindpcr = dpcr;

                    #ifdef SELF_TEST
                    //printf("%d: [%08x %08x] %d **\n", i, spll->in_tuple[i].pcr, spll->in_tuple[i].stc, dpcr );
                    #endif
                }
            }


            /*By now the algo has min PCR-STC difference (mindpcr) for the 64 sample burst */

  //          #ifdef SELF_TEST
//            OS_PRINT("%d\n", mindpcr );
            //#endif

            if ( !discontinuity_detected )
            {
                unsigned long long  dt_since_last_correction;

                    dt_since_last_correction =
                    spll->in_tuple[SOFTPLL_TUPLE_GROUP_SIZE-1].stc -
                    spll->correct.stc;

                #ifdef ENABLE_SVEN
                smd_core_send_sven_event(dbg_devh,
                                          SVEN_EV_SMDCore_SoftPLL_DriftStatus,
                                          spll->in_tuple[minpos].pcr,
                                          spll->in_tuple[minpos].stc,
                                          mindpcr,
                                          dt_since_last_correction,
                                          spll->state,
                                          0 );


               #endif



                if  ((mindpcr > SOFTPLL_CORRECTION_THRESHHOLD) ||
                      (mindpcr < -SOFTPLL_CORRECTION_THRESHHOLD) ) {

                   /* If the currect error is greater then previous error => error is in untracable range */

                   temp = abs(mindpcr) - abs(spll->correct_dpcr);
                   if(temp)
                      spll->error_untrackable = true;
                   else
                      spll->error_untrackable = false;

                   /*If the difference is too big, increase the ppm saturation*/
                   /* These numbers are experimental*/

                   if(temp>600)
                      spll->ppm_saturate = 45;


                   if(dt_since_last_correction > SOFTPLL_CORRECTION_MIN_TIME)  {

                       int         ippm,ppm;
                       bool neg = mindpcr < 0;


                            /* Clock drift, in PPM */
                       #if 1
                       //ippm = ((long long)(mindpcr-spll->correct_dpcr) * 3000000L) / ((long long)(dt_since_last_correction<<2));
                       // do the math with absolute value and restore the sign
                       // afterword.  Otherwise, you may get a random sign from
                       // OSAL_DIV64 as it only does unsigned math
                       ippm = OSAL_DIV64(((long long)abs(mindpcr) * 3000000L),
                              ((long long)(dt_since_last_correction<<2)));
                       if((neg && ippm > 0) || (!neg && ippm < 0)){
                          ippm = -ippm;
                       }


                       #else
                       //ppm = ((long long)(mindpcr) * 1000000L) / ((long long)dt_since_last_correction);
                       if ( (mindpcr * spll->correct_dpcr) >= 0 )
                       {
                           /* both neg or both positive */
                           ippm = ((long long)(mindpcr-spll->correct_dpcr) * 1000000L) / ((long long)(dt_since_last_correction<<1));
                       }
                       else
                       {
                           /* We've crossed, only use the sign */
                           ippm = ((long long)mindpcr * 1000000L) / ((long long)dt_since_last_correction);
                       }
                       #endif

                       if ( ippm > 45 )        ippm = spll->ppm_saturate;
                       else if ( ippm < -45 )  ippm = -(spll->ppm_saturate);

                       ppm = ippm;
                       if ( ! ppm )
                       {
                           if ( mindpcr >= 0 )  ppm = 1;
                           else                 ppm = -1;
                       }
                       #define CLAMP   200

                       spll->correct_ppm -= SOFTPLL_UNITY_PPM;
                       spll->correct_ppm += ppm;
                       if ( spll->correct_ppm > CLAMP)         spll->correct_ppm = CLAMP;
                       else if ( spll->correct_ppm < -CLAMP)   spll->correct_ppm = -CLAMP;
                       spll->correct_ppm += SOFTPLL_UNITY_PPM;

                       #ifdef ENABLE_SVEN

                       smd_core_send_sven_event(dbg_devh,
                                                 SVEN_EV_SMDCore_SoftPLL_NudgeClock,
                                                 spll->in_tuple[minpos].pcr,
                                                 spll->in_tuple[minpos].stc,
                                                 mindpcr,
                                                 dt_since_last_correction,
                                                 ippm,
                                                 ppm );


                       #endif
                       #ifdef SELF_TEST_
                       OS_PRINT("\ncorrection: %08x [%08x %08x] %5d:%5d:%5d ippm:%4d ppm:%4d = %7d] ",
                         dt_since_last_correction,
                         spll->in_tuple[minpos].pcr,
                         spll->in_tuple[minpos].stc,
                         spll->correct_dpcr, mindpcr, mindpcr - spll->correct_dpcr,
                         ippm, ppm, spll->correct_ppm );
                       #endif

                       /* When correction was made */
                       spll->correct.stc = spll->in_tuple[SOFTPLL_TUPLE_GROUP_SIZE-1].stc;
                       /* tune the clock, addition of parts-per-million to the clock */
                       softpll_set_dds_ppm( spll, spll->correct_ppm );


                       #ifdef SELF_TEST_CSV
                       OS_PRINT( "%5d, %5d, %7d, %7.1lf, %5d\n",
                        (spll->correct.stc - spll->start.stc) / 9000, /* tenths of seconds */
                        mindpcr,
                        spll->correct_ppm,
                        ((double)spll->correct_ppm / (double)SOFTPLL_UNITY_PPM) * (double)SOFTPLL_PCR_FREQ,
                        ppm );
                       #endif
                   }
                }
                else if ( dt_since_last_correction > SOFTPLL_CORRECTION_MIN_TIME )
                {
                       if ( ((mindpcr >= 0) && (spll->last_dpcr < 0)) ||
                       ((mindpcr < 0) && (spll->last_dpcr >= 0)) )
                     {

                        if ( (spll->correct_dpcr > SOFTPLL_CORRECTION_THRESHHOLD) ||
                             (spll->correct_dpcr < -SOFTPLL_CORRECTION_THRESHHOLD) )
                        {
                            int         ppm;
                            spll->clock_locked = false;

                                #ifdef SELF_TEST_
                            OS_PRINT("zero-crossing: [%08x %08x %d] ",
                              spll->in_tuple[minpos].pcr,
                              spll->in_tuple[minpos].stc,
                              mindpcr );
                            #endif

                            /*
                             *   |
                             *   |---------*------------------------------- threshhold
                             *   |
                             *   |
                             *   |
                             *   +------------------------------*---------- zero
                             *   |
                             */
                            /* we had bounced against the threshhold at the last correction */
                            ppm = OSAL_DIV64(((long long)-spll->correct_dpcr *
                            900000L), ((long long)dt_since_last_correction));

                            /* Set the correction to near zero */
                            spll->correct_ppm -= SOFTPLL_UNITY_PPM;
                            spll->correct_ppm += ppm;
                            if ( spll->correct_ppm > CLAMP)         spll->correct_ppm = CLAMP;
                            else if ( spll->correct_ppm < -CLAMP)   spll->correct_ppm = -CLAMP;
                            spll->correct_ppm += SOFTPLL_UNITY_PPM;

                            /* When correction was made */
                            spll->correct.stc = spll->in_tuple[SOFTPLL_TUPLE_GROUP_SIZE-1].stc;
                            spll->correct_dpcr = mindpcr;


                            #ifdef ENABLE_SVEN
                            smd_core_send_sven_event(dbg_devh,
                                                      SVEN_EV_SMDCore_SoftPLL_NudgeClock,
                                                      spll->in_tuple[minpos].pcr,
                                                      spll->in_tuple[minpos].stc,
                                                      mindpcr,
                                                      dt_since_last_correction,
                                                      spll->last_dpcr,
                                                      ppm );
                            #endif
                            /* tune the clock, addition of parts-per-million to the clock */
                            softpll_set_dds_ppm( spll, spll->correct_ppm );



                            #ifdef SELF_TEST_
                            OS_PRINT( "%5d, %5d, %7d, %7.1lf, %5d\n",
                             (spll->correct.stc - spll->start.stc) / 9000, /* tenths of seconds */
                             mindpcr,
                             spll->correct_ppm,
                             ((double)spll->correct_ppm / (double)SOFTPLL_UNITY_PPM) * (double)SOFTPLL_PCR_FREQ,
                             ppm );
                            #endif
                        }
                        else
                        {
                            spll->clock_locked = true;
                            #ifdef SELF_TEST_
                            OS_PRINT("zero-crossing: [%08x %08x %d] ignored, not from edge\n",
                              spll->in_tuple[minpos].pcr,
                              spll->in_tuple[minpos].stc,
                              mindpcr );
                            #endif
                            OS_PRINT("\nLocked");
                        }
                    }
                    #ifdef SELF_TEST
                    //printf("steady: [%08x %08x %d] ",
                    //  spll->in_tuple[minpos].pcr,
                    //  spll->in_tuple[minpos].stc,
                    //  mindpcr );
                    #endif
                }

                spll->last_dpcr = mindpcr;
            }
         }
    }

    if ( discontinuity_detected )
    {
        spll->clock_locked = false;

        #ifdef SELF_TEST
        OS_PRINT("\ndiscontinuity\n");
        #endif

        #ifdef ENABLE_SVEN
        if(spll->in_tuple_pos <= SOFTPLL_TUPLE_GROUP_SIZE ) {

        smd_core_send_sven_event(dbg_devh,
                                  SVEN_EV_SMDCore_SoftPLL_Discontinuity,
                                  spll->in_tuple[spll->in_tuple_pos-1].pcr,
                                  spll->in_tuple[spll->in_tuple_pos-1].stc,
                                  (spll->in_tuple[spll->in_tuple_pos-1].pcr - spll->stc_dt)-spll->in_tuple[spll->in_tuple_pos-1].stc,
                                  spll->in_tuple_pos-1,
                                  spll->state,
                                  0 );
         }
      #endif
      softpll_init( spll );
        OS_PRINT("\ndiscontinuity\n");
        softpll_init( spll );
    }
}






