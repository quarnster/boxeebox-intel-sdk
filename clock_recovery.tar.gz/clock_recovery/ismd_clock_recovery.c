/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2011  Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2011  Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

#include "osal.h"
#include "ismd_global_defs.h"
#include "ismd_core.h"
#include "ismd_msg.h"
#include "ismd_clock_recovery.h"
#include "algo_threshold_monitor.h"
#include "algo_adaptive_pid.h"
#include "gen3_clock.h"
#include "clock_recovery_local_defs.h"


#define UNITY_PPM 1000000
#define VCXO_TUNABLE_BOUND_LOWER 80
#define VCXO_TUNABLE_BOUND_UPPER 80
/* the tuple is a combination of:
 *
 *  pcr - arriving with High Jitter
 *  stc - monotonically increasing
 *
 */

#define SOFTPLL_TUPLE_GROUP_SIZE        64
#define SOFTPLL_HISTORY_SIZE            4

static clock_sync_context_t clock_synchronizer[ISMD_CLOCK_SYNC_MAX];

static clock_sync_context_t *lookup_and_lock_clock_sync(clock_sync_t handle );
static void init_clock_sync( clock_sync_context_t *clock_sync );
static void clock_sync_unlock( clock_sync_context_t *clock_sync );
static void clock_sync_lock( clock_sync_context_t *clock_sync );
static bool clock_sync_is_open( clock_sync_context_t *clock_sync );
static clock_sync_context_t *lookup_clock_sync( clock_sync_t handle );
static void smd_adjust_dds_ppm(void *userdata, int ppm );
static void check_trackability(clock_sync_context_t *clock_sync);
static void strobe_ismd_event(clock_sync_context_t *clock_sync, ismd_clock_sync_event_type_t event);

static int ismd_debug_level = 1;
int interrupt_flags = 0;

os_devhandle_t *dbg_devh;


void ismd_clock_sync_close_autoapi_callback(void *data) {
    ismd_clock_sync_close((ismd_clock_sync_t)data);
}


ismd_result_t ismd_clock_sync_open_track(unsigned long connection, ismd_clock_sync_t *sync) {
   ismd_result_t result;
   ISMD_LOG_MSG( 5,"ismd_clock_sync_open_track begins....\n");
   
   result = ismd_clock_sync_open(sync);
   if (result == ISMD_SUCCESS) {
      result = ismd_connection_register(connection, ismd_clock_sync_close_autoapi_callback, (void *)(*sync));
      if (result != ISMD_SUCCESS) {
         OS_INFO("Critical error, ismd_connection_register Failed for ismd_clock_sync_open_track - freeing clock sync");
         ismd_clock_sync_close(*sync);
      }
   }
   return result;
}


ismd_result_t ismd_clock_sync_close_track( unsigned long connection, ismd_clock_sync_t handle ) {
   ismd_result_t result;

   (void)connection; // suppressing warning about unused param.

   result = ismd_clock_sync_close(handle);
   if (result == ISMD_SUCCESS) {
      ismd_connection_unregister(ismd_clock_sync_close_autoapi_callback, (void *)handle);
   }
   return result;
}


void clock_sync_init(void)
{
   clock_sync_context_t *clock_sync;
   int i;

   for ( i=0; i<ISMD_CLOCK_SYNC_MAX; i++ ) {
      clock_sync = lookup_clock_sync(i);
      init_clock_sync(clock_sync );
   }
   dbg_devh = devhandle_factory(NULL);
   devh_SVEN_SetModuleUnit( dbg_devh , SVEN_module_SMD_CORE, 0);
}



ismd_result_t ismd_clock_sync_open(ismd_clock_sync_t *handle)
{
   ismd_result_t           result = ISMD_ERROR_NO_RESOURCES;
   ismd_clock_sync_t       i;
   ismd_clock_sync_t       temp_handle = ISMD_CLOCK_HANDLE_INVALID;
   clock_sync_context_t    *clock_sync=NULL;

   ISMD_LOG_MSG( 5, "clock_sync_open(): entering function.\n" );

   for ( i = 0; i < ISMD_CLOCK_SYNC_MAX; i++ ) {
      clock_sync = lookup_clock_sync( i );
      OS_ASSERT(clock_sync != NULL);
      clock_sync_lock( clock_sync );
      if ( !clock_sync_is_open(clock_sync) ) {
         clock_sync->state = CLOCK_SYNC_STATE_OPEN;
         temp_handle = i;
         i = ISMD_CLOCK_SYNC_MAX; /* exit for-loop on next iteration.  */
         result = ISMD_SUCCESS;
         ISMD_LOG_MSG( 2, "clock_sync_open(): openated clock %d.\n", *handle );
      }
      clock_sync_unlock( clock_sync );
   }


   /* If any action failed, then cleanup all of the allocated resources. */
   if ( result != ISMD_SUCCESS ) {
      /* Not much we can do if any of these functions fail. */
      if ( temp_handle != CLOCK_SYNC_HANDLE_INVALID ) {
         clock_sync_close(temp_handle);
      }
   }
   else
      *handle = temp_handle;

   ISMD_LOG_MSG( 4, "clock_sync_open(): exiting function.\n" );
   return ( result );
}


ismd_result_t ismd_clock_sync_close(ismd_clock_sync_t handle)
{
      ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
      clock_sync_context_t *clock_sync;

      ISMD_LOG_MSG( 4, "clock_sync_close(): entering function.\n" );
      clock_sync = lookup_and_lock_clock_sync( handle );

      if ( clock_sync != NULL ) {
         clock_sync->state = CLOCK_SYNC_STATE_CLOSED;

         //Initialize general clock sync context
         init_clock_sync(clock_sync );
         result = ISMD_SUCCESS;
         ISMD_LOG_MSG( 3, "clock_sync_close(): closed clock recoverer %d.\n", handle );
         clock_sync_unlock( clock_sync );     
      }
      else {
         ISMD_LOG_MSG( 2, "clock_sync_close(): invalid handle %d.\n", handle );
      }

      ISMD_LOG_MSG( 4, "clock_sync_close(): exiting function.\n" );
      return ( result );
}


ismd_result_t ismd_clock_sync_set_clock(ismd_clock_sync_t handle, ismd_clock_t clock)
{

   ismd_result_t result = ISMD_ERROR_INVALID_HANDLE;
   clock_sync_context_t *clock_sync;

   clock_sync = lookup_and_lock_clock_sync( handle );

   if ( clock_sync != NULL ) {
         clock_sync->clock = clock;
         result = ISMD_SUCCESS;
         clock_sync_unlock(clock_sync);
   }

   else {
      ISMD_LOG_MSG( 2, "clock_sync_set_clock(): invalid clock sync handle %d.\n",handle);
   }

   return(result);
}


ismd_result_t ismd_clock_sync_set_algorithm(ismd_clock_sync_t handle, ismd_clock_sync_algo_t algorithm_type)
{
   ismd_result_t result = ISMD_SUCCESS;
   clock_sync_context_t *clock_sync;
   SoftPLL     *spll_temp;

   clock_sync = lookup_and_lock_clock_sync( handle );

   if ( clock_sync != NULL ) {

      switch(algorithm_type)  {

         case THRESHOLD_MONITOR :
         case PID_FILTERING :
         case PID_FILTERING_V1 :
              clock_sync->algorithm_type = algorithm_type;

              /* Algorithm specific initialization */
              /*Setting clock_sync handle in the algorithm structure */
              spll_temp= (SoftPLL*)clock_sync->algo_struct;
              spll_temp->ppm_userdata = clock_sync;

              //Initializing the dds/vcxo freq adjust & read stc func.
              spll_temp->set_dds_ppm = smd_adjust_dds_ppm;

              //Initializing other algorithm specific parameters
              if ( THRESHOLD_MONITOR == algorithm_type )
                 softpll_init( spll_temp);
              else if ( PID_FILTERING_V1 == algorithm_type )
                 adaptive_pid_init_v1( (AdaptivePID*)spll_temp );
              else
                 adaptive_pid_init( (AdaptivePID*)spll_temp );

              break;

         default :

              result = ISMD_ERROR_INVALID_PARAMETER;

              break;
      }  // End of switch(algorithm_type)

      clock_sync_unlock( clock_sync );
   }
   else {
      result = ISMD_ERROR_INVALID_HANDLE;
      ISMD_LOG_MSG( 2, "clock_sync_set_clock(): invalid handle %d.\n", handle );
   }

   return(result);
}


   /* Expected value = PCR, Actual value   = STC */
ismd_result_t ismd_clock_sync_add_pair_th_safe(ismd_clock_sync_t handle, int expected_value, int actual_value)
{
   ismd_result_t result = ISMD_SUCCESS;
   clock_sync_context_t *clock_sync;

     clock_sync = lookup_clock_sync( handle );

   /* Th SAFE CODE*/
   if ( clock_sync != NULL ) {
      OS_DISABLE_INTERRUPTS(interrupt_flags);

      if ( !clock_sync_is_open(clock_sync) ) {
         clock_sync = NULL;
      }
      OS_ENABLE_INTERRUPTS(interrupt_flags);
   }
   /***********/

      if ( clock_sync != NULL ) {

            switch(clock_sync->algorithm_type)  {

               case THRESHOLD_MONITOR :   {
                  SoftPLL     *temp_softpll;

                  temp_softpll = (SoftPLL*)clock_sync->algo_struct;
                  temp_softpll->ppm_userdata = clock_sync;

                  softpll_append_sample(temp_softpll, expected_value, actual_value);
               }
               break;

               case PID_FILTERING : {
                  AdaptivePID     *temp_apid;

                  temp_apid = (AdaptivePID*)clock_sync->algo_struct;
                  temp_apid->spll.ppm_userdata = clock_sync;

                  adaptive_pid_append_sample( temp_apid, expected_value, actual_value );
               }
               break;

               case PID_FILTERING_V1 : {
                  AdaptivePID     *temp_apid;

                  temp_apid = (AdaptivePID*)clock_sync->algo_struct;
                  temp_apid->spll.ppm_userdata = clock_sync;

                  adaptive_pid_append_sample_v1( temp_apid, expected_value, actual_value );
               }
               break;

               default :

                     result = ISMD_ERROR_INVALID_PARAMETER;
                     break;
             }

         //clock_sync_unlock(clock_sync);
         }
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
         ISMD_LOG_MSG( 2, "clock_sync_add_pair(): invalid handle %d.\n", handle );
      }
   return(result);
}


ismd_result_t ismd_clock_sync_add_pair(ismd_clock_sync_t handle, int expected_value, int actual_value)
{
   ismd_result_t result = ISMD_SUCCESS;
   clock_sync_context_t *clock_sync;

     clock_sync = lookup_and_lock_clock_sync( handle );


      if ( clock_sync != NULL ) {

            switch(clock_sync->algorithm_type)  {

               case THRESHOLD_MONITOR :   {
                  SoftPLL     *temp_softpll;

                  temp_softpll = (SoftPLL*)clock_sync->algo_struct;
                  temp_softpll->ppm_userdata = clock_sync;

                  softpll_append_sample(temp_softpll, expected_value, actual_value);
               }
               break;

               case PID_FILTERING : {
                  AdaptivePID     *temp_apid;

                  temp_apid = (AdaptivePID*)clock_sync->algo_struct;
                  temp_apid->spll.ppm_userdata = clock_sync;

                  adaptive_pid_append_sample( temp_apid, expected_value, actual_value );
               }
               break;

               case PID_FILTERING_V1 : {
                  AdaptivePID     *temp_apid;

                  temp_apid = (AdaptivePID*)clock_sync->algo_struct;
                  temp_apid->spll.ppm_userdata = clock_sync;

                  adaptive_pid_append_sample_v1( temp_apid, expected_value, actual_value );
               }
               break;

               default :

                     result = ISMD_ERROR_INVALID_PARAMETER;
                     break;
             }

         clock_sync_unlock(clock_sync);
         }
      else {
         result = ISMD_ERROR_INVALID_HANDLE;
         ISMD_LOG_MSG( 2, "clock_sync_add_pair(): invalid handle %d.\n", handle );
      }
   return(result);
}


/** Registers a user event with the given clock sync instance */
ismd_result_t ismd_clock_sync_register_event(ismd_clock_sync_t  handle, 
                                             ismd_event_t       event, 
                                             ismd_clock_sync_event_type_t type)

{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   clock_sync_context_t *clock_sync;  

   CLOCK_SYNC_SVEN_ENTER(dbg_devh);

   /** Check that the event is valid */
   if (event == ISMD_EVENT_HANDLE_INVALID ) {       
      result = ISMD_ERROR_INVALID_HANDLE;
      goto exit_register_event;
   } else if (type < 0 || type >= ISMD_CLOCK_SYNC_EVENT_MAX) {
      result = ISMD_ERROR_INVALID_PARAMETER;
      goto exit_register_event; 
   }

   /** Get context */
   clock_sync = lookup_and_lock_clock_sync( handle );
   if (clock_sync == NULL) {  
      result = ISMD_ERROR_INVALID_HANDLE;
      goto exit_register_event;
   } 

   if(clock_sync->user_event[type] != ISMD_EVENT_HANDLE_INVALID) {
      result = ISMD_ERROR_NO_RESOURCES;
   } else {
      /** Register event */      
      clock_sync->user_event[type] = event;
      result = ISMD_SUCCESS;
   
      /** Sven event */
      smd_core_send_sven_event(dbg_devh,
                          SVEN_EV_SMDCore_SoftPLL_RegEvent,
                          handle, event,type,0,0,0 );
   }
   /** Release context */
   clock_sync_unlock(clock_sync); 

exit_register_event :

   CLOCK_SYNC_SVEN_EXIT(dbg_devh);   
   return result;
}

/** Gets all the relevant metadata associated to the given clock sync instance */
ismd_result_t ismd_clock_sync_get_sync_info(ismd_clock_sync_t handle, ismd_clock_sync_info_t *sync_info) {
   
   ismd_result_t result  = ISMD_ERROR_UNSPECIFIED;
   clock_sync_context_t *clock_sync;  
   int i;

   CLOCK_SYNC_SVEN_ENTER(dbg_devh);

   /** Parameter check */
   if(sync_info == NULL) {
      result = ISMD_ERROR_NULL_POINTER;
      goto exit_get_sync_info ;
   }

   /** Get context */
   clock_sync = lookup_and_lock_clock_sync( handle );
   if (clock_sync == NULL) {
      result = ISMD_ERROR_INVALID_HANDLE;
      goto exit_get_sync_info;
   } 
      
   /** Populate the sync_info structure */
   sync_info->last_adjustment   = clock_sync->last_adjustment;
   sync_info->associated_clock  = clock_sync->clock;
   sync_info->algorithm         = clock_sync->algorithm_type;
   for(i=0 ; i<ISMD_CLOCK_SYNC_EVENT_MAX ; i++) {     
      sync_info->user_events[i] = clock_sync->user_event[i];
   }
   result = ISMD_SUCCESS; 

   /** Sven event */
   smd_core_send_sven_event(dbg_devh,
                       SVEN_EV_SMDCore_SoftPLL_GetSyncInfo,
                       handle, sync_info->last_adjustment,
                       sync_info->associated_clock,
                       sync_info->algorithm,0,0 );

   /** Release context */
   clock_sync_unlock(clock_sync);

exit_get_sync_info : 

   CLOCK_SYNC_SVEN_EXIT(dbg_devh);
   return result;
}

ismd_result_t ismd_clock_sync_reset(ismd_clock_sync_t handle)
{
   ismd_result_t result = ISMD_SUCCESS;
   clock_sync_context_t *clock_sync = NULL;
   SoftPLL *temp_softpll = NULL;
   AdaptivePID *temp_apid = NULL;

   clock_sync = lookup_and_lock_clock_sync( handle );

   if ( clock_sync != NULL ) {
      switch(clock_sync->algorithm_type)
      {
      case THRESHOLD_MONITOR:
         temp_softpll = (SoftPLL*)clock_sync->algo_struct;
         softpll_init( temp_softpll );
         break;
      case PID_FILTERING:
         temp_apid = (AdaptivePID*)clock_sync->algo_struct;
         adaptive_pid_init( temp_apid );
         break;
      case PID_FILTERING_V1:
         temp_apid = (AdaptivePID*)clock_sync->algo_struct;
         adaptive_pid_init_v1( temp_apid );
         break;
      }
      clock_sync_unlock( clock_sync );
   } else {
      ISMD_LOG_MSG( 2, "clock_sync_reset(): invalid handle %d.\n", handle );
      result = ISMD_ERROR_INVALID_HANDLE;
   }

   return ( result );
}

static clock_sync_context_t *lookup_clock_sync( clock_sync_t handle )
{
   clock_sync_context_t *clock_sync_context = NULL;

   if ( (handle >= 0) && (handle < ISMD_CLOCK_SYNC_MAX) ) {
      clock_sync_context = &(clock_synchronizer[handle]);
   }
   return ( clock_sync_context );
}




static bool clock_sync_is_open( clock_sync_context_t *clock_sync )
{
   bool result = false;
   if ( clock_sync->state != CLOCK_SYNC_STATE_CLOSED ) {
      result = true;
   }
   return ( result );
}



static void clock_sync_lock( clock_sync_context_t *clock_sync )
{
   if(clock_sync!=NULL)
   os_sema_get( &(clock_sync->lock) );
}


static void clock_sync_unlock( clock_sync_context_t *clock_sync )
{
   os_sema_put( &(clock_sync->lock) );
}



static void init_clock_sync( clock_sync_context_t *clock_sync )
{

   osal_result result;
   int i;
   
   clock_sync->state            = CLOCK_SYNC_STATE_CLOSED;
   clock_sync->algorithm_type   = THRESHOLD_MONITOR;
   clock_sync->clock_associated = false;
   clock_sync->master_clock_source = MASTER_CLOCK_SOURCE;
   clock_sync->tracking_counter = 0;
   clock_sync->last_adjustment  = 0;
   clock_sync->clock            = ISMD_CLOCK_HANDLE_INVALID;
   clock_sync->algo_struct      = &clock_sync->clock_sync_algos;

   for(i=0; i<ISMD_CLOCK_SYNC_EVENT_MAX; i++) {
      clock_sync->user_event[i] = ISMD_EVENT_HANDLE_INVALID;
   }
   result = os_sema_init( &clock_sync->lock, 1 );
   OS_ASSERT(result == OSAL_SUCCESS);

}


static clock_sync_context_t *lookup_and_lock_clock_sync(clock_sync_t handle )
{
   clock_sync_context_t *clock_sync_context;

   clock_sync_context = lookup_clock_sync( handle );
   if ( clock_sync_context != NULL ) {
      clock_sync_lock( clock_sync_context );
      if ( !clock_sync_is_open(clock_sync_context) ) {
         clock_sync_unlock( clock_sync_context );
         clock_sync_context = NULL;
      }
   }
   return ( clock_sync_context );
}


static void smd_adjust_dds_ppm(void *userdata, int ppm )
{
    clock_sync_context_t *clock_sync = (clock_sync_context_t*)userdata;
    SoftPLL       *algo_struct_temp;
    ismd_result_t result;
    ismd_clock_t handle;

    int correction_ppm = INVALID_VALUE;

    OS_ASSERT(clock_sync != NULL);

   /* Clock associated to clock sync could be NULL in the case where the clock 
   recovery algorithm is being used to just spot the drift in clocks and not 
   adjust them */

   if(clock_sync->clock != ISMD_CLOCK_HANDLE_INVALID) {

      algo_struct_temp = (SoftPLL *)clock_sync->algo_struct;
      result = ismd_clock_get_primary(&handle);
      if((result == ISMD_SUCCESS) && (handle == clock_sync->clock) &&
         (clock_sync->master_clock_source == ISMD_CLOCK_SIGNAL_VCXO)) {
  
         /* Saturating for lower limit */
         if(ppm<(UNITY_PPM - VCXO_TUNABLE_BOUND_LOWER)) {
            correction_ppm = -VCXO_TUNABLE_BOUND_LOWER;
            algo_struct_temp->correct_ppm = UNITY_PPM - VCXO_TUNABLE_BOUND_LOWER;
            clock_sync->result = ISMD_ERROR_OUT_OF_RANGE;
            check_trackability(clock_sync);
            ISMD_LOG_MSG( 2, "CR Lppm : %d\n", ppm );
   
         }
   
         /* Saturating for upper limit */
         else if(ppm>(UNITY_PPM + VCXO_TUNABLE_BOUND_UPPER)) {
            correction_ppm = VCXO_TUNABLE_BOUND_UPPER;
            algo_struct_temp->correct_ppm = UNITY_PPM + VCXO_TUNABLE_BOUND_UPPER;
            clock_sync->result = ISMD_ERROR_OUT_OF_RANGE;
            check_trackability(clock_sync);
            ISMD_LOG_MSG( 2, "CR Uppm : %d\n", ppm );
         }
         /* If within the tuning range, no saturation required */
         else {
            algo_struct_temp->correct_ppm = ppm;
            correction_ppm = ppm - UNITY_PPM;
            clock_sync->tracking_counter=0;
         }
      }     
      /* If the clock source is not VCXO => dds can be adjusted as much as */
      else {
         algo_struct_temp->correct_ppm = ppm;
         correction_ppm = ppm - UNITY_PPM;
      }

      /* Calling clock manager to adjust the clock frequency */
      ISMD_LOG_MSG( 2, "CR: corr : %d ppm : %d\n", correction_ppm, ppm);
      clock_sync->result = ismd_clock_set_freq_th_safe(clock_sync->clock, correction_ppm);
   }

   /** Even if no clock is associated to the clock recoverer, keep record of 
   last adjustment issued by clock recovery */
   if(correction_ppm == INVALID_VALUE) { 
      clock_sync->last_adjustment = ppm - UNITY_PPM;
   } else {
      clock_sync->last_adjustment = correction_ppm;
   }

   /* Strobe user ismd event if registered */
   strobe_ismd_event(clock_sync, ISMD_CLOCK_SYNC_EVENT_ADJUST_CLOCK);

   return;
}


/** This function strobes given ISMD event */
static void strobe_ismd_event(clock_sync_context_t *clock_sync, ismd_clock_sync_event_type_t event_type) {
    
   CLOCK_SYNC_SVEN_ENTER(dbg_devh);
   if(clock_sync->user_event[event_type] != ISMD_EVENT_HANDLE_INVALID) {

     /** Strobe ismd event */
      ismd_event_strobe(clock_sync->user_event[event_type]);

     /** Sven event */
     smd_core_send_sven_event(dbg_devh,
                       SVEN_EV_SMDCore_SoftPLL_TriggerEvent,
                       clock_sync->user_event[event_type], 
                       event_type,0,0,0,0 );
   }
   CLOCK_SYNC_SVEN_EXIT(dbg_devh);
   return;     
}
   

/* This function checks if the transmitter clock is in the trackable range of
the VCXO */
static void check_trackability(clock_sync_context_t *clock_sync)
{

   SoftPLL *temp_softpll;

      switch(clock_sync->algorithm_type)  {

         case(THRESHOLD_MONITOR) :

               temp_softpll = (SoftPLL*)clock_sync->algo_struct;
               //OS_PRINT("\n %d : %d",temp_softpll->error_untrackable,clock_sync->tracking_counter);

               if(temp_softpll->error_untrackable)
                  clock_sync->tracking_counter++;
               else
                  clock_sync->tracking_counter=0;

               if(clock_sync->tracking_counter >1) {
                 // OS_PRINT("\n %d : %d",temp_softpll->error_untrackable,clock_sync->tracking_counter);
                  smd_core_send_sven_event(dbg_devh,
                                            SVEN_EV_SMDCore_SoftPLL_UnTrackable,
                                            temp_softpll->correct_dpcr,0,0,0,0,0 );
               }
               break;

         case(PID_FILTERING) :
         case(PID_FILTERING_V1) :

               break;

         default :

               break;
      }
}


// this is a client-exposed interface.
// See function header comment in ismd_clock_recovery.h
ismd_result_t SMDEXPORT ismd_clock_sync_statistics(ismd_clock_sync_t handle, ismd_clock_sync_statistics_t * stats)
{
   clock_sync_context_t *clock_sync_context;
   ismd_result_t  result = ISMD_SUCCESS;

   if (stats == NULL) {
      result = ISMD_ERROR_NULL_POINTER;
   } else {

      stats->error_untrackable   = true;
      stats->clock_locked        = false;

      clock_sync_context = lookup_clock_sync( handle );
      if ( clock_sync_context != NULL ) {

         stats->error_untrackable   = ((SoftPLL*)clock_sync_context->algo_struct)->error_untrackable;

         switch(clock_sync_context->algorithm_type)  {
         case THRESHOLD_MONITOR :
            stats->clock_locked        = ((SoftPLL*)clock_sync_context->algo_struct)->clock_locked;
            break;
         case PID_FILTERING :
         case PID_FILTERING_V1 :
				//result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;
            break;
         }
      }
   }
   return result;
}


