/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009  Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009  Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "algo_adaptive_pid.h"
#include "osal.h"
#include "clock_recovery_local_defs.h"
#include "sven_event_type.h"
#include "sven.h"


//#define SELF_TEST
#define ENABLE_SVEN

#define SOFTPLL_JITTER_EVALUATION_THRESHHOLD 32
#define PID_PPM_LOPASS_SIZE   3

#ifdef SELF_TEST
#include <stdio.h>
//#include <stdlib.h>
#endif

static signed long long signed_divide64(
   signed long long num,
   signed long long den )
{
   int         flip_result_sign = 0;

   if( den == 0 ) {
      den = 1;
   }

   if ( num < 0 )
   {
      flip_result_sign ^= 1;
      num = -num;
   }

   if ( den < 0 )
   {
      flip_result_sign ^= 1;
      den = -den;
   }

   num = OSAL_DIV64( num, den );

   if ( flip_result_sign )
   {
      num = -num;
   }

   return(num);
}

/** Initialize/Reset the adaptive P.I.D. controller algorithm
 */
void adaptive_pid_init(
    AdaptivePID      *apid )
{
    SoftPLL          *spll = &apid->spll;
    int               i;

    spll->state = SOFTPLL_FreeRun;
    spll->in_tuple_pos = 0;

    // Userdata should not be initialized to NULL as this
    // is used during discontinuity detection.
    // spll->ppm_userdata = NULL;

    spll->error_untrackable = false;
    spll->ppm_saturate = 15;
    spll->clock_locked = false;

    apid->pid.term_diff    = 0;
    apid->pid.term_int     = 0;

    /* These coefficients are harvested from 50,000 iterations of randomizing coefficient tests
     */
    apid->pid.pgain        = (int)(0.262695 * (float)(1<<10));   /* proportional gain */
    apid->pid.igain        = (int)(0.000000 * (float)(1<<10));   /* integral gain */
    apid->pid.dgain        = (int)(1.831055 * (float)(1<<10));   /* differential gain */

    apid->pid.integral_max =  SOFTPLL_PCR_FREQ;
    apid->pid.integral_min = -SOFTPLL_PCR_FREQ;

    apid->pid.jgain        = (int)(0.2 * (float)(1<<8));    /* jitter gain */

    /* add to lowpass adjustment filter */
    for ( i = 0; i < PID_PPM_LOPASS_SIZE; i++ )
    {
       apid->pid.ppm[i] = 0;
    }
}

static void softpll_set_dds_ppm(
    SoftPLL          *spll,
    int              ppm )
{
    if(spll->ppm_userdata == NULL) 
    {
       OS_INFO("Clock Recovery Algo struct handle is NULL\n");
       OS_INFO("Not adjusting the clock. Pls set valid algo using clock_sync_set_algorithm().\n");
    }
    else
    {
       (*spll->set_dds_ppm)( spll->ppm_userdata, ppm  );
    }
}


/* De-jitter this sample
 * returns:
 *
 *    -1 = discontinuity detected
 *    0 = sample appended to dejitter buffer
 *    1 = dejitter buffer is full, tuple at "minpos" contains smallest PCR/STC pair
 *    2 = dejitter buffer is full, There is TOO MUCH Jitter to evaluate, deferred action requested
 *
 */
static int softpll_dejitter_sample(
    SoftPLL         *spll,
    int              pcr,
    int              stc,
    int             *pminpos )
{
   int         discontinuity_detected = 0;
   int         retval = 0;
   int         jitter_is_below_noise = 0;

   /* Add it */
   spll->in_tuple[ spll->in_tuple_pos ].pcr = pcr; /* high jitter PCR */
   spll->in_tuple[ spll->in_tuple_pos ].stc = stc; /* Wall Clock at PCR capture */

   /* if we're out of initialization mode */
   if ((SOFTPLL_FreeRun != spll->state) &&
       (SOFTPLL_Setup   != spll->state) )
   {
      signed long long   cmpslope, cur_min;

      /* Compare dPCR / dt slope of this sample from origin to current
       * minimum slope.
       *
       *    Note we determine MINIMUM slope because jitter only
       *    increases the differences between the clocks
       *
       */
      if ( 0 != spll->in_tuple_pos )
      {
         /* 1) Slope of line:
          *
          *    dSTC
          *    ----
          *    dPCR
          *
          * 2) comparison of slopes, find the lowest
          *    because any jitter only increases the
          *    apparent slope (STC is larger)
          *
          *    dSTC1      dSTC0
          * if -----  <   -----
          *    dPCR1      dPCR0
          *
          * 3) multiply both sides by dPCR0
          *
          *    dSTC1 * dPCR0      
          * if -------------  <  dSTC0
          *        dPCR1      
          *
          * 4) multiply both sides by dPCR1
          *
          * if dSTC1 * dPCR0  <  dSTC0 * dPCR1
          *
          *     "cmpslope"      "cur_min"
          *
          *
          */
         cmpslope  = (int)(spll->in_tuple[spll->minslope_pos].pcr - spll->prev_end.pcr); /* dpcr0 */
         cmpslope *= (int)(spll->in_tuple[spll->in_tuple_pos].stc - spll->prev_end.stc); /* * dSTC1 */

         cur_min   = (int)(spll->in_tuple[spll->in_tuple_pos].pcr - spll->prev_end.pcr); /* dpcr1 */
         cur_min  *= (int)(spll->in_tuple[spll->minslope_pos].stc - spll->prev_end.stc); /* * dSTC0 */

         /* must be signed */
         if ( cmpslope < cur_min )
         {

            spll->minslope_pos = spll->in_tuple_pos;
            spll->minslope_age = 0;
         }
         else
         {
            spll->minslope_age++;
         }

         /* determine if jitter is low enough in relation to time elapsed to steer the clock now
          */
         if ( spll->in_tuple_pos > SOFTPLL_JITTER_EVALUATION_THRESHHOLD )
         {
            int               i;
            int               max_jitter;

            max_jitter = 0;
            
            for ( i = 0; i < spll->in_tuple_pos; i++ )
            {
               signed long long     predicted_stc;
               int                  jitter;

               /*
                *                                dSTC
                * predicted_stc = (pcr - PCR0) * ----
                *                                dPCR
                */
               predicted_stc = (int)(spll->in_tuple[i].pcr - spll->prev_end.pcr);  /* pcr - PCR0 */
               predicted_stc *= (int)(spll->in_tuple[spll->minslope_pos].stc - spll->prev_end.stc); /* dSTC */
               predicted_stc  = signed_divide64( predicted_stc, (int)(spll->in_tuple[spll->minslope_pos].pcr - spll->prev_end.pcr) ); /* dPCR */
               predicted_stc += (int)spll->prev_end.stc;

               jitter = (int)(spll->in_tuple[i].stc - predicted_stc);

               #ifdef GNUPLOT_OUTPUT_SAMPLES
                  printf("# %d stc %d, predicted_stc %d, jitter %d\n",
                      spll->minslope_pos, (int)spll->in_tuple[i].stc, (int)predicted_stc, jitter);
               #endif

               if ( jitter >= max_jitter )
               {
                  max_jitter = jitter;
               }
            }

            /* max_jitter excursion is below 1/256 of total acquisition time */
            if ( (max_jitter << 8) < (int)(spll->in_tuple[spll->in_tuple_pos].pcr - spll->prev_end.pcr) )
            {
               jitter_is_below_noise = 1;
               #ifdef GNUPLOT_OUTPUT_SAMPLES
                  printf("# %d max_jitter (%d) is below noise (%d)\n",
                      spll->in_tuple_pos, max_jitter, (int)(spll->in_tuple[spll->in_tuple_pos].stc - spll->prev_end.stc) >> 8 );
               #endif
               spll->in_tuple_max_jitter = max_jitter;
            }
         }
      }
      else  /* first tuple */
      {
         spll->minslope_pos = 0;
         spll->minslope_age = 0;
         #ifdef GNUPLOT_OUTPUT_SAMPLES
            printf("# reset minslope\n" );
         #endif
      }

      #ifdef SELF_TEST
      #ifdef GNUPLOT_OUTPUT
      #ifdef GNUPLOT_OUTPUT_SAMPLES
      if ( spll->in_tuple_pos > 0 )
      {
         /** for analysis with gnuplot: colums are
          *    1     - i
          *    2     - dSTC
          *    3     - dPCR
          *    4     - dSTC - (offset) - dPCR
          *    5     - minslope
          *    6     - minslope_age
          */
         printf("%3d\t%8d\t%8d\t%8d\t%f\t%d\n",
            (int) spll->in_tuple_pos,
            (int)(spll->in_tuple[spll->in_tuple_pos].stc - spll->prev_end.stc),
            (int)(spll->in_tuple[spll->in_tuple_pos].pcr - spll->prev_end.pcr),
            (int)((spll->in_tuple[spll->in_tuple_pos].stc - spll->prev_end.stc) -
                  (spll->in_tuple[spll->in_tuple_pos].pcr - spll->prev_end.pcr) ),
            (float)( (float) (spll->in_tuple[spll->minslope_pos].stc - spll->prev_end.stc) /
                     (float) (spll->in_tuple[spll->minslope_pos].pcr - spll->prev_end.pcr) ),
            (int)(spll->minslope_age)
                  );

         if ( spll->in_tuple_pos == (SOFTPLL_TUPLE_GROUP_SIZE - 1) )
         {
            printf("\n\n");
         }
      }
      #endif
      #endif
      #endif
   }
   else
   {
      /* Grab SOME starting position */
      if ( 0 == spll->in_tuple_pos )
      {
         spll->prev_end.pcr = pcr;
         spll->prev_end.stc = stc;
      }

      #ifdef GNUPLOT_OUTPUT_SAMPLES
         printf("# %3d\t%8d\t%8d\n",
            (int) spll->in_tuple_pos,
            (int)(spll->in_tuple[spll->in_tuple_pos].stc - spll->prev_end.stc),
            (int)(spll->in_tuple[spll->in_tuple_pos].pcr - spll->prev_end.pcr) );
      #endif
   }

   /* is the bucket full? */
   if ( (0 != jitter_is_below_noise) ||
        (spll->in_tuple_pos == (SOFTPLL_TUPLE_GROUP_SIZE-1)) )
   {
      int         i,minpos;
      int         clockd;

      retval = 1;

      /* calculate initial offset */
      clockd = spll->prev_end.stc - spll->prev_end.pcr;
      minpos = 0;

      /* look for discontinuities */
      for ( i = 0; i < SOFTPLL_TUPLE_GROUP_SIZE; i++ )
      {
          int     dt;

          dt = (spll->in_tuple[i].stc - clockd) -
                spll->in_tuple[i].pcr;

          if ( (dt > SOFTPLL_DISCONTINUITY_THRESHHOLD) ||
               (dt < -SOFTPLL_DISCONTINUITY_THRESHHOLD) )
          {
              discontinuity_detected = 1;
              break;
          }
          else if ( dt < 0 ) /* less than before */
          {
              clockd += dt;
              minpos = i;
          }
          else
          {
          }
      }

      /* if we're out of initialization mode */
      if ((SOFTPLL_FreeRun != spll->state) &&
          (SOFTPLL_Setup   != spll->state) )
      {
         *pminpos = spll->minslope_pos;

         if ( (0 == jitter_is_below_noise) &&
              (0 == discontinuity_detected) )
         {
            /* we got to the end of the bucket and still have too much jitter */
            retval = 2;
         }
      }
      else
      {
         /* smallest clock difference of the first group */
         *pminpos = minpos;
      }
   }

   if ( 0 != discontinuity_detected )
   {
      /* algorithm needs reset */
      retval = -1;
   }

   spll->in_tuple_pos++;   /* increment */

   return( retval );
}

/* Add a new PCR to the AdaptivePID, for tracking.
 */
void adaptive_pid_append_sample(
    AdaptivePID      *apid,
    int              pcr,
    int              stc )
{
   SoftPLL            *spll = &apid->spll;
   int                 dejitter_result;
   int                 minpos = 0;

   dejitter_result = softpll_dejitter_sample( spll, pcr, stc, &minpos );

   #ifdef ENABLE_SVEN
   {
      int i,dt;

      /* write out all PCRs and STCs during startup */
      i = spll->in_tuple_pos - 1;

      if ((SOFTPLL_FreeRun == spll->state) || (SOFTPLL_Setup == spll->state) )
      {
         dt = spll->in_tuple[0].stc - spll->in_tuple[0].pcr;
      }
      else
      {
         dt = spll->stc_dt;
      }

      smd_core_send_sven_event(dbg_devh,
         SVEN_EV_SMDCore_SoftPLL_PCR_Arrive,
         spll->in_tuple[i].pcr,
         spll->in_tuple[i].stc,
         (spll->in_tuple[i].stc - dt) - spll->in_tuple[i].pcr,
         i,
         spll->state,
         0 );
   }
   #endif

   if ( dejitter_result > 0 )  /* time to evaluate */
   {
      if ( SOFTPLL_FreeRun == spll->state )
      {
         spll->state = SOFTPLL_Acquiring;

         /* Set Initial Clock Difference */
         spll->stc_dt = spll->in_tuple[minpos].stc - spll->in_tuple[minpos].pcr;

         /* Clock at start */
         spll->start.pcr = spll->in_tuple[minpos].pcr;
         spll->start.stc = spll->in_tuple[minpos].stc;
         spll->start_dpcr = 0;
         spll->start_ppm = SOFTPLL_UNITY_PPM;

         /* State at last clock correction */
         spll->correct.stc = spll->in_tuple[minpos].stc;
         spll->correct_dpcr = 0;
         spll->correct_ppm = SOFTPLL_UNITY_PPM;

         /* This is the first bucket analyzed, we grab the minpos
          * as base time for following min_slope calculations.
          */
         spll->prev_end.pcr = spll->in_tuple[minpos].pcr;
         spll->prev_end.stc = spll->in_tuple[minpos].stc;
      }
      else if ( SOFTPLL_Acquiring == spll->state )
      {
         /*
          *  ^
          *  |
          * P|
          * C|                            * *
          * R|                           *
          *  |                       *
          * t|                *  *
          * i|           *
          * m|              *
          * e|     *    *
          *  |    *
          *  *
          *  |
          *--+-------------------------------------->
          *  |  (STC at PCR Arrival, zero jitter)
          *  |
          *
          */
         int        i;                 /*  */
         int        ppm;               /* parts-per-million to adjust */
         int        pterm,dterm,iterm; /* P, I, and D calculations */
         int        jterm = 0;         /* TODO: Remove JTERM */
         int        window_dt;         /* duration (int ticks) of this data */
         int        mindpcr;           /* de--jittered correction */
         long long  dtt,ptt;
         unsigned long long  dt_since_last_correction;


         /* Did jitter amount make the calculations inconclusive? 
          */
         if ( 2 == dejitter_result )
         {
            /* Reset the tuple analysis position, but leave previous "anchor" point
             * This forces jitter to be evaluated over a longer interval from anchor
             */
            spll->in_tuple_pos = 0;
            spll->minslope_pos = 0;
            return;
         }
         
         dt_since_last_correction =
                  spll->in_tuple[spll->in_tuple_pos-1].stc -
                  spll->correct.stc;

         /* what is the dejittered PCR difference? */
         mindpcr = (spll->in_tuple[minpos].stc - spll->stc_dt) -
                    spll->in_tuple[minpos].pcr;

         /* how many 90k clocks during entire sampling interval */
         window_dt = spll->in_tuple[spll->in_tuple_pos-1].stc - spll->prev_end.stc;

         /* Ensure window_dt != 0 */
         if ( window_dt < spll->in_tuple_pos )
            window_dt = spll->in_tuple_pos;

         /* calculate proportional term as PPM */
         ptt  = (long long) SOFTPLL_UNITY_PPM;
         ptt *= (long long) mindpcr;
         ptt  = signed_divide64( ptt, (long long) window_dt );
         pterm = (ptt * apid->pid.pgain) >> 10;

         /* add integrator */
         apid->pid.term_int += mindpcr;

         /* clamp integration */
         if ( apid->pid.term_int > apid->pid.integral_max )
            apid->pid.term_int = apid->pid.integral_max;
         else if ( apid->pid.term_int < apid->pid.integral_min )
            apid->pid.term_int = apid->pid.integral_min;

         /* integrative term */
         iterm = (apid->pid.term_int * apid->pid.igain) >> 10;

         /* calculate differential term in absolute parts-per-million  */
         dtt  = (long long) SOFTPLL_UNITY_PPM;                                /* dSTC --> dPPM */
         dtt *= (long long)(spll->in_tuple[minpos].stc - spll->prev_end.stc); /* dSTC0 */
         dtt  = signed_divide64( dtt, (long long)(spll->in_tuple[minpos].pcr - spll->prev_end.pcr) ); /* dPCR0 */
         dtt -= (long long) SOFTPLL_UNITY_PPM;                                /* dPPM minus unity */
         dterm = (dtt * apid->pid.dgain) >> 10;

         /* sum the terms together */
         ppm = -(pterm + iterm + dterm) >> 2;

         /* add to lowpass adjustment filter */
         for ( i = 0; i < PID_PPM_LOPASS_SIZE-1; i++ )
         {
            apid->pid.ppm[i] = apid->pid.ppm[i+1];
         }
         apid->pid.ppm[PID_PPM_LOPASS_SIZE-1] = ppm;

         ppm = 0;
         for ( i = 0; i < PID_PPM_LOPASS_SIZE; i++ )
         {
            ppm += apid->pid.ppm[i];
         }
         ppm /= PID_PPM_LOPASS_SIZE;

         #define MAX_PPM_ADJUST 400
         if ( ppm > MAX_PPM_ADJUST )        ppm = MAX_PPM_ADJUST;
         else if ( ppm < -MAX_PPM_ADJUST )  ppm = -MAX_PPM_ADJUST;

         #ifdef ENABLE_SVEN
         smd_core_send_sven_event(dbg_devh,
                     SVEN_EV_SMDCore_SoftPLL_DriftStatus,
                     spll->in_tuple[minpos].pcr,
                     spll->in_tuple[minpos].stc,
                     mindpcr,
                     dt_since_last_correction,
                     pterm + iterm + dterm,
                     jterm );
         #endif

         if ( 0 != ppm )
         {
            spll->correct_ppm += ppm;

            #define CLAMP   5200
            /* CLAMP maximum adjustment to +- 80 ppm */
            spll->correct_ppm -= SOFTPLL_UNITY_PPM;
            if ( spll->correct_ppm > CLAMP )         spll->correct_ppm = CLAMP;
            else if ( spll->correct_ppm < -CLAMP )   spll->correct_ppm = -CLAMP;
            spll->correct_ppm += SOFTPLL_UNITY_PPM;

            /** TODO, will lose track of actual PPM when hits high-low edge
             */

            /* tune the clock, addition of parts-per-million to the clock */
            softpll_set_dds_ppm( spll, spll->correct_ppm );

            #ifdef ENABLE_SVEN
            smd_core_send_sven_event(dbg_devh,
                               SVEN_EV_SMDCore_SoftPLL_NudgeClock,
                               spll->in_tuple[minpos].pcr,
                               spll->in_tuple[minpos].stc,
                               mindpcr,
                               dt_since_last_correction,
                               jterm,
                               ppm );
            #endif

            spll->correct.stc = spll->in_tuple[spll->in_tuple_pos-1].stc;
         }

         #ifdef SELF_TEST
            #ifdef GNUPLOT_OUTPUT
               #ifndef GNUPLOT_OUTPUT_SAMPLES
               /** for analysis with gnuplot: colums are
                *    1     - STC'
                *    2     - PCR'
                *    3     - MIN_DT
                *    4     - PPM Adjustment
                *    5     - PPM Adjustment
                *    6     - Jitter Term
                *    7     - pterm
                *    8     - iterm
                *    9     - dterm
                */
               printf("%lf\t%lf\t%6d\t%6d\t%6d\t%6d\t%6d\t%6d\t%6d\n",
                  (double)(stc - spll->start.stc) / (double)SOFTPLL_PCR_FREQ,
                  (double)(pcr - spll->start.pcr) / (double)SOFTPLL_PCR_FREQ,
                  mindpcr,
                  spll->correct_ppm - SOFTPLL_UNITY_PPM,
                  ppm,
                  jterm,
                  pterm, iterm, dterm );
               #endif /* GNUPLOT_OUTPUT_SAMPLES */
            #else
               printf("PID: dt: %6d st: %6d [p %6d i %6d d %6d j %6d] ppm %4d %5d\n",
                  mindpcr, window_dt, pterm, iterm, dterm, jterm, ppm,
                  spll->correct_ppm - SOFTPLL_UNITY_PPM);
            #endif
         #endif

         spll->last_dpcr = mindpcr;

         /* Set reference point for next synchronization attempt */
         spll->prev_end.pcr = spll->in_tuple[spll->minslope_pos].pcr;
         spll->prev_end.stc = spll->in_tuple[spll->minslope_pos].stc;
      }
      else
      {
         /* This is the first bucket analyzed, we grab the minpos
          * as base time for following min_slope calculations.
          */
         spll->prev_end.pcr = spll->in_tuple[minpos].pcr;
         spll->prev_end.stc = spll->in_tuple[minpos].stc;
      }

      /* Reset the tuple analysis position */
      spll->in_tuple_pos = 0;
      spll->minslope_pos = 0;
   }
   else if ( dejitter_result < 0 )   /* discontinuity detected */
   {
      spll->clock_locked = false;

      #ifdef SELF_TEST
      OS_PRINT("\ndiscontinuity\n");
      #endif

      #ifdef ENABLE_SVEN
      smd_core_send_sven_event(dbg_devh,
         SVEN_EV_SMDCore_SoftPLL_Discontinuity,
         spll->in_tuple[spll->in_tuple_pos-1].pcr,
         spll->in_tuple[spll->in_tuple_pos-1].stc,
         (spll->in_tuple[spll->in_tuple_pos-1].stc - spll->stc_dt)-spll->in_tuple[spll->in_tuple_pos-1].pcr,
         spll->in_tuple_pos-1,
         spll->state,
         0 );
      #endif

      /* reset */
      adaptive_pid_init( apid );
   }
   else /* dejitter_result == 0 */
   {
      /* no action necessary */
   }
}

