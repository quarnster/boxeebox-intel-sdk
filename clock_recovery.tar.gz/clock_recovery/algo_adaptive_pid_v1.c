/*
  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2007-2009  Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2007-2009  Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


#include "algo_adaptive_pid.h"
#include "osal.h"
#include "clock_recovery_local_defs.h"
#include "sven_event_type.h"
#include "sven.h"


//#define SELF_TEST
#define ENABLE_SVEN

#define ADAPTIVE_PID_JTERM_MAX               0x100
#define PID_PPM_LOPASS_SIZE   7


#ifdef SELF_TEST
#include <stdio.h>
//#include <stdlib.h>
#endif

/** Initialize/Reset the adaptive P.I.D. controller algorithm
 */
void adaptive_pid_init_v1(
    AdaptivePID      *apid )
{
    SoftPLL          *spll = &apid->spll;
    int               i;

    spll->state = SOFTPLL_FreeRun;
    spll->in_tuple_pos = 0;

    // Userdata should not be initialized to NULL as this
    // is used during discontinuity detection.
    // spll->ppm_userdata = NULL;

    spll->error_untrackable = false;
    spll->ppm_saturate = 15;
    spll->clock_locked = false;

    apid->pid.term_diff    = 0;
    apid->pid.term_int     = 0;
    apid->pid.pgain        = (int)(0.1 * (float)(1<<10));   /* proportional gain */
    apid->pid.igain        = (int)(0.0 * (float)(1<<10));   /* integral gain */
    apid->pid.dgain        = (int)(0.5 * (float)(1<<10));   /* differential gain */

    apid->pid.integral_max =  SOFTPLL_PCR_FREQ;
    apid->pid.integral_min = -SOFTPLL_PCR_FREQ;

    apid->pid.jgain        = (int)(0.2 * (float)(1<<8));    /* jitter gain */

    /* add to lowpass adjustment filter */
    for ( i = 0; i < PID_PPM_LOPASS_SIZE; i++ )
    {
       apid->pid.ppm[i] = 0;
    }
}

static void softpll_set_dds_ppm(
    SoftPLL          *spll,
    int              ppm )
{
    if(spll->ppm_userdata == NULL) 
    {
       OS_INFO("Clock Recovery Algo struct handle is NULL\n");
       OS_INFO("Not adjusting the clock. Pls set valid algo using clock_sync_set_algorithm().\n");
    }
    else
    {
       (*spll->set_dds_ppm)( spll->ppm_userdata, ppm  );
    }
}



/* De-jitter this sample
 * returns:
 *
 *    -1 = discontinuity detected
 *    0 = sample appended to dejitter buffer
 *    1 = dejitter buffer is full, tuple at "minpos" contains smallest PCR/STC pair
 *
 */
static int softpll_dejitter_sample(
    SoftPLL        *spll,
    int              pcr,
    int              stc,
    int             *pminpos )
{
   int         discontinuity_detected = 0;
   int         retval = 0;

   /* Add it */
   spll->in_tuple[ spll->in_tuple_pos ].pcr = pcr; /* high jitter PCR */
   spll->in_tuple[ spll->in_tuple_pos ].stc = stc; /* Wall Clock at PCR capture */
   spll->in_tuple_pos++;

   if ( SOFTPLL_TUPLE_GROUP_SIZE == spll->in_tuple_pos)
   {
      int         i,minpos;
      int         clockd;

      spll->in_tuple_pos = 0;     /* Change state */

      /* calculate initial offset */
      minpos = 0;
      clockd = spll->in_tuple[0].pcr - spll->in_tuple[0].stc;

      /* find lowest jitter */
      for ( i = 1; i < SOFTPLL_TUPLE_GROUP_SIZE; i++ )
      {
          int     dt;

          dt = (spll->in_tuple[i].pcr - clockd) -
                spll->in_tuple[i].stc;

          if ( (dt > SOFTPLL_DISCONTINUITY_THRESHHOLD) ||
               (dt < -SOFTPLL_DISCONTINUITY_THRESHHOLD) )
          {
              discontinuity_detected = 1;
              break;
          }
          else if ( dt < 0 ) /* less than before */
          {
              clockd += dt;
              minpos = i;
          }
          else
          {
          }
      }

      /* smallest clock difference of this group */
      *pminpos = minpos;
      retval = 1;
   }

   if ( 0 != discontinuity_detected )
   {
      /* algorithm needs reset */
      retval = -1;
   }

   return( retval );
}


/* Add a new PCR to the AdaptivePID, for tracking.
 */
void adaptive_pid_append_sample_v1(
    AdaptivePID      *apid,
    int              pcr,
    int              stc )
{
   SoftPLL            *spll = &apid->spll;
   int                 dejit;
   int                 minpos = 0;

   dejit = softpll_dejitter_sample( spll, pcr, stc, &minpos );

   #ifdef ENABLE_SVEN
   {
      int i,dt;

      /* write out all PCRs and STCs during startup */
      i = spll->in_tuple_pos - 1;

      if ((SOFTPLL_FreeRun == spll->state) || (SOFTPLL_Setup == spll->state) )
      {
         dt = spll->in_tuple[0].pcr - spll->in_tuple[0].stc;
      }
      else
      {
         dt = spll->stc_dt;
      }

      smd_core_send_sven_event(dbg_devh,
         SVEN_EV_SMDCore_SoftPLL_PCR_Arrive,
         spll->in_tuple[i].pcr,
         spll->in_tuple[i].stc,
         (spll->in_tuple[i].pcr - dt) - spll->in_tuple[i].stc,
         i,
         spll->state,
         0 );
   }
   #endif

   if ( dejit > 0 )  /* time to evaluate */
   {
      if ( SOFTPLL_FreeRun == spll->state )
      {
         spll->state = SOFTPLL_Acquiring;

         /* Initial Clock Difference */
         spll->stc_dt = spll->in_tuple[minpos].pcr - spll->in_tuple[minpos].stc;

         /* Clock at start */
         spll->start.pcr = spll->in_tuple[minpos].pcr;
         spll->start.stc = spll->in_tuple[minpos].stc;
         spll->start_dpcr = 0;
         spll->start_ppm = SOFTPLL_UNITY_PPM;

         /* State at last clock correction */
         spll->correct.stc = spll->in_tuple[minpos].stc;
         spll->correct_dpcr = 0;
         spll->correct_ppm = SOFTPLL_UNITY_PPM;
      }
      else if ( SOFTPLL_Acquiring == spll->state )
      {
         /*
          *  ^
          *  |
          * P|
          * C|                            * *
          * R|                           *
          *  |                       *
          * t|                *  *
          * i|           *
          * m|              *
          * e|     *    *
          *  |    *
          *  *
          *  |
          *--+-------------------------------------->
          *  |  (STC at PCR Arrival, zero jitter)
          *  |
          *
          */
         int        i;                 /*  */
         int        ppm;               /* parts-per-million to adjust */
         int        pterm,dterm,iterm; /* P, I, and D calculations */
         int        jterm;             /* jitter term */
         int        window_dt;         /* duration (int ticks) of this data */
         int        mindpcr;           /* de--jittered correction */

         unsigned long long  dt_since_last_correction;

         dt_since_last_correction =
                  spll->in_tuple[SOFTPLL_TUPLE_GROUP_SIZE-1].stc -
                  spll->correct.stc;

         /* what is the dejittered PCR difference? */
         mindpcr = (spll->in_tuple[minpos].pcr - spll->stc_dt) -
                    spll->in_tuple[minpos].stc;

         /* how many clocks during sampling interval */
         window_dt = spll->in_tuple[SOFTPLL_TUPLE_GROUP_SIZE-1].stc - spll->in_tuple[0].stc;
         if ( window_dt < SOFTPLL_TUPLE_GROUP_SIZE )
            window_dt = SOFTPLL_TUPLE_GROUP_SIZE;

         jterm = 0;    /* find jitter term */
         for ( i = 1; i < SOFTPLL_TUPLE_GROUP_SIZE; i++ )
         {
            int     dpcr;

            dpcr = (spll->in_tuple[i].pcr - spll->stc_dt) -
                    spll->in_tuple[i].stc;

            jterm += (dpcr - mindpcr);   /* total jitter sum */
         }

         /* calculate proportion PCR intervals is jitter */
         jterm = (jterm * (1<<8)) / window_dt;

         /* create inverse proportion for our multiplier */
         jterm = ADAPTIVE_PID_JTERM_MAX - jterm;

         if ( jterm <= 0 )
            jterm = 1;
         else if ( jterm > ADAPTIVE_PID_JTERM_MAX )
            jterm = ADAPTIVE_PID_JTERM_MAX;

         /* calculate proportional term */
         pterm = (mindpcr * apid->pid.pgain) >> 10;

         /* add integrator */
         apid->pid.term_int += mindpcr;

         /* clamp integration */
         if ( apid->pid.term_int > apid->pid.integral_max )
            apid->pid.term_int = apid->pid.integral_max;
         else if ( apid->pid.term_int < apid->pid.integral_min )
            apid->pid.term_int = apid->pid.integral_min;

         /* integrative term */
         iterm = (apid->pid.term_int * apid->pid.igain) >> 10;

         /* differential term */
         dterm = ((mindpcr - spll->last_dpcr) * apid->pid.dgain) >> 8;

         ppm = ((pterm + iterm + dterm) * jterm) >> 11;

         /* add to lowpass adjustment filter */
         for ( i = 0; i < PID_PPM_LOPASS_SIZE-1; i++ )
         {
            apid->pid.ppm[i] = apid->pid.ppm[i+1];
         }
         apid->pid.ppm[PID_PPM_LOPASS_SIZE-1] = ppm;

         ppm = 0;
         for ( i = 0; i < PID_PPM_LOPASS_SIZE; i++ )
         {
            ppm += apid->pid.ppm[i];
         }
         ppm /= PID_PPM_LOPASS_SIZE;

         #define MAX_PPM_ADJUST 4
         if ( ppm > MAX_PPM_ADJUST )        ppm = MAX_PPM_ADJUST;
         else if ( ppm < -MAX_PPM_ADJUST )  ppm = -MAX_PPM_ADJUST;

         #ifdef ENABLE_SVEN
         smd_core_send_sven_event(dbg_devh,
                     SVEN_EV_SMDCore_SoftPLL_DriftStatus,
                     spll->in_tuple[minpos].pcr,
                     spll->in_tuple[minpos].stc,
                     mindpcr,
                     dt_since_last_correction,
                     pterm + iterm + dterm,
                     jterm );
         #endif

         if ( 0 != ppm )
         {
            spll->correct_ppm += ppm;

            #define CLAMP   200
            /* CLAMP maximum adjustment to +- 80 ppm */
            spll->correct_ppm -= SOFTPLL_UNITY_PPM;
            if ( spll->correct_ppm > CLAMP )         spll->correct_ppm = CLAMP;
            else if ( spll->correct_ppm < -CLAMP )   spll->correct_ppm = -CLAMP;
            spll->correct_ppm += SOFTPLL_UNITY_PPM;

            /* tune the clock, addition of parts-per-million to the clock */
            softpll_set_dds_ppm( spll, spll->correct_ppm );

            #ifdef ENABLE_SVEN
            smd_core_send_sven_event(dbg_devh,
                               SVEN_EV_SMDCore_SoftPLL_NudgeClock,
                               spll->in_tuple[minpos].pcr,
                               spll->in_tuple[minpos].stc,
                               mindpcr,
                               dt_since_last_correction,
                               jterm,
                               ppm );
            #endif

            spll->correct.stc = spll->in_tuple[SOFTPLL_TUPLE_GROUP_SIZE-1].stc;
         }

         #ifdef SELF_TEST
         printf("PID: dt: %6d st: %6d [p %6d i %6d d %6d j %6d] ppm %4d %5d\n",
         mindpcr, window_dt, pterm, iterm, dterm, jterm, ppm,
         spll->correct_ppm - SOFTPLL_UNITY_PPM);
         #endif

         spll->last_dpcr = mindpcr;
      }
      else
      {
      }
   }
   else if ( dejit < 0 )   /* discontinuity detected */
   {
      spll->clock_locked = false;

      #ifdef SELF_TEST
      OS_PRINT("\ndiscontinuity\n");
      #endif

      #ifdef ENABLE_SVEN
      smd_core_send_sven_event(dbg_devh,
         SVEN_EV_SMDCore_SoftPLL_Discontinuity,
         spll->in_tuple[spll->in_tuple_pos-1].pcr,
         spll->in_tuple[spll->in_tuple_pos-1].stc,
         (spll->in_tuple[spll->in_tuple_pos-1].pcr - spll->stc_dt)-spll->in_tuple[spll->in_tuple_pos-1].stc,
         spll->in_tuple_pos-1,
         spll->state,
         0 );
      #endif

      /* reset */
      adaptive_pid_init_v1( apid );
   }
   else /* dejit == 0 */
   {
      /* no action necessary */
   }
}
