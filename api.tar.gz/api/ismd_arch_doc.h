/*

This file is provided under a dual BSD/GPLv2 license.  When using or
redistributing this file, you may do so under either license.

GPL LICENSE SUMMARY

Copyright(c) 2010 Intel Corporation. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
The full GNU General Public License is included in this distribution
in the file called LICENSE.GPL.

Contact Information:

Intel Corporation
2200 Mission College Blvd.
Santa Clara, CA  97052

BSD LICENSE

Copyright(c) 2010 Intel Corporation. All rights reserved.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in
the documentation and/or other materials provided with the
distribution.
* Neither the name of Intel Corporation nor the names of its
contributors may be used to endorse or promote products derived
from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



   /** @weakgroup new_smd_arch  Chapter 1 SMD Architecture
     \brief This  chapter provides description of SMD Core Components.

     \anchor Contents
	 	 	 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Contents</H2>
	 	      - <A HREF=#smdIntro style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 1A Introduction</A>
     		  - <A HREF=#smdFeatures style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 1B  SMD Features</A>
     		  - <A HREF=#smdInter style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 1C  SMD Interfaces and SMD Components</A>







\anchor smdIntro
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 1A Introduction </h2>


\anchor smdFeatures
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">  1B SMD Features </h2>
The Streaming Media Drivers (SMD) subsystem exposes control over the streaming media processing capabilities of Intel media processors. Streaming media processing includes input, output, parsing, encoding, decoding, filtering, and timing of compressed and raw audio and video data and related metadata.
 SMD provides the following features:
-# General
	-# Memory management of media buffers,Efficient data flow between media pipeline components.
	-# Presentation timing,Clock recovery/synchronization with live sources.
	-# 	Features allowing higher level software to implement trick modes.
-# Transport and Program Stream (TS/PS) Processing
	-# De-multiplexing of MPEG2 TS and PS
	-# Receive/Transmit MPEG2 TS via hardware TS interfaces, with optional timestamp headers
	-# Decrypt TS packet payload using  cryptos AES/DES/3DES/Multi2/DVB-CSA
-# Audio
	-# Capture samples from 2-channel I2S input, Decode of up to two streams of compressed audio.
	-# Mix up to three streams of audio (2 compressed and 1 stereo PCM), including sample rate conversion.
	-# Simultaneous audio output via HDMI, S/PDIF, and I2S, potentially at different sample rates and channel configurations.
	-# DTS and AC3 encoding for output of mixed, 5.1 channel audio via S/PDIF.
-# Video Decode
	-# Decode of up to 2 video streams.
	-# Optional skipping of P, B, and non reference frames frames (for MPEG2)
	-# Decoded frames provided in display order with timestamps
	-# Allows setting of a fixed frame rate for output frames independent of original PTS values
	-# Extraction of ancillary stream data including closed caption data, pan-and-scan vectors, etc.
-# Video Post-processing
	-# Scaling, 3:2 pull-down for 60i output of progressive content.
	-# De-interlacing, including reverse telecine.
	-# Gamma conversion,Pixel format conversion,Film Grain Technology
\anchor smdInterfaces
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 1C SMD Interfaces and SMD Components </h2>

\image  html arch1.png Fig.1. SMD Interfaces

-# SMD C API: The base API for SMD is called the SMD C API. Applications and middleware may be written or ported directly to the SMD C API, or to other APIs exposed via wrappers written on top of the SMD C API.
	-# The SMD C API is a union of the general functions provided by SMD Core and of various specific capabilities provided by the SMD Modules.
	-# On Linux, the SMD C API is accessible to both kernel modules and user space processes.
-# OS Audio API: The API typically used by applications to play sounds on a particular OS (e.g. DirectSound on Windows, ALSA on Linux). The sounds played via this interface are called application audio or asynchronous audio. An OS-specific audio driver must be implemented for each target OS, to integrate SMD�s asynchronous audio input into the OS audio infrastructure. SMD mixes asynchronous audio provided via OS Audio API with any other active �audio streams.�
-# Streaming Infrastructure API: Various 3rd party audio/video streaming infrastructures exist (e.g. DirectShow, GStreamer, or Windows kernel streaming). SMD includes plug-ins for some of those infrastructures, providing interoperability with 3rd party plug-ins and very easy integration with any application written to the supported infrastructures.
-# Middleware Driver API: Some 3rd party middlewares impose very specific API requirements on their underlying drivers. For example, some middlewares rely on POSIX-style APIs, requiring their drivers to be kernel modules on Linux. Although wrappers to expose such middleware-specific driver APIs are outside of the scope of SMD, the SMD C API must conform to certain constraints to allow the implementation of the important wrappers.

 \image html arch2.png Fig.2. SMD Components


	SMD includes the following components:
	-# SMD Core :SMD core is to a set of base services used by all SMD applications and modules as shown in Fig.1 The SMD Core comprises of 6 basic components:
		-# Clock Manager : synchronize media processing elements
		-# Port Manager :data flow of media buffers through pipelines
		-# Memory Manager :allocation and tracking of physically-contiguous buffers containing media data.
		-# Event Manager :notify applications of asynchronous events
		-# device Manager: defines and provides access to standard functions that every SMD module must support.
		-# Buffer Monitor : detecting buffer overruns and underruns.
For  detail information on this module refer to the  - \ref new_smd_core " SMD Core "

	-# SMD Demux : The Intel� CE Media Processor demux module seperates an incoming stream into Audio  and/or video  streams along with some ancillary information.
  The input stream can be a Transport Stream(TS) or Program Stream(PS).
  For  detail information on this module refer to the  SMD Core Chapter - \ref new_smd_core " SMD Core "
For  detail information on this module refer to   - \ref new_smd_demux " SMD Demux "

-# SMD Audio : Audio subsystem  is a powerful and complex audio processing engine. Audio subsystem  caters to  high-definition and high-resolution audio processing to provide
the highest quality of sound experience available in today's consumer electronics.  It is capable of accepting multiple audio streams as input,
processing and mixing the audio streams into one output stream, and rendering the output audio stream at  multiple  audio output interfaces.
In addition, Audio Processor also provides the ability of audio presentation-timing control for audio/video (A/V) synchronization in consumer electronics
applications, such as Blue Laser players, Internet Protocol (IP) set-top boxes (IP-STB), connected consumer electronic (CCE) products, cable set-top boxes, etc.

For  detail information on this module refer to   - \ref new_smd_audio " SMD Audio "

-# SMD Video Decode : The SMD MFD host software provides an application level interface to video codec accelerators on Intel's CE  SoCs. The Intel's CE Media Processor
contains HW video decode capabilities for many of the most common video formats in use today such as MPEG2.
For  detail information on this module refer to   - \ref new_smd_video " SMD Video "

-# SMD Video Post Processor : Video Postprocesor also referred as Display Processing Engine  or DPE  is an Intel Streaming Media device responsible for post processing of the decoded frames. DPE receives decoded frames with PTS and applies various processing algorithms before sending the frames to the renderer.

For  detail information on this module refer to   - \ref new_smd_video " SMD Video "
-# SMD Video Renderer : The video renderer is an Intel Streaming Media Device (ISMD) on the Intel? CE Media Processor responsible for presenting uncompressed video data to the display at the correct time. The source of the uncompressed video content can be a hardware/software codec or video composed by a graphics unit or a compositor and they are written to the renderer?s input port. The presentation timestamp, the display rate and the content rate together determine when a new frame or field is sent to the display. The renderer interacts with the display driver through a Linux kernel interface called the Video Back Door (VBD). Video renderer is a software only kernel module; it allows the application to open multiple (currently16) instances (one instance per stream). Each instance operates independently.

For  detail information on this module refer to   - \ref new_smd_video " SMD Video "

 */


