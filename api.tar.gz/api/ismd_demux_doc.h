/*

This file is provided under a dual BSD/GPLv2 license.  When using or
redistributing this file, you may do so under either license.

GPL LICENSE SUMMARY

Copyright(c) 2010-2011 Intel Corporation. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
The full GNU General Public License is included in this distribution
in the file called LICENSE.GPL.

Contact Information:

Intel Corporation
2200 Mission College Blvd.
Santa Clara, CA  97052

BSD LICENSE

Copyright(c) 2010-2011 Intel Corporation. All rights reserved.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in
the documentation and/or other materials provided with the
distribution.
* Neither the name of Intel Corporation nor the names of its
contributors may be used to endorse or promote products derived
from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



   /** @weakgroup new_smd_demux  Chapter 3 SMD Demux
     \brief This  chapter provides description of SMD Core Components.

     \anchor Contents
	 	 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Contents</H2>
	      - <A HREF=#DemuxIntro style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt" > 3A Introduction</A>
     		- <A HREF=#Demuxfeatures> 3A.1 Key Features</A>
     		- <A HREF=#DemuxInput> 3A.2 Demux Input and Outputs</A>
     	 	- <A HREF=#DemuxComp> 3A.3  Software Components of Demux System</A>

     	 - <A HREF=#DemuxTS style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 3B Handling a Transport Stream</A>
			- <A HREF=#DemuxTSa> 3B.1 Open Stream</A>
			- <A HREF=#DemuxTSb> 3B.2 Configure Filters</A>
     	 		- <A HREF=#DemuxTSb1> 3B.2.1 Elementary Filters</A>
				- <A HREF=#DemuxTSb2> 3B.2.2 PSI/Section Filters</A>
				- <A HREF=#DemuxTSb3> 3B.2.3 TS Packet Filter</A>
				- <A HREF=#DemuxTSb4> 3B.2.4 Stream Index Filter</A>
				- <A HREF=#DemuxTSb5> 3B.3 Crypto Settings</A>
           	 	- <A HREF=#DemuxTSb6> 3B.4 How to Read Output Buffers</A>
            - <A HREF=#DemuxTSc> 3B.5 Notes for channel changing </A>




           - <A HREF=#DemuxCode style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 3C Code Snippets</A>
           		- <A HREF=#DemuxCode1> 3C.1  TS File Input Thread</A>
           		- <A HREF=#DemuxCode2> 3C.2 ES Filter Output Thread</A>
           		- <A HREF=#DemuxCode3> 3C.3 ES for TS</A>
           		- <A HREF=#DemuxCode4> 3C.4  Section Filter for TS</A>
           		- <A HREF=#DemuxCode5> 3C.5 DVR/PVR for TS</A>

- <A HREF=#DemuxAPI>  Reference to Demux API</A>

   - <A HREF=#Remux style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 3D.4 Remux</A>
     		- <A HREF=#RemuxOver> 3D.1  Overview and Architecture</A>
          	- <A HREF=#RemuxCfg> 3D.2  Configuring MVC Remux</A>
        	- <A HREF=#RemuxCode> 3D.3 Sample Code : Remux Setup</A>
          	- <A HREF=#RemuxMPTS> 3D.4 MPTS 3DBD Pipe</A>
          	- <A HREF=#RemuxSSIF> 3D.5 SSIF 3DBD Pipe</A>

  - <A HREF=#RemuxAPI style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">  Reference to Remux API</A>


\anchor DemuxIntro
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3A  Intorduction</h2>

  The Intel� CE Media Processor demux module seperates an incoming stream into Audio  and/or video  streams along with some ancillary information.
  The input stream can be a Transport Stream(TS) or Program Stream(PS).
  \image html Demux.png " Fig.1 SMD Core Components"

  \anchor Demuxfeatures
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3A.1  Key Features</h2>
   -# 188 Bytes Transport stream demultiplexing, supporting Audio, Video Element Stream output, PSI section data output and TS packet output.
   -# 192 Bytes Transport stream demultiplexing (MPEG2 Transport Stream with additional 4 byte timestamp header preceding each TS packet).
   -# DVD Program Stream demultiplexing.
   -#  Support Open Cable transport stream multiplexing and demultiplexing.
   -# Support four serial external TS sources through NIM 0~3. (*for CE3100 only?)
   -# Intel CE3100/4100 media processor support six instances of the demux which can receive different input source (like NIM 0~3 or file) and output demultiplexing result independently. The Intel CE4200 media processor supports sixteen instances of the demux.
   -# Extract the Program Clock Reference (PCR) timestamp field from the incoming transport steam, and recreate 27-MHz program clock from the broadcast stream.
   -# MPEG2 Video Content Indexing for PVR (TS only).  No support is provided for other video formats like VC-1 or H.264.
`  -# DVB-CSA, AES/DES/3DES descrambling
   -# Support for PSI/section filtering and basic indexing.
   -# For the CE4200 demux, advanced indexing is supported.

<br>
<br>
  \anchor DemuxInput
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3A.2  Demux Inputs and Outputs</h2>

Demux subsystem receives inputs via two interfaces

Logical Interfaces : are standard SMD Ports where buffers can be read by the clientsfrom/to the disk controller or network stack.
Physical Interfaces :  . Physical interfaces correspond to specific HW NIM (Network Interface Module) interface (not on CE4200?).

Demux can handle two types of Inputs and is capable of processing up to six input streams simultaneously, with a maximum of two of them being program streams.
-# DVD  TS
-#  DVD PS


 \anchor DemuxComp
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">3A.3  Software Components of Demux System</h2>
The demux uses three core types of elements: streams, PID/SID, and filters. A stream is synonymous with an input data stream, filters are output data streams, and PID/SID is the numeric packet ids found in transport streams and program streams. The mapping of PID/SID list to a filter determines which packets will become part of the filter output data. A filter is configured with a format type which determines the elements of a packet to send. For example, a transport stream filter would output an unmodified TS packet, while an ES filter would extract the ES payload and timestamp and then drop the rest of the packet.

\anchor DemuxTS
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B  Handling a Transport Stream</h2>

To use the demux to handle a transport stream, the following steps should be followed.
-# Open a stream
-# Configure filters
-# Enable stream to process data
-# Close stream

\anchor DemuxTSa
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.1  Open a Stream</h2>

The Fig.2 shows the sequence digram for opening a stream.
\image demux2.png Fig.2. Open a Stream Sequence Diagram
Opening a stream means to create a demux instance for the specified input source. For transport streams, there are two types of input sources. One input source is the hardware NIM interface; the other is from memory, like streaming data from a file, network or other devices.


For TS stream input from a NIM interface, API:
\code ismd_result_t ismd_tsin_open ismd_tsin_open  (int interface_id,  ismd_dev_t *  handle) \endcode
This will open a stream which receives TS data from a hardware NIM "interface_id" and returns a stream handle if successful. There are some stream configuration APIs for customizing the setup of the environment.
\code
/*Configure input stream is normal TS or Open Cable TS*/
ismd_result_t SMDEXPORT ismd_demux_tsin_set_open_cable_mode(ismd_dev_handle_t  demux_handle, enum ismd_demux_open_cable_mode  mode)
/*Configure NIM interface parameters, like clock polarity, error polarity. etc*/
ismd_result_t SMDEXPORT ismd_demux_tsin_set_nim_config(ismd_dev_t handle, ismd_demux_tsin_nim_config_t*  nim_config)
\endcode
The Intel� CE Media Processor supports up to 4 NIM interfaces, HW NIM id is 0~3.

<br>
<br>

\code
// Open a stream from the memory
ismd_result_t SMDCONNECTION ismd_demux_stream_open(ismd_demux_input_stream_type_t  stream_type, ismd_dev_t* handle, ismd_port_handle_t*  port_handle )

// This will open a stream which receives TS data from an SMD input port "port_handle". When opening a TS stream, the "stream_type" is specified by the caller for either a standard 188-byte MPEG2 transport stream, or a 192-byte MPEG2 transport stream. Normally, another process or thread will be used to write SMD buffers (original TS packets) to �port_handle� as input source for the demux instance. When everything is ready, the application should set the demux instance to �PLAY� status to enable the stream, as shown below.
ismd_dev_set_state(g_ts_dev_handle, ISMD_DEV_STATE_PLAY) ;
\endcode

<br>
<br>
\anchor DemuxTSb
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.2  Configure Filters</h2>

The Intel� CE Media Processor demux supplies multiple types of TS filters for different output streams.  Support is provided for elementary stream, PSI packets, transport packets, and MPEG-2 video index information.


\anchor DemuxTSb1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.2.1  Elementary Stream Filter</h2>

For video/audio streams, the Intel� CE Media Processor decoders all operate on elementary stream data at their input.  Therefore, elementary stream filters are required when feeding the decoders.  The Intel� CE Media Processor demux will parse TS packets and generate elementary stream data into SMD buffers, and output it from the elementary stream filter�s output port. Meanwhile, the SMD buffers have some extra data fields which indicate private attributes for the elementary streams.




<h3> Step 1: Create the elementary stream filter </h3>
\code
    /*1, Call ismd_demux_filter_open to create Element stream filter, parameter ISMD_DEMUX_OUTPUT_ES indicate this is Element stream filter */
ismd_result_t SMDEXPORT ismd_demux_filter_open(
ismd_dev_t  handle,                                                 /*demux device handle which was opened before*/
ismd_demux_filter_output_format_t  op_format,   /*Filter Type, for ES filter, should be ISMD_DEMUX_OUTPUT_ES */
unsigned  output_buf_size,                                     /*Maximum size of each output buffer*/
ismd_demux_filter_handle_t *  filter_handle,       /* Opened filter handle */
ismd_port_handle_t *  port_handle                        /*ES output port */
) ;
\endcode
Upon successful creation of the filter, the function returns a handle to the newly created filter (which can later be used for mapping PIDs to the filter) and a handle "port_handle" to the filter�s output port which can be connected to the desired downstream unit.

<h3> Step 2: Set the video or audio PID which can be found in the PMT table </h3>
For elementary stream filters, only one PID should be mapped to one filter, and PID type should be "ISMD_DEMUX_PID_TYPE_PES".  For example:
\code
/* 2, map pid to filter, set PID list first, then call �ismd_demux_filter_map_to_pids� */
pid_list.pid_array[0].pid_val = pid ;
pid_list.pid_array[0].pid_type = ISMD_DEMUX_PID_TYPE_PES ;
ismd_demux_filter_map_to_pids(ts_dev_handle, *p_filter_handle, pid_list, 1)  ;

\endcode

<h3> Step 3: For encrypted streams enable the crypto </h3>
For information on  how to enable the encrypted streams refer to  - <A HREF=#DemuxTSb5> 3B.2.5 Crypto Settings</A>


<h3> Step 4: Enable the Filter </h3>
Finally, use the API \code ismd_demux_filter_start to enable the filter \endcode. If demux is working correctly, the elementary stream buffer will be sent to filter�s output port.
\code /* 4, start demux PES filter */
ismd_demux_filter_start(ts_dev_handle, *p_filter_handle) ;
\endcode


<h3> Step 5: Close a Stream </h3>
Before the application quits or changes to another stream, please close all filters and release all resources allocated. Next, set the demux state to ISMD_DEV_STATE_STOP.  Then, close the demux to free the demux instance.
\code
//1, close all open filters
�.

//2, stop demux
ismd_dev_set_state(ts_dev_handle, ISMD_DEV_STATE_STOP) ;

//3, close demux
ismd_demux_stream_close(ts_dev_handle) ;

\endcode

\anchor DemuxTSb2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.2.2  PSI Section Filter</h2>

For TS streams, the PSI (program system information) is transported as section table data, and DVB defines some similar data structures for transporting private information to clients, like EPG (Electric Program Guide). Most silicon vendors support a section filters function for the customer to get the required section data. The Intel� CE Media Processor supports section filters too. The following section filtering features are supported.
-# Intel CE3100/4100 media processor support 32 section filters and every section filter support up to 24 byte depth filtering.
-# Intel CE4200 media processor support 256 section filters and every section filter support up to 24 byte depth filtering.
-# Every section filter has two level filters, the first level is PID, and second is table ID or section data match and mask check.
-# At most 2 section filters can be mapped to same PID.
-# Every section filter can be created/destroyed dynamically and independently, even the section filter that has the same PID as another working section filter. This means that the old section filter which has same PID will keep working when the customer adds a new section filter or destroys one whose PID is same as the PID of working section filter.
-# Support negative mask/match filtering feature for performance consideration.
-# Section will be abandoned if CRC check fail.
Enabling section filters is a little more complex than configuring an ES filter. First, create the demux filter and map the PID to the filter, just similar to ES filter. But the filter type and PID type should be changed to �ISMD_DEMUX_OUTPUT_PSI� and �ISMD_DEMUX_PID_TYPE_PSI� respectively.

\code
    /*1, Call ismd_demux_filter_open to create PSI/section filter, parameter �ISMD_DEMUX_OUTPUT_PSI� indicate this is PSI filter */
ismd_result_t ismd_demux_filter_open(
ismd_dev_t  handle,                                                              /*demux device handle which opened before*/
ismd_demux_filter_output_format_t  op_format,                /* Filter Type, for section filter, should be  */
/* �ISMD_DEMUX_OUTPUT_PSI� */
unsigned  output_buf_size,                                                   /*Maximum size of each output buffer*/
ismd_demux_filter_handle_t *  filter_handle,                      /* Opened filter handle */
ismd_port_handle_t *  port_handle                                      /*section date output port */
) ;

/* 2, map pid to filter, set PID list first, then call �ismd_demux_filter_map_to_pids� */
pid_list.pid_array[0].pid_val = pid ;
pid_list.pid_array[0].pid_type = ISMD_DEMUX_PID_TYPE_PSI ;
ismd_demux_filter_map_to_pids(handle, filter_handle, pid_list, 1)  ;

\endcode

Output_buf_size specifies the size of output PSI buffers which should be defined in memory layout. For CE3100/CE4100, cached output PSI buffers are used for section filters to improve performance. The output PSI buffers need to be defined as cached memory by option �cached=1�. Example:
	\code
	smd_buffers_DMX_PSI    { buf_size =   0x1000  base = 0x01700000  size = 0x00100000 cached = 1 } // (  1MB) 256x4KB PSI Output
	\endcode
The next key step is creating and configuring a section filter, and setting the right section filter parameter to the filter. Note that All sections will be abandoned if no section filter connected to the demux filter.

\code
//3, create section filter based on demux filer which created in step 1
ismd_demux_section_filter_open(handle, filter_handle, pid, &section_filter_handle)  ;

//4, set parameter to section filter
psi_filter_parameter.tid = 0 ; //will be ignored after set other fields
psi_filter_parameter.section_offset = 0 ;
memset(psi_filter_parameter.negative_filter, 0, ISMD_DEMUX_SF_MASK_SIZE ) ;
memset(psi_filter_parameter.negative_mask, 0, ISMD_DEMUX_SF_MASK_SIZE) ;
if(ISMD_DEMUX_SF_MASK_SIZE < filter_length){
    ERROR_MSG("Input section filter data length is too long; size=%d\n", filter_length);
    filter_length = ISMD_DEMUX_SF_MASK_SIZE ;
}
memcpy(psi_filter_parameter.positive_filter, p_filter_data, filter_length) ;
memcpy(psi_filter_parameter.positive_mask, p_filter_mask, filter_length) ;
if(ISMD_DEMUX_SF_MASK_SIZE > filter_length){
    memset(&psi_filter_parameter.positive_filter[filter_legnth], 0, ISMD_DEMUX_SF_MASK_SIZE - filter_length) ;
    memset(&psi_filter_parameter.positive_mask[filter_legnth], 0, ISMD_DEMUX_SF_MASK_SIZE - filter_length) ;
}
ismd_demux_section_filter_set_params(handle, section_filter_handle, &psi_filter_parameter) ;
\endocde
From the algorithm, section table ID will be checked if section_offset is non-zero or positive filter and negative filter is not enabled (there is not any one bit in either positive_mask or negative_mask fields be set). Secondly, check positive match/mask, if any pair of match/mask fails (not equal), then the whole match/mask will also fail. This section is not matched.
If a negative filter is enabled, check negative match/mask, if any pair of match/mask fails, then this section is matched. This is different from positive filter.
\code
/* check table ID, must check if section_offset non-zero */
If(section_offset && tid != section_data[0]) then this section is not matched (it will be abandoned)

/* check table ID if all positive_mask and negative_mask is 0 */
If(!section_offset && (positive_mask[i]==0) && (negative_mask[i]==0) && (tid != section_data[0])), i is from 0 to ISMD_DEMUX_SF_MASK_SIZE, then this section is not matched

For(i=0; i < ISMD_DEMUX_SF_MASK_SIZE; i++){
/* check if all positive match/mask is ok */
If((section_data[section_offset + i] & positive_mask[i]) != (positive_filter[i] & positive_mask[i])),
Then this section is not matched
}
/* check if any negative mask is non-zero, that means negative filter is enabled. Otherwise this section is accept */
For(i=0; i < ISMD_DEMUX_SF_MASK_SIZE; i++){
If(negative_mask[i]!=0) then {
     /* if negative filter enable, and all negative match/mask are equal, this section is not accept */
        If((section_data[section_offset + i] & negative_mask[i]) != (negative_filter[i] & negative_mask[i]))
Then this section is matched.
}
}

\endcode

After setting up the section filter parameters, enable the section filter and the demux filter to make it work.
    \code
    //5, start section filter
    ismd_demux_section_filter_start (handle, section_filter_handle)  ;
    //6, start demux filter
    ismd_demux_filter_start(handle, filter_handle) ;
    \endcode
When the section filter is no longer needed, call the stop and close APIs to stop and destroy the section filter.

\code
//1, stop demux filter
ismd_demux_filter_stop(handle, filter_handle)  ;
//2, stop section filter
ismd_demux_section_filter_stop(handle, section_filter_handle) ;
//3, remove pid from demux filter
list_size = ISMD_DEMUX_MAX_PID_LIST;
ismd_demux_filter_get_mapped_pids(handle, filter_handle, &pid_list, &list_size ) ;
ismd_demux_filter_unmap_from_pids(handle, filter_handle, pid_list, list_size)  ;
//4, close section filter
ismd_demux_section_filter_close(handle, section_filter_handle) ;
//5, close demux filter
ismd_demux_filter_close(handle, filter_handle) ;
//set section filter parameter to receive all section data from the section filter
psi_filter_parameter.tid = 0 ; //will be ignored after set other fields
psi_filter_parameter.section_offset = 0 ;
memset(psi_filter_parameter.negative_filter, 0, ISMD_DEMUX_SF_MASK_SIZE ) ;
memset(psi_filter_parameter.negative_mask, 0, ISMD_DEMUX_SF_MASK_SIZE) ;
memset(psi_filter_parameter.positive_filter, 0, ISMD_DEMUX_SF_MASK_SIZE) ;
memset(psi_filter_parameter.positive_mask, 0, ISMD_DEMUX_SF_MASK_SIZE) ;
/*Only compare section_syntax_indicator bit of section data since section_syntax_indicator is always 1*/
psi_filter_parameter.positive.filter_mask[1] = 0x80 ;
psi_filter_parameter.positive.filter_filter[1] = 0x80 ;


 \endcode




\anchor DemuxTSb3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.2.3  TS Packet Filter</h2>
As TS packet filter is a PID level filter for transport streams, it will compare a TS packet�s PID with the mapped PID list and block all unmatched TS packets and output the entire transport stream packets. Typical use cases are PVR (Personal Video Recorder) or DVR (Digital Video Recorder), which will filter MPTS (Multi Program Transport Stream) to SPTS (Single Program Transport Stream). The application can then save the SPTS to disk.
The following key APIs are used to create and destroy a TS stream filter. To create a TS packet filter, call API \code ismd_demux_filter_open\endcode. The filter type should be �ISMD_DEMUX_OUTPUT_WHOLE_TS_PACKET�. The �output_buf_size� should be a multiple of the TS packet size, like 256*188:



\code
ismd_demux_filter_open(ts_dev_handle,  ISMD_DEMUX_OUTPUT_WHOLE_TS_PACKET,
256*188, &spts_filter_handle, &spts_filter_outport)
After successfully opening a TS packet filter, the next step is to map a PID list to the filter. The example, below is a typical PVR PID list setting:
pid_list_size = 0;
pid_list.pid_array[pid_list_size].pid_val  = 0; //PAT table
pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PSI;
pid_list_size++;
pid_list.pid_array[pid_list_size].pid_val  = 1024; //PMT table
pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PSI;
pid_list_size++;
pid_list.pid_array[pid_list_size].pid_val  = 160; //video pid
pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PES;
pid_list_size++;
pid_list.pid_array[pid_list_size].pid_val  = 80; //audio pid
pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PES;
pid_list_size++;
ismd_demux_filter_map_to_pids(ts_dev_handle, spts_filter_handle, pid_list, list_size) ;
\endcode
After the PIDS have been mapped to the filter, call \code ismd_demux_filter_start\endcode to start the filter.  All TS packets who�s PID matches any PID in the mapped PID list will be sent to �spts_filter_outport� as an SMD buffer.
ismd_demux_filter_start(ts_dev_handle, spts_filter_handle) ;
To stop and destroy a TS packet filter, use the following APIs:
\code
//1, stop demux filter
ismd_demux_filter_stop(ts_dev_handle, spts_filter_handle) ;
//2, remove pid from demux filter
list_size = ISMD_DEMUX_MAX_PID_LIST;
ismd_demux_filter_get_mapped_pids (ts_dev_handle, spts_filter_handle, &pid_list, &list_size)  ;
ismd_demux_filter_unmap_from_pids (ts_dev_handle, spts_filter_handle, pid_list, list_size) ;
//3, close demux filter
ismd_demux_filter_close(ts_dev_handle, spts_filter_handle)  ;
\endcode


\anchor DemuxTSb4
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.2.4  Stream Indexing Filter</h2>

Indexing is a PVR functionality that takes an unmodified stream of TS packets and writes them to disk while simultaneously recording the position of the start of significant headers/events in the stream. This is done so that trick modes can be utilized during later playback, like fast forward and fast reverse. Indexing can be only performed on MPEG-2 Video ES bitstreams and only one PID at a time in the ver2 demux (CE3100 and CE4100) but has more features/flexibility in the ver3 demux on CE4200 and beyond. Meanwhile, the index filter must be bound to a TS packet filter.
The legacy  mode of operation which can only be used to index MPEG2 video streams is also available on the ver3 demux for backward compatibility, but it is recommended that the advanced format is used because of the greater flexibility if provides:
-# It can be used to index audio-only streams, by indexing the PES headers only.
-# It can be used to index H.264 streams by marking where the PUSI and RAI bits were set in the TS headers
-# More than one PID may be indexed.  For example, the MPEG2 video ES + PES headers might be indexed on one PID, while PES headers only are indexed on another at the same time.
Note that the output formats for the legacy and advanced modes differ.  The formats are defined below.

\code
//1, create TS packet filter
ismd_demux_filter_open(ts_dev_handle,  ISMD_DEMUX_OUTPUT_WHOLE_TS_PACKET,
256*188, &spts_filter_handle, &spts_filter_outport)
//2, map request PID list to TS packet filter
pid_list_size = 0;
pid_list.pid_array[pid_list_size].pid_val  = 0; //PAT table
pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PSI;
pid_list_size++;
pid_list.pid_array[pid_list_size].pid_val  = 1024; //PMT table
pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PSI;
pid_list_size++;
pid_list.pid_array[pid_list_size].pid_val  = 160; //video pid
pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PES;
pid_list_size++;
pid_list.pid_array[pid_list_size].pid_val  = 80; //audio pid
pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PES;
pid_list_size++;
ismd_demux_filter_map_to_pids(ts_dev_handle, spts_filter_handle, pid_list, list_size) ;

//3, create index filter, index data will output from index_out_port
ismd_demux_filter_open_indexer(ts_dev_handle,  spts_filter_handle, &index_handle, &index_out_port) ;

//4, Configure/enable indexing on the PID(s)
if (CE4100 || CE3100) {
   ismd_demux_ts_set_indexing_on_pid(ts_dev_handle, mepg2_video_pid, true) ;
} else {
   ismd_demux_indexing_configure_pid(ts_dev_handle, 160, ISMD_DEMUX_INDEX_PES_HDR | ISMD_DEMUX_INDEX_MPEG2_VID_ES) ;
   ismd_demux_indexing_configure_pid(ts_dev_handle, 80, ISMD_DEMUX_INDEX_PES_HDR) ;
   ismd_demux_indexing_configure_pid(ts_dev_handle, 0, ISMD_DEMUX_INDEX_TS_HDR_PUSI) ;
}

//5, start TS packet filter and index filter
ismd_demux_filter_start(ts_dev_handle, spts_filter_handle) ;
ismd_demux_filter_start(ts_dev_handle, index_handle) ;
\endcode

The output data structure of the index filter is a private data structure which is defined by Intel. Below is the data structure and description of each data field.
\code
LEGACY FORMAT:
struct {
  char   zero; // unused
  char   one;  // reserved
  char   index_type; // PSI=2, PES, SEQ, GOP, PIC, PCEH, PDE
  char   offset_in_ts_packet;
  char   pic_type; // I (b01), P (b10), B(b11)
  char   five; // unused
  char   six;  // unused
  char   pts_hi_and_valid; // bit7: is PTS Valid; bit 0: 33rd bit of the PTS
  uint32 pts_lo;
  uint32 packet_number; // TS Packet number
} index_data ;

// Indexing Header type values.
#define TSD_INDEX_ID_PSI  (0x2)
#define TSD_INDEX_ID_PES  (0x3)
#define TSD_INDEX_ID_SEQ  (0x4)
#define TSD_INDEX_ID_GOP  (0x5)
#define TSD_INDEX_ID_PIC  (0x6)
#define TSD_INDEX_ID_PCEH (0x7)
#define TSD_INDEX_ID_PDE  (0x8)

// pic_type values, only valid with index_type = PIC (6)
// Value of 0 indicates pic_type undetermined
#define PIC_TYPE_I  (0x1)
#define PIC_TYPE_P  (0x2)
#define PIC_TYPE_B  (0x3)

ADVANCED FORMAT:
// Enumerates the values of the index_type field
enum {
   TSD_INDEX_ID_FIRST_PACKET = 0,
   TSD_INDEX_ID_TS_HDR,
   TSD_INDEX_ID_TS_HDR_PCR,
   TSD_INDEX_ID_TS_HDR_OPCR,
   TSD_INDEX_ID_PES_HDR,
   TSD_INDEX_ID_MPEG_VID_ES
};

// bytes 0-1   : pid (little endian)
// byte  2     : index_type (lower 4 bits), aux_data (upper 4 bits)
// byte  3     : offset in TS packet
// bytes 4-7   : packet number (relative to TS output filter) (little endian)
// bytes 8-11  : time since indexing enabled, in 90kHz ticks (little endian)
// bytes 12-15 : data (depends on index type) (little endian)
struct {
  char record[16];
} index_data;

// The interpretation of the data and aux_data fields depends on index_type.
// TSD_INDEX_ID_FIRST_PACKET: Neither data nor aux_data are used,
// TSD_INDEX_ID_TS_HDR:
//       data: bit 0: TS packet header PUSI bit set
//             bit 1: TS header Adaptation Field RAI flag set
//             bit 2: TS header Adaptation Field ES priority flag set
//             bit 3: TS header Adaptation Field splice flag set
//             bit 4: TS header Adaptation Field Transport Pvt flag set
//             bit 5: TS header Adaptation Field extension available
//             bit 6: TS header Adaptation Field discontinuity indicator set
//       aux_data: not used
// TSD_INDEX_ID_TS_HDR_PCR:
//       data: bits 0-31: lower 32 bits of PCR base
//       aux_data: bit 0: 33rd bit of PCR base
// TSD_INDEX_ID_TS_HDR_OPCR:
//       data: bits 0-31: lower 32 bits of OPCR base
//       aux_data: bit 0: 33rd bit of OPCR base
// TSD_INDEX_ID_PES_HDR:
//       data: bits 0-31: lower 32 bits of PTS, if PTS_available
//       aux_data: bit 0: PTS_available - 1 if PTS 0 otherwise
//                 bit 1: 33rd bit of PTS, if PTS_available
// TSD_INDEX_ID_MPEG_VID_ES:
//       data: bit 0: SEQuence header found
//       data: bit 1: GOP header found
//       data: bit 2: I frame found
//       data: bit 3: P frame found
//       data: bit 4: B frame found
//       data: bit 5: Picture Coding Extension header found
//       data: bit 6: Picture Display Extension header found
//       aux_data: not used

\endcode


There are 3 important data fields for PVR/DVR seek/trick playback:
-# index_type: For MPEG2 trick/seek playback, it will started from a GOP or I picture.  In H.264 the RAI bit should be set in the TS header. The application will search this field in the index to get right start point.
-# pts_hi_and_valid and pts_lo: These fields record the time stamp of the current picture or GOP. The application will check this PTS to get the desired seek position or next trick entry point.
-# packet_number: This field will record the TS packet number which is output from the TS packet filter. The packet_number * packet_size should be the offset of the current picture or GOP in the TS file if all output TS packets are saved to one TS file.
The example below will stop the TS packet filter and index filter and destroy them:
\code
//1, stop demux filter
ismd_demux_filter_stop(ts_dev_handle, spts_filter_handle) ;
ismd_demux_filter_stop(ts_dev_handle, index_handle) ;

//2, stop demux to generate index on video PID
if (CE4100 || CE3100) {   ismd_demux_ts_set_indexing_on_pid(ts_dev_handle, vid_pid, false) ;
} else {
   ismd_demux_indexing_remove_all_pids() ;
}

//3, remove pid from demux filter
list_size = ISMD_DEMUX_MAX_PID_LIST;
ismd_demux_filter_get_mapped_pids (ts_dev_handle, spts_filter_handle, &pid_list, &list_size)  ;
ismd_demux_filter_unmap_from_pids (ts_dev_handle, spts_filter_handle, pid_list, list_size) ;

//4, close demux filter
ismd_demux_filter_close(ts_dev_handle, index_handle) ;
ismd_demux_filter_close(ts_dev_handle, spts_filter_handle)  ;

\endcode



\anchor DemuxTSb5
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.2.5  Crypto Settings</h2>
If the input stream is encrypted, the Intel� CE Media Processor demux has the ability to decrypt encoded TS packets using AES, DES, Triple DES, and DVB CSA algorithms.
To set up the demux encryption/decryption engine for any encrypted PIDs, Following steps of configuration are needed:
-# set decryption parameters using ismd_demux_descramble_set_paramsismd_demux_ts_set_crypto_params
-# set decryption key using ismd_demux_descramble_set_keyismd_demux_ts_set_key
-# enable decryption using ismd_demux_filter_set_ts_crypto
-# if the encryption algorithm is multi2, set system key using ismd_demux_descramble_set_system_keyimsd_demux_ts_set_system_key.

Note: step 1) must be executed before other steps.

to enable crypto for the filter \ref ismd_demux_descramble_set_params
It has no effect if the transport packets passing through the filter are not encrypted or the PID didn't have an algorithm and key set for descrambling.

By default, all filters have crypto disabled.

\anchor DemuxTSb6
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.2.6  How to read Ouput Buffers</h2>

For some special cases, (like enabling the software decoder to decode the elementary stream) the application writer will need to understand detailed information about the elementary stream buffer. All data in the Intel� CE Media Processor is transported in a common data structure \code ismd_buffer_descriptor_t\endcode.
the structure \code typedef struct ismd_buffer_descriptor_struct \endcode

There are two important data fields in this structure for element stream buffer. One is \code ismd_phys_buf_node_t \endcode, which indicates the element stream buffer�s physical memory address, physical buffer size and data buffer size. The application can map this physical memory to user space and send it to the software decoder.

The other important data field is \code unsigned char    attributes[256]; \endcode This is a private field for different kinds of buffers. For elementary stream buffers, the application can convert this field to a special elementary stream buffer attribute \code ismd_es_buf_attr_t \endcode. The data structure as below:

Each of these buffers can have at most one PTS value associated with it, but due to the possibility of high bandwidth content resulting in PTS values separated by more than the size of one buffer, it is possible for an output port buffer to have no PTS value associated with it.

\anchor DemuxTSc
<h2 style="color:#FFFFFF; background-color:#0860A8; font-weight :bold font-size :14pt"> 3B.5 Notes for channel changing </h2>
Demux and TSIN stop and flush is recommended during channel changing. If demux is in PLAY/PAUSE state during channel changing, it is necessary to flush the pipeline from front to back to ensure that no data from the previous frequency is anywhere in the pipeline. This flush needs to be done before PSI parsing or anything else.  The reason is the following:
-# If some old PSI packets are still in the demux after the frequency change, PSI parsing might get the old PIDs.
-# If some old PCR values are still in the demux, the newsegment generated from the demux will not reflect the correct timing.
 
Also setting the PCR PID to -1 (or any value not in the stream) in the demux resets its internal discontinuity/newsegment logic, to ensure that it does not "discover" any PCRs from the old stream and generate a newsegment with the old values:  
\code ismd_demux_ts_set_pcr_pid(m_demux_stream_handle, (uint16_t)-1) \endcode

The following steps are recommended for channel changing if demux is in PLAY/PAUSE state:
-# Stop audio/video pipes and demux filters.
-# Get rid of the demux PCR PID (set it to -1 or something).
-# Flush pipeline. Note: this ensures that there are no packets from the old stream left over and it needs to include the TSIN and demux.
-# Start PSI parsing (if used at all)

\anchor DemuxCode
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.3  Code Snippets</h2>

The following examples are provided to demonstrate how to use some of the features of the demux system. In order for the audience to more easily understand the demux functions, the examples below only involve the demux module. Input TS will come from the HW NIM or TS file (and will write to the demux input port by thread). The filter output will be read by the thread from the output port also.


\anchor DemuxCode1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.3.1  TS File Input Thread</h2>
This thread will read file data and send it to the Intel� CE Media Processors demux input port \code g_demux_input_port \endcode which is a global variable and assigned a value when the demux is opened in the main function.
\code
void* thread_demux_file_input (void *data)
{
    char * buffer, *file_path =(char *)data ;
    FILE* ts_file ;
    ismd_buffer_handle_t ts_file_buf ;
    ismd_buffer_descriptor_t buf_desc ;
    int read_size ;
    ismd_result_t result = ISMD_SUCCESS;
    ismd_event_t  in_port_event;
    ismd_port_status_t port_status ;

    ts_file = fopen(file_path, "rb");
    if(NULL == ts_file){
        printf("Cannot open TS file (%s)...\n", file_path);
        assert(0) ;
    }

    CHK_SMD_RETURN_ERROR( ismd_event_alloc(&in_port_event) ) ;
    CHK_SMD_RETURN_ERROR( ismd_port_get_status  (g_demux_input_port,  &port_status) );
    printf("Demux input port depth is %d\n", port_status.max_depth);
    CHK_SMD_RETURN_ERROR( ismd_port_attach(g_demux_input_port, in_port_event, ISMD_QUEUE_EVENT_LOW_WATERMARK , 2) );

    thread_running = 1 ;
    while(thread_running){
        CHK_SMD_RETURN_ERROR( ismd_buffer_alloc(TS_FILE_READ_SIZE, &ts_file_buf) ) ;
        CHK_SMD_RETURN_ERROR( ismd_buffer_read_desc(ts_file_buf, &buf_desc) ) ;

        buffer = OS_MAP_IO_TO_MEM_NOCACHE(buf_desc.phys.base, buf_desc.phys.size);
        read_size = fread(buffer, 1, TS_FILE_READ_SIZE, ts_file) ;

        if((read_size >=0) && (TS_FILE_READ_SIZE > read_size)){//end of file, loop back
            printf("Read to end of file, loop again\n");
            fseek(ts_file, 0, SEEK_SET) ;
        }
        buf_desc.phys.level = read_size ;
        OS_UNMAP_IO_FROM_MEM(buffer, buf_desc.phys.size);

        CHK_SMD_RETURN_ERROR(ismd_buffer_update_desc(ts_file_buf, &buf_desc) );
        do{
            result = ismd_port_write(g_demux_input_port, ts_file_buf) ;
            if(result==ISMD_ERROR_NO_SPACE_AVAILABLE){
                //printf("Demux input port is full, wait for a moment...\n");
                CHK_SMD_RETURN_WARNING( ismd_event_wait(in_port_event, ISMD_TIMEOUT_NONE ) );
                CHK_SMD_RETURN_ERROR( ismd_event_acknowledge(in_port_event) );
            }
        }while(result==ISMD_ERROR_NO_SPACE_AVAILABLE) ;

    }
    CHK_SMD_RETURN_ERROR( ismd_port_detach(g_demux_input_port) ); //fix me
    CHK_SMD_RETURN_ERROR( ismd_event_free(in_port_event) );
    fclose(ts_file) ;

    return NULL;
}
\endcode


\anchor DemuxCode2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.3.2  ES Filter output thread</h2>

This thread will read ES data from parameter data and write to the ES file. Data should point to the ES filter�s output port:

\code
/* main code about how to use different demux */
typedef struct {
    unsigned int es_sync_word;
    unsigned int es_size ;
    int          tag_flags ;
    int          client_id ;
    ismd_newsegment_tag_t   segment_tag ;
    ismd_es_buf_attr_t es_attr ;
}es_header_t ;
static int thread_running ;


void* thread_pes_data_read(void *data)
{
    ismd_result_t result = ISMD_SUCCESS;
    ismd_port_handle_t *p_port = (ismd_port_handle_t *)data ;
    ismd_event_t  port_event;
   	ismd_buffer_handle_t smd_buf = ISMD_BUFFER_HANDLE_INVALID;
	  ismd_buffer_descriptor_t buffer_descriptor;
	  ismd_es_buf_attr_t    *p_es_attr ;
	  int buffer_size;
	  unsigned char*data_buf;
	  char pes_file[128] ;
	  es_header_t es_header ;
	  ismd_port_status_t port_status ;
	  FILE *es_file ;

	 sprintf(pes_file, "./%d.es", *p_port);
    es_file = fopen(pes_file, "wb") ;
    es_header.es_sync_word = 0x74747474 ;

    CHK_SMD_RETURN_ERROR( ismd_event_alloc(&port_event) ) ;
    CHK_SMD_RETURN_ERROR( ismd_port_attach(*p_port, port_event, ISMD_QUEUE_EVENT_ALWAYS, ISMD_QUEUE_WATERMARK_NONE) );

    thread_running = 1 ;
    while(thread_running){
        result = ismd_event_wait(port_event, 10000);
        //sometime even port is full, ismd_event_wait will return timeout also. Need to check port depth
        CHK_SMD_RETURN_ERROR( ismd_port_get_status (*p_port, &port_status) ) ;
    	if ( result == ISMD_SUCCESS){
            CHK_SMD_RETURN_ERROR( ismd_event_acknowledge(port_event) ) ;
        }
        else{
    	DEBUG_MSG("%s: Wait event result = %d; At Line %d; Port_depth=%d; Max_depth=%d\n", __FUNCTION__, result, __LINE__, port_status.cur_depth, port_status.max_depth);
        }
        while(port_status.cur_depth){
            result = ismd_port_read(*p_port, &smd_buf);
    	if (result == ISMD_SUCCESS){
    	CHK_SMD_RETURN_ERROR( ismd_buffer_read_desc(smd_buf, &buffer_descriptor) );
    		p_es_attr = (ismd_es_buf_attr_t *)buffer_descriptor.attributes ;
    		buffer_size = buffer_descriptor.phys.level;
                es_header.es_size = buffer_size ;
                es_header.tag_flags = 0 ;
                memcpy(&es_header.es_attr, p_es_attr, sizeof(ismd_es_buf_attr_t)) ;
     		//check for tag information
     		if(buffer_descriptor.tags_present){
     		DEBUG_MSG("Have tags: ") ;
     			result = ismd_tag_get_client_id(smd_buf, &es_header.client_id) ;
     			if(ISMD_SUCCESS == result){
     		es_header.tag_flags |= 0x1;
     			     DEBUG_MSG("Get client_id tag=%d;  ", es_header.client_id) ;
     			}
     			result = ismd_tag_get_eos(smd_buf) ;
     			if(ISMD_SUCCESS == result){
     			es_header.tag_flags |= 0x2;
     			      DEBUG_MSG("Get EOS tag;  ") ;
     			}
     			result = ismd_tag_get_newsegment(smd_buf, &es_header.segment_tag) ;
     			if(ISMD_SUCCESS == result){
     			        es_header.tag_flags |= 0x4;
     			    DEBUG_MSG("Get New Segment tag; start=0x%llX stop=0x%llX linear_start=0x%llX",
     			                  es_header.segment_tag.start, es_header.segment_tag.stop, es_header.segment_tag.linear_start) ;
     			}
     			DEBUG_MSG(" \n") ;
     		}
     		fwrite(&es_header, sizeof(es_header_t), 1, es_file) ;

                    if (buffer_size != 0){
        		//must map smd buffer to virtual memory address :-(
        			data_buf = OS_MAP_IO_TO_MEM_NOCACHE(buffer_descriptor.phys.base, buffer_size);
        			fwrite(data_buf, 1, buffer_size, es_file) ;
         			 //unmap smd buffer, and de-reference it
         			 OS_UNMAP_IO_FROM_MEM(data_buf, buffer_size);
    		 }
    		else{
     		      ERROR_MSG("Buf size=0; ismd_port_read return = 0x%x\n",result);
     		  }
     		  DEBUG_MSG("PES Attr: Org_PTS=0x%llX; Local_PTS=0x%llX; Discontinue=%d; Buf_Size=%d; tag=%d\n",
	             p_es_attr->original_pts, p_es_attr->local_pts, p_es_attr->discontinuity, buffer_size, buffer_descriptor.tags_present );
     			CHK_SMD_RETURN_ERROR( ismd_buffer_dereference (smd_buf) ) ;
    	}
    	else{
    		ERROR_MSG("Line %d; ismd_port_read error = %d; Port depth=%d; Max depth=%d\n",__LINE__, result, port_status.cur_depth, port_status.max_depth)	;
    	}
    	//read current port depth
    	CHK_SMD_RETURN_ERROR( ismd_port_get_status (*p_port, &port_status) ) ;
}
    }
    CHK_SMD_RETURN_ERROR( ismd_port_detach(*p_port) );
    CHK_SMD_RETURN_ERROR( ismd_event_free(port_event) );

    fclose(es_file) ;
    return NULL;
}


\endcode


\anchor DemuxCode3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.3.3  General Output data read thread</h2>

This thread will read any data from a filter output port. �Data� should point to the filter output port:

\code
void* thread_port_data_read(void *data)
{
    ismd_port_handle_t psi_out_port = *(ismd_port_handle_t *)data ;
    ismd_result_t result = ISMD_SUCCESS;
    ismd_event_t  port_event;
   	ismd_buffer_handle_t psi_buf = ISMD_BUFFER_HANDLE_INVALID;
	  ismd_buffer_descriptor_t buffer_descriptor;
	  int buffer_size;
	  ismd_port_status_t port_status ;


    CHK_SMD_RETURN_ERROR( ismd_event_alloc(&port_event) ) ;
    CHK_SMD_RETURN_ERROR( ismd_port_attach(psi_out_port, port_event, ISMD_QUEUE_EVENT_ALWAYS, ISMD_QUEUE_WATERMARK_NONE) );

    thread_running = 1 ;
    while(thread_running){
        result = ismd_event_wait(port_event, 10000);
        //bug--alex; sometime even port is full, ismd_event_wait will return timeout also. Need to check port depth :-(
        CHK_SMD_RETURN_ERROR( ismd_port_get_status (psi_out_port, &port_status) ) ;
    	if ( result == ISMD_SUCCESS){
            CHK_SMD_RETURN_ERROR( ismd_event_acknowledge(port_event) ) ;
        }
        else{
    	ERROR_MSG("%s: Wait event result = %d; At Line %d; Port_depth=%d; Max_depth=%d\n", __FUNCTION__, result, __LINE__, port_status.cur_depth, port_status.max_depth);
        }
        while(port_status.cur_depth){
    	result = ismd_port_read(psi_out_port, &psi_buf);
    	if (result == ISMD_SUCCESS){
               assert(psi_buf != ISMD_BUFFER_HANDLE_INVALID);
               result = ismd_buffer_read_desc(psi_buf, &buffer_descriptor);
    	buffer_size = buffer_descriptor.phys.level;
 		   ERROR_MSG("Get PSI data from port %d; size is %d\n",psi_out_port, buffer_size);
     	  CHK_SMD_RETURN_ERROR( ismd_buffer_dereference (psi_buf) ) ;
    	}
    	else{
    		ERROR_MSG("Line %d; ismd_port_read error = %d; Port depth=%d; Max depth=%d\n",__LINE__, result, port_status.cur_depth, port_status.max_depth)	;
    	}
    	CHK_SMD_RETURN_ERROR( ismd_port_get_status (psi_out_port, &port_status) ) ;
    	}
    }
    CHK_SMD_RETURN_ERROR( ismd_port_detach(psi_out_port) );
    CHK_SMD_RETURN_ERROR( ismd_event_free(port_event) );

    return NULL;
}
\endcode


\anchor DemuxCode4
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.3.4  ES Filter for TS</h2>


\code
#include "osal.h"
#include "ismd_core.h"
#include "ismd_demux.h"

/* Private Types and defines ---------------------------------------------------------- */
#define CHK_SMD_RETURN_WARNING(a) {ismd_result_t ret=a; if(ISMD_SUCCESS != ret ) { \
printf("Warning: SMD returned error=%d; Line %d of %s; fun %s\n", ret, __LINE__, __FILE__, __FUNCTION__); } }

#define CHK_SMD_RETURN_ERROR(a) {ismd_result_t ret = a ; if(ISMD_SUCCESS != ret ) { \
printf("ERROR: SMD returned error=%d; Line %d of %s; fun %s\n", ret, __LINE__, __FILE__, __FUNCTION__);  assert(0) ;} }

#define DEBUG_MSG           printf
#define ERROR_MSG           printf

#define DEMUX_ES_FILTER_SIZE            0x10000 //64KB
#define DEMUX_TS_PACKET_FILTER_SIZE     0x8000 //32KB
#define DEMUX_PSI_FILTER_SIZE           0x1000 //4KB
#define TS_FILE_READ_SIZE               0x8000 //32KB

/* Private Variables ------------------------------------------------------ */
static unsigned char ts_demux_dec_type = 0 ;
static ismd_port_handle_t g_demux_input_port, g_psi_out_port, g_pes_out_port, g_spts_out_port, g_index_out_port ;
static ismd_dev_t g_ts_dev_handle ;

/* Sample code about TS demux function*/
int ts_demux_open(int phy_ts_input, ismd_dev_t *p_ts_dev_handle, ismd_port_handle_t* p_input_port)
{
    if((phy_ts_input >=0) && (phy_ts_input < 4)){ //get TS data from HW TS port
        CHK_SMD_RETURN_ERROR(ismd_tsin_open(phy_ts_input, p_ts_dev_handle)) ;
        CHK_SMD_RETURN_WARNING(ismd_dev_set_state(*p_ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;
        CHK_SMD_RETURN_ERROR( ismd_demux_tsin_set_open_cable_mode(*p_ts_dev_handle,ISMD_DEMUX_NO_OPEN_CABLE) );
        //should configure TS HW
        //ismd_demux_tsin_set_nim_config
        //ismd_demux_tsin_set_buffer_size
        ts_demux_dec_type = 1 ; //HW TSIN device
    }
    else {
        CHK_SMD_RETURN_ERROR(ismd_demux_stream_open(ISMD_DEMUX_STREAM_TYPE_MPEG2_TRANSPORT_STREAM, p_ts_dev_handle, p_input_port) ) ;
        CHK_SMD_RETURN_WARNING(ismd_dev_set_state(*p_ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;
        ts_demux_dec_type = 0 ; //normal demux device
    }

    return 0 ;
}

int ts_demux_create_pes_filter(ismd_dev_t ts_dev_handle, unsigned short pid, ismd_port_handle_t* p_out_port, ismd_demux_filter_handle_t *p_filter_handle)
{
    ismd_demux_pid_list_t pid_list;

    //1, create demux filter
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_open(ts_dev_handle,  ISMD_DEMUX_OUTPUT_ES, DEMUX_ES_FILTER_SIZE, p_filter_handle, p_out_port) ) ;
    //2, map pid to filter
    pid_list.pid_array[0].pid_val = pid ;
    pid_list.pid_array[0].pid_type = ISMD_DEMUX_PID_TYPE_PES ;
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_map_to_pids(ts_dev_handle, *p_filter_handle, pid_list, 1) ) ;
    //3, auto enable crypto for PES demux filter
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_set_ts_crypto(ts_dev_handle, *p_filter_handle, true) ) ;
    //4, start demux PES filter
    CHK_SMD_RETURN_WARNING( ismd_demux_filter_start(ts_dev_handle, *p_filter_handle) ) ;

    return 0 ;
}

int ts_demux_destroy_pes_filter(ismd_dev_t ts_dev_handle, ismd_demux_filter_handle_t filter_handle)
{

    ismd_demux_pid_list_t pid_list;
    unsigned list_size ;

    //1, remove pid from demux filter
    list_size = ISMD_DEMUX_MAX_PID_LIST; //should set this to pid_list array length, other wise will get back unexpect data
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_get_mapped_pids (ts_dev_handle, filter_handle, &pid_list, &list_size) ) ;
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_unmap_from_pids (ts_dev_handle, filter_handle, pid_list, list_size) ) ;
    //3, close demux filter
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_close(ts_dev_handle, filter_handle) ) ;

    return 0 ;
}

int ts_demux_close(ismd_dev_t ts_dev_handle)
{
    CHK_SMD_RETURN_WARNING(ismd_dev_set_state(ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;
    if(ts_demux_dec_type){ //TS data from HW TS port, close ts in HW
        CHK_SMD_RETURN_ERROR(ismd_dev_close(ts_dev_handle)) ;
    }
    else {
        CHK_SMD_RETURN_ERROR( ismd_demux_stream_close(ts_dev_handle) ) ;
    }

    return 0 ;
}

int ts_demux_set_csa_key(ismd_dev_t ts_dev_handle, unsigned short pid, unsigned char* key, unsigned key_length, int even_key )
{
    ismd_demux_key_type_t key_type ;
    ismd_demux_crypto_info_t key_data ;

    if(even_key)
        key_type =  ISMD_DEMUX_KEY_TYPE_EVEN ;
    else
        key_type =  ISMD_DEMUX_KEY_TYPE_ODD ;
    memcpy(key_data.crypto_info, key, key_length) ;
    CHK_SMD_RETURN_ERROR( ismd_demux_ts_load_key(ts_dev_handle, pid, ISMD_DEMUX_DVB_CSA_DESCRAMBLE, ISMD_DEMUX_CLEAR_RESIDUAL, key_type, key_data, key_length, key_data, 0) ) ;

    return 0 ;
}

int main (int argc, char **argv)
{
    int ts_phy_num = -1;
    pthread_t ts_file_thread, pes_thread ;
    ismd_demux_filter_handle_t pes_filter_handle ;
    unsigned char ch ;
    ismd_clock_t pipe_clock ;
    ismd_time_t curr_time = ISMD_NO_PTS;

    if(argc != 2){
        printf("Usage: %s ts_source_path\n", argv[0]);
        printf("          ts_source_path : @TSIN0 -- TSIN HW NIM 0; \n");
        printf("                         : @TSIN1 -- TSIN HW NIM 1; \n");
        printf("                         : @TSIN2 -- TSIN HW NIM 2; \n");
        printf("                         : @TSIN3 -- TSIN HW NIM 3; \n");
        printf("                         : other -- Normal TS file; \n");
        return -1 ;
    }

    if(0 == strcmp("@TSIN0", argv[1]))
        ts_phy_num = 0 ;
    if(0 == strcmp("@TSIN1", argv[1]))
        ts_phy_num = 1 ;
    if(0 == strcmp("@TSIN2", argv[1]))
        ts_phy_num = 2 ;
    if(0 == strcmp("@TSIN3", argv[1]))
        ts_phy_num = 3 ;

    ts_demux_open(ts_phy_num, &g_ts_dev_handle, &g_demux_input_port) ;

    if(-1 == ts_phy_num){ //normal TS file, need a thread to read TS data to demux input port
        pthread_create(&ts_file_thread, NULL, thread_demux_file_input, (void*)argv[1]);
    }

    //set clock
    CHK_SMD_RETURN_ERROR( ismd_clock_alloc(ISMD_CLOCK_TYPE_FIXED, &pipe_clock) ) ;
    CHK_SMD_RETURN_ERROR( ismd_clock_make_primary(pipe_clock) ) ;
    CHK_SMD_RETURN_ERROR( ismd_dev_set_clock(g_ts_dev_handle, pipe_clock) ) ;

    //set base time for demux, video render, audio dev
    CHK_SMD_RETURN_ERROR( ismd_clock_get_time(pipe_clock, &curr_time) ) ;
    CHK_SMD_RETURN_ERROR( ismd_dev_set_stream_base_time(g_ts_dev_handle, curr_time) ) ;

    //set state
    CHK_SMD_RETURN_WARNING(ismd_dev_set_state(g_ts_dev_handle, ISMD_DEV_STATE_PLAY) ) ;

    //open PES filter
    ts_demux_create_pes_filter(g_ts_dev_handle, 513, &g_pes_out_port, &pes_filter_handle) ;
    //create thread to read ES data from PES filter output port
    pthread_create(&pes_thread, NULL, thread_pes_data_read, (void*)&g_pes_out_port);

    sleep(1) ;
    printf("Press any key to quit ... \n");
    ch = getchar() ;

    thread_running =  0;
    if(-1 == ts_phy_num){
        pthread_join(ts_file_thread, NULL) ;
        printf("TS file Thread ended...\n");
    }

    //stop ES data read and filter
    pthread_join(pes_thread, NULL) ;
    printf("PES data read Thread ended; PES out port = %d ...\n", g_pes_out_port);
    ts_demux_destroy_pes_filter(g_ts_dev_handle, pes_filter_handle) ;

    //set state
    CHK_SMD_RETURN_WARNING(ismd_dev_set_state(g_ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;

    ts_demux_close(g_ts_dev_handle) ;

    return 0 ;
}

\endcode



\anchor DemuxCode5
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.3.5  Section/PSI Filter for TS</h2>

\code
#include "osal.h"
#include "ismd_core.h"
#include "ismd_demux.h"

/* Private Types and defines ---------------------------------------------------------- */
#define CHK_SMD_RETURN_WARNING(a) {ismd_result_t ret=a; if(ISMD_SUCCESS != ret ) { \
printf("Warning: SMD returned error=%d; Line %d of %s; fun %s\n", ret, __LINE__, __FILE__, __FUNCTION__); } }

#define CHK_SMD_RETURN_ERROR(a) {ismd_result_t ret = a ; if(ISMD_SUCCESS != ret ) { \
printf("ERROR: SMD returned error=%d; Line %d of %s; fun %s\n", ret, __LINE__, __FILE__, __FUNCTION__);  assert(0) ;} }

#define DEBUG_MSG           printf
#define ERROR_MSG           printf

#define DEMUX_ES_FILTER_SIZE            0x10000 //64KB
#define DEMUX_TS_PACKET_FILTER_SIZE     0x8000 //32KB
#define DEMUX_PSI_FILTER_SIZE           0x1000 //4KB
#define TS_FILE_READ_SIZE               0x8000 //32KB

/* Private Variables ------------------------------------------------------ */
static unsigned char ts_demux_dec_type = 0 ;
static ismd_port_handle_t g_demux_input_port, g_psi_out_port, g_pes_out_port, g_spts_out_port, g_index_out_port ;
static ismd_dev_t g_ts_dev_handle ;

/* Sample code about TS demux function*/
int ts_demux_open(int phy_ts_input, ismd_dev_t *p_ts_dev_handle, ismd_port_handle_t* p_input_port)
{
    if((phy_ts_input >=0) && (phy_ts_input < 4)){ //get TS data from HW TS port
        CHK_SMD_RETURN_ERROR(ismd_tsin_open(phy_ts_input, p_ts_dev_handle)) ;
        CHK_SMD_RETURN_WARNING(ismd_dev_set_state(*p_ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;
        CHK_SMD_RETURN_ERROR( ismd_demux_tsin_set_open_cable_mode(*p_ts_dev_handle,ISMD_DEMUX_NO_OPEN_CABLE) );
        //should configure TS HW
        //ismd_demux_tsin_set_nim_config
        //ismd_demux_tsin_set_buffer_size
        ts_demux_dec_type = 1 ; //HW TSIN device
    }
    else {
        CHK_SMD_RETURN_ERROR (ismd_demux_stream_open (ISMD_DEMUX_STREAM_TYPE_MPEG2_TRANSPORT_STREAM, p_ts_dev_handle, p_input_port) ) ;
        CHK_SMD_RETURN_WARNING(ismd_dev_set_state(*p_ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;
        ts_demux_dec_type = 0 ; //normal demux device
    }

    return 0 ;
}

int ts_demux_create_psi_filter(ismd_dev_t ts_dev_handle, unsigned short pid, unsigned char *p_filter_data, unsigned char *p_filter_mask, int filter_legnth, ismd_port_handle_t* p_out_port, ismd_demux_filter_handle_t* p_filter_handle, ismd_demux_section_filter_handle_t * p_sec_filter_handle)
{
    ismd_demux_pid_list_t pid_list;
    ismd_demux_section_filter_params_t psi_filter_parameter;

    //1, create demux filter for new section filter
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_open(ts_dev_handle,  ISMD_DEMUX_OUTPUT_PSI, DEMUX_PSI_FILTER_SIZE, p_filter_handle, p_out_port) ) ;
    //2, map pid to new demux filter
    pid_list.pid_array[0].pid_val = pid ;
    pid_list.pid_array[0].pid_type = ISMD_DEMUX_PID_TYPE_PSI ;
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_map_to_pids(ts_dev_handle, *p_filter_handle, pid_list, 1) ) ;

    //3, create section filter based on demux filer
    CHK_SMD_RETURN_ERROR( ismd_demux_section_filter_open(ts_dev_handle, *p_filter_handle, pid, p_sec_filter_handle) ) ;

    //4, set parameter to section filter
    psi_filter_parameter.tid = 0 ; //will be ignored after set other fields
    psi_filter_parameter.section_offset = 0 ;
#ifdef NEGATIVE_FILTER
#else
    memset(psi_filter_parameter.negative_filter, 0, ISMD_DEMUX_SF_MASK_SIZE ) ;
    memset(psi_filter_parameter.negative_mask, 0, ISMD_DEMUX_SF_MASK_SIZE) ;
    if(ISMD_DEMUX_SF_MASK_SIZE < filter_legnth){
        ERROR_MSG("Input section filter data length is too long; size=%d\n", filter_legnth);
        filter_legnth = ISMD_DEMUX_SF_MASK_SIZE ;
    }
    memcpy(psi_filter_parameter.positive_filter, p_filter_data, filter_legnth) ;
    memcpy(psi_filter_parameter.positive_mask, p_filter_mask, filter_legnth) ;
    if(ISMD_DEMUX_SF_MASK_SIZE > filter_legnth){
        memset(&psi_filter_parameter.positive_filter[filter_legnth], 0, ISMD_DEMUX_SF_MASK_SIZE - filter_legnth) ;
        memset(&psi_filter_parameter.positive_mask[filter_legnth], 0, ISMD_DEMUX_SF_MASK_SIZE - filter_legnth) ;
    }
#endif
    CHK_SMD_RETURN_ERROR( ismd_demux_section_filter_set_params(ts_dev_handle, *p_sec_filter_handle, &psi_filter_parameter) );

    //5, start section filter
    CHK_SMD_RETURN_WARNING( ismd_demux_section_filter_start (ts_dev_handle, *p_sec_filter_handle) ) ;
    //6, start demux filter
    CHK_SMD_RETURN_WARNING( ismd_demux_filter_start(ts_dev_handle, *p_filter_handle) ) ;

    return 0 ;
}

int ts_demux_destory_psi_filter(ismd_dev_t ts_dev_handle, ismd_demux_filter_handle_t filter_handle, ismd_demux_section_filter_handle_t sec_filter_handle)
{
    ismd_demux_pid_list_t pid_list;
    unsigned list_size ;

    //1, stop section filter
    CHK_SMD_RETURN_WARNING( ismd_demux_section_filter_stop(ts_dev_handle, sec_filter_handle) ) ;
    //2, remove pid from demux filter
    list_size = ISMD_DEMUX_MAX_PID_LIST; //should set this to pid_list array length, other wise will get back unexpect data; bug--alex
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_get_mapped_pids(ts_dev_handle, filter_handle, &pid_list, &list_size) ) ;
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_unmap_from_pids(ts_dev_handle, filter_handle, pid_list, list_size) )  ;
    //3, close section filter
    CHK_SMD_RETURN_ERROR( ismd_demux_section_filter_close(ts_dev_handle, sec_filter_handle) );
    //4, close demux filter
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_close(ts_dev_handle, filter_handle) );

    return 0 ;
}

int ts_demux_close(ismd_dev_t ts_dev_handle)
{

    CHK_SMD_RETURN_WARNING(ismd_dev_set_state(ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;

    if(ts_demux_dec_type){ //TS data from HW TS port, close ts in HW
        CHK_SMD_RETURN_ERROR(ismd_dev_close(ts_dev_handle)) ;
    }
    else {
        CHK_SMD_RETURN_ERROR( ismd_demux_stream_close(ts_dev_handle) ) ;
    }

    return 0 ;
}

static int thread_running ;

int main (int argc, char **argv)
{
    int ts_phy_num = -1;
    pthread_t ts_file_thread, psi_thread ;
    ismd_demux_filter_handle_t psi_filter_handle ;
    ismd_demux_section_filter_handle_t sec_filter_handle ;
    unsigned char ch ;
    ismd_clock_t pipe_clock ;
    ismd_time_t curr_time = ISMD_NO_PTS;
    unsigned char sec_match[] = {0x00}; //PAT table
    unsigned char sec_mask[] = {0xff}; //PAT table

    if(argc != 2){
        printf("Usage: %s ts_source_path\n", argv[0]);
        printf("          ts_source_path : @TSIN0 -- TSIN HW NIM 0; \n");
        printf("                         : @TSIN1 -- TSIN HW NIM 1; \n");
        printf("                         : @TSIN2 -- TSIN HW NIM 2; \n");
        printf("                         : @TSIN3 -- TSIN HW NIM 3; \n");
        printf("                         : other -- Normal TS file; \n");
        return -1 ;
    }

    if(0 == strcmp("@TSIN0", argv[1]))
        ts_phy_num = 0 ;
    if(0 == strcmp("@TSIN1", argv[1]))
        ts_phy_num = 1 ;
    if(0 == strcmp("@TSIN2", argv[1]))
        ts_phy_num = 2 ;
    if(0 == strcmp("@TSIN3", argv[1]))
        ts_phy_num = 3 ;

    ts_demux_open(ts_phy_num, &g_ts_dev_handle, &g_demux_input_port) ;

    if(-1 == ts_phy_num){ //normal TS file, need a thread to read TS data to demux input port
        pthread_create(&ts_file_thread, NULL, thread_demux_file_input, (void*)argv[1]);
    }

    //set clock
    CHK_SMD_RETURN_ERROR( ismd_clock_alloc(ISMD_CLOCK_TYPE_FIXED, &pipe_clock) ) ;
    CHK_SMD_RETURN_ERROR( ismd_clock_make_primary(pipe_clock) ) ;
    CHK_SMD_RETURN_ERROR( ismd_dev_set_clock(g_ts_dev_handle, pipe_clock) ) ;

    //set base time for demux, video render, audio dev
    CHK_SMD_RETURN_ERROR( ismd_clock_get_time(pipe_clock, &curr_time) ) ;
    CHK_SMD_RETURN_ERROR( ismd_dev_set_stream_base_time(g_ts_dev_handle, curr_time) ) ;

    //set state
    CHK_SMD_RETURN_WARNING(ismd_dev_set_state(g_ts_dev_handle, ISMD_DEV_STATE_PLAY) ) ;

    //open PSI/section filter
    ts_demux_create_psi_filter(g_ts_dev_handle, 0, sec_match, sec_mask, 1, &g_psi_out_port,
                                &psi_filter_handle, &sec_filter_handle) ;
    pthread_create(&psi_thread, NULL, thread_port_data_read, (void*)&g_psi_out_port);

    sleep(1) ;
    printf("Press any key to quit ... \n");
    ch = getchar() ;

    thread_running =  0;
    if(-1 == ts_phy_num){
        pthread_join(ts_file_thread, NULL) ;
        printf("TS file Thread ended...\n");
    }

    //stop PSI data read thread and filter
    pthread_join(psi_thread, NULL) ;
    printf("PSI data read Thread ended; PSI out port = %d ...\n", g_psi_out_port);
    ts_demux_destory_psi_filter(g_ts_dev_handle, psi_filter_handle, sec_filter_handle) ;

    //set state
    CHK_SMD_RETURN_WARNING(ismd_dev_set_state(g_ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;

    ts_demux_close(g_ts_dev_handle) ;

    return 0 ;
}

\endcode


\anchor DemuxCode6
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 3B.3.6  DVR/PVR for TS</h2>

\code
#include "osal.h"
#include "ismd_core.h"
#include "ismd_demux.h"

/* Private Types and defines ---------------------------------------------------------- */
#define CHK_SMD_RETURN_WARNING(a) {ismd_result_t ret=a; if(ISMD_SUCCESS != ret ) { \
printf("Warning: SMD returned error=%d; Line %d of %s; fun %s\n", ret, __LINE__, __FILE__, __FUNCTION__); } }

#define CHK_SMD_RETURN_ERROR(a) {ismd_result_t ret = a ; if(ISMD_SUCCESS != ret ) { \
printf("ERROR: SMD returned error=%d; Line %d of %s; fun %s\n", ret, __LINE__, __FILE__, __FUNCTION__);  assert(0) ;} }

#define DEBUG_MSG           printf
#define ERROR_MSG           printf

#define DEMUX_ES_FILTER_SIZE            0x10000 //64KB
#define DEMUX_TS_PACKET_FILTER_SIZE     0x8000 //32KB
#define DEMUX_PSI_FILTER_SIZE           0x1000 //4KB
#define TS_FILE_READ_SIZE               0x8000 //32KB

/* Private Variables ------------------------------------------------------ */
static unsigned char ts_demux_dec_type = 0 ;
static ismd_port_handle_t g_demux_input_port, g_psi_out_port, g_pes_out_port, g_spts_out_port, g_index_out_port ;
static ismd_dev_t g_ts_dev_handle ;

/* Sample code about TS demux function*/
int ts_demux_open(int phy_ts_input, ismd_dev_t *p_ts_dev_handle, ismd_port_handle_t* p_input_port)
{
    if((phy_ts_input >=0) && (phy_ts_input < 4)){ //get TS data from HW TS port
        CHK_SMD_RETURN_ERROR(ismd_tsin_open(phy_ts_input, p_ts_dev_handle)) ;
        CHK_SMD_RETURN_WARNING(ismd_dev_set_state(*p_ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;
        CHK_SMD_RETURN_ERROR( ismd_demux_tsin_set_open_cable_mode(*p_ts_dev_handle,ISMD_DEMUX_NO_OPEN_CABLE) );
        //should configure TS HW
        //ismd_demux_tsin_set_nim_config
        //ismd_demux_tsin_set_buffer_size
        ts_demux_dec_type = 1 ; //HW TSIN device
    }
    else {
        CHK_SMD_RETURN_ERROR(ismd_demux_stream_open(ISMD_DEMUX_STREAM_TYPE_MPEG2_TRANSPORT_STREAM, p_ts_dev_handle, p_input_port) ) ;
        CHK_SMD_RETURN_WARNING(ismd_dev_set_state(*p_ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;
        ts_demux_dec_type = 0 ; //normal demux device
    }

    return 0 ;
}

int ts_demux_close(ismd_dev_t ts_dev_handle)
{

    CHK_SMD_RETURN_WARNING(ismd_dev_set_state(ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;

    if(ts_demux_dec_type){ //TS data from HW TS port, close ts in HW
        CHK_SMD_RETURN_ERROR(ismd_dev_close(ts_dev_handle)) ;
    }
    else {
        CHK_SMD_RETURN_ERROR( ismd_demux_stream_close(ts_dev_handle) ) ;
    }

    return 0 ;
}

int ts_demux_start_dvr(ismd_dev_t ts_dev_handle, unsigned short vid_pid, ismd_demux_pid_list_t pid_list, unsigned short list_size, ismd_port_handle_t* p_spts_out_port, ismd_port_handle_t* p_index_out_port,    ismd_demux_filter_handle_t *p_spts_handle, ismd_demux_filter_handle_t *p_index_handle )
{

    //1, create SPTS demux filter
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_open(ts_dev_handle,  ISMD_DEMUX_OUTPUT_WHOLE_TS_PACKET,  DEMUX_TS_PACKET_FILTER_SIZE, p_spts_handle, p_spts_out_port) ) ;
    //2, map pid to filter
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_map_to_pids(ts_dev_handle, *p_spts_handle, pid_list, list_size) ) ;

    //4, auto enable crypto for PES demux filter
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_set_ts_crypto(ts_dev_handle, *p_spts_handle, true) ) ;
    //5, create index filter for SPTS filter
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_open_indexer(ts_dev_handle, *p_spts_handle, p_index_handle, p_index_out_port) );
    CHK_SMD_RETURN_ERROR( ismd_demux_ts_set_indexing_on_pid(ts_dev_handle, vid_pid, true) ) ;
    //6, start SPTS demux filter
    CHK_SMD_RETURN_WARNING( ismd_demux_filter_start(ts_dev_handle, *p_spts_handle) ) ;
    CHK_SMD_RETURN_WARNING( ismd_demux_filter_start(ts_dev_handle, *p_index_handle) ) ;

    return 0 ;
}

int ts_demux_stop_dvr(ismd_dev_t ts_dev_handle, ismd_demux_filter_handle_t spts_handle, ismd_demux_filter_handle_t index_handle )
{
    ismd_demux_pid_list_t pid_list;
    unsigned list_size ;

    //1, remove pid from demux filter
    list_size = ISMD_DEMUX_MAX_PID_LIST; //should set this to pid_list array length, other wise will get back unexpect data
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_get_mapped_pids (ts_dev_handle, spts_handle, &pid_list, &list_size) ) ;
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_unmap_from_pids (ts_dev_handle, spts_handle, pid_list, list_size) ) ;

    //2, close  filter
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_close(ts_dev_handle, index_handle) ) ;
    CHK_SMD_RETURN_ERROR( ismd_demux_filter_close(ts_dev_handle, spts_handle) ) ;

    return 0 ;
}


/* main code about how to use different demux */
static int thread_running ;
int main (int argc, char **argv)
{
    int ts_phy_num = -1;
    pthread_t ts_file_thread, spts_thread, index_thread ;
    ismd_demux_filter_handle_t  spts_filter_handle, index_filter_handle ;
    unsigned char ch ;
    ismd_clock_t pipe_clock ;
    ismd_time_t curr_time = ISMD_NO_PTS;
    ismd_demux_pid_list_t      pid_list;
    unsigned int               pid_list_size;

    if(argc != 2){
        printf("Usage: %s ts_source_path\n", argv[0]);
        printf("          ts_source_path : @TSIN0 -- TSIN HW NIM 0; \n");
        printf("                         : @TSIN1 -- TSIN HW NIM 1; \n");
        printf("                         : @TSIN2 -- TSIN HW NIM 2; \n");
        printf("                         : @TSIN3 -- TSIN HW NIM 3; \n");
        printf("                         : other -- Normal TS file; \n");
        return -1 ;
    }

    if(0 == strcmp("@TSIN0", argv[1]))
        ts_phy_num = 0 ;
    if(0 == strcmp("@TSIN1", argv[1]))
        ts_phy_num = 1 ;
    if(0 == strcmp("@TSIN2", argv[1]))
        ts_phy_num = 2 ;
    if(0 == strcmp("@TSIN3", argv[1]))
        ts_phy_num = 3 ;

    ts_demux_open(ts_phy_num, &g_ts_dev_handle, &g_demux_input_port) ;

    if(-1 == ts_phy_num){ //normal TS file, need a thread to read TS data to demux input port
        pthread_create(&ts_file_thread, &attr, thread_demux_file_input, (void*)argv[1]);
    }

    //set clock
    CHK_SMD_RETURN_ERROR( ismd_clock_alloc(ISMD_CLOCK_TYPE_FIXED, &pipe_clock) ) ;
    CHK_SMD_RETURN_ERROR( ismd_clock_make_primary(pipe_clock) ) ;
    CHK_SMD_RETURN_ERROR( ismd_dev_set_clock(g_ts_dev_handle, pipe_clock) ) ;

    //set base time for demux, video render, audio dev
    CHK_SMD_RETURN_ERROR( ismd_clock_get_time(pipe_clock, &curr_time) ) ;
    CHK_SMD_RETURN_ERROR( ismd_dev_set_stream_base_time(g_ts_dev_handle, curr_time) ) ;

    //set state
    CHK_SMD_RETURN_WARNING(ismd_dev_set_state(g_ts_dev_handle, ISMD_DEV_STATE_PLAY) ) ;

    //Open SPTS/index filter (for PVR/DVR)
    // map pids to SPTS filter
    pid_list_size = 0;
    pid_list.pid_array[pid_list_size].pid_val  = 0; //PAT table
    pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PSI;
    pid_list_size++;
    pid_list.pid_array[pid_list_size].pid_val  = 1024; //PMT table
    pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PSI;
    pid_list_size++;
    pid_list.pid_array[pid_list_size].pid_val  = 160; //video pid
    pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PES;
    pid_list_size++;
    pid_list.pid_array[pid_list_size].pid_val  = 80; //audio pid
    pid_list.pid_array[pid_list_size].pid_type = ISMD_DEMUX_PID_TYPE_PES;
    pid_list_size++;

    ts_demux_start_dvr(g_ts_dev_handle, 160, pid_list, pid_list_size,  &g_spts_out_port, &g_index_out_port,
                       &spts_filter_handle, &index_filter_handle ) ;
//create thread to read SPTS packet and index data from SPTS filter and index filter
    pthread_create(&spts_thread, &attr, thread_port_data_read, (void*)&g_spts_out_port);
    pthread_create(&index_thread, &attr, thread_port_data_read, (void*)&g_index_out_port);

    sleep(1) ;
    printf("Press any key to quit ... \n");
    ch = getchar() ;

    thread_running =  0;
    if(-1 == ts_phy_num){
        pthread_join(ts_file_thread, NULL) ;
        printf("TS file Thread ended...\n");
    }

    //stop PVR
    pthread_join(index_thread, NULL) ;
    pthread_join(spts_thread, NULL) ;
    printf("PVR data read Thread ended; SPTS port= %d; Index Port = %d ...\n", g_spts_out_port, g_index_out_port);
    ts_demux_stop_dvr(g_ts_dev_handle, spts_filter_handle,index_filter_handle ) ;

    //set state
    CHK_SMD_RETURN_WARNING(ismd_dev_set_state(g_ts_dev_handle, ISMD_DEV_STATE_STOP) ) ;

    ts_demux_close(g_ts_dev_handle) ;

    return 0 ;
}

\endcode


\anchor SMDDemuxAPI
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> Reference to Demux API</h2>
- \ref ismd_demux "Transport/Program Stream Processing": Transport and program stream input, filtering, de-multiplexing, and indexing.
- \ref ismd_tsout "Transport Stream Output": Isochronous transport stream transmission. provides many stream processing capabilities including element stream assembling, PSI section assembling, crypto, timing control, etc.

\anchor RemuxOver
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> Overview and Architecture</h2>

The SMD Remux module provides capabilities to do MVC (Multi-view Video Coding) 3D use case.  Currently it supports 3D Blu-ray (special case for MVC) only and hence it is not recommended to use the component in other pipeline use cases.  There is no hardware related to this module as it is a software only kernel module that runs on the host processor (e.g. IA).
Remux provides the basic ability of muxing the multiple video ES streams required to form a single 3D stream.  The muxing of video ES streams is done in such a manner so as to be decodable by the downstream element (i.e. video decoder).
Remux can allow the application to open multiple instances in future, but currently only one instance is supported.  Each instance operates independently as a separate thread.
Remux currently supports MPTS and SSIF pipeline modes. Fig R1 shows Remux Architecture and Table R1  explains remux external interfaces.
\image html remux.png Fig.R1 Remux Architecture

<table border=1">
<caption>Table 1: SMD Remux External Interfaces </caption>
<tr>
<th style="color:black;background-color:blue;" >Interface</th> <th style="color:black;background-color:blue;" >Description</th> <th style="color:black;background-color:blue;" >Type i.e CTL,stream,event </th> <th style="color:black;background-color:blue;" >Notes</th>
</tr>
<tr>
<td> Base View </td>	<td>  Receives compressed video </td> <td> Stream	</td> <td>Input data is contained in ismd_buffers</td>
</tr>

</tr>
<tr>
<td> Input Port </td>	<td>  ES Stream for base view input </td> <td> 	</td> <td>Input data is contained in ismd_buffers</td>
</tr>

</tr>
<tr>
<td>  Depedent View Input Port </td>	<td>   Receives compressed ES Stream for dependent view input </td> <td> Control	</td> <td>SMD Remux API</td>
</tr>


</tr>
<tr>
<td> Control </td>	<td>   Public method exposed by the driver for remux control </td> <td> Control	</td> <td>SMD Remux API</td>
</tr>


</tr>
<tr>
<td> Event </td>	<td>  Asynchronous callback mechanism for notifying applications that a certain remux event was triggered </td> <td>Event/Stream	</td> <td></td>
</tr>
</table>

Input ports on remux feed compressed video ES data in to remux.  The source of ES data can be hardware demux, soft demux or application.  Remux has one output port which outputs re-muxed video ES data (muxed from all the video ES inputs).  The sink to remux is video decoder.  Remux has two input ports (for 3DBD use case) base view and dependent view.
Base view input port should be fed the base view video ES stream (independently decodable as mentioned in H.264 spec) and dependent view should be fed dependent video ES stream.  It is the responsibility of the application so as to connect correct video ES streams (base / dependent) to the input of the remux.  This information is available in PMT of a Transport Stream or in the file structures available on the 3DBD disc.


\anchor RemuxCfg
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> Configuring Remux</h2>
Application controls the order in which the component view ES streams (at the input of the remux) need to be remuxed.  Application parses the PSI information (PMT) along with hierarchy descriptor (if necessary and if present) to extract the remuxing order.  Application looks at the parameters specified below to get the parsing order information for the mvc stream.

-# Stream_type:   is a parameter in PMT.  It can be extracted by the PSI parser to determine which ES stream is the base view video stream and which ES stream is a dependent view video bitstream.
Stream_type in PMT is set to 0x1B for base view video elementary sub-bitstreams and to 0x20 for non-base view video elementary sub-bitstreams


-# Hierarchy_type : Note:-  Hierarchy descriptor may not be present in the content  but it must present in PMT if there are multiple base view streams or multiple mvc streams present in TS.  The following parameters are a part of hierarchy descriptor that may be present in PMT of transport streams carrying mvc video sub bitstreams.

is a parameter in hierarchy descriptor (present in PMT).  PSI parser can parse it to determine which streams are base view and dependent view video sub-bitstreams.
Hierarchy_type is set to 9 for MVC video sub bitstreams and 15 for MVC base view sub bitstreams.

-# Hierarchy_layer_index :
If the hierarchy descriptor is present for this Scalable Video Coding (SVC ) video sub-bitstream then the video sub-bitstream of which the hierarchy_layer_index equals the hierarchy_embedded_layer_index of this SVC sub-bitstream should have an elementary stream access point in the same access unit.

\anchor RemuxCode
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> Sample Code : Remux Set Up</h2>
\code
// Use case where both the mvc component es streams are available in the same program.

void setup_remux( ... ) {

parse_pmt()
// Go through all the ES streams in the (PMT) program and see if there is a base mvc ES stream and a dependent mvs ES stream available.

  result = ismd_remux_open(*handle, *output_port);

// Each component view mvc ES stream is hooked to a separate input port at the mvc remux.  A base view stream should always be added first before adding a dependent view.  �View_id� parameter in the API below is just an �mvc component view remux order� tracking mechanism for the application and the mvc remux unit.  It is managed by the API.  The base component view ES stream should always have the lowest (unsigned int) value of all the view_id�s added to the remux unit.  The streams would be remuxed (by the mvc remux unit) in increasing order of view_id�s.

*view_info holds the remux configuration information for a particular view. e.g. input port (handle) it is hooked to, etc.

  result = ismd_remux_add_view(handle, view_id, *view_info);
  result = ismd_remux_add_view(handle, view_id, *view_info);
  result = ismd_remux_set_state(handle, play_state);
}

\endcode

\anchor RemuxMPTS
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> MPTS 3DBD Pipe</h2>

\image html remux2.png Fig.R2 Demux-Remux pipe in MPTS use case
\anchor RemuxSSIF
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> SSIF 3DBD Pipe</h2>

\image html remux3.png Fig.R3 Demux-Remux pipe in SSIF  use case

\anchor RemuxAPI
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> Reference to Remux API</h2>
- \ref ismd_remux "ISMD Remux API"


*/

