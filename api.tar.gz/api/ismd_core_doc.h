/*

This file is provided under a dual BSD/GPLv2 license.  When using or
redistributing this file, you may do so under either license.

GPL LICENSE SUMMARY

Copyright(c) 2010 Intel Corporation. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
The full GNU General Public License is included in this distribution
in the file called LICENSE.GPL.

Contact Information:

Intel Corporation
2200 Mission College Blvd.
Santa Clara, CA  97052

BSD LICENSE

Copyright(c) 2010 Intel Corporation. All rights reserved.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in
the documentation and/or other materials provided with the
distribution.
* Neither the name of Intel Corporation nor the names of its
contributors may be used to endorse or promote products derived
from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



   /** @weakgroup new_smd_core  Chapter 2 SMD Core

     \anchor Contents
	 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> Contents</H2>
     - <A HREF="#Introduction" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 2A Introduction</A>

     - <A HREF="#EventManager" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 2B Event Manager</A>
        - <A HREF="#EventManagerServices"> 2B.1 Event Manager Services</A>
        - <A HREF="#EventMgrSampleCode1"> 2B.2 Sample Code Ex.1</A>
        - <A HREF="#EventMgrSampleCode2"> 2B.3 Sample Code Ex.2</A>

     - <A HREF="#ClockManager" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 2C Clock Manager</A>
     	- <A HREF="#PlatformSpecInfo"> 2C.1 Platform Specific Information</A>
     	- <A HREF="#SoftComp"> 2C.2 Clock Manager Services</A>
     	- <A HREF="#ClockUsage"> 2C.3 Clock Usage by Various Modules</A>
     	- <A HREF="#ClockMgrSampleCode1"> 2C.4 Sample Code Ex.1</A>
        - <A HREF="#ClockMgrSampleCode2"> 2C.5 Example 2</A>

     - <A HREF="#BufferManager" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 2D Buffer Manager</A>
     	 - <A HREF="#FrameManager"> 2D.1 Allocating a Frame Buffer</A>
     	 - <A HREF="#BuffSoftComp"> 2D.2 Software Components </A>
     	 - <A HREF="#BuffMgrSampleCode1"> 2D.3 Sample Code Ex.1 : Normal Buffer Allocation</A>
     	 - <A HREF="#BuffMgrSampleCode1"> 2D.4 Sample Code Ex.2: Frame Buffer Allocation</A>

     - <A HREF="#PortManager" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">  2E Port Manager</A>
        - <A HREF="#PortSoftComp"> 2E.1 Software Components </A>
     	- <A HREF="#PortMgrSampleCode1"> 2E.2 Sample Code Ex.1 : Output Port Being Read by an Application</A>
     	- <A HREF="#PortMgrSampleCode2"> 2E.3 Sample Code Ex.2: Input Port Being Fed  by an Application</A>

     - <A HREF="#DeviceManager" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 2F Device Manager</A>
      	- <A HREF="#DeviceMgrSampleCode1"> 2F.1 Sample Code Ex.1 : Opening a New Device</A>
     	- <A HREF="#DeviceMgrSampleCode2"> 2F.2 Sample Code Ex.2 : Opening a New Instance of Widget Device,perform some operation and Closing it</A>

    - <A HREF="#BuffMonitor" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 2G Buffer Monitor</A>
     	 - <A HREF="#BuffMonitorServices"> 2G.1 Software Components</A>
     	 - <A HREF="#BuffMgrSampleCode1"> 2G.2 Sample Code Ex.1 : Setting up a Buffer Monitor</A>
     	 - <A HREF="#BuffMgrSampleCode2"> 2G.3 Sample Code Ex.2 : Detecting Overruns</A>

   - <A HREF="#SMDTags" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 2H SMD Tags</A>
	- <A HREF="#SMDTagsEx1"> 2H.1 Pseudo Code Ex.1 : Client ID Tags</A>

  - <A HREF="#SMDCoreAPI" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">Reference to SMD Core APIs and Structures</A>



\anchor Introduction
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2A Introduction </h2>
  SMD core is to a set of base services used by all SMD applications and modules as shown in Fig.1 The SMD Core comprises  of   6 basic components:
  	-# Clock Manager : synchronize media processing elements
  	-# Port Manager :data flow of media buffers through pipelines
  	-#  Memory Manager :allocation and tracking of physically-contiguous buffers containing media data.
  	-# Event Manager :notify applications of asynchronous events
  	-# device Manager: defines and provides access to standard functions that every SMD module must support.
  	-#  Buffer Monitor :d detecting buffer overruns and underruns.

\image html SMDCore.png " Fig.1 SMD Core Components"

\anchor EventManager
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2B Event Manager</H2>

The objective of the SMD Event Manager is to provide a consistent and reliable method for asynchronous  event notifications across the entire SMD software stack.  These asynchronous events are  by nature  inherent  to  streaming media processing. Examples include errors detected in the stream or the arrival of user-data encoded into the stream.  The asynchronous events notifications can happen in 3 different ways

	-# Driver to Driver : For example driver detects  buffers  underflow and wants to notify an upstream driver that can modify the system buffering or system timing.

	-# User to User: (need example)
	-#  Driver to User: driver detects an error in the media stream and wants to notify the application so that the application can track the error rate.


The most challenging aspect of the design and implementation of the event manager is synchronization.  Events are inherently asynchronous, however, access to underlying data that supports the event mechanisms must be synchronized to prevent race conditions.  Event synchronization is  further complicated by the requirement that a single thread can wait on multiple events at the same time.

\anchor EventManagerServices
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2B.1 Event Manager Services</H2>

The event manager consists of a set of data structures to mainting the internal state of events and a set of functions to manipulate those data structures.
There are no persistent threads in the event manager.  Except for the one-time global initialization of the event manager, all data structure manipulation is handled within the
context of the threads that call the event manager APIs. Fig.2 shows the high level  interaction between the event manager and other components in the SMD software stack. The functions can be broken down into three categores.

\image html EventManager.png "Fig2. Event Manager High Level Interaction"

-#	Resource management.  The event manager provides APIs to allocate resources and initialize a new event, and also to deallocate the resources for an event.
-# State changes.  The event manager provides APIs that allow clients/servers to change the state of an event from it's triggered state to it's reset state and vice versa.
-# Thread Block and Resume.  The event manager provides an API that allows a thread to block itself until the event state changes from reset state to triggered state.  In effect, the thread is suspended until another sofware component triggers the event.

Note:
\anchor EventMgrSampleCode1
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2B.2 Sample Code Ex. 1</H2>
 Sample  code shows how an application might use the event manager infrastructure to process errors from a driver.

 \code
 /*
  * This function processes errors reported by the widget device.
  */

 void process_widget_errors( ismd_dev_t widget_handle )
 {
    ismd_event_t widget_event;
    widget_error_t widget_error;

    /* Allocate an SMD event */
    ismd_event_alloc( &widget_event );

    /* Tell the widget driver to trigger the event any time
     * a WIDGET_ERROR occurs. */
    widget_event_associate( widget_handle, widget_event, WIDGET_ERROR );

    while ( 1 ) {
       ret = ismd_event_wait( widget_event, ISMD_TIMEOUT_NONE );
       if ( ret == ISMD_SUCCESS ) {
          widget_read_error( &widget_error );
          if ( widget_error = WIDGET_CLOSE ) {
             break; /* If the widget is closing, exit this thread */
          } else { /* Otherwise, handle the error. */
             handle_widget_error( widget_error );
          }
       }
    }
    /* free the event. */
    ismd_event_free( widget_event );
 }
\endcode
\anchor EventMgrSampleCode2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> Sample Code Ex. 2</H2>
 shows how an application can use the event manager to schedule and wait for a clock event.

 \code
 /*
  * Schedule a new clock event and waits for that event to occur.
  */
 void wait_for_clock_event( ismd_clock_handle_t clock,
                            ismd_time_t         time )
 {
    ismd_event_t async_event;
    ismd_clock_event_t clock_event;

    /* Allocate an new SMD event */
    ismd_event_alloc( ISMD_EVENT_TYPE_EDGE, &async_event );

    /* Schedule a new clock event for the specified time */
    ismd_clock_schedule_event( clock, time, 0,
                               async_event, &clock_event );

    /* Wait for the clock event to occur */
    ismd_event_wait( async_event, ISMD_TIMEOUT_NONE );

    /* free the event. */
    ismd_event_free( async_event );
 }
\endcode

\anchor ClockManager
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2C Clock Manager </H2>

 \image html Clock1.png " Fig.3 High Level Interaction of Clock Manager"

 Clock manager is a clock management utility used by most of ISMD modules as well as ISMD clients.  An SMD reference clock consists of a nominal 90 KHz or 180 KHz hardware counter and a consistent software
interface for using the counter. Two resources are required for SMD Core to provide such a clock: a physical counter and a
physical clock that can be routed to drive the counter. The physical clock and counter resources are provided by SoC-specific clock and counter drivers.
Audio and video streams on the client side are handled exclusive of each other after the transport stream demux, demuxes the TS.
Audio and video samples are rendered with reference to a common clock.  At a high level, proper timing synchronization between audio and video
streams at the client is achieved by attaching presentation timestamps (PTS) to presentation units (e.g. video frames or audio samples).
The timestamps are compared to a clock, called a presentation clock (wall clock) running at 27MHz, shared between all elements of a pipeline.
Each sample is presented / rendered when its timestamp matches the pipeline's wall clock. The basis for synchronization of related streams within a pipeline (e.g. audio and video) is the use of a common clock that is used for
controlling presentation timing.  some terms frequently used in the context of clock maangers are lsited below.

-# A common base time value/offset is provided to each module in a pipeline when a stream is started.  Generally a snapshot of the reference time is taken and set to base_time when the pipeline is started.

-# While the base time is greater than the reference time (i.e. the base time is in the future), the pipeline is not yet started and no samples should be presented.

-# When the base time is less than the reference time, stream time equals the reference time minus the base time.

-# Modules can convert between reference and stream time values as follows:
-# reference_time = stream_time + base_time
-# stream_time = reference_time - base_time

There are two generic clock types, but other platform specific clock types may exist.

-#	Fixed:  A fixed clock is a counter driven by a local crystal at a fixed, nominal 90 KHz.
-# Software-controlled:  A software controlled clock is a counter driven by a clock whose frequency may be adjusted by software. This type of clock is useful for implementing clock-recovery schemes.

Clock driver performs resource management for physical hardware clocks that may only be used by one pipeline at a time and, optionally, provide the ability to control the frequency of a clock.  Specifically, clock drivers support the following controls for their counters:

-# Select an appropriate source for the clock
-# Read the current clock value
-# Set or cancel alarms (invoke a callback when the clock reaches or exceeds a specified value)
Intel media processors have multiple presentation clocks which may be independently used as references for presentation timing of several streams.

\anchor PlatformSpecInfo
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2C.1 Platform Specific information </H2>

CE3100 has 6 physical wall clocks.  Wall clock runs at 90 Khz.  Only one TS(TS driving full screen audio and video) can be driven by master PLL.  The wall clock which is driven by master clock (which drives the full screen audio and video) is the primary clock (API : ismd_clock_make_primary ()).

 Client can also set the alarms so as to trigger an event at those time instants.  The alarms can be periodic as well.
 This can be done using ismd_clock_alarm_schedule() API.  Clients can set and get time from the wall clock timestamp register which captures the time at certain time instants triggered by various sources such as software trigger, hardware trigger or PCR inputs from the TS for which the respective wall clock is being used.  The sources that can trigger the wall clock time stamp logic can be selected using ismd_clock_set_timestamp_trigger_source() API.  The vsync time stamp logic is triggered by video display hardware.  It's triggered immediately after the display begins transmitting a new picture to the monitor (during vertical display interval).  So the vsync time stamp register will hold the time when the last picture was flipped. Client can read the vsync time stamp register with ismd_clock_get_last_vsync_time() API.  Frequency of the program clock can be adjusted as per requirements using ismd_clock_adjust_freq() API to lock the client side program clock to the house clock.

Reading the wall clock timestamps: After the snapshot of the wall clock is taken, an interrupt is asserted, and the trigger circuit is
locked until the software reads the timestamp registers.   So the software has to acknowledge in order to unlock the trigger circuit.

\anchor SoftComp
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2C.2 Clock Manager Services</H2>
The clock-managers dependencies are OS Abstraction Layer and SMD core event manager.  There are two components: the ISMD clock manager and the client.  The discussion in this section will focus on the ISMD clock manager since the client is merely calling into the buffer clock to allocate, manipulate and free clocks.
Figure 3 above shows the ISMD clock manager and several clients using it.  ISMD clock manager is a part of SMD core through which various common services are provided to the modules as well as application.  Clock manager abstracts various services provided by the clock driver, utilizes services provided by SMD core event manager to provide management services for the clock hardware on the platform.
The Clock driver registers its resources with SMD Core when they are initialized.  The clock driver expects that the higher-level software i.e. the SMD Core Clock Manager will provide synchronization for all clock devices.  However, during clock device allocation, the higher-level software does not know which clock device to synchronize.  Therefore, the clock driver will protect all allocate and free calls.


Clock Manager handles all of the clock management.  It exposes  allocate, free and several clock manipulation and access functions.  It provides
a set of APIs that allows other SMD devices to register their hardware clocks and counters so that they may be used by respective clients (modules / application).
The ISMD clock manager is initialized internally by the ISMD core's initialize function.  ismd_clock_alloc() and ismd_clock_free() are used
to allocate clocks of specified type and free them.  To allocate a clock the client needs to specify the type of the clock(fixed :1, software controlled :2
or platform specific clock : >2) that needs to be allocated and a return pointer to the clock handle.  ismd_clock_free() just requires the clock handle to be specified which is returned by ismd_clock_alloc().
It also provides services to get the current time of the clock and set current time of the clock by using ismd_clock_get_time()
and ismd_clock_set_time()respectively.  To get the time ismd_clock_get_time() requires the clock handle for the clock of interest and
a return pointer for time.  As soon as the board is reset the clock starts counting.  So if the client tries to read the clock, the value
read would be arbitrary.  But the client can set the clock to start counting from a particular value by using ismd_clock_set_time().
To set the time ismd_clock_set_time() requires a clock handle and time to set. Generally the first PCR in the TS is used to set the clock
under normal playback and this would also be a critical service during trick modes.
Refer to the Media playback HLD for more information.  When ismd_clock_set_time() function returns, the clock will begin incrementing normally
starting from the specified time value.

The media processing software occasionally needs to perform activities at specific "wall clock" times.  The Clock Manager supports the idea of alarms where an event is triggered at specific time.  Clients can schedule or cancel an alarms (to trigger an event allocated with ismd_event_alloc(), event manager) with ismd_clock_alarm_schedule() and ismd_clock_alarm_cancel() respectively.
To set a particular wall clock as primary clock, use ismd_clock_make_primary().Client can adjust the frequency of a clock using ismd_clock_adjust_freq().  The clock adjustment is done by providing a value in parts per million.  This service can be used for clock recovery.

ismd_clock_get_time() reads the value of the timestamp register which has the clock value at the time of the last time stamp capture.  Similarly ismd_clock_get_last_vsync_time() reads the value from the vsync register which has the clock value at the time of last vsync time stamp capture. ismd_clock_trigger() provides a way for the clients to trigger the time stamping logic in clock circuitry which will latch the value of the program clock at the time of the trigger.


\anchor ClockUsage
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2C.3 Clock Usage by Various Modules</H2>
	<H3>TSD</H3>

The TSD must adjust or rebase PTS values encoded within a stream so that they are relative to the
local presentation clock being used and so that any discontinuities are eliminated. As a transport stream passes
through the TSD, the TSD searches for the first PCR in the stream, discarding any packets prior to the first packet
containing a PCR. It then uses that initial PCR value as a basis for how to rebase the stream to a local time base.
For all the rebasing TSD will use clock manager services.

	<H3>Video Renderer</H3>

The video renderer places each incoming picture into a local queue and uses SMD Core clock manager services to request/schedule a callback at the time of each frame�s PTS. As stream time matches each frame�s PTS time, SMD Core then invokes the video renderer�s callback function. To reduce latency, this callback is made from within an ISR context. The video renderer�s callback scans its internal queue for frames whose PTS values are less than the current time, and pushes them to the display driver for output.  For proper A/V sync video renderer will use clock manager services.

<H3>Audio Renderer</H3>

The application software can provide different reference
clocks to different input audio elementary streams for independent streaming time, or the
application can provide the same reference clock to multiple input audio elementary streams
to synchronize the processing and rendering of all the input audio elementary streams.
For proper A/V sync audio renderer will use clock manager services.


For jittery or asynchronous transmission paths (e.g. IP networks), a UDP Clock Recovery module is provided.
The module filters the jitter introduced by UDP broadcast and performs clock recovery.
To synchronize push based media sources properly, clock manager services will be used


\anchor ClockMgrSampleCode1
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2C.4 Sample Code Ex. 1</H2>
 This case will illustrate the following sequence of events between three clients and the core.
 The first client will create a clock, and use device manager to use that clock for client two.
 These two clients (Client one and client three) dereference the clock when they are done with it and the buffer is freed.
 Note that client two is not involved in the freeing process at all because it didn�t allocate any clock.

 \code
 //////////////////////////////////////////////////////////////////////
 // Client1:
 ismd_clock_t clock;
 ismd_time_t time;
 ismd_result_t result = ISMD_SUCCESS;


 result = ismd_clock_alloc(1, &clock);
 if (result != ISMD_SUCCESS) printf("error allocating fixed clock\n");

 // do stuff to the clock here, like set and get the clock.  Fill the time structure first

 time = 1324;

 result = ismd_clock_set_time(clock, time);
 if (result != ISMD_SUCCESS) printf("error setting the time\n");

 // some local function to do the operation.
 result = pass_buffer_to_client_2();

 // Tell the device manager that client 2 will use clock #1

 //////////////////////////////////////////////////////////////////////
 // Client2:
 ismd_clock_t clock;
 ismd_time_t start_time, interval;
 ismd_clock_alarm_t alarm;
 ismd_event_t event;
 ismd_result_t result = ISMD_SUCCESS;

 // some local function to do the operation.
 result = wait_for_handle_to_come_from_client_1(&clock);
 if (result != ISMD_SUCCESS) printf("client2: error receiving clock handle\n");


 // schedule the alarm or whatever here.
 // register an event using event manager

 result = ismd_clock_alarm_schedule(clock, start_time, interval, event, *alarm);
 if (result != ISMD_SUCCESS) printf("client2: error scheduling the alarm\n");

 // done with alarms

 result = ismd_clock_alarm_cancel(clock, alarm);
 if (result != ISMD_SUCCESS) printf("client2: error canceling the alarm\n");

 //////////////////////////////////////////////////////////////////////
 // Client3:
 ismd_clock_t clock;
 int adjustment;
 ismd_result_t result = ISMD_SUCCESS;

 // some local function to do the operation.
 result = ismd_clock_alloc(2, &clock);
 if (result != ISMD_SUCCESS) printf("client3: error allocating software controlled clock\n");

 // read the clock or adjust the frequency or whatever here.

 Adjustment =10;
 result = ismd_clock_adjust_freq(clock, adjustment);
 if (result != ISMD_SUCCESS) printf("client3: error adjusting the clock frequency\n");

 // done with clock operations

 \endcode


 \anchor ClockMgrSampleCode2
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2C.5 Example 2</H2>
Clock Manager interaction with Event Manager.
 \image html Clock2.png " Fig.4 Clock Manager interaction with Event Manager"

\anchor BufferManager
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2D BufferManager</H2>

 The ISMD buffer manager is a physical memory management utility used by all ISMD modules as well as ISMD clients.  As such,
 it impacts nearly every piece of code in the project.  The ISMD buffer manager relies on boot-time configuration information
 such as the memory map. The proper operation of the ISMD buffer manager depends on the correctness of this memory map and correct usage by the clients.
 This information is supplied by a separate utility, called the Platform Configuration.
 The platform_config reader, a utility that supplies information about the memory layout among other things, must exist.
 This is a utility that is not part of the SMD core but is a dependency of the core.  This utility must exist in order for
 the SMD core to work.   The memory layout must supply sufficient memory to handle all desired use cases.
 If this is not the case, the ISMD buffer manager will not be able to allocate enough buffers to meet
 the incoming requests.  Failure to allocate an ISMD buffer should be considered a serious system failure.
 While it is possible to wait a little bit longer� and try the allocation again, it is up to clients to notify control code that the system is running out of memory and is not in a stable state.


  \image html Buff1.png " Fig.5 Buffer Manager High Level Interaction"
  The ISMD buffer manager exposes an allocation function that will supply a descriptor for a physically-contiguous
  buffer of the specified size, if one is available.  Descriptors can be read, modified, and processed by other clients �
  either ISMD devices or applications.  Each buffer descriptor carries a reference count, and when all users of a buffer
  dereference it then the buffer is returned to the pool of usable physical memory. Frame Buffers have a special need and is explained in the next section.

  \anchor FrameManager
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2D.1 Allocating a Frame Buffer</H2>
 Video frame buffers often take much more space in linear memory than they need to.  This is because each line of
 pixels of a buffer takes up one stride� of data.  Stride has the effect of making video memory appear two-dimensional
 as it determines a memory width�. In the Intel SOCs, some devices limit stride to values like 2048, 4096, or 8192.
 This means that the stride cannot closely match the frame�s width.  If the stride is 2048, then each line of the frame
 will start 2048 bytes after the previous line did, regardless of the actual frame width.  A particular video frame may be
 720x480 pixels, but will take up the same amount of space as a frame that is 2048x480 if the stride is 2048.  In essence,
 the width of the spot in memory that the frame occupies becomes the stride, which is often much larger than the actual width needed.

  \anchor BuffSoftComp
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2D.2 Software Components </H2>
  Fig.6. shows the ISMD buffer manager components used by  clients. The ISMD buffer manager is internally split into a memory layout parser, a buffer allocator, and a frame buffer manager.
  The various levels of the ISMD Buffer Manager in the figure above perform the following tasks.

  -#Layout Parser: When the ISMD core is initialized, this block reads the memory layout from the Platform Configuration and saves that information into some internal structures.  This code only executes on startup.
  -#Internal Structures: These store the memory layout information in a way that is quick to access from the allocation and free routines, making allocation and freeing as inexpensive as possible.
  -# The Buffer Allocator serves the requests for buffer allocations and frees.  If a frame buffer is freed, this block calls into the Frame Buffer Manager to handle the free operation.
  -# The Frame Buffer Manager handles video frame-specific operations including the stride-based buffer packing.  This block makes some calls into the Buffer Allocator to allocate and free blocks of frame memory.

  \image html Buff2.png " Fig.6 Software Components of Buffer Manager"
     The  layout parser only runs when the ISMD buffer manager is initialized.  It does a lot of the allocation work in the beginning by converting the memory map into internal structures to make the allocation process faster.
     The buffer allocator is where the external interfaces are connected.  This code parses the internal structures to allocate, free and manipulate the properties of buffers.
     The frame buffer manager uses the buffer allocator and some of its own interfaces to manage the allocation and freeing of video frame buffers.
     An underlying design restriction on the ISMD buffer manager is that it does not create any threads.

     <H3> Client </H3>
     The client interfaces are not of interest in the operation of the buffer manager,
     since all calls are made by the client into the buffer manager.  The only exception is the release function
     in the buffer descriptor that the client can overload.  This function must be able to accept a release context
     and a pointer to a buffer descriptor.  Clients should only use the release function if they exist in the same
   process space that the buffer manager does.

 \anchor BuffMgrSampleCode1
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2D.3 Sample Code Ex.1</H2>


 This  Example as shown in Fig.7  will illustrate the following sequence of events between three clients and the core.
 The first client will create a buffer, increase the reference count, and pass the buffer to clients two and three.
 These two clients dereference the buffer when they are done with it and the buffer is freed.  Note that client one is not involved in
 the freeing process at all; once it sends the buffer to the other clients it can forget about the buffer.
 \image html Buff3.png " Fig.7 Normal Buffer Flow Sequence Diagram"
  \code
  //////////////////////////////////////////////////////////////////////
  // Client1:
  ismd_buffer_handle_t buffer;
  ismd_result_t result = ISMD_SUCCESS;

  result = ismd_buffer_alloc(1024, &buffer);
  if (result != ISMD_SUCCESS) printf("error allocating buffer\n");

  // do stuff to the buffer here, like read descriptor and update it.

  result = ismd_buffer_add_reference(buffer);
  if (result != ISMD_SUCCESS) printf("error increasing ref count\n");
  // reference count is now 2

  // some local function to do the operation.
  result = pass_buffer_to clients_2_and_3();

  // done with buffer operations

  //////////////////////////////////////////////////////////////////////
  // Client2:
  ismd_buffer_handle_t buffer;
  ismd_result_t result = ISMD_SUCCESS;

  // some local function to do the operation.
  result = wait_for_buffer_to_come_from_client_1(&buffer);
  if (result != ISMD_SUCCESS) printf("client2: error receiving buffer\n");

  // read the buffer or whatever here.

  result = ismd_buffer_dereference(buffer);
  if (result != ISMD_SUCCESS) printf("client2: error dereferencing buffer\n");

  // done with buffer operations

  //////////////////////////////////////////////////////////////////////
  // Client3:
  ismd_buffer_handle_t buffer;
  ismd_result_t result = ISMD_SUCCESS;

  // some local function to do the operation.
  result = wait_for_buffer_to_come_from_client_1(&buffer);
  if (result != ISMD_SUCCESS) printf("client3: error receiving buffer\n");

  // read the buffer or whatever here.

  result = ismd_buffer_dereference(buffer);
  if (result != ISMD_SUCCESS) printf("client3: error dereferencing buffer\n");

  // done with buffer operations

\endcode


 \anchor BuffMgrSampleCode2
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2D.4 Sample Code Ex.2: Frame Buffer Allocation</H2>
   This scenario may take several code paths depending on the state of the frame buffer manager.  If the buffer manager does not
   have any memory chunks split up into the requested size (or the ones it has are full or from a different context),
   it must first allocate and split up a new one.  This extra allocation and splitting is optimized to take very little time and will
   not cause any performance issues.   Once there is a chunk split to the correct buffer size, a piece of that is reserved for
   the new buffer and the frame buffer manager allocates an empty descriptor from the ISMD buffer manager.  The empty descriptor is used
   to describe the new frame buffer and it is returned to the client.
   As described before, the frame buffer manager supports contexts that are used to prevent buffers that belong from different devices or
   pipelines from sharing the same block of memory  even if they are of the same size.  These contexts are simply unique identifiers
   that are specified when frame buffers are allocated the frame buffer does not interpret these integers in any way except to ensure
   that frame buffers allocated with different contexts never share a block of memory.

   \image html Buff4.png " Fig.8  Allocating a Frame Buffer Flow Sequence Diagram"
    \code

	// Allocate 1920x1080 byte frame buffer
	result = ismd_frame_buffer_alloc(1920, 1080, &buffer);
	if (result != ISMD_SUCCESS) {
	   printf("error allocating frame buffer\n");
	}

	// Allocate a 1920x2176 (8-bit 4:2:2) frame buffer using context 5
	result = ismd_frame_buffer_alloc_with_context(1920, 2176, 5, &buffer);
	if (result != ISMD_SUCCESS) {
	   printf("error allocating frame buffer\n");
	}
    \endcode
\anchor PortManager
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2E Port Manager</H2>
In a system with many entities communicating with each other, it helps to abstract the communication method to be generic and uniform.
The ISMD port manager is an ISMD core service through which all data I/O takes place with the ISMD modules as shown in Fig.8..  This also allows for the easy addition of new entities and new configurations.  This benefit is particularly noticeable in a media environment, where many different pipeline configurations exist.  If modules directly communicated, each I/O interface becomes special-purpose and would likely need modification each time a new module was interfaced to it.  Other concerns like process-safe connections further complicate the direct module-module communication scheme.  For these reasons a generic, unified, connection-based data/metadata I/O mechanism will be used in ISMD.
Circular buffer connections can be used in some cases, where data is moved through endless buffers that wrap around.  This scheme is very performance-friendly but has a major drawback; it is very difficult to associate metadata with any specific point in the buffer.  This model also does not lend itself to a frame buffer circulation or other models that need discrete buffers.
Because circular buffers cannot be used for all connections, they will not be used at all.  Instead, a model that uses discrete buffers is employed.  The buffers are moved through ports abstract entities that each module owns and uses to move buffers to/from other entities.  Ports can be dynamically connected to other ports or interfaced to non-ISMD software.  Since each piece of data has its own discrete buffer, it is easy to attach metadata to specific pieces of data.
If two devices were to communicate, the writing device (the producer) would own an output port and the reading device (the consumer) would own an input port.  The two ports would be connected and data written to the output port by the producer can be read from the input port owned by the consumer.

\image html PortMgr1.png " Fig.9 Port Manager High Level Interaction"

\anchor PortSoftComp
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2E.1 Software Components </H2>
  The port Manager has two components  ISMD port manager and  ISMD queue manager as shown in Fig.9.
  The ISMD port manager internally uses the ISMD queue manager to handle most of the underlying mechanisms.  Each port internally owns
  a queue.  The port manager adds functionality for connecting and I/O events.  The events are used instead of callbacks because
  the events can cross process boundaries while the callbacks cannot. The ISMD queue manager is not exposed externally therefore how it works
   is not explained here except that it supports variable-depth queues of ISMD buffers and has callbacks for input and output events.
   \image html PortMgr2.png " Fig.10 Port Manager  Software Components"

Internally, the ISMD queue manager implements most of this functionality with the ISMD port manager acting more as a wrapper.  ismd_port_alloc() creates a queue with the desired configuration for the port (maximum depth, watermark, etc�).  Read and write operations are forwarded to the queue read and write calls.  The queue callbacks are used to signal user-supplied events and for the automatic buffer passing between connected ports.  Basically, the ISMD port manager adds a few features on top of the ISMD queue manager: input and output types, connections and error checking related to these features.
The ISMD port manager accomplishes most of its tasks using the callback functionality in the ISMD queue manager.
The queue manager basically calls these callbacks anytime anything happens to the queue related to the callback.
For instance if someone reads (or tries to read) a buffer from a queue, the queue level crosses the low watermark,
or the queue becomes empty, then the queue will want to pull a buffer from its input and call the pull callback to accomplish this.
The queue also has a push callback that works similarly.



  Figure 10 shows three cases: output port connected to application, input port connected to application, and output port connected to input port.  Each is explained in more detail below:
  -#Output port connected to application: The "pull" side of this port is connected to the ISMD module that owns the port.  The queue�s pull callback is set to a function that sets the module event that is supplied when the port is opened. The queue (and thus the port) calls this function when more data is needed from the module.  The calling of this function unblocks the module so it can push more data into the port.  The push side of the port works in very much the same way that the pull side does.  The queue�s callback signals the application�s event � supplied when the application attached� to the port - when the queue has data to get rid of.  This allows the application to unblock and read the data.
  -#Input port connect to application: This works just like the output port case, except the ends of the queue are switched.  The queue�s pull callback signals the event that the application supplied when attaching to the port.  The push callback signals the event that the module supplied when creating the port.
  -#Output port connected to input port: In this case data is moved between two modules automatically  without any application intervention and without any extra threads.  The push callback in the output port�s queue is set to an ISMD core function that writes the supplied buffer into the input port�s queue.  The pull function in the input port�s queue is set to a function that tries to read a buffer from the output port�s queue.  The act of connecting the port is what sets up the callbacks.  Any time a buffer operation is performed (the producing element writes a buffer into its output port or the consuming element reads a buffer from its input port) these callbacks will move data through the connection.  This establishes automatic buffer movement without any threads.  The two modules are unblocked in the same way that they were in the single-port model.

  \image html PortMgr3.png " Fig.11 Use of Queue Call Backs"

\anchor PortMgrSampleCode1
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2E.2 Sample Code Ex.1 : Output Port Being Read by an Application</H2>

 In this simple scenario, an application will be reading data from an ISMD module through an ISMD port.  To keep this case simple,
 the port will never become full.  Essentially, this is a cycle of the producer module writing a buffer whenever it has one to write
 and the application waking up to read the buffers when they are ready from the port.  The means through which the application wakes up are
 abstracted � it can be through a polling function or an event signaled by the port.  This assumes that module has already allocated the
 port and the application already obtained the module�s port handle.  Note that the producing module does not use its event in this case,
 since it is controlling the flow of data.

\image html PortMgr4.png " Fig.12 Output Port Being Read by an Application"

\code
// Module
ismd_result_t result;
ismd_buffer_handle_t buf;
while (!stop) {
   wait_for_data_to_be_ready();  // Internal function
   get_data(&buf);               // Internal function

   result = ismd_port_write(output_port, buf);
   if (result != ISMD_SUCCESS) {
      printf("This example does not handle port full\n");
   }
}


//////////////////////////////////////////////////////////////////////
// Application
ismd_result_t result;
ismd_buffer_handle_t buf;
while (!stop) {
   wait_for_port_to_have_data(); // Poll the port or use an event

   result = ismd_port_read(output_port, &buf);
   if (result != ISMD_SUCCESS) {
      printf("Unexpected error\n");
   }
   process_data(buf);            // Internal function
}
\endcode


\anchor PortMgrSampleCode2
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2E.3 Sample Code Ex.2 : Input Port Being Fed by an Application</H2>

 Similar to the previous scenario, an application is performing I/O with a module through an ISMD port.  This time, the application is writing data into the port for the module to process.  This shows the port becoming full and the producer waiting until it is able to write more data.  As before, the method through which the producer and consumer wake up to write or read data is abstracted.  This assumes that the module has already allocated the port and the application already obtained the module�s port handle.

 \image html PortMgr5.png " Fig.12 Input Port Being Fed by an Application"

 \code
//////////////////////////////////////////////////////////////////////
// Application
ismd_result_t result;
ismd_buffer_handle_t buf;
while (!stop) {
   wait_for_data_to_be_ready();  // Internal function
   get_data(&buf);               // Internal function

   wait_for_port_to_have_space(); // Poll port or use event
   result = ismd_port_write(output_port, buf);
   if (result != ISMD_SUCCESS) {
      // error
   }
}

//////////////////////////////////////////////////////////////////////
// Module
ismd_result_t result;
ismd_buffer_handle_t buf;
while (!stop) {

   wait_until_possible_to_accept_more_data();   // Internal function

   wait_for_port_to_have_data(); // Poll port or use event
   result = ismd_port_read(input_port, &buf);
   if (result != ISMD_SUCCESS) {
      // error
   }

   process_data(buf);            // Internal function
}

\endcode

\anchor DeviceManager
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2F Device Manager</H2>
 The device manager is a simple component of the SMD Core, but it is also a component that all other SMD modules depend
 upon for proper operation.  Therefore, the device manager must be 100% robust.  Care must be taken to ensure that all possible error
 conditions are handled and all possible race conditions are avoided.

 The objective of the SMD Device Manager is to generate and maintain system-wide unique device handles and a set of
 common functions that operate on those handles.  Those functions include close, flush, set_state, set_clock, and set_stream_base_time.
 Each SMD module implements device-specific version of these functions and the device manager implements a common version which invokes
 the device-specific version.  The Device Manager also provides a method for SMD modules to associate local context information with device
 handles.  This allows the modules to allocate local resources associated with a device instance without having to implement their own method
 of translating a device handle into a local resource.

\image html DeviceMgr.png " Fig.13 High Level Interaction of Device Manager"
\anchor DeviceManagerServices
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2F.1 Device Manager Services</H2>

The device manager has a very limited set of functionality.  The functions can be broken down into three categores.

-#Handle Allocation/Free.  The device manager provides APIs to allocate and free a device handle.
-#Assign/Retrieve User data.  The device manager provides APIs that allow SMD modules to assign user data to a device handle and later
  retrieve it.  This feature provides SMD modules with an instant method of associating a device handle with device-specific context
  information.
-#Common functions.  These are the common functions that all SMD modules may implement.  They are close, flush, set_state, set_clock,
   and set_stream_base_time.

   \anchor DeviceMgrSampleCode1
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2F.2 Sample Code Ex.1 : Opening a New Device</H2>
 The following sample shows how an SMD module would use the device manager when opening a new instance of a device.
   \image html Device2.png " Fig.14 Sequence Flow : Opening a New Device"

   \code
   /*
    * Open an new instance of the widget device and return a handle
    * to that new instance.
    */
   ismd_result_t ismd_widget_open( ismd_dev_t *handle )
   {
      ismd_result_t result;
      widget_context_t *widget_ctx;
      ismd_dev_ops_t widget_ops;

      widget_ops.close         = widget_close;
      widget_ops.flush         = widget_flush;
      widget_ops.set_state     = widget_set_state;
      widget_ops.set_clock     = NULL;
      widget_ops.set_base_time = NULL;

      /* Allocate an new SMD device handle. */
      result = ismd_dev_handle_alloc( handle );
      if ( result == ISMD_SUCCESS ) {
          alloc_widget_ctx( &widget_ctx );
          init_widget_ctx( widget_ctx );
          result = ismd_dev_set_user_data( *handle, widget );
          if ( result != ISMD_SUCCESS ) {
             ismd_dev_handle_free( *handle );
          }
      }

      return ( result );
   }
\endcode

\anchor DeviceMgrSampleCode2
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2F.3 Sample Code Ex.2 : Opening a New instance of widget device,perform some basic operation and close it</H2>
 An appliction opens a new instance of a widget device, performs some operations on the device, and closes the device again.
 \image html Device3.png " Fig.14 Sequence Flow : Opening a New instance of Widget device"
 \code
 /*
  * Get a new widget device instance, set its state to playing,
  * set its state to pause, flush it, then close it.
  */
 void app_function( void )
 {
    ismd_result_t result;
    ismd_dev_t handle;

    /* Open a new instance of the widget device. */
    result = ismd_widget_open( &handle );
    if ( result == ISMD_SUCCESS ) {
       ismd_dev_set_state( handle, ISMD_DEV_STATE_PLAY );
       ismd_dev_set_state( handle, ISMD_DEV_STATE_PAUSE );
       ismd_dev_flush( handle, true, ISMD_EVENT_HANDLE_INVALID );
       ismd_dev_close( handle );
    }
 }

\endcode


\anchor BuffMonitor
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">   2G Buffer Monitor</H2>

The Buffering Monitor (BUFMON) Driver is an SMD module that detects and takes steps needed to adapt to buffering errors in push-mode playback.
The term push mode basically means playing streams from broadcast sources where the transmission rate cannot be altered such as TSI, UDP.
The SMD pipeline can be abstracted as a single buffer.  If the buffer overflows, data is dropped because the source can�t store it anywhere.  If the buffer empties, the SMD renderers starve and cannot render data on time.  Both of these cases are nasty and usually need corrective action to prevent them from being permanent.
When playing from a file or optical disc (called pull mode) these problems generally don�t happen.  The source is generally capable of providing the data faster than the play speed (in other words, the buffer won�t underrun) and the player software only �pulls� more data when it is needed (in other words, the buffer won�t overrun).
Push mode refers to use cases such as playing broadcast data from sources like a satellite source, a terrestrial broadcast, cable, or network streaming over UDP.  These cases are different than file playback because the client device (SMD and the player) does not control the rate at which data becomes available.  In file or optical disc playback, when the player software needs to add more data, it simply requests it.  If it has enough, it stops requesting until it needs more.  In �push mode� this is not possible, the transmitter sends the data at a fixed rate and the player software has no control over this rate.
What this means is that that the client device must ensure that it plays the stream at the same average rate that it is being transmitted at.  If it is played too quickly, eventually the client runs out of data (called underrun) and if it is played too slowly the client has to start dropping packets because there is nowhere to store them (overrun).
This matching of the play rate to the transmission rate is generally handled by a process called clock recovery, where the client matches its play clock to a signal embedded in the stream that represents the speed of the transmitter�s clock.
Unfortunately, sometimes the transmission rate is outside of the window that clock recovery can adjust to  such as the case when a VCXO with a very narrow adjustment window is used.  Additionally, if a discontinuity is not handled correctly or the content has some incorrect timing attributes, the system may enter the buffering error state.  While this should not typically happen, having a �safety net� to recover from such a situation increases the system robustness.
The buffering monitor is to be that second line of defense if the typical mechanisms to deal with buffering are insufficient or fail for some reason, or if the content itself was not multiplexed properly.

\image html BuffMon1.png " Fig.15 High Level Interaction of Buffer Monitor with Other Modules"

Fig. 15 above shows, the push sources, SMD renderers, the new buffering monitor SMD module, the SMD Clock, and the client all need to be involved in making this functionality work.
The detection of overrun is to be done in the push source element or module, where packet loss due to buffer overrun is easiest to detect.  When this is detected an SMD event will be set to indicate to the buffering monitor that overrun is occurring.  This event can be set by an SMD device or some other device such as a UDP source or GStreamer element, allowing for software pipelines to use this functionality.
The detection of underrun is to be done in the renderer elements or modules, where the arrival of late samples due to underrun can be detected.  As with the overrun detection, an SMD event is used for notification.
When a buffering condition is detected, the buffering monitor adjusts the clock counter, used to time the presentation of the samples, to adjust the buffering being done by the renderers.
The client software (middleware or application) will be responsible for configuring the buffering monitor for the pipeline that it needs to function in.  This includes registering the underrun/overrun events as well as the SMD device handles for the renderers.
This functionality is designed to be used in push mode, although it may be useful in pull mode as well if the data source is too slow to operate in real-time.

\anchor BuffMonitorServices
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2G.1 Software Components</H2>
Figure 16 above shows the components involved and the major interactions for the buffering monitor.  The function names here are not necessarily the actual API names, but are descriptions of the basic operations.  Additionally not all operations are shown here.  The operations highlighted in red represent the client software registering events and renderer handles with the buffering monitor.  Operations highlighted in yellow represent the communication between the ISMD devices.  Operations in green represent events that the buffering monitor exposes to the client software for notification when a buffering correction was made, or when the pipeline is in a state that cannot be corrected by the buffering monitor.  Each component and its responsibilities and interfaces are described in the below.
\image html BuffMon2.png " Fig.16 Software Components of Buffer Monitor"

<H3>Event Types</H3>
There are two basic event types; events owned by the client to be notified of overruns and underruns (or both) by the bufmon driver, and bufmon owned events that are handed the tsin source and renderers to notify the bufmon when an overrun or underrun condition occurs.

Below are the five typical uses of these event types:

-# Client allocates event and gives handle to bufmon using ismd_bufmon_set_underrun_event for notification that underrun correction was attempted by bufmon; No action required by client.
-#	Client allocates event and gives handle to bufmon using ismd_bufmon_set_overrun_event for notification that overrun correction was attempted by bufmon; No action required by client.
-#	Client allocates event and gives handle to bufmon using ismd_bufmon_set_critical_error_event for notification that overrun and underrun is occurning and bufmon will not take action; Action required by client.
-#	Bufmon allocates event and returns handle to client using ismd_bufmon_get_push_source_overrun_event. This handle should then be passed to the tsin module/client with ismd_tsin_set_overrun_event  for the tsin to strobe when it detects an overrun. The bufmon event handler will then attempt to correct the overrun (Then notify the client application if ismd_bufmon_set_overrun_event was set).
-#	Bufmon allocates event and returns handle to client using ismd_bufmon_add_renderer (for audio and video). These handles should then be passed to the renderers with ismd_dev_set_underrun_event for the renderers to strobe when they detect an underrun. The bufmon will then attempt to correct the underrun (Then notify the client application if ismd_bufmon_set_underrun_event was set).


<H3>Push Mode Services</H3>
This device has the smallest role in the buffering monitor�s operation, since it merely reports when overrun has been detected.  Overrun is defined as the condition when the push source has to drop a packet because there is no more room in the pipeline�s buffers or the push source�s internal buffer to write it.  An event is registered with the push source for it to strobe when an overrun occurs.  In the case of TSI there is a hardware interrupt for this, for software sources the software needs to somehow log the condition so that an ISMD event may be strobed.  The interfaces described below are the interfaces for buffer monitoring, not all interfaces for that device.

<H3>SMD Clock</H3>
The SMD clock is used for the presentation timing during playback.  The buffering monitor needs to be able to change the clock value to compensate for underrun or overrun.  This can be done by reading the clock, incrementing the value read, and setting the clock value BUT these operations need to be atomic to protect against a higher priority thread causing a delay in between the read and set operations.  A new API to atomically complete these operations must be added.

 <H3>SMD Renderers</H3>
 The renderers need two major functionalities.  First, like the push-mode source, they need to be able to detect a buffering error and strobe an event to notify the buffering monitor.  The buffering error here is buffer underrun, when the renderer has �late� PTS values � in other words the samples are arriving after the time that they should have been rendered.  The renderers also need to be able to store how late the samples are and report this amount when queried.  This will be done through an ISMD dev function.
 Note that Underrun should not be reported unless it is for real.  In some discontinuity or signal loss cases the renderers may get a late sample or two but not actually be in underrun.
 For video, underrun can be defined as a large number of consecutive frames with late timestamps without any on-time frames in between.  The large number should be as large as the worst-case temporal encoding structure supported by the video decoder, such as 16 in the case of H.264 SD.
 For audio, underrun can be described as a number of consecutive audio frames with late timestamps without any on time frames in between.  The number depends on the audio internal pipeline and shouldn�t be larger than 2 or 3.

 \anchor BuffMgrSampleCode1
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2G.2 Sample Code Ex.1 : Setting up a Buffer Monitor</H2>

 This section describes two basic interaction types: client software setting up the buffering monitor, and the handling of buffering errors.
 This shows the client opening an instance of the buffering monitor, setting it up, and shutting it down.  It assumes that the clock, TSIN and renderers have already been opened.  It is assumed that this setup and teardown is done �around� the following sequence diagrams.
 \image html BuffMon3.png " Fig.17 "Setting up a  Buffer Monitor"
 Fig.17 above 3above shows the following: the application creating and setting the clock for the buffer monitor (required), the application registering the overrun event (required), the application registering the renderers (required), the application registering for the notices (optional), the application setting the viddec port to flush on overrun (optional), the buffer monitor being set to play (at the same time the pipeline should be) (required), and the teardown sequence.  Note that the teardown can be done several ways.  If the buffering monitor is torn down last, the other devices can simply be closed without the events being set to invalid but the flush ports must be removed so the buffering monitor does not try to access them.  If the buffering monitor is torn down early, the events must be set to invalid in the other devices as the buffering monitor will free the events internally. Also, the renderers do not need to be removed from the buffering monitor on shutdown but it is shown here for completeness.


 \code
 //////////////////////////////////////////////////////////////////////
 // Client:
 ismd_dev_t    vidrend_handle     = ISMD_DEV_HANDLE_INVALID;
 ismd_dev_t    audio_input_handle = ISMD_DEV_HANDLE_INVALID;
 ismd_dev_t    tsin_handle        = ISMD_DEV_HANDLE_INVALID;
 ismd_dev_t    bufmon_handle      = ISMD_DEV_HANDLE_INVALID;
 ismd_clock_t  clock              = ISMD_CLOCK_HANDLE_INVALID;
 ismd_result_t result             = ISMD_SUCCESS;
 ismd_event_t  tsin_overrun_event = ISMD_EVENT_HANDLE_INVALID;
 ismd_event_t  renderer_event     = ISMD_EVENT_HANDLE_INVALID;

 // Create the clock, tsin, vidrend and audio components (not shown)

 // Create the buffering monitor and assign the clock
 result = ismd_bufmon_open(&bufmon_handle);
 result = ismd_dev_set_clock(bufmon_handle, clock);

 // Register the events used to signal errors to the buffer monitor.
 // Note: these are events provided by the buffer monitor that should
 // be assigned to the push source (overrun) and the renderers.
 // (underrun) so they can strobe the events when the errors occur.
 // These events are not for the client to monitor, there are other
 // "notice" events for that.
 // Note that these events are owned by the buffer monitor and clients
 // should never free them.
 result = ismd_bufmon_get_push_source_overrun_event(
                                 bufmon_handle,
                                &tsin_overrun_event);
 result = ismd_tsin_set_overrun_event(tsin_handle, tsin_overrun_event);

 result = ismd_bufmon_add_renderer(bufmon_handle,
                                   vidrend_handle,
                                   &renderer_event);
 result = ismd_dev_set_underrun_event(vidrend_handle,
                                      renderer_event);

 result = ismd_bufmon_add_renderer(bufmon_handle,
                                   audio_input_handle,
                                   &renderer_event);
 result = ismd_dev_set_underrun_event(audio_input_handle,

 // Optionally register the viddec input port to be flushed when
 // Overrun is encountered.  This will help the pipeline �catch up�
 // in the case of HD video.  For some cases such as dual-stream HD,
 // the pipeline may never recover from overrun unless the viddec
 // input port is flushed.
 // Multiple ports can be registered in this way.
 result = ismd_bufmon_add_port_for_overrun_flush(bufmon_handle,
                                                 viddec_input_port);
                                                 renderer_event);

 // Optionally register for the notice events from the buffering
 // monitor.  These events inform the client when certain conditions
 // are detected.  These events should be allocated by the client.
 // Note that these events are owned by the buffer monitor and clients
 // should never free them.
 result = ismd_bufmon_set_underrun_event(bufmon_handle,
                                         und_notice_event);
 result = ismd_bufmon_set_overrun_event(bufmon_handle,
                                        ovr_notice_event);
 result = ismd_bufmon_set_critical_error_event(bufmon_handle,
                                               err_notice_event);

 // Start playback - set the pipeline to the playing state, including
 // the buffering monitor
 result = ismd_dev_set_state(bufmon_handle, ISMD_DEV_STATE_PLAY);

 // At this point playback is occurring.  Wait until playback needs to
 // stop.

 // Begin shutdown of the buffering monitor.  If the buffering monitor
 // is closed before the renderers and the push source, unregister
 // the events with them.  This way they won't attempt to use these
 // events after they were freed by the buffering monitor during close.
 // If the buffering monitor is shut down last, this is not needed.
 renderer_event = tsin_overrun_event = ISMD_EVENT_HANDLE_INVALID;
 result = ismd_tsin_set_overrun_event(tsin_handle, tsin_overrun_event);
 result = ismd_dev_set_underrun_event(vidrend_handle,
                                      renderer_event);
 result = ismd_dev_set_underrun_event(audio_input_handle,
                                      renderer_event);


 // Remove the renderers from the buffering monitor.  For simple
 // shutdown, this is not needed since the close function handles
 // this.  This would mainly be used for dynamic pipelines if a
 // renderer is closed but the pipeline itself is not.
 result = ismd_bufmon_remove_renderer(bufmon_handle,
                                      audio_input_handle);
 result = ismd_bufmon_remove_renderer(bufmon_handle,
                                      vidrend_handle);

 // Unregister the ports from the buffering monitor.  This is needed
 // if the pipeline devices that own these ports are closed before the
 // buffering monitor is closed � to prevent the buffering monitor
 // from using invalid port handles.
 result = ismd_bufmon_remove_port_for_overrun_flush(bufmon_handle,
                                                    viddec_input_port);

 // Close the buffering monitor.  This can be done before or after
 // closing the rest of the pipeline devices, but remember if closing
 // this before the other pipeline devices that were set to use the
 // buffer monitor's events, those devices should be told to stop
 // using the events before the buffering monitor is closed.
 result = ismd_dev_close(bufmon_handle);

 \endcode



 \anchor BuffMgrSampleCode2
 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> Sample Code Ex.2 : Detecting Overruns</H2>
 Once the buffering monitor has been set up, the renderer(s) may indicate a buffering underrun.  The buffering monitor receives this event and reacts by adjusting the clock to be backward in time.  This causes a short pause in playback long enough for the pipeline to rebuffer.  The renderers are queried for how late the most recent PTS value was so that the correct amount of buffering needed can be calculated.
 \image html BuffMon4.png " Fig.17 "Detecting Errors"
 When one of the renderers detects buffer underrun (samples are consistently arriving late) it strobes its underrun event to signal the buffering monitor.  The buffering monitor then adjusts the clock and notifies the client that an underrun was detected.  The amount used for the correction is obtained by taking the largest lateness amount queried from the renderers and then adding the programmable offset to it.  The offset is meant to communicate the amount of buffering required by the pipeline on top of what the content requires.

\anchor SMDTags
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt">  2H SMD Tags</H2>
There is function-based mechanism for attaching standardized event-related buffer tags which is used to track events in the stream like the end of the clip, the start of a new segment or play rate, or points in the stream that the application is interested in knowing when they get to a specific point in the pipeline.
The buffer tags is needed when something is to change in the stream (such as play rate or media format) without the stream being flushed or otherwise emptied. There is a set of functions for adding specific types of tags to a specified buffer.  There is another set of function for reading specific types of tags from a specified buffer.  Finally, there is a function to add the tags from one buffer to the tags of another buffer.

\anchor  2H.1 SMDTagsEx1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> Pseudo Code Ex.1 : Client ID Tags</H2>
In SMD, a buffer marked with an integer is called a "Client ID Tag".  Certain devices support event notification when such a marker reaches the device.  This can be used to coordinate dynamic transitions where knowledge of what data is in the pipeline is required. Following is the APIs related to Client ID Tag.


\code
/*
Allocates an empty SMD buffer (any buffer can be used, empty or not), uses ismd_tag_set_client_id() to attach the specified integer to the buffer, and insert the tagged buffer into the stream.
*/
ismd_buffer_alloc(0, &buffer);
ismd_tag_set_client_id(buffer, client_id);
ismd_port_write(input_port, buffer);

/*
The event from the vidrend is acquired by ismd_vidrend_get_client_id_seen_event().
Create client ID monitor thread to wait for the client ID event. Once the vidrend sets the event, the ismd_event_wait () wakes up.
The vidrend is queried for the most recently seen tag with ismd_vidrend_get_status(),
*/
ismd_vidrend_get_client_id_seen_event(vidrend_dev, &vidrend_client_event);
ismd_event_wait(vidrend_client_event, ISMD_TIMEOUT_NONE);
ismd_vidrend_get_status(vidrend_dev, &vidrend_status);
printf("client_id = %d\n", vidrend_status.client_id_last_seen);

\endcode

\anchor SMDCoreAPI
- \ref smd_core " SMD Core API": Reference to SMD Core APIs and Structures



 */


