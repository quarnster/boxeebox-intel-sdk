/*

This file is provided under a dual BSD/GPLv2 license.  When using or
redistributing this file, you may do so under either license.

GPL LICENSE SUMMARY

Copyright(c) 2010 Intel Corporation. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
The full GNU General Public License is included in this distribution
in the file called LICENSE.GPL.

Contact Information:

Intel Corporation
2200 Mission College Blvd.
Santa Clara, CA  97052

BSD LICENSE

Copyright(c) 2010 Intel Corporation. All rights reserved.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in
the documentation and/or other materials provided with the
distribution.
* Neither the name of Intel Corporation nor the names of its
contributors may be used to endorse or promote products derived
from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
AS IS AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



   /** @weakgroup new_smd_audio Chapter 4  SMD Audio

     \anchor Contents
	 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Contents</H2>
     - <A HREF=#Introduction style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 4A Introduction to Audio Sub System</A>
     	- <A HREF=#Audiofeatures>4A.1  Key Features</A>

     - <A HREF=#AudioInput style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">4B  Audio Inputs </A>
     	- <A HREF=#AudioInputco> 4B.1 List of  Audio Codec  Types Supported </A>
        - <A HREF=#AudioInputco2> 4B.2 Supported Channel Configuration, Sample Rate and Sample Width</A>
     	- <A HREF=#AudioRateSupp> 4B.3  Supported Sample Rate Conversion</A>
       	- <A HREF=#AudioCap> 4B.4  AudioCapture </A>

     - <A HREF=#AudioOutput style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 4C. Audio Outputs</A>
	 	- <A HREF=#AudioOutputMode> 4C.1 Output Mode  Attributes: Channel Configuration, Sample Rate and Sample Width</A>
	 	- <A HREF=#AudioPass> 4C.2  Pass Through Mode</A>
	 	- <A HREF=#AudioOutputMode3>  4C.3   Encoded Output Mode</A>

	 - <A HREF=#AudioSWComp style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">  4D Software Components of Audio Sub System</A>
		- <A HREF=#AudioAPM>  4D.1 Audio Processor Manager</A>
		- <A HREF=#AudioIM>  4D.2 Input Manager</A>
		- <A HREF=#AudioPSD2> 4D.3 Pipeline Stage Manager:Decoding Stage</A>
		- <A HREF=#AudioPSD2> 4D.4 Pipeline Stage Manager:Post Processing Stage</A>
			- <A HREF=#AudioPSD2de> 4D.4.1 Deinterleaver</A>
			- <A HREF=#AudioPSD2src> 4D.4.2  Sample Rate Converter</A>
			- <A HREF=#AudioPSD2mix> 4D.4.3 Mixing</A>
			- <A HREF=#AudioPSD2dmix> 4D.4.4 Down Mixing</A>
			- <A HREF=#AudioPSD2water> 4D.4.5 Water Mark Detector</A>
			- <A HREF=#AudioPSD2delay> 4D.4.6 Delay Manager</A>
			- <A HREF=#AudioTime> 4D.4.6 Audio Timing Control</A>
			- <A HREF=#AudioRend> 4D.4.7 Audio Renderer</A>


	- <A HREF=#AudioExamples style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">  4E Sample Codes/Algorithms</A>
		- <A HREF=#AudioEx1> 4E.1  Example 1 : General Audio Set Up</A>
		- <A HREF=#AudiopEx2>  4E.2 Example 2: Basic Play Back</A>
		- <A HREF=#AudioEx3>  4E.3 Example 3 : Pass Through Settings</A>
		- <A HREF=#AudioEx4>  4E.4 Example 4 : Mixing and Volume Control</A>
		- <A HREF=#AudioEx4>4E.5  Example 5 : Configure S/PDIF output for AC3</A>

		- <A HREF=#AudioInputco3 style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 4F  Capabilities Supported Codecs </A>
     		- <A HREF=#AudioMpegCodecs> 4F.1  MPEG Codecs</A>
     		- <A HREF=#AudioAACCodecs>4F.2  A Codecs</A>
     		- <A HREF=#AudioDolbyCodecs> 4F.3 Dolby Digital  Codecs</A>
     		- <A HREF=#AudioDolbyComp> 4F.4  Dolby Digital  Compatible Output</A>
     			- <A HREF=#AudioDolbyComp1> 4F.5  Sample Code: Configure S/PDIF output for AC3 output</A>
        	- <A HREF=#AudioDolbyPlus>4F.5.1  Dolby Digital  Plus</A>
     		- <A HREF=#AudioDolbyTrue> 4F.6  Dolby Digital  True HD</A>
     		- <A HREF=#AudioDTSSurround>  4F.7  DTS 5.1 Digital Surround Codec  </A>
     		- <A HREF=#AudioDTSLBR> 4F.8 DTS LBR  </A>
     		- <A HREF=#AudioDTrans>  4F.9  DTS Transcoder  </A>
     		- <A HREF=#AudioDTSHD>4F.10 DTS-HD MA/HRA  </A>

	- <A HREF=#AudioExamples style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">  4G Configuring Dolby  Codecs for Dolby Player Certifications</A>
		- <A HREF=#AudioDDEx>  4G.1 Dolby  Digital (DD or AC3) Codec Configurations</A>
			- <A HREF=#AudioDDEx1>4G.1.1  Ex. 1 : Karoke Capable Reproduction Mode</A>
			- <A HREF=#AudioDDEx2> 4G.1.2  Ex. 2 : Dynamic range compression mode</A>
			- <A HREF=#AudioDDEx3>4G.1.3  Ex. 3 : PCM Scale Factor </A>
			- <A HREF=#AudioDDEx4>4G.1.4  Appendix : Other Settings and Sample Code </A>
		- <A HREF=#AudioDDPlusEx>  4G.2 Dolby  Digital Plus (DD+ or EC3) Codec Configurations</A>
			- <A HREF=#AudioDDPlusEx1> 4G.2.1  Wrapper Code</A>
		- <A HREF=#AudioDDPlusEx> 4G.3  True HD</A>
					- <A HREF=#AudioDDPlusEx1> 4G.3.1 Wrapper Code</A>





    - <A HREF=#SMDAudioAPI>Reference to Audio API's</A>


\anchor Introduction
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4A Introduction to Audio Subsystem </h2>

Audio subsystem  is a powerful and complex audio processing engine. Audio subsystem  caters to  high-definition and high-resolution audio processing to provide
the highest quality of sound experience available in today's consumer electronics.  It is capable of accepting multiple audio streams as input,
processing and mixing the audio streams into one output stream, and rendering the output audio stream at  multiple  audio output interfaces.
In addition, Audio Processor also provides the ability of audio presentation-timing control for audio/video (A/V) synchronization in consumer electronics
applications, such as Blue Laser players, Internet Protocol (IP) set-top boxes (IP-STB), connected consumer electronic (CCE) products, cable set-top boxes, etc.
<br>
<br>

\anchor Audiofeatures
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4A.1 Key Features</H2>
High Level feature of Audio Subsystem include:
-# Elementary stream decoder interface for multiple encoding algorithms.
-# Ability of audio presentation-timing control for audio/video (A/V) synchronization in consumer electronics applications, such as Blue Ray players ,
Internet Protocol (IP) set-top boxes (IP-STB), connected consumer electronic (CCE) products, cable set-top boxes, etc.
-#  Audio subsystem  offers features such as volume control, speaker management, mixing/down mixing, pass-through mode, encoded audio output, audio watermark detection, in-band and out-of-band events/commands, I2S input audio capture, etc.
-# Two audio processers, each processor support maximum 11 inputs, 3 maximum input codecs simulatenously and upto 24 channels across all inputs
 for detailed list refer to supported codec list (section 4B.1), passthrough modes(4C.2), encoder list(4C.3).

\image html AudioCore2.png  Fig.1 Audio Sub System

<br>
<br>

\anchor AudioInput
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4B Audio Inputs  </H2>
Audio subsystem  receives inputs via two interfaces
-# Logical Interfaces : are standard SMD Ports  where buffers can be read by the clients. ES serve as input for logical interfaces.  ES could be a compressed stream or an uncompressed stream.
-# Physical Interfaces : correspond to specific, physical inputs  on a platform. Refers to the Audio capture unit used for feeding the audio from external soruce such as DVR, Blue Ray or Karaoke System.

\anchor AudioInputco
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4B.1  List of  Codec Supported </H2>
Following are the supported input formats:

-# LPCM
-# MPEG audio (MPEG-1/2, Layer 1/2/3, )
-# AAC-HE (upto v2)
-# AAC-LC
-# DTS Core (5.1)
-# DTS-HD HRA
-# DTS-HD MA
-# Dolby Digital (AC3)
-# Dolby Digital Plus (DD+)
-# Dolby TrueHD
-# Dolby MS-10
-# DTS broadcast
-# DTS-LBR

<br>
<br>



\anchor AudioInputco2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4B.2 Supported Channel Configuration, Sample Rate and Sample Width </H2>
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> Channel Configuration </H3>
-# Up to 7.1 channels

<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Sample Width/Size</H3>
Sample size refers to the bit depth of each audio sample. The more bits used during encoding, the higher the precision for reproducing and rendering the audio wave, producing higher quality audio. For highest quality, the output sample size should always match the input sample size unless sample size conversion is necessary.
-# 8-bit
-# 16-bit
-# 20-bit
-# 24-bit


<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> Sampling Rates </H3>
Sample rate refers to the frequency at which the audio signal is sampled at the source or for reproduction.
<br>

Audio Processor is capable of simultaneously accepting and processing audio input of different sample rates. Audio Processor supports 2 groups of sample rates :
-# Group 1:	44.1 kHz, 22.05 kHz, 11.025 kHz
-# Group 2:	 8 kHz, 12 kHz, 24 kHz, 32 kHz 48 kHz, 96 kHz, and 192 kHz

  An instance of Audio Processor is capable of accepting, processing, and rendering audio input and output with sample rates of only the same sample- rate group.  For example, Audio Processor allows either all the audio input and output are in 44.1 kHz, or all the audio input and output are in any combination of 12/24/48/96/192 kHz sample rates. In other words Audio Processor does not support cross-group sample rate.
<br>
In the event of multiple audio inputs of various sample rates connecting to an Audio Processor, Audio Processor processes the audio data at the highest sample rate among all the audio inputs if there is sufficient computation resource to do so.  If any one of the input audio streams changes its sample rate at during streaming time that ultimately alters the highest input sample rate, Audio Processor automatically changes its internal audio processing sample rate at the moment it starts processing the audio data of the new highest input sample rate without disrupting the existing audio processing and rendering activities.  When such event of change in the highest input sample rate occurs, Audio Processor notifies the application software when Audio Processor changes it internal processing sample rate.
Audio Processor, however, does not alter the output sample rates at the output points even if Audio Processor changes its internal processing sample rate.  Upon receiving the notification of sample rate changes from Audio Processor, the application software can, if desire, change the output sample rate at any of the output points using Set Output Sample Rate API.
Audio Processor provides high-quality sample rate conversion that is suitable for consumer electronics of tier-1 grade.  The high-quality sample rate converter of Audio Processor and processing the audio data at the highest input sample rate ensure superior audio quality at the output of Audio Processor.



\anchor AudioRateSupp
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4B.3 Supported Sample Rate Conversion</H2>
<table style='border: 1px solid #900'>
<caption>Table 1: Supported Sample Rate Conversions </caption>
<tr>
<th style="color:black;background-color:blue;" ></th> <th style="color:black;background-color:blue;" ></th> <th style="color:black;background-color:blue;" > Output</th><th style="color:black;background-color:blue;" ></th> <th style="color:black;background-color:blue;" ></th>
</tr>
<tr>
<th style="color:black;background-color:blue;" >Input Rates </th>
<th style="color:black;background-color:blue;" >32 KHz </th>
<th style="color:black;background-color:blue;" > 44.1 KHz </th>
<th style="color:black;background-color:blue;" > 48 KHz  </th>
<th style="color:black;background-color:blue;" > 96 KHz  </th>
<th style="color:black;background-color:blue;" > 192 KHz  </th>
</tr>

<tr>
<th style="color:black;background-color:blue;" > 8KHz</th>
<td> Supported</td> <td> Not Supported </td> <td> Supported</td>  <td>  Not Supported</td> <td> Not Supported</td>
</tr>
<tr>
<th style="color:black;background-color:blue;" > 11.025 KHz</th>
<td>  Not Supported</td> <td>  Supported </td> <td> Supported</td>  <td> Supported</td> <td>   Not Supported</td>
</tr>
<tr>
<th style="color:black;background-color:blue;" > 12 KHz</th>
<td>  Not Supported</td> <td>  Not Supported </td> <td> Supported</td>  <td> Supported</td> <td>  Not Supported</td>
</tr>

<tr>
<th style="color:black;background-color:blue;" > 16 KHz</th>
<td>  Supported</td> <td>  Not Supported </td> <td> Supported</td>  <td> Supported</td> <td>  Not Supported</td>
</tr>
<tr>
<th style="color:black;background-color:blue;" > 22.05 KHz</th>
<td>  Not Supported</td> <td>  Supported </td> <td> Supported</td>  <td> Supported</td> <td>  Not Supported</td>
</tr>
<tr>
<th style="color:black;background-color:blue;" > 24 KHz</th>
<td>  Not Supported</td> <td>  Not Supported </td> <td> Supported</td>  <td> Supported</td> <td>   Supported</td>
</tr>
<tr>
<th style="color:black;background-color:blue;" > 32 KHz</th>
<td> Supported</td> <td>  Not Supported </td> <td> Supported</td>  <td> Supported</td> <td>   Supported</td>
</tr>
<tr>
<th style="color:black;background-color:blue;" > 44.1 KHz</th>
<td>  Not Supported</td> <td>  Supported </td> <td> Supported</td>  <td> Supported</td> <td>   Supported</td>
</tr>
<tr>
<th style="color:black;background-color:blue;" > 48 KHz</th>
<td>  Not Supported</td> <td>  Not Supported </td> <td> Supported</td>  <td> Supported</td> <td>   Supported</td>
</tr>

<tr>
<th style="color:black;background-color:blue;" > 96 KHz</th>
<td>  Not Supported</td> <td>  Not Supported </td> <td> Supported</td>  <td> Supported</td> <td>   Supported</td>
</tr>
<tr>
<th style="color:black;background-color:blue;" > 192 KHz</th>
<td>  Not Supported</td> <td>  Not Supported </td> <td> Supported</td>  <td> Supported</td> <td>   Supported</td>
</tr>

</table>


\anchor AudioCap
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4B.4 AudioCapture</h2>
The Intel� CE Media Processor comes equipped with one audio input via I2S.  Customers can use this for applications like karaoke, telephone, or as an audio repeater for physical, inputs into the product.  The audio capture feature can be enabled using the standard audio interfaces.  Audio capture will appear as an input into the audio processor.
Audio capture supports the following the data formats.
-# Sampling Rate: 32/44.1/48 kHz
-# Sample Size: 16/24 bits,
-# Uncompressed: PCM 2, 6 and 8 channels.
-# Compressed format: AC3, DTS

\image html audiocap.png  Fig.2 Overview of Audio Capture

Figure above  depicts the high level view of different components involved in A/V capture from HDMI input.
Silicon image driver detects new audio mode and calls audio mode routing driver notifying it about the mode. Audio mode routing driver generates AVCAP event for a new mode.  AVCAP core notifies registered AVCAP clients (smd avcap shim) about new mode. SMD AVCAP shim analyzes event received from core and triggers corresponding ismd_event_handle_t handle (audio mode change handle in this case). CL_APP wakes up from event sleep. It makes ismd_avcap_shim_get_audio_mode() call to retrieve new mode. It notifies SMD audio capturing driver about new mode.
Audio capture driver configures the DMA such that it captures in small chunks. For PCM capture the chunk size is programmed to 10 ms. For compressed capture the chunk size is programmed based on the frame length of the compressed audio format.
In case of compressed capture the PTS association needs to be done so that the PTS of the captured buffer gets adjusted based on the sync word offset in the captured buffer.

Below are the few steps that needs to be done differently from the normal setup of SMD Audio pipeline for file playback
 	During input add

-# Add the audio physical input by calling ismd_audio_add_phys_input(). Specify the input parameter �timed_stream� to true if timed mode capture is needed.
    Ex. To enable the capture port, call the function below.
result = ismd_audio_add_phys_input(proc_context->proc_h, 0x4D1, false, &input_context->input_h
-# Create AVCAP shim instance by issuing �ismd_avcap_shim_open� call. As an argument to this call application needs to specify, which native capturing driver it will be connected with (in this case it should be ISMD_AVCAP_ID_CE4X00_AUDIO).
-# Register for audio mode change event (ISMD_AVCAP_SHIM_EVENT_AUDIO_MODE_CHANGE) by calling ismd_avcap_shim_get_event_handle()
-# For timed mode capture allocate the ISMD clock (ismd_clock_alloc), make it primary (ismd_clock_make_primary) and set the clock handle to audio (ismd_dev_set_clock).
 	<br>
 	During input start
-# Allocate a new clock recovery instance (clock_sync_open). Associate an allocated clock during input add to the clock recoverer (clock_sync_set_clock).  This is the clock which will be adjusted/recovered by the specified clock recoverer.  Associate a clock recoverer algorithm (PID_FILTERING) to the clock recoverer (clock_sync_set_algorithm).  This is the algorithm which will be used to adjust/recover clock by the specified clock recoverer.
-# If audio capture driver needs to do clock recovery call ismd_audio_set_capture_sync_clock() to set the sync clock to audio capture device.
-# Right before we start the input we need to get the current time (ismd_clock_get_time), add a desired offset and set the base time on the input (ismd_dev_set_stream_base_time).
-# Get the audio mode using ismd_avcap_shim_get_audio_mode(). If the audio mode is valid then, set the data format using ismd_audio_input_set_data_format(), set the PCM format using ismd_audio_input_set_pcm_format() and set the device state to play.


 	Handling audio mode change event
-# Get the audio mode by calling ismd_avcap_shim_get_audio_mode(). If the audio mode is not valid keep waiting for event.
-# If the mode is valid then stop the device using ismd_dev_set_state(), set the data format using ismd_audio_input_set_data_format(), set the PCM format using ismd_audio_input_set_pcm_format() and flush the device using ismd_dev_flush().
-# If this input is a timed input, right before restarting the input we need to get the current time (ismd_clock_get_time) add a desired offset and set the base time on the input (ismd_dev_set_stream_base_time).
-# Set the device state back to play using ismd_dev_set_state().




If timed mode is enabled then audio capture driver reads the audio capture timestamp register, convert it to 90 KHz and use it to time stamp the buffer when DMA is done with it. The clock driving the capture timestamp register is in sync with the renderer clock.





<br>
<br>
<br>
<br>




\anchor AudioOutput
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4C Audio Output</H2>
-# Logical Interface : Audio outputs can be written to the output ports when logical interface is used.  A logical output port is capable of delivering audio output of all the supported
modes and formats.
-# Physical  Interface:  Audio Processor supports 4 types of physical  interfaces  and various sample sizes and sample rates supported as listed below.
<br>
Output interfaces :Any combination of these outputs can be added or removed dynamically. Each output will have its own settings for sample size & rate and output mode.

<table border="1">
<caption>Table 1: Attributes of Output Mode </caption>
<tr>
<th style="color:black;background-color:blue;" >Attribute</th> <th style="color:black;background-color:blue;" >Possible Settings</th>
</tr>
<tr>
<td> Audio Output </td>	<td> I2S0, I2S1, SPDIF, HDMI,Logical Interface </td>
</tr>
<tr>
<td> Sample Size </td>	<td> 16,20,24,32 </td>
</tr>
<tr>
<td> Sample Rate </td>	<td> Group1, Group2 </td>
</tr>
<tr>
<td> Modes </td>	<td> PCM , Pass through, Encoded Dolbym Digital Encoded DTS </td>
</tr>
</table>


<br>
<br>
\anchor AudioOutputMode
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4C.1 Output Mode Attributes</H2>
<br>
<br>
The following table describes the four audio output attributes along with their potential settings.
<table border="1">
<caption>Table 2: Audio Output Attributes Along with their Potential Settings </caption>
<tr>
<td> </td>
<th style="color:black;background-color:blue;" > HDMI</th>
<th style="color:black;background-color:blue;" > SPDIF </th>
<th style="color:black;background-color:blue;" > 2 Ch. I2S </th>
<th style="color:black;background-color:blue;" > Multi Ch. I2S </th>
</tr>
<tr>
<th style="color:black;background-color:blue;" > Sample Rate (LPCM) </th>
<td> 48/96/192 kHz         or 44.1 kHz</td>
<td> 48/96/192 kHz                or 44.1 kHz</td>
<td> 48/96/192 kHz         or 44.1 kHz </td>
<td> 48/96/192 kHz         or 44.1 kHz</td>
</tr>
<tr>
<th style="color:black;background-color:blue;" >Channel Count (LPCM)	</th>
<td>Up to 8 channels (LPCM)	</td>
<td>Up to 2 channels (LPCM)	</td>
<td>Up to 8 channels (LPCM)	</td>
<td>Up to 2 channels (LPCM)</td>
</tr>
<tr>
<th style="color:black;background-color:blue;" > Encoded Audio	</th>
<td>DTS 5.1, 48 kHz      or AC3 5.1, </td>
<td>48kHz	DTS 5.1, 48 kHz      or AC3 5.1, 48kHz	</td>
<td>Not Supported	</td>
<td>Not Supported </td>
</tr>

<tr>

<th style="color:black;background-color:blue;" >Pass-Through	</th>
<td>DTS-HD, DD+, DTS, AC3, and LPCM	</td>
<td>DTS-HD, DD+, DTS, AC3, and LPCM	</td>
<td>Not Supported	</td>
<td>Not Supported </td>
</tr>

</table>

<br>
<br>
<br>

\anchor AudioPass
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4C.2  Pass-Through Mode</H2>
Pass-through mode provides the capability to render the audio of one of the input audio elementary streams (except OS system audio) in its original form
(i.e., with minimal or no modification to the original input audio data).  The application software has the capability to select one of the input audio elementary
streams as the source stream of the pass-through mode.
The application software also can specify a set of encoding types that are allowed in the pass-through stream.  If the encoding type of the input audio data of the
pass-through stream is not one of the allowed encoding types, Audio Processor converts the pass-through stream to LPCM format with the specific channel configuration,
sample rate, and sample size of the pass-through output point.  The application software specifies only 1 set of allowed encoding types for the pass-through mode in an Audio Processor that applies to all the pass-through output points of that Audio Processor.
The pass-through mode also provides the ability to convert DTS-HD audio stream to DTS audio stream and convert Dolby Digital+ (DD+) audio stream to Dolby Digital
(AC3) audio stream for output at one or more pass-through output points.  If the encoding type of the input audio stream selected for pass-through is either
DTS-HD or DD+, and one of the allowed encoding types for pass-through mode is either DTS or AC3 respectively then, instead of converting the input audio data to
LPCM format, Audio Processor automatically converts the input DTS-HD or DD+ audio stream to DTS or AC3 audio stream respectively and passes through the converted
DTS or AC3 audio stream to all pass-through output points.

The packetizer module packetizes the incoming compressed elementary audio streams when the output is configured for pass-through over HDMI/SPDIF output. This output mode requires the streams to be sent out as an isochronous stream. This module packetizes the compressed stream based on ISO/IEC (60958) specification.
The packetizer adds the necessary headers and zero pads the incoming frames to the appropriate length. Data leaving the packetizer cannot be mixed with any other audio stream.
HDMI strongly requires the output sample size to be 32 bits only. However, when it�s packetized its in words of size 16 bits. So, it does some zero padding. Even though SPDIF can work on 16 bit words, 32 bit requirement has been set for both HDMI and SPDIF.
In some cases streams are wrapped up in PCM format. If application needs to send these streams in pass-through mode, no need to packetize and it has to send it in PCM format only. For example DTS CD streams are wrapped in PCM format, if application needs to send DTS CD stream in pass-through mode, middleware needs to detect that stream has wrapped in PCM format and notify audio driver about this. Then audio driver does not packetize this stream and send it in PCM mode only.

The table below shows the encoding types which audio driver supports in pass-through mode.  Although the software output port and physical hardware output interface potentially can support other encoding type in pass-through mode, the audio driver supports only the following set of encoding types in pass-through mode.  Audio Processor supports only LPCM encoding type for I2S hardware output interface.
<table border="1">
<caption>Table 3: Supported   Sample Rate Conversions </caption>
<tr>
<th style="color:black;background-color:blue;" >Codec </th>	<th style="color:black;background-color:blue;" >Input Audio Stream</th>	<th style="color:black;background-color:blue;" >Software Output Port</th>	<th style="color:black;background-color:blue;" >HDMI Hardware Output Interface</th>	<th style="color:black;background-color:blue;" >S/PDIF Hardware Output Interface</th>
</TR>
<tr>
<td> DTS,AC3 </td> <td> Up to 5.1 channels</td>	<td>Same as input</td><td>Same as input</td> <td>Same as input</td>
</tr>
<tr>
<td>MP3, MPEG-1</td>  <td> Up to 2 channels</td> <td> Not Supported</td> <td> Not Supported</td> <td> Not Supported</td>
</tr>
<tr>
<td>MLP</td>  <td> Up to 8 channels</td> <td> Not Supported</td> <td> Not Supported</td> <td> Not Supported</td>
</tr>

<tr>
<td>Mpeg-2</td>  <td> Up to 7 channels</td> <td> Not Supported</td> <td> Not Supported</td> <td> Not Supported</td>
</tr>

<tr>
<td>WMP Pro</td>  <td> Up to 2 channels</td> <td> Not Supported</td> <td> Not Supported</td> <td> Not Supported</td>
</tr>
<tr>
<td>MPEG-4 HE AAC</td>  <td> Up to 2 channels</td> <td> Not Supported</td> <td> Not Supported</td> <td> Not Supported</td>
</tr>
<tr>
<td>DTS-HD </td>	<td>Up to 7.1 channels</td>	<td>Same as input </td>    <td>Same as input or convert to DTS 5.1 </td>       	<td>DTS, up to 5.1 channels or convert to DTS 5.1</td>

</tr>
<tr>
<td>Dolby Digital plus </td>	<td>Up to 7.1 channels</td>	<td>Same as input </td>       	   <td>Same as input or convert to AC3 5.1 </td>       	<td>AC3, up to 5.1 channels or convert to AC3 5.1</td>

</tr>
<tr>
<td> Linear PCM </td> <td> 3-6channels</td>	<td>Same as input</td><td>Same as input</td> <td>Not Supported</td>
</tr>
<tr>
<td> Linear PCM </td> <td> 2 channels</td>	<td>Same as input</td><td>Same as input</td> <td>Not Supported</td>
</tr>
</table>
<br>
<br>
<br>
\anchor AudioOutputMode3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4C.3 Encoded Output Mode</H2>

In addition to linear pulse code modulated (LPCM) audio output, Audio Processor also supports encoded audio output.  The application software also can enable speaker management on the encoded audio output.  However, if the application software enables speaker management on encoded audio output, the speaker management unit must have the same sample rate and channel configuration as the encoding type.  As a result, all output points (with speaker management) of this particular Audio Processor must have the same output sample rate and channel configuration of the encoded audio output point (with speaker management) due to the fact that each Audio Processor can have at most one speaker management unit.
Each Audio Processor supports at most one encoder unit to produce one encoded audio output stream.  The single encoded audio output stream can connect to multiple output points of the Audio Processor.  Consequently, all encoded audio output points of an Audio Processor must have the same encoding type, sample rate, and channel configuration.
  Audio Processor supports the following types of encoded audio output:
-# DTS encoder:	Fixed bBit rRate 1.536 Mbps, 48 kHz, 5.1 channels
-# Dolby Digital encoder:	DDCO Encoder, 640 kbps, 48 kHz, 5.1 channels

<br>
<br>
<br>

\anchor AudioSWComp
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D Software Components of Audio Sub System</H2>
The Audio subsystem  contains various modular software components as shown in Fig.3

-# Audio Processor Manager: Implements public APIs.
-# Input Manager: Processes all inputs to the Audio Subsystem from software (SMD ports) and hardware (audio capture).
-# Pipeline Stage Manager: Manages the flow of data through all of the processing stages within the audio subsystem.
-# Audio Timing Control: Handles timing of audio data, including A/V sync.
-# Audio Renderer: Manages all audio outputs to hardware (e.g. I2S) and software (SMD ports).
-# Audio HAL: Abstracts the silicon-specific features from higher layers of the driver.

\image html Audio2.png  Fig.3 Software Components of Audio Subsystem
\anchor AudioAPM
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D.1 Audio Processor Manager (APM) </H2>
Audio Processor Manager implements public API. When an application starts up, APM functions are called to create and configure the audio subsystem.  These user level calls are translated into the kernel
level APM calls which then build the underlying audio pipeline.  APM ensures that a multi-threaded application can be executed at the user level API correctly.

The APM abstracts configuring and connecting of the necessary stages in the audio pipeline, as the user specifies them. APM interfaces with Input Manager that manages the input sources,
Pipeline Stage Manager that builds/rebuilds appropriate pipes, manages data flow in the audio subsystem, Audio Timing Control that controls the presentation time of the incoming audio data and
the Renderer which passes the processed data to appropriate software/hardware outputs.

For example an application can create a global processor instance and add an input with uncompressed audio data (PCM), and configure the output to be in pass through with certain sample size, sample rate etc. Similarly an application can configure the Audio Processor with properties such as mixing, down mixing, and speaker management that can be enabled and configured. In the event that the user does not enable these features, default settings will be applied.
A simplified overview of the APM capabilities:
-# Control the properties and capabilities of the Audio Processor. (i.e. mixing, speaker management)
-# Control the input and outputs and their corresponding configurations.
-# Abstract the need for the user to allocate and free lower level resources.
-# Provides mechanism for pipeline control and configuration.
-# Tracking and freeing of low level resources as needed based on audio subsystem changes.
-# Make appropriate calls to SMD Core and handle the inherited functions from Core.

<br>
<br>
<br>

\anchor AudioIM
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D.2 Input Manager</H2>
Input Manager manages all the input sources in the Audio sub-system.
-# Allocates and frees SMD ports when software inputs are added or removed.
-# Configures the audio capture device (via the HAL) for hardware inputs.
-# Implements a single thread that monitors all of the inputs and routes data from the inputs to the proper stages within the audio system.


<br>
<br>
<br>


\anchor AudioPSD
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D.3 Pipeline Stage Manager: Decoding Stage</H2>
After the elementary audio stream is extracted by demux, it is then passed to the decoding stage of the Audio Subsystem. This is the stage where the incoming encoded audio data
is decoded and generated as LPCM frames. If the output ports are configured to receive the audio stream as pass through then the elementary streams bypass the decoding stage. APM kernel module
notifies the DSP firmware that it is ready to decode the incoming audio stream by triggering corresponding interrupt.
various advanced decoding algorithms.
***ned a picture
<br>
Key Functionality
-# Manages how data is processed within the audio subsystem.
-# Organizes individual processing stages into pipes within the audio subsystem.
-# Builds pipes and re-builds pipes when necessary.
-# Controls the flow of data in and out of pipes.
-# Controls where each pipe executes (e.g., Host or DSP).
-# Guarantees that all stages in a pipe are processed sequentially and atomically.

<br>
<br>
<br>
<br>
<br>
<br>

\anchor AudioPSD2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D.4  Pipeline Stage Manager: Post Processing Stage</H2>

\anchor AudioPSD2de
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D.3.1 De-Interleaver</H3>
The first stage in the post-processing is to de-interleave the data coming out of the ATC. Audio data is de-interleaved because it is more efficient to apply
post-processing algorithms on the de-interleaved data and improves the performance of the audio post-processing. This stage is not available for configuration
by the user. Fig.4 below shows the working of Deinterleaver.

\image html Audiodeint.png  Fig.4 5.1 Channels to 2-Channel Stereo Compatible Downmix
<br>
<br>
<br>


\anchor AudiodPSD2src
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D.3.2 Sample Rate Converter</H3>
Audio Processor provides high-quality sample rate conversion that is suitable for consumer electronics of tier-1 grade.  The high-quality sample rate converter of Audio Processor and processing the audio data at the highest input sample rate ensure superior audio quality at the output of Audio Processor.
Audio Processor is capable of simultaneously accepting and processing audio input of different sample rates.  It is also capable of rendering audio output of different sample rates concurrently.  However, Audio Processor does not support all possible combinations of input and output sample rates, one particular example is Audio Processor does not support cross-group sample rate support.
Audio Processor supports 2 groups of sample rates, 44.1 kHz group and 12/24/48/96/192 kHz group.  An instance of Audio Processor is capable of accepting, processing, and rendering audio input and output with sample rates of only the same sample- rate group.  For example, Audio Processor allows either all the audio input and output are in 44.1 kHz, or all the audio input and output are in any combination of 12/24/48/96/192 kHz sample rates

In the event of multiple audio inputs of various sample rates connecting to an Audio Processor, Audio Processor processes the audio data at the highest sample rate among all the audio inputs if there is sufficient computation resource to do so.  If any one of the input audio streams changes its sample rate at during streaming time that ultimately alters the highest input sample rate, Audio Processor automatically changes its internal audio processing sample rate at the moment it starts processing the audio data of the new highest input sample rate without disrupting the existing audio processing and rendering activities.  When such event of change in the highest input sample rate occurs, Audio Processor notifies the application software when Audio Processor changes it internal processing sample rate.
Audio Processor, however, does not alter the output sample rates at the output points even if Audio Processor changes its internal processing sample rate.  Upon receiving the notification of sample rate changes from Audio Processor, the application software can, if desire, change the output sample rate at any of the output points using Set Output Sample Rate API.
<br>
<br>
<br>


\anchor AudioPSD2mix
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4D.3.3 Mixing</H3>
When there are multiple input points associate with an instance of Audio Processor, Audio Processor mixes all the input audio streams (including OS system audio)
into a single mixed output stream (for one or more synchronized output points).  Audio Processor offers a true n-to-m mixing feature.  The application can specify
how to mix a lower- channel- count audio stream into a higher- channel- count audio stream by specifying the mixer gain levels.  The audio signal in every channel
can mix into any or multiple channels (up to all channels) of another audio stream.  Using the default settings the output mixed audio stream has the same channel count as the highest channel
count of the input audio streams.  However, other settings are permitted such as output channel to follow the channle count in primary stream.
<br>
<br>
<br>


\anchor AudioPSD2dmix
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4D.3.4 Down Mixing</H3>
Audio Processor supports various number of channel counts at the output point i.e is  7.1 channels, 5.1 channels, 2-channel stereo, and dual-mono.  If the application
software specifies an output channel configuration that has more channels thatn the highest channel count of the input streams, Audio Processor simply outputs
silence at the additional output channels.  For example, if the highest input channel count is 6 channels (i.e., 5.1 channels, L/C/R/Ls/Rs/LEF) and the
application configure the output channel configuration to be 7.1 channels (i.e., L/C/R/Ls/Rs/Lr/Rr/LEF), Audio Processor simply produces silence in the Lr and Rr
channels at the output point of 7.1 channels.

On the other hand, if the application software specifies an output channel configuration that has lower fewer number of channels than the highest input channel
count, Audio Processor downmixes the output audio stream to the specified lower channel count at the output point.  Audio Processor provides 3 levels of downmixing
(i.e., 7.1-to-5.1, 5.1-to-stereo, and stereo-to-dual-mono) to support 4 different channel configurations at the output point (i.e., 7.1 channels, 5.1 channels,
2-channel stereo, and dual-mono). Fig.5 shows an example of 5.1 Channels to 2-Channel Stereo Compatible Downmix

<br>
<br>
<br>

\image html Audio4.png  Fig.5 5.1 Channels to 2-Channel Stereo Compatible Downmix
\anchor AudioPSD2water
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D.3.5 Water Mark Detector</H3>
Watermarking is an analog video copy protection mechanism.  Watermark detector exists after the mixer stage in the audio pipeline. Watermark detection happens
only on the PCM data. Once the Watermark detection is enabled by the application, the detector starts looking for the watermark in the audio stream.
Watermark detector does not manipulate the incoming audio buffer in any way. Watermark detection happens in the same thread as the rest of the pipeline stages. In the case, where the primary is configured for pass through and the watermark is present in the primary audio stream, this stream is decoded to extract the watermark information, though the encoded stream is sent to the output port as passthru. When the watermark is detected in the stream, the detector invokes the application callback.
Watermark detection requires license from Verance.

<br>
<br>
<br>


\anchor AudioPSD2delay
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D.3.6  Manager</H3>
This stage is created in the post-processing pipe. The application software has the capability to introduce additional delay (in unit of millisecond) to the output audio stream at each of the audio output points.  The additional audio output delay for each of the audio output points is independent of another audio output point, and so, the application software could specify different audio output delay for each audio output point.  This output delay applies to the whole output stream at the specific output point.
Range of delay:	0 milliseconds through 255 milliseconds (1-millisecond step)

By default, per out delay is set to 0 but this default value is configurable in
the Platform Configuration file and a user level api is provided to configure this delay. One could also set the per output channel delay.
<br>
<br>
<br>
<br>
<br>
<br>


\anchor AudioTime
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D.3.6 Audio Timing Control</H2>
The main goal of ATC is to control the timing of the incoming audio packets. There is a single instance of ATC in the system and it currently runs on the IA processor and not on the DSP.  During the Audio Timing Control stage the audio data coming into ATC from the decoder is quantized into packets for fixed amount of time (10 ms). Untimed streams, decoded and encoded streams pass through ATC before going through the post processing stages. ATC uses the PTS values from the incoming packets, interpolates and assigns PTS to each audio frame. ATC then pushes these audio frames to the downstream pipe, guaranteeing a fixed end-to-end delay (70 ms) between the time it received the data and the time the data is rendered. If no data is present at the time an audio packet needs to be released into the downstream pipe, ATC inserts silence.
<br>
<br>
<br>


\anchor AudioTimeQuant
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4D3.7 Quantization</H3>
Audio buffers coming into the ATC carry metadata in the buffer descriptors that ATC uses to quantize the audio samples to be released to the downstream pipeline.  An Alarm clock associated with the ATC device is used to wake up ATC thread once every 10 ms to releases 10 ms worth of samples. The reason for using 10 ms is because the current renderer takes 10 ms to release the data to the port drivers

The following example shows how ATC calculates the number of samples it needs to release every 10 ms.
Chunk size in millisecs = (sample_rate*sample_size_bytes*channel_count*chunk_period)/1000.

Input stream 1:
-# Metadata: 48KHZ sample rate stream with sample size =24 bits and number of channels = 6
	-# Number of samples for 1 msec = 48000 samples/sec = 48 samples/msec.
	-# Number of channels in the stream = 6; sample size = 24 bit (3 bytes)
	-# Number of of samples/msec = 48*6*3 = 864 samples/msec

Input stream 2:
	-# Metadata: 96KHZ sample rate stream with sample size =32 bits and number of channels =8
	-# Number of samples for 1 msec = 96000 samples/sec = 96 samples/msec.
	-# Number of channels in the stream = 8; sample size = 32 bit (4 bytes)
	-# Number of  samples/msec = 96*8*4 = 3072 samples/msec

\anchor AudioRend
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Audio Renderer </H2>

Description:
-# Passes data from the audio subsystem to software or hardware outputs.
-# Maintains proper output buffering levels.
-# Triggers audio events for conditions such as buffer-underrun or end-of-stream.
How it works:
-# Move�s buffers from internal queues to the outputs.  Outputs may be either software (e.g., an SMD port), or hardware (e.g. a TX Channel DMA).
-# Relies on the Audio HAL to control the hardware output devices.
-# Thread-less.  All execution is done within the context of threads that call into the renderer.  All data flow is handled via callbacks from the internal queues or from the HAL.


\anchor AudioExamples
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4E Sample Codes/Algorithms</h2>

\anchor AudioEx1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4E.1 Example.1 :General Audio Subsystem Setup Sequence Diagram </H2>
The most common initialization sequence is opening an audio processor instance, adding an input, adding an output and setting the stream to play (render audio). In the process of setting up the audio unit there are interactions that happen between SMD core SVEN and OSAL. The following sequence diagram illustrates, at a high level, the sequence that is taken to do so.

\image html Audio6.png  Fig.6 General Audio Subsystem Setup Sequence Diagram
\code
/*Handles*/
ismd_audio_processor_t  proc_h;
ismd_audio_output_t output_h;
ismd_dev_t input_h;

/*input/output configuration structs*/
ismd_audio_output_config_t out_config;
ismd_audio_input_config_t  in_config;

/*Port handle */
ismd_port_handle_t   in_port;

/*Setup input port config.*/
in_config.fmt = ISMD_AUDIO_MEDIA_FMT_MPEG;
in_config.sample_size = 16;
in_config.timed_stream = false;

/*Setup output config.*/
out_config.bit_width = 32;
out_config.ch_config = AUDIO_CHAN_LOC_LEFT | AUDIO_CHAN_LOC_RIGHT;
out_config.sample_rate = 48000;
out_config.out_mode = ISMD_AUDIO_OUTPUT_PCM;

int main(int argc, char *argv[])
{
   if(ismd_audio_open_processor(&proc_h) != ISMD_SUCCESS)
   {
      printf(Could not open processor!!\n);
      return -1;
   }
   if(ismd_audio_add_input_port(proc_h, in_config, &input_h,      &in_port) != ISMD_SUCCESS)
   {
      printf(Could not add input port!\n);
      return -1;
   }

	if(ismd_audio_add_phys_output(proc_h, out_config, GEN3_HW_OUTPUT_I2S0, &output_h) != ISMD_SUCCESS)
   {
      printf(Could not add output!\n);
      return -1;
   }

   if(ismd_dev_set_state(input_h, ISMD_DEV_STATE_PLAY) != ISMD_SUCCESS)
   {
      printf(Could set state!\n);
      return -1;
   }

   /*Loop here feeding the input port with audio ES file. */

   if(ismd_dev_set_state(input_h, ISMD_DEV_STATE_STOP) != ISMD_SUCCESS)
   {
      printf(Could set state!\n);
      return -1;
   }

   if(ismd_audio_close_processor(&proc_h) != ISMD_SUCCESS)
   {
      printf(Could not close processor!!\n);
      return -1;
   }
}
\endcode




\anchor AudioEx2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4E.2 Example2: Basic Play Back</h2>
The SMD Audio sub-system is capable of supporting several different usage models.  A common use case of Basic Play back is illustrated in the Fig.above and discussed here.

The audio processor can handle up to 12 simultaneous inputs with 2 of them being encoded streams.  The remaining inputs are PCM and limited to a total of 8 channels of PCM data.
Pseudocode for basic play back
<em> Step.1 Open an audio Processor</em>
An application opens the audio processor using the function below.

\code
ismd_result_t ismd_audio_open_processor(ismd_audio_processor_t *processor_h);
\endcode

An instance of a global processor can be created using the following function below.
\code
ismd_result_t ismd_audio_open_global_processor(ismd_audio_processor_t *global_processor_h);
\endcode
<br>
<br>

<em>Step.2 Add input port</em>

If the global processor is already created, the handle to the already created global processor is returned. There exists only one global processor that can be accessed from multiple independent applications.
Applications can add a logical input to an audio processor by using the function below.

\code
ismd_result_t ismd_audio_add_input_port(ismd_audio_processor_t processor_h,
                              bool timed_stream,
                              ismd_dev_t *input_h,
                              ismd_port_handle_t *port_h);
 \endcode

 The above function will fill in the device handle input_h and the input port handle for the application to write into port_h.  The timed_stream parameter is used to denote if time stamps should be used on this input.  If presentation time stamps are used, data will be held at the renderer until the time denoted in the time stamp.  Data will be discarded until the first time stamp is sent.
Once the input has been obtained, it must be configured.
<br>
<br>

 <em>Step.3 Set audio format data for the input and enable the input port</em>

To set the format of the input data the function below is provided.
\code
ismd_result_t ismd_audio_input_set_data_format(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_format_t format);
  \endcode

<em>Note1:  Additional configuration is necessary for some codecs.</em>
	For PCM inputs which have no headers, the following function is used to provide the stream information.
\code
ismd_result_t ismd_audio_input_set_pcm_format(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              int sample_size,
                              int sample_rate,
                              int channel_config);
  \endcode

<em>Note2: Other codecs, like WMA, have additional, required dependencies on external information not found in the header to enable decode.  This function is used for WMA configuration.</em>
\code
ismd_result_t ismd_audio_input_set_wma_format(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_wma_format_t wma_stream_format);
 \endcode

Other optional functions exist and may be required for other use cases.


Finally, the input can be enabled using the function below.
	\code
ismd_result_t SMDEXPORT ismd_audio_input_enable(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h);
     \endcode

If this stream is meant to operate as the primary stream, it can be made primary with the function below.

\code
ismd_result_t ismd_audio_input_set_as_primary(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_input_pass_through_config_t pass_through_config );
  \endcode

The primary input will be the stream sent to outputs configured for pass-through mode and will also be given the highest priority for minimizing noise. For example, if the mixing mode is set to primary using the following API. By default, the mixing mode is set to AUTO but the following API can be used to set the mixer to operate in different modes.

\code
ismd_result_t ismd_audio_set_mixing_channel_config(ismd_audio_processor_t processor_h,
                                                   ismd_audio_mix_ch_cfg_mode_t ch_cfg_mode,
                                                   int ch_cfg);
 \endcode

Since each input to an audio processor may carry an independent stream, each timed input is a separate SMD core device and has an independent playback state, such as stopped, playing, etc. and contains independent timing information. For example, clocks, stream base time, etc.

	-# Physical inputs should be added using the function below.
\code
ismd_result_t ismd_audio_add_phys_input(ismd_audio_processor_t processor_h,
                              int hw_id,
                              bool timed_stream,
                              ismd_dev_t *input_h);
  \endcode


Step4. Add output
The function below is used to add physical outputs to an audio processor.

\code

ismd_result_t ismd_audio_add_phys_output(ismd_audio_processor_t processor_h,
                              int hw_id,
                              ismd_audio_output_config_t config,
                              ismd_audio_output_t *output_h);

\endcode

Step5:  configure output
For output configuration,  there are sepearte API's to set channel config, sample rate, output mode, configure enable the output port.

Step6. Set the audio input to pause state.

Step7. Set timing information on the audio inputs
Step8.  Register for notification events
Step.9. Set the audio input to play state
Step10.  Wait for the events; handle the events
Step.11.  Close audio processor ;





\anchor AudioEx3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4E.3  Example.3 :Pass Through Mode Settings </H2>

For Pass Through mode settings  two API are used one to set the input to pass through mode and the other to set the output pass throught mode.

\code
ismd_audio_input_set_passthrough_mode
ismd_audio_output_set_passthrough_mode
\endcode

\anchor AudioEx4
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4E.4 Example 4 : Mixing and Volume Control </H2>

The audio processor contains the ability to support complex mixing and volume requirements designed to handle the worst cases Blu-ray can throw at it.  This results in rich API support for both audio mixing and precise volume control.
Volume is controlled on a per-audio processor, and per channel, basis.  The small piece of code below shows how to adjust the output volume of an audio processor configured for stereo output.
\code
{
  ismd_audio_per_channel_volume_t volume_struct;
  //memset will make sure unused channels are set to 0 which is legal input
  memset(&volume_struct, MIN_VOLUME, sizeof(ismd_audio_per_channel_volume_t));
#define MAX_VOLUME 18
#define FULL_SCALE 0
#define MIN_VOLUME -145
  volume_struct.front_left = FULL_SCALE;
  volume_struct.front_right = FULL_SCALE;
  ismd_ret = ismd_audio_set_per_channel_volume(audio_processor, volume_struct);
  if (ismd_ret) {
   printf("ismd_audio_set_master_volume failed\n");
   assert(0);
  }
}
\endcode

Mixing is also controlled on a per channel basis.  Mixing controls are based on input channel through, versus output channel, on the volume control functions.  To control the mixer please use the function below.

\code
ismd_result_t ismd_audio_input_set_channel_mix(ismd_audio_processor_t processor_h,
                              ismd_dev_t input_h,
                              ismd_audio_channel_mix_config_t ch_mix_config);
Caution should be taken when filling in the ismd_audio_channel_mix_config_t structure.  Unused channels should be filled with silence to ensure that valid configuration is set.  The code below could be used to mix one stereo stream at full scale, with another being mixed in with lower level.
ismd_result_t
set_mixing_matrix_mp3(void) {
   ismd_audio_channel_mix_config_t ch_mix_config;
   unsigned int input_ch;
   unsigned int output_ch;

  for(input_ch = 0; input_ch < AUDIO_MAX_INPUT_CHANNELS; input_ch++) {

	 ch_mix_config.input_channels_map[input_ch].input_channel_id = input_ch;

	 for(output_ch = 0; output_ch < AUDIO_MAX_OUTPUT_CHANNELS; output_ch++) {
        ch_mix_config.input_channels_map[input_ch].output_channels_gain[output_ch] = -1450;
	 }
  }

   ch_mix_config.input_channels_map[0].output_channels_gain[0] = 0;
   ch_mix_config.input_channels_map[2].output_channels_gain[2] = 0;

   return ismd_audio_input_set_channel_mix(audio_processor, audio_dev_handle_mp3, ch_mix_config);
}


ismd_result_t
set_mixing_matrix_pcm(void) {
   ismd_audio_channel_mix_config_t ch_mix_config;
	unsigned int input_ch;
	unsigned int output_ch;

   for(input_ch = 0; input_ch < AUDIO_MAX_INPUT_CHANNELS; input_ch++) {

	  ch_mix_config.input_channels_map[input_ch].input_channel_id = input_ch;

	  for(output_ch = 0; output_ch < AUDIO_MAX_OUTPUT_CHANNELS; output_ch++) {
		 ch_mix_config.input_channels_map[input_ch].output_channels_gain[output_ch] = -1450;
	  }
   }

	ch_mix_config.input_channels_map[0].output_channels_gain[0] = -150;
	ch_mix_config.input_channels_map[2].output_channels_gain[2] = -150;


   return ismd_audio_input_set_channel_mix(audio_processor, audio_dev_handle_pcm, ch_mix_config);
}

\endcode


\anchor AudioEX4

<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4E.5  Example 5 : Configure S/PDIF output for AC3 </h2>

The S/PDIF and HDMI outputs can be modified to re-encode the mixed output of all of the inputs.  A small piece of code to illustrate how to configure the S/PDIF output for AC3 output is provided below. Please refer to the audio_player or audio_setup_outputs sample application available in the smd_sample_apps component of the Intel CE Media Processor SDK.

   \code
   output_config.ch_config = ISMD_AUDIO_STEREO;
   output_config.out_mode = ISMD_AUDIO_OUTPUT_ENCODED_DOLBY_DIGITAL;
   output_config.sample_rate = 48000;
   output_config.sample_size = 16;
   output_config.stream_delay = 0;

   ismd_ret = ismd_audio_add_phys_output(audio_processor, GEN3_HW_OUTPUT_SPDIF, output_config, &audio_output_port_handle);
   if (ismd_ret) {
      printf("ismd_audio_add_phys_output failed\n");
      assert(0);
   }

   ismd_ret = ismd_audio_output_enable(audio_processor, audio_output_handle);
   if (ismd_ret) {
      printf("ismd_audio_output_enable failed\n");
      assert(0);
   }


\endcode




\anchor AudioInputco3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4F Capabilities Supported Codecs </h2>
The following sections describe the capabilities of various codecs.
<br>
<br>
<br>
\anchor AudioMpegCodecs
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4F.1 MPEG Audio Codecs</h2>
The SMD Audio sub-system comes equipped with several of the most popular MPEG audio codecs.  The capabilities of the MPEG codecs can be found in the table below.



<table border="1">
<caption>Table 4: MPEG Codec Capabilities </caption>
<tr>
<th style="color:black;background-color:blue;" >Codecs</th> <th style="color:black;background-color:blue;" >Sample Rates</th> <th style="color:black;background-color:blue;" >Output Sample Size</th> <th style="color:black;background-color:blue;" >Headers,Objects Supported</th>
</tr>
<tr>
<td> MPEG1 layerI, II, III </td>	<td>32, 44.1, 48	</td> <td>16/24	</td> <td>ALL</td>
</tr>
<tr>
<td> MPEG2 layerI, II, III </td>	<td>16,22.05,24,32, 44.1, 48	</td> <td>16/24	</td> <td>ALL</td>
</tr>
<tr>
<td> MPEG2.5 layerIII </td>	<td>8,11.025,12,16,22.05,24,32, 44.1, 48	</td> <td>16/24	</td> <td>ALL</td>
</tr>
<tr>
<td> MPEG2 AAC, LC, HE v1 </td>	<td> upto 96KHz	</td> <td>16/24	</td> <td>Raw, ADTS, LATM/LOAS,ADIF</td>
</tr>
<tr>
<td> MPEG2 AAC, LC, HE v1 and v2 </td>	<td> upto 96KHz	</td> <td>16/24	</td> <td>Raw, ADTS, LATM/LOAS,ADIF</td>
</tr>
</table>

Currently, only AAC pass-through is supported on either S/PDIF or HDMI out of all the MPEG algorithms.  Similar to the other algorithms, the mixer data after decode and mixing with other streams can be sent out S/PDIF or HDMI encoded in either the Dolby Digital or DTS format.  This feature can be used to effectively transcode from MPEG to AC3 or DTS assuming no other streams are being fed into the audio processor, which would get mixed.  A visual diagram of the options available to the application programmer when using MPEG input audio stream can be seen in Fig.7 below.
\image html Mpeg.png  Fig.7 Output Options Available When using the MPEG Audio Input Stream

<br>
<br>
<br>
<br>

\anchor Audio AACCodecs
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4F.2 AAC Audio Codecs</h2>
<table border="1">
<caption>Table 5: AAC Codec Capabilities </caption>
<tr>
<th style="color:black;background-color:blue;" >Codecs</th> <th style="color:black;background-color:blue;" >Sample Rates</th> <th style="color:black;background-color:blue;" >Output Sample Size</th> <th style="color:black;background-color:blue;" >Headers,Objects Supported</th>
</tr>
<tr>
<td> MPEG2 AAC, LC, HE v1 </td>	<td> upto 96KHz	</td> <td>16/24	</td> <td>Raw, ADTS, LATM/LOAS,ADIF</td>
</tr>
<tr>
<td> MPEG2 AAC, LC, HE v1 and v2 </td>	<td> upto 96KHz	</td> <td>16/24	</td> <td>Raw, ADTS, LATM/LOAS,ADIF</td>
</tr>
</table>

\anchor AudioDolbyCodecs
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4F.3 Dolby Digital Codecs</h2>
The SMD Audio sub-system supports decoding of Dolby Digital (AC3) streams.  The Intel CE Media Processor has been certified by Dolby for Dolby Digital at the silicon level. Customers will be required to certify at the platform level. All of the hooks needed for the application have been provided to simplify this process.  The capabilities of the Dolby Digital codec can be found in the table below. Also, AC3 supports mono, stereo and up to 5.1 channels.


<table border="1">
<caption>Table 6: Dolby Digital Codec Capabilities </caption>
<tr>
<th style="color:black;background-color:blue;" >Codecs</th> <th style="color:black;background-color:blue;" >Sample Rates</th> <th style="color:black;background-color:blue;" > Bit Rates</th><th style="color:black;background-color:blue;" >Output Sample Size</th> <th style="color:black;background-color:blue;" >Headers,Objects Supported</th>
</tr>
<tr>
<td> Dolby Digital </td>	<td>32, 44.1, 48 KHz <td> 32-640 kbps	</td> <td>16/24	</td> <td>None</td>
</tr>
</table>

The audio processor usage models available increase with Dolby Digital.  In addition to all of the cases provided for with the MPEG codecs, some additional pass-through cases are available.  Direct pass-through of the AC3 streams is supported on both the S/PDIF and HDMI outputs. This will allow the application to have an external audio receiver decode and render the stream in its original form.  The options available to the application programmer for Dolby Digital streams are  shown in the Fig.8 below
\image html DolbyDigital.png  Fig.8 Output Options Available When Using the Dolby Digital Codec
 Note:  raw DD stream cannot be directly rendered to HDMI/SPDIF. It should be packetized as IEC61937.
<br>
<br>

\anchor AudioDolbyComp
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4F.4 Dolby Digital Compatible Output</h2>

The SMD Audio sub-system supports encoding to AC3 streams.  The Intel� CE Media Processor has been certified by Dolby for DDCO at the silicon level.  Customers will be required to certify at the platform level and all of the hooks needed for the application to certify at the platform level are available.
DDCO is an implementation of Dolby Digital AC-3 Encoder that supports following features:
<br>
<table border="1">
<caption>Table 7: Dolby Digital Compatible Output Capabilities Capabilities (DDCO) </caption>
<tr>
<th style="color:black;background-color:blue;" >Codecs</th> <th style="color:black;background-color:blue;" >Sample Rates</th> <th style="color:black;background-color:blue;" > Bit Rates</th><th style="color:black;background-color:blue;" >Input Sample Size</th> <th style="color:black;background-color:blue;" >Headers,Objects Supported</th>
</tr>
<tr>
<td> DDCO </td>	<td> 48 KHz <td> 640 kbps	</td> <td>16/24	</td> <td>3/2(L,C,R,Ls, Rs)</td>
</tr>
</table>

DDCO implementation supports 5.1-channel audio inputs with the capability to do arbitrary routing of input channels. The other capabilities implemented are as follows:
	-# Ability to enable/disable dynamic range compression
	-# Ability to switch LFE channel on and off
	-#Ability to switch LPF on and off for the LFE channel
	-# Ability to enable white-box testing mode for Dolby certification.
Audio processor can be programmed to route the output of DDCO to HDMI or S/PDIF as well as deliver original PCM through I2S.

<br>
<br>



Use of this codec requires licensing from Dolby and is hence not found in the basic download package.  Please see your Intel representative for the install packet for adding DDCO to the IntelCE SDK. Please refer to audio_player for more details.

<br>
<br>
<br>
<br>

\anchor AudioDolbyPlus
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4F.5 Dolby Digital Plus Codec</h2>

The SMD Audio sub-system supports decoding of the Dolby Digital Plus streams.  The Intel� CE Media Processor has been certified by Dolby for Dolby Digital Plus at the silicon level.    Customer will still be required to certify at the platform level, but all of the hooks needed for the application have been provided to simplify this process.  The capabilities of the Dolby Digital Plus codec can be found in the table below. Also, DDPlus decoder supports mono, stereo and up to 7.1 channels.

<table border=1">
<caption>Table 8: Dolby Digital Plus Codec  Capabilities (DDCO) </caption>
<tr>
<th style="color:black;background-color:blue;" >Codecs</th> <th style="color:black;background-color:blue;" >Sample Rates</th> <th style="color:black;background-color:blue;" > Bit Rates</th><th style="color:black;background-color:blue;" >Output Sample Size</th> <th style="color:black;background-color:blue;" >Headers,Objects Supported</th>
</tr>
<tr>
<td> DD+ </td>	<td> 32,44.1,48 KHz <td> 32-6144 kbps	</td> <td>16/24	</td> <td>ALL</td>
</tr>
</table>

The audio processor usage models are more complex with the high definition audio codecs.   Direct pass-through of the DD+ streams is supported on  HDMI output to HDMI receiver via HDMI 1.3a compliant interface.  Analog outputs should be muted in the case of pass-through if the customer does not have the licenses necessary to obtain the decoder for DD+.  The options available to the application programmer for Dolby Digital streams are illustrated in the Fig.9  below
\image html DDPlus.png  Fig.9 Output Options Available When using the DD+ Input Stream

<br>
<br>
<br>
<br>

\anchor AudioDolbyTrue
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4F.6 Dolby Digital TrueHD</h2>


The SMD Audio sub-system supports decoding of the Dolby TrueHD streams.  The Intel� CE Media Processor has been certified by Dolby for Dolby Digital Plus at the silicon level.    Dolby TrueHD is an extension of the Meridian Lossless Packing (MLP) algorithm and the Intel� CE Media Processor has been certified by Dolby for True-HD at the silicon level.  Customers will still be required to certify at the platform level, but all of the hooks needed for the application have been provided to simplify this process.  The capabilities of the Dolby TrueHD codec can be found in the table below.
<br>
<table border=1">
<caption>Table 9: Dolby Digital TrueHD  Capabilities (DDCO) </caption>
<tr>
<th style="color:black;background-color:blue;" >Codecs</th> <th style="color:black;background-color:blue;" >Sample Rates</th> <th style="color:black;background-color:blue;" > Bit Rates</th><th style="color:black;background-color:blue;" >Output Sample Size</th> <th style="color:black;background-color:blue;" >Headers,Objects Supported</th>
</tr>
<tr>
<td> True HD </td>	<td> upto 192 KHz <td> Upto 18 Mbps	</td> <td>16/24	</td> <td>ALL</td>
</tr>
</table>
<br>
<br>
The SMD audio sub-system supports pass-through of the Dolby TrueHD stream to HDMI.  This capability is referred to as MAT (Metadata-Enhanced Audio Transmission).  While the audio processor is configured for HDMI pass-through the current software restricts the S/PDIF output to PCM only.  Analog outputs should be muted in the case of pass-through if the user does not have the licenses necessary to obtain the decoder for Dolby TrueHD.
Use of this codec requires licensing from Dolby and is not found in the basic download package.  Please see your Intel representative for the install packet for adding Dolby TrueHD to the Intel� CE Media Processor SDK.

\image html DolbyTrue.png  Fig.10 Output Options Available When using the True HD Input Stream

\anchor AudioDTSSurround
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4F.7 DTS 5.1 Digital Surround Codec (DTS Core) </h2>

The SMD Audio sub-system supports decoding of the DTS audio streams.  The Intel� CE Media Processor has been certified by DTS at the silicon level.  Customers will be required to certify at the platform level, and all of the hooks needed for the application have been provided to simplify this process.  The capabilities of the DTS codec can be found in the table below.
<table border=1">
<caption>Table 6: DTS 5.1 Digital Surround Codec  Capabilities (DDCO) </caption>
<tr>
<th style="color:black;background-color:blue;" >Codecs</th> <th style="color:black;background-color:blue;" >Sample Rates</th> <th style="color:black;background-color:blue;" > Bit Rates</th><th style="color:black;background-color:blue;" >Output Sample Size</th> <th style="color:black;background-color:blue;" >Headers,Objects Supported</th>
</tr>
<tr>
<td> DTS 5.1 </td>	<td> upto 48 KHz <td> Upto 1.536 Mbps	</td> <td>16/24	</td> <td>ALL</td>
</tr>
</table>


The audio processor usage models for DTS are very similar to Dolby Digital.  In addition to all of the cases provided for with the MPEG codecs, some additional pass-through cases are available when handling DTS stream.  Pass-through of the DTS stream is supported over the S/PDIF and HDMI outputs.  This will allow the user to have external audio receiver decode and render the stream in its original form.  The options available to the application programmer for DTS streams are illustrated in the Fig. below

\image html DTS.png  Fig.11 Output Options Available When using the DTS 5.1(Core) Input Stream

Use of this codec requires licensing from DTS and is not found in the basic package of the SDK.  Please see your Intel representative for the install packet for adding DTS decoder to the Intel� CE Media Processor SDK.


\anchor AudioDTSLBR
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4F.8 DTS LBR (Low Bit Rate) </h2>


The SMD Audio sub-system supports decoding of the DTS-Low Bit Rate audio streams.  DTS LBR is a high-efficiency low-bit-rate (hence �LBR� name) codec designed primarily for use on the secondary audio pipeline of Blu-ray devices.  It is capable of decoding 5.1 channels of audio data at up to 48 kHz sample rates.  It also carries within its stream headers the metadata coefficients for mixing of primary and secondary audio in the mixer.
The Intel� CE Media Processor has been certified by DTS at the silicon level for DTS-LBR.  Customers will be required to certify at the platform level, and all of
the hooks needed for the application have been provided to simplify this process.  The capabilities of the DTS-LBR codec can be found in the table below.

<table border=1">
<caption>Table 10: DTS 5.1 Digital Surround Codec  Capabilities (DDCO) </caption>
<tr>
<th style="color:black;background-color:blue;" >Codecs</th> <th style="color:black;background-color:blue;" >Sample Rates</th> <th style="color:black;background-color:blue;" > Bit Rates</th><th style="color:black;background-color:blue;" >Output Sample Size</th> <th style="color:black;background-color:blue;" >Headers,Objects Supported</th>
</tr>
<tr>
<td> DTS-LBR </td>	<td>  48 KHz <td> 48-256 kbps	</td> <td>16/24	</td> <td>ALL</td>
</tr>
</table>

 Use of this codec requires licensing from DTS and is not found in the core download package of the SDK.  Please see your Intel representative for the install packet for adding DTS transcoder codec to the Intel� CE Media Processor SDK.

<br>
<br>

\anchor AudioDTSTrans
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4F.9 DTS Transcoder </h2>

The DTS transcoder is a fixed output DTS encoder.  This codec will accept up to 6 channels of raw PCM data at 48 kHz and encode into a 1536 kbps output stream.  The DTS transcoder output can be configured for the HDMI and S/PDIF outputs.  The application can configure the HDMI and/or S/PDIF outputs to render DTS transcoded stream.  Application can also configure output to HDMI and S/PDIF to render the DTS transcoded stream renders the decoded DTS stream to other outputs concurrently.
Use of this codec requires licensing from DTS and is not found in the core download package of the SDK.  Please see your Intel representative for the install packet for adding DTS LBR  codec to the Intel� CE Media Processor SDK.


<br>
<br>
\anchor AudioDTSHD
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4F.10 DTS-HD MA/HRA </h2>

The DTS-HD Master Audio (MA) codec performs the same function as the other audio codecs (DD, DD+, TrueHD, DTS 5.1 Core) already existing in the SMD audio firmware
namely, decoding the primary audio track from the disc to 24-bit LPCM.  Unique to the DTS-HD codec is the ability to decode the latest DTS-HD Master Audio and Hi-Resolution Audio streams while maintaining backwards compatibility for streams encoded with DTS legacy formats (DTS 5.1, DTS-ES/Neo:6, DTS 96/24, etc.).
The Intel CE Media Processor has been certified by DTS at the silicon level for DTS-MA and customers will be required to certify at the system level, and all of the hooks needed for the application have been provided to simplify this process. There is a separate SKU available for DTS MA which consists of the DTS MA decoder and the Neo6 standalone decoder

The DTS MA codec also includes various embedded post processing functions that are required by DTS for proper pipeline operation. The various post processing modes included are:
-# Dialog Normalization (Dialnorm) :  Provides a method to normalize the playback level between different presentations so that one is not louder than the other.
-# Dynamic Range Control (DRC) :  Compresses the amplitude range of the decoded output signals in order to minimize difference between loud and soft passages in a presentation.
-# Downmixing :  Reduces the number of decoded output channels to match the channel configuration of the system mixer (or of a particular output interface if the mixer is bypassed).
-# Speaker Remapping :  Re-configures the decoded output channels to match the speaker configuration of the end user (similar to downmixing but without reducing the number of channels)
-# DTS Neo6 Matrix :  Extracts discrete 3rd surround channel from specially encoded left/right surround channels, effectively producing a 6.1 channel presentation.
 DTS-HD could be pass through via HDMI.
<table border=1">
<caption>Table 11: DTS 5.1 Digital Surround Codec  Capabilities (DDCO) </caption>
<tr>
<th style="color:black;background-color:blue;" >Codecs</th> <th style="color:black;background-color:blue;" >Sample Rates</th> <th style="color:black;background-color:blue;" > Bit Rates</th><th style="color:black;background-color:blue;" >Output Sample Size</th> <th style="color:black;background-color:blue;" >Headers,Objects Supported</th>
</tr>
<tr>
<td> DTS-HD </td>	<td>  44.1 - 192 KHz <td> upto 24.5 Mbps	</td> <td>16/24	</td> <td>ALL</td>
</tr>
</table>


\anchor AudioExamples>
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4G Configuring Dolby  Codecs for Dolby Player Certifications</h2>

This section provides the examples on how to configure Dolby Codecs for Dolby certifcations use cases. The configuration requires  API wrappers around existing  Audio API's and requires conversion of floats to fixed points in some cases.
Following features need to be  configured for Dolby Player certification and have different settings for each of  Dolby codec as explained in the following section.
-# Karaoke capable reproduction mode
-# Dynamic range compression mode
-# Output lfe channel present
-# Output channel configuration
-# Number of output channels
-# PCM scale factor
-# Stereo output mode
-# Dual mono reproduction mode
-# Dynamic range compression cut scale factor
-# Dynamic range compression boost scale factor

\anchor AudioDDEx
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4G.1  Dolby Digital (DD or AC3)Configuration</h2>
This section focuses of configuration settings for DD or AC3 Codec.

\anchor AudioDDEx1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">  4G.1.1 Example 1 : Karoke Capable Reproduction Mode</h2>

For setting Karoke Capable Reproduction Mode, use the warapper audio_dd_karaoke_reproduction_mode() which requires configuration of the mode parameter
with following options.
-# 	0 = no vocal
-#  1 = left vocal
-#  2 = right vocal
-#  3 = both vocals

\code
ismd_result_t audio_dd_karaoke_reproduction_mode(
                              ismd_dev_t input_h,
                              ismd_audio_ac3_karaoke_reproduction_mode_t mode)
{
      ismd_result_t retStatus = ISMD_SUCCESS;
      ismd_audio_decoder_param_t param;

      *((ismd_audio_ac3_karaoke_reproduction_mode_t*)&param) = mode;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
      goto end;

   error:
      //Error handler for entire app

   end:

      //Clean up and exit code
      return retStatus;
}

\endcode


\anchor AudioDDEx2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4G.1.2 Example 2 : Dynamic range compression mode </h2>

For setting Dynamic range compression mode use the wrapper  audio_dd_dynamic_range_compression_mode with following options for the mode

-# 0 = custom mode, analog dialnorm
-# 1 = custom mode, digital dialnorm
-# 2 = line out mode
-# 3 = RF remod mode

\code

ismd_result_t audio_dd_dynamic_range_compression_mode(
                              ismd_dev_t input_h,
                              ismd_audio_ac3_dynamic_range_compression_mode_t mode)
{
      ismd_result_t retStatus = ISMD_SUCCESS;
      ismd_audio_decoder_param_t param;

      *((ismd_audio_ac3_dynamic_range_compression_mode_t*)&param) = mode;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_DYNAMIC_RANGE_COMPRESSION_MODE, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
      goto end;

   error:
      //Error handler for entire app

   end:

      //Clean up and exit code
      return retStatus;
}
\endcode

\anchor AudioDDEx2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4G.1.3 Example 3 : pcm Scale Factor </h2>

 For PCM scale factor settings  (default 1.0)  use audio_dd_pcm_scale_factor warpper.
 \code
 // 0.0 - 1.0 are valid, 1.0 is default
 ismd_result_t audio_dd_pcm_scale_factor(
                               ismd_dev_t input_h,
                               double scale_factor)
 {
       ismd_result_t retStatus = ISMD_SUCCESS;
       ismd_audio_decoder_param_t param;

       if(scale_factor < 0.0 || scale_factor > 1.0)
       {
          retStatus = ISMD_ERROR_INVALID_PARAMETER;
          VERIFY_AT_RETSTATUS("Error invalid scale factor must be between 0.0 and 1.0\n", retStatus);
       }

       //convert to int
       *((ismd_audio_ac3_pcm_scale_factor_t*)&param) = ((ismd_audio_ac3_pcm_scale_factor_t)Convert2FixedPoint(scale_factor));
       retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_PCM_SCALE_FACTOR, &param);
       VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
       goto end;

    error:
       //Error handler for entire app

    end:

       //Clean up and exit code
       return retStatus;
 }
static int Convert2FixedPoint (double scale_factor)
{
   signed int argVal;

   //convert from double precision to DSP format 1.23 fixed-point fraction
   scale_factor *= 0x007FFFFFL;
   scale_factor += 0.5;
   argVal = (long)scale_factor;
   return(argVal);
}

 \endcode


 \anchor AudioDDEx2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4G.1.4 Appendix : Other Examples and the warpper code </h2>

 Output lfe channel present (default 1) (audio_dd_lfe_channel_output)
             <br>
 Output channel configuration (default 7) (audio_dd_output_configuration)
 -# 0 = reserved
 -# 1 = 1/0 (C)
 -# 2 = 2/0 (L, R)
 -# 3 = 3/0 (L, C, R)
 -# 4 = 2/1 (L, R, l)
 -# 5 = 3/1 (L, C, R, l)
 -# 6 = 2/2 (L, R, l, r)
 -# 7 = 3/2 (L, C, R, l, r)
          <br>
 Number of output channels (default 6) (audio_dd_number_of_output_channels)
 <br>

 Stereo output mode (default 0) (audio_dd_stereo_output_mode)
   	Only effective when  when output channel configuration=2
    -# 0 = auto detect
    -# 1 = Dolby Surround compatible (Lt/Rt)
    -# 2 = Stereo (Lo/Ro)
    <br>

  Dual mono reproduction mode (default 0) (audio_dd_dual_mono_reproduction_mode)
    -# 0 = Stereo
    -# 1 = Left mono
    -# 2 = Right mono
    -# 3 = Mixed mono
    <br>
  Dynamic range compression cut scale factor (default 1.0) (audio_dd_dynamic_range_cut_scale_factor)
  <br>
 Dynamic range compression boost scale factor (default 1.0) (audio_dd_dynamic_range_boost_scale_factor)
 <br>
 Channel routing information (audio_dd_channel_routing)
  -# Route arbitrary input channels (L, C, R, l, r, s) to
  -# arbitrary interleaved output channel (0..5).
   -# Example: -0L -1R routes left bitstream channel to first ,interleaved output channel, and routes right bitstream
                   channel to second interleaved output channel. Note: use l to designate mono surround in 2/1 or 3/1 modes,
                   use L and R to designate independent channels in 1+1 mode.
   -# Default: -0L -1C -2R -3l -4r -5s

   \code
   #ifndef GEN3_AUDIO_DD_API_C
   #define GEN3_AUDIO_DD_API_C "audio_dd_api.c"

   #include "audio_dd_api.h"
   #include "dolby_player.h"

   static int Convert2FixedPoint (double scale_factor);


   ismd_result_t audio_dd_karaoke_reproduction_mode(
                                 ismd_dev_t input_h,
                                 ismd_audio_ac3_karaoke_reproduction_mode_t mode)
   {
         ismd_result_t retStatus = ISMD_SUCCESS;
         ismd_audio_decoder_param_t param;

         *((ismd_audio_ac3_karaoke_reproduction_mode_t*)&param) = mode;
         retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_KARAOKE_REPRODUCTION_MODE, &param);
         VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         goto end;

      error:
         //Error handler for entire app

      end:

         //Clean up and exit code
         return retStatus;
   }

   ismd_result_t audio_dd_dynamic_range_compression_mode(
                                 ismd_dev_t input_h,
                                 ismd_audio_ac3_dynamic_range_compression_mode_t mode)
   {
         ismd_result_t retStatus = ISMD_SUCCESS;
         ismd_audio_decoder_param_t param;

         *((ismd_audio_ac3_dynamic_range_compression_mode_t*)&param) = mode;
         retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_DYNAMIC_RANGE_COMPRESSION_MODE, &param);
         VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         goto end;

      error:
         //Error handler for entire app

      end:

         //Clean up and exit code
         return retStatus;
   }

   ismd_result_t audio_dd_lfe_channel_output(
                                 ismd_dev_t input_h,
                                 ismd_audio_ac3_lfe_channel_output_t lfe_mode)
   {
      ismd_result_t retStatus = ISMD_SUCCESS;
      ismd_audio_decoder_param_t param;

      *((ismd_audio_ac3_lfe_channel_output_t*)&param) = lfe_mode;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_LFE_CHANNEL_OUTPUT, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
      goto end;

   error:
      //Error handler for entire app

   end:

      //Clean up and exit code
      return retStatus;
   }


   ismd_result_t audio_dd_output_configuration(
                                 ismd_dev_t input_h,
                                 ismd_audio_ac3_output_configuration_t output_config)
   {
         ismd_result_t retStatus = ISMD_SUCCESS;
         ismd_audio_decoder_param_t param;

         *((ismd_audio_ac3_output_configuration_t*)&param) = output_config;
         retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_OUTPUT_CONFIGURATION, &param);
         VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         goto end;

      error:
         //Error handler for entire app

      end:

         //Clean up and exit code
         return retStatus;
   }


   // 1 - 6 are valid, default is 6
   ismd_result_t audio_dd_number_of_output_channels(
                                 ismd_dev_t input_h,
                                 unsigned number_of_output_channels)
   {
         ismd_result_t retStatus = ISMD_SUCCESS;
         ismd_audio_decoder_param_t param;

         if(number_of_output_channels < 1 || number_of_output_channels > 6)
         {
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_AT_RETSTATUS("Error invalid number of output channels must be between 1 and 6\n", retStatus);
         }

         *((ismd_audio_ac3_num_output_channels_t*)&param) = (ismd_audio_ac3_num_output_channels_t)number_of_output_channels;
         retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_NUM_OUTPUT_CHANNELS, &param);
         VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         goto end;

      error:
         //Error handler for entire app

      end:

         //Clean up and exit code
         return retStatus;
   }


   //valid only when number_of_output_channels = AUDIO_DD_OUTPUT_CONFIGURATION_2_0_LR
   ismd_result_t audio_dd_stereo_output_mode(
                                 ismd_dev_t input_h,
                                 ismd_audio_ac3_stereo_output_mode_t mode)
   {
         ismd_result_t retStatus = ISMD_SUCCESS;
         ismd_audio_decoder_param_t param;

         *((ismd_audio_ac3_stereo_output_mode_t*)&param) = mode;
         retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_STEREO_OUTPUT_MODE, &param);
         VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         goto end;

      error:
         //Error handler for entire app

      end:

         //Clean up and exit code
         return retStatus;
   }


   ismd_result_t audio_dd_dual_mono_reproduction_mode(
                                 ismd_dev_t input_h,
                                 ismd_audio_ac3_dual_mono_reproduction_mode_t mode)
   {
         ismd_result_t retStatus = ISMD_SUCCESS;
         ismd_audio_decoder_param_t param;

         *((ismd_audio_ac3_dual_mono_reproduction_mode_t*)&param) = mode;
         retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_DUAL_MONO_REPRODUCTION_MODE, &param);
         VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         goto end;

      error:
         //Error handler for entire app

      end:

         //Clean up and exit code
         return retStatus;
   }


   // 0.0 - 1.0 are valid, 1.0 is default
   ismd_result_t audio_dd_pcm_scale_factor(
                                 ismd_dev_t input_h,
                                 double scale_factor)
   {
         ismd_result_t retStatus = ISMD_SUCCESS;
         ismd_audio_decoder_param_t param;

         if(scale_factor < 0.0 || scale_factor > 1.0)
         {
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_AT_RETSTATUS("Error invalid scale factor must be between 0.0 and 1.0\n", retStatus);
         }

         //convert to int
         *((ismd_audio_ac3_pcm_scale_factor_t*)&param) = ((ismd_audio_ac3_pcm_scale_factor_t)Convert2FixedPoint(scale_factor));
         retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_PCM_SCALE_FACTOR, &param);
         VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         goto end;

      error:
         //Error handler for entire app

      end:

         //Clean up and exit code
         return retStatus;
   }


   // 0.0 - 1.0 are valid, 1.0 is default
   ismd_result_t audio_dd_dynamic_range_cut_scale_factor(
                                 ismd_dev_t input_h,
                                 double scale_factor)
   {
         ismd_result_t retStatus = ISMD_SUCCESS;
         ismd_audio_decoder_param_t param;

         if(scale_factor < 0.0 || scale_factor > 1.0)
         {
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_AT_RETSTATUS("Error invalid scale factor must be between 0.0 and 1.0\n", retStatus);
         }

         //convert to int
         *((ismd_audio_ac3_high_freq_dynamic_cut_scale_factor_t*)&param) = ((ismd_audio_ac3_high_freq_dynamic_cut_scale_factor_t)Convert2FixedPoint(scale_factor));
         retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_DYNAMIC_RANGE_HIGH_FREQ_CUT_SCALE_FACTOR, &param);
         VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         goto end;

      error:
         //Error handler for entire app

      end:

         //Clean up and exit code
         return retStatus;
   }


   // 0.0 - 1.0 are valid, 1.0 is default
   ismd_result_t audio_dd_dynamic_range_boost_scale_factor(
                                 ismd_dev_t input_h,
                                 double scale_factor)
   {
         ismd_result_t retStatus = ISMD_SUCCESS;
         ismd_audio_decoder_param_t param;

         if(scale_factor < 0.0 || scale_factor > 1.0)
         {
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_AT_RETSTATUS("Error invalid scale factor must be between 0.0 and 1.0\n", retStatus);
         }

         //convert to int
         *((ismd_audio_ac3_low_freq_dynamic_boost_scale_factor_t*)&param) = ((ismd_audio_ac3_low_freq_dynamic_boost_scale_factor_t)Convert2FixedPoint(scale_factor));
         retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_DYNAMIC_RANGE_LOW_FREQ_BOOST_SCALE_FACTOR, &param);
         VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         goto end;

      error:
         //Error handler for entire app

      end:

         //Clean up and exit code
         return retStatus;
   }



   // default -0L -1C -2R -3l -4r -5s
   ismd_result_t audio_dd_channel_routing(
                                 ismd_dev_t input_h,
                                 ismd_audio_ac3_channel_route_t L,
                                 ismd_audio_ac3_channel_route_t C,
                                 ismd_audio_ac3_channel_route_t R,
                                 ismd_audio_ac3_channel_route_t l,
                                 ismd_audio_ac3_channel_route_t r,
                                 ismd_audio_ac3_channel_route_t s)
   {
         ismd_result_t retStatus = ISMD_SUCCESS;
         ismd_audio_decoder_param_t param;


         if
         (
            L < -1 || L > 5 ||
            C < -1 || C > 5 ||
            R < -1 || R > 5 ||
            l < -1 || l > 5 ||
            r < -1 || r > 5 ||
            s < -1 || s > 5
         )
         {
            AT_DEBUG(AT_DEBUG_ERROR,"Error: L%d C%d R%d l%d r%d s%d\n", L,C,R,l,r,s);
            retStatus = ISMD_ERROR_INVALID_PARAMETER;
            VERIFY_AT_RETSTATUS("Error invalid channel routes must be between 0 and 5\n", retStatus);
         }

         if(L!=-1)
         {
            *((ismd_audio_ac3_channel_route_t*)&param) = L;
            retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_CHANNEL_ROUTE_L, &param);
            VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         }

         if(C!=-1)
         {
            *((ismd_audio_ac3_channel_route_t*)&param) = C;
            retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_CHANNEL_ROUTE_C, &param);
            VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         }

         if(R!=-1)
         {
            *((ismd_audio_ac3_channel_route_t*)&param) = R;
            retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_CHANNEL_ROUTE_R, &param);
            VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         }

         if(l!=-1)
         {
            *((ismd_audio_ac3_channel_route_t*)&param) = l;
            retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_CHANNEL_ROUTE_Ls, &param);
            VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         }

         if(r!=-1)
         {
            *((ismd_audio_ac3_channel_route_t*)&param) = r;
            retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_CHANNEL_ROUTE_Rs, &param);
            VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         }

         if(s!=-1)
         {
            *((ismd_audio_ac3_channel_route_t*)&param) = s;
            retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_AC3_CHANNEL_ROUTE_LFE, &param);
            VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
         }
         goto end;

      error:
         //Error handler for entire app

      end:

         //Clean up and exit code
         return retStatus;
   }


   static int Convert2FixedPoint (double scale_factor)
   {
      signed int argVal;

      //convert from double precision to DSP format 1.23 fixed-point fraction
      scale_factor *= 0x007FFFFFL;
      scale_factor += 0.5;
      argVal = (long)scale_factor;
      return(argVal);
   }

   #endif /* #define GEN3_AUDIO_DD_API_C "ismd_audio_dd_api.c" */

   \endcode
\anchor AudioDDPlusEx
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 4G.2 Dolby  Digital Plus (DD+ or EC3) Codec Configurations</h2>
Similar instructions as with DD.Note: pcm, cut, and boost functions must convert float to fixedpoint before calling out APIs,
A  function Convert2FixedPoint  is used to  do this and included in the sample code.

-# Karaoke capable reproduction mode (audio_ddplus_karaoke_reproduction_mode)
                  -# 0 = no vocal
                  -# 1 = left vocal
                  -# 2 = right vocal
                  -# 3 = both vocals (default)
-# Dynamic range compression mode (audio_ddplus_dynamic_range_compression_mode)
                  -# 0 = custom mode, analog dialnorm
                  -# 1 = custom mode, digital dialnorm
                  -# 2 = line out mode (default)
                  -# 3 = RF remod mode
 -# LFE channels to output (if available in bitstream) (audio_ddplus_lfe_channel_output)
                  -# 0 = none
                  -# 1 = .1 channel (default)
                  -# 2 = .2 channels
 -# Output channel configuration (audio_ddplus_output_configuration)
                  -# r = raw mode (all channels in bitstream; default)
                  -# 0 = reserved
                  -# 1 = 1/0 (C)
                  -# 2 = 2/0 (L, R)
                  -# 3 = 3/0 (L, C, R)
                  -# 4 = 2/1 (L, R, l)
                  -# 5 = 3/1 (L, C, R, l)
                  -# 6 = 2/2 (L, R, l, r)
                  -# 7 = 3/2 (L, C, R, l, r)
                  -# 8 = 3/0/1 (L, C, R, Cvh)
                  -# 9 = 2/2/1 (L, R, l, r, Ts)
                  -# 10 = 3/2/1 (L, C, R, l, r, Ts)
                  -# 11 = 3/2/1 (L, C, R, l, r, Cvh)
                  -# 12 = 3/0/2 (L, C, R, Lc, Rc)
                  -# 13 = 2/2/2 (L, R, l, r, Lw, Rw)
                  -# 14 = 2/2/2 (L, R, l, r, Lvh, Rvh)
                  -# 15 = 2/2/2 (L, R, l, r, Lsd, Rsd)
                  -# 16 = 2/2/2 (L, R, l, r, Lrs, Rrs)
                  -# 17 = 3/2/2 (L, C, R, l, r, Lc, Rc)
                  -# 18 = 3/2/2 (L, C, R, l, r, Lw, Rw)
                  -# 19 = 3/2/2 (L, C, R, l, r, Lvh, Rvh)
                  -# 20 = 3/2/2 (L, C, R, l, r, Lsd, Rsd)
                  -# 21 = 3/2/2 (L, C, R, l, r, Lrs, Rrs)
                  -# 22 = 3/2/2 (L, C, R, l, r, Ts, Cvh)
  -# Number of output channels (default 8) (audio_ddplus_number_of_output_channels)
  -# PCM scale factor (default 1.0) (audio_ddplus_pcm_scale_factor)
                  -# Do not quit on processing error
                  -# By default, DEC will quit if processing error is encountered.
                  -# This option overrides this behavior.
  -# Region to process in frames (default 0:end) (audio_ddplus_frame_start_end)
  -# Stereo output mode (only effective when -m = 2)( audio_ddplus_stereo_output_mode)
                  -# 0 = auto detect (default)
                  -# 1 = Surround compatible (Lt/Rt)
                  -# 2 = Stereo (Lo/Ro)
  -# Dual mono reproduction mode (audio_ddplus_dual_mono_reproduction_mode)
                  -# 0 = Stereo (default)
                  -# 1 = Left mono
                  -# 2 = Right mono
                  -# 3 = Mixed mono
   -# Upsampling mode (audio_ddplus_upsampling_mode)
                  -# 0 = Upsample based on bitstream metadata (default)
                  -# 1 = Always perform upsampling
                  -# 2 = Never perform upsampling
   -# Dynamic range compression cut scale factor (default 1.0) (audio_ddplus_dynamic_range_cut_scale_factor)
   -# Dynamic range compression boost scale factor (default 1.0) (audio_ddplus_dynamic_range_boost_scale_factor)
                 -# -0..7  Channel routing information (audio_ddplus_channel_routing)

                  -# Route arbitrary input channels (L, C, R, l, r, s, x1, x2)                  to arbitrary interleaved PCM output channels (0..7).
                  -# Example: -0L -1R routes left bitstream channel to first                   interleaved output channel, and routes right bitstream
                  channel to second interleaved output channel. Note: x1 and x2 are used to represent the first and second
                  extension channels in the bitstream in the order defined by
                  chanmap.
                  -# Default: -0L -1C -2R -3l -4r -5s -6x1 -7x2

\anchor AudioDDPlusEx1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4G.2.1 Warpper Code</h2>



\code
#ifndef AUDIO_DDPLUS_API_C
#define AUDIO_DDPLUS_API_C "audio_ddplus_api.c"


#include "audio_ddplus_api.h"
#include "dolby_player.h"

static int Convert2FixedPoint (double scale_factor);

/*Set codec params*/

ismd_result_t audio_ddplus_karaoke_reproduction_mode(
                              ismd_dev_t input_h,
                              ismd_audio_ddplus_karaoke_reproduction_mode_t mode)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_ddplus_karaoke_reproduction_mode_t*)&param) = mode;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_KARAOKE_REPRODUCTION_MODE, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}


ismd_result_t audio_ddplus_dynamic_range_compression_mode(
                              ismd_dev_t input_h,
                              ismd_audio_ddplus_dynamic_range_compression_mode_t mode)

{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_ddplus_dynamic_range_compression_mode_t*)&param) = mode;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_DYNAMIC_RANGE_COMPRESSION_MODE, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}


ismd_result_t audio_ddplus_lfe_channel_output(
                              ismd_dev_t input_h,
                              ismd_audio_ddplus_lfe_channel_output_t lfe_mode)

{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_ddplus_lfe_channel_output_t*)&param) = lfe_mode;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_LFE_CHANNEL_OUTPUT, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

ismd_result_t audio_ddplus_output_configuration(
                              ismd_dev_t input_h,
                              ismd_audio_ddplus_output_configuration_t output_config)

{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_ddplus_output_configuration_t*)&param) = output_config;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_OUTPUT_CONFIGURATION, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

// 1 - 8 are valid, default is 8
ismd_result_t audio_ddplus_number_of_output_channels(
                              ismd_dev_t input_h,
                              unsigned number_of_output_channels)

{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   if(number_of_output_channels < 1 || number_of_output_channels > 8)
   {
      retStatus = ISMD_ERROR_INVALID_PARAMETER;
      VERIFY_AT_RETSTATUS("Error invalid number of output channels must be between 1 and 8\n", retStatus);
   }

   *((ismd_audio_ddplus_num_output_channels_t*)&param) = (ismd_audio_ddplus_num_output_channels_t)number_of_output_channels;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_NUM_OUTPUT_CHANNELS, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

//valid only when number_of_output_channels = AUDIO_DDPLUS_OUTPUT_CONFIGURATION_2_0_LR
ismd_result_t audio_ddplus_stereo_output_mode(
                              ismd_dev_t input_h,
                              ismd_audio_ddplus_stereo_output_mode_t mode)

{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_ddplus_stereo_output_mode_t*)&param) = mode;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_STEREO_OUTPUT_MODE, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

ismd_result_t audio_ddplus_dual_mono_reproduction_mode(
                           ismd_dev_t input_h,
                           ismd_audio_ddplus_dual_mono_reproduction_mode_t mode)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_ddplus_dual_mono_reproduction_mode_t*)&param) = mode;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_DUAL_MONO_REPRODUCTION_MODE, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

ismd_result_t audio_ddplus_upsampling_mode(
                           ismd_dev_t input_h,
                           ismd_audio_ddplus_upsampling_mode_t mode)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_ddplus_upsampling_mode_t*)&param) = mode;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_UPSAMPLING_MODE, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

// 0.0 - 1.0 are valid, 1.0 is default
ismd_result_t audio_ddplus_pcm_scale_factor(
                           ismd_dev_t input_h,
                           double scale_factor)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   if(scale_factor < 0.0 || scale_factor > 1.0)
   {
      retStatus = ISMD_ERROR_INVALID_PARAMETER;
      VERIFY_AT_RETSTATUS("Error invalid scale factor must be between 0.0 and 1.0\n", retStatus);
   }

   //convert to int
   *((ismd_audio_ddplus_pcm_scale_factor_t*)&param) = ((ismd_audio_ddplus_pcm_scale_factor_t)Convert2FixedPoint(scale_factor));
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_PCM_SCALE_FACTOR, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

// 0 and -1 is default
ismd_result_t audio_ddplus_frame_start_end(
                              ismd_dev_t input_h,
                              ismd_audio_ddplus_framestart_t framestart,
                              ismd_audio_ddplus_frameend_t frameend)

{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_ddplus_framestart_t*)&param) = framestart;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_FRAMESTART, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);

   *((ismd_audio_ddplus_frameend_t*)&param) = frameend;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_FRAMEEND, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}


// 0.0 - 1.0 are valid, 1.0 is default
ismd_result_t audio_ddplus_quitonerr(
                              ismd_dev_t input_h,
                              ismd_audio_ddplus_quitonerr_t quitonerr)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;


   *((ismd_audio_ddplus_quitonerr_t*)&param) = quitonerr;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_QUITONERR, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}


// 0.0 - 1.0 are valid, 1.0 is default
ismd_result_t audio_ddplus_dynamic_range_cut_scale_factor(
                              ismd_dev_t input_h,
                              double scale_factor)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   if(scale_factor < 0.0 || scale_factor > 1.0)
   {
      retStatus = ISMD_ERROR_INVALID_PARAMETER;
      VERIFY_AT_RETSTATUS("Error invalid scale factor must be between 0.0 and 1.0\n", retStatus);
   }

   //convert to int
   *((ismd_audio_ddplus_high_freq_dynamic_cut_scale_factor_t*)&param) = ((ismd_audio_ddplus_high_freq_dynamic_cut_scale_factor_t)Convert2FixedPoint(scale_factor));
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_DYNAMIC_RANGE_HIGH_FREQ_CUT_SCALE_FACTOR, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

// 0.0 - 1.0 are valid, 1.0 is default
ismd_result_t audio_ddplus_dynamic_range_boost_scale_factor(
                              ismd_dev_t input_h,
                              double scale_factor)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   if(scale_factor < 0.0 || scale_factor > 1.0)
   {
      retStatus = ISMD_ERROR_INVALID_PARAMETER;
      VERIFY_AT_RETSTATUS("Error invalid scale factor must be between 0.0 and 1.0\n", retStatus);
   }

   //convert to int
   *((ismd_audio_ddplus_low_freq_dynamic_boost_scale_factor_t*)&param) = ((ismd_audio_ddplus_low_freq_dynamic_boost_scale_factor_t)Convert2FixedPoint(scale_factor));
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_DYNAMIC_RANGE_LOW_FREQ_BOOST_SCALE_FACTOR, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}


// default -0L -1C -2R -3l -4r -5s -6x1 -7x2
ismd_result_t audio_ddplus_channel_routing(
                              ismd_dev_t input_h,
                              ismd_audio_ddplus_channel_route_t L,
                              ismd_audio_ddplus_channel_route_t C,
                              ismd_audio_ddplus_channel_route_t R,
                              ismd_audio_ddplus_channel_route_t l,
                              ismd_audio_ddplus_channel_route_t r,
                              ismd_audio_ddplus_channel_route_t s,
                              ismd_audio_ddplus_channel_route_t x1,
                              ismd_audio_ddplus_channel_route_t x2)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;


   if
   (
      L < -1 || L > 7 ||
      C < -1 || C > 7 ||
      R < -1 || R > 7 ||
      l < -1 || l > 7 ||
      r < -1 || r > 7 ||
      s < -1 || s > 7 ||
      x1 < -1 || x1 > 7 ||
      x2 < -1 || x2 > 7
   )
   {
      AT_DEBUG(AT_DEBUG_ERROR,"Error: L%d C%d R%d l%d r%d s%d x1%d x2%d\n", L,C,R,l,r,s,x1,x2);
      retStatus = ISMD_ERROR_INVALID_PARAMETER;
      VERIFY_AT_RETSTATUS("Error invalid channel routes must be between 0 and 7\n", retStatus);
   }

   if(L!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = L;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_CHANNEL_ROUTE_L, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }

   if(C!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = C;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_CHANNEL_ROUTE_C, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }
   if(R!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = R;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_CHANNEL_ROUTE_R, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }
   if(l!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = l;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_CHANNEL_ROUTE_Ls, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }

   if(r!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = r;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_CHANNEL_ROUTE_Rs, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }

   if(s!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = s;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_CHANNEL_ROUTE_LFE, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }

   if(x1!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = x1;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_CHANNEL_ROUTE_Lrs, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }

   if(x2!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = x2;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_DDPLUS_CHANNEL_ROUTE_Rrs, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

static int Convert2FixedPoint (double scale_factor)
{
   signed int argVal;

   //convert from double precision to DSP format 1.23 fixed-point fraction
   scale_factor *= 0x007FFFFFL;
   scale_factor += 0.5;
   argVal = (long)scale_factor;
   return(argVal);
}

#endif /*#define AUDIO_DDPLUS_API_C*/

\endcode

\anchor AudioHDEx
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4G.3 True HD Codec Configurations</h2>
-# -x2 fileName  Two channel output filename (audio_truehd_set_channel_mode)
-# -x6 fileName  Six channel output filename (audio_truehd_set_channel_mode)
-# -x8 fileName  Eight channel output filename (audio_truehd_set_channel_mode)
-#          output fbb streams with fba channel order (audio_truehd_fba_chan_reorder)
-# -drc n        Enable dynamic range control {OFF=0,FOLLOW,ON} (default = follow) (audio_truehd_enable_drc)
-# -boost n      %age of drc value used for boost (default = 100%) (audio_truehd_set_boost_percent)
-# -cut n        %age of drc value used for cut (default = 100%) (audio_truehd_set_cut_percent)
-# -dialref n    reference dialogue level, 0=disabled (default = -31) (audio_truehd_set_dial_ref_level)
-# -lossless     only perform lossless decoding (audio_truehd_enable_lossless)
-# -archive      decode exact length (otherwise decodes whole access units) (audio_truehd_enable_archive)

\anchor AudioHDEx1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">4G.3.1 Wrapper Code</h2>
\code
#ifndef AUDIO_TRUEHD_API_C
#define AUDIO_TRUEHD_API_C "audio_truehd_api.c"


#include "audio_truehd_api.h"
#include "dolby_player.h"


/*Set codec params*/

//This function is used to set the mode as either 2-channel, 6-channel, 8-channel.
ismd_result_t audio_truehd_set_channel_mode(
		                        ismd_dev_t input_h,
		                        ismd_audio_truehd_decode_mode_t mode)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_truehd_decode_mode_t*)&param) = mode;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_DECODE_MODE, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}


//This is function is used to enable/disable the lossless mode. By default lossless should be disabled OFF/FALSE
ismd_result_t audio_truehd_enable_lossless(
                        		ismd_dev_t input_h,
                        		bool enable)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;
   ismd_audio_truehd_lossless_t lossless = (enable?1:0);

   *((ismd_audio_truehd_lossless_t*)&param) = lossless;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_LOSSLESS, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

//This function is used to enable the archive mode which is used to remove zero padding from access units containing a terminator.
//DISABLED is the default mode
ismd_result_t audio_truehd_enable_archive(
                        		ismd_dev_t input_h,
                        		bool enable)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;
   ismd_audio_truehd_zero_unused_chans_t zero = (enable?1:0);

   *((ismd_audio_truehd_zero_unused_chans_t*)&param) = zero;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_ZERO_UNUSED_CHANS, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

//This function is used to set the DRC mode: OFF 0, FOLLOW 1, ON 2
//Deafult mode is FOLLOW
ismd_result_t audio_truehd_enable_drc(
                        		ismd_dev_t input_h,
                        		ismd_audio_truehd_drc_enable_t mode)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_truehd_drc_enable_t*)&param) = mode;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_DRC_ENABLE, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

//This function is used for setting the dialogue reference level
//The value of the reference level ranges from 0dB to -48dB
//The default value is -31dB
ismd_result_t audio_truehd_set_dial_ref_level(
                        		ismd_dev_t input_h,
                        		signed int dial_ref_level)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_truehd_dialog_ref_t*)&param) = -abs(dial_ref_level);
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_DIALOG_REF, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

#ifdef NEVER
//This function is used for setting up the channel output order
//The value of the order could be Left (L), Right (R), Center (C), Low-Frequency Effects (LFE)
//Left Surround (Ls), Right Surround (Rs), Left Back (Lb), Right Back (Rb)
//default -0L -1C -2R -3Ls -4Rs -5LFE -6Lb -7Rb
ismd_result_t audio_truehd_set_channel_output_order(
                              ismd_dev_t input_h,
                              ismd_audio_truehd_channel_route_t L,
                              ismd_audio_truehd_channel_route_t C,
                              ismd_audio_truehd_channel_route_t R,
                              ismd_audio_truehd_channel_route_t Ls,
                              ismd_audio_truehd_channel_route_t Rs,
                              ismd_audio_truehd_channel_route_t LFE,
                              ismd_audio_truehd_channel_route_t Lb,
                              ismd_audio_truehd_channel_route_t Rb)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;


   if
   (
      L < -1   || L > 7   ||
      C < -1   || C > 7   ||
      R < -1   || R > 7   ||
      Ls < -1  || Ls > 7  ||
      Rs < -1  || Rs > 7  ||
      LFE < -1 || LFE > 7 ||
      Lb < -1  || Lb > 7  ||
      Rb < -1  || Rb > 7
   )
   {
      AT_DEBUG(AT_DEBUG_ERROR,"Error: L%d C%d R%d Ls%d Rs%d LFE%d Lb%d Rb%d\n", L,C,R,Ls,Rs,LFE,Lb,Rb);
      retStatus = ISMD_ERROR_INVALID_PARAMETER;
      VERIFY_AT_RETSTATUS("Error invalid channel routes must be between 0 and 7\n", retStatus);
   }


   if(L!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = L;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_CHANNEL_ROUTE_L, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }

   if(C!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = C;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_CHANNEL_ROUTE_C, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }
   if(R!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = R;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_CHANNEL_ROUTE_R, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }
   if(Ls!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = Ls;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_CHANNEL_ROUTE_Ls, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }

   if(Rs!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = Rs;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_CHANNEL_ROUTE_Rs, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }

   if(LFE!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = LFE;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_CHANNEL_ROUTE_LFE, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }

   if(Lb!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = Lb;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_CHANNEL_ROUTE_Lb, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }

   if(Rb!=-1)
   {
      *((ismd_audio_ddplus_channel_route_t*)&param) = Rb;
      retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_CHANNEL_ROUTE_Rb, &param);
      VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   }
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}
#endif /* NEVER */

//This function is used for setting the boost %
//The values can range from 0 to 100, but it should be an INTEGER
//The defualt value of the boost% is 100
ismd_result_t audio_truehd_set_boost_percent(
                        		ismd_dev_t input_h,
                        		int percent)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_truehd_drc_boost_t*)&param) = percent;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_DRC_BOOST, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

//This function is used for setting the cut %
//The values can range from 0 to 100, but it should be an INTEGER
//The defualt value of the boost% is 100
ismd_result_t audio_truehd_set_cut_percent(
                        		ismd_dev_t input_h,
                        		int percent)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;

   *((ismd_audio_truehd_drc_cut_t*)&param) = percent;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_DRC_CUT, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

//This function is used to enable the CRC check on the block headers.
//ENABLED is the default mode
ismd_result_t audio_truehd_enable_crc_check(
                        		ismd_dev_t input_h,
                        		bool enable)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;
   ismd_audio_truehd_block_crc_t crc = (enable?1:0);

   *((ismd_audio_truehd_block_crc_t*)&param) = crc;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_BLOCK_CRC, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

//This function reroutes the FBB stream channels to match the FBA channel order.
//FALSE NO Reorder is the default mode
ismd_result_t audio_truehd_fba_chan_reorder(
                        		ismd_dev_t input_h,
                        		bool reorder)
{
   ismd_result_t retStatus = ISMD_SUCCESS;
   ismd_audio_decoder_param_t param;
   ismd_audio_truehd_fba_chan_reorder_t fba = (reorder?1:0);

   *((ismd_audio_truehd_fba_chan_reorder_t*)&param) = fba;
   retStatus = ismd_audio_input_set_decoder_param(proc_h, input_h, ISMD_AUDIO_TRUEHD_FBA_CH_REORDER, &param);
   VERIFY_AT_RETSTATUS("Failed ismd_audio_input_set_decoder_param\n", retStatus);
   goto end;

error:
   //Error handler for entire app

end:

   //Clean up and exit code
   return retStatus;
}

#endif /*#define AUDIO_TRUEHD_API_C*/

\endcode
\anchor SMDAudioAPI
- \ref ismd_audio Audio: SMD Audio API.

 */


