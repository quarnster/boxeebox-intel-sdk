
/*
* File Name: ismd_audio_type_defs.h
*/

/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2010 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2010 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/


/** \addtogroup ismd_audio
@{ */

#ifndef _ISMD_AUDIO_TYPE_DEFS_H_
#define _ISMD_AUDIO_TYPE_DEFS_H_

#ifdef __cplusplus
extern "C" {
#endif

#ifndef AUDIO_FW
#include "osal.h"
#include "sven_devh.h"
   typedef uint64_t audio_uint64_t;
#else
/** 64bit unsigned integer type used in stuctures
    shared with audio processing hardware.*/
   typedef struct {
      unsigned int low;
      unsigned int high;
   } audio_uint64_t;
#endif

/** 16bit type used in stuctures shared with audio
    processing hardware.*/
typedef signed short audio_int16_t;

/** 32bit type used in stuctures shared with audio
    processing hardware.*/
typedef int audio_int32_t;


/** Boolean value to be used in stuctures shared with
    audio processing hardware.*/
typedef uint32_t bool_shared_t;

/**
Value that can be used to specify gain in dB with a resolution of 0.1dB.
Valid values are  +180 to -1450, representing gains of +18.0dB to -145.0dB.
*/
typedef int ismd_audio_gain_value_t;



/** @} */ // End of weakgroup ismd_audio_data_types

#ifdef __cplusplus
}
#endif
#endif
