/*

This file is provided under a dual BSD/GPLv2 license.  When using or
redistributing this file, you may do so under either license.

GPL LICENSE SUMMARY

Copyright(c) 2010-2011 Intel Corporation. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
The full GNU General Public License is included in this distribution
in the file called LICENSE.GPL.

Contact Information:

Intel Corporation
2200 Mission College Blvd.
Santa Clara, CA  97052

BSD LICENSE

Copyright(c) 2010-2011 Intel Corporation. All rights reserved.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in
the documentation and/or other materials provided with the
distribution.
* Neither the name of Intel Corporation nor the names of its
contributors may be used to endorse or promote products derived
from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



   /** @weakgroup new_smd_systems1  Chapter 6  SMD System Features

\anchor Contents
    \anchor Contents
    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Contents</H2>
      - <A HREF="#SystemComp" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">6A. SMD Pipeline </A>
         - <A HREF="#SystemComp1">6A.1 Pipeline Cobnstruction </A>
            - <A HREF="#SystemCom1EX1">6A.1.1   Demux Construction  and Sample Code </A>
            - <A HREF="#SystemCom1EX2">6A.1.2  Audio Decoder Construction  and Sample Code    </A>
            - <A HREF="#SystemCom1EX3">6A.1.3  Video Decoder Construction  and Sample Code  </A>
            - <A HREF="#SystemCom1EX4">6A.1.4  Video Processor Construction  and Sample Code  </A>
            - <A HREF="#SystemCom1EX5">6A.1.5  Video Renderer Construction  and Sample Code </A>
         - <A HREF="#SystemComp2">6A.2  Clock Allocation and Assignment</A>
         - <A HREF="#SystemComp3">6A.3  Pipeline Connection</A>
         - <A HREF="#SystemComp4">6A.4  Timing Initialization</A>
         - <A HREF="#SystemComp5">6A.5  Pipeline Start</A>

      - <A HREF="#SystemPlay" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">6B Various Play Back Modes</A>
         - <A HREF="#SystemPlay1">6B.1 File Playback</A>
         - <A HREF="#SystemPlay2">6B.2 Tuner Playback</A>

      - <A HREF="#SystemTrick" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">6C Trick modes</A>
         - <A HREF="#SystemTrick1">6C.1 Pause and Resumek</A>
         - <A HREF="#SystemTrick2">6C.2 Fast Forward</A>
         - <A HREF="#SystemTrick3">6C.3 Seek</A>

       - <A HREF="#SystemTrickTr" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">6D Trick Mode Transition</A>
         - <A HREF="#SystemTrickTr1">6D.1 Change Playback Speed</A>
         - <A HREF="#SystemTrickTr2">6D.2 Dynamic Rate Change</A>
         - <A HREF="#SystemTrickTr3">6D.3 Fixed Frame Rate Playback</A>
         - <A HREF="#SystemTrickTr4">6D.4 Partial GOP decode</A>
         - <A HREF="#SystemTrickTr5">6D.5 Smooth Reverse Trick Mode</A>
         - <A HREF="#SystemTrickTr6">6D.6 Single Step Frame</A>

         - <A HREF="#SystemSync" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">6E Achieving A/V sync</A>
         - <A HREF="#SystemDual" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">6F Handling Dual Stream</A>

       - <A HREF="#SystemEvents" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">6G Pipeline Asynchronous Events</A>
         - <A HREF="#SystemEvents1">6G.1 Critical Error</A>
         - <A HREF="#SystemEvents2">6G.2 Buffer Allocation Failure</A>
         - <A HREF="#SystemEvents3">6G.3 Overrun and Underrun</A>
         - <A HREF="#SystemEvents4">6G.4 Heartbeats</A>

\anchor Introduction
    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> Pipeline Construction Overview</H2>
    Previous chapters have discussed the demux, audio, viddec, vidpproc, render and smd core components separately.  This chapter will introduce the pipeline mechanism, which will accommodate all of the above components into one pipeline and make them work together to carry out certain operations to stream as playback, trick mode playback, channel change, etc. The pipeline can be made by simply combining components together or to be abstract by providing a container which provides a unified control interface to the entire pipeline.
    Fig.1 shows the Baisc pipeline components.
    \image html system1.png Basic Pipeline Components

    The basic sequence to construct a pipeline will be divided into the 5 stages below.
    -# Component construction
    -# Clock construction and assignment
    -# Pipeline connection
    -# Timing initialization
    -# Start the pipeline


   \anchor SystemComp1
   <h2> Pipeline Construction Components</h2>

   Component construction is the first stage to build a pipeline, which includes the construction of demux, audio processor, video decoder, video post processor
   and video render. Generally speaking, every stage will automatically handle self-initiation and port initiation for input and output.
The exceptions are demux, video render and audio processor. The following example shows the pseudo code for this stage:


\anchor SystemCom1EX1
    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> 6A.1.1 Sample Code for Demux Construction</H2>

-# Demux Construction
   -# open a stream \ref ismd_demux_stream_open
   -# open a  ES filter for Video \ref ismd_demux_filter_open
   -# get  video output port from ES Filter  ismd_demux_filter_get_output_port
   -# open a  ES filter for audio \ref ismd_demux_filter_open
   -# get  audio output port from ES Filter  ismd_demux_filter_get_output_port
   -# Map the audio pid to this filter;
   -# Set the PCR pid to the TSD \ref ismd_demux_ts_set_pcr_pid
   -# Set the demux to the  pause state. \ref ismd_dev_set_state
\code
static ismd_result_t build_demux(uint16_t audio_pid, uint16_t video_pid, uint16_t pcr_pid)
{
   ismd_result_t ismd_ret;
   unsigned output_buf_size = 0;
   ismd_demux_pid_list_t demux_pid_list;

   ismd_ret = ismd_demux_stream_open(ISMD_DEMUX_STREAM_TYPE_MPEG2_TRANSPORT_STREAM, &demux_stream_handle, &demux_input_port_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_demux_stream_open\n");
      assert(0);
   }
   output_buf_size = 32*1024;
   ismd_ret = ismd_demux_filter_open(demux_stream_handle, ISMD_DEMUX_OUTPUT_ES, output_buf_size, &demux_ves_filter_handle, &dummy_port_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_demux_filter_open\n");
      assert(0);
   }
   ismd_ret = ismd_demux_filter_get_output_port(demux_stream_handle, demux_ves_filter_handle, &ts_vid_output_port_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_demux_filter_get_output_port\n");
      assert(0);
   }
   output_buf_size = 8*1024;
   ismd_ret = ismd_demux_filter_open(demux_stream_handle, ISMD_DEMUX_OUTPUT_ES, output_buf_size, &demux_aes_filter_handle, &dummy_port_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_demux_filter_open\n");
      assert(0);
   }
   ismd_ret = ismd_demux_filter_get_output_port(demux_stream_handle, demux_aes_filter_handle, &ts_aud_output_port_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_demux_filter_get_output_port\n");
      assert(0);
   }
   ismd_ret = ismd_demux_stream_get_input_port(demux_stream_handle, &ts_input_port_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_demux_filter_get_output_port\n");
      assert(0);
   }

   demux_pid_list.pid_array[0].pid_type = ISMD_DEMUX_PID_TYPE_PES;
   demux_pid_list.pid_array[0].pid_val = video_pid;
   ismd_ret = ismd_demux_filter_map_to_pids(demux_stream_handle, demux_ves_filter_handle, demux_pid_list, 1);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_demux_filter_map_to_pids\n");
      assert(0);
   }

   demux_pid_list.pid_array[0].pid_type = ISMD_DEMUX_PID_TYPE_PES;
   demux_pid_list.pid_array[0].pid_val = audio_pid;
   ismd_ret = ismd_demux_filter_map_to_pids(demux_stream_handle, demux_aes_filter_handle, demux_pid_list, 1);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_demux_filter_map_to_pids\n");
      assert(0);
   }

   ismd_ret = ismd_demux_ts_set_pcr_pid(demux_stream_handle, pcr_pid);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_demux_ts_set_pcr_pid\n");
      assert(0);
   }



   ismd_ret = ismd_dev_set_state(demux_stream_handle,ISMD_DEV_STATE_PAUSE);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_dev_set_state\n");
      assert(0);
   }

   return ISMD_SUCCESS;

}
\endcode


\anchor SystemCom1EX2
    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> 6A.1.2 Sample Code for Audio Construction</H2>
-# Audio Component Construction
   -# Open Audio Processor  using the api \ref ismd_audio_open_processor
   -# Add Input Port \ref ismd_audio_add_input_port
   -# Set audio format for the input and enable input port using  \ref ismd_audio_input_set_data_format
      Additional configuration is necesaary for some codecs. Refer to Audio chapter.
   -# Add output port to the processor \ref  ismd_audio_add_phys_output
   -# Configure output
         -# configure sample rate  \ref ismd_audio_set_sample_rate
         -# configure channel config  \ref ismd_audio_output_set_channel_config
         -# configure sample size  \ref ismd_audio_output_set_sample_size
         -# configure output mode  \ref ismd_audio_output_set_mode
   -# Enable output \ref ismd_audio_output_enable
   -# Set the Audio Input to pause state \ref ismd_dev_set_state
\code
static ismd_result_t build_audio(ismd_audio_format_t aud_fmt)
{
   ismd_result_t ismd_ret;
   ismd_audio_output_config_t audio_output;
   audio_output.ch_config = ISMD_AUDIO_STEREO;
   audio_output.out_mode = ISMD_AUDIO_OUTPUT_PCM;
   audio_output.sample_rate = 48000;
   audio_output.sample_size = 16;
   audio_output.stream_delay = 0;

   ismd_ret = ismd_audio_open_global_processor(&audio_processor);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_open_processor\n");
      assert(0);
   }
   ismd_ret = ismd_audio_add_input_port(audio_processor, true, &audio_handle, &audio_input_port_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_add_input_port\n");
      assert(0);
   }
   ismd_ret = ismd_audio_input_set_data_format(audio_processor, audio_handle, aud_fmt);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_input_set_data_format\n");
      assert(0);
   }
   ismd_ret = ismd_audio_input_enable(audio_processor, audio_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_input_enable\n");
      assert(0);
   }
   ismd_ret = ismd_audio_add_phys_output(audio_processor, GEN3_HW_OUTPUT_HDMI, audio_output, &audio_output_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_add_phys_output\n");
      assert(0);
   }
   ismd_ret = setup_audio_pll_freq_ce3100(48000);
  if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at setup audio pll\n");
      assert(0);
   }

   ismd_ret = ismd_audio_output_set_channel_config(audio_processor, audio_output_handle, ISMD_AUDIO_STEREO);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_output_set_channel_config\n");
      assert(0);
   }
   ismd_ret = ismd_audio_output_set_sample_size(audio_processor, audio_output_handle, 16);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_output_set_sample_size\n");
      assert(0);
   }

   ismd_ret = ismd_audio_output_set_sample_rate(audio_processor, audio_output_handle, 48000);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_output_set_sample_rate\n");
      assert(0);
   }
   ismd_ret = ismd_audio_output_set_mode(audio_processor, audio_output_handle, ISMD_AUDIO_OUTPUT_PCM);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_output_set_mode\n");
      assert(0);
   }
   ismd_ret = ismd_audio_output_set_external_bit_clock_div(audio_processor, audio_output_handle, 12);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_output_set_external_bit_clock_div\n");
      assert(0);
   }
   ismd_ret = ismd_audio_output_enable(audio_processor, audio_output_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_audio_output_enable\n");
      assert(0);
   }
   ismd_ret = ismd_dev_set_state(audio_handle,ISMD_DEV_STATE_PAUSE);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_dev_set_state\n");
      assert(0);
   }
\endcode

\anchor SystemCom1EX3
    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> 6A.1.3 Sample Code for Video Decoder Construction</H2>

    -# Video Decoder Construction
      -# Open the decoder;
      -# Set frame mask to tell the decoder skip certain kind of frames;
      -# Set max num of frames that can be decoded;
      -# Set frame error policy;
      -# Get input and output port from the decode object;
      -# Set the decoder to the pause status \ref ismd_dev_set_state



   \code
   static ismd_result_t build_viddec(ismd_codec_type_t vid_codec)
    {
       ismd_result_t ismd_ret;

       ismd_ret = ismd_viddec_open(vid_codec, &viddec_handle);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_viddec_open\n");
          assert(0);
       }
       ismd_ret = ismd_viddec_set_pts_interpolation_policy(viddec_handle, ISMD_VIDDEC_INTERPOLATE_MISSING_PTS , ISMD_NO_PTS);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_viddec_set_pts_interpolation_policy\n");
          assert(0);
       }
       ismd_ret = ismd_viddec_set_frame_mask(viddec_handle, ISMD_VIDDEC_SKIP_NONE);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_viddec_set_frame_mask\n");
          assert(0);
       }
       ismd_ret = ismd_viddec_set_max_frames_to_decode(viddec_handle,ISMD_VIDDEC_ALL_FRAMES);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_viddec_set_max_frames_to_decode\n");
          assert(0);
       }
       ismd_ret = ismd_viddec_set_frame_error_policy(viddec_handle, ISMD_VIDDEC_EMIT_ALL);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_viddec_set_frame_error_policy\n");
          assert(0);
       }
       ismd_ret = ismd_viddec_get_input_port(viddec_handle, &viddec_input_port_handle);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_viddec_get_input_port\n");
          assert(0);
       }
       ismd_ret = ismd_viddec_get_output_port(viddec_handle, &viddec_output_port_handle);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_viddec_get_output_port\n");
          assert(0);
       }
       ismd_ret = ismd_dev_set_state(viddec_handle,ISMD_DEV_STATE_PAUSE);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_dev_set_state\n");
          assert(0);
       }

       return ISMD_SUCCESS;

    }

\endcode


\anchor SystemCom1EX4
    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> 6A.1.4 Sample Code for Video Processor Construction</H2>

     -#  vidpproc component:
         -# Open the vpp;
         -# Set the DI policy;
         -# Set dest hight and width;
         -# Set scaling policy;
         -# Get input and output port of the vpp object;
         -# Set the VPP to the pause status \ref ismd_dev_set_state


    \code
    static ismd_result_t build_vidpproc(void)
    {
       ismd_result_t ismd_ret;

       ismd_ret = ismd_vidpproc_open(&vidpproc_handle);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_vidpproc_open\n");
          assert(0);
       }
       ismd_ret = ismd_vidpproc_set_deinterlace_policy(vidpproc_handle, AUTO);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_vidpproc_set_deinterlace_policy\n");
          assert(0);
       }
       ismd_ret = ismd_vidpproc_set_dest_params(vidpproc_handle, DISPLAY_WIDTH, DISPLAY_HEIGHT, 1, 1);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_vidpproc_set_dest_params\n");
          assert(0);
       }
       ismd_ret = ismd_vidpproc_set_scaling_policy(vidpproc_handle, SCALE_TO_FIT);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_vidpproc_set_scaling_policy\n");
          assert(0);
       }
       ismd_ret = ismd_vidpproc_get_input_port(vidpproc_handle,&vidpproc_input_port_handle);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_vidpproc_get_input_port\n");
          assert(0);
       }
       ismd_ret = ismd_vidpproc_get_output_port(vidpproc_handle,&vidpproc_output_port_handle);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_vidpproc_get_output_port\n");
          assert(0);
       }
       ismd_ret = ismd_dev_set_state(vidpproc_handle,ISMD_DEV_STATE_PAUSE);
       if(ismd_ret != ISMD_SUCCESS) {
          printf("failed at ismd_dev_set_state\n");
          assert(0);
       }

       return ISMD_SUCCESS;
    }

\endcode

\anchor SystemCom1EX5
    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> 6A.1.5 Sample Code for Video Renderer Construction</H2>
    Pseudo code for the video render:
          -# Video Renderer Construction
            -# Set video plane for this render;
            -# Disable fixed frame rate; (optional, because fixed frame rate is disabled defaultly)
            -# Get input port from the render;
      -# Set the render to the pause state

    \code
    static ismd_result_t build_vidrend(void)
    {
      ismd_result_t ismd_ret;

      ismd_ret = ismd_vidrend_open(&vidrend_handle);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_vidrend_open\n");
         assert(0);
      }
      ismd_ret = ismd_vidrend_set_video_plane(vidrend_handle, GDL_PLANE_ID_UPP_C);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_vidrend_set_video_plane\n");
         assert(0);
      }
      ismd_ret = ismd_vidrend_set_interlaced_display_rate(ISMD_VIDREND_INTERLACED_RATE_59_94);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_vidrend_enable_max_hold_time\n");
         assert(0);
      }
      ismd_ret = ismd_vidrend_enable_max_hold_time(vidrend_handle, 10, 1);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_vidrend_enable_max_hold_time\n");
         assert(0);
      }
      ismd_ret = ismd_vidrend_disable_fixed_frame_rate(vidrend_handle);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_vidrend_disable_fixed_frame_rate\n");
         assert(0);
      }
      ismd_ret = ismd_vidrend_set_flush_policy(vidrend_handle, ISMD_VIDREND_FLUSH_POLICY_DISPLAY_BLACK);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_vidrend_set flush policy\n");
         assert(0);
      }
      ismd_ret = ismd_vidrend_get_input_port(vidrend_handle, &vidrend_input_port_handle);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_vidrend_get_input_port\n");
         assert(0);
      }

      ismd_dev_set_state(vidrend_handle,ISMD_DEV_STATE_PAUSE);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state\n");
         assert(0);
      }

      return ISMD_SUCCESS;
    }

    \endcode

\anchor SystemComp2
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">6A.2  Clock Allocation and Assignment</h2>
   In this stage, one clock will be created and assigned to each component to make sure every component can work by referencing one unique clock.
   Pseudo code for this stage:
   -# Alloc one clock object;
   -# Make the clock primary;   //for render
   -# Assign the clock for audio processor, demux and video render;
\code

static ismd_result_t build_clock(void)
{
   ismd_result_t ismd_ret;

   ismd_ret = ismd_clock_alloc(ISMD_CLOCK_TYPE_FIXED, &clock_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_clock_alloc\n");
      assert(0);
   }

   ismd_ret = ismd_clock_make_primary(clock_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_clock_make_primary\n");
      assert(0);
   }

   ismd_ret = ismd_clock_set_vsync_pipe(clock_handle, 0);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_clock_set_vsync_pipe\n");
      assert(0);
   }

   return ISMD_SUCCESS;
}

static ismd_result_t assign_clock(uint16_t pcr_pid)
{
   ismd_result_t ismd_ret;

   pcr_pid = 0;

   ismd_ret = ismd_dev_set_clock(audio_handle, clock_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_dev_set_clock\n");
      assert(0);
   }
   ismd_ret = ismd_dev_set_clock(demux_stream_handle, clock_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_dev_set_clock\n");
      assert(0);
   }
   ismd_ret = ismd_dev_set_clock(vidrend_handle, clock_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_dev_set_clock\n");
      assert(0);
   }

   ismd_ret = ismd_demux_stream_use_arrival_time(demux_stream_handle, false);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_demux_stream_use_arrival_time\n");
      assert(0);
   }


   return ISMD_SUCCESS;
}



\endcode
\anchor SystemComp3
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6A.3 Pipeline Connection</h2>
   In this stage, connect all the components to create an integrated pipeline.
   Pseudo code for this stage:
   -# Connect the audio ES output port of demux to the input port of the audio processor;
   -# Connect the video ES output port of demux to the input port of the video decoder;
   -# Connect the output port of video decoder to the input port of the DPE;
   -# Connect the output port of the DPE to the input port of the render;

   \code
   static ismd_result_t connect_pipeline(void)
   {
      ismd_result_t ismd_ret;

      ismd_ret = ismd_port_connect(ts_aud_output_port_handle, audio_input_port_handle);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_port_connect, ts_aud to audio\n");
         assert(0);
      }

      ismd_ret = ismd_port_connect(ts_vid_output_port_handle, viddec_input_port_handle);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_port_connect, ts_vid to viddec\n");
         assert(0);
      }

      ismd_ret = ismd_port_connect(viddec_output_port_handle, vidpproc_input_port_handle);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_port_connect, viddec to vidpproc\n");
         assert(0);
      }

      ismd_ret = ismd_port_connect(vidpproc_output_port_handle, vidrend_input_port_handle);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_port_connect, vidpproc to vidrend\n");
         assert(0);
      }

      return ISMD_SUCCESS;
}
   \endocde

anchor SystemComp4
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> Timing Initialization</h2>
   As what has been described previously in the SMD Core chapter, the Intel SMD adopts the concept of segment and basetime to arrange normal playback on time, so the segment related time value must be initialized before starting the pipeline.
   Pseudo code for initialize the timing:
   -# Set the basetime of demux, audio input and video render to be current time;
   -# Set newsegment linear_start to be 0;
   -# Set newsegment start/stop of segment to be -1;
   -# Set newsegment rate to be normal rate;
   -# Call ismd_tag_set_newsegment() interface to set newsegment in a buffer
   -# Send the buffer containing the new segment information to demux through the input port of demux by ismd_port_send() interface

\anchor SystemComp5
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> Pipeline Start</h2>

   Performing the prior four steps, the necessary preparation for a simple video playback pipeline has been completed. The only thing left is to start the pipeline.  For any kind of pipeline, file pipeline or TSIN pipeline, make sure the source, file or TSIN module is started before starting the whole pipeline.
   Be careful with the sequence issue, if it�s a TSIN (Tuner) pipeline, start the demux component first to buffer a certain amount of data to avoid underrun before starting the decoder, audio input, vidpproc and video render components.
   Also, if the start of the pipeline is a bit later than the timing initialization stage, set the basetime to be the current time.
   Pseudo code for pipeline start:
   -# Set the render to be play status;
   -# Set the DPE to be play status;
   -# Set the decoder to be play status;
   -# Set the audio processor to be play status;
   -# Set the demux to be play status;
   -# After this stage is finished, the entire pipeline is ready to be used for the playback of a stream. Next, decide which type of source will be connected to the pipeline.

\code
static ismd_result_t start_pipeline(void)
{
   ismd_result_t ismd_ret;

   if (ptype != TSIN_PLAYBACK)
   {
      ismd_ret = ismd_dev_set_state(vidrend_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
            printf("failed at ismd_dev_set_state, vidrend_handle to PLAY\n");
            assert(0);
      }
      ismd_ret = ismd_dev_set_state(vidpproc_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state, vidpproc_handle to PLAY\n");
         assert(0);
      }
      ismd_ret = ismd_dev_set_state(viddec_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state, viddec_handle to PLAY\n");
         assert(0);
      }
      ismd_ret = ismd_dev_set_state(audio_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state, audio_handle to PLAY\n");
         assert(0);
      }
      ismd_ret = ismd_dev_set_state(demux_stream_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state, demux_stream_handle to PLAY\n");
         assert(0);
      }
   }
   else
   {
      ismd_ret = ismd_dev_set_state(demux_stream_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state, demux_stream_handle to PLAY\n");
         assert(0);
      }
      ismd_ret = ismd_dev_set_state(tsi_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state, tsi_handle to PLAY\n");
         assert(0);
      }

      ismd_ret = ismd_dev_set_state(vidrend_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state, vidrend_handle to PLAY\n");
         assert(0);
      }
      ismd_ret = ismd_dev_set_state(vidpproc_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state, vidpproc_handle to PLAY\n");
         assert(0);
      }
      ismd_ret = ismd_dev_set_state(viddec_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state, viddec_handle to PLAY\n");
         assert(0);
      }
      ismd_ret = ismd_dev_set_state(audio_handle, ISMD_DEV_STATE_PLAY);
      if(ismd_ret != ISMD_SUCCESS) {
         printf("failed at ismd_dev_set_state, audio_handle to PLAY\n");
         assert(0);
      }

   }

   return ISMD_SUCCESS;
}

\endcode

\anchor SystemPlay
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> Various Playbck Modes</h2>


   \anchor SystemPlay1
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> File Playback</h2>

   As a file feeder, it should constantly send data into the demux to avoid underrun from occurring. At the same time, the feeder still needs to know when it should not send data to the demux to avoid overflow from occurring. When a feeder is designed, take both of the above concerns into account. The following is the pseudo code for a file feeder.
   Please note that this is a basic feeder which will not take into account exceptional situations such as end of file, etc.
   Pseudo code for a basic file feeder:
   -# Get a file handler ready (including open, seek etc);
   -# Determine the size of data chunk which is sent to demux. //attention, the size of data chunk is decided by the field smd_buffers_DMX_DESC1 in the memory_layout_xyz.cfg in /etc/platform
   -# Loop:
   -# Check whether or not input port of demux is full
   -# Case full:
          Wait until it�s not full;
   // there are two ways to implement the wait function, 1st is using the ismd_port_get_status() function, 2nd is using the event mechanism.
   -# Case other situations:
      -# Read one data chunk from the file;
       -# Allocate buffer
      -# Copy the data to the buffer;
      -# Init the buffer attribute such as the size of data;
      -# Send the data to the input port of demux
   -# Goto loop.

\anchor SystemPlay2
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6B.2  Tuner Playback</h2>
   Generally speaking, the pipeline is for tuner playback and is quite similar to that for file playback; however, there are still some obvious differences that must be noted:
      -# The transport stream source is the tuner, so an extra driver will need to be configured and the application will need to initialize the tuner, setting the frequency and bandwidth to make the tuner output the described TS stream.
      -# One more component will be introduced to the pipeline, which is TSIN (transport stream input) component.
      -# The four components (demux, decoder (a/v), vidpproc and video render) should not be started simultaneously. The demux should start first to get some stream data buffered to avoid underrun.

At the hardware level, the tuner/demodulator will be connected to NIM of the Intel� CE Media Processor. The output of the tuner is a transport stream.  The application will need to initialize the tuner using their tuner driver to lock the frequency and bandwidth of the tuner.

The tuner pipeline construction consists of the basic pipeline construction, plus the TSIN component being connected to the basic pipeline.  Perform the following jobs to finish the tuner pipeline construction:
   -# Construct the TSIN component
   -# Allocate filter for TS package, and set the right PCR, AUDIO_pid, video_pid to the TSIN
   -# Connect TSIN component to the basic pipeline
Pseudo code for constructing TSIN component:
-# Open the TSIN component with \ref ismd_tsin_open() interface;
-# Set the PCR_pid to the TSIN component with \ref ismd_demux_ts_set_pcr_pid()
-# Open TS package filter for the TSIN component; with \ref ismd_demux_filter_open();
-# Get output port from the filter with \ref ismd_demux_filter_get_output_port();
-# Map the pid to the filter with \ref ismd_demux_filter_map_to_pids();
-# Enable the clock recovery function to the TSI component with \ref ismd_demux_tsin_enable_clock_recovery()s
-# Set the TSIN component to be pause status;
-# Set the TSIN component to be stop status;

In the construction of the demux component, enable the clock_recovery for demux with the interface ismd_demux_tsin_enable_clock_recovery (demux_handle, pcr_pid).The clock assignment must still be modified to assign the clock to TSIN.
Pseudo code for connecting the TSIN component to the basic pipeline:
-# Connect the output of TSIN component to the input port of the demux component
Pre-buffering is required to ensure that the system has enough data to play audio and video without starving.  The trick is to keep the amount of buffering at the bare minimum that is required for your particular system.  Calculation of the exact amount of time that is necessary for system stability is hard to do mathematically.  Hard to measure items like thread scheduling, network jitter, etc make each system unique.  In addition, the codec requirements of the end system also play a factor as some audio and video codecs can operate with smaller amounts of data.
The function below is used to create some buffering in the pipeline:
\code  ismd_result_t SMDEXPORT ismd_demux_set_buffering_event(ismd_dev_t devhandle, ismd_event_t event, unsigned buffer_time); \endcode

The buffer_time variable is in 90 kHz clock ticks.  In the sample programs in the SDK, the buffer_time is set to 60,000 or 2/3 of a second.
This is really a conservative number; based on your specific system, this may be reduced.  It is recommended that the customer experiments, to see how low
this value can be set while not influencing playback.

When enabling buffering, the pipeline start will be divided into two stages; the first stage includes starting TSIN and demux and then buffering by setting them to pause. The second stage includes starting all the components in the pipeline. It is necessary to re-set the basetime based on the current clock time for all the components after buffering.
Pseudo code for buffering control and start pipeline:
-# Keep all the components paused;
-# Send buffering event by ismd_demux_set_buffering_event()
-# Wait for buffering complishment with interface ismd_event_wait_multiple()
-# If the event is the buffering event, acknowledge the event with ismd_event_acknowledge()
-# Set the buffering event to be invalid by ismd_demux_set_buffering_event()
-# Reset the basetime for all component to be current clock time.
-# start the whole pipeline.

\anchor SystemPlay3
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6B.3  UDP Playback</h2>
Playing TS streams from an IP network is almost the same as from local file system, except that the big network latency will be allowed and data may arrive in burst. Data is always available on local file system while the possibility that data from an IP network may come in later still exists. The main difference in implementation between file playback and UDP playback is as follows:
   -#  The source element is different.
   -#  File playback is pull mode. UDP playback is push mode.
    -#   Use VCXO as primary clock. Need a new component to handle clock recovery by adjusting frequency of VCXO.
   -#  Due to jitter during transmission on network, a queue is added between clock recovery and demux.
    -#  Enable underrun/overrun recovery.
Same to turner playback, the pipeline needs to buffer before it begins to play. Otherwise, it will enter underrun state. Channel change and PIP features have already supported.
\anchor SystemTrick
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Trick Modes</h2>
Trick modes are playback modes in which a stream is played at a different rate or in a different sequence than the normal, real-time rate for which it was created (i.e. 1X playback). Many trick mode operations require the ability to asynchronously seek to arbitrary locations within the original stream.
Since SMD does not control any trick mode inputs (e.g. file sources, VOD trick mode servers, etc.), it does not implement very many trick modes, directly. Instead, it provides driver-level controls that enable applications to implement trick modes.
This section discusses trick mode, seek mode and basic pause/resume functions for file playback. SMD is very flexible in how timing is managed in trick modes. Generally speaking, there are two ways to implement the trick mode switch. In this section, the Dynamic Rate Change will be the primary focus.


\anchor SystemTrick1
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Pause and Resume</h2>
   Pause/Resume is the basic operation for a working pipeline. On the Intel� CE Media Processor platform this feature may be implemented on file playback pipeline with ease.
   Pseudo code for Pause:
   -# Pause all the components in the pipeline;
   -# Save the original_basetime and original clocktime;
   -# Save current clock time as original_clocktime;
   Pseudo code for Resume:
   -# Get current_clocktime;
   -# Calculate the new basetime=original_basetime+(current_clocktime-original_clocktime) + offset;
   -# Set basetime for all the components.
   -# Restart all the components in turn(render, DPE, A/V decoder, demux and file feeder)

   Attention: the offset in the calculation of basetime is a workaround to conquer a bug in the audio component


\anchor SystemTrick2
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Fast Forward</h2>
Different methods are used to deal with different trick modes because of silicon performance limitations. Generally speaking, when the play rate is less than or equal to 2x trick mode, it will simply pause the entire pipeline. Modify the playrate and linear_rate_change_time of video render and audio component by using the interface ismd_dev_set_play_rate()
For trick mode >2x, it�s little different. Software needs to stop and flush the working pipeline, configure the audio to be disable by calling interface enable_disable_audio_primary_input(), set the video decoder to ignore B&P frames by calling ismd_viddec_set_frame_mask(), set a new basetime, initialize a new segment and restart the entire pipeline.
Following  rates are currently supported.
-# 1/8x, 1/4x,1/2x,1x,1.5x
-# 2x,4x,8x,16x

Pseudo code for <=2x and >=1x Trick switch and previous mode is <=2x:
-# pause all the component in the working pipeline;
-#If prev_mode < 1x mode, flush audio device; Get the current properties of the stream that is being played
-# If rate >=15000, width > 1280 and height > 720, set the scaling mode in video decoder to be ISMD_VIDDEC_HALF_HORIZONTAL
-# Otherwise, set the decoder to be ISMD_VIDDEC_SCALE_NONE;
-# Calculate current linear time;
-# Calculate new playing rate
-# Set the linear_rate_chage_time of be current linear time in the render;
-# Set the new playing rate to the video and render and audio component by ismd_dev_set_play_rate()
-# Calculate new basetime=original_basetime+(current_clocktime-original_clocktime) + offset; //offset can be 20000
-# Set the new basetime to all the component in the pipeline;
-# Start all the component in the working pipeline;\
<br>
<br>

Pseudo code for <1x trick mode,Pseudo code for >2x Trick mode switch
-# Set max frames for decoder by ismd_viddec_set_max_frames_to_decoder()
-# Disable fixed frame rate by ismd_vidrend_disable_fixed_frame_rate();
-# Enable audio by ismd_audio_input_enable();
-# Pause the file source;
-# pause all the component in the pipeline
-# Set flush policy for video render by ismd_vidrend_set_flush_policy();
-# Stop the demux component;
-# Flush pipeline including demux, A/V decoder, Vidpproc, vidrender;
-# Set frame mask for video decoder; (if new trick mode is 2x, new mask will be ISMD_VIDDEC_SKIP_NONE, otherwise ISMD_VIDDEC_SKIP_FRAME_TYPE_P|ISMD_VIDDEC_SKIP_FRAME_TYPE_B;
-# Set frame error policy for video decoder by ismd_viddec_set_frame_error_policy();
-# If new trick mode is 2x, enable the audio
-# Else disable the audio;
-# Configure the new base time for all the component to be current clock time;
-# Generate and initlize a new segment,
-# Allocate a buffer to be set with the new segment
-# Send the buffer to the input port of demux.
-# Start the file source
-# Start the pipeline;

\anchor SystemTrick3
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Seek </h2>
The implementation of seek mode is a bit different. It will not do much work on the basic pipeline. Instead, it mainly focuses on the file feeder. It will require that the file feeder provides a function to adjust the file pointer to point to the position that destination PTS resides.
Pseudo code for seek mode:
-# Pause the file feeder;
-# Calculate the new position in the file by the designated dest PTS;
-# Pause the pipeline;
-# Set flush policy for render to be ISMD_VIDREND_FLUSH_POLICY_REPEAT_FRAME by ismd_vidrend_set_flush_policy()
-# Stop the demux;
-# Flush the pipeline
-# Set the basetime for all components to be current clock time
-# Generate and initlize a new segment,
-# Allocate a buffer to be set with the new segment
-# Send the buffer to the input port of demux.
-# Restart the file feeders
-# Restart the entire pipeline.



\anchor SystemTrick4
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Sample Code Trick Mode </h2>

\code
#include "ismd_core.h"
#include "ismd_vidrend.h"
#include "ismd_core_protected.h"
#include "vbd.h"



// Renderer Data
typedef struct {
   ismd_dev_t rend;
   ismd_clock_t clock;
   ismd_time_t base_time;
   ismd_port_handle_t input_port;
   unsigned int plane;
   ismd_vidrend_test_params_t params;
   bool renderer_running;

   ismd_frame_polarity_t content_polarity;
   ismd_time_t content_rate; //frames or fields per second
   int effective_content_rate;
   int pts_increment;
   int width;
   int height;

   ismd_test_passing_criteria_t pass_criteria_number;
   vidrend_test_case_t test_case;
   vidrend_test_behavior_t behavior;
   unsigned int input_frame_count;
   int expected_frame_count;
   int flipped_frame_count;
   int port_frame_count;
   unsigned int TopUV_BottomUV_Diff;

   ismd_time_t current_time;

   ismd_buffer_handle_t buffer;
   bool test_failed_flag;
   unsigned int prev_top_uv_ptr;
   unsigned int prev_pts;
   unsigned int frames_written;
   ismd_pts_t max_pts;
   ismd_pts_t last_written_pts;
   int count_th_calls;

   ismd_event_t eos;
   ismd_event_t event_list[NUM_OF_EVENTS];
   unsigned int event_count[NUM_OF_EVENTS];
   bool event_thread_created;
   os_thread_t event_thread;
   ismd_vidrend_stats_t stats;
   ismd_vidrend_status_t status;
   bool events_test_completed;

   bool flush_eos;
   bool flush_play;
   bool flush_pause;
   bool flush_frame_repeated;
   ismd_pts_t frame_pts_after_flush;
   int flush_repeated_frames;
   int black_frames_flipped;
   bool flush_test_pass[2][4];

   os_event_t wait_to_input_event;
   os_event_t drop_event;
   os_event_t late_event;
   bool drop_frame;
   bool late_frame;
   bool waiting_to_input_late_frame;
   bool waiting_to_input_drop_frame;
   ismd_pts_t drop_frame_pts;
   ismd_pts_t late_frame_pts;

   bool state_change_thread_running;
   bool state_change_thread_created;
   bool renderer_paused;
   os_thread_t state_change_thread;
   ismd_time_t paused_clock_value;

   cc_test_type_t cc_test_case[18];
   int cc_text_index;
   bool was_prev_frame_late;
   bool was_prev_frame_drop;

   // for PTS Scaling
   bool rate_changed;
   int pts_rate;
   test_state_transitions state_transition;
   ismd_vidrend_stream_position_info_t position;
   int pts_frame_count;
   int calculated_rate;
   int multiplier;

   //Trick modes
   ismd_pts_t inband_scaling_rate;
   ismd_pts_t oob_scaling_rate;
   ismd_pts_t pts_before_trick_mode_change;
   bool enable_inband_scaling;

} test_rend_data_t;

//trick modes
typedef enum {
   FFR_IB_SCALING   = 1,
   IB_SCALING_FFR   = 2,
   FFR_OOB_SCALING  = 3,
   OOB_SCALING_FFR  = 4,
   IB_OOB_SCALING   = 5,
   OOB_IB_SCALING   = 6
} test_trick_mode_case_t;


//render instance
test_rend_data_t rend_data;
//trick mode types
test_trick_mode_case_t trick_mode_case = FFR_IB_SCALING;

rend_data.input_frame_count = 20;  //20 frames for test
rend_data.pts_rate = 30;           //for example
rend_data.effective_content_rate = 30; //for example
rend_data.pts_increment = VIDREND_CLOCK_FREQUENCY/rend_data.effective_content_rate;
rend_data.rate_changed = false;
rend_data.position.linear_time = 0;
// Trick modes Integration
rend_data.fixed_frame_rate_interval = (int) ((float)VIDREND_CLOCK_FREQUENCY / 29.97); //set the FFR to 29.97;
rend_data.inband_scaling_rate = 20000;
rend_data.oob_scaling_rate = 40000;
rend_data.pts_before_trick_mode_change = ISMD_NO_PTS;
rend_data.enable_inband_scaling = false;


//Configure video render
ismd_result_t configure_vidrend();
// Start video render
ismd_result_t start_vidrend();
//Release video render resource
ismd_result_t unconfigure_vidrend();
// Create frame buffer and write to input port
ismd_result_t frame_input (ismd_pts_t *pts, bool set_original_pts, int index);
//
bool fill_ip_port(void);


//Change the state of the renderer for changing the PTS Scaling rate.
ismd_result_t change_state_for_pts(pts_change_rend_state_t state)
{
    ismd_result_t result;
    ismd_time_t curr_time;

    switch (state)
    {
        case (PAUSE_CHANGE_PTS):
            if ((result = ismd_clock_get_time (rend_data.clock, &(rend_data.paused_clock_value))) != ISMD_SUCCESS)  {
               OS_PRINT("VR: ismd_clock_get_time failed: %d\n",result);
               return result;
         }
           //pause the renderer
           if((result = ismd_dev_set_state(rend_data.rend, ISMD_DEV_STATE_PAUSE)) != ISMD_SUCCESS) {
               OS_PRINT("VR: ismd_dev_set_state PAUSE failed: %d\n", result);
               return result;
           }
           rend_data.renderer_paused = true;
          break;

      case (CHANGE_PTS_PLAY):
           //get current time
           if ((result = ismd_clock_get_time (rend_data.clock, &curr_time)) != ISMD_SUCCESS)
           {
               OS_PRINT("VR:ismd_clock_get_time_failed: %d\n", result);
               return result;
           }
           //Calculate the new base time
           if (rend_data.renderer_paused == true)  {
               rend_data.base_time += (curr_time - rend_data.paused_clock_value);
           } else if (rend_data.renderer_running == false)  {
               rend_data.base_time = curr_time;
           }
           //set the new basetime
           result = ismd_dev_set_stream_base_time (rend_data.rend, rend_data.base_time);
           if (result != ISMD_SUCCESS) {
               OS_PRINT("VR: ismd_dev_set_base_time_failed: got %d\n", result);
               return result;
           }
           //restart the renderer
           if ((result = ismd_dev_set_state(rend_data.rend, ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
               OS_PRINT("VR: ismd_dev_set_state start failed: %d\n", result);
           }

           rend_data.renderer_running = true;
           break;
    }

    return (ISMD_SUCCESS);
}



//Creates thread to change the renderer status for play rate changes
ismd_result_t pts_rate_change(int rate)
{
    ismd_result_t result = ISMD_SUCCESS;

    // PLAY - PAUSE state change
    os_sleep ((unsigned long) 1);

    result = change_state_for_pts(PAUSE_CHANGE_PTS);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("VR: Error: Cannot perform transition from, play to pause state, ret = %d\n", result);
    }

    // get the current stream position
    result = ismd_vidrend_get_stream_position(rend_data.rend, &rend_data.position);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("Error: Cannot obtain the stream positon.\n");
        return result;
    }

    //change the rate
    result = ismd_dev_set_play_rate(rend_data.rend, rend_data.position.linear_time , rate);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("VR: The ismd_dev_set_play_rate does not return Success for PTS_Rate = %d.\n", rate);
        return result;
    }

    // PAUSE - PLAY state change
    os_sleep ((unsigned long) 1);

    result = change_state_for_pts(CHANGE_PTS_PLAY);
    if (ISMD_SUCCESS != result) {
        OS_PRINT("VR: Error: Cannot perform the transition from play to pause state, ret = %d\n", result);
    }

    return result;
}// end pts_rate_change()


//
int main(void)
{
    ismd_result_t result = ISMD_ERROR_UNSPECIFIED;

   /*initialize global setting: rend_data*/
   ;

    /*configuration video render*/
   result = configure_vidrend();

   /* set the hold time to 10 frames  - as a robustness measure against bas PTS valuse*/
    if((result = ismd_vidrend_enable_max_hold_time(rend_data.rend, 10, 1)) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_enable_max_hold_time failed: %d\n", result);
      return result;
    }

   /*start video render*/
   result = start_vidrend();

   /*write frame buffers into the input port*/
    fill_ip_port();

    /* Unconfigure video renderer*/
    result = unconfigure_vidrend();

   return 0;
}

//
ismd_result_t configure_vidrend()
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   //
   if((result = ismd_vidrend_open(&rend_data.rend)) != ISMD_SUCCESS) {
       OS_PRINT("vidrend_open failed: %d\n", result);
   }
   //
   if((result = ismd_vidrend_get_input_port(rend_data.rend,&rend_data.input_port)) != ISMD_SUCCESS)
   {
       OS_PRINT("vidrend_get_input_port failed: %d\n", result);
   }
   // Set video plane same as renderer instance
   rend_data.plane = 0;
   if((result = ismd_vidrend_set_video_plane(rend_data.rend,rend_data.plane)) != ISMD_SUCCESS)
   {
       OS_PRINT("ismd_vidrend_set_video_plane failed: %d\n", result);
   }
   // Set clock same as renderer instance
   rend_data.clock = rend_data.rend;
   // Set vsync pipeline A
   if((result = ismd_clock_set_vsync_pipe(rend_data.clock, 0)) != ISMD_SUCCESS)
   {
       OS_PRINT("ismd_clock_set_vsync_pipe failed: %d\n", result);
   }
   // Set clock
   if((result = ismd_dev_set_clock(rend_data.rend,rend_data.clock)) != ISMD_SUCCESS)
   {
       OS_PRINT("ismd_dev_set_clock failed: %d\n", result);
   }
   //Set display rate, i.e.ISMD_VIDREND_INTERLACED_RATE_59_94
   if((result = ismd_vidrend_set_interlaced_display_rate(ISMD_VIDREND_INTERLACED_RATE_59_94)) != ISMD_SUCCESS)
   {
       OS_PRINT("ismd_vidrend_set_interlaced_display_rate failed: %d\n", result);
   }
   //fixed frame rate is enabled
   if((result = ismd_vidrend_enable_fixed_frame_rate(rend_data.rend,rend_data.fixed_frame_rate_interval)) != ISMD_SUCCESS)
   {
       OS_PRINT("ismd_vidrend_enable_fixed_frame_rate failed: %d\n", result);
   }

   return result;
}

// Start video renderer
ismd_result_t start_vidrend()
{
    ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
    rend_data.base_time = rend_data.current_time;
    //
   result = ismd_dev_set_stream_base_time (rend_data.rend, rend_data.base_time);
    if(result != ISMD_SUCCESS ) {
        OS_PRINT("ismd_dev_set_base_time failed: got %d, expected %d\n", result, ISMD_SUCCESS);
        fflush( stdout );
        return (result);
    }
    //start the renderer
    if((result = ismd_dev_set_state(rend_data.rend,ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
        OS_PRINT("ismd_dev_set_state start failed: %d\n", result);
    } else {
        OS_PRINT("Renderer playing\n");
        rend_data.renderer_running = true;
    }

    return result;
} // end start_vidrend()

//
ismd_result_t unconfigure_vidrend()
{
    ismd_result_t result = ISMD_SUCCESS;
    // Renderer State = Stop
    result = ismd_dev_set_state(rend_data[rend_num].rend, ISMD_DEV_STATE_STOP);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("Error setting renderer state to stop %d\n", result);
    } else {
        OS_PRINT("Renderer Stopped\n");
    }

    if((result = ismd_dev_close(rend_data.rend)) != ISMD_SUCCESS) {
        OS_PRINT("vidrend_close failed: %d\n", result);
        return result;
    }

    return result;
} // end unconfigure_vidrend()


/* Create frame buffer and write to input port */
ismd_result_t frame_input (ismd_pts_t *pts, bool set_original_pts, int index)
{
    ismd_result_t result=ISMD_SUCCESS;
    ismd_buffer_descriptor_t desc;
    ismd_frame_attributes_t frame_attr;
   ismd_newsegment_tag_t newsegment_data;
    ismd_pts_t linear_time, over_head;
   ismd_pts_t offset = 10000;


   if (set_original_pts == true){
         frame_attr.original_pts = rend_data.pts_increment;
    } else if (rend_data.second_segment) {
         frame_attr.original_pts = frame_attr.original_pts + offset;
    }  else {
         frame_attr.original_pts = *pts;
    }

   /* Create a frame buffer */
    result = ismd_frame_buffer_alloc(rend_data.width, rend_data.height, &rend_data.buffer);
    if (result != ISMD_SUCCESS) {
        OS_PRINT( "ismd_frame_buffer_alloc, failed\n");
        OS_PRINT( "result: got %d, expected %d\n", result, ISMD_SUCCESS );
        fflush( stdout );
    }

   //populate frame attributes structure

    /* set the variable attributes based on the input */
    frame_attr.original_pts += rend_data.pts_increment;
    frame_attr.local_pts = frame_attr.original_pts;
    frame_attr->polarity = rend_data.content_polarity;
    //let y,u,v addresses be same as pts values for testing
    frame_attr.y      = frame_attr.local_pts;
    frame_attr.u      = frame_attr.local_pts;
    frame_attr.v      = frame_attr.local_pts;

    frame_attr.pixel_format    = ISMD_PF_NV16;
    frame_attr.gamma_type      = ISMD_GAMMA_NTSC;
    frame_attr.color_space     = ISMD_SRC_COLOR_SPACE_BT601;

    frame_attr.cont_rate       = 0;

    frame_attr.dest_size.width = rend_data[rend_num].width;
    frame_attr.dest_size.height= rend_data[rend_num].height;
    frame_attr.cont_pan_scan[0].horz_offset = 0;
    frame_attr.cont_pan_scan[0].vert_offset = 0;


    /* Read buffer desctriptor */
    result = ismd_buffer_read_desc(rend_data.buffer,&desc);
    if ( result != ISMD_SUCCESS ) {
        OS_PRINT("Error: Could not read buffer descriptor\n");
        return result;
    }

    /* Copy the frame attributes to buffer descriptor */
    memcpy (desc.attributes, &frame_attr, sizeof(ismd_frame_attributes_t));

    result = ismd_buffer_update_desc(rend_data.buffer, &desc);
    if ( result != ISMD_SUCCESS ) {
        OS_PRINT("Error: Could not update buffer attributes\n");
        return result;
    }

    if ( rend_data.enable_inband_scaling ) {
        /* set the linear time and send a new segment */
        over_head = rend_data.pts_increment + 500;
        linear_time = rend_data.position.linear_time + over_head;

        newsegment_data.linear_start   = linear_time;
        newsegment_data.start          = frame_attr.original_pts;
        newsegment_data.stop           = ISMD_NO_PTS;
        newsegment_data.requested_rate = rend_data.inband_scaling_rate;
        newsegment_data.applied_rate   = ISMD_NORMAL_PLAY_RATE;
        newsegment_data.rate_valid     = true;
        result = ismd_tag_set_newsegment(rend_data.buffer, newsegment_data);
        if (result != ISMD_SUCCESS) {
            OS_PRINT("Error: Could not set newsegment tag.\n");
            return result;
        }
    } else if ( set_original_pts && (trick_mode_case == IB_SCALING_FFR || case_num == IB_OOB_SCALING) ) {
        // The inband is originally enabled
        newsegment_data.linear_start   = 0;
        newsegment_data.start          = 0;
        newsegment_data.stop           = ISMD_NO_PTS;
        newsegment_data.requested_rate = rend_data.inband_scaling_rate;
        newsegment_data.applied_rate   = ISMD_NORMAL_PLAY_RATE;
        newsegment_data.rate_valid     = true;
        result = ismd_tag_set_newsegment(rend_data.buffer, newsegment_data);
        if (result != ISMD_SUCCESS) {
            OS_PRINT("Error: Could not set newsegment tag.\n");
            return result;
        }
    }

    /* Write buffer into the input port */
    result = ISMD_ERROR_UNSPECIFIED;
    while (result != ISMD_SUCCESS)
    {
        result = ismd_port_write(rend_data.input_port, rend_data.buffer);
        if(result != ISMD_SUCCESS) {
            os_sleep( (unsigned long)(1)); // sleep for 1 ms
        } else {
            rend_data.port_frame_count++;
        }
    }

    rend_data.last_written_pts = frame_attr.original_pts;
    rend_data.frames_written++;

    *pts = frame_attr.local_pts;

    return result;
} // end frame_input()


//
bool fill_ip_port(void)
{
    ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
    ismd_pts_t pts = rend_data.pts_increment;
    unsigned int index = 0;

    switch (trick_mode_case) {
        case FFR_IB_SCALING: // FFR set - Inband enabled after 3 frames
            result = ismd_vidrend_enable_fixed_frame_rate ( rend_data.rend, rend_data.fixed_frame_rate_interval );
            while (true)
            {
                if ( index == 4 ) {
                    /* Enable Inband Scaling*/
                    //while (rend_data[rend_num].flipped_frame_count < 3);
                    os_sleep((unsigned int)10);
                    result = ismd_vidrend_get_stream_position(rend_data.rend, &rend_data.position);
                    rend_num.enable_inband_scaling = true;
                    result = frame_input(&pts, false, index);
                } else {
                    rend_num.enable_inband_scaling = false;
                    result = frame_input(&pts, (index==0) ? true : false, index);
                }
              index ++;
                // EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
          break;
        case IB_SCALING_FFR: // Inband Scaling Enabled - Enable FFR after 3 frames
            result = ismd_vidrend_get_stream_position(rend_data.rend, &rend_data.position);
            while (true)
            {
                result = frame_input(&pts, (index==0) ? true : false, index);
                if (index == 3) {
                    result = ismd_vidrend_enable_fixed_frame_rate ( rend_data.rend, rend_data.fixed_frame_rate_interval );
                }
              index ++;
                //EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
          break;
        case FFR_OOB_SCALING: // Enable Fixed Frame Rate - Enable Out of Band Scaling
            result = ismd_vidrend_enable_fixed_frame_rate ( rend_data.rend, rend_data.fixed_frame_rate_interval );
            while (true) {
                result = frame_input(&pts, (index==0) ? true : false, index);
                if (index == 3) {
                    result = pts_rate_change(rend_data.oob_scaling_rate);
                }
              index ++;
              // EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
          break;
        case OOB_SCALING_FFR: // Enable OOB then Enable FFR after
            result = pts_rate_change(rend_data.oob_scaling_rate);
            while (true) {
                result = frame_input(&pts, (index==0) ? true : false, index);
                if (index == 3) {
                    result = ismd_vidrend_enable_fixed_frame_rate ( rend_data.rend, rend_data.fixed_frame_rate_interval );
                }
              index ++;
                // EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
          break;
        case IB_OOB_SCALING: // Enbale Inband Scaling - Enable oob Scaling
            while (true)
            {
                result = frame_input(&pts, (index==0) ? true : false, index);
                if (index == 3) {
                    result = pts_rate_change(rend_data.oob_scaling_rate);
                }
                index ++;
                // EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
          break;
        case OOB_IB_SCALING : // Enable oob scaling - Enable Inband Scaling
            result = pts_rate_change(rend_data.oob_scaling_rate);
            while (true)
            {
                if ( index == 4 ) {
                    /* Enable Inband Scaling*/
                    //while (rend_data[rend_num].flipped_frame_count < 3);
                    os_sleep((unsigned int)10);
                    rend_data.enable_inband_scaling = true;
                    result = frame_input(&pts, false, index);
                } else {
                    rend_data.enable_inband_scaling = false;
                    result = frame_input(&pts, (index==0) ? true : false, index);
                }
                index ++;
                // EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
          break;
    }

    rend_data.max_pts = pts;

    return true;
} // end fill_ip_port()


\endcode



\anchor SystemTrickTr
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6D Sample Code Trick Mode </h2>

SMD is very flexible in how timing is managed in trick modes. In general, SMD uses a newsegment "tag" to communicate rate changes "in-band".  This tag
contains information describing when the data following it should be played, and at which speed it should be played.  The one exception to using newsegment
tags to initiate trick modes is the "Dynamic Rate Change" or out of band mode


\anchor SystemTrickTr1
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6D.1 Change Playback Speed </h2>

The following is a typical sequence for changing the playback speed:

-# Stop the source feeding the pipeline.
-# Flush the pipeline to clear the data in all the devices. Call
\ref ismd_dev_flush on devices in the order in which the data flows -
starting from the demux, viddec, vidpproc, vidrend, audio.
-# Insert a new segment tag at the beginning of the pipeline -
   -# Allocate a zero sized buffer. Call \ref ismd_buffer_alloc with size 0
   -# Create a new segment tag of type \ref ismd_newsegment_tag_t - the
requested rate should be the normalized trick mode rate
   -# Assign the tag to the buffer. Call \ref ismd_tag_set_newsegment with
buffer id and tag details.
   -# Write it to the input port of the first element in the pipeline, typically
the demux.
-# Set the frame mask in the viddec to mask P and B frames by calling
\ref ismd_viddec_set_frame_mask. A special case of frame masking is I-frame
only trick modes, where all non-reference frames are dropped by the video decoder.
-# Pause the pipeline. Call \ref ismd_dev_set_state on all the devices with
state ISMD_DEV_STATE_PAUSE.
-# Recalculate and set the correct basetime on all devices that need it.
Call \ref ismd_dev_set_stream_base_time. The basetime can be calculated by
the formula:
     new_base_time = (current_time - initial_localized_pts in the new segment tag)
-# Restart the pipeline. Call \ref ismd_dev_set_state on all devices with
state ISMD_DEV_STATE_PLAY.

Another important point is that if data is being fed discontiguously (such as
reverse or I-frame modes) the discontinuity flag should be set at the points
that represent a break in the input data (between GOPs in reverse, for instance).
This will cause the viddec to discard old reference frames to prevent macroblocking.
This can be done by setting the discontinuity flag in the buffer descriptor's
ES attributes to "true" before sending the buffer to the demux input.



\anchor SystemTrickTr2
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6D.2 Dynamic Rate Change </h2>
This mode can be used if the direction of playback is not changing and the
format of the input does not change.  This mode gives the smoothest trick mode
transition experience as it does not require to flush the pipeline and rebuffer
before the transition to the new playback speed.

To use this mode the following must apply:

-# Playback must not change direction (forward to forward or reverse to reverse only).
-# The input structure is not changing.  For example, if going from a mode that
plays all GOPs to one where the source only supplies every other GOP, a flush must
be used.
-# The video decoder frame masking is not changing.
-# Once this mode is activated the renderers ignore rate changes communicated in
newsegment tags.  The other fields in the newsegment tags are still used.

The sequence of operations is as follows:
-# Optionally enable the viddec downscaler, if using high rates on HD content (to
ease workload on vidpproc)
-# Pause pipeline by calling \ref ismd_dev_set_state on all the devices with state
ISMD_DEV_STATE_PAUSE.
-# Get the stream position from the video renderer by calling
\ref ismd_vidrend_get_stream_position
-# Set the play rate on the renderers by calling \ref ismd_dev_set_play_rate
-# Set base time to (current time - current scaled PTS)
-# Restart the pipeline. Call \ref ismd_dev_set_state on all devices with state
ISMD_DEV_STATE_PLAY.

\anchor SystemTrickTr3
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6D.3 Fixed Frame Rate Playback </h2>


   The video renderer (vidrend) allows fixed frame-rate playback (PTS values ignored)
   which may be simpler to use for some faster trick modes or for reverse I-frame
   trick modes.  Note that audio should be disabled when using this feature
   (automatically happens for faster trick modes and reverse playback). To enable
   fixed framerate playback the video renderer's \ref ismd_vidrend_enable_fixed_frame_rate()
   function is used to set the rate, and \ref ismd_audio_input_disable() to
   disable audio. The rate is expressed as the number of 90kHz ticks that
separate the frames.



\anchor SystemTrickTr4
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6D.4 Partial GOP Decode </h2>
   The video decoder (viddec) supports an option to only decode an arbitrary number
   of frames, N, from a segment of data, where N can be configured through
   \ref ismd_viddec_set_max_frames_to_decode().  This can be used in conjunction
   with fixed frame-rate and sourcing a subset of the input file to create a
   fast forward "bursty" trick mode effect that looks smoother than simple frame
   masking in some instances (dependent on the content motion).

   The sequence of operations is:
   -# Stop the source feeding the pipeline.
   -# Flush the pipeline to clear the data in all the devices. Call
   \ref ismd_dev_flush on devices in the order in which the data flows -
   starting from the demux, viddec, vidpproc, vidrend, audio.
   -# Insert a new segment tag at the beginning of the pipeline -
      -# Allocate a zero sized buffer. Call \ref ismd_buffer_alloc with size 0.
      -# Create a new segment tag of type ismd_newsegment_tag_t - the requested
   rate should be the normalized trick mode rate.
      -# Assign the tag to the buffer. Call \ref ismd_tag_set_newsegment with
   buffer id and tag details.
      -# Write it to the input port of the first element in the pipeline, maybe
   the demux.
   -# Configure the video decoder:
      -# Set the frame mask, \ref ismd_viddec_set_frame_mask.
      -# Set the maximum frames to decode, \ref ismd_viddec_set_max_frames_to_decode.
      -# And set error concealment, \ref ismd_viddec_set_frame_error_policy.
   -# Enable or disable fixed-framerate mode in the video renderer,
   \ref ismd_vidrend_enable_fixed_frame_rate or \ref ismd_vidrend_disable_fixed_frame_rate.
   -# Enable or disable audio, \ref ismd_audio_input_disable or
   \ref ismd_audio_input_enable.
   -# Configure the filesource as desired.
   -# Pause the pipeline, set the base time to the current time, and resume playback.

   The other important aspect of this functionality is how the data is sourced.
   A file source is required to set the input buffer ES attributes' discontinuity
   flag for each new data unit sourced through the pipline.  This flag
   being set does a few important things:
   -# Causes the viddec to flush all reference frames and halt decoding until
   the next reference frame is found
   -# Causes the viddec to reset its frame counter for the partial-GOP decode
   feature, so it starts decoding again until the count is reached.
   -# Causes the demux to abstain from sending a newsegment tag when the actual
   discontinuity is encountered.

\anchor SystemTrickTr5
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6D.5 Smooth Reverse Trick </h2>
In addition to I-frame trick modes to accomplish reverse playback, the viddec
supports reversing the frames in a GOP to get a smoother reverse effect.
The GOPs must be fed in reverse order relative to each other for this
functionality to work. This mode is triggered automatically whenever the
newsegment contains a negative rate AND the video renderer is configured
in fixed frame rate mode. See <A HREF="#Fixed_Framerate_Playback">Fixed frame-rate Playback</A>.

Due to the amount of video memory required to store decoded frames for reversal,
the video decoder (viddec) is designed with an upper limit of 18 frames for MPEG2 within a
video segment.  H264 is limited to 10 and VC1 max is 15.  Therefore, to enable smooth reverse trick mode,
the viddec needs to be configured using \ref ismd_viddec_set_max_frames_to_decode to set the maximum
number of frames to decode. If the value (max_frames_to_decode) specified by
an application is greater than 18, the decoder will default to 18 for GOP reversal.
The remaining frames within that video segment will be dropped until the next video
segment is received.

It is important that the application sets a discontinuity flag at the points
that represent a start of a new video segment. This tells the decoder to output
the reversed frames buffered from that segment. The discontinuity flag can be
set in the buffer descriptor's ES attributes to "true" before sending the buffer
to the demux input.

To transition from normal playback to smooth reverse trick mode:

-# Stop the source feeding the pipeline.
-# Flush the pipeline to clear the data in all the devices. Call
\ref ismd_dev_flush on devices in the order in which the data flows -
starting from the demux, viddec, vidpproc, vidrend, audio.
-# Insert a new segment tag at the beginning of the pipeline with a negative rate.
-# Configure the video decoder:
   -# Set the frame mask, \ref ismd_viddec_set_frame_mask.
   -# Set the maximum frames to decode, \ref ismd_viddec_set_max_frames_to_decode.
   -# And set error concealment, \ref ismd_viddec_set_frame_error_policy.
-# Enable fixed-framerate mode in the video renderer,
\ref ismd_vidrend_enable_fixed_frame_rate. Note that future versions of the software
will not require fixed frame rate when enabling smooth reverse trick modes.
-# Disable audio \ref ismd_audio_input_disable.
-# Configure the filesource to feed data to the pipeline in reverse order.
-# Pause the pipeline, set the base time to the current time, and resume playback.

To transition from smooth reverse trick modes to normal playback:

-# Stop the source feeding the pipeline.
-# Reset the number of frames to decode on video decoder by calling
\ref ismd_viddec_set_max_frames_to_decode using ISMD_VIDDEC_ALL_FRAMES.
-# Disable fixed frame rate mode on video renderer by calling
\ref ismd_vidrend_enable_fixed_frame_rate.
-# Enable audio by calling \ref ismd_audio_input_enable.
-# Flush the pipeline to clear the data in all the devices. Call
\ref ismd_dev_flush on devices in the order in which the data flows -
starting from the demux, viddec, vidpproc, vidrend, audio.
-# Insert a new segment tag at the beginning of the pipeline with a negative rate.
-# Configure the filesource to start feeding data forward.
-# Pause the pipeline, set the base time to the current time, and resume playback.

\anchor SystemTrickTr6
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6D.5 Single Frame Step </h2>

This mode can step frames one by one when the pipeline is paused. This is done
by telling the video renderer (vidrend) and audio renderer (audio) to advance to the
next frame in forward or backward direction.
The sequence of operations is as follows:
-# Pause pipeline by calling \ref ismd_dev_set_state on all the devices with state
ISMD_DEV_STATE_PAUSE.
-# Get the stream position from the video renderer by calling
\ref ismd_vidrend_get_stream_position (or from audio renderer by calling
\ref ismd_audio_input_get_stream_position).
-# Advance to the next frame by calling
\ref ismd_vidrend_advance_to_pts on video renderer or \ref ismd_audio_input_advance_to_pts
on audio renderer.
-# To advance to another frame, the application should repeat the above step.
To resume normal playback, the application should follow below programming sequence:
-# Query the current clock time using \ref ismd_clock_get_time.
-# Adding a new variable to the recalculation of base time.
The base time is normally incremented by the amount of time the clock ran and decremented
by the amount of media that was played in the paused state.
-# Update both the video and audio renderers base time by calling
\ref ismd_dev_set_stream_base_time.
-# Restart the pipeline. Call \ref ismd_dev_set_state on all devices with state
ISMD_DEV_STATE_PLAY.
Note: This can be used during forward and reverse playback.
If reverse frame advance is desired, first put the system into reverse mode and
flush the pipeline. Direction changes (step forward,
then back, then forward again) would require a pipeline flush, newsegment to set the correct
play rate/direction, and a reconfiguration of the smart source.



\anchor SystemSync
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6E Achiveing A/V Sync </h2>

The following is a typical sequence for enabling synchronized audio/video
presentation timing:

Setting up a synchronized pipeline:
-# Allocate a new clock using \ref ismd_clock_alloc.
-# Lock the audio and video outputs to the clock using \ref ismd_clock_make_primary.
-# If the display supports multiple output pipes/timing generators, use
\ref ismd_clock_set_vsync_pipe to specify which display pipe should be
used for video presentation timing. Internally, the clock will capture the time
of every VSYNC for the specified display pipe.
-# Set all of the modules in the pipeline to use the new clock using
\ref ismd_dev_set_clock.
-# Configure the video decoder to interpolate a PTS value for pictures that
do not have have a PTS in the original stream using
\ref ismd_viddec_set_pts_interpolation_policy.
-# When adding the audio processor input to be used for playing the audio
portion of the stream, be sure to create a "timed" input by setting the
"timed_stream" parameter of \ref ismd_audio_add_input_port.

Starting playback:
-# Calculate the time to start playback by 1) reading the current time using
\ref ismd_clock_get_time and 2) adding a small amount of time to account for
the time required to set the base time on all of the pipeline elements.
-# Set the start time calculated above on all of the pipeline modules by calling
\ref ismd_dev_set_stream_base_time.
-# Set all of the pipeline modules into the ISMD_DEV_STATE_PLAY state using
\ref ismd_dev_set_state.

\anchor SystemDual
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6F Dual Stream </h2>
SMD provides capibilities to decode multiple streams, one use case is to display
two (or more) video streams on the display while playback of one audio is heard.
This example will decode two streams and display the video of the second stream in
a small window overlaid on top of the first (Picture in Picture) while listening to
the primary stream audio.

\dot
digraph PIP {
  rankdir="LR";
  subgraph PipelineA {
    label = "Pipeline A";
    color = "orange";
    Demux [shape="Msquare"];
    Viddec [shape="doubleoctagon", labelURL="group__ismd__viddec.html", tooltip="the best driver in SMD"];
    Vidpproc [shape="box"];
    Vidrend [shape="box"];

    Demux -> input0[label="Audio ES",color = "orange"];
    Demux -> Viddec[label="Video ES",color = "orange"];
    Viddec -> Vidpproc[label="NV12 4:2:0",color = "orange"];
    Vidpproc -> Vidrend[label="NV16 4:2:2",color = "orange"];

    Demux -> input1[label="Audio ES",color = "turquoise1"];
    Demux -> Viddec[label="Video ES",color = "turquoise1"];
    Viddec -> Vidpproc[label="NV12 4:2:0",color = "turquoise1"];
    Vidpproc -> Vidrend[label="NV16 4:2:2",color = "turquoise1"];
  }

  subgraph Audio {
      rankdir="LR";
      subgraph clusterAudio {
        label = "Audio";
        audio_cloud [shape = "egg"];
        input0 -> audio_cloud[color = "orange"];
        input1 -> audio_cloud[arrowhead="tee", label="mute", color = "red", fontcolor = "red"];
        audio_cloud -> output0[color = "orange"];
      }
      output0 -> o0[color = "orange"];
      o0 [label="",shape=circle,height=0.12,width=0.12];
    }

  in_0[color = "orange"];
  in_0 -> Demux [label="TS/PS in",shape=circle,height=0.12,width=0.12, color = "orange"];
  Vidrend -> Display [label="VBD UPP_A",color = "orange"];

  in_1[color = "turquoise1"];
  in_1 -> Demux [label="TS/PS in",shape=circle,height=0.12,width=0.12, color = "turquoise1"];
  Vidrend -> Display [label="VBD UPP_B",color = "turquoise1"];
}
\enddot

-# Follow the same steps in <A HREF="#AV_Synch"><B>Audio/Video Synchronization</B></A> for the first pipeline, use UPP A for video.
-# For the second pipeline, change the following
   -# Use another universal pixel plane (UPP) example UPP_B for display output.
   -# Do NOT call \ref ismd_clock_make_primary.
   -# Mute or disable the audio input.
   -# Setup the vidpproc to downscale the video (optionally use the viddec horizontal downscaling).
   -# Position the scaled video on the display plane using x and y offsets (be sure to stay inbounds for the target areas).
-# Follow the same steps in <A HREF="#AV_Synch"><B>Audio/Video Synchronization</B></A> for Starting playback for each stream.
<H3> To PIP Swap </H3>
-# The pipelines should not need to change to do PIP swap.
-# Video Swap:
   -# Swap the output scale factors and possibly other settings of Viddec
   -# Swap the output scale factors and possibly other settings of Vidpproc
   -# Swap the display planes of Vidrend
-# Audio Swap:
   -# Disable and flush (or mute) the input that is being swapped to PIP display
   -# Enable (or unmute) the input that is being swapped to the main display
   -# tbd - more to do here
-# Clock Swap:
   -# Call \ref ismd_clock_reset_primary on the pipeline that is being swapped to PIP display
   -# Call \ref ismd_clock_make_primary on the pipeline that is being swapped to main display

\anchor PSI_parsing
<H2>Turn on and setup section filters for PSI parsing</H2>
\addindex PSI filtering
Review the MPEG specification for how to do PSI parsing.
Suggested steps for PSI parsing and retrieve the PSI tables: (Review the \ref ismd_demux "demux api" for specifics.)

-# Open filter using ismd_demux_filter_open()
-# Open section filter using ismd_demux_section_filter_open()
-# Set mask, see ismd_demux_section_filter_set_params()

Note: One can also create events to trigger on filter output using ismd_event_alloc() with ismd_demux_filter_get_output_port() and ismd_port_attach().

Sample code for the above is available in ../smd_sample_apps/common_utils/psi_handler/psi_handler.c::init_psi_context().

\anchor SystemEvents
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6G Pipeline Asynchronous Events </h2>
Once a pipeline is active there are several system-level events that can be monitored for status and notification of errors.
Monitoring these is not required for basic playback but they can be used for error recovery for when the unexpected happens.

\anchor SystemEvents1
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6G.1 Critical Error </h2>
The SMD Critical Error event is exposed by the SMD Core.  This event is triggered by any of the SMD drivers when they
detect an error that impacts all streams.  An example would be a loss of communication with embedded firmware.
Generally, the state of the system cannot be guaranteed if such an error is detected.  memory corruption may have taken place.
It is best to restart the system to get back to a known state when this happens.

To listen for this event, one needs to allocate an SMD event and register it with ismd_register_critical_error_event().
Multiple events (multiple listeners) can be concurrently registered in this way.

\anchor SystemEvents2
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6G.2 Buffer Allocation Failure </h2>
The SMD Buffer Allocation Failure event is exposed by the SMD Core.  This event is triggered when any ISMD buffer allocation fails.
This is an indication that the media subsystem doesn't have enough memory or the right memory configuration for the current use-case.
Memory allocation failures can impact all running streams.
The recommended course of action when this is detected is to shut down lower-priority streams.

To listen for this event, one needs to allocate an SMD event and register it with ismd_register_buffer_alloc_fail_event().
Multiple events (multiple listeners) can be concurrently registered in this way.

\anchor SystemEvents3
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6G.3 Overrun and Underrun </h2>
When push-mode playback is being used (such as a broadcast stream) there are events in the pipeline that can notify when buffering problems are encountered.
Underrun events signal that more buffering is needed, and overrun events signal when there is too much buffering and data is being dropped.
When not in push mode (file playback, for example) there is no need to monitor the buffering exceptions since the pipeline controls the rate of input (it "pulls" the data).

There are multiple places in each pipeline where underrun and overrun can occur.  Figure 2 below shows three pipeline types and where the events come from.
    \image html system_events_overrun_underrun.png Overrun and Underrun Event Locations

Sample code for the non-bufmon push pipe (assuming TSI)
\code

#include "ismd_core.h"
#include "ismd_global_defs.h"
#include "ismd_demux.h"
#include "ismd_audio.h"
#include "ismd_vidrend.h"

extern ismd_dev_t demux, vidrend, audio_input;
extern ismd_demux_filter_handle_t a_filter, v_filter;

ismd_event_t raw_overrun_event, raw_underrun_event;

// Overrun event(s)
// NOTE: If the demux and TSI are separate, use the TSI handle here instead
ismd_event_alloc(&raw_overrun_event);
ismd_tsin_set_overrun_event(demux, raw_overrun_event);

// If leaky demux filters are enabled, buffers will be dropped if the output
// ports get full.  The push source will never see an overrun because of this.
// Use the filters to report overrun in this case.
if (leaky_filters) {
   ismd_demux_filter_set_overrun_event(demux, a_filter, raw_overrun_event);
   ismd_demux_filter_set_overrun_event(demux, v_filter, raw_overrun_event);
}

// Underrun event
ismd_event_alloc(&raw_underrun_event);
ismd_dev_set_underrun_event(audio_input, raw_underrun_event);
ismd_dev_set_underrun_event(vidrend, raw_underrun_event);

// Play content here.
// Monitor raw_overrun_event and raw_underrun_event
// Teardown pipe when totally done

ismd_event_free(raw_underrun_event);
ismd_event_free(raw_overrun_event);

\endcode

Sample code for the bufmon push pipe (assuming TSI)
\code

#include "ismd_core.h"
#include "ismd_global_defs.h"
#include "ismd_demux.h"
#include "ismd_audio.h"
#include "ismd_vidrend.h"
#include "ismd_bufmon.h"

extern ismd_dev_t demux, vidrend, audio_input, bufmon;
extern ismd_demux_filter_handle_t a_filter, v_filter;

// These events are generated by the pipeline to signal bufmon
ismd_event_t raw_overrun_event, raw_underrun_event;

// These events are generated by bufmon
ismd_event_t bufmon_overrun_event, bufmon_underrun_event, bufmon_error_event;

// Setup overrun signaling to bufmon
ismd_bufmon_get_push_source_overrun_event(bufmon, &raw_overrun_event);
ismd_tsin_set_overrun_event(demux, raw_overrun_event);
// If UDP is used instead of TSI it must strobe raw_overrun_event when it
// drops packets due to its buffer being full.

// If leaky demux filters are enabled, buffers will be dropped if the output
// ports get full.  The push source will never see an overrun because of this.
// Use the filters to report overrun in this case.
if (leaky_filters) {
   ismd_demux_filter_set_overrun_event(demux, a_filter, raw_overrun_event);
   ismd_demux_filter_set_overrun_event(demux, v_filter, raw_overrun_event);
}

// Setup underrun signaling to bufmon
ismd_bufmon_add_renderer(bufmon, audio_input, &raw_underrun_event);
ismd_dev_set_underrun_event(audio_input, raw_underrun_event);
ismd_bufmon_add_renderer(bufmon, vidrend, &raw_underrun_event);
ismd_dev_set_underrun_event(vidrend, raw_underrun_event);

// Get event handles that bufmon signals us with
ismd_event_alloc(&bufmon_error_event);
ismd_event_alloc(&bufmon_overrun_event);
ismd_event_alloc(&bufmon_underrun_event);
ismd_bufmon_set_critical_error_event(bufmon, bufmon_error_event);
ismd_bufmon_set_overrun_event(bufmon, bufmon_overrun_event);
ismd_bufmon_set_underrun_event(bufmon, bufmon_underrun_event);

// Play content here.
// Monitor bufmon_error_event, bufmon_overrun_event and bufmon_underrun_event
//   bufmon_error_event   : pipeline needs restarting (overrun and underrun at same time)
//   bufmon_overrun_event : bufmon decreased buffering - no action needed
//   bufmon_underrun_event: bufmon increased buffering - no action needed
// Teardown pipe when totally done

ismd_event_free(bufmon_underrun_event);
ismd_event_free(bufmon_overrun_event);
ismd_event_free(bufmon_error_event);

\endcode

Sample code for the A/V capture pipe
\code

#include "ismd_core.h"
#include "ismd_global_defs.h"
#include "ismd_audio.h"
#include "ismd_vidrend.h"
#include "ismd_avcap_shim.h"

extern ismd_dev_t vcap, vidrend, audio_input;
externismd_audio_processor_t audio_proc;

ismd_event_t raw_overrun_event_v, raw_overrun_event_a, raw_underrun_event;

// Overrun events
ismd_avcap_shim_get_event_handle(vcap, ISMD_AVCAP_SHIM_EVENT_PORT_WRITE_ERROR, &raw_overrun_event_v);
ismd_audio_input_get_notification_event(audio_proc, audio_input, ISMD_AUDIO_CAPTURE_OVERRUN, raw_overrun_event_a);

// Underrun event
ismd_event_alloc(&raw_underrun_event);
ismd_dev_set_underrun_event(audio_input, raw_underrun_event);
ismd_dev_set_underrun_event(vidrend, raw_underrun_event);

// Play content here.
// Monitor raw_overrun_event_v, raw_overrun_event_a and raw_underrun_event
// Teardown pipe when totally done

ismd_event_free(raw_underrun_event);

\endcode

The recommended course of action to take when these events are detected depends on the pipeline.  The most basic action is to restart and rebuffer playback.
If the bufmon is in use then it handles underrun and overrun automatically by decreasing or increasing the clock value, respectively.
There is no need to do anything else.
The critical error event forwarded from the bufmon indicates that bufmon cannot correct the problem and playback should be restarted.

\anchor SystemEvents4
   <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 6G.4 Heartbeats </h2>
The audio and vidrend devices support events that will regularly strobe when audio/video is being played.
Clients can monitor these events.
If these events unexpectadly stop being strobed then it is a good indication that something is not working
and the pipeline should be restarted.
The audio "heartbeat" can be obtained with ismd_audio_input_get_notification_event, using event type ISMD_AUDIO_NOTIFY_DATA_RENDERED
The video "heartbeat" can be obtained with ismd_vidrend_get_frame_flipped_event

 */


