/*
* File Name: ismd_videnc.h
*/

/* 

  This file is provided under a dual BSD/GPLv2 license.  When using or 
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2011 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify 
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but 
  WITHOUT ANY WARRANTY; without even the implied warranty of 
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
  General Public License for more details.

  You should have received a copy of the GNU General Public License 
  along with this program; if not, write to the Free Software 
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution 
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE 

  Copyright(c) 2011 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without 
  modification, are permitted provided that the following conditions 
  are met:

    * Redistributions of source code must retain the above copyright 
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright 
      notice, this list of conditions and the following disclaimer in 
      the documentation and/or other materials provided with the 
      distribution.
    * Neither the name of Intel Corporation nor the names of its 
      contributors may be used to endorse or promote products derived 
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR 
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY 
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/
/*
*  Authors:  Video Encoder Software Team
*/

/** @weakgroup ismd_videnc Video Encoder

<H3>Overview</H3>

The SMD video encoder module provides hardware accelerated compression of 
decompressed video streams.
The following compression standards are supported:

- H.264 (supports High Profile up to Level 4.1)<br>
 
Video encode capabilities are exposed through a stream interface. For a given
stream, decompressed video frames are passed into the video encoder as input.
A compressed video elementary stream is emitted as output. Up to two instances
of the encoder may be opened at once, and streams are completely independent
entities. The actions/operations on one stream in the system will not affect
other streams that are running concurrently.

<H3>Input and Output Interfaces</H3>

The SMD videnc module interfaces are standard \ref smd_core "SMD Ports" where 
buffers may be read/written by the client or which may be connected to upstream
or downstream modules.

The SMD videnc module contains three port interfaces:

1) An input port that receives video frame buffers.<br>
2) An output port that emits encoded elementary stream buffers.<br>
3) A user data input port for inserting user data into the bitstream.<br> 

The port interfaces are per stream entities. That is, each stream will have its
own input, output, and user data ports. 

It should be noted that passing a NULL pointer or an invalid pointer (that 
points to invalid address space) is an application error. The behavior of the 
encoder in this case is to crash. Here, the kernel dump can be used to figure 
out which line of the code received the invalid pointer. The encoder shall not
return NULL pointer error message.

<H3>Events</H3>

In addition to data channels, the SMD videnc module provides applications with 
notification of encoder events asynchronously. The application can be notified 
when:

1) The encoder is out of memory.<br>
2) The input stream's resolution or frame rate has changed.<br>
3) The end of the stream was detected and encoded.<br>
4) There was a bitstream error detected.<br>

<H3>Theory of Operation</H3>

I. Setup/Intialization

-# Open a new stream using \ref ismd_videnc_open. Specify the type of video
compression you'd like to generate, init parameters for that codec 
and the maximum resolution expected on the input stream<br>  
-# Query the encoder for the input/output ports using \ref ismd_videnc_get_input_port and \ref ismd_videnc_get_output_port.<br> 
-# Set encoder policies and behaviors using the different control interfaces (use get functions to get the defaults for the
selected codec and parameters, and use set functions to change them).
-# For H.264: set the H.264 encoding parameters, by calling \ref ismd_videnc_h264_get_encoding_params to get the
default settings, change the desired parameters and call \ref ismd_videnc_h264_set_encoding_params <br>

-# Query the encoder for the EOS event using \ref ismd_videnc_get_event with the ISMD_VIDENC_EOS field.<br> 

II. Compression

-# Write video frame buffers into the encoder using \ref ismd_port_write.<br>
-# Read encoded stream via \ref ismd_port_read.<br> 
-# Wait for EOS event using \ref ismd_event_wait.<br>

III. Shutdown

-# Shutdown stream using \ref ismd_dev_close.<br>

*/
#ifndef __ISMD_VIDENC_H__
#define __ISMD_VIDENC_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "ismd_global_defs.h"
#include "ismd_videnc_h264_encoding_params.h"

/** @ingroup ismd_videnc */
/** @{ */

/** Number of concurrent streams allowed. 
 *  
 */ 
#define ISMD_VIDENC_MAX_STREAMS   2
                                          
/**
Events that the encoder can generate.
*/
typedef enum {
    ISMD_VIDENC_STREAM_PROPS_CHANGE   = 0x0, /**< Resolution or frame rate change */
    ISMD_VIDENC_EOS                   = 0x1, /**< End of stream reached */
    ISMD_VIDENC_CLIENT_ID_SEEN        = 0x2, /**< Client id seen */
    ISMD_VIDENC_ENCODER_ERROR         = 0x3, /**< An error was detected */
    ISMD_VIDENC_OUT_OF_RESOURCES      = 0x4, /**< Encoder is out of resources */
} ismd_videnc_event_t;

/**
Statistics collected from the encode process.
*/
typedef struct {
   unsigned long es_encoded;   /**< Total number of es buffers generated */
   unsigned long frames_encoded;   /**< Total number of frames encoded */
   unsigned long frames_dropped;   /**< Total number of frames dropped */
} ismd_videnc_stream_statistics_t;

/**
Parameters used for initializing the selected codec. 
*/
typedef union {
   ismd_videnc_h264_init_params_t   h264_init_params;	/**< Initial parameters for H.264 codec */
   //init params of other codecs to go here
} ismd_videnc_codec_init_params_t;

/**
Type of scan mode for encoder to use
*/
typedef enum 
{
   ISMD_VIDENC_SCAN_MODE_ENCODE_PROGRESSIVE = 0, /**< Encode as progressive */
   ISMD_VIDENC_SCAN_MODE_ENCODE_INTERLACED,      /**< Encode as interlaced */  
   ISMD_VIDENC_SCAN_MODE_ENCODE_PAFF             /**< Picture adaptive frame-field coding  */
} ismd_videnc_scan_mode_t;

/**
Bit-field of options to enable/disable when encoding interlaced input (options can be OR'ed)
*/
typedef enum 
{
   ISMD_VIDENC_INPUT_INTERLACED_FLAGS_NONE = 0,
   ISMD_VIDENC_INPUT_INTERLACED_FLAGS_DO_PULLDOWN = (1<<0)    /**< implement pulldown if relevant to input stream. Ignored if scan_mode=progressive. */
   //... = (1<<1)
   //... = (1<<2)
   //...
} ismd_videnc_input_interlaced_flags_t;

/**
Bit-field of options to enable/disable when encoding progressive input (options can be OR'ed)
*/
typedef enum 
{
   ISMD_VIDENC_INPUT_PROGRESSIVE_FLAGS_NONE = 0,
   ISMD_VIDENC_INPUT_PROGRESSIVE_FLAGS_HALVE_FRAME_RATE = (1<<0)    /**< e.g. 50p->25p */
   //... = (1<<1)
   //... = (1<<2)
   //...
} ismd_videnc_input_progressive_flags_t;

/**
Bit-field of options to enable/disable when encoding deinterlaced input (interlaced input that went through deinterlacing in the DPE). 
(options can be OR'ed).
*/
typedef enum 
{
   /** if encoding as progressive, can produce a double frame-rate output, using the original field rate (e.g. 50i->50p) */
   ISMD_VIDENC_INPUT_DEINTERLACED_FLAGS_NONE = 0,
   ISMD_VIDENC_INPUT_DEINTERLACED_FLAGS_DOUBLE_FRAME_RATE_PROGRESSIVE = (1<<0)
   //... = (1<<1)
   //... = (1<<2)
   //...
} ismd_videnc_input_deinterlaced_flags_t;

typedef struct 
{
   /** Interlaced input policies. H.264 encoder supports all encoding scan modes */
   ismd_videnc_scan_mode_t                     interlaced_input_encoding_scan_mode; 
   ismd_videnc_input_interlaced_flags_t        interlaced_input_flags;
   /** Progressive input policies. H.264 encoder supports progressive/PAFF encoding scan modes */
   ismd_videnc_scan_mode_t                     progressive_input_encoding_scan_mode;
   ismd_videnc_input_progressive_flags_t       progressive_input_flags;
   /** Deinterlaced input policies. H.264 encoder supports interlaced/progressive encoding scan modes */
   ismd_videnc_scan_mode_t                     deinterlaced_input_encoding_scan_mode;
   ismd_videnc_input_deinterlaced_flags_t      deinterlaced_input_flags;
} ismd_videnc_per_input_encoding_policies_t;

/******************************************************************************/
/*!    @name Video encoder device initialization and teardown APIs */

/**
Opens an available video encoder device.
All resources required for normal operation are allocated and the default
encoder capabilites are enabled. This operation must succeed for subsequent
encoder operations to be successful.

The video encoder instance is returned in the videnc handle. Multiple encoder
instances can be created by calling this function multiple times.

The video encoder device is destroyed using the standard Intel SMD close
function.

   @param [in] codec_type: Requested codec format. Supported formats are:
                           H.264.

   @param [in] codec_params: Basic parameters used to initialize the selected codec.
                             Other settings will be automatically initialized to 
                             defaults according to the basic parameters provided here.
 
   @param [in] frame_width: The maximum width expected on the input
                            frame buffer stream. 0 if this is unknown.
 
   @param [in] frame_height: The maximum height expected on the input
                             frame buffer stream. 0 if this is unknown.

   @param[out] videnc: Handle to the video encoder. Used in subsequent
                           calls to refer to a specific stream.

   @retval ISMD_SUCCESS: Video encoder handle is created successfully.
   @retval ISMD_ERROR_NO_RESOURCES: No encoder instance is available.
   @retval ISMD_ERROR_OPERATION_FAILED: Video encoder creation failed due to
                                    lack of system resources.
 */
ismd_result_t ismd_videnc_open(ismd_codec_type_t codec_type, ismd_videnc_codec_init_params_t *codec_params, 
                               uint32_t frame_width, uint32_t frame_height, ismd_dev_t *videnc);


/******************************************************************************/
/*!    @name Video encoder port interface */
/**
Gets the handle to video encoder input port.
Decompressed video frame buffers are written to the encoder through this port.

   @param[in] videnc: Handle to the video encoder
   @param[out] port : Input port handle

   @retval ISMD_SUCCESS : Stream input port is successfully returned.
   @retval ISMD_ERROR_INVALID_HANDLE : The specified encoder handle was invalid.
*/
ismd_result_t ismd_videnc_get_input_port(ismd_dev_t videnc,
                                         ismd_port_handle_t *port);

/**
Gets the handle to video encoder output port.
The video encoder writes compressed data to this port.

   @param[in] videnc: Handle to the video encoder.
   @param[out] port : Output port handle.

   @retval ISMD_SUCCESS : Stream output port is successfully returned.
   @retval ISMD_ERROR_INVALID_HANDLE : The specified encoder handle was invalid.
*/
ismd_result_t ismd_videnc_get_output_port(ismd_dev_t videnc,
                                          ismd_port_handle_t *port);

/**
Gets the handle to user data input port.
The application writes user data to this port. The timestamps of the incoming data are compared
to those of the input frames. Only matching timestamps will be inserted to the resultant stream.

   @param[in] videnc: Handle to the video encoder.
   @param[out] port : User data port handle.

   @retval ISMD_SUCCESS : Stream user data port is successfully returned.
   @retval ISMD_ERROR_INVALID_HANDLE : The specified encoder handle was invalid.
*/
ismd_result_t  ismd_videnc_get_user_data_port(ismd_dev_t videnc,
                                             ismd_port_handle_t *port);

/******************************************************************************/
/*!    @name Video encoder control interface */

/**
 *  start, stop, and flush operations use standard Intel SMD interface.
 */

/**
Sets encoding policies to be used according to the input type. 
This function must be called before entering play state.

   @param[in] videnc: Handle to the video encoder
   @param[in] policies: per input policies to be used by encoder

   @retval ISMD_SUCCESS: Successfully set the policies.
   @retval ISMD_ERROR_INVALID_HANDLE: The specified encoder handle was invalid.
   @retval ISMD_ERROR_INVALID_REQUEST: The command is invalid in the current encoder
                                       state
   @retval ISMD_ERROR_INVALID_PARAMETER: An invalid parameter was used
   @retval ISMD_ERROR_FEATURE_NOT_SUPPORTED: The requested settings aren't supported.
   @retval ISMD_ERROR_OPERATION_FAILED: FW failure.
 */
ismd_result_t ismd_videnc_set_per_input_encoding_policies(ismd_dev_t videnc, ismd_videnc_per_input_encoding_policies_t *policies);
/* Save info and return unsupported until firmware is ready
have to identify each frame if it's progressive, interlaced, or deinterlaced
tell the fw how to encode  based on the policies.
Currently use the default.
*/

/**
Gets encoding policies used by the encoder for handling different input types. 

   @param[in] videnc: Handle to the video encoder
   @param[out] policies: per input policies used by encoder

   @retval ISMD_SUCCESS: Successfully got the policies.
   @retval ISMD_ERROR_INVALID_HANDLE: The specified encoder handle was invalid.
 */
ismd_result_t ismd_videnc_get_per_input_encoding_policies(ismd_dev_t videnc, ismd_videnc_per_input_encoding_policies_t *policies);

/**
Determines whether or not to use the end of sequence indications from the 
input stream (received from viddec). This can be useful, for example, for slideshow content.  

   @param[in] videnc: Handle to the video encoder
   @param[in] reuse: true=reuse, false=do not reuse

   @retval ISMD_SUCCESS: Successfully set the parameter.
   @retval ISMD_ERROR_INVALID_HANDLE: The specified encoder handle was invalid.
   @retval ISMD_ERROR_INVALID_REQUEST: The command is invalid in the current encoder
                                       state
   @retval ISMD_ERROR_FEATURE_NOT_SUPPORTED: The requested settings aren't supported.
   @retval ISMD_ERROR_OPERATION_FAILED: FW failure.
   @retval ISMD_ERROR_INVALID_PARAMETER: An invalid parameter was used
 */
ismd_result_t ismd_videnc_set_reuse_input_end_sequence(ismd_dev_t videnc, bool reuse);

/**
Set whether or not the encoder reuses the end of sequence indications from the 
input stream (received from viddec). This can be useful, for example, for slideshow content.

   @param[in] videnc: Handle to the video encoder
   @param[out] reuse: true if reusing, false if not

   @retval ISMD_SUCCESS: Successfully read the parameter.
   @retval ISMD_ERROR_INVALID_HANDLE: The specified encoder handle was invalid.
 */
ismd_result_t ismd_videnc_get_reuse_input_end_sequence(ismd_dev_t videnc, bool *reuse);

/*!    @name Video encoder stream properties APIs */

/**
Get stream statistics of the encode process.

   @param[in] videnc: Handle to the video encoder
   @param[out] stat: Receive the stream statistics

   @retval ISMD_SUCCESS: Successfully read stream statistics.
   @retval ISMD_ERROR_INVALID_HANDLE : The specified encoder handle was invalid.
 */
ismd_result_t ismd_videnc_get_stream_statistics(ismd_dev_t videnc,
                                         ismd_videnc_stream_statistics_t *stat);


/******************************************************************************/
/*!    @name H.264 specific APIs */

/**
Set the parameters of the h264 encode process. To set the encoding parameters, first call
ismd_videnc_get_encoding_params to get the default or current settings, change the desired 
parameters and call ismd_videnc_set_encoding_params. 
Most parameters can only be changed when the encoder is not in the play state.
Parameters that can be changed also in the play state (on-the-fly changes, 
taking effect starting from the next frame): max_bitrate, bitrate.

   @param[in] videnc: Handle to the video encoder
   @param[in] settings: the encoding params

   @retval ISMD_SUCCESS: Successfully set the encoding params.
   @retval ISMD_ERROR_INVALID_HANDLE: The specified encoder handle was invalid.
   @retval ISMD_ERROR_INVALID_REQUEST: The command is invalid in the current encoder
                                       state or the specified encoder handle is not initialized for h264.
   @retval ISMD_ERROR_NO_SPACE_AVAILABLE: There isn't enough space to process the
                                          request. Try again later.
   @retval ISMD_ERROR_FEATURE_NOT_SUPPORTED: The requested settings aren't supported.
   @retval ISMD_ERROR_OPERATION_FAILED: FW failure.
   @retval ISMD_ERROR_INVALID_PARAMETER: An invalid parameter was used
 */
ismd_result_t ismd_videnc_h264_set_encoding_params(ismd_dev_t videnc,
                                         ismd_videnc_h264_encoder_params_t* params);

/**
Get the parameters of the h264 encode process.

   @param[in] videnc: Handle to the video encoder
   @param[out] params: Receive the encoding params

   @retval ISMD_SUCCESS: Successfully read the encoding params.
   @retval ISMD_ERROR_INVALID_HANDLE : The specified encoder handle was invalid.
   @retval ISMD_ERROR_INVALID_REQUEST : The specified encoder handle is not initialized for h264.
 */
ismd_result_t ismd_videnc_h264_get_encoding_params(ismd_dev_t videnc, 
                                         ismd_videnc_h264_encoder_params_t* params);


/******************************************************************************/
/*!    @name Video encoder asynchronous notification APIs */
/**
Gets the event associated with the given event condition.

   @param[in] videnc: Handle to the video encoder.
   @param[in] event_type: Requests the specific event associated with this
                     type.
   @param[out] event: Event that is signalled when the given condition occurs.

   @retval ISMD_SUCCESS: Requested event is returned successfully.
   @retval ISMD_ERROR_INVALID_HANDLE : The specified encoder handle was invalid.
   @retval ISMD_ERROR_INVALID_PARAMETER : The event type is invalid.
 */
ismd_result_t ismd_videnc_get_event(ismd_dev_t videnc,
                                    ismd_videnc_event_t event_type,
                                    ismd_event_t *event);


/** @} */ // end of ingroup ismd_videnc
/** @} */ // end of weakgroup ismd_videnc


#ifdef __cplusplus
}
#endif

#endif // __ISMD_VIDENC_H__
