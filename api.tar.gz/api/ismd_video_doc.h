/*

This file is provided under a dual BSD/GPLv2 license.  When using or
redistributing this file, you may do so under either license.

GPL LICENSE SUMMARY

Copyright(c) 2010 Intel Corporation. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
The full GNU General Public License is included in this distribution
in the file called LICENSE.GPL.

Contact Information:

Intel Corporation
2200 Mission College Blvd.
Santa Clara, CA  97052

BSD LICENSE

Copyright(c) 2010 Intel Corporation. All rights reserved.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in
the documentation and/or other materials provided with the
distribution.
* Neither the name of Intel Corporation nor the names of its
contributors may be used to endorse or promote products derived
from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



   /** @weakgroup new_smd_video  Chapter 5  SMD Video


     \anchor Contents
	 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 30pt"> SMD Video Chapter Contents</H2>
     - <A HREF="#ViddecIntro" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 5A Video Decoder Introduction</A>
     	- <A HREF="#ViddecFeatures">5A.1 Key Features</A>
     	- <A HREF="#ViddecInter">5A.2 Video decoder Interface</A>
     	- <A HREF="#ViddecCodecs">5A.3 Video Codecs</A>
     		- <A HREF="#ViddecCodecs1">5A.3.1 H.264</A>
     		- <A HREF="#ViddecCodecs2">5A.3.2  MPEG-2</A>
     		- <A HREF="#ViddecCodecs3">5A.3.3 MPEG4-Part2</A>



     	- <A HREF="#ViddecExamples">5A.4 Some Useful Examples</A>
     		- <A HREF="#ViddecEx1">5A.4.1 Connecting to Demux</A>
     		- <A HREF="#ViddecEx2"> 5A.4.2 PIP Horizontal Downscale</A>
     		- <A HREF="#ViddecEx3">5A.4.3 Sequence Display Extensions</A>
     		- <A HREF="#ViddecEx4">5A.4.4 User Data Handling</A>
     		- <A HREF="#ViddecEx5">5A.4.5 Smooth (partial-GOP) Trick Mode Playback</A>
     		- <A HREF="#ViddecEx6">5A.4.6 Smooth (partial-GOP)  Reverse Trick Mode Playback</A>
       		- <A HREF="#ViddecAdd1"> 5A.4.7 Stream Transitions</A>
     			- <A HREF="#ViddecAddmore1"> 5A.4.7 .1  Channel Change</A>
     			- <A HREF="#ViddecAddmore2"> 5A.4.7.2  End of Stream</A>

		- <A HREF="#ViddecNew"> 5A.5  Additional Features</A>
     		- <A HREF="#ViddecNew1"> 5A.5.1 3DBD Playback</A>
     		- <A HREF="#ViddecNew2"> 5A.5.2 3D AVC Playback</A>


     		- <A HREF="#ViddecTrick"> 5A.7 Trick Mode Operation</A>
     			- <A HREF="#ViddecTrick1"> 5A.7.1 Pause and Resume</A>
     			- <A HREF="#ViddecTrick2"> 5A.7.2 Single Frame Forward Step</A>
     			- <A HREF="#ViddecTrick3"> 5A.7.3 Single Frame Reverse Step</A>
     			- <A HREF="#ViddecTrick4"> 5A.7.4  Variable Speed Forward Playback</A>
     			- <A HREF="#ViddecTrick5"> 5A.7.5 Variable Speed Reverse Playback</A>
     			- <A HREF="#ViddecTrick6">5A.7.6 1X or slower smooth rewind for SD quality MPEG-2  </A>

     	- <A HREF="#SMDVideoAPI"> 5A.8 Reference to Video Decoder API's</A>


- <A HREF="#VidprocIntro" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 5B Video Postprocessor/Display Processing Engine(DPE)</A>
	- <A HREF="#Vidprocfeatures"> 5B.1 Key Features</A>
	- <A HREF="#VidprocDesign"> 5B.2 Sofware Components</A>
	- <A HREF="#Vidproccfg"> 5B.3 Configuring DPE</A>


	- <A HREF="#Vidproccon"> 5B.6 DPE Concepts</A>
		- <A HREF="#Vidproccon1"> 5B.6.1 Scaling Policies</A>
			- <A HREF="#Vidproccon1a"> 5B.6.1.1Scale to Fit</A>
			- <A HREF="#Vidproccon1b"> 5B.6.1.2 Zoom to Fit</A>
			- <A HREF="#Vidproccon1c"> 5B.6.1.3 Zoom to Fill</A>
			- <A HREF="#Vidproccon1e"> 5B.6.1.5 Anarmophic Scaling</A>
			- <A HREF="#Vidproccon1f"> 5B.6.1.6 Programmable Scaling Coefficient Table</A>
			- <A HREF="#Vidproccon2"> 5B.6.1.7 Input Cropping</A>
		- <A HREF="#vidproccon3"> 5B.6.2 De-interlacing</A>
		- <A HREF="#vidproccon3b"> 5B.6.3 Film Mode Detection Exposure</A>
		- <A HREF="#vidproccon4"> 5B.6.4 De-Ringing Filter</A>
		- <A HREF="#vidproccon5"> 5B.6.5 Gaussian  Noise Filter</A>
	    - <A HREF="#Vidprocnew1"> 5B.6.6 3D  Frame Handling</A>

- <A HREF="#SMDVideopAPI"> 5B.7 Reference to  DPE API's</A>


- <A HREF="#vidrend" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 5C Video Renderer</A>
	- <A HREF="#Vidrendfeatures"> 5C.1 Key Features</A>
	- <A HREF="#Vidrendfeatures"> 5C.2 Software Components</A>

	- <A HREF="#vidrendopnormal"> 5C.3  Some Useful Examples</A>
		- <A HREF="#vidrendopnormal1">   5C.3.1  Normal Playback</A>
			- <A HREF="#vidrendopnormal1a">   5C.3.1.1  Code Snippet for Normal Playback</A>
		- <A HREF="#vidrendopnormal1">   5C.3.2  Trick Mode : Pause and Resume</A>
		- <A HREF="#vidrendopnormal1">   5C.3.2  Trick Mode : Variable Speed Playback</A>
		- <A HREF="#vidrendopnormal1">   5C.3.3   Code Snippet for Trick Mode</A>

    - <A HREF="#vidrendcon"> 5C.4  Video Renderer Feature Description</A>
		- <A HREF="#vidrendcon1">   5C.4.1  Frequency Matching</A>
			- <A HREF="#vidrendcon1a">   5C.4.1.1 Code Snippet  Frequency Matching</A>
		- <A HREF="#vidrendcon2">   5C.4.2  Closed Caption</A>
			- <A HREF="#vidrendcon2a">   5C.4.2.1 Code Snippet  Closed Caption</A>
		- <A HREF="#vidrendcon3">   5C.4.3  Event Handling</A>
			- <A HREF="#vidrendcon3a">   5C.4.3.1 Code Snippet  Event Handling</A>
		- <A HREF="#vidrendcon4">   5C.4.4 Hold time</A>
			- <A HREF="#vidrendcon4a">   5C.4.4.1 Code Snippet Hold time</A>
		- <A HREF="#vidrendcon5">   5C.4.5 Stream Position</A>
			- <A HREF="#vidrendcon5a"> 5C.4.5.1 Code Snippet Stream Position</A>
		- <A HREF="#vidrendcon6">   5C.4.6 Video Mute</A>
		- <A HREF="#vidrendcon7">   5C.4.7 Stereo 3D Support</A>

 - <A HREF="#vidMo"> 5D   Video Mosaic </A>
 - <A HREF="#vidWater"> 5E   Video Watermarking </A>




   - <A HREF="#SMDVideorAPI"> 5C.5 Reference to  Video Renderer API's</A>



<br>
<br>
<br>
<br>

\anchor ViddecIntro
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 5A Video decoder Intorduction</h2>

The SMD Video decoder host software provides an application level interface to video codec accelerators on Intel's CE  SoCs. The Intel's CE Media Processor
contains HW video decode capabilities for many of the most common video formats in use today. The SMD Video decoder module provides hardware accelerated decode of video elementary streams.
The following standards are supported at hardware level for decode:
-# MPEG-1/MPEG-2 (MP@ML - MP@HL)
-# H.264 (supports High Profile up to Level 4.1)
-# VC-1  (Simple, Main, and Advanced Profile up to Level 3)
-# MPEG4- Part 2 (Simple profile Level 0 to Level 6 and Advanced Simple Profile Level 0 to Level 5). This is supported only by CE4100 and beyond (not supported by CE3100)
Video decode capabilities are exposed through a stream interface. For a given stream, compressed video data of a certain format is passed into the Video decoder
as input. Decompressed video frames (in NV12 format) are emitted as output. Up to two instances of the decoder may be opened at once, and streams are completely
independent entities. The actions/operations on one stream in the system will not affect other streams that are running concurrently.

The SMD Video decoder module interfaces are standard "SMD Ports" where buffers may be read or written by the client or which may be connected to upstream or downstream modules.  The SMD Video decoder module contains three port interfaces:
-# An input port that receives buffers containing ES data.
-# An output port that emits frame buffers that contain images for display.
-# A user data port that extracts user data from the bit stream and sends it to the application for processing.


<br>
<br>
<br>
<br>

\anchor ViddecFeatures
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 5A.1 Key Features</h2>

High level features for the SMD Video decoder include:
-# Elementary stream decoder interface for MPEG-2, H.264, and VC1 video streams. Codec formats are defined
-# Capable of decoding two HD quality streams simultaneously
-# Capable of decoding multiple lower resolution streams simultaneously, as supported by system resources

\image html videodecode1.png  Fig.2 SMD Video decoder interface

\anchor ViddecInter
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.2 Video decoder Interface</h2>

The Video decoder has two input interfaces: an input port (per stream) that takes incoming compressed bitstream data plus any associated metadata
(such as presentation timestamps) and a control interface that allows the client programmer to set, enable, and disable different decoder settings.
The output interface of the SMD decoder is decoded video frames stored in NV12 format, plus the attributes of the video frames that were extracted from the
bitstream during the decode process. User data found in the stream is output via a separate port. Events are sent by the decoder to the host to asynchronously
notify clients when certain decoder events occur.
<table border="1">
<caption>Table 1: Video decoder Interfaces </caption>
<tr>
<th style="color:black;background-color:blue;" >Interface</th> <th style="color:black;background-color:blue;" >Description</th> <th style="color:black;background-color:blue;" >Type i.e CTL,stream,event </th> <th style="color:black;background-color:blue;" >Notes</th>
</tr>
<tr>
<td> Input Port </td>	<td>  Receives compressed elementary stream data plus any additional metadata </td> <td> Stream	</td> <td>Input data is contained in ismd_buffers</td>
</tr>

<tr>
<td> Input Control Port </td>	<td>  Public methods exposed by the driver for decoder control </td> <td> Control	</td> <td>SMD Video decoder API</td>
</tr>

<tr>
<td> Output  Port </td>	<td>  Uncompressed video frames stored in NV12 format, with associated frame attributes </td> <td> Frame	</td> <td></td>
</tr>
<tr>
<td> Output  User Data Port </td>	<td>  User data found in bit stream </td> <td> User Data	</td> <td>SMD Video decoder does not do any processing of the user data other than extraction. </td>
</tr>

<tr>
<td> Event </td>	<td>  Asynchronous callback mechanism for notifying applications that a certain decoder event was triggered </td><td> Event	</td> <td> </td>
</tr>


</table>


<br>
<br>
<br>
<br>

\anchor ViddecCodecs
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.3 Video Codecs</h2>

<br>
<br>


\anchor ViddecCodecs1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.3.1 H.624</h2>

The SMD H.264 decoder handles the decoding of H.264 elementary streams after the stream has been demuxed. The hardware H.264 Video decoder natively decodes the Annex B\ Byte-Stream format of H.264. The Byte Stream format is the common format used in a broadcast environment. This format relies on start codes to delimit NAL units. H.264 video that comes from software-based demux/container elements such as QuickTime*, MP4, Matroska*, and Flash* will typically be in what is referred to as Unit Stream H.264 format. Unit Stream H.264 will not contain start codes.  The application will need to do conversion from Unit Stream H.264 to Byte Stream H.264 in order to play contents from these sources.
The SMD H.264 hardware decoder supports Main Profile and High Profile H.264 streams.  It will also decode the Constrained Baseline Profile (i.e. Baseline Profile that does not use Flexible Macroblock Ordering (FMO), Arbitrary Slice Ordering (ASO), or Redundant Slices (RS) features).  Please refer to the ITU-T Rec. H.264 | ISO/IEC 14496-10 AVC specification for more information about the technical details of H.264.
In the SMD H264 G-Streamer element, some code exists for the conversion of Unit Stream to Byte Stream format.  Please refer to the code in the SDK for the GStreamer H.264 decoder unit for more details.

<br>
<br>

\anchor ViddecCodecs2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.3.2 MPEG-2</h2>
The Intel CE Media Processors are capable of decoding MPEG-2 streams.  Current support is up to MP@HL which covers most content in use today.  This decoder is able to handle up to 3 instances simultaneously, different from the H264 and VC1 decoders that can together equal 2 instances.


<br>
<br>

\anchor ViddecCodecs3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.3.3 VC-1</h2>
<br>
<br>


The SMD VC-1 decoder can decode VC-1 Bitstream Transport Encoded video streams per SMPTE PR227 specification. VC-1 content with Simple/Main/Advanced Profiles (SP/MP/AP) contained in an MPEG-2 transport stream or program stream are compliant VC-1 formats that can be decoded properly.
While ASF/WMV (WM9) video content is technically a VC-1 format, most WM9 content from the internet is SP/AP-based ASF/WMV video streams that are encapsulated in the RCV container format and cannot be decoded properly by SMD's VC-1 Video decoder element without pre-processing. RCV streams do not contain start codes in them and SMD�s Video decoder firmware only supports streams with start codes (i.e. encapsulated streams). All RCV based (ASF/WMV SP/MP streams) must be pre-processed to embed start codes and emulation encapsulation prevention in the streams before they can be decoded by SMD�s VC-1 decoder.

<br>
<br>

\anchor ViddecCodecs3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.3.3 MPEG4-Part2</h2>
The Intel's Atom processor CE4100 and above are capable of decoding MPEG4-Part 2 streams.  Current support is for Simple profile Level 0 to Level 6 and Advanced Simple Profile Level 0 to Level 5.

<br>
<br>
<br>
<br>


\anchor ViddecExamples
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.4 Some Useful Examples</h2>


  \anchor ViddecEx1
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.4.1 Connecting to Demux</h2>

The Intel CE Media Processor Video decoder module is created to easily accept data from 3rd party software de-multiplexers.  The input port for the Video decoder module can accept SMD buffers which can be filled out easily by the application.  The process of converting buffers for feeding into the Video decoder device will be described below.
The initialization of the Video decoder does not change whether data is coming from the SMD demux or a SW demux.  Please skip the connection of the Video decoder input port to the SMD demux.  The creation of the demux should be omitted when using a SW demux.
The SMD devices all require that a segment is sent to them to start playback.  For purposes of the Video decoder component, a generic segment can be sent allowing data from any time to pass through the device.  As this is usually automatically sent to the Video decoder from the demux it must be simulated for cases of SW demux.  Please send the new segment to Video decoder after the device has been put into the PLAYING state.  A sample of creating a generic new segment for feeding into Video decoder can be seen below.

\code
{
ismd_newsegment_tag_t 	newsegment_data;
ismd_es_buf_attr_t *buf_attrs;
ismd_buffer_handle_t		buffer_handle;
ismd_buffer_descriptor_t	buffer_desc;
ismd_result_t ismd_ret;

//create a carrier buffer for the new segment
ismd_ret = ismd_buffer_alloc(0, &buffer_handle);
if (ismd_ret != ISMD_SUCCESS) { assert(0); }

//need to get the buffer descriptor so it can be modified
ismd_ret = ismd_buffer_read_desc(buffer_handle, &buffer_desc);
if (ismd_ret != ISMD_SUCCESS) { assert(0); }

newsegment_data.linear_start = 0;
newsegment_data.start = 0;
newsegment_data.stop = ISMD_NO_PTS;
newsegment_data.requested_rate = 10000;
newsegment_data.applied_rate = ISMD_NORMAL_PLAY_RATE;
newsegment_data.rate_valid = true;
ismd_ret = ismd_tag_set_newsegment(buffer_handle, newsegment_data);
if (ismd_ret != ISMD_SUCCESS) { assert(0); }

ismd_ret = ismd_buffer_update_desc(buffer_handle, &buffer_desc);
if (ismd_ret != ISMD_SUCCESS) { assert(0); }

ismd_ret = ismd_port_write(viddec_input_port, buffer_handle);
if (ismd_ret != ISMD_SUCCESS) { assert(0); }

\endcode
At this point, the Video decoder device is ready to start accepting data.  Data should be fed into the  decoder inside of SMD buffers.  The process below shows a potential solution for preparing data for the Video decoder device.

\code
ismd_es_buf_attr_t *buf_attrs;
ismd_buffer_handle_t		buffer_handle;
ismd_buffer_descriptor_t	buffer_desc;
ismd_result_t ismd_ret;
uint8_t *ptr;

//recommend using 32 kB buffers as these are already allocated in the memory map,
//break data into smaller pieces if over 32 kB
ismd_ret = ismd_buffer_alloc(32*1024, &buffer_handle);
if (ismd_ret != ISMD_SUCCESS) { assert(0); }

//need to get the buffer descriptor so it can be modified
ismd_ret = ismd_buffer_read_desc(buffer_handle, &buffer_desc);
if (ismd_ret != ISMD_SUCCESS) { assert(0); }


ptr = OS_MAP_IO_TO_MEM_NOCACHE(buffer_desc.phys.base, buffer_desc.phys.size);
OS_MEMCPY(ptr, ptr_to_data, amount_of_data); //ptr to data should be the data being copied to viddec
OS_UNMAP_IO_FROM_MEM(ptr, buffer_desc.phys.size);

buffer_desc.phys.level = amount_of_data; //amount of data is the size in bytes of the data being written to viddec

buf_attrs = (ismd_es_buf_attr_t *) buffer_desc.attributes;
buf_attrs ->original_pts = pts; //pts will just be associated at viddec, can choose to do any necessary conversion before or after viddec
buf_attrs->local_pts = pts;

ismd_ret = ismd_buffer_update_desc(buffer_handle, &buffer_desc);
if (ismd_ret != ISMD_SUCCESS) { assert(0); }

//the input port should be full frequently when doing file, or any other push mode
while(ismd_port_write(*viddec_input_port, buffer_handle) != ISMD_SUCCESS) {
   usleep(1000);
}

\endcode
<br>
<br>
<br>
<br>


  \anchor ViddecEx2
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.4.2 PIP Horizontal Downscale</h2>
  Precautions are necessary for performance reasons when doing dual HD stream playback.  In order to avoid potential performance bottlenecks, it is highly suggested that the programmer configure the Video decoder to perform a horizontal downscale in the Video decoder device before feeding video frames to the vidpproc device.  This is required for all codecs as the issue will manifest in the vidpproc device.
  The Video decoder supports two different scales, half horizontal and quarter horizontal.  The choice of using half or quarter scaling should be dictated by combination of quality desired and bandwidth required by the system.  It is recommend that half horizontal scaling is used, then if any use cases expose bandwidth problems change to quarter horizontal scaling.  Exact usage will vary depending on the customer's complete system memory bandwidth requirements and use cases.  From a programming perspective, to control the downscale the function below is provided.  Please note that this function should be called in the code after opening the device during initial configuration.  It is required that this function is called before the device is placed in the PLAYING state.
\code
typedef enum {
   ISMD_VIDDEC_SCALE_NONE    = 0x0,      /**< Default - Do not scale down output image */
   ISMD_VIDDEC_HALF_HORIZONTAL = 0x1,    /**< Scale output image by � (horizontal only) */
   ISMD_VIDDEC_QUARTER_HORIZONTAL = 0x2, /**< Scale output image by � (horizontal only) */
} ismd_viddec_output_scale_factor_t;

ismd_result_t ismd_viddec_enable_output_scaling(ismd_dev_t viddec,
                                 ismd_viddec_output_scale_factor_t scale_val);

\endcode



  \anchor ViddecEx3
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.4.3 Sequence Display Extensions</h2>

In the event that sequence display extensions are missing from incoming bit stream with MPEG-2 video, the Intel CE Media Processor will default to settings appropriate for high definition video.  This is appropriate for most applications, but those with cases that include mainly standard definition video need to be aware of this and over-ride the default value.  For applications like DVD, the function below is provided to configure the Video decoder for standard definition appropriate values when sequence display extensions are missing from the stream.  Please note that this is only applicable to MPEG-2 video.  With all other Video decoders, this value will be ignored.

\code
/**
This enumeration defines how the MPEG-2 decoder should interpret content that does not explicitly specify sequence display extensions
*/
typedef enum {
   ISMD_VIDDEC_ISO13818_2	= 0x0, /**< Use default MPEG-2 settings for sequence display extensions */
   ISMD_VIDDEC_DVD		= 0x1,    /**< Use DVD default settings for sequence display extensions */
} ismd_viddec_seq_disp_ext_default_policy_t;

ismd_result_t ismd_viddec_set_seq_disp_ext_default_policy(ismd_dev_t viddec,
                                              ismd_viddec_seq_disp_ext_default_policy_t policy);

\endcode

For best results, please call this function during the Video decoder initialization section of code.  It must be called before putting the device in the PLAYING state.  For instance, the code below would be an acceptable call sequence for configuring the Video decoder to use standard definition optimized sequence display extensions when they are not present in the incoming stream.
\code
static ismd_result_t build_viddec(ismd_codec_type_t vid_codec)
{
   ismd_result_t ismd_ret;

   ismd_ret = ismd_viddec_open(vid_codec, &viddec_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_viddec_open\n");
      assert(0);
   }
   ismd_ret = ismd_viddec_set_seq_disp_ext_default_policy(viddec_handle, ISMD_VIDDEC_DVD);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_viddec_set_pts_interpolation_policy\n");
      assert(0);
   }
   ismd_ret = ismd_viddec_set_max_frames_to_decode(viddec_handle,ISMD_VIDDEC_ALL_FRAMES);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_viddec_set_max_frames_to_decode\n");
      assert(0);
   }
   ismd_ret = ismd_viddec_set_frame_error_policy(viddec_handle, ISMD_VIDDEC_EMIT_ALL);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_viddec_set_frame_error_policy\n");
      assert(0);
   }
   ismd_ret = ismd_viddec_get_input_port(viddec_handle, &viddec_input_port_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_viddec_get_input_port\n");
      assert(0);
   }
   ismd_ret = ismd_viddec_get_output_port(viddec_handle, &viddec_output_port_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_viddec_get_output_port\n");
      assert(0);
   }
   ismd_ret = ismd_dev_set_state(viddec_handle,ISMD_DEV_STATE_PAUSE);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_dev_set_state\n");
      assert(0);
   }

   return ISMD_SUCCESS;
}
\endcode

<br>
<br>
<br>
<br>

  \anchor ViddecEx4
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.4.4 User Data Handling</h2>
The Intel CE Media Processor allows the application access to the user data from all of the HW Video decoders.  The user data is commonly used for DVB AFD (active format description), closed captioning, and many other uses.
User data from the viddec is limited to 1024 byte buffers.  The actual data size should be queried from the buffer in the level field (see example program).  These buffers are allocated by the driver and should be released in the application after the data is acquired.  The buffers should be freed using the ismd_buffer_dereference function provided by the SMD core driver.
Access to the user data can be achieved by calling the function below to get a port from the Video decoder driver.
\code ismd_result_t  ismd_viddec_get_user_data_port(ismd_dev_t viddec, ismd_port_handle_t *port); \endcode

Depending on the decoder in use, different user data encoding is possible.  Some algorithms will allow for picture, GOP (group of pictures), or sequence level user data.  For user data elements found at the picture level, the presentation timestamp of the corresponding frame is stored with the user data. This allows the client programmer to render information related to the user data at the appropriate time.  In the case of picture level user data, only the first 8 elements will be sent to the output port.
It is important that the programmer ensure that the port is read in a timely manner.  In the event that the internal queues fill, user data will be discarded to ensure that video playback continues playing normally.  A functional sample program will be provided in the supplementary materials of this document for customer experimentation.  Please contact your Intel representative if you are unable to locate the supplemental materials.
The code snippet below illustrates the key portions of the configuration to enable user data extraction to the application.
During the initialization phase the following code will get the user data port and associate an event to wait for.

During the initialization phase the following code will get the user data port and associate an event to wait for.
\code
   ismd_ret = ismd_viddec_get_user_data_port(viddec_handle, &viddec_user_data_port_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_viddec_get_user_data_port\n");
      assert(0);
   }
   ismd_ret = ismd_event_alloc(&viddec_user_data_event);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_event_alloc\n");
      assert(0);
   }
   ismd_ret = ismd_port_attach(
      viddec_user_data_port_handle,viddec_user_data_event, ISMD_QUEUE_EVENT_NOT_EMPTY, ISMD_QUEUE_WATERMARK_NONE);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_port_attach\n");
      assert(0);
   }
   \endcode
Then another thread can be used to read the data from the user data port.
\code
void *video_user_data_thread(void *args)
{
   ismd_result_t ismd_ret;
   ismd_buffer_handle_t buffer;
   ismd_buffer_descriptor_t ismd_buf_desc;
   uint8_t *buf_ptr;

   args = NULL;//required for compilation purposes

   while (!main_thread_exit) {
      ismd_ret = ismd_event_wait(viddec_user_data_event, 50); //only wait 50 seconds so there is a way out of the loop
      if (ismd_ret == ISMD_ERROR_TIMEOUT) {
         continue;
      } else if (ismd_ret != ISMD_SUCCESS) {
         printf("got unexpected error waiting for user data\n");
         assert(0);
      }
      //at this point there should be data ready to be read
      ismd_ret = ismd_port_read(viddec_user_data_port_handle, &buffer);
      if (ismd_ret == ISMD_SUCCESS) {

         ismd_ret = ismd_buffer_read_desc(buffer, &ismd_buf_desc);
         if (ismd_ret != ISMD_SUCCESS) {
            OS_ASSERT(0);
         }

         printf("successfully read buffer, data level: %d\n", ismd_buf_desc.phys.level);

         buf_ptr = (uint8_t *)OS_MAP_IO_TO_MEM_NOCACHE(ismd_buf_desc.phys.base,ismd_buf_desc.phys.size);

         //here is the spot to do stuff with the data

         OS_UNMAP_IO_FROM_MEM(buf_ptr, ismd_buf_desc.phys.size);

         //need to dereference this buffer as SMD driver created reference when it made the buffer so it can be freed
         ismd_ret = ismd_buffer_dereference(buffer);
         if (ismd_ret != ISMD_SUCCESS) {
            printf("error freeing SMD buffer\n");
            assert(0);
         }
      }

   }

   printf("exiting the video_user_data_thread\n");

   return NULL;
}

\endcode

<br>
<br>
<br>
<br>

 \anchor ViddecEx5
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.4.5	Smooth (partial-GOP) trick mode playback</h2>


  The Intel CE Media Processor allows the application to specify number of frames to be decoded a video segment to get a 'smooth' playback effect during trick modes.

  ismd_result_t ismd_viddec_set_max_frames_to_decode(ismd_dev_t viddec,
                                                     unsigned int num_frames);

  This function specifies the number of frames in the sequence to be decoded. The Intel� CE Media Processor will not decode any more frames in the sequence after it has reached the specified limit. It will only resume decoding data once the previous sequence is terminated using the discontinuity flag or by flushing the video decoder. If the user wishes to have the decoder decode N frames from a particular point in a bitstream (e.g. the start of a GOP i.e. Group of Pictures), it should feed data into the decoder in a suitable fashion. E.g.:

  -# Call ismd_viddec_set_max_frames_to_decode()
  -# 	Send first sequence (first GOP)
  -#	For the second sequence (second GOP), set the discontinuity flag on the first input buffer of the second sequence to indicate to the video decoder that a new sequence has arrived. The video decoder will resume decoding at this point.

  Examples:    To decode all frames in a sequence:

  \code
  ismd_result_t result = ISMD_SUCCESS;
  ismd_dev_t viddec;

  result = ismd_viddec_set_max_frames_to_decode(viddec,
                                                ISMD_VIDDEC_ALL_FRAMES);
 \endocde

  Example:  To decode the first 5 frames in a sequence:

  \code result = ismd_viddec_set_max_frames_to_decode(viddec,5); \endcode

\anchor ViddecEx6
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt">	5A.4.6 Smooth (partial-GOP) reverse trick mode playback</h2>
  The Intel� CE Media Processor allows the application to configure the Video decoder to reverse frames in a video segment. Note that the video segments (GOPs) must be fed in reverse order relative to each other. For configuring the Intel� CE Video decoder in smooth reverse mode:

  -# The new segment sent to the Video decoder should contain a negative rate AND
  -# The frame masking on Video decoder should be set to decode all frames.
  -# Video Renderer must be configured in Fixed frame rate mode. Please see Video Renderer section on information about Fixed frame rate mode configuration.

  <h3> Buffering limitation for smooth reverse</h3>
  The amount of video memory increases in smooth reverse mode since the Intel CE Video Decoder must internally buffer all frames within the segment so they can be reordered. The amount of memory needed depends on the frame resolution, GOP structure and also the stream codec format. There is a default upper limit on the number of frames that can be reversed within a video segment. Please see below for the limitations:

<table border="1">
<caption>Table 2: Buffer Limitations </caption>
<tr>
<th style="color:black;background-color:blue;" >Codec Format of the Input Video Stream</th> <th style="color:black;background-color:blue;" >Number of frames that can be Reversed</th>
</tr>
<tr>
<td> MPEG2 </td>	<td>  18 </td>
</tr>
<tr>
<td> H.264 </td>	<td>  10 </td>
</tr>
<tr>
<td> VC-1 </td>	<td>  15 </td>
</tr>
<tr>
<td> MPEG-4 </td>	<td>  18 </td>
</tr>
</table>
The viddec ismd_viddec_set_max_frames_to_decode() option can be used to put a hard limit on number of frames to decode within a video segment. If this value (max_frames_to_decode) specified by application is greater than 18, the decoder will reverse first 18 decoded frames and display them. The remaining frames within that video segment will be dropped till the next video segment is received.
<H3>Setting Discontinuity flag</H3>
It is important that the application sets a discontinuity flag at the points that represent a start of a new video segment. This tells the decoder to that the current video segment is over and it displays the reversed frames buffered from that segment. The discontinuity flag can be set in the buffer descriptors ES attributes by the application before sending the buffer to the Demux input.


 \anchor ViddecAdd1
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.6.1 In-Stream Codec Transitions</h2>
  When doing an operation such as channel change, the application will be transitioning between two different streams. Stream transitions should be fast to provide the best possible user experience.

\anchor ViddecAddmore1
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.6.1.1 Channel Change</h2>

In the digital broadcast model, the end user will be interested in transitioning between different streams on different broadcast channels. When the user initiates the channel change, the following sequence of events will occur:
-# The application should flush the video decoder driver.
-# The viddec driver will release all frame buffers back to SMD core for reuse and flush its internal queues and reinitialize the data structures.
-# The application will start sending the elementary stream data associated with the new stream. If the codec type for the new stream has changed, the application will close the existing stream and allocate a new instance of video decoder driver. Otherwise, it will reuse the existing instance.




\anchor ViddecNew
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.5	New Features</h2>

\anchor ViddecNew1
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt">	5A.5.1 3DBD Playback</h2>

  The Intel Video decoder driver supports playback of 3D streams that are compliant to:
  3D Blu-Ray specification as defined in BD-ROM part3 V2.4D1_091014, Strawman Proposal Bridge Document. 3DBD is a simplified implementation of the MVC specification. It constrains the bitstream so that there are only two views.
  Figure below shows a typical pipeline configuration with a 3D stream. The input to the Intel Video decoder driver is expected to be a muxed stream with base (B) and dependent (D) elementary stream data. The Video decoder decodes the base frames and sends out the base frames on its default output port. The application can configure the viddec to add an additional output port and video decoder will then decode the dependent frames and send them on the dependent output port.

\image html videodecode6.png  Fig.6 SMD Video decoder interface
\code
ismd_result_t ismd_viddec_add_view (ismd_dev_t viddec,
						unsigned int view_index,
                                    ismd_port_handle_t *port);

ismd_result_t ismd_viddec_enable_view (ismd_dev_t viddec,
						    unsigned int view_index);

ismd_result_t ismd_viddec_disable_view (ismd_dev_t viddec,
						    unsigned int view_index);

ismd_result_t ismd_viddec_remove_view (ismd_dev_t viddec,
						   unsigned int view_index);

ismd_result_t ismd_viddec_get_view_info (ismd_dev_t viddec,
						     unsigned int view_index,
                                         ismd_viddec_view_info_t *info);

ismd_result_t ismd_viddec_set_eos_policy(ismd_dev_t viddec,
                                         ismd_viddec_eos_policy_t policy);

ismd_result_t ismd_viddec_get_eos_policy(ismd_dev_t viddec,
                                         ismd_viddec_eos_policy_t *policy);

/**
This enum defines the EOS handling policy on the decoder
*/
typedef enum {
   ISMD_VIDDEC_EOS_POLICY_INVALID            = 0,
   ISMD_VIDDEC_DO_NOT_IGNORE_BASE_VIEW_EOS   = 1, /**< Default - do not
                                                   ignore base view EOS in
                                                   the 3D stream*/
   ISMD_VIDDEC_IGNORE_BASE_VIEW_EOS          = 2, /**< Decoder will ignore
                                                    base view EOS */
   ISMD_VIDDEC_EOS_POLICY_MAX                = 3,
} ismd_viddec_eos_policy_t;

\endcode

\anchor ViddecNew2
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt">5A.5.2 	3D AVC playback</h2>
  The ISMD Video decoder driver supports decoding of 3D AVC streams with support for  a subset of frame packing formats as follows:
  -# Side by side
  -# Over-under
  -# Frame sequential
  -# Row interleaved

  Similar to 3DBD playback, the application can add the second output port using the ismd_viddec_add_view() API.
  Format change notification:
  The decoder can detect changes in stream format. A new event is added to ismd_viddec_event_t enum to indicate format change. The application needs to register for this event if it wants to be notified of the format change.
  \code
  /**
  Events that the decoder can generate.
  */
  typedef enum {
     ISMD_VIDDEC_OUT_OF_MEMORY        = 0x0, /**< Buffer allocation failures */
     ISMD_VIDDEC_RESOLUTION_CHANGE    = 0x1, /**< Resolution, aspect ratio, or        frame rate change */
     ISMD_VIDDEC_EOS                  = 0x2, /**< End of stream detected */
     ISMD_VIDDEC_BITSTREAM_ERROR      = 0x3, /**< Bitstream error detected */
     ISMD_VIDDEC_DROPPED_FRAMES       = 0x4, /**< Error frames dropped */
     ISMD_VIDDEC_CLIENT_ID_SEEN       = 0x5  /**< Client id seen */
     ISMD_VIDDEC_STREAM_FORMAT_CHANGE = 0x6  /**< change in stream format
                                                  detected. Either 2D-3D or
                                                  3D-2D or 3D-3D */
  } ismd_viddec_event_t;
  \endcode

  Following format changes will be detected:
  -# 2D to 3D (Side by side, over-under or frame sequential)
  -# 3D (Side by side, over-under or frame sequential) to 2D
  -# 3D to 3D (Side by side, over-under or frame sequential)
  Forced 2D-3D conversion:
  The ISMD decoder can be forced to play 2D content as 3D. The use-case is that the content will be encoded with either a side-by-side look or over-under look. However, the stream will not contain any metadata to indicate that it is a 3D stream. In this case, the user can force 3D output using following APIs.

  \code
  /*API to set the output video format. This will be used to force 2D-3D conversion or to disable 2D-3D conversion. When input format to this API are SBS or
  over-under, decoder will force the 2D stream to play as SBS or over-under. Only acceptable formats are 2D, SIDEBYSIDE and OVER_UNDER*/
  ismd_result_t ismd_viddec_set_output_video_format(ismd_dev_t viddec,
                                                    ismd_viddec_stream_format_t format);

  /*Query API to get the current output video format.*/
  ismd_result_t ismd_viddec_get_output_video_format(ismd_dev_t viddec,ismd_viddec_stream_format_t *format);

  \endcode

  When this API is called with VIDDEC_STREAM_FORMAT_3D_SIDEBYSIDE, the decoder will split the frame in half along the width and one frame for each half. When the
  API is called with VIDDEC_STREAM_FORMAT_3D_OVER_UNDER format, the decoder will split the frame in half along the height and create one frame for each half.
  The output of decoder will be two views.
  The application is required to open the second output port in the decoder by calling ismd_viddec_add_view() API. If second view is not added,
  decoder will drop the second half.  When the user wants to disable forced 2D-3D conversion, the user can call the same API with VIDDEC_STREAM_FORMAT_2D format.
  The Table.3.  below shows all possible combinations of stream format and the output format set by the API:

  <table border="1">
  <caption>Table 3: Stream Input an doutput format </caption>
  <tr>
  <th style="color:black;background-color:blue;" >Input </th> <th style="color:black;background-color:blue;" >Output</th> <th style="color:black;background-color:blue;" >Expected Output from the Decoder</th>
  </tr>
  <tr>
  <td> 2D </td> <td>Not Set</td>	<td>  2D </td>
  </tr>
  <tr>
    <td> 2D </td> <td>2D</td>	<td>  2D </td>
  </tr>

  <tr>
      <td> 2D </td> <td>3D(SBS/TB)</td>	<td>  3D(Decoder Performs aliasing) </td>
  </tr>

  <tr>
        <td> 3D </td> <td>Not Set</td>	<td>  3D </td>
  </tr>

  <tr>
          <td> 3D </td> <td>2D </td>	<td>  2D (Decoder drops View1)</td>
  </tr>

  <tr>
            <td> 3D </td> <td>3D</td>	<td>  3D </td>
  </tr>
  </table>

  <H3>APIs to enable/disable override of dependent view PTS</h3>
  If the frame sequential stream does not have identical PTS values on both view0 and view1 frames, then the video decoder will provide an API to handle this error case. The decode will copy over PTS value from view0 frame to the corresponding view1 frame. This will ensure that the frames have same PTS value. Three APIs will be added for this error handling feature:

  \code
  /*API to enable PTS override on dependent frames. Decoder will copy PTS value of base frame onto the corresponding dependent frame*/
  ismd_result_t ismd_viddec_enable_override_dependent_view_frame_pts(ismd_dev_t viddec);

  /*API to disable PTS override on dependent frames. Decoder will not modify the PTS
  values */
  ismd_result_t ismd_viddec_disable_override_dependent_view_frame_pts(ismd_dev_t viddec);

  /*API to get the PTS override setting*/
  ismd_result_t ismd_viddec_get_override_dependent_view_frame_pts(ismd_dev_t viddec,
                                                    bool * enable);

\endcode

<br>
<br>
<br>
<br>




\anchor ViddecAddmore2
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.6.1.2 End of Stream</h2>
  Streaming media infrastructures notify devices that no more data is available for a stream using an end-of-stream (EOS) notification mechanism. In order to work properly, the infrastructure must correlate the EOS method with the last data buffer of the stream. Once the Video decoder driver receives notification from the system that the EOS occurs, the following sequence of events occur:
  -# The driver will send an EOS message to the firmware, indicating that there won't be any more data sent by the driver until it is notified that the EOS message has occurred
  -# After emitting the last frame associated with the input buffers received prior to the EOS message, the firmware will send an EOS complete message to the driver after all frames have been provided to the driver. After all these frames are written out the output port of the driver, the driver will then insert a 0-sized buffer in the output port with the EOS tag on it, so that the EOS is propagated downstream in the right order.


\anchor ViddecTrick
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.7  Trick Mode Operation</h2>
  Trick modes are special video playback modes where the playback rate/order is altered or stopped entirely based on external events, typically a user command. Example trick modes include fast-forward playback, pause/resume, and reverse video playback.
  This section describes the capabilities exposed by the SMD Video Decoder module to provide client-side trick mode support. These capabilities are designed to support the trick modes defined in the CE3100 Core Software PRD. The PRD focuses on client side trick modes, and specifically excludes server side trick mode support. Support for server side trick modes may need to be added in the future based on customer requests.
  The CE3100 Core Software PRD specifies  that the following trick modes need to be supported by software:
  The CE3100 Core Software PRD specifies  that the following trick modes need to be supported by software:
  -# Pause/Resume
  -# Single Frame Forward Step
  -# Single Frame Reverse Step
  -# Variable Speed Forward Playback
  -# Variable Speed Reverse Playback
  -# 1X or slower smooth rewind for SD quality MPEG-2

Trick mode implementation is inherently a system operation driven by user interaction. The support required by the SMD Video Decoder Module to enable the capabilities will be described in the following sections.

\anchor ViddecTrick1
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.7.1 Pause and Resume</h2>
  No support is needed in the SMD Video Decoder for pause and resume. When the user decides to pause the stream, the video renderer will stop displaying frames. Eventually, no space will be available in the host module output port. This in turn will cause the SMD Video Decoder to stall once there are no frame buffers to allocate.
  When the user decides to resume playback, the application will notify the video renderer, who will eventually start to release frames. As frame buffers are released, the condition that the decoder was stalling on (no available frame buffers to decode into) will be released as the output port will eventually drain, and steady state decoding will continue. In the case of live streams, the application is responsible for handling buffer build up. This is typically done by dumping the input stream to disk.

\anchor ViddecTrick2
  <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.7.2 Single Frame Forward Step</h2>
  As in the pause/resume case, the Video decoder driver will not need to provide any additional support to enable single frame forward step mode.

  \anchor ViddecTrick3
    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.7.3 Single Frame Reverse Step</h2>
    As in the pause/resume case, the Video decoder driver will not need to provide any additional support to enable single frame forward step mode.

\anchor ViddecTrick4
    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.7.4 Variable Speed Playback</h2>

    Variable speed video playback, more commonly known as fast-forward or rewind mode, allows the user to play the stream at different speeds. In the ideal case, the decoder would decode every frame and the system would display them at the rate specified by the user. This results in smooth video playback and a better experience for the end user. However, the decode rate of the decoder is limited (especially at higher resolution content), and the display is refreshed at a fixed rate. Approximation techniques are used to overcome these limitations. These techniques come at the cost of �smoothness� � the video playback will appear jerkier when compared to the ideal case.
	A frame mask is used to overcome the limitation on the rate the decoder can decode frames. The frame mask instructs the decoder as to which frame types (I, P, or B) it should decode. For advanced codecs that allow all picture types to be reference frames, a mode is added that instructs the decoder to skip non-reference frames (those frames that aren't used as references). The frame mask gives the decoder a chance to decode enough frames to keep up with the desired video playback rate.
	Once the frame mask is configured the decoder will begin emitting frames. The frames will have presentation timestamp (PTS) values associated with them; however, these values will specify when the frames should be displayed based on the stream�s native framerate. For variable speed playback, the host software must modify the PTS values based on the rate specified by the user. To illustrate this concept, consider the hypothetical situation w/ a MPEG-2 stream illustrated in Fig.7 below.

\image html viddectric1.png  Fig.7 SMD Video decoder interface

Fig.7  shows a typical MPEG-2 display sequence. The first time scale shows the time units in which the frames are played at normal playback speed. These are the actual PTS values associated with the frame. The second time scale shows the clip played in 2X fast forward mode. The values shown assume the best case scenario where the decoder can decode the stream at 2X the native framerate.
In the case where the decoder is not able to keep up with the fast forward playback, certain frames must be skipped. Assume in this case B-skip mode is sufficient. The first I-Frame will be displayed at time 0. The next frame that will be displayed (the P-frame) has a native PTS value of 3. However, according to the 2X time scale, the frame should actually be displayed at time 1.5  in 2X fast forward mode. In order to calculate the proper PTS value, a scale value is used. The scale value is calculated from the user specified playback rate and is used to compute the new PTS value for the frame in a trick mode.

\anchor ViddecTrick5
    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.7.5 Variable Speed  Forward Playback</h2>
   There are two modes of configuring video decoder in forward trick mode playback.
   I frame mode: Here the frame mask is set to display only I frames. P and B frames are dropped by the decoder.
   Smooth (partial-GOP) trick mode: section 5.A.5.5

    <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5A.7.6 Variable Speed  Reverse Playback</h2>
    There are two modes of configuring video decoder in forward trick mode playback.
	I frame mode: Here the frame mask is set to display only I frames. P and B frames are dropped by the decoder.
	Smooth (partial-GOP) trick mode: see section 5.A.5.6





\anchor SMDVideoAPI
- \ref ismd_viddec " Link to Video Decoder API"



<br>
<br>
<br>
<br>
<br>
<br>
<br>

\anchor VidprocIntro
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B Video PostProcessor / Display Processor Engine(DPE)</h2>

 Video Postprocesor also referred as Display Processing Engine  or DPE  is an Intel Streaming Media device responsible for post processing of the decoded frames. DPE receives decoded frames with PTS and applies various processing algorithms before sending the frames to the renderer.

\anchor Vidprocfeatures
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.1 Key Features</h2>
The features supported by the DPE include the following:.
-# Scaling
	-# Scale to fit
	-# Zoom to fit
	-# Pan/scan processing
-# Pixel format conversion.
	-# Input format:
		-# 4:2:0 (NV12 - 8 bit )
		-# 4:20: (NV15 -10 bit)
		-# 4:2:2  (NV16 - 8 bit format)
		-# 4:2:2 (NV20 -10 bit)
   -# Output format:
    -# 	4:2:2  (NV16 - 8 bit format)
	-# 4:2:2 (NV20 - 10 bit) : (not implemented at this time)
-# Cropping
-# Process interlaced input
	-# Spatial de-interlacing.
	-# Motion adaptive filtering.
	-# Film-Mode Detection.
	-# Top field only
-# Interlaced pass-through
-# Process progressive input
-# De-ringing
-# Gaussian noise reduction.
-# Animated zoom
-# Scale only context
-# Supports upto 1080p input and output
-# Support for up to 6 video streams.

\anchor VidprocDesign
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.2 Software Components</h2>
The DPE has two input interfaces : the input port and the control information from an application. The input port feeds decoded video frames to the DPE. Applications use  the control interface to configure  DPE and control its operations as shown in the Fig.8. below
\image html vidproc1.png  Fig.8  Software Components of DPE
The output interfaces of the DPE are event notifications and placing the processed frame buffer in the output port. The application can register for events and the DPE sends these event notifications asynchronously as they happen.
The following figure shows the event notification flow of the DPE.  Events that are detected in the FW will be sent to the driver, where the event can be logged and/or sent up to the application.  Events that are detected in the driver can be logged in the driver and/or sent up to the application.  There is no notification from the driver to the FW; existing messages will be used to notify the FW if an event has occurred.

\image html vidproc2.png  Fig.9  Event Notification Flow

Events supported :
-# Internal
	-# Input
	-# Output
	-# Kill thread
	-# IPC
-# External (Application notification)
	-# display size change
	-# source size change
    -# Film mode detection (FMD) Cadence change
	-# open device
	-# close device

There can be multiple DPE (upto 6) instances (one instance per stream) opened at a time. Each instance operates independently.

\anchor Vidproccfg
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.3 Configuring DPE</h2>
To configure the device for normal playback please follow the steps below:
	-# Open the vidpproc device.
	-# If scaling is desired, set the scaling mode.
	-# If de-interlacing is desired, set the scaling mode.
	-# If source content cropping is desired, set the cropping rectangle
 	-# If de-ringing noise reduction is not desired, disable the de-ringing filter
	-# If Gaussian noise reduction is not desired, disable the Gaussian filter
	-# Set the output parameters (width, height, pixel aspect ratio)
	-# Set the output pixel format (NV16, NV20, YUYV)
	-#	Get the input and output ports.
	-#	Write to the input port
Please note that steps 2 through 8 can be done in any order.
On close, all resources are de-allocated and everything is reset to the initial state.
The default states for vidpproc device can be found below:
	-# De-ringing Noise Filter:  Enabled (using HW defaults)
	-# Gaussian Noise Filter:  Enabled (using HW defaults)
	-# Scaling Policy:  Scale-to-fit
	-# Deinterlacing Policy:  Auto
	-# Cropping:  Disabled
	-# Output Format:  4:2:2, 8-bit pseudo-planar (NV16)





\anchor Vidproccon
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt">5B.6 DPE Concepts</h2>

\anchor Vidproccon1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.1.1 Scaling Policies</h2>
The Intel� CE Media Processor handles video scaling at the vidpproc.  Some scaling capabilities are provided at the multi-format video decoder, but only for PIP (picture-in-picture) use cases.  The PIP Video decoder scale is necessary to avoid excessive use of memory bandwidth.  For all other video scaling, the vidpproc is the preferred method of scaling.
The Intel� CE Media Processors provide the following function to set the scaling method.
-# Scale-to-fit.
-# Zoom-to-fit.
-# Zoom-to-fill.
-# Anamorphic
\anchor Vidproccon1a
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.1.2  Scale to Fit</h2>

The scale to fit method is the most basic and easy to understand method.  The scaling in the X and Y direction will happen independently.  This method will ensure that the entire picture buffer is displayed.  It does this at the expense of possible stretching on images that are being scaled to different aspect ratios from the original.  To demonstrate how an image would be scaled from 720x480 to 1920x1080 please see the drawing below.

\image html vidproc5.png  Fig.10  Scale to Fit

 \anchor Vidproccon1b
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.1.3 Zoom to Fit</h2>

 Zoom to fit is another method of scaling that will ensure that scaling occurs equally in the X and Y direction to maintain an aspect ratio of the original source image.  Different from the zoom to fill method, this method will only scale until either the X or Y direction is completely filled by the new image.  This scaling method will result in a smaller image than the display plane in the event that the aspect ratios of the source and destination planes are not equal.  Graphically, the zoom to fit scaling method is shown below.

 \image html vidproc6.png  Fig.11  Zoom to Fit
 Notice that the image was scaled 2.25 times in both the X and Y direction.  This maintains the original aspect ratio.  The image was then centered in the Y direction with 150 pixel wide black bars inserted on the left and right.  As seen in the drawing, this method will result in the entire original image being displayed in the resulting frame.


  \anchor Vidproccon1c
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.1.4 Zoom to Fill</h2>

 Zoom to fill will fill the entire display plane similar to the scale to fit method.  When scaling using the zoom to fill method the aspect ratio of the original image will be maintained throughout the scale.  So the entire display will contain parts of the image, but the entire image will not be displayed unless the source and destination are of the exact same aspect ratio.  Again the 720x480 to 1920x1080 example will be used to demonstrate the scale.

 \image html vidproc7.png  Fig.12  Zoom to Fill

 Zoom to Fill uses the following formulas to calculate the size of the input rectangle (with all cropping) on the output frame such that the output rectangle is filled and Sample Aspect Ratios are converted to result in no distortion (assuming output SAR is handled properly by downstream devices)




 In this case the image was scaled by 2.67 in both the X and Y directions.  This maintained the aspect ratio perfectly with the original image.  This will avoid the annoying stretching effects that many users dislike.  This results in an 18% loss of the image in the X direction.  This scaling method will share that loss of data equal on both sides, 9% off the top and bottom in this case.  In the image above, the lost data is denoted in dark blue color with the light blue being the displayed part of the scaled image.




  \anchor Vidproccon1e
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.1.5 Anarmophic Scaling</h2>

 When the aspect ratio of the destination image is different from that of the source image, usually the pillar box or the letter box is used to fill the screen. In these methods, the scaling is linear scaling. A newer method called anamorphic scaling which is non-linear will keep the center of the image to the original aspect ratio while adjust the left side and right side of the image to a different aspect ratio. An example of anamorphic scaling which scales the image from 4:3 to 16:9 is shown below:

 \image html vidproc9.png  Fig.13  Anarmophic Scaling

 In the Intel� CE Media Processors, the horizontal scaler module supports the anamorphic scaling by having three independent scaling panels in each image. For each scaling panel, the scaling ratio and the panel width can be set independently. Configuring the scaling mode to VPP_SCP_ANAMORPHIC will enable user to access the anamorphic feature.


\anchor Vidproccon1f
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.1.6 Programmable Coefficient Table</h2>

The DPE provides a set of 150 scaling filter tables to optimize the video quality as various scaling ratios (ranging from  a down-scaling ratio of 100:1 in index 0 thru  1:1 in index 99 to 1:1.5 in index 149), Normally DPE automatically selects from the bottom 100 indices are (with upscaling always using index 99) however to obtain a video degrade (or blur) effect the application may call the ismd_vidrend_set_degrade_factor API to apply a uniform offset to the index. This offset is subtracted from the ideal index as calculated by the DPE.

\code ismd_result_t SMDEXPORT ismd_vidpproc_set_degrade_factor( ismd_dev_t dev, unsigned int blur_factor);\endocde

In addition applications can set individual offsets on each of the four scaling table indices (Y/UV and Vertical/Horizontal) using the \code ismd_vidpproc_set_parameter  \endocde
API. This API may only set the index offset if degrade is disabled. The parameters PAR_HSC_COEFF_IDXSHIFT_Y, PAR_HSC_COEFF_IDXSHIFT_UV, PAR_VSC_COEFF_IDXSHIFT_Y, and PAR_VSC_COEFF_IDXSHIFT_UV allow the application to apply an offset that will be added to the ideal index as calculated by the DPE for Horizontal Y, Horizontal UV, Vertical Y, and Vertical UV scaling respectively. The final index is range limited to [0�149] and any value beyond these will be clamped to this range.

\code
ismd_result_t SMDEXPORT ismd_vidpproc_set_parameter(
   ismd_dev_t dev,
   ismd_vidpproc_param_t par_name,
   int par_value
);
\endcode
The filter coefficients used in the scaling filters are programmable by the application. The parameters can be overridden by using APIs exposed from the vidpproc device.
The following APIs are declared in the vidpproc header but not implemented and not supported:

-# \code        ismd_vidpproc_override_horizontal_filter_coeffcients \endcode
-# \code        ismd_vidpproc_set_default_horizontal_filter_coeffcients \endcode
-# \code         ismd_vidpproc_override_vertical_filter_coeffcients \endcode
-# \code         ismd_vidpproc_set_default_vertical_filter_coeffcients \endcode

The following APIs are currently implemented but should be treated as temporary and will be removed when an improved API is ready.
\code
ismd_result_t SMDEXPORT ismd_vidpproc_override_horizontal_filter_luma_coefficients(
   ismd_dev_t dev,
   unsigned int y_filter_table_index,
   unsigned int y_filter_data,
   unsigned int y_size);

ismd_result_t SMDEXPORT ismd_vidpproc_override_horizontal_filter_chroma_coefficients(
   ismd_dev_t dev,
   unsigned int uv_filter_table_index,
   unsigned int uv_filter_data,
   unsigned int uv_size);

ismd_result_t SMDEXPORT ismd_vidpproc_override_vertical_filter_chroma_coefficients(
   ismd_dev_t dev,
   unsigned int uv_filter_table_index,
   unsigned int uv_filter_data,
   unsigned int uv_size);
\endcode
Warnings:
-# ismd_vidpproc_override_horizontal_filter_chroma_coefficients and ismd_vidpproc_override_vertical_filter_chroma_coefficients are effectively duplicates as vertical and horizontal filters currently point to the same locations.
-#       Despite the device context parameter, updates made to these tables are global and will affect all contexts
-#        Tables are updated asynchronously top frame processing and, if updated while a frame is being processed, may result in a visual artifact. Tables should normally only be updated when all streams are stopped, however this is not enforced as the only result will be a tear at the point where the tables are switched.
Usage Notes:
-#        The index parameter must fall between 0 and 149 inclusive
-#        The data parameter must be an integer cast of an address that will be accessible by the driver running in kernel space
-#         The uv_size parameter must be 254
-#        The y_size parameter must be 508

Each coefficient in the filters must be a 12 bit value structured as a s.1.10 fixed point number.

\image html vidproccoeff.png  Fig.14  Coefficient Table




  \anchor Vidproccon2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.1.7 Input Cropping</h2>
 In some cases it is desired to crop the incoming image before completing the scaling function.  To provide this capability to the programmer the function below is provided.
    \code
    ismd_result_t SMDEXPORT ismd_vidpproc_set_crop_input( ismd_dev_t dev,
          unsigned int x, unsigned int y,
          unsigned int width, unsigned int height);
      \endcode

 One particular case where this can be used is for DVB AFD.  Take the case where a 16:9 image is being broadcast inside of a 4:3 aspect broadcast.  The vidpproc allows the programmer to strip off the black bars and scale to a 16:9 aspect output plane.  The resulting crop and scale would look something like the diagram below.

\image html vidproc10.png  Fig.15  Input Cropping

 First, the ismd_vidpproc_set_crop_input function should be used to crop the black bars off the top and bottom of the image.  Then it can be scaled to the output 16:9 display plane, removing the unnecessary black bars.  In this case, the method should only be used if the output is 16:9 aspect ratio and the incoming aspect ratio is 4:3.  This will result in an optimal display of the source content.  Please refer to the DVB specifications for more information about this particular usage case.

 \anchor vidproccon3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.2 De-Interlacing</h2>
The Intel CE Media Processors provide several different de-interlacing options to the application developer.  The vidpproc de-interlace is performed by using a 9-direction spatial de-interlace.  Film mode detection is available for cases of 3:2, 2:2 etc pull down.  Thresholds for film mode detection are controlled via the de-interlacing policy.  By default the AUTO mode will be used.  In the AUTO mode, higher thresholds are used to avoid accidental entry into a film mode such as the 3:2 pull-down mode.  For most applications, this setting is appropriate.  In cases where it is highly likely that the content is going to require 3:2, 2:2, etc it is recommended that the FILM mode is used so that driver uses looser requirements for entering the film mode.  The film modes can also be disabled for those applications that can guarantee this content will not be used.  To disable the film mode detection, please use the VIDEO mode.

 The supported modes are:
 -# None.  Interlacing is disabled.(note that due to a current design limitation deinterlacing will be enabled when there is vertical scaling)
 -# Top field Only: Uses line replication algorithm
 -# Film. Disable Motion Adaptive Deinterlacing and perform inverse telecine, if film-content is detected.  This mode uses a relatively low threshold to identify Film Mode content (it effectively assumes that it will normally see Film Mode content)
 -# Video. Use motion adaptive, if FMD is not done. Motion adaptive uses 3 fields fields (which always includes both the current fields and the last field of the same polarity (top/bottom) so the algo can determine actual motion of objects)
 -# Auto. Make the best choice between Inverse Telecine and Motion Adaptive Deinterlacing. This mode uses a relatively high threshold to identify Film Mode content (it effectively looks for obvious Film Mode content)

 \code
 typedef enum {
       NONE, // do not deinterlace unless there is vertical scaling.do not deinterlace
       SPATIAL_ONLY, // no motion adaptive filtering
       FILM, // use a lower film mode detection threshold
       VIDEO, // disable film mode detection
       AUTO, // use motion-adaptive deinterlacing if video, also detect film mode with high film mode threshold
       TOP_FIELD_ONLY, // deinterlace top field of the frame and drop bottom field
       VPP_MAX_DEINTERLACE_POLICIES // Maximum number of deinterlacing policies
    } ismd_vidpproc_deinterlace_policy_t;

    ismd_result_t SMDEXPORT ismd_vidpproc_set_deinterlace_policy(
       ismd_dev_t dev,
       ismd_vidpproc_deinterlace_policy_t policy
    );
\endcode


\anchor vidproccon3b
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.3 Fim Mode Detection Exposure</h2>
Note:Please not that this event interface should be treated as temporary and the API to obtain the event should be expected to change
Video post processor does Film mode detection and recover the film mode sequence according to the detection result. The functions below provide the support for app to get the current film mode cadence type and to get an event when the film mode cadence type changes.
\code
ismd_result_t  SMDEXPORTismd_result_t ismd_vidpproc_get_parameter (
	ismd_dev_t dev,
	ismd_vidpproc_param_t par_name,
	int* par_value
);

\endcode

Besides, DPE driver updates the film mode detection results (including the cadence type and the frame index) into the frame attributes for each frame. Thus the app and the module after DPE in video pipeline can specify the cadence type and the frame index for each frame.
Note: dpe_common.h should be included to access cadence type since it is defined in dpe_common.h.
Below is an example of app to use the FMD API:

\code
#include �dpe_common.h�

ismd_event_t dpe_event = ISMD_EVENT_HANDLE_INVALID;
etDpeFmdCadence fmd_cadence_type;
ismd_result_t is_result = ISMD_ERROR_FEATURE_NOT_IMPLEMENTED;

//get the fmd_cadence_change_event
is_result = ismd_vidpproc_get_parameter(dpe_devh, FMD_CADENCE_CHANGED_EVENT,&dpe_event);
if(ISMD_SUCCESS == is_result)
{
   printf("EVENT:get event success\n");
}

//wait for the event
is_result = ismd_event_wait(dpe_event, 1000);
if(ISMD_SUCCESS == is_result) {
	is_result = ismd_vidpproc_get_parameter(dpe_devh, FMD_CADENCE_TYPE,&fmd_cadence_type);
	printf("cad_type:%d\n",fmd_cadence_type);
	is_result = ismd_event_acknowledge(dpe_event);
	if(is_result == ISMD_SUCCESS) {
   		printf("EVENT:event ack success\n");
	}
	else {
   		printf("EVENT:event ack failure\n");
	}
} else {
   printf("EVENT:event wait failure\n");
}

\endcode

\anchor vidproccon4
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.4 De-Ringing Noise Filter</h2>
This filter is responsible for removing ringing noise from the decoded images.  Ringing noise comes from error, estimation of quantized values, at the encoder when quantizing high frequency DCT coefficient.  Ringing noise will show up in the output around the sharp edges in the image.  With the Intel� CE Media Processor, a de-ringing noise filter is enabled by default in the vidpproc device.  The functions below are used to enable/disable this filter in the vidpproc.
\code
ismd_result_t SMDEXPORT ismd_vidpproc_deringing_enable( ismd_dev_t dev);
ismd_result_t SMDEXPORT ismd_vidpproc_deringing_disable( ismd_dev_t dev);
\endcode
The de-ringing filter is also controllable in regard to the effects of the filter.  Please use the function below to control the filter.  The default value is 4 with 1 � 100 being valid inputs.
\code
ismd_result_t SMDEXPORT ismd_vidpproc_set_deringing_level( ismd_dev_t dev, int level);
\endcode
It will take a transport stream and render the audio and video to the HDMI port.  The key portions of that code can be seen below, with complete code in the supplemental materials package.  Please contact your Intel field representative if you cannot find the test code sample.
\code
#if DERINGING_ENABLED
   ismd_ret = ismd_vidpproc_deringing_enable(vidpproc_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_vidpproc_deringing_enable\n");
      assert(0);
   }
#else
   ismd_ret = ismd_vidpproc_deringing_disable(vidpproc_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_vidpproc_deringing_disable\n");
      assert(0);
   }
#endif
\endcode

\anchor vidproccon5
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt">5B.6.5 Gaussian Noise Filter</h2>

Gaussian noise is random noise commonly found on streams that were originally recorded in analog formats, such as old films and camcorders.  This analog noise can cause images to appear blurry when converted to digital formats.  The Intel� CE Media Processors have filters that can be enabled to remove this noise from the image.  By default, the Gaussian Noise Filter will be enabled.  Call the ismd_vidpproc_guassian_disable() function if this filter is not desired.
//This function will enable the Guassian Noise Filter
ismd_result_t SMDEXPORT ismd_vidpproc_gaussian_enable( ismd_dev_t dev);

//This function will disable the Guassian Noise Filter
ismd_result_t SMDEXPORT ismd_vidpproc_gaussian_disable( ismd_dev_t dev);
An interface is also provided to control the affect of the Gaussian filter.  Please use the function below to experiment with the different filter curves.  The default value of the function below is 1, with 0 and 2 other valid inputs.
ismd_result_t SMDEXPORT ismd_vidpproc_set_gaussian_level( ismd_dev_t dev, int level);
To see the effect of the Gaussian noise filter in the Intel� CE Media Processor, an image has been placed below.  The left side is the original image; the image on the right is after applying the Gaussian noise filter.

\image  html vidproc11.png  fig.16. Gaussian Noise Filter

In the supplemental materials for this document a small test application exists for experimentation with the Gaussian noise filter.  This is part of the vidpproc_filters applications used in the previous section.  The key sections of code are exampled below. Refer to the complete source in the supplemental materials.  Please contact your Intel field representative if you cannot find the test code sample.
\code
#if GUASSIAN_ENABLED
   ismd_ret = ismd_vidpproc_gaussian_enable(vidpproc_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_vidpproc_gaussian_enable\n");
      assert(0);
   }
#else
   ismd_ret = ismd_vidpproc_gaussian_disable(vidpproc_handle);
   if(ismd_ret != ISMD_SUCCESS) {
      printf("failed at ismd_vidpproc_gaussian_disable\n");
      assert(0);
   }
#endif
\endcode



\anchor vidprocnew1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5B.6.6 3D Frame Handling</h2>
In order to support side by side, top and bottom 3D playback in CE3100, Video Post Processor provides the function to do 3D frame scaling and reposition.
   \code
   ismd_result_t SMDEXPORT ismd_vidpproc_set_parameter(
      ismd_dev_t dev,
      ismd_vidpproc_param_t par_name,
      int par_value
   );
   \endcode
<table border="1">
  <caption>Table 5: New Parameters for 3D Frame Handling </caption>
  <tr>
  <th style="color:black;background-color:blue;" >Parameter Name </th> <th style="color:black;background-color:blue;" >Description</th>
  </tr>
  <tr>
  <td>PAR_FRAME_PACKING_FORMAT</td> <td>Set the incoming frame packing format</td>
  </tr>

  <tr>
    <td>PAR_RIGHT_SHIFT_FOR_RIGHT_VIEW</td> <td>Set the horizontal shift between left and right view</td>
  </tr>
  <tr>
      <td>PAR_RIGHT_SHIFT_FOR_LEFT_VIEW</td> <td>Set the vertical shift between left and right view</td>
  </tr>
  </table>
The frame packing format data structure is  \code ismd_vidpproc_frm_packing_t \endcode

Application will call above API to configure the incoming frame format and shift distance. Based on this information obtained from application, video post processor will be responsible for scaling and position 3D frame properly. The behavior is shown in below
\image  html vidproc11.png Fig. 17  Scaling and Positioning 3D Frame

\anchor SMDVideopAPI
- \ref ismd_vidpproc " Link to DPE API"

\anchor vidrend
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C Video Renderer</h2>
The video renderer is an Intel Streaming Media Device (ISMD) on the Intel� CE Media Processor responsible for presenting uncompressed video data to the display at the correct time. The source of the uncompressed video content can be a hardware/software codec or video composed by a graphics unit or a compositor and they are written to the renderer�s input port. The presentation timestamp, the display rate and the content rate together determine when a new frame or field is sent to the display. The renderer interacts with the display driver through a Linux kernel interface called the Video Back Door (VBD).
Video renderer is a software only kernel module; it allows the application to open multiple (currently16) instances (one instance per stream). Each instance operates independently.

\anchor vidrendfeatures
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.1 Key Features</h2>
The following list contains the basic features of the Intel� CE Media Processor video renderer:
-# Normal play back
-# Frequency matching (Rate conversion)
-# Close caption(608) output
-# Trick mode
	-# Single frame advance and reverse
	-# Variable speed forward and reverse playback
-# Event notifications

\anchor vidrendcomp
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.2 Software Components</h2>
The video renderer has two input interfaces � the input port and the control information from an application. The input port feeds uncompressed video data into the renderer. The source of uncompressed video data can be the video post processor, a soft codec or the application. The control interface performs the renderer configuration and controls its operations.
The output interfaces of the renderer are event notifications and interactions with the VBD. The application can register for certain renderer events and the renderer sends these event notifications asynchronously as they happen. The VBD interface is a kernel interface to the display driver that the renderer links to at compile or run time. When frames are ready for display, the renderer sends them to the display driver via the VBD API vbd_flip and not through an output port.
The renderer allows the application to open multiple (currently 16) instances (one instance per stream). Each instance operates independently. The application programs each renderer through its control interface and then starts the renderer. Video frame buffers (pointers) are input to the input port and at the right time, the renderer writes these buffer pointers to the display driver through the VBD interface.

\image  html vidrend1.png  Fig.18 Software Components of Video Renderer

The main components of the renderer core are � the top-half callback registered with display (Top-Half), the bottom-half thread (Bottom-Half) and the Internal Process Queue (IPQ). A single top-half and a single bottom-half in the renderer service all open renderer instances. Each instance has an IPQ associated with it.

\anchor vidrendopnormal
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.3 Some Useful Examples</h2>

\anchor vidrendopnormal1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.3.1 Normal Playback</h2>
The video renderer operations during normal playback can be sub-divided into the following categories:
<h3> System Initialization </h3>
The initialization phase is done at device driver load time.
System initialization API:
\code ismd_result_t ismd_vidrend_init (void); \endcode

<h3> Stream Open </h3>

Stream Open API:
\code ismd_result_t ismd_vidrend_open (ismd_dev_t  *vidrend); \endcode
The device handle is the return parameter. All other renderer APIs take the device handle obtained on stream open as an input parameter.  The input port associated with the renderer is obtained and is used by the application to send video data to the renderer.  Any control data required to control renderer operation can be set at this point.  Mandatory control information is the display mode, the video plane id, the clock and the base time.


<h3> Stream Startup </h3>

The video plane id, the clock and the base time must be set before the renderer startup can succeed.  The video plane id is the video plane on which the uncompressed video frames from this renderer instance will be displayed.  The base time is the clock time when the stream started playing.  Base time, presentation timestamps and current time are based off the same clock and the renderer is notified of this clock before it can start.
Related APIs:
\code
ismd_result_t ismd_vidrend_set_interlaced_display_rate (ismd_vidrend_interlaced_rate_t rate);
ismd_result_t ismd_vidrend_set_video_plane (ismd_dev_t   vidrend, unsigned int video_plane_id);
ismd_result_t ismd_dev_set_clock (ismd_dev_t dev, ismd_clock_t clock);
ismd_result_t SMDEXPORT ismd_dev_set_stream_base_time (ismd_dev_t  vidrend, ismd_time_t base time);
ismd_result_t SMDEXPORT ismd_dev_set_state (ismd_dev_t  vidrend, ismd_dev_state_t state);
\endcode


<h3> Stream Shutdown </h3>

During shutdown, the renderer goes through the following stages � paused, stopped and then closed.
Stream Stop API:
\code
ismd_result_t SMDEXPORT ismd_dev_set_state (ismd_dev_t  vidrend, ismd_dev_state_t state);
Stream close API:
ismd_result_t ismd_dev_close (ismd_dev_t  vidrend);
\endcode


\anchor vidrendopnormal1a
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.3.1.1 Code Snippet:  Normal Playback</h2>

\code
#include "ismd_core.h"
#include "ismd_vidrend.h"
#include "ismd_core_protected.h"
#include "vbd.h"

int main(void)
{
    ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
    ismd_dev_t rend;
	ismd_port_handle_t input_port;
	ismd_port_handle_t output_port;
	unsigned int plane;
	ismd_clock_t clock;
	ismd_time_t base_time;
	ismd_time_t current_time;
	ismd_event_t eos;

    if((result = ismd_vidrend_open(&rend)) != ISMD_SUCCESS) {
        OS_PRINT("vidrend_open failed: %d\n", result);
    }

    if((result = ismd_vidrend_get_input_port(rend_data.rend, &input_port)) != ISMD_SUCCESS)
    {
        OS_PRINT("vidrend_get_input_port failed: %d\n", result);
    }
    // Set video plane same as renderer instance
    plane = 0;
    if((result = ismd_vidrend_set_video_plane(rend, plane)) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_set_video_plane failed: %d\n", result);
    }
    // Set clock same as renderer instance
    clock = rend;
    // Set vsync pipeline A
    if((result = ismd_clock_set_vsync_pipe(clock, 0)) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_clock_set_vsync_pipe failed: %d\n", result);
    }
    // Set clock
    if((result = ismd_dev_set_clock(rend, clock)) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_dev_set_clock failed: %d\n", result);
    }

	base_time = current_time = 0;
   	result = ismd_dev_set_stream_base_time (rend, base_time);
    if(result != ISMD_SUCCESS ) {
        OS_PRINT("VR: ismd_dev_set_stream_base_timeismd_dev_set_stream_base_time failed: got %d, expected %d\n", result, ISMD_SUCCESS);
    }
//start the renderer
    if((result = ismd_dev_set_state(rend, ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
        OS_PRINT("ismd_dev_set_state start failed: %d\n", result);
    } else {
        OS_PRINT("Renderer playing\n");
    }
    // Allocate eos event for the instance
    if ((result = ismd_event_alloc(&eos)) != ISMD_SUCCESS) {
        OS_PRINT("ERROR: Event eos creation failed for instance.%d\n", result);
    }

    // Enable output port in video renderer
    result = ismd_vidrend_enable_port_output(rend, 0, 1, &output_port);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("Unable to enable port output in video renderer.%d\n", result);
    }

    // Attach to the output port before starting to read
    result = ismd_port_attach(output_port, ISMD_EVENT_HANDLE_INVALID
                                                        , ISMD_QUEUE_EVENT_ALWAYS
                                                        , ISMD_QUEUE_WATERMARK_NONE);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("Unable to attach to video renderer output port.%d\n", result);
    }

    // Write frame buffers into the input port

    // Disable video renderer output port
    result = ismd_vidrend_disable_port_output(rend);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("Unable to disable output port in video renderer.%d\n",result);
    }

    // Wait on eos event
    ismd_event_wait(eos, ISMD_TIMEOUT_NONE);

    // Unconfigure video renderer
    result = ismd_dev_set_state(rend, ISMD_DEV_STATE_STOP);
    if (result != ISMD_SUCCESS) {
         OS_PRINT("Error setting renderer state to stop %d\n", result);
    }

    if((result = ismd_dev_close(rend) != ISMD_SUCCESS) {
      OS_PRINT("vidrend_close failed: %d\n", result);
      return result;
    }
    return 0;
}

\endcode

\anchor vidrendopnormal2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.3.2  Trick Mode : Pause/resume</h2>

On pause, the base time in the renderer is queried and a new value is calculated based on the previous value and the amount of time the stream is paused. On resume, this new base time is set in the renderer and then (renderer) restarted.
Stream pause API:\
\code
ismd_result_t SMDEXPORT ismd_dev_set_state (ismd_dev_t  vidrend, ismd_dev_state_t state);
ismd_result_t  ismd_vidrend_get_base_time (ismd_dev_t  vidrend, ismd_time_t* basetime);
\endcode
Stream Resume API:
\code
ismd_result_t SMDEXPORT ismd_dev_set_base_timeismd_dev_set_stream_base_time (ismd_dev_t  vidrend, ismd_time_t base time);
ismd_result_t SMDEXPORT ismd_dev_set_state (ismd_dev_t  vidrend, ismd_dev_state_t state);
\endcode


\anchor vidrendopnormal3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.3.2  Trick Mode : Variable Speed Playback</h2>

The renderer is not concerned with the direction or rate of playback. It provides a flush API to cleanup frames from the current stream during transitions from normal to variable playback and vice versa. Based on the flush policy, it either flips a black frame to the display or retains the last displayed frame. The default policy is to retain the last displayed frame.
The renderer also provides APIs to stop rendering closed caption information and to stop special conversions (3:2 pull-down etc) during trick modes.
APIs for transition from normal playback into trick mode:
\code
ismd_result_t SMDEXPORT ismd_dev_set_state (ismd_dev_t  vidrend, ismd_dev_state_t state);
ismd_result_t  ismd_vidrend_get_base_time (ismd_dev_t  vidrend, ismd_time_t* basetime);
ismd_result_t SMDEXPORT ismd_dev_flush (ismd_dev_t dev);
ismd_result_t SMDEXPORT ismd_dev_set_base_timeismd_dev_set_stream_base_time (ismd_dev_t  vidrend, ismd_time_t base time);
\endcode
APIs for transition from trick mode into normal playback:
\code
ismd_result_t SMDEXPORT ismd_dev_set_state (ismd_dev_t  vidrend, ismd_dev_state_t state);
ismd_result_t  ismd_vidrend_get_base_time (ismd_dev_t  vidrend, ismd_time_t* basetime);
ismd_result_t SMDEXPORT ismd_dev_flush (ismd_dev_t dev);
ismd_result_t SMDEXPORT ismd_dev_set_base_timeismd_dev_set_stream_base_time (ismd_dev_t  vidrend, ismd_time_t base time);
\endcode



\anchor vidrendopnormal4
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.3.2  Trick Mode : Single Frame Step</h2>

To support single frame step, the renderer provides APIs to query the presentation timestamp of the next frame and to advance the display to a given presentation timestamp. To perform single frame step, the application first pauses the renderer and then queries the next frame pts. The advance_to_pts API takes local pts value for the next frame as input and uses it to send the frame with matching pts to the display.
APIs for single frame step:
\code
ismd_result_t SMDEXPORT ismd_dev_set_state (ismd_dev_t  vidrend, ismd_dev_state_t state);
ismd_result_t SMDEXPORT ismd_dev_flush (ismd_dev_t dev);
ismd_result_t  ismd_vidrend_get_stream_position (ismd_dev_t  vidrend, ismd_pts_t *pts);
ismd_result_t  ismd_vidrend_advance_to_pts (ismd_dev_t  vidrend, ismd_pts_t linear_pts);
ismd_result_t  ismd_vidrend_get_base_time (ismd_dev_t  vidrend, ismd_time_t* basetime);
ismd_result_t SMDEXPORT ismd_dev_set_base_timeismd_dev_set_stream_base_time (ismd_dev_t  vidrend, ismd_time_t base time);
\endcode


\anchor vidrendopnormal5
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.3.3  Sample Code : Trick Mode</h2>

\code

#include "ismd_core.h"
#include "ismd_vidrend.h"
#include "ismd_core_protected.h"
#include "vbd.h"



// Renderer Data
typedef struct {
   ismd_dev_t rend;
   ismd_clock_t clock;
   ismd_time_t base_time;
   ismd_port_handle_t input_port;
   unsigned int plane;
   ismd_vidrend_test_params_t params;
   bool renderer_running;

   ismd_frame_polarity_t content_polarity;
   ismd_time_t content_rate; //frames or fields per second
   int effective_content_rate;
   int pts_increment;
   int width;
   int height;

   ismd_test_passing_criteria_t pass_criteria_number;
   vidrend_test_case_t test_case;
   vidrend_test_behavior_t behavior;
   unsigned int input_frame_count;
   int expected_frame_count;
   int flipped_frame_count;
   int port_frame_count;
   unsigned int TopUV_BottomUV_Diff;

   ismd_time_t current_time;

   ismd_buffer_handle_t buffer;
   bool test_failed_flag;
   unsigned int prev_top_uv_ptr;
   unsigned int prev_pts;
   unsigned int frames_written;
   ismd_pts_t max_pts;
   ismd_pts_t last_written_pts;
   int count_th_calls;

   ismd_event_t eos;
   ismd_event_t event_list[NUM_OF_EVENTS];
   unsigned int event_count[NUM_OF_EVENTS];
   bool event_thread_created;
   os_thread_t event_thread;
   ismd_vidrend_stats_t stats;
   ismd_vidrend_status_t status;
   bool events_test_completed;

   bool flush_eos;
   bool flush_play;
   bool flush_pause;
   bool flush_frame_repeated;
   ismd_pts_t frame_pts_after_flush;
   int flush_repeated_frames;
   int black_frames_flipped;
   bool flush_test_pass[2][4];

   os_event_t wait_to_input_event;
   os_event_t drop_event;
   os_event_t late_event;
   bool drop_frame;
   bool late_frame;
   bool waiting_to_input_late_frame;
   bool waiting_to_input_drop_frame;
   ismd_pts_t drop_frame_pts;
   ismd_pts_t late_frame_pts;

   bool state_change_thread_running;
   bool state_change_thread_created;
   bool renderer_paused;
   os_thread_t state_change_thread;
   ismd_time_t paused_clock_value;

   cc_test_type_t cc_test_case[18];
   int cc_text_index;
   bool was_prev_frame_late;
   bool was_prev_frame_drop;

   // for PTS Scaling
   bool rate_changed;
   int pts_rate;
   test_state_transitions state_transition;
   ismd_vidrend_stream_position_info_t position;
   int pts_frame_count;
   int calculated_rate;
   int multiplier;

   //Trick modes
   ismd_pts_t inband_scaling_rate;
   ismd_pts_t oob_scaling_rate;
   ismd_pts_t pts_before_trick_mode_change;
   bool enable_inband_scaling;

} test_rend_data_t;

//trick modes
typedef enum {
   FFR_IB_SCALING   = 1,
   IB_SCALING_FFR   = 2,
   FFR_OOB_SCALING  = 3,
   OOB_SCALING_FFR  = 4,
   IB_OOB_SCALING   = 5,
   OOB_IB_SCALING   = 6
} test_trick_mode_case_t;


//render instance
test_rend_data_t rend_data;
//trick mode types
test_trick_mode_case_t trick_mode_case = FFR_IB_SCALING;

rend_data.input_frame_count = 20;  //20 frames for test
rend_data.pts_rate = 30;           //for example
rend_data.effective_content_rate = 30; //for example
rend_data.pts_increment = VIDREND_CLOCK_FREQUENCY/rend_data.effective_content_rate;
rend_data.rate_changed = false;
rend_data.position.linear_time = 0;
// Trick modes Integration
rend_data.fixed_frame_rate_interval = (int) ((float)VIDREND_CLOCK_FREQUENCY / 29.97); //set the FFR to 29.97;
rend_data.inband_scaling_rate = 20000;
rend_data.oob_scaling_rate = 40000;
rend_data.pts_before_trick_mode_change = ISMD_NO_PTS;
rend_data.enable_inband_scaling = false;


//Configure video render
ismd_result_t configure_vidrend();
// Start video render
ismd_result_t start_vidrend();
//Release video render resource
ismd_result_t unconfigure_vidrend();
// Create frame buffer and write to input port
ismd_result_t frame_input (ismd_pts_t *pts, bool set_original_pts, int index);
//
bool fill_ip_port(void);


//Change the state of the renderer for changing the PTS Scaling rate.
ismd_result_t change_state_for_pts(pts_change_rend_state_t state)
{
    ismd_result_t result;
    ismd_time_t curr_time;

    switch (state)
    {
        case (PAUSE_CHANGE_PTS):
            if ((result = ismd_clock_get_time (rend_data.clock, &(rend_data.paused_clock_value))) != ISMD_SUCCESS)  {
	            OS_PRINT("VR: ismd_clock_get_time failed: %d\n",result);
	            return result;
			}
	        //pause the renderer
	        if((result = ismd_dev_set_state(rend_data.rend, ISMD_DEV_STATE_PAUSE)) != ISMD_SUCCESS) {
	            OS_PRINT("VR: ismd_dev_set_state PAUSE failed: %d\n", result);
	            return result;
	        }
	        rend_data.renderer_paused = true;
	  	    break;

		case (CHANGE_PTS_PLAY):
	        //get current time
	        if ((result = ismd_clock_get_time (rend_data.clock, &curr_time)) != ISMD_SUCCESS)
	        {
	            OS_PRINT("VR:ismd_clock_get_time_failed: %d\n", result);
	            return result;
	        }
	        //Calculate the new base time
	        if (rend_data.renderer_paused == true)  {
	            rend_data.base_time += (curr_time - rend_data.paused_clock_value);
	        } else if (rend_data.renderer_running == false)  {
	            rend_data.base_time = curr_time;
	        }
	        //set the new basetime
	        result = ismd_dev_set_stream_base_time (rend_data.rend, rend_data.base_time);
	        if (result != ISMD_SUCCESS) {
	            OS_PRINT("VR: ismd_dev_set_base_timeismd_dev_set_stream_base_time_failed: got %d\n", result);
	            return result;
	        }
	        //restart the renderer
	        if ((result = ismd_dev_set_state(rend_data.rend, ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
	            OS_PRINT("VR: ismd_dev_set_state start failed: %d\n", result);
	        }

	        rend_data.renderer_running = true;
	        break;
    }

    return (ISMD_SUCCESS);
}



//Creates thread to change the renderer status for play rate changes
ismd_result_t pts_rate_change(int rate)
{
    ismd_result_t result = ISMD_SUCCESS;

    // PLAY - PAUSE state change
    os_sleep ((unsigned long) 1);

    result = change_state_for_pts(PAUSE_CHANGE_PTS);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("VR: Error: Cannot perform transition from, play to pause state, ret = %d\n", result);
    }

    // get the current stream position
    result = ismd_vidrend_get_stream_position(rend_data.rend, &rend_data.position);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("Error: Cannot obtain the stream positon.\n");
        return result;
    }

    //change the rate
    result = ismd_dev_set_play_rate(rend_data.rend, rend_data.position.linear_time , rate);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("VR: The ismd_dev_set_play_rate does not return Success for PTS_Rate = %d.\n", rate);
        return result;
    }

    // PAUSE - PLAY state change
    os_sleep ((unsigned long) 1);

    result = change_state_for_pts(CHANGE_PTS_PLAY);
    if (ISMD_SUCCESS != result) {
        OS_PRINT("VR: Error: Cannot perform the transition from play to pause state, ret = %d\n", result);
    }

    return result;
}// end pts_rate_change()


//
int main(void)
{
    ismd_result_t result = ISMD_ERROR_UNSPECIFIED;

	/*initialize global setting: rend_data*/
	;

    /*configuration video render*/
	result = configure_vidrend();

	/* set the hold time to 10 frames  - as a robustness measure against bas PTS valuse*/
    if((result = ismd_vidrend_enable_max_hold_time(rend_data.rend, 10, 1)) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_enable_max_hold_time failed: %d\n", result);
		return result;
    }

	/*start video render*/
	result = start_vidrend();

	/*write frame buffers into the input port*/
    fill_ip_port();

    /* Unconfigure video renderer*/
    result = unconfigure_vidrend();

	return 0;
}

//
ismd_result_t configure_vidrend()
{
   ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
   //
   if((result = ismd_vidrend_open(&rend_data.rend)) != ISMD_SUCCESS) {
       OS_PRINT("vidrend_open failed: %d\n", result);
   }
   //
   if((result = ismd_vidrend_get_input_port(rend_data.rend,&rend_data.input_port)) != ISMD_SUCCESS)
   {
       OS_PRINT("vidrend_get_input_port failed: %d\n", result);
   }
   // Set video plane same as renderer instance
   rend_data.plane = 0;
   if((result = ismd_vidrend_set_video_plane(rend_data.rend,rend_data.plane)) != ISMD_SUCCESS)
   {
       OS_PRINT("ismd_vidrend_set_video_plane failed: %d\n", result);
   }
   // Set clock same as renderer instance
   rend_data.clock = rend_data.rend;
   // Set vsync pipeline A
   if((result = ismd_clock_set_vsync_pipe(rend_data.clock, 0)) != ISMD_SUCCESS)
   {
       OS_PRINT("ismd_clock_set_vsync_pipe failed: %d\n", result);
   }
   // Set clock
   if((result = ismd_dev_set_clock(rend_data.rend,rend_data.clock)) != ISMD_SUCCESS)
   {
       OS_PRINT("ismd_dev_set_clock failed: %d\n", result);
   }
   //Set display rate, i.e.ISMD_VIDREND_INTERLACED_RATE_59_94
   if((result = ismd_vidrend_set_interlaced_display_rate(ISMD_VIDREND_INTERLACED_RATE_59_94)) != ISMD_SUCCESS)
   {
       OS_PRINT("ismd_vidrend_set_interlaced_display_rate failed: %d\n", result);
   }
   //fixed frame rate is enabled
   if((result = ismd_vidrend_enable_fixed_frame_rate(rend_data.rend,rend_data.fixed_frame_rate_interval)) != ISMD_SUCCESS)
   {
       OS_PRINT("ismd_vidrend_enable_fixed_frame_rate failed: %d\n", result);
   }

   return result;
}

// Start video renderer
ismd_result_t start_vidrend()
{
    ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
    rend_data.base_time = rend_data.current_time;
    //
	result = ismd_dev_set_stream_base_time (rend_data.rend, rend_data.base_time);
    if(result != ISMD_SUCCESS ) {
        OS_PRINT("ismd_dev_set_base_timeismd_dev_set_stream_base_time failed: got %d, expected %d\n", result, ISMD_SUCCESS);
        fflush( stdout );
        return (result);
    }
    //start the renderer
    if((result = ismd_dev_set_state(rend_data.rend,ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
        OS_PRINT("ismd_dev_set_state start failed: %d\n", result);
    } else {
        OS_PRINT("Renderer playing\n");
        rend_data.renderer_running = true;
    }

    return result;
} // end start_vidrend()

//
ismd_result_t unconfigure_vidrend()
{
    ismd_result_t result = ISMD_SUCCESS;
    // Renderer State = Stop
    result = ismd_dev_set_state(rend_data[rend_num].rend, ISMD_DEV_STATE_STOP);
    if (result != ISMD_SUCCESS) {
        OS_PRINT("Error setting renderer state to stop %d\n", result);
    } else {
        OS_PRINT("Renderer Stopped\n");
    }

    if((result = ismd_dev_close(rend_data.rend)) != ISMD_SUCCESS) {
        OS_PRINT("vidrend_close failed: %d\n", result);
        return result;
    }

    return result;
} // end unconfigure_vidrend()


/* Create frame buffer and write to input port */
ismd_result_t frame_input (ismd_pts_t *pts, bool set_original_pts, int index)
{
    ismd_result_t result=ISMD_SUCCESS;
    ismd_buffer_descriptor_t desc;
    ismd_frame_attributes_t frame_attr;
	ismd_newsegment_tag_t newsegment_data;
    ismd_pts_t linear_time, over_head;
	ismd_pts_t offset = 10000;


	if (set_original_pts == true){
         frame_attr.original_pts = rend_data.pts_increment;
    } else if (rend_data.second_segment) {
         frame_attr.original_pts = frame_attr.original_pts + offset;
    }  else {
         frame_attr.original_pts = *pts;
    }

	/* Create a frame buffer */
    result = ismd_frame_buffer_alloc(rend_data.width, rend_data.height, &rend_data.buffer);
    if (result != ISMD_SUCCESS) {
        OS_PRINT( "ismd_frame_buffer_alloc, failed\n");
        OS_PRINT( "result: got %d, expected %d\n", result, ISMD_SUCCESS );
        fflush( stdout );
    }

	//populate frame attributes structure

    /* set the variable attributes based on the input */
    frame_attr.original_pts += rend_data.pts_increment;
    frame_attr.local_pts = frame_attr.original_pts;
    frame_attr->polarity = rend_data.content_polarity;
    //let y,u,v addresses be same as pts values for testing
    frame_attr.y      = frame_attr.local_pts;
    frame_attr.u      = frame_attr.local_pts;
    frame_attr.v      = frame_attr.local_pts;

    frame_attr.pixel_format    = ISMD_PF_NV16;
    frame_attr.gamma_type      = ISMD_GAMMA_NTSC;
    frame_attr.color_space     = ISMD_SRC_COLOR_SPACE_BT601;

    frame_attr.cont_rate       = 0;

    frame_attr.dest_size.width = rend_data[rend_num].width;
    frame_attr.dest_size.height= rend_data[rend_num].height;
    frame_attr.cont_pan_scan[0].horz_offset = 0;
    frame_attr.cont_pan_scan[0].vert_offset = 0;


    /* Read buffer desctriptor */
    result = ismd_buffer_read_desc(rend_data.buffer,&desc);
    if ( result != ISMD_SUCCESS ) {
        OS_PRINT("Error: Could not read buffer descriptor\n");
        return result;
    }

    /* Copy the frame attributes to buffer descriptor */
    memcpy (desc.attributes, &frame_attr, sizeof(ismd_frame_attributes_t));

    result = ismd_buffer_update_desc(rend_data.buffer, &desc);
    if ( result != ISMD_SUCCESS ) {
        OS_PRINT("Error: Could not update buffer attributes\n");
        return result;
    }

    if ( rend_data.enable_inband_scaling ) {
        /* set the linear time and send a new segment */
        over_head = rend_data.pts_increment + 500;
        linear_time = rend_data.position.linear_time + over_head;

        newsegment_data.linear_start   = linear_time;
        newsegment_data.start          = frame_attr.original_pts;
        newsegment_data.stop           = ISMD_NO_PTS;
        newsegment_data.requested_rate = rend_data.inband_scaling_rate;
        newsegment_data.applied_rate   = ISMD_NORMAL_PLAY_RATE;
        newsegment_data.rate_valid     = true;
        result = ismd_tag_set_newsegment(rend_data.buffer, newsegment_data);
        if (result != ISMD_SUCCESS) {
            OS_PRINT("Error: Could not set newsegment tag.\n");
            return result;
        }
    } else if ( set_original_pts && (trick_mode_case == IB_SCALING_FFR || case_num == IB_OOB_SCALING) ) {
        // The inband is originally enabled
        newsegment_data.linear_start   = 0;
        newsegment_data.start          = 0;
        newsegment_data.stop           = ISMD_NO_PTS;
        newsegment_data.requested_rate = rend_data.inband_scaling_rate;
        newsegment_data.applied_rate   = ISMD_NORMAL_PLAY_RATE;
        newsegment_data.rate_valid     = true;
        result = ismd_tag_set_newsegment(rend_data.buffer, newsegment_data);
        if (result != ISMD_SUCCESS) {
            OS_PRINT("Error: Could not set newsegment tag.\n");
            return result;
        }
    }

    /* Write buffer into the input port */
    result = ISMD_ERROR_UNSPECIFIED;
    while (result != ISMD_SUCCESS)
    {
        result = ismd_port_write(rend_data.input_port, rend_data.buffer);
        if(result != ISMD_SUCCESS) {
            os_sleep( (unsigned long)(1)); // sleep for 1 ms
        } else {
            rend_data.port_frame_count++;
        }
    }

    rend_data.last_written_pts = frame_attr.original_pts;
    rend_data.frames_written++;

    *pts = frame_attr.local_pts;

    return result;
} // end frame_input()


//
bool fill_ip_port(void)
{
    ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
    ismd_pts_t pts = rend_data.pts_increment;
    unsigned int index = 0;

    switch (trick_mode_case) {
        case FFR_IB_SCALING: // FFR set - Inband enabled after 3 frames
            result = ismd_vidrend_enable_fixed_frame_rate ( rend_data.rend, rend_data.fixed_frame_rate_interval );
            while (true)
            {
                if ( index == 4 ) {
                    /* Enable Inband Scaling*/
                    //while (rend_data[rend_num].flipped_frame_count < 3);
                    os_sleep((unsigned int)10);
                    result = ismd_vidrend_get_stream_position(rend_data.rend, &rend_data.position);
                    rend_num.enable_inband_scaling = true;
                    result = frame_input(&pts, false, index);
                } else {
                    rend_num.enable_inband_scaling = false;
                    result = frame_input(&pts, (index==0) ? true : false, index);
                }
		        index ++;
                // EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
		    break;
        case IB_SCALING_FFR: // Inband Scaling Enabled - Enable FFR after 3 frames
            result = ismd_vidrend_get_stream_position(rend_data.rend, &rend_data.position);
            while (true)
            {
                result = frame_input(&pts, (index==0) ? true : false, index);
                if (index == 3) {
                    result = ismd_vidrend_enable_fixed_frame_rate ( rend_data.rend, rend_data.fixed_frame_rate_interval );
                }
		        index ++;
                //EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
		    break;
        case FFR_OOB_SCALING: // Enable Fixed Frame Rate - Enable Out of Band Scaling
            result = ismd_vidrend_enable_fixed_frame_rate ( rend_data.rend, rend_data.fixed_frame_rate_interval );
            while (true) {
                result = frame_input(&pts, (index==0) ? true : false, index);
                if (index == 3) {
                    result = pts_rate_change(rend_data.oob_scaling_rate);
                }
		        index ++;
		        // EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
		    break;
        case OOB_SCALING_FFR: // Enable OOB then Enable FFR after
            result = pts_rate_change(rend_data.oob_scaling_rate);
            while (true) {
                result = frame_input(&pts, (index==0) ? true : false, index);
                if (index == 3) {
                    result = ismd_vidrend_enable_fixed_frame_rate ( rend_data.rend, rend_data.fixed_frame_rate_interval );
                }
		        index ++;
                // EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
		    break;
        case IB_OOB_SCALING: // Enbale Inband Scaling - Enable oob Scaling
            while (true)
            {
                result = frame_input(&pts, (index==0) ? true : false, index);
                if (index == 3) {
                    result = pts_rate_change(rend_data.oob_scaling_rate);
                }
                index ++;
                // EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
		    break;
        case OOB_IB_SCALING : // Enable oob scaling - Enable Inband Scaling
            result = pts_rate_change(rend_data.oob_scaling_rate);
            while (true)
            {
                if ( index == 4 ) {
                    /* Enable Inband Scaling*/
                    //while (rend_data[rend_num].flipped_frame_count < 3);
                    os_sleep((unsigned int)10);
                    rend_data.enable_inband_scaling = true;
                    result = frame_input(&pts, false, index);
                } else {
                    rend_data.enable_inband_scaling = false;
                    result = frame_input(&pts, (index==0) ? true : false, index);
                }
                index ++;
                // EOS
                if (index == rend_data.input_frame_count) {
                    break;
                }
            }
		    break;
    }

    rend_data.max_pts = pts;

    return true;
} // end fill_ip_port()

\endcode



\anchor vidrendcon
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4  Video Renderer Feature Description</h2>

This section describes some of the important features of the renderer in detail. These include
-# Frequency Matching
-# closed caption
-# event handling
-# hold time
-# stream position
-# Video Mute
-# Stereo 3D Support


\anchor vidrendcon1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.1  Frequency Matching</h2>

The renderer, along with the video post processor (vidpproc) is responsible for performing any rate conversions from the content rate to the display refresh rate. Examples of this coordination are provided in


\image  html vidrend1.png Fig.17 Frequency Matching

The vidpproc performs all the de-interlacing and scaling that needs to be performed on the content to meet the display characteristics. Table 9 2Table 8 2 shows the polarity of the renderer input for different content and display combinations. On progressive displays, the vidpproc always outputs progressive frames regardless of the content type. On interlaced displays, no de-interlacing is done unless otherwise specified in the postprocessor and the renderer input matches the original content polarity.

Output of DPE is progressive unless all of :
-# Input is interlaced
-# DI Policy is none
-# There is no vertical scaling
This is not connected to the display settings unless the APP adjusts these based on the display settings
We will always drop/repeat frames (field pairs) to rate match. The only exception is when we think that we are in 3:2 pulldown (which should be 24p->60i) in which case we drop/repeat fields to rate match.



  \anchor vidrendcon1a
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.1.1  Code Snippet Frequency Matching</h2>
  \code
  #include "ismd_core.h"
  #include "ismd_vidrend.h"
  #include "ismd_core_protected.h"
  #include "vbd.h"



  // Renderer Data
  typedef struct {
     ismd_dev_t rend;
     ismd_clock_t clock;
     ismd_time_t base_time;
     ismd_port_handle_t input_port;
     unsigned int plane;
     ismd_vidrend_test_params_t params;
     bool renderer_running;

     ismd_frame_polarity_t content_polarity;
     ismd_time_t content_rate; //frames or fields per second
     int effective_content_rate;
     int pts_increment;
     int width;
     int height;

     ismd_test_passing_criteria_t pass_criteria_number;
     vidrend_test_case_t test_case;
     vidrend_test_behavior_t behavior;
     unsigned int input_frame_count;
     int expected_frame_count;
     int flipped_frame_count;
     int port_frame_count;
     unsigned int TopUV_BottomUV_Diff;

     ismd_time_t current_time;

     ismd_buffer_handle_t buffer;
     bool test_failed_flag;
     unsigned int prev_top_uv_ptr;
     unsigned int prev_pts;
     unsigned int frames_written;
     ismd_pts_t max_pts;
     ismd_pts_t last_written_pts;
     int count_th_calls;

     ismd_event_t eos;
     ismd_event_t event_list[NUM_OF_EVENTS];
     unsigned int event_count[NUM_OF_EVENTS];
     bool event_thread_created;
     os_thread_t event_thread;
     ismd_vidrend_stats_t stats;
     ismd_vidrend_status_t status;
     bool events_test_completed;

     bool flush_eos;
     bool flush_play;
     bool flush_pause;
     bool flush_frame_repeated;
     ismd_pts_t frame_pts_after_flush;
     int flush_repeated_frames;
     int black_frames_flipped;
     bool flush_test_pass[2][4];

     os_event_t wait_to_input_event;
     os_event_t drop_event;
     os_event_t late_event;
     bool drop_frame;
     bool late_frame;
     bool waiting_to_input_late_frame;
     bool waiting_to_input_drop_frame;
     ismd_pts_t drop_frame_pts;
     ismd_pts_t late_frame_pts;

     bool state_change_thread_running;
     bool state_change_thread_created;
     bool renderer_paused;
     os_thread_t state_change_thread;
     ismd_time_t paused_clock_value;

     cc_test_type_t cc_test_case[18];
     int cc_text_index;
     bool was_prev_frame_late;
     bool was_prev_frame_drop;

     //pts scalling
     bool rate_changed;
     int pts_rate;

  } test_rend_data_t;

  //render instance
  test_rend_data_t rend_data;

  rend_data.input_frame_count = 20;  //20 frames for test
  rend_data.pts_rate = 30;           //for example
  rend_data.effective_content_rate = 30; //for example
  rend_data.pts_increment = VIDREND_CLOCK_FREQUENCY/rend_data.effective_content_rate;

  //Configure video render
  ismd_result_t configure_vidrend();
  // Start video render
  ismd_result_t start_vidrend();
  //Release video render resource
  ismd_result_t unconfigure_vidrend();
  // Create frame buffer and write to input port
  ismd_result_t frame_input (ismd_pts_t *pts, bool set_original_pts, int index);



  //Change the state of the renderer for changing the PTS Scaling rate.
  ismd_result_t change_state_for_pts(pts_change_rend_state_t state)
  {
      ismd_result_t result;
      ismd_time_t curr_time;

      switch (state)
      {
          case (PAUSE_CHANGE_PTS):
              if ((result = ismd_clock_get_time (rend_data.clock, &(rend_data.paused_clock_value))) != ISMD_SUCCESS)  {
  	            OS_PRINT("VR: ismd_clock_get_time failed: %d\n",result);
  	            return result;
  			}
  	        //pause the renderer
  	        if((result = ismd_dev_set_state(rend_data.rend, ISMD_DEV_STATE_PAUSE)) != ISMD_SUCCESS) {
  	            OS_PRINT("VR: ismd_dev_set_state PAUSE failed: %d\n", result);
  	            return result;
  	        }
  	        rend_data.renderer_paused = true;
  	  	    break;

  		case (CHANGE_PTS_PLAY):
  	        //get current time
  	        if ((result = ismd_clock_get_time (rend_data.clock, &curr_time)) != ISMD_SUCCESS)
  	        {
  	            OS_PRINT("VR:ismd_clock_get_time_failed: %d\n", result);
  	            return result;
  	        }
  	        //Calculate the new base time
  	        if (rend_data.renderer_paused == true)  {
  	            rend_data.base_time += (curr_time - rend_data.paused_clock_value);
  	        } else if (rend_data.renderer_running == false)  {
  	            rend_data.base_time = curr_time;
  	        }
  	        //set the new basetime
  	        result = ismd_dev_set_stream_base_time (rend_data.rend, rend_data.base_time);
  	        if (result != ISMD_SUCCESS) {
  	            OS_PRINT("VR: ismd_dev_set_base_timeismd_dev_set_stream_base_time_failed: got %d\n", result);
  	            return result;
  	        }
  	        //restart the renderer
  	        if ((result = ismd_dev_set_state(rend_data.rend, ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
  	            OS_PRINT("VR: ismd_dev_set_state start failed: %d\n", result);
  	        }

  	        rend_data.renderer_running = true;
  	        break;
      }

      return (ISMD_SUCCESS);
  }



  //Creates thread to change the renderer status for play rate changes
  ismd_result_t pts_rate_change(int rate)
  {
      ismd_result_t result = ISMD_SUCCESS;

      // PLAY - PAUSE state change
      os_sleep ((unsigned long) 1);

      result = change_state_for_pts(PAUSE_CHANGE_PTS);
      if (result != ISMD_SUCCESS) {
          OS_PRINT("VR: Error: Cannot perform transition from, play to pause state, ret = %d\n", result);
      }

      // get the current stream position
      result = ismd_vidrend_get_stream_position(rend_data.rend, &rend_data.position);
      if (result != ISMD_SUCCESS) {
          OS_PRINT("Error: Cannot obtain the stream positon.\n");
          return result;
      }

      //change the rate
      result = ismd_dev_set_play_rate(rend_data.rend, rend_data.position.linear_time , rate);
      if (result != ISMD_SUCCESS) {
          OS_PRINT("VR: The ismd_dev_set_play_rate does not return Success for PTS_Rate = %d.\n", rate);
          return result;
      }

      // PAUSE - PLAY state change
      os_sleep ((unsigned long) 1);

      result = change_state_for_pts(CHANGE_PTS_PLAY);
      if (ISMD_SUCCESS != result) {
          OS_PRINT("VR: Error: Cannot perform the transition from play to pause state, ret = %d\n", result);
      }

      return result;
  }// end pts_rate_change()


  //
  int main(void)
  {
      ismd_result_t result = ISMD_ERROR_UNSPECIFIED;

  	/*initialize global setting: rend_data*/
  	;

      /*configuration video render*/
  	result = configure_vidrend();

  	/* set the hold time to 10 frames  - as a robustness measure against bas PTS valuse*/
      if((result = ismd_vidrend_enable_max_hold_time(rend_data.rend, 10, 1)) != ISMD_SUCCESS)
      {
          OS_PRINT("ismd_vidrend_enable_max_hold_time failed: %d\n", result);
  		return result;
      }

  	/*start video render*/
  	result = start_vidrend();

  	/*write frame buffers into the input port*/
  	int index = 0;
  	ismd_pts_t pts = rend_data.pts_increment;

  	while (true)
      {
          result = frame_input(&pts, (index==0) ? true : false, index);
          index ++;
          //Change the renderer rate after 3 frames.
          if (index == 3) {
              //Change the rate for any
              rend_data.rate_changed = true;
              result = pts_rate_change(rend_data.pts_rate);

          } // end if index == 3

          // EOS
          if (index == rend_data.input_frame_count) {
              break;
          }
      }// end the while loop

      /* Unconfigure video renderer*/
      result = unconfigure_vidrend();

  	return 0;
  }

  //
  ismd_result_t configure_vidrend()
  {
     ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
     //
     if((result = ismd_vidrend_open(&rend_data.rend)) != ISMD_SUCCESS) {
         OS_PRINT("vidrend_open failed: %d\n", result);
     }
     //
     if((result = ismd_vidrend_get_input_port(rend_data.rend,&rend_data.input_port)) != ISMD_SUCCESS)
     {
         OS_PRINT("vidrend_get_input_port failed: %d\n", result);
     }
     // Set video plane same as renderer instance
     rend_data.plane = 0;
     if((result = ismd_vidrend_set_video_plane(rend_data.rend,rend_data.plane)) != ISMD_SUCCESS)
     {
         OS_PRINT("ismd_vidrend_set_video_plane failed: %d\n", result);
     }
     // Set clock same as renderer instance
     rend_data.clock = rend_data.rend;
     // Set vsync pipeline A
     if((result = ismd_clock_set_vsync_pipe(rend_data.clock, 0)) != ISMD_SUCCESS)
     {
         OS_PRINT("ismd_clock_set_vsync_pipe failed: %d\n", result);
     }
     // Set clock
     if((result = ismd_dev_set_clock(rend_data.rend,rend_data.clock)) != ISMD_SUCCESS)
     {
         OS_PRINT("ismd_dev_set_clock failed: %d\n", result);
     }
     //Set display rate, i.e.ISMD_VIDREND_INTERLACED_RATE_59_94
     if((result = ismd_vidrend_set_interlaced_display_rate(ISMD_VIDREND_INTERLACED_RATE_59_94)) != ISMD_SUCCESS)
     {
         OS_PRINT("ismd_vidrend_set_interlaced_display_rate failed: %d\n", result);
     }
     //fixed frame rate is enabled
     if((result = ismd_vidrend_enable_fixed_frame_rate(rend_data.rend,rend_data.fixed_frame_rate_interval)) != ISMD_SUCCESS)
     {
         OS_PRINT("ismd_vidrend_enable_fixed_frame_rate failed: %d\n", result);
     }

     return result;
  }

  // Start video renderer
  ismd_result_t start_vidrend()
  {
      ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
      rend_data.base_time = rend_data.current_time;
      //
  	result = ismd_dev_set_stream_base_time (rend_data.rend, rend_data.base_time);
      if(result != ISMD_SUCCESS ) {
          OS_PRINT("ismd_dev_set_base_timeismd_dev_set_stream_base_time failed: got %d, expected %d\n", result, ISMD_SUCCESS);
          fflush( stdout );
          return (result);
      }
      //start the renderer
      if((result = ismd_dev_set_state(rend_data.rend,ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
          OS_PRINT("ismd_dev_set_state start failed: %d\n", result);
      } else {
          OS_PRINT("Renderer playing\n");
          rend_data.renderer_running = true;
      }

      return result;
  } // end start_vidrend()

  //
  ismd_result_t unconfigure_vidrend()
  {
      ismd_result_t result = ISMD_SUCCESS;
      // Renderer State = Stop
      result = ismd_dev_set_state(rend_data[rend_num].rend, ISMD_DEV_STATE_STOP);
      if (result != ISMD_SUCCESS) {
          OS_PRINT("Error setting renderer state to stop %d\n", result);
      } else {
          OS_PRINT("Renderer Stopped\n");
      }

      if((result = ismd_dev_close(rend_data.rend)) != ISMD_SUCCESS) {
          OS_PRINT("vidrend_close failed: %d\n", result);
          return result;
      }

      return result;
  } // end unconfigure_vidrend()


  /* Create frame buffer and write to input port */
  ismd_result_t frame_input (ismd_pts_t *pts, bool set_original_pts, int index)
  {
      ismd_result_t result=ISMD_SUCCESS;
      ismd_buffer_descriptor_t desc;
      ismd_frame_attributes_t frame_attr;
      ismd_pts_t offset = 10000;


  	if (set_original_pts == true){
           frame_attr.original_pts = rend_data.pts_increment;
      } else if (rend_data.second_segment) {
           frame_attr.original_pts = frame_attr.original_pts + offset;
      }  else {
           frame_attr.original_pts = *pts;
      }

  	/* Create a frame buffer */
      result = ismd_frame_buffer_alloc(rend_data.width, rend_data.height, &rend_data.buffer);
      if (result != ISMD_SUCCESS) {
          OS_PRINT( "ismd_frame_buffer_alloc, failed\n");
          OS_PRINT( "result: got %d, expected %d\n", result, ISMD_SUCCESS );
          fflush( stdout );
      }

  	//populate frame attributes structure

      /* set the variable attributes based on the input */
      frame_attr.original_pts += rend_data.pts_increment;
      frame_attr.local_pts = frame_attr.original_pts;
      frame_attr->polarity = rend_data.content_polarity;
      //let y,u,v addresses be same as pts values for testing
      frame_attr.y      = frame_attr.local_pts;
      frame_attr.u      = frame_attr.local_pts;
      frame_attr.v      = frame_attr.local_pts;

      frame_attr.pixel_format    = ISMD_PF_NV16;
      frame_attr.gamma_type      = ISMD_GAMMA_NTSC;
      frame_attr.color_space     = ISMD_SRC_COLOR_SPACE_BT601;

      frame_attr.cont_rate       = 0;

      frame_attr.dest_size.width = rend_data[rend_num].width;
      frame_attr.dest_size.height= rend_data[rend_num].height;
      frame_attr.cont_pan_scan[0].horz_offset = 0;
      frame_attr.cont_pan_scan[0].vert_offset = 0;


      /* Read buffer desctriptor */
      result = ismd_buffer_read_desc(rend_data.buffer,&desc);
      if ( result != ISMD_SUCCESS ) {
          OS_PRINT("Error: Could not read buffer descriptor\n");
          return result;
      }

      /* Copy the frame attributes to buffer descriptor */
      memcpy (desc.attributes, &frame_attr, sizeof(ismd_frame_attributes_t));

      result = ismd_buffer_update_desc(rend_data.buffer, &desc);
      if ( result != ISMD_SUCCESS ) {
          OS_PRINT("Error: Could not update buffer attributes\n");
          return result;
      }

      /* Write buffer into the input port */
      result = ISMD_ERROR_UNSPECIFIED;
      while (result != ISMD_SUCCESS)
      {
          result = ismd_port_write(rend_data.input_port, rend_data.buffer);
          if(result != ISMD_SUCCESS) {
              os_sleep( (unsigned long)(1)); // sleep for 1 ms
          } else {
              rend_data.port_frame_count++;
          }
      }

      rend_data.last_written_pts = frame_attr.original_pts;
      rend_data.frames_written++;

      *pts = frame_attr.local_pts;

      return result;
  } // end frame_input()

  \endcode
<br>
<br>
<br>
<br>
  \anchor vidrendcon2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.2  Closed Caption</h2>
  Only NTSC (EIA-608) closed caption information associated with each frame is sent to the renderer to be displayed on line 21. The renderer forwards this information to the vbd_flip function along with frame/field pointers. The renderer sends closed caption information for all video planes but only closed caption information sent to the closed caption source is displayed by the display driver. The display driver API gdl_closed_caption_source indicates the plane id that needs to be used as a closed caption source.
  During frame repeats, the renderer will not send the closed caption information associated with the frame more than once to the display. On frame drops, the renderer will collect closed caption information from the dropped frames and send it with the next frame to the display.  Closed-captions are disabled during trick mode playback and are re-enabled during normal playback.
<br>
<br>

 \anchor vidrendcon2a
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.2a  Code Snippet: Closed Caption</h2>
  \code
  #include "ismd_core.h"
  #include "ismd_vidrend.h"
  #include "ismd_core_protected.h"
  #include "vbd.h"


  #define CC_TEST_INPUT       45
  #define CC_TEXT_LENGTH      18

  typedef enum {
     TEST_VALID_CC=1,
     TEST_VALID_CC1_INVALID_CC2,
     TEST_INVALID_CC1_VALID_CC2,
     TEST_INVALID_CC,
  } test_cc_validity_type_t;

  typedef enum {
     TEST_FRAME_NORMAL=1,
     TEST_FRAME_LATE,
     TEST_FRAME_DROP,
     TEST_FRAME_OUT_OF_ORDER,
  } test_cc_timing_type_t;

  typedef enum {
     TEST_PROG_FRAME=1,
     TEST_INTL_POLARITY_TOP,
     TEST_INTL_POLARITY_BOTTOM,
  } test_cc_polarity_type_t;

  // Structure for cc test input data
  typedef struct test_cc_input_config_struct {
     int test_frame_validity;
     int test_frame_timing;
     int test_frame_polarity;
     bool reset_original_pts;
     bool reset_cc_text_index;
  } test_frame_input_config_t;

  // Renderer Data
  typedef struct {
     ismd_dev_t rend;
     ismd_clock_t clock;
     ismd_time_t base_time;
     ismd_port_handle_t input_port;
     unsigned int plane;
     ismd_vidrend_test_params_t params;
     bool renderer_running;

     ismd_frame_polarity_t content_polarity;
     ismd_time_t content_rate; //frames or fields per second
     int effective_content_rate;
     int pts_increment;
     int width;
     int height;

     ismd_test_passing_criteria_t pass_criteria_number;
     vidrend_test_case_t test_case;
     vidrend_test_behavior_t behavior;
     unsigned int input_frame_count;
     int expected_frame_count;
     int flipped_frame_count;
     int port_frame_count;
     unsigned int TopUV_BottomUV_Diff;

     ismd_time_t current_time;

     ismd_buffer_handle_t buffer;
     bool test_failed_flag;
     unsigned int prev_top_uv_ptr;
     unsigned int prev_pts;
     unsigned int frames_written;
     ismd_pts_t max_pts;
     ismd_pts_t last_written_pts;
     int count_th_calls;

     ismd_event_t eos;
     ismd_event_t event_list[NUM_OF_EVENTS];
     unsigned int event_count[NUM_OF_EVENTS];
     bool event_thread_created;
     os_thread_t event_thread;
     ismd_vidrend_stats_t stats;
     ismd_vidrend_status_t status;
     bool events_test_completed;

     bool flush_eos;
     bool flush_play;
     bool flush_pause;
     bool flush_frame_repeated;
     ismd_pts_t frame_pts_after_flush;
     int flush_repeated_frames;
     int black_frames_flipped;
     bool flush_test_pass[2][4];

     os_event_t wait_to_input_event;
     os_event_t drop_event;
     os_event_t late_event;
     bool drop_frame;
     bool late_frame;
     bool waiting_to_input_late_frame;
     bool waiting_to_input_drop_frame;
     ismd_pts_t drop_frame_pts;
     ismd_pts_t late_frame_pts;

     bool state_change_thread_running;
     bool state_change_thread_created;
     bool renderer_paused;
     os_thread_t state_change_thread;
     ismd_time_t paused_clock_value;

     cc_test_type_t cc_test_case[18];
     int cc_text_index;
     bool was_prev_frame_late;
     bool was_prev_frame_drop;

  } test_rend_data_t;

  //render instance
  test_rend_data_t rend_data;
  //closed caption info
  char cc_text[CC_TEXT_LENGTH]="CLOSEDCAPTIONSTEST";
  //closed caption info index
  int cc_text_index;

  // All input configurations for cc test
  test_frame_input_config_t input_config[] =
  {
     // Validity test frames
     //0
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_PROG_FRAME,          true,  true},
     {TEST_VALID_CC1_INVALID_CC2,TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, false},
     {TEST_INVALID_CC1_VALID_CC2,TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, false},
     {TEST_INVALID_CC,           TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, false},
     //3

     //Polarity test frames
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, true},
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, false},
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_INTL_POLARITY_BOTTOM,false, false},
     //6

     //Timing test frames
     {TEST_VALID_CC,             TEST_FRAME_LATE,   TEST_PROG_FRAME,          false, true},
     {TEST_VALID_CC,             TEST_FRAME_DROP,   TEST_PROG_FRAME,          false, false},
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, false},
     //9

     //Validity and Polarity test frames
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, true},
     {TEST_VALID_CC1_INVALID_CC2,TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, false},
     {TEST_INVALID_CC,           TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, false}, //12
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, true},
     {TEST_INVALID_CC1_VALID_CC2,TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, false},
     {TEST_INVALID_CC,           TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, false}, //15
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, true},
     {TEST_VALID_CC1_INVALID_CC2,TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, false},
     {TEST_INVALID_CC,           TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, false}, //18
     //18

     //Timing and Polarity test frames
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, true},
     {TEST_VALID_CC,             TEST_FRAME_LATE,   TEST_PROG_FRAME,          false, false},
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, false}, //21
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, true},
     {TEST_VALID_CC,             TEST_FRAME_DROP,   TEST_INTL_POLARITY_TOP,   false, false},
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, false}, //24
     {TEST_VALID_CC,             TEST_FRAME_LATE,   TEST_INTL_POLARITY_TOP,   false, true},
     {TEST_VALID_CC,             TEST_FRAME_DROP,   TEST_INTL_POLARITY_TOP,   false, false},
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, false}, //27

     //Timing and Validity test frames
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, true},
     {TEST_INVALID_CC1_VALID_CC2,TEST_FRAME_LATE,   TEST_PROG_FRAME,          false, false},
     {TEST_INVALID_CC,           TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, false}, //30
     {TEST_INVALID_CC1_VALID_CC2,TEST_FRAME_DROP,   TEST_INTL_POLARITY_TOP,   false, true},//
     {TEST_INVALID_CC,           TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, false},
     {TEST_VALID_CC1_INVALID_CC2,TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, false}, //33

     //Combined test frames
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, true},
     {TEST_VALID_CC1_INVALID_CC2,TEST_FRAME_LATE,   TEST_PROG_FRAME,          false, false},
     {TEST_VALID_CC1_INVALID_CC2,TEST_FRAME_LATE,   TEST_PROG_FRAME,          false, false}, //36
     {TEST_INVALID_CC,           TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, false},
     {TEST_VALID_CC1_INVALID_CC2,TEST_FRAME_DROP,   TEST_PROG_FRAME,          false, false},//
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_PROG_FRAME,          false, false}, //39

     {TEST_INVALID_CC,           TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, true},
     {TEST_VALID_CC1_INVALID_CC2,TEST_FRAME_DROP,   TEST_INTL_POLARITY_TOP,   false, false},
     {TEST_VALID_CC1_INVALID_CC2,TEST_FRAME_DROP,   TEST_INTL_POLARITY_TOP,   false, false},
     {TEST_VALID_CC,             TEST_FRAME_NORMAL, TEST_INTL_POLARITY_TOP,   false, false},
     {TEST_VALID_CC,             TEST_FRAME_LATE,   TEST_INTL_POLARITY_TOP,   false, false},
  };

  //populate frame attributes structure
  ismd_result_t populate_frame_attr(ismd_frame_attributes_t *frame_attr, test_frame_input_config_t frame_config, int index)
  {
  	ismd_result_t result = ISMD_SUCCESS;

  	/*configure NTSC (EIA-608) closed caption information associated with each frame*/
  	switch (frame_config.test_frame_validity) {
          case TEST_INVALID_CC:
              frame_attr->EIA_608_capt[0].cc_valid = 0;
              frame_attr->EIA_608_capt[1].cc_valid = 0;
              frame_attr->EIA_608_capt[0].cc_data1 = cc_text[cc_text_index%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[0].cc_data2 = cc_text[(cc_text_index+1)%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[1].cc_data1 = cc_text[(cc_text_index+2)%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[1].cc_data2 = cc_text[(cc_text_index+3)%CC_TEXT_LENGTH];
              cc_text_index=(cc_text_index+4)%CC_TEXT_LENGTH;
              break;
          case TEST_VALID_CC1_INVALID_CC2:
              frame_attr->EIA_608_capt[0].cc_valid = 1;
              frame_attr->EIA_608_capt[1].cc_valid = 0;
              frame_attr->EIA_608_capt[0].cc_data1 = cc_text[cc_text_index%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[0].cc_data2 = cc_text[(cc_text_index+1)%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[1].cc_data1 = cc_text[(cc_text_index+2)%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[1].cc_data2 = cc_text[(cc_text_index+3)%CC_TEXT_LENGTH];
              cc_text_index=(cc_text_index+4)%CC_TEXT_LENGTH;
              break;
          case TEST_INVALID_CC1_VALID_CC2:
              frame_attr->EIA_608_capt[0].cc_valid = 0;
              frame_attr->EIA_608_capt[1].cc_valid = 1;
              frame_attr->EIA_608_capt[0].cc_data1 = cc_text[cc_text_index%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[0].cc_data2 = cc_text[(cc_text_index+1)%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[1].cc_data1 = cc_text[(cc_text_index+2)%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[1].cc_data2 = cc_text[(cc_text_index+3)%CC_TEXT_LENGTH];
              cc_text_index=(cc_text_index+4)%CC_TEXT_LENGTH;
              break;
          default:
              frame_attr->EIA_608_capt[0].cc_valid = 1;
              frame_attr->EIA_608_capt[1].cc_valid = 1;
              frame_attr->EIA_608_capt[0].cc_data1 = cc_text[cc_text_index%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[0].cc_data2 = cc_text[cc_text_index+1)%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[1].cc_data1 = cc_text[cc_text_index+2)%CC_TEXT_LENGTH];
              frame_attr->EIA_608_capt[1].cc_data2 = cc_text[cc_text_index+3)%CC_TEXT_LENGTH];
              cc_text_index=(cc_text_index+4)%CC_TEXT_LENGTH;
        }

      frame_attr->EIA_608_capt[2].cc_valid = 0;

      switch (frame_config.test_frame_polarity) {
          case TEST_INTL_POLARITY_TOP:
              frame_attr->polarity = ISMD_POLARITY_FIELD_TOP;
              frame_attr->EIA_608_capt[0].cc_type  = 0;
              frame_attr->EIA_608_capt[1].cc_type  = 1;
              break;
          case TEST_INTL_POLARITY_BOTTOM:
              frame_attr->polarity = ISMD_POLARITY_FIELD_BOTTOM;
              frame_attr->EIA_608_capt[0].cc_type  = 1;
              frame_attr->EIA_608_capt[1].cc_type  = 0;
              break;
          default:
              frame_attr->polarity = ISMD_POLARITY_FRAME;
              frame_attr->EIA_608_capt[0].cc_type  = -1;
              frame_attr->EIA_608_capt[1].cc_type  = -1;
        }

  	/*configure other frame attributes*/
  	//frame_attr->original_pts = ;
      //frame_attr->local_pts = ;
      //frame_attr->polarity = ;
      //let y,u,v addresses be same as pts values for testing
      //frame_attr->y      = frame_attr->local_pts;
      //frame_attr->u      = frame_attr->local_pts;
      //frame_attr->v      = frame_attr->local_pts;
      //frame_attr->pixel_format    = ISMD_PF_NV16;
      //frame_attr->gamma_type      = ISMD_GAMMA_NTSC;
      //frame_attr->color_space     = ISMD_SRC_COLOR_SPACE_BT601;
      //frame_attr->cont_rate       = 0;
      //frame_attr->dest_size.width = ;
      //frame_attr->dest_size.height= ;
      //frame_attr->cont_pan_scan[0].horz_offset = pan_scan_h_offset;
      //frame_attr->cont_pan_scan[0].vert_offset = pan_scan_v_offset;

      return result;
  } // end populate_frame_attr()


  /* Create frame buffer and write to input port */
  ismd_result_t frame_input (test_frame_input_config_t frame_config, ismd_pts_t *pts, bool set_original_pts, int index)
  {
     ismd_result_t result=ISMD_SUCCESS;
     ismd_buffer_descriptor_t desc;
     ismd_frame_attributes_t frame_attr;
     ismd_newsegment_tag_t newsegment_data;

      /* Create a frame buffer */
      result = ismd_frame_buffer_alloc(rend_data.width,rend_data.height, &rend_data.buffer);
      if (result != ISMD_SUCCESS) {
          OS_PRINT( "ismd_frame_buffer_alloc, failed\n");
          OS_PRINT( "result: got %d, expected %d\n", result, ISMD_SUCCESS );
          fflush( stdout );
      }

      /* Populate the frame buffer attributes here - PTS and polarity */
      result = populate_frame_attr (&frame_attr, frame_config, index);

      /* Read buffer desctriptor */
      result = ismd_buffer_read_desc(rend_data.buffer,&desc);
      if ( result != ISMD_SUCCESS ) {
          OS_PRINT("Error: Could not read buffer descriptor\n");
         return result;
      }

      /* Copy the frame attributes to buffer descriptor */
      memcpy (desc.attributes, &frame_attr, sizeof(ismd_frame_attributes_t));

      result = ismd_buffer_update_desc(rend_data.buffer, &desc);
      if ( result != ISMD_SUCCESS ) {
         OS_PRINT("Error: Could not update buffer attributes\n");
         return result;
      }

      if (set_original_pts) {
          newsegment_data.linear_start   = 0;
          newsegment_data.start          = 0;
          newsegment_data.stop           = ISMD_NO_PTS;
          newsegment_data.requested_rate = ISMD_NORMAL_PLAY_RATE;
          newsegment_data.applied_rate   = ISMD_NORMAL_PLAY_RATE;
          newsegment_data.rate_valid     = true;

          result = ismd_tag_set_newsegment(rend_data.buffer, newsegment_data);
          if (result != ISMD_SUCCESS) {
              OS_PRINT("Error: Could not set newsegment tag.\n");
              return result;
          }
      }

      /* Write buffer into the input port */
      result = ISMD_ERROR_UNSPECIFIED;
      while (result != ISMD_SUCCESS)
      {
          result = ismd_port_write(rend_data.input_port, rend_data.buffer);
          if(result != ISMD_SUCCESS) {
             os_sleep( (unsigned long)(1)); // sleep for 1 ms
          } else {
              rend_data.port_frame_count++;
          }
      }

      rend_data.last_written_pts = frame_attr.original_pts;
      rend_data.frames_written++;
      *pts = frame_attr.local_pts;

      return result;
  } // end frame_input()



  //
  int main(void)
  {
      ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
  	int content_rate = 30;    //30fps
  	ismd_pts_t pts = VIDREND_CLOCK_FREQUENCY/content_rate;
  	unsigned int index = 0;

      /*configuration video render: fill up rend_data structure*/
  	//result = configure_vidrend();

  	/*start video render*/
  	//result = start_vidrend();

      /* Write frame buffers into the input port */
      for (index=0; index< CC_TEST_INPUT; index++)
      {
  		if (input_config[index].reset_cc_text_index) {
              cc_text_index = 0;
          }
          result = frame_input(input_config[index], &pts, false, index);
          if (result != ISMD_SUCCESS) {
              OS_PRINT("Error: Cannot input frame number %d\n", index);
              return false;
          }
      }


      /* Unconfigure video renderer*/
      //result = unconfigure_vidrend();

  	return 0;
  }

  \endcode
<br>
<br>
<br>
<br>
    \anchor vidrendcon3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.3  Event Handling</h2>

The application can register to be notified on the following renderer events:
-# Late display interrupts event (framestart interrupt occurs much later than expected)
-# Late frames event (PTS of frames read from port are in the past � the demux might have to rebase PTS correctly)
-# Attribute changes event
-# End of stream (EOS) event
-# Start of segment event
-# Frame flipped event
-# Input underflow event (input of renderer was empty)
-# Underflow recovered event.

<br>
<br>

\anchor vidrendcon3a
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.3.1 Code Snippet:  Event Handling</h2>

\code
#include "ismd_core.h"
#include "ismd_vidrend.h"
#include "ismd_core_protected.h"
#include "vbd.h"



//event thread running status
bool event_thread_created;
//event list
ismd_event_t event_list[NUM_OF_EVENTS];
//event countor
unsigned int event_count[NUM_OF_EVENTS];


// Event notification support thread
void *get_events(void *data)
{
    ismd_result_t result;
    ismd_event_t event_got;
    int *temp = (int *) data;
    int rend_num = *temp;

    while (event_thread_created)
    {
        result = ismd_event_wait_multiple(event_list, NUM_OF_EVENTS, 10, &event_got);
        if (result == ISMD_ERROR_TIMEOUT) {
            break;
        }
        ismd_event_acknowledge(event_got);

        if (event_got == event_list[ISMD_VIDREND_EVENT_TYPE_VSYNC]) {
            event_count[ISMD_VIDREND_EVENT_TYPE_VSYNC]++;
            OS_PRINT("Got vsync event\n");
        } else if (event_got == event_list[ISMD_VIDREND_EVENT_TYPE_ERROR]) {
            event_count[ISMD_VIDREND_EVENT_TYPE_ERROR]++;
            OS_PRINT("Got error event\n");
        } else if (event_got == event_list[ISMD_VIDREND_EVENT_TYPE_EOS]) {
            event_count[ISMD_VIDREND_EVENT_TYPE_EOS]++;
            OS_PRINT("Got eos event\n");
        } else if (event_got == event_list[ISMD_VIDREND_EVENT_TYPE_RES_CHG]) {
            event_count[ISMD_VIDREND_EVENT_TYPE_RES_CHG]++;
            OS_PRINT("Got resolution change event\n");
        } else if (event_got == event_list[ISMD_VIDREND_EVENT_TYPE_CLIENT_ID_SEEN]) {
            event_count[ISMD_VIDREND_EVENT_TYPE_CLIENT_ID_SEEN]++;
            OS_PRINT("Got client id event\n");
        }
    }

    OS_PRINT("Event thread done\n");

    return NULL;
} // end get_events()

//
int main(void)
{
    ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
    ismd_dev_t rend;
	os_thread_t event_thread;
    osal_result osal_ret;
	int temp = 0;

    /*configuration video render*/
	//result = configure_vidrend();

	/*start video render*/
	//result = start_vidrend();

	/* Get the renderer events */
    if((result = ismd_vidrend_get_vsync_event(rend, &event_list[ISMD_VIDREND_EVENT_TYPE_VSYNC])) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_get_vsync_event failed: %d\n", result);
    }
    event_count[ISMD_VIDREND_EVENT_TYPE_VSYNC] = 0;

    if((result = ismd_vidrend_get_error_event(rend, &event_list[ISMD_VIDREND_EVENT_TYPE_ERROR])) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_get_error_event failed: %d\n", result);
    }
    event_count[ISMD_VIDREND_EVENT_TYPE_ERROR] = 0;

    if((result = ismd_vidrend_get_eos_event(rend,&event_list[ISMD_VIDREND_EVENT_TYPE_EOS])) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_get_eos_event failed: %d\n", result);
    }
    event_count[ISMD_VIDREND_EVENT_TYPE_EOS] = 0;

    if((result = ismd_vidrend_get_resolution_change_event(rend, &event_list[ISMD_VIDREND_EVENT_TYPE_RES_CHG])) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_get_resolution_change_event failed: %d\n", result);
    }
    event_count[ISMD_VIDREND_EVENT_TYPE_RES_CHG] = 0;

    if((result = ismd_vidrend_get_client_id_seen_event(rend, &event_list[ISMD_VIDREND_EVENT_TYPE_CLIENT_ID_SEEN])) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_get_client_id_seen_event failed: %d\n", result);
    }
    event_count[ISMD_VIDREND_EVENT_TYPE_CLIENT_ID_SEEN] = 0;


	/* create thread to get events from the renderer and start it to wait/acknowledge events */
    osal_ret = os_thread_create(&event_thread, get_events,&temp, 0, 0, "event_thread");
    if (osal_ret != OSAL_SUCCESS) {
        OS_PRINT("VR: Unable to create events thread=%d.\n", osal_ret);
        event_thread_created = false;
        result = ISMD_ERROR_NO_RESOURCES;
    } else {
		event_thread_created = true;
        OS_PRINT("VR: Get events thread created...\n");
    }

    /* Write frame buffers into the input port */
    ;

	/* Destory get events thread*/
    if (event_thread_created) {
        os_thread_wait(&event_thread, 1);
        osal_ret = os_thread_destroy(&event_thread);
        if (osal_ret != OSAL_SUCCESS) {
			OS_PRINT("VR: Unable to destroy events thread = %d.\n",osal_ret);
            result = ISMD_ERROR_NO_RESOURCES;
        }
		event_thread_created = false;
    }

    /* Unconfigure video renderer*/
    //result = unconfigure_vidrend();

	return 0;
}

\endcode
<br>
<br>
<br>
<br>

    \anchor vidrendcon4
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.4  Hold Time</h2>

The renderer presents frames to display when the PTS becomes current. Most transport streams contain first audio and video PTS close to each other and close to the first PCR and hence the time to display first frame is close to the first rendered audio sample maintaining AV sync.
Sometimes content might be encoded such that first video PTS is a few seconds after the PCR. In this case, audio can be heard for a few seconds before the first video frame is actually seen. This is usually not acceptable because channel change time seems longer than usual in this case (case 1).
The hold time is a feature introduced in the renderer to handle this situation by presenting video to the display as soon as possible. If no new frame is ready to be displayed (no PTS match) for �hold time� after the last frame has been displayed, the renderer sends a new frame to the display even if its PTS is not current. Audio and video will not be in sync for the initial few frames but AV sync will be attained within a couple of seconds. Video will appear to be played in slow motion until this is achieved (Case 2). The time to achieve AV sync depends on the �hold time� and the stream properties (how far the first video PTS is from audio PTS). As seen in Case 2 and 3 of the figure, a larger hold time value (Case 3) presents video to display that much slower but AV sync is achieved faster than with a smaller hold time (Case 2). With usual content, audio and video PTS are close enough and the maximum hold time feature does not come into effect.

  \image  html vidrend2.png Fig.17 AV Sync with and without Hold Time


  The hold time feature has another useful side effect of letting the renderer recover from large frame PTS. Without the hold time, this scenario would cause a video freeze until that large PTS becomes current. With the hold time, the renderer will stall only until the hold time after the previous flip. There are legal scenarios like VC1 still picture content and HD-DVD seamless audio and non-seamless video scenarios where the content has presentation timestamps far apart. In most of these cases, the application has knowledge of the type of content and can disable the hold time feature.

<br>
<br>

 \anchor vidrendcon4a
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.4.1  Code Snippet: Hold Time</h2>

 \code
 #include "ismd_core.h"
 #include "ismd_vidrend.h"
 #include "ismd_core_protected.h"
 #include "vbd.h"



 // Renderer Data
 typedef struct {
    ismd_dev_t rend;
    ismd_clock_t clock;
    ismd_time_t base_time;
    ismd_port_handle_t input_port;
    unsigned int plane;
    ismd_vidrend_test_params_t params;
    bool renderer_running;

    ismd_frame_polarity_t content_polarity;
    ismd_time_t content_rate; //frames or fields per second
    int effective_content_rate;
    int pts_increment;
    int width;
    int height;

    ismd_test_passing_criteria_t pass_criteria_number;
    vidrend_test_case_t test_case;
    vidrend_test_behavior_t behavior;
    unsigned int input_frame_count;
    int expected_frame_count;
    int flipped_frame_count;
    int port_frame_count;
    unsigned int TopUV_BottomUV_Diff;

    ismd_time_t current_time;

    ismd_buffer_handle_t buffer;
    bool test_failed_flag;
    unsigned int prev_top_uv_ptr;
    unsigned int prev_pts;
    unsigned int frames_written;
    ismd_pts_t max_pts;
    ismd_pts_t last_written_pts;
    int count_th_calls;

    ismd_event_t eos;
    ismd_event_t event_list[NUM_OF_EVENTS];
    unsigned int event_count[NUM_OF_EVENTS];
    bool event_thread_created;
    os_thread_t event_thread;
    ismd_vidrend_stats_t stats;
    ismd_vidrend_status_t status;
    bool events_test_completed;

    bool flush_eos;
    bool flush_play;
    bool flush_pause;
    bool flush_frame_repeated;
    ismd_pts_t frame_pts_after_flush;
    int flush_repeated_frames;
    int black_frames_flipped;
    bool flush_test_pass[2][4];

    os_event_t wait_to_input_event;
    os_event_t drop_event;
    os_event_t late_event;
    bool drop_frame;
    bool late_frame;
    bool waiting_to_input_late_frame;
    bool waiting_to_input_drop_frame;
    ismd_pts_t drop_frame_pts;
    ismd_pts_t late_frame_pts;

    bool state_change_thread_running;
    bool state_change_thread_created;
    bool renderer_paused;
    os_thread_t state_change_thread;
    ismd_time_t paused_clock_value;

    cc_test_type_t cc_test_case[18];
    int cc_text_index;
    bool was_prev_frame_late;
    bool was_prev_frame_drop;

 } test_rend_data_t;

 //render instance
 test_rend_data_t rend_data;

 //
 int main(void)
 {
     ismd_result_t result = ISMD_ERROR_UNSPECIFIED;

     /*configuration video render*/
 	result = configure_vidrend();

 	/* set the hold time to 10 frames  - as a robustness measure against bas PTS valuse*/
     if((result = ismd_vidrend_enable_max_hold_time(rend_data.rend, 10, 1)) != ISMD_SUCCESS)
     {
         OS_PRINT("ismd_vidrend_enable_max_hold_time failed: %d\n", result);
 		return result;
     }

 	/*start video render*/
 	result = start_vidrend();

     /* Unconfigure video renderer*/
     result = unconfigure_vidrend();

 	return 0;
 }

 //
 ismd_result_t configure_vidrend()
 {
    ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
    //
    if((result = ismd_vidrend_open(&rend_data.rend)) != ISMD_SUCCESS) {
        OS_PRINT("vidrend_open failed: %d\n", result);
    }
    //
    if((result = ismd_vidrend_get_input_port(rend_data.rend,&rend_data.input_port)) != ISMD_SUCCESS)
    {
        OS_PRINT("vidrend_get_input_port failed: %d\n", result);
    }
    // Set video plane same as renderer instance
    rend_data.plane = 0;
    if((result = ismd_vidrend_set_video_plane(rend_data.rend,rend_data.plane)) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_set_video_plane failed: %d\n", result);
    }
    // Set clock same as renderer instance
    rend_data.clock = rend_data.rend;
    // Set vsync pipeline A
    if((result = ismd_clock_set_vsync_pipe(rend_data.clock, 0)) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_clock_set_vsync_pipe failed: %d\n", result);
    }
    // Set clock
    if((result = ismd_dev_set_clock(rend_data.rend,rend_data.clock)) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_dev_set_clock failed: %d\n", result);
    }
    //Set display rate, i.e.ISMD_VIDREND_INTERLACED_RATE_59_94
    if((result = ismd_vidrend_set_interlaced_display_rate(ISMD_VIDREND_INTERLACED_RATE_59_94)) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_set_interlaced_display_rate failed: %d\n", result);
    }
    //fixed frame rate is enabled
    if((result = ismd_vidrend_enable_fixed_frame_rate(rend_data.rend,rend_data.fixed_frame_rate_interval)) != ISMD_SUCCESS)
    {
        OS_PRINT("ismd_vidrend_enable_fixed_frame_rate failed: %d\n", result);
    }

    return result;
 }

 // Start video renderer
 ismd_result_t start_vidrend()
 {
     ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
     rend_data.base_time = rend_data.current_time;
     //
 	result = ismd_dev_set_stream_base_time (rend_data.rend, rend_data.base_time);
     if(result != ISMD_SUCCESS ) {
         OS_PRINT("ismd_dev_set_base_timeismd_dev_set_stream_base_time failed: got %d, expected %d\n", result, ISMD_SUCCESS);
         fflush( stdout );
         return (result);
     }
     //start the renderer
     if((result = ismd_dev_set_state(rend_data.rend,ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
         OS_PRINT("ismd_dev_set_state start failed: %d\n", result);
     } else {
         OS_PRINT("Renderer playing\n");
         rend_data.renderer_running = true;
     }

     return result;
 } // end start_vidrend()

 //
 ismd_result_t unconfigure_vidrend()
 {
     ismd_result_t result = ISMD_SUCCESS;
     // Renderer State = Stop
     result = ismd_dev_set_state(rend_data[rend_num].rend, ISMD_DEV_STATE_STOP);
     if (result != ISMD_SUCCESS) {
         OS_PRINT("Error setting renderer state to stop %d\n", result);
     } else {
         OS_PRINT("Renderer Stopped\n");
     }

     if((result = ismd_dev_close(rend_data.rend)) != ISMD_SUCCESS) {
         OS_PRINT("vidrend_close failed: %d\n", result);
         return result;
     }

     return result;
 } // end unconfigure_vidrend()

 \endcode


 \anchor vidrendcon5
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.5  Stream Position</h2>

 The renderer provides the feature of query current stream position by API ismd_vidrend_get_stream_position(). If the pipeline is flushed and playback is restarted, stream position is not available before the first buffer goes into vidrend through the pipeline. In this case, vidrend will return a NO_DATA_AVAILABLE error. To handle this special case, the correct way to query stream position from vidrend is that the application continuously calls ismd_vidrend_get_stream_position() until it returns ISMD_SUCCESS.

  \anchor vidrendcon5a
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.5.1 Code Snippet:  Stream Position</h2>
 \code
 #include "ismd_core.h"
 #include "ismd_vidrend.h"
 #include "ismd_core_protected.h"
 #include "vbd.h"

 int main(void)
 {
     ismd_result_t result = ISMD_ERROR_UNSPECIFIED;
     ismd_dev_t rend;
     ismd_port_handle_t input_port;
     ismd_port_handle_t output_port;
     unsigned int plane;
     ismd_clock_t clock;
     ismd_time_t base_time;
     ismd_time_t current_time;
     ismd_event_t eos;
     ismd_vidrend_stream_position_info_t smd_position;
     int wait_count = 0;

     if((result = ismd_vidrend_open(&rend)) != ISMD_SUCCESS) {
         OS_PRINT("vidrend_open failed: %d\n", result);
     }

     if((result = ismd_vidrend_get_input_port(rend, &input_port)) != ISMD_SUCCESS)
     {
         OS_PRINT("vidrend_get_input_port failed: %d\n", result);
     }
     // Set video plane same as renderer instance
     plane = 0;
     if((result = ismd_vidrend_set_video_plane(rend, plane)) != ISMD_SUCCESS)
     {
         OS_PRINT("ismd_vidrend_set_video_plane failed: %d\n", result);
     }
     // Set clock same as renderer instance
     clock = rend;
     // Set vsync pipeline A
     if((result = ismd_clock_set_vsync_pipe(clock, 0)) != ISMD_SUCCESS)
     {
         OS_PRINT("ismd_clock_set_vsync_pipe failed: %d\n", result);
     }
     // Set clock
     if((result = ismd_dev_set_clock(rend, clock)) != ISMD_SUCCESS)
     {
         OS_PRINT("ismd_dev_set_clock failed: %d\n", result);
     }

     base_time = current_time = 0;
     result = ismd_dev_set_stream_base_time (rend, base_time);
     if(result != ISMD_SUCCESS ) {
         OS_PRINT("VR: ismd_dev_set_base_timeismd_dev_set_stream_base_time failed: got %d, expected %d\n", result, ISMD_SUCCESS);
     }
     //start the renderer
     if((result = ismd_dev_set_state(rend, ISMD_DEV_STATE_PLAY)) != ISMD_SUCCESS) {
         OS_PRINT("ismd_dev_set_state start failed: %d\n", result);
     } else {
         OS_PRINT("Renderer playing\n");
     }
     // Allocate eos event for the instance
     if ((result = ismd_event_alloc(&eos)) != ISMD_SUCCESS) {
         OS_PRINT("ERROR: Event eos creation failed for instance.%d\n", result);
     }

     // Enable output port in video renderer
     result = ismd_vidrend_enable_port_output(rend, 0, 1, &output_port);
     if (result != ISMD_SUCCESS) {
         OS_PRINT("Unable to enable port output in video renderer.%d\n", result);
     }

     // Attach to the output port before starting to read
     result = ismd_port_attach(output_port, ISMD_EVENT_HANDLE_INVALID
                                                         , ISMD_QUEUE_EVENT_ALWAYS
                                                         , ISMD_QUEUE_WATERMARK_NONE);
     if (result != ISMD_SUCCESS) {
         OS_PRINT("Unable to attach to video renderer output port.%d\n", result);
     }

     // Write frame buffers into the input port

     // Disable video renderer output port
     result = ismd_vidrend_disable_port_output(rend);
     if (result != ISMD_SUCCESS) {
         OS_PRINT("Unable to disable output port in video renderer.%d\n",result);
     }

     // Wait on eos event
     while(ismd_event_wait(eos, 1000) == ISMD_ERROR_TIMEOUT) {

         // Query stream position in video renderer every 1 second
         result = ismd_vidrend_get_stream_position(rend, &smd_position);
         for (wait_count = 0; wait_count < 10 && result == ISMD_ERROR_NO_DATA_AVAILABLE; wait_count++) {
             // wait a while for video renderer to have stream position information
             os_sleep(10);
             result = ismd_vidrend_get_stream_position(rend, &smd_position);
         }
         if (result ==  ISMD_ERROR_NO_DATA_AVAILABLE) {
             OS_PRINT("Warning: no data availbe in vidrend; stream position info is not reliable.\n");
         } else if (result != ISMD_SUCCESS) {
             OS_PRINT("Unable to do position query in video renderer.%d\n", result);
         }
     }

     // Unconfigure video renderer
     result = ismd_dev_set_state(rend, ISMD_DEV_STATE_STOP);
     if (result != ISMD_SUCCESS) {
          OS_PRINT("Error setting renderer state to stop %d\n", result);
     }

     if((result = ismd_dev_close(rend)) != ISMD_SUCCESS) {
       OS_PRINT("vidrend_close failed: %d\n", result);
       return result;
     }
     return 0;
 }



 \endcode

<br>
<br>
<br>
<br>

 \anchor vidrendcon6
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.6  Video Mute</h2>

 The render provides the feature of muting video by API ismd_vidrend_mute(). When it is enabled, video render will process the incoming frames, but will drop them instead of flipping them. This feature can be used when swapping Z-axis order of two concurrent video windows of different sizes/positions.
 The video mute API:
 ismd_result_t ismd_vidrend_mute (ismd_dev_t  *vidrend, ismd_vidrend_mute_policy_t mode);
 This function allows the client programmer to tell the vidrend to stop displaying frames, and to either display a black frame or hold the last displayed frame. When the user wants to re-enable the display, the application should call this function passing in the value of ISMD_VIDREND_MUTE_NONE into the mode parameter.
 If the mode is ISMD_VIDREND_MUTE_DISPLAY_BLACK_FRAME, a black frame/field is displayed.
 If the mode is ISMD_VIDREND_MUTE_HOLD_LAST_FRAME, last frame is kept on the screen.
 If the mode is ISMD_VIDREND_MUTE_NONE, the renderer sends new frames/fields to the display. This is the default value after vidrend is initialized.
 This operation is invalid if the render is not started or plane id is not set.
<br>
<br>
<br>
<br>
 \anchor vidrendcon7
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5C.4.7  Stereo 3D Support</h2>
 The renderer supports the concept of stereoscopic 3D streams. In this mode each renderer device context represents a 2D view. Two views are linked to form a stereoscopic 3D stream using the ismd_vidrend_link_views() API. The views are termed the base and the dependent view. When using linked views many APIs such as flush and set stat� are shared between the two linked views, in general any API that manipulates or provides information about a single incoming video stream will still operate only on that stream (this includes events) however APIs that manipulate the behavior of the combined outgoing stream are linked. When views are linked the frames arriving on both views are required to have matching timestamps, if they do not then the mismatched frames are not displayed, resulting in an effective video freeze.
 The video renderer and Display driver are configured in tandem to produce 3D output. For most HDMI 1.4 compatible formats the Display driver can be configured to support the format without extra work on the part of the video renderer. These formats behave similarly to Picture in picture and Picture on Picture cases with the added feature that the two views are time synced. For some formats, notably Frame Sequential, two video streams must be muxed onto one video plane. In these cases the dependent view should not have a video plane associated with it; instead it will use the video plane from the base view.
In some cases the application goal may be to render stereoscopic frames to a normal 2D output frame for use by a pre HDMI 1.4 device. For compatible formats (such as side by side half and over under half) vidrend provides an extra API, called ismd_vidrend_set_dependent_origin_offset(), to set the offset of the origin of the dependent view from the base view (normally either half the frame width or height). This API should always be set, however in the case where the Display Driver has been configured

<br>
<br>
<br>
<br>
\anchor vidMo
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5D  Video Mosaic</h2>
The mosaic use case is a scenario where multiple video streams are presented simultaneously as part of a graphical user interface.  The videos are presented
integrated with graphics and the entire presentation uses animation on both the graphics and videos.  The user can interact with the presentation and this may
drive some of the animations.  A hypothetical example for illustrative purposes might be five videos arranged in a circle where four of the videos are playing at a
smaller size and one is playing at a much larger size.  The video of the larger size is the "selected" video.  The user can navigate between the videos using left
and right arrows.  As the user presses an arrow, the circle of videos rotates in the indicated direction.  As it rotates the sizes of the videos smoothly change so
that the video rotating into the selected position grows to the large size and the video rotating out of the selected position shrinks to the smaller size.  So we
are animation of the video's sizes and positions. Other effects might include 3D transformations where perhaps the planar model on which the non-selected videos are
being textured move through a sequence of 3D rotations as they move around the circle and masking so that each video has rounded corners.   The video ring is
displayed integrated with a rich graphical background that may also include animations.  Throughout the experience each of the videos is playing.

To support mosaic video, all modules in video pipeline need to support multiple instances. Each instance will handle one single video stream. Currently on CE3100, the number of instances we need to support is 8.
Figure 14 illustrates the general work flows in video pipeline for mosaic. All output frames will be read, processed, and rendered by video as texture module in customer app, which is not part of this design doc.
\image html Fig.14 vidMo.png High Level Video Pipeline Configuration

<br>
<br>


Two APIs were added in ismd_core_protected.h.
-# One is to allocate YUV or MH buffer \ref ismd_intermediate_buffer_alloc
-# the other is to free YUV or MH buffer back to buffer manage ismd_intermediate_buffer_free


\code
Following memory will be DELETED and merge into smd_frame_buffers:
smd_buffers_VPP_YUV1   { buf_size =  0x660000    base = 0x137A0000    size = 0x00660000 } // (6.4MB) 3x2.125MB VidPProc Intermediate Stream 3
smd_buffers_VPP_MH1    { buf_size =  0x220000    base = 0x13E00000    size = 0x00440000 } // (4.2MB) 2x2.125MB VidPProc Motion History Stream 3
smd_buffers_VPP_YUV2   { buf_size =  0x660000    base = 0x14240000    size = 0x00660000 } // (6.4MB) 3x2.125MB VidPProc Intermediate Stream 4
smd_buffers_VPP_MH2    { buf_size =  0x220000    base = 0x148A0000    size = 0x00440000 } // (4.2MB) 2x2.125MB VidPProc Motion History Stream 4

smd_buffers_VPP_YUV3   { buf_size =  0x660000    base = 0x137A0000    size = 0x00660000 } // (6.4MB) 3x2.125MB VidPProc Intermediate Stream 3
smd_buffers_VPP_MH3    { buf_size =  0x220000    base = 0x13E00000    size = 0x00440000 } // (4.2MB) 2x2.125MB VidPProc Motion History Stream 3
smd_buffers_VPP_YUV4   { buf_size =  0x660000    base = 0x14240000    size = 0x00660000 } // (6.4MB) 3x2.125MB VidPProc Intermediate Stream 4
smd_buffers_VPP_MH4    { buf_size =  0x220000    base = 0x148A0000    size = 0x00440000 } // (4.2MB) 2x2.125MB VidPProc Motion History Stream 4

Additonal memory will be ADDED to smd_frame_buffers for DPE YUV and MH buffer:
smd_frame_buffers      {                         base = 0x077E0000    size = 0x0DD00000 } // (221MB) used to allocate 52 frame buffer regions, include normal, YUV and MH buffer

Additional memory will be ADDED for additional Video decoder queues, descriptors and video ES buffers for multiple streams:
smd_buffers_VID_ES3    { buf_size =    0x8000    base = 0x17FE0000    size = 0x00800000 } // (  8MB) 256x32KB Video ES Data from Demux
smd_buffers_VUSER3     { buf_size =     0x400    base = 0x187E0000    size = 0x00060000 } // ( 64KB) 6x64x1KB VidDec User-Data Buffers
smd_buffers_VDESC3     { buf_size =    0x8000    base = 0x18840000    size = 0x00030000 } // ( 32KB) 6x1x32KB VidDec FW Descriptors
//empty_space          {                         base = 0x18870000    size = 0x00010000 } // 64KB empty space
smd_buffers_VFWQ3      { buf_size =  0x100000    base = 0x18880000    size = 0x00600000 } // (  1MB) 6x1x1MB VidDec Firmware Stream Queue Stream 2

\endcode

\anchor vidWater
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 24pt"> 5E  Video WaterMarking</h2>
Watermark technology need pre-parsing and manipulating certain parts of video elementary stream before the stream syntax start to be parsed. The GV fw need to provide a set of hook APIs for enabling pre-processing ability.

One example of Watermarking system is like below figure. For each incoming NALUs, the watermarking algorithm will prepares certain bytes to check whether current NALU need to be watermarked.   If watermarking is needed for current NALU, the watermarking algorithm will write the watermarked bytes (generated based on private ID of the box) into original NALU. Then the watermarked NALU will be decoded like normal case.

\image html  vidWater.png  Fig.15 Watermark API Insertion

In Normal H264 decoding process nal is parsed by viddec_h264_parse function to generate the final workload.  In the case of watermakring, hook API is inserted and  could be rewritten for watermarking.

 Following API's are added to support Hook API
 -# \ref ismd_viddec_set_video_preproc_id_buffer
 -# \ref	ismd_viddec_set_video_preproc_pipeline_buffer
 -# \ref ismd_viddec_set_video_preproc_flags
 -# \ref ismd_viddec_get_video_preproc_flags

 Tools needed for FW and driver compilation
 -# Intel CE SDK
 -# gcc 4.2.4 for sparc
 -# receive CE4200 firmware library (gv_fw.a)
 -# Compile/Link firmware vpp_stb.c + library to generate firmware image (gv_fw.c)
 -# recompile viddec driver




 \anchor SMDVideorAPI
- \ref ismd_vidrend " Link to Video Render API"

 */


