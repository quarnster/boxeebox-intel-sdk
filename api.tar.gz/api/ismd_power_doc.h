/*

This file is provided under a dual BSD/GPLv2 license.  When using or
redistributing this file, you may do so under either license.

GPL LICENSE SUMMARY

Copyright(c) 2010 Intel Corporation. All rights reserved.

This program is free software; you can redistribute it and/or modify
it under the terms of version 2 of the GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
The full GNU General Public License is included in this distribution
in the file called LICENSE.GPL.

Contact Information:

Intel Corporation
2200 Mission College Blvd.
Santa Clara, CA  97052

BSD LICENSE

Copyright(c) 2010 Intel Corporation. All rights reserved.
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:

* Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
* Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in
the documentation and/or other materials provided with the
distribution.
* Neither the name of Intel Corporation nor the names of its
contributors may be used to endorse or promote products derived
from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/



   /** @weakgroup new_smd_power  Chapter 7 Power Management SMD Demux
     \brief This  chapter provides description of SMD Core Components.

     \anchor Contents
	 	 <h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Contents</H2>
	        - <A HREF="#Introduction" style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 7A Introduction</A>

       	  	- <A HREF=#PowerMgm2 style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt">  7A.1 Power Management CE3100/CE4100</A>

       	  	- <A HREF=#PowerMgm3 style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 7A.2 Power Manager</A>

     	  	- <A HREF=#PowerMgm4 style="color:#000000; background-color:#EE82EE; font-weight :bold font-size : 30pt"> 7A.3 Audio Power Management </A>
     			- <A HREF=#PowerMgm5> 7A.3.1 How to Suspend/Resume </A>



\anchor Introduction
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">Introduction</h2>

The purpose of this document is to capture the architecture, assumptions, and implementation notes related to the Power Management software for Intel CE Media Processors.
At this time, the set of target processors includes the CE3100, CE4100, and CE4200.
The power management functionality is client-driven, where clients are customer applications/middleware.  Implementation comprises:
	-# A set of client rules: assumptions about how clients will interact with the power manager.

	-# A set of supported power modes for each supported SOC.  For each SOC, a section of the platform configuration file is used by the customer to define the names by which the modes will be invoked by power management clients.

	-# A set of APIs that PM-compliant drivers must implement, and standards with which they must comply.  In particular, all drivers must:
		-# export a suspend() function that will be invoked by the PM when it wishes to reduce power to the device controlled by the driver.
		-# export a resume() function that will be invoked by the PM when it wishes to restore power to the device controlled by the driver.
		-# call a power manager API when they are ready for a power state transition.  Drivers make power-state transitions within their suspend() or resume() functions;  but they may also transition to a low-power state autonomously if they can discover that their devices are not in use.
	-# A power manager (PM) component (intel_ce_pm-linux-x86) that provides APIs that allow:
		-# CE drivers to register for power management and to report power state changes.
		-# middleware/application clients to request specific power mode transitions.


\anchor PowerMgm1
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">  7A.1 Power Management for  CE3100/CE4100</H2>
As the hardware provides no power management support, power management is limited to gating the clocks of the devices controlled by five Intel CE drivers.
In addition, when the PM gates a device�s clocks, it puts the device into reset.
The CE3100/CE4100 implementation only supports two operational modes, one in which all affected devices are clock-gated, and one in which none are

<br>
<br>
<br>

CE4200 contains multiple islands that can be individually powered down, providing more significant power savings than clock gating. Islands are powered down/up by
a separate 8051-based P-unit on its own always-on island. Almost all devices in the system (including the CPU) can be powered down; the handful of devices on the P-Unit island can cause wakeup events.

Power modes on CE4100 are defined by the islands that are on/off.  Powering an island off requires stopping all devices on the island.  Table1  defines the power modes currently designed for CE4200.

<table border="1">
<caption> Table.1 CE4100 Power Modes</caption>
<tr> <th style="color:black;background-color:blue;" >Island </th> <th style="color:black;background-color:blue;" >1</th> <th style="color:black;background-color:blue;" >2</th> <th style="color:black;background-color:blue;" >3</th>
</tr>

<tr> <td>0     PUnit (always on)</td>	<td>ON</td>	<td>ON</td>	<td>ON</td></tr>

<tr> <td> 1     IA Backbone </td> <td>ON</td>	<td>ON</td>	<td>ON</td></tr>

<tr> <td> 1     SEC </td> <td>ON</td>	<td>ON</td>	<td>ON</td></tr>

<tr> <td>2.5  Recording devices: <br> H264 encoder <br> SATA<br> USB</td> <td>ON</td>	<td>ON</td>	<td>OFF</td></tr>

<tr> <td> 3    A/V Devices</td> <td>ON</td>	<td>OFF</td>	<td>OFF</td></tr>

<tr> <td> 4     CPU  </td> <td>ON</td>	<td>ON</td>	<td>ON</td></tr>

</table>

<br>
<br>
<br>
<br>


<table border="1">
<caption> Table.2 CE4100 Island 3 Devices</caption>
<tr> <th style="color:black;background-color:blue;" >CE Driver Name <th style="color:black;background-color:blue;" >Device Name/ID <th style="color:black;background-color:blue;" >Clock/Reset Signals</th>
</tr>
<tr>
<td>audio </td><td>Audio IF(0x2E60) Audio DSP 0/1(0x2E5F)</td>	<td>S_AU_DSP_CLK,L_AU_DSP_CLK,AU_XSI_CLK,AU_DSP0_RST,AU_DSP1_RST,AU_IF_RST</td>
</tr>

<tr>
<td>display </td><td>VDC(0x2E61) Audio DSP 0/1(0x2E63)</td>	<td>VDC_DA_CLK,VDC_DB_CLK,VDC_MDVO_CLK,VDC_XSI_CLK,VDC_CLK,HDMI_RST,HDMI_I2C_RST,VDC_RST
</td>
</tr>
<tr>
<td>Linux Driver </td><td>eMMC Controller(0x2070B)</td>	<td>NAND_RST
</td>
</tr>
<tr>
<td>Graphics </td><td>GFX(0x2E5B), 2D Graphics(0x070A)</td>	<td>GFX_CLK,GFX_RST,GFX2D_CLK,GFX2D_RST
</td>
</tr>

<tr>
<td>Linux Driver </td><td>PCIE 2x1(0x0101,0x0202)</td>	<td>PCIE_LGCLK,PCIE_BBCLK,PCIE_RST
</td>
</tr>

<tr>
<td>Vidcap </td><td>HDVCAP(0x0704)</td>	<td>HDVCAP_CLK,HDVCAP_RST</td>
</tr>

<tr>
<td>Viddec</td><td>GVSparc(0x0703),MFD(0x2E5C)</td>	<td>RSB_MFD_CLK,MPG4_MFD_CLK,VC1_MFD_CLK,H264_DEF640_CLK,GBLVSPARC_XSI_CLK,MFD_RST,GBLVSPARC_RST
</td>
</tr>
<tr>
<td>Vidpproc</td><td>DPE(0x2E62)</td>	<td>DPE_CLK,DPE_RST</td>
</tr>

</table>

<br>
<br>

<table border="1">
<caption> Table.3 CE4100 Island 2.5 Devices</caption>
<tr> <th style="color:black;background-color:blue;" >CE Driver Name <th style="color:black;background-color:blue;" >Device Name/ID <th style="color:black;background-color:blue;" >Clock/Reset Signals</th>
</tr>
<tr>
<td>h264_enc </td><td>H264 encoder(0x0706)</td>	<td>H264VE_CLK,H264VE_RST</td>
</tr>
<tr>
<td>Linux Driver </td><td>SATA(0x2E71)</td>	<td>SATA_CLK,SATA_RST
</td>
<tr>
<td>Linux Driver </td><td>USB(0x0101,Vendor ID 0x192)</td>	<td>USB_CLK480,USB_XSI_CLK,USB_RST_CFG,USB_RST_SW,USB_RST
</td>

</tr>
</table>

<em>Note: </em>
CE4200 silicon only permits power mode transitions between the FULL ON state and one of the STANDBY (lower power) states, or vice versa. Transitions between different STANDBY modes are not allowed.  In other words, if a transition does not include mode 0 as either the start state or the end state, it is illegal.


\anchor PowerMgm2
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt"> 7A.2 Power Manager</H2>
The PM is the software component intel_ce_pm-linux-x86.
When loaded, the PM:
-# processes the contents of the node platform.power in the platform configuration file.
-# locates the Linux PCI device structures for all supported devices (using the PCI Vendor ID and Device ID) in order to have access to the suspend()/resume() functions registered by those drivers.
-# assumes that all supported devices are in state D0, and tracks driver power mode  transitions to maintain its knowledge of the current power state of the devices.

The PM exposes two sets of APIs.
-# Function(s) in this interface are to be called by customer applications and middle, and are implemented in both kernel and user space.
At present, there is a single function defined in this API:  \ref icepm_ret_t icepm_set_mode(char *mode_name);
where mode_name is the name of a power mode defined in the platform configuration file.  This function attempts to transition the system to the specified power mode.

-# Functions in this interface must be called by Intel CE device drivers. These APIs are implemented only in kernel space.
	-# \ref icepm_device_register ( char *dev_name, icepm_functions_t *pfunc )
	-# \ref icepm_device_unregister( char *dev_name )
	-# \ref icepm_set_power_state

	Mode transitions will normally be peformed under client direction. When the client calls icepm_set_mode(), the PM:
	-#	Looks up the information for the requested power mode in its database, to determine which drivers must have power reduced or restored.
	-#	Invokes the suspend() function exported by the drivers of units that must be power-reduced.  When suspend() calls icepm_set_power_state(ICEPM_D3), the PM gates the clocks of devices controlled by the driver and puts them into reset.
	-#	Invokes the resume() function exported by the drivers of power-restored units. When resume() calls icepm_set_power_state(ICEPM_D0), the PM takes devices controlled by the driver out of reset and enables their clocks.

	In order for the PM component to receive the power state change notifications from the standard Linux drivers, it must register with the kernel in order to receive callbacks such as the one made from within pci_set_power_state().
	-#	Since this registration can only be done from within the kernel itself, a small hook was delivered to the platform team to permit registration of intel_ce_pm from a loadable kernel module.
	-#	Because other power management schemes (such as ACPI) also register for these callbacks, it will not be possible for any other power management mechanism to co-exist with intel_ce_pm.

	SOCs such as CE4200 contain multiple islands that can be individually powered down, providing more significant power savings than clock gating.  This has several implications for power management on these targets:

	-#	All drivers for devices on an island must be successfully suspended before the island can be powered down.

	-#	An island may contain devices driven by a mix of standard Linux drivers and Intel CE drivers.

	Because it is not desirable to require modification of Linux device drivers, standard Linux power management infrastructure is employed by the PM

	For Intel CE drivers, that infrastructure is abstracted with PM APIs.

	-#	The PM controls power to islands via a register interface to the firmware on the P-Unit.  For a complete understanding of the CE4200 power management capabilities and the responsibilities of hardware and firmware, see the CE4200 P-Unit EAS.
	Because the CE4200 silicon does not permit transitions from one standby (low-power) mode to another, the PM cannot disable power islands one at a time as it suspends the last driver for an island (or enable them when the first driver becomes active). Therefore, P-Unit programming to enable island(s) is done before resuming any affected drives, or after all affected drivers have been suspended.



\anchor PowerMgm3
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">  7A.3 Audio Power Management</H2>
At the time of bootup and insmod time, audio driver will register it�s own power management functions with Power Management driver public API pwr_device_register()/pwr_device_unregister(). The on top PM driver will call these registered API later when the system decides to suspend/resume, it is high level driver/application�s responsibility to make sure the pipeline is under PAUSE state before go into low-power state. For audio, that�s ismd_audio_suspend()/ismd_audio_resume().
What need to do before suspend/resume:
Audio driver is expected to keep current decoder parameters, running status (rate, segment info, play state), output configurations also well as audio frames before go into suspend.
And the resume function requires reverse actions: restore decoder parameters, restore playing state, output configurations�
Actually most of these information lay in system memory, so it will not be lost after enter/exit low-power state. But the driver need to make sure these information will not be destroyed due to reinitialize or resume the pipeline.
The only thing audio driver need to do is to close/clock-gated all none IA32 audio components which includes DSP0, DSP1 and audio input interface and audio output interface.

During this low-power state:
-# All audio threads are sleeping. (Except ATC thread is still waked up every 10ms)
-# Configuration, buffers, and parameters lays in system memory domain are still can read/write.
-# Data in DSP cache, and DSP internal stack/heap are no longer available.
-# Registers of DSP and audio interface(I2S0/I2S1/SPDIF/I2Scapture) are no longer available.
-# The DMA should been already stopped or paused.

<br>
<br>



\anchor PowerMgm4
<h2 style="color:#000000; background-color:#7696CB; font-weight :bold font-size : 14pt">  7A.3.1 How to Suspend and Resume</H2>

Audio driver is required to do every thing in suspend function. The job includes:
-# Enumerate each active audio processor
-# Enumerate each processor�s input and flush these inputs (The high level application should make sure the current state is PAUSE before go suspend, otherwise driver should return failure)
-#	Keep each input�s decoder parameters (Do not reinitialize or destroy these information)
-# Release/free decoder pipelines: psm_dec_pipe psm_pcm_in_pipe packetizer_pipe in DSP1
-# 	Release/free post process pipelines: psm_pass_pipe psm_pa_pipe in DSP0
-#	shutdown DSP0 & DSP1
-#	shutdown physical render and capture associated with each output/input handle
-#	Disable audio interface (I2S0, I2S1, SPDIF, I2Sc) via AU_IF_CLK or CGR
-#	Check the DMA of physical output/input is not active, if AU_IF_CLK is not available
-#	Finally if every thing goes well, return success to function caller
-#	Block any API who need to talk to audio registers, ismd_audio_resume() should still open to public.
NOTE: ATC thread is still running and wakes up each 10ms timeslot.

How to RESUME
<br>

And the resume function does the reverse. The job includes:
-#	Enumerate each suspended processor
-#	Enable CGR or AU_IF_CLK
-#	Enable physical render/capture associated with each output/input handle
-#	Enumerate each processor�s input and check individual input decoder�s parameters
-#	Reload DSP1, DSP0 firmware and boot/active DSP0/DSP1
-#	Allocate and reconfig (reconfig the parameters before suspend state) post process pipelines: psm_pass_pipe psm_pa_pipe in DSP0
-#	Allocate and reconfig (reconfig the parameters before suspend state) decoder pipelines: psm_dec_pipe psm_pcm_in_pipe packetizer_pipe in DSP1
-#	Then return success to function caller
-#	At this time Renders will automatically strobe resync event to ATC
-#	Unblock all API which blocked
These calling sequences are already proved to be correctly under prototype code.
And it is obviously that there will be a little audio frame lost during DSP suspending.

Following APIs will be used.
-# \ref ismd_audio_suspend(dev, ..)
-# \ref ismd_audio_resume(dev,.. )



     	 */

