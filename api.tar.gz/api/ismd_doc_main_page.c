/*

  This file is provided under a dual BSD/GPLv2 license.  When using or
  redistributing this file, you may do so under either license.

  GPL LICENSE SUMMARY

  Copyright(c) 2009 Intel Corporation. All rights reserved.

  This program is free software; you can redistribute it and/or modify
  it under the terms of version 2 of the GNU General Public License as
  published by the Free Software Foundation.

  This program is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 51 Franklin St - Fifth Floor, Boston, MA 02110-1301 USA.
  The full GNU General Public License is included in this distribution
  in the file called LICENSE.GPL.

  Contact Information:

  Intel Corporation
  2200 Mission College Blvd.
  Santa Clara, CA  97052

  BSD LICENSE

  Copyright(c) 2009 Intel Corporation. All rights reserved.
  All rights reserved.

  Redistribution and use in source and binary forms, with or without
  modification, are permitted provided that the following conditions
  are met:

    * Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    * Neither the name of Intel Corporation nor the names of its
      contributors may be used to endorse or promote products derived
      from this software without specific prior written permission.

  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

*/

/*! \mainpage Intel&reg; Streaming Media Drivers API
\htmlinclude chapter_header.html
<H1 style="color:#FFFFFF; background-color:#0860A8;font-weight:bold; font-size:18pt"> Preface</H1>

 This document is applicable to the Intel&reg; Media Processor CE 3100 and Intel&reg; Atom&tm; processor CE41xx series processors. In this document, both processors are referred to as the Intel&reg; CE Media Processors. When functional differences occur, applicability to platform/silicon will be delineated.
 SMD is an acronym for <em>Streaming Media DriversM</em>.  The SMD software covers most of the low level media drivers.  SMD contains two supported interfaces: GStreamer and C-API.  This document will cover the C-API only.  Separate documents are available for GStreamer. Please contact your Intel representative for these documents.
 The C-API consists of a C-level Linux user space API that applications and middleware can call to access the media drivers.  The C-API is written 100% in the C programming language.  The C-API is exposed to applications via a set of header files and Linux shared objects which access the kernel drivers.
 This document will cover the audio, video and demux systems.  In addition, some helper drivers like bufmon and SMD core will get coverage here.  Where possible, code samples will be provided in this document to assist programmers writing software on top of the C-API for integration of their middleware or applications to the Intel&reg; CE Media Processor.

<br>
<br>
<br>

<H1 style="color:#FFFFFF; background-color:#0860A8; font-weight:bold "> Contents</h1>
- \ref new_smd_arch "Chapter 1: SMD Architecture"
<br>
<br>
- \ref new_smd_core  "Chapter 2: SMD Core"
<br>
<br>
- \ref new_smd_demux "Chapter 3: SMD Demux"
<br>
<br>
- \ref new_smd_audio "Chapter 4: SMD Audio "
<br>
<br>
- \ref new_smd_video "Chapter 5: SMD Video "
<br>
<br>
- \ref new_smd_systems1 "Chapter 6: SMD Systems"
<br>
<br>
- \ref smd_doc_sample_app   "Chapter 7: SMD Sample App"
<br>
<br>
- \ref smd_doc_appendix "Chapter 8: SMD Appendix"
<br>

<br>
<br>

<H1 style="color:#FFFFFF; background-color:#0860A8; font-weight:bold "> Legal Statement</h1>

INFORMATION IN THIS DOCUMENT IS PROVIDED IN CONNECTION WITH INTEL PRODUCTS. NO LICENSE, EXPRESS OR IMPLIED, BY ESTOPPEL OR OTHERWISE, TO ANY INTELLECTUAL PROPERTY RIGHTS IS GRANTED BY THIS DOCUMENT. EXCEPT AS PROVIDED IN INTEL'S TERMS AND CONDITIONS OF SALE FOR SUCH PRODUCTS, INTEL ASSUMES NO LIABILITY WHATSOEVER, AND INTEL DISCLAIMS ANY EXPRESS OR IMPLIED WARRANTY, RELATING TO SALE AND/OR USE OF INTEL PRODUCTS INCLUDING LIABILITY OR WARRANTIES RELATING TO FITNESS FOR A PARTICULAR PURPOSE, MERCHANTABILITY, OR INFRINGEMENT OF ANY PATENT, COPYRIGHT OR OTHER INTELLECTUAL PROPERTY RIGHT.

The information provided in this report, and related materials and presentations, are intended to illustrate the effects of certain design variables as determined by modeling, and are neither a recommendation nor endorsement of any specific system-level design practices or targets.  The model results are based on a simulated notebook configuration, and do not describe or characterize the properties of any specific, existing system design.  A detailed description of the simulated notebook configuration is available upon request.

Intel products are not intended for use in medical, life saving, life sustaining applications.

Intel may make changes to specifications and product descriptions at any time, without notice.

Designers must not rely on the absence or characteristics of any features or instructions marked "reserved" or "undefined". Intel reserves these for future definition and shall have no responsibility whatsoever for conflicts or incompatibilities arising from future changes to them.

This manual may contain design defects or errors known as errata, which may cause the product to deviate from published specifications. Current characterized errata are available on request.

This manual as well as the software, hardware and/or technology described in it, if it is furnished under a license then it may only be used or copied in accordance with the terms of such license. The information in this document is furnished for informational use only, is subject to change without notice, and should not be construed as a commitment by Intel Corporation. Intel Corporation assumes no responsibility or liability for any errors or inaccuracies that may appear in this document or any software that may be provided in association with this document.

Except as permitted by any such license that may be provided with any Intel product no part of this document may be reproduced, stored in a retrieval system, or transmitted in any form or by any means without the express written consent of Intel Corporation.

I2C is a 2-wire communications bus/protocol developed by Philips.  SMBus is a subset of the I2C bus/protocol and was developed by Intel.  Implementations of the I2C bus/protocol may require licenses from various entities, including Philips Electronics N.V. and North American Philips Corporation.

Alert on LAN is a result of the Intel-IBM Advanced Manageability Alliance and is a trademark of IBM.

MPEG is an international standard for video compression/decompression promoted by ISO. Implementations of MPEG CODECs, or MPEG enabled platforms may require licenses from various entities, including Intel Corporation.

This document  may include modified and unmodified data taken from the GStreamer Application Development Manual and GStreamer Libraries Reference documentation, which are covered by the Open Content License. The License may be viewed at http://www.opencontent.org/opl.shtml all citations are listed at the end of this document.

Supply of this Implementation of Dolby technology does not convey a license nor imply a right under any patent, or any other industrial or intellectual property right of Dolby Laboratories, to use this Implementation in any finished end-user or ready-to-use final product.  It is hereby notified that a license for such use is required from Dolby Laboratories.

The Intel&reg; Media Processor CE 3100, Intel&reg; Atom&tm; processor CE4100, and Intel&reg; Atom&tm; processor CE4200 include graphics functionality based on the POWERVR&tm; SGX535 from Imagination Technologies.

BunnyPeople, Celeron, Celeron Inside, Centrino, Centrino logo, Chips, Core Inside, Dialogic, EtherExpress, ETOX, FlashFile, i386, i486, i960, iCOMP, InstantIP, Intel, Intel logo, Intel386, Intel486, Intel740, Intel&reg; Media Processor CE 3100, Intel&reg; Atom&tm; processor CE4100, Intel&reg; Atom&tm; processor CE4200, IntelDX2, IntelDX4, IntelSX2, Intel Core, Intel Inside, Intel Inside logo, Intel. Leap ahead., Intel. Leap ahead. logo, Intel NetBurst, Intel NetMerge, Intel NetStructure, Intel SingleDriver, Intel SpeedStep, Intel StrataFlash, Intel Viiv, Intel XScale, IPLink, Itanium, Itanium Inside, MCS, MMX, MMX logo, Optimizer logo, OverDrive, Paragon, PDCharm, Pentium, Pentium II Xeon, Pentium III Xeon, Performance at Your Command, Pentium Inside, skoool, Sound Mark, The Computer Inside., The Journey Inside, VTune, Xeon, Xeon Inside and Xircom are trademarks or registered trademarks of Intel Corporation or its subsidiaries in the United States and other countries.

Contact your local Intel sales office or your distributor to obtain the latest specifications and before placing your product order.

Copies of documents which have an ordering number and are referenced in this document, or other Intel literature may be obtained by calling 1-800-548-4725 or by visiting Intel's website at http://www.intel.com.

*Other names and brands may be claimed as the property of others.

Copyright &copy; 2011, Intel Corporation

*/

